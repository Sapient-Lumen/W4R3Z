# COPYRIGHT (C) 2020-2024 Nicotine+ Contributors
# COPYRIGHT (C) 2009-2011 quinox <quinox@users.sf.net>
# COPYRIGHT (C) 2007-2009 daelstorm <daelstorm@gmail.com>
# COPYRIGHT (C) 2003-2004 Hyriand <hyriand@thegraveyard.org>
# COPYRIGHT (C) 2001-2003 Alexander Kanavin
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
import zlib

from collections import deque
from itertools import islice

try:
    # Try faster module import first, if available
    from _md5 import md5  # pylint: disable=import-private-name
except ImportError:
    from hashlib import md5

from operator import itemgetter
from random import randint
from socket import inet_aton
from socket import inet_ntoa
from struct import Struct

from pynicotine.utils import UINT32_LIMIT
from pynicotine.utils import human_length

# This module contains message classes, that networking and UI thread
# exchange. Basically there are three types of messages: internal messages,
# server messages and p2p messages (between clients).


INT32_UNPACK = Struct("<i").unpack_from
DOUBLE_UINT32_UNPACK = Struct("<II").unpack_from
UINT16_UNPACK = Struct("<H").unpack_from
UINT32_UNPACK = Struct("<I").unpack_from
UINT64_UNPACK = Struct("<Q").unpack_from

BOOL_PACK = Struct("?").pack
UINT8_PACK = Struct("B").pack
INT32_PACK = Struct("<i").pack
UINT32_PACK = Struct("<I").pack
UINT64_PACK = Struct("<Q").pack

class AllowedFolderTokenSet(set):
    """Bound one-shot folder-content response grants by count and age.

    FolderContentsResponse bodies can be large. Keep the legacy set interface
    used by existing download code/tests, but make membership checks reject
    expired tokens and prevent stale grants from accumulating indefinitely.
    """

    __slots__ = ("token_times", "token_order")

    MAX_TOKENS = 100000
    TOKEN_TTL = 300

    def __init__(self):
        super().__init__()
        self.token_times = {}
        self.token_order = deque()

    def _discard_tracked(self, token):
        set.discard(self, token)
        self.token_times.pop(token, None)

    def _compact_order(self):
        self.token_order = deque(sorted(self.token_times.items(), key=itemgetter(1)))

    def _prune_expired(self, current_time=None):
        if current_time is None:
            current_time = time.monotonic()

        while self.token_order:
            token, token_time = self.token_order[0]
            current_token_time = self.token_times.get(token)

            if current_token_time != token_time:
                self.token_order.popleft()
                continue

            if current_time - token_time <= self.TOKEN_TTL:
                break

            self.token_order.popleft()
            self._discard_tracked(token)

    def _discard_oldest(self):
        while self.token_order:
            token, token_time = self.token_order.popleft()

            if self.token_times.get(token) != token_time:
                continue

            self._discard_tracked(token)
            return True

        return False

    def add(self, token):
        current_time = time.monotonic()
        self._prune_expired(current_time)

        if len(self.token_order) > max(1024, self.MAX_TOKENS * 2, (len(self) * 4)):
            self._compact_order()

        if token not in self:
            while len(self) >= self.MAX_TOKENS:
                if not self._discard_oldest():
                    break

            if len(self) >= self.MAX_TOKENS:
                return

        set.add(self, token)
        self.token_times[token] = current_time
        self.token_order.append((token, current_time))

    def discard(self, token):
        self._discard_tracked(token)

    def remove(self, token):
        set.remove(self, token)
        self.token_times.pop(token, None)

    def clear(self):
        set.clear(self)
        self.token_times.clear()
        self.token_order.clear()

    def __contains__(self, token):
        if not set.__contains__(self, token):
            return False

        token_time = self.token_times.get(token)

        if token_time is None:
            return True

        if time.monotonic() - token_time > self.TOKEN_TTL:
            self.discard(token)
            return False

        return True


FOLDER_TOKENS_ALLOWED = AllowedFolderTokenSet()

# Search-response tokens are long-lived enough that parser-level token checks
# alone still allow repeated heavyweight compressed responses from the same
# peer. Track accepted responders per token in the network-message parser so
# duplicates can be rejected before the large result body is decompressed.
SEARCH_RESPONSE_USERS_ACCEPTED = {}
MAX_SEARCH_RESPONSE_USERS_PER_TOKEN = 10000


def clear_search_response_users(token=None):
    """Forget parser-level search response grants for one token or all tokens."""

    if token is None:
        SEARCH_RESPONSE_USERS_ACCEPTED.clear()
        return

    SEARCH_RESPONSE_USERS_ACCEPTED.pop(token, None)


def release_search_response_user(token, username):
    """Release one parser-level responder grant for a search token.

    FileSearchResponse bodies are deduped before heavy decompression/parsing, but
    a response can still fail after parsing when delivery to the main thread is
    backpressured. In that case, forget only the responder that was not delivered
    so a later retry from the same peer is not rejected as a duplicate.
    """

    if username is None:
        username = ""

    accepted_users = SEARCH_RESPONSE_USERS_ACCEPTED.get(token)

    if accepted_users is None:
        return

    accepted_users.discard(username)

    if not accepted_users:
        SEARCH_RESPONSE_USERS_ACCEPTED.pop(token, None)


class SearchTokenSet(set):
    """Search tokens whose parser-level responder ledger follows membership.

    A token can be represented by multiple outbound server requests, most notably
    targeted/buddy searches where one local search token is sent to many users.
    Public search removal should drop the token immediately, while a lower-layer
    unsent-message rollback should only release the specific request grant that
    failed. Keep a small reference count for the latter without changing normal
    set membership semantics used by the parser and existing tests.
    """

    def __init__(self):
        super().__init__()
        self._counts = {}

    def add(self, token):
        if token not in self:
            clear_search_response_users(token)
            set.add(self, token)
            self._counts[token] = 1
            return

        self._counts[token] = self._counts.get(token, 1) + 1

    def release(self, token):
        """Release one outbound request grant for *token*.

        This is used when a server request was accepted into the local queue but
        failed later at packing/socket/output-buffer time. If other requests for
        the same token were already accepted, keep the parser grant alive.
        """

        count = self._counts.get(token)

        if count is None:
            return

        if count > 1:
            self._counts[token] = count - 1
            return

        self.discard(token)

    def discard(self, token):
        set.discard(self, token)
        self._counts.pop(token, None)
        clear_search_response_users(token)

    def remove(self, token):
        set.remove(self, token)
        self._counts.pop(token, None)
        clear_search_response_users(token)

    def clear(self):
        set.clear(self)
        self._counts.clear()
        clear_search_response_users()


SEARCH_TOKENS_ALLOWED = SearchTokenSet()


def consume_search_response_user(token, username):
    """Return True once per responder/token before heavy response parsing."""

    if username is None:
        username = ""

    accepted_users = SEARCH_RESPONSE_USERS_ACCEPTED.get(token)

    if accepted_users is None:
        accepted_users = SEARCH_RESPONSE_USERS_ACCEPTED[token] = set()

    if username in accepted_users:
        return False

    if len(accepted_users) >= MAX_SEARCH_RESPONSE_USERS_PER_TOKEN:
        SEARCH_TOKENS_ALLOWED.discard(token)
        return False

    accepted_users.add(username)
    return True


class AllowedResponseUsers(set):
    """Bound one-shot heavyweight peer response grants by count and age.

    Shared-file-list and user-info responses can be very large. A request
    grant should therefore be short-lived and bounded, even before the peer
    sends the corresponding response. Subclassing set preserves the existing
    call sites/tests that use add(), update(), discard(), clear() and
    membership checks directly. Network parsing should use is_allowed() so
    expired grants are not accepted.
    """

    __slots__ = ("grant_times",)

    MAX_GRANTS = 4096
    GRANT_TTL = 300

    def __init__(self):
        set.__init__(self)
        self.grant_times = {}

    def _prune_expired(self, current_time=None):
        if current_time is None:
            current_time = time.monotonic()

        expired_users = [
            username for username, grant_time in self.grant_times.items()
            if (current_time - grant_time) > self.GRANT_TTL
        ]

        for username in expired_users:
            self.discard(username)

    def _prune_to_capacity(self, current_time=None):
        self._prune_expired(current_time)

        while len(self) >= self.MAX_GRANTS:
            if self.grant_times:
                oldest_username = min(self.grant_times, key=self.grant_times.get)
            else:
                oldest_username = next(iter(self))

            self.discard(oldest_username)

    def add(self, username):
        if username in self:
            self.grant_times[username] = time.monotonic()
            return

        self._prune_to_capacity()
        set.add(self, username)
        self.grant_times[username] = time.monotonic()

    def update(self, usernames):
        for username in usernames:
            self.add(username)

    def discard(self, username):
        self.grant_times.pop(username, None)
        set.discard(self, username)

    def remove(self, username):
        self.grant_times.pop(username, None)
        set.remove(self, username)

    def clear(self):
        self.grant_times.clear()
        set.clear(self)

    def is_allowed(self, username, current_time=None):
        if username not in self:
            return False

        if current_time is None:
            current_time = time.monotonic()

        grant_time = self.grant_times.get(username)

        if grant_time is None:
            # Backwards-compatible fallback for tests or callers that bypassed
            # add(). Treat the current membership as fresh, but timestamp it so
            # it is bounded from now on.
            self.grant_times[username] = current_time
            return True

        if (current_time - grant_time) > self.GRANT_TTL:
            self.discard(username)
            return False

        return True

    def consume(self, username, current_time=None):
        if not self.is_allowed(username, current_time):
            return False

        self.discard(username)
        return True


class AllowedResponseCounter:
    """Bound one-shot grants for server responses without a response key."""

    __slots__ = ("grant_times",)

    MAX_GRANTS = 64
    GRANT_TTL = 300

    def __init__(self):
        from collections import deque
        self.grant_times = deque()

    def _prune_expired(self, current_time=None):
        if current_time is None:
            current_time = time.monotonic()

        while self.grant_times and (current_time - self.grant_times[0]) > self.GRANT_TTL:
            self.grant_times.popleft()

    def add(self):
        self._prune_expired()

        while len(self.grant_times) >= self.MAX_GRANTS:
            self.grant_times.popleft()

        self.grant_times.append(time.monotonic())

    def is_allowed(self, current_time=None):
        self._prune_expired(current_time)
        return bool(self.grant_times)

    def consume(self, current_time=None):
        self._prune_expired(current_time)

        if not self.grant_times:
            return False

        self.grant_times.popleft()
        return True

    def clear(self):
        self.grant_times.clear()


class AllowedResponseFlag:
    """Boolean request grant for deprecated stateful server feeds.

    Some server message streams are not one-shot responses with a useful key,
    but they are still only expected after the client explicitly opted in. Keep
    that state in the protocol layer so unsolicited stream messages can be
    rejected before parsing and materializing their payload.
    """

    __slots__ = ("enabled",)

    def __init__(self):
        self.enabled = False

    def allow(self):
        self.enabled = True

    def disallow(self):
        self.enabled = False

    def clear(self):
        self.enabled = False

    def is_allowed(self):
        return self.enabled


SHARED_FILE_LIST_USERS_ALLOWED = AllowedResponseUsers()
USER_INFO_USERS_ALLOWED = AllowedResponseUsers()
USER_INTERESTS_USERS_ALLOWED = AllowedResponseUsers()
ITEM_RECOMMENDATIONS_ALLOWED = AllowedResponseUsers()
ITEM_SIMILAR_USERS_ALLOWED = AllowedResponseUsers()
RECOMMENDATIONS_ALLOWED = AllowedResponseCounter()
GLOBAL_RECOMMENDATIONS_ALLOWED = AllowedResponseCounter()
SIMILAR_USERS_ALLOWED = AllowedResponseCounter()
GLOBAL_ROOM_FEED_ALLOWED = AllowedResponseFlag()


def clear_interests_response_grants():
    USER_INTERESTS_USERS_ALLOWED.clear()
    ITEM_RECOMMENDATIONS_ALLOWED.clear()
    ITEM_SIMILAR_USERS_ALLOWED.clear()
    RECOMMENDATIONS_ALLOWED.clear()
    GLOBAL_RECOMMENDATIONS_ALLOWED.clear()
    SIMILAR_USERS_ALLOWED.clear()


def clear_global_room_feed_grant():
    GLOBAL_ROOM_FEED_ALLOWED.clear()

MAX_LOG_ATTR_REPR_LENGTH = 2048
MAX_LOG_ATTR_COLLECTION_ITEMS = 5


def _format_log_attr_value(value, depth=0):
    """Return a bounded representation of a protocol/debug-log value."""

    if isinstance(value, memoryview):
        return f"<memoryview len={len(value)}>"

    if isinstance(value, (bytes, bytearray)):
        return f"<{value.__class__.__name__} len={len(value)}>"

    if depth >= 2:
        try:
            value_len = len(value)
        except TypeError:
            value_len = None

        if value_len is not None:
            return f"<{value.__class__.__name__} len={value_len}>"

    elif isinstance(value, dict):
        sample = [
            (_format_log_attr_value(key, depth + 1), _format_log_attr_value(item, depth + 1))
            for key, item in islice(value.items(), MAX_LOG_ATTR_COLLECTION_ITEMS)
        ]
        return f"<dict len={len(value)} sample={sample!r}>"

    elif isinstance(value, (list, tuple, set, frozenset)):
        value_type = value.__class__.__name__
        sample = [_format_log_attr_value(item, depth + 1)
                  for item in islice(value, MAX_LOG_ATTR_COLLECTION_ITEMS)]
        return f"<{value_type} len={len(value)} sample={sample!r}>"

    if isinstance(value, str):
        if len(value) > MAX_LOG_ATTR_REPR_LENGTH:
            omitted_chars = len(value) - MAX_LOG_ATTR_REPR_LENGTH
            return f"{value[:MAX_LOG_ATTR_REPR_LENGTH]!r}... <truncated {omitted_chars} chars>"

        return repr(value)

    value_repr = repr(value)

    if len(value_repr) > MAX_LOG_ATTR_REPR_LENGTH:
        omitted_chars = len(value_repr) - MAX_LOG_ATTR_REPR_LENGTH
        value_repr = f"{value_repr[:MAX_LOG_ATTR_REPR_LENGTH]}... <truncated {omitted_chars} chars>"

    return value_repr


def _format_log_attrs(message):
    return {
        slot: _format_log_attr_value(getattr(message, slot))
        for slot in message.__slots__
        if slot not in message.__excluded_attrs__
    }


def initial_token():
    """Return a random token in a large enough range to effectively prevent
    conflicting tokens between sessions."""
    return randint(0, UINT32_LIMIT // 1000)


def increment_token(token):
    """Increment a token used by file search, transfer and connection
    requests."""

    if token < 0 or token >= UINT32_LIMIT:
        # Protocol messages use unsigned integers for tokens
        token = 0

    token += 1
    return token


# Constants #


class MessageType:
    INTERNAL = "N"
    INIT = "I"
    SERVER = "S"
    PEER = "P"
    FILE = "F"
    DISTRIBUTED = "D"


class ConnectionType:
    SERVER = "S"
    PEER = "P"
    FILE = "F"
    DISTRIBUTED = "D"


class LoginFailure:
    USERNAME = "INVALIDUSERNAME"
    PASSWORD = "INVALIDPASS"
    VERSION = "INVALIDVERSION"


class UserStatus:
    OFFLINE = 0
    AWAY = 1
    ONLINE = 2


class TransferDirection:
    DOWNLOAD = 0
    UPLOAD = 1


class TransferRejectReason:
    QUEUED = "Queued"
    COMPLETE = "Complete"
    CANCELLED = "Cancelled"
    FILE_READ_ERROR = "File read error."
    FILE_NOT_SHARED = "File not shared."
    BANNED = "Banned"
    PENDING_SHUTDOWN = "Pending shutdown."
    TOO_MANY_FILES = "Too many files"
    TOO_MANY_MEGABYTES = "Too many megabytes"
    DISALLOWED_EXTENSION = "Disallowed extension"


class FileAttribute:
    BITRATE = 0
    DURATION = 1
    VBR = 2
    ENCODER = 3
    SAMPLE_RATE = 4
    BIT_DEPTH = 5


# Internal Messages #


class InternalMessage:
    __slots__ = ()
    __excluded_attrs__ = {}
    msg_type = MessageType.INTERNAL

    def __str__(self):
        return f"<{self.msg_type} - {self.__class__.__name__}> {_format_log_attrs(self)}"


class CloseConnection(InternalMessage):
    __slots__ = ("sock",)

    def __init__(self, sock=None):
        self.sock = sock


class ServerConnect(InternalMessage):
    """Sent to the networking thread to establish a server connection."""

    __slots__ = ("addr", "login", "interface_name", "interface_address", "listen_port",
                 "portmapper")
    __excluded_attrs__ = {"login"}

    def __init__(self, addr=None, login=None, interface_name=None, interface_address=None,
                 listen_port=None, portmapper=None):
        self.addr = addr
        self.login = login
        self.interface_name = interface_name
        self.interface_address = interface_address
        self.listen_port = listen_port
        self.portmapper = portmapper


class ServerDisconnect(InternalMessage):
    __slots__ = ("manual_disconnect",)

    def __init__(self, manual_disconnect=False):
        self.manual_disconnect = manual_disconnect


class ServerReconnect(InternalMessage):
    __slots__ = ("manual_reconnect",)

    def __init__(self, manual_reconnect=False):
        self.manual_reconnect = manual_reconnect


class EmitNetworkMessageEvents(InternalMessage):
    """Sent to the networking thread to tell it to emit events for list of
    network messages.

    Currently used after shares have rescanned to process any
    QueueUpload messages that arrived while scanning.
    """

    __slots__ = ("msgs",)

    def __init__(self, msgs=None):
        self.msgs = msgs


class DownloadFile(InternalMessage):
    """Sent to the networking thread to pass the file object to write."""

    __slots__ = ("sock", "token", "file", "leftbytes", "speed", "username")

    def __init__(self, sock=None, token=None, file=None, leftbytes=None, username=None):
        self.sock = sock
        self.token = token
        self.file = file
        self.leftbytes = leftbytes
        self.speed = 0
        self.username = username


class UploadFile(InternalMessage):
    __slots__ = ("sock", "token", "file", "size", "sentbytes", "offset", "speed", "username")

    def __init__(self, sock=None, token=None, file=None, size=None, sentbytes=0, offset=None, username=None):
        self.sock = sock
        self.token = token
        self.file = file
        self.size = size
        self.sentbytes = sentbytes
        self.offset = offset
        self.speed = 0
        self.username = username


class SetUploadLimit(InternalMessage):
    """Sent to the networking thread to indicate changes in bandwidth shaping rules."""

    __slots__ = ("limit", "limitby")

    def __init__(self, limit, limitby):
        self.limit = limit
        self.limitby = limitby


class SetDownloadLimit(InternalMessage):
    """Sent to the networking thread to indicate changes in bandwidth shaping rules."""

    __slots__ = ("limit",)

    def __init__(self, limit):
        self.limit = limit


# Network Messages #


class SlskMessage:
    """This is a parent class for all protocol messages."""

    __slots__ = ()
    __excluded_attrs__ = {}
    msg_type = None
    MAX_INCOMING_MESSAGE_SIZE = None
    MAX_DECOMPRESSED_MESSAGE_SIZE = 469762048  # 448 MiB, matches the incoming compressed message limit
    MAX_DECOMPRESSED_USERNAME_SIZE = 1024
    MAX_EMPTY_PEER_MESSAGE_SIZE = 4          # 4-byte peer message code, no payload
    MAX_EMPTY_DISTRIBUTED_MESSAGE_SIZE = 1   # 1-byte distributed message code, no payload
    MAX_TEXT_PEER_MESSAGE_SIZE = 262144      # Small legacy text/status messages
    MAX_PATH_PEER_MESSAGE_SIZE = 1048576     # Messages containing one or more virtual file paths
    MAX_TEXT_SERVER_MESSAGE_SIZE = 1048576   # Chat/search/ticker/admin messages from the server
    MAX_LIST_SERVER_MESSAGE_SIZE = 16777216  # Gross guardrail for large server-side metadata lists
    MAX_UNKNOWN_SERVER_MESSAGE_SIZE = 1048576
    MAX_SERVER_LIST_ITEMS = 100000           # Gross guardrail for server-declared lists
    MAX_UI_LIST_ITEMS = 20000                # Upper bound for lists normally materialized in GTK/core state
    MAX_RECOMMENDATION_ITEMS = 20000         # Recommendations can be rendered and deduplicated on receipt
    MAX_USER_INTEREST_ITEMS = 8192           # Likes/dislikes are shown in user-info lists
    MAX_RELATED_SEARCH_TERMS = 4096          # Small suggestion lists should not become UI/result storms
    MAX_EXCLUDED_SEARCH_PHRASES = 4096       # Each phrase is scanned against outgoing result paths
    MAX_PRIVATE_ROOM_USERS = 20000           # Private room rosters are retained and shown in room views
    MAX_PRIVATE_ROOM_OPERATORS = 4096        # Operator lists are usually tiny; keep the bound lower
    MAX_USERNAME_FIELD_BYTES = 1024          # Gross guardrail for server/peer-provided usernames
    MAX_ROOM_FIELD_BYTES = 1024              # Gross guardrail for server-provided room names
    MAX_CHAT_MESSAGE_FIELD_BYTES = 65536     # Avoid megabyte-scale chat/log/plugin processing
    MAX_SEARCH_TERM_FIELD_BYTES = 1024       # Avoid megabyte-scale search-term parsing
    MAX_TICKER_MESSAGE_FIELD_BYTES = 16384   # Tickers are retained/displayed; keep each bounded
    MAX_EXCLUDED_PHRASE_FIELD_BYTES = 256    # Each excluded phrase is matched against outgoing result paths
    MAX_COUNTRY_FIELD_BYTES = 16             # Country codes/names should never be large
    MAX_INTEREST_FIELD_BYTES = 4096          # Interests/recommendation strings can fan out in the UI
    MAX_CONNECTION_TYPE_FIELD_BYTES = 16     # Peer connection type is a tiny protocol token
    MAX_TRANSFER_REASON_FIELD_BYTES = 4096   # Avoid giant transfer status/log strings
    MAX_PASSWORD_FIELD_BYTES = 4096          # Local/configured credentials should never be large protocol fields
    MAX_OUTGOING_BULK_USERS = 5000           # Gross cap for protocol messages containing username lists
    MAX_OUTGOING_COMMAND_ARGS = 1024         # Obsolete admin command, but keep packing bounded
    MAX_COMPRESSED_PEER_MESSAGE_SIZE = 128 * 1024 * 1024  # Fits the peer non-file outgoing buffer cap
    # Distributed message sizes include the 1-byte distributed code. Most distributed
    # messages are tiny; keep their declared-size caps close to the real wire shape
    # so parents/servers cannot make us buffer and forward huge trailing payloads.
    MAX_DISTRIBUTED_SEARCH_MESSAGE_SIZE = (
        1 + 4 + (4 + MAX_USERNAME_FIELD_BYTES) + 4 + (4 + MAX_SEARCH_TERM_FIELD_BYTES)
    )
    MAX_DISTRIBUTED_USERNAME_MESSAGE_SIZE = 1 + 4 + MAX_USERNAME_FIELD_BYTES
    # DistribEmbeddedMessage carries its own distributed code. Older clients may encode
    # that embedded code as a uint32, so allow three compatibility bytes beyond the
    # normal embedded DistribSearch shape.
    MAX_EMBEDDED_DISTRIBUTED_MESSAGE_SIZE = MAX_DISTRIBUTED_SEARCH_MESSAGE_SIZE + 4

    @classmethod
    def decompress_message(cls, message, max_size=None):
        """Decompress a zlib-compressed message with a decompressed-size cap."""

        if max_size is None:
            max_size = cls.MAX_DECOMPRESSED_MESSAGE_SIZE

        decompressor = zlib.decompressobj()
        decompressed_message = decompressor.decompress(message, max_size)

        if decompressor.unconsumed_tail:
            raise ValueError("Decompressed message exceeds maximum size")

        if not decompressor.eof:
            raise ValueError("Compressed message is truncated")

        flushed_message = decompressor.flush()

        if flushed_message:
            decompressed_message += flushed_message

            if len(decompressed_message) > max_size:
                raise ValueError("Decompressed message exceeds maximum size")

        if decompressor.unused_data:
            raise ValueError("Trailing data found after compressed message")

        return decompressed_message

    @classmethod
    def finish_decompressing_message(cls, decompressor, prefix=b"", max_size=None, description="compressed message"):
        """Finish a bounded zlib decompression after an initial capped prefix read."""

        if max_size is None:
            max_size = cls.MAX_DECOMPRESSED_MESSAGE_SIZE

        if len(prefix) > max_size:
            raise ValueError(f"Decompressed {description} exceeds maximum size")

        max_remaining_size = max_size - len(prefix)

        try:
            suffix = decompressor.decompress(decompressor.unconsumed_tail, max_remaining_size)

        except zlib.error as error:
            raise ValueError(f"Compressed {description} is invalid") from error

        if decompressor.unconsumed_tail:
            raise ValueError(f"Decompressed {description} exceeds maximum size")

        if not decompressor.eof:
            raise ValueError(f"Compressed {description} is truncated")

        flushed_suffix = decompressor.flush()

        if flushed_suffix:
            suffix += flushed_suffix

            if len(suffix) > max_remaining_size:
                raise ValueError(f"Decompressed {description} exceeds maximum size")

        if decompressor.unused_data:
            raise ValueError(f"Trailing data found after compressed {description}")

        return prefix + suffix

    @staticmethod
    def compress_message_chunks(chunks, max_size=None, description="compressed message"):
        """Compress message chunks without first materializing one huge payload.

        The network layer enforces outgoing socket/buffer budgets after
        make_network_message() has returned a bytes object. Heavy peer
        responses should not build a giant compressed payload only for that
        later layer to reject it, so callers can pass a compressed-output cap
        and fail during compression.
        """

        compressor = zlib.compressobj()
        compressed = bytearray()

        def check_size():
            if max_size is not None and len(compressed) > max_size:
                raise ValueError(f"{description} exceeds maximum compressed size")

        for chunk in chunks:
            if chunk:
                compressed += compressor.compress(chunk)
                check_size()

        compressed += compressor.flush()
        check_size()
        return bytes(compressed)

    @staticmethod
    def check_message_count(count, max_count, description):
        """Validate a peer-declared record count before allocating result structures."""

        if count > max_count:
            raise ValueError(f"{description} count {count} exceeds maximum {max_count}")

    @staticmethod
    def pack_bytes(content):
        return UINT32_PACK(len(content)) + content

    @staticmethod
    def truncate_string_bytes(content, max_length, is_legacy=False):
        """Return a string that will fit within *max_length* encoded bytes.

        pack_string() can truncate the encoded payload, but a few protocol
        messages need the exact packed string value first (for example the
        login password checksum). Normalize and cap before hashing so the
        checksum matches the actually transmitted credentials, and so a corrupt
        config/plugin value cannot force a giant temporary encoded string.
        """

        if content is None:
            content = ""

        elif not isinstance(content, str):
            content = str(content)

        max_length = max(0, int(max_length))

        if len(content) > max_length:
            content = content[:max_length]

        if is_legacy:
            try:
                encoded = content.encode("latin-1")
                decoder = "latin-1"

            except UnicodeEncodeError:
                encoded = content.encode("utf-8", "replace")
                decoder = "utf-8"

        else:
            encoded = content.encode("utf-8", "replace")
            decoder = "utf-8"

        if len(encoded) <= max_length:
            return content

        encoded = encoded[:max_length]

        if decoder == "utf-8":
            return encoded.decode("utf-8", "ignore")

        return encoded.decode(decoder, "ignore")

    @staticmethod
    def pack_string(content, is_legacy=False, max_length=None, field_name="string"):
        """Pack a protocol string, optionally enforcing an outgoing byte cap.

        Network-buffer caps are applied after make_network_message() has
        already built the bytes object. Without a field-level cap, a user or
        plugin can hand us a giant chat/search/path string and force a large
        temporary allocation before the later transport budget has a chance to
        reject it. Keep caps at the field boundary for high-fanout text/path
        messages.
        """

        if max_length is not None:
            content = SlskMessage.truncate_string_bytes(content, max_length, is_legacy=is_legacy)

        elif content is None:
            content = ""

        elif not isinstance(content, str):
            content = str(content)

        if is_legacy:
            # Legacy string
            try:
                encoded = content.encode("latin-1")

            except UnicodeEncodeError:
                encoded = content.encode("utf-8", "replace")

        else:
            encoded = content.encode("utf-8", "replace")

        return UINT32_PACK(len(encoded)) + encoded

    @staticmethod
    def pack_bool(content):
        return BOOL_PACK(content)

    @staticmethod
    def pack_uint8(content):
        return UINT8_PACK(content)

    @staticmethod
    def pack_int32(content):
        return INT32_PACK(content)

    @staticmethod
    def pack_uint32(content):
        return UINT32_PACK(content)

    @staticmethod
    def pack_uint64(content):
        return UINT64_PACK(content)

    @staticmethod
    def unpack_bytes(message, start=0):

        length, = UINT32_UNPACK(message, start)
        start += 4
        end = start + length

        if end > len(message):
            raise ValueError("Byte field is truncated")

        content = message[start:end]

        return end, content.tobytes()

    @staticmethod
    def skip_bytes(message, start=0, max_length=None, field_name="byte"):

        length, = UINT32_UNPACK(message, start)

        if max_length is not None and length > max_length:
            raise ValueError(f"{field_name} field exceeds maximum size")

        start += 4
        end = start + length

        if end > len(message):
            raise ValueError("Byte field is truncated")

        return end

    @classmethod
    def unpack_limited_string(cls, message, start=0, max_length=None, field_name="string"):

        length, = UINT32_UNPACK(message, start)

        if max_length is not None and length > max_length:
            raise ValueError(f"{field_name} field exceeds maximum size")

        return cls.unpack_string(message, start)

    @classmethod
    def unpack_username(cls, message, start=0, field_name="username"):
        return cls.unpack_limited_string(message, start, cls.MAX_USERNAME_FIELD_BYTES, field_name)

    @classmethod
    def unpack_room_name(cls, message, start=0, field_name="room"):
        return cls.unpack_limited_string(message, start, cls.MAX_ROOM_FIELD_BYTES, field_name)

    @classmethod
    def unpack_interest(cls, message, start=0, field_name="interest"):
        return cls.unpack_limited_string(message, start, cls.MAX_INTEREST_FIELD_BYTES, field_name)

    @classmethod
    def unpack_virtual_path(cls, message, start=0, field_name="virtual path"):
        end, virtual_path = cls.unpack_limited_string(
            message, start, FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name)
        virtual_path = virtual_path.replace("/", "\\")

        if len(virtual_path.split("\\")) > FileListMessage.MAX_VIRTUAL_PATH_COMPONENTS:
            raise ValueError(f"{field_name} has too many path components")

        return end, virtual_path

    @staticmethod
    def unpack_string(message, start=0):

        length, = UINT32_UNPACK(message, start)
        start += 4
        end = start + length

        if end > len(message):
            raise ValueError("String field is truncated")

        content = message[start:end].tobytes()

        try:
            string = content.decode("utf-8")

        except UnicodeDecodeError:
            # Legacy strings
            string = content.decode("latin-1")

        return end, string

    @staticmethod
    def unpack_bool(message, start=0):
        return start + 1, bool(message[start])

    @staticmethod
    def unpack_ip(message, start=0):
        end = start + 4
        return end, inet_ntoa(message[start:end].tobytes()[::-1])

    @staticmethod
    def unpack_uint8(message, start=0):
        return start + 1, message[start]

    @staticmethod
    def unpack_uint16(message, start=0):
        result, = UINT16_UNPACK(message, start)
        return start + 2, result

    @staticmethod
    def unpack_int32(message, start=0):
        result, = INT32_UNPACK(message, start)
        return start + 4, result

    @staticmethod
    def unpack_uint32(message, start=0):
        result, = UINT32_UNPACK(message, start)
        return start + 4, result

    @staticmethod
    def unpack_uint64(message, start=0):
        result, = UINT64_UNPACK(message, start)
        return start + 8, result

    def __str__(self):
        return f"<{self.msg_type} - {self.__class__.__name__}> {_format_log_attrs(self)}"


class FileListMessage(SlskMessage):
    __slots__ = ()
    MAX_VIRTUAL_PATH_BYTES = 32768
    MAX_VIRTUAL_PATH_FIELD_MESSAGE_SIZE = 4 + MAX_VIRTUAL_PATH_BYTES
    MAX_ONE_PATH_PEER_MESSAGE_SIZE = 4 + MAX_VIRTUAL_PATH_FIELD_MESSAGE_SIZE
    MAX_ONE_PATH_UINT32_PEER_MESSAGE_SIZE = MAX_ONE_PATH_PEER_MESSAGE_SIZE + 4
    MAX_PATH_REASON_PEER_MESSAGE_SIZE = (
        MAX_ONE_PATH_PEER_MESSAGE_SIZE + 4 + SlskMessage.MAX_TRANSFER_REASON_FIELD_BYTES
    )
    MAX_TRANSFER_REQUEST_PEER_MESSAGE_SIZE = MAX_ONE_PATH_PEER_MESSAGE_SIZE + 4 + 4 + 8

    VALID_FILE_ATTRIBUTES = {
        FileAttribute.BITRATE,
        FileAttribute.DURATION,
        FileAttribute.VBR,
        FileAttribute.SAMPLE_RATE,
        FileAttribute.BIT_DEPTH
    }
    MAX_FILE_ATTRIBUTE_RECORDS = 64
    MAX_VIRTUAL_PATH_COMPONENTS = 512
    MAX_BASENAME_BYTES = 4096
    MAX_OBSOLETE_EXTENSION_BYTES = 4096
    MAX_SORTED_RESULT_FOLDERS = 50000
    MAX_SORTED_RESULT_FILES = 10000

    @classmethod
    def pack_file_info(cls, fileinfo):

        msg = bytearray()
        virtual_file_path, size, quality, duration = fileinfo
        bitrate = is_vbr = samplerate = bitdepth = None

        if quality is not None:
            bitrate, is_vbr, samplerate, bitdepth = quality

        msg += cls.pack_uint8(1)
        msg += cls.pack_string(
            virtual_file_path, max_length=cls.MAX_VIRTUAL_PATH_BYTES, field_name="virtual path")
        msg += cls.pack_uint64(size)
        msg += cls.pack_uint32(0)  # empty ext

        num_attrs = 0
        msg_attrs = bytearray()

        is_lossless = bitdepth is not None

        if is_lossless:
            if duration is not None:
                msg_attrs += cls.pack_uint32(1)
                msg_attrs += cls.pack_uint32(duration)
                num_attrs += 1

            if samplerate is not None:
                msg_attrs += cls.pack_uint32(4)
                msg_attrs += cls.pack_uint32(samplerate)
                num_attrs += 1

            if bitdepth is not None:
                msg_attrs += cls.pack_uint32(5)
                msg_attrs += cls.pack_uint32(bitdepth)
                num_attrs += 1
        else:
            if bitrate is not None:
                msg_attrs += cls.pack_uint32(0)
                msg_attrs += cls.pack_uint32(bitrate)
                num_attrs += 1

            if duration is not None:
                msg_attrs += cls.pack_uint32(1)
                msg_attrs += cls.pack_uint32(duration)
                num_attrs += 1

            if bitrate is not None:
                msg_attrs += cls.pack_uint32(2)
                msg_attrs += cls.pack_uint32(is_vbr)
                num_attrs += 1

        msg += cls.pack_uint32(num_attrs)

        if msg_attrs:
            msg += msg_attrs

        return msg

    @classmethod
    def parse_file_size(cls, message, pos):

        if message[pos + 7] == 255:
            # Soulseek NS bug: >2 GiB files show up as ~16 EiB when unpacking the size
            # as uint64 (8 bytes), due to the first 4 bytes containing the size, and the
            # last 4 bytes containing garbage (a value of 4294967295 bytes, integer limit).
            # Only unpack the first 4 bytes to work around this issue.

            pos, size = cls.unpack_uint32(message, pos)
            pos, _garbage = cls.unpack_uint32(message, pos)

        else:
            # Everything looks fine, parse size as usual
            pos, size = cls.unpack_uint64(message, pos)

        return pos, size

    @classmethod
    def get_file_attributes_end(cls, message, pos):

        pos, numattr = cls.unpack_uint32(message, pos)
        attributes_end = pos + (numattr * 8)

        if attributes_end > len(message):
            raise ValueError("File attribute list is truncated")

        return pos, numattr, attributes_end

    @classmethod
    def unpack_file_attributes(cls, message, pos):

        attrs = {}
        valid_file_attributes = cls.VALID_FILE_ATTRIBUTES
        pos, numattr, attributes_end = cls.get_file_attributes_end(message, pos)

        # Remote peers can choose numattr. Don't spend unbounded CPU time walking
        # millions of unknown records when only a few attribute IDs are meaningful.
        for _ in range(min(numattr, cls.MAX_FILE_ATTRIBUTE_RECORDS)):
            pos, attrnum = cls.unpack_uint32(message, pos)
            pos, attr = cls.unpack_uint32(message, pos)

            if attrnum in valid_file_attributes:
                attrs[attrnum] = attr

        return attributes_end, attrs

    @classmethod
    def skip_file_info(cls, message, pos):

        if pos >= len(message):
            raise ValueError("File record is truncated")

        pos += 1  # File code
        pos = cls.skip_bytes(message, pos, cls.MAX_BASENAME_BYTES, "file name")

        if pos + 8 > len(message):
            raise ValueError("File size field is truncated")

        pos += 8  # Size
        pos = cls.skip_bytes(message, pos, cls.MAX_OBSOLETE_EXTENSION_BYTES, "file extension")
        _pos, _numattr, attributes_end = cls.get_file_attributes_end(message, pos)

        return attributes_end

    @staticmethod
    def parse_file_attributes(attributes):

        if attributes is None:
            attributes = {}

        try:
            bitrate = attributes.get(FileAttribute.BITRATE)
            length = attributes.get(FileAttribute.DURATION)
            vbr = attributes.get(FileAttribute.VBR)
            sample_rate = attributes.get(FileAttribute.SAMPLE_RATE)
            bit_depth = attributes.get(FileAttribute.BIT_DEPTH)

        except AttributeError:
            # Legacy attribute list format used for shares lists saved in Nicotine+ 3.2.2 and earlier
            bitrate = length = vbr = sample_rate = bit_depth = None

            if len(attributes) == 3:
                attribute1, attribute2, attribute3 = attributes

                if attribute3 in {0, 1}:
                    bitrate = attribute1
                    length = attribute2
                    vbr = attribute3

                elif attribute3 > 1:
                    length = attribute1
                    sample_rate = attribute2
                    bit_depth = attribute3

            elif len(attributes) == 2:
                attribute1, attribute2 = attributes

                if attribute2 in {0, 1}:
                    bitrate = attribute1
                    vbr = attribute2

                elif attribute1 >= 8000 and attribute2 <= 64:
                    sample_rate = attribute1
                    bit_depth = attribute2

                else:
                    bitrate = attribute1
                    length = attribute2

        return bitrate, length, vbr, sample_rate, bit_depth

    @classmethod
    def parse_audio_quality_length(cls, filesize, attributes, always_show_bitrate=False):

        bitrate, length, vbr, sample_rate, bit_depth = cls.parse_file_attributes(attributes)

        if bitrate is None:
            if sample_rate and bit_depth:
                # Bitrate = sample rate (Hz) * word length (bits) * channel count
                # Bitrate = 44100 * 16 * 2
                bitrate = (sample_rate * bit_depth * 2) // 1000
            else:
                bitrate = -1

        if length is None:
            if bitrate > 0:
                # Dividing the file size by the bitrate in Bytes should give us a good enough approximation
                length = filesize // (bitrate * 125)
            else:
                length = -1

        # Ignore invalid values
        if bitrate <= 0 or bitrate > UINT32_LIMIT:
            bitrate = 0
            h_quality = ""

        elif sample_rate and bit_depth:
            h_quality = f"{sample_rate / 1000:.3g} kHz / {bit_depth} bit"

            if always_show_bitrate:
                h_quality += f" / {bitrate} kbps"
        else:
            h_quality = f"{bitrate} kbps"

            if vbr == 1:
                h_quality += " (vbr)"

        if length < 0 or length > UINT32_LIMIT:
            length = 0
            h_length = ""
        else:
            h_length = human_length(length)

        return h_quality, bitrate, h_length, length


class RecommendationsMessage(SlskMessage):
    __slots__ = ()

    @classmethod
    def populate_recommendations(cls, recommendations, unrecommendations, message, pos=0,
                                 seen_recommendations=None, seen_unrecommendations=None):
        pos, num = cls.unpack_uint32(message, pos)
        cls.check_message_count(num, cls.MAX_RECOMMENDATION_ITEMS, "recommendation")

        if seen_recommendations is None:
            seen_recommendations = set(recommendations)

        if seen_unrecommendations is None:
            seen_unrecommendations = set(unrecommendations)

        for _ in range(num):
            pos, key = cls.unpack_interest(message, pos, "recommendation")
            pos, rating = cls.unpack_int32(message, pos)

            lst = recommendations if rating >= 0 else unrecommendations
            seen = seen_recommendations if rating >= 0 else seen_unrecommendations
            item = (key, rating)

            if item not in seen:
                lst.append(item)
                seen.add(item)

        return pos

    @classmethod
    def parse_recommendations(cls, message, pos=0):
        recommendations = []
        unrecommendations = []
        seen_recommendations = set()
        seen_unrecommendations = set()

        pos = cls.populate_recommendations(
            recommendations, unrecommendations, message, pos, seen_recommendations, seen_unrecommendations)

        if message[pos:]:
            pos = cls.populate_recommendations(
                recommendations, unrecommendations, message, pos, seen_recommendations, seen_unrecommendations)

        return pos, recommendations, unrecommendations


class UserData:
    """When we join a room, the server sends us a bunch of these for each
    user."""

    __slots__ = ("username", "status", "avgspeed", "uploadnum", "unknown", "files", "dirs", "slotsfull", "country")

    def __init__(self, username=None, status=None, avgspeed=None, uploadnum=None, unknown=None, files=None, dirs=None,
                 slotsfull=None, country=None):
        self.username = username
        self.status = status
        self.avgspeed = avgspeed
        self.uploadnum = uploadnum
        self.unknown = unknown
        self.files = files
        self.dirs = dirs
        self.slotsfull = slotsfull
        self.country = country


class UsersMessage(SlskMessage):
    __slots__ = ()

    @classmethod
    def parse_users(cls, message, pos=0, max_users=None):
        """Parse a segmented room-user list with an optional retained-user cap.

        JoinRoom responses are segmented: usernames first, then status/stat/slot/
        country arrays by index. Core/UI state caps can be far lower than the
        protocol's gross server-list cap, so callers that only retain a bounded
        prefix should not allocate UserData objects for the discarded tail. Still
        consume and validate every segment so malformed/truncated responses are
        detected and the caller's offset remains correct.
        """

        pos, numusers = cls.unpack_uint32(message, pos)
        cls.check_message_count(numusers, cls.MAX_SERVER_LIST_ITEMS, "room user")

        if max_users is None:
            retained_users = numusers
        else:
            retained_users = min(numusers, max(0, int(max_users)))

        users = []
        for i in range(numusers):
            if i < retained_users:
                pos, username = cls.unpack_username(message, pos, "room username")
                users.append(UserData(username=username))
                continue

            # Discarded tail records still need bounds/truncation checks, but
            # do not need string decoding or UserData allocation.
            pos = cls.skip_bytes(message, pos, cls.MAX_USERNAME_FIELD_BYTES, "room username")

        pos, statuslen = cls.unpack_uint32(message, pos)
        if statuslen > numusers:
            raise ValueError("Room user status count exceeds username count")

        for i in range(statuslen):
            pos, status = cls.unpack_uint32(message, pos)

            if i < retained_users:
                users[i].status = status

        pos, statslen = cls.unpack_uint32(message, pos)
        if statslen > numusers:
            raise ValueError("Room user stats count exceeds username count")

        for i in range(statslen):
            pos, avgspeed = cls.unpack_uint32(message, pos)
            pos, uploadnum = cls.unpack_uint32(message, pos)
            pos, unknown = cls.unpack_uint32(message, pos)
            pos, files = cls.unpack_uint32(message, pos)
            pos, dirs = cls.unpack_uint32(message, pos)

            if i < retained_users:
                user_data = users[i]
                user_data.avgspeed = avgspeed
                user_data.uploadnum = uploadnum
                user_data.unknown = unknown
                user_data.files = files
                user_data.dirs = dirs

        pos, slotslen = cls.unpack_uint32(message, pos)
        if slotslen > numusers:
            raise ValueError("Room user slot count exceeds username count")

        for i in range(slotslen):
            pos, slotsfull = cls.unpack_uint32(message, pos)

            if i < retained_users:
                users[i].slotsfull = slotsfull

        pos, countrylen = cls.unpack_uint32(message, pos)
        if countrylen > numusers:
            raise ValueError("Room user country count exceeds username count")

        for i in range(countrylen):
            if i < retained_users:
                pos, country = cls.unpack_limited_string(
                    message, pos, cls.MAX_COUNTRY_FIELD_BYTES, "room user country")
                users[i].country = country
                continue

            pos = cls.skip_bytes(message, pos, cls.MAX_COUNTRY_FIELD_BYTES, "room user country")

        return pos, users


# Server Messages #


class ServerMessage(SlskMessage):
    __slots__ = ()
    msg_type = MessageType.SERVER
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_LIST_SERVER_MESSAGE_SIZE

    # Server msg_size includes the 4-byte message code. Most server control
    # messages are tiny, but inheriting the broad list-message cap lets a
    # buggy server/MITM make the network thread buffer megabytes of trailing
    # payload for messages whose useful body is only a few bytes. These helpers
    # keep class-level caps close to each message's wire shape.
    MAX_EMPTY_MESSAGE_SIZE = 4
    MAX_UINT32_MESSAGE_SIZE = 8
    MAX_BOOL_MESSAGE_SIZE = 5
    MAX_USERNAME_ONLY_MESSAGE_SIZE = 4 + 4 + SlskMessage.MAX_USERNAME_FIELD_BYTES
    MAX_ROOM_ONLY_MESSAGE_SIZE = 4 + 4 + SlskMessage.MAX_ROOM_FIELD_BYTES
    MAX_USER_BOOL_MESSAGE_SIZE = MAX_USERNAME_ONLY_MESSAGE_SIZE + 1
    MAX_USER_UINT32_MESSAGE_SIZE = MAX_USERNAME_ONLY_MESSAGE_SIZE + 4
    MAX_USER_STATUS_MESSAGE_SIZE = MAX_USERNAME_ONLY_MESSAGE_SIZE + 4 + 1
    MAX_USER_STATS_MESSAGE_SIZE = MAX_USERNAME_ONLY_MESSAGE_SIZE + (5 * 4)
    MAX_USER_ADDRESS_MESSAGE_SIZE = MAX_USERNAME_ONLY_MESSAGE_SIZE + 4 + 4 + 4 + 2
    MAX_WATCH_USER_MESSAGE_SIZE = MAX_USERNAME_ONLY_MESSAGE_SIZE + 1 + (6 * 4) + 4 + SlskMessage.MAX_COUNTRY_FIELD_BYTES
    MAX_ROOM_USER_MESSAGE_SIZE = (
        MAX_ROOM_ONLY_MESSAGE_SIZE + 4 + SlskMessage.MAX_USERNAME_FIELD_BYTES + (7 * 4)
        + 4 + SlskMessage.MAX_COUNTRY_FIELD_BYTES
    )
    MAX_LOGIN_MESSAGE_SIZE = (
        4 + 1 + 4 + SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES
        + 4 + 4 + 128 + 1
    )
    MAX_USERNAME_TOKEN_MESSAGE_SIZE = MAX_USERNAME_ONLY_MESSAGE_SIZE + 4
    MAX_USER_SEARCH_MESSAGE_SIZE = (
        MAX_USERNAME_ONLY_MESSAGE_SIZE + 4 + 4 + SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES
    )
    MAX_FILE_SEARCH_ROOM_MESSAGE_SIZE = 4 + 4 + 4 + 4 + SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES
    MAX_INTEREST_ONLY_MESSAGE_SIZE = 4 + 4 + SlskMessage.MAX_INTEREST_FIELD_BYTES
    MAX_ROOM_USERNAME_MESSAGE_SIZE = MAX_ROOM_ONLY_MESSAGE_SIZE + 4 + SlskMessage.MAX_USERNAME_FIELD_BYTES
    MAX_EXACT_FILE_SEARCH_MESSAGE_SIZE = (
        MAX_USERNAME_ONLY_MESSAGE_SIZE + 4
        + 4 + FileListMessage.MAX_BASENAME_BYTES
        + 4 + FileListMessage.MAX_VIRTUAL_PATH_BYTES
        + 8 + 4
    )
    MAX_TUNNELED_MESSAGE_SIZE = (
        MAX_USERNAME_ONLY_MESSAGE_SIZE + 4 + 4 + 4 + 4
        + 4 + SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES
    )
    MAX_RELATED_SEARCH_MESSAGE_SIZE = (
        4 + 4 + SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES + 4
        + (SlskMessage.MAX_RELATED_SEARCH_TERMS * (4 + SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES + 4))
    )
    MAX_EXCLUDED_SEARCH_PHRASES_MESSAGE_SIZE = (
        4 + 4 + (SlskMessage.MAX_EXCLUDED_SEARCH_PHRASES * (4 + SlskMessage.MAX_EXCLUDED_PHRASE_FIELD_BYTES))
    )
    MAX_BULK_PRIVATE_MESSAGE_SIZE = (
        4 + 4 + (SlskMessage.MAX_OUTGOING_BULK_USERS * (4 + SlskMessage.MAX_USERNAME_FIELD_BYTES))
        + 4 + SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES
    )


class Login(ServerMessage):
    """Server code 1.

    We send this to the server right after the connection has been
    established. Server responds with the greeting message.
    """

    __slots__ = ("username", "passwd", "version", "minorversion", "success", "reason",
                 "banner", "ip_address", "local_address", "server_address", "is_supporter")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_LOGIN_MESSAGE_SIZE
    __excluded_attrs__ = {"passwd"}

    def __init__(self, username=None, passwd=None, version=None, minorversion=None):
        self.username = username
        self.passwd = passwd
        self.version = version
        self.minorversion = minorversion
        self.success = None
        self.reason = None
        self.banner = None
        self.ip_address = None
        self.local_address = None
        self.server_address = None
        self.is_supporter = None

    def make_network_message(self):

        username = self.truncate_string_bytes(self.username, self.MAX_USERNAME_FIELD_BYTES)
        password = self.truncate_string_bytes(self.passwd, self.MAX_PASSWORD_FIELD_BYTES)

        msg = bytearray()
        msg += self.pack_string(username, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="login username")
        msg += self.pack_string(password, max_length=self.MAX_PASSWORD_FIELD_BYTES, field_name="login password")
        msg += self.pack_uint32(self.version)

        payload = username + password
        md5hash = md5(payload.encode()).hexdigest()
        msg += self.pack_string(md5hash)

        msg += self.pack_uint32(self.minorversion)

        return msg

    def parse_network_message(self, message):
        pos, self.success = self.unpack_bool(message)

        if not self.success:
            pos, self.reason = self.unpack_limited_string(
                message, pos, self.MAX_CHAT_MESSAGE_FIELD_BYTES, "login failure reason")
            return

        pos, self.banner = self.unpack_limited_string(
            message, pos, self.MAX_CHAT_MESSAGE_FIELD_BYTES, "login banner")
        pos, self.ip_address = self.unpack_ip(message, pos)
        pos, _checksum = self.unpack_limited_string(
            message, pos, 128, "login checksum")  # MD5 hexdigest of the password you sent
        pos, self.is_supporter = self.unpack_bool(message, pos)


class SetWaitPort(ServerMessage):
    """Server code 2.

    We send this to the server to indicate the port number that we
    listen on (2234 by default).
    """

    __slots__ = ("port",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self, port=None):
        self.port = port

    def make_network_message(self):
        return self.pack_uint32(self.port)


class GetPeerAddress(ServerMessage):
    """Server code 3.

    We send this to the server to ask for a peer's address (IP address
    and port), given the peer's username.
    """

    __slots__ = ("user", "ip_address", "port", "unknown", "obfuscated_port")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USER_ADDRESS_MESSAGE_SIZE

    def __init__(self, user=None):
        self.user = user
        self.ip_address = None
        self.port = None
        self.unknown = None
        self.obfuscated_port = None

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="address username")
        pos, self.ip_address = self.unpack_ip(message, pos)
        pos, self.port = self.unpack_uint32(message, pos)
        pos, self.unknown = self.unpack_uint32(message, pos)
        pos, self.obfuscated_port = self.unpack_uint16(message, pos)


class WatchUser(ServerMessage):
    """Server code 5.

    Used to be kept updated about a user's status. Whenever a user's status
    changes, the server sends a GetUserStatus message.

    Note that the server does not currently send stat updates (GetUserStats)
    when watching a user, only the initial stats in the WatchUser response.
    As a consequence, stats can be outdated.
    """

    __slots__ = ("user", "userexists", "status", "avgspeed", "uploadnum", "unknown", "files", "dirs",
                 "country", "contains_stats")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_WATCH_USER_MESSAGE_SIZE

    def __init__(self, user=None):
        self.user = user
        self.userexists = None
        self.status = None
        self.avgspeed = None
        self.uploadnum = None
        self.unknown = None
        self.files = None
        self.dirs = None
        self.country = None
        self.contains_stats = False

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="watched username")
        pos, self.userexists = self.unpack_bool(message, pos)

        if not message[pos:]:
            # User does not exist
            return

        self.contains_stats = True
        pos, self.status = self.unpack_uint32(message, pos)
        pos, self.avgspeed = self.unpack_uint32(message, pos)
        pos, self.uploadnum = self.unpack_uint32(message, pos)
        pos, self.unknown = self.unpack_uint32(message, pos)
        pos, self.files = self.unpack_uint32(message, pos)
        pos, self.dirs = self.unpack_uint32(message, pos)

        if not message[pos:]:
            # User is offline
            return

        pos, self.country = self.unpack_limited_string(
            message, pos, self.MAX_COUNTRY_FIELD_BYTES, "watched user country")


class UnwatchUser(ServerMessage):
    """Server code 6.

    Used when we no longer want to be kept updated about a user's status.
    """

    __slots__ = ("user",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_ONLY_MESSAGE_SIZE

    def __init__(self, user=None):
        self.user = user

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")


class GetUserStatus(ServerMessage):
    """Server code 7.

    The server tells us if a user has gone away or has returned.
    """

    __slots__ = ("user", "status", "privileged")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USER_STATUS_MESSAGE_SIZE

    def __init__(self, user=None, status=None):
        self.user = user
        self.status = status
        self.privileged = None

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="status username")
        pos, self.status = self.unpack_uint32(message, pos)
        pos, self.privileged = self.unpack_bool(message, pos)


class IgnoreUser(ServerMessage):
    """Server code 11.

    We send this to the server to tell a user we have ignored them.

    The server tells us a user has ignored us.

    OBSOLETE, no longer used
    """

    __slots__ = ("user",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_ONLY_MESSAGE_SIZE

    def __init__(self, user=None):
        self.user = user

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

    def parse_network_message(self, message):
        _pos, self.user = self.unpack_username(message, field_name="ignored username")


class UnignoreUser(ServerMessage):
    """Server code 12.

    We send this to the server to tell a user we are no longer ignoring them.

    The server tells us a user is no longer ignoring us.

    OBSOLETE, no longer used
    """

    __slots__ = ("user",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_ONLY_MESSAGE_SIZE

    def __init__(self, user=None):
        self.user = user

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

    def parse_network_message(self, message):
        _pos, self.user = self.unpack_username(message, field_name="unignored username")


class SayChatroom(ServerMessage):
    """Server code 13.

    Either we want to say something in the chatroom, or someone else
    did.
    """

    __slots__ = ("room", "message", "user", "formatted_message", "message_type")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self, room=None, message=None, user=None):
        self.room = room
        self.message = message
        self.user = user
        self.formatted_message = None
        self.message_type = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")
        msg += self.pack_string(self.message, max_length=self.MAX_CHAT_MESSAGE_FIELD_BYTES, field_name="chat message")

        return msg

    def parse_network_message(self, message):
        pos, self.room = self.unpack_limited_string(
            message, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="chat room")
        pos, self.user = self.unpack_limited_string(
            message, pos, self.MAX_USERNAME_FIELD_BYTES, "chat username")
        pos, self.message = self.unpack_limited_string(
            message, pos, self.MAX_CHAT_MESSAGE_FIELD_BYTES, "chat message")


class JoinRoom(ServerMessage):
    """Server code 14.

    We send this message to the server when we want to join a room. If
    the room doesn't exist, it is created.

    Server responds with this message when we join a room. Contains
    users list with data on everyone.

    As long as we're in the room, the server will automatically send us
    status/stat updates for room users, including ourselves, in the form
    of GetUserStatus and GetUserStats messages.

    Room names must meet certain requirements, otherwise the server will
    send a MessageUser message containing an error message. Requirements
    include:

      - Non-empty string
      - Only ASCII characters
      - 24 characters or fewer
      - No leading or trailing spaces
      - No consecutive spaces
    """

    __slots__ = ("room", "private", "owner", "users", "operators")
    MAX_JOIN_ROOM_USERS = SlskMessage.MAX_UI_LIST_ITEMS
    MAX_JOIN_ROOM_OPERATORS = SlskMessage.MAX_PRIVATE_ROOM_OPERATORS

    def __init__(self, room=None, private=False):
        self.room = room
        self.private = private
        self.owner = None
        self.users = []
        self.operators = []

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")
        msg += self.pack_uint32(1 if self.private else 0)

        return msg

    def parse_network_message(self, message):
        pos, self.room = self.unpack_room_name(message, field_name="joined room")
        pos, self.users = UsersMessage.parse_users(message, pos, max_users=self.MAX_JOIN_ROOM_USERS)

        if message[pos:]:
            self.private = True
            pos, self.owner = self.unpack_username(message, pos, "private room owner")

        if message[pos:] and self.private:
            pos, numops = self.unpack_uint32(message, pos)
            self.check_message_count(numops, self.MAX_SERVER_LIST_ITEMS, "private room operator")
            retained_operators = min(numops, self.MAX_JOIN_ROOM_OPERATORS)

            for i in range(numops):
                if i >= retained_operators:
                    pos = self.skip_bytes(message, pos, self.MAX_USERNAME_FIELD_BYTES, "private room operator")
                    continue

                pos, operator = self.unpack_username(message, pos, "private room operator")
                self.operators.append(operator)


class LeaveRoom(ServerMessage):
    """Server code 15.

    We send this to the server when we want to leave a room.
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self, room=None):
        self.room = room

    def make_network_message(self):
        return self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")

    def parse_network_message(self, message):
        _pos, self.room = self.unpack_room_name(message, field_name="left room")


class UserJoinedRoom(ServerMessage):
    """Server code 16.

    The server tells us someone has just joined a room we're in.
    """

    __slots__ = ("room", "userdata")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_USER_MESSAGE_SIZE

    def __init__(self):
        self.room = None
        self.userdata = None

    def parse_network_message(self, message):
        pos, self.room = self.unpack_room_name(message, field_name="joined user room")

        self.userdata = UserData()
        pos, self.userdata.username = self.unpack_username(message, pos, "joined room username")
        pos, self.userdata.status = self.unpack_uint32(message, pos)
        pos, self.userdata.avgspeed = self.unpack_uint32(message, pos)
        pos, self.userdata.uploadnum = self.unpack_uint32(message, pos)
        pos, self.userdata.unknown = self.unpack_uint32(message, pos)
        pos, self.userdata.files = self.unpack_uint32(message, pos)
        pos, self.userdata.dirs = self.unpack_uint32(message, pos)
        pos, self.userdata.slotsfull = self.unpack_uint32(message, pos)
        pos, self.userdata.country = self.unpack_limited_string(
            message, pos, self.MAX_COUNTRY_FIELD_BYTES, "joined room user country")


class UserLeftRoom(ServerMessage):
    """Server code 17.

    The server tells us someone has just left a room we're in.
    """

    __slots__ = ("room", "username")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE + 4 + SlskMessage.MAX_USERNAME_FIELD_BYTES

    def __init__(self):
        self.room = None
        self.username = None

    def parse_network_message(self, message):
        pos, self.room = self.unpack_room_name(message, field_name="left user room")
        pos, self.username = self.unpack_username(message, pos, "left room username")


class ConnectToPeer(ServerMessage):
    """Server code 18.

    We send this to the server to attempt an indirect connection with a user.
    The server forwards the message to the user, who in turn attempts to establish
    a connection to our IP address and port from their end.
    """

    __slots__ = ("token", "user", "conn_type", "ip_address", "port", "privileged", "unknown", "obfuscated_port")
    MAX_INCOMING_MESSAGE_SIZE = (
        ServerMessage.MAX_USERNAME_ONLY_MESSAGE_SIZE + 4 + SlskMessage.MAX_CONNECTION_TYPE_FIELD_BYTES
        + 4 + 4 + 4 + 1 + 4 + 4
    )

    def __init__(self, token=None, user=None, conn_type=None):
        self.token = token
        self.user = user
        self.conn_type = conn_type
        self.ip_address = None
        self.port = None
        self.privileged = None
        self.unknown = None
        self.obfuscated_port = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")
        msg += self.pack_string(self.conn_type, max_length=self.MAX_CONNECTION_TYPE_FIELD_BYTES, field_name="connection type")

        return msg

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="connect username")
        pos, self.conn_type = self.unpack_limited_string(
            message, pos, self.MAX_CONNECTION_TYPE_FIELD_BYTES, "connection type")
        pos, self.ip_address = self.unpack_ip(message, pos)
        pos, self.port = self.unpack_uint32(message, pos)
        pos, self.token = self.unpack_uint32(message, pos)
        pos, self.privileged = self.unpack_bool(message, pos)
        pos, self.unknown = self.unpack_uint32(message, pos)
        pos, self.obfuscated_port = self.unpack_uint32(message, pos)


class MessageUser(ServerMessage):
    """Server code 22.

    Chat phrase sent to someone or received by us in private.
    """

    __slots__ = ("user", "message", "message_id", "timestamp", "is_new_message", "formatted_message",
                 "message_type")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self, user=None, message=None):
        self.user = user
        self.message = message
        self.message_id = None
        self.timestamp = None
        self.is_new_message = True
        self.formatted_message = None
        self.message_type = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")
        msg += self.pack_string(self.message, max_length=self.MAX_CHAT_MESSAGE_FIELD_BYTES, field_name="chat message")

        return msg

    def parse_network_message(self, message):
        pos, self.message_id = self.unpack_uint32(message)
        pos, self.timestamp = self.unpack_uint32(message, pos)
        pos, self.user = self.unpack_limited_string(
            message, pos, self.MAX_USERNAME_FIELD_BYTES, "private-message username")
        pos, self.message = self.unpack_limited_string(
            message, pos, self.MAX_CHAT_MESSAGE_FIELD_BYTES, "private message")
        pos, self.is_new_message = self.unpack_bool(message, pos)


class MessageAcked(ServerMessage):
    """Server code 23.

    We send this to the server to confirm that we received a private
    message. If we don't send it, the server will keep sending the chat
    phrase to us.
    """

    __slots__ = ("msgid",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self, msgid=None):
        self.msgid = msgid

    def make_network_message(self):
        return self.pack_uint32(self.msgid)


class FileSearchRoom(ServerMessage):
    """Server code 25.

    We send this to the server when we search for something in a room.

    OBSOLETE, use RoomSearch server message
    """

    __slots__ = ("token", "roomid", "searchterm")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_FILE_SEARCH_ROOM_MESSAGE_SIZE

    def __init__(self, token=None, roomid=None, text=None):
        self.token = token
        self.roomid = roomid
        self.searchterm = text

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.token)
        msg += self.pack_uint32(self.roomid)
        msg += self.pack_string(self.searchterm, max_length=self.MAX_SEARCH_TERM_FIELD_BYTES, field_name="search term")

        return msg


class FileSearch(ServerMessage):
    """Server code 26.

    We send this to the server when we search for something.
    Alternatively, the server sends this message outside the distributed
    network to tell us that someone is searching for something,
    currently used for UserSearch and RoomSearch requests.

    The token is a number generated by the client and is used to track
    the search results.
    """

    __slots__ = ("token", "searchterm", "search_username")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self, token=None, text=None):
        self.token = token
        self.searchterm = text
        self.search_username = None

        if text:
            self.searchterm = " ".join(x for x in text.split() if x != "-")

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.searchterm, is_legacy=True, max_length=self.MAX_SEARCH_TERM_FIELD_BYTES, field_name="search term")

        return msg

    def parse_network_message(self, message):
        pos, self.search_username = self.unpack_limited_string(
            message, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="search username")
        pos, self.token = self.unpack_uint32(message, pos)
        pos, self.searchterm = self.unpack_limited_string(
            message, pos, self.MAX_SEARCH_TERM_FIELD_BYTES, "search term")


class SetStatus(ServerMessage):
    """Server code 28.

    We send our new status to the server. Status is a way to define
    whether we're available (online) or busy (away).

    When changing our own status, the server sends us a GetUserStatus
    message when enabling away status, but not when disabling it.

    1 = Away 2 = Online
    """

    __slots__ = ("status",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self, status=None):
        self.status = status

    def make_network_message(self):
        return self.pack_int32(self.status)


class ServerPing(ServerMessage):
    """Server code 32.

    We send this to the server at most once per minute to ensure the
    connection stays alive.

    The server used to send a response message in the past, but this is no
    longer the case.

    Nicotine+ uses TCP keepalive instead of sending this message.
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_EMPTY_MESSAGE_SIZE

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        """Obsolete."""


class SendConnectToken(ServerMessage):
    """Server code 33.

    OBSOLETE, no longer used
    """

    __slots__ = ("user", "token")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_TOKEN_MESSAGE_SIZE

    def __init__(self, user, token):
        self.user = user
        self.token = token

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")
        msg += self.pack_uint32(self.token)

        return msg

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="connect token username")
        pos, self.token = self.unpack_uint32(message, pos)


class SendDownloadSpeed(ServerMessage):
    """Server code 34.

    We used to send this after a finished download to let the server
    update the speed statistics for a user.

    OBSOLETE, use SendUploadSpeed server message
    """

    __slots__ = ("user", "speed")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_TOKEN_MESSAGE_SIZE

    def __init__(self, user=None, speed=None):
        self.user = user
        self.speed = speed

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")
        msg += self.pack_uint32(self.speed)

        return msg


class SharedFoldersFiles(ServerMessage):
    """Server code 35.

    We send this to server to indicate the number of folder and files
    that we share.
    """

    __slots__ = ("folders", "files")
    MAX_INCOMING_MESSAGE_SIZE = 4 + 4 + 4

    def __init__(self, folders=None, files=None):
        self.folders = folders
        self.files = files

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.folders)
        msg += self.pack_uint32(self.files)

        return msg


class GetUserStats(ServerMessage):
    """Server code 36.

    The server sends this to indicate a change in a user's statistics,
    if we've requested to watch the user in WatchUser previously. A
    user's stats can also be requested by sending a GetUserStats message
    to the server, but WatchUser should be used instead.
    """

    __slots__ = ("user", "avgspeed", "uploadnum", "unknown", "files", "dirs")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USER_STATS_MESSAGE_SIZE

    def __init__(self, user=None, avgspeed=None, files=None, dirs=None):
        self.user = user
        self.avgspeed = avgspeed
        self.files = files
        self.dirs = dirs
        self.uploadnum = None
        self.unknown = None

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="stats username")
        pos, self.avgspeed = self.unpack_uint32(message, pos)
        pos, self.uploadnum = self.unpack_uint32(message, pos)
        pos, self.unknown = self.unpack_uint32(message, pos)
        pos, self.files = self.unpack_uint32(message, pos)
        pos, self.dirs = self.unpack_uint32(message, pos)


class QueuedDownloads(ServerMessage):
    """Server code 40.

    The server sends this to indicate if someone has download slots
    available or not.

    OBSOLETE, no longer sent by the server
    """

    __slots__ = ("user", "slotsfull")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USER_UINT32_MESSAGE_SIZE

    def __init__(self):
        self.user = None
        self.slotsfull = None

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="queued-download username")
        pos, self.slotsfull = self.unpack_uint32(message, pos)


class Relogged(ServerMessage):
    """Server code 41.

    The server sends this if someone else logged in under our nickname,
    and then disconnects us.
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_EMPTY_MESSAGE_SIZE

    def parse_network_message(self, message):
        # Empty message
        pass


class UserSearch(ServerMessage):
    """Server code 42.

    We send this to the server when we search a specific user's shares.
    The token is a number generated by the client and is used to track
    the search results.

    In the past, the server sent us this message for UserSearch requests from
    other users. Today, the server sends a FileSearch message instead.
    """

    __slots__ = ("search_username", "token", "searchterm")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USER_SEARCH_MESSAGE_SIZE

    def __init__(self, search_username=None, token=None, text=None):
        self.search_username = search_username
        self.token = token
        self.searchterm = text

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.search_username, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="search username")
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.searchterm, is_legacy=True, max_length=self.MAX_SEARCH_TERM_FIELD_BYTES, field_name="search term")

        return msg

    def parse_network_message(self, message):
        """Obsolete."""
        pos, self.search_username = self.unpack_limited_string(
            message, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="search username")
        pos, self.token = self.unpack_uint32(message, pos)
        pos, self.searchterm = self.unpack_limited_string(
            message, pos, self.MAX_SEARCH_TERM_FIELD_BYTES, "search term")


class SimilarRecommendations(ServerMessage):
    """Server code 50.

    We send this to the server when we are adding a recommendation to our
    "My recommendations" list, and want to receive a list of similar
    recommendations.

    The server sends a list of similar recommendations to the one we want to
    add. Older versions of the official Soulseek client would display a dialog
    containing such recommendations, asking us if we want to add our original
    recommendation or one of the similar ones instead.

    OBSOLETE
    """

    __slots__ = ("recommendation", "similar_recommendations")

    def __init__(self, recommendation=None):
        self.recommendation = recommendation
        self.similar_recommendations = []

    def make_network_message(self):
        return self.pack_string(self.recommendation, max_length=self.MAX_INTEREST_FIELD_BYTES, field_name="recommendation")

    def parse_network_message(self, message):
        pos, self.recommendation = self.unpack_interest(message, field_name="recommendation")
        pos, num = self.unpack_uint32(message, pos)
        self.check_message_count(num, self.MAX_SERVER_LIST_ITEMS, "similar recommendation")

        for _ in range(num):
            pos, similar_recommendation = self.unpack_interest(
                message, pos, "similar recommendation")
            self.similar_recommendations.append(similar_recommendation)


class AddThingILike(ServerMessage):
    """Server code 51.

    We send this to the server when we add an item to our likes list.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("thing",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_INTEREST_ONLY_MESSAGE_SIZE

    def __init__(self, thing=None):
        self.thing = thing

    def make_network_message(self):
        return self.pack_string(self.thing, max_length=self.MAX_INTEREST_FIELD_BYTES, field_name="interest")


class RemoveThingILike(ServerMessage):
    """Server code 52.

    We send this to the server when we remove an item from our likes
    list.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("thing",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_INTEREST_ONLY_MESSAGE_SIZE

    def __init__(self, thing=None):
        self.thing = thing

    def make_network_message(self):
        return self.pack_string(self.thing, max_length=self.MAX_INTEREST_FIELD_BYTES, field_name="interest")


class Recommendations(ServerMessage):
    """Server code 54.

    The server sends us a list of personal recommendations and a number
    for each.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("recommendations", "unrecommendations", "is_allowed")

    def __init__(self):
        self.recommendations = []
        self.unrecommendations = []
        self.is_allowed = True

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        _pos, self.recommendations, self.unrecommendations = RecommendationsMessage.parse_recommendations(message)


class MyRecommendations(ServerMessage):
    """Server code 55.

    We send this to the server to ask for our own list of added
    likes/recommendations (called "My recommendations" in older versions
    of the official Soulseek client).

    The server sends us the list of recommendations it knows we have added.
    For any recommendations present locally, but not on the server, the
    official Soulseek client would send a AddThingILike message for each
    missing item.

    OBSOLETE
    """

    __slots__ = ("my_recommendations",)

    def __init__(self):
        self.my_recommendations = []

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        pos, num = self.unpack_uint32(message)
        self.check_message_count(num, self.MAX_RECOMMENDATION_ITEMS, "my recommendation")

        for _ in range(num):
            pos, recommendation = self.unpack_interest(message, pos, "my recommendation")
            self.my_recommendations.append(recommendation)


class GlobalRecommendations(ServerMessage):
    """Server code 56.

    The server sends us a list of global recommendations and a number
    for each.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("recommendations", "unrecommendations", "is_allowed")

    def __init__(self):
        self.recommendations = []
        self.unrecommendations = []
        self.is_allowed = True

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        _pos, self.recommendations, self.unrecommendations = RecommendationsMessage.parse_recommendations(message)


class UserInterests(ServerMessage):
    """Server code 57.

    We ask the server for a user's liked and hated interests. The server
    responds with a list of interests.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("user", "likes", "hates")

    def __init__(self, user=None):
        self.user = user
        self.likes = []
        self.hates = []

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="interest username")
        pos, likesnum = self.unpack_uint32(message, pos)
        self.check_message_count(likesnum, self.MAX_USER_INTEREST_ITEMS, "liked interest")

        for _ in range(likesnum):
            pos, key = self.unpack_interest(message, pos, "liked interest")

            self.likes.append(key)

        pos, hatesnum = self.unpack_uint32(message, pos)
        self.check_message_count(hatesnum, self.MAX_USER_INTEREST_ITEMS, "hated interest")

        for _ in range(hatesnum):
            pos, key = self.unpack_interest(message, pos, "hated interest")

            self.hates.append(key)


class AdminCommand(ServerMessage):
    """Server code 58.

    We send this to the server to run an admin command (e.g. to ban or
    silence a user) if we have admin status on the server.

    OBSOLETE, no longer used since Soulseek stopped supporting third-
    party servers in 2002
    """

    __slots__ = ("command", "command_args")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self, command=None, command_args=None):
        self.command = command
        self.command_args = command_args

    def make_network_message(self):
        msg = bytearray()
        command_args = tuple(islice(self.command_args or (), self.MAX_OUTGOING_COMMAND_ARGS))

        msg += self.pack_string(
            self.command, max_length=self.MAX_CHAT_MESSAGE_FIELD_BYTES, field_name="admin command")
        msg += self.pack_uint32(len(command_args))

        for arg in command_args:
            msg += self.pack_string(arg, max_length=self.MAX_CHAT_MESSAGE_FIELD_BYTES, field_name="command argument")

        return msg


class PlaceInLineResponse(ServerMessage):
    """Server code 60.

    The server sends this to indicate change in place in queue while
    we're waiting for files from another peer.

    OBSOLETE, use PlaceInQueueResponse peer message
    """

    __slots__ = ("token", "user", "place")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_ONLY_MESSAGE_SIZE + 8

    def __init__(self, user=None, token=None, place=None):
        self.token = token
        self.user = user
        self.place = place

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")
        msg += self.pack_uint32(self.token)
        msg += self.pack_uint32(self.place)

        return msg

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="privileged query username")
        pos, self.token = self.unpack_uint32(message, pos)
        pos, self.place = self.unpack_uint32(message, pos)


class RoomAdded(ServerMessage):
    """Server code 62.

    The server tells us a new room has been added.

    OBSOLETE, no longer sent by the server
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self):
        self.room = None

    def parse_network_message(self, message):
        _pos, self.room = self.unpack_room_name(message, field_name="added room")


class RoomRemoved(ServerMessage):
    """Server code 63.

    The server tells us a room has been removed.

    OBSOLETE, no longer sent by the server
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self):
        self.room = None

    def parse_network_message(self, message):
        _pos, self.room = self.unpack_room_name(message, field_name="removed room")


class RoomList(ServerMessage):
    """Server code 64.

    The server tells us a list of rooms and the number of users in them.
    When connecting to the server, the server only sends us rooms with
    at least 5 users. A few select rooms are also excluded, such as
    nicotine and The Lobby. Requesting the room list yields a response
    containing the missing rooms.
    """

    __slots__ = ("rooms", "ownedprivaterooms", "otherprivaterooms", "operatedprivaterooms")
    MAX_TOTAL_ROOM_LIST_ITEMS = SlskMessage.MAX_UI_LIST_ITEMS

    def __init__(self):
        self.rooms = []
        self.ownedprivaterooms = []
        self.otherprivaterooms = []
        self.operatedprivaterooms = []

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        pos = 0
        total_retained_rooms = 0

        for attr_name, has_count in (
                ("rooms", True),
                ("ownedprivaterooms", True),
                ("otherprivaterooms", True),
                ("operatedprivaterooms", False)):
            remaining_rooms = max(0, self.MAX_TOTAL_ROOM_LIST_ITEMS - total_retained_rooms)
            pos, rooms = self.parse_rooms(message, pos, has_count=has_count, retain_items=remaining_rooms)
            setattr(self, attr_name, rooms)
            total_retained_rooms += len(rooms)

    def parse_rooms(self, message, pos=0, has_count=True, retain_items=None):
        """Parse one room-list section while retaining only a bounded prefix.

        A server response can contain several room sections. Once the combined
        UI-facing cap is reached, still consume and validate the remaining wire
        records so malformed tails are rejected, but avoid retaining or decoding
        more room names for GTK/core lists.
        """

        pos, numrooms = self.unpack_uint32(message, pos)
        self.check_message_count(numrooms, self.MAX_SERVER_LIST_ITEMS, "room")

        if retain_items is None:
            retained_rooms = numrooms
        else:
            retained_rooms = min(numrooms, max(0, int(retain_items)))

        rooms = []
        for i in range(numrooms):
            if i >= retained_rooms:
                pos = self.skip_bytes(message, pos, self.MAX_ROOM_FIELD_BYTES, "room list room")
                continue

            pos, room = self.unpack_room_name(message, pos, "room list room")

            if has_count:
                rooms.append([room, None])
            else:
                rooms.append(room)

        if not has_count:
            return pos, rooms

        pos, numusers = self.unpack_uint32(message, pos)
        self.check_message_count(numusers, self.MAX_SERVER_LIST_ITEMS, "room user-count")

        if numusers != numrooms:
            raise ValueError("Room list contains mismatched room and user-count records")

        for i in range(numusers):
            pos, usercount = self.unpack_uint32(message, pos)

            if i < retained_rooms:
                rooms[i][1] = usercount

        return pos, rooms


class ExactFileSearch(ServerMessage):
    """Server code 65.

    We send this to search for an exact file name and folder, to find
    other sources.

    OBSOLETE, no results even with official client
    """

    __slots__ = ("token", "file", "folder", "size", "checksum", "user", "unknown")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_EXACT_FILE_SEARCH_MESSAGE_SIZE

    def __init__(self, token=None, file=None, folder=None, size=None, checksum=None, unknown=None):
        self.token = token
        self.file = file
        self.folder = folder
        self.size = size
        self.checksum = checksum
        self.unknown = unknown
        self.user = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.file, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="virtual path")
        msg += self.pack_string(self.folder, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="folder path")
        msg += self.pack_uint64(self.size)
        msg += self.pack_uint32(self.checksum)
        msg += self.pack_uint8(self.unknown)

        return msg

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="exact search username")
        pos, self.token = self.unpack_uint32(message, pos)
        pos, self.file = self.unpack_limited_string(
            message, pos, FileListMessage.MAX_BASENAME_BYTES, "exact search file")
        pos, self.folder = self.unpack_virtual_path(message, pos, "exact search folder")
        pos, self.size = self.unpack_uint64(message, pos)
        pos, self.checksum = self.unpack_uint32(message, pos)


class AdminMessage(ServerMessage):
    """Server code 66.

    A global message from the server admin has arrived.
    """

    __slots__ = ("msg",)
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self):
        self.msg = None

    def parse_network_message(self, message):
        _pos, self.msg = self.unpack_limited_string(
            message, max_length=self.MAX_CHAT_MESSAGE_FIELD_BYTES, field_name="global admin message")


class GlobalUserList(ServerMessage):
    """Server code 67.

    We send this to get a global list of all users online.

    OBSOLETE, no longer used
    """

    __slots__ = ("users",)
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_LIST_SERVER_MESSAGE_SIZE

    def __init__(self):
        self.users = None

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        _pos, self.users = UsersMessage.parse_users(message)


class TunneledMessage(ServerMessage):
    """Server code 68.

    Server message for tunneling a chat message.

    OBSOLETE, no longer used
    """

    __slots__ = ("user", "token", "code", "msg", "addr")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_TUNNELED_MESSAGE_SIZE

    def __init__(self, user=None, token=None, code=None, msg=None):
        self.user = user
        self.token = token
        self.code = code
        self.msg = msg
        self.addr = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")
        msg += self.pack_uint32(self.token)
        msg += self.pack_uint32(self.code)
        msg += self.pack_string(self.msg, max_length=self.MAX_TICKER_MESSAGE_FIELD_BYTES, field_name="ticker message")

        return msg

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="tunneled username")
        pos, self.code = self.unpack_uint32(message, pos)
        pos, self.token = self.unpack_uint32(message, pos)

        pos, ip_address = self.unpack_ip(message, pos)
        pos, port = self.unpack_uint32(message, pos)
        self.addr = (ip_address, port)

        pos, self.msg = self.unpack_limited_string(
            message, pos, self.MAX_CHAT_MESSAGE_FIELD_BYTES, "tunneled message")


class PrivilegedUsers(ServerMessage):
    """Server code 69.

    The server sends us a list of privileged users, a.k.a. users who
    have donated.
    """

    __slots__ = ("users",)
    MAX_RETAINED_PRIVILEGED_USERS = SlskMessage.MAX_UI_LIST_ITEMS

    def __init__(self):
        self.users = []

    def parse_network_message(self, message):
        pos, numusers = self.unpack_uint32(message)
        self.check_message_count(numusers, self.MAX_SERVER_LIST_ITEMS, "privileged user")

        for index in range(numusers):
            if index >= self.MAX_RETAINED_PRIVILEGED_USERS:
                pos = self.skip_bytes(message, pos, self.MAX_USERNAME_FIELD_BYTES, "privileged username")
                continue

            pos, user = self.unpack_username(message, pos, "privileged username")

            self.users.append(user)


class HaveNoParent(ServerMessage):
    """Server code 71.

    We inform the server if we have a distributed parent or not. If not,
    the server eventually sends us a PossibleParents message with a list
    of 10 possible parents to connect to.
    """

    __slots__ = ("noparent",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_BOOL_MESSAGE_SIZE

    def __init__(self, noparent=None):
        self.noparent = noparent

    def make_network_message(self):
        return self.pack_bool(self.noparent)


class SearchParent(ServerMessage):
    """Server code 73.

    We send the IP address of our parent to the server.

    DEPRECATED, sent by Soulseek NS but not SoulseekQt
    """

    __slots__ = ("parentip",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self, parentip=None):
        self.parentip = parentip

    @staticmethod
    def strunreverse(string):
        strlist = string.split(".")
        strlist.reverse()
        return ".".join(strlist)

    def make_network_message(self):
        return self.pack_uint32(inet_aton(self.strunreverse(self.parentip)))


class ParentMinSpeed(ServerMessage):
    """Server code 83.

    The server informs us about the minimum upload speed required to
    become a parent in the distributed network.
    """

    __slots__ = ("speed",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self):
        self.speed = None

    def parse_network_message(self, message):
        _pos, self.speed = self.unpack_uint32(message)


class ParentSpeedRatio(ServerMessage):
    """Server code 84.

    The server sends us a speed ratio determining the number of children
    we can have in the distributed network. The maximum number of
    children is our upload speed divided by the speed ratio.
    """

    __slots__ = ("ratio",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self):
        self.ratio = None

    def parse_network_message(self, message):
        _pos, self.ratio = self.unpack_uint32(message)


class ParentInactivityTimeout(ServerMessage):
    """Server code 86.

    OBSOLETE, no longer sent by the server
    """

    __slots__ = ("seconds",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self):
        self.seconds = None

    def parse_network_message(self, message):
        _pos, self.seconds = self.unpack_uint32(message)


class SearchInactivityTimeout(ServerMessage):
    """Server code 87.

    OBSOLETE, no longer sent by the server
    """

    __slots__ = ("seconds",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self):
        self.seconds = None

    def parse_network_message(self, message):
        _pos, self.seconds = self.unpack_uint32(message)


class MinParentsInCache(ServerMessage):
    """Server code 88.

    OBSOLETE, no longer sent by the server
    """

    __slots__ = ("num",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self):
        self.num = None

    def parse_network_message(self, message):
        _pos, self.num = self.unpack_uint32(message)


class DistribPingInterval(ServerMessage):
    """Server code 90.

    OBSOLETE, no longer sent by the server
    """

    __slots__ = ("seconds",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self):
        self.seconds = None

    def parse_network_message(self, message):
        _pos, self.seconds = self.unpack_uint32(message)


class AddToPrivileged(ServerMessage):
    """Server code 91.

    The server sends us the username of a new privileged user, which we
    add to our list of global privileged users.

    OBSOLETE, no longer sent by the server
    """

    __slots__ = ("user",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_ONLY_MESSAGE_SIZE

    def __init__(self):
        self.user = None

    def parse_network_message(self, message):
        _pos, self.user = self.unpack_username(message, field_name="privileged username")


class CheckPrivileges(ServerMessage):
    """Server code 92.

    We ask the server how much time we have left of our privileges. The
    server responds with the remaining time, in seconds.
    """

    __slots__ = ("seconds",)
    MAX_INCOMING_MESSAGE_SIZE = 12

    def __init__(self):
        self.seconds = None

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        _pos, self.seconds = self.unpack_uint32(message)


class EmbeddedMessage(ServerMessage):
    """Server code 93.

    The server sends us an embedded distributed message. The only type
    of distributed message sent at present is DistribSearch (distributed
    code 3). If we receive such a message, we are a branch root in the
    distributed network, and we distribute the embedded message (not the
    unpacked distributed message) to our child peers.
    """

    __slots__ = ("distrib_code", "distrib_message")
    # Server msg_size includes the 4-byte server message code. The embedded
    # distributed payload currently supports DistribSearch; keep the cap close
    # to that wire shape instead of the broad text-message cap.
    MAX_INCOMING_MESSAGE_SIZE = 4 + SlskMessage.MAX_DISTRIBUTED_SEARCH_MESSAGE_SIZE

    def __init__(self):
        self.distrib_code = None
        self.distrib_message = None

    def parse_network_message(self, message):
        pos, self.distrib_code = self.unpack_uint8(message)
        self.distrib_message = message[pos:].tobytes()


class AcceptChildren(ServerMessage):
    """Server code 100.

    We tell the server if we want to accept child nodes.
    """

    __slots__ = ("enabled",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_BOOL_MESSAGE_SIZE

    def __init__(self, enabled=None):
        self.enabled = enabled

    def make_network_message(self):
        return self.pack_bool(self.enabled)


class PossibleParents(ServerMessage):
    """Server code 102.

    The server send us a list of 10 possible distributed parents to
    connect to. This message is sent to us at regular intervals until we
    tell the server we don't need more possible parents, through a
    HaveNoParent message.
    """

    __slots__ = ("list",)
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_LIST_SERVER_MESSAGE_SIZE
    MAX_POSSIBLE_PARENTS = 64

    def __init__(self):
        self.list = {}

    def parse_network_message(self, message):
        pos, num = self.unpack_uint32(message)
        self.check_message_count(num, self.MAX_POSSIBLE_PARENTS, "possible parent")

        for _ in range(num):
            pos, username = self.unpack_username(message, pos, "possible parent username")
            pos, ip_address = self.unpack_ip(message, pos)
            pos, port = self.unpack_uint32(message, pos)

            self.list[username] = (ip_address, port)


class WishlistSearch(FileSearch):
    """Server code 103.

    We send the server one of our wishlist search queries at each
    interval.
    """

    __slots__ = ()


class WishlistInterval(ServerMessage):
    """Server code 104.

    The server tells us the wishlist search interval.
    """

    __slots__ = ("seconds",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self):
        self.seconds = None

    def parse_network_message(self, message):
        _pos, self.seconds = self.unpack_uint32(message)


class SimilarUsers(ServerMessage):
    """Server code 110.

    The server sends us a list of similar users related to our
    interests.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("users", "is_allowed")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_LIST_SERVER_MESSAGE_SIZE

    def __init__(self):
        self.users = {}
        self.is_allowed = True

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        pos, num = self.unpack_uint32(message)
        self.check_message_count(num, self.MAX_UI_LIST_ITEMS, "similar user")

        for _ in range(num):
            pos, user = self.unpack_username(message, pos, "similar username")
            pos, rating = self.unpack_uint32(message, pos)

            self.users[user] = rating


class ItemRecommendations(ServerMessage):
    """Server code 111.

    The server sends us a list of recommendations related to a specific
    item, which is usually present in the like/dislike list or an
    existing recommendation list.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("thing", "recommendations", "unrecommendations", "is_allowed")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_LIST_SERVER_MESSAGE_SIZE

    def __init__(self, thing=None):
        self.thing = thing
        self.recommendations = []
        self.unrecommendations = []
        self.is_allowed = True

    def make_network_message(self):
        return self.pack_string(self.thing, max_length=self.MAX_INTEREST_FIELD_BYTES, field_name="interest")

    def parse_network_message(self, message):
        pos, self.thing = self.unpack_interest(message, field_name="recommendation item")
        pos, self.recommendations, self.unrecommendations = RecommendationsMessage.parse_recommendations(message, pos)


class ItemSimilarUsers(ServerMessage):
    """Server code 112.

    The server sends us a list of similar users related to a specific
    item, which is usually present in the like/dislike list or
    recommendation list.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("thing", "users", "is_allowed")

    def __init__(self, thing=None):
        self.thing = thing
        self.users = []
        self.is_allowed = True

    def make_network_message(self):
        return self.pack_string(self.thing, max_length=self.MAX_INTEREST_FIELD_BYTES, field_name="interest")

    def parse_network_message(self, message):
        pos, self.thing = self.unpack_interest(message, field_name="similar-user item")
        pos, num = self.unpack_uint32(message, pos)
        self.check_message_count(num, self.MAX_UI_LIST_ITEMS, "similar item user")

        for _ in range(num):
            pos, user = self.unpack_username(message, pos, "similar item username")
            self.users.append(user)


class RoomTickerState(ServerMessage):
    """Server code 113.

    The server returns a list of tickers in a chat room.

    Tickers are customizable, user-specific messages that appear on chat
    room walls.
    """

    __slots__ = ("room", "user", "msgs", "num_tickers")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_LIST_SERVER_MESSAGE_SIZE
    MAX_ROOM_TICKERS = 1000

    def __init__(self):
        self.room = None
        self.user = None
        self.msgs = []
        self.num_tickers = 0

    def parse_network_message(self, message):
        pos, self.room = self.unpack_limited_string(
            message, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="ticker room")
        pos, self.num_tickers = self.unpack_uint32(message, pos)
        self.check_message_count(self.num_tickers, self.MAX_SERVER_LIST_ITEMS, "room ticker")

        for index in range(self.num_tickers):
            if index >= self.MAX_ROOM_TICKERS:
                pos = self.skip_bytes(message, pos, self.MAX_USERNAME_FIELD_BYTES, "ticker username")
                pos = self.skip_bytes(message, pos, self.MAX_TICKER_MESSAGE_FIELD_BYTES, "ticker message")
                continue

            pos, user = self.unpack_limited_string(
                message, pos, self.MAX_USERNAME_FIELD_BYTES, "ticker username")
            pos, msg = self.unpack_limited_string(
                message, pos, self.MAX_TICKER_MESSAGE_FIELD_BYTES, "ticker message")

            self.msgs.append((user, msg))


class RoomTickerAdd(ServerMessage):
    """Server code 114.

    The server sends us a new ticker that was added to a chat room.

    Tickers are customizable, user-specific messages that appear on chat
    room walls.
    """

    __slots__ = ("room", "user", "msg")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self):
        self.room = None
        self.user = None
        self.msg = None

    def parse_network_message(self, message):
        pos, self.room = self.unpack_limited_string(
            message, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="ticker room")
        pos, self.user = self.unpack_limited_string(
            message, pos, self.MAX_USERNAME_FIELD_BYTES, "ticker username")
        pos, self.msg = self.unpack_limited_string(
            message, pos, self.MAX_TICKER_MESSAGE_FIELD_BYTES, "ticker message")


class RoomTickerRemove(ServerMessage):
    """Server code 115.

    The server informs us that a ticker was removed from a chat room.

    Tickers are customizable, user-specific messages that appear on chat
    room walls.
    """

    __slots__ = ("room", "user")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self):
        self.room = None
        self.user = None

    def parse_network_message(self, message):
        pos, self.room = self.unpack_limited_string(
            message, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="ticker room")
        pos, self.user = self.unpack_limited_string(
            message, pos, self.MAX_USERNAME_FIELD_BYTES, "ticker username")


class RoomTickerSet(ServerMessage):
    """Server code 116.

    We send this to the server when we change our own ticker in a chat
    room. Sending an empty ticker string removes any existing ticker in
    the room.

    Tickers are customizable, user-specific messages that appear on chat
    room walls.
    """

    __slots__ = ("room", "msg")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self, room=None, msg=""):
        self.room = room
        self.msg = msg

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")
        msg += self.pack_string(self.msg, max_length=self.MAX_TICKER_MESSAGE_FIELD_BYTES, field_name="ticker message")

        return msg


class AddThingIHate(ServerMessage):
    """Server code 117.

    We send this to the server when we add an item to our hate list.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("thing",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_INTEREST_ONLY_MESSAGE_SIZE

    def __init__(self, thing=None):
        self.thing = thing

    def make_network_message(self):
        return self.pack_string(self.thing, max_length=self.MAX_INTEREST_FIELD_BYTES, field_name="interest")


class RemoveThingIHate(ServerMessage):
    """Server code 118.

    We send this to the server when we remove an item from our hate
    list.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("thing",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_INTEREST_ONLY_MESSAGE_SIZE

    def __init__(self, thing=None):
        self.thing = thing

    def make_network_message(self):
        return self.pack_string(self.thing, max_length=self.MAX_INTEREST_FIELD_BYTES, field_name="interest")


class RoomSearch(ServerMessage):
    """Server code 120.

    We send this to the server to search files shared by users who have
    joined a specific chat room. The token is a number generated by the
    client and is used to track the search results.

    In the past, the server sent us this message for RoomSearch requests from
    other users. Today, the server sends a FileSearch message instead.
    """

    __slots__ = ("room", "token", "searchterm", "search_username")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self, room=None, token=None, text=""):
        self.room = room
        self.token = token
        self.searchterm = " ".join([x for x in text.split() if x != "-"])
        self.search_username = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.searchterm, is_legacy=True, max_length=self.MAX_SEARCH_TERM_FIELD_BYTES, field_name="search term")

        return msg

    def parse_network_message(self, message):
        """Obsolete."""
        pos, self.search_username = self.unpack_limited_string(
            message, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="search username")
        pos, self.token = self.unpack_uint32(message, pos)
        pos, self.searchterm = self.unpack_limited_string(
            message, pos, self.MAX_SEARCH_TERM_FIELD_BYTES, "search term")


class SendUploadSpeed(ServerMessage):
    """Server code 121.

    We send this after a finished upload to let the server update the
    speed statistics for ourselves.
    """

    __slots__ = ("speed",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self, speed=None):
        self.speed = speed

    def make_network_message(self):
        return self.pack_uint32(self.speed)


class UserPrivileged(ServerMessage):
    """Server code 122.

    We ask the server whether a user is privileged or not.

    DEPRECATED, use WatchUser and GetUserStatus server messages
    """

    __slots__ = ("user", "privileged")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USER_BOOL_MESSAGE_SIZE

    def __init__(self, user=None):
        self.user = user
        self.privileged = None

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

    def parse_network_message(self, message):
        pos, self.user = self.unpack_username(message, field_name="privileged query username")
        pos, self.privileged = self.unpack_bool(message, pos)


class GivePrivileges(ServerMessage):
    """Server code 123.

    We give (part of) our privileges, specified in days, to another user
    on the network.
    """

    __slots__ = ("user", "days")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_TOKEN_MESSAGE_SIZE

    def __init__(self, user=None, days=None):
        self.user = user
        self.days = days

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")
        msg += self.pack_uint32(self.days)

        return msg


class NotifyPrivileges(ServerMessage):
    """Server code 124.

    DEPRECATED, sent by Soulseek NS but not SoulseekQt
    """

    __slots__ = ("token", "user")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_ONLY_MESSAGE_SIZE + 4

    def __init__(self, token=None, user=None):
        self.token = token
        self.user = user

    def parse_network_message(self, message):
        pos, self.token = self.unpack_uint32(message)
        pos, self.user = self.unpack_username(message, pos, "privilege notification username")

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

        return msg


class AckNotifyPrivileges(ServerMessage):
    """Server code 125.

    DEPRECATED, no longer used
    """

    __slots__ = ("token",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self, token=None):
        self.token = token

    def parse_network_message(self, message):
        _pos, self.token = self.unpack_uint32(message)

    def make_network_message(self):
        return self.pack_uint32(self.token)


class BranchLevel(ServerMessage):
    """Server code 126.

    We tell the server what our position is in our branch (xth
    generation) on the distributed network.
    """

    __slots__ = ("value",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self, value=None):
        self.value = value

    def make_network_message(self):
        return self.pack_uint32(self.value)


class BranchRoot(ServerMessage):
    """Server code 127.

    We tell the server the username of the root of the branch we’re in
    on the distributed network.
    """

    __slots__ = ("user",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_USERNAME_ONLY_MESSAGE_SIZE

    def __init__(self, user=None):
        self.user = user

    def make_network_message(self):
        return self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")


class ChildDepth(ServerMessage):
    """Server code 129.

    We tell the server the maximum number of generation of children we
    have on the distributed network.

    DEPRECATED, sent by Soulseek NS but not SoulseekQt
    """

    __slots__ = ("value",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self, value=None):
        self.value = value

    def make_network_message(self):
        return self.pack_uint32(self.value)


class ResetDistributed(ServerMessage):
    """Server code 130.

    The server asks us to reset our distributed parent and children.
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_EMPTY_MESSAGE_SIZE

    def parse_network_message(self, message):
        # Empty message
        pass


class PrivateRoomUsers(ServerMessage):
    """Server code 133.

    The server sends us a list of members (excluding the owner) in a private
    room we are in.
    """

    __slots__ = ("room", "numusers", "users")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_LIST_SERVER_MESSAGE_SIZE

    def __init__(self):
        self.room = None
        self.numusers = None
        self.users = []

    def parse_network_message(self, message):
        pos, self.room = self.unpack_room_name(message, field_name="private room")
        pos, self.numusers = self.unpack_uint32(message, pos)
        self.check_message_count(self.numusers, self.MAX_SERVER_LIST_ITEMS, "private room user")

        for index in range(self.numusers):
            if index >= self.MAX_PRIVATE_ROOM_USERS:
                pos = self.skip_bytes(message, pos, self.MAX_USERNAME_FIELD_BYTES, "private room username")
                continue

            pos, user = self.unpack_username(message, pos, "private room username")
            self.users.append(user)


class PrivateRoomAddUser(ServerMessage):
    """Server code 134.

    We send this to the server to add a member to a private room, if we are
    the owner or an operator.

    The server tells us a member has been added to a private room we are in.
    """

    __slots__ = ("room", "user")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_USERNAME_MESSAGE_SIZE

    def __init__(self, room=None, user=None):
        self.room = room
        self.user = user

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

        return msg

    def parse_network_message(self, message):
        pos, self.room = self.unpack_room_name(message, field_name="private room")
        pos, self.user = self.unpack_username(message, pos, "private room username")


class PrivateRoomRemoveUser(ServerMessage):
    """Server code 135.

    We send this to the server to remove a member from a private room, if we
    are the owner or an operator. Owners can remove operators and regular
    members, operators can only remove regular members.

    The server tells us a member has been removed from a private room we are in.
    """

    __slots__ = ("room", "user")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_USERNAME_MESSAGE_SIZE

    def __init__(self, room=None, user=None):
        self.room = room
        self.user = user

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

        return msg

    def parse_network_message(self, message):
        pos, self.room = self.unpack_room_name(message, field_name="private room")
        pos, self.user = self.unpack_username(message, pos, "private room username")


class PrivateRoomCancelMembership(ServerMessage):
    """Server code 136.

    We send this to the server to cancel our own membership of a private room.
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self, room=None):
        self.room = room

    def make_network_message(self):
        return self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")


class PrivateRoomDisown(ServerMessage):
    """Server code 137.

    We send this to the server to stop owning a private room.
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self, room=None):
        self.room = room

    def make_network_message(self):
        return self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")


class PrivateRoomSomething(ServerMessage):
    """Server code 138.

    OBSOLETE, no longer used
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self, room=None):
        self.room = room

    def make_network_message(self):
        return self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")

    def parse_network_message(self, message):
        _pos, self.room = self.unpack_room_name(message, field_name="private room")


class PrivateRoomAdded(ServerMessage):
    """Server code 139.

    The server tells us we were added to a private room.
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self, room=None):
        self.room = room

    def parse_network_message(self, message):
        _pos, self.room = self.unpack_room_name(message, field_name="private room")


class PrivateRoomRemoved(ServerMessage):
    """Server code 140.

    The server tells us we were removed from a private room.
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self, room=None):
        self.room = room

    def parse_network_message(self, message):
        _pos, self.room = self.unpack_room_name(message, field_name="private room")


class PrivateRoomToggle(ServerMessage):
    """Server code 141.

    We send this when we want to enable or disable invitations to
    private rooms.
    """

    __slots__ = ("enabled",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_BOOL_MESSAGE_SIZE

    def __init__(self, enabled=None):
        self.enabled = enabled

    def make_network_message(self):
        return self.pack_bool(self.enabled)

    def parse_network_message(self, message):
        _pos, self.enabled = self.unpack_bool(message)


class ChangePassword(ServerMessage):
    """Server code 142.

    We send this to the server to change our password. We receive a
    response if our password changes.
    """

    __slots__ = ("password",)
    MAX_INCOMING_MESSAGE_SIZE = 4 + 4 + SlskMessage.MAX_PASSWORD_FIELD_BYTES
    __excluded_attrs__ = {"password"}

    def __init__(self, password=None):
        self.password = password

    def make_network_message(self):
        return self.pack_string(
            self.password, max_length=self.MAX_PASSWORD_FIELD_BYTES, field_name="changed password")

    def parse_network_message(self, message):
        _pos, self.password = self.unpack_limited_string(
            message, max_length=self.MAX_PASSWORD_FIELD_BYTES, field_name="changed password")


class PrivateRoomAddOperator(ServerMessage):
    """Server code 143.

    We send this to the server to add private room operator abilities to
    a member.

    The server tells us a member received operator abilities in a private
    room we are in.
    """

    __slots__ = ("room", "user")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_USERNAME_MESSAGE_SIZE

    def __init__(self, room=None, user=None):
        self.room = room
        self.user = user

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

        return msg

    def parse_network_message(self, message):
        pos, self.room = self.unpack_room_name(message, field_name="private room")
        pos, self.user = self.unpack_username(message, pos, "private room operator")


class PrivateRoomRemoveOperator(ServerMessage):
    """Server code 144.

    We send this to the server to remove private room operator abilities
    from a member.

    The server tells us operator abilities were removed for a member in a
    private room we are in.
    """

    __slots__ = ("room", "user")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_USERNAME_MESSAGE_SIZE

    def __init__(self, room=None, user=None):
        self.room = room
        self.user = user

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

        return msg

    def parse_network_message(self, message):
        pos, self.room = self.unpack_room_name(message, field_name="private room")
        pos, self.user = self.unpack_username(message, pos, "private room operator")


class PrivateRoomOperatorAdded(ServerMessage):
    """Server code 145.

    The server tells us we were given operator abilities in a private room
    we are in.
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self, room=None):
        self.room = room

    def parse_network_message(self, message):
        _pos, self.room = self.unpack_room_name(message, field_name="private room")


class PrivateRoomOperatorRemoved(ServerMessage):
    """Server code 146.

    The server tells us our operator abilities were removed in a private room
    we are in.
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self, room=None):
        self.room = room

    def make_network_message(self):
        return self.pack_string(self.room, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="room")

    def parse_network_message(self, message):
        _pos, self.room = self.unpack_room_name(message, field_name="private room")


class PrivateRoomOperators(ServerMessage):
    """Server code 148.

    The server sends us a list of operators in a private room we are in.
    """

    __slots__ = ("room", "number", "operators")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_LIST_SERVER_MESSAGE_SIZE

    def __init__(self):
        self.room = None
        self.number = None
        self.operators = []

    def parse_network_message(self, message):
        pos, self.room = self.unpack_room_name(message, field_name="private room")
        pos, self.number = self.unpack_uint32(message, pos)
        self.check_message_count(self.number, self.MAX_SERVER_LIST_ITEMS, "private room operator")

        for index in range(self.number):
            if index >= self.MAX_PRIVATE_ROOM_OPERATORS:
                pos = self.skip_bytes(message, pos, self.MAX_USERNAME_FIELD_BYTES, "private room operator")
                continue

            pos, user = self.unpack_username(message, pos, "private room operator")
            self.operators.append(user)


class MessageUsers(ServerMessage):
    """Server code 149.

    Sends a broadcast private message to the given list of online users.
    """

    __slots__ = ("users", "msg")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_BULK_PRIVATE_MESSAGE_SIZE

    def __init__(self, users=None, msg=None):
        self.users = users
        self.msg = msg

    def make_network_message(self):
        msg = bytearray()
        users = tuple(islice(self.users or (), self.MAX_OUTGOING_BULK_USERS))

        msg += self.pack_uint32(len(users))

        for user in users:
            msg += self.pack_string(user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="message recipient")

        msg += self.pack_string(
            self.msg, max_length=self.MAX_CHAT_MESSAGE_FIELD_BYTES, field_name="bulk private message")
        return msg


class JoinGlobalRoom(ServerMessage):
    """Server code 150.

    We ask the server to send us messages from all public rooms, also
    known as public room feed.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_EMPTY_MESSAGE_SIZE

    def make_network_message(self):
        return b""


class LeaveGlobalRoom(ServerMessage):
    """Server code 151.

    We ask the server to stop sending us messages from all public rooms,
    also known as public room feed.

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_EMPTY_MESSAGE_SIZE

    def make_network_message(self):
        return b""


class GlobalRoomMessage(ServerMessage):
    """Server code 152.

    The server sends this when a new message has been written in the
    public room feed (every single line written in every public room).

    DEPRECATED, used in Soulseek NS but not SoulseekQt
    """

    __slots__ = ("room", "user", "message", "formatted_message", "message_type")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_TEXT_SERVER_MESSAGE_SIZE

    def __init__(self):
        self.room = None
        self.user = None
        self.message = None
        self.formatted_message = None
        self.message_type = None

    def parse_network_message(self, message):
        pos, self.room = self.unpack_limited_string(
            message, max_length=self.MAX_ROOM_FIELD_BYTES, field_name="global-room name")
        pos, self.user = self.unpack_limited_string(
            message, pos, self.MAX_USERNAME_FIELD_BYTES, "global-room username")
        pos, self.message = self.unpack_limited_string(
            message, pos, self.MAX_CHAT_MESSAGE_FIELD_BYTES, "global-room message")


class RelatedSearch(ServerMessage):
    """Server code 153.

    The server returns a list of related search terms for a search
    query.

    OBSOLETE, server sends empty list as of 2018
    """

    __slots__ = ("query", "terms")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_RELATED_SEARCH_MESSAGE_SIZE

    def __init__(self, query=None):
        self.query = query
        self.terms = []

    def make_network_message(self):
        return self.pack_string(self.query, max_length=self.MAX_SEARCH_TERM_FIELD_BYTES, field_name="search query")

    def parse_network_message(self, message):
        pos, self.query = self.unpack_limited_string(
            message, max_length=self.MAX_SEARCH_TERM_FIELD_BYTES, field_name="related search query")
        pos, num = self.unpack_uint32(message, pos)
        self.check_message_count(num, self.MAX_RELATED_SEARCH_TERMS, "related search term")

        for _ in range(num):
            pos, term = self.unpack_limited_string(
                message, pos, self.MAX_SEARCH_TERM_FIELD_BYTES, "related search term")
            pos, score = self.unpack_uint32(message, pos)

            self.terms.append((term, score))


class ExcludedSearchPhrases(ServerMessage):
    """Server code 160.

    The server sends a list of phrases not allowed on the search network.
    File paths containing such phrases should be excluded when responding
    to search requests.
    """

    __slots__ = ("phrases",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_EXCLUDED_SEARCH_PHRASES_MESSAGE_SIZE

    def __init__(self):
        self.phrases = []

    def parse_network_message(self, message):
        pos, num = self.unpack_uint32(message)
        self.check_message_count(num, self.MAX_EXCLUDED_SEARCH_PHRASES, "excluded search phrase")

        for _ in range(num):
            pos, phrase = self.unpack_limited_string(
                message, pos, self.MAX_EXCLUDED_PHRASE_FIELD_BYTES, "excluded search phrase")
            self.phrases.append(phrase)


class CantConnectToPeer(ServerMessage):
    """Server code 1001.

    We send this when we are not able to respond to an indirect connection
    request. We receive this if a peer was not able to respond to our
    indirect connection request. The token is taken from the ConnectToPeer
    message.

    Do not rely on receiving this message from peers. Keep a local timeout
    for indirect connections as well.
    """

    __slots__ = ("token", "user")
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_UINT32_MESSAGE_SIZE

    def __init__(self, token=None, user=None):
        self.token = token
        self.user = user

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="username")

        return msg

    def parse_network_message(self, message):
        _pos, self.token = self.unpack_uint32(message)


class CantCreateRoom(ServerMessage):
    """Server code 1003.

    Server tells us a new room cannot be created. This message only
    seems to be sent if we try to create a room with the same name as
    an existing private room. In other cases, such as using a room name
    with leading or trailing spaces, only a private message containing
    an error message is sent.
    """

    __slots__ = ("room",)
    MAX_INCOMING_MESSAGE_SIZE = ServerMessage.MAX_ROOM_ONLY_MESSAGE_SIZE

    def __init__(self):
        self.room = None

    def parse_network_message(self, message):
        _pos, self.room = self.unpack_room_name(message, field_name="room creation failure room")


# Peer Init Messages #


class PeerInitMessage(SlskMessage):
    __slots__ = ()
    msg_type = MessageType.INIT


class PierceFireWall(PeerInitMessage):
    """Peer init code 0.

    This message is sent in response to an indirect connection request
    from another user. If the message goes through to the user, the
    connection is ready. The token is taken from the ConnectToPeer
    server message.
    """

    __slots__ = ("sock", "token")
    MAX_INCOMING_MESSAGE_SIZE = 5  # 1-byte peer-init code + 4-byte token

    def __init__(self, sock=None, token=None):
        self.sock = sock
        self.token = token

    def make_network_message(self):
        return self.pack_uint32(self.token)

    def parse_network_message(self, message):
        _pos, self.token = self.unpack_uint32(message)


class PeerInit(PeerInitMessage):
    """Peer init code 1.

    This message is sent to initiate a direct connection to another
    peer. The token is apparently always 0 and ignored.
    """

    __slots__ = ("sock", "init_user", "target_user", "conn_type", "outgoing_msgs", "outgoing_msg_bytes", "token")
    MAX_INCOMING_MESSAGE_SIZE = (
        1 + 4 + SlskMessage.MAX_USERNAME_FIELD_BYTES
        + 4 + SlskMessage.MAX_CONNECTION_TYPE_FIELD_BYTES
        + 4
    )

    def __init__(self, sock=None, init_user=None, target_user=None, conn_type=None):
        self.sock = sock
        self.init_user = init_user      # username of peer who initiated the message
        self.target_user = target_user  # username of peer we're connected to
        self.conn_type = conn_type
        self.outgoing_msgs = []
        self.outgoing_msg_bytes = 0
        self.token = 0

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.init_user, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="peer-init username")
        msg += self.pack_string(self.conn_type, max_length=self.MAX_CONNECTION_TYPE_FIELD_BYTES, field_name="connection type")
        msg += self.pack_uint32(self.token)

        return msg

    def parse_network_message(self, message):
        pos, self.init_user = self.unpack_username(message, field_name="peer init username")
        pos, self.conn_type = self.unpack_limited_string(
            message, pos, self.MAX_CONNECTION_TYPE_FIELD_BYTES, "peer connection type")

        if self.target_user is None:
            # The user we're connecting to initiated the connection. Set them as target user.
            self.target_user = self.init_user


# Peer Messages #


class PeerMessage(SlskMessage):

    __slots__ = ("username", "sock", "addr", "unsent_rollback_info")
    msg_type = MessageType.PEER

    def __init__(self):
        self.username = None
        self.sock = None
        self.addr = None
        self.unsent_rollback_info = None


class SharedFileListRequest(PeerMessage):
    """Peer code 4.

    We send this to a peer to ask for a list of shared files.
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_EMPTY_PEER_MESSAGE_SIZE

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        # Empty message
        pass


class SharedFileListResponse(PeerMessage):
    """Peer code 5.

    A peer responds with a list of shared files when we've sent a
    SharedFileListRequest.
    """

    __slots__ = ("list", "unknown", "privatelist", "built", "permission_level",
                 "public_shares", "buddy_shares", "trusted_shares",
                 "num_folders", "num_files", "shared_size")
    __excluded_attrs__ = {"list", "privatelist"}
    MAX_RESULT_FOLDERS = 250000
    MAX_RESULT_FILES = 2000000
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_DECOMPRESSED_MESSAGE_SIZE + 1048576

    def __init__(self, public_shares=None, buddy_shares=None, trusted_shares=None,
                 permission_level=None):
        PeerMessage.__init__(self)
        self.public_shares = public_shares
        self.buddy_shares = buddy_shares
        self.trusted_shares = trusted_shares
        self.permission_level = permission_level
        self.list = []
        self.privatelist = []
        self.num_folders = None
        self.num_files = None
        self.shared_size = None
        self.unknown = 0
        self.built = None

    def _iter_shares_list_chunks(self, share_groups):
        num_folders = 0

        for shares in share_groups:
            num_folders += len(shares)

        yield self.pack_uint32(num_folders)

        for shares in share_groups:
            for key, folder_stream in shares.items():
                yield self.pack_string(key, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="share folder")
                yield folder_stream

    def _iter_network_message_chunks(self, share_groups, private_share_groups):
        yield from self._iter_shares_list_chunks(share_groups)

        # Unknown purpose, but official clients always send a value of 0
        yield self.pack_uint32(self.unknown)

        if private_share_groups:
            yield from self._iter_shares_list_chunks(private_share_groups)

    def copy_without_results(self):
        """Return a lightweight copy safe for independent parsing/sending.

        Shared-file-list responses are cached after compression to avoid
        repeatedly packing large share databases. The same cached object must
        not be reused for multiple requests, because the network layer and
        local browse parser mutate per-request fields such as username, socket
        and parsed result lists.
        """

        response = self.__class__(
            public_shares=self.public_shares,
            buddy_shares=self.buddy_shares,
            trusted_shares=self.trusted_shares,
            permission_level=self.permission_level
        )
        response.unknown = self.unknown
        response.built = self.built
        return response

    def make_network_message(self):
        # Elaborate hack to save CPU
        # Store packed message contents in self.built, and use instead of repacking it
        if self.built is not None:
            return self.built

        from pynicotine.shares import PermissionLevel

        share_groups = []
        private_share_groups = []

        if self.permission_level and self.public_shares:
            share_groups.append(self.public_shares)

        if self.permission_level in {PermissionLevel.BUDDY, PermissionLevel.TRUSTED} and self.buddy_shares:
            share_groups.append(self.buddy_shares)

        if self.permission_level == PermissionLevel.TRUSTED and self.trusted_shares:
            share_groups.append(self.trusted_shares)

        for shares in (self.buddy_shares, self.trusted_shares):
            if shares and shares not in share_groups:
                private_share_groups.append(shares)

        try:
            self.built = self.compress_message_chunks(
                self._iter_network_message_chunks(share_groups, private_share_groups),
                max_size=self.MAX_COMPRESSED_PEER_MESSAGE_SIZE,
                description="shared-file-list response"
            )

        except Exception as error:
            from pynicotine.logfacility import log
            self.built = zlib.compress(self.pack_uint32(0) + self.pack_uint32(self.unknown))
            log.add(_("Unable to read shares database. Please rescan your shares. Error: %s"), error)

        return self.built

    def parse_network_message(self, message):
        self._parse_network_message(memoryview(self.decompress_message(message)))

    def _parse_result_list(self, message, pos=0, max_folders=None, max_files=None):
        pos, ndir = self.unpack_uint32(message, pos)

        if max_folders is None:
            max_folders = self.MAX_RESULT_FOLDERS

        if max_files is None:
            max_files = self.MAX_RESULT_FILES

        self.check_message_count(ndir, max_folders, "shared folder")

        ext = None
        should_sort_folders = (1 < ndir <= FileListMessage.MAX_SORTED_RESULT_FOLDERS)
        shares = [] if should_sort_folders else {}
        total_files = 0
        shared_size = 0

        for _ in range(ndir):
            pos, directory = self.unpack_virtual_path(message, pos, "directory")
            pos, nfiles = self.unpack_uint32(message, pos)
            total_files += nfiles
            self.check_message_count(total_files, max_files, "shared file")

            files = []

            for _ in range(nfiles):
                pos, code = self.unpack_uint8(message, pos)
                pos, name = self.unpack_limited_string(
                    message, pos, FileListMessage.MAX_BASENAME_BYTES, "file name")
                pos, size = FileListMessage.parse_file_size(message, pos)
                pos = FileListMessage.skip_bytes(
                    message, pos, FileListMessage.MAX_OBSOLETE_EXTENSION_BYTES, "file extension")
                pos, attrs = FileListMessage.unpack_file_attributes(message, pos)
                shared_size += size

                files.append((code, name, size, ext, attrs))

            if 1 < nfiles <= FileListMessage.MAX_SORTED_RESULT_FILES:
                files.sort(key=itemgetter(1))

            if should_sort_folders:
                shares.append((directory, files))
            else:
                # UserBrowse stores parsed share folders in dictionaries. For
                # grossly large folder lists, build that final shape directly
                # instead of first retaining a huge list of pairs and then
                # copying it into a dict on the main thread.
                shares[directory] = files

        if should_sort_folders:
            shares.sort(key=itemgetter(0))
            shares = dict(shares)

        return pos, shares, ndir, total_files, shared_size

    def _parse_network_message(self, message):
        pos, self.list, self.num_folders, self.num_files, self.shared_size = self._parse_result_list(message)

        if message[pos:]:
            pos, self.unknown = self.unpack_uint32(message, pos)

        if message[pos:]:
            remaining_folders = max(0, self.MAX_RESULT_FOLDERS - self.num_folders)
            remaining_files = max(0, self.MAX_RESULT_FILES - self.num_files)
            pos, self.privatelist, num_folders, num_files, shared_size = self._parse_result_list(
                message, pos, max_folders=remaining_folders, max_files=remaining_files)
            self.num_folders += num_folders
            self.num_files += num_files
            self.shared_size += shared_size


class FileSearchRequest(PeerMessage):
    """Peer code 8.

    We send this to the peer when we search for a file. Alternatively,
    the peer sends this to tell us it is searching for a file.

    OBSOLETE, use UserSearch server message
    """

    __slots__ = ("token", "text", "searchterm")
    MAX_INCOMING_MESSAGE_SIZE = 4 + 4 + 4 + SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES

    def __init__(self, token=None, text=None):
        PeerMessage.__init__(self)
        self.token = token
        self.text = text
        self.searchterm = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.text, max_length=self.MAX_SEARCH_TERM_FIELD_BYTES, field_name="peer search term")

        return msg

    def parse_network_message(self, message):
        pos, self.token = self.unpack_uint32(message)
        pos, self.searchterm = self.unpack_limited_string(
            message, pos, self.MAX_SEARCH_TERM_FIELD_BYTES, "peer search term")


class FileSearchResponse(PeerMessage):
    """Peer code 9.

    A peer sends this message when it has a file search match. The token
    is taken from original FileSearch, UserSearch or RoomSearch server
    message.
    """

    __slots__ = ("search_username", "token", "list", "privatelist", "freeulslots",
                 "ulspeed", "inqueue", "unknown")
    __excluded_attrs__ = {"list", "privatelist"}
    MAX_DECOMPRESSED_MESSAGE_SIZE = 134217728
    MAX_DECOMPRESSED_USERNAME_SIZE = 1024
    MAX_INCOMING_MESSAGE_SIZE = MAX_DECOMPRESSED_MESSAGE_SIZE + 1048576
    MAX_RESULT_FILES = 50000

    def __init__(self, search_username=None, token=None, shares=None, freeulslots=None,
                 ulspeed=None, inqueue=None, private_shares=None):
        PeerMessage.__init__(self)
        self.search_username = search_username
        self.token = token
        self.list = shares
        self.privatelist = private_shares
        self.freeulslots = freeulslots
        self.ulspeed = ulspeed
        self.inqueue = inqueue
        self.unknown = 0

    def _iter_network_message_chunks(self):
        public_results = self.list or ()
        private_results = self.privatelist or ()
        public_count = min(len(public_results), self.MAX_RESULT_FILES)
        private_count = min(len(private_results), self.MAX_RESULT_FILES - public_count)

        yield self.pack_string(self.search_username, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="search username")
        yield self.pack_uint32(self.token)
        yield self.pack_uint32(public_count)

        for fileinfo in islice(public_results, public_count):
            yield FileListMessage.pack_file_info(fileinfo)

        yield self.pack_bool(self.freeulslots)
        yield self.pack_uint32(self.ulspeed)
        yield self.pack_uint32(self.inqueue)
        yield self.pack_uint32(self.unknown)

        if private_count:
            yield self.pack_uint32(private_count)

            for fileinfo in islice(private_results, private_count):
                yield FileListMessage.pack_file_info(fileinfo)

    def make_network_message(self):
        return self.compress_message_chunks(
            self._iter_network_message_chunks(),
            max_size=self.MAX_COMPRESSED_PEER_MESSAGE_SIZE,
            description="search response"
        )

    def parse_network_message(self, message):
        decompressor = zlib.decompressobj()
        unpacked_username_len = decompressor.decompress(message, 4)

        if len(unpacked_username_len) < 4:
            raise ValueError("Compressed search response is truncated")

        _pos, username_len = self.unpack_uint32(unpacked_username_len)

        if username_len > self.MAX_DECOMPRESSED_USERNAME_SIZE:
            raise ValueError("Compressed search response username is too large")

        token_message_size = username_len + 4

        if len(unpacked_username_len) + token_message_size > self.MAX_DECOMPRESSED_MESSAGE_SIZE:
            raise ValueError("Decompressed search response exceeds maximum size")

        unpacked_username_and_token = decompressor.decompress(
            decompressor.unconsumed_tail, token_message_size
        )

        if len(unpacked_username_and_token) < token_message_size:
            raise ValueError("Compressed search response is truncated")

        username = unpacked_username_and_token[:username_len]

        try:
            self.search_username = username.decode("utf-8")

        except UnicodeDecodeError:
            self.search_username = username.decode("latin-1")

        _pos, self.token = self.unpack_uint32(unpacked_username_and_token, username_len)

        if self.token not in SEARCH_TOKENS_ALLOWED:
            # Results are no longer accepted for this search token, stop parsing message
            self.list = []
            self.privatelist = []
            return

        responder = self.username or self.search_username

        if not consume_search_response_user(self.token, responder):
            # Already accepted a response from this peer for the same token,
            # or the responder budget for this token was exhausted. Stop before
            # decompressing and parsing the large result body.
            self.list = []
            self.privatelist = []
            return

        # Optimization: only decompress the rest of the message when needed
        max_remaining_size = (
            self.MAX_DECOMPRESSED_MESSAGE_SIZE
            - len(unpacked_username_len)
            - len(unpacked_username_and_token)
        )

        if max_remaining_size <= 0:
            raise ValueError("Decompressed search response exceeds maximum size")

        unpacked_results = decompressor.decompress(decompressor.unconsumed_tail, max_remaining_size)

        if decompressor.unconsumed_tail:
            raise ValueError("Decompressed search response exceeds maximum size")

        if not decompressor.eof:
            raise ValueError("Compressed search response is truncated")

        flushed_results = decompressor.flush()

        if flushed_results:
            unpacked_results += flushed_results

            if len(unpacked_results) > max_remaining_size:
                raise ValueError("Decompressed search response exceeds maximum size")

        if decompressor.unused_data:
            raise ValueError("Trailing data found after compressed search response")

        self._parse_remaining_network_message(
            memoryview(unpacked_results)
        )

    def _parse_remaining_network_message(self, message):
        pos, self.list = self._parse_result_list(message, max_results=self.MAX_RESULT_FILES)
        num_results = len(self.list)
        pos, self.freeulslots = self.unpack_bool(message, pos)
        pos, self.ulspeed = self.unpack_uint32(message, pos)
        pos, self.inqueue = self.unpack_uint32(message, pos)

        if message[pos:]:
            pos, self.unknown = self.unpack_uint32(message, pos)

        if message[pos:]:
            remaining_results = self.MAX_RESULT_FILES - num_results
            pos, self.privatelist = self._parse_result_list(message, pos, max_results=remaining_results)

    def _parse_result_list(self, message, pos=0, max_results=None):
        pos, nfiles = self.unpack_uint32(message, pos)
        self.check_message_count(
            nfiles,
            self.MAX_RESULT_FILES if max_results is None else max_results,
            "search result file"
        )

        ext = None
        results = []

        for _ in range(nfiles):
            pos, code = self.unpack_uint8(message, pos)
            pos, name = self.unpack_virtual_path(message, pos, "file path")
            pos, size = FileListMessage.parse_file_size(message, pos)
            pos = FileListMessage.skip_bytes(
                message, pos, FileListMessage.MAX_OBSOLETE_EXTENSION_BYTES, "file extension")
            pos, attrs = FileListMessage.unpack_file_attributes(message, pos)

            results.append((code, name, size, ext, attrs))

        if 1 < nfiles <= FileListMessage.MAX_SORTED_RESULT_FILES:
            results.sort(key=itemgetter(1))

        return pos, results


class UserInfoRequest(PeerMessage):
    """Peer code 15.

    We ask the other peer to send us their user information, picture and
    all.
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_EMPTY_PEER_MESSAGE_SIZE

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        # Empty message
        pass


class UserInfoResponse(PeerMessage):
    """Peer code 16.

    A peer responds with this after we've sent a UserInfoRequest.
    """

    __slots__ = ("descr", "pic", "totalupl", "queuesize", "slotsavail", "uploadallowed", "has_pic")
    __excluded_attrs__ = {"pic"}
    MAX_DESCRIPTION_SIZE = 1048576   # 1 MiB of UTF-8 text
    MAX_PICTURE_SIZE = 10485760      # 10 MiB of encoded image data
    MAX_INCOMING_MESSAGE_SIZE = MAX_DESCRIPTION_SIZE + MAX_PICTURE_SIZE + 64

    def __init__(self, descr=None, pic=None, totalupl=None, queuesize=None,
                 slotsavail=None, uploadallowed=None):
        PeerMessage.__init__(self)
        self.descr = descr
        self.pic = pic
        self.totalupl = totalupl
        self.queuesize = queuesize
        self.slotsavail = slotsavail
        self.uploadallowed = uploadallowed
        self.has_pic = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.descr, max_length=UserInfoResponse.MAX_DESCRIPTION_SIZE, field_name="user info description")

        if self.pic is not None and len(self.pic) <= self.MAX_PICTURE_SIZE:
            msg += self.pack_bool(True)
            msg += self.pack_bytes(self.pic)
        else:
            msg += self.pack_bool(False)

        msg += self.pack_uint32(self.totalupl)
        msg += self.pack_uint32(self.queuesize)
        msg += self.pack_bool(self.slotsavail)
        msg += self.pack_uint32(self.uploadallowed)

        return msg

    def parse_network_message(self, message):
        pos, description_length = self.unpack_uint32(message)
        description_end = pos + description_length

        if description_length > self.MAX_DESCRIPTION_SIZE:
            raise ValueError("User info description exceeds maximum size")

        if description_end > len(message):
            raise ValueError("User info description is truncated")

        description = message[pos:description_end].tobytes()

        try:
            self.descr = description.decode("utf-8")

        except UnicodeDecodeError:
            self.descr = description.decode("latin-1")

        pos = description_end
        pos, self.has_pic = self.unpack_bool(message, pos)
        self.pic = None

        if self.has_pic:
            pos, picture_length = self.unpack_uint32(message, pos)
            picture_end = pos + picture_length

            if picture_end > len(message):
                raise ValueError("User info picture is truncated")

            if picture_length <= self.MAX_PICTURE_SIZE:
                self.pic = message[pos:picture_end].tobytes()

            pos = picture_end

        pos, self.totalupl = self.unpack_uint32(message, pos)
        pos, self.queuesize = self.unpack_uint32(message, pos)
        pos, self.slotsavail = self.unpack_bool(message, pos)

        # To prevent errors, ensure that >= 4 bytes are left. Museek+ incorrectly sends
        # slotsavail as an integer, resulting in 3 bytes of garbage here.
        if len(message[pos:]) >= 4:
            pos, self.uploadallowed = self.unpack_uint32(message, pos)


class PMessageUser(PeerMessage):
    """Peer code 22.

    Chat phrase sent to someone or received by us in private. This is a
    Nicotine+ extension to the Soulseek protocol.

    OBSOLETE
    """

    __slots__ = ("message_username", "msg", "msgid", "timestamp")
    MAX_INCOMING_MESSAGE_SIZE = (
        4 + 4 + 4
        + 4 + SlskMessage.MAX_USERNAME_FIELD_BYTES
        + 4 + SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES
    )

    def __init__(self, message_username=None, msg=None):
        PeerMessage.__init__(self)
        self.message_username = message_username
        self.msg = msg
        self.msgid = None
        self.timestamp = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(0)
        msg += self.pack_uint32(0)
        msg += self.pack_string(self.message_username, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="private-message username")
        msg += self.pack_string(self.msg, max_length=self.MAX_TICKER_MESSAGE_FIELD_BYTES, field_name="ticker message")

        return msg

    def parse_network_message(self, message):
        pos, self.msgid = self.unpack_uint32(message)
        pos, self.timestamp = self.unpack_uint32(message, pos)
        pos, self.message_username = self.unpack_limited_string(
            message, pos, self.MAX_USERNAME_FIELD_BYTES, "peer private-message username")
        pos, self.msg = self.unpack_limited_string(
            message, pos, self.MAX_CHAT_MESSAGE_FIELD_BYTES, "peer private message")


class FolderContentsRequest(PeerMessage):
    """Peer code 36.

    We ask the peer to send us the contents of a single folder.
    """

    __slots__ = ("dir", "token", "legacy_client")
    MAX_INCOMING_MESSAGE_SIZE = FileListMessage.MAX_ONE_PATH_UINT32_PEER_MESSAGE_SIZE

    def __init__(self, directory=None, token=None, legacy_client=False):
        PeerMessage.__init__(self)
        self.dir = directory
        self.token = token
        self.legacy_client = legacy_client

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.dir, is_legacy=self.legacy_client, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="folder path")

        return msg

    def parse_network_message(self, message):
        pos, self.token = self.unpack_uint32(message)
        pos, self.dir = self.unpack_virtual_path(message, pos, "requested folder")


class FolderContentsResponse(PeerMessage):
    """Peer code 37.

    A peer responds with the contents of a particular folder (with all
    subfolders) after we've sent a FolderContentsRequest.
    """

    __slots__ = ("dir", "token", "list")
    __excluded_attrs__ = {"list"}
    MAX_DECOMPRESSED_MESSAGE_SIZE = 134217728
    MAX_INCOMING_MESSAGE_SIZE = MAX_DECOMPRESSED_MESSAGE_SIZE + 1048576
    MAX_RESULT_FOLDERS = 50000
    MAX_RESULT_FILES = 500000

    def __init__(self, directory=None, token=None, shares=None):
        PeerMessage.__init__(self)
        self.dir = directory
        self.token = token
        self.list = shares

    def parse_network_message(self, message):
        decompressor = zlib.decompressobj()

        try:
            unpacked_token = decompressor.decompress(message, 4)

        except zlib.error as error:
            raise ValueError("Compressed folder contents response is invalid") from error

        if len(unpacked_token) < 4:
            raise ValueError("Compressed folder contents response is truncated")

        _pos, self.token = self.unpack_uint32(memoryview(unpacked_token))

        allowed_token = (self.username, self.token)

        if allowed_token not in FOLDER_TOKENS_ALLOWED:
            self.dir = None
            self.list = {}
            return

        # Folder-content responses can be very large. Consume the one-shot
        # request token before fragile decompression/parsing, so a malformed
        # allowed response cannot keep the token alive until timeout and repeat
        # the heavyweight path.
        FOLDER_TOKENS_ALLOWED.discard(allowed_token)

        decompressed_message = self.finish_decompressing_message(
            decompressor, unpacked_token, description="folder contents response"
        )
        self._parse_network_message(memoryview(decompressed_message))

    def _parse_network_message(self, message):
        pos, self.token = self.unpack_uint32(message)
        pos, self.dir = self.unpack_virtual_path(message, pos, "requested directory")
        pos, ndir = self.unpack_uint32(message, pos)
        self.check_message_count(ndir, self.MAX_RESULT_FOLDERS, "folder contents folder")

        requested_directory = self.dir
        requested_files = None
        total_files = 0

        for _ in range(ndir):
            pos, directory = self.unpack_virtual_path(message, pos, "directory")
            pos, nfiles = self.unpack_uint32(message, pos)
            total_files += nfiles
            self.check_message_count(total_files, self.MAX_RESULT_FILES, "folder contents file")

            if directory != requested_directory:
                # The download path only consumes the requested directory entry.
                # Do not retain every unrelated folder name from a huge response,
                # but still validate/skip the file records so truncated bodies are
                # detected and the stream offset remains correct.
                for _ in range(nfiles):
                    pos = FileListMessage.skip_file_info(message, pos)

                continue

            if requested_files is None:
                requested_files = []

            ext = None

            for _ in range(nfiles):
                pos, code = self.unpack_uint8(message, pos)
                pos, name = self.unpack_limited_string(
                    message, pos, FileListMessage.MAX_BASENAME_BYTES, "file name")
                pos, size = self.unpack_uint64(message, pos)
                pos = FileListMessage.skip_bytes(
                    message, pos, FileListMessage.MAX_OBSOLETE_EXTENSION_BYTES, "file extension")
                pos, attrs = FileListMessage.unpack_file_attributes(message, pos)
                requested_files.append((code, name, size, ext, attrs))

        if requested_files is not None and 1 < len(requested_files) <= FileListMessage.MAX_SORTED_RESULT_FILES:
            requested_files.sort(key=itemgetter(1))

        self.list = {} if requested_files is None else {requested_directory: requested_files}

    def _iter_network_message_chunks(self):
        yield self.pack_uint32(self.token)
        yield self.pack_string(
            self.dir, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="folder path")

        if self.list is not None:
            yield self.pack_uint32(1)
            yield self.pack_string(
                self.dir, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="folder path")

            # We already saved the folder contents as bytes when scanning our shares.
            yield self.list
            return

        # No folder contents
        yield self.pack_uint32(0)

    def make_network_message(self):
        return self.compress_message_chunks(
            self._iter_network_message_chunks(),
            max_size=self.MAX_COMPRESSED_PEER_MESSAGE_SIZE,
            description="folder contents response"
        )


class TransferRequest(PeerMessage):
    """Peer code 40.

    This message is sent by a peer once they are ready to start
    uploading a file. A TransferResponse message is expected from the
    recipient, either allowing or rejecting the upload attempt.

    This message was formerly used to send a download request (direction
    0) as well, but Nicotine+ >= 3.0.3, Museek+ and the official clients
    use the QueueUpload message for this purpose today.
    """

    __slots__ = ("direction", "token", "file", "filesize")
    MAX_INCOMING_MESSAGE_SIZE = FileListMessage.MAX_TRANSFER_REQUEST_PEER_MESSAGE_SIZE

    def __init__(self, direction=None, token=None, file=None, filesize=None):
        PeerMessage.__init__(self)
        self.direction = direction
        self.token = token
        self.file = file  # virtual file
        self.filesize = filesize

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.direction)
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.file, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="virtual path")

        if self.direction == TransferDirection.UPLOAD:
            msg += self.pack_uint64(self.filesize)

        return msg

    def parse_network_message(self, message):
        pos, self.direction = self.unpack_uint32(message)
        pos, self.token = self.unpack_uint32(message, pos)
        pos, self.file = self.unpack_virtual_path(message, pos, "transfer request path")

        if self.direction == TransferDirection.UPLOAD:
            pos, self.filesize = self.unpack_uint64(message, pos)


class TransferResponse(PeerMessage):
    """Peer code 41.

    Response to TransferRequest - We (or the other peer) either agrees,
    or tells the reason for rejecting the file transfer.
    """

    __slots__ = ("allowed", "token", "reason", "filesize", "rollback_info")
    MAX_INCOMING_MESSAGE_SIZE = (
        4 + 4 + 1 + max(8, 4 + SlskMessage.MAX_TRANSFER_REASON_FIELD_BYTES)
    )

    def __init__(self, allowed=None, reason=None, token=None, filesize=None):
        PeerMessage.__init__(self)
        self.allowed = allowed
        self.token = token
        self.reason = reason
        self.filesize = filesize
        self.rollback_info = None

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.token)
        msg += self.pack_bool(self.allowed)

        if self.reason is not None:
            msg += self.pack_string(self.reason, max_length=self.MAX_TRANSFER_REASON_FIELD_BYTES, field_name="transfer reason")

        if self.filesize is not None:
            msg += self.pack_uint64(self.filesize)

        return msg

    def parse_network_message(self, message):
        pos, self.token = self.unpack_uint32(message)
        pos, self.allowed = self.unpack_bool(message, pos)

        if message[pos:]:
            if self.allowed:
                pos, self.filesize = self.unpack_uint64(message, pos)
            else:
                pos, self.reason = self.unpack_limited_string(
                    message, pos, self.MAX_TRANSFER_REASON_FIELD_BYTES, "transfer denial reason")


class PlaceholdUpload(PeerMessage):
    """Peer code 42.

    OBSOLETE, no longer used
    """

    __slots__ = ("file",)
    MAX_INCOMING_MESSAGE_SIZE = FileListMessage.MAX_ONE_PATH_PEER_MESSAGE_SIZE

    def __init__(self, file=None):
        PeerMessage.__init__(self)
        self.file = file

    def make_network_message(self):
        return self.pack_string(self.file, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="virtual path")

    def parse_network_message(self, message):
        _pos, self.file = self.unpack_virtual_path(message, field_name="placeholder upload path")


class QueueUpload(PeerMessage):
    """Peer code 43.

    This message is used to tell a peer that an upload should be queued
    on their end. Once the recipient is ready to transfer the requested
    file, they will send a TransferRequest to us.
    """

    __slots__ = ("file", "legacy_client")
    MAX_INCOMING_MESSAGE_SIZE = FileListMessage.MAX_ONE_PATH_PEER_MESSAGE_SIZE

    def __init__(self, file=None, legacy_client=False):
        PeerMessage.__init__(self)
        self.file = file
        self.legacy_client = legacy_client

    def make_network_message(self):
        return self.pack_string(self.file, is_legacy=self.legacy_client, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="virtual path")

    def parse_network_message(self, message):
        _pos, self.file = self.unpack_virtual_path(message, field_name="queued upload path")


class PlaceInQueueResponse(PeerMessage):
    """Peer code 44.

    The peer replies with the upload queue placement of the requested
    file.
    """

    __slots__ = ("filename", "place")
    MAX_INCOMING_MESSAGE_SIZE = FileListMessage.MAX_ONE_PATH_UINT32_PEER_MESSAGE_SIZE

    def __init__(self, filename=None, place=None):
        PeerMessage.__init__(self)
        self.filename = filename
        self.place = place

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.filename, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="virtual path")
        msg += self.pack_uint32(self.place)

        return msg

    def parse_network_message(self, message):
        pos, self.filename = self.unpack_virtual_path(message, field_name="queue position path")
        pos, self.place = self.unpack_uint32(message, pos)


class UploadFailed(PeerMessage):
    """Peer code 46.

    This message is sent whenever a file connection of an active upload
    closes. Soulseek NS clients can also send this message when a file
    cannot be read. The recipient either re-queues the upload (download
    on their end), or ignores the message if the transfer finished.
    """

    __slots__ = ("file",)
    MAX_INCOMING_MESSAGE_SIZE = FileListMessage.MAX_ONE_PATH_PEER_MESSAGE_SIZE

    def __init__(self, file=None):
        PeerMessage.__init__(self)
        self.file = file

    def make_network_message(self):
        return self.pack_string(self.file, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="virtual path")

    def parse_network_message(self, message):
        _pos, self.file = self.unpack_virtual_path(message, field_name="failed upload path")


class UploadDenied(PeerMessage):
    """Peer code 50.

    This message is sent to reject QueueUpload attempts and previously
    queued files. The reason for rejection will appear in the transfer
    list of the recipient.
    """

    __slots__ = ("file", "reason")
    MAX_INCOMING_MESSAGE_SIZE = FileListMessage.MAX_PATH_REASON_PEER_MESSAGE_SIZE

    def __init__(self, file=None, reason=None):
        PeerMessage.__init__(self)
        self.file = file
        self.reason = reason

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_string(self.file, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="virtual path")
        msg += self.pack_string(self.reason, max_length=self.MAX_TRANSFER_REASON_FIELD_BYTES, field_name="transfer reason")

        return msg

    def parse_network_message(self, message):
        pos, self.file = self.unpack_virtual_path(message, field_name="denied upload path")
        pos, self.reason = self.unpack_limited_string(
            message, pos, self.MAX_TRANSFER_REASON_FIELD_BYTES, "upload denial reason")


class PlaceInQueueRequest(PeerMessage):
    """Peer code 51.

    This message is sent when asking for the upload queue placement of a
    file.
    """

    __slots__ = ("file", "legacy_client")
    MAX_INCOMING_MESSAGE_SIZE = FileListMessage.MAX_ONE_PATH_PEER_MESSAGE_SIZE

    def __init__(self, file=None, legacy_client=False):
        PeerMessage.__init__(self)
        self.file = file
        self.legacy_client = legacy_client

    def make_network_message(self):
        return self.pack_string(self.file, is_legacy=self.legacy_client, max_length=FileListMessage.MAX_VIRTUAL_PATH_BYTES, field_name="virtual path")

    def parse_network_message(self, message):
        _pos, self.file = self.unpack_virtual_path(message, field_name="queue position request path")


class UploadQueueNotification(PeerMessage):
    """Peer code 52.

    This message is sent to inform a peer about an upload attempt
    initiated by us.

    DEPRECATED, sent by Soulseek NS but not SoulseekQt
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_EMPTY_PEER_MESSAGE_SIZE

    def make_network_message(self):
        return b""

    def parse_network_message(self, _message):
        return b""


class UnknownPeerMessage(PeerMessage):
    """Peer code 12547.

    UNKNOWN
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_EMPTY_PEER_MESSAGE_SIZE

    def parse_network_message(self, message):
        # Empty message
        pass


# File Messages #


class FileMessage(SlskMessage):

    __slots__ = ("sock", "username")
    msg_type = MessageType.FILE

    def __init__(self, sock=None):
        self.sock = sock
        self.username = None


class FileTransferInit(FileMessage):
    """We send this to a peer via a 'F' connection to tell them that we want to
    start uploading a file. The token is the same as the one previously included in the
    TransferRequest peer message.

    Note that slskd and Nicotine+ <= 3.0.2 use legacy download requests, and send this
    message when initializing our file upload connection from their end.
    """

    __slots__ = ("token", "is_outgoing")

    def __init__(self, token=None, is_outgoing=False):
        FileMessage.__init__(self)
        self.token = token
        self.is_outgoing = is_outgoing

    def make_network_message(self):
        return self.pack_uint32(self.token)

    def parse_network_message(self, message):
        _pos, self.token = self.unpack_uint32(message)


class FileOffset(FileMessage):
    """We send this to the uploading peer at the beginning of a 'F' connection,
    to tell them how many bytes of the file we've previously downloaded. If nothing
    was downloaded, the offset is 0.

    Note that Soulseek NS fails to read the size of an incomplete download if more
    than 2 GB of the file has been downloaded, and the download is resumed. In
    consequence, the client sends an invalid file offset of -1.
    """

    __slots__ = ("offset",)

    def __init__(self, sock=None, offset=None):
        FileMessage.__init__(self, sock=sock)
        self.offset = offset

    def make_network_message(self):
        return self.pack_uint64(self.offset)

    def parse_network_message(self, message):
        _pos, self.offset = self.unpack_uint64(message)


# Distributed Messages #


class DistribMessage(SlskMessage):

    __slots__ = ("sock", "username")
    msg_type = MessageType.DISTRIBUTED

    def __init__(self):
        self.sock = None
        self.username = None


class DistribPing(DistribMessage):
    """Distrib code 0.

    We ping distributed children every 60 seconds.

    DEPRECATED, sent by Soulseek NS but not SoulseekQt
    """

    __slots__ = ()
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_EMPTY_DISTRIBUTED_MESSAGE_SIZE

    def make_network_message(self):
        return b""

    def parse_network_message(self, message):
        # Empty message
        pass


class DistribSearch(DistribMessage):
    """Distrib code 3.

    Search request that arrives through the distributed network. We
    transmit the search request to our child peers.
    """

    __slots__ = ("unknown", "search_username", "token", "searchterm")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_DISTRIBUTED_SEARCH_MESSAGE_SIZE

    def __init__(self, unknown=None, search_username=None, token=None, searchterm=None):
        DistribMessage.__init__(self)
        self.unknown = unknown
        self.search_username = search_username
        self.token = token
        self.searchterm = searchterm

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint32(self.unknown)
        msg += self.pack_string(self.search_username, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="search username")
        msg += self.pack_uint32(self.token)
        msg += self.pack_string(self.searchterm, max_length=self.MAX_SEARCH_TERM_FIELD_BYTES, field_name="search term")

        return msg

    def parse_network_message(self, message):
        pos, self.unknown = self.unpack_uint32(message)
        pos, self.search_username = self.unpack_limited_string(
            message, pos, self.MAX_USERNAME_FIELD_BYTES, "distributed search username")
        pos, self.token = self.unpack_uint32(message, pos)
        pos, self.searchterm = self.unpack_limited_string(
            message, pos, self.MAX_SEARCH_TERM_FIELD_BYTES, "distributed search term")


class DistribBranchLevel(DistribMessage):
    """Distrib code 4.

    We tell our distributed children what our position is in our branch
    (xth generation) on the distributed network.

    If we receive a branch level of 0 from a parent, we should mark the
    parent as our branch root, since they won't send a DistribBranchRoot
    message in this case.
    """

    __slots__ = ("level",)
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_EMPTY_DISTRIBUTED_MESSAGE_SIZE + 4

    def __init__(self, level=None):
        DistribMessage.__init__(self)
        self.level = level

    def make_network_message(self):
        return self.pack_int32(self.level)

    def parse_network_message(self, message):
        _pos, self.level = self.unpack_int32(message)


class DistribBranchRoot(DistribMessage):
    """Distrib code 5.

    We tell our distributed children the username of the root of the
    branch we’re in on the distributed network.

    This message should not be sent when we're the branch root.
    """

    __slots__ = ("root_username",)
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_DISTRIBUTED_USERNAME_MESSAGE_SIZE

    def __init__(self, root_username=None):
        DistribMessage.__init__(self)
        self.root_username = root_username

    def make_network_message(self):
        return self.pack_string(self.root_username, max_length=self.MAX_USERNAME_FIELD_BYTES, field_name="distributed root username")

    def parse_network_message(self, message):
        _pos, self.root_username = self.unpack_username(message, field_name="distributed root username")


class DistribChildDepth(DistribMessage):
    """Distrib code 7.

    We tell our distributed parent the maximum number of generation of
    children we have on the distributed network.

    DEPRECATED, sent by Soulseek NS but not SoulseekQt
    """

    __slots__ = ("value",)
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_EMPTY_DISTRIBUTED_MESSAGE_SIZE + 4

    def __init__(self, value=None):
        DistribMessage.__init__(self)
        self.value = value

    def make_network_message(self):
        return self.pack_uint32(self.value)

    def parse_network_message(self, message):
        _pos, self.value = self.unpack_uint32(message)


class DistribEmbeddedMessage(DistribMessage):
    """Distrib code 93.

    A branch root sends us an embedded distributed message. We unpack
    the distributed message and distribute it to our child peers. The
    only type of distributed message sent at present is DistribSearch
    (distributed code 3).
    """

    __slots__ = ("distrib_code", "distrib_message")
    MAX_INCOMING_MESSAGE_SIZE = SlskMessage.MAX_EMBEDDED_DISTRIBUTED_MESSAGE_SIZE

    def __init__(self, distrib_code=None, distrib_message=None):
        DistribMessage.__init__(self)
        self.distrib_code = distrib_code
        self.distrib_message = distrib_message

    def make_network_message(self):
        msg = bytearray()
        msg += self.pack_uint8(self.distrib_code)
        msg += self.distrib_message

        return msg

    def parse_network_message(self, message):
        # Older SoulseekQt versions sent the embedded distributed message type as
        # a 32-bit little-endian integer. Nicotine+ sends the type as a single
        # byte. Accept both formats, but do not blindly skip three bytes for the
        # normal one-byte format.
        start = 3 if message[:3] == b"\x00\x00\x00" else 0
        pos, self.distrib_code = self.unpack_uint8(message, start)
        self.distrib_message = message[pos:].tobytes()


# Message Events #


NETWORK_MESSAGE_EVENTS = {
    AdminMessage: "admin-message",
    ChangePassword: "change-password",
    CheckPrivileges: "check-privileges",
    ConnectToPeer: "connect-to-peer",
    DistribSearch: "file-search-request-distributed",
    ExcludedSearchPhrases: "excluded-search-phrases",
    FileSearch: "file-search-request-server",
    FileSearchResponse: "file-search-response",
    FileTransferInit: "file-transfer-init",
    FolderContentsRequest: "folder-contents-request",
    FolderContentsResponse: "folder-contents-response",
    GetPeerAddress: "peer-address",
    GetUserStats: "user-stats",
    GetUserStatus: "user-status",
    GlobalRecommendations: "global-recommendations",
    GlobalRoomMessage: "global-room-message",
    ItemRecommendations: "item-recommendations",
    ItemSimilarUsers: "item-similar-users",
    JoinRoom: "join-room",
    LeaveRoom: "leave-room",
    Login: "server-login",
    MessageUser: "message-user",
    PlaceInQueueRequest: "place-in-queue-request",
    PlaceInQueueResponse: "place-in-queue-response",
    PrivateRoomAddOperator: "private-room-add-operator",
    PrivateRoomAddUser: "private-room-add-user",
    PrivateRoomAdded: "private-room-added",
    PrivateRoomOperatorAdded: "private-room-operator-added",
    PrivateRoomOperatorRemoved: "private-room-operator-removed",
    PrivateRoomOperators: "private-room-operators",
    PrivateRoomRemoveOperator: "private-room-remove-operator",
    PrivateRoomRemoveUser: "private-room-remove-user",
    PrivateRoomRemoved: "private-room-removed",
    PrivateRoomToggle: "private-room-toggle",
    PrivateRoomUsers: "private-room-users",
    PrivilegedUsers: "privileged-users",
    QueueUpload: "queue-upload",
    Recommendations: "recommendations",
    RoomList: "room-list",
    RoomTickerAdd: "ticker-add",
    RoomTickerRemove: "ticker-remove",
    RoomTickerState: "ticker-state",
    SayChatroom: "say-chat-room",
    SharedFileListRequest: "shared-file-list-request",
    SharedFileListResponse: "shared-file-list-response",
    SimilarUsers: "similar-users",
    TransferRequest: "transfer-request",
    TransferResponse: "transfer-response",
    UploadDenied: "upload-denied",
    UploadFailed: "upload-failed",
    UploadFile: "file-upload-progress",
    UserInfoRequest: "user-info-request",
    UserInfoResponse: "user-info-response",
    UserInterests: "user-interests",
    UserJoinedRoom: "user-joined-room",
    UserLeftRoom: "user-left-room",
    WatchUser: "watch-user",
    WishlistInterval: "set-wishlist-interval"
}


# Message Codes #


SERVER_MESSAGE_CODES = {
    Login: 1,
    SetWaitPort: 2,
    GetPeerAddress: 3,
    WatchUser: 5,
    UnwatchUser: 6,
    GetUserStatus: 7,
    IgnoreUser: 11,
    UnignoreUser: 12,
    SayChatroom: 13,
    JoinRoom: 14,
    LeaveRoom: 15,
    UserJoinedRoom: 16,
    UserLeftRoom: 17,
    ConnectToPeer: 18,
    MessageUser: 22,
    MessageAcked: 23,
    FileSearchRoom: 25,           # Obsolete
    FileSearch: 26,
    SetStatus: 28,
    ServerPing: 32,
    SendConnectToken: 33,         # Obsolete
    SendDownloadSpeed: 34,        # Obsolete
    SharedFoldersFiles: 35,
    GetUserStats: 36,
    QueuedDownloads: 40,          # Obsolete
    Relogged: 41,
    UserSearch: 42,
    SimilarRecommendations: 50,   # Obsolete
    AddThingILike: 51,            # Deprecated
    RemoveThingILike: 52,         # Deprecated
    Recommendations: 54,          # Deprecated
    MyRecommendations: 55,        # Obsolete
    GlobalRecommendations: 56,    # Deprecated
    UserInterests: 57,            # Deprecated
    AdminCommand: 58,             # Obsolete
    PlaceInLineResponse: 60,      # Obsolete
    RoomAdded: 62,                # Obsolete
    RoomRemoved: 63,              # Obsolete
    RoomList: 64,
    ExactFileSearch: 65,          # Obsolete
    AdminMessage: 66,
    GlobalUserList: 67,           # Obsolete
    TunneledMessage: 68,          # Obsolete
    PrivilegedUsers: 69,
    HaveNoParent: 71,
    SearchParent: 73,             # Deprecated
    ParentMinSpeed: 83,
    ParentSpeedRatio: 84,
    ParentInactivityTimeout: 86,  # Obsolete
    SearchInactivityTimeout: 87,  # Obsolete
    MinParentsInCache: 88,        # Obsolete
    DistribPingInterval: 90,      # Obsolete
    AddToPrivileged: 91,          # Obsolete
    CheckPrivileges: 92,
    EmbeddedMessage: 93,
    AcceptChildren: 100,
    PossibleParents: 102,
    WishlistSearch: 103,
    WishlistInterval: 104,
    SimilarUsers: 110,            # Deprecated
    ItemRecommendations: 111,     # Deprecated
    ItemSimilarUsers: 112,        # Deprecated
    RoomTickerState: 113,
    RoomTickerAdd: 114,
    RoomTickerRemove: 115,
    RoomTickerSet: 116,
    AddThingIHate: 117,           # Deprecated
    RemoveThingIHate: 118,        # Deprecated
    RoomSearch: 120,
    SendUploadSpeed: 121,
    UserPrivileged: 122,          # Deprecated
    GivePrivileges: 123,
    NotifyPrivileges: 124,        # Deprecated
    AckNotifyPrivileges: 125,     # Deprecated
    BranchLevel: 126,
    BranchRoot: 127,
    ChildDepth: 129,              # Deprecated
    ResetDistributed: 130,
    PrivateRoomUsers: 133,
    PrivateRoomAddUser: 134,
    PrivateRoomRemoveUser: 135,
    PrivateRoomCancelMembership: 136,
    PrivateRoomDisown: 137,
    PrivateRoomSomething: 138,    # Obsolete
    PrivateRoomAdded: 139,
    PrivateRoomRemoved: 140,
    PrivateRoomToggle: 141,
    ChangePassword: 142,
    PrivateRoomAddOperator: 143,
    PrivateRoomRemoveOperator: 144,
    PrivateRoomOperatorAdded: 145,
    PrivateRoomOperatorRemoved: 146,
    PrivateRoomOperators: 148,
    MessageUsers: 149,
    JoinGlobalRoom: 150,          # Deprecated
    LeaveGlobalRoom: 151,         # Deprecated
    GlobalRoomMessage: 152,       # Deprecated
    RelatedSearch: 153,           # Obsolete
    ExcludedSearchPhrases: 160,
    CantConnectToPeer: 1001,
    CantCreateRoom: 1003
}

PEER_INIT_MESSAGE_CODES = {
    PierceFireWall: 0,
    PeerInit: 1
}

PEER_MESSAGE_CODES = {
    SharedFileListRequest: 4,
    SharedFileListResponse: 5,
    FileSearchRequest: 8,         # Obsolete
    FileSearchResponse: 9,
    UserInfoRequest: 15,
    UserInfoResponse: 16,
    PMessageUser: 22,             # Obsolete
    FolderContentsRequest: 36,
    FolderContentsResponse: 37,
    TransferRequest: 40,
    TransferResponse: 41,
    PlaceholdUpload: 42,          # Obsolete
    QueueUpload: 43,
    PlaceInQueueResponse: 44,
    UploadFailed: 46,
    UploadDenied: 50,
    PlaceInQueueRequest: 51,
    UploadQueueNotification: 52,  # Deprecated
    UnknownPeerMessage: 12547
}

DISTRIBUTED_MESSAGE_CODES = {
    DistribPing: 0,               # Deprecated
    DistribSearch: 3,
    DistribBranchLevel: 4,
    DistribBranchRoot: 5,
    DistribChildDepth: 7,         # Deprecated
    DistribEmbeddedMessage: 93
}

SERVER_MESSAGE_CLASSES = {v: k for k, v in SERVER_MESSAGE_CODES.items()}
PEER_INIT_MESSAGE_CLASSES = {v: k for k, v in PEER_INIT_MESSAGE_CODES.items()}
PEER_MESSAGE_CLASSES = {v: k for k, v in PEER_MESSAGE_CODES.items()}
DISTRIBUTED_MESSAGE_CLASSES = {v: k for k, v in DISTRIBUTED_MESSAGE_CODES.items()}
