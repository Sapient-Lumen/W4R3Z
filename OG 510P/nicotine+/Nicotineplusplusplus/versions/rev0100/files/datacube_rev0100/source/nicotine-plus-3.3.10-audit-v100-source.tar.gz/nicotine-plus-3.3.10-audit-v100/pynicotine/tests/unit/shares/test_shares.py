# COPYRIGHT (C) 2020-2025 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import shutil
import struct
import wave

from array import array

from tempfile import TemporaryDirectory

from queue import Empty
from queue import Queue
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import patch

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.shares import Database
from pynicotine.shares import DatabaseError
from pynicotine.shares import PermissionLevel
from pynicotine.shares import Scanner
from pynicotine.shares import Shares
from pynicotine.slskmessages import FileListMessage
from pynicotine.slskmessages import FolderContentsResponse
from pynicotine.slskmessages import SharedFileListResponse
from pynicotine.slskmessages import SharedFoldersFiles

CURRENT_FOLDER_PATH = os.path.dirname(os.path.realpath(__file__))
DATA_FOLDER_PATH = os.path.join(CURRENT_FOLDER_PATH, "temp_data")
SHARES_FOLDER_PATH = os.path.join(CURRENT_FOLDER_PATH, ".sharedfiles")
BUDDY_SHARES_FOLDER_PATH = os.path.join(CURRENT_FOLDER_PATH, ".sharedbuddyfiles")
TRUSTED_SHARES_FOLDER_PATH = os.path.join(CURRENT_FOLDER_PATH, ".sharedtrustedfiles")
INVALID_SHARES_FOLDER_PATH = os.path.join(CURRENT_FOLDER_PATH, ".sharedinvalidfiles")
AUDIO_FILES = (
    (SHARES_FOLDER_PATH, "audiofile.wav", 50000),
    (BUDDY_SHARES_FOLDER_PATH, "audiofile2.wav", 150000),
    (TRUSTED_SHARES_FOLDER_PATH, "audiofile3.wav", 200000)
)

_MISSING = object()


class SharesPathTest(TestCase):

    @staticmethod
    def _restore_transfer_key(key, value):
        if value is _MISSING:
            config.sections["transfers"].pop(key, None)
        else:
            config.sections["transfers"][key] = value

    def test_virtual2real_uses_cached_virtual_root_map(self):
        shares = object.__new__(Shares)
        shares._virtual_share_root_map = {}
        shares._virtual_share_root_map_key = None

        config.sections.setdefault("transfers", {})
        old_public = config.sections["transfers"].get("shared", _MISSING)
        old_buddy = config.sections["transfers"].get("buddyshared", _MISSING)
        old_trusted = config.sections["transfers"].get("trustedshared", _MISSING)

        try:
            config.sections["transfers"]["shared"] = [("Root", os.path.join(os.sep, "shares", "root"))]
            config.sections["transfers"]["buddyshared"] = []
            config.sections["transfers"]["trustedshared"] = []

            self.assertEqual(
                os.path.join(os.sep, "shares", "root", "disc", "track.mp3"),
                shares.virtual2real("Root\\disc\\track.mp3")
            )

            first_map = shares._virtual_share_root_map
            self.assertIs(first_map, shares._get_virtual_share_root_map())

            config.sections["transfers"]["shared"] = [("Other", os.path.join(os.sep, "shares", "other"))]
            self.assertEqual(
                os.path.join(os.sep, "shares", "other", "file.mp3"),
                shares.virtual2real("Other\\file.mp3")
            )
            self.assertIsNot(first_map, shares._virtual_share_root_map)

        finally:
            self._restore_transfer_key("shared", old_public)
            self._restore_transfer_key("buddyshared", old_buddy)
            self._restore_transfer_key("trustedshared", old_trusted)

    def test_virtual2real_rejects_unknown_root_without_scanning_tails(self):
        shares = object.__new__(Shares)
        shares._virtual_share_root_map = {}
        shares._virtual_share_root_map_key = None

        config.sections.setdefault("transfers", {})
        old_public = config.sections["transfers"].get("shared", _MISSING)

        try:
            config.sections["transfers"]["shared"] = [("Known", os.path.join(os.sep, "shares", "known"))]
            self.assertEqual("__INVALID_SHARE__Missing\\file.mp3", shares.virtual2real("Missing\\file.mp3"))
        finally:
            self._restore_transfer_key("shared", old_public)


class ScannerBudgetTest(TestCase):

    def test_word_index_postings_are_capped_per_word(self):
        scanner = Scanner(Queue(), ([], [], []), {})
        old_limit = Scanner.MAX_WORD_INDEX_POSTINGS

        try:
            Scanner.MAX_WORD_INDEX_POSTINGS = 2
            scanner._append_to_word_index("common", 0)
            scanner._append_to_word_index("common", 1)
            scanner._append_to_word_index("common", 2)

        finally:
            Scanner.MAX_WORD_INDEX_POSTINGS = old_limit

        self.assertEqual([0, 1], list(scanner.word_index["common"]))

    def test_word_index_unique_terms_are_capped(self):
        scanner = Scanner(Queue(), ([], [], []), {})
        old_limit = Scanner.MAX_WORD_INDEX_TERMS

        try:
            Scanner.MAX_WORD_INDEX_TERMS = 2
            scanner._append_to_word_index("alpha", 0)
            scanner._append_to_word_index("beta", 1)
            scanner._append_to_word_index("gamma", 2)

        finally:
            Scanner.MAX_WORD_INDEX_TERMS = old_limit

        self.assertEqual({"alpha", "beta"}, set(scanner.word_index))
        self.assertNotIn("gamma", scanner.word_index)

    def test_search_words_per_path_are_capped(self):
        with TemporaryDirectory() as temp_dir:
            with open(os.path.join(temp_dir, "delta epsilon.txt"), "wb") as file_handle:
                file_handle.write(b"")

            scanner = Scanner(Queue(), ([("Share", temp_dir)], [], []), {})
            old_limit = Scanner.MAX_SEARCH_WORDS_PER_PATH

            try:
                Scanner.MAX_SEARCH_WORDS_PER_PATH = 2
                scanner.scan_shared_folder(
                    temp_dir, old_mtimes={}, old_files={},
                    root_virtual_folder_path="alpha beta gamma")

            finally:
                Scanner.MAX_SEARCH_WORDS_PER_PATH = old_limit

            self.assertLessEqual(len(scanner.word_index), 2)

    def test_search_word_cap_preserves_file_basename_terms(self):
        with TemporaryDirectory() as temp_dir:
            with open(os.path.join(temp_dir, "omega.txt"), "wb") as file_handle:
                file_handle.write(b"")

            scanner = Scanner(Queue(), ([("Share", temp_dir)], [], []), {})
            old_limit = Scanner.MAX_SEARCH_WORDS_PER_PATH

            try:
                Scanner.MAX_SEARCH_WORDS_PER_PATH = 2
                scanner.scan_shared_folder(
                    temp_dir, old_mtimes={}, old_files={},
                    root_virtual_folder_path="alpha beta gamma")

            finally:
                Scanner.MAX_SEARCH_WORDS_PER_PATH = old_limit

            self.assertIn("omega", scanner.word_index)
            self.assertLessEqual(len(scanner.word_index), 2)

    def test_audio_metadata_nonfinite_values_are_discarded(self):
        scanner = Scanner(Queue(), ([], [], []), {})
        fake_stat = type("Stat", (), {"st_size": 4096})()
        fake_tag = type("Tag", (), {
            "bitrate": float("inf"),
            "samplerate": "not-a-number",
            "bitdepth": object(),
            "duration": float("nan"),
            "is_vbr": float("inf")
        })()

        with patch.object(Scanner, "get_audio_tag", return_value=fake_tag):
            file_info = scanner.get_file_info("Share\\bad.mp3", "bad.mp3", fake_stat)

        self.assertEqual(["Share\\bad.mp3", 4096, (None, 0, None, None), None], file_info)

    def test_shared_folder_stream_is_capped_before_database_write(self):
        with TemporaryDirectory() as temp_dir:
            for basename in ("a", "b", "c"):
                with open(os.path.join(temp_dir, basename), "wb") as file_handle:
                    file_handle.write(b"")

            scanner = Scanner(Queue(), ([("Share", temp_dir)], [], []), {})
            old_limit = Scanner.MAX_FOLDER_STREAM_BYTES

            try:
                packed_file = FileListMessage.pack_file_info(["a", 0, None, None])
                Scanner.MAX_FOLDER_STREAM_BYTES = 4 + len(packed_file) + 1
                scanner.scan_shared_folder(temp_dir, {}, {})

            finally:
                Scanner.MAX_FOLDER_STREAM_BYTES = old_limit

            stream = scanner.streams["Share"]
            num_files, = struct.unpack("<I", stream[:4])

            self.assertEqual(1, num_files)
            self.assertEqual(1, len(scanner.files))

    def test_global_file_scan_limit_skips_extra_files_before_database_write(self):
        with TemporaryDirectory() as temp_dir:
            for basename in ("a", "b"):
                with open(os.path.join(temp_dir, basename), "wb") as file_handle:
                    file_handle.write(b"")

            scanner = Scanner(Queue(), ([("Share", temp_dir)], [], []), {})
            old_limit = Scanner.MAX_SCANNED_FILES

            try:
                Scanner.MAX_SCANNED_FILES = 1
                scanner.scan_shared_folder(temp_dir, {}, {})

            finally:
                Scanner.MAX_SCANNED_FILES = old_limit

            self.assertEqual(1, len(scanner.files))
            self.assertEqual(1, scanner.current_file_index)

    def test_global_folder_scan_limit_skips_extra_folders_before_database_write(self):
        with TemporaryDirectory() as temp_dir:
            os.mkdir(os.path.join(temp_dir, "a"))
            os.mkdir(os.path.join(temp_dir, "b"))

            scanner = Scanner(Queue(), ([("Share", temp_dir)], [], []), {})
            old_limit = Scanner.MAX_SCANNED_FOLDERS

            try:
                Scanner.MAX_SCANNED_FOLDERS = 1
                scanner.scan_shared_folder(temp_dir, {}, {})

            finally:
                Scanner.MAX_SCANNED_FOLDERS = old_limit

            scanned_children = [path for path in scanner.streams if path.startswith("Share\\")]
            self.assertEqual(1, len(scanned_children))
            self.assertEqual(1, scanner.current_folder_count)

    def test_global_folder_stream_budget_skips_extra_streams_before_database_write(self):
        with TemporaryDirectory() as temp_dir:
            os.mkdir(os.path.join(temp_dir, "a"))
            os.mkdir(os.path.join(temp_dir, "b"))

            for folder_name in ("a", "b"):
                with open(os.path.join(temp_dir, folder_name, "file.txt"), "wb") as file_handle:
                    file_handle.write(b"")

            scanner = Scanner(Queue(), ([("Share", temp_dir)], [], []), {})
            old_limit = Scanner.MAX_SCANNER_FOLDER_STREAM_BYTES

            try:
                Scanner.MAX_SCANNER_FOLDER_STREAM_BYTES = 4
                scanner.scan_shared_folder(temp_dir, {}, {}, root_virtual_folder_path="Share")

            finally:
                Scanner.MAX_SCANNER_FOLDER_STREAM_BYTES = old_limit

            self.assertEqual({"Share"}, set(scanner.streams))
            self.assertGreater(len(scanner.files), 0)

    def test_scanner_file_path_budget_skips_extra_files_before_metadata_work(self):
        with TemporaryDirectory() as temp_dir:
            for basename in ("a.txt", "b.txt"):
                with open(os.path.join(temp_dir, basename), "wb") as file_handle:
                    file_handle.write(b"audio-like-payload" * 16)

            scanner = Scanner(Queue(), ([("Share", temp_dir)], [], []), {})
            old_limit = Scanner.MAX_SCANNER_FILE_PATH_BYTES

            try:
                Scanner.MAX_SCANNER_FILE_PATH_BYTES = 0

                with patch.object(Scanner, "get_audio_tag", side_effect=AssertionError("metadata scan should be skipped")):
                    scanner.scan_shared_folder(temp_dir, {}, {}, root_virtual_folder_path="Share")

            finally:
                Scanner.MAX_SCANNER_FILE_PATH_BYTES = old_limit

            self.assertEqual(0, len(scanner.files))
            self.assertEqual(0, scanner.current_file_index)

    def test_processed_share_path_child_check_uses_parent_keys(self):
        scanner = Scanner(Queue(), ([], [], []), {})
        root_path = os.path.join(os.sep, "tmp", "share-root")
        child_path = os.path.join(root_path, "disc", "track")
        sibling_path = os.path.join(os.sep, "tmp", "share-root2")

        scanner.processed_share_path_keys.add(scanner._normalize_share_path_key(root_path))

        self.assertTrue(scanner._is_processed_share_path_or_child(root_path))
        self.assertTrue(scanner._is_processed_share_path_or_child(child_path))
        self.assertFalse(scanner._is_processed_share_path_or_child(sibling_path))

    def test_scan_shared_folder_uses_supplied_virtual_root_without_lookup(self):
        with TemporaryDirectory() as temp_dir:
            with open(os.path.join(temp_dir, "a.txt"), "wb") as file_handle:
                file_handle.write(b"")

            scanner = Scanner(Queue(), ([], [], []), {})

            with patch.object(Scanner, "real2virtual", side_effect=AssertionError("unexpected root lookup")):
                scanner.scan_shared_folder(
                    temp_dir, old_mtimes={}, old_files={}, root_virtual_folder_path="Root")

            self.assertIn("Root", scanner.streams)
            self.assertEqual(1, len(scanner.files))

class SharesVirtualNameTest(TestCase):

    def test_normalized_virtual_name_uses_single_collision_set(self):

        class SinglePassShares:

            def __init__(self):
                self.items = [("Music", "/a"), ("Music1", "/b"), ("Music2", "/c")]
                self.num_iterations = 0

            def __iter__(self):
                self.num_iterations += 1

                if self.num_iterations > 1:
                    raise AssertionError("shared folders were scanned more than once")

                return iter(self.items)

        shared_folders = SinglePassShares()
        shares = object.__new__(Shares)

        self.assertEqual(
            "Music3",
            shares.get_normalized_virtual_name("Music", shared_folders=shared_folders)
        )
        self.assertEqual(1, shared_folders.num_iterations)


class DatabaseTest(TestCase):

    def _write_database(self, file_path, content):
        with open(file_path, "wb") as file_handle:
            file_handle.write(Database.FILE_SIGNATURE)
            file_handle.write(bytes([Database.VERSION]))
            file_handle.write(content)

    def test_database_rejects_truncated_record_header(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            self._write_database(file_path, b"\x00\x00\x00")

            with self.assertRaises(DatabaseError):
                Database(file_path, overwrite=False)

    def test_database_rejects_truncated_record_key(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            self._write_database(file_path, Database.PACK_LENGTHS(10, 0) + b"abc")

            with self.assertRaises(DatabaseError):
                Database(file_path, overwrite=False)

    def test_database_rejects_truncated_record_value(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            self._write_database(file_path, Database.PACK_LENGTHS(3, 10) + b"key" + b"short")

            with self.assertRaises(DatabaseError):
                Database(file_path, overwrite=False)

    def test_database_rejects_empty_record_key(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            self._write_database(file_path, Database.PACK_LENGTHS(0, 0))

            with self.assertRaises(DatabaseError):
                Database(file_path, overwrite=False)

    def test_database_rejects_oversized_record_key(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            old_limit = Database.MAX_DATABASE_KEY_BYTES

            try:
                Database.MAX_DATABASE_KEY_BYTES = 4
                self._write_database(file_path, Database.PACK_LENGTHS(5, 0) + b"abcde")

                with self.assertRaises(DatabaseError):
                    Database(file_path, overwrite=False)

            finally:
                Database.MAX_DATABASE_KEY_BYTES = old_limit

    def test_database_rejects_oversized_record_value(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            old_limit = Database.MAX_DATABASE_VALUE_BYTES

            try:
                Database.MAX_DATABASE_VALUE_BYTES = 4
                self._write_database(file_path, Database.PACK_LENGTHS(3, 5) + b"key" + b"abcde")

                with self.assertRaises(DatabaseError):
                    Database(file_path, overwrite=False)

            finally:
                Database.MAX_DATABASE_VALUE_BYTES = old_limit

    def test_database_rejects_too_many_records(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            old_limit = Database.MAX_DATABASE_RECORDS

            try:
                Database.MAX_DATABASE_RECORDS = 1
                content = (
                    Database.PACK_LENGTHS(4, 0) + b"key1"
                    + Database.PACK_LENGTHS(4, 0) + b"key2"
                )
                self._write_database(file_path, content)

                with self.assertRaises(DatabaseError):
                    Database(file_path, overwrite=False)

            finally:
                Database.MAX_DATABASE_RECORDS = old_limit

    def test_database_rejects_too_many_duplicate_records(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            old_limit = Database.MAX_DATABASE_RECORDS

            try:
                Database.MAX_DATABASE_RECORDS = 1
                content = (
                    Database.PACK_LENGTHS(3, 0) + b"key"
                    + Database.PACK_LENGTHS(3, 0) + b"key"
                )
                self._write_database(file_path, content)

                with self.assertRaises(DatabaseError):
                    Database(file_path, overwrite=False)

            finally:
                Database.MAX_DATABASE_RECORDS = old_limit

    def test_database_rejects_oversized_file_before_mmap(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            old_limit = Database.MAX_DATABASE_FILE_BYTES

            try:
                Database.MAX_DATABASE_FILE_BYTES = len(Database.FILE_SIGNATURE)
                self._write_database(file_path, b"")

                with self.assertRaises(DatabaseError):
                    Database(file_path, overwrite=False)

            finally:
                Database.MAX_DATABASE_FILE_BYTES = old_limit

    def test_database_rejects_write_that_exceeds_total_file_size_limit(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            database = Database(file_path)
            old_limit = Database.MAX_DATABASE_FILE_BYTES

            try:
                Database.MAX_DATABASE_FILE_BYTES = len(Database.FILE_SIGNATURE) + 1

                with self.assertRaises(DatabaseError):
                    database["key"] = {"value": 1}

            finally:
                Database.MAX_DATABASE_FILE_BYTES = old_limit
                database.abort()

    def test_database_removes_temp_file_if_close_fails(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            database = Database(file_path)
            database["key"] = {"value": "old"}
            database.close()

            replacement = Database(file_path)
            replacement["key"] = {"value": "new"}
            temp_path = replacement._temp_path

            with patch("pynicotine.shares.os.fsync", side_effect=OSError("sync failed")):
                with self.assertRaises(OSError):
                    replacement.close()

            self.assertFalse(os.path.exists(temp_path))

            current = Database(file_path, overwrite=False)
            self.addCleanup(current.close)
            self.assertEqual({"value": "old"}, current["key"])

    def test_database_rejects_truncated_pickled_value_without_reading_next_record(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            # The first record declares a two-byte value that starts a pickle stream but never
            # reaches a STOP opcode. Loading the value must fail inside that record instead
            # of reading into the following complete record.
            content = (
                Database.PACK_LENGTHS(3, 2) + b"bad" + b"\x80\x04"
                + Database.PACK_LENGTHS(4, 5) + b"good" + b"\x80\x04K\x01."
            )
            self._write_database(file_path, content)

            database = Database(file_path, overwrite=False)
            self.addCleanup(database.close)

            with self.assertRaises(Exception):
                database["bad"]

            self.assertEqual(1, database["good"])

    def test_database_rejects_oversized_key_on_write(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            database = Database(file_path)
            old_limit = Database.MAX_DATABASE_KEY_BYTES

            try:
                Database.MAX_DATABASE_KEY_BYTES = 4

                with self.assertRaises(DatabaseError):
                    database["abcde"] = {"value": 1}

            finally:
                Database.MAX_DATABASE_KEY_BYTES = old_limit
                database.abort()

    def test_database_rejects_oversized_value_on_write(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            database = Database(file_path)
            old_limit = Database.MAX_DATABASE_VALUE_BYTES

            try:
                Database.MAX_DATABASE_VALUE_BYTES = 4

                with self.assertRaises(DatabaseError):
                    database["key"] = b"abcde"

            finally:
                Database.MAX_DATABASE_VALUE_BYTES = old_limit
                database.abort()

    def test_database_rejects_too_many_records_on_write(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            database = Database(file_path)
            old_limit = Database.MAX_DATABASE_RECORDS

            try:
                Database.MAX_DATABASE_RECORDS = 1
                database["key1"] = {"value": 1}

                with self.assertRaises(DatabaseError):
                    database["key2"] = {"value": 2}

            finally:
                Database.MAX_DATABASE_RECORDS = old_limit
                database.abort()

    def test_database_abort_preserves_previous_file_after_write_validation_failure(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")

            database = Database(file_path)
            database["key"] = {"value": "old"}
            database.close()

            replacement = Database(file_path)
            old_limit = Database.MAX_DATABASE_VALUE_BYTES

            try:
                Database.MAX_DATABASE_VALUE_BYTES = 4

                with self.assertRaises(DatabaseError):
                    replacement["huge"] = b"abcde"

                replacement.abort()

            finally:
                Database.MAX_DATABASE_VALUE_BYTES = old_limit

            current = Database(file_path, overwrite=False)
            self.addCleanup(current.close)
            self.assertEqual({"value": "old"}, current["key"])

    def test_database_accepts_complete_record(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            database = Database(file_path)
            database["key"] = {"value": 1}
            database.close()

            database = Database(file_path, overwrite=False)
            self.addCleanup(database.close)

            self.assertEqual({"value": 1}, database["key"])

    def test_database_accepts_compact_word_index_array(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            postings = array("I", [1, 2, 3])

            database = Database(file_path)
            database["word"] = postings
            database.close()

            database = Database(file_path, overwrite=False)
            self.addCleanup(database.close)

            loaded_postings = database["word"]
            self.assertIsInstance(loaded_postings, array)
            self.assertEqual("I", loaded_postings.typecode)
            self.assertEqual([1, 2, 3], list(loaded_postings))

    def test_database_flushes_python_buffer_before_fsync(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")
            database = Database(file_path)
            database["key"] = {"value": 1}
            synced_sizes = []

            def fake_fsync(file_descriptor):
                synced_sizes.append(os.fstat(file_descriptor).st_size)

            with patch("pynicotine.shares.os.fsync", fake_fsync):
                database.close()

            self.assertGreater(synced_sizes[0], len(Database.FILE_SIGNATURE) + 1)

    def test_database_preserves_previous_file_until_atomic_close(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")

            database = Database(file_path)
            database["key"] = {"value": "old"}
            database.close()

            replacement = Database(file_path)
            replacement["key"] = {"value": "new"}

            previous = Database(file_path, overwrite=False)
            try:
                self.assertEqual({"value": "old"}, previous["key"])
            finally:
                previous.close()

            replacement.close()

            current = Database(file_path, overwrite=False)
            self.addCleanup(current.close)
            self.assertEqual({"value": "new"}, current["key"])

    def test_database_preserves_previous_file_if_replacement_write_fails(self):
        with TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "shares.dbn")

            database = Database(file_path)
            database["key"] = {"value": "old"}
            database.close()

            replacement = Database(file_path)
            replacement["key"] = {"value": "new"}

            with patch("pynicotine.shares.os.fsync", side_effect=OSError("sync failed")):
                with self.assertRaises(OSError):
                    replacement.close()

            current = Database(file_path, overwrite=False)
            self.addCleanup(current.close)
            self.assertEqual({"value": "old"}, current["key"])


class ScannerStreamBudgetTest(TestCase):

    def test_scan_shared_folder_uses_compact_and_capped_word_postings(self):
        with TemporaryDirectory() as temp_dir:
            for basename in ("common-one.txt", "common-two.txt", "common-three.txt"):
                with open(os.path.join(temp_dir, basename), "wb") as file_handle:
                    file_handle.write(b"")

            scanner = Scanner(
                queue=Queue(),
                share_groups=([("Common", temp_dir)], [], []),
                share_db_paths={}
            )

            old_limit = Scanner.MAX_WORD_INDEX_POSTINGS

            try:
                Scanner.MAX_WORD_INDEX_POSTINGS = 2
                scanner.scan_shared_folder(temp_dir, old_mtimes={}, old_files={})

            finally:
                Scanner.MAX_WORD_INDEX_POSTINGS = old_limit

            self.assertIsInstance(scanner.word_index["common"], array)
            self.assertEqual(2, len(scanner.word_index["common"]))
            self.assertEqual(3, len(scanner.files))

            queued_messages = []
            while True:
                try:
                    queued_messages.append(scanner.queue.get_nowait())
                except Empty:
                    break

            self.assertTrue(any("posting limit" in msg.msg for msg in queued_messages))

    def test_scan_shared_folder_caps_folder_stream_before_database_write(self):
        with TemporaryDirectory() as temp_dir:
            first_path = os.path.join(temp_dir, "a.txt")
            second_path = os.path.join(temp_dir, "b.txt")

            for file_path in (first_path, second_path):
                with open(file_path, "wb") as file_handle:
                    file_handle.write(b"")

            scanner = Scanner(
                queue=Queue(),
                share_groups=([("Shares", temp_dir)], [], []),
                share_db_paths={}
            )

            first_record_size = len(FileListMessage.pack_file_info(["a.txt", 0, None, None]))
            old_limit = Scanner.MAX_FOLDER_STREAM_BYTES

            try:
                Scanner.MAX_FOLDER_STREAM_BYTES = 4 + first_record_size
                scanner.scan_shared_folder(temp_dir, old_mtimes={}, old_files={})

            finally:
                Scanner.MAX_FOLDER_STREAM_BYTES = old_limit

            self.assertEqual(1, len(scanner.files))
            self.assertEqual(1, FileListMessage.unpack_uint32(memoryview(scanner.streams["Shares"]))[1])

            queued_messages = []
            while True:
                try:
                    queued_messages.append(scanner.queue.get_nowait())
                except Empty:
                    break

            self.assertTrue(any("browse stream exceeds" in msg.msg for msg in queued_messages))


class SharesRequestLimiterTest(TestCase):

    # pylint: disable=protected-access

    def test_folder_contents_request_has_per_user_distinct_folder_cap(self):
        shares = object.__new__(Shares)
        shares.requested_folder_times = {("alice", "Music\\A"): 100.0}
        shares.requested_folder_address_times = {}

        old_limit = Shares.MAX_FOLDER_CONTENTS_REQUEST_TIMES_PER_USER

        try:
            Shares.MAX_FOLDER_CONTENTS_REQUEST_TIMES_PER_USER = 1

            with patch("pynicotine.shares.time.monotonic", return_value=100.1):
                self.assertFalse(shares._allow_folder_contents_request(
                    "alice", "Music\\B", ip_address="203.0.113.5"))
                self.assertTrue(shares._allow_folder_contents_request(
                    "bob", "Music\\B", ip_address="203.0.113.5"))

        finally:
            Shares.MAX_FOLDER_CONTENTS_REQUEST_TIMES_PER_USER = old_limit

        self.assertIn(("bob", "Music\\B"), shares.requested_folder_times)
        self.assertNotIn(("alice", "Music\\B"), shares.requested_folder_times)

    def test_folder_contents_request_existing_key_refreshes_at_per_user_cap(self):
        shares = object.__new__(Shares)
        shares.requested_folder_times = {("alice", "Music\\A"): 90.0}
        shares.requested_folder_address_times = {}

        old_limit = Shares.MAX_FOLDER_CONTENTS_REQUEST_TIMES_PER_USER

        try:
            Shares.MAX_FOLDER_CONTENTS_REQUEST_TIMES_PER_USER = 1

            with patch("pynicotine.shares.time.monotonic", return_value=100.0):
                self.assertTrue(shares._allow_folder_contents_request(
                    "alice", "Music\\A", ip_address="203.0.113.5"))

        finally:
            Shares.MAX_FOLDER_CONTENTS_REQUEST_TIMES_PER_USER = old_limit

        self.assertEqual(100.0, shares.requested_folder_times[("alice", "Music\\A")])


class SharesTest(TestCase):

    def setUp(self):

        config.set_data_folder(DATA_FOLDER_PATH)
        config.set_config_file(os.path.join(DATA_FOLDER_PATH, "temp_config"))

        core.init_components(enabled_components={"shares"})

        # Prepare shares
        config.sections["transfers"]["shared"] = [
            ("Shares", SHARES_FOLDER_PATH, "junk"),                     # Superfluous item in tuple
            ("invalid", os.path.join(SHARES_FOLDER_PATH, "folder2"))    # Resharing subfolder from previous share
        ]
        config.sections["transfers"]["buddyshared"] = [
            ("Secrets", BUDDY_SHARES_FOLDER_PATH),
            ("invalid2", os.path.join(BUDDY_SHARES_FOLDER_PATH, "buddies")),  # Resharing subfolder from previous share
            ("invalid3", os.path.join(BUDDY_SHARES_FOLDER_PATH, "something2", "nothing2")),  # File instead of folder
            ("Shares", INVALID_SHARES_FOLDER_PATH)                      # Duplicate virtual name
        ]
        config.sections["transfers"]["trustedshared"] = [
            ("invalid4", SHARES_FOLDER_PATH),                           # Resharing public folder
            ("Trusted", TRUSTED_SHARES_FOLDER_PATH)
        ]

        # Prepare audio files
        for folder_path, basename, num_frames in AUDIO_FILES:
            with wave.open(os.path.join(folder_path, basename), "wb") as audio_file:
                # pylint: disable=no-member
                audio_file.setnchannels(1)
                audio_file.setsampwidth(2)
                audio_file.setframerate(44100)
                audio_file.writeframes(struct.pack("h", 0) * num_frames)

            self.addCleanup(lambda path: os.path.exists(path) and os.remove(path), os.path.join(folder_path, basename))

        # Rescan shares
        self.assertTrue(core.shares.rescan_shares(rebuild=True, use_thread=False))

    def tearDown(self):
        core.quit()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(DATA_FOLDER_PATH)

    def test_shares_scan(self):
        """Test a full shares scan."""

        # Verify that modification times were saved
        public_mtimes = list(core.shares.share_dbs["public_mtimes"])
        buddy_mtimes = list(core.shares.share_dbs["buddy_mtimes"])
        trusted_mtimes = list(core.shares.share_dbs["trusted_mtimes"])

        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "dummy_file"), public_mtimes)
        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "audiofile.wav"), public_mtimes)
        self.assertIn(os.path.join(BUDDY_SHARES_FOLDER_PATH, "audiofile2.wav"), buddy_mtimes)
        self.assertIn(os.path.join(BUDDY_SHARES_FOLDER_PATH, "something2", "nothing2"), buddy_mtimes)
        self.assertIn(os.path.join(TRUSTED_SHARES_FOLDER_PATH, "audiofile3.wav"), trusted_mtimes)
        self.assertIn(os.path.join(TRUSTED_SHARES_FOLDER_PATH, "folder", "folder2", "folder3", "folder4", "nothing"),
                      trusted_mtimes)

        # Verify that shared files were added
        public_files = core.shares.share_dbs["public_files"]
        buddy_files = core.shares.share_dbs["buddy_files"]
        trusted_files = core.shares.share_dbs["trusted_files"]

        self.assertEqual(
            ["Shares\\dummy_file", 0, None, None],
            public_files[os.path.join(SHARES_FOLDER_PATH, "dummy_file")]
        )
        self.assertEqual(
            ["Shares\\audiofile.wav", 100044, (706, 0, 44100, 16), 1],
            public_files[os.path.join(SHARES_FOLDER_PATH, "audiofile.wav")]
        )
        self.assertEqual(
            ["Secrets\\audiofile2.wav", 300044, (706, 0, 44100, 16), 3],
            buddy_files[os.path.join(BUDDY_SHARES_FOLDER_PATH, "audiofile2.wav")]
        )
        self.assertEqual(
            ["Secrets\\something2\\nothing2", 0, None, None],
            buddy_files[os.path.join(BUDDY_SHARES_FOLDER_PATH, "something2", "nothing2")]
        )
        self.assertEqual(
            ["Trusted\\audiofile3.wav", 400044, (706, 0, 44100, 16), 4],
            trusted_files[os.path.join(TRUSTED_SHARES_FOLDER_PATH, "audiofile3.wav")]
        )

        # Verify that expected folders are empty
        self.assertEqual(core.shares.share_dbs["public_streams"]["Shares\\folder2"], b"\x00\x00\x00\x00")
        self.assertEqual(core.shares.share_dbs["buddy_streams"]["Secrets\\folder3"], b"\x00\x00\x00\x00")
        self.assertEqual(core.shares.share_dbs["trusted_streams"]["Trusted\\folder\\folder2"], b"\x00\x00\x00\x00")

        # Verify that search index was updated
        word_index = core.shares.share_dbs["words"]
        audiofile_indexes = list(word_index["audiofile"])
        audiofile2_indexes = list(word_index["audiofile2"])
        audiofile3_indexes = list(word_index["audiofile3"])
        wav_indexes = list(word_index["wav"])

        self.assertEqual(set(word_index), {
            "wav", "folder2", "nothing2", "trusted", "nothing", "folder3", "dummy",
            "test", "file3", "folder", "file", "folder4", "secrets", "test2",
            "something", "something2", "file2", "audiofile", "somefile",
            "audiofile2", "txt", "folder1", "buddies", "audiofile3", "shares"
        })

        self.assertEqual(len(audiofile_indexes), 1)
        self.assertEqual(len(audiofile2_indexes), 1)
        self.assertEqual(len(audiofile3_indexes), 1)
        self.assertEqual(len(wav_indexes), 3)

        # File ID associated with word "wav" should return our audiofile files
        self.assertIn(wav_indexes[0], audiofile_indexes)
        self.assertIn(wav_indexes[1], audiofile2_indexes)
        self.assertIn(wav_indexes[2], audiofile3_indexes)
        self.assertEqual(
            core.shares.share_dbs["public_files"][core.shares.file_path_index[wav_indexes[0]]][0],
            "Shares\\audiofile.wav"
        )
        self.assertEqual(
            core.shares.share_dbs["buddy_files"][core.shares.file_path_index[wav_indexes[1]]][0],
            "Secrets\\audiofile2.wav"
        )
        self.assertEqual(
            core.shares.share_dbs["trusted_files"][core.shares.file_path_index[wav_indexes[2]]][0],
            "Trusted\\audiofile3.wav"
        )

    def test_shared_counts_retry_after_lower_server_output_rejection(self):
        """A lower server-output failure should keep the latest shared-count report pending."""

        with patch.object(events.__class__, "schedule", return_value=456) as schedule:
            core.shares._server_message_unsent(SharedFoldersFiles(12, 34))

        self.assertEqual((12, 34), core.shares._pending_shared_counts)
        self.assertEqual(456, core.shares._shared_counts_retry_timer_id)
        schedule.assert_called_once()

    def test_shared_counts_retry_waits_for_queue_acceptance(self):
        """Local self stats should advance only once SharedFoldersFiles was accepted."""

        old_users = core.users
        old_uploads = core.uploads
        core.users = SimpleNamespace(login_username="localuser")
        core.uploads = SimpleNamespace(upload_speed=1234)
        self.addCleanup(lambda: setattr(core, "users", old_users))
        self.addCleanup(lambda: setattr(core, "uploads", old_uploads))

        sent_messages = []

        def fake_send(_core, msg):
            sent_messages.append(msg)
            return len(sent_messages) > 1

        with patch.object(core.__class__, "send_message_to_server", fake_send), \
                patch.object(events.__class__, "schedule", return_value=999) as schedule, \
                patch.object(events.__class__, "emit") as emit_event:
            self.assertFalse(core.shares.send_num_shared_folders_files())
            self.assertEqual(999, core.shares._shared_counts_retry_timer_id)
            self.assertIsNotNone(core.shares._pending_shared_counts)
            schedule.assert_called_once()
            emit_event.assert_not_called()

            core.shares._retry_shared_counts()

        self.assertIsNone(core.shares._pending_shared_counts)
        self.assertEqual(2, len(sent_messages))
        emit_event.assert_called_once()
        event_name, stats_msg = emit_event.call_args.args
        self.assertEqual("user-stats", event_name)
        self.assertEqual("localuser", stats_msg.user)
        self.assertEqual(1234, stats_msg.avgspeed)

    def test_failed_scan_restores_previous_share_database(self):
        """A failed rescan should not leave the client with no loaded shares."""

        previous_file_path_index = core.shares.file_path_index
        self.assertTrue(previous_file_path_index)

        # Simulate the main-process handoff performed before the scanner runs.
        # The previous DB files are still on disk, but all live handles/indexes
        # have been dropped while the scanner owns the replacement attempt.
        core.shares.close_shares(core.shares.share_dbs)
        core.shares.file_path_index = ()
        core.shares.compressed_shares["public"].built = b"partial failed scan payload"

        with patch.object(Shares, "send_num_shared_folders_files") as send_counts:
            core.shares._shares_ready(False)

        send_counts.assert_called_once_with()
        self.assertEqual(previous_file_path_index, core.shares.file_path_index)
        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "dummy_file"), core.shares.share_dbs["public_files"])
        self.assertNotEqual(b"partial failed scan payload", core.shares.compressed_shares["public"].built)

    def test_scanner_process_start_failure_restores_previous_share_database(self):
        """A scanner bootstrap failure should not leave rescanning/no-shares state behind."""

        previous_file_path_index = core.shares.file_path_index
        self.assertTrue(previous_file_path_index)

        class FailingScannerProcess:
            def start(self):
                raise OSError("process table exhausted")

        with patch.object(Shares, "_build_scanner_process", return_value=(FailingScannerProcess(), Queue())):
            self.assertFalse(core.shares.rescan_shares(use_thread=False, force=True))

        self.assertFalse(core.shares.rescanning)
        self.assertIsNone(core.shares._scanner_process)
        self.assertEqual(previous_file_path_index, core.shares.file_path_index)
        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "dummy_file"), core.shares.share_dbs["public_files"])

    def test_scanner_process_build_failure_restores_previous_share_database(self):
        """A scanner queue/process build failure should restore live shares."""

        previous_file_path_index = core.shares.file_path_index
        self.assertTrue(previous_file_path_index)

        with patch.object(Shares, "_build_scanner_process", side_effect=OSError("no queue handles")):
            self.assertFalse(core.shares.rescan_shares(use_thread=False, force=True))

        self.assertFalse(core.shares.rescanning)
        self.assertIsNone(core.shares._scanner_process)
        self.assertEqual(previous_file_path_index, core.shares.file_path_index)
        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "dummy_file"), core.shares.share_dbs["public_files"])

    def test_hidden_file_folder_scan(self):
        """Test that hidden files and folders are excluded."""

        # Check modification times
        public_mtimes = list(core.shares.share_dbs["public_mtimes"])
        buddy_mtimes = list(core.shares.share_dbs["buddy_mtimes"])
        trusted_mtimes = list(core.shares.share_dbs["trusted_mtimes"])

        self.assertNotIn(os.path.join(SHARES_FOLDER_PATH, ".abc", "nothing"), public_mtimes)
        self.assertNotIn(os.path.join(SHARES_FOLDER_PATH, ".xyz", "nothing"), public_mtimes)
        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "folder1", "nothing"), public_mtimes)
        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "folder2", "test", "nothing"), public_mtimes)
        self.assertNotIn(os.path.join(SHARES_FOLDER_PATH, "folder2", ".poof", "nothing"), public_mtimes)
        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "folder2", "test", "nothing"), public_mtimes)
        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "something", "nothing"), public_mtimes)

        self.assertNotIn(os.path.join(BUDDY_SHARES_FOLDER_PATH, "folder3", ".poof2", "nothing2"), buddy_mtimes)
        self.assertIn(os.path.join(BUDDY_SHARES_FOLDER_PATH, "folder3", "test2", "nothing2"), buddy_mtimes)
        self.assertNotIn(os.path.join(INVALID_SHARES_FOLDER_PATH, "file.txt"), buddy_mtimes)

        self.assertNotIn(os.path.join(TRUSTED_SHARES_FOLDER_PATH, ".hidden_folder", "nothing"), trusted_mtimes)
        self.assertIn(os.path.join(TRUSTED_SHARES_FOLDER_PATH, "folder", "folder2", "folder3", "folder4", "nothing"),
                      trusted_mtimes)

        # Check file data
        public_files = core.shares.share_dbs["public_files"]
        buddy_files = core.shares.share_dbs["buddy_files"]
        trusted_files = core.shares.share_dbs["trusted_files"]

        self.assertNotIn(os.path.join(SHARES_FOLDER_PATH, ".abc_file"), public_files)
        self.assertNotIn(os.path.join(SHARES_FOLDER_PATH, ".hidden_file"), public_files)
        self.assertNotIn(os.path.join(SHARES_FOLDER_PATH, ".xyz_file"), public_files)
        self.assertIn(os.path.join(SHARES_FOLDER_PATH, "dummy_file"), public_files)
        self.assertEqual(len(public_files), 5)

        self.assertNotIn(os.path.join(BUDDY_SHARES_FOLDER_PATH, ".uvw_file"), buddy_files)
        self.assertIn(os.path.join(BUDDY_SHARES_FOLDER_PATH, "dummy_file2"), buddy_files)
        self.assertEqual(len(buddy_files), 6)

        self.assertNotIn(os.path.join(TRUSTED_SHARES_FOLDER_PATH, ".hidden_folder", "nothing"), trusted_files)
        self.assertIn(os.path.join(TRUSTED_SHARES_FOLDER_PATH, "dummy_file3"), trusted_files)
        self.assertEqual(len(trusted_files), 3)


class SharesRequestLimiterTest(TestCase):

    # pylint: disable=protected-access

    def test_folder_contents_requests_are_rate_limited(self):
        """Repeated folder contents requests should not repeatedly compress/send the same folder."""

        shares = object.__new__(Shares)
        shares.requested_folder_times = {}
        shares.requested_folder_address_times = {}

        with patch("pynicotine.shares.time.monotonic", return_value=1234.0):
            self.assertTrue(shares._allow_folder_contents_request("remoteuser", "Shares\\folder1"))
            self.assertFalse(shares._allow_folder_contents_request("remoteuser", "Shares\\folder1"))
            self.assertTrue(shares._allow_folder_contents_request("remoteuser", "Shares\\folder2"))

        self.assertEqual(2, len(shares.requested_folder_times))

    def test_shared_file_list_requests_are_rate_limited(self):
        """Repeated full-share browse requests should not repeatedly compress/send the share list."""

        shares = object.__new__(Shares)
        shares.requested_share_times = {}
        shares.requested_share_address_times = {}

        with patch("pynicotine.shares.time.monotonic", return_value=1234.0):
            self.assertTrue(shares._allow_shared_file_list_request("remoteuser"))
            self.assertFalse(shares._allow_shared_file_list_request("remoteuser"))
            self.assertTrue(shares._allow_shared_file_list_request("otheruser"))

        self.assertEqual(2, len(shares.requested_share_times))

    def test_shared_file_list_request_ledger_rolls_back_when_response_queue_rejects(self):
        """Do not rate-limit a peer for a share-list response we failed to queue."""

        shares = object.__new__(Shares)
        shares.requested_share_times = {}
        shares.requested_share_address_times = {}
        shares.compressed_shares = {
            PermissionLevel.PUBLIC: SharedFileListResponse(permission_level=PermissionLevel.PUBLIC)
        }

        msg = SimpleNamespace(username="remoteuser", addr=("203.0.113.5", 1234))

        with patch("pynicotine.shares.time.monotonic", return_value=1234.0), \
                patch.object(Shares, "check_user_permission", return_value=(PermissionLevel.PUBLIC, None)), \
                patch.object(type(core), "send_message_to_peer", return_value=False):
            shares._shared_file_list_request(msg)

        self.assertEqual({}, shares.requested_share_times)
        self.assertEqual({}, shares.requested_share_address_times)

    def test_shared_file_list_request_ledger_rolls_back_when_response_is_unavailable(self):
        """Do not consume browse-request budget when no compressed share response is ready."""

        shares = object.__new__(Shares)
        shares.requested_share_times = {}
        shares.requested_share_address_times = {}
        shares.compressed_shares = {}

        msg = SimpleNamespace(username="remoteuser", addr=("203.0.113.5", 1234))

        with patch("pynicotine.shares.time.monotonic", return_value=1234.0), \
                patch.object(Shares, "check_user_permission", return_value=(PermissionLevel.PUBLIC, None)):
            shares._shared_file_list_request(msg)

        self.assertEqual({}, shares.requested_share_times)
        self.assertEqual({}, shares.requested_share_address_times)

    def test_shared_file_list_request_ledger_rolls_back_when_response_output_fails_later(self):
        """Do not rate-limit a peer when an accepted browse response dies below peer output."""

        shares = object.__new__(Shares)
        shares.requested_share_times = {}
        shares.requested_share_address_times = {}

        with patch("pynicotine.shares.time.monotonic", return_value=1234.0):
            marker = shares._record_shared_file_list_request("remoteuser", "203.0.113.5")

        self.assertIn("remoteuser", shares.requested_share_times)

        shares._peer_response_unsent(
            SharedFileListResponse, "remoteuser", ("shared-file-list-request", marker))

        self.assertEqual({}, shares.requested_share_times)
        self.assertEqual({}, shares.requested_share_address_times)

    def test_folder_contents_request_ledger_rolls_back_when_response_output_fails_later(self):
        """Do not rate-limit a peer when an accepted folder response dies below peer output."""

        shares = object.__new__(Shares)
        shares.requested_folder_times = {}
        shares.requested_folder_address_times = {}

        with patch("pynicotine.shares.time.monotonic", return_value=1234.0):
            marker = shares._record_folder_contents_request(
                "remoteuser", "Shares\\folder", "203.0.113.5")

        self.assertIn(("remoteuser", "Shares\\folder"), shares.requested_folder_times)

        shares._peer_response_unsent(
            FolderContentsResponse, "remoteuser", ("folder-contents-request", marker))

        self.assertEqual({}, shares.requested_folder_times)
        self.assertEqual({}, shares.requested_folder_address_times)

    def test_shared_file_list_request_table_is_bounded(self):
        """Full-share browse rate limiting must not create an unbounded per-user table."""

        shares = object.__new__(Shares)
        shares.requested_share_times = {}
        shares.requested_share_address_times = {}
        old_limit = Shares.MAX_SHARED_FILE_LIST_REQUEST_TIMES
        Shares.MAX_SHARED_FILE_LIST_REQUEST_TIMES = 2

        try:
            with patch("pynicotine.shares.time.monotonic", return_value=1234.0):
                self.assertTrue(shares._allow_shared_file_list_request("user1"))
                self.assertTrue(shares._allow_shared_file_list_request("user2"))
                self.assertFalse(shares._allow_shared_file_list_request("user3"))

            self.assertEqual(2, len(shares.requested_share_times))

        finally:
            Shares.MAX_SHARED_FILE_LIST_REQUEST_TIMES = old_limit

    def test_shared_file_list_request_table_prunes_old_entries(self):
        """Expired full-share browse limit entries are pruned before blocking new users."""

        shares = object.__new__(Shares)
        shares.requested_share_times = {"olduser": 1000.0}
        shares.requested_share_address_times = {}
        old_limit = Shares.MAX_SHARED_FILE_LIST_REQUEST_TIMES
        Shares.MAX_SHARED_FILE_LIST_REQUEST_TIMES = 1

        try:
            with patch("pynicotine.shares.time.monotonic", return_value=1234.0):
                self.assertTrue(shares._allow_shared_file_list_request("newuser"))

            self.assertNotIn("olduser", shares.requested_share_times)
            self.assertIn("newuser", shares.requested_share_times)

        finally:
            Shares.MAX_SHARED_FILE_LIST_REQUEST_TIMES = old_limit

    def test_shared_file_list_address_budget_blocks_username_rotation(self):
        """A peer should not bypass share-list rate limits by rotating claimed usernames."""

        shares = object.__new__(Shares)
        shares.requested_share_times = {}
        shares.requested_share_address_times = {}
        old_limit = Shares.MAX_SHARED_FILE_LIST_REQUESTS_PER_ADDRESS
        Shares.MAX_SHARED_FILE_LIST_REQUESTS_PER_ADDRESS = 2

        try:
            with patch("pynicotine.shares.time.monotonic", return_value=1234.0):
                self.assertTrue(shares._allow_shared_file_list_request("user1", "203.0.113.5"))
                self.assertTrue(shares._allow_shared_file_list_request("user2", "203.0.113.5"))
                self.assertFalse(shares._allow_shared_file_list_request("user3", "203.0.113.5"))
                self.assertTrue(shares._allow_shared_file_list_request("user4", "203.0.113.6"))

        finally:
            Shares.MAX_SHARED_FILE_LIST_REQUESTS_PER_ADDRESS = old_limit

    def test_folder_contents_address_budget_blocks_many_distinct_folders(self):
        """A peer should not bypass folder rate limits with many usernames/folders."""

        shares = object.__new__(Shares)
        shares.requested_folder_times = {}
        shares.requested_folder_address_times = {}
        old_limit = Shares.MAX_FOLDER_CONTENTS_REQUESTS_PER_ADDRESS
        Shares.MAX_FOLDER_CONTENTS_REQUESTS_PER_ADDRESS = 2

        try:
            with patch("pynicotine.shares.time.monotonic", return_value=1234.0):
                self.assertTrue(shares._allow_folder_contents_request("user1", "Shares\\folder1", "203.0.113.5"))
                self.assertTrue(shares._allow_folder_contents_request("user2", "Shares\\folder2", "203.0.113.5"))
                self.assertFalse(shares._allow_folder_contents_request("user3", "Shares\\folder3", "203.0.113.5"))
                self.assertTrue(shares._allow_folder_contents_request("user4", "Shares\\folder4", "203.0.113.6"))

        finally:
            Shares.MAX_FOLDER_CONTENTS_REQUESTS_PER_ADDRESS = old_limit

    def test_folder_contents_request_table_does_not_clear_recent_entries_when_full(self):
        """A full folder limiter should reject new keys instead of forgetting recent requests."""

        shares = object.__new__(Shares)
        shares.requested_folder_times = {("user1", "Shares\\folder1"): 1230.0}
        shares.requested_folder_address_times = {}
        old_limit = Shares.MAX_FOLDER_CONTENTS_REQUEST_TIMES
        Shares.MAX_FOLDER_CONTENTS_REQUEST_TIMES = 1

        try:
            with patch("pynicotine.shares.time.monotonic", return_value=1234.0):
                self.assertFalse(shares._allow_folder_contents_request("user2", "Shares\\folder2", "203.0.113.5"))

        finally:
            Shares.MAX_FOLDER_CONTENTS_REQUEST_TIMES = old_limit

        self.assertEqual({("user1", "Shares\\folder1"): 1230.0}, shares.requested_folder_times)

    def test_folder_contents_request_ledger_rolls_back_when_response_queue_rejects(self):
        """Do not consume folder-request rate budget for a response rejected locally."""

        shares = object.__new__(Shares)
        shares.requested_folder_times = {}
        shares.requested_folder_address_times = {}
        shares.share_dbs = {}

        msg = SimpleNamespace(
            username="remoteuser", addr=("203.0.113.5", 1234), dir="Shares\\folder", token=123
        )
        old_reveal_buddy = config.sections["transfers"].get("reveal_buddy_shares", _MISSING)
        old_reveal_trusted = config.sections["transfers"].get("reveal_trusted_shares", _MISSING)

        try:
            config.sections["transfers"]["reveal_buddy_shares"] = False
            config.sections["transfers"]["reveal_trusted_shares"] = False

            with patch("pynicotine.shares.time.monotonic", return_value=1234.0), \
                    patch.object(Shares, "check_user_permission", return_value=(PermissionLevel.PUBLIC, None)), \
                    patch.object(type(core), "send_message_to_peer", return_value=False):
                shares._folder_contents_request(msg)

        finally:
            if old_reveal_buddy is _MISSING:
                config.sections["transfers"].pop("reveal_buddy_shares", None)
            else:
                config.sections["transfers"]["reveal_buddy_shares"] = old_reveal_buddy

            if old_reveal_trusted is _MISSING:
                config.sections["transfers"].pop("reveal_trusted_shares", None)
            else:
                config.sections["transfers"]["reveal_trusted_shares"] = old_reveal_trusted

        self.assertEqual({}, shares.requested_folder_times)
        self.assertEqual({}, shares.requested_folder_address_times)


class ScannerTest(TestCase):

    def test_symlink_scan(self):
        """Symbolic links are not followed while scanning shares."""

        if os.name == "nt":
            self.skipTest("creating symbolic links requires elevated privileges on Windows")

        from queue import SimpleQueue
        from tempfile import TemporaryDirectory
        from pynicotine.shares import Scanner

        with TemporaryDirectory() as temp_dir:
            shared_folder_path = os.path.join(temp_dir, "shared")
            target_folder_path = os.path.join(shared_folder_path, "folder1")
            symlink_path = os.path.join(shared_folder_path, "symlink_to_folder")
            symlink_file_path = os.path.join(shared_folder_path, "symlink_to_file")
            outside_file_path = os.path.join(temp_dir, "outside_secret")
            os.makedirs(target_folder_path)

            with open(os.path.join(target_folder_path, "nothing"), "wb") as file_handle:
                file_handle.write(b"")

            with open(outside_file_path, "wb") as file_handle:
                file_handle.write(b"secret")

            try:
                os.symlink(target_folder_path, symlink_path)
                os.symlink(outside_file_path, symlink_file_path)
            except OSError as error:
                self.skipTest(f"creating symbolic links failed: {error}")

            scanner = Scanner(
                queue=SimpleQueue(),
                share_groups=([("Shares", shared_folder_path)], [], []),
                share_db_paths={},
                rebuild=True
            )
            scanner.scan_shared_folder(shared_folder_path, old_mtimes={}, old_files={})

            self.assertIn(os.path.join(target_folder_path, "nothing"), scanner.mtimes)
            self.assertNotIn(os.path.join(symlink_path, "nothing"), scanner.mtimes)
            self.assertNotIn(symlink_file_path, scanner.mtimes)
            self.assertIn("Shares\\folder1", scanner.streams)
            self.assertNotIn("Shares\\symlink_to_folder", scanner.streams)

    def test_special_file_scan(self):
        """Special files such as FIFOs are not shared."""

        if not hasattr(os, "mkfifo"):
            self.skipTest("creating FIFOs is not supported on this platform")

        from queue import SimpleQueue
        from tempfile import TemporaryDirectory
        from pynicotine.shares import Scanner

        with TemporaryDirectory() as temp_dir:
            shared_folder_path = os.path.join(temp_dir, "shared")
            fifo_path = os.path.join(shared_folder_path, "pipe")
            os.makedirs(shared_folder_path)

            try:
                os.mkfifo(fifo_path)
            except OSError as error:
                self.skipTest(f"creating FIFO failed: {error}")

            scanner = Scanner(
                queue=SimpleQueue(),
                share_groups=([("Shares", shared_folder_path)], [], []),
                share_db_paths={},
                rebuild=True
            )
            scanner.scan_shared_folder(shared_folder_path, old_mtimes={}, old_files={})

            self.assertNotIn(fifo_path, scanner.mtimes)
            self.assertNotIn(fifo_path, scanner.files)

    def test_folder_stream_matches_packed_scan_output(self):
        """Folder streams should be packed incrementally without changing browse results."""

        from queue import SimpleQueue
        from tempfile import TemporaryDirectory
        from pynicotine.shares import Scanner

        with TemporaryDirectory() as temp_dir:
            shared_folder_path = os.path.join(temp_dir, "shared")
            os.makedirs(shared_folder_path)

            with open(os.path.join(shared_folder_path, "song.mp3"), "wb") as file_handle:
                file_handle.write(b"abc")

            scanner = Scanner(
                queue=SimpleQueue(),
                share_groups=([("Shares", shared_folder_path)], [], []),
                share_db_paths={},
                rebuild=True
            )
            scanner.scan_shared_folder(shared_folder_path, old_mtimes={}, old_files={})

            self.assertEqual(
                Scanner.get_folder_stream([("song.mp3", 3, None, None)]),
                scanner.streams["Shares"]
            )

    def test_nested_folder_scan_reuses_virtual_path_without_repeated_root_matching(self):
        """Nested share scans should propagate virtual paths instead of rematching every folder."""

        from queue import SimpleQueue
        from tempfile import TemporaryDirectory
        from unittest.mock import patch
        from pynicotine.shares import Scanner

        with TemporaryDirectory() as temp_dir:
            shared_folder_path = os.path.join(temp_dir, "shared")
            nested_folder_path = os.path.join(shared_folder_path, "a", "b", "c")
            os.makedirs(nested_folder_path)

            with open(os.path.join(nested_folder_path, "tiny.txt"), "wb") as file_handle:
                file_handle.write(b"x")

            scanner = Scanner(
                queue=SimpleQueue(),
                share_groups=([("Shares", shared_folder_path)], [], []),
                share_db_paths={},
                rebuild=True
            )

            call_count = 0
            original_real2virtual = Scanner.real2virtual

            def counted_real2virtual(current_scanner, real_path):
                nonlocal call_count
                call_count += 1
                return original_real2virtual(current_scanner, real_path)

            with patch.object(Scanner, "real2virtual", counted_real2virtual):
                scanner.scan_shared_folder(shared_folder_path, old_mtimes={}, old_files={})

            self.assertEqual(1, call_count)
            self.assertIn("Shares\\a\\b\\c", scanner.streams)
            self.assertIn(os.path.join(nested_folder_path, "tiny.txt"), scanner.files)

    def test_create_file_path_index_validates_without_ipc_payload(self):
        """Scanner should not send every shared path through its IPC queue."""

        from tempfile import TemporaryDirectory
        from pynicotine.shares import Scanner

        class RecordingQueue:
            def __init__(self):
                self.items = []

            def put(self, item):
                self.items.append(item)

        with TemporaryDirectory() as temp_dir:
            share_db_paths = {
                name: os.path.join(temp_dir, f"{name}.dbn")
                for name in ("public_files", "buddy_files", "trusted_files")
            }

            for destination, db_path in share_db_paths.items():
                database = Shares.create_db_file(db_path)
                database[f"/{destination}/song.mp3"] = [f"{destination}\\song.mp3", 3, None, None]
                database.close()

            queue = RecordingQueue()
            scanner = Scanner(
                queue=queue,
                share_groups=([], [], []),
                share_db_paths=share_db_paths
            )

            scanner.create_file_path_index()
            self.assertEqual([], queue.items)

    def test_scanner_log_messages_are_capped_and_summarized(self):
        """Scanner error logs should not grow without bound during bad scans."""

        from unittest.mock import patch
        from pynicotine.shares import Scanner
        from pynicotine.shares import ScannerLogMessage

        class RecordingQueue:
            def __init__(self):
                self.items = []

            def put(self, item):
                self.items.append(item)

        queue = RecordingQueue()
        scanner = Scanner(queue=queue, share_groups=([], [], []), share_db_paths={})

        with patch.object(Scanner, "MAX_SCANNER_LOG_MESSAGES", 2):
            for i in range(5):
                scanner._put_scanner_log("bad file %(num)s", {"num": i})

            scanner._flush_scanner_log_summary()

        self.assertEqual(3, len(queue.items))
        self.assertTrue(all(isinstance(item, ScannerLogMessage) for item in queue.items))
        self.assertEqual({"num": 3}, queue.items[-1].msg_args)


class ScannerQueueTest(TestCase):

    def test_process_scanner_drains_queue_after_process_exit(self):
        """Scanner can exit before the queue reader has consumed final items."""

        from collections import deque

        class FinishedProcess:
            @staticmethod
            def is_alive():
                return False

        class QueueWithPendingItem:
            def __init__(self, *items):
                self.items = deque(items)

            def get_nowait(self):
                if not self.items:
                    raise Empty

                return self.items.popleft()

            def get(self, timeout=None):  # pylint: disable=unused-argument
                return self.get_nowait()

        shares = object.__new__(Shares)
        shares._scanner_process = FinishedProcess()
        shares.file_path_index = ()
        shares.compressed_shares = {}
        shares.initialized = False

        file_path_index = ("/shared/file.flac",)
        successful = shares._process_scanner(QueueWithPendingItem(file_path_index))

        self.assertTrue(successful)
        self.assertEqual(file_path_index, shares.file_path_index)
