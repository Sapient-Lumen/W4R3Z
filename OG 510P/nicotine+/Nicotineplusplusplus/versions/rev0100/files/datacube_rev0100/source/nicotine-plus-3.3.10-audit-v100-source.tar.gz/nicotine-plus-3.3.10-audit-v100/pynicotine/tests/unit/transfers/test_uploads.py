# COPYRIGHT (C) 2021-2025 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import shutil

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import patch
from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.slskmessages import FileAttribute
from pynicotine.slskmessages import PlaceInQueueRequest
from pynicotine.slskmessages import PlaceInQueueResponse
from pynicotine.slskmessages import QueueUpload
from pynicotine.slskmessages import SendUploadSpeed
from pynicotine.slskmessages import TransferDirection
from pynicotine.slskmessages import TransferRejectReason
from pynicotine.slskmessages import TransferRequest
from pynicotine.slskmessages import TransferResponse
from pynicotine.slskmessages import UploadDenied
from pynicotine.slskmessages import UploadFailed
from pynicotine.slskmessages import UserStatus
from pynicotine.shares import PermissionLevel
from pynicotine.uploads import Uploads
from pynicotine.transfers import Transfer
from pynicotine.transfers import TransferStatus

CURRENT_FOLDER_PATH = os.path.dirname(os.path.realpath(__file__))
DATA_FOLDER_PATH = os.path.join(CURRENT_FOLDER_PATH, "temp_data")
TRANSFERS_BASENAME = "uploads.json"
TRANSFERS_FILE_PATH = os.path.join(CURRENT_FOLDER_PATH, TRANSFERS_BASENAME)
SAVED_TRANSFERS_FILE_PATH = os.path.join(DATA_FOLDER_PATH, TRANSFERS_BASENAME)


class UploadsTest(TestCase):

    # pylint: disable=protected-access

    def setUp(self):

        config.set_data_folder(DATA_FOLDER_PATH)
        config.set_config_file(os.path.join(DATA_FOLDER_PATH, "temp_config"))

        if not os.path.exists(DATA_FOLDER_PATH):
            os.makedirs(DATA_FOLDER_PATH)

        shutil.copy(TRANSFERS_FILE_PATH, os.path.join(DATA_FOLDER_PATH, TRANSFERS_BASENAME))

        core.init_components(enabled_components={"users", "shares", "uploads", "buddies"})
        self._network_acceptor = lambda _msg: True
        events.connect("queue-network-message", self._network_acceptor)
        core.start()

    def tearDown(self):
        try:
            events.disconnect("queue-network-message", self._network_acceptor)
        except ValueError:
            pass

        core.quit()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(DATA_FOLDER_PATH, ignore_errors=True)




    def test_unsent_upload_transfer_request_requeues_active_upload(self):
        uploads = core.uploads
        core.users.login_status = UserStatus.ONLINE
        transfer = Transfer("peer", "Folder\\upload.mp3", DATA_FOLDER_PATH, 123)
        uploads._append_transfer(transfer)
        self.assertTrue(uploads._activate_transfer(transfer, token=77))

        msg = TransferRequest(
            direction=TransferDirection.UPLOAD, token=77, file="Folder\\upload.mp3", filesize=123
        )
        msg.username = "peer"

        uploads._peer_message_unsent(msg)

        self.assertNotIn(77, uploads.active_users.get("peer", {}))
        self.assertIs(uploads.queued_users["peer"]["Folder\\upload.mp3"], transfer)


    def test_unsent_legacy_upload_transfer_response_requeues_active_upload(self):
        uploads = core.uploads
        core.users.login_status = UserStatus.ONLINE
        transfer = Transfer("peer", "Folder\\legacy.mp3", DATA_FOLDER_PATH, 123)
        uploads._append_transfer(transfer)
        self.assertTrue(uploads._activate_transfer(transfer, token=88))

        response = TransferResponse(allowed=True, token=88)
        response.username = "peer"

        uploads._peer_message_unsent(response)

        self.assertNotIn(88, uploads.active_users.get("peer", {}))
        self.assertIs(uploads.queued_users["peer"]["Folder\\legacy.mp3"], transfer)

    def test_unsent_peer_transfer_notice_requeues_lower_output_failure(self):
        notice = UploadDenied("Folder\\lost.mp3", TransferRejectReason.BANNED)
        notice.username = "peer"

        with patch.object(events.__class__, "schedule", return_value=222):
            core.uploads._peer_message_unsent(notice)

        self.assertEqual(1, len(core.uploads._pending_peer_transfer_notices))
        username, msg, _key = core.uploads._pending_peer_transfer_notices[0]
        self.assertEqual("peer", username)
        self.assertIs(msg, notice)
        self.assertEqual(222, core.uploads._peer_transfer_notice_timer_id)

    def test_unsent_queue_position_response_requeues_lower_output_failure(self):
        response = PlaceInQueueResponse("Folder\\queued.mp3", 5)
        response.username = "peer"

        with patch.object(events.__class__, "schedule", return_value=333):
            core.uploads._peer_message_unsent(response)

        self.assertEqual(1, len(core.uploads._pending_peer_transfer_notices))
        username, msg, key = core.uploads._pending_peer_transfer_notices[0]
        self.assertEqual("peer", username)
        self.assertIs(msg, response)
        self.assertIn("Folder\\queued.mp3", key)

    def test_peer_transfer_notice_retries_after_queue_rejection(self):
        """Peer transfer notices should be retried if local queue backpressure rejects them."""

        notice = UploadDenied("Folder\\file.mp3", TransferRejectReason.BANNED)

        with patch.object(core.__class__, "send_message_to_peer", side_effect=[False, True]) as send_message_to_peer, \
                patch.object(events.__class__, "schedule", return_value=321) as schedule:
            self.assertFalse(core.uploads._send_peer_transfer_notice("noticeuser", notice))
            self.assertEqual(1, len(core.uploads._pending_peer_transfer_notices))
            self.assertEqual(321, core.uploads._peer_transfer_notice_timer_id)
            schedule.assert_called_once()

            core.uploads._process_peer_transfer_notices()

        self.assertEqual(2, send_message_to_peer.call_count)
        self.assertFalse(core.uploads._pending_peer_transfer_notices)
        self.assertFalse(core.uploads._pending_peer_transfer_notice_keys)
        self.assertIsNone(core.uploads._peer_transfer_notice_timer_id)

    def test_clear_queued_upload_retries_denial_after_queue_rejection(self):
        """Clearing a queued upload must not silently lose the UploadDenied peer notice."""

        username = "deniedqueueduser"
        virtual_path = "Folder\\Denied.mp3"
        upload = Transfer(username=username, virtual_path=virtual_path, folder_path=DATA_FOLDER_PATH, size=1)
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses[username] = UserStatus.ONLINE
        core.uploads._append_transfer(upload)
        core.uploads._enqueue_transfer(upload)

        with patch.object(core.__class__, "send_message_to_peer", return_value=False), \
                patch.object(events.__class__, "schedule", return_value=456):
            core.uploads._clear_transfer(upload, denied_message=TransferRejectReason.BANNED)

        self.assertEqual(1, len(core.uploads._pending_peer_transfer_notices))
        queued_username, msg, _key = core.uploads._pending_peer_transfer_notices[0]
        self.assertEqual(username, queued_username)
        self.assertIsInstance(msg, UploadDenied)
        self.assertEqual(virtual_path, msg.file)
        self.assertEqual(TransferRejectReason.BANNED, msg.reason)
        self.assertNotIn((username, virtual_path), core.uploads.transfers)

    def test_file_close_uses_authoritative_final_upload_offset(self):
        """A dropped final progress event must not make a completed upload abort."""

        username = "finaluploaduser"
        virtual_path = "Folder\\FinalUpload.mp3"
        sock = object()
        upload = Transfer(
            username=username, virtual_path=virtual_path, folder_path=DATA_FOLDER_PATH,
            size=100, status=TransferStatus.TRANSFERRING, current_byte_offset=90
        )
        upload.last_byte_offset = 90
        upload.start_time = 0
        upload.sock = sock
        upload.token = 456
        core.uploads._append_transfer(upload)
        core.uploads.active_users[username][upload.token] = upload

        old_statistics = core.statistics
        core.statistics = SimpleNamespace(append_stat_value=lambda *_args: None)

        try:
            with patch.object(Uploads, "_finish_transfer") as finish_transfer:
                core.uploads._file_connection_closed(
                    username, upload.token, sock, timed_out=False, current_byte_offset=100)
        finally:
            core.statistics = old_statistics

        self.assertEqual(100, upload.current_byte_offset)
        finish_transfer.assert_called_once_with(upload)

    def test_upload_failed_notice_retries_after_queue_rejection(self):
        """Abrupt upload close should retry the UploadFailed notice under queue backpressure."""

        username = "failednoticeuser"
        virtual_path = "Folder\\RetryMe.mp3"
        sock = object()
        upload = Transfer(username=username, virtual_path=virtual_path, folder_path=DATA_FOLDER_PATH, size=100)
        upload.sock = sock
        upload.token = 999
        upload.current_byte_offset = 10
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses[username] = UserStatus.ONLINE
        core.uploads._append_transfer(upload)
        core.uploads._activate_transfer(upload, upload.token)

        with patch.object(core.__class__, "send_message_to_peer", return_value=False), \
                patch.object(core.__class__, "send_message_to_network_thread", return_value=True), \
                patch.object(events.__class__, "schedule", return_value=789):
            core.uploads._file_connection_closed(username, upload.token, sock, timed_out=False)

        self.assertEqual(1, len(core.uploads._pending_peer_transfer_notices))
        queued_username, msg, _key = core.uploads._pending_peer_transfer_notices[0]
        self.assertEqual(username, queued_username)
        self.assertIsInstance(msg, UploadFailed)
        self.assertEqual(virtual_path, msg.file)

    def test_upload_speed_report_retries_after_lower_server_output_rejection(self):
        """A lower server-output failure should reuse the upload-speed retry lane."""

        with patch.object(events.__class__, "schedule", return_value=654) as schedule:
            core.uploads._server_message_unsent(SendUploadSpeed(9876))

        self.assertEqual([9876], list(core.uploads._pending_upload_speed_reports))
        self.assertEqual(654, core.uploads._upload_speed_report_timer_id)
        schedule.assert_called_once()


    def test_upload_speed_report_retries_after_queue_rejection(self):
        """Finished upload speed reports should not be lost when server output is backpressured."""

        sent_speeds = []

        def fake_send(_core, msg):
            sent_speeds.append(msg.speed)
            return len(sent_speeds) > 1

        with patch.object(core.__class__, "send_message_to_server", fake_send), \
                patch.object(events.__class__, "schedule", return_value=321) as schedule:
            self.assertFalse(core.uploads._send_upload_speed_report(9876))
            self.assertEqual([9876], list(core.uploads._pending_upload_speed_reports))
            self.assertEqual(321, core.uploads._upload_speed_report_timer_id)
            schedule.assert_called_once()

            core.uploads._process_upload_speed_reports()

        self.assertEqual([9876, 9876], sent_speeds)
        self.assertFalse(core.uploads._pending_upload_speed_reports)
        self.assertIsNone(core.uploads._upload_speed_report_timer_id)

    def test_upload_request_requeues_transfer_when_peer_queue_rejects(self):
        """Backpressure must not leave an upload active when TransferRequest was dropped."""

        username = "queueduploaduser"
        virtual_path = "Folder\\Upload.mp3"
        upload = Transfer(username=username, virtual_path=virtual_path, folder_path=DATA_FOLDER_PATH, size=123)
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses[username] = UserStatus.ONLINE
        core.uploads._append_transfer(upload)
        core.uploads._enqueue_transfer(upload)
        core.uploads._user_update_counters[username] = 1

        with patch.object(core.uploads.__class__, "is_new_upload_accepted", return_value=True), \
                patch.object(core.shares.__class__, "virtual2real", return_value=__file__), \
                patch.object(core.shares.__class__, "file_is_shared", return_value=(True, 123)), \
                patch.object(core.uploads.__class__, "is_file_readable", return_value=True), \
                patch.object(core.uploads.__class__, "_get_current_file_size", return_value=123), \
                patch.object(core.__class__, "send_message_to_peer", return_value=False), \
                patch.object(core.uploads.__class__, "_schedule_upload_queue_check") as schedule_upload_queue_check:
            core.uploads._check_upload_queue()

        self.assertEqual(TransferStatus.QUEUED, upload.status)
        self.assertIsNone(upload.token)
        self.assertIn(virtual_path, core.uploads.queued_users[username])
        self.assertNotIn(username, core.uploads.active_users)
        schedule_upload_queue_check.assert_called_once()

    def test_bulk_upload_abort_actions_are_batched(self):
        uploads = core.uploads
        transfers = [Transfer(f"bulk{i}", f"file{i}.mp3") for i in range(5)]

        for transfer in transfers:
            transfer.status = TransferStatus.QUEUED

        aborted = []

        with patch.object(core.uploads.__class__, "MAX_BULK_UPLOAD_ACTIONS_PER_TICK", 2), \
                patch.object(core.uploads.__class__, "_abort_transfer", side_effect=lambda transfer, **_kwargs: aborted.append(transfer)), \
                patch.object(core.uploads.__class__, "_schedule_bulk_upload_actions",
                             lambda _self: setattr(_self, "_bulk_upload_action_timer_id", 123)):
            uploads.abort_uploads(transfers, status=TransferStatus.CANCELLED)

            self.assertEqual(transfers[:2], aborted)
            self.assertEqual(3, len(uploads._bulk_upload_action_queue))
            self.assertEqual(123, uploads._bulk_upload_action_timer_id)

            uploads._process_bulk_upload_actions()
            self.assertEqual(transfers[:4], aborted)

            uploads._process_bulk_upload_actions()
            self.assertEqual(transfers, aborted)
            self.assertFalse(uploads._bulk_upload_action_queue)

    def test_bulk_upload_clear_all_actions_are_batched(self):
        uploads = core.uploads
        uploads.transfers.clear()
        transfers = [Transfer(f"clear{i}", f"file{i}.mp3") for i in range(5)]

        for transfer in transfers:
            transfer.status = TransferStatus.FINISHED
            uploads._append_transfer(transfer)

        cleared = []

        with patch.object(core.uploads.__class__, "MAX_BULK_UPLOAD_ACTIONS_PER_TICK", 2), \
                patch.object(core.uploads.__class__, "MAX_BULK_UPLOAD_SOURCE_SCANS_PER_TICK", 2), \
                patch.object(core.uploads.__class__, "_clear_transfer", side_effect=lambda transfer, **_kwargs: cleared.append(transfer)), \
                patch.object(core.uploads.__class__, "_schedule_bulk_upload_actions",
                             lambda _self: setattr(_self, "_bulk_upload_action_timer_id", 456)):
            uploads.clear_uploads(statuses={TransferStatus.FINISHED})

            self.assertEqual(transfers[:2], cleared)
            self.assertFalse(uploads._bulk_upload_action_queue)
            self.assertIsNotNone(uploads._bulk_upload_clear_all_state)
            self.assertEqual(456, uploads._bulk_upload_action_timer_id)

            uploads._process_bulk_upload_actions()
            uploads._process_bulk_upload_actions()
            self.assertEqual(transfers, cleared)
            self.assertFalse(uploads._bulk_upload_action_queue)
            self.assertIsNone(uploads._bulk_upload_clear_all_state)

    def test_bulk_upload_clear_all_unfiltered_avoids_seen_key_ledger(self):
        uploads = core.uploads
        uploads.transfers.clear()
        transfers = [Transfer(f"clearall{i}", f"file{i}.mp3") for i in range(5)]

        for transfer in transfers:
            transfer.status = TransferStatus.FINISHED
            uploads._append_transfer(transfer)

        with patch.object(core.uploads.__class__, "MAX_BULK_UPLOAD_ACTIONS_PER_TICK", 2), \
                patch.object(core.uploads.__class__, "MAX_BULK_UPLOAD_SOURCE_SCANS_PER_TICK", 2), \
                patch.object(core.uploads.__class__, "_schedule_bulk_upload_actions",
                             lambda _self: setattr(_self, "_bulk_upload_action_timer_id", 789)):
            uploads.clear_uploads()

            self.assertEqual(3, len(uploads.transfers))
            self.assertIsNotNone(uploads._bulk_upload_clear_all_state)
            self.assertIsNone(uploads._bulk_upload_clear_all_state[2])
            self.assertFalse(uploads._bulk_upload_action_queue)

            uploads._process_bulk_upload_actions()
            self.assertEqual(1, len(uploads.transfers))

            uploads._process_bulk_upload_actions()
            self.assertFalse(uploads.transfers)
            self.assertIsNone(uploads._bulk_upload_clear_all_state)

    def test_load_uploads(self):
        """Test loading a uploads.json file."""

        transfers = list(core.uploads.transfers.values())

        # Only finished uploads are loaded, other types should never be stored
        self.assertEqual(len(transfers), 3)

        transfer = transfers[2]

        self.assertEqual(transfer.username, "user5")
        self.assertEqual(transfer.virtual_path, "Junk\\Song5.mp3")
        self.assertEqual(transfer.status, TransferStatus.FINISHED)
        self.assertEqual(transfer.size, 11733776)
        self.assertEqual(transfer.current_byte_offset, 11733776)
        self.assertFalse(transfer.file_attributes)

        transfer = transfers[0]

        self.assertEqual(transfer.username, "user3")
        self.assertEqual(transfer.virtual_path, "Junk\\Song3.flac")
        self.assertEqual(transfer.status, TransferStatus.FINISHED)
        self.assertEqual(transfer.size, 27231044)
        self.assertEqual(transfer.current_byte_offset, 27231044)
        self.assertEqual(transfer.file_attributes, {
            FileAttribute.BITRATE: 792,
            FileAttribute.DURATION: 268
        })

    def test_save_uploads(self):
        """Verify that the order of the upload list at the end of the session
        is identical to the one we loaded.

        Ignore the first two unfinished uploads, since only finished uploads are
        saved to file.
        """

        old_transfers = core.uploads._load_transfers_file(TRANSFERS_FILE_PATH)[2:]
        core.uploads._save_transfers(force=True)
        saved_transfers = core.uploads._load_transfers_file(SAVED_TRANSFERS_FILE_PATH)

        self.assertEqual(old_transfers, saved_transfers)

    @staticmethod
    def _make_queue_upload(username, virtual_path):
        msg = QueueUpload(file=virtual_path)
        msg.username = username
        msg.addr = ("203.0.113.9", 2234)
        return msg

    def test_pending_upload_requests_deduplicated_while_rescanning(self):
        """Repeated upload requests during a share rescan should not grow without bound."""

        core.shares.rescanning = True
        msg = self._make_queue_upload("remoteuser", "Junk\\Song3.flac")

        try:
            with patch.object(core.shares.__class__, "check_user_permission", return_value=(PermissionLevel.PUBLIC, None)):
                for _ in range(3):
                    allowed, reject_reason, _size = core.uploads._check_queue_upload_allowed(
                        msg.username, msg.addr, msg.file, None, msg)
                    self.assertFalse(allowed)
                    self.assertIsNone(reject_reason)

            self.assertEqual(1, len(core.uploads._pending_network_msgs))
            self.assertEqual(1, len(core.uploads._pending_network_msg_keys))

        finally:
            core.shares.rescanning = False

    def test_pending_upload_requests_capped_while_rescanning(self):
        """A rescan should not allow unlimited remote requests to pile up in memory."""

        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_PENDING_NETWORK_MESSAGES
        upload_class.MAX_PENDING_NETWORK_MESSAGES = 2
        core.shares.rescanning = True

        try:
            with patch.object(core.shares.__class__, "check_user_permission",
                              return_value=(PermissionLevel.PUBLIC, None)):
                for filename in ("A.flac", "B.flac", "C.flac"):
                    msg = self._make_queue_upload("remoteuser", f"Junk\\{filename}")
                    allowed, reject_reason, _size = core.uploads._check_queue_upload_allowed(
                        msg.username, msg.addr, msg.file, None, msg)
                    self.assertFalse(allowed)
                    self.assertIsNone(reject_reason)

            self.assertEqual(2, len(core.uploads._pending_network_msgs))
            self.assertEqual(2, len(core.uploads._pending_network_msg_keys))
            self.assertTrue(core.uploads._pending_network_msgs_limit_logged)

        finally:
            core.shares.rescanning = False
            upload_class.MAX_PENDING_NETWORK_MESSAGES = old_limit

    def test_pending_upload_request_keys_cleared_after_rescan(self):
        core.shares.rescanning = True

        try:
            msg = self._make_queue_upload("remoteuser", "Junk\\Song3.flac")

            with patch.object(core.shares.__class__, "check_user_permission",
                              return_value=(PermissionLevel.PUBLIC, None)):
                core.uploads._check_queue_upload_allowed(msg.username, msg.addr, msg.file, None, msg)

            with patch.object(core.__class__, "send_message_to_network_thread") as send_message_to_network_thread:
                core.uploads._shares_ready(True)

            send_message_to_network_thread.assert_called_once()
            self.assertFalse(core.uploads._pending_network_msgs)
            self.assertFalse(core.uploads._pending_network_msg_keys)
            self.assertFalse(core.uploads._pending_network_msgs_limit_logged)

        finally:
            core.shares.rescanning = False

    def test_pending_upload_requests_flush_in_bounded_batches_after_rescan(self):
        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_PENDING_NETWORK_MESSAGES_PER_READY_TICK
        upload_class.MAX_PENDING_NETWORK_MESSAGES_PER_READY_TICK = 2

        try:
            for filename in ("A.flac", "B.flac", "C.flac"):
                msg = self._make_queue_upload("remoteuser", f"Junk\\{filename}")
                core.uploads._pending_network_msgs.append(msg)
                core.uploads._pending_network_msg_keys.add(core.uploads._get_pending_network_msg_key(msg))

            schedule_calls = []

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                schedule_calls.append((delay, callback, callback_args, repeat))
                return 12345

            with patch.object(core.__class__, "send_message_to_network_thread") as send_message_to_network_thread:
                with patch.object(events.__class__, "schedule", schedule):
                    core.uploads._shares_ready(True)

            send_message_to_network_thread.assert_called_once()
            sent_event = send_message_to_network_thread.call_args.args[0]
            self.assertEqual(2, len(sent_event.msgs))
            self.assertEqual(1, len(core.uploads._pending_network_msgs))
            self.assertEqual(1, len(core.uploads._pending_network_msg_keys))
            self.assertEqual(12345, core.uploads._pending_network_flush_timer_id)
            self.assertEqual(1, len(schedule_calls))

        finally:
            upload_class.MAX_PENDING_NETWORK_MESSAGES_PER_READY_TICK = old_limit
            core.uploads._pending_network_msgs.clear()
            core.uploads._pending_network_msg_keys.clear()
            core.uploads._pending_network_flush_timer_id = None


    def test_pending_upload_requests_restored_when_network_queue_rejects_replay(self):
        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_PENDING_NETWORK_MESSAGES_PER_READY_TICK
        old_delay = upload_class.PENDING_NETWORK_FLUSH_RETRY_DELAY
        upload_class.MAX_PENDING_NETWORK_MESSAGES_PER_READY_TICK = 2
        upload_class.PENDING_NETWORK_FLUSH_RETRY_DELAY = 7

        try:
            for filename in ("A.flac", "B.flac", "C.flac"):
                msg = self._make_queue_upload("remoteuser", f"Junk\\{filename}")
                core.uploads._pending_network_msgs.append(msg)
                core.uploads._pending_network_msg_keys.add(core.uploads._get_pending_network_msg_key(msg))

            schedule_calls = []

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                schedule_calls.append((delay, callback, callback_args, repeat))
                return 67890

            with patch.object(core.__class__, "send_message_to_network_thread", return_value=False) as send_message:
                with patch.object(events.__class__, "schedule", schedule):
                    core.uploads._shares_ready(True)

            send_message.assert_called_once()
            sent_event = send_message.call_args.args[0]
            self.assertEqual(2, len(sent_event.msgs))

            # The rejected batch is restored at the front, preserving order and
            # duplicate-tracking keys so the peer requests can be replayed later.
            self.assertEqual(["Junk\\A.flac", "Junk\\B.flac", "Junk\\C.flac"], [
                msg.file for msg in core.uploads._pending_network_msgs])
            self.assertEqual(3, len(core.uploads._pending_network_msg_keys))
            self.assertEqual(67890, core.uploads._pending_network_flush_timer_id)
            self.assertEqual([(7, core.uploads._flush_pending_network_msgs, None, False)], schedule_calls)

        finally:
            upload_class.MAX_PENDING_NETWORK_MESSAGES_PER_READY_TICK = old_limit
            upload_class.PENDING_NETWORK_FLUSH_RETRY_DELAY = old_delay
            core.uploads._pending_network_msgs.clear()
            core.uploads._pending_network_msg_keys.clear()
            core.uploads._pending_network_flush_timer_id = None

    def test_queue_limit_rejects_when_global_queue_is_full(self):
        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_TOTAL_QUEUED_UPLOADS
        upload_class.MAX_TOTAL_QUEUED_UPLOADS = 1

        try:
            core.uploads.queued_transfers[("user", "Junk\\Song.flac")] = Transfer(
                username="user", virtual_path="Junk\\Song.flac")

            is_limited, reject_reason = core.uploads.is_queue_limit_reached("newuser")

            self.assertTrue(is_limited)
            self.assertEqual(TransferRejectReason.TOO_MANY_FILES, reject_reason)

        finally:
            upload_class.MAX_TOTAL_QUEUED_UPLOADS = old_limit

    def test_user_online_only_cancels_user_logged_off_uploads(self):
        """A user-status update must not overwrite unrelated failed upload states."""

        username = "retryuser"
        core.users.login_status = UserStatus.ONLINE
        core.users.watch_user(username, context="uploads")
        offline_upload = Transfer(username=username, virtual_path="Junk\\Offline.flac")
        timeout_upload = Transfer(username=username, virtual_path="Junk\\Timeout.flac")

        offline_upload.status = TransferStatus.USER_LOGGED_OFF
        timeout_upload.status = TransferStatus.CONNECTION_TIMEOUT

        for upload in (offline_upload, timeout_upload):
            core.uploads._append_transfer(upload)
            core.uploads._fail_transfer(upload)

        core.uploads._online_users.discard(username)
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses[username] = UserStatus.ONLINE
        core.users.watch_user(username, context="uploads")
        core.uploads._user_status(SimpleNamespace(user=username, status=UserStatus.ONLINE))

        self.assertEqual(TransferStatus.CANCELLED, offline_upload.status)
        self.assertIn(offline_upload.virtual_path, core.uploads.failed_users[username])

        self.assertEqual(TransferStatus.CONNECTION_TIMEOUT, timeout_upload.status)
        self.assertIn(timeout_upload.virtual_path, core.uploads.failed_users[username])
        self.assertNotIn(timeout_upload, core.uploads.queued_transfers)

    def test_user_status_upload_cancels_are_batched(self):
        """A user-status update should not cancel every offline upload in one tick."""

        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_USER_STATUS_UPLOAD_CANCELS_PER_TICK
        upload_class.MAX_USER_STATUS_UPLOAD_CANCELS_PER_TICK = 2
        username = "bulkstatususer"

        try:
            core.users.login_status = UserStatus.ONLINE
            core.users.statuses[username] = UserStatus.ONLINE
            core.users.watch_user(username, context="uploads")

            for index in range(5):
                upload = Transfer(username=username, virtual_path=f"Junk\\Offline{index}.flac")
                upload.status = TransferStatus.USER_LOGGED_OFF
                core.uploads._append_transfer(upload)
                core.uploads._fail_transfer(upload)

            schedule_calls = []

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                schedule_calls.append((delay, callback, callback_args, repeat))
                return len(schedule_calls)

            with patch.object(events.__class__, "schedule", schedule):
                core.uploads._user_status(SimpleNamespace(user=username, status=UserStatus.ONLINE))

                self.assertEqual(2, sum(
                    upload.status == TransferStatus.CANCELLED
                    for upload in core.uploads.failed_users[username].values()
                ))
                self.assertEqual(3, sum(
                    upload.status == TransferStatus.USER_LOGGED_OFF
                    for upload in core.uploads.failed_users[username].values()
                ))
                self.assertEqual(1, len(schedule_calls))

                schedule_calls.pop(0)[1]()
                self.assertEqual(4, sum(
                    upload.status == TransferStatus.CANCELLED
                    for upload in core.uploads.failed_users[username].values()
                ))
                self.assertEqual(1, sum(
                    upload.status == TransferStatus.USER_LOGGED_OFF
                    for upload in core.uploads.failed_users[username].values()
                ))

                schedule_calls.pop(0)[1]()
                self.assertEqual(5, sum(
                    upload.status == TransferStatus.CANCELLED
                    for upload in core.uploads.failed_users[username].values()
                ))
                self.assertFalse(any(
                    upload.status == TransferStatus.USER_LOGGED_OFF
                    for upload in core.uploads.failed_users[username].values()
                ))

        finally:
            upload_class.MAX_USER_STATUS_UPLOAD_CANCELS_PER_TICK = old_limit
            core.uploads._user_status_cancel_timer_id = None
            core.uploads._user_status_cancel_queue.clear()
            core.uploads._user_status_cancel_users.clear()

    def test_user_offline_upload_aborts_are_batched(self):
        """A user-status offline update should not abort every failed upload in one tick."""

        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_USER_STATUS_UPLOAD_OFFLINE_ABORTS_PER_TICK
        upload_class.MAX_USER_STATUS_UPLOAD_OFFLINE_ABORTS_PER_TICK = 2
        username = "bulkofflinestatususer"

        try:
            core.users.login_status = UserStatus.ONLINE
            core.users.statuses[username] = UserStatus.ONLINE
            core.users.watch_user(username, context="uploads")
            core.uploads._online_users.add(username)

            for index in range(5):
                upload = Transfer(username=username, virtual_path=f"Junk\\Timeout{index}.flac")
                upload.status = TransferStatus.CONNECTION_TIMEOUT
                core.uploads._append_transfer(upload)
                core.uploads._fail_transfer(upload)

            schedule_calls = []

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                schedule_calls.append((delay, callback, callback_args, repeat))
                return len(schedule_calls)

            with patch.object(events.__class__, "schedule", schedule):
                core.uploads._user_status(SimpleNamespace(user=username, status=UserStatus.OFFLINE))

                self.assertEqual(2, sum(
                    upload.status == TransferStatus.USER_LOGGED_OFF
                    for upload in core.uploads.failed_users[username].values()
                ))
                self.assertEqual(3, sum(
                    upload.status == TransferStatus.CONNECTION_TIMEOUT
                    for upload in core.uploads.failed_users[username].values()
                ))
                self.assertEqual(1, len(schedule_calls))

                schedule_calls.pop(0)[1]()
                self.assertEqual(4, sum(
                    upload.status == TransferStatus.USER_LOGGED_OFF
                    for upload in core.uploads.failed_users[username].values()
                ))
                self.assertEqual(1, sum(
                    upload.status == TransferStatus.CONNECTION_TIMEOUT
                    for upload in core.uploads.failed_users[username].values()
                ))

                schedule_calls.pop(0)[1]()
                self.assertTrue(all(
                    upload.status == TransferStatus.USER_LOGGED_OFF
                    for upload in core.uploads.failed_users[username].values()
                ))

        finally:
            upload_class.MAX_USER_STATUS_UPLOAD_OFFLINE_ABORTS_PER_TICK = old_limit
            core.uploads._user_status_offline_timer_id = None
            core.uploads._user_status_offline_queue.clear()
            core.uploads._user_status_offline_users.clear()

    def test_retry_failed_uploads_batches_large_failed_sets(self):
        """Connection-timeout upload retries should not all run in one timer callback."""

        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_FAILED_UPLOAD_RETRIES_PER_TICK
        upload_class.MAX_FAILED_UPLOAD_RETRIES_PER_TICK = 2

        try:
            core.users.login_status = UserStatus.ONLINE
            core.users.statuses["retryuser"] = UserStatus.ONLINE

            for index in range(5):
                upload = Transfer(username="retryuser", virtual_path=f"Junk\\Timeout{index}.flac")
                upload.status = TransferStatus.CONNECTION_TIMEOUT
                core.uploads._append_transfer(upload)
                core.uploads._fail_transfer(upload)

            schedule_calls = []

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                schedule_calls.append((delay, callback, callback_args, repeat))
                return 98765

            with patch.object(events.__class__, "schedule", schedule):
                core.uploads._retry_failed_uploads()

            self.assertEqual(2, len(core.uploads.queued_transfers))
            self.assertEqual(3, len(core.uploads.failed_users["retryuser"]))
            self.assertEqual(98765, core.uploads._retry_failed_uploads_continuation_timer_id)
            self.assertEqual(1, len(schedule_calls))

        finally:
            upload_class.MAX_FAILED_UPLOAD_RETRIES_PER_TICK = old_limit
            core.uploads._retry_failed_uploads_continuation_timer_id = None

    def test_ban_user_ip_handles_active_upload_without_socket(self):
        """Banning by IP must not crash if the active upload has no file socket yet."""

        upload = Transfer(username="activeuser", virtual_path="Junk\\Song.mp3")
        core.uploads._append_transfer(upload)
        core.uploads._activate_transfer(upload, token=123)
        core.users.addresses["activeuser"] = ("10.0.0.4", 2242)

        core.uploads._ban_user(ip_address="10.0.0.4")

        self.assertNotIn("activeuser", core.uploads.active_users)
        self.assertIsNone(core.uploads.get_transfer("activeuser", "Junk\\Song.mp3"))

    def test_upload_open_rejects_symlink(self):
        """Upload startup must not follow a stale shared-path symlink."""

        if os.name == "nt":
            self.skipTest("creating symbolic links requires elevated privileges on Windows")

        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as temp_dir:
            target_path = os.path.join(temp_dir, "target.flac")
            symlink_path = os.path.join(temp_dir, "shared.flac")

            with open(target_path, "wb") as file_handle:
                file_handle.write(b"secret")

            try:
                os.symlink(target_path, symlink_path)
            except OSError as error:
                self.skipTest(f"creating symbolic link failed: {error}")

            self.assertFalse(core.uploads.is_file_readable("Shared\\shared.flac", symlink_path))

            with self.assertRaises(OSError):
                core.uploads._open_upload_file("Shared\\shared.flac", symlink_path)

    def test_upload_open_rejects_fifo(self):
        """Upload startup must not block on a stale shared-path FIFO."""

        if not hasattr(os, "mkfifo"):
            self.skipTest("creating FIFOs is not supported on this platform")

        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as temp_dir:
            fifo_path = os.path.join(temp_dir, "shared_pipe")

            try:
                os.mkfifo(fifo_path)
            except OSError as error:
                self.skipTest(f"creating FIFO failed: {error}")

            self.assertFalse(core.uploads.is_file_readable("Shared\\shared_pipe", fifo_path))

            with self.assertRaises(OSError):
                core.uploads._open_upload_file("Shared\\shared_pipe", fifo_path)


    def test_upload_queue_validation_is_batched(self):
        """Invalid queued uploads should not all be cleared in one main-loop turn."""

        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_UPLOAD_QUEUE_VALIDATION_STEPS_PER_TICK
        upload_class.MAX_UPLOAD_QUEUE_VALIDATION_STEPS_PER_TICK = 2
        core.users.login_status = UserStatus.ONLINE
        core.shares.rescanning = False

        try:
            for index in range(3):
                username = f"remoteuser{index}"
                transfer = Transfer(username=username, virtual_path=f"Junk\\Missing{index}.flac", size=1)
                core.users.statuses[username] = UserStatus.ONLINE
                core.uploads._append_transfer(transfer)
                core.uploads._enqueue_transfer(transfer)
                core.uploads._update_transfer(transfer)

            schedule_calls = []

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                schedule_calls.append((delay, callback, callback_args, repeat))
                return 12345

            with patch.object(core.uploads.__class__, "is_new_upload_accepted", return_value=True), \
                    patch.object(core.shares.__class__, "virtual2real", return_value="/missing"), \
                    patch.object(core.shares.__class__, "file_is_shared", return_value=(False, 0)), \
                    patch.object(events.__class__, "schedule", schedule):
                core.uploads._check_upload_queue()

            self.assertEqual(1, len(core.uploads.queued_transfers))
            self.assertEqual(12345, core.uploads._upload_queue_check_timer_id)
            self.assertEqual(1, len(schedule_calls))

        finally:
            upload_class.MAX_UPLOAD_QUEUE_VALIDATION_STEPS_PER_TICK = old_limit

    def test_fifo_queue_position_request_does_not_materialize_all_positions(self):
        """A single FIFO queue-position request should not build a full queue-position map."""

        config.sections["transfers"]["fifoqueue"] = True

        first_upload = Transfer(username="remoteuser1", virtual_path="Junk\\Song1.flac", size=1)
        second_upload = Transfer(username="remoteuser2", virtual_path="Junk\\Song2.flac", size=1)

        for upload in (first_upload, second_upload):
            core.uploads._append_transfer(upload)
            core.uploads._enqueue_transfer(upload)

        msg = PlaceInQueueRequest(file=second_upload.virtual_path)
        msg.username = second_upload.username

        with patch("pynicotine.uploads.time.monotonic", return_value=100.0), \
                patch.object(core.__class__, "send_message_to_peer") as send_message_to_peer:
            core.uploads._place_in_queue_request(msg)

        _username, response = send_message_to_peer.call_args.args
        self.assertEqual(2, response.place)
        self.assertIn(("fifo", first_upload.username, first_upload.virtual_path), core.uploads._queue_positions)
        self.assertIn(("fifo", second_upload.username, second_upload.virtual_path), core.uploads._queue_positions)

    def test_queue_position_not_updated_when_response_queue_rejects(self):
        """Local queue position should not claim an unsent PlaceInQueueResponse was delivered."""

        config.sections["transfers"]["fifoqueue"] = True
        upload = Transfer(username="remoteuser", virtual_path="Junk\\Song.flac", size=1)
        core.uploads._append_transfer(upload)
        core.uploads._enqueue_transfer(upload)

        msg = PlaceInQueueRequest(file=upload.virtual_path)
        msg.username = upload.username

        with patch("pynicotine.uploads.time.monotonic", return_value=100.0), \
                patch.object(core.__class__, "send_message_to_peer", return_value=False), \
                patch.object(core.uploads.__class__, "_update_transfer") as update_transfer:
            core.uploads._place_in_queue_request(msg)

        self.assertEqual(0, upload.queue_position)
        update_transfer.assert_not_called()

    def test_non_fifo_queue_position_request_does_not_materialize_user_positions(self):
        """A single non-FIFO request should not build a map for every queued file."""

        config.sections["transfers"]["fifoqueue"] = False

        first_upload = Transfer(username="remoteuser", virtual_path="Junk\\Song1.flac", size=1)
        second_upload = Transfer(username="remoteuser", virtual_path="Junk\\Song2.flac", size=1)

        for upload in (first_upload, second_upload):
            core.uploads._append_transfer(upload)
            core.uploads._enqueue_transfer(upload)

        msg = PlaceInQueueRequest(file=second_upload.virtual_path)
        msg.username = second_upload.username

        with patch("pynicotine.uploads.time.monotonic", return_value=100.0), \
                patch.object(core.__class__, "send_message_to_peer") as send_message_to_peer:
            core.uploads._place_in_queue_request(msg)

        _username, response = send_message_to_peer.call_args.args
        self.assertEqual(3, response.place)
        self.assertIn(("non-fifo", first_upload.username, first_upload.virtual_path), core.uploads._queue_positions)
        self.assertIn(("non-fifo", second_upload.username, second_upload.virtual_path), core.uploads._queue_positions)
        self.assertEqual({first_upload.virtual_path: 1, second_upload.virtual_path: 2},
                         dict(core.uploads._queue_position_users[first_upload.username]))


    def test_fifo_queue_position_request_reuses_cached_answer(self):
        """Repeated queue-position requests should not rescan unchanged FIFO queues."""

        config.sections["transfers"]["fifoqueue"] = True

        first_upload = Transfer(username="remoteuser1", virtual_path="Junk\\Song1.flac", size=1)
        second_upload = Transfer(username="remoteuser2", virtual_path="Junk\\Song2.flac", size=1)

        for upload in (first_upload, second_upload):
            core.uploads._append_transfer(upload)
            core.uploads._enqueue_transfer(upload)

        msg = PlaceInQueueRequest(file=second_upload.virtual_path)
        msg.username = second_upload.username

        with patch("pynicotine.uploads.time.monotonic", return_value=100.0), \
                patch.object(core.__class__, "send_message_to_peer") as send_message_to_peer:
            core.uploads._place_in_queue_request(msg)

        self.assertEqual(2, send_message_to_peer.call_args.args[1].place)

        class ExplodingQueuedTransfers(dict):
            def __iter__(self):
                raise AssertionError("queue-position cache was not used")

        core.uploads.queued_transfers = ExplodingQueuedTransfers(core.uploads.queued_transfers)

        with patch("pynicotine.uploads.time.monotonic", return_value=102.0), \
                patch.object(core.__class__, "send_message_to_peer") as send_message_to_peer:
            core.uploads._place_in_queue_request(msg)

        self.assertEqual(2, send_message_to_peer.call_args.args[1].place)

    def test_privileged_queue_counts_are_cached_and_invalidated(self):
        """Privilege-aware queue-position requests should not rescan every queued user repeatedly."""

        core.users.privileged.add("remoteuser1")
        core.users.privileged.add("remoteuser2")

        for username in ("remoteuser1", "remoteuser2", "remoteuser3"):
            transfer = Transfer(username=username, virtual_path=f"Junk\\{username}.flac", size=1)
            core.uploads._append_transfer(transfer)
            core.uploads._enqueue_transfer(transfer)

        privileged_queued_users = core.uploads._get_privileged_queued_users()
        self.assertEqual({"remoteuser1": 1, "remoteuser2": 1}, privileged_queued_users)
        self.assertIs(privileged_queued_users, core.uploads._get_privileged_queued_users())
        self.assertEqual(2, core.uploads._get_privileged_queued_count())
        self.assertEqual(2, core.uploads._get_privileged_queued_count())

        core.uploads._invalidate_queue_position_cache("remoteuser1")
        self.assertIsNone(core.uploads._privileged_queued_users_cache)
        self.assertIsNone(core.uploads._privileged_queued_count_cache)

        rebuilt_queued_users = core.uploads._get_privileged_queued_users()
        self.assertEqual(privileged_queued_users, rebuilt_queued_users)
        self.assertIsNot(privileged_queued_users, rebuilt_queued_users)
        self.assertEqual(2, core.uploads._get_privileged_queued_count())

    def test_place_in_queue_requests_are_rate_limited(self):
        """Repeated queue-position requests should not repeatedly scan a large upload queue."""

        upload = Transfer(username="remoteuser", virtual_path="Junk\\Song3.flac", size=1234)
        core.uploads._append_transfer(upload)
        core.uploads._enqueue_transfer(upload)

        msg = PlaceInQueueRequest(file=upload.virtual_path)
        msg.username = upload.username

        with patch("pynicotine.uploads.time.monotonic", side_effect=(100.0, 100.5, 101.1)):
            with patch.object(core.__class__, "send_message_to_peer") as send_message_to_peer:
                core.uploads._place_in_queue_request(msg)
                core.uploads._place_in_queue_request(msg)
                core.uploads._place_in_queue_request(msg)

        self.assertEqual(2, send_message_to_peer.call_count)

    def test_queue_position_rate_limit_table_is_bounded(self):
        """Queue-position rate limiting must not create a new unbounded table."""

        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_QUEUE_POSITION_REQUEST_TIMES
        upload_class.MAX_QUEUE_POSITION_REQUEST_TIMES = 2

        try:
            with patch("pynicotine.uploads.time.monotonic", side_effect=(100.0, 100.0, 100.0)):
                self.assertFalse(core.uploads._is_queue_position_request_limited("user1", "File1.mp3"))
                self.assertFalse(core.uploads._is_queue_position_request_limited("user2", "File2.mp3"))
                self.assertTrue(core.uploads._is_queue_position_request_limited("user3", "File3.mp3"))

            self.assertEqual(2, len(core.uploads._queue_position_request_times))

        finally:
            upload_class.MAX_QUEUE_POSITION_REQUEST_TIMES = old_limit

    def test_queue_position_requests_have_aggregate_rate_limit(self):
        """Many distinct files/users should not bypass queue-position throttling in one burst."""

        upload_class = core.uploads.__class__
        old_limit = upload_class.MAX_QUEUE_POSITION_REQUESTS_PER_INTERVAL
        upload_class.MAX_QUEUE_POSITION_REQUESTS_PER_INTERVAL = 2

        try:
            with patch("pynicotine.uploads.time.monotonic", return_value=100.0):
                self.assertFalse(core.uploads._is_queue_position_request_limited("user1", "File1.mp3"))
                self.assertFalse(core.uploads._is_queue_position_request_limited("user2", "File2.mp3"))
                self.assertTrue(core.uploads._is_queue_position_request_limited("user3", "File3.mp3"))

            self.assertEqual(2, core.uploads._queue_position_request_window_count)

        finally:
            upload_class.MAX_QUEUE_POSITION_REQUESTS_PER_INTERVAL = old_limit

    def test_legacy_upload_response_uses_current_file_size(self):
        """A legacy upload response should not advertise a stale size from the share database."""

        virtual_path = "Junk\\Changed.mp3"
        real_path = os.path.join(DATA_FOLDER_PATH, "Changed.mp3")
        msg = TransferRequest(direction=TransferDirection.DOWNLOAD, token=789, file=virtual_path)
        msg.username = "remoteuser"
        msg.addr = ("203.0.113.9", 2234)

        class DummyPluginHandler:
            @staticmethod
            def upload_queued_notification(_username, _virtual_path, _real_path):
                return None

        core.shares.rescanning = False

        try:
            with patch.object(core.shares.__class__, "check_user_permission",
                              return_value=(PermissionLevel.PUBLIC, None)), \
                    patch.object(core.shares.__class__, "virtual2real", return_value=real_path), \
                    patch.object(core.shares.__class__, "file_is_shared", return_value=(True, 10)), \
                    patch.object(core.uploads.__class__, "_get_current_file_size", return_value=99), \
                    patch.object(core, "pluginhandler", DummyPluginHandler()):
                response = core.uploads._transfer_request_uploads(msg)

        finally:
            core.shares.rescanning = False

        self.assertTrue(response.allowed)
        self.assertEqual(99, response.filesize)
        self.assertEqual(99, core.uploads.active_users[msg.username][msg.token].size)

    def test_legacy_upload_response_rejection_requeues_active_transfer(self):
        """An accepted legacy upload must not stay active if TransferResponse is not queued."""

        virtual_path = "Junk\\Changed.mp3"
        real_path = os.path.join(DATA_FOLDER_PATH, "Changed.mp3")
        msg = TransferRequest(direction=TransferDirection.DOWNLOAD, token=790, file=virtual_path)
        msg.username = "remoteuser"
        msg.addr = ("203.0.113.9", 2234)

        class DummyPluginHandler:
            @staticmethod
            def upload_queued_notification(_username, _virtual_path, _real_path):
                return None

        core.shares.rescanning = False

        try:
            with patch.object(core.shares.__class__, "check_user_permission",
                              return_value=(PermissionLevel.PUBLIC, None)), \
                    patch.object(core.shares.__class__, "virtual2real", return_value=real_path), \
                    patch.object(core.shares.__class__, "file_is_shared", return_value=(True, 10)), \
                    patch.object(core.uploads.__class__, "_get_current_file_size", return_value=99), \
                    patch.object(core.uploads.__class__, "_schedule_upload_queue_check") as schedule_check, \
                    patch.object(core.__class__, "send_message_to_peer", return_value=False), \
                    patch.object(core, "pluginhandler", DummyPluginHandler()):
                core.uploads._transfer_request(msg)

        finally:
            core.shares.rescanning = False

        transfer = core.uploads.get_transfer(msg.username, virtual_path)
        self.assertIsNotNone(transfer)
        self.assertEqual(TransferStatus.QUEUED, transfer.status)
        self.assertIsNone(transfer.token)
        self.assertNotIn(msg.username, core.uploads.active_users)
        self.assertIn(virtual_path, core.uploads.queued_users[msg.username])
        schedule_check.assert_called_once()

    def test_push_upload(self):
        """Verify that non-existent files are not added to the list."""

        core.uploads.enqueue_upload("newuser2", "Hello\\Upload\\File.mp3")
        core.uploads.enqueue_upload("newuser99", "Home\\None.mp3")

        self.assertEqual(len(core.uploads.transfers.values()), 3)

    def test_ban_user_by_ip_matches_remote_socket_address(self):
        """Banning by IP should match the peer address, not our local socket."""

        class MockSocket:
            @staticmethod
            def getpeername():
                return "203.0.113.7", 2234

            @staticmethod
            def getsockname():
                return "127.0.0.1", 1234

        upload = Transfer("remoteuser", "Shared\\Song.mp3")
        core.uploads._append_transfer(upload)
        core.uploads._activate_transfer(upload, token=1)
        upload.sock = MockSocket()

        core.uploads._ban_user(ip_address="203.0.113.7")

        self.assertNotIn("remoteuser", core.uploads.active_users)
        self.assertIsNone(core.uploads.get_transfer("remoteuser", "Shared\\Song.mp3"))

    def test_denied_upload_response_without_reason_does_not_start_file_connection(self):
        """A denied response without a reason is still denied."""

        upload = Transfer("remoteuser", "Shared\\Song.mp3")
        core.uploads._append_transfer(upload)
        core.uploads._activate_transfer(upload, token=123)

        msg = TransferResponse(allowed=False, token=123)
        msg.username = "remoteuser"

        core.uploads._transfer_response(msg)

        self.assertNotIn("remoteuser", core.uploads.active_users)
        self.assertEqual(TransferRejectReason.CANCELLED, upload.status)

    def test_allowed_upload_response_requeues_when_file_init_queue_rejects(self):
        """Backpressure must not leave an accepted upload active without FileTransferInit."""

        upload = Transfer("remoteuser", "Shared\\Song.mp3", folder_path=DATA_FOLDER_PATH, size=123)
        core.uploads._append_transfer(upload)
        core.uploads._activate_transfer(upload, token=123)

        msg = TransferResponse(allowed=True, token=123)
        msg.username = "remoteuser"

        with patch.object(core.__class__, "send_message_to_peer", return_value=False), \
                patch.object(core.uploads.__class__, "_schedule_upload_queue_check") as schedule_upload_queue_check:
            core.uploads._transfer_response(msg)

        self.assertEqual(TransferStatus.QUEUED, upload.status)
        self.assertIsNone(upload.token)
        self.assertIn(upload.virtual_path, core.uploads.queued_users[upload.username])
        self.assertNotIn(upload.username, core.uploads.active_users)
        schedule_upload_queue_check.assert_called_once()

    def test_upload_file_init_handoff_rejection_aborts_upload_without_started_notification(self):
        """UploadFile queue rejection must not leave a false started/transferring upload."""

        class FakeFile:
            closed = False

            def close(self):
                self.closed = True

        fake_file = FakeFile()
        upload = Transfer("remoteuser", "Shared\\Song.mp3", folder_path=DATA_FOLDER_PATH, size=123)
        core.uploads._append_transfer(upload)
        core.uploads._activate_transfer(upload, token=123)

        msg = SimpleNamespace(username="remoteuser", token=123, sock=object())
        fake_pluginhandler = SimpleNamespace(
            upload_started_notification=lambda *_args: self.fail("started notification should not fire"))

        with patch.object(core.shares.__class__, "virtual2real", return_value=__file__), \
                patch.object(core.uploads.__class__, "_open_upload_file", return_value=(fake_file, 123)), \
                patch.object(core.__class__, "send_message_to_network_thread", return_value=False), \
                patch("pynicotine.uploads.core.pluginhandler", fake_pluginhandler), \
                patch.object(core.uploads.__class__, "_check_upload_queue") as check_upload_queue:
            core.uploads._file_transfer_init(msg)

        self.assertTrue(fake_file.closed)
        self.assertIsNone(upload.sock)
        self.assertIsNone(upload.file_handle)
        self.assertNotIn("remoteuser", core.uploads.active_users)
        self.assertEqual(TransferStatus.CONNECTION_CLOSED, upload.status)
        check_upload_queue.assert_called_once()

    def test_upload_speed_report_is_retried_when_server_queue_rejects(self):
        """Average upload speed reports should not be silently lost under server backpressure."""

        with patch.object(core.__class__, "send_message_to_server", return_value=False) as send_message, \
                patch.object(core.uploads.__class__, "_schedule_upload_speed_report_retry") as schedule_retry:
            self.assertFalse(core.uploads._send_upload_speed_report(4096))

        send_message.assert_called_once()
        self.assertEqual([4096], list(core.uploads._pending_upload_speed_reports))
        schedule_retry.assert_called_once()

        sent_speeds = []

        def send_server(_core, msg):
            sent_speeds.append(msg.speed)
            return True

        with patch.object(core.__class__, "send_message_to_server", send_server):
            core.uploads._process_upload_speed_reports()

        self.assertEqual([4096], sent_speeds)
        self.assertFalse(core.uploads._pending_upload_speed_reports)
