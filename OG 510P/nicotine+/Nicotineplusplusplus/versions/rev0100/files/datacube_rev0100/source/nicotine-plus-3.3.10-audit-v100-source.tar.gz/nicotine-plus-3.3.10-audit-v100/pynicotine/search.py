# COPYRIGHT (C) 2020-2025 Nicotine+ Contributors
# COPYRIGHT (C) 2016-2018 Mutnick <mutnick@techie.com>
# COPYRIGHT (C) 2016-2017 Michael Labouebe <gfarmerfr@free.fr>
# COPYRIGHT (C) 2008-2011 quinox <quinox@users.sf.net>
# COPYRIGHT (C) 2006-2009 daelstorm <daelstorm@gmail.com>
# COPYRIGHT (C) 2003-2004 Hyriand <hyriand@thegraveyard.org>
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time

from collections import deque
from itertools import islice
from operator import itemgetter
from shlex import shlex

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.shares import PermissionLevel
from pynicotine.slskmessages import FileSearch
from pynicotine.slskmessages import FileSearchResponse
from pynicotine.slskmessages import increment_token
from pynicotine.slskmessages import initial_token
from pynicotine.slskmessages import RoomSearch
from pynicotine.slskmessages import SEARCH_TOKENS_ALLOWED
from pynicotine.slskmessages import release_search_response_user
from pynicotine.slskmessages import clear_search_response_users
from pynicotine.slskmessages import UserSearch
from pynicotine.slskmessages import WishlistSearch
from pynicotine.utils import TRANSLATE_PUNCTUATION


class SearchRequest:
    __slots__ = ("token", "term", "term_sanitized", "term_transmitted", "included_words", "excluded_words",
                 "mode", "room", "users", "is_ignored", "responded_users")

    def __init__(self, token=None, term=None, term_sanitized=None, term_transmitted=None, included_words=None,
                 excluded_words=None, mode="global", room=None, users=None, is_ignored=False):

        self.token = token
        self.term = term
        self.term_sanitized = term_sanitized
        self.term_transmitted = term_transmitted
        self.included_words = included_words
        self.excluded_words = excluded_words
        self.mode = mode
        self.room = room
        self.users = users
        self.is_ignored = is_ignored
        self.responded_users = set()


class Search:
    __slots__ = (
        "searches", "excluded_phrases", "token", "wishlist_interval", "_own_tokens",
        "_excluded_phrase_index", "_wishlist_timer_id", "_processed_search_requests", "_processed_search_request_order",
        "_processed_search_request_limit_logged", "_partial_word_scan_limit_logged",
        "_pending_folder_downloads", "_pending_folder_download_timer_id",
        "_pending_folder_download_limit_logged", "_pending_user_search_jobs",
        "_pending_user_search_timer_id", "_pending_user_search_limit_logged",
        "_wishlist_terms", "_wishlist_tokens_by_term", "_wishlist_limit_logged"
    )

    SEARCH_HISTORY_LIMIT = 200
    RESULT_FILTER_HISTORY_LIMIT = 50
    MAX_EXCLUDED_SEARCH_PHRASES = 4096
    MAX_LOGGED_EXCLUDED_SEARCH_PHRASES = 20
    MAX_SEARCH_RESPONSE_USERS = 10000
    MAX_INCOMING_SEARCH_REQUEST_WORDS = 64
    MAX_PROCESSED_SEARCH_REQUESTS = 65536
    SEARCH_REQUEST_RETENTION = 5 * 60
    MAX_PARTIAL_WORD_INDEX_SCAN = 100000
    MAX_SEARCH_RESULT_CANDIDATE_SCAN_MULTIPLIER = 16
    MAX_SEARCH_RESULT_CANDIDATE_SCAN = 100000
    MAX_EXCLUDED_SEARCH_RESULT_LOGS_PER_REQUEST = 8
    MAX_SEARCH_FOLDER_DOWNLOAD_FILES_PER_TICK = 1000
    MAX_PENDING_SEARCH_FOLDER_DOWNLOAD_JOBS = 512
    MAX_USER_SEARCH_MESSAGES_PER_TICK = 1000
    MAX_PENDING_USER_SEARCH_JOBS = 512
    MAX_USER_SEARCH_MESSAGES_PER_JOB = 50000
    MAX_STORED_USER_SEARCH_USERS = MAX_USER_SEARCH_MESSAGES_PER_JOB
    MAX_OUTGOING_SEARCH_TERM_BYTES = FileSearch.MAX_SEARCH_TERM_FIELD_BYTES
    MAX_OUTGOING_ROOM_SEARCH_ROOM_BYTES = RoomSearch.MAX_ROOM_FIELD_BYTES
    MAX_WISHLIST_SEARCHES = 50000
    MIN_WISHLIST_INTERVAL = 60
    MAX_WISHLIST_INTERVAL = 24 * 60 * 60
    REMOVED_SEARCH_CHARACTERS = [
        "!", '"', "#", "$", "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", "/", ":", ";",
        "<", "=", ">", "?", "@", "[", "\\", "]", "^", "_", "`", "{", "|", "}", "~", "–", "—",
        "‐", "’", "“", "”", "…"
    ]
    TRANSLATE_REMOVED_SEARCH_CHARACTERS = str.maketrans(dict.fromkeys(REMOVED_SEARCH_CHARACTERS, " "))

    def __init__(self):

        self.searches = {}
        self.excluded_phrases = []
        self._excluded_phrase_index = {}
        self.token = initial_token()
        self.wishlist_interval = 0
        self._own_tokens = set()
        self._wishlist_timer_id = None
        self._processed_search_requests = {}
        self._processed_search_request_order = deque()
        self._processed_search_request_limit_logged = False
        self._partial_word_scan_limit_logged = False
        self._pending_folder_downloads = deque()
        self._pending_folder_download_timer_id = None
        self._pending_folder_download_limit_logged = False
        self._pending_user_search_jobs = deque()
        self._pending_user_search_timer_id = None
        self._pending_user_search_limit_logged = False
        self._wishlist_terms = set()
        self._wishlist_tokens_by_term = {}
        self._wishlist_limit_logged = False

        for event_name, callback in (
            ("excluded-search-phrases", self._excluded_search_phrases),
            ("file-search-request-distributed", self._file_search_request_distributed),
            ("file-search-request-server", self._file_search_request_server),
            ("file-search-response", self._file_search_response),
            ("peer-response-delivery-failed", self._peer_response_delivery_failed),
            ("peer-response-unsent", self._peer_response_unsent),
            ("quit", self._quit),
            ("server-disconnect", self._server_disconnect),
            ("server-login", self._server_login),
            ("server-message-unsent", self._server_message_unsent),
            ("set-wishlist-interval", self._set_wishlist_interval),
            ("start", self._start)
        ):
            events.connect(event_name, callback)

    def _peer_response_delivery_failed(self, msg_class, _username, rollback_info):
        """Release parser-side search response dedupe when delivery fails.

        FileSearchResponse is parsed before it can be emitted to the main thread.
        If the bridge rejects the parsed response, the search owner never sees it,
        so do not keep the responder in the pre-parse duplicate ledger.
        """

        if msg_class is not FileSearchResponse or not rollback_info:
            return

        rollback_kind, token, responder = rollback_info

        if rollback_kind != "file-search-response":
            return

        release_search_response_user(token, responder)

        search = self.searches.get(token)

        if search is not None and responder is not None:
            search.responded_users.discard(responder)

    def _peer_response_unsent(self, msg_class, _username, rollback_info):
        """Undo incoming-search replay state when our response dies below peer output."""

        if msg_class is not FileSearchResponse or not rollback_info:
            return

        rollback_kind, username, token, is_own_search = rollback_info

        if rollback_kind != "file-search-response":
            return

        self._forget_search_request(username, token)

        if is_own_search:
            self._own_tokens.add(token)

    def _server_message_unsent(self, msg):
        """Clean up local search state when the matching server request never reached output."""

        if msg.__class__ is WishlistSearch:
            # Wishlist searches are long-lived and automatically retried on the
            # next interval. A lower output failure for one interval should only
            # revoke that interval's response grant, not hide the saved wish.
            return

        if msg.__class__ not in {FileSearch, RoomSearch, UserSearch}:
            return

        token = getattr(msg, "token", None)

        if token is None or token in SEARCH_TOKENS_ALLOWED:
            return

        search = self.searches.get(token)

        if search is None:
            return

        log.add_debug(
            "Removing local search token %s for term %s; server request was not sent",
            (token, search.term)
        )
        self.remove_search(token)

    def _start(self):

        # Create wishlist searches, but do not let an oversized or duplicated
        # restored wishlist turn startup and every wishlist interval into an
        # O(total searches) scan. Keep a direct term -> token index for the
        # interval callback and cap retained wishlist search objects.
        self._wishlist_terms.clear()
        self._wishlist_tokens_by_term.clear()
        self._wishlist_limit_logged = False

        for search_term in config.sections["server"]["autosearch"]:
            search_term = self._normalize_wishlist_term(search_term)

            if not search_term or not self._register_wishlist_term(search_term):
                continue

            if len(self._wishlist_tokens_by_term) >= self.MAX_WISHLIST_SEARCHES:
                self._log_wishlist_limit()
                break

            self.token = increment_token(self.token)
            self.add_search(search_term, mode="wishlist", is_ignored=True)

    def _quit(self):
        self._clear_pending_folder_downloads()
        self._clear_pending_user_searches()
        self.remove_all_searches()
        self._wishlist_terms.clear()
        self._wishlist_tokens_by_term.clear()
        self._wishlist_limit_logged = False

    def _server_login(self, msg):

        if not msg.success:
            return

        if not config.sections["searches"]["search_results"]:
            log.add_search(("Search responses disabled in preferences, ignoring search "
                            "requests from other users"))

    def _server_disconnect(self, _msg):

        self.excluded_phrases.clear()
        self._excluded_phrase_index.clear()
        self._own_tokens.clear()
        self._processed_search_requests.clear()
        self._processed_search_request_order.clear()
        self._processed_search_request_limit_logged = False
        self._partial_word_scan_limit_logged = False
        self._clear_pending_folder_downloads()
        self._clear_pending_user_searches()
        clear_search_response_users()

        events.cancel_scheduled(self._wishlist_timer_id)
        self._wishlist_timer_id = None
        self.wishlist_interval = 0

    def _clear_pending_folder_downloads(self):
        events.cancel_scheduled(self._pending_folder_download_timer_id)
        self._pending_folder_download_timer_id = None
        self._pending_folder_downloads.clear()
        self._pending_folder_download_limit_logged = False

    def _schedule_pending_folder_downloads(self):
        if not self._pending_folder_downloads or self._pending_folder_download_timer_id is not None:
            return

        self._pending_folder_download_timer_id = events.schedule(
            delay=0, callback=self._process_pending_folder_downloads)

        if self._pending_folder_download_timer_id is None:
            # Scheduler work is saturated; drop visible-result enqueue backlog
            # rather than retaining a large unreachable batch indefinitely.
            self._pending_folder_downloads.clear()

    def _queue_visible_folder_downloads(self, username, destination_folder_path, visible_files):
        if len(self._pending_folder_downloads) >= self.MAX_PENDING_SEARCH_FOLDER_DOWNLOAD_JOBS:
            if not self._pending_folder_download_limit_logged:
                log.add_debug(
                    "Pending search folder download queue reached %s jobs; discarding additional visible results",
                    self.MAX_PENDING_SEARCH_FOLDER_DOWNLOAD_JOBS
                )
                self._pending_folder_download_limit_logged = True

            return

        self._pending_folder_downloads.append((username, destination_folder_path, iter(visible_files)))
        self._process_pending_folder_downloads()

    def _process_pending_folder_downloads(self):
        self._pending_folder_download_timer_id = None
        num_processed = 0

        while (self._pending_folder_downloads
                and num_processed < self.MAX_SEARCH_FOLDER_DOWNLOAD_FILES_PER_TICK):
            username, destination_folder_path, visible_files = self._pending_folder_downloads[0]

            while num_processed < self.MAX_SEARCH_FOLDER_DOWNLOAD_FILES_PER_TICK:
                try:
                    file_path, size, file_attributes, *_unused = next(visible_files)
                except StopIteration:
                    self._pending_folder_downloads.popleft()
                    break

                core.downloads.enqueue_download(
                    username, file_path, folder_path=destination_folder_path,
                    size=size, file_attributes=file_attributes)
                num_processed += 1
            else:
                # Current folder still has visible results left.
                break

        if self._pending_folder_downloads:
            self._schedule_pending_folder_downloads()
        else:
            self._pending_folder_download_limit_logged = False

    def _clear_pending_user_searches(self):
        events.cancel_scheduled(self._pending_user_search_timer_id)
        self._pending_user_search_timer_id = None
        self._pending_user_search_jobs.clear()
        self._pending_user_search_limit_logged = False

    def _schedule_pending_user_searches(self):
        if not self._pending_user_search_jobs or self._pending_user_search_timer_id is not None:
            return

        self._pending_user_search_timer_id = events.schedule(delay=0, callback=self._process_pending_user_searches)

        if self._pending_user_search_timer_id is None:
            # Scheduler work is saturated; drop the remaining targeted-search
            # fanout rather than retaining stale iterators indefinitely.
            self._pending_user_search_jobs.clear()

    def _queue_user_searches(self, text, users):
        text = self._normalize_outgoing_search_term(text)
        users = self._normalize_search_users(users)

        if not text or not users:
            return False

        if len(self._pending_user_search_jobs) >= self.MAX_PENDING_USER_SEARCH_JOBS:
            if not self._pending_user_search_limit_logged:
                log.add_debug(
                    "Pending targeted-search queue reached %s jobs; discarding additional user search fanout",
                    self.MAX_PENDING_USER_SEARCH_JOBS
                )
                self._pending_user_search_limit_logged = True

            return False

        self._pending_user_search_jobs.append([self.token, text, iter(users), 0])
        self._process_pending_user_searches()
        return True

    def _process_pending_user_searches(self):
        self._pending_user_search_timer_id = None
        num_sent = 0

        while (self._pending_user_search_jobs
                and num_sent < self.MAX_USER_SEARCH_MESSAGES_PER_TICK):
            token, text, usernames, num_sent_for_job = self._pending_user_search_jobs[0]
            search = self.searches.get(token)
            login_username = core.users.login_username if core.users is not None else None

            if search is None or search.is_ignored:
                self._pending_user_search_jobs.popleft()
                continue

            while (num_sent < self.MAX_USER_SEARCH_MESSAGES_PER_TICK
                    and num_sent_for_job < self.MAX_USER_SEARCH_MESSAGES_PER_JOB):
                try:
                    username = next(usernames)
                except StopIteration:
                    self._pending_user_search_jobs.popleft()
                    break

                num_sent_for_job += 1
                self._pending_user_search_jobs[0][3] = num_sent_for_job

                accepted = core.send_message_to_server(UserSearch(username, token, text))

                if accepted is False:
                    if not self._pending_user_search_limit_logged:
                        log.add_debug(
                            "Discarding targeted search request for %s; network queue rejected it", username)
                        self._pending_user_search_limit_logged = True

                    # Treat local queue rejection as processed for this batch so a
                    # full network queue cannot cause a retry storm over the same
                    # recipient list.
                    num_sent += 1
                    continue

                self.add_allowed_token(token)

                if username == login_username:
                    self._own_tokens.add(token)

                num_sent += 1

            else:
                if num_sent_for_job >= self.MAX_USER_SEARCH_MESSAGES_PER_JOB:
                    if not self._pending_user_search_limit_logged:
                        log.add_debug(
                            "Targeted search token %s reached the per-search user fanout limit; "
                            "discarding remaining users", token
                        )
                        self._pending_user_search_limit_logged = True

                    self._pending_user_search_jobs.popleft()
                    continue

                # Current job still has users left and this tick's budget is exhausted.
                break

        if self._pending_user_search_jobs:
            self._schedule_pending_user_searches()
        else:
            self._pending_user_search_limit_logged = False

    def request_folder_download(self, username, folder_path, visible_files, download_folder_path=None):

        # Ask for the rest of the files in the folder
        core.downloads.enqueue_folder(username, folder_path, download_folder_path=download_folder_path)

        # Queue visible search results in bounded batches. A peer can return
        # thousands of visible files for one folder in a search response;
        # enqueueing them synchronously from the GUI/network callback can turn
        # one folder action into a long UI and transfer-state burst.
        destination_folder_path = core.downloads.get_folder_destination(username, folder_path)
        self._queue_visible_folder_downloads(username, destination_folder_path, visible_files)

    # Outgoing Search Requests #

    def _log_wishlist_limit(self):
        if self._wishlist_limit_logged:
            return

        log.add_debug(
            "Wishlist search limit of %s reached; ignoring additional configured wishlist items",
            self.MAX_WISHLIST_SEARCHES
        )
        self._wishlist_limit_logged = True

    @classmethod
    def _normalize_outgoing_search_term(cls, search_term):
        """Normalize/cap locally retained outgoing search text.

        Protocol packers truncate the transmitted search field, but SearchRequest
        objects, history, wishlist state and plugin feedback retain the pre-packed
        string. A corrupt config entry or plugin can therefore allocate and keep a
        much larger term than the protocol can ever send. Keep the local model at
        the same gross byte boundary as the wire field.
        """

        if search_term is None:
            return ""

        if not isinstance(search_term, str):
            search_term = str(search_term)

        search_term = FileSearch.truncate_string_bytes(
            search_term.strip(), cls.MAX_OUTGOING_SEARCH_TERM_BYTES)
        return search_term.strip()

    @classmethod
    def _normalize_search_room(cls, room):
        if room is None:
            return None

        if not isinstance(room, str):
            room = str(room)

        room = RoomSearch.truncate_string_bytes(room.strip(), cls.MAX_OUTGOING_ROOM_SEARCH_ROOM_BYTES)
        return room or None

    @classmethod
    def _normalize_search_users(cls, users):
        """Return a bounded tuple of unique target usernames.

        Targeted/user search feedback can come from plugins or restored local
        state. The send path is batched, but SearchRequest previously retained the
        full user iterable/list before batching. Bound and deduplicate it before
        storing or queueing work.
        """

        if users is None:
            return ()

        if isinstance(users, str):
            iterator = iter((users,))
        else:
            try:
                iterator = iter(users)
            except TypeError:
                iterator = iter((users,))

        normalized_users = []
        seen_users = set()

        for username in iterator:
            if len(normalized_users) >= cls.MAX_STORED_USER_SEARCH_USERS:
                break

            if username is None:
                continue

            if not isinstance(username, str):
                username = str(username)

            username = UserSearch.truncate_string_bytes(
                username.strip(), UserSearch.MAX_USERNAME_FIELD_BYTES)

            if not username or username in seen_users:
                continue

            seen_users.add(username)
            normalized_users.append(username)

        return tuple(normalized_users)

    @classmethod
    def _normalize_wishlist_term(cls, search_term):
        search_term = cls._normalize_outgoing_search_term(search_term)
        return search_term or None

    def _register_wishlist_term(self, search_term):
        search_term = self._normalize_wishlist_term(search_term)

        if search_term is None:
            return False

        if search_term in self._wishlist_terms:
            return False

        if len(self._wishlist_terms) >= self.MAX_WISHLIST_SEARCHES:
            self._log_wishlist_limit()
            return False

        self._wishlist_terms.add(search_term)
        return True

    def _register_wishlist_search(self, search):
        if search.mode != "wishlist":
            return

        if search.term not in self._wishlist_terms:
            if not self._register_wishlist_term(search.term):
                return

        self._wishlist_tokens_by_term[search.term] = search.token

    def _unregister_wishlist_search(self, token, term=None):
        if term is None:
            search = self.searches.get(token)
            term = search.term if search is not None else None

        if term is not None and self._wishlist_tokens_by_term.get(term) == token:
            self._wishlist_tokens_by_term.pop(term, None)

    def _get_wishlist_search(self, term):
        token = self._wishlist_tokens_by_term.get(term)
        search = self.searches.get(token) if token is not None else None

        if search is not None and search.mode == "wishlist" and search.term == term:
            return search

        # Configuration or restored state may have been edited externally. Fall
        # back once, repair the index, and keep future intervals O(1).
        for search in self.searches.values():
            if search.mode == "wishlist" and search.term == term:
                self._wishlist_tokens_by_term[term] = search.token
                return search

        return None

    @staticmethod
    def add_allowed_token(token):
        """Allow parsing search result messages for a search ID."""
        if token not in SEARCH_TOKENS_ALLOWED:
            clear_search_response_users(token)

        SEARCH_TOKENS_ALLOWED.add(token)

    @staticmethod
    def remove_allowed_token(token):
        """Disallow parsing search result messages for a search ID."""
        SEARCH_TOKENS_ALLOWED.discard(token)
        clear_search_response_users(token)

    def add_search(self, search_term, mode, room=None, users=None, is_ignored=False, allow_response=True):

        search_term = self._normalize_outgoing_search_term(search_term)
        room = self._normalize_search_room(room)
        users = self._normalize_search_users(users) if mode == "user" else users

        term_sanitized, term_transmitted, included_words, excluded_words = self.sanitize_search_term(search_term)

        self.searches[self.token] = search = SearchRequest(
            token=self.token, term=search_term, term_sanitized=term_sanitized, term_transmitted=term_transmitted,
            included_words=included_words, excluded_words=excluded_words, mode=mode, room=room, users=users,
            is_ignored=is_ignored
        )

        if mode == "wishlist":
            self._register_wishlist_search(search)

        if allow_response and not is_ignored:
            self.add_allowed_token(self.token)

        return search

    def _discard_unemitted_search(self, token):
        """Discard a SearchRequest that was never exposed to the UI.

        Outbound search requests can be rejected locally by the bounded network
        queue. In that case, do not leave a response token, wishlist index entry
        or retained search object behind for a request that was never accepted
        for sending.
        """

        self.remove_allowed_token(token)
        search = self.searches.get(token)

        if search is None:
            return

        self._unregister_wishlist_search(token, search.term)
        del self.searches[token]
        self._own_tokens.discard(token)

    def remove_search(self, token):

        self.remove_allowed_token(token)
        search = self.searches.get(token)

        if search is None:
            return

        if search.mode == "wishlist" and search.term in self._wishlist_terms:
            search.is_ignored = True
        else:
            self._unregister_wishlist_search(token, search.term)
            del self.searches[token]

        events.emit("remove-search", token)

    def remove_all_searches(self):
        for token in self.searches.copy():
            self.remove_search(token)

    def show_search(self, token):
        events.emit("show-search", token)

    def sanitize_search_term(self, search_term):

        included_words = []
        excluded_words = []
        search_term = search_term_transmitted = search_term.strip()

        try:
            lex = shlex(search_term)
            lex.quotes = '"'
            lex.whitespace_split = True
            lex.commenters = ""

            search_term_words = list(lex)

        except ValueError:
            search_term_words = search_term.split()

        # Remove certain special characters from search term
        # SoulseekQt doesn't seem to send search results if such characters are included (July 7, 2020)
        search_term_words_transmitted = []

        excluded_char = "-"
        partial_char = "*"
        quotation_char = '"'

        for index, word in enumerate(search_term_words):
            if not word:
                continue

            first_char = word[0]

            if first_char == partial_char and len(word) > 1:
                # Partial word (*erm)
                included_words.append(word[1:].lower())

            elif first_char == excluded_char and len(word) > 1:
                # Excluded word (-word)
                excluded_words.append(word[1:].lower())

            elif first_char == quotation_char and word[-1] == quotation_char and len(word) > 2:
                # Phrase "some words here"
                word = word[1:-1]
                included_words.append(word.lower())

                # Remove problematic characters before appending to outgoing search term
                for inner_word in word.translate(self.TRANSLATE_REMOVED_SEARCH_CHARACTERS).strip().split():
                    search_term_words_transmitted.append(inner_word)

                continue

            else:
                # Remove problematic characters before appending to outgoing search term
                subwords = word.translate(self.TRANSLATE_REMOVED_SEARCH_CHARACTERS).strip().split()
                word = search_term_words[index] = " ".join(x for x in subwords if x)

                if not subwords:
                    continue

                for subword in word.translate(TRANSLATE_PUNCTUATION).strip().split():
                    included_words.append(subword.lower())

            search_term_words_transmitted.append(word)

        sanitized_search_term_transmitted = " ".join(x for x in search_term_words_transmitted).strip()

        # Only modify search term if string also contains non-special characters
        if sanitized_search_term_transmitted:
            search_term = " ".join(x for x in search_term_words if x).strip()
            search_term_transmitted = sanitized_search_term_transmitted

        return search_term, search_term_transmitted, included_words, excluded_words

    def process_search_term(self, search_term, mode, room=None, users=None):

        search_term = self._normalize_outgoing_search_term(search_term)
        room = self._normalize_search_room(room)
        users = self._normalize_search_users(users) if mode == "user" else users

        if mode == "global":
            feedback = core.pluginhandler.outgoing_global_search_event(search_term)

            if feedback is not None:
                search_term = feedback[0]

        elif mode == "rooms":
            if not room:
                room = next(iter(config.sections["server"]["autojoin"]), None)

            feedback = core.pluginhandler.outgoing_room_search_event(room, search_term)

            if feedback is not None:
                room, search_term = feedback

        elif mode == "buddies":
            feedback = core.pluginhandler.outgoing_buddy_search_event(search_term)

            if feedback is not None:
                search_term = feedback[0]

        elif mode == "user":
            if not users:
                users = [core.users.login_username]

            feedback = core.pluginhandler.outgoing_user_search_event(users, search_term)

            if feedback is not None:
                users, search_term = feedback

        elif mode == "wishlist":
            feedback = core.pluginhandler.outgoing_wishlist_search_event(search_term)

            if feedback is not None:
                search_term = feedback[0]

        else:
            log.add("Unknown search mode, not using plugin system. Fix me!")

        search_term = self._normalize_outgoing_search_term(search_term)
        room = self._normalize_search_room(room) if mode == "rooms" else room
        users = self._normalize_search_users(users) if mode == "user" else users

        return search_term, room, users

    def do_search(self, search_term, mode, room=None, users=None, switch_page=True):

        # Validate search term and run it through plugins
        search_term, room, users = self.process_search_term(search_term, mode, room, users)

        if not search_term or (mode == "rooms" and not room):
            return

        # Get a new search token. Do not allow heavy peer responses until the
        # corresponding outbound request has actually been accepted by the
        # bounded network queue; otherwise a local backpressure drop can leave a
        # stale accepted response token and retained SearchRequest behind.
        self.token = increment_token(self.token)
        search = self.add_search(search_term, mode, room, users, allow_response=False)

        if mode == "global":
            request_accepted = self.do_global_search(search.term_transmitted)

        elif mode == "rooms":
            request_accepted = self.do_rooms_search(search.term_transmitted, room)

        elif mode == "buddies":
            request_accepted = self.do_buddies_search(search.term_transmitted)

        elif mode == "user":
            request_accepted = self.do_peer_search(search.term_transmitted, users)

        else:
            request_accepted = False

        if not request_accepted:
            self._discard_unemitted_search(search.token)
            return

        if mode in {"global", "rooms"}:
            self.add_allowed_token(search.token)

        if config.sections["searches"]["enable_history"]:
            items = config.sections["searches"]["history"]

            if search.term_sanitized in items:
                items.remove(search.term_sanitized)

            items.insert(0, search.term_sanitized)

            # Clear old items
            del items[self.SEARCH_HISTORY_LIMIT:]
            config.write_configuration()

        events.emit("add-search", search.token, search, switch_page)

    def do_global_search(self, text):
        accepted = core.send_message_to_server(FileSearch(self.token, text))

        # Request a list of related searches from the server.
        # Seemingly non-functional since 2018 (always receiving empty lists).

        # core.send_message_to_server(RelatedSearch(text))
        return accepted is not False

    def do_rooms_search(self, text, room):
        accepted = core.send_message_to_server(RoomSearch(room, self.token, text))
        return accepted is not False

    def do_buddies_search(self, text):
        return self._queue_user_searches(text, core.buddies.users)

    def do_peer_search(self, text, users):
        return self._queue_user_searches(text, users)

    def do_wishlist_search(self, token, text):

        search = self.searches.get(token)

        text, _room, _users = self.process_search_term(text, mode="wishlist")

        if not text:
            return

        if core.send_message_to_server(WishlistSearch(token, text)) is False:
            log.add_debug("Discarding wishlist search for %s; network queue rejected it", text)
            return

        if search is not None:
            # Wishlist tokens are reused at each server-provided interval. A
            # previously exhausted response-user set belongs to the old
            # interval and must not suppress the next scheduled wishlist run.
            search.responded_users.clear()
            clear_search_response_users(token)

        log.add_search(_('Searching for wishlist item "%s"'), text)
        self.add_allowed_token(token)

    def do_wishlist_search_interval(self):

        searches = config.sections["server"]["autosearch"]

        if not searches:
            return

        # Search for a maximum of 1 item at each search interval
        term = searches.pop()
        searches.insert(0, term)

        term = self._normalize_wishlist_term(term)

        if not term:
            return

        search = self._get_wishlist_search(term)

        if search is None:
            return

        search.is_ignored = False
        self.do_wishlist_search(search.token, search.term_transmitted)

    def add_wish(self, wish):

        wish = self._normalize_wishlist_term(wish)

        if not wish:
            return

        is_new_term = wish not in self._wishlist_terms

        if is_new_term and not self._register_wishlist_term(wish):
            return

        if wish not in config.sections["server"]["autosearch"]:
            config.sections["server"]["autosearch"].append(wish)
            config.write_configuration()

        if self._get_wishlist_search(wish) is None:
            # Get a new search token
            self.token = increment_token(self.token)
            self.add_search(wish, mode="wishlist", is_ignored=True)

        events.emit("add-wish", wish)

    def remove_wish(self, wish):

        if wish not in self._wishlist_terms:
            return

        self._wishlist_terms.discard(wish)

        if wish in config.sections["server"]["autosearch"]:
            config.sections["server"]["autosearch"].remove(wish)
            config.write_configuration()

        search = self._get_wishlist_search(wish)

        if search is not None:
            self._unregister_wishlist_search(search.token, wish)

            if search.is_ignored:
                del self.searches[search.token]

        events.emit("remove-wish", wish)

    def is_wish(self, wish):
        return wish in self._wishlist_terms

    def _set_wishlist_interval(self, msg):
        """Server code 104."""

        events.cancel_scheduled(self._wishlist_timer_id)
        self._wishlist_timer_id = None

        interval = msg.seconds

        if interval <= 0:
            self.wishlist_interval = 0
            return

        if interval < self.MIN_WISHLIST_INTERVAL:
            interval = self.MIN_WISHLIST_INTERVAL
        elif interval > self.MAX_WISHLIST_INTERVAL:
            interval = self.MAX_WISHLIST_INTERVAL

        self.wishlist_interval = interval
        log.add_search(_("Wishlist wait period set to %s seconds"), self.wishlist_interval)

        self._wishlist_timer_id = events.schedule(
            delay=self.wishlist_interval, callback=self.do_wishlist_search_interval, repeat=True)

    def _excluded_search_phrases(self, msg):
        """Server code 160."""

        phrases = []
        phrase_index = {}

        for phrase in msg.phrases[:self.MAX_EXCLUDED_SEARCH_PHRASES]:
            if not isinstance(phrase, str):
                continue

            phrase = phrase.lower()

            if not phrase:
                continue

            phrases.append(phrase)
            phrase_index.setdefault(phrase[0], []).append(phrase)

        if self.excluded_phrases and self.excluded_phrases != msg.phrases:
            log.add_search("Previous list of excluded search phrases: %s", self._format_phrase_summary(
                self.excluded_phrases))

        self.excluded_phrases = phrases
        self._excluded_phrase_index = {key: tuple(value) for key, value in phrase_index.items()}

        log.add_search("Server provided %(num_phrases)s excluded search phrase(s), storing %(num_stored)s: "
                       "%(phrases)s", {
            "num_phrases": len(msg.phrases),
            "num_stored": len(phrases),
            "phrases": self._format_phrase_summary(phrases)
        })

    @classmethod
    def _format_phrase_summary(cls, phrases):
        """Return a bounded phrase-list summary for logs.

        Excluded search phrases are applied to every result in every outgoing
        search response. A server-sent phrase list that is grossly larger than
        normal should not also create huge log lines when it is received.
        """

        sample = phrases[:cls.MAX_LOGGED_EXCLUDED_SEARCH_PHRASES]
        num_omitted = len(phrases) - len(sample)

        if num_omitted <= 0:
            return repr(sample)

        return f"{sample!r} ... <omitted {num_omitted} phrase(s)>"

    def _find_excluded_phrase(self, file_path_lower):
        """Return a matching server-excluded phrase, if any.

        Server-provided excluded phrases are checked for every outgoing search
        result candidate. Index phrases by first character so large phrase lists
        avoid repeatedly scanning phrases that cannot be present in the path.
        """

        if not self._excluded_phrase_index:
            # Preserve compatibility with tests/legacy code assigning
            # excluded_phrases directly instead of going through the server
            # message handler that builds the index.
            return next((phrase for phrase in self.excluded_phrases if phrase in file_path_lower), None)

        for first_char in set(file_path_lower):
            for phrase in self._excluded_phrase_index.get(first_char, ()):  # pragma: no branch - tiny tuple normally
                if phrase in file_path_lower:
                    return phrase

        return None

    @classmethod
    def _get_search_result_candidate_scan_limit(cls, max_results):
        """Return a bounded raw-candidate scan window for accepted search results."""

        if max_results <= 0:
            return 0

        scaled_limit = max_results * cls.MAX_SEARCH_RESULT_CANDIDATE_SCAN_MULTIPLIER

        if cls.MAX_SEARCH_RESULT_CANDIDATE_SCAN > 0:
            scaled_limit = min(scaled_limit, cls.MAX_SEARCH_RESULT_CANDIDATE_SCAN)

        return max(max_results, scaled_limit)

    def _file_search_response(self, msg):
        """Peer code 9."""

        if msg.token not in SEARCH_TOKENS_ALLOWED:
            msg.token = None
            return

        search = self.searches.get(msg.token)

        if search is None or search.is_ignored:
            msg.token = None
            return

        username = msg.username
        ip_address, _port = msg.addr

        if core.network_filter.is_user_ignored(username):
            msg.token = None
            return

        if core.network_filter.is_user_ip_ignored(username, ip_address):
            msg.token = None
            return

        responded_users = search.responded_users

        if username in responded_users:
            msg.token = None
            return

        if len(responded_users) >= self.MAX_SEARCH_RESPONSE_USERS:
            self.remove_allowed_token(msg.token)
            msg.token = None
            log.add_debug(
                "Search response user limit of %s reached for token %s, ignoring additional responses",
                (self.MAX_SEARCH_RESPONSE_USERS, search.token)
            )
            return

        responded_users.add(username)

    def _forget_old_search_requests(self, now):
        cutoff_time = now - self.SEARCH_REQUEST_RETENTION

        while self._processed_search_request_order:
            key, timestamp = self._processed_search_request_order[0]

            if timestamp > cutoff_time and self._processed_search_requests.get(key) == timestamp:
                break

            self._processed_search_request_order.popleft()

            if self._processed_search_requests.get(key) == timestamp:
                del self._processed_search_requests[key]

    def _remember_search_request(self, username, token):
        """Reject duplicate incoming searches before share/plugin fanout."""

        if token is None:
            return True

        key = (username, token)
        now = time.monotonic()

        if key in self._processed_search_requests:
            return False

        self._forget_old_search_requests(now)

        if len(self._processed_search_requests) >= self.MAX_PROCESSED_SEARCH_REQUESTS:
            if not self._processed_search_request_limit_logged:
                log.add_search("Incoming search request dedupe table limit of %s reached, ignoring new search requests",
                               self.MAX_PROCESSED_SEARCH_REQUESTS)
                self._processed_search_request_limit_logged = True
            return False

        self._processed_search_requests[key] = now
        self._processed_search_request_order.append((key, now))
        return True

    def _forget_search_request(self, username, token):
        """Roll back a remembered request if its response was never accepted."""

        if token is None:
            return

        self._processed_search_requests.pop((username, token), None)

    def _handle_file_search_request(self, msg, notification_callback):
        if not self._remember_search_request(msg.search_username, msg.token):
            return

        result = self._process_search_request(msg.searchterm, msg.search_username, msg.token)

        if result is False:
            # The request reached the expensive response path, but the response
            # did not enter the bounded network queue. Do not poison the replay
            # ledger or notify plugins for work that we failed to queue; a later
            # retry with the same token can be processed after backpressure clears.
            self._forget_search_request(msg.search_username, msg.token)
            return

        notification_callback(msg.searchterm, msg.search_username, msg.token)

    def _file_search_request_server(self, msg):
        """Server code 26."""

        self._handle_file_search_request(msg, core.pluginhandler.search_request_notification)

    def _file_search_request_distributed(self, msg):
        """Distrib code 3."""

        self._handle_file_search_request(msg, core.pluginhandler.distrib_search_notification)

    # Incoming Search Requests #

    def _append_file_info(self, file_list, fileinfo, excluded_log_state=None):

        file_path, *_unused = fileinfo
        file_path_lower = file_path.lower()
        excluded_phrase = self._find_excluded_phrase(file_path_lower)

        # Check if file path contains phrase excluded from the search network.
        # A common search can match many excluded files; cap per-file logging so
        # the responder does not spend the whole request formatting log lines.
        if excluded_phrase:
            if excluded_log_state is not None:
                logged = excluded_log_state["logged"]

                if logged < self.MAX_EXCLUDED_SEARCH_RESULT_LOGS_PER_REQUEST:
                    excluded_log_state["logged"] = logged + 1
                    log.add_search(('Excluding file %(file)s from search response because server '
                                    'disallowed phrase "%(phrase)s"'), {
                        "file": file_path,
                        "phrase": excluded_phrase
                    })

                elif not excluded_log_state["suppressed"]:
                    excluded_log_state["suppressed"] = True
                    log.add_search(
                        "Suppressing additional per-file excluded-search-response logs for this request")

            return False

        file_list.append(fileinfo)
        return True

    def _create_file_info_list(self, results, max_results, permission_level):
        """Given a list of file indices, retrieve the file information for each index."""

        reveal_buddy_shares = config.sections["transfers"]["reveal_buddy_shares"]
        reveal_trusted_shares = config.sections["transfers"]["reveal_trusted_shares"]
        is_buddy = (permission_level == PermissionLevel.BUDDY)
        is_trusted = (permission_level == PermissionLevel.TRUSTED)

        fileinfos = []
        private_fileinfos = []
        num_fileinfos = 0

        public_files = core.shares.share_dbs["public_files"]
        buddy_files = core.shares.share_dbs["buddy_files"]
        trusted_files = core.shares.share_dbs["trusted_files"]

        candidate_scan_limit = min(len(results), self._get_search_result_candidate_scan_limit(max_results))
        excluded_log_state = {"logged": 0, "suppressed": False}

        for index in islice(results, candidate_scan_limit):
            try:
                file_path = core.shares.file_path_index[index]

            except IndexError:
                continue

            accepted = False

            if file_path in public_files:
                accepted = self._append_file_info(fileinfos, public_files[file_path], excluded_log_state)

            elif (is_buddy or reveal_buddy_shares) and file_path in buddy_files:
                fileinfo = buddy_files[file_path]

                if is_buddy:
                    accepted = self._append_file_info(fileinfos, fileinfo, excluded_log_state)
                else:
                    accepted = self._append_file_info(private_fileinfos, fileinfo, excluded_log_state)

            elif (is_trusted or reveal_trusted_shares) and file_path in trusted_files:
                fileinfo = trusted_files[file_path]

                if is_trusted:
                    accepted = self._append_file_info(fileinfos, fileinfo, excluded_log_state)
                else:
                    accepted = self._append_file_info(private_fileinfos, fileinfo, excluded_log_state)

            if accepted:
                num_fileinfos += 1

                if num_fileinfos >= max_results:
                    break

        results.clear()

        if fileinfos:
            fileinfos.sort(key=itemgetter(0))

        if private_fileinfos:
            private_fileinfos.sort(key=itemgetter(0))

        return num_fileinfos, fileinfos, private_fileinfos

    @staticmethod
    def _update_search_results(results, word_indices, excluded=False):
        """Updates the search result list with indices for a new word."""

        if not word_indices:
            if excluded:
                # We don't care if an excluded word doesn't exist in our DB
                return results

            # Included word does not exist in our DB, no results
            return set()

        if results is None:
            if excluded:
                # No results yet, but word is excluded. Bail.
                return set()

            # First match for included word, return results
            return set(word_indices)

        if excluded:
            # Remove results for excluded word
            results.difference_update(word_indices)
        else:
            # Only retain common results for all words so far
            results.intersection_update(word_indices)

        return results

    @staticmethod
    def _file_path_matches_partial_word(file_path, partial_word):
        partial_word_len = len(partial_word)
        file_path_words = file_path.lower().translate(TRANSLATE_PUNCTUATION).split()

        return any(
            len(file_path_word) >= partial_word_len and file_path_word.endswith(partial_word)
            for file_path_word in file_path_words
        )

    def _create_search_result_list(self, included_words, excluded_words, partial_words, max_results, word_index):
        """Returns a list of common file indices for each word in a search
        term."""

        results = None

        for word in included_words:
            if word not in word_index:
                # No results
                return results

        start_word = min(included_words, key=lambda word: len(word_index[word]), default=None)
        has_single_word = (sum(len(words) for words in (included_words, excluded_words, partial_words)) == 1)
        included_words.discard(start_word)

        # Included search words (e.g. hello). Process exact terms before partial terms,
        # so a rare exact match can constrain expensive partial suffix scans.
        if start_word:
            start_results = word_index[start_word]

            if has_single_word:
                # Attempt to avoid large memory usage if someone searches for e.g. "flac".
                # Keep enough raw candidates to survive later permission/exclusion
                # filtering, while still bounding gross responder work.
                start_results = start_results[:self._get_search_result_candidate_scan_limit(max_results)]

            results = self._update_search_results(results, start_results)

            for included_word in included_words:
                results = self._update_search_results(results, word_index[included_word])

            if not results:
                return None

        # Partial search words (e.g. *ello)
        for partial_word in partial_words:
            if results is not None:
                file_path_index = core.shares.file_path_index
                public_files = core.shares.share_dbs.get("public_files")
                buddy_files = core.shares.share_dbs.get("buddy_files")
                trusted_files = core.shares.share_dbs.get("trusted_files")

                if file_path_index and all(db is not None for db in (public_files, buddy_files, trusted_files)):
                    matched_results = set()

                    for file_index in results:
                        try:
                            file_path = file_path_index[file_index]

                        except IndexError:
                            continue

                        fileinfo = public_files.get(file_path)

                        if fileinfo is None:
                            fileinfo = buddy_files.get(file_path)

                        if fileinfo is None:
                            fileinfo = trusted_files.get(file_path)

                        if fileinfo is None:
                            continue

                        if self._file_path_matches_partial_word(fileinfo[0], partial_word):
                            matched_results.add(file_index)

                    results = matched_results

                    if not results:
                        return None

                    continue

            partial_word_len = len(partial_word)
            partial_results = set()
            num_partial_results = 0

            for num_scanned_words, complete_word in enumerate(word_index, start=1):
                if num_scanned_words > self.MAX_PARTIAL_WORD_INDEX_SCAN:
                    if not self._partial_word_scan_limit_logged:
                        log.add_search(
                            "Partial search word-index scan limit of %s reached, ignoring remaining words",
                            self.MAX_PARTIAL_WORD_INDEX_SCAN
                        )
                        self._partial_word_scan_limit_logged = True
                    break

                if len(complete_word) < partial_word_len or not complete_word.endswith(partial_word):
                    continue

                indices = word_index[complete_word]

                if results is not None:
                    partial_results.update(index for index in indices if index in results)

                    if len(partial_results) >= len(results):
                        break

                    continue

                if has_single_word:
                    # Attempt to avoid large memory usage if someone searches for e.g. "*lac".
                    # Keep enough raw candidates to survive later permission/exclusion
                    # filtering, while still bounding gross responder work.
                    candidate_limit = self._get_search_result_candidate_scan_limit(max_results)
                    indices = indices[:candidate_limit - num_partial_results]

                partial_results.update(indices)

                if not has_single_word:
                    continue

                num_partial_results = len(partial_results)

                if num_partial_results >= self._get_search_result_candidate_scan_limit(max_results):
                    break

            if not partial_results:
                return None

            results = self._update_search_results(results, partial_results)

        # Excluded search words (e.g. -hello)
        if results:
            for excluded_word in excluded_words:
                if excluded_word not in word_index:
                    continue

                results = self._update_search_results(results, word_index[excluded_word], excluded=True)

        if not results:
            return None

        return results

    @classmethod
    def _parse_incoming_search_words(cls, search_term):
        """Extract searchable word sets without accepting token storms.

        Incoming search messages can fit within a byte-sized protocol cap while
        still containing thousands of tiny words. Splitting and intersecting all
        of them for each remote request can dominate the search responder.
        """

        words = tuple(islice(search_term.split(), cls.MAX_INCOMING_SEARCH_REQUEST_WORDS + 1))

        if len(words) > cls.MAX_INCOMING_SEARCH_REQUEST_WORDS:
            return None

        included_words = set()
        excluded_words = set()
        partial_words = set()
        excluded_char = "-"
        partial_char = "*"

        for word in words:
            if not word:
                continue

            first_char = word[0]

            if first_char == excluded_char:
                target_words = excluded_words
            elif first_char == partial_char:
                target_words = partial_words
            else:
                target_words = included_words

            target_words.update(word.translate(TRANSLATE_PUNCTUATION).split())

        included_words.difference_update(excluded_words, partial_words)
        return included_words, excluded_words, partial_words

    def _process_search_request(self, search_term, username, token):
        """This section is accessed every time a search request arrives,
        several times per second.

        Please keep it as optimized and memory sparse as possible!
        """

        if not search_term:
            return

        if not config.sections["searches"]["search_results"]:
            # Don't return _any_ results when this option is disabled
            return

        if core.uploads.pending_shutdown:
            # Don't return results when waiting to quit after finishing uploads
            return

        local_username = core.users.login_username

        is_own_search = False

        if username == local_username:
            if token not in self._own_tokens:
                # We shouldn't send a search response if we initiated the search
                # request, unless we're specifically searching our own username
                return

            self._own_tokens.discard(token)
            is_own_search = True

        max_results = min(
            config.sections["searches"]["maxresults"],
            FileSearchResponse.MAX_RESULT_FILES
        )

        if max_results <= 0:
            return

        if len(search_term) < config.sections["searches"]["min_search_chars"]:
            # Don't send search response if search term contains too few characters
            return

        permission_level, _reject_reason = core.shares.check_user_permission(username)

        if permission_level == PermissionLevel.BANNED:
            return

        if "words" not in core.shares.share_dbs:
            return

        word_index = core.shares.share_dbs["words"]
        original_search_term = search_term
        search_term = search_term.lower()

        parsed_words = self._parse_incoming_search_words(search_term)

        if parsed_words is None:
            return

        included_words, excluded_words, partial_words = parsed_words

        # Find common file matches for each word in search term
        results = self._create_search_result_list(
            included_words, excluded_words, partial_words, max_results, word_index)

        if not results:
            return

        # Get file information for each file index in result list
        num_results, fileinfos, private_fileinfos = self._create_file_info_list(
            results, max_results, permission_level)

        if not num_results:
            return

        response = FileSearchResponse(
            search_username=local_username,
            token=token,
            shares=fileinfos,
            freeulslots=core.uploads.is_new_upload_accepted(),
            ulspeed=core.uploads.upload_speed,
            inqueue=core.uploads.get_upload_queue_size(username),
            private_shares=private_fileinfos
        )
        response.unsent_rollback_info = ("file-search-response", username, token, is_own_search)

        if core.send_message_to_peer(username, response) is False:
            if is_own_search:
                self._own_tokens.add(token)

            log.add_search(
                'Discarding search response to %(user)s for "%(query)s"; network queue rejected it',
                {"user": username, "query": original_search_term}
            )
            return False

        log.add_search(_('User %(user)s is searching for "%(query)s", found %(num)i results'), {
            "user": username,
            "query": original_search_term,
            "num": num_results
        })
        return True
