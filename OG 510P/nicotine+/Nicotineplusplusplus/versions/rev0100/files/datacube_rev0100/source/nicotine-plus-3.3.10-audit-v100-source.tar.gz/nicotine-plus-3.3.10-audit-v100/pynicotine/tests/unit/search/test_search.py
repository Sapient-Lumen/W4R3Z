# COPYRIGHT (C) 2021-2025 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import shutil

from collections import deque
from collections import UserDict
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import patch

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.search import Search
from pynicotine.search import SearchRequest
from pynicotine.shares import PermissionLevel
from pynicotine.slskmessages import ExcludedSearchPhrases
from pynicotine.slskmessages import FileSearch
from pynicotine.slskmessages import FileSearchResponse
from pynicotine.slskmessages import UserSearch
from pynicotine.slskmessages import WishlistSearch
from pynicotine.slskmessages import SEARCH_TOKENS_ALLOWED
from pynicotine.slskmessages import SEARCH_RESPONSE_USERS_ACCEPTED
from pynicotine.slskmessages import consume_search_response_user
from pynicotine.slskmessages import increment_token

DATA_FOLDER_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), "temp_data")
SEARCH_TEXT = '70 - * Gwen "test" "" -mp3 "what\'s up" don\'t -nothanks a:::b;c+d +++---}[ *ello [[ @@ auto -No yes'
SEARCH_MODE = "global"


class SearchTest(TestCase):

    # pylint: disable=protected-access

    def setUp(self):

        config.set_data_folder(DATA_FOLDER_PATH)
        config.set_config_file(os.path.join(DATA_FOLDER_PATH, "temp_config"))

        core.init_components(enabled_components={"pluginhandler", "search", "shares", "network_filter"})
        self._dummy_network_queue = lambda _message: True
        events.connect("queue-network-message", self._dummy_network_queue)

    def tearDown(self):
        try:
            events.disconnect("queue-network-message", self._dummy_network_queue)
        except (AttributeError, ValueError):
            pass

        core.quit()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(DATA_FOLDER_PATH)

    def test_server_message_unsent_removes_search_after_last_grant(self):
        token = core.search.token
        core.search.add_search("term", mode="global", allow_response=False)
        core.search.add_allowed_token(token)

        SEARCH_TOKENS_ALLOWED.release(token)
        events.emit("server-message-unsent", FileSearch(token, "term"))

        self.assertNotIn(token, core.search.searches)
        self.assertNotIn(token, SEARCH_TOKENS_ALLOWED)

    def test_server_message_unsent_keeps_targeted_search_until_last_grant(self):
        token = core.search.token
        core.search.add_search("term", mode="user", users=["a", "b"], allow_response=False)
        core.search.add_allowed_token(token)
        core.search.add_allowed_token(token)

        SEARCH_TOKENS_ALLOWED.release(token)
        events.emit("server-message-unsent", UserSearch("a", token, "term"))

        self.assertIn(token, core.search.searches)

        SEARCH_TOKENS_ALLOWED.release(token)
        events.emit("server-message-unsent", UserSearch("b", token, "term"))

        self.assertNotIn(token, core.search.searches)


    def test_peer_response_delivery_failed_releases_parser_responder(self):
        token = core.search.token
        core.search.add_search("term", mode="global", allow_response=False)
        core.search.add_allowed_token(token)
        self.assertTrue(consume_search_response_user(token, "peer"))
        self.assertFalse(consume_search_response_user(token, "peer"))

        core.search._peer_response_delivery_failed(
            FileSearchResponse, "peer", ("file-search-response", token, "peer"))

        self.assertTrue(consume_search_response_user(token, "peer"))

    def test_peer_response_delivery_failed_clears_local_responder_if_present(self):
        token = core.search.token
        core.search.add_search("term", mode="global", allow_response=False)
        search = core.search.searches[token]
        search.responded_users.add("peer")
        SEARCH_RESPONSE_USERS_ACCEPTED[token] = {"peer"}

        core.search._peer_response_delivery_failed(
            FileSearchResponse, "peer", ("file-search-response", token, "peer"))

        self.assertNotIn("peer", search.responded_users)
        self.assertNotIn(token, SEARCH_RESPONSE_USERS_ACCEPTED)

    def test_peer_response_unsent_forgets_incoming_search_request(self):
        token = 4242
        self.assertTrue(core.search._remember_search_request("peer", token))

        core.search._peer_response_unsent(
            FileSearchResponse, "peer", ("file-search-response", "peer", token, False))

        self.assertTrue(core.search._remember_search_request("peer", token))

    def test_peer_response_unsent_restores_own_search_token(self):
        token = 4243
        core.search._own_tokens.discard(token)

        core.search._peer_response_unsent(
            FileSearchResponse, "me", ("file-search-response", "me", token, True))

        self.assertIn(token, core.search._own_tokens)

    def test_server_message_unsent_keeps_wishlist_search_after_interval_failure(self):
        token = core.search.token
        core.search.add_search("wish term", mode="wishlist", allow_response=False)
        search = core.search.searches[token]
        core.search.add_allowed_token(token)

        SEARCH_TOKENS_ALLOWED.release(token)
        events.emit("server-message-unsent", WishlistSearch(token, "wish term"))

        self.assertIs(core.search.searches[token], search)
        self.assertFalse(search.is_ignored)
        self.assertNotIn(token, SEARCH_TOKENS_ALLOWED)

    def test_do_search(self):
        """Test the do_search function, including the outgoing search term and
        search history."""

        old_token = core.search.token
        core.search.do_search(SEARCH_TEXT, SEARCH_MODE)
        search = core.search.searches[core.search.token]

        self.assertEqual(core.search.token, old_token + 1)
        self.assertEqual(search.term, SEARCH_TEXT)
        self.assertEqual(
            search.term_sanitized, '70 Gwen "test" -mp3 "what\'s up" don t -nothanks a b c d *ello auto -No yes'
        )
        self.assertEqual(
            search.term_transmitted, '70 Gwen test -mp3 what s up don t -nothanks a b c d *ello auto -No yes'
        )
        self.assertEqual(config.sections["searches"]["history"][0], search.term_sanitized)
        self.assertIn("ello", search.included_words)
        self.assertIn("gwen", search.included_words)
        self.assertIn("what's up", search.included_words)
        self.assertIn("don", search.included_words)
        self.assertIn("t", search.included_words)
        self.assertIn("no", search.excluded_words)
        self.assertIn("mp3", search.excluded_words)

    def test_outgoing_search_term_is_capped_before_retention(self):
        """Local/plugin search text should not be retained beyond the protocol field cap."""

        search_class = core.search.__class__
        old_limit = search_class.MAX_OUTGOING_SEARCH_TERM_BYTES

        try:
            search_class.MAX_OUTGOING_SEARCH_TERM_BYTES = 8
            core.search.do_search("x" * 100, SEARCH_MODE)
            search = core.search.searches[core.search.token]

            self.assertEqual("x" * 8, search.term)
            self.assertEqual("x" * 8, search.term_sanitized)
            self.assertEqual("x" * 8, search.term_transmitted)
            self.assertEqual("x" * 8, config.sections["searches"]["history"][0])

        finally:
            search_class.MAX_OUTGOING_SEARCH_TERM_BYTES = old_limit

    def test_plugin_search_feedback_is_capped_before_retention(self):
        """A plugin returning a huge search term should not bypass local caps."""

        search_class = core.search.__class__
        old_limit = search_class.MAX_OUTGOING_SEARCH_TERM_BYTES

        try:
            search_class.MAX_OUTGOING_SEARCH_TERM_BYTES = 8

            with patch.object(core.pluginhandler.__class__, "outgoing_global_search_event", return_value=("y" * 100,)):
                core.search.do_search("query", SEARCH_MODE)

            search = core.search.searches[core.search.token]
            self.assertEqual("y" * 8, search.term)
            self.assertEqual("y" * 8, search.term_transmitted)

        finally:
            search_class.MAX_OUTGOING_SEARCH_TERM_BYTES = old_limit

    def test_targeted_user_search_recipients_are_capped_before_retention(self):
        """Huge plugin/user target lists should be deduped and capped before SearchRequest storage."""

        search_class = core.search.__class__
        old_limit = search_class.MAX_STORED_USER_SEARCH_USERS
        old_user_limit = search_class.MAX_USER_SEARCH_MESSAGES_PER_JOB

        try:
            search_class.MAX_STORED_USER_SEARCH_USERS = 2
            search_class.MAX_USER_SEARCH_MESSAGES_PER_JOB = 2
            long_username = "u" * (1024 + 10)

            core.search.do_search("query", mode="user", users=[long_username, "bob", "bob", "carol"])
            search = core.search.searches[core.search.token]

            self.assertEqual(2, len(search.users))
            self.assertEqual(1024, len(search.users[0]))
            self.assertEqual("bob", search.users[1])

        finally:
            search_class.MAX_STORED_USER_SEARCH_USERS = old_limit
            search_class.MAX_USER_SEARCH_MESSAGES_PER_JOB = old_user_limit

    def test_restored_wishlist_terms_are_capped_consistently(self):
        """Gross autosearch entries should not desync wishlist indexes from retained SearchRequest terms."""

        search_class = core.search.__class__
        old_limit = search_class.MAX_OUTGOING_SEARCH_TERM_BYTES
        old_autosearch = config.sections["server"]["autosearch"]

        try:
            search_class.MAX_OUTGOING_SEARCH_TERM_BYTES = 8
            config.sections["server"]["autosearch"] = ["w" * 100]
            core.search._start()

            self.assertIn("w" * 8, core.search._wishlist_terms)
            self.assertIsNotNone(core.search._get_wishlist_search("w" * 8))

        finally:
            search_class.MAX_OUTGOING_SEARCH_TERM_BYTES = old_limit
            config.sections["server"]["autosearch"] = old_autosearch

    def test_rooms_search_without_room_is_ignored(self):
        """Verify that a room search without a selected room doesn't crash."""

        config.sections["server"]["autojoin"] = []
        old_token = core.search.token
        core.search.do_search("query", mode="rooms", room=None)

        self.assertEqual(old_token, core.search.token)
        self.assertEqual({}, core.search.searches)

    def test_rejected_global_search_does_not_leave_allowed_token_or_history(self):
        """Search response tokens should only be allowed after request queue acceptance."""

        config.sections["searches"]["history"] = []
        old_token = core.search.token

        with patch.object(core.__class__, "send_message_to_server", return_value=False):
            core.search.do_search("rare query", mode="global")

        rejected_token = old_token + 1
        self.assertNotIn(rejected_token, core.search.searches)
        self.assertNotIn(rejected_token, SEARCH_TOKENS_ALLOWED)
        self.assertEqual([], config.sections["searches"]["history"])

    def test_targeted_search_allows_token_only_after_accepted_recipient_message(self):
        """A queued targeted search should not expose its token until at least one UserSearch is accepted."""

        sent_results = iter([False, True])

        def fake_send(_msg):
            return next(sent_results)

        with patch.object(core.__class__, "send_message_to_server", side_effect=fake_send):
            core.search.do_search("rare query", mode="user", users=["alice", "bob"])

        token = core.search.token
        self.assertIn(token, core.search.searches)
        self.assertIn(token, SEARCH_TOKENS_ALLOWED)

    def test_rejected_wishlist_search_does_not_refresh_response_ledger(self):
        """Wishlist tokens are reused, but a rejected queue request should not reset response state."""

        core.search.add_search("rare wishlist", mode="wishlist")
        token = core.search.token
        search = core.search.searches[token]
        search.responded_users.add("olduser")
        core.search.remove_allowed_token(token)

        with patch.object(core.__class__, "send_message_to_server", return_value=False):
            core.search.do_wishlist_search(token, "rare wishlist")

        self.assertEqual({"olduser"}, search.responded_users)
        self.assertNotIn(token, SEARCH_TOKENS_ALLOWED)

    def test_rooms_search_uses_configured_autojoin_room(self):
        """Verify that the first configured room is used if none is selected."""

        config.sections["server"]["autojoin"] = ["music"]
        old_token = core.search.token

        core.search.do_search("query", mode="rooms", room=None)
        search = core.search.searches[core.search.token]

        self.assertEqual(old_token + 1, core.search.token)
        self.assertEqual("music", search.room)

    def test_parse_incoming_search_words_preserves_word_classes(self):
        """Incoming search parsing should preserve include/exclude/partial terms."""

        parsed_words = core.search._parse_incoming_search_words("artist -live *mix file.name")

        self.assertEqual(({"artist", "file", "name"}, {"live"}, {"mix"}), parsed_words)

    def test_parse_incoming_search_words_rejects_token_storms(self):
        """A small byte-sized remote search can still contain excessive word tokens."""

        search_class = core.search.__class__
        old_limit = search_class.MAX_INCOMING_SEARCH_REQUEST_WORDS
        search_class.MAX_INCOMING_SEARCH_REQUEST_WORDS = 2

        try:
            self.assertIsNone(core.search._parse_incoming_search_words("one two three"))
            self.assertEqual(({"one", "two"}, set(), set()),
                             core.search._parse_incoming_search_words("one two"))

        finally:
            search_class.MAX_INCOMING_SEARCH_REQUEST_WORDS = old_limit

    def test_search_response_user_limit_discards_token(self):
        """One search token should not retain unlimited distinct responders."""

        search_class = core.search.__class__
        old_limit = search_class.MAX_SEARCH_RESPONSE_USERS
        token = 123456
        search_class.MAX_SEARCH_RESPONSE_USERS = 1
        core.search.searches[token] = SearchRequest(token=token, term="query")
        core.search.add_allowed_token(token)

        old_network_filter = core.network_filter
        core.network_filter = SimpleNamespace(
            is_user_ignored=lambda _username: False,
            is_user_ip_ignored=lambda _username, _ip_address: False
        )

        try:
            first_msg = SimpleNamespace(token=token, username="first", addr=("203.0.113.1", 2242))
            second_msg = SimpleNamespace(token=token, username="second", addr=("203.0.113.2", 2242))

            core.search._file_search_response(first_msg)
            core.search._file_search_response(second_msg)

            self.assertEqual(token, first_msg.token)
            self.assertIsNone(second_msg.token)

        finally:
            core.network_filter = old_network_filter
            core.search.remove_allowed_token(token)
            search_class.MAX_SEARCH_RESPONSE_USERS = old_limit

    def test_search_token_increment(self):
        """Test that search token increments work properly."""

        old_token = core.search.token

        core.search.token = increment_token(core.search.token)
        self.assertEqual(old_token, core.search.token - 1)

    def test_file_search_response_deduplicates_same_user_before_gui_rows(self):
        """Repeated empty/filtered responses from one user should not keep hitting the GUI path."""

        core.search.add_search("rare album", mode="global")
        token = core.search.token
        SEARCH_TOKENS_ALLOWED.add(token)

        first_msg = SimpleNamespace(token=token, username="peer", addr=("203.0.113.10", 2234))
        second_msg = SimpleNamespace(token=token, username="peer", addr=("203.0.113.10", 2234))

        core.search._file_search_response(first_msg)
        core.search._file_search_response(second_msg)

        self.assertEqual(token, first_msg.token)
        self.assertIsNone(second_msg.token)
        self.assertEqual({"peer"}, core.search.searches[token].responded_users)

    def test_file_search_response_user_limit_discards_allowed_token(self):
        """A search token should not accept responses from unlimited distinct users."""

        core.search.add_search("rare album", mode="global")
        token = core.search.token
        search = core.search.searches[token]
        search.responded_users.add("peer1")
        SEARCH_TOKENS_ALLOWED.add(token)

        search_class = core.search.__class__
        old_limit = search_class.MAX_SEARCH_RESPONSE_USERS
        search_class.MAX_SEARCH_RESPONSE_USERS = 1

        try:
            msg = SimpleNamespace(token=token, username="peer2", addr=("203.0.113.11", 2234))
            core.search._file_search_response(msg)

        finally:
            search_class.MAX_SEARCH_RESPONSE_USERS = old_limit

        self.assertIsNone(msg.token)
        self.assertNotIn(token, SEARCH_TOKENS_ALLOWED)
        self.assertEqual({"peer1"}, search.responded_users)

    def test_wishlist_search_clears_previous_response_user_set(self):
        """Wishlist tokens are reused, so duplicate-response accounting resets each interval."""

        core.search.add_search("rare album", mode="wishlist")
        token = core.search.token
        search = core.search.searches[token]
        search.responded_users.add("peer")

        with patch.object(core.__class__, "send_message_to_server"):
            core.search.do_wishlist_search(token, search.term_transmitted)

        self.assertEqual(set(), search.responded_users)

    def test_wishlist_start_deduplicates_and_caps_restored_items(self):
        """Restored wishlist entries should not create unbounded duplicate search objects."""

        search_class = core.search.__class__
        old_limit = search_class.MAX_WISHLIST_SEARCHES
        search_class.MAX_WISHLIST_SEARCHES = 2
        config.sections["server"]["autosearch"] = ["alpha", "alpha", "beta", "gamma"]

        try:
            core.search._start()

        finally:
            search_class.MAX_WISHLIST_SEARCHES = old_limit

        self.assertEqual({"alpha", "beta"}, core.search._wishlist_terms)
        self.assertEqual({"alpha", "beta"}, set(core.search._wishlist_tokens_by_term))
        self.assertEqual(2, sum(1 for search in core.search.searches.values() if search.mode == "wishlist"))

    def test_wishlist_interval_uses_indexed_search(self):
        """Wishlist intervals should find the rotated term through the term-token index."""

        config.sections["server"]["autosearch"] = ["alpha", "beta"]
        core.search.add_wish("alpha")
        alpha_token = core.search._wishlist_tokens_by_term["alpha"]
        core.search.add_wish("beta")
        beta_token = core.search._wishlist_tokens_by_term["beta"]
        sent_messages = []

        with patch.object(core.__class__, "send_message_to_server", side_effect=sent_messages.append):
            core.search.do_wishlist_search_interval()

        self.assertEqual(beta_token, sent_messages[0].token)
        self.assertNotEqual(alpha_token, sent_messages[0].token)
        self.assertEqual(["beta", "alpha"], config.sections["server"]["autosearch"])

    def test_remove_wish_updates_index_and_term_set(self):
        """Removing a wish should not leave stale indexed terms behind."""

        core.search.add_wish("alpha")
        token = core.search._wishlist_tokens_by_term["alpha"]
        self.assertIn(token, core.search.searches)

        core.search.remove_wish("alpha")

        self.assertNotIn("alpha", core.search._wishlist_terms)
        self.assertNotIn("alpha", core.search._wishlist_tokens_by_term)
        self.assertNotIn(token, core.search.searches)

    def test_wishlist_interval_zero_cancels_existing_timer(self):
        """A zero server wishlist interval should disable any active timer."""

        class FakeEvents:
            def __init__(self):
                self.cancelled = []
                self.scheduled = []

            def cancel_scheduled(self, timer_id):
                self.cancelled.append(timer_id)

            def schedule(self, **kwargs):
                self.scheduled.append(kwargs)
                return "new-timer"

        timer_id = object()
        fake_events = FakeEvents()
        core.search._wishlist_timer_id = timer_id
        core.search.wishlist_interval = 123

        with patch("pynicotine.search.events", fake_events):
            core.search._set_wishlist_interval(SimpleNamespace(seconds=0))

        self.assertEqual([timer_id], fake_events.cancelled)
        self.assertEqual([], fake_events.scheduled)
        self.assertIsNone(core.search._wishlist_timer_id)
        self.assertEqual(0, core.search.wishlist_interval)

    def test_wishlist_interval_is_clamped_and_replaces_existing_timer(self):
        """A tiny server wishlist interval should not create a search storm."""

        class FakeEvents:
            def __init__(self):
                self.cancelled = []
                self.scheduled = []

            def cancel_scheduled(self, timer_id):
                self.cancelled.append(timer_id)

            def schedule(self, **kwargs):
                self.scheduled.append(kwargs)
                return "new-timer"

        fake_events = FakeEvents()
        core.search._wishlist_timer_id = "old-timer"

        with patch("pynicotine.search.events", fake_events):
            core.search._set_wishlist_interval(SimpleNamespace(seconds=1))

        self.assertEqual(["old-timer"], fake_events.cancelled)
        self.assertEqual(1, len(fake_events.scheduled))
        self.assertEqual(Search.MIN_WISHLIST_INTERVAL, fake_events.scheduled[0]["delay"])
        self.assertEqual(Search.MIN_WISHLIST_INTERVAL, core.search.wishlist_interval)
        self.assertEqual("new-timer", core.search._wishlist_timer_id)

    def test_wishlist_add(self):
        """Test that items are added to the wishlist properly."""

        old_token = core.search.token

        # First item

        core.search.add_wish(SEARCH_TEXT)
        search = core.search.searches[core.search.token]

        self.assertEqual(config.sections["server"]["autosearch"][0], SEARCH_TEXT)
        self.assertEqual(core.search.token, old_token + 1)
        self.assertEqual(core.search.token, core.search.token)
        self.assertEqual(search.term, SEARCH_TEXT)
        self.assertEqual(search.mode, "wishlist")
        self.assertTrue(search.is_ignored)

        # Second item

        new_item = f"{SEARCH_TEXT}1"
        core.search.add_wish(new_item)
        search = core.search.searches[core.search.token]

        self.assertEqual(config.sections["server"]["autosearch"][0], SEARCH_TEXT)
        self.assertEqual(config.sections["server"]["autosearch"][1], new_item)
        self.assertEqual(search.term, new_item)
        self.assertEqual(search.mode, "wishlist")
        self.assertTrue(search.is_ignored)

    def test_search_response_user_cap_stops_token_after_many_users(self):
        """One search token should not accept result payloads from unlimited users."""

        core.search.add_search("query", SEARCH_MODE)
        token = core.search.token
        search_class = core.search.__class__
        old_limit = search_class.MAX_SEARCH_RESPONSE_USERS
        search_class.MAX_SEARCH_RESPONSE_USERS = 1
        fake_network_filter = SimpleNamespace(
            is_user_ignored=lambda _username: False,
            is_user_ip_ignored=lambda _username, _ip_address: False
        )

        try:
            with patch.object(core, "network_filter", fake_network_filter):
                first_msg = SimpleNamespace(token=token, username="user1", addr=("203.0.113.1", 1))
                core.search._file_search_response(first_msg)

                second_msg = SimpleNamespace(token=token, username="user2", addr=("203.0.113.2", 1))
                core.search._file_search_response(second_msg)

            self.assertEqual(token, first_msg.token)
            self.assertIsNone(second_msg.token)
            self.assertNotIn(token, SEARCH_TOKENS_ALLOWED)

        finally:
            search_class.MAX_SEARCH_RESPONSE_USERS = old_limit
            SEARCH_TOKENS_ALLOWED.discard(token)

    def test_targeted_user_search_fanout_is_batched(self):
        """Large targeted searches should not synchronously send every UserSearch at once."""

        class FakeEvents:
            def __init__(self):
                self.scheduled = []

            def schedule(self, **kwargs):
                self.scheduled.append(kwargs)
                return "timer"

            def cancel_scheduled(self, _timer_id):
                pass

        fake_events = FakeEvents()
        sent_messages = []
        search_class = core.search.__class__
        old_per_tick = search_class.MAX_USER_SEARCH_MESSAGES_PER_TICK
        old_job_limit = search_class.MAX_USER_SEARCH_MESSAGES_PER_JOB
        search_class.MAX_USER_SEARCH_MESSAGES_PER_TICK = 2
        search_class.MAX_USER_SEARCH_MESSAGES_PER_JOB = 10

        try:
            core.search.add_search("query", mode="user", users=["a", "b", "c"])

            with patch("pynicotine.search.events", fake_events), \
                    patch.object(core.__class__, "send_message_to_server", side_effect=sent_messages.append):
                core.search.do_peer_search("query", ["a", "b", "c"])

                self.assertEqual(2, len(sent_messages))
                self.assertEqual(1, len(fake_events.scheduled))
                self.assertIsNotNone(core.search._pending_user_search_timer_id)

                core.search._process_pending_user_searches()

            self.assertEqual(["a", "b", "c"], [msg.search_username for msg in sent_messages])
            self.assertEqual([], list(core.search._pending_user_search_jobs))

        finally:
            search_class.MAX_USER_SEARCH_MESSAGES_PER_TICK = old_per_tick
            search_class.MAX_USER_SEARCH_MESSAGES_PER_JOB = old_job_limit

    def test_targeted_user_search_job_limit_discards_remaining_users(self):
        """A huge peer-search recipient list should have a gross per-search cap."""

        sent_messages = []
        search_class = core.search.__class__
        old_per_tick = search_class.MAX_USER_SEARCH_MESSAGES_PER_TICK
        old_job_limit = search_class.MAX_USER_SEARCH_MESSAGES_PER_JOB
        search_class.MAX_USER_SEARCH_MESSAGES_PER_TICK = 10
        search_class.MAX_USER_SEARCH_MESSAGES_PER_JOB = 2

        try:
            core.search.add_search("query", mode="user", users=["a", "b", "c"])

            with patch.object(core.__class__, "send_message_to_server", side_effect=sent_messages.append):
                core.search.do_peer_search("query", ["a", "b", "c"])

            self.assertEqual(["a", "b"], [msg.search_username for msg in sent_messages])
            self.assertEqual([], list(core.search._pending_user_search_jobs))

        finally:
            search_class.MAX_USER_SEARCH_MESSAGES_PER_TICK = old_per_tick
            search_class.MAX_USER_SEARCH_MESSAGES_PER_JOB = old_job_limit

    def test_targeted_user_search_marks_own_token_when_batched(self):
        """Deferred targeted searches should preserve the self-search token marker."""

        sent_messages = []
        old_users = core.users
        core.users = SimpleNamespace(login_username="me")

        try:
            core.search.add_search("query", mode="user", users=["me"])
            token = core.search.token

            with patch.object(core.__class__, "send_message_to_server", side_effect=sent_messages.append):
                core.search.do_peer_search("query", ["me"])

            self.assertEqual(["me"], [msg.search_username for msg in sent_messages])
            self.assertIn(token, core.search._own_tokens)

        finally:
            core.users = old_users

    def test_duplicate_search_response_user_is_ignored(self):
        """A repeated peer response for the same search token should not be processed twice."""

        core.search.add_search("query", SEARCH_MODE)
        token = core.search.token
        fake_network_filter = SimpleNamespace(
            is_user_ignored=lambda _username: False,
            is_user_ip_ignored=lambda _username, _ip_address: False
        )

        try:
            with patch.object(core, "network_filter", fake_network_filter):
                first_msg = SimpleNamespace(token=token, username="user1", addr=("203.0.113.1", 1))
                core.search._file_search_response(first_msg)

                duplicate_msg = SimpleNamespace(token=token, username="user1", addr=("203.0.113.1", 1))
                core.search._file_search_response(duplicate_msg)

            self.assertEqual(token, first_msg.token)
            self.assertIsNone(duplicate_msg.token)
            self.assertEqual({"user1"}, core.search.searches[token].responded_users)

        finally:
            SEARCH_TOKENS_ALLOWED.discard(token)

    def test_incoming_search_request_replay_is_ignored_before_plugin_notification(self):
        """Duplicate remote searches should not repeat share/plugin fanout."""

        msg = SimpleNamespace(searchterm="rare album", search_username="peer", token=12345)
        process_search_request = []
        fake_pluginhandler = SimpleNamespace(search_request_notification=lambda *args: process_search_request.append(args))
        old_pluginhandler = core.pluginhandler
        core.pluginhandler = fake_pluginhandler

        old_process_search_request = Search._process_search_request

        try:
            Search._process_search_request = lambda self, *args: process_search_request.append(args)
            core.search._file_search_request_server(msg)
            core.search._file_search_request_server(msg)

        finally:
            Search._process_search_request = old_process_search_request
            core.pluginhandler = old_pluginhandler

        self.assertEqual(2, len(process_search_request))
        self.assertEqual(("rare album", "peer", 12345), process_search_request[0])
        self.assertEqual(("rare album", "peer", 12345), process_search_request[1])

    def test_rejected_incoming_search_response_rolls_back_replay_ledger(self):
        """A queue-rejected response should not poison incoming search replay state."""

        msg = SimpleNamespace(searchterm="rare album", search_username="peer", token=54321)
        notifications = []
        fake_pluginhandler = SimpleNamespace(search_request_notification=lambda *args: notifications.append(args))
        old_pluginhandler = core.pluginhandler
        old_process_search_request = Search._process_search_request

        try:
            core.pluginhandler = fake_pluginhandler
            Search._process_search_request = lambda self, *args: False

            core.search._file_search_request_server(msg)

            self.assertNotIn(("peer", 54321), core.search._processed_search_requests)
            self.assertEqual([], notifications)

            Search._process_search_request = lambda self, *args: None
            core.search._file_search_request_server(msg)

            self.assertIn(("peer", 54321), core.search._processed_search_requests)
            self.assertEqual([("rare album", "peer", 54321)], notifications)

        finally:
            Search._process_search_request = old_process_search_request
            core.pluginhandler = old_pluginhandler

    def test_process_search_request_reports_rejected_response_and_restores_own_token(self):
        """A rejected FileSearchResponse should be visible to replay lifecycle callers."""

        old_uploads = core.uploads
        old_users = core.users
        old_max_results = config.sections["searches"]["maxresults"]
        old_min_chars = config.sections["searches"]["min_search_chars"]
        token = 67890

        core.users = SimpleNamespace(login_username="local")
        core.uploads = SimpleNamespace(
            pending_shutdown=False,
            is_new_upload_accepted=lambda: True,
            upload_speed=0,
            get_upload_queue_size=lambda _username: 0
        )
        config.sections["searches"]["maxresults"] = 10
        config.sections["searches"]["min_search_chars"] = 1
        core.shares.file_path_index = ("real\rare_track.flac",)
        core.shares.share_dbs["words"] = UserDict({"rare": [0]})
        core.shares.share_dbs["public_files"] = UserDict({
            "real\rare_track.flac": ["music\rare_track.flac", 1, None, None]
        })
        core.shares.share_dbs["buddy_files"] = UserDict()
        core.shares.share_dbs["trusted_files"] = UserDict()

        for share_db in core.shares.share_dbs.values():
            share_db.close = lambda: None

        try:
            core.search._own_tokens.add(token)

            with patch.object(core.shares.__class__, "check_user_permission",
                              return_value=(PermissionLevel.PUBLIC, None)), \
                    patch.object(type(core), "send_message_to_peer", return_value=False):
                result = core.search._process_search_request("rare", "local", token)

            self.assertFalse(result)
            self.assertIn(token, core.search._own_tokens)

        finally:
            core.uploads = old_uploads
            core.users = old_users
            config.sections["searches"]["maxresults"] = old_max_results
            config.sections["searches"]["min_search_chars"] = old_min_chars
            core.search._own_tokens.discard(token)

    def test_incoming_search_request_dedupe_table_is_capped(self):
        """A malicious stream of unique search tokens should not grow the dedupe ledger without bound."""

        old_limit = Search.MAX_PROCESSED_SEARCH_REQUESTS
        Search.MAX_PROCESSED_SEARCH_REQUESTS = 1

        try:
            self.assertTrue(core.search._remember_search_request("peer1", 1))
            self.assertFalse(core.search._remember_search_request("peer2", 2))
            self.assertEqual({("peer1", 1)}, set(core.search._processed_search_requests))

        finally:
            Search.MAX_PROCESSED_SEARCH_REQUESTS = old_limit

    def test_partial_only_search_scan_is_capped(self):
        """A rare suffix search should not sweep a grossly huge word index forever."""

        old_limit = Search.MAX_PARTIAL_WORD_INDEX_SCAN
        Search.MAX_PARTIAL_WORD_INDEX_SCAN = 2

        try:
            results = core.search._create_search_result_list(
                included_words=set(),
                excluded_words=set(),
                partial_words={"zzzz"},
                max_results=1500,
                word_index={"alpha": [1], "beta": [2], "gamma": [3], "delta": [4]}
            )

        finally:
            Search.MAX_PARTIAL_WORD_INDEX_SCAN = old_limit

        self.assertIsNone(results)
        self.assertTrue(core.search._partial_word_scan_limit_logged)

    def test_create_search_result_list_keeps_candidate_window_for_later_filtering(self):
        """Single-word raw candidates should not be clipped to accepted-result cap too early."""

        old_multiplier = Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN_MULTIPLIER
        old_scan = Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN

        try:
            Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN_MULTIPLIER = 3
            Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN = 100

            results = core.search._create_search_result_list(
                included_words={"rare"},
                excluded_words=set(),
                partial_words=set(),
                max_results=1,
                word_index={"rare": [0, 1, 2, 3, 4]}
            )

            self.assertEqual({0, 1, 2}, results)

        finally:
            Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN_MULTIPLIER = old_multiplier
            Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN = old_scan

    def test_create_search_result_list(self):
        """Test creating search result lists from the word index."""

        max_results = 1500
        word_index = {
            "iso": [34, 35, 36, 37, 38],
            "lts": [63, 68, 73],
            "system": [37, 38],
            "linux": [35, 36]
        }

        included_words = {"iso"}
        excluded_words = {"linux", "game"}
        partial_words = {"stem"}

        results = core.search._create_search_result_list(
            included_words, excluded_words, partial_words, max_results, word_index)
        self.assertEqual(results, {37, 38})

        included_words = {"lts", "iso"}
        excluded_words = {"linux", "game", "music", "cd"}
        partial_words = set()

        results = core.search._create_search_result_list(
            included_words, excluded_words, partial_words, max_results, word_index)
        self.assertIsNone(results)

        included_words = {"iso"}
        excluded_words = {"system"}
        partial_words = {"ibberish"}

        results = core.search._create_search_result_list(
            included_words, excluded_words, partial_words, max_results, word_index)
        self.assertIsNone(results)

    def test_create_search_result_list_starts_with_rarest_included_word(self):
        """Verify that common words don't seed a large intermediate result set."""

        from pynicotine.search import Search

        class OrderedWordSet(set):
            def __iter__(self):
                return iter(("common", "rare"))

        word_index = {
            "common": list(range(10000)),
            "rare": [9999]
        }
        initial_result_lengths = []
        original_update_search_results = Search._update_search_results

        def update_search_results(results, word_indices, excluded=False):
            if results is None and not excluded:
                initial_result_lengths.append(len(word_indices))

            return original_update_search_results(results, word_indices, excluded)

        Search._update_search_results = staticmethod(update_search_results)
        self.addCleanup(setattr, Search, "_update_search_results", staticmethod(original_update_search_results))

        results = core.search._create_search_result_list(
            OrderedWordSet(("common", "rare")), set(), set(), max_results=1500, word_index=word_index)

        self.assertEqual({9999}, results)
        self.assertEqual([1], initial_result_lengths)

    def test_create_search_result_list_filters_partials_after_exact_words(self):
        """Verify that exact words avoid a full word-index scan for partial words."""

        class ExplodingWordIndex(dict):
            def __iter__(self):
                raise AssertionError("partial search scanned the full word index")

        word_index = ExplodingWordIndex({
            "rare": [0, 1, 2]
        })
        core.shares.file_path_index = [
            "real\\rare_track_1",
            "real\\rare_track_2",
            "real\\rare_track_3"
        ]
        core.shares.share_dbs["public_files"] = UserDict({
            "real\\rare_track_1": ["music\\artist\\rare track.flac", 0, None, None],
            "real\\rare_track_2": ["music\\artist\\rare track.mp3", 0, None, None],
            "real\\rare_track_3": ["music\\artist\\rare demo.wav", 0, None, None]
        })
        core.shares.share_dbs["buddy_files"] = UserDict()
        core.shares.share_dbs["trusted_files"] = UserDict()

        for share_db in core.shares.share_dbs.values():
            share_db.close = lambda: None

        results = core.search._create_search_result_list(
            included_words={"rare"},
            excluded_words=set(),
            partial_words={"lac"},
            max_results=1500,
            word_index=word_index
        )

        self.assertEqual({0}, results)

    def test_incoming_search_caps_work_to_protocol_result_limit(self):
        """Local maxresults above the protocol cap should not drive extra response work."""

        old_uploads = core.uploads
        old_users = core.users
        old_max_results = config.sections["searches"]["maxresults"]
        observed_max_results = []

        core.users = SimpleNamespace(login_username="local")
        config.sections["searches"]["maxresults"] = FileSearchResponse.MAX_RESULT_FILES + 50000
        config.sections["searches"]["min_search_chars"] = 1
        core.uploads = SimpleNamespace(
            pending_shutdown=False,
            is_new_upload_accepted=lambda: True,
            upload_speed=0,
            get_upload_queue_size=lambda _username: 0
        )
        core.shares.share_dbs["words"] = UserDict({"rare": [0]})
        core.shares.share_dbs["words"].close = lambda: None

        def create_file_info_list(self, results, max_results, permission_level):
            observed_max_results.append(max_results)
            return 0, [], []

        try:
            with patch.object(core.shares.__class__, "check_user_permission",
                              return_value=(PermissionLevel.PUBLIC, None)), \
                    patch.object(Search, "_create_file_info_list", create_file_info_list):
                core.search._process_search_request("rare", "peer", 1234)

        finally:
            core.uploads = old_uploads
            core.users = old_users
            config.sections["searches"]["maxresults"] = old_max_results

        self.assertEqual([FileSearchResponse.MAX_RESULT_FILES], observed_max_results)

    def test_create_file_info_list_skips_stale_indices(self):
        """Verify that stale search indices don't crash response generation."""

        core.shares.file_path_index = ("real\\song.mp3",)
        core.shares.share_dbs["public_files"] = UserDict({
            "real\\song.mp3": ["virtual\\song.mp3", 1000, None, None]
        })
        core.shares.share_dbs["buddy_files"] = UserDict()
        core.shares.share_dbs["trusted_files"] = UserDict()

        for share_db in core.shares.share_dbs.values():
            share_db.close = lambda: None

        num_results, fileinfos, private_fileinfos = core.search._create_file_info_list(
            {0, 999}, max_results=1500, permission_level=PermissionLevel.PUBLIC)

        self.assertEqual(1, num_results)
        self.assertEqual([["virtual\\song.mp3", 1000, None, None]], fileinfos)
        self.assertEqual([], private_fileinfos)

    def test_exclude_server_phrases(self):
        """Verify that results containing excluded phrases are not included."""

        core.search.excluded_phrases = ["linux distro", "netbsd"]
        results = {0, 1, 2, 3, 4, 5}
        public_share_db = core.shares.share_dbs["public_files"] = UserDict({
            "real\\isos\\freebsd.iso": ["virtual\\isos\\freebsd.iso", 1000, None, None],
            "real\\isos\\linux.iso": ["virtual\\isos\\linux.iso", 2000, None, None],
            "real\\isos\\linux distro.iso": ["virtual\\isos\\linux distro.iso", 3000, None, None],
            "real\\isos\\Linux Distro.iso": ["virtual\\isos\\Linux Distro.iso", 4000, None, None],
            "real\\isos\\NetBSD.iso": ["virtual\\isos\\NetBSD.iso", 5000, None, None],
            "real\\isos\\openbsd.iso": ["virtual\\isos\\openbsd.iso", 6000, None, None]
        })
        core.shares.share_dbs["buddy_files"] = core.shares.share_dbs["trusted_files"] = UserDict()
        core.shares.file_path_index = list(public_share_db)

        for share_db in core.shares.share_dbs.values():
            share_db.close = lambda: None

        num_results, fileinfos, private_fileinfos = core.search._create_file_info_list(
            results, max_results=100, permission_level=PermissionLevel.PUBLIC
        )
        self.assertEqual(num_results, 3)
        self.assertEqual(fileinfos, [
            ["virtual\\isos\\freebsd.iso", 1000, None, None],
            ["virtual\\isos\\linux.iso", 2000, None, None],
            ["virtual\\isos\\openbsd.iso", 6000, None, None]
        ])
        self.assertEqual(private_fileinfos, [])

    def test_excluded_search_phrase_matching_is_indexed_and_case_insensitive(self):
        """Large phrase lists should be indexed before per-result filtering."""

        msg = ExcludedSearchPhrases()
        msg.phrases = ["NETBSD", "linux distro", "zzz"]
        core.search._excluded_search_phrases(msg)

        self.assertEqual(["netbsd", "linux distro", "zzz"], core.search.excluded_phrases)
        self.assertEqual(("netbsd",), core.search._excluded_phrase_index["n"])
        self.assertEqual("netbsd", core.search._find_excluded_phrase("virtual/NetBSD.iso".lower()))

    def test_excluded_search_result_logs_are_capped_per_request(self):
        """A common excluded phrase should not create one log line per candidate."""

        old_limit = Search.MAX_EXCLUDED_SEARCH_RESULT_LOGS_PER_REQUEST
        logged_messages = []

        try:
            Search.MAX_EXCLUDED_SEARCH_RESULT_LOGS_PER_REQUEST = 2
            core.search.excluded_phrases = ["blocked"]
            core.search._excluded_phrase_index = {"b": ("blocked",)}
            results = set(range(5))
            public_share_db = core.shares.share_dbs["public_files"] = UserDict({
                f"real/blocked{index}.flac": [f"virtual/blocked{index}.flac", 1000, None, None]
                for index in range(5)
            })
            core.shares.share_dbs["buddy_files"] = core.shares.share_dbs["trusted_files"] = UserDict()
            core.shares.file_path_index = list(public_share_db)

            for share_db in core.shares.share_dbs.values():
                share_db.close = lambda: None

            fake_log = SimpleNamespace(add_search=lambda *args, **_kwargs: logged_messages.append(args))

            with patch("pynicotine.search.log", fake_log):
                num_results, fileinfos, private_fileinfos = core.search._create_file_info_list(
                    results, max_results=5, permission_level=PermissionLevel.PUBLIC)

        finally:
            Search.MAX_EXCLUDED_SEARCH_RESULT_LOGS_PER_REQUEST = old_limit

        self.assertEqual(0, num_results)
        self.assertEqual([], fileinfos)
        self.assertEqual([], private_fileinfos)
        self.assertEqual(3, len(logged_messages))
        self.assertIn("Suppressing additional", logged_messages[-1][0])

    def test_search_result_candidate_scan_is_bounded_when_exclusions_hide_prefix(self):
        """Trying to fill results past excluded candidates should still have a gross scan bound."""

        old_multiplier = Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN_MULTIPLIER
        old_scan = Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN

        try:
            Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN_MULTIPLIER = 2
            Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN = 4
            core.search.excluded_phrases = ["blocked"]
            core.search._excluded_phrase_index = {"b": ("blocked",)}

            public_share_db = core.shares.share_dbs["public_files"] = UserDict({
                "real/blocked0.flac": ["virtual/blocked0.flac", 1000, None, None],
                "real/blocked1.flac": ["virtual/blocked1.flac", 1000, None, None],
                "real/allowed2.flac": ["virtual/allowed2.flac", 1000, None, None],
                "real/allowed3.flac": ["virtual/allowed3.flac", 1000, None, None],
                "real/allowed4.flac": ["virtual/allowed4.flac", 1000, None, None]
            })
            core.shares.share_dbs["buddy_files"] = core.shares.share_dbs["trusted_files"] = UserDict()
            core.shares.file_path_index = list(public_share_db)

            for share_db in core.shares.share_dbs.values():
                share_db.close = lambda: None

            num_results, fileinfos, _private_fileinfos = core.search._create_file_info_list(
                set(range(5)), max_results=2, permission_level=PermissionLevel.PUBLIC)

        finally:
            Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN_MULTIPLIER = old_multiplier
            Search.MAX_SEARCH_RESULT_CANDIDATE_SCAN = old_scan

        self.assertEqual(2, num_results)
        self.assertEqual([
            ["virtual/allowed2.flac", 1000, None, None],
            ["virtual/allowed3.flac", 1000, None, None]
        ], fileinfos)

    def test_search_response_ignores_duplicate_users(self):
        """Repeated responses from one user shouldn't keep growing one search tab."""

        token = core.search.token
        search = core.search.add_search("query", mode="global")

        first_response = SimpleNamespace(token=token, username="user1", addr=("203.0.113.1", 1234))
        duplicate_response = SimpleNamespace(token=token, username="user1", addr=("203.0.113.1", 1234))

        core.search._file_search_response(first_response)
        core.search._file_search_response(duplicate_response)

        self.assertEqual(token, first_response.token)
        self.assertIsNone(duplicate_response.token)
        self.assertEqual({"user1"}, search.responded_users)

    def test_search_response_user_limit_removes_token(self):
        """A response storm for one search should eventually stop accepting peers."""

        old_limit = Search.MAX_SEARCH_RESPONSE_USERS
        Search.MAX_SEARCH_RESPONSE_USERS = 2

        try:
            token = core.search.token
            search = core.search.add_search("query", mode="global")

            for index in range(2):
                msg = SimpleNamespace(token=token, username=f"user{index}", addr=(f"203.0.113.{index}", 1234))
                core.search._file_search_response(msg)
                self.assertEqual(token, msg.token)

            capped_response = SimpleNamespace(token=token, username="user2", addr=("203.0.113.2", 1234))
            core.search._file_search_response(capped_response)

            self.assertIsNone(capped_response.token)
            self.assertEqual({"user0", "user1"}, search.responded_users)
            self.assertNotIn(token, SEARCH_TOKENS_ALLOWED)

        finally:
            Search.MAX_SEARCH_RESPONSE_USERS = old_limit

    def test_excluded_search_phrases_are_capped_and_logged_bounded(self):
        """Grossly large server phrase lists shouldn't slow every search or create huge logs."""

        old_max_phrases = Search.MAX_EXCLUDED_SEARCH_PHRASES
        old_max_logged_phrases = Search.MAX_LOGGED_EXCLUDED_SEARCH_PHRASES
        Search.MAX_EXCLUDED_SEARCH_PHRASES = 3
        Search.MAX_LOGGED_EXCLUDED_SEARCH_PHRASES = 2

        try:
            msg = ExcludedSearchPhrases()
            msg.phrases = [f"phrase{i}" for i in range(10)]

            core.search._excluded_search_phrases(msg)

            self.assertEqual(["phrase0", "phrase1", "phrase2"], core.search.excluded_phrases)

            phrase_summary = Search._format_phrase_summary(core.search.excluded_phrases)
            self.assertIn("omitted", phrase_summary)
            self.assertNotIn("phrase9", phrase_summary)

        finally:
            Search.MAX_EXCLUDED_SEARCH_PHRASES = old_max_phrases
            Search.MAX_LOGGED_EXCLUDED_SEARCH_PHRASES = old_max_logged_phrases

    def test_request_folder_download_batches_visible_search_results(self):
        """Visible search-folder results should be enqueued in bounded batches."""

        class FakeDownloads:
            def __init__(self):
                self.folders = []
                self.downloads = []

            def enqueue_folder(self, username, folder_path, download_folder_path=None):
                self.folders.append((username, folder_path, download_folder_path))

            @staticmethod
            def get_folder_destination(username, folder_path):
                return f"dest:{username}:{folder_path}"

            def enqueue_download(self, username, file_path, folder_path=None, size=None, file_attributes=None):
                self.downloads.append((username, file_path, folder_path, size, file_attributes))

        fake_downloads = FakeDownloads()
        old_downloads = getattr(core, "downloads", None)
        old_limit = Search.MAX_SEARCH_FOLDER_DOWNLOAD_FILES_PER_TICK
        callbacks = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            callbacks.append((callback, callback_args or ()))
            return len(callbacks)

        visible_files = [(f"folder\\file{index}.mp3", index, {"duration": index}) for index in range(5)]

        try:
            core.downloads = fake_downloads
            Search.MAX_SEARCH_FOLDER_DOWNLOAD_FILES_PER_TICK = 2
            fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=lambda timer_id: None)

            with patch("pynicotine.search.events", fake_events):
                core.search.request_folder_download("peer", "folder", visible_files, download_folder_path="album")

                self.assertEqual([("peer", "folder", "album")], fake_downloads.folders)
                self.assertEqual(2, len(fake_downloads.downloads))
                self.assertEqual(1, len(callbacks))

                callback, callback_args = callbacks.pop(0)
                callback(*callback_args)
                self.assertEqual(4, len(fake_downloads.downloads))
                self.assertEqual(1, len(callbacks))

                callback, callback_args = callbacks.pop(0)
                callback(*callback_args)
                self.assertEqual(5, len(fake_downloads.downloads))
                self.assertEqual([], callbacks)

            self.assertEqual([
                ("peer", "folder\\file0.mp3", "dest:peer:folder", 0, {"duration": 0}),
                ("peer", "folder\\file1.mp3", "dest:peer:folder", 1, {"duration": 1}),
                ("peer", "folder\\file2.mp3", "dest:peer:folder", 2, {"duration": 2}),
                ("peer", "folder\\file3.mp3", "dest:peer:folder", 3, {"duration": 3}),
                ("peer", "folder\\file4.mp3", "dest:peer:folder", 4, {"duration": 4})
            ], fake_downloads.downloads)

        finally:
            Search.MAX_SEARCH_FOLDER_DOWNLOAD_FILES_PER_TICK = old_limit
            core.downloads = old_downloads
