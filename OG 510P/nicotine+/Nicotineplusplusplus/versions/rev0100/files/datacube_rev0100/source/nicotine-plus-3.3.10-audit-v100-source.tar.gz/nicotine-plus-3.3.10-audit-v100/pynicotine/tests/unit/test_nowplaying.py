# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

import sys
import types

from unittest import TestCase

from pynicotine.nowplaying import NowPlaying


class DummyLastFMNowPlaying(NowPlaying):

    __slots__ = ()

    def lastfm(self, _username):
        self.title["title"] = "Song"
        return True


class NowPlayingTest(TestCase):

    def test_program_placeholder_is_available_for_non_mpris_players(self):
        now_playing = DummyLastFMNowPlaying()

        title = now_playing.get_np(
            get_player=lambda: "lastfm",
            get_command=lambda: "ignored",
            get_format=lambda: "$p - $t"
        )

        self.assertEqual(" - Song", title)

    def test_mpris_reads_xesam_track_number(self):
        metadata = {
            "xesam:artist": ["Artist"],
            "xesam:title": "Title",
            "xesam:trackNumber": 7,
            "mpris:length": 180000000
        }

        class FakeProxy:
            def Get(self, *_args):
                return metadata

        class FakeDBusProxy:
            @staticmethod
            def new_for_bus_sync(**_kwargs):
                return FakeProxy()

        fake_gio = types.SimpleNamespace(
            BusType=types.SimpleNamespace(SESSION=0),
            DBusProxyFlags=types.SimpleNamespace(NONE=0),
            DBusProxy=FakeDBusProxy
        )
        fake_gi = types.ModuleType("gi")
        fake_repository = types.ModuleType("gi.repository")
        fake_repository.Gio = fake_gio
        fake_gi.repository = fake_repository

        old_gi = sys.modules.get("gi")
        old_repository = sys.modules.get("gi.repository")

        try:
            sys.modules["gi"] = fake_gi
            sys.modules["gi.repository"] = fake_repository

            now_playing = NowPlaying()
            self.assertTrue(now_playing.mpris("fakeplayer"))

        finally:
            if old_gi is None:
                sys.modules.pop("gi", None)
            else:
                sys.modules["gi"] = old_gi

            if old_repository is None:
                sys.modules.pop("gi.repository", None)
            else:
                sys.modules["gi.repository"] = old_repository

        self.assertEqual("7", now_playing.title["track"])

    def test_now_playing_truncates_custom_command_output(self):
        now_playing = NowPlaying()
        old_limit = NowPlaying.MAX_NOW_PLAYING_FIELD_BYTES

        try:
            NowPlaying.MAX_NOW_PLAYING_FIELD_BYTES = 16
            now_playing._set_title_field("nowplaying", "x" * 100)
            self.assertLessEqual(len(now_playing.title["nowplaying"].encode("utf-8")), 16)
        finally:
            NowPlaying.MAX_NOW_PLAYING_FIELD_BYTES = old_limit

    def test_mpris_metadata_list_is_bounded_before_join(self):
        class ExplodingIterable:
            def __iter__(self):
                while True:
                    yield "ArtistName"

        old_items = NowPlaying.MAX_MPRIS_LIST_ITEMS
        old_field = NowPlaying.MAX_NOW_PLAYING_FIELD_BYTES

        try:
            NowPlaying.MAX_MPRIS_LIST_ITEMS = 2
            NowPlaying.MAX_NOW_PLAYING_FIELD_BYTES = 64
            joined = NowPlaying._join_mpris_values(ExplodingIterable())
        finally:
            NowPlaying.MAX_MPRIS_LIST_ITEMS = old_items
            NowPlaying.MAX_NOW_PLAYING_FIELD_BYTES = old_field

        self.assertEqual("ArtistName+ArtistName", joined)
