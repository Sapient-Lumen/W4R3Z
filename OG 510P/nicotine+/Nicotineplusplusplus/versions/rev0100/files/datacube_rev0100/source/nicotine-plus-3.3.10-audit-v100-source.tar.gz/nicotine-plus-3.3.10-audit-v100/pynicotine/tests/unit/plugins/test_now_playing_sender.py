# COPYRIGHT (C) 2026 Nicotine+ Contributors

import importlib
import sys
import types

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch


class NowPlayingSenderPluginTest(TestCase):

    @classmethod
    def setUpClass(cls):
        cls._old_gi = sys.modules.get("gi")
        cls._old_gi_repository = sys.modules.get("gi.repository")

        gi_module = types.ModuleType("gi")
        repository_module = types.ModuleType("gi.repository")

        class FakeBusType:
            SESSION = object()

        class FakeDBusSignalFlags:
            NONE = object()

        class FakeGio:
            BusType = FakeBusType
            DBusSignalFlags = FakeDBusSignalFlags
            DBusProxyFlags = SimpleNamespace(NONE=object())
            bus_get_sync = Mock(return_value=SimpleNamespace(
                signal_subscribe=Mock(return_value=1), signal_unsubscribe=Mock()))
            DBusProxy = SimpleNamespace(new_sync=Mock())

        repository_module.Gio = FakeGio
        gi_module.repository = repository_module
        sys.modules["gi"] = gi_module
        sys.modules["gi.repository"] = repository_module

        cls.module = importlib.import_module("pynicotine.plugins.now_playing_sender")
        cls.Plugin = cls.module.Plugin

    @classmethod
    def tearDownClass(cls):
        sys.modules.pop("pynicotine.plugins.now_playing_sender", None)

        if cls._old_gi is None:
            sys.modules.pop("gi", None)
        else:
            sys.modules["gi"] = cls._old_gi

        if cls._old_gi_repository is None:
            sys.modules.pop("gi.repository", None)
        else:
            sys.modules["gi.repository"] = cls._old_gi_repository

    def _plugin(self):
        plugin = self.Plugin()
        plugin.core = SimpleNamespace(now_playing=SimpleNamespace(get_np=Mock(return_value="now playing")))
        plugin.config = SimpleNamespace(sections={"players": {"npothercommand": "", "npplayer": "mpris"}})
        plugin.send_public = Mock()
        plugin.log = Mock()
        return plugin

    def test_send_now_playing_resolves_once_and_batches_unique_rooms(self):
        plugin = self._plugin()
        plugin.settings["rooms"] = ["room1", "room2", "room1", "room3", "room4"]

        old_per_tick = self.Plugin.MAX_BROADCAST_ROOMS_PER_TICK
        old_max_rooms = self.Plugin.MAX_BROADCAST_ROOMS
        self.Plugin.MAX_BROADCAST_ROOMS_PER_TICK = 2
        self.Plugin.MAX_BROADCAST_ROOMS = 4

        fake_events = SimpleNamespace(schedule=Mock(return_value=101), cancel_scheduled=Mock())

        try:
            with patch.object(self.module, "events", fake_events):
                plugin.send_now_playing()

                plugin.core.now_playing.get_np.assert_called_once()
                self.assertEqual(
                    [("room1", "now playing"), ("room2", "now playing")],
                    [call.args for call in plugin.send_public.call_args_list]
                )
                self.assertEqual(["room3", "room4"], list(plugin.pending_broadcast_rooms))
                fake_events.schedule.assert_called_once()

                plugin._process_broadcast_queue()

            self.assertEqual(
                [("room1", "now playing"), ("room2", "now playing"),
                 ("room3", "now playing"), ("room4", "now playing")],
                [call.args for call in plugin.send_public.call_args_list]
            )
            self.assertFalse(plugin.pending_broadcast_rooms)

        finally:
            self.Plugin.MAX_BROADCAST_ROOMS_PER_TICK = old_per_tick
            self.Plugin.MAX_BROADCAST_ROOMS = old_max_rooms

    def test_send_now_playing_caps_configured_rooms(self):
        plugin = self._plugin()
        plugin.settings["rooms"] = ["room1", "room2", "room3"]

        old_per_tick = self.Plugin.MAX_BROADCAST_ROOMS_PER_TICK
        old_max_rooms = self.Plugin.MAX_BROADCAST_ROOMS
        self.Plugin.MAX_BROADCAST_ROOMS_PER_TICK = 10
        self.Plugin.MAX_BROADCAST_ROOMS = 2

        try:
            plugin.send_now_playing()

            self.assertEqual(
                [("room1", "now playing"), ("room2", "now playing")],
                [call.args for call in plugin.send_public.call_args_list]
            )
            plugin.log.assert_called_once()

        finally:
            self.Plugin.MAX_BROADCAST_ROOMS_PER_TICK = old_per_tick
            self.Plugin.MAX_BROADCAST_ROOMS = old_max_rooms

    def test_oversized_mpris_url_is_ignored_before_storage(self):
        plugin = self._plugin()
        old_limit = self.Plugin.MAX_MPRIS_URL_CHARS
        self.Plugin.MAX_MPRIS_URL_CHARS = 4

        try:
            plugin.song_change(None, None, None, None, None, [None, {"Metadata": {"xesam:url": "x" * 5}}], None)
            self.assertEqual("", plugin.last_song_url)
            plugin.send_public.assert_not_called()

        finally:
            self.Plugin.MAX_MPRIS_URL_CHARS = old_limit
