# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

import pynicotine.watchbatch as watchbatch_module
from pynicotine.watchbatch import WatchUserBatcher


class WatchUserBatcherTest(TestCase):

    # pylint: disable=protected-access

    def test_queue_processes_first_batch_and_schedules_remainder(self):
        scheduled_callbacks = []
        watch_user = Mock()

        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )
        fake_core = SimpleNamespace(users=SimpleNamespace(watch_user=watch_user))
        batcher = WatchUserBatcher(
            context="test-context",
            contains_user=lambda username: username != "removed",
            max_users_per_tick=lambda: 2,
            max_pending_users=lambda: 5
        )

        with patch.object(watchbatch_module, "core", fake_core), patch.object(watchbatch_module, "events", fake_events):
            batcher.queue(["user1", "user2", "removed", "user3", "user4"])

            self.assertEqual([
                (("user1",), {"context": "test-context"}),
                (("user2",), {"context": "test-context"})
            ], [(call.args, call.kwargs) for call in watch_user.call_args_list])
            self.assertEqual(1, len(scheduled_callbacks))

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

            self.assertEqual([
                (("user1",), {"context": "test-context"}),
                (("user2",), {"context": "test-context"}),
                (("user3",), {"context": "test-context"})
            ], [(call.args, call.kwargs) for call in watch_user.call_args_list])
            self.assertEqual(1, len(scheduled_callbacks))

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        self.assertEqual([
            (("user1",), {"context": "test-context"}),
            (("user2",), {"context": "test-context"}),
            (("user3",), {"context": "test-context"}),
            (("user4",), {"context": "test-context"})
        ], [(call.args, call.kwargs) for call in watch_user.call_args_list])
        self.assertFalse(batcher._queue)
        self.assertFalse(batcher._queued_users)

    def test_queue_applies_pending_cap_before_processing(self):
        watch_user = Mock()
        fake_events = SimpleNamespace(schedule=Mock(), cancel_scheduled=Mock())
        fake_core = SimpleNamespace(users=SimpleNamespace(watch_user=watch_user))
        fake_log = SimpleNamespace(add_debug=Mock())
        batcher = WatchUserBatcher(
            context="test-context",
            contains_user=lambda _username: True,
            max_users_per_tick=lambda: 1,
            max_pending_users=lambda: 2
        )

        with patch.object(watchbatch_module, "core", fake_core), \
                patch.object(watchbatch_module, "events", fake_events), \
                patch.object(watchbatch_module, "log", fake_log):
            batcher.queue(["user1", "user2", "user3"])

        self.assertEqual(["user1"], [call.args[0] for call in watch_user.call_args_list])
        self.assertEqual(["user2"], list(batcher._queue))
        fake_log.add_debug.assert_called_once()


    def test_retryable_watch_failure_is_requeued(self):
        scheduled_callbacks = []
        calls = []

        class FakeUsers:
            last_watch_failure_retryable = False

            def watch_user(self, username, context=None):
                calls.append((username, context))

                if len(calls) == 1:
                    self.last_watch_failure_retryable = True
                    return False

                self.last_watch_failure_retryable = False
                return True

        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )
        fake_core = SimpleNamespace(users=FakeUsers())
        batcher = WatchUserBatcher(
            context="test-context",
            contains_user=lambda _username: True,
            max_users_per_tick=lambda: 4,
            max_pending_users=lambda: 4
        )

        with patch.object(watchbatch_module, "core", fake_core), patch.object(watchbatch_module, "events", fake_events):
            batcher.queue(["user1", "user2"])

            self.assertEqual([("user1", "test-context")], calls)
            self.assertEqual(["user1", "user2"], list(batcher._queue))
            self.assertEqual(1, len(scheduled_callbacks))
            self.assertEqual(WatchUserBatcher.RETRY_DELAY, scheduled_callbacks[0][0])

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        self.assertEqual([
            ("user1", "test-context"),
            ("user1", "test-context"),
            ("user2", "test-context")
        ], calls)
        self.assertFalse(batcher._queue)
        self.assertFalse(batcher._queued_users)

    def test_nonretryable_watch_failure_is_not_requeued(self):
        watch_user = Mock(return_value=False)
        fake_events = SimpleNamespace(schedule=Mock(), cancel_scheduled=Mock())
        fake_core = SimpleNamespace(users=SimpleNamespace(
            watch_user=watch_user, last_watch_failure_retryable=False))
        batcher = WatchUserBatcher(
            context="test-context",
            contains_user=lambda _username: True,
            max_users_per_tick=lambda: 4,
            max_pending_users=lambda: 4
        )

        with patch.object(watchbatch_module, "core", fake_core), patch.object(watchbatch_module, "events", fake_events):
            batcher.queue(["user1", "user2"])

        self.assertEqual(["user1", "user2"], [call.args[0] for call in watch_user.call_args_list])
        self.assertFalse(batcher._queue)
        self.assertFalse(batcher._queued_users)
        fake_events.schedule.assert_not_called()

    def test_module_login_handlers_use_batched_watches(self):
        from pynicotine.buddies import Buddies
        from pynicotine.privatechat import PrivateChat
        from pynicotine.userbrowse import UserBrowse
        from pynicotine.userinfo import UserInfo

        for cls, users_value in (
                (Buddies, {"buddy": object()}),
                (PrivateChat, {"privateuser"}),
                (UserBrowse, {"browseuser": object()}),
                (UserInfo, {"infouser"})):
            obj = object.__new__(cls)
            obj.users = users_value
            obj._server_login_watch_batcher = SimpleNamespace(queue=Mock(), cancel=Mock())
            obj._server_login(SimpleNamespace(success=True))
            obj._server_login_watch_batcher.queue.assert_called_once_with(users_value)
