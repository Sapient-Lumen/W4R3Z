# COPYRIGHT (C) 2020-2025 Nicotine+ Contributors
# COPYRIGHT (C) 2016-2017 Michael Labouebe <gfarmerfr@free.fr>
# COPYRIGHT (C) 2016 Mutnick <muhing@yahoo.com>
# COPYRIGHT (C) 2013 eLvErDe <gandalf@le-vert.net>
# COPYRIGHT (C) 2008-2012 quinox <quinox@users.sf.net>
# COPYRIGHT (C) 2009 hedonist <ak@sensi.org>
# COPYRIGHT (C) 2006-2009 daelstorm <daelstorm@gmail.com>
# COPYRIGHT (C) 2003-2004 Hyriand <hyriand@thegraveyard.org>
# COPYRIGHT (C) 2001-2003 Alexander Kanavin
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import errno
import heapq
import os
import re
import shutil
import stat
import time

try:
    # Try faster module import first, if available
    from _md5 import md5  # pylint: disable=import-private-name
except ImportError:
    from hashlib import md5

from collections import defaultdict, deque

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.slskmessages import ConnectionType
from pynicotine.slskmessages import DownloadFile
from pynicotine.slskmessages import FileOffset
from pynicotine.slskmessages import FOLDER_TOKENS_ALLOWED
from pynicotine.slskmessages import FolderContentsRequest
from pynicotine.slskmessages import FolderContentsResponse
from pynicotine.slskmessages import increment_token
from pynicotine.slskmessages import initial_token
from pynicotine.slskmessages import PlaceInQueueRequest
from pynicotine.slskmessages import QueueUpload
from pynicotine.slskmessages import SetDownloadLimit
from pynicotine.slskmessages import TransferDirection
from pynicotine.slskmessages import TransferRejectReason
from pynicotine.slskmessages import TransferResponse
from pynicotine.slskmessages import UserStatus
from pynicotine.transfers import Transfer
from pynicotine.transfers import Transfers
from pynicotine.transfers import TransferStatus
from pynicotine.utils import execute_command
from pynicotine.utils import clean_file
from pynicotine.utils import clean_path
from pynicotine.utils import encode_path
from pynicotine.utils import truncate_string_byte


class RequestedFolder:
    __slots__ = ("username", "folder_path", "download_folder_path", "request_timer_id", "has_retried",
                 "legacy_attempt", "token")

    def __init__(self, username, folder_path, download_folder_path):
        self.username = username
        self.folder_path = folder_path
        self.download_folder_path = download_folder_path
        self.request_timer_id = None
        self.has_retried = False
        self.legacy_attempt = False
        self.token = None


class PendingFolderDownload:
    __slots__ = ("username", "folder_path", "destination_folder_path", "files", "file_index")

    def __init__(self, username, folder_path, destination_folder_path, files):
        self.username = username
        self.folder_path = folder_path
        self.destination_folder_path = destination_folder_path
        self.files = files
        self.file_index = 0


class Downloads(Transfers):
    __slots__ = ("_requested_folders", "_requested_folder_token", "_folder_basename_byte_limits",
                 "_pending_queue_messages", "_pending_queue_flush_timer_id",
                 "_pending_folder_downloads", "_pending_folder_download_timer_id",
                 "_pending_download_folder_counts", "_pending_download_folder_transfer_keys",
                 "_bulk_download_action_queue", "_bulk_download_action_timer_id",
                 "_bulk_download_clear_all_state",
                 "_finished_command_queue", "_finished_command_timer_id",
                 "_finished_command_bytes", "_finished_command_limit_logged",
                 "_download_filter_regex", "_download_filter_regex_pattern",
                 "_download_filter_limit_logged",
                 "_queue_position_request_iterator", "_queue_position_request_retry_queue",
                 "_queue_position_request_retry_keys", "_queue_position_request_retry_timer_id",
                 "_queue_position_request_retry_limit_logged", "_download_queue_limit_logged",
                 "_retry_connection_downloads_continuation_timer_id",
                 "_retry_io_downloads_continuation_timer_id",
                 "_user_status_resume_queue", "_user_status_resume_users",
                 "_user_status_resume_timer_id",
                 "_user_status_offline_queue", "_user_status_offline_users",
                 "_user_status_offline_timer_id",
                 "_limited_download_resume_queue", "_limited_download_resume_users",
                 "_limited_download_resume_timer_id",
                 "_download_queue_timer_id", "_retry_connection_downloads_timer_id",
                 "_retry_io_downloads_timer_id")

    MAX_QUEUE_POSITION_REQUESTS_PER_TICK = 1000
    MAX_PENDING_QUEUE_POSITION_REQUEST_RETRIES = 200000
    MAX_PENDING_QUEUE_MESSAGES_PER_READY_TICK = 1000
    MAX_FAILED_DOWNLOAD_RETRIES_PER_TICK = 1000
    MAX_FILENAME_CONFLICT_ATTEMPTS = 4096
    MAX_HASHED_FILENAME_CONFLICT_ATTEMPTS = 32
    MAX_PENDING_FOLDER_REQUESTS = 8192
    MAX_PENDING_FOLDER_REQUESTS_PER_USER = 1024
    MAX_TOTAL_DOWNLOADS = 200000
    MAX_FOLDER_DOWNLOAD_FILES_PER_TICK = 1000
    MAX_PENDING_FOLDER_DOWNLOAD_JOBS = 512
    MAX_USER_STATUS_DOWNLOAD_RESUMES_PER_TICK = 1000
    MAX_USER_STATUS_DOWNLOAD_OFFLINE_ABORTS_PER_TICK = 1000
    MAX_LIMITED_DOWNLOAD_RESUMES_PER_TICK = 1000
    MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK = 1000
    MAX_PENDING_BULK_DOWNLOAD_ACTIONS = 200000
    MAX_BULK_DOWNLOAD_SOURCE_SCANS_PER_TICK = 5000
    MAX_FINISHED_COMMANDS_PER_TICK = 16
    MAX_PENDING_FINISHED_COMMANDS = 4096
    MAX_PENDING_FINISHED_COMMAND_BYTES = 16 * 1024 * 1024
    MAX_STALE_INCOMPLETE_CLEANUP_FILES = 100000
    MAX_DOWNLOAD_FILTERS = 4096
    MAX_DOWNLOAD_FILTER_ITEM_BYTES = 65536
    MAX_DOWNLOAD_FILTER_PATTERN_BYTES = 1024 * 1024
    MAX_DOWNLOAD_FILTER_ERROR_CHARS = 8192
    MAX_DOWNLOAD_FILTER_NESTED_REPEAT_GROUP_BYTES = 4096
    MAX_DOWNLOAD_FOLDER_COMPONENTS = 128
    MAX_SYNCHRONOUS_CROSS_DEVICE_MOVE_BYTES = 256 * 1024 * 1024

    def __init__(self):

        super().__init__(name="downloads")

        self._requested_folders = defaultdict(dict)
        self._requested_folder_token = initial_token()

        self._folder_basename_byte_limits = {}
        self._pending_queue_messages = {}
        self._pending_queue_flush_timer_id = None
        self._pending_folder_downloads = deque()
        self._pending_folder_download_timer_id = None
        self._pending_download_folder_counts = defaultdict(int)
        self._pending_download_folder_transfer_keys = {}
        self._bulk_download_action_queue = deque()
        self._bulk_download_action_timer_id = None
        self._bulk_download_clear_all_state = None
        self._finished_command_queue = deque()
        self._finished_command_timer_id = None
        self._finished_command_bytes = 0
        self._finished_command_limit_logged = False
        self._download_filter_regex = None
        self._download_filter_regex_pattern = None
        self._download_filter_limit_logged = False
        self._queue_position_request_iterator = None
        self._queue_position_request_retry_queue = deque()
        self._queue_position_request_retry_keys = set()
        self._queue_position_request_retry_timer_id = None
        self._queue_position_request_retry_limit_logged = False
        self._download_queue_limit_logged = False
        self._retry_connection_downloads_continuation_timer_id = None
        self._retry_io_downloads_continuation_timer_id = None
        self._user_status_resume_queue = deque()
        self._user_status_resume_users = set()
        self._user_status_resume_timer_id = None
        self._user_status_offline_queue = deque()
        self._user_status_offline_users = set()
        self._user_status_offline_timer_id = None
        self._limited_download_resume_queue = deque()
        self._limited_download_resume_users = set()
        self._limited_download_resume_timer_id = None

        self._download_queue_timer_id = None
        self._retry_connection_downloads_timer_id = None
        self._retry_io_downloads_timer_id = None

        for event_name, callback in (
            ("download-file-error", self._download_file_error),
            ("file-connection-closed", self._file_connection_closed),
            ("file-transfer-init", self._file_transfer_init),
            ("file-download-progress", self._file_download_progress),
            ("folder-contents-response", self._folder_contents_response),
            ("peer-connection-closed", self._peer_connection_closed),
            ("peer-connection-error", self._peer_connection_error),
            ("peer-message-unsent", self._peer_message_unsent),
            ("peer-request-unsent", self._peer_request_unsent),
            ("peer-response-delivery-failed", self._peer_response_delivery_failed),
            ("place-in-queue-response", self._place_in_queue_response),
            ("set-connection-stats", self._set_connection_stats),
            ("shares-ready", self._shares_ready),
            ("transfer-request", self._transfer_request),
            ("upload-denied", self._upload_denied),
            ("upload-failed", self._upload_failed),
            ("user-status", self._user_status)
        ):
            events.connect(event_name, callback)

    def _start(self):
        super()._start()
        self.update_download_filters()

    def _quit(self):

        self._delete_stale_incomplete_downloads()

        if self._pending_folder_download_timer_id is not None:
            events.cancel_scheduled(self._pending_folder_download_timer_id)
            self._pending_folder_download_timer_id = None

        self._pending_folder_downloads.clear()
        self._cancel_bulk_download_actions()
        self._cancel_finished_commands()
        self._cancel_queue_position_request_retries()

        super()._quit()

        self._pending_download_folder_counts.clear()
        self._pending_download_folder_transfer_keys.clear()
        self._folder_basename_byte_limits.clear()

    @staticmethod
    def _discard_requested_folder_token(requested_folder):
        if requested_folder.token is None:
            return

        FOLDER_TOKENS_ALLOWED.discard((requested_folder.username, requested_folder.token))
        requested_folder.token = None

    @staticmethod
    def _cancel_requested_folder_timer(requested_folder):
        if requested_folder.request_timer_id is None:
            return

        events.cancel_scheduled(requested_folder.request_timer_id)
        requested_folder.request_timer_id = None

    def _complete_requested_folder_response(self, requested_folder):
        self._discard_requested_folder_token(requested_folder)
        self._cancel_requested_folder_timer(requested_folder)

    def _remove_requested_folder(self, requested_folder):
        username = requested_folder.username
        folder_path = requested_folder.folder_path

        self._complete_requested_folder_response(requested_folder)
        user_folders = self._requested_folders.get(username)

        if user_folders is None:
            return

        user_folders.pop(folder_path, None)

        if not user_folders:
            self._requested_folders.pop(username, None)

    def _get_num_requested_folders(self):
        return sum(len(folders) for folders in self._requested_folders.values())

    def _server_login(self, msg):

        if not msg.success:
            return

        super()._server_login(msg)

        # Request queue position of queued downloads every 5 minutes
        self._download_queue_timer_id = events.schedule(
            delay=300, callback=self._request_queue_positions, repeat=True)

        # Retry downloads failed due to connection issues every 3 minutes
        self._retry_connection_downloads_timer_id = events.schedule(
            delay=180, callback=self._retry_failed_connection_downloads, repeat=True)

        # Retry downloads failed due to file I/O errors every 15 minutes
        self._retry_io_downloads_timer_id = events.schedule(
            delay=900, callback=self._retry_failed_io_downloads, repeat=True)

    def _server_disconnect(self, msg):

        super()._server_disconnect(msg)

        for timer_id in (
            self._download_queue_timer_id,
            self._retry_connection_downloads_timer_id,
            self._retry_io_downloads_timer_id,
            self._retry_connection_downloads_continuation_timer_id,
            self._retry_io_downloads_continuation_timer_id,
            self._user_status_resume_timer_id,
            self._user_status_offline_timer_id,
            self._limited_download_resume_timer_id,
            self._pending_queue_flush_timer_id,
            self._pending_folder_download_timer_id,
            self._bulk_download_action_timer_id,
            self._queue_position_request_retry_timer_id
        ):
            events.cancel_scheduled(timer_id)

        self._pending_queue_flush_timer_id = None
        self._pending_folder_downloads.clear()
        self._pending_folder_download_timer_id = None
        self._bulk_download_action_queue.clear()
        self._bulk_download_action_timer_id = None
        self._bulk_download_clear_all_state = None
        self._queue_position_request_retry_queue.clear()
        self._queue_position_request_retry_keys.clear()
        self._queue_position_request_retry_timer_id = None
        self._queue_position_request_retry_limit_logged = False
        self._retry_connection_downloads_continuation_timer_id = None
        self._retry_io_downloads_continuation_timer_id = None
        self._user_status_resume_queue.clear()
        self._user_status_resume_users.clear()
        self._user_status_resume_timer_id = None
        self._user_status_offline_queue.clear()
        self._user_status_offline_users.clear()
        self._user_status_offline_timer_id = None
        self._limited_download_resume_queue.clear()
        self._limited_download_resume_users.clear()
        self._limited_download_resume_timer_id = None

        for user_requested_folders in self._requested_folders.values():
            for requested_folder in user_requested_folders.values():
                self._discard_requested_folder_token(requested_folder)

                if requested_folder.request_timer_id is None:
                    continue

                events.cancel_scheduled(requested_folder.request_timer_id)
                requested_folder.request_timer_id = None

        self._requested_folders.clear()
        self._pending_queue_messages.clear()

    # Load Transfers #

    def _get_transfer_list_file_path(self):

        downloads_file_1_4_2 = os.path.join(config.data_folder_path, "config.transfers.pickle")
        downloads_file_1_4_1 = os.path.join(config.data_folder_path, "transfers.pickle")

        if os.path.exists(encode_path(self.transfers_file_path)):
            # New file format
            return self.transfers_file_path

        if os.path.exists(encode_path(downloads_file_1_4_2)):
            # Nicotine+ 1.4.2+
            return downloads_file_1_4_2

        if os.path.exists(encode_path(downloads_file_1_4_1)):
            # Nicotine <=1.4.1
            return downloads_file_1_4_1

        # Fall back to new file format
        return self.transfers_file_path

    def _load_transfers(self):

        load_func = self._load_transfers_file
        transfers_file_path = self._get_transfer_list_file_path()

        if transfers_file_path != self.transfers_file_path:
            load_func = self._load_legacy_transfers_file

        for transfer in self._get_stored_transfers(transfers_file_path, load_func):
            if not self._can_add_download():
                break

            self._append_transfer(transfer)

            if transfer.status == TransferStatus.USER_LOGGED_OFF:
                # Mark transfer as failed in order to resume it when connected
                self._fail_transfer(transfer)

    # Filters/Limits #

    def _can_add_download(self):

        if len(self.transfers) < self.MAX_TOTAL_DOWNLOADS:
            self._download_queue_limit_logged = False
            return True

        if not self._download_queue_limit_logged:
            log.add_transfer(
                "Download list limit of %s reached, dropping additional queued downloads",
                self.MAX_TOTAL_DOWNLOADS
            )
            self._download_queue_limit_logged = True

        return False

    @classmethod
    def _normalize_download_filter_row(cls, item):
        """Return a bounded (pattern, escaped) tuple, or None for malformed rows.

        Download filters come from persisted config and may be edited/imported
        outside Nicotine+. The compiled composite regex is already capped, but
        sorting and escaping the entire raw list first can still create a
        startup/update cliff. Normalize one row at a time and reject malformed
        or grossly large entries before they reach sorting or regex escaping.
        """

        if not isinstance(item, (list, tuple)) or len(item) != 2:
            return None

        dfilter, escaped = item

        if dfilter is None:
            return None

        dfilter = str(dfilter)

        if len(dfilter.encode("utf-8", "replace")) > cls.MAX_DOWNLOAD_FILTER_ITEM_BYTES:
            return None

        return dfilter, bool(escaped)

    @classmethod
    def _get_limited_download_filters(cls, download_filters):
        """Return up to MAX_DOWNLOAD_FILTERS normalized rows in sorted order.

        heapq.nsmallest() scans the raw iterable but retains only limit+1
        normalized rows, unlike sorted(...), which materializes and sorts every
        saved filter before the cap can help. Returning one extra row lets the
        caller tell whether truncation happened.
        """

        max_filters = cls.MAX_DOWNLOAD_FILTERS

        if max_filters <= 0:
            return [], True

        def iter_normalized_filters():
            for item in download_filters:
                item = cls._normalize_download_filter_row(item)

                if item is not None:
                    yield item

        limited_filters = heapq.nsmallest(max_filters + 1, iter_normalized_filters())
        truncated_filters = len(limited_filters) > max_filters
        return limited_filters[:max_filters], truncated_filters

    def update_download_filters(self):

        failed = {}
        filter_parts = []
        pattern_bytes = len("(\\(") + len(")$)")
        download_filters, truncated_filters = self._get_limited_download_filters(
            config.sections["transfers"].get("downloadfilters", ())
        )
        max_filters = self.MAX_DOWNLOAD_FILTERS

        if truncated_filters and not self._download_filter_limit_logged:
            log.add(
                _("Download filter limit of %(limit)s reached; ignoring additional filters."),
                {"limit": max_filters}
            )
            self._download_filter_limit_logged = True

        if not truncated_filters:
            self._download_filter_limit_logged = False

        for dfilter, escaped in download_filters:

            if escaped:
                dfilter = re.escape(dfilter)
                dfilter = dfilter.replace("\\*", ".*")

            if self._has_potentially_catastrophic_download_filter(dfilter):
                failed[dfilter[:self.MAX_DOWNLOAD_FILTER_ERROR_CHARS]] = ValueError(
                    "nested or overlapping repeat operators are not allowed")
                continue

            try:
                re.compile(f"({dfilter})")

            except re.error as error:
                failed[dfilter[:self.MAX_DOWNLOAD_FILTER_ERROR_CHARS]] = error
                continue

            candidate_size = len(dfilter.encode("utf-8", "replace")) + 1

            if pattern_bytes + candidate_size > self.MAX_DOWNLOAD_FILTER_PATTERN_BYTES:
                if not self._download_filter_limit_logged:
                    log.add(
                        _("Download filter regular expression reached %(limit)s bytes; ignoring additional filters."),
                        {"limit": self.MAX_DOWNLOAD_FILTER_PATTERN_BYTES}
                    )
                    self._download_filter_limit_logged = True
                break

            filter_parts.append(dfilter)
            pattern_bytes += candidate_size

        outfilter = "(\\\\(" + "|".join(filter_parts) + ")$)"

        try:
            compiled_filter = re.compile(outfilter, flags=re.IGNORECASE)

        except re.error as error:
            # Strange that individual filters _and_ the composite filter both fail
            log.add(_("Error: Download Filter failed! Verify your filters. Reason: %s"), error)
            config.sections["transfers"]["downloadregexp"] = ""
            self._download_filter_regex = None
            self._download_filter_regex_pattern = ""
            return

        config.sections["transfers"]["downloadregexp"] = outfilter
        self._download_filter_regex = compiled_filter
        self._download_filter_regex_pattern = outfilter

        # Send error messages for each failed filter to log window, but keep the
        # log payload itself bounded. A corrupt/imported config can contain many
        # invalid filters, and logging every full pattern can become another UI
        # and file-write burst.
        if not failed:
            return

        errors = []
        error_chars = 0

        for dfilter, error in failed.items():
            error_text = f"Filter: {dfilter} Error: {error} "
            error_chars += len(error_text)

            if error_chars > self.MAX_DOWNLOAD_FILTER_ERROR_CHARS:
                errors.append("…")
                break

            errors.append(error_text)

        log.add(_("Error: %(num)d Download filters failed! %(error)s "), {
            "num": len(failed),
            "error": "".join(errors)
        })

    def _get_download_filter_regex(self):
        """Return a cached compiled download-filter regexp."""

        pattern = config.sections["transfers"]["downloadregexp"]

        if not pattern:
            self._download_filter_regex = None
            self._download_filter_regex_pattern = pattern
            return None

        if len(pattern.encode("utf-8", "replace")) > self.MAX_DOWNLOAD_FILTER_PATTERN_BYTES:
            self._download_filter_regex = None
            self._download_filter_regex_pattern = ""
            return None

        if self._has_potentially_catastrophic_download_filter(pattern):
            log.add(_("Error: Download Filter failed! Reason: nested or overlapping repeat operators are not allowed"))
            self._download_filter_regex = None
            self._download_filter_regex_pattern = ""
            return None

        if pattern != self._download_filter_regex_pattern or self._download_filter_regex is None:
            try:
                self._download_filter_regex = re.compile(pattern, flags=re.IGNORECASE)
            except re.error as error:
                log.add(_("Error: Download Filter failed! Verify your filters. Reason: %s"), error)
                self._download_filter_regex = None
                self._download_filter_regex_pattern = ""
                return None

            self._download_filter_regex_pattern = pattern

        return self._download_filter_regex

    @classmethod
    def _has_potentially_catastrophic_download_filter(cls, pattern):
        """Heuristically reject regex shapes prone to catastrophic backtracking.

        Download filters are applied on the hot enqueue path for peer-provided
        virtual paths. Python's stdlib ``re`` engine has no match timeout, so a
        corrupt/imported filter like ``(a+)+$`` can freeze the UI/network path
        even when pattern length/count caps are in place. Keep this check narrow:
        reject groups that both contain repeat operators and are themselves
        repeated, plus adjacent repeated wildcards such as ``.*.*``.
        """

        if not pattern:
            return False

        group_stack = []
        escaped = False
        in_class = False
        last_repeated_atom = False
        previous_group_had_inner_repeat = False
        group_buffer_bytes = 0
        last_atom_was_wildcard = False
        previous_repeated_wildcard = False

        for char in pattern:
            if escaped:
                escaped = False
                previous_group_had_inner_repeat = False
                last_atom_was_wildcard = False
                previous_repeated_wildcard = False
                continue

            if char == "\\":
                escaped = True
                previous_group_had_inner_repeat = False
                last_atom_was_wildcard = False
                continue

            if in_class:
                if char == "]":
                    in_class = False
                    previous_group_had_inner_repeat = False
                    last_atom_was_wildcard = False
                    previous_repeated_wildcard = False
                continue

            if char == "[":
                in_class = True
                previous_group_had_inner_repeat = False
                last_atom_was_wildcard = False
                continue

            if char == "(":
                group_stack.append(False)
                group_buffer_bytes = 0
                previous_group_had_inner_repeat = False
                last_repeated_atom = False
                last_atom_was_wildcard = False
                previous_repeated_wildcard = False
                continue

            if char == ")" and group_stack:
                previous_group_had_inner_repeat = group_stack.pop()
                last_repeated_atom = False
                last_atom_was_wildcard = False
                previous_repeated_wildcard = False
                continue

            if group_stack:
                group_buffer_bytes += len(char.encode("utf-8", "replace"))

                if group_buffer_bytes > cls.MAX_DOWNLOAD_FILTER_NESTED_REPEAT_GROUP_BYTES:
                    # A huge repeated group is not worth attempting on every
                    # transfer path, even if the shape is not obviously nested.
                    return True

            if char in {"*", "+"}:
                if previous_group_had_inner_repeat:
                    return True

                if last_repeated_atom:
                    return True

                if last_atom_was_wildcard and previous_repeated_wildcard:
                    return True

                if group_stack:
                    group_stack[-1] = True

                last_repeated_atom = True
                previous_repeated_wildcard = last_atom_was_wildcard
                last_atom_was_wildcard = False
                previous_group_had_inner_repeat = False
                continue

            if char == "{":
                if previous_group_had_inner_repeat:
                    return True

                if last_repeated_atom:
                    return True

                if last_atom_was_wildcard and previous_repeated_wildcard:
                    return True

                if group_stack:
                    group_stack[-1] = True

                last_repeated_atom = True
                previous_repeated_wildcard = last_atom_was_wildcard
                last_atom_was_wildcard = False
                previous_group_had_inner_repeat = False
                continue

            if char == ".":
                previous_group_had_inner_repeat = False
                last_repeated_atom = False
                last_atom_was_wildcard = True
                continue

            if char not in {"?", "}"}:
                previous_group_had_inner_repeat = False
                last_repeated_atom = False
                last_atom_was_wildcard = False
                previous_repeated_wildcard = False

        return False

    def update_transfer_limits(self):

        events.emit("update-download-limits")

        use_speed_limit = config.sections["transfers"]["use_download_speed_limit"]

        if use_speed_limit == "primary":
            speed_limit = config.sections["transfers"]["downloadlimit"]

        elif use_speed_limit == "alternative":
            speed_limit = config.sections["transfers"]["downloadlimitalt"]

        else:
            speed_limit = 0

        core.send_message_to_network_thread(SetDownloadLimit(speed_limit))

    # Transfer Actions #

    def _update_transfer(self, transfer, update_parent=True):
        events.emit("update-download", transfer, update_parent)

    def _enqueue_transfer(self, transfer, bypass_filter=False):

        username = transfer.username
        virtual_path = transfer.virtual_path
        size = transfer.size

        if not bypass_filter and config.sections["transfers"]["enablefilters"]:
            try:
                downloadregexp = self._get_download_filter_regex()

                if downloadregexp is not None and downloadregexp.search(virtual_path) is not None:
                    log.add_transfer("Filtering: %s", virtual_path)

                    if not self._auto_clear_transfer(transfer):
                        self._abort_transfer(transfer, status=TransferStatus.FILTERED)

                    return False

            except re.error:
                pass

        if UserStatus.OFFLINE in (core.users.login_status, core.users.statuses.get(username)):
            # Either we are offline or the user we want to download from is
            self._abort_transfer(transfer, status=TransferStatus.USER_LOGGED_OFF)
            return False

        log.add_transfer("Adding file %s from user %s to download queue", (virtual_path, username))

        _file_path, file_exists = self.get_complete_download_file_path(
            username, virtual_path, size, transfer.folder_path)

        if file_exists:
            self._finish_transfer(transfer)
            return False

        super()._enqueue_transfer(transfer)
        self._sync_pending_download_folder_transfer(transfer)

        msg = QueueUpload(virtual_path, transfer.legacy_attempt)

        if not core.shares.initialized:
            # Remain queued locally until our shares have initialized, to prevent invalid
            # messages about not sharing any files
            self._pending_queue_messages[transfer] = msg
        elif core.send_message_to_peer(username, msg) is False:
            # Network-thread backpressure can reject non-critical peer messages before they
            # reach any socket/pending-peer queue. Keep the local transfer queued and retry
            # the QueueUpload later instead of silently losing the request and leaving the
            # download stuck in a queued-but-never-requested state.
            self._pending_queue_messages[transfer] = msg
            self._schedule_pending_queue_flush(delay=1)

        return True

    def _schedule_limited_download_resumes(self):

        if (not self._limited_download_resume_queue
                or self._limited_download_resume_timer_id is not None):
            return

        self._limited_download_resume_timer_id = events.schedule(
            delay=0, callback=self._process_limited_download_resumes)

    def _queue_limited_download_resume(self, username):

        if username in self._limited_download_resume_users:
            return

        self._limited_download_resume_users.add(username)
        self._limited_download_resume_queue.append(username)

    def _enqueue_limited_transfers_for_user(self, username, max_downloads):

        queue_size_limit = self._user_queue_limits.get(username)

        if queue_size_limit is None or max_downloads <= 0:
            return 0, False

        processed = 0
        has_more = False
        remaining_limit = min(queue_size_limit, max_downloads)

        for download in tuple(self.failed_users.get(username, {}).values()):
            if download.status != TransferRejectReason.QUEUED:
                continue

            if processed >= remaining_limit:
                has_more = True
                break

            self._unfail_transfer(download)

            if self._enqueue_transfer(download):
                self._update_transfer(download)

            processed += 1

        remaining_user_limit = queue_size_limit - processed

        if remaining_user_limit <= 0 or not has_more:
            self._user_queue_limits.pop(username, None)
            return processed, False

        self._user_queue_limits[username] = remaining_user_limit
        return processed, True

    def _process_limited_download_resumes(self):

        self._limited_download_resume_timer_id = None
        num_processed = 0

        while (self._limited_download_resume_queue
                and num_processed < self.MAX_LIMITED_DOWNLOAD_RESUMES_PER_TICK):
            username = self._limited_download_resume_queue.popleft()
            self._limited_download_resume_users.discard(username)

            processed, has_more = self._enqueue_limited_transfers_for_user(
                username, self.MAX_LIMITED_DOWNLOAD_RESUMES_PER_TICK - num_processed)
            num_processed += processed

            if has_more:
                self._queue_limited_download_resume(username)

        if self._limited_download_resume_queue:
            self._schedule_limited_download_resumes()

    def _enqueue_limited_transfers(self, username):

        self._queue_limited_download_resume(username)

        # Preserve old immediate behavior for small queues, but only up to a
        # per-tick cap. Larger limited-download backlogs continue later instead
        # of being requeued in one synchronous transfer-state callback.
        if self._limited_download_resume_timer_id is None:
            self._process_limited_download_resumes()

    def _dequeue_transfer(self, transfer):

        if not super()._dequeue_transfer(transfer):
            return False

        if transfer in self._pending_queue_messages:
            del self._pending_queue_messages[transfer]

        self._sync_pending_download_folder_transfer(transfer)
        return True

    def _get_pending_download_folder_key(self, transfer):
        folder_path = transfer.folder_path

        if not folder_path:
            return None

        if folder_path == self.get_default_download_folder(transfer.username):
            return None

        return (transfer.username, folder_path)

    def _is_pending_download_folder_transfer(self, transfer):
        username = transfer.username
        virtual_path = transfer.virtual_path

        if self.queued_users.get(username, {}).get(virtual_path) is transfer:
            return True

        if self.failed_users.get(username, {}).get(virtual_path) is transfer:
            return True

        token = transfer.token
        return token is not None and self.active_users.get(username, {}).get(token) is transfer

    def _decrement_pending_download_folder_count(self, folder_key):
        count = self._pending_download_folder_counts.get(folder_key, 0)

        if count <= 1:
            self._pending_download_folder_counts.pop(folder_key, None)
            return

        self._pending_download_folder_counts[folder_key] = count - 1

    def _sync_pending_download_folder_transfer(self, transfer):
        transfer_id = id(transfer)
        old_folder_key = self._pending_download_folder_transfer_keys.get(transfer_id)
        new_folder_key = None

        if self._is_pending_download_folder_transfer(transfer):
            new_folder_key = self._get_pending_download_folder_key(transfer)

        if old_folder_key == new_folder_key:
            return

        if old_folder_key is not None:
            self._decrement_pending_download_folder_count(old_folder_key)
            self._pending_download_folder_transfer_keys.pop(transfer_id, None)

        if new_folder_key is not None:
            self._pending_download_folder_counts[new_folder_key] += 1
            self._pending_download_folder_transfer_keys[transfer_id] = new_folder_key

    def _has_pending_folder_downloads(self, username, folder_path):
        return self._pending_download_folder_counts.get((username, folder_path), 0) > 0

    def _activate_transfer(self, transfer, token):
        if not super()._activate_transfer(transfer, token):
            return False

        self._sync_pending_download_folder_transfer(transfer)
        return True

    def _deactivate_transfer(self, transfer):
        deactivated = super()._deactivate_transfer(transfer)
        self._sync_pending_download_folder_transfer(transfer)
        return deactivated

    def _fail_transfer(self, transfer):
        super()._fail_transfer(transfer)
        self._sync_pending_download_folder_transfer(transfer)

    def _unfail_transfer(self, transfer):
        unfailed = super()._unfail_transfer(transfer)
        self._sync_pending_download_folder_transfer(transfer)
        return unfailed

    def _estimate_finished_command_size(self, command, target_path):
        return (
            len(str(command).encode("utf-8", "replace"))
            + len(str(target_path).encode("utf-8", "replace"))
            + 128
        )

    def _cancel_finished_commands(self):

        if self._finished_command_timer_id is not None:
            events.cancel_scheduled(self._finished_command_timer_id)
            self._finished_command_timer_id = None

        self._finished_command_queue.clear()
        self._finished_command_bytes = 0
        self._finished_command_limit_logged = False

    def _schedule_finished_commands(self):

        if self._finished_command_timer_id is not None or not self._finished_command_queue:
            return

        self._finished_command_timer_id = events.schedule(delay=0, callback=self._process_finished_commands)

        if self._finished_command_timer_id is None:
            # Scheduler saturation should not leave post-download actions stuck.
            # Run one bounded batch synchronously instead of spawning every queued
            # hook process in the file-completion call path.
            self._process_finished_commands(schedule_continuation=False)

    def _queue_finished_command(self, command, target_path, is_folder=False):

        retained_size = self._estimate_finished_command_size(command, target_path)

        if (retained_size > self.MAX_PENDING_FINISHED_COMMAND_BYTES
                or len(self._finished_command_queue) >= self.MAX_PENDING_FINISHED_COMMANDS
                or self._finished_command_bytes + retained_size > self.MAX_PENDING_FINISHED_COMMAND_BYTES):
            if not self._finished_command_limit_logged:
                self._finished_command_limit_logged = True
                log.add(
                    _("Post-download command queue limit reached; dropping additional commands until the backlog drains."))

            return False

        self._finished_command_queue.append((command, target_path, is_folder, retained_size))
        self._finished_command_bytes += retained_size
        self._schedule_finished_commands()
        return True

    def _run_finished_command(self, command, target_path, is_folder):

        try:
            execute_command(command, target_path, hidden=True)

            if is_folder:
                log.add(_("Executed on folder: %s"), command)
            else:
                log.add(_("Executed: %s"), command)

        except Exception as error:
            log.add(_("Executing '%(command)s' failed: %(error)s"), {
                "command": command,
                "error": error
            })

    def _process_finished_commands(self, schedule_continuation=True):

        self._finished_command_timer_id = None
        num_processed = 0

        while self._finished_command_queue and num_processed < self.MAX_FINISHED_COMMANDS_PER_TICK:
            command, target_path, is_folder, retained_size = self._finished_command_queue.popleft()
            self._finished_command_bytes = max(0, self._finished_command_bytes - retained_size)
            self._run_finished_command(command, target_path, is_folder)
            num_processed += 1

        if self._finished_command_bytes < (self.MAX_PENDING_FINISHED_COMMAND_BYTES // 2):
            self._finished_command_limit_logged = False

        if self._finished_command_queue and schedule_continuation:
            self._schedule_finished_commands()

    def _file_downloaded_actions(self, username, file_path):

        if config.sections["notifications"]["notification_popup_file"]:
            core.notifications.show_download_notification(
                _("%(file)s downloaded from %(user)s") % {
                    "user": username,
                    "file": os.path.basename(file_path)
                },
                title=_("File Downloaded")
            )

        command = config.sections["transfers"]["afterfinish"]

        if command:
            self._queue_finished_command(command, file_path)

    def _folder_downloaded_actions(self, username, folder_path):

        if not folder_path:
            return

        if folder_path == self.get_default_download_folder(username):
            return

        if self._has_pending_folder_downloads(username, folder_path):
            return

        events.emit("folder-download-finished", folder_path)

        if config.sections["notifications"]["notification_popup_folder"]:
            core.notifications.show_download_notification(
                _("%(folder)s downloaded from %(user)s") % {
                    "user": username,
                    "folder": folder_path
                },
                title=_("Folder Downloaded")
            )

        command = config.sections["transfers"]["afterfolder"]

        if command:
            self._queue_finished_command(command, folder_path, is_folder=True)

    @classmethod
    def _move_completed_file(cls, incomplete_file_path, download_file_path):
        """Move a completed download without falling into a huge synchronous copy.

        shutil.move() first tries os.rename(), but when the incomplete and
        destination folders are on different filesystems it silently falls back
        to copying the whole file in the caller's thread.  File completion runs
        through the main/core event path, so a multi-GiB cross-device fallback
        can look like an application freeze.  Keep the fast atomic rename path,
        allow small cross-device copies for compatibility, and reject gross
        cross-device copies before starting them.
        """

        try:
            os.replace(incomplete_file_path, download_file_path)
            return

        except OSError as error:
            if error.errno != errno.EXDEV:
                raise

            try:
                source_size = os.path.getsize(incomplete_file_path)
            except OSError:
                source_size = cls.MAX_SYNCHRONOUS_CROSS_DEVICE_MOVE_BYTES + 1

            if source_size > cls.MAX_SYNCHRONOUS_CROSS_DEVICE_MOVE_BYTES:
                raise OSError(
                    errno.EXDEV,
                    "completed file is on a different filesystem and is too large "
                    "to copy synchronously; configure incomplete and download folders "
                    "on the same filesystem or move the file manually"
                ) from error

            shutil.move(incomplete_file_path, download_file_path)

    def _move_finished_transfer(self, transfer, incomplete_file_path):

        download_folder_path = transfer.folder_path or self.get_default_download_folder(transfer.username)
        download_folder_path_encoded = encode_path(download_folder_path)
        download_file_path = download_folder_path

        try:
            if not os.path.isdir(download_folder_path_encoded):
                os.makedirs(download_folder_path_encoded)

            download_basename = self.get_download_basename(
                transfer.virtual_path, download_folder_path, avoid_conflict=True)
            download_file_path = os.path.join(download_folder_path, download_basename)

            if os.path.exists(encode_path(download_file_path)):
                raise FileExistsError(download_file_path)

            self._move_completed_file(incomplete_file_path, encode_path(download_file_path))

        except OSError as error:
            if isinstance(incomplete_file_path, bytes):
                h_incomplete_file_path = incomplete_file_path.decode("utf-8", "replace")
            else:
                h_incomplete_file_path = incomplete_file_path

            log.add(
                _("Couldn't move '%(tempfile)s' to '%(file)s': %(error)s"), {
                    "tempfile": h_incomplete_file_path,
                    "file": download_file_path,
                    "error": error
                }
            )
            self._abort_transfer(transfer, status=TransferStatus.DOWNLOAD_FOLDER_ERROR)
            core.notifications.show_download_notification(
                str(error), title=_("Download Folder Error"), high_priority=True
            )
            return None

        return download_file_path

    def _finish_transfer(self, transfer):

        username = transfer.username
        virtual_path = transfer.virtual_path
        already_exists = transfer.file_handle is None
        incomplete_file_path = transfer.file_handle.name if not already_exists else None

        super()._finish_transfer(transfer)

        if not already_exists:
            download_file_path = self._move_finished_transfer(transfer, incomplete_file_path)

            if download_file_path is None:
                # Download was not moved successfully
                return

        if not self._auto_clear_transfer(transfer):
            self._update_transfer(transfer)

        if already_exists:
            log.add_transfer("File %s is already downloaded", virtual_path)
            return

        core.statistics.append_stat_value("completed_downloads", 1)

        # Attempt to show notification and execute commands
        self._file_downloaded_actions(username, download_file_path)
        self._folder_downloaded_actions(username, transfer.folder_path)

        core.pluginhandler.download_finished_notification(username, virtual_path, download_file_path)

        log.add_download(
            _("Download finished: user %(user)s, file %(file)s"), {
                "user": username,
                "file": virtual_path
            }
        )

    def _emit_batched_aborted_transfers(self, transfers, status):
        events.emit("abort-downloads", transfers, status)

    def _abort_transfer(self, transfer, status=None, denied_message=None, update_parent=True):

        if transfer.file_handle is not None:
            log.add_download(
                _("Download aborted, user %(user)s file %(file)s"), {
                    "user": transfer.username,
                    "file": transfer.virtual_path
                }
            )

        super()._abort_transfer(transfer, status=status, denied_message=denied_message)

        if status:
            events.emit("abort-download", transfer, status, update_parent)

    def _clear_transfer(self, transfer, denied_message=None, update_parent=True):

        virtual_path = transfer.virtual_path
        username = transfer.username

        log.add_transfer("Clearing download %s from user %s", (virtual_path, username))

        try:
            super()._clear_transfer(transfer, denied_message=denied_message)

        except KeyError:
            log.add("FIXME: failed to remove download %s from user %s, not present in list",
                    (virtual_path, username))

        events.emit("clear-download", transfer, update_parent)

    @staticmethod
    def _open_incomplete_download_file(incomplete_file_path):
        """Open an incomplete download without following stale special paths."""

        incomplete_file_path_encoded = encode_path(incomplete_file_path)

        def opener(file_path, flags):
            if hasattr(os, "O_BINARY"):
                flags |= os.O_BINARY

            if hasattr(os, "O_NOFOLLOW"):
                flags |= os.O_NOFOLLOW

            return os.open(file_path, flags, 0o666)

        file_handle = open(  # pylint: disable=consider-using-with
            incomplete_file_path_encoded, "ab+", opener=opener)

        try:
            file_stat = os.fstat(file_handle.fileno())

            if not stat.S_ISREG(file_stat.st_mode):
                raise OSError("incomplete download path is not a regular file")

            try:
                import fcntl
                fcntl.lockf(file_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)

            except ImportError:
                pass

            except OSError as error:
                raise OSError(f"can't get an exclusive lock: {error}") from error

            return file_handle

        except Exception:
            file_handle.close()
            raise

    @staticmethod
    def _is_incomplete_download_basename(basename):
        prefix = b"INCOMPLETE"
        prefix_len = len(prefix)
        md5_len = 32

        return (
            basename.startswith(prefix)
            and len(basename) > (prefix_len + md5_len)
            and re.match(b"[0-9a-f]{32}", basename[prefix_len:prefix_len + md5_len], flags=re.IGNORECASE)
        )

    def _get_stale_incomplete_candidates(self, incomplete_download_folder_path):
        candidate_paths = set()

        try:
            with os.scandir(encode_path(incomplete_download_folder_path)) as entries:
                for entry in entries:
                    if entry.is_dir(follow_symlinks=False):
                        continue

                    if not self._is_incomplete_download_basename(entry.name):
                        continue

                    candidate_paths.add(entry.path)

                    if len(candidate_paths) >= self.MAX_STALE_INCOMPLETE_CLEANUP_FILES:
                        log.add_transfer(
                            "Found at least %s stale incomplete download candidates; "
                            "remaining files will be checked on a later shutdown",
                            self.MAX_STALE_INCOMPLETE_CLEANUP_FILES
                        )
                        break

        except OSError as error:
            log.add_transfer("Cannot read incomplete download folder: %s", error)

        return candidate_paths

    def _delete_stale_incomplete_downloads(self):

        if not self._allow_saving_transfers:
            return

        incomplete_download_folder_path = self.get_incomplete_download_folder()
        candidate_paths = self._get_stale_incomplete_candidates(incomplete_download_folder_path)

        if not candidate_paths:
            return

        for transfer in self.transfers.values():
            if not transfer.current_byte_offset or transfer.status == TransferStatus.FINISHED:
                continue

            for incomplete_file_path in self.get_incomplete_download_file_paths(
                    transfer.username, transfer.virtual_path):
                candidate_paths.discard(encode_path(incomplete_file_path))

            if not candidate_paths:
                return

        for file_path in candidate_paths:
            # Incomplete file no longer has a download associated with it. Delete it.
            try:
                os.remove(file_path)
                log.add_transfer("Deleted stale incomplete download %s", file_path)

            except OSError as error:
                log.add_transfer("Cannot delete incomplete download %s: %s", (file_path, error))

    def _cancel_queue_position_request_retries(self):
        events.cancel_scheduled(self._queue_position_request_retry_timer_id)
        self._queue_position_request_retry_timer_id = None
        self._queue_position_request_retry_queue.clear()
        self._queue_position_request_retry_keys.clear()
        self._queue_position_request_retry_limit_logged = False

    def _is_queued_download(self, transfer):
        return self.queued_users.get(transfer.username, {}).get(transfer.virtual_path) is transfer

    def _queue_queue_position_request_retry(self, transfer):
        key = (transfer.username, transfer.virtual_path)

        if key in self._queue_position_request_retry_keys:
            return True

        if len(self._queue_position_request_retry_queue) >= self.MAX_PENDING_QUEUE_POSITION_REQUEST_RETRIES:
            if not self._queue_position_request_retry_limit_logged:
                log.add_transfer(
                    "Queue-position request retry backlog reached %s downloads; dropping additional retries",
                    self.MAX_PENDING_QUEUE_POSITION_REQUEST_RETRIES
                )
                self._queue_position_request_retry_limit_logged = True

            return False

        self._queue_position_request_retry_queue.append(transfer)
        self._queue_position_request_retry_keys.add(key)
        return True

    def _schedule_queue_position_request_retries(self, delay=0):

        if self._queue_position_request_retry_timer_id is not None:
            return

        self._queue_position_request_retry_timer_id = events.schedule(
            delay=delay, callback=self._process_queue_position_request_retries)

        if self._queue_position_request_retry_timer_id is None:
            self._queue_position_request_retry_queue.clear()
            self._queue_position_request_retry_keys.clear()

    def _send_queue_position_request(self, transfer):
        return core.send_message_to_peer(
            transfer.username,
            PlaceInQueueRequest(transfer.virtual_path, transfer.legacy_attempt)
        ) is not False

    def _process_queue_position_request_retries(self):
        self._queue_position_request_retry_timer_id = None
        num_requested = 0

        while (self._queue_position_request_retry_queue
                and num_requested < self.MAX_QUEUE_POSITION_REQUESTS_PER_TICK):
            transfer = self._queue_position_request_retry_queue.popleft()
            self._queue_position_request_retry_keys.discard((transfer.username, transfer.virtual_path))

            if not self._is_queued_download(transfer):
                continue

            if not self._send_queue_position_request(transfer):
                self._queue_queue_position_request_retry(transfer)
                self._schedule_queue_position_request_retries(delay=1)
                return

            num_requested += 1

        if self._queue_position_request_retry_queue:
            self._schedule_queue_position_request_retries()
        else:
            self._queue_position_request_retry_limit_logged = False

    def _request_queue_positions(self):

        num_queued_downloads = len(self.queued_transfers)

        if not num_queued_downloads:
            self._queue_position_request_iterator = None
            return

        request_limit = min(self.MAX_QUEUE_POSITION_REQUESTS_PER_TICK, num_queued_downloads)
        num_requested = 0

        if self._queue_position_request_iterator is None:
            self._queue_position_request_iterator = iter(self.queued_transfers)

        while num_requested < request_limit:
            try:
                download = next(self._queue_position_request_iterator)

            except StopIteration:
                self._queue_position_request_iterator = iter(self.queued_transfers)

                try:
                    download = next(self._queue_position_request_iterator)

                except StopIteration:
                    self._queue_position_request_iterator = None
                    break

            except RuntimeError:
                # The queue changed while the saved iterator was active. Restart
                # from the current queue rather than materializing a huge snapshot.
                self._queue_position_request_iterator = iter(self.queued_transfers)
                continue

            if not self._send_queue_position_request(download):
                self._queue_queue_position_request_retry(download)
                self._schedule_queue_position_request_retries(delay=1)
                break

            num_requested += 1

        if num_requested < num_queued_downloads:
            log.add_transfer(
                "Requested queue positions for %(num_requested)s of %(num_total)s queued downloads; "
                "remaining requests will be spread across later checks", {
                    "num_requested": num_requested,
                    "num_total": num_queued_downloads
                }
            )

    def _retry_failed_downloads(self, statuses):
        """Retry a bounded number of failed downloads.

        Large queues can accumulate many failed transfers. Timer callbacks run
        on the main thread, so retry work is capped and continuation callbacks
        spread catch-up work across later main-loop turns.
        """

        downloads = []
        limit = self.MAX_FAILED_DOWNLOAD_RETRIES_PER_TICK

        for failed_downloads in self.failed_users.values():
            for download in failed_downloads.values():
                if download.status not in statuses:
                    continue

                downloads.append(download)

                if len(downloads) >= limit:
                    break

            if len(downloads) >= limit:
                break

        for download in downloads:
            self._unfail_transfer(download)

            if self._enqueue_transfer(download):
                self._update_transfer(download)

        return len(downloads) >= limit

    def _schedule_retry_failed_connection_downloads(self):

        if self._retry_connection_downloads_continuation_timer_id is not None:
            return

        self._retry_connection_downloads_continuation_timer_id = events.schedule(
            delay=0, callback=self._retry_failed_connection_downloads)

    def _schedule_retry_failed_io_downloads(self):

        if self._retry_io_downloads_continuation_timer_id is not None:
            return

        self._retry_io_downloads_continuation_timer_id = events.schedule(
            delay=0, callback=self._retry_failed_io_downloads)

    def _retry_failed_connection_downloads(self):

        self._retry_connection_downloads_continuation_timer_id = None
        statuses = {
            TransferStatus.CONNECTION_CLOSED, TransferStatus.CONNECTION_TIMEOUT, TransferRejectReason.PENDING_SHUTDOWN}

        if self._retry_failed_downloads(statuses):
            self._schedule_retry_failed_connection_downloads()

    def _retry_failed_io_downloads(self):

        self._retry_io_downloads_continuation_timer_id = None
        statuses = {
            TransferStatus.DOWNLOAD_FOLDER_ERROR, TransferStatus.LOCAL_FILE_ERROR, TransferRejectReason.FILE_READ_ERROR}

        if self._retry_failed_downloads(statuses):
            self._schedule_retry_failed_io_downloads()

    def can_upload(self, username):

        transfers = config.sections["transfers"]

        if not transfers["remotedownloads"]:
            return False

        if transfers["uploadallowed"] == 1:
            # Everyone
            return True

        if transfers["uploadallowed"] == 2 and username in core.buddies.users:
            # Buddies
            return True

        if transfers["uploadallowed"] == 3:
            # Trusted buddies
            user_data = core.buddies.users.get(username)

            if user_data and user_data.is_trusted:
                return True

        return False

    def get_folder_destination(self, username, folder_path, root_folder_path=None, download_folder_path=None):

        # Remove parent folders of the requested folder from path
        parent_folder_path = root_folder_path if root_folder_path else folder_path
        virtual_folder_path = folder_path.replace("/", "\\")
        removed_parent_folders = parent_folder_path.replace("/", "\\").rpartition("\\")[0]

        if removed_parent_folders and virtual_folder_path.startswith(removed_parent_folders + "\\"):
            target_folders = virtual_folder_path[len(removed_parent_folders) + 1:]
        else:
            target_folders = virtual_folder_path

        raw_folder_names = [folder_name for folder_name in target_folders.split("\\") if folder_name]

        if not raw_folder_names:
            raw_folder_names = [target_folders]

        # Check if a custom download location was specified
        if not download_folder_path:
            requested_folder = self._requested_folders.get(username, {}).get(folder_path)

            if requested_folder is not None and requested_folder.download_folder_path:
                download_folder_path = requested_folder.download_folder_path
            else:
                download_folder_path = self.get_default_download_folder(username)

        max_bytes = self.get_basename_byte_limit(download_folder_path)
        target_folder_names = []

        for folder_name in raw_folder_names[:self.MAX_DOWNLOAD_FOLDER_COMPONENTS]:
            cleaned_folder_name = clean_file(folder_name)
            cleaned_folder_name = truncate_string_byte(cleaned_folder_name, max_bytes).rstrip(". ")
            target_folder_names.append(cleaned_folder_name or clean_file(""))

        if len(raw_folder_names) > self.MAX_DOWNLOAD_FOLDER_COMPONENTS:
            overflow_name = self._get_hashed_conflict_suffix(folder_path, len(raw_folder_names)).strip()
            target_folder_names.append(truncate_string_byte(clean_file(overflow_name), max_bytes) or clean_file(""))

        # Merge download path with sanitized virtual folder names. Remote peers provide
        # virtual folder paths, so never pass components such as '..' through to the local
        # filesystem when recursively downloading a folder. Also cap each local path
        # component before os.makedirs() sees it; protocol string caps are intentionally
        # larger than common filesystem component limits.
        return os.path.join(download_folder_path, *target_folder_names)

    def get_default_download_folder(self, username=None):

        download_folder_path = os.path.normpath(os.path.expandvars(config.sections["transfers"]["downloaddir"]))

        # Check if username subfolders should be created for downloads
        if username and config.sections["transfers"]["usernamesubfolders"]:
            download_folder_path = os.path.join(download_folder_path, clean_file(username))

        return download_folder_path

    def get_incomplete_download_folder(self):
        return os.path.normpath(os.path.expandvars(config.sections["transfers"]["incompletedir"]))

    def get_basename_byte_limit(self, folder_path):

        max_bytes = self._folder_basename_byte_limits.get(folder_path)

        if max_bytes is None:
            try:
                max_bytes = os.statvfs(encode_path(folder_path)).f_namemax

            except (AttributeError, OSError):
                max_bytes = 255

            self._folder_basename_byte_limits[folder_path] = max_bytes

        return max_bytes

    @staticmethod
    def _split_download_basename(virtual_path):
        basename = clean_file(virtual_path.rpartition("\\")[-1])
        basename_no_extension, separator, extension = basename.rpartition(".")
        return basename_no_extension, separator + extension

    @staticmethod
    def _format_conflict_basename(basename_no_extension, extension, suffix, max_bytes):
        suffix_bytes = suffix.encode()

        if len(suffix_bytes) >= max_bytes:
            candidate = truncate_string_byte(suffix.strip() or suffix, max_bytes)
            return candidate or clean_file("")

        extension_limit = max(0, max_bytes - len(suffix_bytes))
        extension_was_truncated = len(extension.encode()) > extension_limit
        extension = truncate_string_byte(extension, extension_limit)
        basename_limit = 0 if extension_was_truncated else max_bytes - len(suffix_bytes) - len(extension.encode())
        basename_no_extension = truncate_string_byte(basename_no_extension, max(0, basename_limit))

        return basename_no_extension + suffix + extension

    @staticmethod
    def _get_hashed_conflict_suffix(*values):
        md5sum = md5()

        for value in values:
            value = str(value)
            value_bytes = value.encode()
            md5sum.update(len(value_bytes).to_bytes(8, "big"))
            md5sum.update(value_bytes)

        return f" ({md5sum.hexdigest()[:12]})"

    @staticmethod
    def _file_size_matches(file_path, size):
        try:
            return os.stat(encode_path(file_path)).st_size == size

        except OSError:
            return False

    def get_download_basename(self, virtual_path, download_folder_path, avoid_conflict=False):
        """Returns the download basename for a virtual file path."""

        max_bytes = self.get_basename_byte_limit(download_folder_path)
        basename_no_extension, extension = self._split_download_basename(virtual_path)
        corrected_basename = self._format_conflict_basename(basename_no_extension, extension, "", max_bytes)

        if not avoid_conflict:
            return corrected_basename

        corrected_path = os.path.join(download_folder_path, corrected_basename)

        if not os.path.exists(encode_path(corrected_path)):
            return corrected_basename

        for counter in range(1, self.MAX_FILENAME_CONFLICT_ATTEMPTS + 1):
            corrected_basename = self._format_conflict_basename(
                basename_no_extension, extension, f" ({counter})", max_bytes)
            corrected_path = os.path.join(download_folder_path, corrected_basename)

            if not os.path.exists(encode_path(corrected_path)):
                return corrected_basename

        for counter in range(self.MAX_HASHED_FILENAME_CONFLICT_ATTEMPTS):
            suffix = self._get_hashed_conflict_suffix(virtual_path, counter)
            corrected_basename = self._format_conflict_basename(basename_no_extension, extension, suffix, max_bytes)
            corrected_path = os.path.join(download_folder_path, corrected_basename)

            if not os.path.exists(encode_path(corrected_path)):
                return corrected_basename

        raise FileExistsError(f"Unable to find available filename for {virtual_path!r}")

    def get_complete_download_file_path(self, username, virtual_path, size, download_folder_path=None):
        """Returns the download path of a complete download, if available."""

        if not download_folder_path:
            download_folder_path = self.get_default_download_folder(username)

        max_bytes = self.get_basename_byte_limit(download_folder_path)
        basename_no_extension, extension = self._split_download_basename(virtual_path)
        basename = self._format_conflict_basename(basename_no_extension, extension, "", max_bytes)
        download_file_path = os.path.join(download_folder_path, basename)

        if not os.path.exists(encode_path(download_file_path)):
            return download_file_path, False

        if self._file_size_matches(download_file_path, size):
            # Found a previous download with a matching file size
            return download_file_path, True

        for counter in range(1, self.MAX_FILENAME_CONFLICT_ATTEMPTS + 1):
            basename = self._format_conflict_basename(basename_no_extension, extension, f" ({counter})", max_bytes)
            download_file_path = os.path.join(download_folder_path, basename)

            if not os.path.exists(encode_path(download_file_path)):
                return download_file_path, False

            if self._file_size_matches(download_file_path, size):
                # Found a previous download with a matching file size
                return download_file_path, True

        for counter in range(self.MAX_HASHED_FILENAME_CONFLICT_ATTEMPTS):
            suffix = self._get_hashed_conflict_suffix(username, virtual_path, size, counter)
            basename = self._format_conflict_basename(basename_no_extension, extension, suffix, max_bytes)
            download_file_path = os.path.join(download_folder_path, basename)

            if not os.path.exists(encode_path(download_file_path)):
                return download_file_path, False

            if self._file_size_matches(download_file_path, size):
                return download_file_path, True

        return download_file_path, False

    @staticmethod
    def _get_incomplete_download_hash(username, virtual_path, legacy=False):
        md5sum = md5()

        if legacy:
            # Preserve access to older incomplete files generated by Nicotine+
            # versions that hashed a simple concatenation. That construction is
            # ambiguous for distinct username/path pairs such as ("ab", "c")
            # and ("a", "bc"), so new files use length-delimited fields.
            md5sum.update((virtual_path + username).encode())
            return md5sum.hexdigest()

        for value in (username, virtual_path):
            value_bytes = value.encode()
            md5sum.update(len(value_bytes).to_bytes(8, "big"))
            md5sum.update(value_bytes)

        return md5sum.hexdigest()

    def get_incomplete_download_file_path(self, username, virtual_path, legacy=False):
        """Returns the path to store a download while it's still
        transferring."""

        prefix = f"INCOMPLETE{self._get_incomplete_download_hash(username, virtual_path, legacy=legacy)}"

        # Ensure file name length doesn't exceed file system limit
        incomplete_folder_path = self.get_incomplete_download_folder()
        max_bytes = self.get_basename_byte_limit(incomplete_folder_path)

        basename = clean_file(virtual_path.rpartition("\\")[-1])
        basename_no_extension, separator, extension = basename.rpartition(".")
        extension = separator + extension
        basename_limit = max_bytes - len(prefix) - len(extension.encode())
        basename_no_extension = truncate_string_byte(basename_no_extension, max(0, basename_limit))

        if basename_limit < 0:
            extension = truncate_string_byte(extension, max_bytes - len(prefix))

        return os.path.join(incomplete_folder_path, prefix + basename_no_extension + extension)

    def get_incomplete_download_file_paths(self, username, virtual_path):
        """Return current and legacy incomplete paths for cleanup/resume compatibility."""

        incomplete_file_path = self.get_incomplete_download_file_path(username, virtual_path)
        legacy_incomplete_file_path = self.get_incomplete_download_file_path(username, virtual_path, legacy=True)

        if legacy_incomplete_file_path == incomplete_file_path:
            return (incomplete_file_path,)

        return (incomplete_file_path, legacy_incomplete_file_path)

    def get_existing_incomplete_download_file_path(self, transfer):
        """Return the preferred incomplete file path, preserving legacy resumes."""

        username = transfer.username
        virtual_path = transfer.virtual_path
        incomplete_file_path = self.get_incomplete_download_file_path(username, virtual_path)

        if not transfer.current_byte_offset or os.path.exists(encode_path(incomplete_file_path)):
            return incomplete_file_path

        legacy_incomplete_file_path = self.get_incomplete_download_file_path(username, virtual_path, legacy=True)

        if legacy_incomplete_file_path != incomplete_file_path and os.path.exists(encode_path(legacy_incomplete_file_path)):
            return legacy_incomplete_file_path

        return incomplete_file_path

    def get_current_download_file_path(self, transfer):
        """Returns the current file path of a download."""

        file_path, file_exists = self.get_complete_download_file_path(
            transfer.username, transfer.virtual_path, transfer.size, transfer.folder_path)

        if file_exists or transfer.status == TransferStatus.FINISHED:
            return file_path

        return self.get_existing_incomplete_download_file_path(transfer)

    def enqueue_folder(self, username, folder_path, download_folder_path=None):

        user_folders = self._requested_folders.get(username)
        requested_folder = None if user_folders is None else user_folders.get(folder_path)

        if requested_folder is None:
            num_user_folders = 0 if user_folders is None else len(user_folders)

            if num_user_folders >= self.MAX_PENDING_FOLDER_REQUESTS_PER_USER:
                log.add_transfer(
                    "Maximum number of pending folder content requests for user %s reached; "
                    "ignoring request for folder %s", (username, folder_path))
                return False

            if self._get_num_requested_folders() >= self.MAX_PENDING_FOLDER_REQUESTS:
                log.add_transfer(
                    "Maximum number of pending folder content requests reached; "
                    "ignoring request for folder %s from user %s", (folder_path, username))
                return False

            if user_folders is None:
                user_folders = self._requested_folders[username]

            user_folders[folder_path] = requested_folder = RequestedFolder(
                username, folder_path, download_folder_path
            )

        # First timeout is shorter to get a response sooner in case the first request
        # failed. Second timeout is longer in case the response is delayed.
        timeout = 60 if requested_folder.has_retried else 15

        if requested_folder.request_timer_id is not None:
            events.cancel_scheduled(requested_folder.request_timer_id)
            requested_folder.request_timer_id = None

        request_timer_id = events.schedule(
            delay=timeout, callback=self._requested_folder_timeout, callback_args=(requested_folder,)
        )

        if request_timer_id is None:
            log.add_transfer(
                "Unable to schedule timeout for folder content request %s from user %s; ignoring request",
                (folder_path, username)
            )
            self._remove_requested_folder(requested_folder)
            return False

        requested_folder.request_timer_id = request_timer_id

        log.add_transfer("Requesting contents of folder %s from user %s", (folder_path, username))

        self._requested_folder_token = increment_token(self._requested_folder_token)
        self._discard_requested_folder_token(requested_folder)
        requested_folder.token = self._requested_folder_token

        if core.send_message_to_peer(
                username, FolderContentsRequest(
                    folder_path, requested_folder.token, legacy_client=requested_folder.legacy_attempt
                )) is False:
            log.add_transfer(
                "Unable to queue folder content request %s for user %s; ignoring request",
                (folder_path, username)
            )
            self._remove_requested_folder(requested_folder)
            return False

        FOLDER_TOKENS_ALLOWED.add((username, requested_folder.token))
        return True

    def enqueue_download(self, username, virtual_path, folder_path=None, size=0, file_attributes=None,
                         bypass_filter=False):

        transfer = self.get_transfer(username, virtual_path)

        if folder_path:
            folder_path = clean_path(folder_path)
        else:
            folder_path = self.get_default_download_folder(username)

        if transfer is not None and transfer.folder_path != folder_path and transfer.status == TransferStatus.FINISHED:
            # Only one user + virtual path transfer possible at a time, remove the old one
            self._clear_transfer(transfer, update_parent=False)
            transfer = None

        if transfer is not None:
            # Duplicate download found, stop here
            return True

        if not self._can_add_download():
            return False

        transfer = Transfer(username, virtual_path, folder_path, size, file_attributes)

        self._append_transfer(transfer)

        if self._enqueue_transfer(transfer, bypass_filter=bypass_filter):
            self._update_transfer(transfer)

        return True

    def _retry_finished_incomplete_move(self, transfer):
        """Retry moving a fully downloaded incomplete file without contacting the peer again."""

        if transfer.status != TransferStatus.DOWNLOAD_FOLDER_ERROR:
            return False

        if transfer.size <= 0 or transfer.current_byte_offset < transfer.size:
            return False

        incomplete_file_path = self.get_existing_incomplete_download_file_path(transfer)
        encoded_incomplete_file_path = encode_path(incomplete_file_path)

        if not os.path.exists(encoded_incomplete_file_path):
            return False

        download_file_path = self._move_finished_transfer(transfer, encoded_incomplete_file_path)

        if download_file_path is None:
            # The retry path was handled locally and failed again; keep the
            # download in the error state instead of enqueueing a redundant
            # network request for bytes we already have.
            self._update_transfer(transfer)
            return True

        self._dequeue_transfer(transfer)
        self._unfail_transfer(transfer)
        transfer.status = TransferStatus.FINISHED
        transfer.current_byte_offset = transfer.size
        transfer.last_byte_offset = None
        transfer.queue_position = 0
        self._unwatch_stale_user(transfer.username)

        if not self._auto_clear_transfer(transfer):
            self._update_transfer(transfer)

        core.statistics.append_stat_value("completed_downloads", 1)
        self._file_downloaded_actions(transfer.username, download_file_path)
        self._folder_downloaded_actions(transfer.username, transfer.folder_path)
        core.pluginhandler.download_finished_notification(
            transfer.username, transfer.virtual_path, download_file_path)
        log.add_download(
            _("Download finished: user %(user)s, file %(file)s"), {
                "user": transfer.username,
                "file": transfer.virtual_path
            }
        )
        return True

    def retry_download(self, transfer, bypass_filter=False):

        username = transfer.username
        active_downloads = self.active_users.get(username, {}).values()

        if transfer in active_downloads or transfer.status == TransferStatus.FINISHED:
            # Don't retry active or finished downloads
            return

        if self._retry_finished_incomplete_move(transfer):
            return

        self._dequeue_transfer(transfer)
        self._unfail_transfer(transfer)

        if self._enqueue_transfer(transfer, bypass_filter=bypass_filter):
            self._update_transfer(transfer)

    def _cancel_bulk_download_actions(self):
        events.cancel_scheduled(self._bulk_download_action_timer_id)
        self._bulk_download_action_timer_id = None
        self._bulk_download_action_queue.clear()

    def _schedule_bulk_download_actions(self):

        if self._bulk_download_action_timer_id is not None:
            return

        self._bulk_download_action_timer_id = events.schedule(delay=0, callback=self._process_bulk_download_actions)

        if self._bulk_download_action_timer_id is None:
            # Scheduler is saturated. Process one bounded batch synchronously so
            # user-triggered bulk actions still make progress without retaining
            # the entire pending action list indefinitely.
            self._process_bulk_download_actions()

    def _queue_bulk_download_actions(self, action, downloads, *args):

        queued = 0

        for download in downloads:
            if len(self._bulk_download_action_queue) >= self.MAX_PENDING_BULK_DOWNLOAD_ACTIONS:
                break

            self._bulk_download_action_queue.append((action, download, args))
            queued += 1

        if queued:
            self._process_bulk_download_actions()

    def _queue_clear_all_download_actions(self, statuses, clear_deleted):
        """Queue a clear-all operation without snapshotting every transfer object.

        The public clear-all path can be used on very large persisted transfer
        lists. Batching only helps if work starts before we materialize a tuple
        containing every transfer. Keep a small cursor state instead, refill the
        ordinary per-transfer action queue in bounded scans, and clear that state
        when the current transfer map has been walked once.
        """

        if self._bulk_download_clear_all_state is None:
            # The common clear-all path can make progress by repeatedly taking
            # the current first batch and clearing it. Do not retain a "seen"
            # set containing every transfer key unless filtering requires us to
            # skip entries that must remain in the map.
            seen_keys = set() if (statuses or clear_deleted) else None
            self._bulk_download_clear_all_state = [statuses, clear_deleted, seen_keys]

        self._process_bulk_download_actions()

    def _fill_bulk_download_actions_from_sources(self):

        state = self._bulk_download_clear_all_state

        if state is None:
            return

        statuses, clear_deleted, seen_keys = state
        remaining_capacity = self.MAX_PENDING_BULK_DOWNLOAD_ACTIONS - len(self._bulk_download_action_queue)

        if seen_keys is None:
            # Unfiltered clear-all removes every queued item. Keep the queue no
            # larger than a single processing batch so the next refill starts
            # after the previous batch has actually been deleted from the
            # transfer map, avoiding both full snapshots and a giant seen-key
            # ledger.
            remaining_capacity = min(
                remaining_capacity,
                self.MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK - len(self._bulk_download_action_queue)
            )

        if remaining_capacity <= 0:
            return

        scanned = 0
        completed = True

        for key, download in self.transfers.items():
            if seen_keys is not None:
                if key in seen_keys:
                    continue

                seen_keys.add(key)

            scanned += 1

            if not statuses or download.status in statuses:
                self._bulk_download_action_queue.append(("clear", download, (statuses, clear_deleted)))
                remaining_capacity -= 1

            if (scanned >= self.MAX_BULK_DOWNLOAD_SOURCE_SCANS_PER_TICK
                    or remaining_capacity <= 0):
                completed = False
                break

        if completed:
            self._bulk_download_clear_all_state = None

    def _process_bulk_download_actions(self):

        self._bulk_download_action_timer_id = None
        self._fill_bulk_download_actions_from_sources()
        aborted = defaultdict(list)
        cleared = defaultdict(list)
        clear_args = {}
        num_processed = 0

        while (self._bulk_download_action_queue
               and num_processed < self.MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK):
            action, download, args = self._bulk_download_action_queue.popleft()
            num_processed += 1

            if action == "retry":
                bypass_filter, = args
                self.retry_download(download, bypass_filter)

            elif action == "abort":
                status, = args

                if download.status not in {status, TransferStatus.FINISHED}:
                    self._abort_transfer(download, status=status, update_parent=False)
                    aborted[status].append(download)

            elif action == "clear":
                statuses, clear_deleted = args

                if statuses and download.status not in statuses:
                    continue

                if clear_deleted:
                    if download.status != TransferStatus.FINISHED:
                        continue

                    _file_path, file_exists = self.get_complete_download_file_path(
                        download.username, download.virtual_path, download.size, download.folder_path)

                    if file_exists:
                        continue

                self._clear_transfer(download, update_parent=False)
                key = (frozenset(statuses) if statuses else None, clear_deleted)
                clear_args[key] = (statuses, clear_deleted)
                cleared[key].append(download)

        for status, downloads in aborted.items():
            events.emit("abort-downloads", downloads, status)

        for key, downloads in cleared.items():
            statuses, clear_deleted = clear_args[key]
            events.emit("clear-downloads", downloads, statuses, clear_deleted)

        if self._bulk_download_action_queue or self._bulk_download_clear_all_state is not None:
            self._schedule_bulk_download_actions()

    @staticmethod
    def _normalize_bulk_downloads(downloads):
        if downloads is None:
            return None

        if isinstance(downloads, (list, tuple)):
            return downloads

        return tuple(downloads)

    def retry_downloads(self, downloads):

        downloads = self._normalize_bulk_downloads(downloads)
        num_downloads = len(downloads)

        if num_downloads > self.MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK:
            self._queue_bulk_download_actions("retry", downloads, False)
            return

        for download in downloads:
            # Provide a way to bypass download filters in case the user actually wants a file.
            # To avoid accidentally bypassing filters, ensure that only a single file is selected,
            # and it has the "Filtered" status.

            bypass_filter = (num_downloads == 1 and download.status == TransferStatus.FILTERED)
            self.retry_download(download, bypass_filter)

    def abort_downloads(self, downloads, status=TransferStatus.PAUSED):

        downloads = self._normalize_bulk_downloads(downloads)

        if len(downloads) > self.MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK:
            self._queue_bulk_download_actions("abort", downloads, status)
            return

        ignored_statuses = {status, TransferStatus.FINISHED}

        for download in downloads:
            if download.status not in ignored_statuses:
                self._abort_transfer(download, status=status, update_parent=False)

        events.emit("abort-downloads", downloads, status)

    def clear_downloads(self, downloads=None, statuses=None, clear_deleted=False):

        if downloads is None:
            # Clear all downloads. For large transfer lists, avoid building a
            # tuple of every Transfer before the bulk-action batcher can run.
            if len(self.transfers) > self.MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK:
                self._queue_clear_all_download_actions(statuses, clear_deleted)
                return

            downloads = tuple(self.transfers.values())
        else:
            downloads = tuple(downloads)

        if len(downloads) > self.MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK:
            self._queue_bulk_download_actions("clear", downloads, statuses, clear_deleted)
            return

        for download in downloads:
            if statuses and download.status not in statuses:
                continue

            if clear_deleted:
                if download.status != TransferStatus.FINISHED:
                    continue

                _file_path, file_exists = self.get_complete_download_file_path(
                    download.username, download.virtual_path, download.size, download.folder_path)

                if file_exists:
                    continue

            self._clear_transfer(download, update_parent=False)

        events.emit("clear-downloads", downloads, statuses, clear_deleted)

    # Events #

    def _schedule_pending_queue_flush(self, delay=0):

        if self._pending_queue_flush_timer_id is not None:
            return

        self._pending_queue_flush_timer_id = events.schedule(
            delay=delay, callback=self._flush_pending_queue_messages)

    def _flush_pending_queue_messages(self):

        self._pending_queue_flush_timer_id = None
        num_sent = 0

        while self._pending_queue_messages and num_sent < self.MAX_PENDING_QUEUE_MESSAGES_PER_READY_TICK:
            transfer, msg = self._pending_queue_messages.popitem()

            if core.send_message_to_peer(transfer.username, msg) is False:
                # Put the message back and retry later. Do not spin in a zero-delay loop
                # while the network queue is still over budget.
                self._pending_queue_messages[transfer] = msg
                self._schedule_pending_queue_flush(delay=1)
                return

            num_sent += 1

        if self._pending_queue_messages:
            self._schedule_pending_queue_flush()

    def _shares_ready(self, _successful):
        """Send any QueueUpload messages we delayed while our shares were
        initializing.
        """

        self._flush_pending_queue_messages()

    def _schedule_user_status_download_resumes(self):
        if self._user_status_resume_timer_id is None:
            self._user_status_resume_timer_id = events.schedule(
                delay=0, callback=self._resume_user_status_downloads)

    def _schedule_user_status_download_offline_aborts(self):
        if self._user_status_offline_timer_id is None:
            self._user_status_offline_timer_id = events.schedule(
                delay=0, callback=self._abort_user_status_downloads)

    def _queue_user_status_download_resume(self, username):
        if username in self._user_status_resume_users:
            return

        self._user_status_resume_users.add(username)
        self._user_status_resume_queue.append(username)
        self._schedule_user_status_download_resumes()

    def _queue_user_status_download_offline_aborts(self, username):
        if username in self._user_status_offline_users:
            return

        self._user_status_offline_users.add(username)
        self._user_status_offline_queue.append(username)
        self._schedule_user_status_download_offline_aborts()

    def _resume_user_status_downloads_for_user(self, username, max_downloads):
        failed_downloads = self.failed_users.get(username)

        if not failed_downloads or max_downloads <= 0:
            return 0, False

        downloads = []

        for download in failed_downloads.values():
            if download.status != TransferStatus.USER_LOGGED_OFF:
                continue

            downloads.append(download)

            if len(downloads) >= max_downloads:
                break

        for download in downloads:
            self._unfail_transfer(download)

            if self._enqueue_transfer(download):
                self._update_transfer(download)

        has_more = any(
            download.status == TransferStatus.USER_LOGGED_OFF
            for download in self.failed_users.get(username, {}).values()
        )

        return len(downloads), has_more

    def _resume_user_status_downloads(self):
        self._user_status_resume_timer_id = None
        num_processed = 0

        while (self._user_status_resume_queue
                and num_processed < self.MAX_USER_STATUS_DOWNLOAD_RESUMES_PER_TICK):
            username = self._user_status_resume_queue.popleft()
            self._user_status_resume_users.discard(username)

            if username not in self._online_users:
                continue

            processed, has_more = self._resume_user_status_downloads_for_user(
                username, self.MAX_USER_STATUS_DOWNLOAD_RESUMES_PER_TICK - num_processed)
            num_processed += processed

            if has_more:
                self._queue_user_status_download_resume(username)

        if self._user_status_resume_queue:
            self._schedule_user_status_download_resumes()

    def _abort_user_status_downloads_for_user(self, username, max_downloads):
        if max_downloads <= 0:
            return 0, self._has_user_status_downloads_to_abort(username)

        downloads = []

        for users in (self.queued_users, self.failed_users):
            for download in users.get(username, {}).values():
                if download.status == TransferStatus.USER_LOGGED_OFF:
                    continue

                downloads.append(download)

                if len(downloads) >= max_downloads:
                    break

            if len(downloads) >= max_downloads:
                break

        if len(downloads) < max_downloads:
            for download in self.active_users.get(username, {}).values():
                if download.status == TransferStatus.TRANSFERRING:
                    continue

                downloads.append(download)

                if len(downloads) >= max_downloads:
                    break

        for download in downloads:
            self._abort_transfer(download, status=TransferStatus.USER_LOGGED_OFF)

        return len(downloads), self._has_user_status_downloads_to_abort(username)

    def _has_user_status_downloads_to_abort(self, username):
        for users in (self.queued_users, self.failed_users):
            if any(
                download.status != TransferStatus.USER_LOGGED_OFF
                for download in users.get(username, {}).values()
            ):
                return True

        return any(
            download.status != TransferStatus.TRANSFERRING
            for download in self.active_users.get(username, {}).values()
        )

    def _abort_user_status_downloads(self):
        self._user_status_offline_timer_id = None
        num_processed = 0

        while (self._user_status_offline_queue
                and num_processed < self.MAX_USER_STATUS_DOWNLOAD_OFFLINE_ABORTS_PER_TICK):
            username = self._user_status_offline_queue.popleft()
            self._user_status_offline_users.discard(username)

            if username in self._online_users:
                continue

            processed, has_more = self._abort_user_status_downloads_for_user(
                username, self.MAX_USER_STATUS_DOWNLOAD_OFFLINE_ABORTS_PER_TICK - num_processed)
            num_processed += processed

            if has_more:
                self._queue_user_status_download_offline_aborts(username)

        if self._user_status_offline_queue:
            self._schedule_user_status_download_offline_aborts()

    def _user_status(self, msg):
        """Server code 7."""

        username = msg.user

        if username not in core.users.watched:
            # Skip redundant status updates from users in joined rooms
            return

        if msg.status == UserStatus.OFFLINE:
            self._online_users.discard(username)
            self._user_status_resume_users.discard(username)

            _, has_more = self._abort_user_status_downloads_for_user(
                username, self.MAX_USER_STATUS_DOWNLOAD_OFFLINE_ABORTS_PER_TICK)

            if has_more:
                self._queue_user_status_download_offline_aborts(username)

            return

        # No need to check transfers on away status change
        if username in self._online_users:
            return

        self._online_users.add(username)

        # User logged in, resume only transfers that actually failed because
        # the user was offline. Keep local I/O errors, filters and connection
        # failures in their existing states for the dedicated retry paths, and
        # avoid sending an unbounded burst when a user with many failed
        # transfers comes back online.
        _, has_more = self._resume_user_status_downloads_for_user(
            username, self.MAX_USER_STATUS_DOWNLOAD_RESUMES_PER_TICK)

        if has_more:
            self._queue_user_status_download_resume(username)

    def _set_connection_stats(self, download_bandwidth=0, **_unused):
        self.total_bandwidth = download_bandwidth

    def _peer_connection_error(self, username, conn_type, msgs, is_offline=False, is_timeout=True):

        if not msgs:
            return

        if conn_type not in {ConnectionType.FILE, ConnectionType.PEER}:
            return

        failed_msg_types = {QueueUpload, PlaceInQueueRequest}

        for msg in msgs:
            if msg.__class__ in failed_msg_types:
                self._cant_connect_queue_file(username, msg.file, is_offline, is_timeout)

    def _peer_connection_closed(self, username, conn_type, msgs=None):
        self._peer_connection_error(username, conn_type, msgs, is_timeout=False)

    def _cant_connect_queue_file(self, username, virtual_path, is_offline, is_timeout):
        """We can't connect to the user, either way (QueueUpload, PlaceInQueueRequest)."""

        download = self.queued_users.get(username, {}).get(virtual_path)

        if download is None:
            return

        if is_offline:
            status = TransferStatus.USER_LOGGED_OFF

        elif is_timeout:
            status = TransferStatus.CONNECTION_TIMEOUT

        else:
            status = TransferStatus.CONNECTION_CLOSED

        log.add_transfer("Download attempt for file %s from user %s failed with status %s",
                         (virtual_path, username, status))
        self._abort_transfer(download, status=status)

    def _requested_folder_timeout(self, requested_folder):

        if requested_folder.request_timer_id is None:
            return

        requested_folder.request_timer_id = None
        username = requested_folder.username
        folder_path = requested_folder.folder_path

        if requested_folder.has_retried:
            log.add_transfer("Folder content request for folder %s from user %s timed out, "
                             "giving up", (folder_path, username))
            self._remove_requested_folder(requested_folder)
            return

        log.add_transfer("Folder content request for folder %s from user %s timed out, "
                         "retrying", (folder_path, username))

        requested_folder.has_retried = True
        self.enqueue_folder(username, folder_path, requested_folder.download_folder_path)

    def _add_pending_folder_download(self, username, folder_path, destination_folder_path, files):

        if len(self._pending_folder_downloads) >= self.MAX_PENDING_FOLDER_DOWNLOAD_JOBS:
            log.add_transfer(
                "Maximum number of pending folder download jobs reached; "
                "ignoring folder %s from user %s", (folder_path, username))
            return

        self._pending_folder_downloads.append(
            PendingFolderDownload(username, folder_path, destination_folder_path, files)
        )

        if self._pending_folder_download_timer_id is None:
            self._process_pending_folder_downloads()

    def _schedule_pending_folder_downloads(self):

        if self._pending_folder_download_timer_id is not None or not self._pending_folder_downloads:
            return

        self._pending_folder_download_timer_id = events.schedule(
            delay=0, callback=self._process_pending_folder_downloads
        )

    def _process_pending_folder_downloads(self):

        self._pending_folder_download_timer_id = None
        num_processed = 0

        while self._pending_folder_downloads and num_processed < self.MAX_FOLDER_DOWNLOAD_FILES_PER_TICK:
            pending_folder = self._pending_folder_downloads[0]
            files = pending_folder.files

            while pending_folder.file_index < len(files) and num_processed < self.MAX_FOLDER_DOWNLOAD_FILES_PER_TICK:
                _code, basename, file_size, _ext, file_attributes, *_unused = files[pending_folder.file_index]
                virtual_path = pending_folder.folder_path.rstrip("\\") + "\\" + basename
                pending_folder.file_index += 1
                num_processed += 1

                if not self.enqueue_download(
                    pending_folder.username, virtual_path, folder_path=pending_folder.destination_folder_path,
                    size=file_size, file_attributes=file_attributes
                ):
                    pending_folder.file_index = len(files)
                    break

            if pending_folder.file_index >= len(files):
                self._pending_folder_downloads.popleft()

        self._schedule_pending_folder_downloads()

    def _folder_contents_response(self, msg, check_num_files=True):
        """Peer code 37."""

        username = msg.username
        folder_path = msg.dir

        if username not in self._requested_folders:
            return

        requested_folder = self._requested_folders[username].get(msg.dir)

        if requested_folder is None or msg.token != requested_folder.token:
            return

        log.add_transfer("Received response for folder content request for folder %s "
                         "from user %s", (folder_path, username))

        if not msg.list and not requested_folder.legacy_attempt:
            log.add_transfer("Folder content response is empty. Trying legacy latin-1 request.")
            self._complete_requested_folder_response(requested_folder)
            requested_folder.legacy_attempt = True
            self.enqueue_folder(username, folder_path, requested_folder.download_folder_path)
            return

        if not msg.list:
            self._remove_requested_folder(requested_folder)
            return

        files = msg.list.get(folder_path)

        if files is None:
            self._complete_requested_folder_response(requested_folder)
            self._remove_requested_folder(requested_folder)
            return

        num_files = len(files)

        if check_num_files and num_files > 100:
            check_num_files = False
            self._cancel_requested_folder_timer(requested_folder)
            events.emit(
                "download-large-folder", username, folder_path, num_files,
                self._folder_contents_response, (msg, check_num_files)
            )
            return

        self._complete_requested_folder_response(requested_folder)

        destination_folder_path = self.get_folder_destination(username, folder_path)

        log.add_transfer("Attempting to download files in folder %s for user %s. "
                         "Destination path: %s", (folder_path, username, destination_folder_path))

        self._remove_requested_folder(requested_folder)
        self._add_pending_folder_download(username, folder_path, destination_folder_path, files)

    _TRANSFER_REQUEST_ROLLBACK_FIELDS = (
        "status", "size", "size_changed", "current_byte_offset", "last_byte_offset",
        "transferred_bytes_total", "speed", "avg_speed", "time_elapsed", "time_left",
        "queue_position", "token", "retry_attempt", "legacy_attempt"
    )

    @classmethod
    def _snapshot_transfer_request_state(cls, transfer):
        return {field: getattr(transfer, field) for field in cls._TRANSFER_REQUEST_ROLLBACK_FIELDS}

    @staticmethod
    def _restore_transfer_request_state(transfer, state):
        for field, value in state.items():
            setattr(transfer, field, value)

    def _rollback_unsent_download_transfer_response(self, rollback_info):
        """Undo local download state when a positive TransferResponse is not queued.

        Legacy peer TransferRequest handling activates or creates local transfer
        state before the response is sent. With bounded network queues, the
        response can be rejected locally. In that case, the peer never saw the
        acceptance, so leaving the download active would strand a timeout and UI
        row for work that was never announced.
        """

        if rollback_info is None:
            return

        kind = rollback_info[0]

        if kind == "existing":
            _kind, transfer, was_queued, was_failed, previous_state = rollback_info
            self._deactivate_transfer(transfer)
            self._restore_transfer_request_state(transfer, previous_state)

            if was_queued:
                # Restore the local queued state without emitting a fresh QueueUpload.
                # The original QueueUpload already reached the peer; this rollback is
                # only undoing a locally rejected TransferResponse.
                Transfers._enqueue_transfer(self, transfer)
                self._sync_pending_download_folder_transfer(transfer)

            elif was_failed:
                self._fail_transfer(transfer)

            self._update_transfer(transfer)
            return

        if kind == "new":
            _kind, transfer = rollback_info

            if self.get_transfer(transfer.username, transfer.virtual_path) is transfer:
                self._clear_transfer(transfer, update_parent=False)


    def _retry_unsent_folder_contents_request(self, username, msg):
        requested_folder = None

        for folder_request in self._requested_folders.get(username, {}).values():
            if folder_request.token == getattr(msg, "token", None):
                requested_folder = folder_request
                break

        if requested_folder is None:
            requested_folder = self._requested_folders.get(username, {}).get(getattr(msg, "dir", None))

        if requested_folder is None:
            return

        folder_path = requested_folder.folder_path
        download_folder_path = requested_folder.download_folder_path

        if requested_folder.has_retried:
            log.add_transfer(
                "Folder content request for folder %s from user %s was not sent after retry, giving up",
                (folder_path, username)
            )
            self._remove_requested_folder(requested_folder)
            return

        log.add_transfer(
            "Folder content request for folder %s from user %s was not sent, retrying",
            (folder_path, username)
        )
        requested_folder.has_retried = True
        self.enqueue_folder(username, folder_path, download_folder_path)

    def _peer_request_unsent(self, msg_class, username, msg):
        if msg_class is FolderContentsRequest:
            self._retry_unsent_folder_contents_request(username, msg)

    def _peer_response_delivery_failed(self, msg_class, username, rollback_info):
        if msg_class is not FolderContentsResponse or not rollback_info:
            return

        rollback_kind, token, folder_path = rollback_info

        if rollback_kind != "folder-contents-response":
            return

        requested_folder = None

        for folder_request in self._requested_folders.get(username, {}).values():
            if folder_request.token == token:
                requested_folder = folder_request
                break

        if requested_folder is None:
            requested_folder = self._requested_folders.get(username, {}).get(folder_path)

        if requested_folder is None:
            return

        if requested_folder.has_retried:
            log.add_transfer(
                "Folder content response for folder %s from user %s was not delivered after retry, giving up",
                (requested_folder.folder_path, username)
            )
            self._remove_requested_folder(requested_folder)
            return

        log.add_transfer(
            "Folder content response for folder %s from user %s was not delivered, retrying request",
            (requested_folder.folder_path, username)
        )
        requested_folder.has_retried = True
        self.enqueue_folder(username, requested_folder.folder_path, requested_folder.download_folder_path)

    def _peer_message_unsent(self, msg):
        """Undo local transfer state when a positive TransferResponse dies below the public queue.

        Public send_message_to_peer() acceptance only means the response reached the
        network-thread queue. A later closed socket, pack failure or output-buffer
        rejection still means the peer never saw our acceptance. Do not leave the
        remote-upload download activated/dequeued as if the response had gone out.
        """

        if msg.__class__ is QueueUpload:
            transfer = self.queued_users.get(msg.username, {}).get(msg.file)

            if transfer is not None:
                log.add_transfer(
                    "QueueUpload for file %s to user %s was not sent, retrying",
                    (msg.file, msg.username)
                )
                self._pending_queue_messages[transfer] = QueueUpload(msg.file, msg.legacy_client)
                self._schedule_pending_queue_flush(delay=1)

            return

        if msg.__class__ is PlaceInQueueRequest:
            transfer = self.queued_users.get(msg.username, {}).get(msg.file)

            if transfer is not None:
                self._queue_queue_position_request_retry(transfer)
                self._schedule_queue_position_request_retries(delay=1)

            return

        if msg.__class__ is not TransferResponse or not msg.allowed:
            return

        rollback_info = getattr(msg, "rollback_info", None)

        if rollback_info is None:
            return

        log.add_transfer(
            "Rolling back download transfer response with token %s because peer output failed",
            msg.token
        )
        self._rollback_unsent_download_transfer_response(rollback_info)
        msg.rollback_info = None

    def _transfer_request(self, msg):
        """Peer code 40."""

        if msg.direction != TransferDirection.UPLOAD:
            return

        username = msg.username
        response, rollback_info = self._prepare_transfer_request_downloads(msg)

        log.add_transfer("Responding to download request with token %s for file %s "
                         "from user: %s, allowed: %s, reason: %s",
                         (response.token, msg.file, username, response.allowed, response.reason))

        if response.allowed:
            response.rollback_info = rollback_info

        if core.send_message_to_peer(username, response) is False:
            log.add_transfer(
                "Unable to queue download response with token %s for file %s from user %s; "
                "rolling back local transfer state", (response.token, msg.file, username)
            )

            if response.allowed:
                self._rollback_unsent_download_transfer_response(rollback_info)

    def _transfer_request_downloads(self, msg):
        response, _rollback_info = self._prepare_transfer_request_downloads(msg)
        return response

    def _prepare_transfer_request_downloads(self, msg):

        username = msg.username
        virtual_path = msg.file
        size = msg.filesize
        token = msg.token

        log.add_transfer("Received download request with token %s for file %s from user %s",
                         (token, virtual_path, username))

        download = (self.queued_users.get(username, {}).get(virtual_path)
                    or self.failed_users.get(username, {}).get(virtual_path))

        if download is not None:
            # Remote peer is signaling a transfer is ready, attempting to download it

            # If the file is larger than 2GB, the SoulseekQt client seems to
            # send a malformed file size (0 bytes) in the TransferRequest response.
            # In that case, we rely on the cached, correct file size we received when
            # we initially added the download.

            if not self._is_active_transfer_token_available(username, token, download):
                return TransferResponse(allowed=False, reason=TransferRejectReason.CANCELLED, token=token), None

            was_queued = virtual_path in self.queued_users.get(username, {})
            was_failed = virtual_path in self.failed_users.get(username, {})
            rollback_info = (
                "existing", download, was_queued, was_failed, self._snapshot_transfer_request_state(download)
            )

            self._unfail_transfer(download)
            self._dequeue_transfer(download)

            if size > 0:
                if download.size != size:
                    # The remote user's file contents have changed since we queued the download
                    download.size_changed = True

                download.size = size

            self._activate_transfer(download, token)
            self._update_transfer(download)

            return TransferResponse(allowed=True, token=token), rollback_info

        download = self.get_transfer(username, virtual_path)
        cancel_reason = TransferRejectReason.CANCELLED

        if download is not None:
            if download.status == TransferStatus.FINISHED:
                # SoulseekQt sends "Complete" as the reason for rejecting the download if it exists
                cancel_reason = TransferRejectReason.COMPLETE

        elif self.can_upload(username):
            # Check if download exists in our default download folder
            _file_path, file_exists = self.get_complete_download_file_path(username, virtual_path, size)

            if file_exists:
                cancel_reason = TransferRejectReason.COMPLETE
            else:
                # If this file is not in your download queue, then it must be
                # a remotely initiated download and someone is manually uploading to you.
                # Peers can send a root-level filename without a parent folder.
                parent_folder_path = virtual_path.replace("/", "\\").rpartition("\\")[0]
                parent_folder_name = parent_folder_path.rpartition("\\")[-1]
                received_folder_path = os.path.normpath(os.path.expandvars(config.sections["transfers"]["uploaddir"]))
                folder_path = os.path.join(received_folder_path, clean_file(username))

                if parent_folder_name:
                    folder_path = os.path.join(folder_path, clean_file(parent_folder_name))

                transfer = Transfer(username, virtual_path, folder_path, size)

                if not self._is_active_transfer_token_available(username, token, transfer):
                    return TransferResponse(allowed=False, reason=TransferRejectReason.CANCELLED, token=token), None

                self._append_transfer(transfer)
                self._activate_transfer(transfer, token)
                self._update_transfer(transfer)

                return TransferResponse(allowed=True, token=token), ("new", transfer)

        log.add_transfer("Denied file request: user %s, message %s", (username, msg))
        return TransferResponse(allowed=False, reason=cancel_reason, token=token), None

    def _transfer_timeout(self, transfer):

        if transfer.request_timer_id is None:
            return

        log.add_transfer("Download %s with token %s for user %s timed out",
                         (transfer.virtual_path, transfer.token, transfer.username))

        super()._transfer_timeout(transfer)

    def _download_file_error(self, username, token, error):
        """Networking thread encountered a local file error for download."""

        download = self.active_users.get(username, {}).get(token)

        if download is None:
            return

        self._abort_transfer(download, status=TransferStatus.LOCAL_FILE_ERROR)
        log.add(_("Download I/O error: %s"), error)

    def _file_transfer_init(self, msg):
        """A peer is requesting to start uploading a file to us."""

        if msg.is_outgoing:
            # Upload init message sent to ourselves, ignore
            return

        username = msg.username
        token = msg.token
        download = self.active_users.get(username, {}).get(token)

        if download is None or download.sock is not None:
            return

        virtual_path = download.virtual_path
        incomplete_folder_path = self.get_incomplete_download_folder()
        sock = download.sock = msg.sock
        need_update = True
        download_started = False

        log.add_transfer("Received file download init with token %s for file %s from user %s",
                         (token, virtual_path, username))

        try:
            incomplete_folder_path_encoded = encode_path(incomplete_folder_path)

            if not os.path.isdir(incomplete_folder_path_encoded):
                os.makedirs(incomplete_folder_path_encoded)

            incomplete_file_path = self.get_existing_incomplete_download_file_path(download)
            file_handle = self._open_incomplete_download_file(incomplete_file_path)

            if download.size_changed:
                # Remote user sent a different file size than we originally requested,
                # wipe any existing data in the incomplete file to avoid corruption
                file_handle.truncate(0)

            # Seek to the end of the file for resuming the download. If a stale
            # or corrupted incomplete file is larger than the expected download
            # size, do not treat it as a completed transfer; restart it instead.
            offset = file_handle.seek(0, os.SEEK_END)

            if offset > download.size:
                log.add_transfer(
                    "Discarding incomplete download %s for user %s, size %s exceeds expected size %s",
                    (virtual_path, username, offset, download.size)
                )
                file_handle.seek(0)
                file_handle.truncate(0)
                offset = 0
                download.current_byte_offset = 0

        except OSError as error:
            log.add(_("Cannot save file in %(folder_path)s: %(error)s"), {
                "folder_path": incomplete_folder_path,
                "error": error
            })
            self._abort_transfer(download, status=TransferStatus.DOWNLOAD_FOLDER_ERROR)
            core.notifications.show_download_notification(
                str(error), title=_("Download Folder Error"), high_priority=True)
            need_update = False

        else:
            download.file_handle = file_handle
            download.last_byte_offset = offset
            download.start_time = time.monotonic() - download.time_elapsed
            download.retry_attempt = False

            core.statistics.append_stat_value("started_downloads", 1)
            download_started = True

            log.add_download(
                _("Download started: user %(user)s, file %(file)s"), {
                    "user": username,
                    "file": file_handle.name.decode("utf-8", "replace")
                }
            )

            if download.size > offset:
                download.status = TransferStatus.TRANSFERRING

                if core.send_message_to_network_thread(DownloadFile(
                        sock=sock, token=token, file=file_handle, leftbytes=(download.size - offset),
                        username=username
                )) is False:
                    log.add_transfer(
                        "Unable to queue local download reader for file %s from user %s; aborting transfer",
                        (virtual_path, username)
                    )
                    self._abort_transfer(download, status=TransferStatus.CONNECTION_CLOSED)
                    need_update = False
                    download_started = False

                elif core.send_message_to_peer(username, FileOffset(sock, offset)) is False:
                    log.add_transfer(
                        "Unable to queue file offset for file %s from user %s; aborting transfer",
                        (virtual_path, username)
                    )
                    self._abort_transfer(download, status=TransferStatus.CONNECTION_CLOSED)
                    need_update = False
                    download_started = False

            else:
                self._finish_transfer(download)
                need_update = False

        if need_update:
            self._update_transfer(download)

        if download_started:
            # Must be emitted after the final update to prevent inconsistent state
            core.pluginhandler.download_started_notification(username, virtual_path, incomplete_file_path)

    def _upload_denied(self, msg):
        """Peer code 50."""

        username = msg.username
        virtual_path = msg.file
        reason = msg.reason
        queued_downloads = self.queued_users.get(username, {})
        download = queued_downloads.get(virtual_path)

        if download is None:
            return

        if reason in TransferStatus.__dict__.values():
            # Don't allow internal statuses as reason
            reason = TransferRejectReason.CANCELLED

        if reason == TransferRejectReason.FILE_NOT_SHARED and not download.legacy_attempt:
            # The peer is possibly using an old client that doesn't support Unicode
            # (Soulseek NS). Attempt to request file name encoded as latin-1 once.

            log.add_transfer("User %s responded with reason '%s' for download request %s. "
                             "Attempting to request file as latin-1.", (username, reason, virtual_path))

            self._dequeue_transfer(download)
            download.legacy_attempt = True

            if self._enqueue_transfer(download):
                self._update_transfer(download)

            return

        if (reason in {TransferRejectReason.TOO_MANY_FILES, TransferRejectReason.TOO_MANY_MEGABYTES}
                or reason.startswith("User limit of")):
            # Make limited downloads appear as queued, and automatically resume them later
            reason = TransferRejectReason.QUEUED
            self._user_queue_limits[username] = max(5, len(queued_downloads) - 1)

        self._abort_transfer(download, status=reason)
        self._update_transfer(download)

        log.add_transfer("Download request denied by user %s for file %s. Reason: %s",
                         (username, virtual_path, msg.reason))

    def _upload_failed(self, msg):
        """Peer code 46."""

        username = msg.username
        virtual_path = msg.file
        download = self.get_transfer(username, virtual_path)

        if download is None:
            return

        if (download.token not in self.active_users.get(username, {})
                and virtual_path not in self.failed_users.get(username, {})
                and virtual_path not in self.queued_users.get(username, {})):
            return

        if download.status in {TransferStatus.DOWNLOAD_FOLDER_ERROR, TransferStatus.LOCAL_FILE_ERROR}:
            # Local error, no need to retry
            return

        if not download.retry_attempt:
            # Attempt to request file name encoded as latin-1 once

            # We mark download as failed when aborting it, to avoid a redundant request
            # to unwatch the user. Need to call _unfail_transfer() to undo this.
            self._abort_transfer(download, status=TransferStatus.CONNECTION_CLOSED)
            self._unfail_transfer(download)

            download.legacy_attempt = download.retry_attempt = True

            if self._enqueue_transfer(download):
                self._update_transfer(download)

            return

        # Already failed once previously, give up
        self._abort_transfer(download, status=TransferStatus.CONNECTION_CLOSED)
        download.retry_attempt = False

        log.add_transfer("Upload attempt by user %s for file %s failed. Reason: %s",
                         (virtual_path, username, download.status))

    def _file_download_progress(self, username, token, bytes_left, speed=None):
        """A file download is in progress."""

        download = self.active_users.get(username, {}).get(token)

        if download is None:
            return

        if download.request_timer_id is not None:
            events.cancel_scheduled(download.request_timer_id)
            download.request_timer_id = None

        self._update_transfer_progress(
            download, stat_id="downloaded_size",
            current_byte_offset=(download.size - bytes_left), speed=speed
        )
        self._update_transfer(download)

    def _file_connection_closed(
            self, username, token, sock, bytes_left=None, current_byte_offset=None, **_unused):
        """A file download connection has closed for any reason."""

        download = self.active_users.get(username, {}).get(token)

        if download is None:
            return

        if download.sock != sock:
            return

        if current_byte_offset is None and bytes_left is not None:
            current_byte_offset = max(0, min(download.size, download.size - bytes_left))

        if (current_byte_offset is not None
                and current_byte_offset > (download.current_byte_offset or 0)):
            self._update_transfer_progress(
                download, stat_id="downloaded_size", current_byte_offset=current_byte_offset)

        if download.current_byte_offset is not None and download.current_byte_offset >= download.size:
            self._finish_transfer(download)
            return

        if core.users.statuses.get(download.username) == UserStatus.OFFLINE:
            status = TransferStatus.USER_LOGGED_OFF
        else:
            status = TransferStatus.CANCELLED

        self._abort_transfer(download, status=status)

    def _place_in_queue_response(self, msg):
        """Peer code 44.

        The peer tells us our place in queue for a particular transfer
        """

        username = msg.username
        virtual_path = msg.filename
        download = self.queued_users.get(username, {}).get(virtual_path)

        if download is None:
            return

        download.queue_position = msg.place
        self._update_transfer(download, update_parent=False)
