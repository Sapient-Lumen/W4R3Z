# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

import os

from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

from pynicotine.pluginsystem import PluginHandler
from pynicotine.pluginsystem import ResponseThrottle


class ResponseThrottleTest(TestCase):

    @staticmethod
    def _throttle():
        return ResponseThrottle(
            core=SimpleNamespace(
                users=SimpleNamespace(addresses={}),
                network_filter=SimpleNamespace(
                    is_user_ignored=Mock(return_value=False),
                    is_user_ip_ignored=Mock(return_value=False)
                )
            ),
            plugin_name="test"
        )

    def test_plugin_usage_room_cache_is_bounded(self):
        throttle = self._throttle()
        old_limit = ResponseThrottle.MAX_PLUGIN_USAGE_ROOMS

        try:
            ResponseThrottle.MAX_PLUGIN_USAGE_ROOMS = 2
            throttle._remember_room_usage("room0")
            throttle._remember_room_usage("room1")
            throttle._remember_room_usage("room2")

        finally:
            ResponseThrottle.MAX_PLUGIN_USAGE_ROOMS = old_limit

        self.assertEqual(["room1", "room2"], list(throttle.plugin_usage))

    def test_responded_uses_bounded_room_cache(self):
        throttle = self._throttle()
        old_limit = ResponseThrottle.MAX_PLUGIN_USAGE_ROOMS

        try:
            ResponseThrottle.MAX_PLUGIN_USAGE_ROOMS = 1
            throttle.room = "old"
            throttle.nick = "nick"
            throttle.request = "req"
            throttle.responded()
            throttle.room = "new"
            throttle.responded()

        finally:
            ResponseThrottle.MAX_PLUGIN_USAGE_ROOMS = old_limit

        self.assertEqual(["new"], list(throttle.plugin_usage))


class PluginHandlerCommandCompletionTest(TestCase):

    def test_command_completion_iterator_is_bounded(self):
        handler = object.__new__(PluginHandler)
        handler.commands = {
            "chatroom": {
                "one": {"aliases": ["one-a", "one-b"]},
                "two": {"aliases": ["two-a"]}
            }
        }

        self.assertEqual(
            ["/one ", "/one-a ", "/one-b "],
            list(handler.iter_command_list("chatroom", limit=3))
        )

    def test_command_completion_default_cap(self):
        old_limit = PluginHandler.MAX_COMMAND_COMPLETIONS
        PluginHandler.MAX_COMMAND_COMPLETIONS = 2

        try:
            handler = object.__new__(PluginHandler)
            handler.commands = {
                "private_chat": {
                    "one": {"aliases": ["one-a"]},
                    "two": {"aliases": ["two-a"]}
                }
            }

            self.assertEqual(["/one ", "/one-a "], handler.get_command_list("private_chat"))

        finally:
            PluginHandler.MAX_COMMAND_COMPLETIONS = old_limit

    def test_command_help_data_is_bounded(self):
        old_entries = PluginHandler.MAX_COMMAND_HELP_ENTRIES
        old_aliases = PluginHandler.MAX_COMMAND_HELP_ALIASES
        old_parameters = PluginHandler.MAX_COMMAND_HELP_PARAMETERS
        old_chars = PluginHandler.MAX_COMMAND_HELP_FIELD_CHARS

        try:
            PluginHandler.MAX_COMMAND_HELP_ENTRIES = 1
            PluginHandler.MAX_COMMAND_HELP_ALIASES = 2
            PluginHandler.MAX_COMMAND_HELP_PARAMETERS = 2
            PluginHandler.MAX_COMMAND_HELP_FIELD_CHARS = 4
            handler = object.__new__(PluginHandler)
            handler.commands = {
                "chatroom": {
                    "commandlong": {
                        "aliases": ["alias0", "alias1", "alias2"],
                        "parameters": ["param0", "param1", "param2"],
                        "description": "descriptionlong",
                        "group": "grouplong"
                    },
                    "second": {"aliases": ["second-a"]}
                }
            }

            groups = handler.get_command_groups_data("chatroom")

        finally:
            PluginHandler.MAX_COMMAND_HELP_ENTRIES = old_entries
            PluginHandler.MAX_COMMAND_HELP_ALIASES = old_aliases
            PluginHandler.MAX_COMMAND_HELP_PARAMETERS = old_parameters
            PluginHandler.MAX_COMMAND_HELP_FIELD_CHARS = old_chars

        self.assertEqual(["grou…"], list(groups))
        self.assertEqual(1, sum(len(entries) for entries in groups.values()))
        command, aliases, parameters, description = groups["grou…"][0]
        self.assertEqual("comm…", command)
        self.assertEqual(["alia…", "alia…"], aliases)
        self.assertEqual(["para…", "para…"], parameters)
        self.assertEqual("desc…", description)


class PluginHandlerInfoTest(TestCase):

    @staticmethod
    def _handler(plugin_folder):
        handler = object.__new__(PluginHandler)
        handler.plugin_folders = [plugin_folder]
        handler.enabled_plugins = {}
        handler.command_source = None
        handler.commands = {"chatroom": {}, "private_chat": {}, "cli": {}}
        handler.user_plugin_folder = plugin_folder
        handler._load_now_playing_sender = False
        handler._command_map = {"chatroom": {}, "private_chat": {}, "cli": {}}
        return handler

    def test_plugin_info_uses_bounded_literal_eval(self):
        with TemporaryDirectory() as temp_dir:
            plugin_path = os.path.join(temp_dir, "plugin")
            os.mkdir(plugin_path)

            with open(os.path.join(plugin_path, "PLUGININFO"), "w", encoding="utf-8") as file_handle:
                file_handle.write("Name='Test Plugin'\n")
                file_handle.write("Description=_('Translated')\n")

            info = self._handler(temp_dir).get_plugin_info("plugin")

        self.assertEqual("Test Plugin", info["Name"])
        self.assertEqual("Translated", info["Description"])

    def test_plugin_info_rejects_gross_file_before_literal_eval(self):
        old_limit = PluginHandler.MAX_PLUGININFO_FILE_BYTES

        try:
            PluginHandler.MAX_PLUGININFO_FILE_BYTES = 10

            with TemporaryDirectory() as temp_dir:
                plugin_path = os.path.join(temp_dir, "plugin")
                os.mkdir(plugin_path)

                with open(os.path.join(plugin_path, "PLUGININFO"), "w", encoding="utf-8") as file_handle:
                    file_handle.write("Name='This file is too large'\n")

                self.assertEqual({}, self._handler(temp_dir).get_plugin_info("plugin"))

        finally:
            PluginHandler.MAX_PLUGININFO_FILE_BYTES = old_limit

    def test_plugin_info_rejects_gross_literal_value(self):
        from pynicotine.config import Config

        old_limit = Config.MAX_CONFIG_LITERAL_BYTES

        try:
            Config.MAX_CONFIG_LITERAL_BYTES = 16

            with TemporaryDirectory() as temp_dir:
                plugin_path = os.path.join(temp_dir, "plugin")
                os.mkdir(plugin_path)

                with open(os.path.join(plugin_path, "PLUGININFO"), "w", encoding="utf-8") as file_handle:
                    file_handle.write("Name='ok'\n")
                    file_handle.write("Description='" + ("x" * 100) + "'\n")

                info = self._handler(temp_dir).get_plugin_info("plugin")

        finally:
            Config.MAX_CONFIG_LITERAL_BYTES = old_limit

        self.assertEqual("ok", info["Name"])
        self.assertNotIn("Description", info)


class PluginHandlerCommandDispatchTest(TestCase):

    @staticmethod
    def _handler():
        handler = object.__new__(PluginHandler)
        handler.enabled_plugins = {}
        handler.command_source = None
        handler.commands = {"chatroom": {}, "private_chat": {}, "cli": {}}
        handler._command_map = {"chatroom": {}, "private_chat": {}, "cli": {}}
        return handler

    def test_command_dispatch_uses_direct_alias_index(self):
        handler = self._handler()
        callback = Mock(return_value=True)
        plugin = SimpleNamespace(
            commands={"target": {"aliases": ["alias"], "callback_chatroom": callback}},
            __publiccommands__=[],
            __privatecommands__=[],
            output=Mock()
        )
        handler.enabled_plugins["plugin"] = plugin
        data = plugin.commands["target"]
        handler.commands["chatroom"]["target"] = data
        handler._index_command_lookup("chatroom", "plugin", "target", data)

        self.assertTrue(handler._trigger_command("alias", "hello", room="room"))
        callback.assert_called_once_with("hello", room="room")
        self.assertIsNone(handler.command_source)

    def test_command_alias_index_is_bounded(self):
        old_limit = PluginHandler.MAX_COMMAND_ALIASES_PER_COMMAND

        try:
            PluginHandler.MAX_COMMAND_ALIASES_PER_COMMAND = 2
            handler = self._handler()
            data = {"aliases": ["a0", "a1", "a2"]}
            handler._index_command_lookup("chatroom", "plugin", "target", data)

        finally:
            PluginHandler.MAX_COMMAND_ALIASES_PER_COMMAND = old_limit

        command_map = handler._get_command_map("chatroom")
        self.assertIn("target", command_map)
        self.assertIn("a0", command_map)
        self.assertIn("a1", command_map)
        self.assertNotIn("a2", command_map)

    def test_unindex_plugin_commands_removes_aliases(self):
        handler = self._handler()
        data = {"aliases": ["alias"]}
        handler._index_command_lookup("private_chat", "plugin", "target", data)
        handler._unindex_plugin_commands("plugin")

        self.assertEqual({}, handler._get_command_map("private_chat"))

    def test_rebuild_command_map_restores_shadowed_command_after_disable(self):
        handler = self._handler()
        first = SimpleNamespace(commands={"same": {"callback_chatroom": Mock(return_value=True)}},
                                __publiccommands__=[], __privatecommands__=[], output=Mock())
        second_callback = Mock(return_value=True)
        second = SimpleNamespace(commands={"same": {"callback_chatroom": second_callback}},
                                 __publiccommands__=[], __privatecommands__=[], output=Mock())
        handler.enabled_plugins["first"] = first
        handler.enabled_plugins["second"] = second
        handler.commands["chatroom"]["same"] = first.commands["same"]
        handler._index_command_lookup("chatroom", "first", "same", first.commands["same"])

        # Simulate removing the first plugin, then rebuilding direct lookup maps.
        del handler.enabled_plugins["first"]
        handler.commands["chatroom"]["same"] = second.commands["same"]
        handler._rebuild_command_map()

        self.assertTrue(handler._trigger_command("same", "args", room="room"))
        second_callback.assert_called_once_with("args", room="room")


class PluginHandlerListAndQuitTest(TestCase):

    def test_quit_disables_enabled_plugins_without_scanning_installed_plugin_dirs(self):
        handler = object.__new__(PluginHandler)
        handler.enabled_plugins = {"first": object(), "second": object()}

        with patch.object(PluginHandler, "shutdown_notification") as shutdown, \
                patch.object(PluginHandler, "list_installed_plugins", side_effect=AssertionError("scanned")), \
                patch.object(PluginHandler, "disable_plugin") as disable_plugin:
            handler._quit()  # pylint: disable=protected-access

        shutdown.assert_called_once_with()
        self.assertEqual([("first",), ("second",)], [call.args for call in disable_plugin.call_args_list])
        self.assertTrue(all(call.kwargs == {"is_permanent": False} for call in disable_plugin.call_args_list))


    def test_list_installed_plugins_does_not_follow_symlinked_dirs(self):
        if not hasattr(os, "symlink"):
            self.skipTest("platform does not support symlinks")

        with TemporaryDirectory() as plugin_dir, TemporaryDirectory() as target_dir:
            os.mkdir(os.path.join(plugin_dir, "real_plugin"))
            os.symlink(target_dir, os.path.join(plugin_dir, "linked_plugin"), target_is_directory=True)

            handler = object.__new__(PluginHandler)
            handler.plugin_folders = [plugin_dir]
            handler._load_now_playing_sender = True

            self.assertEqual(["real_plugin"], handler.list_installed_plugins())

    def test_list_installed_plugins_is_bounded_and_deduplicated(self):
        old_limit = PluginHandler.MAX_INSTALLED_PLUGINS

        try:
            PluginHandler.MAX_INSTALLED_PLUGINS = 2

            with TemporaryDirectory() as first_dir, TemporaryDirectory() as second_dir:
                for folder, names in ((first_dir, ("a", "b", "c")), (second_dir, ("a", "d"))):
                    for name in names:
                        os.mkdir(os.path.join(folder, name))

                handler = object.__new__(PluginHandler)
                handler.plugin_folders = [first_dir, second_dir]
                handler._load_now_playing_sender = True

                self.assertEqual(["a", "b"], handler.list_installed_plugins())

        finally:
            PluginHandler.MAX_INSTALLED_PLUGINS = old_limit

