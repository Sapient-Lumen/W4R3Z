# COPYRIGHT (C) 2020-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import pynicotine
import time

from collections import deque
from ipaddress import ip_address as parse_ip_address

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.slskmessages import ChangePassword
from pynicotine.slskmessages import CheckPrivileges
from pynicotine.slskmessages import GetPeerAddress
from pynicotine.slskmessages import GetUserStats
from pynicotine.slskmessages import GetUserStatus
from pynicotine.slskmessages import GivePrivileges
from pynicotine.slskmessages import LoginFailure
from pynicotine.slskmessages import SetStatus
from pynicotine.slskmessages import SlskMessage
from pynicotine.slskmessages import UnwatchUser
from pynicotine.slskmessages import UserStatus
from pynicotine.slskmessages import WatchUser
from pynicotine.utils import UINT32_LIMIT
from pynicotine.utils import open_uri


class WatchedUser:

    __slots__ = ("username", "upload_speed", "files", "folders", "contexts", "is_implicit")

    def __init__(self, username):

        self.username = username
        self.upload_speed = None
        self.files = None
        self.folders = None
        self.contexts = set()
        self.is_implicit = True


class Users:
    __slots__ = ("login_status", "login_username", "public_ip_address", "public_port",
                 "server_hostname", "server_port", "privileges_left", "_should_open_privileges_url",
                 "addresses", "countries", "statuses", "watched", "privileged", "_ip_requested",
                 "_ip_request_times", "_stats_requested", "_ip_requested_limit_logged", "_stats_requested_limit_logged",
                 "_privileged_limit_logged", "_watched_users_limit_logged", "_watch_contexts_limit_logged",
                 "_pending_watch_removals", "_pending_watch_removals_limit_logged", "_admin_message_times",
                 "_admin_message_limit_logged", "_pending_password_changes",
                 "_password_change_limit_logged", "_pending_privilege_checks",
                 "_privilege_check_limit_logged", "_pending_privilege_gifts",
                 "_privilege_gift_timer_id", "_privilege_gift_limit_logged",
                 "_server_user_request_retries", "_server_user_request_retry_keys",
                 "_server_user_request_retry_timer_id", "_server_user_request_retry_limit_logged",
                 "_last_watch_failure_retryable", "_status_retry_msg", "_status_retry_timer_id")
    USERNAME_MAX_LENGTH = 30
    MAX_PENDING_IP_REQUESTS = 8192
    MAX_PENDING_USER_STATS_REQUESTS = 8192
    IP_REQUEST_RETENTION = 60
    USER_STATS_REQUEST_RETENTION = 60
    MAX_PRIVILEGED_USERS = 100000
    MAX_WATCHED_USERS = 100000
    MAX_WATCH_CONTEXTS_PER_USER = 1024
    MAX_PENDING_WATCH_REMOVALS = 8192
    MAX_ADMIN_MESSAGES_PER_MINUTE = 5
    ADMIN_MESSAGE_RATE_PERIOD = 60
    MAX_PENDING_PASSWORD_CHANGES = 4
    MAX_PENDING_PRIVILEGE_CHECKS = 8
    MAX_PENDING_PRIVILEGE_GIFTS = 128
    MAX_PRIVILEGE_GIFTS_PER_TICK = 16
    PRIVILEGE_GIFT_RETRY_DELAY = 1
    STATUS_RETRY_DELAY = 1
    MAX_PENDING_SERVER_USER_REQUEST_RETRIES = 8192
    MAX_SERVER_USER_REQUEST_RETRIES_PER_TICK = 256
    SERVER_USER_REQUEST_RETRY_DELAY = 1

    def __init__(self):

        self.login_status = UserStatus.OFFLINE
        self.login_username = None  # Only present while logged in
        self.public_ip_address = None
        self.public_port = None
        self.server_hostname = None
        self.server_port = None
        self.privileges_left = None
        self._should_open_privileges_url = False

        self.addresses = {}
        self.countries = {}
        self.statuses = {}
        self.watched = {}
        self.privileged = set()
        self._ip_requested = {}
        self._ip_request_times = {}
        self._stats_requested = {}
        self._ip_requested_limit_logged = False
        self._stats_requested_limit_logged = False
        self._privileged_limit_logged = False
        self._watched_users_limit_logged = False
        self._watch_contexts_limit_logged = False
        self._pending_watch_removals = set()
        self._pending_watch_removals_limit_logged = False
        self._admin_message_times = deque()
        self._admin_message_limit_logged = False
        self._pending_password_changes = set()
        self._password_change_limit_logged = False
        self._pending_privilege_checks = 0
        self._privilege_check_limit_logged = False
        self._pending_privilege_gifts = deque()
        self._privilege_gift_timer_id = None
        self._privilege_gift_limit_logged = False
        self._server_user_request_retries = deque()
        self._server_user_request_retry_keys = set()
        self._server_user_request_retry_timer_id = None
        self._server_user_request_retry_limit_logged = False
        self._last_watch_failure_retryable = False
        self._status_retry_msg = None
        self._status_retry_timer_id = None

        for event_name, callback in (
            ("admin-message", self._admin_message),
            ("change-password", self._change_password),
            ("check-privileges", self._check_privileges),
            ("connect-to-peer", self._connect_to_peer),
            ("peer-address", self._get_peer_address),
            ("privileged-users", self._privileged_users),
            ("server-disconnect", self._server_disconnect),
            ("server-login", self._server_login),
            ("server-message-unsent", self._server_message_unsent),
            ("user-stats", self._user_stats),
            ("user-status", self._user_status),
            ("watch-user", self._watch_user)
        ):
            events.connect(event_name, callback)

    def set_away_mode(self, is_away, save_state=False):

        new_status = UserStatus.AWAY if is_away else UserStatus.ONLINE

        if self.request_set_status(new_status) is False:
            return False

        if save_state:
            config.sections["server"]["away"] = is_away

        self.login_status = new_status

        # Fake a user status message, since server doesn't send updates when we
        # disable away mode. Only do this after the SetStatus request is queued
        # locally; otherwise local/UI state can diverge from the server when the
        # network queue rejects the status message under backpressure.
        events.emit("user-status", GetUserStatus(self.login_username, self.login_status))
        return True


    def _cancel_status_retry(self):
        timer_id = getattr(self, "_status_retry_timer_id", None)

        if timer_id is not None:
            events.cancel_scheduled(timer_id)

        self._status_retry_timer_id = None
        self._status_retry_msg = None

    def _schedule_status_retry(self, delay=0):
        if self._status_retry_msg is None or self._status_retry_timer_id is not None:
            return

        self._status_retry_timer_id = events.schedule(delay=delay, callback=self._process_status_retry)

        if self._status_retry_timer_id is None:
            # Scheduler backpressure should not create an unbounded status
            # retry backlog. Keep local/UI state as the user's requested state,
            # but drop the retry until the user changes status again.
            self._status_retry_msg = None

    def _queue_status_retry(self, msg):
        if getattr(msg, "status", None) != self.login_status:
            return False

        self._status_retry_msg = msg
        self._schedule_status_retry(delay=self.STATUS_RETRY_DELAY)
        return True

    def _process_status_retry(self):
        self._status_retry_timer_id = None
        msg = self._status_retry_msg

        if msg is None:
            return

        if getattr(msg, "status", None) != self.login_status:
            self._status_retry_msg = None
            return

        if core.send_message_to_server(msg) is False:
            self._schedule_status_retry(delay=self.STATUS_RETRY_DELAY)
            return

        self._status_retry_msg = None


    def _ensure_server_user_request_retry_state(self):
        if not hasattr(self, "_server_user_request_retries"):
            self._server_user_request_retries = deque()
            self._server_user_request_retry_keys = set()
            self._server_user_request_retry_timer_id = None
            self._server_user_request_retry_limit_logged = False

    def _cancel_server_user_request_retries(self):
        self._ensure_server_user_request_retry_state()

        if self._server_user_request_retry_timer_id is not None:
            events.cancel_scheduled(self._server_user_request_retry_timer_id)

        self._server_user_request_retries.clear()
        self._server_user_request_retry_keys.clear()
        self._server_user_request_retry_timer_id = None
        self._server_user_request_retry_limit_logged = False

    def _schedule_server_user_request_retries(self, delay=0):
        self._ensure_server_user_request_retry_state()

        if not self._server_user_request_retries or self._server_user_request_retry_timer_id is not None:
            return

        self._server_user_request_retry_timer_id = events.schedule(
            delay=delay, callback=self._process_server_user_request_retries)

        if self._server_user_request_retry_timer_id is None:
            # Do not retain an unbounded retry backlog if the shared scheduler
            # is saturated. The cap below limits steady-state growth; scheduler
            # rejection means the process is already shedding work.
            self._server_user_request_retries.clear()
            self._server_user_request_retry_keys.clear()

    def _queue_server_user_request_retry(self, msg_class, username, delay=None, front=False):
        self._ensure_server_user_request_retry_state()

        if self.login_status == UserStatus.OFFLINE or not username:
            return False

        key = (msg_class, username)

        if key in self._server_user_request_retry_keys:
            return True

        if len(self._server_user_request_retries) >= self.MAX_PENDING_SERVER_USER_REQUEST_RETRIES:
            if not self._server_user_request_retry_limit_logged:
                log.add_debug(
                    "Discarding server user request retry for %s; pending user request retry limit reached.",
                    username)
                self._server_user_request_retry_limit_logged = True

            return False

        if front:
            self._server_user_request_retries.appendleft(key)
        else:
            self._server_user_request_retries.append(key)

        self._server_user_request_retry_keys.add(key)
        self._schedule_server_user_request_retries(
            self.SERVER_USER_REQUEST_RETRY_DELAY if delay is None else delay)
        return True

    def _process_server_user_request_retries(self):
        self._ensure_server_user_request_retry_state()
        self._server_user_request_retry_timer_id = None

        processed = 0
        retry_delay = 0

        while (self._server_user_request_retries
                and processed < self.MAX_SERVER_USER_REQUEST_RETRIES_PER_TICK):
            msg_class, username = self._server_user_request_retries.popleft()
            self._server_user_request_retry_keys.discard((msg_class, username))
            processed += 1

            if self.login_status == UserStatus.OFFLINE:
                continue

            if msg_class is WatchUser:
                watched_user = self.watched.get(username)

                if watched_user is None or watched_user.is_implicit or not watched_user.contexts:
                    continue

                msg = WatchUser(username)

            elif msg_class is UnwatchUser:
                watched_user = self.watched.get(username)

                # If the user has been explicitly watched again before the
                # deferred UnwatchUser retry runs, do not send a stale unwatch
                # that would cancel the new watch on the server.
                if watched_user is not None and not watched_user.is_implicit:
                    continue

                msg = UnwatchUser(username)

            elif msg_class is GetUserStatus:
                watched_user = self.watched.get(username)

                if watched_user is None or watched_user.is_implicit:
                    continue

                msg = GetUserStatus(username)

            else:
                continue

            if core.send_message_to_server(msg) is False:
                self._queue_server_user_request_retry(
                    msg_class, username, delay=self.SERVER_USER_REQUEST_RETRY_DELAY, front=True)
                retry_delay = self.SERVER_USER_REQUEST_RETRY_DELAY
                break

            if msg_class is WatchUser and core.send_message_to_server(GetUserStatus(username)) is False:
                self._queue_server_user_request_retry(
                    GetUserStatus, username, delay=self.SERVER_USER_REQUEST_RETRY_DELAY)

        if self._server_user_request_retries:
            self._schedule_server_user_request_retries(delay=retry_delay)
        else:
            self._server_user_request_retry_limit_logged = False

    def open_privileges_url(self):

        default_server_hostname, _port = config.defaults["server"]["server"]
        default_server_domain = default_server_hostname.split(".", maxsplit=1)[-1]

        if not self.server_hostname or not self.server_hostname.endswith(f".{default_server_domain}"):
            # Only official server is supported for now
            return

        import urllib.parse

        login = urllib.parse.quote(self.login_username)
        open_uri(pynicotine.__privileges_url__ % login)

    def request_change_password(self, password):

        password = SlskMessage.truncate_string_bytes(password, SlskMessage.MAX_PASSWORD_FIELD_BYTES)

        if len(self._pending_password_changes) >= self.MAX_PENDING_PASSWORD_CHANGES:
            if not self._password_change_limit_logged:
                log.add_debug(
                    "Discarding password change request; pending password-change limit reached.")
                self._password_change_limit_logged = True

            return False

        if core.send_message_to_server(ChangePassword(password)) is False:
            return False

        self._pending_password_changes.add(password)
        self._password_change_limit_logged = False
        return True

    def request_check_privileges(self, should_open_url=False):
        if self._pending_privilege_checks >= self.MAX_PENDING_PRIVILEGE_CHECKS:
            if not self._privilege_check_limit_logged:
                log.add_debug(
                    "Discarding privilege check request; pending privilege-check limit reached.")
                self._privilege_check_limit_logged = True

            return False

        if core.send_message_to_server(CheckPrivileges()) is False:
            return False

        self._pending_privilege_checks += 1
        self._privilege_check_limit_logged = False

        if should_open_url:
            self._should_open_privileges_url = True

        return True

    def _schedule_privilege_gift_retry(self, delay=0):
        if self._privilege_gift_timer_id is not None:
            return

        self._privilege_gift_timer_id = events.schedule(delay=delay, callback=self._process_privilege_gift_retries)

        if self._privilege_gift_timer_id is None:
            self._pending_privilege_gifts.clear()
            self._privilege_gift_limit_logged = False

    def _queue_privilege_gift_retry(self, username, days):
        if len(self._pending_privilege_gifts) >= self.MAX_PENDING_PRIVILEGE_GIFTS:
            if not self._privilege_gift_limit_logged:
                log.add_debug(
                    "Discarding privilege gift to %s; pending privilege-gift retry limit reached.", username)
                self._privilege_gift_limit_logged = True

            return False

        self._pending_privilege_gifts.append((username, days))
        self._schedule_privilege_gift_retry(delay=self.PRIVILEGE_GIFT_RETRY_DELAY)
        return True

    def _process_privilege_gift_retries(self):
        self._privilege_gift_timer_id = None
        num_processed = 0

        while (self._pending_privilege_gifts
                and num_processed < self.MAX_PRIVILEGE_GIFTS_PER_TICK
                and self.login_status != UserStatus.OFFLINE):
            username, days = self._pending_privilege_gifts.popleft()
            num_processed += 1

            if core.send_message_to_server(GivePrivileges(username, days)) is False:
                self._pending_privilege_gifts.appendleft((username, days))
                self._schedule_privilege_gift_retry(delay=self.PRIVILEGE_GIFT_RETRY_DELAY)
                return

        if self._pending_privilege_gifts and self.login_status != UserStatus.OFFLINE:
            self._schedule_privilege_gift_retry(delay=self.PRIVILEGE_GIFT_RETRY_DELAY)
        else:
            self._privilege_gift_limit_logged = False

    def request_give_privileges(self, username, days):
        if not UINT32_LIMIT >= days > 0:
            return False

        if core.send_message_to_server(GivePrivileges(username, days)) is False:
            return self._queue_privilege_gift_retry(username, days)

        return True

    def _ensure_ip_request_times(self):
        if not hasattr(self, "_ip_request_times"):
            self._ip_request_times = {}

    def _prune_ip_requests(self, now):
        self._ensure_ip_request_times()
        cutoff_time = now - self.IP_REQUEST_RETENTION

        for username, request_time in tuple(self._ip_request_times.items()):
            if request_time >= cutoff_time:
                continue

            self._ip_request_times.pop(username, None)
            self._ip_requested.pop(username, None)

    def request_ip_address(self, username, notify=False):

        request_time = time.monotonic()
        self._prune_ip_requests(request_time)

        if username in self._ip_requested:
            if notify:
                self._ip_requested[username] = True
            return True

        if len(self._ip_requested) >= self.MAX_PENDING_IP_REQUESTS:
            if not self._ip_requested_limit_logged:
                log.add_debug(
                    "Discarding peer address request for %s; pending address request limit "
                    "reached.", username)
                self._ip_requested_limit_logged = True

            return False

        if core.send_message_to_server(GetPeerAddress(username)) is False:
            return False

        self._ip_requested[username] = notify
        self._ip_request_times[username] = request_time
        return True

    def request_set_status(self, status):
        return core.send_message_to_server(SetStatus(status))

    def request_user_stats(self, username):
        request_time = time.monotonic()
        min_request_time = request_time - self.USER_STATS_REQUEST_RETENTION
        existing_request_time = self._stats_requested.get(username)

        if existing_request_time is not None:
            if existing_request_time >= min_request_time:
                return False

            del self._stats_requested[username]

        if len(self._stats_requested) >= self.MAX_PENDING_USER_STATS_REQUESTS:
            self._stats_requested = {
                current_username: current_request_time
                for current_username, current_request_time in self._stats_requested.items()
                if current_request_time >= min_request_time
            }

            if len(self._stats_requested) >= self.MAX_PENDING_USER_STATS_REQUESTS:
                if not self._stats_requested_limit_logged:
                    log.add_debug(
                        "Discarding user stats request for %s; pending user stats request limit reached.",
                        username)
                    self._stats_requested_limit_logged = True

                return False

        if core.send_message_to_server(GetUserStats(username)) is False:
            return False

        self._stats_requested_limit_logged = False
        self._stats_requested[username] = request_time
        return True

    def _add_privileged_user(self, username):

        if username in self.privileged:
            return True

        if len(self.privileged) >= self.MAX_PRIVILEGED_USERS:
            if not self._privileged_limit_logged:
                log.add_debug(
                    "Discarding privileged user %s; privileged user cache limit reached.",
                    username)
                self._privileged_limit_logged = True

            return False

        self.privileged.add(username)
        return True

    def _remove_privileged_user(self, username):
        self.privileged.discard(username)

    def _add_pending_watch_removal(self, username):

        if username not in self.watched:
            return False

        if username in self._pending_watch_removals:
            return True

        if len(self._pending_watch_removals) >= self.MAX_PENDING_WATCH_REMOVALS:
            if not self._pending_watch_removals_limit_logged:
                log.add_debug(
                    "Discarding pending watch removal for %s; pending watch-removal "
                    "limit reached.", username)
                self._pending_watch_removals_limit_logged = True

            return False

        self._pending_watch_removals.add(username)
        return True

    @property
    def last_watch_failure_retryable(self):
        return self._last_watch_failure_retryable

    def watch_user(self, username, context=None, is_implicit=False):
        """Tells the server we want to be notified of status updates for a
        user.

        context is a string specifying where the user is being watched.
        The same context must be provided when calling unwatch_user(), when
        we no longer wish to receive updates for the user in said context.

        is_implicit is set when receiving status updates from the server
        without sending a message first. At present, this only happens for
        users in a joined chat room.
        """

        self._last_watch_failure_retryable = False

        if self.login_status == UserStatus.OFFLINE:
            return False

        watched_user = self.watched.get(username)

        if watched_user is None:
            if len(self.watched) >= self.MAX_WATCHED_USERS and username != self.login_username:
                if not self._watched_users_limit_logged:
                    log.add_debug(
                        "Discarding watch request for %s; watched user limit reached.", username)
                    self._watched_users_limit_logged = True

                return False

            self.watched[username] = watched_user = WatchedUser(username)

        if not context:
            log.add("Calling watch_user() without providing a 'context' argument is deprecated.")
            context = "unknown"

        if context in watched_user.contexts:
            return True

        if is_implicit and len(watched_user.contexts) >= self.MAX_WATCH_CONTEXTS_PER_USER:
            if not self._watch_contexts_limit_logged:
                log.add_debug(
                    "Discarding implicit watch context '%s' for user %s; per-user watch-context "
                    "limit of %s reached.", (context, username, self.MAX_WATCH_CONTEXTS_PER_USER))
                self._watch_contexts_limit_logged = True

            return False

        if not is_implicit and watched_user.is_implicit:
            if core.send_message_to_server(WatchUser(username)) is False:
                if not watched_user.contexts:
                    self.watched.pop(username, None)

                self._last_watch_failure_retryable = True
                return False

            # Supplemental privilege lookup. If this is rejected by the local
            # network queue, still keep the watch: the primary WatchUser request
            # was accepted and status updates will arrive normally.
            if core.send_message_to_server(GetUserStatus(username)) is False:
                self._queue_server_user_request_retry(GetUserStatus, username)
            watched_user.is_implicit = False

        watched_user.contexts.add(context)
        log.add_conn("Watching user %s in context '%s'. Active context count: %s",
                     (username, context, len(watched_user.contexts)))
        return True

    def unwatch_user(self, username, context):
        """Tells the server we no longer wish to receive status updates for a
        user.

        context must be the same as previously provided when calling watch_user().
        """

        watched_user = self.watched.get(username)

        if watched_user is None:
            return False

        had_context = context in watched_user.contexts
        watched_user.contexts.discard(context)
        log.add_conn("Unwatching user %s in context '%s'. Remaining context count: %s",
                     (username, context, len(watched_user.contexts)))

        if watched_user.contexts:
            return True

        if not watched_user.is_implicit and core.send_message_to_server(UnwatchUser(username)) is False:
            # Do not tear down local watch state when the corresponding
            # UnwatchUser request never reaches the local network queue. If we
            # dropped local state here, the server would continue sending status
            # updates for a watch the client no longer tracks or can cleanly
            # retry.
            if had_context:
                watched_user.contexts.add(context)

            return False

        if username in self.addresses:
            del self.addresses[username]

        if username in self.countries:
            del self.countries[username]

        if username in self.statuses:
            del self.statuses[username]

        del self.watched[username]
        return True


    def _server_message_unsent(self, msg):
        """Rollback request ledgers for server messages dropped below the public queue boundary."""

        msg_class = msg.__class__

        if msg_class is GetPeerAddress:
            self._ip_requested.pop(msg.user, None)
            self._ip_request_times.pop(msg.user, None)
            return

        if msg_class is GetUserStats:
            self._stats_requested.pop(msg.user, None)
            return

        if msg_class is ChangePassword:
            self._pending_password_changes.discard(msg.password)
            return

        if msg_class is CheckPrivileges:
            self._pending_privilege_checks = max(0, self._pending_privilege_checks - 1)

            if self._pending_privilege_checks == 0:
                self._should_open_privileges_url = False

            return

        if msg_class is GivePrivileges:
            self._queue_privilege_gift_retry(msg.user, msg.days)
            return

        if msg_class is SetStatus:
            self._queue_status_retry(msg)
            return

        if msg_class in {WatchUser, UnwatchUser, GetUserStatus}:
            self._queue_server_user_request_retry(msg_class, msg.user)

    def _server_disconnect(self, msg):

        self.login_status = UserStatus.OFFLINE

        if core.pluginhandler:
            core.pluginhandler.server_disconnect_notification(msg.manual_disconnect)

        # Clean up connections
        self.addresses.clear()
        self.countries.clear()
        self.statuses.clear()
        self.watched.clear()
        self.privileged.clear()
        self._ip_requested.clear()
        self._ip_request_times.clear()
        self._stats_requested.clear()
        self._ip_requested_limit_logged = False
        self._stats_requested_limit_logged = False
        self._privileged_limit_logged = False
        self._watched_users_limit_logged = False
        self._watch_contexts_limit_logged = False
        self._pending_watch_removals.clear()
        self._pending_watch_removals_limit_logged = False
        self._admin_message_times.clear()
        self._admin_message_limit_logged = False
        self._pending_password_changes.clear()
        self._password_change_limit_logged = False
        self._pending_privilege_checks = 0
        self._privilege_check_limit_logged = False
        events.cancel_scheduled(self._privilege_gift_timer_id)
        self._pending_privilege_gifts.clear()
        self._privilege_gift_timer_id = None
        self._privilege_gift_limit_logged = False
        self._cancel_server_user_request_retries()
        self._cancel_status_retry()

        self.login_username = None
        self.public_ip_address = None
        self.public_port = None
        self.server_hostname = None
        self.server_port = None
        self.privileges_left = None
        self._should_open_privileges_url = False

    def _server_login(self, msg):
        """Server code 1."""

        if msg.success:
            self.login_status = UserStatus.ONLINE
            self.login_username = username = msg.username
            _local_ip_address, self.public_port = msg.local_address
            self.server_hostname, self.server_port = msg.server_address
            self.addresses[username] = msg.local_address

            self.request_check_privileges()
            self.set_away_mode(config.sections["server"]["away"])
            self.watch_user(username, context="login")

            if msg.ip_address is not None:
                self.public_ip_address = msg.ip_address
                self.countries[username] = country_code = core.network_filter.get_country_code(msg.ip_address)
                events.emit("user-country", username, country_code)

            if msg.banner:
                log.add(msg.banner)

            core.pluginhandler.server_connect_notification()
            return

        if msg.reason == LoginFailure.USERNAME:
            events.emit("invalid-username")
            return

        if msg.reason == LoginFailure.PASSWORD:
            events.emit("invalid-password")
            return

        log.add(_("Unable to connect to the server. Reason: %s"), msg.reason, title=_("Cannot Connect"))

    @staticmethod
    def _is_valid_resolved_peer_address(ip_address, port):
        """Return whether a resolved peer endpoint should enter user/filter state."""

        try:
            port = int(port)

        except (TypeError, ValueError):
            return False

        if port <= 0 or port > 65535:
            return False

        try:
            ip_obj = parse_ip_address(ip_address)

        except ValueError:
            return False

        if ip_obj.version != 4:
            return False

        return not (
            ip_obj.is_unspecified
            or ip_obj.is_loopback
            or ip_obj.is_multicast
            or ip_obj.is_link_local
        )

    def _get_peer_address(self, msg):
        """Server code 3."""

        username = msg.user
        self._ensure_ip_request_times()
        address_requested = (username in self._ip_requested)
        notify = self._ip_requested.pop(username, None)
        self._ip_request_times.pop(username, None)

        if not address_requested:
            # Peer-address responses should be correlated with our own request.
            # Ignore unsolicited server/MITM messages instead of turning them
            # into plugin notifications, country lookups and cached addresses.
            # Also poison the event object for later peer-address listeners;
            # the event dispatcher does not stop propagation when one listener
            # rejects a message.
            msg.user = None
            return

        ip_address = msg.ip_address
        user_offline = (ip_address == "0.0.0.0" and msg.port == 0)

        if not user_offline and not self._is_valid_resolved_peer_address(ip_address, msg.port):
            log.add_debug("Ignoring invalid peer address response for user %s: %s:%s",
                          (username, ip_address, msg.port))
            msg.user = None
            return

        country_code = core.network_filter.get_country_code(ip_address)

        if user_offline:
            self.addresses.pop(username, None)
            self.countries.pop(username, None)

        elif username in self.watched:
            # Only cache IP address of watched users, otherwise we won't know if
            # a user reconnects and changes their IP address.
            # Don't update our own IP address, since we already store a local IP
            # address.

            if username != self.login_username:
                self.addresses[username] = (ip_address, msg.port)

            self.countries[username] = country_code
            events.emit("user-country", username, country_code)

        if not notify:
            core.pluginhandler.user_resolve_notification(username, ip_address, msg.port)
            return

        core.pluginhandler.user_resolve_notification(username, ip_address, msg.port, country_code)

        if user_offline:
            log.add(_("Cannot retrieve the IP of user %s, since this user is offline"), username)
            return

        if country_code:
            country_name = core.network_filter.COUNTRIES.get(country_code, _("Unknown"))
            country = f" ({country_code} / {country_name})"
        else:
            country = ""

        log.add(_("IP address of user %(user)s: %(ip)s, port %(port)i%(country)s"), {
            "user": username,
            "ip": msg.ip_address,
            "port": msg.port,
            "country": country
        }, title=_("IP Address"))

    def _watch_user(self, msg):
        """Server code 5."""

        username = msg.user
        is_self = (username == getattr(self, "login_username", None))
        is_watched = (username in self.watched)

        if not is_self and not is_watched:
            # WatchUser responses should only arrive for users we explicitly
            # watch (or for our own login username). Ignore unsolicited server
            # / MITM messages before they can remove local watch state or fan
            # out synthetic UserStats updates to plugins and GUI views.
            msg.user = None
            return

        if not msg.userexists:
            # User does not exist. The server will not keep us informed if the user is created
            # later, so we need to remove the user from our list.
            # Due to a bug, the server will in rare cases tell us a user doesn't exist, while
            # the user is actually online. Remove the user when we receive a UserStatus message
            # telling us the user is offline.
            self._add_pending_watch_removal(username)
            return

        if msg.contains_stats:
            status = msg.status

            if status not in {UserStatus.OFFLINE, UserStatus.ONLINE, UserStatus.AWAY}:
                log.add_debug("Received an unknown watch status %s for user %s from the server",
                              (status, username))
                msg.status = UserStatus.OFFLINE

            events.emit("user-stats", msg)

    def _user_status(self, msg):
        """Server code 7."""

        username = msg.user
        status = msg.status
        is_privileged = msg.privileged
        is_self = (username == getattr(self, "login_username", None))
        is_watched = (username in self.watched)

        if not is_self and not is_watched:
            # UserStatus messages are only useful for users we explicitly watch
            # (or our own login state). Ignore unsolicited server/MITM messages
            # before touching privilege caches or plugin callbacks.
            msg.user = None
            return

        if is_privileged is not None:
            if is_privileged:
                self._add_privileged_user(username)

            else:
                self._remove_privileged_user(username)

        if status not in {UserStatus.OFFLINE, UserStatus.ONLINE, UserStatus.AWAY}:
            log.add_debug("Received an unknown status %s for user %s from the server",
                          (status, username))
            status = msg.status = UserStatus.OFFLINE

        # Ignore invalid status updates for our own username in case we've already
        # changed our status again by the time they arrive from the server
        if is_self and status != self.login_status:
            msg.user = None
            return

        # User went offline, reset stored IP address and country
        if status == UserStatus.OFFLINE:
            self.addresses.pop(username, None)
            self.countries.pop(username, None)

            if username in self._pending_watch_removals:
                # User does not exist, remove it from list
                log.add_conn("Unwatching non-existent user %s", username)
                self.watched.pop(username, None)

        elif is_watched:
            user_status = self.statuses.get(username)

            # Online user seen for the first time, request IP address and country
            if user_status is None:
                self.request_ip_address(username)

            # Previously watched user logged in again. Server will not send user stats, so request them.
            elif user_status == UserStatus.OFFLINE:
                self.request_user_stats(username)
                self.request_ip_address(username)

        if is_watched:
            self.statuses[username] = status

        self._pending_watch_removals.discard(username)
        core.pluginhandler.user_status_notification(username, status, msg.privileged)

    def _connect_to_peer(self, msg):
        """Server code 18."""

        username = msg.user
        is_privileged = msg.privileged

        if is_privileged is None:
            return

        if is_privileged:
            self._add_privileged_user(username)

        else:
            self._remove_privileged_user(username)

    def _user_stats(self, msg):
        """Server code 36."""

        username = msg.user
        upload_speed = msg.avgspeed
        files = msg.files
        folders = msg.dirs
        is_requested = (self._stats_requested.pop(username, None) is not None)

        if username != self.login_username and username not in self.watched and not is_requested:
            # UserStats messages are normally responses to our own requests, or
            # updates for users we watch. Ignore unsolicited server/MITM stats
            # before fanning them out to plugins and GUI/user-list handlers.
            msg.user = None
            return

        stats = self.watched.get(username)

        if stats is not None:
            stats.upload_speed = upload_speed
            stats.files = files
            stats.folders = folders

        core.pluginhandler.user_stats_notification(username, stats={
            "avgspeed": upload_speed,
            "files": files,
            "dirs": folders,
            "shared_size": None,
            "source": "server"
        })

    def _admin_message(self, msg):
        """Server code 66."""

        now = time.monotonic()
        cutoff_time = now - self.ADMIN_MESSAGE_RATE_PERIOD

        while self._admin_message_times and self._admin_message_times[0] <= cutoff_time:
            self._admin_message_times.popleft()

        if len(self._admin_message_times) >= self.MAX_ADMIN_MESSAGES_PER_MINUTE:
            if not self._admin_message_limit_logged:
                log.add_debug("Admin message rate limit of %s per minute reached, ignoring further announcements",
                              self.MAX_ADMIN_MESSAGES_PER_MINUTE)
                self._admin_message_limit_logged = True
            return

        self._admin_message_times.append(now)
        log.add(msg.msg, title=_("Soulseek Announcement"))

    def _privileged_users(self, msg):
        """Server code 69."""

        for username in msg.users:
            if not self._add_privileged_user(username):
                break

    def _check_privileges(self, msg):
        """Server code 92."""

        if self._pending_privilege_checks <= 0:
            # Privilege responses should correspond to a local request. Ignore
            # unsolicited server/MITM messages instead of letting them alter
            # privilege state or trigger the privilege-purchase URL path.
            msg.seconds = None
            return

        self._pending_privilege_checks -= 1

        mins = msg.seconds // 60
        hours = mins // 60
        days = hours // 24

        if msg.seconds <= 0:
            log.add(_("You have no Soulseek privileges. While privileges are active, your downloads "
                      "will be queued ahead of those of non-privileged users."))

            if self._should_open_privileges_url:
                self.open_privileges_url()
        else:
            log.add(_("%(days)i days, %(hours)i hours, %(minutes)i minutes, %(seconds)i seconds of "
                      "Soulseek privileges left"), {
                "days": days,
                "hours": hours % 24,
                "minutes": mins % 60,
                "seconds": msg.seconds % 60
            })

        self.privileges_left = msg.seconds
        self._should_open_privileges_url = False

    def _change_password(self, msg):
        """Server code 142."""

        password = msg.password

        if password not in self._pending_password_changes:
            # Password-change responses should correspond to an explicit local
            # request. Ignore unsolicited server/MITM responses instead of
            # silently overwriting the saved login secret.
            msg.password = None
            return

        self._pending_password_changes.discard(password)

        config.sections["server"]["passw"] = password
        config.write_configuration()

        log.add(_("Your password has been changed"), title=_("Password Changed"))
