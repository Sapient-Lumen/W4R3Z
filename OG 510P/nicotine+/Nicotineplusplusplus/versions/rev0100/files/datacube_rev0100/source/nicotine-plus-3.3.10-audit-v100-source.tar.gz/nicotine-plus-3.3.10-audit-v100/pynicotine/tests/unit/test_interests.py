# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE

from collections import deque
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

from pynicotine.slskmessages import AddThingIHate
from pynicotine.slskmessages import AddThingILike
from pynicotine.slskmessages import GlobalRecommendations
from pynicotine.slskmessages import ItemRecommendations
from pynicotine.slskmessages import ItemSimilarUsers
from pynicotine.slskmessages import Recommendations
from pynicotine.slskmessages import RemoveThingIHate
from pynicotine.slskmessages import RemoveThingILike
from pynicotine.slskmessages import SimilarUsers
from pynicotine.slskmessages import clear_interests_response_grants

import pynicotine.interests as interests_module
import pynicotine.watchbatch as watchbatch_module
from pynicotine.interests import Interests
from pynicotine.interests import SimilarUser
from pynicotine.watchbatch import WatchUserBatcher


class InterestsTest(TestCase):

    # pylint: disable=protected-access

    def tearDown(self):
        clear_interests_response_grants()

    @staticmethod
    def _make_fake_core():
        return SimpleNamespace(
            users=SimpleNamespace(
                watch_user=Mock(),
                unwatch_user=Mock()
            )
        )

    @staticmethod
    def _new_interests():
        interests = object.__new__(Interests)
        interests.similar_users = {}
        interests._similar_users_limit_logged = False
        interests._unwatch_queue = deque()
        interests._unwatch_keys = set()
        interests._unwatch_timer_id = None
        interests._unwatch_limit_logged = False
        interests._pending_recommendations = False
        interests._pending_global_recommendations = False
        interests._pending_similar_users = False
        interests._pending_item_recommendations = set()
        interests._pending_item_similar_users = set()
        interests._pending_interest_response_limit_logged = False
        interests._interest_sync_queue = deque()
        interests._interest_sync_keys = set()
        interests._interest_sync_timer_id = None
        interests._interest_sync_limit_logged = False
        interests._interest_request_retry_queue = deque()
        interests._interest_request_retry_keys = set()
        interests._interest_request_retry_timer_id = None
        interests._interest_request_retry_limit_logged = False
        interests._watch_batcher = WatchUserBatcher(
            "interests", lambda username: username in interests.similar_users,
            lambda: Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK,
            lambda: Interests.MAX_PENDING_SIMILAR_USER_WATCHES
        )
        return interests



    def test_interest_config_changes_follow_queue_acceptance(self):
        interests = self._new_interests()
        fake_config = SimpleNamespace(
            sections={"interests": {"likes": [], "dislikes": ["oldhate"]}},
            write_configuration=Mock()
        )
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=False))
        fake_events = SimpleNamespace(emit=Mock())

        with patch.object(interests_module, "config", fake_config), \
                patch.object(interests_module, "core", fake_core), \
                patch.object(interests_module, "events", fake_events):
            self.assertFalse(interests.add_thing_i_like("Artist"))
            self.assertFalse(interests.remove_thing_i_hate("oldhate"))

        self.assertEqual([], fake_config.sections["interests"]["likes"])
        self.assertEqual(["oldhate"], fake_config.sections["interests"]["dislikes"])
        fake_config.write_configuration.assert_not_called()
        fake_events.emit.assert_not_called()

        fake_core.send_message_to_server.return_value = True

        with patch.object(interests_module, "config", fake_config), \
                patch.object(interests_module, "core", fake_core), \
                patch.object(interests_module, "events", fake_events):
            self.assertTrue(interests.add_thing_i_like("Artist"))
            self.assertTrue(interests.add_thing_i_hate("Song"))
            self.assertTrue(interests.remove_thing_i_like("artist"))
            self.assertTrue(interests.remove_thing_i_hate("song"))

        self.assertEqual([], fake_config.sections["interests"]["likes"])
        self.assertEqual(["oldhate"], fake_config.sections["interests"]["dislikes"])
        self.assertEqual(4, fake_config.write_configuration.call_count)
        sent_types = [type(call.args[0]) for call in fake_core.send_message_to_server.call_args_list[-4:]]
        self.assertEqual([AddThingILike, AddThingIHate, RemoveThingILike, RemoveThingIHate], sent_types)

    def test_unsolicited_similar_users_response_is_dropped_before_watch_fanout(self):
        interests = self._new_interests()
        fake_core = self._make_fake_core()
        msg = SimpleNamespace(users={"user1": 10, "user2": 9}, is_allowed=True)

        with patch("pynicotine.interests.core", fake_core), patch("pynicotine.watchbatch.core", fake_core):
            interests._similar_users(msg)

        self.assertFalse(msg.is_allowed)
        self.assertEqual({}, msg.users)
        self.assertEqual({}, interests.similar_users)
        fake_core.users.watch_user.assert_not_called()

    def test_requested_similar_users_response_is_consumed_once(self):
        interests = self._new_interests()
        fake_core = self._make_fake_core()
        msg = SimpleNamespace(users={"user1": 10}, is_allowed=True)

        interests._pending_similar_users = True

        with patch("pynicotine.interests.core", fake_core), patch("pynicotine.watchbatch.core", fake_core):
            interests._similar_users(msg)

        self.assertTrue(msg.is_allowed)
        self.assertFalse(interests._pending_similar_users)
        self.assertIn("user1", interests.similar_users)
        fake_core.users.watch_user.assert_called_once_with("user1", context="interests")

    def test_unsolicited_item_recommendations_response_is_dropped(self):
        interests = self._new_interests()
        msg = SimpleNamespace(thing="artist", recommendations=[("artist2", 1)], unrecommendations=[], is_allowed=True)

        interests._item_recommendations(msg)

        self.assertFalse(msg.is_allowed)
        self.assertEqual([], msg.recommendations)

    def test_item_recommendations_request_grant_is_capped(self):
        interests = self._new_interests()
        fake_core = SimpleNamespace(send_message_to_server=Mock())
        old_limit = Interests.MAX_PENDING_ITEM_RECOMMENDATION_REQUESTS
        Interests.MAX_PENDING_ITEM_RECOMMENDATION_REQUESTS = 1

        try:
            with patch("pynicotine.interests.core", fake_core):
                self.assertTrue(interests.request_item_recommendations("artist1"))
                self.assertFalse(interests.request_item_recommendations("artist2"))

            self.assertEqual({"artist1"}, interests._pending_item_recommendations)
            self.assertEqual(1, fake_core.send_message_to_server.call_count)

        finally:
            Interests.MAX_PENDING_ITEM_RECOMMENDATION_REQUESTS = old_limit


    def test_recommendation_grants_follow_queue_acceptance(self):
        interests = self._new_interests()
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=False))

        with patch("pynicotine.interests.core", fake_core):
            self.assertFalse(interests.request_recommendations())
            self.assertFalse(interests._pending_recommendations)
            self.assertFalse(interests.request_global_recommendations())
            self.assertFalse(interests._pending_global_recommendations)
            self.assertFalse(interests.request_similar_users())
            self.assertFalse(interests._pending_similar_users)
            self.assertFalse(interests.request_item_recommendations("artist"))
            self.assertNotIn("artist", interests._pending_item_recommendations)
            self.assertFalse(interests.request_item_similar_users("artist"))
            self.assertNotIn("artist", interests._pending_item_similar_users)

        fake_core.send_message_to_server.return_value = True

        with patch("pynicotine.interests.core", fake_core):
            self.assertTrue(interests.request_recommendations())
            self.assertTrue(interests._pending_recommendations)
            self.assertTrue(interests.request_global_recommendations())
            self.assertTrue(interests._pending_global_recommendations)
            self.assertTrue(interests.request_similar_users())
            self.assertTrue(interests._pending_similar_users)
            self.assertTrue(interests.request_item_recommendations("artist"))
            self.assertIn("artist", interests._pending_item_recommendations)
            self.assertTrue(interests.request_item_similar_users("song"))
            self.assertIn("song", interests._pending_item_similar_users)

    def test_similar_users_response_is_capped_before_watch_fanout(self):
        interests = self._new_interests()

        old_limit = Interests.MAX_SIMILAR_USERS
        old_watch = Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK
        Interests.MAX_SIMILAR_USERS = 2
        Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK = 10
        fake_core = self._make_fake_core()
        msg = SimpleNamespace(users={"user1": 10, "user2": 9, "user3": 8})

        interests._pending_similar_users = True

        try:
            with patch("pynicotine.interests.core", fake_core), patch("pynicotine.watchbatch.core", fake_core):
                interests._similar_users(msg)

            self.assertEqual({"user1", "user2"}, set(interests.similar_users))
            self.assertEqual({"user1": 10, "user2": 9}, msg.users)
            self.assertEqual(10, interests.similar_users["user1"].rating)
            self.assertEqual(2, fake_core.users.watch_user.call_count)

        finally:
            Interests.MAX_SIMILAR_USERS = old_limit
            Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK = old_watch

    def test_item_similar_users_response_is_capped_before_watch_fanout(self):
        interests = self._new_interests()

        old_limit = Interests.MAX_SIMILAR_USERS
        old_watch = Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK
        Interests.MAX_SIMILAR_USERS = 2
        Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK = 10
        fake_core = self._make_fake_core()
        msg = SimpleNamespace(users=["user1", "user2", "user3"])

        interests._pending_item_similar_users.add(None)
        msg.thing = None

        try:
            with patch("pynicotine.interests.core", fake_core), patch("pynicotine.watchbatch.core", fake_core):
                interests._item_similar_users(msg)

            self.assertEqual({"user1", "user2"}, set(interests.similar_users))
            self.assertEqual(["user1", "user2"], msg.users)
            self.assertIsNone(interests.similar_users["user1"].rating)
            self.assertEqual(2, fake_core.users.watch_user.call_count)

        finally:
            Interests.MAX_SIMILAR_USERS = old_limit
            Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK = old_watch

    def test_similar_user_watch_fanout_is_batched(self):
        interests = self._new_interests()
        fake_core = self._make_fake_core()
        callbacks = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            callbacks.append((callback, callback_args or ()))
            return len(callbacks)

        old_watch = Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK
        Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK = 2
        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())
        msg = SimpleNamespace(users={f"user{i}": i for i in range(5)})

        interests._pending_similar_users = True

        try:
            with patch.object(interests_module, "events", fake_events), \
                    patch.object(watchbatch_module, "events", fake_events), \
                    patch.object(interests_module, "core", fake_core), \
                    patch.object(watchbatch_module, "core", fake_core):
                interests._similar_users(msg)

                self.assertEqual(2, fake_core.users.watch_user.call_count)
                self.assertEqual(1, len(callbacks))

                callback, callback_args = callbacks.pop(0)
                callback(*callback_args)
                self.assertEqual(4, fake_core.users.watch_user.call_count)

        finally:
            Interests.MAX_SIMILAR_USER_WATCHES_PER_TICK = old_watch

    def test_similar_user_unwatch_fanout_is_batched_and_skips_reappeared_users(self):
        interests = self._new_interests()
        interests.similar_users = {
            "old1": SimilarUser("old1"),
            "old2": SimilarUser("old2"),
            "old3": SimilarUser("old3")
        }
        fake_core = self._make_fake_core()
        callbacks = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            callbacks.append((callback, callback_args or ()))
            return len(callbacks)

        old_unwatch = Interests.MAX_SIMILAR_USER_UNWATCHES_PER_TICK
        Interests.MAX_SIMILAR_USER_UNWATCHES_PER_TICK = 1
        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())

        interests._pending_similar_users = True

        try:
            with patch.object(interests_module, "events", fake_events), \
                    patch.object(watchbatch_module, "events", fake_events), \
                    patch.object(interests_module, "core", fake_core), \
                    patch.object(watchbatch_module, "core", fake_core):
                interests._similar_users(SimpleNamespace(users={"new1": 1}, is_allowed=True))

                self.assertEqual([("old1",)], [call.args[:1] for call in fake_core.users.unwatch_user.call_args_list])
                self.assertEqual(1, len(callbacks))

                interests.similar_users["old2"] = SimilarUser("old2")
                callback, callback_args = callbacks.pop(0)
                callback(*callback_args)
                self.assertEqual([("old1",)], [call.args[:1] for call in fake_core.users.unwatch_user.call_args_list])
                self.assertEqual(1, len(callbacks))

                callback, callback_args = callbacks.pop(0)
                callback(*callback_args)

                self.assertEqual(
                    [("old1",), ("old3",)],
                    [call.args[:1] for call in fake_core.users.unwatch_user.call_args_list]
                )

        finally:
            Interests.MAX_SIMILAR_USER_UNWATCHES_PER_TICK = old_unwatch

    def test_server_login_interest_sync_is_batched_and_deduplicated(self):
        interests = self._new_interests()
        fake_core = SimpleNamespace(send_message_to_server=Mock())
        fake_config = SimpleNamespace(sections={
            "interests": {
                "likes": ["Alpha", " alpha ", "Beta", ""],
                "dislikes": ["Gamma", "gamma", "Delta"]
            }
        })
        callbacks = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            callbacks.append((callback, callback_args or ()))
            return len(callbacks)

        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())
        old_limit = Interests.MAX_INTEREST_SYNC_ITEMS_PER_TICK
        Interests.MAX_INTEREST_SYNC_ITEMS_PER_TICK = 2

        try:
            with patch.object(interests_module, "core", fake_core), \
                    patch.object(interests_module, "config", fake_config), \
                    patch.object(interests_module, "events", fake_events):
                interests._server_login(SimpleNamespace(success=True))

                self.assertEqual(2, fake_core.send_message_to_server.call_count)
                self.assertEqual(1, len(callbacks))

                callback, callback_args = callbacks.pop(0)
                callback(*callback_args)

                self.assertEqual(4, fake_core.send_message_to_server.call_count)
                self.assertFalse(callbacks)
                self.assertFalse(interests._interest_sync_queue)

        finally:
            Interests.MAX_INTEREST_SYNC_ITEMS_PER_TICK = old_limit


    def test_server_login_interest_sync_retries_rejected_queue_item(self):
        interests = self._new_interests()
        sent = []

        def send_message(msg):
            sent.append(msg)
            return False if len(sent) == 1 else True

        fake_core = SimpleNamespace(send_message_to_server=Mock(side_effect=send_message))
        fake_config = SimpleNamespace(sections={
            "interests": {
                "likes": ["Alpha"],
                "dislikes": ["Beta"]
            }
        })
        callbacks = []
        delays = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            delays.append(delay)
            callbacks.append((callback, callback_args or ()))
            return len(callbacks)

        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())

        with patch.object(interests_module, "core", fake_core), \
                patch.object(interests_module, "config", fake_config), \
                patch.object(interests_module, "events", fake_events):
            interests._server_login(SimpleNamespace(success=True))

            self.assertEqual(1, fake_core.send_message_to_server.call_count)
            self.assertEqual([Interests.INTEREST_SYNC_RETRY_DELAY], delays)
            self.assertEqual([("add_like", "alpha"), ("add_hate", "beta")], list(interests._interest_sync_queue))

            callback, callback_args = callbacks.pop(0)
            callback(*callback_args)

        self.assertEqual(3, fake_core.send_message_to_server.call_count)
        self.assertIsInstance(sent[1], AddThingILike)
        self.assertIsInstance(sent[2], AddThingIHate)
        self.assertFalse(interests._interest_sync_queue)

    def test_server_login_interest_sync_pending_cap(self):
        interests = self._new_interests()
        fake_core = SimpleNamespace(send_message_to_server=Mock())
        fake_config = SimpleNamespace(sections={
            "interests": {
                "likes": ["one", "two", "three"],
                "dislikes": ["four"]
            }
        })
        fake_events = SimpleNamespace(schedule=Mock(return_value=None), cancel_scheduled=Mock())
        old_pending = Interests.MAX_PENDING_INTEREST_SYNC_ITEMS
        old_tick = Interests.MAX_INTEREST_SYNC_ITEMS_PER_TICK
        Interests.MAX_PENDING_INTEREST_SYNC_ITEMS = 2
        Interests.MAX_INTEREST_SYNC_ITEMS_PER_TICK = 10

        try:
            with patch.object(interests_module, "core", fake_core), \
                    patch.object(interests_module, "config", fake_config), \
                    patch.object(interests_module, "events", fake_events):
                interests._server_login(SimpleNamespace(success=True))

            self.assertEqual(2, fake_core.send_message_to_server.call_count)

        finally:
            Interests.MAX_PENDING_INTEREST_SYNC_ITEMS = old_pending
            Interests.MAX_INTEREST_SYNC_ITEMS_PER_TICK = old_tick

    def test_unsent_recommendation_request_clears_pending_state(self):
        interests = self._new_interests()

        interests._pending_recommendations = True
        interests._pending_global_recommendations = True
        interests._pending_similar_users = True
        interests._pending_item_recommendations.add("artist")
        interests._pending_item_similar_users.add("song")

        interests._server_message_unsent(Recommendations())
        interests._server_message_unsent(GlobalRecommendations())
        interests._server_message_unsent(SimilarUsers())
        interests._server_message_unsent(ItemRecommendations("artist"))
        interests._server_message_unsent(ItemSimilarUsers("song"))

        self.assertFalse(interests._pending_recommendations)
        self.assertFalse(interests._pending_global_recommendations)
        self.assertFalse(interests._pending_similar_users)
        self.assertNotIn("artist", interests._pending_item_recommendations)
        self.assertNotIn("song", interests._pending_item_similar_users)

    def test_unsent_interest_config_change_is_retried_if_still_desired(self):
        interests = self._new_interests()
        fake_config = SimpleNamespace(sections={
            "interests": {
                "likes": ["alpha"],
                "dislikes": []
            }
        })
        callbacks = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            callbacks.append((callback, callback_args or ()))
            return len(callbacks)

        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())

        with patch.object(interests_module, "config", fake_config), \
                patch.object(interests_module, "events", fake_events):
            interests._server_message_unsent(AddThingILike("alpha"))
            interests._server_message_unsent(AddThingILike("stale"))

        self.assertEqual([("add_like", "alpha")], list(interests._interest_sync_queue))
        self.assertEqual(1, len(callbacks))

    def test_unsent_interest_removal_is_retried_if_still_desired(self):
        interests = self._new_interests()
        fake_config = SimpleNamespace(sections={
            "interests": {
                "likes": [],
                "dislikes": ["beta"]
            }
        })
        callbacks = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            callbacks.append((callback, callback_args or ()))
            return len(callbacks)

        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())

        with patch.object(interests_module, "config", fake_config), \
                patch.object(interests_module, "events", fake_events):
            interests._server_message_unsent(RemoveThingILike("alpha"))
            interests._server_message_unsent(RemoveThingIHate("beta"))

        self.assertEqual([("remove_like", "alpha")], list(interests._interest_sync_queue))
        self.assertEqual(1, len(callbacks))

    def test_server_response_delivery_failure_retries_interest_request(self):
        interests = self._new_interests()
        interests._pending_recommendations = True
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=True))
        callbacks = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            callbacks.append((callback, callback_args or ()))
            return len(callbacks)

        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())

        with patch.object(interests_module, "core", fake_core), \
                patch.object(interests_module, "events", fake_events):
            interests._server_response_delivery_failed(Recommendations, ("recommendations",))

            self.assertFalse(interests._pending_recommendations)
            self.assertEqual([("recommendations", None)], list(interests._interest_request_retry_queue))
            self.assertEqual(1, len(callbacks))

            callback, callback_args = callbacks.pop(0)
            callback(*callback_args)

        self.assertTrue(interests._pending_recommendations)
        self.assertEqual(Recommendations, fake_core.send_message_to_server.call_args.args[0].__class__)

    def test_server_response_delivery_failure_retries_item_interest_request(self):
        interests = self._new_interests()
        interests._pending_item_recommendations.add("artist")
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=True))
        callbacks = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            callbacks.append((callback, callback_args or ()))
            return len(callbacks)

        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())

        with patch.object(interests_module, "core", fake_core), \
                patch.object(interests_module, "events", fake_events):
            interests._server_response_delivery_failed(ItemRecommendations, ("item-recommendations", "artist"))

            self.assertNotIn("artist", interests._pending_item_recommendations)
            self.assertEqual([("item-recommendations", "artist")], list(interests._interest_request_retry_queue))
            callback, callback_args = callbacks.pop(0)
            callback(*callback_args)

        self.assertIn("artist", interests._pending_item_recommendations)
        self.assertEqual(ItemRecommendations, fake_core.send_message_to_server.call_args.args[0].__class__)

