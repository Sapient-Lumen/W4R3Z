# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from unittest import TestCase
from unittest.mock import patch

import socket
import struct

from pynicotine.config import config
from pynicotine.portmapper import NATPMP
from pynicotine.portmapper import PortMapper
from pynicotine.portmapper import PortmapError
from pynicotine.portmapper import UPnP


class FakeResponse:

    def __init__(self, body):
        self.body = body

    def read(self, size=-1):
        if size < 0:
            return self.body

        return self.body[:size]

    def close(self):
        pass


class UPnPTest(TestCase):

    def test_http_response_limit_allows_exact_size(self):
        response_body = b"a" * UPnP.MAX_HTTP_RESPONSE_SIZE

        self.assertEqual(response_body, UPnP._read_http_response(FakeResponse(response_body)))

    def test_http_response_limit_rejects_larger_body(self):
        response_body = b"a" * (UPnP.MAX_HTTP_RESPONSE_SIZE + 1)

        with self.assertRaises(PortmapError):
            UPnP._read_http_response(FakeResponse(response_body))

    def test_http_redirect_error_is_rejected_without_body_parse(self):
        from urllib.error import HTTPError

        error = HTTPError(
            url="http://192.168.1.1/root.xml",
            code=302,
            msg="Found",
            hdrs={"Location": "https://example.com/root.xml"},
            fp=FakeResponse(b"<root/>")
        )

        with self.assertRaises(PortmapError):
            UPnP._read_http_error_body(error)

    def test_non_redirect_http_error_body_is_bounded(self):
        from urllib.error import HTTPError

        error = HTTPError(
            url="http://192.168.1.1/root.xml",
            code=500,
            msg="Internal Server Error",
            hdrs={},
            fp=FakeResponse(b"<error/>")
        )

        self.assertEqual(b"<error/>", UPnP._read_http_error_body(error))


    def test_xml_parser_rejects_doctype_and_entity_declarations(self):
        for response_body in (
            b'<!DOCTYPE root [<!ENTITY x "boom">]><root>&x;</root>',
            b'<root><!ENTITY x "boom"></root>'
        ):
            with self.subTest(response_body=response_body):
                with self.assertRaises(PortmapError):
                    UPnP._parse_xml_response(response_body)

    def test_xml_parser_rejects_gross_element_count(self):
        old_limit = UPnP.MAX_XML_ELEMENTS
        UPnP.MAX_XML_ELEMENTS = 2

        try:
            with self.assertRaises(PortmapError):
                UPnP._parse_xml_response(b"<root><a/><b/></root>")

        finally:
            UPnP.MAX_XML_ELEMENTS = old_limit

    def test_xml_parser_rejects_gross_text_field(self):
        old_limit = UPnP.MAX_XML_TEXT_BYTES
        UPnP.MAX_XML_TEXT_BYTES = 4

        try:
            with self.assertRaises(PortmapError):
                UPnP._parse_xml_response(b"<root>12345</root>")

        finally:
            UPnP.MAX_XML_TEXT_BYTES = old_limit

    def test_ssdp_source_address_validation_rejects_cross_scope_and_special_addresses(self):
        self.assertTrue(UPnP._is_valid_ssdp_source_address("192.168.1.1", "192.168.1.10"))
        self.assertTrue(UPnP._is_valid_ssdp_source_address("203.0.113.1", "203.0.113.10"))

        for source_ip in ("127.0.0.1", "0.0.0.0", "239.255.255.250", "8.8.8.8", "::1", "not-an-ip"):
            with self.subTest(source_ip=source_ip):
                self.assertFalse(UPnP._is_valid_ssdp_source_address(source_ip, "192.168.1.10"))

    def test_ssdp_invalid_source_is_not_parsed(self):
        class FakeSocket:
            def __init__(self):
                self.recv_count = 0
                self.timeouts = []

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def setsockopt(self, *_args):
                pass

            def settimeout(self, timeout):
                self.timeouts.append(timeout)

            def bind(self, _address):
                pass

            def sendto(self, *_args):
                pass

            def recvfrom(self, _size):
                self.recv_count += 1
                return (
                    b"HTTP/1.1 200 OK\r\n"
                    b"LOCATION: http://8.8.8.8/root.xml\r\n"
                    b"\r\n"
                ), ("8.8.8.8", 1900)

        old_limit = UPnP.MAX_DISCOVERY_RESPONSES
        fake_socket = FakeSocket()
        UPnP.MAX_DISCOVERY_RESPONSES = 1

        try:
            with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket), \
                    patch.object(UPnP.SSDP, "add_service") as add_service:

                services = UPnP.SSDP.get_services("192.168.1.10")

            self.assertEqual({}, services)
            self.assertEqual(1, fake_socket.recv_count)
            add_service.assert_not_called()

        finally:
            UPnP.MAX_DISCOVERY_RESPONSES = old_limit

    def test_ssdp_location_rejects_cross_boundary_loopback_and_global_targets(self):
        self.assertFalse(UPnP._is_valid_location_url("http://127.0.0.1/root.xml", "192.168.1.10"))
        self.assertFalse(UPnP._is_valid_location_url("http://localhost/root.xml", "192.168.1.10"))
        self.assertFalse(UPnP._is_valid_location_url("http://8.8.8.8/root.xml", "192.168.1.10"))
        self.assertTrue(UPnP._is_valid_location_url("http://192.168.1.1/root.xml", "192.168.1.1"))

    def test_ssdp_location_rejects_global_hostnames_and_url_authority_tricks(self):
        for location in (
            "http://example.com/root.xml",
            "https://router.example.com/root.xml",
            "http://user:pass@router.local/root.xml",
            "http://router.local/root.xml#fragment",
            "http://router.local:70000/root.xml",
            "http://-router.local/root.xml",
        ):
            with self.subTest(location=location):
                self.assertFalse(UPnP._is_valid_location_url(location, "192.168.1.10"))

        for location in (
            "http://router/root.xml",
            "http://router.local/root.xml",
            "http://gateway.lan/root.xml",
            "http://modem.home/root.xml",
        ):
            with self.subTest(location=location):
                self.assertTrue(UPnP._is_valid_location_url(location, "192.168.1.10"))

    def test_upnp_control_url_resolves_only_same_origin_bounded_targets(self):
        location_url = "http://192.168.1.1:1234/root/device.xml"

        self.assertEqual(
            "http://192.168.1.1:1234/upnp/control",
            UPnP._resolve_control_url("/upnp/control", location_url)
        )
        self.assertEqual(
            "http://192.168.1.1:1234/root/control",
            UPnP._resolve_control_url("control", location_url)
        )

        for control_url in (
            "http://192.168.1.2:1234/upnp/control",
            "https://192.168.1.1:1234/upnp/control",
            "//192.168.1.2/upnp/control",
            "http://user:pass@192.168.1.1:1234/upnp/control",
            "http://192.168.1.1:1234/upnp/control#fragment",
            "http://192.168.1.1:70000/upnp/control",
            "/" + ("a" * (UPnP.MAX_CONTROL_URL_BYTES + 1)),
            "/upnp/\ncontrol",
        ):
            with self.subTest(control_url=control_url):
                self.assertIsNone(UPnP._resolve_control_url(control_url, location_url))

    def test_ssdp_oversized_response_is_counted_but_not_parsed(self):
        class FakeSocket:
            def __init__(self):
                self.recv_count = 0
                self.timeouts = []

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def setsockopt(self, *_args):
                pass

            def settimeout(self, timeout):
                self.timeouts.append(timeout)

            def bind(self, _address):
                pass

            def sendto(self, *_args):
                pass

            def recvfrom(self, size):
                self.recv_count += 1
                self.requested_size = size
                return (b"x" * (UPnP.MAX_SSDP_RESPONSE_BYTES + 1), ("192.0.2.1", 1900))

        old_limit = UPnP.MAX_DISCOVERY_RESPONSES
        fake_socket = FakeSocket()
        UPnP.MAX_DISCOVERY_RESPONSES = 1

        try:
            with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket), \
                    patch.object(UPnP.SSDP, "add_service") as add_service:

                services = UPnP.SSDP.get_services("192.0.2.10")

            self.assertEqual({}, services)
            self.assertEqual(1, fake_socket.recv_count)
            self.assertEqual(UPnP.MAX_SSDP_RESPONSE_BYTES + 1, fake_socket.requested_size)
            add_service.assert_not_called()

        finally:
            UPnP.MAX_DISCOVERY_RESPONSES = old_limit

    def test_ssdp_rejects_non_success_status_before_fetch(self):
        services = {}
        locations = set()

        with patch.object(UPnP.SSDP, "get_service_control_url", return_value=(None, None)) as get_service:
            for first_line in (
                "NOTIFY * HTTP/1.1",
                "HTTP/1.1 500 Internal Server Error",
                "M-SEARCH * HTTP/1.1",
                "",
            ):
                response = UPnP.SSDPResponse(
                    f"{first_line}\r\n"
                    "LOCATION: http://192.168.1.1/root.xml\r\n"
                    "\r\n",
                    source_ip_address="192.168.1.1"
                )
                UPnP.SSDP.add_service(services, locations, response)

        self.assertEqual(set(), locations)
        get_service.assert_not_called()

    def test_ssdp_response_header_parsing_is_bounded(self):
        old_limit = UPnP.SSDPResponse.MAX_HEADER_LINES
        UPnP.SSDPResponse.MAX_HEADER_LINES = 1

        try:
            response = UPnP.SSDPResponse(
                "HTTP/1.1 200 OK\r\n"
                "SERVER: router\r\n"
                "LOCATION: http://192.0.2.1/root.xml\r\n"
                "\r\n"
            )
            self.assertEqual([("SERVER", "router")], response.headers)

        finally:
            UPnP.SSDPResponse.MAX_HEADER_LINES = old_limit

    def test_ssdp_location_processing_is_bounded(self):
        services = {}
        locations = set()
        old_limit = UPnP.MAX_DISCOVERY_LOCATIONS
        UPnP.MAX_DISCOVERY_LOCATIONS = 2

        try:
            with patch.object(UPnP.SSDP, "get_service_control_url", return_value=(None, None)) as get_service:
                for index in range(3):
                    response = UPnP.SSDPResponse(
                        "HTTP/1.1 200 OK\r\n"
                        f"LOCATION: http://192.0.2.{index}/root.xml\r\n"
                        "\r\n"
                    )
                    UPnP.SSDP.add_service(services, locations, response)

            self.assertEqual(2, len(locations))
            self.assertEqual(2, get_service.call_count)

        finally:
            UPnP.MAX_DISCOVERY_LOCATIONS = old_limit


    def test_ssdp_rejects_invalid_location_without_fetch(self):
        services = {}
        locations = set()

        with patch.object(UPnP.SSDP, "get_service_control_url", return_value=(None, None)) as get_service:
            for location in ("file:///etc/passwd", "http://", "x" * (UPnP.MAX_LOCATION_URL_BYTES + 1)):
                response = UPnP.SSDPResponse(
                    "HTTP/1.1 200 OK\r\n"
                    f"LOCATION: {location}\r\n"
                    "\r\n"
                )
                UPnP.SSDP.add_service(services, locations, response)

        self.assertEqual(set(), locations)
        get_service.assert_not_called()

    def test_ssdp_device_description_requests_are_bounded(self):
        services = {}
        locations = set()
        old_limit = UPnP.MAX_DEVICE_DESCRIPTION_REQUESTS
        UPnP.MAX_DEVICE_DESCRIPTION_REQUESTS = 2

        try:
            with patch.object(UPnP.SSDP, "get_service_control_url", return_value=(None, None)) as get_service:
                for index in range(3):
                    response = UPnP.SSDPResponse(
                        "HTTP/1.1 200 OK\r\n"
                        f"LOCATION: http://192.0.2.{index}/root.xml\r\n"
                        "\r\n"
                    )
                    UPnP.SSDP.add_service(services, locations, response)

            self.assertEqual(2, len(locations))
            self.assertEqual(2, get_service.call_count)

        finally:
            UPnP.MAX_DEVICE_DESCRIPTION_REQUESTS = old_limit

    def test_ssdp_discovery_response_processing_is_bounded(self):
        class FakeSocket:
            def __init__(self):
                self.recv_count = 0
                self.timeouts = []

            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def setsockopt(self, *_args):
                pass

            def settimeout(self, timeout):
                self.timeouts.append(timeout)

            def bind(self, _address):
                pass

            def sendto(self, *_args):
                pass

            def recvfrom(self, _size):
                self.recv_count += 1
                return (
                    b"HTTP/1.1 200 OK\r\n"
                    b"LOCATION: http://192.0.2.1/root.xml\r\n"
                    b"\r\n"
                ), ("192.0.2.1", 1900)

        old_limit = UPnP.MAX_DISCOVERY_RESPONSES
        fake_socket = FakeSocket()
        UPnP.MAX_DISCOVERY_RESPONSES = 3

        try:
            with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket), \
                    patch.object(UPnP.SSDP, "get_service_control_url", return_value=(None, None)):

                services = UPnP.SSDP.get_services("192.0.2.10")

            self.assertEqual({}, services)
            self.assertEqual(3, fake_socket.recv_count)

        finally:
            UPnP.MAX_DISCOVERY_RESPONSES = old_limit


class NATPMPTest(TestCase):

    class FakeSocket:

        def __init__(self, responses=None):
            self.responses = list(responses or [])
            self.sent_addresses = []
            self.recv_count = 0
            self.timeouts = []

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return False

        def bind(self, _address):
            return None

        def settimeout(self, timeout):
            self.timeouts.append(timeout)

        def sendto(self, _message, address):
            self.sent_addresses.append(address)

        def recvfrom(self, _size):
            self.recv_count += 1

            if not self.responses:
                raise socket.timeout

            response = self.responses.pop(0)

            if isinstance(response, Exception):
                raise response

            return response

    @staticmethod
    def _response(result=0, version=0, op_code=130, private_port=2234, public_port=2234, lease_duration=3600):
        return struct.pack('!BBHIHHI', version, op_code, result, 1, private_port, public_port, lease_duration)

    @staticmethod
    def _natpmp(gateway_address="192.0.2.1"):
        natpmp = NATPMP()
        natpmp.local_ip_address = "192.0.2.10"
        natpmp._gateway_address = gateway_address
        return natpmp

    def test_natpmp_ignores_spoofed_response_sources_before_accepting_gateway_response(self):
        gateway_address = "192.0.2.1"
        fake_socket = self.FakeSocket([
            (self._response(), ("198.51.100.5", NATPMP.REQUEST_PORT)),
            (self._response(), (gateway_address, NATPMP.REQUEST_PORT + 1)),
            (self._response(), (gateway_address, NATPMP.REQUEST_PORT)),
        ])

        with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket):
            self.assertEqual(NATPMP.SUCCESS_RESULT, self._natpmp(gateway_address)._request_port_mapping(2234, 2234, 3600))

        self.assertEqual(3, fake_socket.recv_count)
        self.assertEqual([(gateway_address, NATPMP.REQUEST_PORT)], fake_socket.sent_addresses)

    def test_natpmp_rejects_malformed_gateway_response_without_crashing(self):
        gateway_address = "192.0.2.1"
        fake_socket = self.FakeSocket([(b"short", (gateway_address, NATPMP.REQUEST_PORT))])

        with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket):
            with self.assertRaises(PortmapError):
                self._natpmp(gateway_address)._request_port_mapping(2234, 2234, 3600)

    def test_natpmp_rejects_wrong_response_opcode_from_gateway(self):
        gateway_address = "192.0.2.1"
        fake_socket = self.FakeSocket([(self._response(op_code=2), (gateway_address, NATPMP.REQUEST_PORT))])

        with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket):
            with self.assertRaises(PortmapError):
                self._natpmp(gateway_address)._request_port_mapping(2234, 2234, 3600)

    def test_natpmp_rejects_response_for_different_private_or_public_port(self):
        gateway_address = "192.0.2.1"

        for response in (
            self._response(private_port=9999),
            self._response(public_port=9999),
        ):
            with self.subTest(response=response):
                fake_socket = self.FakeSocket([(response, (gateway_address, NATPMP.REQUEST_PORT))])

                with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket):
                    with self.assertRaises(PortmapError):
                        self._natpmp(gateway_address)._request_port_mapping(2234, 2234, 3600)

    def test_natpmp_rejects_response_with_longer_lease_than_requested(self):
        gateway_address = "192.0.2.1"
        fake_socket = self.FakeSocket([
            (self._response(lease_duration=7200), (gateway_address, NATPMP.REQUEST_PORT))
        ])

        with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket):
            with self.assertRaises(PortmapError):
                self._natpmp(gateway_address)._request_port_mapping(2234, 2234, 3600)

    def test_natpmp_bounds_unexpected_response_bursts_per_attempt(self):
        old_limit = NATPMP.MAX_RESPONSES_PER_ATTEMPT
        NATPMP.MAX_RESPONSES_PER_ATTEMPT = 2
        fake_socket = self.FakeSocket([
            (self._response(), ("198.51.100.5", NATPMP.REQUEST_PORT)),
            (self._response(), ("198.51.100.6", NATPMP.REQUEST_PORT)),
        ])

        try:
            with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket):
                with self.assertRaises(PortmapError):
                    self._natpmp()._request_port_mapping(2234, 2234, 3600)

            self.assertEqual(2, fake_socket.recv_count)

        finally:
            NATPMP.MAX_RESPONSES_PER_ATTEMPT = old_limit

    def test_natpmp_rejects_invalid_gateway_address_before_sendto(self):
        fake_socket = self.FakeSocket()

        with patch("pynicotine.portmapper.socket.socket", return_value=fake_socket):
            with self.assertRaises(PortmapError):
                self._natpmp(gateway_address="::1")._request_port_mapping(2234, 2234, 3600)

        self.assertEqual([], fake_socket.sent_addresses)


class PortMapperTest(TestCase):

    # pylint: disable=protected-access

    def test_nonblocking_port_mapping_requests_share_one_worker_thread(self):
        """Repeated renewal/add requests should not stack sleeping port-mapping threads."""

        started_threads = []

        class DummyThread:

            def __init__(self, target=None, args=None, name=None, daemon=None):
                self.target = target
                self.args = args or ()
                self.name = name
                self.daemon = daemon
                started_threads.append(self)

            def start(self):
                return None

        portmapper = PortMapper()
        portmapper.set_port(2234, "192.0.2.10")

        old_upnp = config.sections.get("server", {}).get("upnp")
        config.sections.setdefault("server", {})["upnp"] = True

        try:
            with patch("pynicotine.portmapper.Thread", DummyThread):
                portmapper.add_port_mapping(blocking=False)
                portmapper.add_port_mapping(blocking=False)
                portmapper.remove_port_mapping(blocking=False)
        finally:
            if old_upnp is None:
                config.sections["server"].pop("upnp", None)
            else:
                config.sections["server"]["upnp"] = old_upnp

        self.assertEqual(1, len(started_threads))
        self.assertEqual("PortMapping", started_threads[0].name)
        self.assertTrue(started_threads[0].daemon)
        self.assertIs(started_threads[0], portmapper._operation_thread)
        self.assertEqual(PortMapper.OPERATION_REMOVE, portmapper._queued_operation)

    def test_port_mapping_worker_runs_queued_operation_and_clears_state(self):
        """A queued remove should run after the in-flight add without spawning another thread."""

        operations = []
        portmapper = PortMapper()

        def fake_add(instance):
            operations.append("add")
            instance._queued_operation = PortMapper.OPERATION_REMOVE

        def fake_remove(_instance):
            operations.append("remove")

        portmapper._operation_thread = object()

        with patch.object(PortMapper, "_add_port_mapping", fake_add), \
                patch.object(PortMapper, "_remove_port_mapping", fake_remove):
            portmapper._run_port_mapping_operations(PortMapper.OPERATION_ADD)

        self.assertEqual(["add", "remove"], operations)
        self.assertIsNone(portmapper._operation_thread)
        self.assertIsNone(portmapper._queued_operation)
