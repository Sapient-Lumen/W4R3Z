# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE

from collections import deque
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

import pynicotine.privatechat as privatechat_module
from pynicotine.config import config
from pynicotine.privatechat import PrivateChat
from pynicotine.slskmessages import MessageAcked
from pynicotine.slskmessages import MessageUser
from pynicotine.slskmessages import SlskMessage


class PrivateChatTest(TestCase):

    # pylint: disable=protected-access

    @staticmethod
    def _new_private_chat_queue():
        private_chat = object.__new__(PrivateChat)
        private_chat.private_message_queue = {}
        private_chat._private_message_queue_bytes = 0
        private_chat._private_message_queue_limit_logged = False
        private_chat._private_message_flush_queue = deque()
        private_chat._private_message_flush_timer_id = None
        private_chat._private_message_flush_limit_logged = False
        return private_chat

    @staticmethod
    def _new_private_chat_auto_replies():
        private_chat = object.__new__(PrivateChat)
        private_chat.away_message_users = set()
        private_chat._away_message_times = deque()
        private_chat._away_message_limit_logged = False
        private_chat._ctcp_reply_times = deque()
        private_chat._ctcp_reply_user_times = {}
        private_chat._ctcp_reply_limit_logged = False
        return private_chat

    @staticmethod
    def _new_private_chat_message_users():
        private_chat = object.__new__(PrivateChat)
        private_chat._message_users_queue = deque()
        private_chat._message_users_timer_id = None
        private_chat._message_users_limit_logged = False
        return private_chat

    @staticmethod
    def _new_private_chat_replay():
        private_chat = object.__new__(PrivateChat)
        private_chat.private_message_queue = {}
        private_chat.users = set()
        private_chat._recent_private_message_ids = set()
        private_chat._recent_private_message_id_queue = deque()
        private_chat._recent_private_message_replay_limit_logged = False
        private_chat._message_ack_retry_queue = deque()
        private_chat._message_ack_retry_ids = set()
        private_chat._message_ack_retry_timer_id = None
        private_chat._message_ack_retry_limit_logged = False
        private_chat._message_send_retry_queue = deque()
        private_chat._message_send_retry_timer_id = None
        private_chat._message_send_retry_bytes = 0
        private_chat._message_send_retry_limit_logged = False
        private_chat._away_message_times = deque()
        private_chat._away_message_limit_logged = False
        private_chat._ctcp_reply_times = deque()
        private_chat._ctcp_reply_user_times = {}
        private_chat._ctcp_reply_limit_logged = False
        private_chat.away_message_users = set()
        return private_chat


    def test_send_message_notifies_only_after_network_queue_accepts(self):
        private_chat = self._new_private_chat_replay()
        scheduled_callbacks = []
        sent_messages = []
        fake_pluginhandler = SimpleNamespace(
            outgoing_private_chat_event=Mock(return_value=("peer", "hello")),
            outgoing_private_chat_notification=Mock()
        )
        fake_core = SimpleNamespace(
            pluginhandler=fake_pluginhandler,
            send_message_to_server=Mock(side_effect=lambda msg: sent_messages.append(msg) or False)
        )

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        fake_events = SimpleNamespace(emit=Mock(), schedule=schedule_callback, cancel_scheduled=Mock())
        old_replacewords = config.sections["words"].get("replacewords")

        try:
            config.sections["words"]["replacewords"] = False

            with patch.object(privatechat_module, "core", fake_core), \
                    patch.object(privatechat_module, "events", fake_events):
                private_chat.send_message("peer", "hello")

            fake_core.send_message_to_server.assert_called_once()
            fake_pluginhandler.outgoing_private_chat_notification.assert_not_called()
            fake_events.emit.assert_not_called()
            self.assertEqual(1, len(scheduled_callbacks))
            self.assertEqual(1, len(private_chat._message_send_retry_queue))
            self.assertGreater(private_chat._message_send_retry_bytes, 0)

            fake_core.send_message_to_server = Mock(side_effect=lambda msg: sent_messages.append(msg) or True)

            with patch.object(privatechat_module, "core", fake_core), \
                    patch.object(privatechat_module, "events", fake_events):
                _delay, callback, callback_args = scheduled_callbacks.pop(0)
                callback(*callback_args)

        finally:
            if old_replacewords is None:
                config.sections["words"].pop("replacewords", None)
            else:
                config.sections["words"]["replacewords"] = old_replacewords

        fake_pluginhandler.outgoing_private_chat_notification.assert_called_once_with("peer", "hello")
        fake_events.emit.assert_called_once()
        self.assertEqual("message-user", fake_events.emit.call_args.args[0])
        self.assertFalse(private_chat._message_send_retry_queue)

    def test_outgoing_private_chat_is_capped_before_queue_and_notification(self):
        private_chat = object.__new__(PrivateChat)
        long_message = "x" * (SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES + 100)
        sent_messages = []
        fake_pluginhandler = SimpleNamespace(
            outgoing_private_chat_event=Mock(return_value=("peer", long_message)),
            outgoing_private_chat_notification=Mock()
        )
        fake_core = SimpleNamespace(
            pluginhandler=fake_pluginhandler,
            send_message_to_server=Mock(side_effect=lambda msg: sent_messages.append(msg) or True)
        )
        fake_events = SimpleNamespace(emit=Mock())
        old_replacewords = config.sections["words"].get("replacewords")

        try:
            config.sections["words"]["replacewords"] = False

            with patch.object(privatechat_module, "core", fake_core), \
                    patch.object(privatechat_module, "events", fake_events):
                private_chat.send_message("peer", "hello")

        finally:
            if old_replacewords is None:
                config.sections["words"].pop("replacewords", None)
            else:
                config.sections["words"]["replacewords"] = old_replacewords

        self.assertEqual(SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES, len(sent_messages[0].message))
        fake_pluginhandler.outgoing_private_chat_notification.assert_called_once_with(
            "peer", sent_messages[0].message)
        self.assertEqual(sent_messages[0], fake_events.emit.call_args.args[1])

    def test_bulk_private_message_text_and_usernames_are_capped_before_queueing(self):
        private_chat = self._new_private_chat_message_users()
        old_batch_size = PrivateChat.MAX_MESSAGE_USERS_PER_BATCH
        old_batches_per_tick = PrivateChat.MAX_MESSAGE_USER_BATCHES_PER_TICK
        old_pending_users = PrivateChat.MAX_PENDING_MESSAGE_USERS
        sent_messages = []

        try:
            PrivateChat.MAX_MESSAGE_USERS_PER_BATCH = 10
            PrivateChat.MAX_MESSAGE_USER_BATCHES_PER_TICK = 10
            PrivateChat.MAX_PENDING_MESSAGE_USERS = 10
            fake_core = SimpleNamespace(send_message_to_server=lambda msg: sent_messages.append(msg) or True)
            fake_events = SimpleNamespace(schedule=Mock(return_value=1), cancel_scheduled=Mock())
            users = ["u" * (SlskMessage.MAX_USERNAME_FIELD_BYTES + 100)]
            message = "m" * (SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES + 100)

            with patch.object(privatechat_module, "core", fake_core), \
                    patch.object(privatechat_module, "events", fake_events):
                self.assertTrue(private_chat._queue_message_users(users, message))

        finally:
            PrivateChat.MAX_MESSAGE_USERS_PER_BATCH = old_batch_size
            PrivateChat.MAX_MESSAGE_USER_BATCHES_PER_TICK = old_batches_per_tick
            PrivateChat.MAX_PENDING_MESSAGE_USERS = old_pending_users

        self.assertEqual(SlskMessage.MAX_USERNAME_FIELD_BYTES, len(sent_messages[0].users[0]))
        self.assertEqual(SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES, len(sent_messages[0].msg))

    def test_private_message_queue_limits_messages_per_user(self):
        private_chat = self._new_private_chat_queue()

        old_limit = PrivateChat.MAX_PRIVATE_MESSAGES_PER_USER
        PrivateChat.MAX_PRIVATE_MESSAGES_PER_USER = 2

        try:
            for message in ("one", "two", "three"):
                private_chat.private_message_queue_add(MessageUser(user="remoteuser", message=message))

            self.assertEqual(
                ["two", "three"],
                [msg.message for msg in private_chat.private_message_queue["remoteuser"]]
            )

        finally:
            PrivateChat.MAX_PRIVATE_MESSAGES_PER_USER = old_limit

    def test_private_message_queue_limits_number_of_users(self):
        private_chat = self._new_private_chat_queue()

        old_limit = PrivateChat.MAX_PRIVATE_MESSAGE_QUEUE_USERS
        PrivateChat.MAX_PRIVATE_MESSAGE_QUEUE_USERS = 2

        try:
            for username in ("user1", "user2", "user3"):
                private_chat.private_message_queue_add(MessageUser(user=username, message="hello"))

            self.assertNotIn("user1", private_chat.private_message_queue)
            self.assertIn("user2", private_chat.private_message_queue)
            self.assertIn("user3", private_chat.private_message_queue)
            self.assertEqual(2, len(private_chat.private_message_queue))

        finally:
            PrivateChat.MAX_PRIVATE_MESSAGE_QUEUE_USERS = old_limit

    def test_private_message_queue_limits_aggregate_bytes(self):
        private_chat = self._new_private_chat_queue()

        old_byte_limit = PrivateChat.MAX_PRIVATE_MESSAGE_QUEUE_BYTES

        try:
            PrivateChat.MAX_PRIVATE_MESSAGE_QUEUE_BYTES = 8
            private_chat.private_message_queue_add(MessageUser(user="user1", message="aaaa"))
            private_chat.private_message_queue_add(MessageUser(user="user2", message="bbbb"))
            private_chat.private_message_queue_add(MessageUser(user="user3", message="cccc"))

            self.assertNotIn("user1", private_chat.private_message_queue)
            self.assertIn("user2", private_chat.private_message_queue)
            self.assertIn("user3", private_chat.private_message_queue)
            self.assertEqual(8, private_chat._private_message_queue_bytes)

        finally:
            PrivateChat.MAX_PRIVATE_MESSAGE_QUEUE_BYTES = old_byte_limit

    def test_private_message_queue_releases_bytes_on_peer_address(self):
        private_chat = self._new_private_chat_queue()
        queued_messages = [MessageUser(message="one"), MessageUser(message="two")]
        private_chat.private_message_queue = {"remoteuser": queued_messages}
        private_chat._private_message_queue_bytes = sum(
            private_chat._get_queued_private_message_size(msg) for msg in queued_messages)

        with patch.object(privatechat_module, "events", SimpleNamespace(emit=Mock())):
            private_chat._get_peer_address(SimpleNamespace(user="remoteuser"))

        self.assertNotIn("remoteuser", private_chat.private_message_queue)
        self.assertEqual(0, private_chat._private_message_queue_bytes)

    def test_private_message_queue_releases_bytes_on_offline_status(self):
        private_chat = self._new_private_chat_queue()
        queued_message = MessageUser(user="remoteuser", message="hello")
        private_chat.private_message_queue = {"remoteuser": [queued_message]}
        private_chat._private_message_queue_bytes = private_chat._get_queued_private_message_size(queued_message)

        with patch.object(privatechat_module, "core", SimpleNamespace(users=SimpleNamespace(login_username="me"))):
            private_chat._user_status(SimpleNamespace(user="remoteuser", status=0))

        self.assertNotIn("remoteuser", private_chat.private_message_queue)
        self.assertEqual(0, private_chat._private_message_queue_bytes)

    def test_peer_address_flushes_queued_messages_once(self):
        private_chat = self._new_private_chat_queue()
        queued_messages = [MessageUser(message="one"), MessageUser(message="two"), MessageUser(message="three")]
        private_chat.private_message_queue = {"remoteuser": queued_messages}
        private_chat._private_message_queue_bytes = sum(
            private_chat._get_queued_private_message_size(msg) for msg in queued_messages)
        emit = Mock()

        with patch.object(privatechat_module, "events", SimpleNamespace(emit=emit)):
            private_chat._get_peer_address(SimpleNamespace(user="remoteuser"))

        self.assertNotIn("remoteuser", private_chat.private_message_queue)
        self.assertEqual(3, emit.call_count)

        for queued_msg in queued_messages:
            self.assertEqual("remoteuser", queued_msg.user)

        for call_args in emit.call_args_list:
            self.assertEqual("message-user", call_args.args[0])
            self.assertTrue(call_args.kwargs["queued_message"])

    def test_peer_address_flush_batches_queued_messages(self):
        private_chat = self._new_private_chat_queue()
        queued_messages = [MessageUser(message=str(num)) for num in range(5)]
        private_chat.private_message_queue = {"remoteuser": queued_messages}
        private_chat._private_message_queue_bytes = sum(
            private_chat._get_queued_private_message_size(msg) for msg in queued_messages)

        old_limit = PrivateChat.MAX_PRIVATE_MESSAGE_FLUSHES_PER_TICK
        PrivateChat.MAX_PRIVATE_MESSAGE_FLUSHES_PER_TICK = 2
        emit = Mock()
        schedule = Mock(return_value=123)

        try:
            with patch.object(privatechat_module, "events", SimpleNamespace(emit=emit, schedule=schedule)):
                private_chat._get_peer_address(SimpleNamespace(user="remoteuser"))

                self.assertEqual(2, emit.call_count)
                self.assertEqual(3, len(private_chat._private_message_flush_queue))
                self.assertEqual(123, private_chat._private_message_flush_timer_id)
                schedule.assert_called_once()

                private_chat._process_private_message_flush_queue()
                self.assertEqual(4, emit.call_count)
                self.assertEqual(1, len(private_chat._private_message_flush_queue))

                private_chat._process_private_message_flush_queue()
                self.assertEqual(5, emit.call_count)
                self.assertFalse(private_chat._private_message_flush_queue)

        finally:
            PrivateChat.MAX_PRIVATE_MESSAGE_FLUSHES_PER_TICK = old_limit

    def test_offline_status_drops_pending_private_message_flushes(self):
        private_chat = self._new_private_chat_queue()
        queued_messages = [MessageUser(message=str(num)) for num in range(3)]
        private_chat._private_message_flush_queue.extend(("remoteuser", msg) for msg in queued_messages)

        with patch.object(privatechat_module, "core", SimpleNamespace(users=SimpleNamespace(login_username="me"))):
            private_chat._user_status(SimpleNamespace(user="remoteuser", status=0))

        self.assertFalse(private_chat._private_message_flush_queue)

    def test_private_chat_user_limit_blocks_new_tabs_and_config_growth(self):
        private_chat = object.__new__(PrivateChat)
        private_chat.users = {"user1", "user2"}

        old_limit = PrivateChat.MAX_PRIVATE_CHAT_USERS
        old_users = list(config.sections["privatechat"].get("users", []))
        PrivateChat.MAX_PRIVATE_CHAT_USERS = 2
        config.sections["privatechat"]["users"] = ["user1", "user2"]

        fake_core = SimpleNamespace(users=SimpleNamespace(watch_user=Mock()))
        fake_events = SimpleNamespace(emit=Mock())

        try:
            with patch.object(privatechat_module, "core", fake_core), patch.object(privatechat_module, "events", fake_events):
                self.assertFalse(private_chat.show_user("user3", switch_page=False))

            self.assertNotIn("user3", private_chat.users)
            self.assertNotIn("user3", config.sections["privatechat"]["users"])
            fake_events.emit.assert_not_called()
            fake_core.users.watch_user.assert_not_called()

        finally:
            PrivateChat.MAX_PRIVATE_CHAT_USERS = old_limit
            config.sections["privatechat"]["users"] = old_users

    def test_private_chat_user_limit_allows_existing_user(self):
        private_chat = object.__new__(PrivateChat)
        private_chat.users = {"user1", "user2"}

        old_limit = PrivateChat.MAX_PRIVATE_CHAT_USERS
        old_users = list(config.sections["privatechat"].get("users", []))
        PrivateChat.MAX_PRIVATE_CHAT_USERS = 2
        config.sections["privatechat"]["users"] = ["user1", "user2"]

        fake_core = SimpleNamespace(users=SimpleNamespace(watch_user=Mock()))
        fake_events = SimpleNamespace(emit=Mock())

        try:
            with patch.object(privatechat_module, "core", fake_core), patch.object(privatechat_module, "events", fake_events):
                self.assertTrue(private_chat.show_user("user2", switch_page=False))

            fake_events.emit.assert_called_once_with("private-chat-show-user", "user2", False, False)
            fake_core.users.watch_user.assert_called_once_with("user2", context="privatechat")

        finally:
            PrivateChat.MAX_PRIVATE_CHAT_USERS = old_limit
            config.sections["privatechat"]["users"] = old_users

    def test_away_auto_replies_are_rate_limited(self):
        private_chat = self._new_private_chat_auto_replies()

        old_reply_limit = PrivateChat.MAX_AWAY_AUTO_REPLIES_PER_MINUTE
        old_user_limit = PrivateChat.MAX_AWAY_MESSAGE_USERS

        try:
            PrivateChat.MAX_AWAY_AUTO_REPLIES_PER_MINUTE = 2
            PrivateChat.MAX_AWAY_MESSAGE_USERS = 10

            with patch.object(privatechat_module.time, "monotonic", Mock(return_value=100.0)):
                self.assertTrue(private_chat._can_send_away_message("user1"))
                self.assertFalse(private_chat._can_send_away_message("user1"))
                self.assertTrue(private_chat._can_send_away_message("user2"))
                self.assertFalse(private_chat._can_send_away_message("user3"))

            self.assertEqual({"user1", "user2"}, private_chat.away_message_users)

        finally:
            PrivateChat.MAX_AWAY_AUTO_REPLIES_PER_MINUTE = old_reply_limit
            PrivateChat.MAX_AWAY_MESSAGE_USERS = old_user_limit

    def test_away_auto_reply_user_cache_is_capped(self):
        private_chat = self._new_private_chat_auto_replies()
        private_chat.away_message_users = {"user1", "user2"}

        old_user_limit = PrivateChat.MAX_AWAY_MESSAGE_USERS

        try:
            PrivateChat.MAX_AWAY_MESSAGE_USERS = 2
            self.assertFalse(private_chat._can_send_away_message("user3"))
            self.assertEqual({"user1", "user2"}, private_chat.away_message_users)

        finally:
            PrivateChat.MAX_AWAY_MESSAGE_USERS = old_user_limit

    def test_ctcp_auto_replies_are_rate_limited(self):
        private_chat = self._new_private_chat_auto_replies()

        old_reply_limit = PrivateChat.MAX_CTCP_REPLIES_PER_MINUTE
        old_user_limit = PrivateChat.MAX_CTCP_REPLY_USERS
        old_cooldown = PrivateChat.CTCP_REPLY_USER_COOLDOWN

        try:
            PrivateChat.MAX_CTCP_REPLIES_PER_MINUTE = 2
            PrivateChat.MAX_CTCP_REPLY_USERS = 10
            PrivateChat.CTCP_REPLY_USER_COOLDOWN = 60

            with patch.object(privatechat_module.time, "monotonic", Mock(return_value=100.0)):
                self.assertTrue(private_chat._can_send_ctcp_reply("user1"))
                self.assertFalse(private_chat._can_send_ctcp_reply("user1"))
                self.assertTrue(private_chat._can_send_ctcp_reply("user2"))
                self.assertFalse(private_chat._can_send_ctcp_reply("user3"))

            self.assertEqual({"user1", "user2"}, set(private_chat._ctcp_reply_user_times))

        finally:
            PrivateChat.MAX_CTCP_REPLIES_PER_MINUTE = old_reply_limit
            PrivateChat.MAX_CTCP_REPLY_USERS = old_user_limit
            PrivateChat.CTCP_REPLY_USER_COOLDOWN = old_cooldown

    def test_auto_reply_state_can_be_cleared(self):
        private_chat = self._new_private_chat_auto_replies()
        private_chat.away_message_users.update({"user1", "user2"})
        private_chat._away_message_times.extend((1, 2))
        private_chat._away_message_limit_logged = True
        private_chat._ctcp_reply_times.extend((1, 2))
        private_chat._ctcp_reply_user_times.update({"user1": 1, "user2": 2})
        private_chat._ctcp_reply_limit_logged = True

        private_chat._clear_away_message_state()
        private_chat._clear_ctcp_reply_state()

        self.assertFalse(private_chat.away_message_users)
        self.assertFalse(private_chat._away_message_times)
        self.assertFalse(private_chat._away_message_limit_logged)
        self.assertFalse(private_chat._ctcp_reply_times)
        self.assertFalse(private_chat._ctcp_reply_user_times)
        self.assertFalse(private_chat._ctcp_reply_limit_logged)



    def test_unsent_private_message_ack_is_retried_without_duplicate_entries(self):
        private_chat = self._new_private_chat_replay()
        scheduled_callbacks = []
        sent_messages = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())

        try:
            old_batch = PrivateChat.MAX_MESSAGE_ACK_RETRIES_PER_TICK
            PrivateChat.MAX_MESSAGE_ACK_RETRIES_PER_TICK = 1

            with patch.object(privatechat_module, "events", fake_events):
                private_chat._server_message_unsent(MessageAcked(42))
                private_chat._server_message_unsent(MessageAcked(42))

            self.assertEqual([42], list(private_chat._message_ack_retry_queue))
            self.assertEqual({42}, private_chat._message_ack_retry_ids)
            self.assertEqual(1, len(scheduled_callbacks))
            self.assertEqual(PrivateChat.MESSAGE_ACK_RETRY_DELAY, scheduled_callbacks[0][0])

            fake_core = SimpleNamespace(
                send_message_to_server=Mock(side_effect=lambda msg: sent_messages.append(msg) or False)
            )

            with patch.object(privatechat_module, "core", fake_core), \
                    patch.object(privatechat_module, "events", fake_events):
                _delay, callback, callback_args = scheduled_callbacks.pop(0)
                callback(*callback_args)

            self.assertEqual([42], list(private_chat._message_ack_retry_queue))
            self.assertEqual({42}, private_chat._message_ack_retry_ids)
            self.assertEqual(1, len(scheduled_callbacks))
            self.assertIsInstance(sent_messages[-1], MessageAcked)
            self.assertEqual(42, sent_messages[-1].msgid)

            fake_core.send_message_to_server = Mock(side_effect=lambda msg: sent_messages.append(msg) or True)

            with patch.object(privatechat_module, "core", fake_core), \
                    patch.object(privatechat_module, "events", fake_events):
                _delay, callback, callback_args = scheduled_callbacks.pop(0)
                callback(*callback_args)

            self.assertFalse(private_chat._message_ack_retry_queue)
            self.assertFalse(private_chat._message_ack_retry_ids)
            self.assertFalse(private_chat._message_ack_retry_limit_logged)
            self.assertEqual(2, len(sent_messages))

        finally:
            PrivateChat.MAX_MESSAGE_ACK_RETRIES_PER_TICK = old_batch


    def test_unsent_outgoing_private_message_is_retried_without_duplicate_local_fanout(self):
        private_chat = self._new_private_chat_replay()
        scheduled_callbacks = []
        sent_messages = []
        msg = MessageUser("peer", "hello")

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock(), emit=Mock())

        with patch.object(privatechat_module, "events", fake_events):
            private_chat._server_message_unsent(msg)

        self.assertEqual([(msg, False, private_chat._estimate_message_send_retry_size(msg))],
                         list(private_chat._message_send_retry_queue))
        self.assertEqual(1, len(scheduled_callbacks))
        self.assertEqual(PrivateChat.MESSAGE_SEND_RETRY_DELAY, scheduled_callbacks[0][0])
        fake_events.emit.assert_not_called()

        fake_core = SimpleNamespace(
            send_message_to_server=Mock(side_effect=lambda retry_msg: sent_messages.append(retry_msg) or False)
        )

        with patch.object(privatechat_module, "core", fake_core), \
                patch.object(privatechat_module, "events", fake_events):
            _delay, callback, callback_args = scheduled_callbacks.pop(0)
            callback(*callback_args)

        self.assertEqual([(msg, False, private_chat._estimate_message_send_retry_size(msg))],
                         list(private_chat._message_send_retry_queue))
        self.assertEqual(1, len(scheduled_callbacks))
        self.assertEqual([msg], sent_messages)

        fake_core.send_message_to_server = Mock(side_effect=lambda retry_msg: sent_messages.append(retry_msg) or True)

        with patch.object(privatechat_module, "core", fake_core), \
                patch.object(privatechat_module, "events", fake_events):
            _delay, callback, callback_args = scheduled_callbacks.pop(0)
            callback(*callback_args)

        self.assertFalse(private_chat._message_send_retry_queue)
        self.assertEqual(0, private_chat._message_send_retry_bytes)
        self.assertFalse(private_chat._message_send_retry_limit_logged)
        self.assertEqual([msg, msg], sent_messages)
        fake_events.emit.assert_not_called()


    def test_outgoing_private_message_retry_queue_has_byte_budget(self):
        private_chat = self._new_private_chat_replay()
        scheduled_callbacks = []

        def schedule_callback(delay=None, callback=None, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        old_byte_cap = PrivateChat.MAX_PENDING_MESSAGE_SEND_RETRY_BYTES

        try:
            PrivateChat.MAX_PENDING_MESSAGE_SEND_RETRY_BYTES = 8
            fake_events = SimpleNamespace(schedule=schedule_callback, cancel_scheduled=Mock())

            with patch.object(privatechat_module, "events", fake_events):
                self.assertTrue(private_chat._queue_message_send_retry(MessageUser("u", "1234")))
                self.assertFalse(private_chat._queue_message_send_retry(MessageUser("u", "5678")))

            self.assertEqual(1, len(private_chat._message_send_retry_queue))
            self.assertEqual(private_chat._estimate_message_send_retry_size(MessageUser("u", "1234")),
                             private_chat._message_send_retry_bytes)
            self.assertTrue(private_chat._message_send_retry_limit_logged)
            self.assertEqual(1, len(scheduled_callbacks))

        finally:
            PrivateChat.MAX_PENDING_MESSAGE_SEND_RETRY_BYTES = old_byte_cap

    def test_replayed_private_message_id_is_acked_but_not_processed_twice(self):
        private_chat = self._new_private_chat_replay()

        first_msg = MessageUser(user="remoteuser", message="hello")
        first_msg.message_id = 123
        first_msg.timestamp = 1
        first_msg.is_new_message = True

        replayed_msg = MessageUser(user="remoteuser", message="hello again")
        replayed_msg.message_id = 123
        replayed_msg.timestamp = 2
        replayed_msg.is_new_message = True

        fake_core = SimpleNamespace(
            users=SimpleNamespace(
                login_username="localuser",
                login_status=0,
                addresses={"remoteuser": ("1.2.3.4", 1234)}
            ),
            network_filter=SimpleNamespace(
                is_user_ignored=Mock(return_value=False),
                is_user_ip_ignored=Mock(return_value=False)
            ),
            pluginhandler=SimpleNamespace(
                incoming_private_chat_event=Mock(side_effect=lambda username, message: (username, message)),
                incoming_private_chat_notification=Mock()
            ),
            send_message_to_server=Mock()
        )
        fake_log = SimpleNamespace(
            add_chat=Mock(),
            add_debug=Mock(),
            queue_log_file_write=Mock(),
            private_chat_folder_path="/tmp"
        )

        old_logging = {
            "privatechat": config.sections["logging"].get("privatechat"),
            "private_chats": list(config.sections["logging"].get("private_chats", [])),
        }
        old_words = {
            "censorwords": config.sections["words"].get("censorwords"),
            "censored": list(config.sections["words"].get("censored", [])),
        }
        old_autoreply = config.sections["server"].get("autoreply")

        try:
            config.sections["logging"]["privatechat"] = True
            config.sections["logging"]["private_chats"] = []
            config.sections["words"]["censorwords"] = False
            config.sections["words"]["censored"] = []
            config.sections["server"]["autoreply"] = ""

            with (patch.object(privatechat_module, "core", fake_core),
                  patch.object(privatechat_module, "log", fake_log),
                  patch.object(PrivateChat, "show_user", Mock(return_value=True))):
                private_chat._message_user(first_msg)
                private_chat._message_user(replayed_msg)

            self.assertEqual(2, fake_core.send_message_to_server.call_count)
            self.assertEqual(1, fake_log.add_chat.call_count)
            self.assertEqual(1, fake_log.queue_log_file_write.call_count)
            self.assertEqual(1, fake_core.pluginhandler.incoming_private_chat_event.call_count)
            self.assertEqual(1, fake_core.pluginhandler.incoming_private_chat_notification.call_count)
            self.assertIsNone(replayed_msg.user)

        finally:
            config.sections["logging"]["privatechat"] = old_logging["privatechat"]
            config.sections["logging"]["private_chats"] = old_logging["private_chats"]
            config.sections["words"]["censorwords"] = old_words["censorwords"]
            config.sections["words"]["censored"] = old_words["censored"]
            config.sections["server"]["autoreply"] = old_autoreply

    def test_private_message_ack_rejection_does_not_poison_replay_cache_or_deliver(self):
        private_chat = self._new_private_chat_replay()
        msg = MessageUser(user="remoteuser", message="hello")
        msg.message_id = 321
        msg.timestamp = 1
        msg.is_new_message = True

        fake_core = SimpleNamespace(
            users=SimpleNamespace(
                login_username="localuser",
                login_status=0,
                addresses={"remoteuser": ("1.2.3.4", 1234)}
            ),
            network_filter=SimpleNamespace(
                is_user_ignored=Mock(return_value=False),
                is_user_ip_ignored=Mock(return_value=False)
            ),
            pluginhandler=SimpleNamespace(
                incoming_private_chat_event=Mock(side_effect=lambda username, message: (username, message)),
                incoming_private_chat_notification=Mock()
            ),
            send_message_to_server=Mock(return_value=False)
        )
        fake_log = SimpleNamespace(
            add_chat=Mock(),
            add_debug=Mock(),
            queue_log_file_write=Mock(),
            private_chat_folder_path="/tmp"
        )

        with (patch.object(privatechat_module, "core", fake_core),
              patch.object(privatechat_module, "log", fake_log),
              patch.object(PrivateChat, "show_user", Mock(return_value=True)) as show_user):
            private_chat._message_user(msg)

        self.assertIsNone(msg.user)
        self.assertFalse(private_chat._recent_private_message_ids)
        fake_core.send_message_to_server.assert_called_once()
        fake_core.pluginhandler.incoming_private_chat_event.assert_not_called()
        fake_core.pluginhandler.incoming_private_chat_notification.assert_not_called()
        fake_log.add_chat.assert_not_called()
        fake_log.queue_log_file_write.assert_not_called()
        show_user.assert_not_called()

    def test_private_message_ack_acceptance_marks_replay_cache_before_delivery(self):
        private_chat = self._new_private_chat_replay()
        msg = MessageUser(user="remoteuser", message="hello")
        msg.message_id = 654
        msg.timestamp = 1
        msg.is_new_message = True

        fake_core = SimpleNamespace(
            users=SimpleNamespace(
                login_username="localuser",
                login_status=0,
                addresses={"remoteuser": ("1.2.3.4", 1234)}
            ),
            network_filter=SimpleNamespace(
                is_user_ignored=Mock(return_value=False),
                is_user_ip_ignored=Mock(return_value=False)
            ),
            pluginhandler=SimpleNamespace(
                incoming_private_chat_event=Mock(side_effect=lambda username, message: (username, message)),
                incoming_private_chat_notification=Mock()
            ),
            send_message_to_server=Mock(return_value=True)
        )
        fake_log = SimpleNamespace(
            add_chat=Mock(),
            add_debug=Mock(),
            queue_log_file_write=Mock(),
            private_chat_folder_path="/tmp"
        )
        old_logging = {
            "privatechat": config.sections["logging"].get("privatechat"),
            "private_chats": list(config.sections["logging"].get("private_chats", [])),
        }
        old_words = {
            "censorwords": config.sections["words"].get("censorwords"),
            "censored": list(config.sections["words"].get("censored", [])),
        }
        old_autoreply = config.sections["server"].get("autoreply")

        try:
            config.sections["logging"]["privatechat"] = False
            config.sections["logging"]["private_chats"] = []
            config.sections["words"]["censorwords"] = False
            config.sections["words"]["censored"] = []
            config.sections["server"]["autoreply"] = ""

            with (patch.object(privatechat_module, "core", fake_core),
                  patch.object(privatechat_module, "log", fake_log),
                  patch.object(PrivateChat, "show_user", Mock(return_value=True))):
                private_chat._message_user(msg)

        finally:
            config.sections["logging"]["privatechat"] = old_logging["privatechat"]
            config.sections["logging"]["private_chats"] = old_logging["private_chats"]
            config.sections["words"]["censorwords"] = old_words["censorwords"]
            config.sections["words"]["censored"] = old_words["censored"]
            config.sections["server"]["autoreply"] = old_autoreply

        self.assertIn(("remoteuser", 654), private_chat._recent_private_message_ids)
        fake_core.pluginhandler.incoming_private_chat_event.assert_called_once()
        fake_core.pluginhandler.incoming_private_chat_notification.assert_called_once()

    def test_ignored_private_message_is_acked_but_not_logged(self):
        private_chat = self._new_private_chat_replay()
        msg = MessageUser(user="ignoreduser", message="spam")
        msg.message_id = 456
        msg.timestamp = 1
        msg.is_new_message = True

        fake_core = SimpleNamespace(
            users=SimpleNamespace(login_username="localuser", addresses={}),
            network_filter=SimpleNamespace(
                is_user_ignored=Mock(return_value=True),
                is_user_ip_ignored=Mock(return_value=False)
            ),
            pluginhandler=SimpleNamespace(incoming_private_chat_event=Mock()),
            send_message_to_server=Mock()
        )
        fake_log = SimpleNamespace(add_chat=Mock(), add_debug=Mock())

        with (patch.object(privatechat_module, "core", fake_core),
              patch.object(privatechat_module, "log", fake_log),
              patch.object(PrivateChat, "show_user", Mock(return_value=True))):
            private_chat._message_user(msg)

        self.assertIsNone(msg.user)
        fake_core.send_message_to_server.assert_called_once()
        fake_log.add_chat.assert_not_called()
        fake_core.pluginhandler.incoming_private_chat_event.assert_not_called()

    def test_queued_private_message_is_logged_only_after_ip_filter_accepts_it(self):
        private_chat = self._new_private_chat_replay()
        msg = MessageUser(user="remoteuser", message="hello")
        msg.message_id = 789
        msg.timestamp = 1
        msg.is_new_message = True

        fake_core = SimpleNamespace(
            users=SimpleNamespace(
                login_username="localuser",
                login_status=0,
                addresses={"remoteuser": ("1.2.3.4", 1234)}
            ),
            network_filter=SimpleNamespace(
                is_user_ignored=Mock(return_value=False),
                is_user_ip_ignored=Mock(return_value=False)
            ),
            pluginhandler=SimpleNamespace(
                incoming_private_chat_event=Mock(side_effect=lambda username, message: (username, message)),
                incoming_private_chat_notification=Mock()
            ),
            send_message_to_server=Mock()
        )
        fake_log = SimpleNamespace(
            add_chat=Mock(),
            add_debug=Mock(),
            queue_log_file_write=Mock(),
            private_chat_folder_path="/tmp"
        )

        old_logging = {
            "privatechat": config.sections["logging"].get("privatechat"),
            "private_chats": list(config.sections["logging"].get("private_chats", [])),
        }
        old_words = {
            "censorwords": config.sections["words"].get("censorwords"),
            "censored": list(config.sections["words"].get("censored", [])),
        }
        old_autoreply = config.sections["server"].get("autoreply")

        try:
            config.sections["logging"]["privatechat"] = False
            config.sections["logging"]["private_chats"] = []
            config.sections["words"]["censorwords"] = False
            config.sections["words"]["censored"] = []
            config.sections["server"]["autoreply"] = ""

            with (patch.object(privatechat_module, "core", fake_core),
                  patch.object(privatechat_module, "log", fake_log),
                  patch.object(PrivateChat, "show_user", Mock(return_value=True))):
                private_chat._message_user(msg, queued_message=True)

            fake_log.add_chat.assert_called_once()
            fake_core.pluginhandler.incoming_private_chat_event.assert_called_once()

        finally:
            config.sections["logging"]["privatechat"] = old_logging["privatechat"]
            config.sections["logging"]["private_chats"] = old_logging["private_chats"]
            config.sections["words"]["censorwords"] = old_words["censorwords"]
            config.sections["words"]["censored"] = old_words["censored"]
            config.sections["server"]["autoreply"] = old_autoreply

    def test_recent_private_message_id_cache_is_bounded(self):
        private_chat = self._new_private_chat_replay()

        old_limit = PrivateChat.MAX_RECENT_PRIVATE_MESSAGE_IDS
        PrivateChat.MAX_RECENT_PRIVATE_MESSAGE_IDS = 2

        try:
            with patch.object(privatechat_module, "log", SimpleNamespace(add_debug=Mock())):
                self.assertTrue(private_chat._remember_private_message_id("user", 1))
                self.assertTrue(private_chat._remember_private_message_id("user", 2))
                self.assertTrue(private_chat._remember_private_message_id("user", 3))

            self.assertNotIn(("user", 1), private_chat._recent_private_message_ids)
            self.assertIn(("user", 2), private_chat._recent_private_message_ids)
            self.assertIn(("user", 3), private_chat._recent_private_message_ids)
            self.assertTrue(private_chat._remember_private_message_id("user", 1))

        finally:
            PrivateChat.MAX_RECENT_PRIVATE_MESSAGE_IDS = old_limit

    def test_completion_updates_are_capped_and_prioritized(self):
        privatechat = object.__new__(PrivateChat)
        privatechat.completions = set()

        old_login = config.sections["server"].get("login")
        old_word_settings = {
            key: config.sections["words"].get(key)
            for key in ("buddies", "commands", "roomnames")
        }
        old_limit = PrivateChat.MAX_COMPLETIONS
        PrivateChat.MAX_COMPLETIONS = 4

        fake_core = SimpleNamespace(
            buddies=SimpleNamespace(users=["buddy1", "buddy2", "buddy3", "buddy4"]),
            chatrooms=SimpleNamespace(server_rooms=["room1", "room2", "room3", "room4"]),
            pluginhandler=SimpleNamespace(get_command_list=Mock(return_value=["/cmd1", "/cmd2"]))
        )
        fake_events = SimpleNamespace(emit=Mock())

        try:
            config.sections["server"]["login"] = "localuser"
            config.sections["words"].update({"buddies": True, "commands": True, "roomnames": True})

            with patch("pynicotine.privatechat.core", fake_core), patch("pynicotine.privatechat.events", fake_events):
                privatechat.update_completions()

            self.assertEqual({"localuser", "buddy1", "buddy2", "buddy3"}, privatechat.completions)
            fake_core.pluginhandler.get_command_list.assert_not_called()
            fake_events.emit.assert_called_once_with("private-chat-completions", privatechat.completions.copy())

        finally:
            PrivateChat.MAX_COMPLETIONS = old_limit

            if old_login is None:
                config.sections["server"].pop("login", None)
            else:
                config.sections["server"]["login"] = old_login

            for key, value in old_word_settings.items():
                if value is None:
                    config.sections["words"].pop(key, None)
                else:
                    config.sections["words"][key] = value

    def test_message_users_are_batched_and_capped(self):
        private_chat = self._new_private_chat_message_users()

        old_batch_size = PrivateChat.MAX_MESSAGE_USERS_PER_BATCH
        old_batches_per_tick = PrivateChat.MAX_MESSAGE_USER_BATCHES_PER_TICK
        old_pending_users = PrivateChat.MAX_PENDING_MESSAGE_USERS
        PrivateChat.MAX_MESSAGE_USERS_PER_BATCH = 2
        PrivateChat.MAX_MESSAGE_USER_BATCHES_PER_TICK = 1
        PrivateChat.MAX_PENDING_MESSAGE_USERS = 5

        sent_messages = []
        schedule = Mock(return_value=123)
        fake_events = SimpleNamespace(schedule=schedule, cancel_scheduled=Mock())
        fake_core = SimpleNamespace(send_message_to_server=lambda msg: sent_messages.append(msg))

        try:
            with patch.object(privatechat_module, "events", fake_events), patch.object(privatechat_module, "core", fake_core):
                self.assertTrue(private_chat._queue_message_users(["u1", "u2", "u3", "u4", "u5", "u6"], "hello"))
                self.assertEqual(2, len(private_chat._message_users_queue))
                self.assertEqual(123, private_chat._message_users_timer_id)
                schedule.assert_called_once()

                private_chat._process_message_users_queue()
                self.assertEqual(2, len(sent_messages))
                self.assertEqual(("u1", "u2"), tuple(sent_messages[0].users))
                self.assertEqual(("u3", "u4"), tuple(sent_messages[1].users))
                self.assertEqual(1, len(private_chat._message_users_queue))

        finally:
            PrivateChat.MAX_MESSAGE_USERS_PER_BATCH = old_batch_size
            PrivateChat.MAX_MESSAGE_USER_BATCHES_PER_TICK = old_batches_per_tick
            PrivateChat.MAX_PENDING_MESSAGE_USERS = old_pending_users

    def test_message_users_retry_when_server_queue_rejects_batch(self):
        private_chat = self._new_private_chat_message_users()

        old_batch_size = PrivateChat.MAX_MESSAGE_USERS_PER_BATCH
        old_batches_per_tick = PrivateChat.MAX_MESSAGE_USER_BATCHES_PER_TICK
        PrivateChat.MAX_MESSAGE_USERS_PER_BATCH = 2
        PrivateChat.MAX_MESSAGE_USER_BATCHES_PER_TICK = 4

        scheduled_callbacks = []
        sent_messages = []

        def send_message(msg):
            sent_messages.append(msg)
            return False if len(sent_messages) == 1 else True

        fake_core = SimpleNamespace(send_message_to_server=Mock(side_effect=send_message))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 123),
            cancel_scheduled=Mock()
        )

        try:
            with patch.object(privatechat_module, "events", fake_events), patch.object(privatechat_module, "core", fake_core):
                self.assertTrue(private_chat._queue_message_users(["u1", "u2", "u3"], "hello"))
                self.assertEqual(2, len(private_chat._message_users_queue))
                self.assertEqual(1, len(scheduled_callbacks))
                self.assertEqual(PrivateChat.MESSAGE_USERS_RETRY_DELAY, scheduled_callbacks[0][0])

                _delay, callback = scheduled_callbacks.pop(0)
                callback()

            self.assertEqual([], list(private_chat._message_users_queue))
            self.assertEqual(("u1", "u2"), tuple(sent_messages[0].users))
            self.assertEqual(("u1", "u2"), tuple(sent_messages[1].users))
            self.assertEqual(("u3",), tuple(sent_messages[2].users))

        finally:
            PrivateChat.MAX_MESSAGE_USERS_PER_BATCH = old_batch_size
            PrivateChat.MAX_MESSAGE_USER_BATCHES_PER_TICK = old_batches_per_tick

    def test_message_downloading_users_uses_streaming_iterator(self):
        private_chat = self._new_private_chat_message_users()

        iter_downloading_users = Mock(return_value=iter(("u1", "u2")))
        get_downloading_users = Mock()
        fake_core = SimpleNamespace(
            buddies=SimpleNamespace(users=()),
            uploads=SimpleNamespace(
                iter_downloading_users=iter_downloading_users,
                get_downloading_users=get_downloading_users
            ),
            send_message_to_server=Mock()
        )
        fake_events = SimpleNamespace(schedule=Mock(return_value=1), cancel_scheduled=Mock())

        with patch.object(privatechat_module, "core", fake_core), patch.object(privatechat_module, "events", fake_events):
            private_chat.send_message_users("downloading", "hello")

        iter_downloading_users.assert_called_once_with()
        get_downloading_users.assert_not_called()
