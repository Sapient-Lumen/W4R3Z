# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

import io
import json
import os
import tempfile

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

from pynicotine.core import core
from pynicotine.events import events
from pynicotine.shares import PermissionLevel
from pynicotine.slskmessages import FileAttribute
from pynicotine.slskmessages import FileListMessage
from pynicotine.userbrowse import UserBrowse


class UserBrowseTest(TestCase):

    # pylint: disable=protected-access


    def test_request_user_shares_grants_only_after_peer_queue_accepts(self):
        userbrowse = UserBrowse()
        from pynicotine.slskmessages import SHARED_FILE_LIST_USERS_ALLOWED
        SHARED_FILE_LIST_USERS_ALLOWED.clear()

        with patch.object(type(core), "send_message_to_peer", return_value=False):
            self.assertFalse(userbrowse.request_user_shares("peer"))

        self.assertFalse(SHARED_FILE_LIST_USERS_ALLOWED.is_allowed("peer"))

        with patch.object(type(core), "send_message_to_peer", return_value=True):
            self.assertTrue(userbrowse.request_user_shares("peer"))

        self.assertTrue(SHARED_FILE_LIST_USERS_ALLOWED.is_allowed("peer"))
        SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_request_user_shares_retries_after_public_queue_rejection(self):
        from pynicotine.slskmessages import SHARED_FILE_LIST_USERS_ALLOWED

        userbrowse = UserBrowse()
        userbrowse.users["peer"] = SimpleNamespace(
            public_folders={}, private_folders={}, num_folders=None, num_files=None, shared_size=None)
        scheduled_callbacks = []

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        SHARED_FILE_LIST_USERS_ALLOWED.clear()

        try:
            with patch.object(events.__class__, "schedule", schedule), \
                    patch.object(type(core), "send_message_to_peer", side_effect=[False, True]):
                self.assertFalse(userbrowse.request_user_shares("peer"))
                self.assertEqual(1, len(scheduled_callbacks))
                _delay, callback, callback_args = scheduled_callbacks.pop(0)
                callback(*callback_args)

            self.assertTrue(SHARED_FILE_LIST_USERS_ALLOWED.is_allowed("peer"))
            self.assertFalse(userbrowse._peer_request_retry_queue)

        finally:
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_shared_file_list_response_delivery_failure_retries_request(self):
        from pynicotine.slskmessages import SHARED_FILE_LIST_USERS_ALLOWED
        from pynicotine.slskmessages import SharedFileListRequest
        from pynicotine.slskmessages import SharedFileListResponse

        userbrowse = UserBrowse()
        userbrowse.users["peer"] = SimpleNamespace(
            public_folders={}, private_folders={}, num_folders=None, num_files=None, shared_size=None)
        scheduled_callbacks = []

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        SHARED_FILE_LIST_USERS_ALLOWED.clear()

        try:
            with patch.object(events.__class__, "schedule", schedule), \
                    patch.object(type(core), "send_message_to_peer", return_value=True) as send_message:
                userbrowse._peer_response_delivery_failed(
                    SharedFileListResponse, "peer", ("shared-file-list-response",))
                self.assertEqual(1, len(scheduled_callbacks))
                _delay, callback, callback_args = scheduled_callbacks.pop(0)
                callback(*callback_args)

            self.assertEqual("peer", send_message.call_args.args[0])
            self.assertIsInstance(send_message.call_args.args[1], SharedFileListRequest)
            self.assertTrue(SHARED_FILE_LIST_USERS_ALLOWED.is_allowed("peer"))

        finally:
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_upload_queue_notification_retries_after_public_queue_rejection(self):
        userbrowse = UserBrowse()
        scheduled_callbacks = []
        old_uploads = core.uploads
        core.uploads = SimpleNamespace(queued_users={"peer": {"file": object()}}, active_users={}, failed_users={})

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        try:
            with patch.object(events.__class__, "schedule", schedule), \
                    patch.object(type(core), "send_message_to_peer", side_effect=[False, True]) as send_message:
                self.assertFalse(userbrowse.send_upload_attempt_notification("peer"))
                self.assertEqual(1, len(scheduled_callbacks))
                _delay, callback, callback_args = scheduled_callbacks.pop(0)
                callback(*callback_args)

            self.assertEqual(2, send_message.call_count)
            self.assertFalse(userbrowse._peer_request_retry_queue)

        finally:
            core.uploads = old_uploads

    def test_remove_user_tolerates_missing_users_component_on_quit(self):
        userbrowse = UserBrowse()
        userbrowse.users["peer"] = SimpleNamespace(
            public_folders={}, private_folders={}, num_folders=None, num_files=None, shared_size=None)
        old_users = core.users
        core.users = None

        try:
            userbrowse.remove_user("peer")
        finally:
            core.users = old_users

        self.assertNotIn("peer", userbrowse.users)

    def test_load_shares_list_from_disk_rejects_gross_file_before_json_load(self):
        """Saved browse cache loads should not parse grossly oversized files."""

        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "remoteuser")

            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("[]")

            userbrowse = UserBrowse()
            old_limit = UserBrowse.MAX_SAVED_SHARES_FILE_SIZE

            try:
                UserBrowse.MAX_SAVED_SHARES_FILE_SIZE = 1

                with patch("pynicotine.userbrowse.json.load", side_effect=AssertionError("json.load called")):
                    userbrowse.load_shares_list_from_disk(file_path)

            finally:
                UserBrowse.MAX_SAVED_SHARES_FILE_SIZE = old_limit

        self.assertNotIn("remoteuser", userbrowse.users)

    def test_loaded_shares_list_rejects_gross_file_count(self):
        old_limit = UserBrowse.MAX_SAVED_SHARES_FILES

        try:
            UserBrowse.MAX_SAVED_SHARES_FILES = 1

            with self.assertRaises(ValueError):
                UserBrowse._validate_loaded_shares_list({
                    "Folder": [
                        [1, "One.mp3", 1, "", {}],
                        [1, "Two.mp3", 2, "", {}]
                    ]
                })

        finally:
            UserBrowse.MAX_SAVED_SHARES_FILES = old_limit

    def test_load_shares_list_from_disk_normalizes_json_attribute_keys(self):
        """JSON string keys for file attributes are converted back to integers."""

        shares_list = [
            ["Folder", [[1, "Song.mp3", 123, "", {str(FileAttribute.BITRATE): 320}]]]
        ]

        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "remoteuser")

            with open(file_path, "w", encoding="utf-8") as file_handle:
                json.dump(shares_list, file_handle)

            userbrowse = UserBrowse()
            old_pluginhandler = core.pluginhandler
            core.pluginhandler = SimpleNamespace(user_stats_notification=lambda *_args, **_kwargs: None)

            try:
                userbrowse.load_shares_list_from_disk(file_path)
            finally:
                core.pluginhandler = old_pluginhandler

        attrs = userbrowse.users["remoteuser"].public_folders["Folder"][0][4]

        self.assertEqual(attrs, {FileAttribute.BITRATE: 320})
        self.assertNotIn(str(FileAttribute.BITRATE), attrs)
        userbrowse.users.clear()




    def test_load_saved_json_streams_nested_file_records(self):
        """A huge flat saved folder should not need one top-level JSON item buffer."""

        shares_list = [[
            "Folder",
            [
                [1, "One.mp3", 10, "", {str(FileAttribute.BITRATE): 320}],
                [1, "Two.mp3", 20, "", {str(FileAttribute.DURATION): 200}]
            ]
        ]]

        old_item_limit = UserBrowse.MAX_SAVED_SHARES_JSON_ITEM_BYTES

        try:
            # The complete folder item is larger than this, but each individual
            # folder path / file record is small enough. This guards against
            # accidentally going back to raw_decode() of the entire folder item.
            UserBrowse.MAX_SAVED_SHARES_JSON_ITEM_BYTES = 96

            with tempfile.TemporaryDirectory() as temp_dir:
                file_path = os.path.join(temp_dir, "remoteuser")

                with open(file_path, "w", encoding="utf-8") as file_handle:
                    json.dump(shares_list, file_handle)

                userbrowse = UserBrowse()
                old_pluginhandler = core.pluginhandler
                core.pluginhandler = SimpleNamespace(user_stats_notification=lambda *_args, **_kwargs: None)

                try:
                    userbrowse.load_shares_list_from_disk(file_path)
                finally:
                    core.pluginhandler = old_pluginhandler

            files = userbrowse.users["remoteuser"].public_folders["Folder"]
            self.assertEqual(2, len(files))
            self.assertEqual({FileAttribute.BITRATE: 320}, files[0][4])
            self.assertEqual({FileAttribute.DURATION: 200}, files[1][4])
            userbrowse.users.clear()

        finally:
            UserBrowse.MAX_SAVED_SHARES_JSON_ITEM_BYTES = old_item_limit

    def test_loaded_file_info_rejects_gross_extra_fields(self):
        old_limit = UserBrowse.MAX_SAVED_FILE_INFO_FIELDS

        try:
            UserBrowse.MAX_SAVED_FILE_INFO_FIELDS = 5

            with self.assertRaises(ValueError):
                UserBrowse._normalize_loaded_file_info([1, "Song.mp3", 1, "", {}, "extra"])

        finally:
            UserBrowse.MAX_SAVED_FILE_INFO_FIELDS = old_limit

    def test_loaded_file_info_returns_trimmed_record(self):
        file_info = [1, "Song.mp3", 123, "legacy-ext", {str(FileAttribute.BITRATE): 320}]
        normalized = UserBrowse._normalize_loaded_file_info(file_info)

        self.assertEqual([1, "Song.mp3", 123, "", {FileAttribute.BITRATE: 320}], normalized)
        self.assertIsNot(file_info, normalized)
        self.assertEqual("legacy-ext", file_info[3])

    def test_loaded_file_info_rejects_gross_attribute_count(self):
        old_limit = UserBrowse.MAX_SAVED_FILE_ATTRIBUTE_ITEMS

        try:
            UserBrowse.MAX_SAVED_FILE_ATTRIBUTE_ITEMS = 1

            with self.assertRaises(ValueError):
                UserBrowse._normalize_loaded_file_info([1, "Song.mp3", 1, "", {0: 320, 1: 200}])

            with self.assertRaises(ValueError):
                UserBrowse._normalize_loaded_file_info([1, "Song.mp3", 1, "", [320, 200]])

        finally:
            UserBrowse.MAX_SAVED_FILE_ATTRIBUTE_ITEMS = old_limit


    def test_loaded_file_info_rejects_invalid_size_and_attribute_numbers(self):
        with self.assertRaises(ValueError):
            UserBrowse._normalize_loaded_file_info([1, "Song.mp3", -1, "", {}])

        with self.assertRaises(ValueError):
            UserBrowse._normalize_loaded_file_info([1, "Song.mp3", 2 ** 64, "", {}])

        with self.assertRaises(TypeError):
            UserBrowse._normalize_loaded_file_info([1, "Song.mp3", True, "", {}])

        with self.assertRaises(ValueError):
            UserBrowse._normalize_loaded_file_info([1, "Song.mp3", 1, "", {-1: 1}])

        with self.assertRaises(ValueError):
            UserBrowse._normalize_loaded_file_info([1, "Song.mp3", 1, "", {0: 2 ** 32}])

        with self.assertRaises(TypeError):
            UserBrowse._normalize_loaded_file_info([1, "Song.mp3", 1, "", {0: True}])

    def test_open_soulseek_url_rejects_gross_raw_url_before_browsing(self):
        userbrowse = UserBrowse()
        old_limit = UserBrowse.MAX_SOULSEEK_URL_BYTES

        try:
            UserBrowse.MAX_SOULSEEK_URL_BYTES = 16

            with patch.object(UserBrowse, "browse_user", autospec=True) as browse_user:
                self.assertFalse(userbrowse.open_soulseek_url("slsk://alice/" + "x" * 32))

        finally:
            UserBrowse.MAX_SOULSEEK_URL_BYTES = old_limit

        browse_user.assert_not_called()

    def test_open_soulseek_url_rejects_gross_decoded_virtual_path(self):
        userbrowse = UserBrowse()

        with patch.object(FileListMessage, "MAX_VIRTUAL_PATH_BYTES", 4), \
                patch.object(UserBrowse, "browse_user", autospec=True) as browse_user:
            self.assertFalse(userbrowse.open_soulseek_url("slsk://alice/folder/song.mp3"))

        browse_user.assert_not_called()

    def test_open_soulseek_url_normalizes_valid_path(self):
        userbrowse = UserBrowse()

        with patch.object(UserBrowse, "browse_user", autospec=True) as browse_user:
            self.assertTrue(userbrowse.open_soulseek_url("slsk://alice/folder/song.mp3"))

        browse_user.assert_called_once_with(userbrowse, "alice", path="folder\\song.mp3")

    def test_saved_json_rejects_oversized_folder_and_file_names(self):
        old_folder_limit = UserBrowse.MAX_SAVED_SHARES_JSON_ITEM_BYTES

        try:
            UserBrowse.MAX_SAVED_SHARES_JSON_ITEM_BYTES = 4096

            with patch.object(FileListMessage, "MAX_VIRTUAL_PATH_BYTES", 4):
                with self.assertRaises(ValueError):
                    UserBrowse._load_saved_json_shares_list(io.StringIO(json.dumps([["TooLong", []]])))

            with patch.object(FileListMessage, "MAX_BASENAME_BYTES", 4):
                with self.assertRaises(ValueError):
                    UserBrowse._load_saved_json_shares_list(
                        io.StringIO(json.dumps([["Dir", [[1, "TooLong.mp3", 1, "", {}]]]])))

        finally:
            UserBrowse.MAX_SAVED_SHARES_JSON_ITEM_BYTES = old_folder_limit

    def test_count_matching_folder_files_counts_each_file_once(self):
        """Bulk folder confirmation/limits should count matched files without double-counting."""

        userbrowse = UserBrowse()
        browsed_user = SimpleNamespace(
            public_folders={
                "Folder": [
                    [1, "One.mp3", 1, "", {}],
                    [1, "Two.mp3", 2, "", {}]
                ]
            },
            private_folders={}
        )

        self.assertEqual(2, userbrowse._count_matching_folder_files(
            "remoteuser", "Folder", browsed_user, recurse=False))

    def test_download_folder_refuses_gross_bulk_transfer_action(self):
        """Verify recursive folder actions do not enqueue enormous browsed lists in one UI callback."""

        userbrowse = UserBrowse()
        old_limit = UserBrowse.MAX_BULK_FOLDER_TRANSFER_FILES
        UserBrowse.MAX_BULK_FOLDER_TRANSFER_FILES = 1
        userbrowse.users["remoteuser"] = browsed_user = SimpleNamespace(
            public_folders={
                "Folder": [
                    [1, "One.mp3", 1, "", {}],
                    [1, "Two.mp3", 2, "", {}]
                ]
            },
            private_folders={}
        )

        old_downloads = core.downloads
        core.downloads = SimpleNamespace(
            get_folder_destination=lambda *_args, **_kwargs: "destination",
            enqueue_download=lambda *_args, **_kwargs: self.fail("download should not be enqueued")
        )

        try:
            userbrowse.download_folder("remoteuser", "Folder", check_num_files=False)
        finally:
            userbrowse.users.clear()
            core.downloads = old_downloads
            UserBrowse.MAX_BULK_FOLDER_TRANSFER_FILES = old_limit

    def test_upload_folder_refuses_gross_bulk_transfer_action(self):
        """Verify upload-folder actions are capped before walking every browsed file."""

        userbrowse = UserBrowse()
        old_limit = UserBrowse.MAX_BULK_FOLDER_TRANSFER_FILES
        UserBrowse.MAX_BULK_FOLDER_TRANSFER_FILES = 1
        browsed_user = SimpleNamespace(
            public_folders={
                "Folder": [
                    [1, "One.mp3", 1, "", {}],
                    [1, "Two.mp3", 2, "", {}]
                ]
            },
            private_folders={}
        )

        old_uploads = core.uploads
        core.uploads = SimpleNamespace(
            enqueue_upload=lambda *_args, **_kwargs: self.fail("upload should not be enqueued")
        )

        try:
            userbrowse.upload_folder("remoteuser", "Folder", browsed_user)
        finally:
            core.uploads = old_uploads
            UserBrowse.MAX_BULK_FOLDER_TRANSFER_FILES = old_limit

    def test_download_folder_enqueues_browsed_files_in_batches(self):
        """Confirmed browsed-folder downloads should not enqueue every file in one callback turn."""

        userbrowse = UserBrowse()
        userbrowse.users["remoteuser"] = SimpleNamespace(
            public_folders={
                "Folder": [
                    [1, "One.mp3", 1, "", {}],
                    [1, "Two.mp3", 2, "", {}],
                    [1, "Three.mp3", 3, "", {}],
                    [1, "Four.mp3", 4, "", {}]
                ]
            },
            private_folders={}
        )

        enqueued_downloads = []
        scheduled_callbacks = []
        old_downloads = core.downloads
        old_limit = UserBrowse.MAX_FOLDER_TRANSFER_FILES_PER_TICK
        core.downloads = SimpleNamespace(
            get_folder_destination=lambda *_args, **_kwargs: "destination",
            enqueue_download=lambda *args, **kwargs: enqueued_downloads.append((args, kwargs)) or True
        )

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        try:
            UserBrowse.MAX_FOLDER_TRANSFER_FILES_PER_TICK = 2

            with patch.object(events.__class__, "schedule", schedule):
                userbrowse.download_folder("remoteuser", "Folder", check_num_files=False)

                self.assertEqual(2, len(enqueued_downloads))
                self.assertEqual(1, len(scheduled_callbacks))

                while scheduled_callbacks:
                    _delay, callback, callback_args = scheduled_callbacks.pop(0)
                    callback(*callback_args)

        finally:
            core.downloads = old_downloads
            UserBrowse.MAX_FOLDER_TRANSFER_FILES_PER_TICK = old_limit
            userbrowse.users.clear()
            userbrowse._pending_folder_transfers.clear()

        self.assertEqual(4, len(enqueued_downloads))
        self.assertFalse(userbrowse._pending_folder_transfers)
        self.assertIsNone(userbrowse._pending_folder_transfer_timer_id)

    def test_upload_folder_enqueues_browsed_files_in_batches(self):
        """Confirmed browsed-folder uploads should not enqueue every file in one callback turn."""

        userbrowse = UserBrowse()
        browsed_user = SimpleNamespace(
            public_folders={
                "Folder": [
                    [1, "One.mp3", 1, "", {}],
                    [1, "Two.mp3", 2, "", {}],
                    [1, "Three.mp3", 3, "", {}]
                ]
            },
            private_folders={}
        )

        enqueued_uploads = []
        scheduled_callbacks = []
        old_uploads = core.uploads
        old_limit = UserBrowse.MAX_FOLDER_TRANSFER_FILES_PER_TICK
        core.uploads = SimpleNamespace(
            enqueue_upload=lambda *args, **kwargs: enqueued_uploads.append((args, kwargs))
        )

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        try:
            UserBrowse.MAX_FOLDER_TRANSFER_FILES_PER_TICK = 1

            with patch.object(events.__class__, "schedule", schedule):
                userbrowse.upload_folder("remoteuser", "Folder", browsed_user)

                self.assertEqual(1, len(enqueued_uploads))
                self.assertEqual(1, len(scheduled_callbacks))

                while scheduled_callbacks:
                    _delay, callback, callback_args = scheduled_callbacks.pop(0)
                    callback(*callback_args)

        finally:
            core.uploads = old_uploads
            UserBrowse.MAX_FOLDER_TRANSFER_FILES_PER_TICK = old_limit
            userbrowse._pending_folder_transfers.clear()

        self.assertEqual(3, len(enqueued_uploads))
        self.assertFalse(userbrowse._pending_folder_transfers)
        self.assertIsNone(userbrowse._pending_folder_transfer_timer_id)

    def test_browse_user_for_local_user_preserves_new_request_flag(self):
        """Local browse refresh should not be mistaken for a permission level."""

        userbrowse = UserBrowse()

        with patch("pynicotine.userbrowse.core", SimpleNamespace(
                users=SimpleNamespace(login_username="localuser"))):
            with patch.object(UserBrowse, "browse_local_shares") as browse_local_shares:
                userbrowse.browse_user("localuser", path="Music", new_request=True, switch_page=False)

        browse_local_shares.assert_called_once_with("Music", new_request=True, switch_page=False)

    def test_shared_file_list_response_ignores_removed_user_before_summarizing(self):
        """Closed browse tabs should not walk huge parsed result lists just to discard them."""

        class ExplodingShareList:
            def __len__(self):
                raise AssertionError("shares list should not be summarized")

            def __iter__(self):
                raise AssertionError("shares list should not be summarized")

        userbrowse = UserBrowse()
        msg = SimpleNamespace(username="removeduser", list=ExplodingShareList(), privatelist=ExplodingShareList())
        old_pluginhandler = core.pluginhandler
        core.pluginhandler = SimpleNamespace(
            user_stats_notification=lambda *_args, **_kwargs: self.fail("stats should not be emitted")
        )

        try:
            userbrowse._shared_file_list_response(msg)
        finally:
            core.pluginhandler = old_pluginhandler

    def test_shared_file_list_response_uses_precomputed_summary_stats(self):
        """Parsed browse stats should avoid a second file-by-file summary walk."""

        class ExplodingFiles:

            def __len__(self):
                raise AssertionError("file list should not be counted again")

            def __iter__(self):
                raise AssertionError("file list should not be walked again")

        userbrowse = UserBrowse()
        userbrowse.users["remoteuser"] = SimpleNamespace(
            public_folders={}, private_folders={}, num_folders=None, num_files=None, shared_size=None)

        stats_notifications = []
        old_pluginhandler = core.pluginhandler
        core.pluginhandler = SimpleNamespace(
            user_stats_notification=lambda username, stats: stats_notifications.append((username, stats))
        )

        try:
            msg = SimpleNamespace(
                username="remoteuser",
                list=[("Public", ExplodingFiles())],
                privatelist=[],
                num_folders=2,
                num_files=12345,
                shared_size=987654321
            )
            userbrowse._shared_file_list_response(msg)

        finally:
            core.pluginhandler = old_pluginhandler
            userbrowse.users.clear()

        self.assertEqual(12345, stats_notifications[0][1]["files"])
        self.assertEqual(2, stats_notifications[0][1]["dirs"])
        self.assertEqual(987654321, stats_notifications[0][1]["shared_size"])

    def test_shared_file_list_response_reuses_parsed_folder_mappings(self):
        """Parsed share dictionaries should not be copied again into BrowsedUser state."""

        userbrowse = UserBrowse()
        userbrowse.users["remoteuser"] = SimpleNamespace(
            public_folders={}, private_folders={}, num_folders=None, num_files=None, shared_size=None)

        public_folders = {"Public": [(1, "track.mp3", 123, None, {})]}
        private_folders = {"Private": []}
        stats_notifications = []
        old_pluginhandler = core.pluginhandler
        core.pluginhandler = SimpleNamespace(
            user_stats_notification=lambda username, stats: stats_notifications.append((username, stats))
        )

        try:
            msg = SimpleNamespace(
                username="remoteuser", list=public_folders, privatelist=private_folders,
                num_folders=2, num_files=1, shared_size=123)
            userbrowse._shared_file_list_response(msg)

            browsed_user = userbrowse.users["remoteuser"]
            self.assertIs(public_folders, browsed_user.public_folders)
            self.assertIs(private_folders, browsed_user.private_folders)

        finally:
            core.pluginhandler = old_pluginhandler
            userbrowse.users.clear()

        self.assertEqual(1, stats_notifications[0][1]["files"])


    def test_save_shares_list_to_disk_streams_folder_files(self):
        """Saved browsed lists should not encode each whole folder payload at once."""

        class StreamingGuardEncoder(json.JSONEncoder):
            encoded_objects = []

            def encode(self, obj):
                self.encoded_objects.append(obj)

                if isinstance(obj, tuple) and len(obj) == 2 and obj[0] == "Folder":
                    raise AssertionError("whole folder item encoded at once")

                if obj is files:
                    raise AssertionError("whole folder file list encoded at once")

                return super().encode(obj)

        userbrowse = UserBrowse()
        files = [
            [1, "one.mp3", 10, "", {}],
            [1, "two.mp3", 20, "", {}]
        ]
        userbrowse.users["remoteuser"] = SimpleNamespace(public_folders={"Folder": files}, private_folders={})

        with tempfile.TemporaryDirectory() as temp_dir:
            with patch("pynicotine.userbrowse.config", SimpleNamespace(data_folder_path=temp_dir)):
                with patch("pynicotine.userbrowse.json.JSONEncoder", StreamingGuardEncoder):
                    userbrowse.save_shares_list_to_disk("remoteuser")

            with open(os.path.join(temp_dir, "usershares", "remoteuser"), encoding="utf-8") as file_handle:
                saved_data = json.load(file_handle)

        self.assertEqual([["Folder", files]], saved_data)
        self.assertIn("Folder", StreamingGuardEncoder.encoded_objects)
        self.assertIn(files[0], StreamingGuardEncoder.encoded_objects)
        self.assertIn(files[1], StreamingGuardEncoder.encoded_objects)
        userbrowse.users.clear()

    def test_save_shares_list_to_disk_preserves_existing_cache_on_failure(self):
        """A failed large saved-browse write must not truncate the old cache."""

        userbrowse = UserBrowse()
        userbrowse.users["remoteuser"] = SimpleNamespace(public_folders={"Folder": []}, private_folders={})

        with tempfile.TemporaryDirectory() as temp_dir:
            shares_dir = os.path.join(temp_dir, "usershares")
            os.makedirs(shares_dir)
            file_path = os.path.join(shares_dir, "remoteuser")

            with open(file_path, "w", encoding="utf-8") as file_handle:
                json.dump([["Old", []]], file_handle)

            with patch("pynicotine.userbrowse.config", SimpleNamespace(data_folder_path=temp_dir)), \
                    patch.object(UserBrowse, "_write_saved_shares_list_to_file", side_effect=OSError("boom")):
                userbrowse.save_shares_list_to_disk("remoteuser")

            with open(file_path, encoding="utf-8") as file_handle:
                self.assertEqual([["Old", []]], json.load(file_handle))

            self.assertFalse(os.path.exists(file_path + ".new"))

        userbrowse.users.clear()

    def test_save_shares_list_to_disk_rotates_previous_cache_after_success(self):
        """Successful saved-browse writes keep a backup of the previous cache."""

        userbrowse = UserBrowse()
        files = [[1, "new.mp3", 123, "", {}]]
        userbrowse.users["remoteuser"] = SimpleNamespace(public_folders={"New": files}, private_folders={})

        with tempfile.TemporaryDirectory() as temp_dir:
            shares_dir = os.path.join(temp_dir, "usershares")
            os.makedirs(shares_dir)
            file_path = os.path.join(shares_dir, "remoteuser")

            with open(file_path, "w", encoding="utf-8") as file_handle:
                json.dump([["Old", []]], file_handle)

            with patch("pynicotine.userbrowse.config", SimpleNamespace(data_folder_path=temp_dir)):
                userbrowse.save_shares_list_to_disk("remoteuser")

            with open(file_path, encoding="utf-8") as file_handle:
                self.assertEqual([["New", files]], json.load(file_handle))

            with open(file_path + ".old", encoding="utf-8") as file_handle:
                self.assertEqual([["Old", []]], json.load(file_handle))

        userbrowse.users.clear()

    def test_browse_local_shares_suppresses_duplicate_parse_threads(self):
        """Repeated local browse refreshes should not spawn duplicate huge-share parsers."""

        started_threads = []

        class DummySharesMessage:
            def copy_without_results(self):
                return self

        class DummyThread:

            def __init__(self, target=None, args=None, name=None, daemon=None):
                started_threads.append((target, args, name, daemon))

            def start(self):
                return None

        userbrowse = UserBrowse()
        dummy_msg = DummySharesMessage()
        patched_core = SimpleNamespace(
            setup=lambda: None,
            users=SimpleNamespace(
                login_username="localuser",
                watch_user=lambda *_args, **_kwargs: None
            ),
            shares=SimpleNamespace(
                check_user_permission=lambda username: (PermissionLevel.PUBLIC, None),
                compressed_shares={PermissionLevel.PUBLIC: dummy_msg}
            )
        )

        with patch("pynicotine.userbrowse.core", patched_core), patch("pynicotine.userbrowse.Thread", DummyThread):
            userbrowse.browse_local_shares(new_request=True, switch_page=False)
            userbrowse.browse_local_shares(new_request=True, switch_page=False)

        self.assertEqual(1, len(started_threads))
        target, args, name, daemon = started_threads[0]
        self.assertIs(userbrowse, target.__self__)
        self.assertIs(UserBrowse._parse_local_shares, target.__func__)
        self.assertEqual(("localuser", dummy_msg, PermissionLevel.PUBLIC, ("localuser", PermissionLevel.PUBLIC)), args)
        self.assertEqual("LocalShareParser", name)
        self.assertTrue(daemon)
        self.assertIn(("localuser", PermissionLevel.PUBLIC), userbrowse._local_share_parse_keys)

        userbrowse.users.clear()
        userbrowse._local_share_parse_keys.clear()


    def test_parse_local_shares_retries_when_main_thread_delivery_rejected(self):
        """A rejected local self-browse response should retry without retaining the huge parsed payload."""

        class DummySharesMessage:

            @staticmethod
            def make_network_message():
                return b"packed"

            def parse_network_message(self, message):
                self.parsed_message = bytes(message)

        userbrowse = UserBrowse()
        parse_key = ("localuser", PermissionLevel.PUBLIC)
        userbrowse.users["localuser"] = SimpleNamespace()
        userbrowse._local_share_parse_keys.add(parse_key)

        emit_main_thread = Mock(return_value=False)
        schedule = Mock(return_value=123)
        patched_events = SimpleNamespace(
            emit_main_thread=emit_main_thread, schedule=schedule, cancel_scheduled=Mock())

        with patch("pynicotine.userbrowse.events", patched_events):
            userbrowse._parse_local_shares(
                "localuser", DummySharesMessage(), PermissionLevel.PUBLIC, parse_key=parse_key)

        emit_main_thread.assert_called_once()
        schedule.assert_called_once()
        self.assertNotIn(parse_key, userbrowse._local_share_parse_keys)
        self.assertIn(parse_key, userbrowse._local_share_delivery_retry_keys)
        self.assertEqual([parse_key], list(userbrowse._local_share_delivery_retry_queue))

        userbrowse.users.clear()
        userbrowse._clear_local_share_delivery_retries()

    def test_local_share_delivery_retry_starts_new_parser_for_retained_user(self):
        """Retry local self-browse by reparsing cached shares while the user tab remains open."""

        started_threads = []

        class DummySharesMessage:
            def copy_without_results(self):
                return self

        class DummyThread:

            def __init__(self, target=None, args=None, name=None, daemon=None):
                started_threads.append((target, args, name, daemon))

            def start(self):
                return None

        dummy_msg = DummySharesMessage()
        userbrowse = UserBrowse()
        userbrowse.users["localuser"] = SimpleNamespace()
        userbrowse._local_share_delivery_retry_queue.append(("localuser", PermissionLevel.PUBLIC))
        userbrowse._local_share_delivery_retry_keys.add(("localuser", PermissionLevel.PUBLIC))

        patched_core = SimpleNamespace(
            shares=SimpleNamespace(compressed_shares={PermissionLevel.PUBLIC: dummy_msg})
        )

        with patch("pynicotine.userbrowse.core", patched_core), patch("pynicotine.userbrowse.Thread", DummyThread):
            userbrowse._process_local_share_delivery_retries()

        self.assertEqual(1, len(started_threads))
        target, args, name, daemon = started_threads[0]
        self.assertIs(userbrowse, target.__self__)
        self.assertIs(UserBrowse._parse_local_shares, target.__func__)
        self.assertEqual(("localuser", dummy_msg, PermissionLevel.PUBLIC, ("localuser", PermissionLevel.PUBLIC)), args)
        self.assertEqual("LocalShareParser", name)
        self.assertTrue(daemon)

        userbrowse.users.clear()
        userbrowse._local_share_parse_keys.clear()

    def test_parse_local_shares_clears_in_progress_key_on_error(self):
        """The duplicate-parser guard should not get stuck after a parse failure."""

        class BrokenSharesMessage:

            @staticmethod
            def make_network_message():
                return b""

            @staticmethod
            def parse_network_message(_message):
                raise RuntimeError("broken cached shares")

        userbrowse = UserBrowse()
        parse_key = ("localuser", PermissionLevel.PUBLIC)
        userbrowse._local_share_parse_keys.add(parse_key)

        with self.assertRaises(RuntimeError):
            userbrowse._parse_local_shares("localuser", BrokenSharesMessage(), parse_key=parse_key)

        self.assertNotIn(parse_key, userbrowse._local_share_parse_keys)

    def test_soulseek_url_parser_rejects_gross_raw_url_before_decode(self):
        old_limit = UserBrowse.MAX_SOULSEEK_URL_BYTES

        try:
            UserBrowse.MAX_SOULSEEK_URL_BYTES = 16
            self.assertIsNone(UserBrowse._parse_soulseek_url("slsk://" + ("%41" * 100)))
        finally:
            UserBrowse.MAX_SOULSEEK_URL_BYTES = old_limit

    def test_soulseek_url_parser_caps_decoded_username_and_path(self):
        old_url_limit = UserBrowse.MAX_SOULSEEK_URL_BYTES

        try:
            UserBrowse.MAX_SOULSEEK_URL_BYTES = 1024 * 1024
            self.assertIsNone(UserBrowse._parse_soulseek_url("slsk://" + "u" * 2000 + "/Folder"))
            self.assertIsNone(UserBrowse._parse_soulseek_url("slsk://user/" + ("a" * 40000)))
            self.assertEqual(("user", "Folder\\Song.mp3"),
                             UserBrowse._parse_soulseek_url("slsk://user/Folder/Song.mp3"))
        finally:
            UserBrowse.MAX_SOULSEEK_URL_BYTES = old_url_limit

    def test_open_soulseek_url_returns_false_for_malformed_external_url(self):
        userbrowse = UserBrowse()

        with patch.object(UserBrowse, "browse_user", autospec=True, side_effect=AssertionError("browse_user called")):
            self.assertFalse(userbrowse.open_soulseek_url("slsk://" + ("x" * 100000)))
