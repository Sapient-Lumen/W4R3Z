# COPYRIGHT (C) 2020-2024 Nicotine+ Contributors
# COPYRIGHT (C) 2008-2012 quinox <quinox@users.sf.net>
# COPYRIGHT (C) 2007-2009 daelstorm <daelstorm@gmail.com>
# COPYRIGHT (C) 2003-2004 Hyriand <hyriand@thegraveyard.org>
# COPYRIGHT (C) 2001-2003 Alexander Kanavin
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import errno
import random
import selectors
import socket

from ipaddress import ip_address as parse_ip_address
import struct
import sys
import time

from collections import defaultdict
from collections import deque
from itertools import islice
from os import strerror
from threading import Thread

from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.slskmessages import DISTRIBUTED_MESSAGE_CLASSES
from pynicotine.slskmessages import DISTRIBUTED_MESSAGE_CODES
from pynicotine.slskmessages import NETWORK_MESSAGE_EVENTS
from pynicotine.slskmessages import PEER_MESSAGE_CLASSES
from pynicotine.slskmessages import PEER_MESSAGE_CODES
from pynicotine.slskmessages import PEER_INIT_MESSAGE_CLASSES
from pynicotine.slskmessages import PEER_INIT_MESSAGE_CODES
from pynicotine.slskmessages import SERVER_MESSAGE_CLASSES
from pynicotine.slskmessages import SERVER_MESSAGE_CODES
from pynicotine.slskmessages import DOUBLE_UINT32_UNPACK
from pynicotine.slskmessages import UINT32_UNPACK
from pynicotine.slskmessages import AcceptChildren
from pynicotine.slskmessages import BranchLevel
from pynicotine.slskmessages import BranchRoot
from pynicotine.slskmessages import CantConnectToPeer
from pynicotine.slskmessages import CloseConnection
from pynicotine.slskmessages import ConnectionType
from pynicotine.slskmessages import ConnectToPeer
from pynicotine.slskmessages import DistribBranchLevel
from pynicotine.slskmessages import DistribBranchRoot
from pynicotine.slskmessages import DistribEmbeddedMessage
from pynicotine.slskmessages import DistribSearch
from pynicotine.slskmessages import DownloadFile
from pynicotine.slskmessages import EmbeddedMessage
from pynicotine.slskmessages import EmitNetworkMessageEvents
from pynicotine.slskmessages import FileOffset
from pynicotine.slskmessages import FileSearch
from pynicotine.slskmessages import FileSearchResponse
from pynicotine.slskmessages import FOLDER_TOKENS_ALLOWED
from pynicotine.slskmessages import FolderContentsRequest
from pynicotine.slskmessages import FolderContentsResponse
from pynicotine.slskmessages import FileTransferInit
from pynicotine.slskmessages import GetPeerAddress
from pynicotine.slskmessages import GetUserStats
from pynicotine.slskmessages import GetUserStatus
from pynicotine.slskmessages import GLOBAL_RECOMMENDATIONS_ALLOWED
from pynicotine.slskmessages import GLOBAL_ROOM_FEED_ALLOWED
from pynicotine.slskmessages import GlobalRoomMessage
from pynicotine.slskmessages import GlobalRecommendations
from pynicotine.slskmessages import ITEM_RECOMMENDATIONS_ALLOWED
from pynicotine.slskmessages import ITEM_SIMILAR_USERS_ALLOWED
from pynicotine.slskmessages import ItemRecommendations
from pynicotine.slskmessages import ItemSimilarUsers
from pynicotine.slskmessages import RECOMMENDATIONS_ALLOWED
from pynicotine.slskmessages import Recommendations
from pynicotine.slskmessages import RoomList
from pynicotine.slskmessages import RoomSearch
from pynicotine.slskmessages import SEARCH_TOKENS_ALLOWED
from pynicotine.slskmessages import SIMILAR_USERS_ALLOWED
from pynicotine.slskmessages import SimilarUsers
from pynicotine.slskmessages import USER_INTERESTS_USERS_ALLOWED
from pynicotine.slskmessages import UserInterests
from pynicotine.slskmessages import UserSearch
from pynicotine.slskmessages import HaveNoParent
from pynicotine.slskmessages import JoinGlobalRoom
from pynicotine.slskmessages import LeaveGlobalRoom
from pynicotine.slskmessages import Login
from pynicotine.slskmessages import MessageType
from pynicotine.slskmessages import PossibleParents
from pynicotine.slskmessages import QueueUpload
from pynicotine.slskmessages import ParentMinSpeed
from pynicotine.slskmessages import ParentSpeedRatio
from pynicotine.slskmessages import PeerInit
from pynicotine.slskmessages import PlaceInQueueRequest
from pynicotine.slskmessages import PlaceInQueueResponse
from pynicotine.slskmessages import PierceFireWall
from pynicotine.slskmessages import Relogged
from pynicotine.slskmessages import ResetDistributed
from pynicotine.slskmessages import ServerConnect
from pynicotine.slskmessages import ServerMessage
from pynicotine.slskmessages import ServerDisconnect
from pynicotine.slskmessages import ServerReconnect
from pynicotine.slskmessages import SHARED_FILE_LIST_USERS_ALLOWED
from pynicotine.slskmessages import SetDownloadLimit
from pynicotine.slskmessages import SetUploadLimit
from pynicotine.slskmessages import SetWaitPort
from pynicotine.slskmessages import SharedFileListRequest
from pynicotine.slskmessages import SharedFileListResponse
from pynicotine.slskmessages import SlskMessage
from pynicotine.slskmessages import TransferRequest
from pynicotine.slskmessages import TransferResponse
from pynicotine.slskmessages import UnwatchUser
from pynicotine.slskmessages import UploadDenied
from pynicotine.slskmessages import UploadFailed
from pynicotine.slskmessages import UploadFile
from pynicotine.slskmessages import UploadQueueNotification
from pynicotine.slskmessages import USER_INFO_USERS_ALLOWED
from pynicotine.slskmessages import UserInfoRequest
from pynicotine.slskmessages import UserInfoResponse
from pynicotine.slskmessages import UserStatus
from pynicotine.slskmessages import WatchUser
from pynicotine.slskmessages import WishlistSearch
from pynicotine.slskmessages import increment_token
from pynicotine.slskmessages import initial_token
from pynicotine.utils import human_speed


class Connection:
    __slots__ = ("sock", "addr", "io_events", "is_established", "in_buffer", "out_buffer",
                 "out_buffer_tracked_size", "file_upload_buffer_tracked_size", "out_buffer_segments",
                 "last_active", "recv_size")

    def __init__(self, sock=None, addr=None, io_events=None):

        self.sock = sock
        self.addr = addr
        self.io_events = io_events
        self.in_buffer = bytearray()
        self.out_buffer = bytearray()
        self.out_buffer_tracked_size = 0
        self.file_upload_buffer_tracked_size = 0
        self.out_buffer_segments = deque()
        self.last_active = time.monotonic()
        self.recv_size = 51200
        self.is_established = False


class ServerConnection(Connection):
    __slots__ = ("login",)

    def __init__(self, *args, login=None, **kwargs):
        Connection.__init__(self, *args, **kwargs)
        self.login = login


class PeerConnection(Connection):
    __slots__ = ("init", "request_token", "response_token", "has_post_init_activity",
                 "progress_msg_size_total", "progress_buffer_len", "large_message_size_total",
                 "preinit_address_key")

    def __init__(self, *args, init=None, request_token=None, response_token=None, **kwargs):

        Connection.__init__(self, *args, **kwargs)

        self.init = init
        self.request_token = request_token    # Requesting indirect connection to user
        self.response_token = response_token  # Responding to indirect connection request from user
        self.has_post_init_activity = False
        self.progress_msg_size_total = 0
        self.progress_buffer_len = 0
        self.large_message_size_total = 0
        self.preinit_address_key = None


class PendingPeerConnection:
    __slots__ = ("addr", "init", "response_token", "queued_time")

    def __init__(self, addr, init, response_token=None, queued_time=None):
        self.addr = addr
        self.init = init
        self.response_token = response_token
        self.queued_time = time.monotonic() if queued_time is None else queued_time


class NetworkInterfaces:

    IP_BIND_ADDRESS_NO_PORT = SO_BINDTODEVICE = None

    if sys.platform == "win32":
        from ctypes import POINTER, Structure, wintypes

        AF_INET = 2

        GAA_FLAG_SKIP_ANYCAST = 2
        GAA_FLAG_SKIP_MULTICAST = 4
        GAA_FLAG_SKIP_DNS_SERVER = 8

        ERROR_BUFFER_OVERFLOW = 111

        class SockaddrIn(Structure):
            pass

        class SocketAddress(Structure):
            pass

        class IpAdapterUnicastAddress(Structure):
            pass

        class IpAdapterAddresses(Structure):
            pass

        SockaddrIn._fields_ = [  # pylint: disable=protected-access
            ("sin_family", wintypes.USHORT),
            ("sin_port", wintypes.USHORT),
            ("sin_addr", wintypes.BYTE * 4),
            ("sin_zero", wintypes.CHAR * 8)
        ]

        SocketAddress._fields_ = [  # pylint: disable=protected-access
            ("lp_sockaddr", POINTER(SockaddrIn)),
            ("i_sockaddr_length", wintypes.INT)
        ]

        IpAdapterUnicastAddress._fields_ = [  # pylint: disable=protected-access
            ("length", wintypes.ULONG),
            ("flags", wintypes.DWORD),
            ("next", POINTER(IpAdapterUnicastAddress)),
            ("address", SocketAddress)
        ]

        IpAdapterAddresses._fields_ = [  # pylint: disable=protected-access
            ("length", wintypes.ULONG),
            ("if_index", wintypes.DWORD),
            ("next", POINTER(IpAdapterAddresses)),
            ("adapter_name", wintypes.LPSTR),
            ("first_unicast_address", POINTER(IpAdapterUnicastAddress)),
            ("first_anycast_address", wintypes.LPVOID),
            ("first_multicast_address", wintypes.LPVOID),
            ("first_dns_server_address", wintypes.LPVOID),
            ("dns_suffix", wintypes.LPWSTR),
            ("description", wintypes.LPWSTR),
            ("friendly_name", wintypes.LPWSTR)
        ]

    elif sys.platform == "linux":
        IP_BIND_ADDRESS_NO_PORT = 24
        SIOCGIFADDR = 0x8915
        SO_BINDTODEVICE = 25

    elif sys.platform.startswith("sunos"):
        SIOCGIFADDR = -0x3fdf96f3  # Solaris

    else:
        SIOCGIFADDR = 0xc0206921   # macOS, *BSD

    @classmethod
    def _get_interface_addresses_win32(cls):
        """Returns a dictionary of network interface names and IP addresses (Win32).

        https://learn.microsoft.com/en-us/windows/win32/api/iphlpapi/nf-iphlpapi-getadaptersaddresses
        """

        # pylint: disable=invalid-name

        from ctypes import POINTER, byref, cast, create_string_buffer, windll, wintypes

        interface_addresses = {}
        adapter_addresses_size = wintypes.ULONG()
        return_value = cls.ERROR_BUFFER_OVERFLOW

        while return_value == cls.ERROR_BUFFER_OVERFLOW:
            p_adapter_addresses = cast(
                create_string_buffer(adapter_addresses_size.value), POINTER(cls.IpAdapterAddresses)
            )
            return_value = windll.Iphlpapi.GetAdaptersAddresses(
                cls.AF_INET,
                (cls.GAA_FLAG_SKIP_ANYCAST | cls.GAA_FLAG_SKIP_MULTICAST | cls.GAA_FLAG_SKIP_DNS_SERVER),
                None,
                p_adapter_addresses,
                byref(adapter_addresses_size),
            )

        if return_value:
            log.add_debug("Failed to get list of network interfaces. Error code %s", return_value)
            return interface_addresses

        while p_adapter_addresses:
            adapter_addresses = p_adapter_addresses.contents

            if adapter_addresses.first_unicast_address:
                interface_name = adapter_addresses.friendly_name
                socket_address = adapter_addresses.first_unicast_address[0].address
                interface_addresses[interface_name] = socket.inet_ntoa(socket_address.lp_sockaddr[0].sin_addr)

            p_adapter_addresses = adapter_addresses.next

        return interface_addresses

    @classmethod
    def _get_interface_addresses_posix(cls):
        """Returns a dictionary of network interface names and IP addresses
        (POSIX)"""

        interface_addresses = {}

        try:
            interface_name_index = socket.if_nameindex()

        except (AttributeError, OSError) as error:
            log.add_debug("Failed to get list of network interfaces: %s", error)
            return interface_addresses

        for _i, interface_name in interface_name_index:
            try:
                import fcntl

                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                    ip_interface = fcntl.ioctl(sock.fileno(),
                                               cls.SIOCGIFADDR,
                                               struct.pack("256s", interface_name.encode()[:15]))

                    ip_address = socket.inet_ntoa(ip_interface[20:24])
                    interface_addresses[interface_name] = ip_address

            except (ImportError, OSError) as error:
                log.add_debug("Failed to get IP address for network interface %s: %s", (interface_name, error))
                continue

        return interface_addresses

    @classmethod
    def get_interface_addresses(cls):
        """Returns a dictionary of network interface names and IP addresses."""

        if sys.platform == "win32":
            return cls._get_interface_addresses_win32()

        return cls._get_interface_addresses_posix()

    @classmethod
    def get_interface_address(cls, interface_name):
        """Returns the IP address of a specific network interface."""

        if not interface_name:
            return None

        return cls.get_interface_addresses().get(interface_name)

    @classmethod
    def bind_to_interface(cls, sock, interface_name, address):
        """Bind socket to the specified network interface name, if required on
        the current platform. Otherwise bind to the IP address of the network
        interface, retrieved from get_interface_addresses().
        """

        if cls.SO_BINDTODEVICE:
            try:
                # We need to use SO_BINDTODEVICE on Linux, since socket.bind() has no
                # effect on routing (weak host model).
                sock.setsockopt(socket.SOL_SOCKET, cls.SO_BINDTODEVICE, interface_name.encode())
                return

            except PermissionError as error:
                log.add_debug("Failed to bind socket to network interface with SO_BINDTODEVICE. "
                              "Falling back to socket.bind(). Error: %s", error)

                # We only need to bind to the interface address, not a port.
                # Set IP_BIND_ADDRESS_NO_PORT to avoid reserving an ephemeral port in bind(),
                # and let connect() select one instead later.
                sock.setsockopt(socket.SOL_IP, cls.IP_BIND_ADDRESS_NO_PORT, 1)

        sock.bind((address, 0))


class NetworkThread(Thread):
    """This is the networking thread that does all the communication with the
    Soulseek server and peers. Communication with the core is done through
    events.

    The server and peers send each other small binary messages that
    start with length and message code followed by the actual message
    data.
    """

    __slots__ = ("pending_shutdown", "upload_speed", "token", "_pending_network_msgs",
                 "_user_update_counter", "_user_update_counters", "_upload_queue_timer_id",
                 "_retry_failed_uploads_timer_id")

    IN_PROGRESS_STALE_AFTER = 2
    INDIRECT_REQUEST_TIMEOUT = 20
    CONNECTION_MAX_IDLE = 60
    CONNECTION_MAX_IDLE_GHOST = 10
    MIN_SOCKET_RECV_SIZE = 4096
    MAX_SOCKET_RECV_SIZE = 1024 * 1024  # 1 MiB per recv call
    CONNECTION_BACKLOG_LENGTH = 65535      # OS limit can be lower
    MAX_INCOMING_MESSAGE_SIZE = 469762048  # 448 MiB, to leave headroom for large shares
    MAX_FILE_UPLOAD_BUFFER_SIZE = 8 * 1024 * 1024  # 8 MiB read-ahead per upload connection
    MAX_FILE_UPLOAD_BUFFER_BYTES = 512 * 1024 * 1024  # 512 MiB queued file-upload read-ahead across sockets
    MAX_FILE_DOWNLOAD_WRITE_BYTES_PER_CYCLE = 64 * 1024 * 1024  # 64 MiB synchronous file-download reads/writes per cycle
    MAX_OUTGOING_MESSAGE_BUFFER_SIZE = 128 * 1024 * 1024  # 128 MiB non-file-message backlog per peer
    MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE = 32 * 1024 * 1024  # 32 MiB queued commands to the server
    MAX_OUTGOING_BUFFER_BYTES = 768 * 1024 * 1024  # 768 MiB queued non-file output buffers across sockets
    MAX_INCOMING_BUFFER_BYTES = 768 * 1024 * 1024  # 768 MiB raw non-file input buffers across sockets
    LARGE_INCOMING_MESSAGE_THRESHOLD = 16 * 1024 * 1024  # 16 MiB counts toward the aggregate peer budget
    MAX_LARGE_INCOMING_PEER_MESSAGE_BYTES = 512 * 1024 * 1024  # 512 MiB across incomplete peer bodies
    MAX_LARGE_INCOMING_PEER_MESSAGES = 4
    MAX_PENDING_NETWORK_MESSAGES = 65536
    MAX_PENDING_NETWORK_MESSAGE_BYTES = 256 * 1024 * 1024  # retained Python objects before packing/sending
    MAX_PENDING_TRANSFER_NETWORK_MESSAGES = 32768
    MAX_PENDING_PEER_CONNECTION_RETRIES_PER_TICK = 64
    MAX_PENDING_PEER_CONNECTION_AGE = 60
    MAX_INDIRECT_REQUEST_TIMEOUTS_PER_TICK = 256
    MAX_QUEUED_MESSAGES_PER_CYCLE = 4096
    MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH = 250
    MAX_HEAVY_OUTGOING_MESSAGES_PER_CYCLE = 8
    MAX_INCOMING_MESSAGES_PER_CONNECTION_CYCLE = 1024
    MAX_BUFFERED_CONNECTIONS_PER_CYCLE = 64
    MAX_INCOMING_ACCEPTS_PER_CYCLE = 64
    MAX_INCOMING_PREINIT_CONNECTIONS_PER_ADDRESS = 64
    MAX_READY_SOCKETS_PER_CYCLE = 512
    MAX_UNKNOWN_SERVER_MESSAGE_SIZE = SlskMessage.MAX_UNKNOWN_SERVER_MESSAGE_SIZE
    MAX_POSSIBLE_PARENT_CONNECTION_ATTEMPTS = 16
    MAX_PENDING_PEER_INIT_USERS = 4096
    MAX_PENDING_PEER_INITS_PER_USER = 8
    MAX_PENDING_PEER_MESSAGES_PER_INIT = 256
    MAX_PENDING_PEER_MESSAGES = 65536
    MAX_PENDING_PEER_MESSAGE_BYTES_PER_INIT = 16 * 1024 * 1024
    MAX_PENDING_PEER_MESSAGE_BYTES = 128 * 1024 * 1024
    MAX_PENDING_PEER_CONNECTIONS = 4096
    MAX_PENDING_INDIRECT_REQUESTS = 8192
    MAX_INCOMING_INDIRECT_CONNECTS_PER_MINUTE = 256
    INCOMING_INDIRECT_CONNECT_RATE_PERIOD = 60
    MAX_FORWARDED_DISTRIBUTED_SEARCHES = 8192
    FORWARDED_DISTRIBUTED_SEARCH_TTL = 300
    MAX_DISTRIBUTED_SERVER_CONTROL_RETRIES = 64
    MAX_DISTRIBUTED_SERVER_CONTROL_RETRIES_PER_CYCLE = 8
    MAX_WAIT_PORT_REPORT_RETRIES = 8
    MAX_CANT_CONNECT_TO_PEER_RETRIES = 1024
    MAX_CANT_CONNECT_TO_PEER_RETRIES_PER_CYCLE = 64
    MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRIES = 8192
    MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRY_BYTES = 64 * 1024 * 1024
    MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRIES_PER_CYCLE = 256
    PRIORITY_MAIN_THREAD_LIFECYCLE_EVENTS = {
        "server-login", "server-disconnect", "server-message-unsent",
        "server-response-delivery-failed", "peer-connection-error",
        "peer-connection-closed", "file-connection-closed", "download-file-error",
        "upload-file-error", "peer-message-unsent", "peer-request-unsent",
        "peer-response-delivery-failed", "peer-response-unsent"
    }
    RETRYABLE_MAIN_THREAD_MESSAGE_EVENTS = {
        "change-password", "check-privileges", "connect-to-peer", "excluded-search-phrases",
        "file-transfer-init", "file-search-request-distributed", "file-search-request-server",
        "folder-contents-request", "join-room", "leave-room", "message-user", "peer-address",
        "place-in-queue-request", "place-in-queue-response", "private-room-add-operator",
        "private-room-add-user", "private-room-added", "private-room-operator-added",
        "private-room-operator-removed", "private-room-operators", "private-room-remove-operator",
        "private-room-remove-user", "private-room-removed", "private-room-toggle",
        "private-room-users", "privileged-users", "queue-upload", "set-wishlist-interval",
        "shared-file-list-request", "ticker-add", "ticker-remove", "ticker-state",
        "transfer-request", "transfer-response", "upload-denied", "upload-failed",
        "user-info-request", "user-joined-room", "user-left-room", "user-country",
        "user-stats", "user-status", "watch-user"
    }
    # Keep one increment of headroom before forwarding branch levels as signed int32.
    MAX_DISTRIBUTED_BRANCH_LEVEL = 0x7ffffffe
    LARGE_MESSAGE_PROGRESS_INTERVAL = 256 * 1024
    MAX_LOGGED_MESSAGE_CONTENT_SIZE = 256
    SERVER_PEER_MESSAGE_CODE_SIZE = 4
    DISTRIBUTED_MESSAGE_CODE_SIZE = 1
    ALLOWED_PEER_CONN_TYPES = {
        ConnectionType.PEER,
        ConnectionType.FILE,
        ConnectionType.DISTRIBUTED
    }
    ERROR_NOT_CONNECTED = OSError(errno.ENOTCONN, strerror(errno.ENOTCONN))
    ERROR_TIMED_OUT = OSError(errno.ETIMEDOUT, strerror(errno.ETIMEDOUT))
    INTERNALLY_HANDLED_SERVER_MESSAGES = frozenset({
        CantConnectToPeer,
        EmbeddedMessage,
        ParentMinSpeed,
        ParentSpeedRatio,
        PossibleParents,
        Relogged,
        ResetDistributed
    })
    PEER_CONNECTION_FAILURE_MESSAGE_CLASSES = frozenset({
        FileTransferInit,
        PlaceInQueueRequest,
        QueueUpload,
        TransferRequest
    })
    PEER_REQUEST_UNSENT_MESSAGE_CLASSES = frozenset({
        FolderContentsRequest,
        SharedFileListRequest,
        UploadQueueNotification,
        UserInfoRequest
    })

    # Looping max ~240 times per second (SLEEP_MIN_IDLE) on high activity
    # ~20 (SLEEP_MAX_IDLE + SLEEP_MIN_IDLE) by default
    SLEEP_MAX_IDLE = 0.04584
    SLEEP_MIN_IDLE = 0.00416

    try:
        import resource

        # Increase the process file limit to a maximum of 10240 (macOS limit), to provide
        # breathing room for opening both peer sockets and regular files (file transfers,
        # log files etc.)

        _SOFT_FILE_LIMIT, HARD_FILE_LIMIT = resource.getrlimit(resource.RLIMIT_NOFILE)    # pylint: disable=no-member
        MAX_FILE_LIMIT = min(HARD_FILE_LIMIT, 10240)

        resource.setrlimit(resource.RLIMIT_NOFILE, (MAX_FILE_LIMIT, MAX_FILE_LIMIT))  # pylint: disable=no-member

        # Reserve 2/3 of the file limit for sockets, but always limit the maximum number
        # of sockets to 3072 to improve performance.

        MAX_SOCKETS = min(int(MAX_FILE_LIMIT * (2 / 3)), 3072)

    except ImportError:
        # For Windows, FD_SETSIZE is set to 512 in CPython.
        # This limit is hardcoded, so we'll have to live with it for now.
        # https://github.com/python/cpython/issues/72894

        MAX_SOCKETS = 512

    def __init__(self):

        super().__init__(name="NetworkThread")

        self._message_queue = deque()
        self._message_queue_sizes = deque()
        self._queued_close_connection_socks = set()
        self._pending_network_message_bytes = 0
        self._pending_network_message_byte_limit_logged = False
        self._server_message_unavailable_limit_logged = False
        self._dropped_network_messages = 0
        self._pending_transfer_network_messages = 0
        self._dropped_transfer_network_messages = 0
        self._pending_peer_conns = {}
        self._pending_peer_message_count = 0
        self._pending_peer_message_bytes = 0
        self._pending_peer_message_limit_logged = False
        self._pending_init_msgs = defaultdict(list)
        self._token_init_msgs = {}
        self._username_init_msgs = {}
        self._requested_peer_addresses = set()
        self._user_addresses = {}
        self._should_process_queue = False
        self._want_abort = False
        self._incoming_buffer_bytes = 0
        self._incoming_buffer_limit_logged = False
        self._outgoing_buffer_bytes = 0
        self._outgoing_buffer_limit_logged = False
        self._file_upload_buffer_bytes = 0
        self._file_upload_buffer_limit_logged = False
        self._file_download_cycle_bytes = 0
        self._large_peer_message_buffer_bytes = 0
        self._large_peer_message_buffer_count = 0
        self._large_peer_message_buffer_limit_logged = False
        self._incoming_preinit_peer_addresses = defaultdict(int)
        self._incoming_preinit_peer_address_limit_logged = False
        self._incoming_indirect_conn_times = deque()
        self._incoming_indirect_conn_limit_logged = False
        self._forwarded_distributed_searches = {}
        self._forwarded_distributed_search_order = deque()
        self._distributed_server_control_retries = deque()
        self._distributed_server_control_retry_keys = set()
        self._distributed_server_control_retry_limit_logged = False
        self._wait_port_report_retries = deque()
        self._wait_port_report_retry_keys = set()
        self._wait_port_report_retry_limit_logged = False
        self._cant_connect_to_peer_retries = deque()
        self._cant_connect_to_peer_retry_keys = set()
        self._cant_connect_to_peer_retry_limit_logged = False
        self._main_thread_lifecycle_event_retries = deque()
        self._main_thread_lifecycle_event_retry_bytes = 0
        self._main_thread_lifecycle_event_retry_limit_logged = False

        self._selector = None
        self._listen_socket = None
        self._listen_port = None
        self._interface_name = None
        self._interface_address = None
        self._portmapper = None
        self._local_ip_address = ""

        self._server_conn = None
        self._server_address = None
        self._server_username = None
        self._server_timeout_time = None
        self._server_timeout_value = -1
        self._manual_server_disconnect = False
        self._manual_server_reconnect = False
        self._server_relogged = False

        self._parent_conn = None
        self._potential_parents = {}
        self._child_peers = {}
        self._branch_level = 0
        self._branch_root = None
        self._is_server_parent = False
        self._distrib_parent_min_speed = 0
        self._distrib_parent_speed_ratio = 1
        self._max_distrib_children = 0
        self._upload_speed = 0

        self._num_sockets = 0
        self._last_cycle_time = 0

        self._conns = {}
        self._token = initial_token()

        self._file_init_msgs = {}
        self._file_download_msgs = {}
        self._file_upload_msgs = {}
        self._conns_downloaded = defaultdict(int)
        self._conns_uploaded = defaultdict(int)
        self._calc_upload_limit_function = self._calc_upload_limit_none
        self._upload_limit = 0
        self._download_limit = 0
        self._upload_limit_split = 0
        self._download_limit_split = 0
        self._total_uploads = 0
        self._total_downloads = 0
        self._total_download_bandwidth = 0
        self._total_upload_bandwidth = 0

        for event_name, callback in (
            ("enable-message-queue", self._enable_message_queue),
            ("queue-network-message", self._queue_network_message),
            ("schedule-quit", self._schedule_quit),
            ("start", self.start)
        ):
            events.connect(event_name, callback)

    def _enable_message_queue(self):
        self._should_process_queue = True

    @staticmethod
    def _is_critical_network_message(msg):
        return getattr(msg, "msg_type", None) in {MessageType.INTERNAL, MessageType.FILE}

    @staticmethod
    def _is_transfer_network_message(msg):
        if getattr(msg, "msg_type", None) == MessageType.FILE:
            return True

        return msg.__class__ in {DownloadFile, UploadFile}

    @staticmethod
    def _is_heavy_outgoing_network_message(msg):
        return msg.__class__ in {
            FileSearchResponse, FolderContentsResponse, SharedFileListResponse, UserInfoResponse
        }

    @staticmethod
    def _is_queue_byte_cap_exempt(msg):
        """Tiny lifecycle/control messages must remain deliverable under pressure.

        Internal messages such as EmitNetworkMessageEvents, DownloadFile and
        UploadFile can retain large nested objects or feed transfer fanout, so
        they are intentionally *not* exempt from the aggregate retained-object
        budget.
        """

        return msg.__class__ in {
            CloseConnection, ServerConnect, ServerDisconnect, ServerReconnect,
            SetDownloadLimit, SetUploadLimit
        }

    @staticmethod
    def _is_priority_network_message(msg):
        """Return True for tiny lifecycle controls that should not sit behind
        heavyweight backlog.

        Queue byte/count exemptions keep these messages accepted, but FIFO
        ordering can still delay a disconnect/reconnect/close or bandwidth-limit
        update behind thousands of queued peer/search/browse messages. These
        controls are intentionally small and state-machine oriented, so process
        them from the front of the next queue drain.
        """

        return msg.__class__ in {
            CloseConnection, ServerConnect, ServerDisconnect, ServerReconnect,
            SetDownloadLimit, SetUploadLimit
        }

    @staticmethod
    def _is_latest_only_network_message(msg):
        """Return True for queued controls where only the newest value matters."""

        return msg.__class__ in {SetDownloadLimit, SetUploadLimit}

    def _estimate_network_message_queue_size(self, msg):
        """Estimate retained Python-object bytes for queued network messages.

        Socket/input/output budgets cover bytes after packing or receipt. The
        network-thread message queue is earlier: it can hold heavyweight message
        objects containing result lists, folder lists or deferred event batches.
        Count caps alone are weak there, so use the same conservative walker as
        pre-connection peer queues and stop after the process-wide queue budget.
        """

        return self._estimate_pending_peer_message_size(msg, limit=self.MAX_PENDING_NETWORK_MESSAGE_BYTES)

    @staticmethod
    def _get_close_connection_queue_key(msg):
        if msg.__class__ is not CloseConnection:
            return None

        return getattr(msg, "sock", None)

    def _add_close_connection_queue_key(self, msg):
        key = self._get_close_connection_queue_key(msg)

        if key is not None:
            self._queued_close_connection_socks.add(key)

    def _release_close_connection_queue_key(self, msg):
        key = self._get_close_connection_queue_key(msg)

        if key is not None:
            self._queued_close_connection_socks.discard(key)

    def _append_network_message_queue(self, msg, msg_size=None, priority=False):
        if msg_size is None:
            msg_size = self._estimate_network_message_queue_size(msg)

        if priority:
            insert_at = 0

            for queued_msg in self._message_queue:
                if not self._is_priority_network_message(queued_msg):
                    break

                insert_at += 1

            self._message_queue.insert(insert_at, msg)
            self._message_queue_sizes.insert(insert_at, msg_size)
        else:
            self._message_queue.append(msg)
            self._message_queue_sizes.append(msg_size)

        self._pending_network_message_bytes += msg_size
        self._add_close_connection_queue_key(msg)

    def _coalesce_latest_network_message(self, msg, msg_size):
        if not self._is_latest_only_network_message(msg):
            return False

        msg_class = msg.__class__

        for index, queued_msg in enumerate(self._message_queue):
            if queued_msg.__class__ is not msg_class:
                continue

            old_size = self._message_queue_sizes[index] if index < len(self._message_queue_sizes) else 0
            self._message_queue[index] = msg

            if index < len(self._message_queue_sizes):
                self._message_queue_sizes[index] = msg_size

            self._pending_network_message_bytes = max(
                0, self._pending_network_message_bytes - old_size + msg_size)
            return True

        return False

    def _release_network_message_queue_size(self, msg_size):
        if msg_size <= 0:
            return

        self._pending_network_message_bytes = max(0, self._pending_network_message_bytes - msg_size)

        if self._pending_network_message_bytes < (self.MAX_PENDING_NETWORK_MESSAGE_BYTES // 2):
            self._pending_network_message_byte_limit_logged = False

    def _pop_network_message_queue(self):
        msg = self._message_queue.popleft()
        msg_size = self._message_queue_sizes.popleft() if self._message_queue_sizes else 0
        self._release_network_message_queue_size(msg_size)
        self._release_close_connection_queue_key(msg)
        return msg

    def _revoke_unsent_network_message_grant(self, msg):
        msg_type = getattr(msg, "msg_type", None)

        if msg_type == MessageType.SERVER:
            self._handle_unsent_server_request(msg)
            return

        if msg_type == MessageType.PEER:
            self._revoke_unsent_peer_request_grant(getattr(msg, "username", None), msg)

    def _clear_network_message_queue(self, revoke_unsent=False):
        if revoke_unsent:
            for msg in self._message_queue:
                self._revoke_unsent_network_message_grant(msg)

        self._message_queue.clear()
        self._message_queue_sizes.clear()
        self._queued_close_connection_socks.clear()
        self._pending_network_message_bytes = 0
        self._pending_network_message_byte_limit_logged = False
        self._pending_transfer_network_messages = 0

    def _can_queue_server_message(self, msg):
        """Return True if a server-bound message has a live local sink.

        Callers increasingly use send_message_to_server() as an accepted-work
        boundary before mutating local ledgers/config/state. A server message
        accepted into the network queue while no server socket exists would be
        dropped later by _process_server_output(), after the caller already
        treated it as sent. Reject those messages at the public queue boundary
        instead, matching the later output-stage precondition.
        """

        if getattr(msg, "msg_type", None) != MessageType.SERVER:
            return True

        try:
            conn = self._server_conn

        except AttributeError:
            # Some focused unit tests instantiate the network thread via
            # object.__new__() and populate only the queue attributes under
            # test. Treat those isolated queue-budget fixtures as having no
            # server-connection opinion. Real NetworkThread instances always
            # initialize _server_conn.
            return True

        if conn is not None and conn.sock is not None:
            return True

        if not getattr(self, "_server_message_unavailable_limit_logged", False):
            log.add_conn(
                "Rejecting server message %s because no active server connection is available",
                msg.__class__
            )
            self._server_message_unavailable_limit_logged = True

        return False

    def _queue_network_message(self, msg):
        if not self._should_process_queue:
            return False

        if not self._can_queue_server_message(msg):
            return False

        close_key = self._get_close_connection_queue_key(msg)

        if close_key is not None and close_key in self._queued_close_connection_socks:
            # Closing a socket is idempotent. Under transfer-abort storms, many
            # producers can queue CloseConnection for the same socket before the
            # network thread drains the first one. Treat duplicates as accepted
            # work already represented in the queue rather than letting tiny
            # priority controls grow without bound.
            return True

        is_transfer_message = self._is_transfer_network_message(msg)
        msg_size = self._estimate_network_message_queue_size(msg)
        is_byte_cap_exempt = self._is_queue_byte_cap_exempt(msg)

        if is_transfer_message:
            pending_transfer_messages = getattr(self, "_pending_transfer_network_messages", 0)

            if pending_transfer_messages >= self.MAX_PENDING_TRANSFER_NETWORK_MESSAGES:
                self._dropped_transfer_network_messages += 1

                if self._dropped_transfer_network_messages == 1:
                    log.add_conn(
                        "Dropping transfer/file network messages because the pending transfer "
                        "queue reached %(limit)s items", {"limit": self.MAX_PENDING_TRANSFER_NETWORK_MESSAGES})

                return False

        elif (len(self._message_queue) >= self.MAX_PENDING_NETWORK_MESSAGES
                and not self._is_critical_network_message(msg)):
            self._dropped_network_messages += 1

            if self._dropped_network_messages == 1:
                log.add_conn(
                    "Dropping non-critical outgoing network messages because the pending queue "
                    "reached %(limit)s items", {"limit": self.MAX_PENDING_NETWORK_MESSAGES})

            return False

        if (not is_byte_cap_exempt
                and self._pending_network_message_bytes + msg_size > self.MAX_PENDING_NETWORK_MESSAGE_BYTES):
            self._dropped_network_messages += 1

            if not self._pending_network_message_byte_limit_logged:
                log.add_conn(
                    "Dropping outgoing network messages because the pending queue retained-object "
                    "budget reached %(limit)s bytes", {"limit": self.MAX_PENDING_NETWORK_MESSAGE_BYTES})
                self._pending_network_message_byte_limit_logged = True

            return False

        if self._coalesce_latest_network_message(msg, msg_size):
            return True

        self._append_network_message_queue(
            msg, msg_size, priority=self._is_priority_network_message(msg))

        if is_transfer_message:
            self._pending_transfer_network_messages = getattr(self, "_pending_transfer_network_messages", 0) + 1

        return True

    def _schedule_quit(self):
        self._want_abort = True

    # Listening Socket #

    def _create_listen_socket(self):

        try:
            self._listen_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._listen_socket.setblocking(False)

        except OSError as error:
            self._set_server_timer(use_fixed_timeout=True)
            log.add(_("Cannot create listening socket. Error: %(error)s"), {"error": error})
            self._close_listen_socket()
            return False

        # On platforms other than Windows, SO_REUSEADDR is necessary to allow binding
        # to the same port immediately after reconnecting. This option behaves differently
        # on Windows, allowing other programs to hijack the port, so don't set it there.

        try:
            if sys.platform != "win32":
                self._listen_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        except OSError as error:
            self._set_server_timer(use_fixed_timeout=True)
            log.add(_("Cannot configure listening socket. Error: %(error)s"), {"error": error})
            self._close_listen_socket()
            return False

        self._num_sockets += 1

        if not self._bind_listen_port():
            self._close_listen_socket()
            return False

        try:
            self._selector.register(self._listen_socket, selectors.EVENT_READ)

        except (OSError, ValueError, KeyError) as error:
            self._set_server_timer(use_fixed_timeout=True)
            log.add(_("Cannot register listening socket. Error: %(error)s"), {"error": error})
            self._close_listen_socket()
            return False

        return True

    def _close_listen_socket(self):

        if self._listen_socket is None:
            return

        try:
            self._selector.unregister(self._listen_socket)

        except (KeyError, ValueError):
            # Socket was not registered
            pass

        self._close_socket(self._listen_socket)
        self._listen_socket = None
        self._listen_port = None
        self._num_sockets = max(0, self._num_sockets - 1)

    def _bind_listen_port(self):

        if not self._bind_socket_interface(self._listen_socket):
            self._set_server_timer(use_fixed_timeout=True)
            log.add(_("Specified network interface '%s' is not available"), self._interface_name)
            return False

        try:
            ip_address = self._interface_address or self._find_local_ip_address()

            self._listen_socket.bind((ip_address, self._listen_port))
            self._listen_socket.listen(self.CONNECTION_BACKLOG_LENGTH)

        except OSError as error:
            self._set_server_timer(use_fixed_timeout=True)
            log.add(_("Cannot listen on port %(port)s. Ensure no other application uses it, or choose a "
                      "different port. Error: %(error)s"), {"port": self._listen_port, "error": error})
            self._listen_port = None
            return False

        self._local_ip_address = ip_address

        if self._interface_name:
            log.add_debug("Network interface: %s", self._interface_name)

        log.add_debug("Local IP address: %s", ip_address)
        log.add_debug("Maximum number of concurrent connections (sockets): %s", self.MAX_SOCKETS)
        log.add(_("Listening on port: %i"), self._listen_port)
        return True

    # Connections #

    @staticmethod
    def _revoke_unsent_peer_request_grant(username, msg):
        """Revoke heavyweight response grants for peer requests that were not sent.

        UserBrowse/UserInfo/Downloads install one-shot response grants after the
        public send_message_to_peer() call accepts work into the network-thread
        queue. That is still earlier than the peer queue/socket output stage: a
        bounded pre-connection queue, closed socket, pack failure or outgoing
        buffer cap can reject the request later. If that happens, the matching
        heavyweight response grant must be removed too; otherwise a later
        unsolicited browse/info/folder response from the same peer can reuse a
        grant for a request we never actually put on the wire.
        """

        if msg.__class__ is SharedFileListRequest:
            SHARED_FILE_LIST_USERS_ALLOWED.discard(username)
            return

        if msg.__class__ is UserInfoRequest:
            USER_INFO_USERS_ALLOWED.discard(username)
            return

        if msg.__class__ is FolderContentsRequest:
            token = getattr(msg, "token", None)

            if token is not None:
                FOLDER_TOKENS_ALLOWED.discard((username, token))



    @staticmethod
    def _estimate_main_thread_lifecycle_event_retry_size(event_name, args, kwargs):
        """Estimate retained bytes for lifecycle-event retry payloads.

        The retry shelf was originally meant for tiny rollback/error events, but
        accepted protocol-control events can legitimately carry bounded strings
        such as private-chat messages. Keep the shelf itself bounded by bytes so
        a full main-thread bridge cannot turn retry preservation into another
        retained-object memory cliff.
        """

        total = len(event_name) + 128
        seen = set()
        limit = NetworkThread.MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRY_BYTES

        def add(value):
            nonlocal total

            if value is None or total > limit:
                return

            value_id = id(value)

            if value_id in seen:
                return

            seen.add(value_id)

            if isinstance(value, (bytes, bytearray, memoryview)):
                total += len(value)
                return

            if isinstance(value, str):
                total += len(value.encode("utf-8", "replace"))
                return

            if isinstance(value, dict):
                total += len(value) * 64

                for key, item in value.items():
                    add(key)
                    add(item)

                    if total > limit:
                        break

                return

            if isinstance(value, (list, tuple, set, frozenset, deque)):
                total += len(value) * 32

                for item in value:
                    add(item)

                    if total > limit:
                        break

                return

            for attr in getattr(value, "__slots__", ()):
                try:
                    add(getattr(value, attr))

                except AttributeError:
                    continue

                if total > limit:
                    break

        add(args)
        add(kwargs)
        return total

    def _clear_main_thread_lifecycle_event_retries(self):
        self._main_thread_lifecycle_event_retries.clear()
        self._main_thread_lifecycle_event_retry_bytes = 0
        self._main_thread_lifecycle_event_retry_limit_logged = False

    def _release_main_thread_lifecycle_event_retry_size(self, event_name, args, kwargs):
        event_size = self._estimate_main_thread_lifecycle_event_retry_size(event_name, args, kwargs)
        self._main_thread_lifecycle_event_retry_bytes = max(
            0, self._main_thread_lifecycle_event_retry_bytes - event_size)

        if (len(self._main_thread_lifecycle_event_retries) < (self.MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRIES // 2)
                and self._main_thread_lifecycle_event_retry_bytes < (
                    self.MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRY_BYTES // 2)):
            self._main_thread_lifecycle_event_retry_limit_logged = False

    def _can_queue_main_thread_lifecycle_event_retry(self, event_size):
        return (len(self._main_thread_lifecycle_event_retries) < self.MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRIES
                and self._main_thread_lifecycle_event_retry_bytes + event_size
                <= self.MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRY_BYTES)

    def _drop_main_thread_lifecycle_event_retry_at(self, index):
        event_name, args, kwargs = self._main_thread_lifecycle_event_retries[index]
        del self._main_thread_lifecycle_event_retries[index]
        self._release_main_thread_lifecycle_event_retry_size(event_name, args, kwargs)
        return event_name

    def _make_room_for_priority_main_thread_lifecycle_event_retry(self, event_size):
        """Evict ordinary preserved payloads before dropping cleanup/rollback events.

        The lifecycle retry shelf intentionally preserves some accepted request
        intent and bounded parsed payloads, but tiny rollback/close notifications
        are the events that release active transfer, peer-init and grant state.
        If the shelf is full of ordinary preserved payloads, a priority cleanup
        event must be able to displace them instead of being dropped. Preserve
        priority-event ordering by evicting only nonpriority entries, starting
        with the newest/lowest-value ordinary retry.
        """

        if event_size > self.MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRY_BYTES:
            return False

        dropped_event_names = []

        while not self._can_queue_main_thread_lifecycle_event_retry(event_size):
            evict_index = None

            for index in range(len(self._main_thread_lifecycle_event_retries) - 1, -1, -1):
                queued_event_name = self._main_thread_lifecycle_event_retries[index][0]

                if queued_event_name not in self.PRIORITY_MAIN_THREAD_LIFECYCLE_EVENTS:
                    evict_index = index
                    break

            if evict_index is None:
                return False

            dropped_event_names.append(self._drop_main_thread_lifecycle_event_retry_at(evict_index))

        if dropped_event_names:
            log.add_conn(
                "Dropped %s nonpriority main-thread lifecycle event retries to preserve priority event %s",
                (len(dropped_event_names), dropped_event_names[0])
            )

        return True

    def _queue_main_thread_lifecycle_event_retry(self, event_name, args, kwargs):
        event_size = self._estimate_main_thread_lifecycle_event_retry_size(event_name, args, kwargs)
        is_priority_event = event_name in self.PRIORITY_MAIN_THREAD_LIFECYCLE_EVENTS

        if not self._can_queue_main_thread_lifecycle_event_retry(event_size):
            if (not is_priority_event
                    or not self._make_room_for_priority_main_thread_lifecycle_event_retry(event_size)):
                if not self._main_thread_lifecycle_event_retry_limit_logged:
                    log.add_conn(
                        "Dropping main-thread lifecycle event retry %s because the retry shelf is full",
                        event_name
                    )
                    self._main_thread_lifecycle_event_retry_limit_logged = True

                return False

        queued_event = (event_name, args, kwargs)

        if is_priority_event:
            # Retry-preserved parsed messages such as private messages or
            # search/browse requests can be much larger and more numerous than
            # tiny rollback/close notifications. Do not let a blocked preserved
            # payload at the head of the retry shelf hide cleanup events whose
            # loss leaves transfers, peer inits or server ledgers stale. Insert
            # priority lifecycle events after the existing priority prefix so
            # their relative ordering is still preserved.
            insert_index = 0

            for queued_event_name, _queued_args, _queued_kwargs in self._main_thread_lifecycle_event_retries:
                if queued_event_name not in self.PRIORITY_MAIN_THREAD_LIFECYCLE_EVENTS:
                    break

                insert_index += 1

            self._main_thread_lifecycle_event_retries.insert(insert_index, queued_event)

        else:
            self._main_thread_lifecycle_event_retries.append(queued_event)

        self._main_thread_lifecycle_event_retry_bytes += event_size
        return True

    def _emit_main_thread_lifecycle_event(self, event_name, *args, **kwargs):
        """Emit a tiny lifecycle event, preserving it if the main-thread bridge is full.

        Network-thread cleanup paths often mutate or close sockets before the main
        thread can update transfer/user state. If a bounded main-thread critical
        shelf rejects one of these lifecycle notifications, silently consuming it
        leaves stale transfers or peer ledgers behind. Retry only small lifecycle
        events through a bounded queue; heavyweight parsed responses keep their
        existing acceptance/rollback paths.
        """

        if events.emit_main_thread(event_name, *args, **kwargs) is not False:
            return True

        return self._queue_main_thread_lifecycle_event_retry(event_name, args, kwargs)

    def _process_main_thread_lifecycle_event_retries(self):
        if not self._main_thread_lifecycle_event_retries:
            return

        num_retried = 0

        while (self._main_thread_lifecycle_event_retries
                and num_retried < self.MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRIES_PER_CYCLE):
            event_name, args, kwargs = self._main_thread_lifecycle_event_retries.popleft()

            if events.emit_main_thread(event_name, *args, **kwargs) is False:
                self._main_thread_lifecycle_event_retries.appendleft((event_name, args, kwargs))
                self._main_thread_lifecycle_event_retry_limit_logged = False
                return

            self._release_main_thread_lifecycle_event_retry_size(event_name, args, kwargs)
            num_retried += 1

    def _should_emit_unsent_peer_request_event(self, msg):
        """Return whether a peer request owner needs lower-failure retry visibility.

        Some user-facing peer requests are small request frames whose response
        grants or user-visible intent are owned outside the network thread. Public
        send_message_to_peer() acceptance only proves the request entered the
        network queue; a later pre-connection, pack, closed-socket or output-buffer
        failure should return a lightweight signal to the owner without copying
        heavyweight response objects back to the main thread.
        """

        return msg.__class__ in self.PEER_REQUEST_UNSENT_MESSAGE_CLASSES

    def _emit_unsent_peer_request_event(self, msg, username=None):
        if self._should_emit_unsent_peer_request_event(msg):
            if username is None:
                username = getattr(msg, "username", None)

            self._emit_main_thread_lifecycle_event(
                "peer-request-unsent", msg.__class__, username, msg
            )

    @staticmethod
    def _should_emit_unsent_peer_message_event(msg):
        """Return whether a lower-layer peer-send failure needs main-thread rollback.

        Heavy browse/profile/folder requests only need parser-grant revocation here;
        transfer-control messages also mutate local transfer state after public queue
        acceptance, so lower socket/output failures must be visible to transfer
        managers.
        """

        return msg.__class__ in {
            TransferRequest, TransferResponse, FileTransferInit, QueueUpload,
            PlaceInQueueRequest, PlaceInQueueResponse, UploadDenied, UploadFailed
        }

    def _handle_unsent_peer_message(self, msg):
        self._revoke_unsent_peer_request_grant(getattr(msg, "username", None), msg)
        self._emit_unsent_peer_request_event(msg)

        rollback_info = getattr(msg, "unsent_rollback_info", None)

        if rollback_info is not None:
            self._emit_main_thread_lifecycle_event(
                "peer-response-unsent", msg.__class__, getattr(msg, "username", None), rollback_info)
            msg.unsent_rollback_info = None

        if self._should_emit_unsent_peer_message_event(msg):
            self._emit_main_thread_lifecycle_event("peer-message-unsent", msg)

    def _revoke_unsent_peer_request_grants(self, init):
        username = init.target_user

        for msg in init.outgoing_msgs:
            self._revoke_unsent_peer_request_grant(username, msg)

    @classmethod
    def _get_peer_connection_failure_messages(cls, outgoing_msgs):
        """Return only queued peer messages needed by transfer error handlers.

        A peer init can hold many outgoing messages while address/connection
        setup is pending. GUI browse/info error handlers only need the username
        and connection type; transfer handlers only inspect a small set of
        transfer-control message classes. Do not copy and retain an entire
        pre-connection queue in a main-thread error event.
        """

        if not outgoing_msgs:
            return []

        return [
            msg for msg in outgoing_msgs
            if msg.__class__ in cls.PEER_CONNECTION_FAILURE_MESSAGE_CLASSES
        ]

    def _emit_unsent_peer_request_events(self, init):
        for msg in init.outgoing_msgs:
            self._emit_unsent_peer_request_event(msg, username=init.target_user)

    def _emit_peer_connection_result(self, event_name, username, conn_type, init, **kwargs):
        self._emit_unsent_peer_request_events(init)
        self._revoke_unsent_peer_request_grants(init)
        self._emit_main_thread_lifecycle_event(
            event_name, username=username, conn_type=conn_type,
            msgs=self._get_peer_connection_failure_messages(init.outgoing_msgs), **kwargs
        )

    def _emit_peer_connection_error(self, username, conn_type, init, **kwargs):
        self._emit_peer_connection_result("peer-connection-error", username, conn_type, init, **kwargs)

    @staticmethod
    def _get_preinit_peer_address_key(addr):
        """Return a stable key for a direct peer socket before PeerInit identifies it."""

        if not addr:
            return None

        try:
            return addr[0]

        except (IndexError, TypeError):
            return str(addr)

    def _reserve_preinit_peer_address(self, conn):
        """Reserve a per-source slot for an accepted direct peer before PeerInit.

        A remote host can complete TCP handshakes and then send no valid peer-init
        data. Generic socket caps eventually help, but the connection table and
        selector can still be occupied by many sockets from one address before the
        application knows the peer username/connection type.
        """

        address_key = self._get_preinit_peer_address_key(conn.addr)

        if address_key is None:
            return True

        if self._incoming_preinit_peer_addresses[address_key] >= self.MAX_INCOMING_PREINIT_CONNECTIONS_PER_ADDRESS:
            if not self._incoming_preinit_peer_address_limit_logged:
                log.add_conn(
                    "Maximum number of incoming pre-PeerInit connections from one address reached: %s",
                    self.MAX_INCOMING_PREINIT_CONNECTIONS_PER_ADDRESS
                )
                self._incoming_preinit_peer_address_limit_logged = True

            return False

        self._incoming_preinit_peer_addresses[address_key] += 1
        conn.preinit_address_key = address_key
        return True

    def _release_preinit_peer_address(self, conn):
        address_key = getattr(conn, "preinit_address_key", None)

        if address_key is None:
            return

        count = self._incoming_preinit_peer_addresses.get(address_key, 0)

        if count <= 1:
            self._incoming_preinit_peer_addresses.pop(address_key, None)
        else:
            self._incoming_preinit_peer_addresses[address_key] = count - 1

        conn.preinit_address_key = None

    def _indirect_request_error(self, token, init):

        username = init.target_user
        conn_type = init.conn_type

        log.add_conn("Indirect connect request of type %s to user %s with "
                     "token %s failed", (conn_type, username, token))

        if init.sock is not None:
            return

        # No direct connection was established, give up
        self._emit_peer_connection_error(username, conn_type, init)
        self._clear_queued_peer_messages(init, revoke_unsent=True)
        self._username_init_msgs.pop(self._get_init_key(username, conn_type), None)

    def _check_indirect_request_timeouts(self, current_time=None, expire_all=False):
        """Expire indirect peer-connection requests without a one-cycle storm.

        A full pending-token table can otherwise turn one timeout check into
        thousands of peer-connection-error events and server cleanup messages.
        Server disconnect still uses expire_all=True to release everything
        immediately during teardown.
        """

        if not self._token_init_msgs:
            return

        if current_time is None:
            current_time = time.monotonic()

        max_timeouts = len(self._token_init_msgs) if expire_all else self.MAX_INDIRECT_REQUEST_TIMEOUTS_PER_TICK
        timed_out_tokens = []

        for token, (_init, request_time) in self._token_init_msgs.items():
            if not expire_all and (current_time - request_time) < self.INDIRECT_REQUEST_TIMEOUT:
                # Requests are inserted in age order. Once the first pending
                # request is still fresh, newer requests cannot have timed out
                # yet. Avoid walking the full pending table on every scheduler
                # tick when many indirect requests are outstanding.
                break

            timed_out_tokens.append(token)

            if len(timed_out_tokens) >= max_timeouts:
                break

        for token in timed_out_tokens:
            init = self._token_init_msgs.pop(token, (None, None))[0]

            if init is None:
                continue

            self._indirect_request_error(token, init)

    def _is_connection_still_active(self, conn):

        init = conn.init

        if init is not None and (init.conn_type != "P" or init.target_user == self._server_username):
            # Distributed and file connections, as well as connections to ourselves,
            # are critical. Always assume they are active.
            return True

        return len(conn.out_buffer) > 0 or len(conn.in_buffer) > 0

    def _bind_socket_interface(self, sock):
        """Attempt to bind socket to an IP address, if provided with the
        --bindip CLI argument. Otherwise retrieve the IP address of the
        requested interface name, cache it for later, and bind to it.
        """

        if self._interface_address:
            if sock is not self._listen_socket:
                NetworkInterfaces.bind_to_interface(sock, self._interface_name, self._interface_address)

            return True

        if not self._interface_name:
            return True

        return False

    def _find_local_ip_address(self):

        # Create a UDP socket
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as local_socket:

            # Send a broadcast packet on a local address (doesn't need to be reachable,
            # but MacOS requires port to be non-zero)
            local_socket.connect_ex(("10.255.255.255", 1))

            # This returns the "primary" IP on the local box, even if that IP is a NAT/private/internal IP
            ip_address = local_socket.getsockname()[0]

        return ip_address

    @staticmethod
    def _get_init_key(username, conn_type):
        return (username, conn_type)

    @staticmethod
    def _get_pending_peer_conn_key(addr, init, response_token):
        return (addr, init.target_user, init.conn_type, response_token)

    def _remove_init_message(self, init):
        if init.conn_type == ConnectionType.FILE:
            return

        init_key = self._get_init_key(init.target_user, init.conn_type)

        if self._username_init_msgs.get(init_key) is init:
            del self._username_init_msgs[init_key]

    def _add_init_message(self, init):

        conn_type = init.conn_type

        if conn_type == ConnectionType.FILE:
            # File transfer connections are not unique or reused later
            return True

        init_key = self._get_init_key(init.target_user, conn_type)

        if init_key not in self._username_init_msgs:
            self._username_init_msgs[init_key] = init
            return True

        return False

    @staticmethod
    def _pack_network_message(msg):

        try:
            return msg.make_network_message()

        except Exception:
            from traceback import format_exc
            log.add("Unable to pack message type %s: %s", (msg.__class__, format_exc()))

        return None

    @classmethod
    def _get_message_content_preview(cls, msg_content):
        """Return a bounded preview of message contents for parse-error logs."""

        try:
            content_len = len(msg_content)

        except TypeError:
            return msg_content

        max_size = cls.MAX_LOGGED_MESSAGE_CONTENT_SIZE

        if content_len <= max_size:
            return msg_content

        preview = msg_content[:max_size]

        if isinstance(preview, memoryview):
            preview = preview.tobytes()

        elif not isinstance(preview, bytes):
            preview = bytes(preview)

        return f"{preview!r}... ({content_len - max_size} bytes omitted)"

    @classmethod
    def _should_emit_large_message_progress(cls, conn, buffer_len, msg_size_total):
        """Throttle progress updates for huge peer messages that arrive in chunks."""

        if conn.progress_msg_size_total != msg_size_total:
            conn.progress_msg_size_total = msg_size_total
            conn.progress_buffer_len = buffer_len
            return True

        if buffer_len < conn.progress_buffer_len:
            conn.progress_buffer_len = buffer_len
            return True

        if buffer_len - conn.progress_buffer_len < cls.LARGE_MESSAGE_PROGRESS_INTERVAL:
            return False

        conn.progress_buffer_len = buffer_len
        return True

    @staticmethod
    def _reset_large_message_progress(conn):
        conn.progress_msg_size_total = 0
        conn.progress_buffer_len = 0

    def _register_large_message_buffer(self, conn, msg_size_total):
        """Reserve aggregate budget for an incomplete large peer message body."""

        if msg_size_total < self.LARGE_INCOMING_MESSAGE_THRESHOLD:
            self._unregister_large_message_buffer(conn)
            return True

        previous_size = conn.large_message_size_total

        if previous_size == msg_size_total:
            return True

        new_bytes = self._large_peer_message_buffer_bytes - previous_size + msg_size_total
        new_count = self._large_peer_message_buffer_count

        if previous_size == 0:
            new_count += 1

        if (new_bytes > self.MAX_LARGE_INCOMING_PEER_MESSAGE_BYTES
                or new_count > self.MAX_LARGE_INCOMING_PEER_MESSAGES):

            if not self._large_peer_message_buffer_limit_logged:
                log.add_conn(
                    "Closing peer connection; aggregate incomplete large-message buffer budget would be exceeded "
                    "(%s bytes, %s messages)",
                    (new_bytes, new_count)
                )
                self._large_peer_message_buffer_limit_logged = True

            return False

        conn.large_message_size_total = msg_size_total
        self._large_peer_message_buffer_bytes = new_bytes
        self._large_peer_message_buffer_count = new_count
        return True

    def _unregister_large_message_buffer(self, conn):

        msg_size_total = getattr(conn, "large_message_size_total", 0)

        if not msg_size_total:
            return

        self._large_peer_message_buffer_bytes = max(0, self._large_peer_message_buffer_bytes - msg_size_total)
        self._large_peer_message_buffer_count = max(0, self._large_peer_message_buffer_count - 1)
        conn.large_message_size_total = 0

        if self._large_peer_message_buffer_count == 0:
            self._large_peer_message_buffer_limit_logged = False

    def _record_out_buffer_segment(self, conn, segment_type, num_bytes):
        """Record the accounting class of bytes appended to ``conn.out_buffer``.

        A file connection can contain a small file-control message followed by
        file-upload read-ahead bytes in the same socket buffer. Accounting by
        aggregate counters alone cannot tell which bytes a later send() has
        actually consumed, so keep a tiny FIFO of buffer segments and release
        budgets in wire order.
        """

        if num_bytes <= 0:
            return

        segments = conn.out_buffer_segments

        if segments and segments[-1][0] == segment_type:
            old_segment_type, old_num_bytes = segments[-1]
            segments[-1] = (old_segment_type, old_num_bytes + num_bytes)
            return

        segments.append((segment_type, num_bytes))

    def _append_outgoing_data(self, conn, header, msg_content, description):
        """Append non-file output while enforcing a global output-buffer budget."""

        total_size = len(header) + len(msg_content)
        outgoing_buffer_bytes = getattr(self, "_outgoing_buffer_bytes", 0)

        if outgoing_buffer_bytes + total_size > self.MAX_OUTGOING_BUFFER_BYTES:
            if not getattr(self, "_outgoing_buffer_limit_logged", False):
                log.add_conn(
                    "Closing connection %s; aggregate outgoing %s buffer would exceed maximum size %s",
                    (getattr(conn, "addr", None), description, self.MAX_OUTGOING_BUFFER_BYTES)
                )
                self._outgoing_buffer_limit_logged = True

            self._close_connection(conn)
            return False

        conn.out_buffer += header
        conn.out_buffer += msg_content
        conn.out_buffer_tracked_size += total_size
        self._outgoing_buffer_bytes = outgoing_buffer_bytes + total_size
        self._record_out_buffer_segment(conn, "message", total_size)
        return True

    def _append_file_control_data(self, conn, msg_content):
        """Append tiny file-control messages under the outgoing-buffer budget."""

        msg_size = len(msg_content)
        outgoing_buffer_bytes = getattr(self, "_outgoing_buffer_bytes", 0)

        if outgoing_buffer_bytes + msg_size > self.MAX_OUTGOING_BUFFER_BYTES:
            if not getattr(self, "_outgoing_buffer_limit_logged", False):
                log.add_conn(
                    "Closing connection %s; aggregate outgoing file-control buffer would exceed maximum size %s",
                    (getattr(conn, "addr", None), self.MAX_OUTGOING_BUFFER_BYTES)
                )
                self._outgoing_buffer_limit_logged = True

            self._close_connection(conn)
            return False

        conn.out_buffer += msg_content
        conn.out_buffer_tracked_size += msg_size
        self._outgoing_buffer_bytes = outgoing_buffer_bytes + msg_size
        self._record_out_buffer_segment(conn, "message", msg_size)
        return True

    def _append_file_upload_data(self, conn, file_data):
        """Append file-upload read-ahead while enforcing an aggregate budget."""

        data_len = len(file_data)
        file_upload_buffer_bytes = getattr(self, "_file_upload_buffer_bytes", 0)

        if file_upload_buffer_bytes + data_len > self.MAX_FILE_UPLOAD_BUFFER_BYTES:
            if not getattr(self, "_file_upload_buffer_limit_logged", False):
                log.add_conn(
                    "Closing upload connection %s; aggregate file-upload buffer would exceed maximum size %s",
                    (getattr(conn, "addr", None), self.MAX_FILE_UPLOAD_BUFFER_BYTES)
                )
                self._file_upload_buffer_limit_logged = True

            return False

        conn.out_buffer += file_data
        conn.file_upload_buffer_tracked_size += data_len
        self._file_upload_buffer_bytes = file_upload_buffer_bytes + data_len
        self._record_out_buffer_segment(conn, "file-upload", data_len)
        return True

    def _release_out_buffer_segments(self, conn, num_bytes):
        """Release tracked output budgets in the order bytes were sent."""

        if num_bytes <= 0:
            return

        segments = conn.out_buffer_segments

        if not segments:
            # Compatibility for tests or stale connections created before the
            # segment FIFO existed. Prefer non-file message accounting, since
            # file-upload bytes are normally appended through the segment-aware
            # helper.
            outgoing_bytes = min(num_bytes, conn.out_buffer_tracked_size)
            conn.out_buffer_tracked_size -= outgoing_bytes
            self._outgoing_buffer_bytes = max(
                0, getattr(self, "_outgoing_buffer_bytes", 0) - outgoing_bytes)

            upload_bytes = min(num_bytes - outgoing_bytes, conn.file_upload_buffer_tracked_size)
            conn.file_upload_buffer_tracked_size -= upload_bytes
            self._file_upload_buffer_bytes = max(
                0, getattr(self, "_file_upload_buffer_bytes", 0) - upload_bytes)

            if getattr(self, "_outgoing_buffer_bytes", 0) < (self.MAX_OUTGOING_BUFFER_BYTES // 2):
                self._outgoing_buffer_limit_logged = False

            if getattr(self, "_file_upload_buffer_bytes", 0) < (self.MAX_FILE_UPLOAD_BUFFER_BYTES // 2):
                self._file_upload_buffer_limit_logged = False

            return

        remaining_bytes = num_bytes

        while segments and remaining_bytes > 0:
            segment_type, segment_size = segments[0]
            released_bytes = min(segment_size, remaining_bytes)

            if segment_type == "message":
                conn.out_buffer_tracked_size = max(0, conn.out_buffer_tracked_size - released_bytes)
                self._outgoing_buffer_bytes = max(
                    0, getattr(self, "_outgoing_buffer_bytes", 0) - released_bytes)

            elif segment_type == "file-upload":
                conn.file_upload_buffer_tracked_size = max(
                    0, conn.file_upload_buffer_tracked_size - released_bytes)
                self._file_upload_buffer_bytes = max(
                    0, getattr(self, "_file_upload_buffer_bytes", 0) - released_bytes)

            remaining_bytes -= released_bytes
            segment_size -= released_bytes

            if segment_size:
                segments[0] = (segment_type, segment_size)
                break

            segments.popleft()

        if getattr(self, "_outgoing_buffer_bytes", 0) < (self.MAX_OUTGOING_BUFFER_BYTES // 2):
            self._outgoing_buffer_limit_logged = False

        if getattr(self, "_file_upload_buffer_bytes", 0) < (self.MAX_FILE_UPLOAD_BUFFER_BYTES // 2):
            self._file_upload_buffer_limit_logged = False

    def _clear_output_buffers(self, conn):
        """Clear all tracked output bytes for a closing connection."""

        if conn.out_buffer_tracked_size > 0:
            self._outgoing_buffer_bytes = max(
                0, getattr(self, "_outgoing_buffer_bytes", 0) - conn.out_buffer_tracked_size)
            conn.out_buffer_tracked_size = 0

        if conn.file_upload_buffer_tracked_size > 0:
            self._file_upload_buffer_bytes = max(
                0, getattr(self, "_file_upload_buffer_bytes", 0) - conn.file_upload_buffer_tracked_size)
            conn.file_upload_buffer_tracked_size = 0

        conn.out_buffer_segments.clear()

        if getattr(self, "_outgoing_buffer_bytes", 0) < (self.MAX_OUTGOING_BUFFER_BYTES // 2):
            self._outgoing_buffer_limit_logged = False

        if getattr(self, "_file_upload_buffer_bytes", 0) < (self.MAX_FILE_UPLOAD_BUFFER_BYTES // 2):
            self._file_upload_buffer_limit_logged = False

    # Backwards-compatible wrappers for older tests/local call sites.
    def _release_outgoing_data(self, conn, num_bytes):
        self._release_out_buffer_segments(conn, num_bytes)

    def _release_file_upload_data(self, conn, num_bytes):
        self._release_out_buffer_segments(conn, num_bytes)

    def _clear_outgoing_buffer(self, conn):
        self._clear_output_buffers(conn)

    def _clear_file_upload_buffer(self, conn):
        self._clear_output_buffers(conn)

    def _append_incoming_data(self, conn, data, data_len):
        """Append received non-file data while enforcing a global input-buffer budget."""

        incoming_buffer_bytes = getattr(self, "_incoming_buffer_bytes", 0)

        if incoming_buffer_bytes + data_len > self.MAX_INCOMING_BUFFER_BYTES:
            if not getattr(self, "_incoming_buffer_limit_logged", False):
                log.add_conn(
                    "Closing connection %s; aggregate incoming buffer would exceed maximum size %s",
                    (conn.addr, self.MAX_INCOMING_BUFFER_BYTES)
                )
                self._incoming_buffer_limit_logged = True

            self._close_connection(conn)
            return False

        conn.in_buffer += data
        self._incoming_buffer_bytes = incoming_buffer_bytes + data_len
        return True

    def _discard_incoming_data(self, conn, num_bytes):
        """Discard parsed bytes from a connection and release aggregate budget."""

        if num_bytes <= 0:
            return

        num_bytes = min(num_bytes, len(conn.in_buffer))

        if num_bytes <= 0:
            return

        del conn.in_buffer[:num_bytes]
        self._incoming_buffer_bytes = max(0, getattr(self, "_incoming_buffer_bytes", 0) - num_bytes)

        if self._incoming_buffer_bytes < (self.MAX_INCOMING_BUFFER_BYTES // 2):
            self._incoming_buffer_limit_logged = False

    def _clear_incoming_buffer(self, conn):
        """Clear a connection buffer and release its aggregate budget."""

        buffer_len = len(conn.in_buffer)
        conn.in_buffer.clear()
        self._incoming_buffer_bytes = max(0, getattr(self, "_incoming_buffer_bytes", 0) - buffer_len)

        if self._incoming_buffer_bytes < (self.MAX_INCOMING_BUFFER_BYTES // 2):
            self._incoming_buffer_limit_logged = False

    @classmethod
    def _unpack_network_message(cls, msg_class, msg_content, msg_size, conn_type, sock=None, addr=None, username=None):

        try:
            msg = msg_class()

            if sock is not None:
                msg.sock = sock

            if addr is not None:
                msg.addr = addr

            if username is not None:
                msg.username = username

            msg.parse_network_message(msg_content)
            return msg

        except Exception as error:
            log.add_debug("Unable to parse %s message type %s, size %s, contents %s. Error: %s",
                          (conn_type, msg_class, msg_size, cls._get_message_content_preview(msg_content), error))

        return None

    @staticmethod
    def _unpack_embedded_message(msg):
        """This message embeds a distributed message.

        We unpack the distributed message and process it.
        """

        msg_type = msg.distrib_code

        if msg_type not in DISTRIBUTED_MESSAGE_CLASSES:
            log.add_debug("Embedded distrib message type %s unknown", msg_type)
            return None

        distrib_class = DISTRIBUTED_MESSAGE_CLASSES[msg_type]
        msg_content = memoryview(msg.distrib_message)
        msg_size = len(msg_content) + NetworkThread.DISTRIBUTED_MESSAGE_CODE_SIZE
        max_msg_size = getattr(distrib_class, "MAX_INCOMING_MESSAGE_SIZE", None)

        if max_msg_size is not None and msg_size > max_msg_size:
            log.add_debug("Embedded distrib message type %s size %s exceeds maximum size %s",
                          (msg_type, msg_size, max_msg_size))
            return None

        return NetworkThread._unpack_network_message(
            distrib_class,
            msg_content,
            msg_size,
            conn_type="distrib"
        )


    def _handle_network_message_delivery_failure(self, msg_class, msg):
        """Emit a small rollback/retry signal when a heavy parsed response cannot
        be delivered to the main thread.

        Heavy peer responses are intentionally not put on the lifecycle retry
        shelf: a shared-file-list or folder-content response can be large enough
        to recreate the backlog pressure that caused emit_main_thread() to
        reject it. Instead, notify the owning module with only the response
        class, user and token/path metadata, so it can decide whether to retry
        the original request.
        """

        username = getattr(msg, "username", None)
        rollback_info = None

        if msg_class is SharedFileListResponse:
            rollback_info = ("shared-file-list-response",)

        elif msg_class is UserInfoResponse:
            rollback_info = ("user-info-response",)

        elif msg_class is FolderContentsResponse:
            rollback_info = (
                "folder-contents-response",
                getattr(msg, "token", None),
                getattr(msg, "dir", None)
            )

        if msg_class is FileSearchResponse:
            responder = getattr(msg, "username", None) or getattr(msg, "search_username", None)
            rollback_info = ("file-search-response", getattr(msg, "token", None), responder)

        if rollback_info is not None:
            self._emit_main_thread_lifecycle_event(
                "peer-response-delivery-failed", msg_class, username, rollback_info)
            return

        if msg_class is Recommendations:
            rollback_info = ("recommendations",)

        elif msg_class is GlobalRecommendations:
            rollback_info = ("global-recommendations",)

        elif msg_class is SimilarUsers:
            rollback_info = ("similar-users",)

        elif msg_class is UserInterests:
            rollback_info = ("user-interests", getattr(msg, "user", None))

        elif msg_class is ItemRecommendations:
            rollback_info = ("item-recommendations", getattr(msg, "thing", None))

        elif msg_class is ItemSimilarUsers:
            rollback_info = ("item-similar-users", getattr(msg, "thing", None))

        elif msg_class is RoomList:
            rollback_info = ("room-list",)

        else:
            return

        self._emit_main_thread_lifecycle_event(
            "server-response-delivery-failed", msg_class, rollback_info)

    def _emit_network_message_event(self, msg):

        if msg is None:
            return

        msg_class = msg.__class__
        log.add_msg_contents(msg)

        if msg_class in NETWORK_MESSAGE_EVENTS:
            event_name = NETWORK_MESSAGE_EVENTS[msg_class]

            if event_name in self.RETRYABLE_MAIN_THREAD_MESSAGE_EVENTS:
                self._emit_main_thread_lifecycle_event(event_name, msg)
            elif not events.emit_main_thread(event_name, msg):
                self._handle_network_message_delivery_failure(msg_class, msg)

    def _modify_connection_events(self, conn, io_events):

        if conn.io_events != io_events:
            self._selector.modify(conn.sock, io_events)
            conn.io_events = io_events

    @staticmethod
    def _estimate_pending_peer_message_size(msg, limit=None):
        """Estimate retained memory for a queued pre-connection peer message.

        Count caps alone are weak for heavyweight messages whose Python objects
        can already contain many strings, paths, and result rows before a peer
        socket exists. This is a conservative budget heuristic, not an exact
        object-size profiler, and stops walking once *limit* is exceeded.
        """

        total = 256
        seen = set()

        def add(value):
            nonlocal total

            if value is None:
                return

            if limit is not None and total > limit:
                return

            value_id = id(value)

            if value_id in seen:
                return

            seen.add(value_id)

            if isinstance(value, (bytes, bytearray, memoryview)):
                total += len(value)
                return

            if isinstance(value, str):
                total += len(value.encode("utf-8", "replace"))
                return

            if isinstance(value, dict):
                total += len(value) * 64

                for key, item in value.items():
                    add(key)
                    add(item)

                    if limit is not None and total > limit:
                        break

                return

            if isinstance(value, (list, tuple, set, frozenset)):
                total += len(value) * 32

                for item in value:
                    add(item)

                    if limit is not None and total > limit:
                        break

                return

            for attr in getattr(value, "__slots__", ()):  # slskmessages are slot-based
                if attr == "sock":
                    continue

                try:
                    add(getattr(value, attr))

                except AttributeError:
                    continue

                if limit is not None and total > limit:
                    break

        add(msg)
        return total

    def _clear_queued_peer_messages(self, init, revoke_unsent=False):
        """Clear queued pre-connection peer messages and release aggregate accounting."""

        if revoke_unsent:
            self._revoke_unsent_peer_request_grants(init)

        num_messages = len(init.outgoing_msgs)

        if num_messages:
            self._pending_peer_message_count = max(
                0, getattr(self, "_pending_peer_message_count", 0) - num_messages)

        queued_bytes = getattr(init, "outgoing_msg_bytes", 0)

        if queued_bytes:
            self._pending_peer_message_bytes = max(
                0, getattr(self, "_pending_peer_message_bytes", 0) - queued_bytes)
            init.outgoing_msg_bytes = 0

        init.outgoing_msgs.clear()

    def _transfer_queued_peer_messages(self, source_init, target_init):
        """Move accounted queued messages from one peer init object to another."""

        if target_init.outgoing_msgs:
            target_init.outgoing_msgs.extend(source_init.outgoing_msgs)
        else:
            target_init.outgoing_msgs = source_init.outgoing_msgs

        target_init.outgoing_msg_bytes += getattr(source_init, "outgoing_msg_bytes", 0)
        source_init.outgoing_msg_bytes = 0
        source_init.outgoing_msgs = []

    def _process_conn_messages(self, init):
        """A connection is established with the peer, time to queue up our peer
        messages for delivery."""

        username = init.target_user
        sock = init.sock
        msgs = init.outgoing_msgs

        for j in msgs:
            j.username = username
            j.sock = sock

        self._process_outgoing_messages(msgs)
        self._clear_queued_peer_messages(init)

    def _queue_peer_message(self, init, msg):
        """Queue an outgoing peer message without allowing unbounded pre-connection buildup."""

        if len(init.outgoing_msgs) >= self.MAX_PENDING_PEER_MESSAGES_PER_INIT:
            log.add_conn("Dropping outgoing %s message to user %s; per-init pending peer message limit reached",
                         (msg.__class__, init.target_user))
            return False

        if self._pending_peer_message_count >= self.MAX_PENDING_PEER_MESSAGES:
            if not self._pending_peer_message_limit_logged:
                log.add_conn("Dropping outgoing peer messages; aggregate pending peer message limit %s reached",
                             self.MAX_PENDING_PEER_MESSAGES)
                self._pending_peer_message_limit_logged = True

            return False

        msg_size = self._estimate_pending_peer_message_size(
            msg, limit=max(self.MAX_PENDING_PEER_MESSAGE_BYTES_PER_INIT, self.MAX_PENDING_PEER_MESSAGE_BYTES))

        if init.outgoing_msg_bytes + msg_size > self.MAX_PENDING_PEER_MESSAGE_BYTES_PER_INIT:
            log.add_conn("Dropping outgoing %s message to user %s; per-init pending peer message byte limit reached",
                         (msg.__class__, init.target_user))
            return False

        if getattr(self, "_pending_peer_message_bytes", 0) + msg_size > self.MAX_PENDING_PEER_MESSAGE_BYTES:
            if not self._pending_peer_message_limit_logged:
                log.add_conn("Dropping outgoing peer messages; aggregate pending peer message byte limit %s reached",
                             self.MAX_PENDING_PEER_MESSAGE_BYTES)
                self._pending_peer_message_limit_logged = True

            return False

        init.outgoing_msgs.append(msg)
        init.outgoing_msg_bytes += msg_size
        self._pending_peer_message_count += 1
        self._pending_peer_message_bytes = getattr(self, "_pending_peer_message_bytes", 0) + msg_size

        if (self._pending_peer_message_limit_logged
                and self._pending_peer_message_count < (self.MAX_PENDING_PEER_MESSAGES // 2)
                and self._pending_peer_message_bytes < (self.MAX_PENDING_PEER_MESSAGE_BYTES // 2)):
            self._pending_peer_message_limit_logged = False

        return True

    def _queue_pending_init_message(self, username, init):
        """Queue a peer init while waiting for GetPeerAddress, within gross memory bounds."""

        if username not in self._pending_init_msgs and len(self._pending_init_msgs) >= self.MAX_PENDING_PEER_INIT_USERS:
            log.add_conn("Dropping peer init of type %s for user %s; pending user limit reached",
                         (init.conn_type, username))
            self._emit_peer_connection_error(username, init.conn_type, init)
            self._clear_queued_peer_messages(init, revoke_unsent=True)
            return False

        pending_init_msgs = self._pending_init_msgs[username]

        if len(pending_init_msgs) >= self.MAX_PENDING_PEER_INITS_PER_USER:
            log.add_conn("Dropping peer init of type %s for user %s; per-user pending init limit reached",
                         (init.conn_type, username))
            self._emit_peer_connection_error(username, init.conn_type, init)
            self._clear_queued_peer_messages(init, revoke_unsent=True)
            return False

        pending_init_msgs.append(init)
        return True

    def _remove_pending_init_message(self, username, init):
        pending_init_msgs = self._pending_init_msgs.get(username)

        if not pending_init_msgs:
            return

        try:
            pending_init_msgs.remove(init)
        except ValueError:
            return

        if not pending_init_msgs:
            self._pending_init_msgs.pop(username, None)

    @staticmethod
    def _is_valid_peer_address(addr, allow_offline=False):
        """Return whether a server-provided peer address is safe to dial/cache.

        The Soulseek server is the only source of peer IP/port tuples for
        indirect connections and address lookups. A buggy server or MITM should
        not be able to turn Nicotine+ into a connector for loopback, multicast,
        unspecified or other non-dialable sink addresses. Keep private/NAT
        addresses allowed for compatibility with private/LAN deployments, but
        reject addresses that are never valid remote peer destinations.
        """

        try:
            ip_string, port = addr
            port = int(port)

        except (TypeError, ValueError):
            return False

        if allow_offline and ip_string == "0.0.0.0" and port == 0:
            return True

        if port <= 0 or port > 65535:
            return False

        try:
            ip_obj = parse_ip_address(ip_string)

        except ValueError:
            return False

        if ip_obj.version != 4:
            return False

        return not (
            ip_obj.is_unspecified
            or ip_obj.is_loopback
            or ip_obj.is_multicast
            or ip_obj.is_link_local
        )

    def _is_peer_init_address_consistent(self, username, conn_addr):
        """Return whether an incoming direct PeerInit matches trusted cached address state.

        PeerInit carries only a claimed username. If we already have a valid
        server-provided address for that username, do not let a connection from
        another source IP replace the user's message/file/distributed channel.
        The TCP source port is intentionally ignored: incoming peer connections
        originate from ephemeral ports and do not necessarily match the user's
        advertised listening port. Unknown users remain accepted for normal
        inbound browse/download traffic, where no trusted address exists yet.
        """

        cached_addr = self._user_addresses.get(username)

        if cached_addr is None:
            return True

        if not self._is_valid_peer_address(cached_addr):
            # Offline/invalid cache entries are not authoritative enough to
            # reject an otherwise well-formed incoming peer init.
            return True

        try:
            conn_ip = parse_ip_address(conn_addr[0])
            cached_ip = parse_ip_address(cached_addr[0])

        except (TypeError, ValueError, IndexError):
            return False

        if conn_ip.version != 4:
            return False

        return conn_ip == cached_ip

    def _drop_pending_peer_connection(self, init, response_token=None):
        """Drop a peer connection attempt that cannot be queued due to hard pending caps."""

        username = init.target_user
        conn_type = init.conn_type

        log.add_conn("Dropping pending peer connection of type %s to user %s; pending connection limit reached",
                     (conn_type, username))

        if response_token is not None:
            self._send_cant_connect_to_peer(response_token, username)
        else:
            self._emit_peer_connection_error(username, conn_type, init)

        self._clear_queued_peer_messages(init, revoke_unsent=True)
        self._remove_init_message(init)

    def _send_message_to_peer(self, username, msg):

        msg.username = username
        conn_type = msg.msg_type

        if conn_type not in self.ALLOWED_PEER_CONN_TYPES:
            log.add_conn("Unknown connection type %s", conn_type)
            return

        init = None
        init_key = self._get_init_key(username, conn_type)

        # Check if there's already a connection for the specified username
        if init_key in self._username_init_msgs:
            init = self._username_init_msgs[init_key]

        if init is None and conn_type != ConnectionType.FILE and username in self._pending_init_msgs:
            # Check if we have a pending PeerInit message (currently requesting user IP address)
            for pending_init in self._pending_init_msgs[username]:
                if pending_init.conn_type == conn_type:
                    init = pending_init
                    break

        if init is not None:
            log.add_conn("Sending message of type %s to user %s on existing connection",
                         (msg.__class__, username))

            if not self._queue_peer_message(init, msg):
                self._handle_unsent_peer_message(msg)
                return

            if init.sock is not None and self._conns[init.sock].is_established:
                # We have initiated a connection previously, and it's ready
                self._process_conn_messages(init)

        else:
            log.add_conn("Sending message of type %s to user %s on new connection",
                         (msg.__class__, username))

            # This is a new peer, initiate a connection
            self._initiate_connection_to_peer(username, conn_type, msg)

    def _initiate_connection_to_peer(self, username, conn_type, msg=None, in_address=None):
        """Prepare to initiate a connection with a peer."""

        init = PeerInit(init_user=self._server_username, target_user=username, conn_type=conn_type)
        user_address = self._user_addresses.get(username)

        if in_address is not None:
            user_address = in_address

        elif user_address is not None:
            if not self._is_valid_peer_address(user_address):
                log.add_conn("Ignoring invalid cached peer address for user %s: %s", (username, user_address))
                self._user_addresses.pop(username, None)
                user_address = None

        if msg is not None and not self._queue_peer_message(init, msg):
            self._handle_unsent_peer_message(msg)
            return

        if user_address is None:
            request_address = (username not in self._pending_init_msgs)

            if not self._queue_pending_init_message(username, init):
                return

            if request_address and self._send_message_to_server(GetPeerAddress(username)) is False:
                log.add_conn("Cannot request address for user %s; server message was not queued", username)
                self._remove_pending_init_message(username, init)
                self._emit_peer_connection_error(username, conn_type, init)
                self._clear_queued_peer_messages(init, revoke_unsent=True)
                return

            log.add_conn("Requesting address for user %s", username)
        else:
            self._connect_to_peer(username, user_address, init)

    def _connect_to_peer(self, username, addr, init, response_token=None):
        """Initiate a connection with a peer."""

        conn_type = init.conn_type

        if conn_type not in self.ALLOWED_PEER_CONN_TYPES:
            log.add_conn("Unknown connection type %s", conn_type)
            self._clear_queued_peer_messages(init, revoke_unsent=True)
            return

        if not self._add_init_message(init):
            log.add_conn("Direct connection of type %s to user %s (%s) requested, "
                         "but existing connection already exists", (conn_type, username, addr))
            self._clear_queued_peer_messages(init, revoke_unsent=True)
            return

        log.add_conn("Attempting direct connection of type %s to user %s, address %s",
                     (conn_type, username, addr))
        self._init_peer_connection(addr, init, response_token=response_token)

    def _connect_error(self, error, conn):

        if conn.__class__ is ServerConnection:
            server_address, port = conn.addr

            log.add(
                _("Cannot connect to server %(host)s:%(port)s: %(error)s"), {
                    "host": server_address,
                    "port": port,
                    "error": error
                }
            )
            self._set_server_timer()
            return

        conn_type = conn.init.conn_type
        username = conn.init.target_user
        response_token = conn.response_token

        if response_token is not None:
            log.add_conn("Cannot respond to indirect connection request of type %s from user %s, "
                         "token %s: %s", (conn_type, username, response_token, error))
            self._send_cant_connect_to_peer(response_token, username)
            return

        log.add_conn("Direct connection of type %s to user %s failed: %s",
                     (conn_type, username, error))

    def _connect_to_peer_indirect(self, init):
        """Send a message to the server to ask the peer to connect to us
        (indirect connection).

        Keep the response-token ledger behind the server-output acceptance
        boundary. If the server connection is gone or the outgoing server buffer
        rejects the request, storing a token would leave the peer init waiting
        for a PierceFireWall response that can never arrive.
        """

        username = init.target_user
        conn_type = init.conn_type
        if len(self._token_init_msgs) >= self.MAX_PENDING_INDIRECT_REQUESTS:
            log.add_conn("Skipping indirect connection request to user %s; pending indirect request limit reached",
                         username)
            return None

        token = self._token = increment_token(self._token)
        request_time = time.monotonic()

        if self._send_message_to_server(ConnectToPeer(token, username, conn_type)) is False:
            log.add_conn("Skipping indirect connection request to user %s with token %s; "
                         "server message was not queued", (username, token))
            return None

        self._token_init_msgs[token] = (init, request_time)

        log.add_conn("Requesting indirect connection to user %s with token %s", (username, token))
        return token

    def _allow_incoming_indirect_connection(self, username, conn_type, token, addr):
        """Bound server-originated requests that make us open outbound sockets."""

        now = time.monotonic()
        cutoff_time = now - self.INCOMING_INDIRECT_CONNECT_RATE_PERIOD
        request_times = getattr(self, "_incoming_indirect_conn_times", None)

        if request_times is None:
            request_times = self._incoming_indirect_conn_times = deque()

        while request_times and request_times[0] <= cutoff_time:
            request_times.popleft()

        if len(request_times) >= self.MAX_INCOMING_INDIRECT_CONNECTS_PER_MINUTE:
            if not getattr(self, "_incoming_indirect_conn_limit_logged", False):
                log.add_conn(
                    "Ignoring indirect connection request of type %s from user %s, token %s, address %s; "
                    "incoming indirect connection rate limit reached",
                    (conn_type, username, token, addr)
                )
                self._incoming_indirect_conn_limit_logged = True

            return False

        request_times.append(now)
        self._incoming_indirect_conn_limit_logged = False
        return True

    def _establish_outgoing_peer_connection(self, conn):

        conn.is_established = True
        init = conn.init
        sock = init.sock = conn.sock
        response_token = conn.response_token
        username = init.target_user
        conn_type = init.conn_type

        log.add_conn("Established outgoing connection of type %s with user %s. List of "
                     "outgoing messages: %s", (conn_type, username, init.outgoing_msgs))

        if response_token is not None:
            log.add_conn("Responding to indirect connection request of type %s from "
                         "user %s, token %s", (conn_type, username, response_token))

            if self._process_peer_init_output(PierceFireWall(sock, response_token)) is False:
                log.add_conn("Closing indirect connection of type %s to user %s; "
                             "PierceFireWall could not be queued", (conn_type, username))
                return

            self._accept_child_peer_connection(conn)

        else:
            log.add_conn("Sending peer init message of type %s to user %s", (conn_type, username))

            if self._process_peer_init_output(init) is False:
                log.add_conn("Closing outgoing connection of type %s to user %s; "
                             "PeerInit could not be queued", (conn_type, username))
                return

        self._process_conn_messages(init)

    def _replace_existing_connection(self, init):

        username = init.target_user
        conn_type = init.conn_type

        if username == self._server_username:
            return

        prev_init = self._username_init_msgs.pop(self._get_init_key(username, conn_type), None)

        if prev_init is None or prev_init.sock is None:
            return

        log.add_conn("Discarding existing connection of type %s to user %s", (init.conn_type, username))

        self._transfer_queued_peer_messages(prev_init, init)

        self._close_connection(self._conns[prev_init.sock])

    @staticmethod
    def _close_socket(sock):

        try:
            log.add_conn("Shutting down socket %s", sock)
            sock.shutdown(socket.SHUT_RDWR)

        except OSError as error:
            # Can't call shutdown if connection wasn't established, ignore error
            if error.errno != errno.ENOTCONN:
                log.add_conn("Failed to shut down socket %s: %s", (sock, error))

        log.add_conn("Closing socket %s", sock)
        try:
            sock.close()

        except OSError as error:
            log.add_conn("Failed to close socket %s: %s", (sock, error))

    def _close_connection(self, conn):

        if conn is None:
            return

        sock = conn.sock

        if conn.__class__ is PeerConnection:
            self._unregister_large_message_buffer(conn)
            self._release_preinit_peer_address(conn)

        if sock is None:
            self._clear_incoming_buffer(conn)
            self._clear_output_buffers(conn)
            conn.out_buffer.clear()
            return

        registered_conn = self._conns.get(sock)

        if registered_conn is not None and registered_conn is not conn:
            conn.sock = None
            self._clear_incoming_buffer(conn)
            self._clear_output_buffers(conn)
            conn.out_buffer.clear()
            return

        is_registered_connection = (registered_conn is conn)

        if is_registered_connection:
            del self._conns[sock]

        if conn is self._server_conn:
            # Disconnecting from server, clean up connections and queue
            self._server_disconnect()

        try:
            self._selector.unregister(sock)

        except (KeyError, ValueError, OSError):
            # Socket was never registered, or was already unregistered by a
            # previous close path. Closing a connection should be idempotent,
            # because some parser/budget helpers close immediately and their
            # callers may still follow the usual "read returned False" cleanup.
            pass

        self._close_socket(sock)

        if is_registered_connection:
            self._num_sockets = max(0, self._num_sockets - 1)

        conn.sock = None
        self._clear_incoming_buffer(conn)
        self._clear_output_buffers(conn)
        conn.out_buffer.clear()

        if conn.__class__ is not PeerConnection:
            return

        init = conn.init

        if init is None:
            # No peer init message present, nothing to do
            return

        conn_type = init.conn_type
        username = init.target_user
        addr = conn.addr
        is_connection_replaced = (init.sock is not sock)

        log.add_conn("Removed connection of type %s to user %s, address %s", (conn_type, username, addr))

        if not is_connection_replaced:
            init.sock = None

        if conn_type == ConnectionType.DISTRIBUTED:
            child_conn = self._child_peers.get(username)

            if child_conn is conn:
                self._remove_child_peer_connection(username)

            elif conn is self._parent_conn:
                self._send_have_no_parent()

        elif conn in self._file_init_msgs:
            file_init = self._file_init_msgs.pop(conn)

            if self._should_process_queue:
                timed_out = (time.monotonic() - conn.last_active) > self.CONNECTION_MAX_IDLE
                close_kwargs = {
                    "username": username,
                    "token": file_init.token,
                    "sock": sock,
                    "timed_out": timed_out
                }

                if conn in self._file_download_msgs:
                    # Final progress events are intentionally coalesced/noisy UI
                    # work. Preserve the authoritative transfer offset on the
                    # lifecycle close event as well, so a dropped final progress
                    # update cannot make the main thread abort a completed file.
                    close_kwargs["bytes_left"] = self._file_download_msgs[conn].leftbytes

                elif conn in self._file_upload_msgs:
                    file_upload = self._file_upload_msgs[conn]

                    if file_upload.offset is not None:
                        close_kwargs["current_byte_offset"] = (
                            file_upload.offset + file_upload.sentbytes)

                self._emit_main_thread_lifecycle_event("file-connection-closed", **close_kwargs)

        if conn in self._file_download_msgs:
            del self._file_download_msgs[conn]
            self._total_downloads -= 1

            if not self._total_downloads:
                self._total_download_bandwidth = 0

            self._calc_download_limit()

        elif conn in self._file_upload_msgs:
            del self._file_upload_msgs[conn]
            self._total_uploads -= 1

            if not self._total_uploads:
                self._total_upload_bandwidth = 0

            self._calc_upload_limit_function()

        init_key = self._get_init_key(username, conn_type)

        if init_key not in self._username_init_msgs:
            return

        log.add_conn("Removing peer init message of type %s for user %s, address %s",
                     (conn_type, username, addr))

        if is_connection_replaced or init is not self._username_init_msgs[init_key]:
            # Don't remove init message if connection has been superseded
            log.add_conn("Cannot remove peer init message, since the connection has been superseded")
            return

        if conn.request_token in self._token_init_msgs:
            # Indirect connection attempt in progress, remove init message later on timeout
            log.add_conn("Cannot remove peer init message, since an indirect connection attempt "
                         "is still in progress")
            return

        event_name = "peer-connection-closed" if conn.is_established else "peer-connection-error"
        self._emit_peer_connection_result(event_name, username, conn_type, init)
        self._clear_queued_peer_messages(init, revoke_unsent=True)

        del self._username_init_msgs[init_key]

    def _is_connection_inactive(self, conn, current_time, num_sockets):

        if conn is self._server_conn:
            return False

        if num_sockets >= self.MAX_SOCKETS and not self._is_connection_still_active(conn):
            # Connection limit reached, close connection if inactive
            return True

        time_diff = (current_time - conn.last_active)

        if not conn.has_post_init_activity and time_diff > self.CONNECTION_MAX_IDLE_GHOST:
            # "Ghost" connections can appear when an indirect connection is established,
            # search results arrive, we close the connection, and the direct connection attempt
            # succeeds afterwrds. Since the peer already sent a search result message, this connection
            # idles without any messages ever being sent beyond PeerInit. Close it sooner than regular
            # idling connections to prevent connections from piling up.
            return True

        if time_diff > self.CONNECTION_MAX_IDLE:
            # No recent activity, peer connection is stale
            return True

        return False

    def _process_pending_peer_connections(self, current_time=None):

        if not self._pending_peer_conns:
            return

        if current_time is None:
            current_time = time.monotonic()

        pending_keys = tuple(islice(
            self._pending_peer_conns, self.MAX_PENDING_PEER_CONNECTION_RETRIES_PER_TICK
        ))

        for pending_key in pending_keys:
            pending_conn = self._pending_peer_conns.get(pending_key)

            if pending_conn is None:
                continue

            queued_time = getattr(pending_conn, "queued_time", current_time)

            if (current_time - queued_time) >= self.MAX_PENDING_PEER_CONNECTION_AGE:
                self._pending_peer_conns.pop(pending_key, None)
                self._drop_pending_peer_connection(
                    pending_conn.init, response_token=pending_conn.response_token
                )
                continue

            self._init_peer_connection(
                pending_conn.addr, pending_conn.init, response_token=pending_conn.response_token
            )

    def _check_connections(self, current_time):

        num_sockets = self._num_sockets
        inactive_conns = set()
        stale_conns = set()

        for conn in self._conns.values():
            if not conn.is_established:
                if (current_time - conn.last_active) > self.IN_PROGRESS_STALE_AFTER:
                    stale_conns.add(conn)

            elif self._is_connection_inactive(conn, current_time, num_sockets):
                inactive_conns.add(conn)

            elif conn in self._file_download_msgs:
                file_download = self._file_download_msgs[conn]

                events.emit_main_thread(
                    "file-download-progress",
                    username=conn.init.target_user, token=file_download.token,
                    bytes_left=file_download.leftbytes, speed=file_download.speed
                )
                file_download.speed = 0

            elif conn in self._file_upload_msgs:
                file_upload = self._file_upload_msgs[conn]

                events.emit_main_thread(
                    "file-upload-progress",
                    username=conn.init.target_user, token=file_upload.token,
                    offset=file_upload.offset, bytes_sent=file_upload.sentbytes,
                    speed=file_upload.speed
                )
                file_upload.speed = 0

        if inactive_conns:
            for conn in inactive_conns:
                self._close_connection(conn)

            inactive_conns.clear()

        if stale_conns:
            for conn in stale_conns:
                self._connect_error(self.ERROR_TIMED_OUT, conn)
                self._close_connection(conn)

            stale_conns.clear()

        self._process_pending_peer_connections()

    # Server Connection #

    def _set_server_timer(self, use_fixed_timeout=False):

        if use_fixed_timeout:
            self._server_timeout_value = 5

        elif self._server_timeout_value == -1:
            # Add jitter to spread out connection attempts from Nicotine+ clients
            # in case server goes down
            self._server_timeout_value = random.randint(5, 15)

        elif 0 < self._server_timeout_value < 300:
            # Exponential backoff, max 5 minute wait
            self._server_timeout_value *= 2

        self._server_timeout_time = time.monotonic() + self._server_timeout_value
        log.add(_("Reconnecting to server in %s seconds"), self._server_timeout_value)

    @staticmethod
    def _set_server_socket_keepalive(sock, idle=10, interval=2):
        """Ensure we are disconnected from the server in case of connectivity
        issues, by sending TCP keepalive pings.

        Assuming default values are used, once we reach 10 seconds of
        idle time, we start sending keepalive pings once every 2
        seconds. If 10 failed pings have been sent in a row (20
        seconds), the connection is presumed dead.
        """

        count = 10
        timeout_seconds = (idle + (interval * count))

        if hasattr(socket, "SO_KEEPALIVE"):
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)  # pylint: disable=no-member

        if hasattr(socket, "TCP_KEEPINTVL"):
            sock.setsockopt(socket.IPPROTO_TCP,
                            socket.TCP_KEEPINTVL, interval)  # pylint: disable=no-member

        if hasattr(socket, "TCP_KEEPCNT"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, count)  # pylint: disable=no-member

        if hasattr(socket, "TCP_KEEPIDLE"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, idle)  # pylint: disable=no-member

        elif hasattr(socket, "TCP_KEEPALIVE"):
            # macOS fallback

            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPALIVE, idle)  # pylint: disable=no-member

        elif hasattr(socket, "SIO_KEEPALIVE_VALS"):
            # Windows fallback
            # Probe count is set to 10 on a system level, and can't be modified.
            # https://docs.microsoft.com/en-us/windows/win32/winsock/so-keepalive

            sock.ioctl(
                socket.SIO_KEEPALIVE_VALS,  # pylint: disable=no-member
                (
                    1,
                    idle * 1000,
                    interval * 1000
                )
            )

        if hasattr(socket, "TCP_USER_TIMEOUT"):
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_USER_TIMEOUT, timeout_seconds * 1000)

    def _server_connect(self, msg):
        """We're connecting to the server."""

        if self._server_conn is not None:
            return

        self._interface_name = msg.interface_name
        self._interface_address = (
            msg.interface_address or NetworkInterfaces.get_interface_address(self._interface_name)
        )
        self._listen_port = msg.listen_port

        if not self._create_listen_socket():
            self._should_process_queue = False
            events.emit_main_thread("set-connection-stats")  # Reset connection stats
            return

        self._portmapper = msg.portmapper

        self._manual_server_disconnect = False
        self._manual_server_reconnect = False
        self._server_timeout_time = None

        ip_address, port = msg.addr
        log.add(_("Connecting to %(host)s:%(port)s"), {"host": ip_address, "port": port})

        self._init_server_conn(msg)

    def _init_server_conn(self, msg):

        io_events = selectors.EVENT_READ | selectors.EVENT_WRITE
        sock = None
        conn = ServerConnection(
            sock=None, addr=msg.addr, io_events=io_events, login=msg.login
        )

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            conn.sock = sock
            sock.setblocking(False)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

            # Detect if our connection to the server is still alive
            self._set_server_socket_keepalive(sock)

            self._bind_socket_interface(sock)
            sock.connect_ex(msg.addr)
            self._selector.register(sock, io_events)

        except (OSError, ValueError, KeyError) as error:
            self._connect_error(error, conn)

            if sock is not None:
                self._close_socket(sock)

            conn.sock = None
            self._server_disconnect()
            return

        self._server_conn = self._conns[sock] = conn
        self._num_sockets += 1

    def _establish_outgoing_server_connection(self, conn):

        conn.is_established = True
        server_hostname, server_port = conn.addr

        log.add(
            _("Connected to server %(host)s:%(port)s, logging in…"), {
                "host": server_hostname,
                "port": server_port
            }
        )

        login, password = conn.login
        self._user_addresses[login] = (self._local_ip_address, self._listen_port)
        conn.login = True

        self._server_address = conn.addr
        self._server_username = self._branch_root = login
        self._server_timeout_value = -1

        if self._send_message_to_server(
            Login(
                login, password,
                # Soulseek client version
                # NS and SoulseekQt use 157
                # We use a custom version number for Nicotine+
                160,

                # Soulseek client minor version
                # 17 stands for 157 ns 13c, 19 for 157 ns 13e
                # SoulseekQt seems to go higher than this
                # We use a custom minor version for Nicotine+
                2
            )
        ) is False:
            log.add_conn("Closing server connection; Login could not be queued")
            self._manual_server_disconnect = True
            self._close_connection(conn)
            return

        self._send_wait_port_report(self._listen_port)

    def _get_server_response_grant_state(self, msg_class, msg_content, should_consume=False):
        """Return grant state for heavyweight server responses.

        Deprecated interest/recommendation responses can still carry sizeable
        server-controlled lists and then fan out into UI/watch work. Consume
        the matching one-shot grant before full parsing, so repeated responses
        in the same server read cannot reuse a single pending request grant.
        """

        if msg_class is Recommendations:
            return RECOMMENDATIONS_ALLOWED.consume() if should_consume else RECOMMENDATIONS_ALLOWED.is_allowed()

        if msg_class is GlobalRecommendations:
            return GLOBAL_RECOMMENDATIONS_ALLOWED.consume() if should_consume else \
                GLOBAL_RECOMMENDATIONS_ALLOWED.is_allowed()

        if msg_class is SimilarUsers:
            return SIMILAR_USERS_ALLOWED.consume() if should_consume else SIMILAR_USERS_ALLOWED.is_allowed()

        if msg_class is GlobalRoomMessage:
            return GLOBAL_ROOM_FEED_ALLOWED.is_allowed()

        if msg_class is UserInterests:
            try:
                _pos, username = UserInterests.unpack_username(
                    msg_content, field_name="interest username")
            except ValueError:
                # Parsing will log a bounded error via _unpack_network_message.
                return True

            return USER_INTERESTS_USERS_ALLOWED.consume(username) if should_consume else \
                USER_INTERESTS_USERS_ALLOWED.is_allowed(username)

        if msg_class is ItemRecommendations:
            try:
                _pos, item = ItemRecommendations.unpack_interest(
                    msg_content, field_name="item recommendation")
            except ValueError:
                return True

            return ITEM_RECOMMENDATIONS_ALLOWED.consume(item) if should_consume else \
                ITEM_RECOMMENDATIONS_ALLOWED.is_allowed(item)

        if msg_class is ItemSimilarUsers:
            try:
                _pos, item = ItemSimilarUsers.unpack_interest(
                    msg_content, field_name="item similar user")
            except ValueError:
                return True

            return ITEM_SIMILAR_USERS_ALLOWED.consume(item) if should_consume else \
                ITEM_SIMILAR_USERS_ALLOWED.is_allowed(item)

        return True

    def _should_parse_server_message(self, msg_class):
        """Return whether a known server message has any downstream effect.

        Some legacy/obsolete server messages remain in the class table for
        protocol documentation and outbound compatibility, but they are neither
        emitted to the main thread nor handled internally. Avoid fully parsing
        and materializing such payloads; the server framing and size checks have
        already been applied by _process_server_input().
        """

        return (msg_class in NETWORK_MESSAGE_EVENTS
                or msg_class in self.INTERNALLY_HANDLED_SERVER_MESSAGES)

    @staticmethod
    def _should_parse_peer_message(msg_class):
        """Return whether a known peer message has any downstream event.

        Legacy peer message classes without NETWORK_MESSAGE_EVENTS entries have
        no consumer after parsing. Skipping them avoids avoidable path/string
        materialization from obsolete peers while still discarding the framed
        message cleanly.
        """

        return msg_class in NETWORK_MESSAGE_EVENTS

    def _process_server_message(self, msg_type, msg_size, in_buffer, start_offset, end_offset):

        msg_class = SERVER_MESSAGE_CLASSES[msg_type]
        msg_content = memoryview(in_buffer)[start_offset:end_offset]

        if not self._should_parse_server_message(msg_class):
            log.add_debug("Ignoring unhandled server message type %s (%s) without parsing",
                          (msg_type, msg_class.__name__))
            return True

        if not self._get_server_response_grant_state(msg_class, msg_content, should_consume=True):
            log.add_conn("Ignoring unsolicited %s server response", msg_class.__name__)
            return True

        msg = self._unpack_network_message(
            msg_class,
            msg_content,
            msg_size,
            conn_type="server"
        )

        if msg is None:
            # Ignore unknown/malformed message and keep connection open. Any
            # matching one-shot request grant was already consumed above.
            return True

        if msg_class is EmbeddedMessage:
            embedded_msg = self._unpack_embedded_message(msg)

            if embedded_msg is None:
                return True

            self._distribute_embedded_message(msg, embedded_msg)
            msg = embedded_msg

        elif msg_class is Login:
            if msg.success:
                # Ensure listening port is open
                msg.local_address = self._user_addresses[self._server_username]
                local_ip_address, port = msg.local_address
                self._portmapper.set_port(port, local_ip_address)
                self._portmapper.add_port_mapping(blocking=False)

                msg.username = self._server_username
                msg.server_address = self._server_address

                # Ask for a list of parents to connect to (distributed network)
                self._send_have_no_parent()
            else:
                # Emit event and close connection
                self._emit_network_message_event(msg)
                return False

        elif msg_class is ConnectToPeer:
            username = msg.user
            addr = (msg.ip_address, msg.port)
            conn_type = msg.conn_type
            token = msg.token

            log.add_conn("Received indirect connection request of type %s from user %s, "
                         "token %s, address %s", (conn_type, username, token, addr))

            if not self._is_valid_peer_address(addr):
                log.add_conn("Ignoring indirect connection request of type %s from user %s, "
                             "token %s with invalid address %s", (conn_type, username, token, addr))
                self._send_cant_connect_to_peer(token, username)
                return True

            if not self._allow_incoming_indirect_connection(username, conn_type, token, addr):
                self._send_cant_connect_to_peer(token, username)
                return True

            init = PeerInit(init_user=username, target_user=username, conn_type=conn_type)
            self._connect_to_peer(username, addr, init, response_token=token)

        elif msg_class is CantConnectToPeer:
            token = msg.token

            if token in self._token_init_msgs:
                init, _request_time = self._token_init_msgs.pop(token)
                self._indirect_request_error(token, init)

        elif msg_class is GetUserStatus:
            if msg.status == UserStatus.OFFLINE and msg.user in self._user_addresses:
                # User went offline, reset stored IP address
                self._user_addresses[msg.user] = None

        elif msg_class is GetPeerAddress:
            username = msg.user
            pending_init_msgs = self._pending_init_msgs.pop(msg.user, [])
            address_requested = (username in self._requested_peer_addresses)
            self._requested_peer_addresses.discard(username)

            if not address_requested and not pending_init_msgs:
                log.add_conn("Ignoring unsolicited peer address response for user %s", username)
                return True

            addr = (msg.ip_address, msg.port)
            user_offline = (msg.ip_address == "0.0.0.0" and msg.port == 0)

            invalid_peer_address = (not user_offline and not self._is_valid_peer_address(addr))

            if invalid_peer_address:
                log.add_conn("Ignoring invalid peer address response for user %s: %s", (username, addr))

                for init in pending_init_msgs:
                    self._emit_peer_connection_error(username, init.conn_type, init)
                    self._clear_queued_peer_messages(init, revoke_unsent=True)
                    self._remove_init_message(init)

                # Still emit the peer-address event. Users._get_peer_address()
                # owns the user-facing request ledger and will pop/poison the
                # invalid response before later listeners can mutate filters.

            else:
                if not msg.port:
                    log.add_conn("Server reported port 0 for user %s", username)

                for init in pending_init_msgs:
                    # We now have the IP address for a user we previously didn't know,
                    # attempt a connection with the peer/user
                    if user_offline:
                        self._emit_peer_connection_error(username, init.conn_type, init, is_offline=True)
                        self._clear_queued_peer_messages(init, revoke_unsent=True)
                    else:
                        self._connect_to_peer(username, addr, init)

                # We already store a local IP address for our username
                if username != self._server_username and username in self._user_addresses:
                    if user_offline or not msg.port:
                        addr = None

                    self._user_addresses[username] = addr

        elif msg_class in (WatchUser, GetUserStats):
            if msg.user == self._server_username:
                if msg.avgspeed is not None:
                    self._upload_speed = msg.avgspeed
                    log.add_conn("Server reported our upload speed as %s", human_speed(msg.avgspeed))
                    self._update_maximum_distributed_children()

            elif msg_class is WatchUser and not msg.userexists:
                self._user_addresses.pop(msg.user, None)

        elif msg_class is Relogged:
            self._manual_server_disconnect = True
            self._server_relogged = True

        elif msg_class is PossibleParents:
            # Server sent a list of 10 potential parents, whose purpose is to forward us search requests.
            # We attempt to connect to them all at once, since connection errors are fairly common.

            invalid_parent_count = 0
            self._potential_parents = {}

            for username, addr in msg.list.items():
                if self._is_valid_peer_address(addr):
                    self._potential_parents[username] = addr
                    continue

                invalid_parent_count += 1

            log.add_conn("Server sent us a list of %s possible parents", len(msg.list))

            if invalid_parent_count:
                log.add_conn("Ignoring %s possible parent address(es) with invalid peer endpoints", invalid_parent_count)

            if self._parent_conn is None and self._potential_parents:
                attempted_connections = 0

                for username, addr in self._potential_parents.items():
                    if attempted_connections >= self.MAX_POSSIBLE_PARENT_CONNECTION_ATTEMPTS:
                        log.add_conn("Deferring remaining possible parent connections after %s attempts",
                                     self.MAX_POSSIBLE_PARENT_CONNECTION_ATTEMPTS)
                        break

                    log.add_conn("Attempting parent connection to user %s", username)
                    self._initiate_connection_to_peer(username, ConnectionType.DISTRIBUTED, in_address=addr)
                    attempted_connections += 1

        elif msg_class is ParentMinSpeed:
            self._distrib_parent_min_speed = msg.speed
            log.add_conn("Received minimum distributed parent speed %s from the server", msg.speed)
            self._update_maximum_distributed_children()

        elif msg_class is ParentSpeedRatio:
            self._distrib_parent_speed_ratio = msg.ratio
            log.add_conn("Received distributed parent speed ratio %s from the server", msg.ratio)
            self._update_maximum_distributed_children()

        elif msg_class is ResetDistributed:
            log.add_conn("Received a reset request for distributed network")

            if self._parent_conn is not None:
                self._close_connection(self._parent_conn)

            for child_conn in self._child_peers.copy().values():
                self._close_connection(child_conn)

            self._send_have_no_parent()

        self._emit_network_message_event(msg)
        return True

    def _process_server_input(self, conn):
        """Reads messages from the input buffer of a server connection."""

        in_buffer = conn.in_buffer
        buffer_len = len(in_buffer)
        msg_content_offset = 8
        idx = 0

        # Server messages are 8 bytes or greater in length
        processed_messages = 0

        while buffer_len >= msg_content_offset:
            if processed_messages >= self.MAX_INCOMING_MESSAGES_PER_CONNECTION_CYCLE:
                break

            msg_size, msg_type = DOUBLE_UINT32_UNPACK(in_buffer, idx)

            if msg_size > self.MAX_INCOMING_MESSAGE_SIZE:
                log.add_conn("Received message larger than maximum size %s from server. "
                             "Closing connection.", self.MAX_INCOMING_MESSAGE_SIZE)
                self._manual_server_disconnect = True
                self._close_connection(conn)
                return

            if msg_size < self.SERVER_PEER_MESSAGE_CODE_SIZE:
                log.add_conn("Received message smaller than minimum size %s from server. "
                             "Closing connection.", self.SERVER_PEER_MESSAGE_CODE_SIZE)
                self._manual_server_disconnect = True
                self._close_connection(conn)
                return

            msg_size_total = msg_size + 4

            if msg_type in SERVER_MESSAGE_CLASSES:
                msg_class = SERVER_MESSAGE_CLASSES[msg_type]
                max_msg_size = getattr(msg_class, "MAX_INCOMING_MESSAGE_SIZE", None)

                if max_msg_size is not None and msg_size > max_msg_size:
                    log.add_conn("Received %s message larger than maximum size %s from server. "
                                 "Closing connection.", (msg_class.__name__, max_msg_size))
                    self._manual_server_disconnect = True
                    self._close_connection(conn)
                    return

            elif msg_size > self.MAX_UNKNOWN_SERVER_MESSAGE_SIZE:
                log.add_conn("Received unknown message type %s larger than maximum size %s from server. "
                             "Closing connection.", (msg_type, self.MAX_UNKNOWN_SERVER_MESSAGE_SIZE))
                self._manual_server_disconnect = True
                self._close_connection(conn)
                return

            if msg_size_total > buffer_len:
                # Buffer is being filled
                break

            # Unpack server messages
            if msg_type in SERVER_MESSAGE_CLASSES:

                if not self._process_server_message(
                    msg_type, msg_size, in_buffer, idx + msg_content_offset, idx + msg_size_total
                ):
                    self._manual_server_disconnect = True
                    self._close_connection(conn)
                    return
            else:
                msg_content = in_buffer[idx + msg_content_offset:idx + min(50, msg_size_total)]
                log.add_debug("Server message type %s size %s contents %s unknown",
                              (msg_type, msg_size, msg_content))

            idx += msg_size_total
            buffer_len -= msg_size_total
            processed_messages += 1

        if idx:
            self._discard_incoming_data(conn, idx)

    def _process_server_output(self, msg):

        msg_content = self._pack_network_message(msg)

        if msg_content is None:
            self._handle_unsent_server_request(msg)
            return False

        conn = self._server_conn

        if conn is None or conn.sock is None:
            log.add_conn("Cannot send server message without an active server connection: %s", msg.__class__)
            self._handle_unsent_server_request(msg)
            return False

        msg_class = msg.__class__
        header = bytearray(
            msg.pack_uint32(len(msg_content) + 4)
            + msg.pack_uint32(SERVER_MESSAGE_CODES[msg_class])
        )

        if not self._append_server_message(conn, header, msg_content):
            self._handle_unsent_server_request(msg)
            return False

        self._apply_server_output_side_effects(msg)

        self._modify_connection_events(conn, selectors.EVENT_READ | selectors.EVENT_WRITE)
        return True

    def _apply_server_output_side_effects(self, msg):
        """Update local server-message ledgers after a message is queued.

        The server outgoing-buffer cap can reject a packed message and close the
        server connection. In that case, local request/response ledgers must not
        be mutated as if the request had actually been queued for sending.
        """

        msg_class = msg.__class__

        if msg_class is WatchUser and msg.user not in self._user_addresses:
            # Only cache IP address of watched users, otherwise we won't know if
            # a user reconnects and changes their IP address.
            self._user_addresses[msg.user] = None

        elif msg_class is GetPeerAddress:
            self._requested_peer_addresses.add(msg.user)

        elif msg_class is UnwatchUser and msg.user != self._server_username:
            self._user_addresses.pop(msg.user, None)
            self._requested_peer_addresses.discard(msg.user)

        elif msg_class is JoinGlobalRoom:
            GLOBAL_ROOM_FEED_ALLOWED.allow()

        elif msg_class is LeaveGlobalRoom:
            GLOBAL_ROOM_FEED_ALLOWED.disallow()

    def _append_server_message(self, conn, header, msg_content):
        """Append a packed server message if the stalled server buffer stays bounded."""

        out_buffer = conn.out_buffer
        total_size = len(header) + len(msg_content)

        if len(out_buffer) + total_size > self.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE:
            log.add_conn(
                "Closing server connection; outgoing server message buffer would exceed "
                "maximum size %s", self.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE
            )
            self._close_connection(conn)
            return False

        return self._append_outgoing_data(conn, header, msg_content, "server message")

    def _append_outgoing_message(self, conn, header, msg_content, description):
        """Append a packed non-file message to a peer buffer if it stays bounded."""

        out_buffer = conn.out_buffer
        total_size = len(header) + len(msg_content)

        if len(out_buffer) + total_size > self.MAX_OUTGOING_MESSAGE_BUFFER_SIZE:
            target = getattr(getattr(conn, "init", None), "target_user", None) or conn.addr
            log.add_conn(
                "Closing connection to %s; outgoing %s buffer would exceed maximum size %s",
                (target, description, self.MAX_OUTGOING_MESSAGE_BUFFER_SIZE)
            )
            self._close_connection(conn)
            return False

        return self._append_outgoing_data(conn, header, msg_content, description)

    def _server_disconnect(self):
        """We're disconnecting from the server, clean up."""

        self._server_conn = None
        self._should_process_queue = False
        self._interface_name = self._interface_address = None
        self._local_ip_address = ""

        self._close_listen_socket()

        if self._portmapper is not None:
            self._portmapper.remove_port_mapping(blocking=False)
            self._portmapper.set_port(port=None, local_ip_address=None)
            self._portmapper = None

        self._parent_conn = None
        self._potential_parents.clear()
        self._branch_level = 0
        self._branch_root = None
        self._is_server_parent = False
        self._distrib_parent_min_speed = 0
        self._distrib_parent_speed_ratio = 1
        self._max_distrib_children = 0
        self._upload_speed = 0
        self._user_addresses.clear()

        self._check_indirect_request_timeouts(expire_all=True)

        for conn in self._conns.copy().values():
            self._close_connection(conn)

        self._clear_network_message_queue(revoke_unsent=True)
        self._server_message_unavailable_limit_logged = False
        self._dropped_network_messages = 0
        self._dropped_transfer_network_messages = 0
        self._pending_peer_conns.clear()
        self._pending_init_msgs.clear()
        self._username_init_msgs.clear()
        self._requested_peer_addresses.clear()
        self._pending_peer_message_count = 0
        self._pending_peer_message_bytes = 0
        self._pending_peer_message_limit_logged = False
        self._incoming_preinit_peer_addresses.clear()
        self._incoming_preinit_peer_address_limit_logged = False
        self._incoming_indirect_conn_times.clear()
        self._incoming_indirect_conn_limit_logged = False
        self._clear_forwarded_distributed_searches()
        self._clear_distributed_server_control_retries()
        GLOBAL_ROOM_FEED_ALLOWED.clear()

        # Reset connection stats
        events.emit_main_thread("set-connection-stats")

        if not self._server_address:
            # We didn't successfully establish a connection to the server
            return

        ip_address, port = self._server_address

        log.add(
            _("Disconnected from server %(host)s:%(port)s"), {
                "host": ip_address,
                "port": port
            })

        if self._server_relogged:
            log.add(_("Someone logged in to your Soulseek account elsewhere"))
            self._server_relogged = False

        if not self._manual_server_disconnect:
            self._set_server_timer(use_fixed_timeout=self._manual_server_reconnect)

        self._server_address = None
        self._server_username = None
        self._wait_port_report_retries.clear()
        self._wait_port_report_retry_keys.clear()
        self._wait_port_report_retry_limit_logged = False
        self._clear_cant_connect_to_peer_retries()
        self._clear_main_thread_lifecycle_event_retries()

        events.emit_main_thread(
            "server-disconnect",
            ServerDisconnect(manual_disconnect=self._manual_server_disconnect)
        )

    def _send_message_to_server(self, msg):
        if not self._should_process_queue:
            return False

        log.add_msg_contents(msg, is_outgoing=True)
        return self._process_server_output(msg)

    def _handle_unsent_server_request(self, msg):
        """Revoke response grants and notify main-thread ledgers for unsent server requests."""

        self._revoke_unsent_server_request_grant(msg)

        if msg.__class__ is CantConnectToPeer:
            self._queue_cant_connect_to_peer_retry(msg)
            return

        self._emit_main_thread_lifecycle_event("server-message-unsent", msg)

    @staticmethod
    def _revoke_unsent_server_request_grant(msg):
        """Revoke parser grants for server requests that never reached output.

        Main-thread callers can only observe acceptance into the local network
        queue. A later pack failure, disconnect, or server-output buffer cap can
        still prevent the request from being put on the server socket. Any
        heavyweight response grant installed after queue acceptance must be
        revoked at this lower boundary as well, otherwise a later unsolicited
        server response can reuse a grant for a request that was never sent.
        """

        msg_class = msg.__class__

        if msg_class in {FileSearch, RoomSearch, UserSearch, WishlistSearch}:
            token = getattr(msg, "token", None)

            if token is not None:
                SEARCH_TOKENS_ALLOWED.release(token)

            return

        if msg_class is UserInterests:
            USER_INTERESTS_USERS_ALLOWED.discard(msg.user)
            return

        if msg_class is ItemRecommendations:
            ITEM_RECOMMENDATIONS_ALLOWED.discard(msg.thing)
            return

        if msg_class is ItemSimilarUsers:
            ITEM_SIMILAR_USERS_ALLOWED.discard(msg.thing)
            return

        if msg_class is Recommendations:
            RECOMMENDATIONS_ALLOWED.consume()
            return

        if msg_class is GlobalRecommendations:
            GLOBAL_RECOMMENDATIONS_ALLOWED.consume()
            return

        if msg_class is SimilarUsers:
            SIMILAR_USERS_ALLOWED.consume()

    # Peer Init #

    def _process_peer_init_message(self, conn, msg_type, msg_size, in_buffer, start_offset, end_offset):

        msg_class = PEER_INIT_MESSAGE_CLASSES[msg_type]
        msg = self._unpack_network_message(
            msg_class,
            memoryview(in_buffer)[start_offset:end_offset],
            msg_size,
            conn_type="peer init",
            sock=conn.sock
        )

        if msg is None:
            return None

        if msg_class is PierceFireWall:
            token = msg.token
            log.add_conn("Received indirect connection response (PierceFireWall) with token "
                         "%s, address %s", (token, conn.addr))

            log.add_conn("Number of stored peer init message tokens: %s", len(self._token_init_msgs))

            if token not in self._token_init_msgs:
                log.add_conn("Indirect connection attempt with token %s previously expired, "
                             "closing connection", token)
                return None

            init, _request_time = self._token_init_msgs.pop(token)
            previous_sock = init.sock
            is_direct_conn_in_progress = (
                previous_sock is not None and not self._conns[previous_sock].is_established
            )

            log.add_conn("Indirect connection to user %s with token %s established",
                         (init.target_user, token))

            if previous_sock is None or is_direct_conn_in_progress:
                init.sock = conn.sock
                log.add_conn("Using as primary connection, since no direct connection is established")
            else:
                # We already have a direct connection, but some clients may send a message over
                # the indirect connection. Keep it open.
                log.add_conn("Direct connection was already established, keeping it as primary connection")

            if is_direct_conn_in_progress:
                log.add_conn("Stopping direct connection attempt to user %s", init.target_user)
                self._close_connection(self._conns[previous_sock])

        elif msg_class is PeerInit:
            username = msg.target_user
            conn_type = msg.conn_type
            addr = conn.addr

            log.add_conn("Received incoming direct connection of type %s from user "
                         "%s, address %s", (conn_type, username, addr))

            if conn_type not in self.ALLOWED_PEER_CONN_TYPES:
                log.add_conn("Unknown connection type %s", conn_type)
                return None

            if not self._is_peer_init_address_consistent(username, addr):
                log.add_conn("Rejecting incoming direct connection of type %s from user %s, "
                             "address %s; cached server address is %s", (
                                 conn_type, username, addr, self._user_addresses.get(username)))
                return None

            init = msg
            self._replace_existing_connection(init)

        self._emit_network_message_event(msg)
        return init

    def _process_peer_init_input(self, conn):
        """Reads peer init messages from the input buffer of a peer connection."""

        in_buffer = conn.in_buffer
        buffer_len = len(in_buffer)
        msg_content_offset = 5

        if buffer_len < msg_content_offset:
            # TCP can split the 5-byte peer-init header across reads.
            return None

        msg_size, = UINT32_UNPACK(in_buffer)

        if msg_size > self.MAX_INCOMING_MESSAGE_SIZE:
            log.add_conn("Received message larger than maximum size %s from peer %s. "
                         "Closing connection.", (self.MAX_INCOMING_MESSAGE_SIZE, conn.addr))
            self._close_connection(conn)
            return None

        if msg_size < self.DISTRIBUTED_MESSAGE_CODE_SIZE:
            log.add_conn("Received message smaller than minimum size %s from peer %s. "
                         "Closing connection.", (self.DISTRIBUTED_MESSAGE_CODE_SIZE, conn.addr))
            self._close_connection(conn)
            return None

        msg_size_total = msg_size + 4

        # Unpack peer init message code before waiting for the full payload. Otherwise a peer can
        # advertise a huge known message and keep the connection open while the input buffer grows.
        msg_type = in_buffer[4]

        if msg_type not in PEER_INIT_MESSAGE_CLASSES:
            msg_content = in_buffer[msg_content_offset:min(50, msg_size_total)]
            log.add_debug("Peer init message type %s size %s contents %s unknown",
                          (msg_type, msg_size, msg_content))
            self._close_connection(conn)
            return None

        msg_class = PEER_INIT_MESSAGE_CLASSES[msg_type]
        max_msg_size = getattr(msg_class, "MAX_INCOMING_MESSAGE_SIZE", None)

        if max_msg_size is not None and msg_size > max_msg_size:
            log.add_conn("Received %s message larger than maximum size %s from peer %s. "
                         "Closing connection.", (msg_class.__name__, max_msg_size, conn.addr))
            self._close_connection(conn)
            return None

        if msg_size_total > buffer_len:
            # Buffer is still being filled.
            conn.has_post_init_activity = True
            return None

        init = self._process_peer_init_message(
            conn, msg_type, msg_size, in_buffer, msg_content_offset, msg_size_total)

        if init is None:
            self._close_connection(conn)
            return None

        self._discard_incoming_data(conn, msg_size_total)
        self._release_preinit_peer_address(conn)
        conn.init = init

        self._add_init_message(init)
        self._process_conn_messages(init)
        self._accept_child_peer_connection(conn)
        return init

    def _process_peer_init_output(self, msg):

        # Pack peer init messages
        conn = self._conns[msg.sock]
        msg_content = self._pack_network_message(msg)

        if msg_content is None:
            self._close_connection(conn)
            return False

        header = bytearray()
        header += msg.pack_uint32(len(msg_content) + 1)
        header += msg.pack_uint8(PEER_INIT_MESSAGE_CODES[msg.__class__])

        if not self._append_outgoing_message(conn, header, msg_content, "peer-init message"):
            self._close_connection(conn)
            return False

        self._modify_connection_events(conn, selectors.EVENT_READ | selectors.EVENT_WRITE)
        return True

    # Peer Connection #

    def _accept_incoming_peer_connections(self):

        accepted_connections = 0

        while (
            accepted_connections < self.MAX_INCOMING_ACCEPTS_PER_CYCLE
            and self._num_sockets < self.MAX_SOCKETS
        ):
            incoming_sock = None

            try:
                incoming_sock, incoming_addr = self._listen_socket.accept()
                accepted_connections += 1
                incoming_sock.setblocking(False)
                incoming_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

            except OSError as error:
                if error.errno == errno.EWOULDBLOCK:
                    # No more incoming connections
                    break

                log.add_conn("Incoming connection failed: %s", error)

                if incoming_sock is not None:
                    self._close_socket(incoming_sock)

                continue

            io_events = selectors.EVENT_READ

            conn = PeerConnection(sock=incoming_sock, addr=incoming_addr, io_events=io_events)

            if not self._reserve_preinit_peer_address(conn):
                self._close_socket(incoming_sock)
                continue

            self._conns[incoming_sock] = conn
            self._num_sockets += 1

            # Event flags are modified to include 'write' in subsequent loops, if necessary.
            # Don't do it here, otherwise connections may break.
            try:
                self._selector.register(incoming_sock, io_events)

            except (OSError, ValueError, KeyError) as error:
                log.add_conn("Incoming connection from address %s could not be registered: %s",
                             (incoming_addr, error))
                self._close_connection(conn)
                continue

            conn.is_established = True

            log.add_conn("Incoming connection from address %s", (incoming_addr,))

    def _init_peer_connection(self, addr, init, response_token=None):

        pending_key = self._get_pending_peer_conn_key(addr, init, response_token)

        if self._num_sockets >= self.MAX_SOCKETS:
            # Connection limit reached, re-queue within a hard cap to avoid retaining
            # unlimited init messages and response tokens under socket pressure. Keep
            # the original queued_time for existing entries so a constantly full
            # socket table cannot refresh stale pending connections forever.
            if pending_key in self._pending_peer_conns:
                return

            if len(self._pending_peer_conns) >= self.MAX_PENDING_PEER_CONNECTIONS:
                self._drop_pending_peer_connection(init, response_token=response_token)
                return

            self._pending_peer_conns[pending_key] = PendingPeerConnection(addr, init, response_token)
            return

        self._pending_peer_conns.pop(pending_key, None)

        if not self._is_valid_peer_address(addr):
            log.add_conn("Skipping direct connection attempt of type %s to user %s "
                         "due to invalid address %s", (init.conn_type, init.target_user, addr))

            if response_token is not None:
                self._send_cant_connect_to_peer(response_token, init.target_user)

            else:
                self._emit_peer_connection_error(init.target_user, init.conn_type, init)

            self._clear_queued_peer_messages(init, revoke_unsent=True)
            self._remove_init_message(init)
            return

        request_token = None

        if response_token is None:
            # No token provided, we're not responding to an indirect connection request.
            # Request indirect connection from our end in case the user's port is closed.
            request_token = self._connect_to_peer_indirect(init)

        io_events = selectors.EVENT_READ | selectors.EVENT_WRITE
        sock = None
        conn = PeerConnection(
            sock=None, addr=addr, io_events=io_events,
            init=init, request_token=request_token, response_token=response_token
        )

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            conn.sock = sock
            sock.setblocking(False)
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self._bind_socket_interface(sock)
            sock.connect_ex(addr)
            self._selector.register(sock, io_events)

        except (OSError, ValueError, KeyError) as error:
            self._connect_error(error, conn)

            if sock is not None:
                self._close_socket(sock)

            conn.sock = None

            if response_token is not None:
                self._clear_queued_peer_messages(init, revoke_unsent=True)
                self._remove_init_message(init)

            elif request_token is None:
                self._emit_peer_connection_error(init.target_user, init.conn_type, init)
                self._clear_queued_peer_messages(init, revoke_unsent=True)
                self._remove_init_message(init)

            return

        init.sock = sock
        self._conns[sock] = conn
        self._num_sockets += 1

    def _process_peer_input(self, conn):
        """Reads messages from the input buffer of a 'P' connection."""

        in_buffer = conn.in_buffer
        buffer_len = len(in_buffer)
        msg_content_offset = 8
        idx = 0
        search_result_received = False

        # Peer messages are 8 bytes or greater in length
        processed_messages = 0

        while buffer_len >= msg_content_offset:
            if processed_messages >= self.MAX_INCOMING_MESSAGES_PER_CONNECTION_CYCLE:
                break

            msg_size, msg_type = DOUBLE_UINT32_UNPACK(in_buffer, idx)

            if msg_size > self.MAX_INCOMING_MESSAGE_SIZE:
                log.add_conn("Received message larger than maximum size %s from user %s. "
                             "Closing connection.", (self.MAX_INCOMING_MESSAGE_SIZE, conn.init.target_user))
                self._close_connection(conn)
                return

            if msg_size < self.SERVER_PEER_MESSAGE_CODE_SIZE:
                log.add_conn("Received message smaller than minimum size %s from user %s. "
                             "Closing connection.", (self.SERVER_PEER_MESSAGE_CODE_SIZE, conn.init.target_user))
                self._close_connection(conn)
                return

            msg_size_total = msg_size + 4

            if msg_type not in PEER_MESSAGE_CLASSES:
                log.add_debug("Peer message type %s unknown from user %s, address %s. Closing connection.",
                              (msg_type, conn.init.target_user, conn.addr))
                self._close_connection(conn)
                return

            msg_class = PEER_MESSAGE_CLASSES[msg_type]
            max_msg_size = getattr(msg_class, "MAX_INCOMING_MESSAGE_SIZE", None)

            if max_msg_size is not None and msg_size > max_msg_size:
                log.add_conn("Received %s message larger than maximum size %s from user %s. "
                             "Closing connection.", (msg_class.__name__, max_msg_size, conn.init.target_user))
                self._close_connection(conn)
                return

            if msg_class is SharedFileListResponse and not SHARED_FILE_LIST_USERS_ALLOWED.is_allowed(
                    conn.init.target_user):
                log.add_conn("Received unsolicited shared file list response from user %s. Closing connection.",
                             conn.init.target_user)
                self._close_connection(conn)
                return

            if msg_class is UserInfoResponse and not USER_INFO_USERS_ALLOWED.is_allowed(conn.init.target_user):
                log.add_conn("Received unsolicited user info response from user %s. Closing connection.",
                             conn.init.target_user)
                self._close_connection(conn)
                return

            if not self._should_parse_peer_message(msg_class):
                if msg_size_total > buffer_len:
                    break

                log.add_debug("Ignoring unhandled peer message type %s (%s) from user %s without parsing",
                              (msg_type, msg_class.__name__, conn.init.target_user))
                idx += msg_size_total
                buffer_len -= msg_size_total
                processed_messages += 1
                continue

            if not self._register_large_message_buffer(conn, msg_size_total):
                self._close_connection(conn)
                return

            if msg_size_total > buffer_len:
                # Buffer is being filled. Large shared-file-list and user-info
                # responses can arrive in many chunks; avoid enqueueing a main
                # thread progress event for every recv() call.
                if msg_class is SharedFileListResponse:
                    if self._should_emit_large_message_progress(conn, buffer_len, msg_size_total):
                        events.emit_main_thread(
                            "shared-file-list-progress", conn.init.target_user, conn.sock, buffer_len, msg_size_total)

                elif msg_class is UserInfoResponse:
                    if self._should_emit_large_message_progress(conn, buffer_len, msg_size_total):
                        events.emit_main_thread(
                            "user-info-progress", conn.init.target_user, conn.sock, buffer_len, msg_size_total)

                break

            self._reset_large_message_progress(conn)
            self._unregister_large_message_buffer(conn)

            if msg_class is SharedFileListResponse:
                SHARED_FILE_LIST_USERS_ALLOWED.discard(conn.init.target_user)
            elif msg_class is UserInfoResponse:
                USER_INFO_USERS_ALLOWED.discard(conn.init.target_user)

            # Unpack peer messages
            msg = self._unpack_network_message(
                msg_class,
                memoryview(in_buffer)[idx + msg_content_offset:idx + msg_size_total],
                msg_size,
                conn_type="peer",
                sock=conn.sock,
                addr=conn.addr,
                username=conn.init.target_user
            )

            if msg_class is FileSearchResponse:
                search_result_received = True

            self._emit_network_message_event(msg)

            idx += msg_size_total
            buffer_len -= msg_size_total
            processed_messages += 1

        if idx:
            self._discard_incoming_data(conn, idx)
            conn.has_post_init_activity = True

        if search_result_received and not self._is_connection_still_active(conn):
            # Forcibly close peer connection. Only used after receiving a search result,
            # as we need to get rid of peer connections before they pile up.

            self._close_connection(conn)

    def _process_peer_output(self, msg):

        # Pack peer messages
        msg_content = self._pack_network_message(msg)

        if msg_content is None:
            self._handle_unsent_peer_message(msg)
            return

        conn = self._conns[msg.sock]
        header = bytearray()
        header += msg.pack_uint32(len(msg_content) + 4)
        header += msg.pack_uint32(PEER_MESSAGE_CODES[msg.__class__])

        if not self._append_outgoing_message(conn, header, msg_content, "peer message"):
            self._handle_unsent_peer_message(msg)
            return

        conn.has_post_init_activity = True
        self._modify_connection_events(conn, selectors.EVENT_READ | selectors.EVENT_WRITE)

    # File Connection #

    def _calc_upload_limit(self, limit_disabled=False, limit_per_transfer=False):

        limit = self._upload_limit
        loop_limit = 1024  # 1 KB/s is the minimum upload speed per transfer

        if limit_disabled or limit < loop_limit:
            self._upload_limit_split = 0
            return

        if not limit_per_transfer and self._total_uploads > 1:
            limit //= self._total_uploads

        self._upload_limit_split = int(limit)

    def _calc_upload_limit_by_transfer(self):
        return self._calc_upload_limit(limit_per_transfer=True)

    def _calc_upload_limit_none(self):
        return self._calc_upload_limit(limit_disabled=True)

    def _calc_download_limit(self):

        limit = self._download_limit
        loop_limit = 1024  # 1 KB/s is the minimum download speed per transfer

        if limit < loop_limit:
            # Download limit disabled
            self._download_limit_split = 0
            return

        if self._total_downloads > 1:
            limit //= self._total_downloads

        self._download_limit_split = int(limit)

    def _process_file_init_message(self, conn, in_buffer):

        msg_size = 4

        if len(in_buffer) < msg_size:
            return 0

        idx = msg_size
        msg = self._unpack_network_message(
            FileTransferInit,
            memoryview(in_buffer)[:msg_size],
            msg_size,
            conn_type="file",
            sock=conn.sock,
            username=conn.init.target_user
        )

        if msg is not None and msg.token is not None:
            self._file_init_msgs[conn] = msg
            self._emit_network_message_event(msg)

        return idx

    def _process_file_offset_message(self, conn, in_buffer):

        file_upload = self._file_upload_msgs[conn]

        if file_upload.offset is not None:
            # No more incoming messages on this connection after receiving the
            # file offset. If peer sends something anyway, clear it.
            return len(in_buffer)

        msg_size = 8

        if len(in_buffer) < msg_size:
            return 0

        idx = msg_size
        msg = self._unpack_network_message(
            FileOffset,
            memoryview(in_buffer)[:msg_size],
            msg_size,
            conn_type="file",
            sock=conn.sock,
            username=conn.init.target_user
        )

        if msg is None or msg.offset is None:
            return idx

        if file_upload.size is not None and msg.offset > file_upload.size:
            error = ValueError("File offset exceeds upload size")
            self._emit_main_thread_lifecycle_event(
                "upload-file-error",
                username=conn.init.target_user, token=file_upload.token, error=error
            )
            self._close_connection(conn)
            return None

        file_upload.offset = msg.offset

        events.emit_main_thread(
            "file-upload-progress",
            username=conn.init.target_user, token=file_upload.token,
            offset=file_upload.offset, bytes_sent=file_upload.sentbytes
        )

        try:
            file_upload.file.seek(msg.offset)
            self._modify_connection_events(conn, selectors.EVENT_READ | selectors.EVENT_WRITE)

        except (OSError, ValueError) as error:
            self._emit_main_thread_lifecycle_event(
                "upload-file-error",
                username=conn.init.target_user, token=file_upload.token, error=error
            )
            self._close_connection(conn)
            return None

        return idx

    def _write_download_file(self, file_download, data, data_len):

        try:
            if not data:
                return

            file_download.speed += data_len
            self._total_download_bandwidth += data_len

            file_download.file.write(data)
            file_download.leftbytes -= data_len

        finally:
            # Release memoryview in case of critical error
            data = None

    def _process_download(self, conn, data, data_len):

        file_download = self._file_download_msgs[conn]
        idx = file_download.leftbytes

        try:
            if data_len > idx:
                self._write_download_file(file_download, memoryview(data)[:idx], idx)
            else:
                self._write_download_file(file_download, data, data_len)

        except (OSError, ValueError) as error:
            self._emit_main_thread_lifecycle_event(
                "download-file-error",
                username=conn.init.target_user, token=file_download.token, error=error
            )
            return False  # Close the connection

        # Download finished
        if file_download.leftbytes <= 0:
            events.emit_main_thread(
                "file-download-progress",
                username=conn.init.target_user, token=file_download.token,
                bytes_left=file_download.leftbytes
            )
            return False  # Close the connection

        return True

    def _process_upload(self, conn, num_sent_bytes, current_time):

        file_upload = self._file_upload_msgs[conn]

        if file_upload.offset is None:
            return True

        out_buffer = conn.out_buffer
        out_buffer_len = len(out_buffer)
        file_upload.sentbytes += num_sent_bytes
        total_read_bytes = file_upload.offset + file_upload.sentbytes + out_buffer_len
        size = file_upload.size

        try:
            if total_read_bytes < size:
                num_bytes_to_read = int(
                    (max(4096, num_sent_bytes * 1.25) / max(1, current_time - conn.last_active))
                    - out_buffer_len
                )
                if num_bytes_to_read > 0:
                    remaining_bytes = size - total_read_bytes
                    available_buffer_size = self.MAX_FILE_UPLOAD_BUFFER_SIZE - out_buffer_len
                    available_global_buffer_size = self.MAX_FILE_UPLOAD_BUFFER_BYTES - self._file_upload_buffer_bytes

                    if available_global_buffer_size <= 0:
                        raise OSError("aggregate file upload buffer budget exhausted")

                    num_bytes_to_read = min(
                        num_bytes_to_read, remaining_bytes, available_buffer_size, available_global_buffer_size
                    )

                    if num_bytes_to_read > 0:
                        file_data = file_upload.file.read(num_bytes_to_read)

                        if not file_data:
                            raise OSError("file ended before upload completed")

                        if not self._append_file_upload_data(conn, file_data):
                            raise OSError("aggregate file upload buffer budget exhausted")

                        self._modify_connection_events(conn, selectors.EVENT_READ | selectors.EVENT_WRITE)

        except (OSError, ValueError) as error:
            self._emit_main_thread_lifecycle_event(
                "upload-file-error",
                username=conn.init.target_user, token=file_upload.token, error=error
            )
            return False  # Close the connection

        file_upload.speed += num_sent_bytes
        self._total_upload_bandwidth += num_sent_bytes

        # Upload finished
        if file_upload.offset + file_upload.sentbytes == size:
            events.emit_main_thread(
                "file-upload-progress",
                username=conn.init.target_user, token=file_upload.token,
                offset=file_upload.offset, bytes_sent=file_upload.sentbytes
            )
        return True

    def _process_file_input(self, conn):
        """Reads file messages from the input buffer of a 'F' connection."""

        in_buffer = conn.in_buffer
        idx = 0

        if conn not in self._file_init_msgs:
            if len(in_buffer) < 4:
                # TCP can split the 4-byte file-init token across reads.
                return

            idx = self._process_file_init_message(conn, in_buffer)

        elif conn in self._file_upload_msgs:
            if len(in_buffer) < 8:
                # TCP can split the 8-byte file offset across reads.
                return

            idx = self._process_file_offset_message(conn, in_buffer)

        if idx:
            self._discard_incoming_data(conn, idx)
            conn.has_post_init_activity = True

    def _process_file_output(self, msg):

        msg_class = msg.__class__

        # Pack file messages
        if msg_class is FileTransferInit:
            msg_content = self._pack_network_message(msg)

            if msg_content is None:
                self._handle_unsent_peer_message(msg)
                return

            conn = self._conns[msg.sock]

            if not self._append_file_control_data(conn, msg_content):
                self._handle_unsent_peer_message(msg)
                return

            self._file_init_msgs[conn] = msg
            self._emit_network_message_event(msg)

        elif msg_class is FileOffset:
            conn = self._conns[msg.sock]
            msg_content = self._pack_network_message(msg)

            if msg_content is None:
                log.add_conn("Closing file download connection to user %s; file offset could not be packed",
                             conn.init.target_user)
                self._close_connection(conn)
                return

            if not self._append_file_control_data(conn, msg_content):
                log.add_conn("Closing file download connection to user %s; file offset could not be queued",
                             conn.init.target_user)
                self._close_connection(conn)
                return

        conn.has_post_init_activity = True
        self._modify_connection_events(conn, selectors.EVENT_READ | selectors.EVENT_WRITE)

    # Distributed Connection #

    def _accept_child_peer_connection(self, conn):

        if conn.init.conn_type != ConnectionType.DISTRIBUTED:
            return

        username = conn.init.target_user

        if username == self._server_username:
            # We can't connect to ourselves
            return

        if username in self._potential_parents:
            # This is not a child peer, ignore
            return

        if self._parent_conn is None and not self._is_server_parent:
            # We have no parent user and the server hasn't sent search requests, no point
            # in accepting child peers
            log.add_conn("Rejecting distributed child peer connection from user %s, since we have no parent", username)
            self._close_connection(conn)
            return

        if username in self._child_peers:
            log.add_conn("Rejecting distributed child peer connection from user %s, since an existing connection "
                         "already exists", username)
            self._close_connection(conn)
            return

        if len(self._child_peers) >= self._max_distrib_children:
            log.add_conn("Rejecting distributed child peer connection from user %s, since child peer limit "
                         "of %s was reached", (username, self._max_distrib_children))
            self._close_connection(conn)
            return

        branch_msgs = (DistribBranchLevel(self._branch_level),)

        if self._parent_conn is not None:
            # Only sent when we're not the branch root
            branch_msgs += (DistribBranchRoot(self._branch_root),)

        for msg in branch_msgs:
            if self._send_distributed_message_to_connection(conn, msg):
                continue

            log.add_conn("Rejecting distributed child peer connection from user %s, since initial branch "
                         "state could not be queued", username)
            self._close_connection(conn)
            return

        self._child_peers[username] = conn

        log.add_conn("Adopting user %s as distributed child peer. Number of current child peers: %s",
                     (username, len(self._child_peers)))

        if len(self._child_peers) >= self._max_distrib_children:
            log.add_conn("Maximum number of distributed child peers reached (%s), "
                         "no longer accepting new connections", self._max_distrib_children)
            self._send_distributed_server_control_message(AcceptChildren(False))

    def _remove_child_peer_connection(self, username):

        self._child_peers.pop(username, None)

        if not self._should_process_queue:
            return

        if len(self._child_peers) == self._max_distrib_children - 1:
            log.add_conn("Available to accept a new distributed child peer")
            self._send_distributed_server_control_message(AcceptChildren(True))

        log.add_conn("Number of current child peers: %s", len(self._child_peers))

    def _send_distributed_message_to_connection(self, conn, msg):
        """Queue a distributed control/search message on an established child socket.

        Distributed child state is useful only if the peer receives the branch
        control messages that make it part of the tree. Lower output failure
        used to be ignored, leaving retained child state for peers that never
        received our branch level/root or forwarded searches.
        """

        sock = conn.sock

        if sock is None or sock not in self._conns:
            log.add_conn("Cannot send distributed message over a closed child connection: %s", msg.__class__)
            return False

        msg.sock = sock
        return self._process_distrib_output(msg) is not False

    def _send_message_to_child_peers(self, msg):

        msg_class = msg.__class__
        msg_attrs = [getattr(msg, s) for s in msg.__slots__]

        for username, conn in tuple(self._child_peers.items()):
            msg_child = msg_class(*msg_attrs)

            if self._send_distributed_message_to_connection(conn, msg_child):
                continue

            log.add_conn("Closing distributed child peer %s after lower output failure", username)
            self._close_connection(conn)

    def _send_required_distributed_server_messages(self, msgs, reason):
        """Queue distributed-tree control messages before mutating topology state.

        Distributed parent/branch state is shared between the server and child
        peers. If the local server output path rejects one of the required
        control messages under backpressure, mutating local topology first makes
        the client behave as if the server accepted a state transition it never
        saw. Fail closed; callers either keep their previous state or close the
        problematic parent connection.
        """

        for msg in msgs:
            if self._send_message_to_server(msg) is not False:
                continue

            log.add_conn(
                "Aborting distributed state transition '%s'; server output rejected %s",
                (reason, msg.__class__)
            )
            return False

        return True

    @staticmethod
    def _get_distributed_server_control_retry_key(msg):
        return (msg.__class__, tuple(getattr(msg, slot) for slot in getattr(msg, "__slots__", ())))

    def _clear_distributed_server_control_retries(self):
        self._distributed_server_control_retries.clear()
        self._distributed_server_control_retry_keys.clear()
        self._distributed_server_control_retry_limit_logged = False

    def _queue_distributed_server_control_retry(self, msg):
        key = self._get_distributed_server_control_retry_key(msg)

        if key in self._distributed_server_control_retry_keys:
            return

        if len(self._distributed_server_control_retries) >= self.MAX_DISTRIBUTED_SERVER_CONTROL_RETRIES:
            if not self._distributed_server_control_retry_limit_logged:
                log.add_conn(
                    "Dropping distributed server-control retry %s because the retry queue is full",
                    msg.__class__
                )
                self._distributed_server_control_retry_limit_logged = True

            return

        self._distributed_server_control_retry_keys.add(key)
        self._distributed_server_control_retries.append(msg)

    def _send_distributed_server_control_message(self, msg):
        """Send a best-effort distributed topology update and retry transient local failure.

        Required distributed transitions use _send_required_distributed_server_messages()
        and do not mutate state unless every server message is accepted. Some
        follow-up availability updates, such as AcceptChildren(True/False),
        happen after local child state has already changed. Those tiny control
        messages should not be silently lost if the local server-output path is
        temporarily unavailable or backpressured.
        """

        if self._send_message_to_server(msg) is not False:
            return True

        self._queue_distributed_server_control_retry(msg)
        return False

    @staticmethod
    def _get_wait_port_report_retry_key(msg):
        return msg.port

    def _queue_wait_port_report_retry(self, msg):
        key = self._get_wait_port_report_retry_key(msg)

        if key in self._wait_port_report_retry_keys:
            return

        if len(self._wait_port_report_retries) >= self.MAX_WAIT_PORT_REPORT_RETRIES:
            if not self._wait_port_report_retry_limit_logged:
                log.add_conn(
                    "Dropping SetWaitPort retry for port %s because the retry queue is full", key
                )
                self._wait_port_report_retry_limit_logged = True

            return

        self._wait_port_report_retry_keys.add(key)
        self._wait_port_report_retries.append(msg)

    def _send_wait_port_report(self, port):
        """Advertise our listen port and preserve the report if local output fails.

        Login/SetWaitPort are sent from the network thread after a server socket
        is established, bypassing the public queue where most accepted-work
        lifecycle checks live. A lost SetWaitPort leaves the server with stale
        reachability information until the next reconnect, so retry it through a
        small latest-state queue.
        """

        msg = SetWaitPort(port)

        if self._send_message_to_server(msg) is not False:
            return True

        self._queue_wait_port_report_retry(msg)
        return False

    def _process_wait_port_report_retries(self):
        if not self._wait_port_report_retries:
            return

        if self._server_conn is None or self._server_conn.sock is None:
            return

        num_retries = min(len(self._wait_port_report_retries), self.MAX_WAIT_PORT_REPORT_RETRIES)

        for _i in range(num_retries):
            msg = self._wait_port_report_retries.popleft()
            key = self._get_wait_port_report_retry_key(msg)
            self._wait_port_report_retry_keys.discard(key)

            if self._send_message_to_server(msg) is not False:
                continue

            self._queue_wait_port_report_retry(msg)
            break

        if len(self._wait_port_report_retries) < (self.MAX_WAIT_PORT_REPORT_RETRIES // 2):
            self._wait_port_report_retry_limit_logged = False

    @staticmethod
    def _get_cant_connect_to_peer_retry_key(msg):
        return (msg.token, msg.user)

    def _clear_cant_connect_to_peer_retries(self):
        self._cant_connect_to_peer_retries.clear()
        self._cant_connect_to_peer_retry_keys.clear()
        self._cant_connect_to_peer_retry_limit_logged = False

    def _queue_cant_connect_to_peer_retry(self, msg):
        key = self._get_cant_connect_to_peer_retry_key(msg)

        if key in self._cant_connect_to_peer_retry_keys:
            return

        if len(self._cant_connect_to_peer_retries) >= self.MAX_CANT_CONNECT_TO_PEER_RETRIES:
            if not self._cant_connect_to_peer_retry_limit_logged:
                log.add_conn(
                    "Dropping CantConnectToPeer retry for user %s token %s because the retry queue is full",
                    (msg.user, msg.token)
                )
                self._cant_connect_to_peer_retry_limit_logged = True

            return

        self._cant_connect_to_peer_retry_keys.add(key)
        self._cant_connect_to_peer_retries.append(msg)

    def _send_cant_connect_to_peer(self, token, username):
        """Tell the server that an indirect peer connection cannot be completed.

        These replies are generated inside the network thread after we reject or
        fail a server-provided ConnectToPeer request. They bypass the public
        queue, so preserve them in a tiny bounded retry queue if the server
        socket/output path is temporarily unavailable or backpressured.
        """

        msg = CantConnectToPeer(token, username)

        if self._send_message_to_server(msg) is not False:
            return True

        self._queue_cant_connect_to_peer_retry(msg)
        return False

    def _process_cant_connect_to_peer_retries(self):
        if not self._cant_connect_to_peer_retries:
            return

        if self._server_conn is None or self._server_conn.sock is None:
            return

        num_retries = min(
            len(self._cant_connect_to_peer_retries),
            self.MAX_CANT_CONNECT_TO_PEER_RETRIES_PER_CYCLE
        )

        for _i in range(num_retries):
            msg = self._cant_connect_to_peer_retries.popleft()
            key = self._get_cant_connect_to_peer_retry_key(msg)
            self._cant_connect_to_peer_retry_keys.discard(key)

            if self._send_message_to_server(msg) is not False:
                continue

            # _handle_unsent_server_request() requeues real lower-output failures.
            # Keep this fallback for focused tests that mock _send_message_to_server()
            # as a simple False-returning function.
            if key not in self._cant_connect_to_peer_retry_keys:
                self._queue_cant_connect_to_peer_retry(msg)

            break

        if len(self._cant_connect_to_peer_retries) < (self.MAX_CANT_CONNECT_TO_PEER_RETRIES // 2):
            self._cant_connect_to_peer_retry_limit_logged = False

    def _process_distributed_server_control_retries(self):
        if not self._distributed_server_control_retries:
            return

        if self._server_conn is None or self._server_conn.sock is None:
            return

        num_retries = min(
            len(self._distributed_server_control_retries),
            self.MAX_DISTRIBUTED_SERVER_CONTROL_RETRIES_PER_CYCLE
        )

        for _i in range(num_retries):
            msg = self._distributed_server_control_retries.popleft()
            key = self._get_distributed_server_control_retry_key(msg)
            self._distributed_server_control_retry_keys.discard(key)

            if self._send_message_to_server(msg) is not False:
                continue

            self._queue_distributed_server_control_retry(msg)
            break

        if len(self._distributed_server_control_retries) < (self.MAX_DISTRIBUTED_SERVER_CONTROL_RETRIES // 2):
            self._distributed_server_control_retry_limit_logged = False

    def _clear_forwarded_distributed_searches(self):
        self._forwarded_distributed_searches.clear()
        self._forwarded_distributed_search_order.clear()

    def _drop_oldest_forwarded_distributed_search(self):
        while self._forwarded_distributed_search_order:
            _queued_time, key = self._forwarded_distributed_search_order.popleft()

            if key in self._forwarded_distributed_searches:
                self._forwarded_distributed_searches.pop(key, None)
                return True

        return False

    def _prune_forwarded_distributed_searches(self, current_time):
        expire_before = current_time - self.FORWARDED_DISTRIBUTED_SEARCH_TTL

        while self._forwarded_distributed_search_order:
            queued_time, key = self._forwarded_distributed_search_order[0]

            if self._forwarded_distributed_searches.get(key) != queued_time:
                self._forwarded_distributed_search_order.popleft()
                continue

            if queued_time > expire_before:
                break

            self._forwarded_distributed_search_order.popleft()
            self._forwarded_distributed_searches.pop(key, None)

    def _should_forward_distributed_search(self, msg, current_time=None):
        if not isinstance(msg, DistribSearch):
            return True

        if current_time is None:
            current_time = time.monotonic()

        self._prune_forwarded_distributed_searches(current_time)
        key = (msg.search_username, msg.token)

        if key in self._forwarded_distributed_searches:
            log.add_conn(
                "Ignoring duplicate distributed search request from user %s with token %s before child fanout",
                (msg.search_username, msg.token)
            )
            return False

        while len(self._forwarded_distributed_searches) >= self.MAX_FORWARDED_DISTRIBUTED_SEARCHES:
            if not self._drop_oldest_forwarded_distributed_search():
                break

        if len(self._forwarded_distributed_searches) >= self.MAX_FORWARDED_DISTRIBUTED_SEARCHES:
            log.add_conn(
                "Ignoring distributed search request from user %s with token %s; forwarded-search ledger is full",
                (msg.search_username, msg.token)
            )
            return False

        self._forwarded_distributed_searches[key] = current_time
        self._forwarded_distributed_search_order.append((current_time, key))
        return True

    def _distribute_embedded_message(self, msg, embedded_msg):
        """Distributes an embedded message from the server to our child
        peers."""

        if self._parent_conn is not None:
            # The server shouldn't send embedded messages while it's not our parent, but let's be safe
            return

        if self._should_forward_distributed_search(embedded_msg):
            self._send_message_to_child_peers(DistribEmbeddedMessage(msg.distrib_code, msg.distrib_message))

        if self._is_server_parent:
            return

        self._is_server_parent = True

        if len(self._child_peers) < self._max_distrib_children:
            self._send_distributed_server_control_message(AcceptChildren(True))

        log.add_conn("Server is our parent, ready to distribute search requests as a branch root")

    def _verify_parent_connection(self, conn, msg_class):
        """Verify that a connection is our current parent connection."""

        if conn is not self._parent_conn:
            log.add_conn("Received a distributed message %s from user %s, who is not our parent. "
                         "Closing connection.", (msg_class, conn.init.target_user))
            return False

        return True

    def _send_have_no_parent(self):
        """Inform the server we have no parent.

        The server should either send us a PossibleParents message, or
        start sending us search requests.
        """

        if not self._should_process_queue:
            return False

        branch_root = self._server_username
        branch_level = 0

        if not self._send_required_distributed_server_messages((
                HaveNoParent(True),
                BranchRoot(branch_root),
                BranchLevel(branch_level),
                AcceptChildren(False)
        ), "request-new-distributed-parent"):
            return False

        # Note that we don't clear the previous list of possible parents here, since
        # it's possible the parent connection was closed immediately or superseded by
        # an indirect connection
        self._parent_conn = None
        self._branch_level = branch_level
        self._branch_root = branch_root

        log.add_conn("We have no parent, requesting a new one")
        return True

    def _set_branch_root(self, username):
        """Inform the server and child peers of our branch root."""

        if not username:
            return False

        if username == self._branch_root:
            return True

        if not self._send_required_distributed_server_messages((
                BranchRoot(username),
        ), "set-distributed-branch-root"):
            return False

        self._branch_root = username
        self._send_message_to_child_peers(DistribBranchRoot(username))

        log.add_conn("Our branch root is user %s", username)
        return True

    def _update_maximum_distributed_children(self):

        prev_max_distrib_children = self._max_distrib_children
        num_child_peers = len(self._child_peers)

        if self._upload_speed >= self._distrib_parent_min_speed and self._distrib_parent_speed_ratio > 0:
            # Limit maximum distributed child peers to 10 for now due to socket limit concerns
            self._max_distrib_children = min(self._upload_speed // self._distrib_parent_speed_ratio // 100, 10)
        else:
            # Server does not allow us to accept distributed child peers
            self._max_distrib_children = 0

        log.add_conn("Distributed child peer limit updated, maximum connections: %s", self._max_distrib_children)

        if self._max_distrib_children <= num_child_peers < prev_max_distrib_children:
            log.add_conn("Our current number of distributed child peers (%s) reached the new limit, no longer "
                         "accepting new connections", num_child_peers)
            self._send_distributed_server_control_message(AcceptChildren(False))

    def _process_distrib_message(self, conn, msg_type, msg_size, in_buffer, start_offset, end_offset):

        msg_class = DISTRIBUTED_MESSAGE_CLASSES[msg_type]
        msg = self._unpack_network_message(
            msg_class,
            memoryview(in_buffer)[start_offset:end_offset],
            msg_size,
            conn_type="distrib",
            sock=conn.sock,
            username=conn.init.target_user
        )

        if msg is None:
            # Ignore unknown message and keep connection open
            return True

        if msg_class is DistribSearch:
            if not self._verify_parent_connection(conn, msg_class):
                return False

            if self._should_forward_distributed_search(msg):
                self._send_message_to_child_peers(msg)

        elif msg_class is DistribEmbeddedMessage:
            if not self._verify_parent_connection(conn, msg_class):
                return False

            msg = self._unpack_embedded_message(msg)

            if msg is not None and self._should_forward_distributed_search(msg):
                self._send_message_to_child_peers(msg)

        elif msg_class is DistribBranchLevel:
            if msg.level < 0 or msg.level > self.MAX_DISTRIBUTED_BRANCH_LEVEL:
                # There are rare cases of parents sending a branch level value of -1,
                # presumably buggy clients. Very large signed int32 branch levels are
                # also invalid for this client, because we add one before forwarding
                # the value to child peers as another signed int32.
                log.add_conn("Received an invalid branch level value %s from user %s. "
                             "Closing connection.", (msg.level, msg.username))
                return False

            if self._parent_conn is None and msg.username in self._potential_parents:
                # We have a successful connection with a potential parent. Tell the server who
                # our parent is, and stop requesting new potential parents.
                new_branch_level = msg.level + 1
                server_msgs = [HaveNoParent(False), BranchLevel(new_branch_level)]

                if len(self._child_peers) < self._max_distrib_children:
                    server_msgs.append(AcceptChildren(True))

                if new_branch_level == 1:
                    # Our current branch level is 1, our parent is a branch root.
                    server_msgs.append(BranchRoot(msg.username))

                if not self._send_required_distributed_server_messages(server_msgs, "adopt-distributed-parent"):
                    return False

                self._parent_conn = conn
                self._branch_level = new_branch_level
                self._is_server_parent = False
                self._clear_forwarded_distributed_searches()

                if new_branch_level == 1:
                    self._branch_root = msg.username

                self._send_message_to_child_peers(DistribBranchLevel(self._branch_level))
                self._child_peers.pop(msg.username, None)

                log.add_conn("Adopting user %s as parent", msg.username)
                log.add_conn("Our branch level is %s", self._branch_level)

                if self._branch_level == 1:
                    self._send_message_to_child_peers(DistribBranchRoot(self._branch_root))
                    log.add_conn("Our branch root is user %s", self._branch_root)

            elif not self._verify_parent_connection(conn, msg_class):
                return False

            else:
                # Inform the server and child peers of our new branch level
                new_branch_level = msg.level + 1

                if not self._send_required_distributed_server_messages((
                        BranchLevel(new_branch_level),
                ), "update-distributed-branch-level"):
                    return False

                self._branch_level = new_branch_level
                self._send_message_to_child_peers(DistribBranchLevel(self._branch_level))

                log.add_conn("Received a branch level update from our parent. Our new branch level is %s",
                             self._branch_level)

        elif msg_class is DistribBranchRoot:
            if not self._verify_parent_connection(conn, msg_class):
                return False

            if not self._set_branch_root(msg.root_username):
                return False

        self._emit_network_message_event(msg)
        return True

    def _process_distrib_input(self, conn):
        """Reads messages from the input buffer of a 'D' connection."""

        in_buffer = conn.in_buffer
        buffer_len = len(in_buffer)
        msg_content_offset = 5
        idx = 0

        # Distributed messages are 5 bytes or greater in length
        processed_messages = 0

        while buffer_len >= msg_content_offset:
            if processed_messages >= self.MAX_INCOMING_MESSAGES_PER_CONNECTION_CYCLE:
                break

            msg_size, = UINT32_UNPACK(in_buffer, idx)

            if msg_size > self.MAX_INCOMING_MESSAGE_SIZE:
                log.add_conn("Received message larger than maximum size %s from user %s. "
                             "Closing connection.", (self.MAX_INCOMING_MESSAGE_SIZE, conn.init.target_user))
                self._close_connection(conn)
                break

            if msg_size < self.DISTRIBUTED_MESSAGE_CODE_SIZE:
                log.add_conn("Received message smaller than minimum size %s from user %s. "
                             "Closing connection.", (self.DISTRIBUTED_MESSAGE_CODE_SIZE, conn.init.target_user))
                self._close_connection(conn)
                break

            msg_size_total = msg_size + 4
            msg_type = in_buffer[idx + 4]

            if msg_type not in DISTRIBUTED_MESSAGE_CLASSES:
                log.add_debug("Distrib message type %s unknown from user %s. Closing connection.",
                              (msg_type, conn.init.target_user))
                self._close_connection(conn)
                return

            msg_class = DISTRIBUTED_MESSAGE_CLASSES[msg_type]
            max_msg_size = getattr(msg_class, "MAX_INCOMING_MESSAGE_SIZE", None)

            if max_msg_size is not None and msg_size > max_msg_size:
                log.add_conn("Received %s message larger than maximum size %s from user %s. "
                             "Closing connection.", (msg_class.__name__, max_msg_size, conn.init.target_user))
                self._close_connection(conn)
                return

            if msg_size_total > buffer_len:
                # Buffer is being filled
                conn.has_post_init_activity = True
                break

            # Unpack distributed messages
            if not self._process_distrib_message(
                conn, msg_type, msg_size, in_buffer, idx + msg_content_offset, idx + msg_size_total
            ):
                self._close_connection(conn)
                return

            idx += msg_size_total
            buffer_len -= msg_size_total
            processed_messages += 1

        if idx:
            self._discard_incoming_data(conn, idx)
            conn.has_post_init_activity = True

    def _process_distrib_output(self, msg):

        # Pack distributed messages
        msg_content = self._pack_network_message(msg)

        if msg_content is None:
            return False

        conn = self._conns[msg.sock]
        header = bytearray()
        header += msg.pack_uint32(len(msg_content) + 1)
        header += msg.pack_uint8(DISTRIBUTED_MESSAGE_CODES[msg.__class__])

        if not self._append_outgoing_message(conn, header, msg_content, "distributed message"):
            return False

        conn.has_post_init_activity = True
        self._modify_connection_events(conn, selectors.EVENT_READ | selectors.EVENT_WRITE)
        return True

    # Internal Messages #

    @staticmethod
    def _close_internal_file_handle(msg):
        file_handle = getattr(msg, "file", None)

        if file_handle is None:
            return

        try:
            file_handle.close()

        except (OSError, ValueError):
            pass

    def _emit_unattached_file_handoff_closed(self, msg):
        username = getattr(msg, "username", None)
        token = getattr(msg, "token", None)

        if username is None or token is None or not self._should_process_queue:
            return

        self._emit_main_thread_lifecycle_event(
            "file-connection-closed", username=username, token=token, sock=msg.sock, timed_out=False
        )

    def _process_internal_message(self, msg):
        # Backwards-compatible singular helper for tests and internal callers.
        self._process_internal_messages(msg)

    def _process_internal_messages(self, msg):

        msg_class = msg.__class__

        if msg_class is CloseConnection:
            self._close_connection(self._conns.get(msg.sock))

        elif msg_class is ServerConnect:
            self._server_connect(msg)

        elif msg_class is ServerDisconnect:
            self._manual_server_disconnect = True
            self._close_connection(self._server_conn)

        elif msg_class is ServerReconnect:
            self._manual_server_reconnect = True
            self._close_connection(self._server_conn)

        elif msg_class is DownloadFile:
            conn = self._conns.get(msg.sock)

            if conn is None:
                log.add_conn("Download file handoff for user %s token %s lost its socket before attachment",
                             (getattr(msg, "username", None), msg.token))
                self._close_internal_file_handle(msg)
                self._emit_unattached_file_handoff_closed(msg)
                return

            self._file_download_msgs[conn] = msg

            self._total_downloads += 1
            self._calc_download_limit()
            self._process_conn_incoming_messages(conn)

        elif msg_class is UploadFile:
            conn = self._conns.get(msg.sock)

            if conn is None:
                log.add_conn("Upload file handoff for user %s token %s lost its socket before attachment",
                             (getattr(msg, "username", None), msg.token))
                self._close_internal_file_handle(msg)
                self._emit_unattached_file_handoff_closed(msg)
                return

            self._file_upload_msgs[conn] = msg

            self._total_uploads += 1
            self._calc_upload_limit_function()
            self._process_conn_incoming_messages(conn)

        elif msg_class is SetDownloadLimit:
            self._download_limit = msg.limit * 1024
            self._calc_download_limit()

        elif msg_class is SetUploadLimit:
            if msg.limit > 0:
                if msg.limitby:
                    self._calc_upload_limit_function = self._calc_upload_limit
                else:
                    self._calc_upload_limit_function = self._calc_upload_limit_by_transfer
            else:
                self._calc_upload_limit_function = self._calc_upload_limit_none

            self._upload_limit = msg.limit * 1024
            self._calc_upload_limit_function()

        elif msg_class is EmitNetworkMessageEvents:
            self._process_emit_network_message_events(msg)


    def _process_emit_network_message_events(self, msg):
        """Emit queued network-message events in bounded batches.

        EmitNetworkMessageEvents is currently used to replay deferred network
        messages after shares become available again. Keep that replay from
        monopolizing the networking thread if a large deferred batch arrives.
        """

        max_events = self.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH
        network_msgs = msg.msgs
        num_events = min(len(network_msgs), max_events)

        for network_msg in network_msgs[:num_events]:
            self._emit_network_message_event(network_msg)

        if len(network_msgs) > num_events:
            # Keep the unprocessed tail in the same list instead of slicing a
            # potentially huge deferred replay batch into another large list.
            del network_msgs[:num_events]

            if not self._queue_network_message(msg):
                # This replay batch already passed the public accepted-work
                # boundary before we started draining it. If unrelated backlog
                # fills the generic queue cap while a tail remains, preserve the
                # shrinking accepted tail instead of silently dropping deferred
                # peer requests.
                self._append_network_message_queue(
                    msg, priority=self._is_priority_network_message(msg))

    # Input/Output #

    def _process_buffered_conn_messages(self):
        """Continue parsing data already read into connection buffers.

        Incoming message parsing is batched per connection. If a socket delivers
        a huge burst of complete messages, the unprocessed tail remains in the
        in-memory buffer and must be revisited even when the kernel socket has
        no new readable bytes.
        """

        processed_connections = 0

        for conn in tuple(self._conns.values()):
            if not conn.in_buffer:
                continue

            self._process_conn_incoming_messages(conn)
            processed_connections += 1

            if processed_connections >= self.MAX_BUFFERED_CONNECTIONS_PER_CYCLE:
                break

    def _process_ready_input_socket(self, sock, current_time):

        if sock in self._conns:
            conn = self._conns[sock]
        else:
            # Unknown connection
            return

        if (self._download_limit_split
                and conn in self._conns_downloaded
                and self._conns_downloaded[conn] >= self._download_limit_split):
            return

        conn_error = None

        try:
            if self._read_data(conn, current_time):
                self._process_conn_incoming_messages(conn)
                return

        except OSError as error:
            log.add_conn("Cannot read data from connection %s, closing connection. "
                         "Error: %s", (conn.addr, error))
            conn_error = error

        if not conn.is_established:
            if conn_error is None:
                # No error when connection shuts down gracefully (recv() returns
                # 0 bytes), but we need to display one anyway. Is this is the best fit?
                conn_error = self.ERROR_NOT_CONNECTED

            self._connect_error(conn_error, conn)

        if conn.sock is not None:
            self._close_connection(conn)

    def _process_ready_output_socket(self, sock, current_time):

        if sock in self._conns:
            conn = self._conns[sock]
        else:
            # Unknown connection
            return

        if not conn.is_established:
            if conn is self._server_conn:
                self._establish_outgoing_server_connection(conn)
            else:
                self._establish_outgoing_peer_connection(conn)

            if sock not in self._conns:
                # Connection was closed while being established
                return

        if (self._upload_limit_split
                and conn in self._conns_uploaded
                and self._conns_uploaded[conn] >= self._upload_limit_split):
            return

        try:
            if self._write_data(conn, current_time):
                return

        except (OSError, ValueError) as error:
            log.add_conn("Cannot write data to connection %s, closing connection. Error: %s",
                         (conn.addr, error))

        self._close_connection(conn)

    def _process_ready_sockets(self, current_time):

        if self._listen_socket is None:
            # We can't call select() when no sockets are registered (WinError 10022)
            return

        ready_sockets = self._selector.select(timeout=self.SLEEP_MAX_IDLE)

        for key, io_events in islice(ready_sockets, self.MAX_READY_SOCKETS_PER_CYCLE):
            sock = key.fileobj

            if io_events & selectors.EVENT_READ:
                if sock is self._listen_socket:
                    self._accept_incoming_peer_connections()
                    continue

                self._process_ready_input_socket(sock, current_time)

            if io_events & selectors.EVENT_WRITE:
                self._process_ready_output_socket(sock, current_time)

    def _process_conn_incoming_messages(self, conn):

        if not conn.in_buffer:
            return

        if conn is self._server_conn:
            self._process_server_input(conn)
            return

        init = conn.init

        if init is None:
            conn.init = init = self._process_peer_init_input(conn)

            if init is None or not conn.in_buffer:
                return

        if init.conn_type == ConnectionType.PEER:
            self._process_peer_input(conn)

        elif init.conn_type == ConnectionType.FILE:
            self._process_file_input(conn)

        elif init.conn_type == ConnectionType.DISTRIBUTED:
            self._process_distrib_input(conn)

        if conn.sock is not None and init.sock is not conn.sock:
            log.add_conn("Received message on secondary connection of type %s to user %s, "
                         "promoting to primary connection", (init.conn_type, init.target_user))
            init.sock = conn.sock

    def _process_outgoing_messages(self, msgs):

        for msg in msgs:
            if not self._should_process_queue:
                return

            msg_type = msg.msg_type
            process_func = None

            if msg_type == MessageType.INIT:
                process_func = self._process_peer_init_output
                sock = msg.sock

            elif msg_type == MessageType.INTERNAL:
                process_func = self._process_internal_messages
                sock = None

            elif msg_type == MessageType.PEER:
                process_func = self._process_peer_output
                sock = msg.sock

                if sock is None:
                    self._send_message_to_peer(msg.username, msg)
                    continue

            elif msg_type == MessageType.DISTRIBUTED:
                process_func = self._process_distrib_output
                sock = msg.sock

            elif msg_type == MessageType.FILE:
                process_func = self._process_file_output
                sock = msg.sock

                if sock is None:
                    self._send_message_to_peer(msg.username, msg)
                    continue

            elif msg_type == MessageType.SERVER:
                process_func = self._process_server_output

                if self._server_conn is None or self._server_conn.sock is None:
                    log.add_conn("Cannot send server message without an active server connection: %s", msg.__class__)
                    self._handle_unsent_server_request(msg)
                    continue

                sock = self._server_conn.sock

            log.add_msg_contents(msg, is_outgoing=True)

            if sock is not None and sock not in self._conns:
                log.add_conn("Cannot send the message over the closed connection: %s %s",
                             (msg.__class__, msg))

                if msg_type == MessageType.PEER:
                    self._handle_unsent_peer_message(msg)
                elif msg_type == MessageType.FILE and msg.__class__ is FileTransferInit:
                    self._handle_unsent_peer_message(msg)
                elif msg_type == MessageType.SERVER:
                    self._handle_unsent_server_request(msg)

                continue

            if process_func is not None:
                result = process_func(msg)

                if result is False and msg_type == MessageType.DISTRIBUTED and sock in self._conns:
                    log.add_conn("Closing distributed connection after lower output failure: %s", msg.__class__)
                    self._close_connection(self._conns[sock])

    def _process_queue_messages(self):

        if not self._message_queue:
            return

        msgs = []
        num_heavy_msgs = 0

        while self._message_queue and len(msgs) < self.MAX_QUEUED_MESSAGES_PER_CYCLE:
            msg = self._message_queue[0]

            if self._is_heavy_outgoing_network_message(msg):
                if num_heavy_msgs >= self.MAX_HEAVY_OUTGOING_MESSAGES_PER_CYCLE:
                    break

                num_heavy_msgs += 1

            msg = self._pop_network_message_queue()
            msgs.append(msg)

            if self._is_transfer_network_message(msg):
                self._pending_transfer_network_messages = max(
                    0, getattr(self, "_pending_transfer_network_messages", 0) - 1)

        if not msgs:
            return

        self._process_outgoing_messages(msgs)

        if self._dropped_network_messages and len(self._message_queue) < (self.MAX_PENDING_NETWORK_MESSAGES // 2):
            log.add_conn("Dropped %(num)d non-critical outgoing network messages while the "
                         "pending queue was full", {"num": self._dropped_network_messages})
            self._dropped_network_messages = 0

        dropped_transfer_messages = getattr(self, "_dropped_transfer_network_messages", 0)
        pending_transfer_messages = getattr(self, "_pending_transfer_network_messages", 0)

        if (dropped_transfer_messages
                and pending_transfer_messages < (self.MAX_PENDING_TRANSFER_NETWORK_MESSAGES // 2)):
            log.add_conn("Dropped %(num)d transfer/file network messages while the "
                         "pending transfer queue was full", {"num": dropped_transfer_messages})
            self._dropped_transfer_network_messages = 0

    def _get_file_download_recv_size(self, conn, current_recv_size):
        """Return a bounded recv size for file downloads in the current network cycle."""

        file_download = self._file_download_msgs.get(conn)

        if file_download is None:
            return current_recv_size

        bytes_left = file_download.leftbytes

        if bytes_left is None or bytes_left <= 0:
            return 0

        remaining_cycle_bytes = self.MAX_FILE_DOWNLOAD_WRITE_BYTES_PER_CYCLE - self._file_download_cycle_bytes

        if remaining_cycle_bytes <= 0:
            return 0

        return min(current_recv_size, bytes_left, remaining_cycle_bytes)

    def _read_data(self, conn, current_time):

        sock = conn.sock
        current_recv_size = conn.recv_size
        is_file_download = (conn in self._file_download_msgs)
        use_download_limit = (self._download_limit_split and is_file_download)

        if use_download_limit:
            download_limit = (self._download_limit_split - self._conns_downloaded[conn])

            if download_limit <= 0:
                # Quota for this accounting cycle is exhausted. Avoid recv(0),
                # which looks like EOF and would close the download.
                return True

            if current_recv_size > download_limit:  # pylint: disable=consider-using-min-builtin
                current_recv_size = download_limit

        if is_file_download:
            current_recv_size = self._get_file_download_recv_size(conn, current_recv_size)

            if current_recv_size <= 0:
                # Synchronous file-download writes already consumed this network
                # cycle's budget, or the transfer has no bytes left to read.
                return True

        data = sock.recv(current_recv_size)
        data_len = len(data)

        if not data:
            return False  # Close the connection

        # An intermediate buffer is useless when downloading a file. Write to the
        # file immediately, and let the OS handle buffering when necessary.
        if not is_file_download:
            if not self._append_incoming_data(conn, data, data_len):
                return False  # Close the connection

        else:
            self._file_download_cycle_bytes += data_len

            if not self._process_download(conn, data, data_len):
                return False  # Close the connection

        if use_download_limit:
            self._conns_downloaded[conn] += data_len

        # Grow or shrink recv buffer depending on how much data we're receiving
        elif data_len >= current_recv_size // 2:
            conn.recv_size = min(conn.recv_size * 2, self.MAX_SOCKET_RECV_SIZE)

        elif data_len <= current_recv_size // 6:
            conn.recv_size = max(conn.recv_size // 2, self.MIN_SOCKET_RECV_SIZE)

        conn.last_active = current_time
        return True

    def _write_data(self, conn, current_time):

        sock = conn.sock
        out_buffer = conn.out_buffer
        is_file_upload = (conn in self._file_upload_msgs)

        if is_file_upload and self._upload_limit_split:
            limit = (self._upload_limit_split - self._conns_uploaded[conn])

            if limit <= 0:
                # Quota for this accounting cycle is exhausted. Avoid send(0)
                # and negative slices if the limit changed mid-cycle.
                return True

            if len(out_buffer) > limit:
                num_bytes_sent = sock.send(memoryview(out_buffer)[:limit])
            else:
                num_bytes_sent = sock.send(out_buffer)

            self._conns_uploaded[conn] += num_bytes_sent
        else:
            num_bytes_sent = sock.send(out_buffer)

        if num_bytes_sent <= 0:
            raise OSError("socket returned zero bytes while sending")

        self._release_out_buffer_segments(conn, num_bytes_sent)

        del out_buffer[:num_bytes_sent]

        if is_file_upload and not self._process_upload(conn, num_bytes_sent, current_time):
            return False  # Close the connection

        if not out_buffer:
            # Nothing else to send, stop watching connection for writes
            self._modify_connection_events(conn, selectors.EVENT_READ)

        conn.last_active = current_time
        return True

    # Networking Loop #

    def _loop(self):

        while not self._want_abort:
            current_time = time.monotonic()

            if (current_time - self._last_cycle_time) >= 1:
                self._check_connections(current_time)
                self._check_indirect_request_timeouts(current_time)

                events.emit_main_thread(
                    "set-connection-stats",
                    total_conns=self._num_sockets,
                    download_bandwidth=self._total_download_bandwidth,
                    upload_bandwidth=self._total_upload_bandwidth
                )

                self._conns_downloaded.clear()
                self._conns_uploaded.clear()

                self._total_download_bandwidth = 0
                self._total_upload_bandwidth = 0

                self._last_cycle_time = current_time

            self._process_main_thread_lifecycle_event_retries()

            if not self._should_process_queue:
                if self._server_timeout_time and (self._server_timeout_time - current_time) <= 0:
                    self._server_timeout_time = None
                    events.emit_main_thread(
                        "server-reconnect",
                        ServerReconnect(manual_reconnect=self._manual_server_reconnect)
                    )

                time.sleep(self.SLEEP_MAX_IDLE + self.SLEEP_MIN_IDLE)
                continue

            # Continue processing previously read socket buffers in bounded batches.
            self._process_buffered_conn_messages()

            # Retry tiny server-control messages that failed after local state changed.
            self._process_wait_port_report_retries()
            self._process_cant_connect_to_peer_retries()
            self._process_distributed_server_control_retries()

            # Process queue messages
            self._process_queue_messages()

            # Check which connections are ready to send/receive data
            self._file_download_cycle_bytes = 0
            self._process_ready_sockets(current_time)

            # Don't exhaust the CPU
            time.sleep(self.SLEEP_MIN_IDLE)

    def run(self):

        events.emit_main_thread("set-connection-stats")

        # Watch sockets for I/0 readiness with the selectors module. Only call register() after a socket
        # is bound, otherwise watching the socket not guaranteed to work (breaks on OpenBSD at least)
        self._selector = selectors.DefaultSelector()

        try:
            self._loop()

        finally:
            # Networking thread aborted
            self._manual_server_disconnect = True
            self._close_connection(self._server_conn)
            self._selector.close()

            # We're ready to quit
            events.emit_main_thread("quit")
