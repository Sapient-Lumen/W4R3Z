# COPYRIGHT (C) 2020-2025 Nicotine+ Contributors
# COPYRIGHT (C) 2016-2017 Michael Labouebe <gfarmerfr@free.fr>
# COPYRIGHT (C) 2016 Mutnick <muhing@yahoo.com>
# COPYRIGHT (C) 2013 eLvErDe <gandalf@le-vert.net>
# COPYRIGHT (C) 2008-2012 quinox <quinox@users.sf.net>
# COPYRIGHT (C) 2009 hedonist <ak@sensi.org>
# COPYRIGHT (C) 2006-2009 daelstorm <daelstorm@gmail.com>
# COPYRIGHT (C) 2003-2004 Hyriand <hyriand@thegraveyard.org>
# COPYRIGHT (C) 2001-2003 Alexander Kanavin
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import json
import os
import time

from collections import defaultdict, deque
from math import isfinite
from os.path import normpath

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.slskmessages import CloseConnection
from pynicotine.slskmessages import FileAttribute
from pynicotine.slskmessages import UploadDenied
from pynicotine.utils import UINT32_LIMIT
from pynicotine.utils import UINT64_LIMIT
from pynicotine.utils import encode_path
from pynicotine.utils import load_file
from pynicotine.utils import write_file_and_backup


class TransferStatus:
    QUEUED = "Queued"
    GETTING_STATUS = "Getting status"
    TRANSFERRING = "Transferring"
    PAUSED = "Paused"
    CANCELLED = "Cancelled"
    FILTERED = "Filtered"
    FINISHED = "Finished"
    USER_LOGGED_OFF = "User logged off"
    CONNECTION_CLOSED = "Connection closed"
    CONNECTION_TIMEOUT = "Connection timeout"
    DOWNLOAD_FOLDER_ERROR = "Download folder error"
    LOCAL_FILE_ERROR = "Local file error"


class Transfer:
    """This class holds information about a single transfer."""

    __slots__ = ("sock", "username", "virtual_path",
                 "folder_path", "token", "size", "file_handle", "start_time",
                 "current_byte_offset", "last_byte_offset", "transferred_bytes_total",
                 "speed", "avg_speed", "time_elapsed", "time_left", "modifier",
                 "queue_position", "file_attributes", "iterator", "status",
                 "legacy_attempt", "retry_attempt", "size_changed", "request_timer_id")

    def __init__(self, username, virtual_path=None, folder_path=None, size=0, file_attributes=None,
                 status=None, current_byte_offset=None):
        self.username = username
        self.virtual_path = virtual_path
        self.folder_path = folder_path
        self.size = size
        self.status = status
        self.current_byte_offset = current_byte_offset
        self.file_attributes = file_attributes

        self.sock = None
        self.file_handle = None
        self.token = None
        self.queue_position = 0
        self.modifier = None
        self.request_timer_id = None
        self.start_time = None
        self.last_byte_offset = None
        self.transferred_bytes_total = 0
        self.speed = 0
        self.avg_speed = 0
        self.time_elapsed = 0
        self.time_left = 0
        self.iterator = None
        self.legacy_attempt = False
        self.retry_attempt = False
        self.size_changed = False

        if file_attributes is None:
            self.file_attributes = {}


class Transfers:
    MAX_SERVER_DISCONNECT_ABORTS_PER_TICK = 1000
    MAX_SERVER_LOGIN_WATCH_USERS_PER_TICK = 1000
    SERVER_LOGIN_WATCH_RETRY_DELAY = 1
    MAX_TRANSFER_LIST_JSON_LOAD_BYTES = 16 * 1024 * 1024
    MAX_TRANSFER_LIST_JSON_ROW_BYTES = 1024 * 1024
    MAX_LEGACY_TRANSFER_FILE_BYTES = 16 * 1024 * 1024
    MAX_STORED_TRANSFER_USERNAME_CHARS = 128
    MAX_STORED_TRANSFER_PATH_CHARS = 4096
    MAX_STORED_TRANSFER_FOLDER_PATH_CHARS = 4096
    MAX_STORED_TRANSFER_ATTRIBUTE_ITEMS = 64
    MAX_STORED_TRANSFER_ATTRIBUTE_LITERAL_CHARS = 8192

    __slots__ = ("transfers", "queued_transfers", "queued_users", "active_users",
                 "failed_users", "transfers_file_path", "total_bandwidth", "_name",
                 "_allow_saving_transfers", "_online_users", "_user_queue_limits",
                 "_user_queue_sizes", "_transfers_dirty",
                 "_server_disconnect_abort_queue", "_server_disconnect_abort_ids",
                 "_server_disconnect_abort_timer_id", "_server_disconnect_failed_user_counts",
                 "_server_disconnect_transfer_sources", "_server_login_watch_queue",
                 "_server_login_watch_users", "_server_login_watch_timer_id",
                 "_server_login_watch_remaining")

    def __init__(self, name):

        self.transfers = {}
        self.queued_transfers = {}
        self.queued_users = defaultdict(dict)
        self.active_users = defaultdict(dict)
        self.failed_users = defaultdict(dict)
        self.transfers_file_path = os.path.join(config.data_folder_path, f"{name}.json")
        self.total_bandwidth = 0

        self._name = name
        self._allow_saving_transfers = False
        self._online_users = set()
        self._user_queue_limits = defaultdict(int)
        self._user_queue_sizes = defaultdict(int)
        self._transfers_dirty = False
        self._server_disconnect_abort_queue = deque()
        self._server_disconnect_abort_ids = set()
        self._server_disconnect_abort_timer_id = None
        self._server_disconnect_failed_user_counts = deque()
        self._server_disconnect_transfer_sources = deque()
        self._server_login_watch_queue = deque()
        self._server_login_watch_users = set()
        self._server_login_watch_timer_id = None
        self._server_login_watch_remaining = 0

        for event_name, callback in (
            ("quit", self._quit),
            ("server-login", self._server_login),
            ("server-disconnect", self._server_disconnect),
            ("start", self._start)
        ):
            events.connect(event_name, callback)

    def _start(self):

        self._load_transfers()
        self._transfers_dirty = False
        self._allow_saving_transfers = True

        # Save list of transfers every 3 minutes
        events.schedule(delay=180, callback=self._save_transfers, repeat=True)

        self.update_transfer_limits()

    def _quit(self):

        self._cancel_server_disconnect_abort_queue()
        self._cancel_server_login_watch_queue()
        self._save_transfers(force=True)
        self._allow_saving_transfers = False

        self.transfers.clear()
        self.failed_users.clear()

    def _server_login(self, msg):

        if not msg.success:
            return

        # Watch transfers for user status updates. Large transfer lists can
        # contain many failed users after reconnect/startup, so avoid turning
        # one server-login callback into thousands of WatchUser messages and
        # status-request side effects in one main-loop turn. The count-based
        # cursor also avoids materializing every failed username in a second
        # queue before batching begins.
        self._server_login_watch_remaining = len(self.failed_users)
        self._process_server_login_watches()

        self.update_transfer_limits()

    def _queue_server_login_watches(self, usernames):

        for username in usernames:
            if username in self._server_login_watch_users:
                continue

            self._server_login_watch_users.add(username)
            self._server_login_watch_queue.append(username)

    def _cancel_server_login_watch_queue(self):

        if self._server_login_watch_timer_id is not None:
            events.cancel_scheduled(self._server_login_watch_timer_id)
            self._server_login_watch_timer_id = None

        self._server_login_watch_queue.clear()
        self._server_login_watch_users.clear()
        self._server_login_watch_remaining = 0

    def _schedule_server_login_watches(self, delay=0):

        if (not self._server_login_watch_remaining
                or self._server_login_watch_timer_id is not None):
            return

        self._server_login_watch_timer_id = events.schedule(
            delay=delay, callback=self._process_server_login_watches)

    def _process_server_login_watches(self):

        self._server_login_watch_timer_id = None
        num_processed = 0

        while (self._server_login_watch_remaining
                and num_processed < self.MAX_SERVER_LOGIN_WATCH_USERS_PER_TICK):
            if not self.failed_users:
                self._server_login_watch_remaining = 0
                break

            username = next(iter(self.failed_users))
            failed_transfers = self.failed_users.pop(username)
            self.failed_users[username] = failed_transfers

            if not failed_transfers:
                self._server_login_watch_remaining -= 1
                continue

            if core.users.watch_user(username, context=self._name) is False:
                # If WatchUser() could not enter the server-output queue, keep
                # this failed-user replay cursor at the same logical item and
                # retry later. Otherwise reconnect/startup can silently drop
                # status watches for failed transfers, leaving them stale until
                # the next full reconnect.
                if getattr(core.users, "last_watch_failure_retryable", False):
                    self._schedule_server_login_watches(delay=self.SERVER_LOGIN_WATCH_RETRY_DELAY)
                    return

            self._server_login_watch_remaining -= 1
            num_processed += 1

        if self._server_login_watch_remaining:
            self._schedule_server_login_watches()
        else:
            self._server_login_watch_users.clear()

    def _server_disconnect(self, _msg):

        self._cancel_server_login_watch_queue()

        # Do not snapshot/queue every transfer before batching. A huge transfer
        # list should not pay the full enumeration cost in one disconnect
        # callback just to defer the actual abort work.
        self._server_disconnect_failed_user_counts = deque(
            (username, len(failed_transfers))
            for username, failed_transfers in self.failed_users.items()
            if failed_transfers
        )
        self._server_disconnect_transfer_sources = deque(
            users for users in (self.queued_users, self.active_users) if users
        )

        self._online_users.clear()
        self._user_queue_limits.clear()
        self.total_bandwidth = 0

        # Process the first batch immediately so small transfer lists preserve
        # the old synchronous behavior, but large lists continue in later main
        # loop ticks instead of freezing the UI/network callback.
        self._process_server_disconnect_aborts()

    def _queue_server_disconnect_abort(self, transfer):

        transfer_id = id(transfer)

        if transfer_id in self._server_disconnect_abort_ids:
            return

        self._server_disconnect_abort_ids.add(transfer_id)
        self._server_disconnect_abort_queue.append(transfer)

    def _cancel_server_disconnect_abort_queue(self):

        if self._server_disconnect_abort_timer_id is not None:
            events.cancel_scheduled(self._server_disconnect_abort_timer_id)
            self._server_disconnect_abort_timer_id = None

        self._server_disconnect_abort_queue.clear()
        self._server_disconnect_abort_ids.clear()
        self._server_disconnect_failed_user_counts.clear()
        self._server_disconnect_transfer_sources.clear()

    def _get_next_server_disconnect_transfer(self):

        while self._server_disconnect_transfer_sources:
            users = self._server_disconnect_transfer_sources[0]

            if not users:
                self._server_disconnect_transfer_sources.popleft()
                continue

            username, transfers = next(iter(users.items()))

            if not transfers:
                users.pop(username, None)
                continue

            return next(iter(transfers.values()))

        return None

    def _process_server_disconnect_failed_status(self, aborted_transfers, max_transfers):

        while (self._server_disconnect_failed_user_counts
                and len(aborted_transfers) < max_transfers):
            username, remaining_count = self._server_disconnect_failed_user_counts[0]
            failed_transfers = self.failed_users.get(username)

            if not failed_transfers or remaining_count <= 0:
                self._server_disconnect_failed_user_counts.popleft()
                continue

            virtual_path, transfer = next(iter(failed_transfers.items()))

            # Rotate the entry to the end of the user's failed-transfer mapping
            # so the next batch can continue without rescanning all previously
            # handled entries or building a list of every failed transfer.
            failed_transfers.pop(virtual_path, None)
            failed_transfers[virtual_path] = transfer

            transfer.status = TransferStatus.USER_LOGGED_OFF
            self._mark_transfers_dirty()
            aborted_transfers.append(transfer)

            remaining_count -= 1

            if remaining_count <= 0:
                self._server_disconnect_failed_user_counts.popleft()
            else:
                self._server_disconnect_failed_user_counts[0] = (username, remaining_count)

    def _schedule_server_disconnect_aborts(self):

        if (not (self._server_disconnect_failed_user_counts or self._server_disconnect_transfer_sources)
                or self._server_disconnect_abort_timer_id is not None):
            return

        self._server_disconnect_abort_timer_id = events.schedule(
            delay=0, callback=self._process_server_disconnect_aborts)

    def _process_server_disconnect_aborts(self):

        self._server_disconnect_abort_timer_id = None
        aborted_transfers = []
        max_transfers = self.MAX_SERVER_DISCONNECT_ABORTS_PER_TICK

        # Failed transfers are already inactive, so updating their status in
        # bounded chunks is enough; routing them through _abort_transfer() would
        # remove and reinsert them into the same failed map and would require a
        # large snapshot to avoid seeing the same entry forever.
        self._process_server_disconnect_failed_status(aborted_transfers, max_transfers)

        while len(aborted_transfers) < max_transfers:
            transfer = self._get_next_server_disconnect_transfer()

            if transfer is None:
                break

            if self.get_transfer(transfer.username, transfer.virtual_path) is not transfer:
                self._deactivate_transfer(transfer)
                self._dequeue_transfer(transfer)
                continue

            self._abort_transfer(
                transfer, status=TransferStatus.USER_LOGGED_OFF, update_parent=False)
            aborted_transfers.append(transfer)

        if aborted_transfers:
            self._emit_batched_aborted_transfers(aborted_transfers, TransferStatus.USER_LOGGED_OFF)

        if self._server_disconnect_failed_user_counts or self._server_disconnect_transfer_sources:
            self._schedule_server_disconnect_aborts()
        else:
            self._server_disconnect_abort_ids.clear()

    # Load Transfers #

    @classmethod
    def _iter_transfer_json_rows(cls, transfers_file):
        """Stream transfer rows from the JSON list format written by _save_transfers_callback.

        Older hardening streamed newline-separated rows, but a minified large
        transfer file can be one giant line. Use JSONDecoder.raw_decode() so we
        yield one top-level array item at a time without json.load() and without
        requiring line boundaries between rows.
        """

        decoder = json.JSONDecoder()
        buffer = ""
        pos = 0
        eof = False
        chunk_size = 64 * 1024

        def read_more():
            nonlocal buffer, eof

            if eof:
                return

            chunk = handle.read(chunk_size)

            if chunk == "":
                eof = True
                return

            buffer += chunk

            if len(buffer.encode("utf-8", "surrogatepass")) > cls.MAX_TRANSFER_LIST_JSON_ROW_BYTES:
                raise ValueError("transfer row exceeds gross JSON row size limit")

        def compact_buffer():
            nonlocal buffer, pos

            if pos < chunk_size:
                return

            buffer = buffer[pos:]
            pos = 0

        def skip_whitespace():
            nonlocal pos

            while True:
                while pos < len(buffer) and buffer[pos].isspace():
                    pos += 1

                if pos < len(buffer) or eof:
                    return

                compact_buffer()
                read_more()

        with open(transfers_file, encoding="utf-8") as handle:
            read_more()
            skip_whitespace()

            if pos >= len(buffer) or buffer[pos] != "[":
                raise ValueError("transfer list JSON must start with an array")

            pos += 1

            while True:
                compact_buffer()
                skip_whitespace()

                if pos >= len(buffer):
                    raise ValueError("unexpected end of transfer list JSON")

                if buffer[pos] == "]":
                    pos += 1
                    skip_whitespace()

                    if pos < len(buffer):
                        raise ValueError("unexpected trailing data in transfer list JSON")

                    return

                item_start = pos

                while True:
                    try:
                        item, pos = decoder.raw_decode(buffer, pos)
                        break

                    except json.JSONDecodeError:
                        if eof:
                            raise

                        read_more()

                        if len(buffer[item_start:].encode("utf-8", "surrogatepass")) > cls.MAX_TRANSFER_LIST_JSON_ROW_BYTES:
                            raise ValueError("transfer row exceeds gross JSON row size limit")

                if len(buffer[item_start:pos].encode("utf-8", "surrogatepass")) > cls.MAX_TRANSFER_LIST_JSON_ROW_BYTES:
                    raise ValueError("transfer row exceeds gross JSON row size limit")

                yield item

                compact_buffer()
                skip_whitespace()

                if pos >= len(buffer):
                    raise ValueError("unexpected end of transfer list JSON after row")

                if buffer[pos] == ",":
                    pos += 1
                    continue

                if buffer[pos] == "]":
                    pos += 1
                    skip_whitespace()

                    if pos < len(buffer):
                        raise ValueError("unexpected trailing data in transfer list JSON")

                    return

                raise ValueError("expected ',' or ']' in transfer list JSON")

    @staticmethod
    def _load_transfers_file(transfers_file):
        """Loads a file of transfers in json format."""

        transfers_file = encode_path(transfers_file)

        if not os.path.isfile(transfers_file):
            return None

        if os.path.getsize(transfers_file) > Transfers.MAX_TRANSFER_LIST_JSON_LOAD_BYTES:
            return Transfers._iter_transfer_json_rows(transfers_file)

        with open(transfers_file, encoding="utf-8") as handle:
            return json.load(handle)

    @staticmethod
    def _load_legacy_transfers_file(transfers_file):
        """Loads a download queue file in pickle format (legacy)"""

        transfers_file = encode_path(transfers_file)

        if not os.path.isfile(transfers_file):
            return None

        if os.path.getsize(transfers_file) > Transfers.MAX_LEGACY_TRANSFER_FILE_BYTES:
            raise ValueError("legacy transfer file exceeds maximum size")

        with open(transfers_file, "rb") as handle:
            from pynicotine.shares import RestrictedUnpickler
            return RestrictedUnpickler(handle, encoding="utf-8").load()

    def _load_transfers(self):
        raise NotImplementedError

    @staticmethod
    def _load_uint(value, default=0, maximum=UINT64_LIMIT):
        """Return a finite non-negative integer loaded from persisted state."""

        try:
            if isinstance(value, bool):
                return default

            if isinstance(value, float) and not isfinite(value):
                return default

            value = int(value)

        except (OverflowError, TypeError, ValueError):
            return default

        if value < 0:
            return default

        return min(value, maximum)

    @classmethod
    def _load_file_attributes(cls, num_attributes, transfer_row):

        if num_attributes < 7:
            return None

        loaded_file_attributes = transfer_row[6]

        if not loaded_file_attributes:
            return None

        if isinstance(loaded_file_attributes, dict):
            try:
                # Found dictionary with file attributes (Nicotine+ >=3.3.0).
                # JSON stores file attribute types as strings, convert them back to integers.
                return {
                    int(k): cls._load_uint(v, default=0, maximum=UINT32_LIMIT)
                    for k, v in list(loaded_file_attributes.items())[:cls.MAX_STORED_TRANSFER_ATTRIBUTE_ITEMS]
                }

            except (TypeError, ValueError):
                return None

        try:
            # Check if a dictionary is represented in string format. Keep this
            # legacy convenience path bounded: transfer lists are persisted
            # files, and a corrupted/external row should not spend unbounded
            # parser resources before falling back to legacy bitrate strings.
            if (isinstance(loaded_file_attributes, str)
                    and len(loaded_file_attributes) <= cls.MAX_STORED_TRANSFER_ATTRIBUTE_LITERAL_CHARS):
                loaded_attrs = config._literal_eval_config_value(loaded_file_attributes)  # pylint: disable=protected-access

                if isinstance(loaded_attrs, dict):
                    return {
                        int(k): cls._load_uint(v, default=0, maximum=UINT32_LIMIT)
                        for k, v in list(loaded_attrs.items())[:cls.MAX_STORED_TRANSFER_ATTRIBUTE_ITEMS]
                    }

        except (AttributeError, SyntaxError, TypeError, ValueError):
            pass

        # Legacy bitrate/duration strings (Nicotine+ <3.3.0)
        file_attributes = {}
        bitrate = str(loaded_file_attributes)
        is_vbr = (" (vbr)" in bitrate)

        try:
            loaded_bitrate = int(bitrate.replace(" (vbr)", ""))

            if 0 < loaded_bitrate <= UINT32_LIMIT:
                file_attributes[FileAttribute.BITRATE] = loaded_bitrate

                if is_vbr:
                    file_attributes[FileAttribute.VBR] = int(is_vbr)

        except ValueError:
            # No valid bitrate value found
            pass

        if num_attributes < 8:
            return file_attributes

        loaded_length = str(transfer_row[7])

        if ":" not in loaded_length:
            return file_attributes

        # Convert HH:mm:ss to seconds
        seconds = 0

        try:
            for part in loaded_length.split(":"):
                seconds = seconds * 60 + int(part, 10)

        except ValueError:
            return file_attributes

        if 0 <= seconds <= UINT32_LIMIT:
            file_attributes[FileAttribute.DURATION] = seconds

        return file_attributes

    def _get_stored_transfers(self, transfers_file_path, load_func, load_only_finished=False):

        transfer_rows = load_file(transfers_file_path, load_func)

        if not transfer_rows:
            return

        allowed_statuses = {TransferStatus.PAUSED, TransferStatus.FILTERED, TransferStatus.FINISHED}
        normalized_paths = {}

        for transfer_row in transfer_rows:
            num_attributes = len(transfer_row)

            if num_attributes < 3:
                continue

            # Username / virtual path / folder path. Saved transfer files are local state,
            # but they can become very large/corrupt over years of use or after external edits.
            # Reject gross strings before they hit transfer dictionaries and GTK uint/string columns.
            username = transfer_row[0]

            if not isinstance(username, str) or len(username) > self.MAX_STORED_TRANSFER_USERNAME_CHARS:
                continue

            virtual_path = transfer_row[1]

            if not isinstance(virtual_path, str) or len(virtual_path) > self.MAX_STORED_TRANSFER_PATH_CHARS:
                continue

            folder_path = transfer_row[2]

            if (not isinstance(folder_path, str)
                    or len(folder_path) > self.MAX_STORED_TRANSFER_FOLDER_PATH_CHARS):
                continue

            if folder_path:
                # Normalize and cache path
                if folder_path not in normalized_paths:
                    folder_path = normalized_paths[folder_path] = normpath(folder_path)
                else:
                    folder_path = normalized_paths[folder_path]

            # Status
            status = TransferStatus.USER_LOGGED_OFF

            if num_attributes >= 4:
                status = transfer_row[3]

            if status == "Aborted":
                status = TransferStatus.PAUSED

            if load_only_finished and status != TransferStatus.FINISHED:
                continue

            if status not in allowed_statuses:
                status = TransferStatus.USER_LOGGED_OFF

            # Size / offset
            size = 0
            current_byte_offset = None

            if num_attributes >= 5:
                size = self._load_uint(transfer_row[4], default=0)

            if num_attributes >= 6:
                current_byte_offset = self._load_uint(transfer_row[5], default=None)

                if current_byte_offset is not None and current_byte_offset > size:
                    current_byte_offset = size

            # File attributes
            file_attributes = self._load_file_attributes(num_attributes, transfer_row)

            yield (
                Transfer(
                    username, virtual_path, folder_path, size, file_attributes, status,
                    current_byte_offset
                )
            )

    # File Actions #

    @staticmethod
    def _close_file(transfer):

        file_handle = transfer.file_handle
        transfer.file_handle = None

        if file_handle is None:
            return

        try:
            file_handle.close()

        except Exception as error:
            file_path = file_handle.name.decode("utf-8", "replace")
            log.add_transfer("Failed to close file %s: %s", (file_path, error))

    # User Actions #

    def _unwatch_stale_user(self, username):
        """Unwatches a user when status updates are no longer required, i.e.
        no transfers remain, or all remaining transfers are
        finished/filtered/paused.
        """

        for users in (self.active_users, self.queued_users, self.failed_users):
            if username in users:
                return

        core.users.unwatch_user(username, context=self._name)

    def _send_upload_denied_message(self, username, virtual_path, denied_message):
        return core.send_message_to_peer(
            username, UploadDenied(virtual_path, denied_message))

    # Limits #

    def update_transfer_limits(self):
        raise NotImplementedError

    # Events #

    def _transfer_timeout(self, transfer):
        self._abort_transfer(transfer, status=TransferStatus.CONNECTION_TIMEOUT)

    # Transfer Actions #

    @staticmethod
    def _get_transfer_key(username, virtual_path):
        return (username, virtual_path)

    def get_transfer(self, username, virtual_path):
        return self.transfers.get(self._get_transfer_key(username, virtual_path))

    def _mark_transfers_dirty(self):
        self._transfers_dirty = True

    def _append_transfer(self, transfer):
        self.transfers[self._get_transfer_key(transfer.username, transfer.virtual_path)] = transfer
        self._mark_transfers_dirty()

    def _emit_batched_aborted_transfers(self, transfers, status):
        """Optional subclass hook used after large disconnect abort batches."""

    def _abort_transfer(self, transfer, status=None, denied_message=None, update_parent=True):

        username = transfer.username
        virtual_path = transfer.virtual_path

        transfer.legacy_attempt = False
        transfer.size_changed = False

        # Reset last byte offset to avoid incorrect offset subtractions between
        # previous and new transfer sessions when updating statistics
        transfer.last_byte_offset = None

        if transfer.sock is not None:
            core.send_message_to_network_thread(CloseConnection(transfer.sock))

        if transfer.file_handle is not None:
            self._close_file(transfer)

        elif denied_message and virtual_path in self.queued_users.get(username, {}):
            self._send_upload_denied_message(username, virtual_path, denied_message)

        self._deactivate_transfer(transfer)
        self._dequeue_transfer(transfer)
        self._unfail_transfer(transfer)

        if status:
            transfer.status = status

            if status not in {TransferStatus.FINISHED, TransferStatus.FILTERED, TransferStatus.PAUSED}:
                self._fail_transfer(transfer)

        self._mark_transfers_dirty()

        # Only attempt to unwatch user after the transfer status is fully set
        self._unwatch_stale_user(username)

    def _update_transfer(self, transfer):
        raise NotImplementedError

    def _update_transfer_progress(self, transfer, stat_id, current_byte_offset=None, speed=None):

        size = transfer.size

        transfer.status = TransferStatus.TRANSFERRING
        transfer.time_elapsed = time_elapsed = (time.monotonic() - transfer.start_time)
        transfer.time_left = 0

        if current_byte_offset is None:
            return

        if transfer.current_byte_offset != current_byte_offset:
            self._mark_transfers_dirty()

        transfer.current_byte_offset = current_byte_offset
        transferred_fragment_size = current_byte_offset - transfer.last_byte_offset
        transfer.last_byte_offset = current_byte_offset

        if transferred_fragment_size > 0:
            transfer.transferred_bytes_total += transferred_fragment_size
            core.statistics.append_stat_value(stat_id, transferred_fragment_size)

        transfer.avg_speed = max(0, int(transfer.transferred_bytes_total // max(1, time_elapsed)))

        if speed is not None:
            if speed <= 0:
                transfer.speed = transfer.avg_speed
            else:
                transfer.speed = speed

        if transfer.speed > 0 and size > current_byte_offset:
            transfer.time_left = (size - current_byte_offset) // transfer.speed

    def _finish_transfer(self, transfer):

        self._deactivate_transfer(transfer)
        self._close_file(transfer)
        self._unwatch_stale_user(transfer.username)

        transfer.status = TransferStatus.FINISHED
        transfer.current_byte_offset = transfer.size
        transfer.last_byte_offset = None
        self._mark_transfers_dirty()

    def _auto_clear_transfer(self, transfer):

        if config.sections["transfers"][f"autoclear_{self._name}"]:
            self._clear_transfer(transfer)
            return True

        return False

    def _clear_transfer(self, transfer, denied_message=None):
        self._abort_transfer(transfer, denied_message=denied_message)
        del self.transfers[self._get_transfer_key(transfer.username, transfer.virtual_path)]
        self._mark_transfers_dirty()

    def _enqueue_transfer(self, transfer):

        core.users.watch_user(transfer.username, context=self._name)

        transfer.status = TransferStatus.QUEUED

        self.queued_users[transfer.username][transfer.virtual_path] = transfer
        self.queued_transfers[transfer] = None
        self._user_queue_sizes[transfer.username] += transfer.size
        self._mark_transfers_dirty()

        return True

    def _enqueue_limited_transfers(self, username):
        # Optional method
        pass

    def _dequeue_transfer(self, transfer):

        username = transfer.username
        virtual_path = transfer.virtual_path

        if virtual_path not in self.queued_users.get(username, {}):
            return False

        self._user_queue_sizes[username] -= transfer.size
        del self.queued_transfers[transfer]
        del self.queued_users[username][virtual_path]

        if self._user_queue_sizes[username] <= 0:
            del self._user_queue_sizes[username]

        if not self.queued_users[username]:
            del self.queued_users[username]

            # No more queued transfers, resume limited transfers if present
            self._enqueue_limited_transfers(username)

        transfer.queue_position = 0
        self._mark_transfers_dirty()
        return True

    def _is_active_transfer_token_available(self, username, token, transfer=None):
        active_transfer = self.active_users.get(username, {}).get(token)

        if active_transfer is None or active_transfer is transfer:
            return True

        log.add_transfer(
            "Refusing to activate transfer for user %s with duplicate active token %s. "
            "Existing file: %s, new file: %s", (
                username, token, active_transfer.virtual_path,
                getattr(transfer, "virtual_path", None)
            )
        )
        return False

    def _activate_transfer(self, transfer, token):

        if not self._is_active_transfer_token_available(transfer.username, token, transfer):
            return False

        core.users.watch_user(transfer.username, context=self._name)

        transfer.status = TransferStatus.GETTING_STATUS
        transfer.token = token
        transfer.speed = transfer.avg_speed = 0
        transfer.queue_position = 0

        # When our port is closed, certain clients can take up to ~30 seconds before they
        # initiate a 'F' connection, since they only send an indirect connection request after
        # attempting to connect to our port for a certain time period.
        # Known clients: Nicotine+ 2.2.0 - 3.2.0, 2 s; Soulseek NS, ~20 s; soulseeX, ~30 s.
        # To account for potential delays while initializing the connection, add 15 seconds
        # to the timeout value.

        transfer.request_timer_id = events.schedule(
            delay=45, callback=self._transfer_timeout, callback_args=(transfer,))

        self.active_users[transfer.username][token] = transfer
        self._mark_transfers_dirty()
        return True

    def _deactivate_transfer(self, transfer):

        username = transfer.username
        token = transfer.token

        if token is None or token not in self.active_users.get(username, {}):
            return False

        del self.active_users[username][token]

        if not self.active_users[username]:
            del self.active_users[username]

        if transfer.speed > 0:
            self.total_bandwidth = max(0, self.total_bandwidth - transfer.speed)

        if transfer.request_timer_id is not None:
            events.cancel_scheduled(transfer.request_timer_id)
            transfer.request_timer_id = None

        transfer.speed = transfer.avg_speed
        transfer.sock = None
        transfer.token = None
        self._mark_transfers_dirty()

        return True

    def _fail_transfer(self, transfer):
        self.failed_users[transfer.username][transfer.virtual_path] = transfer
        self._mark_transfers_dirty()

    def _unfail_transfer(self, transfer):

        username = transfer.username
        virtual_path = transfer.virtual_path

        if virtual_path not in self.failed_users.get(username, {}):
            return False

        del self.failed_users[username][virtual_path]

        if not self.failed_users[username]:
            del self.failed_users[username]

        self._mark_transfers_dirty()
        return True

    # Saving #

    def _iter_transfer_rows(self):
        """Get a list of transfers to dump to file."""
        for transfer in self.transfers.values():
            yield [
                transfer.username, transfer.virtual_path, transfer.folder_path, transfer.status, transfer.size,
                transfer.current_byte_offset, transfer.file_attributes
            ]

    def _save_transfers_callback(self, file_handle):

        # Dump every transfer to the file individually to avoid large memory usage
        json_encoder = json.JSONEncoder(check_circular=False, ensure_ascii=False)
        is_first_item = True

        file_handle.write("[")

        for row in self._iter_transfer_rows():
            if is_first_item:
                is_first_item = False
            else:
                file_handle.write(",\n")

            file_handle.write(json_encoder.encode(row))

        file_handle.write("]")

    def _save_transfers(self, force=False):
        """Save list of transfers."""

        if not self._allow_saving_transfers:
            # Don't save if transfers didn't load properly!
            return

        if not force and not self._transfers_dirty:
            return

        config.create_data_folder()

        if write_file_and_backup(self.transfers_file_path, self._save_transfers_callback):
            self._transfers_dirty = False


class Statistics:
    __slots__ = ("session_stats", "_pending_stat_update_queue", "_pending_stat_update_ids",
                 "_pending_stat_update_timer_id", "_stat_update_limit_logged")

    MAX_STAT_UPDATES_PER_TICK = 32
    MAX_PENDING_STAT_UPDATES = 256

    def __init__(self):

        self.session_stats = {}
        self._pending_stat_update_queue = deque()
        self._pending_stat_update_ids = set()
        self._pending_stat_update_timer_id = None
        self._stat_update_limit_logged = False

        for event_name, callback in (
            ("quit", self._quit),
            ("start", self._start)
        ):
            events.connect(event_name, callback)

    def _start(self):

        # Only populate total since date on first run
        if (not config.sections["statistics"]["since_timestamp"]
                and config.sections["statistics"] == config.defaults["statistics"]):
            config.sections["statistics"]["since_timestamp"] = int(time.time())

        for stat_id in config.defaults["statistics"]:
            self.session_stats[stat_id] = 0 if stat_id != "since_timestamp" else int(time.time())

    def _quit(self):
        self._cancel_pending_stat_updates()
        self.session_stats.clear()

    def append_stat_value(self, stat_id, stat_value):

        self.session_stats[stat_id] += stat_value
        config.sections["statistics"][stat_id] += stat_value

        self._queue_stat_update(stat_id)

    def _cancel_pending_stat_updates(self):

        if self._pending_stat_update_timer_id is not None:
            events.cancel_scheduled(self._pending_stat_update_timer_id)
            self._pending_stat_update_timer_id = None

        self._pending_stat_update_queue.clear()
        self._pending_stat_update_ids.clear()
        self._stat_update_limit_logged = False

    def _schedule_stat_updates(self):

        if self._pending_stat_update_timer_id is not None:
            return

        self._pending_stat_update_timer_id = events.schedule(
            delay=0, callback=self._flush_stat_updates)

    def _queue_stat_update(self, stat_id):

        if stat_id in self._pending_stat_update_ids:
            return

        if len(self._pending_stat_update_queue) >= self.MAX_PENDING_STAT_UPDATES:
            if not self._stat_update_limit_logged:
                log.add_debug("Discarding statistics update event for %s; pending update limit reached.",
                              stat_id)
                self._stat_update_limit_logged = True

            return

        self._pending_stat_update_queue.append(stat_id)
        self._pending_stat_update_ids.add(stat_id)
        self._schedule_stat_updates()

    def _flush_stat_updates(self):

        self._pending_stat_update_timer_id = None
        num_processed = 0

        while self._pending_stat_update_queue and num_processed < self.MAX_STAT_UPDATES_PER_TICK:
            stat_id = self._pending_stat_update_queue.popleft()
            self._pending_stat_update_ids.discard(stat_id)

            if stat_id in self.session_stats:
                self._update_stat(stat_id)

            num_processed += 1

        if self._pending_stat_update_queue:
            self._schedule_stat_updates()
            return

        self._stat_update_limit_logged = False

    def _update_stat(self, stat_id):

        session_stat_value = self.session_stats[stat_id]
        total_stat_value = config.sections["statistics"][stat_id]

        events.emit("update-stat", stat_id, session_stat_value, total_stat_value)

    def update_stats(self):
        self._cancel_pending_stat_updates()

        for stat_id in self.session_stats:
            self._update_stat(stat_id)

    def reset_stats(self):

        for stat_id in config.defaults["statistics"]:
            stat_value = 0 if stat_id != "since_timestamp" else int(time.time())
            self.session_stats[stat_id] = config.sections["statistics"][stat_id] = stat_value

        self.update_stats()
