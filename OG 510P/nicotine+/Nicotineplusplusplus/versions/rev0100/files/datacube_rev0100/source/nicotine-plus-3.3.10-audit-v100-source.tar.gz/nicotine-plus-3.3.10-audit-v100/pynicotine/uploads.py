# COPYRIGHT (C) 2020-2025 Nicotine+ Contributors
# COPYRIGHT (C) 2016-2017 Michael Labouebe <gfarmerfr@free.fr>
# COPYRIGHT (C) 2016 Mutnick <muhing@yahoo.com>
# COPYRIGHT (C) 2013 eLvErDe <gandalf@le-vert.net>
# COPYRIGHT (C) 2008-2012 quinox <quinox@users.sf.net>
# COPYRIGHT (C) 2009 hedonist <ak@sensi.org>
# COPYRIGHT (C) 2006-2009 daelstorm <daelstorm@gmail.com>
# COPYRIGHT (C) 2003-2004 Hyriand <hyriand@thegraveyard.org>
# COPYRIGHT (C) 2001-2003 Alexander Kanavin
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import stat
import time

from collections import defaultdict, deque

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.shares import PermissionLevel
from pynicotine.slskmessages import ConnectionType
from pynicotine.slskmessages import EmitNetworkMessageEvents
from pynicotine.slskmessages import FileTransferInit
from pynicotine.slskmessages import increment_token
from pynicotine.slskmessages import initial_token
from pynicotine.slskmessages import PlaceInQueueResponse
from pynicotine.slskmessages import SendUploadSpeed
from pynicotine.slskmessages import SetUploadLimit
from pynicotine.slskmessages import TransferDirection
from pynicotine.slskmessages import TransferRejectReason
from pynicotine.slskmessages import TransferRequest
from pynicotine.slskmessages import TransferResponse
from pynicotine.slskmessages import UploadDenied
from pynicotine.slskmessages import UploadFailed
from pynicotine.slskmessages import UploadFile
from pynicotine.slskmessages import UserStatus
from pynicotine.transfers import Transfer
from pynicotine.transfers import Transfers
from pynicotine.transfers import TransferStatus
from pynicotine.utils import encode_path


class Uploads(Transfers):
    MAX_PENDING_NETWORK_MESSAGES = 4096
    MAX_PENDING_NETWORK_MESSAGES_PER_READY_TICK = 1000
    PENDING_NETWORK_FLUSH_RETRY_DELAY = 1.0
    MAX_TOTAL_QUEUED_UPLOADS = 100000
    MAX_QUEUE_POSITION_REQUEST_TIMES = 8192
    MAX_QUEUE_POSITION_REQUESTS_PER_INTERVAL = 512
    MAX_QUEUE_POSITION_CACHE_ITEMS = 20000
    MAX_FAILED_UPLOAD_RETRIES_PER_TICK = 1000
    MAX_UPLOAD_QUEUE_VALIDATION_STEPS_PER_TICK = 1000
    MAX_USER_STATUS_UPLOAD_CANCELS_PER_TICK = 1000
    MAX_USER_STATUS_UPLOAD_OFFLINE_ABORTS_PER_TICK = 1000
    MAX_BULK_UPLOAD_ACTIONS_PER_TICK = 1000
    MAX_PENDING_BULK_UPLOAD_ACTIONS = 200000
    MAX_BULK_UPLOAD_SOURCE_SCANS_PER_TICK = 5000
    QUEUE_POSITION_REQUEST_INTERVAL = 1
    MAX_PENDING_UPLOAD_SPEED_REPORTS = 4096
    MAX_UPLOAD_SPEED_REPORTS_PER_TICK = 512
    UPLOAD_SPEED_REPORT_RETRY_DELAY = 1.0
    MAX_PENDING_PEER_TRANSFER_NOTICES = 4096
    MAX_PEER_TRANSFER_NOTICES_PER_TICK = 512
    PEER_TRANSFER_NOTICE_RETRY_DELAY = 1.0

    __slots__ = ("pending_shutdown", "upload_speed", "token", "_queue_positions",
                 "_queue_position_users", "_queue_position_request_times",
                 "_queue_position_request_window_time", "_queue_position_request_window_count",
                 "_privileged_position_requested", "_privileged_queued_users_cache",
                 "_privileged_queued_count_cache", "_pending_network_msgs",
                 "_pending_network_msg_keys", "_pending_network_msgs_limit_logged",
                 "_pending_network_flush_timer_id", "_user_update_counter", "_user_update_counters",
                 "_user_status_cancel_queue", "_user_status_cancel_users",
                 "_user_status_cancel_timer_id",
                 "_user_status_offline_queue", "_user_status_offline_users",
                 "_user_status_offline_timer_id",
                 "_bulk_upload_action_queue", "_bulk_upload_action_timer_id",
                 "_bulk_upload_clear_all_state",
                 "_pending_upload_speed_reports", "_upload_speed_report_timer_id",
                 "_pending_peer_transfer_notices", "_pending_peer_transfer_notice_keys",
                 "_pending_peer_transfer_notices_limit_logged", "_peer_transfer_notice_timer_id",
                 "_upload_queue_timer_id",
                 "_upload_queue_check_timer_id", "_retry_failed_uploads_timer_id",
                 "_retry_failed_uploads_continuation_timer_id")

    def __init__(self):

        super().__init__(name="uploads")

        self.pending_shutdown = False
        self.upload_speed = 0
        self.token = initial_token()

        self._queue_positions = {}
        self._queue_position_users = defaultdict(dict)
        self._queue_position_request_times = {}
        self._queue_position_request_window_time = 0
        self._queue_position_request_window_count = 0
        self._privileged_position_requested = False
        self._privileged_queued_users_cache = None
        self._privileged_queued_count_cache = None
        self._pending_network_msgs = []
        self._pending_network_msg_keys = set()
        self._pending_network_msgs_limit_logged = False
        self._pending_network_flush_timer_id = None
        self._user_update_counter = 0
        self._user_update_counters = {}
        self._user_status_cancel_queue = deque()
        self._user_status_cancel_users = set()
        self._user_status_cancel_timer_id = None
        self._user_status_offline_queue = deque()
        self._user_status_offline_users = set()
        self._user_status_offline_timer_id = None
        self._bulk_upload_action_queue = deque()
        self._bulk_upload_action_timer_id = None
        self._bulk_upload_clear_all_state = None
        self._pending_upload_speed_reports = deque()
        self._upload_speed_report_timer_id = None
        self._pending_peer_transfer_notices = deque()
        self._pending_peer_transfer_notice_keys = set()
        self._pending_peer_transfer_notices_limit_logged = False
        self._peer_transfer_notice_timer_id = None

        self._upload_queue_timer_id = None
        self._upload_queue_check_timer_id = None
        self._retry_failed_uploads_timer_id = None
        self._retry_failed_uploads_continuation_timer_id = None

        for event_name, callback in (
            ("ban-user", self._ban_user),
            ("ban-user-ip", self._ban_user),
            ("file-connection-closed", self._file_connection_closed),
            ("file-transfer-init", self._file_transfer_init),
            ("file-upload-progress", self._file_upload_progress),
            ("peer-connection-closed", self._peer_connection_error),
            ("peer-connection-error", self._peer_connection_error),
            ("peer-message-unsent", self._peer_message_unsent),
            ("place-in-queue-request", self._place_in_queue_request),
            ("privileged-users", self._privileged_users),
            ("queue-upload", self._queue_upload),
            ("set-connection-stats", self._set_connection_stats),
            ("server-message-unsent", self._server_message_unsent),
            ("shares-ready", self._shares_ready),
            ("transfer-request", self._transfer_request),
            ("transfer-response", self._transfer_response),
            ("upload-file-error", self._upload_file_error),
            ("user-stats", self._user_stats),
            ("user-status", self._user_status)
        ):
            events.connect(event_name, callback)

    def _quit(self):

        self._cancel_bulk_upload_actions()
        events.cancel_scheduled(self._peer_transfer_notice_timer_id)
        self._clear_peer_transfer_notices()
        super()._quit()

        self.upload_speed = 0

    def _server_login(self, msg):

        if not msg.success:
            return

        super()._server_login(msg)

        # Check if queued uploads can be started every 10 seconds
        self._upload_queue_timer_id = events.schedule(delay=10, callback=self._check_upload_queue, repeat=True)

        # Re-queue timed out uploads every 3 minutes
        self._retry_failed_uploads_timer_id = events.schedule(
            delay=180, callback=self._retry_failed_uploads, repeat=True)

    def _server_disconnect(self, msg):

        super()._server_disconnect(msg)

        for timer_id in (
            self._upload_queue_timer_id,
            self._upload_queue_check_timer_id,
            self._retry_failed_uploads_timer_id,
            self._retry_failed_uploads_continuation_timer_id,
            self._user_status_cancel_timer_id,
            self._user_status_offline_timer_id,
            self._pending_network_flush_timer_id,
            self._bulk_upload_action_timer_id,
            self._upload_speed_report_timer_id,
            self._peer_transfer_notice_timer_id
        ):
            events.cancel_scheduled(timer_id)

        self._queue_positions.clear()
        self._queue_position_users.clear()
        self._privileged_queued_users_cache = None
        self._queue_position_request_times.clear()
        self._queue_position_request_window_time = 0
        self._queue_position_request_window_count = 0
        self._pending_network_msgs.clear()
        self._pending_network_msg_keys.clear()
        self._pending_network_msgs_limit_logged = False
        self._pending_network_flush_timer_id = None
        self._bulk_upload_action_queue.clear()
        self._bulk_upload_action_timer_id = None
        self._bulk_upload_clear_all_state = None
        self._pending_upload_speed_reports.clear()
        self._upload_speed_report_timer_id = None
        self._clear_peer_transfer_notices()
        self._user_status_cancel_queue.clear()
        self._user_status_cancel_users.clear()
        self._user_status_cancel_timer_id = None
        self._user_status_offline_queue.clear()
        self._user_status_offline_users.clear()
        self._user_status_offline_timer_id = None
        self._upload_queue_check_timer_id = None
        self._retry_failed_uploads_continuation_timer_id = None
        self._user_update_counters.clear()
        self._user_update_counter = 0

        # Quit in case we were waiting for uploads to finish
        self._check_upload_queue()

    # Load Transfers #

    def _load_transfers(self):

        for transfer in self._get_stored_transfers(
                self.transfers_file_path, self._load_transfers_file, load_only_finished=True):
            self._append_transfer(transfer)

    # Privileges #

    def is_privileged(self, username):

        if not username:
            return False

        if username in core.users.privileged:
            return True

        return self.is_buddy_prioritized(username)

    def _invalidate_queue_position_cache(self, username=None):

        self._queue_positions.clear()
        self._privileged_queued_users_cache = None
        self._privileged_queued_count_cache = None

        if username is None:
            self._queue_position_users.clear()
        else:
            self._queue_position_users.pop(username, None)

    @staticmethod
    def _make_queue_position_cache_key(queue_mode, upload):
        return queue_mode, upload.username, upload.virtual_path

    def _cache_queue_position(self, queue_mode, upload, queue_position, user_position=None):
        """Remember bounded queue-position answers between invalidations.

        Queue-position requests are remote-triggered. Earlier hardening removed
        full-map materialization, but repeatedly scanning a 100k-upload queue for
        the same answer is still a gross CPU cliff. Keep a bounded prefix/answer
        cache that is invalidated whenever queued state or privileges change.
        """

        if len(self._queue_positions) < self.MAX_QUEUE_POSITION_CACHE_ITEMS:
            self._queue_positions[self._make_queue_position_cache_key(queue_mode, upload)] = queue_position

        if user_position is not None:
            user_positions = self._queue_position_users[upload.username]

            if len(user_positions) < self.MAX_QUEUE_POSITION_CACHE_ITEMS:
                user_positions[upload.virtual_path] = user_position

    def _get_cached_queue_position(self, queue_mode, upload):
        queue_position = self._queue_positions.get(self._make_queue_position_cache_key(queue_mode, upload))

        if queue_position is not None:
            return queue_position

        return None

    def _get_privileged_queued_users(self):

        if self._privileged_queued_users_cache is None:
            self._privileged_queued_users_cache = {
                username: len(queued_uploads)
                for username, queued_uploads in self.queued_users.items() if self.is_privileged(username)
            }

        return self._privileged_queued_users_cache

    def _get_privileged_queued_count(self):

        if self._privileged_queued_count_cache is None:
            self._privileged_queued_count_cache = sum(self._get_privileged_queued_users().values())

        return self._privileged_queued_count_cache

    def is_buddy_prioritized(self, username):

        if not username:
            return False

        if username not in core.buddies.users:
            return False

        user_data = core.buddies.users[username]

        # All users
        if config.sections["transfers"]["preferfriends"]:
            return True

        # Only explicitly prioritized users
        return bool(user_data.is_prioritized)

    # Stats/Limits #

    @staticmethod
    def _get_current_file_size(file_path):

        try:
            new_size = os.path.getsize(encode_path(file_path))

        except Exception:
            new_size = None

        return new_size

    def iter_downloading_users(self):
        seen_users = set()

        for users in (self.active_users, self.queued_users):
            for username in users:
                if username in seen_users:
                    continue

                seen_users.add(username)
                yield username

    def get_downloading_users(self):
        return set(self.iter_downloading_users())

    def get_total_uploads_allowed(self):

        if config.sections["transfers"]["useupslots"]:
            upload_slots = config.sections["transfers"]["uploadslots"]
        else:
            upload_slots = len(self.active_users)

            if self.is_new_upload_accepted():
                return upload_slots + 1

        if upload_slots <= 0:
            upload_slots = 1

        return upload_slots

    def get_upload_queue_size(self, username):

        if self.is_privileged(username):
            return self._get_privileged_queued_count()

        return len(self.queued_transfers)

    def has_active_uploads(self):
        return bool(self.active_users or self.queued_users)

    def is_queue_limit_reached(self, username):

        file_limit = config.sections["transfers"]["filelimit"]
        queue_size_limit = config.sections["transfers"]["queuelimit"] * 1024 * 1024

        if len(self.queued_transfers) >= self.MAX_TOTAL_QUEUED_UPLOADS:
            return True, TransferRejectReason.TOO_MANY_FILES

        if len(self.queued_users.get(username, {})) >= file_limit >= 1:
            return True, TransferRejectReason.TOO_MANY_FILES

        if self._user_queue_sizes.get(username, 0) >= queue_size_limit >= 1:
            return True, TransferRejectReason.TOO_MANY_MEGABYTES

        return False, None

    def is_slot_limit_reached(self):

        upload_slot_limit = config.sections["transfers"]["uploadslots"]

        if upload_slot_limit <= 0:
            upload_slot_limit = 1

        return len(self.active_users) >= upload_slot_limit

    def is_bandwidth_limit_reached(self):

        bandwidth_limit = config.sections["transfers"]["uploadbandwidth"] * 1024

        if not bandwidth_limit:
            return False

        return self.total_bandwidth >= bandwidth_limit

    def is_new_upload_accepted(self, enforce_limits=True):

        if core.shares is None or core.shares.rescanning:
            return False

        if not enforce_limits:
            return True

        if config.sections["transfers"]["useupslots"]:
            # Limit by upload slots
            if self.is_slot_limit_reached():
                return False

        elif self.is_bandwidth_limit_reached():
            # Limit by maximum bandwidth
            return False

        # No limits
        return True

    @staticmethod
    def _is_regular_file(real_path):
        file_stat = os.lstat(encode_path(real_path))
        return stat.S_ISREG(file_stat.st_mode)

    @staticmethod
    def is_file_readable(virtual_path, real_path):

        try:
            encoded_real_path = encode_path(real_path)

            if not Uploads._is_regular_file(real_path):
                log.add_transfer("Requested file is not a regular file, not sharing: %s with real path %s",
                                 (virtual_path, real_path))
                return False

            if os.access(encoded_real_path, os.R_OK):
                return True

            log.add_transfer("Cannot access file, not sharing: %s with real path %s",
                             (virtual_path, real_path))

        except Exception:
            log.add_transfer("Requested file path contains invalid characters or other errors, not sharing: "
                             "%s with real path %s", (virtual_path, real_path))

        return False

    @staticmethod
    def _open_upload_file(virtual_path, real_path):
        """Open a shared upload file, rejecting stale symlink/special-file replacements."""

        encoded_real_path = encode_path(real_path)
        pre_open_stat = os.lstat(encoded_real_path)

        if not stat.S_ISREG(pre_open_stat.st_mode):
            raise OSError(f"Requested file is not a regular file: {virtual_path}")

        flags = os.O_RDONLY

        if hasattr(os, "O_BINARY"):
            flags |= os.O_BINARY

        if hasattr(os, "O_NONBLOCK"):
            flags |= os.O_NONBLOCK

        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW

        fd = None

        try:
            fd = os.open(encoded_real_path, flags)
            open_stat = os.fstat(fd)

            if not stat.S_ISREG(open_stat.st_mode):
                raise OSError(f"Requested file is not a regular file: {virtual_path}")

            if ((pre_open_stat.st_dev, pre_open_stat.st_ino)
                    != (open_stat.st_dev, open_stat.st_ino)):
                raise OSError(f"Requested file changed while opening: {virtual_path}")

            file_handle = os.fdopen(fd, "rb")
            fd = None
            return file_handle, open_stat.st_size

        finally:
            if fd is not None:
                os.close(fd)

    def is_upload_queued(self, username, virtual_path):

        if virtual_path in self.queued_users.get(username, {}):
            return True

        return any(upload.virtual_path == virtual_path for upload in self.active_users.get(username, {}).values())

    def update_transfer_limits(self):

        events.emit("update-upload-limits")

        use_speed_limit = config.sections["transfers"]["use_upload_speed_limit"]
        limit_by = config.sections["transfers"]["limitby"]

        if use_speed_limit == "primary":
            speed_limit = config.sections["transfers"]["uploadlimit"]

        elif use_speed_limit == "alternative":
            speed_limit = config.sections["transfers"]["uploadlimitalt"]

        else:
            speed_limit = 0

        core.send_message_to_network_thread(SetUploadLimit(speed_limit, limit_by))
        self._check_upload_queue()

    # Transfer Actions #

    def _enqueue_transfer(self, transfer):

        username = transfer.username

        super()._enqueue_transfer(transfer)

        if self.is_privileged(username):
            transfer.modifier = "privileged" if username in core.users.privileged else "prioritized"

        # Clear queue position cache until next position request
        self._invalidate_queue_position_cache(username)

        return True

    def _dequeue_transfer(self, transfer):

        username = transfer.username

        if not super()._dequeue_transfer(transfer):
            return False

        if username not in self.queued_users:
            self._user_update_counters.pop(username, None)

        transfer.modifier = None

        # Clear queue position cache until next position request
        self._invalidate_queue_position_cache(username)

        return True

    def _activate_transfer(self, transfer, token):
        if not super()._activate_transfer(transfer, token):
            return False

        self._user_update_counters.pop(transfer.username, None)
        return True

    def _update_transfer(self, transfer, update_parent=True):

        username = transfer.username

        # Don't update existing user counter for queued uploads
        # We don't want to push the user back in the queue if they enqueued new files
        if (username not in self._user_update_counters
                or transfer.virtual_path not in self.queued_users.get(username, {})):
            self._update_user_counter(username)

        events.emit("update-upload", transfer, update_parent)

    def _finish_transfer(self, transfer, already_exists=False):

        username = transfer.username
        virtual_path = transfer.virtual_path

        super()._finish_transfer(transfer)

        if not self._auto_clear_transfer(transfer):
            self._update_transfer(transfer)

        if not already_exists:
            core.statistics.append_stat_value("completed_uploads", 1)

            real_path = core.shares.virtual2real(virtual_path)
            core.pluginhandler.upload_finished_notification(username, virtual_path, real_path)

            log.add_upload(
                _("Upload finished: user %(user)s, IP address %(ip)s, file %(file)s"), {
                    "user": username,
                    "ip": core.users.addresses.get(username),
                    "file": virtual_path
                }
            )

        self._check_upload_queue()


    def _emit_batched_aborted_transfers(self, transfers, status):
        events.emit("abort-uploads", transfers, status)

    def _abort_transfer(self, transfer, status=None, denied_message=None, update_parent=True):

        if transfer.file_handle is not None:
            log.add_upload(
                _("Upload aborted, user %(user)s file %(file)s"), {
                    "user": transfer.username,
                    "file": transfer.virtual_path
                }
            )

        super()._abort_transfer(transfer, status=status, denied_message=denied_message)
        self._update_user_counter(transfer.username)

        if status:
            events.emit("abort-upload", transfer, status, update_parent)

    def _clear_transfer(self, transfer, denied_message=None, update_parent=True):

        virtual_path = transfer.virtual_path
        username = transfer.username

        log.add_transfer("Clearing upload %s to user %s", (virtual_path, username))

        try:
            super()._clear_transfer(transfer, denied_message=denied_message)

        except KeyError:
            log.add("FIXME: failed to remove upload %s to user %s, not present in list",
                    (virtual_path, username))

        events.emit("clear-upload", transfer, update_parent)

    def _schedule_retry_failed_uploads(self):

        if self._retry_failed_uploads_continuation_timer_id is not None:
            return

        self._retry_failed_uploads_continuation_timer_id = events.schedule(
            delay=0, callback=self._retry_failed_uploads)

    def _retry_failed_uploads(self):

        self._retry_failed_uploads_continuation_timer_id = None
        uploads = []
        limit = self.MAX_FAILED_UPLOAD_RETRIES_PER_TICK

        for failed_uploads in self.failed_users.values():
            for upload in failed_uploads.values():
                if upload.status != TransferStatus.CONNECTION_TIMEOUT:
                    continue

                uploads.append(upload)

                if len(uploads) >= limit:
                    break

            if len(uploads) >= limit:
                break

        for upload in uploads:
            self._unfail_transfer(upload)
            self._enqueue_transfer(upload)
            self._update_transfer(upload)

        if len(uploads) >= limit:
            self._schedule_retry_failed_uploads()

    @staticmethod
    def _get_pending_network_msg_key(msg):
        msg_class = msg.__class__
        username = getattr(msg, "username", None)
        virtual_path = getattr(msg, "file", None)
        token = getattr(msg, "token", None)

        if msg_class is TransferRequest:
            return msg_class, username, token, virtual_path

        return msg_class, username, virtual_path

    def _add_pending_network_msg(self, msg):
        key = self._get_pending_network_msg_key(msg)

        if key in self._pending_network_msg_keys:
            return

        if len(self._pending_network_msgs) >= self.MAX_PENDING_NETWORK_MESSAGES:
            if not self._pending_network_msgs_limit_logged:
                log.add_transfer("Dropping additional file requests while rescanning shares, "
                                 "pending request limit %s reached",
                                 self.MAX_PENDING_NETWORK_MESSAGES)
                self._pending_network_msgs_limit_logged = True

            return

        self._pending_network_msg_keys.add(key)
        self._pending_network_msgs.append(msg)

    def _check_queue_upload_allowed(self, username, addr, virtual_path, real_path, msg):

        # Is user allowed to download?
        ip_address, _port = addr
        permission_level, reject_reason = core.shares.check_user_permission(username, ip_address)
        size = None

        if permission_level == PermissionLevel.BANNED:
            reject_message = TransferRejectReason.BANNED

            if reject_reason:
                reject_message += f" ({reject_reason})"

            return False, reject_message, size

        if core.shares.rescanning:
            self._add_pending_network_msg(msg)
            return False, None, size

        # Is that file already in the queue?
        if self.is_upload_queued(username, virtual_path):
            return False, TransferRejectReason.QUEUED, size

        # Are we waiting for existing uploads to finish?
        if self.pending_shutdown:
            return False, TransferRejectReason.PENDING_SHUTDOWN, size

        # Has user hit queue limit?
        enable_limits = True

        if config.sections["transfers"]["friendsnolimits"]:
            if username in core.buddies.users:
                enable_limits = False

        if enable_limits:
            limit_reached, reason = self.is_queue_limit_reached(username)

            if limit_reached:
                return False, reason, size

        is_file_shared, size = core.shares.file_is_shared(username, virtual_path, real_path)

        # Do we actually share that file with the world?
        if not is_file_shared:
            return False, TransferRejectReason.FILE_NOT_SHARED, size

        return True, None, size

    def _get_upload_candidate(self):
        """Retrieve a suitable queued transfer for uploading.

        Round Robin: Get the first queued item from the oldest user
        FIFO: Get the first queued item in the list
        """

        is_fifo_queue = config.sections["transfers"]["fifoqueue"]
        has_active_uploads = bool(self.active_users)
        oldest_time = None
        target_username = None
        upload_candidate = None
        privileged_users = set()

        if not self._user_update_counters:
            # No queued uploads to start right now
            return upload_candidate, has_active_uploads

        for username in self._user_update_counters:
            if self.is_privileged(username):
                privileged_users.add(username)

        if is_fifo_queue:
            for upload in self.queued_transfers:
                username = upload.username

                if privileged_users and username not in privileged_users:
                    continue

                if username not in self._user_update_counters:
                    continue

                target_username = username
                break
        else:
            for username, update_time in self._user_update_counters.items():
                if privileged_users and username not in privileged_users:
                    continue

                if not oldest_time:
                    oldest_time = update_time + 1

                if update_time < oldest_time:
                    target_username = username
                    oldest_time = update_time

        if target_username is not None:
            upload_candidate = next(iter(self.queued_users[target_username].values()), None)

        return upload_candidate, has_active_uploads

    def _update_user_counter(self, username):
        """Called when an upload associated with a user has changed.

        The user update counter is used by the Round Robin queue system
        to determine which user has waited the longest since their last
        download.
        """

        if username in self.queued_users and username not in self.active_users:
            self._user_update_counter += 1
            self._user_update_counters[username] = self._user_update_counter

    def _schedule_upload_queue_check(self):

        if self._upload_queue_check_timer_id is not None:
            return

        self._upload_queue_check_timer_id = events.schedule(delay=0, callback=self._scheduled_upload_queue_check)

    def _scheduled_upload_queue_check(self):

        self._upload_queue_check_timer_id = None
        self._check_upload_queue()

    @staticmethod
    def _should_pause_upload_queue_validation(validation_steps, limit):
        return validation_steps >= limit

    def _check_upload_queue(self, upload_candidate=None):
        """Find next file to upload."""

        final_upload_candidate = None
        validation_steps = 0
        validation_limit = self.MAX_UPLOAD_QUEUE_VALIDATION_STEPS_PER_TICK

        while final_upload_candidate is None:
            # If a candidate is provided, we want to upload it immediately
            if not self.is_new_upload_accepted(enforce_limits=(upload_candidate is None)):
                return

            if upload_candidate is None:
                upload_candidate, has_active_uploads = self._get_upload_candidate()

                if upload_candidate is None:
                    if not has_active_uploads and self.pending_shutdown:
                        self.pending_shutdown = False
                        core.quit()
                    return

            elif upload_candidate not in self.queued_users.get(upload_candidate.username, {}).values():
                return

            username = upload_candidate.username
            validation_steps += 1
            pause_after_candidate = self._should_pause_upload_queue_validation(validation_steps, validation_limit)

            if UserStatus.OFFLINE in (core.users.login_status, core.users.statuses.get(username)):
                # Either we are offline or the user we want to upload to is
                if not self._auto_clear_transfer(upload_candidate):
                    self._abort_transfer(upload_candidate, status=TransferStatus.USER_LOGGED_OFF)

                upload_candidate = None

                if pause_after_candidate:
                    self._schedule_upload_queue_check()
                    return

                continue

            virtual_path = upload_candidate.virtual_path
            real_path = core.shares.virtual2real(virtual_path)
            is_file_shared, _new_size = core.shares.file_is_shared(username, virtual_path, real_path)

            if not is_file_shared:
                self._clear_transfer(upload_candidate, denied_message=TransferRejectReason.FILE_NOT_SHARED)
                upload_candidate = None

                if pause_after_candidate:
                    self._schedule_upload_queue_check()
                    return

                continue

            if not self.is_file_readable(virtual_path, real_path):
                self._abort_transfer(
                    upload_candidate, status=TransferStatus.LOCAL_FILE_ERROR,
                    denied_message=TransferRejectReason.FILE_READ_ERROR
                )
                upload_candidate = None

                if pause_after_candidate:
                    self._schedule_upload_queue_check()
                    return

                continue

            current_size = self._get_current_file_size(real_path)

            if current_size is not None:
                upload_candidate.size = current_size

            final_upload_candidate = upload_candidate

        self.token = increment_token(self.token)

        log.add_transfer("Checked upload queue, requesting to upload file %s with "
                         "token %s to user %s", (virtual_path, self.token, username))

        self._dequeue_transfer(final_upload_candidate)
        self._unfail_transfer(final_upload_candidate)
        if not self._activate_transfer(final_upload_candidate, self.token):
            self._enqueue_transfer(final_upload_candidate)
            self._update_transfer(final_upload_candidate)
            return

        transfer_request = TransferRequest(
            direction=TransferDirection.UPLOAD, token=self.token, file=virtual_path,
            filesize=final_upload_candidate.size)

        if core.send_message_to_peer(username, transfer_request) is False:
            # Queue pressure rejected the upload request before the peer could see it.
            # Undo the active state and put the transfer back in the queue; otherwise the
            # request timer would later fail a transfer that was never announced.
            self._deactivate_transfer(final_upload_candidate)
            self._enqueue_transfer(final_upload_candidate)
            self._update_transfer(final_upload_candidate)
            self._schedule_upload_queue_check()
            return

        self._update_transfer(final_upload_candidate)

    def _rollback_unsent_upload_activation(self, username, token, reason):
        upload = self.active_users.get(username, {}).get(token)

        if upload is None:
            return False

        log.add_transfer(
            "Re-queueing upload %s for user %s because %s was not sent",
            (upload.virtual_path, username, reason)
        )
        self._deactivate_transfer(upload)
        self._enqueue_transfer(upload)
        self._update_transfer(upload)
        self._schedule_upload_queue_check()
        return True

    def _peer_message_unsent(self, msg):
        msg_class = msg.__class__

        if msg_class is TransferRequest and msg.direction == TransferDirection.UPLOAD:
            self._rollback_unsent_upload_activation(msg.username, msg.token, "TransferRequest")
            return

        if msg_class is FileTransferInit and msg.is_outgoing:
            self._rollback_unsent_upload_activation(msg.username, msg.token, "FileTransferInit")
            return

        if msg_class is TransferResponse and msg.allowed:
            self._rollback_unsent_upload_activation(msg.username, msg.token, "TransferResponse")
            return

        if msg_class in {UploadDenied, UploadFailed, PlaceInQueueResponse}:
            self._queue_peer_transfer_notice(msg.username, msg)

    def enqueue_upload(self, username, virtual_path):

        transfer = self.get_transfer(username, virtual_path)
        real_path = core.shares.virtual2real(virtual_path)
        is_file_shared, size = core.shares.file_is_shared(username, virtual_path, real_path)

        if not is_file_shared:
            return

        if transfer is None:
            folder_path = os.path.dirname(real_path)
            transfer = Transfer(username, virtual_path, folder_path, size)
            self._append_transfer(transfer)
        else:
            if transfer in self.active_users.get(username, {}).values():
                # Upload already in progress
                return

            if virtual_path in self.queued_users.get(username, {}):
                # Upload already queued
                return

            self._unfail_transfer(transfer)
            transfer.size = size

        if UserStatus.OFFLINE in (core.users.login_status, core.users.statuses.get(username)):
            # Either we are offline or the user we want to upload to is
            if not self._auto_clear_transfer(transfer):
                self._abort_transfer(transfer, status=TransferStatus.USER_LOGGED_OFF)

            return

        self._enqueue_transfer(transfer)
        self._update_transfer(transfer)
        self._check_upload_queue()

    def retry_upload(self, transfer):

        username = transfer.username
        active_uploads = self.active_users.get(username, {}).values()

        if transfer in active_uploads or transfer.status == TransferStatus.FINISHED:
            # Don't retry active or finished uploads
            return

        if transfer not in self.queued_users.get(username, {}).values():
            self._unfail_transfer(transfer)
            self._enqueue_transfer(transfer)
            self._update_transfer(transfer)

        if not active_uploads:
            # No active upload, transfer a queued upload immediately
            self._check_upload_queue(transfer)

    def _cancel_bulk_upload_actions(self):
        events.cancel_scheduled(self._bulk_upload_action_timer_id)
        self._bulk_upload_action_timer_id = None
        self._bulk_upload_action_queue.clear()

    def _schedule_bulk_upload_actions(self):

        if self._bulk_upload_action_timer_id is not None:
            return

        self._bulk_upload_action_timer_id = events.schedule(delay=0, callback=self._process_bulk_upload_actions)

        if self._bulk_upload_action_timer_id is None:
            self._process_bulk_upload_actions()

    def _queue_bulk_upload_actions(self, action, uploads, *args):

        queued = 0

        for upload in uploads:
            if len(self._bulk_upload_action_queue) >= self.MAX_PENDING_BULK_UPLOAD_ACTIONS:
                break

            self._bulk_upload_action_queue.append((action, upload, args))
            queued += 1

        if queued:
            self._process_bulk_upload_actions()

    def _queue_clear_all_upload_actions(self, statuses, denied_message):
        """Queue a clear-all operation without snapshotting every upload object."""

        if self._bulk_upload_clear_all_state is None:
            # The common clear-all path can progress by clearing the current
            # first batch. Only retain every seen key when filters require us to
            # skip entries that stay in the transfer map.
            seen_keys = set() if statuses else None
            self._bulk_upload_clear_all_state = [statuses, denied_message, seen_keys]

        self._process_bulk_upload_actions()

    def _fill_bulk_upload_actions_from_sources(self):

        state = self._bulk_upload_clear_all_state

        if state is None:
            return

        statuses, denied_message, seen_keys = state
        remaining_capacity = self.MAX_PENDING_BULK_UPLOAD_ACTIONS - len(self._bulk_upload_action_queue)

        if seen_keys is None:
            # Keep an unconditional clear-all refill to one processing batch.
            # Once that batch is processed, those transfers are gone from the
            # map and the next tick can start at the beginning without a large
            # retained seen-key set or repeated prefix scan.
            remaining_capacity = min(
                remaining_capacity,
                self.MAX_BULK_UPLOAD_ACTIONS_PER_TICK - len(self._bulk_upload_action_queue)
            )

        if remaining_capacity <= 0:
            return

        scanned = 0
        completed = True

        for key, upload in self.transfers.items():
            if seen_keys is not None:
                if key in seen_keys:
                    continue

                seen_keys.add(key)

            scanned += 1

            if not statuses or upload.status in statuses:
                self._bulk_upload_action_queue.append(("clear", upload, (statuses, denied_message)))
                remaining_capacity -= 1

            if (scanned >= self.MAX_BULK_UPLOAD_SOURCE_SCANS_PER_TICK
                    or remaining_capacity <= 0):
                completed = False
                break

        if completed:
            self._bulk_upload_clear_all_state = None

    def _process_bulk_upload_actions(self):

        self._bulk_upload_action_timer_id = None
        self._fill_bulk_upload_actions_from_sources()
        aborted = defaultdict(list)
        cleared = defaultdict(list)
        clear_args = {}
        num_processed = 0

        while (self._bulk_upload_action_queue
               and num_processed < self.MAX_BULK_UPLOAD_ACTIONS_PER_TICK):
            action, upload, args = self._bulk_upload_action_queue.popleft()
            num_processed += 1

            if action == "retry":
                self.retry_upload(upload)

            elif action == "abort":
                denied_message, status = args

                if upload.status not in {status, TransferStatus.FINISHED}:
                    self._abort_transfer(
                        upload, status=status, denied_message=denied_message, update_parent=False)
                    aborted[status].append(upload)

            elif action == "clear":
                statuses, denied_message = args

                if statuses and upload.status not in statuses:
                    continue

                self._clear_transfer(upload, denied_message=denied_message, update_parent=False)
                key = (frozenset(statuses) if statuses else None, denied_message)
                clear_args[key] = statuses
                cleared[key].append(upload)

        for status, uploads in aborted.items():
            events.emit("abort-uploads", uploads, status)

        for key, uploads in cleared.items():
            events.emit("clear-uploads", uploads, clear_args[key])

        if self._bulk_upload_action_queue or self._bulk_upload_clear_all_state is not None:
            self._schedule_bulk_upload_actions()

    @staticmethod
    def _normalize_bulk_uploads(uploads):
        if uploads is None:
            return None

        if isinstance(uploads, (list, tuple)):
            return uploads

        return tuple(uploads)

    def retry_uploads(self, uploads):
        uploads = self._normalize_bulk_uploads(uploads)

        if len(uploads) > self.MAX_BULK_UPLOAD_ACTIONS_PER_TICK:
            self._queue_bulk_upload_actions("retry", uploads)
            return

        for upload in uploads:
            self.retry_upload(upload)

    def abort_uploads(self, uploads, denied_message=None, status=TransferStatus.CANCELLED):

        uploads = self._normalize_bulk_uploads(uploads)

        if len(uploads) > self.MAX_BULK_UPLOAD_ACTIONS_PER_TICK:
            self._queue_bulk_upload_actions("abort", uploads, denied_message, status)
            return

        ignored_statuses = {status, TransferStatus.FINISHED}

        for upload in uploads:
            if upload.status not in ignored_statuses:
                self._abort_transfer(
                    upload, status=status, denied_message=denied_message, update_parent=False)

        events.emit("abort-uploads", uploads, status)

    def clear_uploads(self, uploads=None, statuses=None, denied_message=None):

        if uploads is None:
            # Clear all uploads. For large transfer lists, avoid building a
            # tuple of every Transfer before the bulk-action batcher can run.
            if len(self.transfers) > self.MAX_BULK_UPLOAD_ACTIONS_PER_TICK:
                self._queue_clear_all_upload_actions(statuses, denied_message)
                return

            uploads = tuple(self.transfers.values())
        else:
            uploads = tuple(uploads)

        if len(uploads) > self.MAX_BULK_UPLOAD_ACTIONS_PER_TICK:
            self._queue_bulk_upload_actions("clear", uploads, statuses, denied_message)
            return

        for upload in uploads:
            if statuses and upload.status not in statuses:
                continue

            self._clear_transfer(upload, denied_message=denied_message, update_parent=False)

        events.emit("clear-uploads", uploads, statuses)

    def request_shutdown(self):
        """Schedule a shutdown after all queued uploads have finished."""

        if self.pending_shutdown:
            return

        self.pending_shutdown = True
        self._check_upload_queue()

        events.emit("uploads-shutdown-request")

    def cancel_shutdown(self):

        if not self.pending_shutdown:
            return

        self.pending_shutdown = False
        events.emit("uploads-shutdown-cancel")

    # Events #

    def _schedule_pending_network_flush(self, delay=0):

        if self._pending_network_flush_timer_id is not None:
            return

        self._pending_network_flush_timer_id = events.schedule(
            delay=delay, callback=self._flush_pending_network_msgs)

    def _restore_pending_network_msgs(self, network_msgs):

        if not network_msgs:
            return

        self._pending_network_msgs[:0] = network_msgs

        for msg in network_msgs:
            self._pending_network_msg_keys.add(self._get_pending_network_msg_key(msg))

    def _flush_pending_network_msgs(self):

        self._pending_network_flush_timer_id = None

        if not self._pending_network_msgs:
            self._pending_network_msg_keys.clear()
            self._pending_network_msgs_limit_logged = False
            return

        network_msgs = self._pending_network_msgs[:self.MAX_PENDING_NETWORK_MESSAGES_PER_READY_TICK]
        del self._pending_network_msgs[:len(network_msgs)]

        for msg in network_msgs:
            self._pending_network_msg_keys.discard(self._get_pending_network_msg_key(msg))

        if core.send_message_to_network_thread(EmitNetworkMessageEvents(network_msgs)) is False:
            # The local network queue can reject non-critical deferred batches
            # while under pressure. Put the batch back at the front so remote
            # requests gathered during a share rescan are retried instead of
            # silently disappearing after the shares become ready.
            self._restore_pending_network_msgs(network_msgs)
            self._schedule_pending_network_flush(delay=self.PENDING_NETWORK_FLUSH_RETRY_DELAY)
            log.add_transfer(
                "Deferred upload-request replay was rejected by the local network queue; retrying %s request(s)",
                len(network_msgs)
            )
            return

        if self._pending_network_msgs:
            self._schedule_pending_network_flush()
        else:
            self._pending_network_msgs_limit_logged = False

    def _shares_ready(self, _successful):
        """Process any file transfer queue requests that arrived while
        scanning shares.
        """

        self._flush_pending_network_msgs()

    def _schedule_user_status_upload_cancels(self):
        if self._user_status_cancel_timer_id is None:
            self._user_status_cancel_timer_id = events.schedule(
                delay=0, callback=self._cancel_user_status_uploads)

    def _schedule_user_status_upload_offline_aborts(self):
        if self._user_status_offline_timer_id is None:
            self._user_status_offline_timer_id = events.schedule(
                delay=0, callback=self._abort_user_status_uploads)

    def _queue_user_status_upload_cancels(self, username):
        if username in self._user_status_cancel_users:
            return

        self._user_status_cancel_users.add(username)
        self._user_status_cancel_queue.append(username)
        self._schedule_user_status_upload_cancels()

    def _queue_user_status_upload_offline_aborts(self, username):
        if username in self._user_status_offline_users:
            return

        self._user_status_offline_users.add(username)
        self._user_status_offline_queue.append(username)
        self._schedule_user_status_upload_offline_aborts()

    def _cancel_user_status_uploads_for_user(self, username, max_uploads):
        failed_uploads = self.failed_users.get(username)

        if not failed_uploads or max_uploads <= 0:
            return 0, False

        uploads = []

        for upload in failed_uploads.values():
            if upload.status != TransferStatus.USER_LOGGED_OFF:
                continue

            uploads.append(upload)

            if len(uploads) >= max_uploads:
                break

        for upload in uploads:
            self._abort_transfer(upload, status=TransferStatus.CANCELLED)

        has_more = any(
            upload.status == TransferStatus.USER_LOGGED_OFF
            for upload in self.failed_users.get(username, {}).values()
        )

        return len(uploads), has_more

    def _cancel_user_status_uploads(self):
        self._user_status_cancel_timer_id = None
        num_processed = 0

        while (self._user_status_cancel_queue
                and num_processed < self.MAX_USER_STATUS_UPLOAD_CANCELS_PER_TICK):
            username = self._user_status_cancel_queue.popleft()
            self._user_status_cancel_users.discard(username)

            if username not in self._online_users:
                continue

            processed, has_more = self._cancel_user_status_uploads_for_user(
                username, self.MAX_USER_STATUS_UPLOAD_CANCELS_PER_TICK - num_processed)
            num_processed += processed

            if has_more:
                self._queue_user_status_upload_cancels(username)

        if self._user_status_cancel_queue:
            self._schedule_user_status_upload_cancels()

    def _has_user_status_uploads_to_abort(self, username):
        if any(
            upload.status != TransferStatus.USER_LOGGED_OFF
            for upload in self.failed_users.get(username, {}).values()
        ):
            return True

        return any(
            upload.status != TransferStatus.TRANSFERRING
            for upload in self.active_users.get(username, {}).values()
        )

    def _abort_user_status_uploads_for_user(self, username, max_uploads):
        if max_uploads <= 0:
            return 0, self._has_user_status_uploads_to_abort(username)

        uploads = []
        active_uploads = set()

        for upload in self.failed_users.get(username, {}).values():
            if upload.status == TransferStatus.USER_LOGGED_OFF:
                continue

            uploads.append(upload)

            if len(uploads) >= max_uploads:
                break

        if len(uploads) < max_uploads:
            for upload in self.active_users.get(username, {}).values():
                if upload.status == TransferStatus.TRANSFERRING:
                    continue

                uploads.append(upload)
                active_uploads.add(upload)

                if len(uploads) >= max_uploads:
                    break

        check_upload_queue = False

        for upload in uploads:
            if upload in active_uploads:
                if self._auto_clear_transfer(upload):
                    check_upload_queue = True
                    continue

                check_upload_queue = True

            self._abort_transfer(upload, status=TransferStatus.USER_LOGGED_OFF)

        if check_upload_queue:
            self._check_upload_queue()

        return len(uploads), self._has_user_status_uploads_to_abort(username)

    def _abort_user_status_uploads(self):
        self._user_status_offline_timer_id = None
        num_processed = 0

        while (self._user_status_offline_queue
                and num_processed < self.MAX_USER_STATUS_UPLOAD_OFFLINE_ABORTS_PER_TICK):
            username = self._user_status_offline_queue.popleft()
            self._user_status_offline_users.discard(username)

            if username in self._online_users:
                continue

            processed, has_more = self._abort_user_status_uploads_for_user(
                username, self.MAX_USER_STATUS_UPLOAD_OFFLINE_ABORTS_PER_TICK - num_processed)
            num_processed += processed

            if has_more:
                self._queue_user_status_upload_offline_aborts(username)

        if self._user_status_offline_queue:
            self._schedule_user_status_upload_offline_aborts()

    def _user_status(self, msg):
        """Server code 7."""

        username = msg.user

        if username not in core.users.watched:
            # Skip redundant status updates from users in joined rooms
            return

        if msg.status == UserStatus.OFFLINE:
            self._online_users.discard(username)
            self._user_status_cancel_users.discard(username)

            _, has_more = self._abort_user_status_uploads_for_user(
                username, self.MAX_USER_STATUS_UPLOAD_OFFLINE_ABORTS_PER_TICK)

            if has_more:
                self._queue_user_status_upload_offline_aborts(username)

            return

        # No need to check transfers on away status change
        if username in self._online_users:
            return

        self._online_users.add(username)

        # User logged in, mark only transfers that actually failed because the
        # user was offline as cancelled. Keep connection timeouts and local I/O
        # failures intact for their dedicated retry/error paths, and avoid
        # changing every failed upload for a high-volume user in one tick.
        _, has_more = self._cancel_user_status_uploads_for_user(
            username, self.MAX_USER_STATUS_UPLOAD_CANCELS_PER_TICK)

        if has_more:
            self._queue_user_status_upload_cancels(username)

    def _user_stats(self, msg):
        """Server code 36."""

        if msg.user == core.users.login_username:
            self.upload_speed = msg.avgspeed

    def _privileged_users(self, _msg):
        """Server code 69."""

        self._invalidate_queue_position_cache()
        log.add_transfer("%s privileged users", len(core.users.privileged))

    def _set_connection_stats(self, upload_bandwidth=0, **_unused):
        self.total_bandwidth = upload_bandwidth

    def _ban_user(self, username=None, ip_address=None):
        """Ban a user, cancel all the user's uploads, send a 'Banned' message
        via the transfers, and clear the transfers from the uploads list."""

        ban_message = None

        if config.sections["transfers"]["usecustomban"]:
            ban_message = config.sections["transfers"]["customban"]

        if ban_message:
            status = f"{TransferRejectReason.BANNED} ({ban_message})"
        else:
            status = TransferRejectReason.BANNED

        removed_uploads = []

        if not username and ip_address:
            for active_uploads in self.active_users.values():
                for upload in active_uploads.values():
                    active_ip_address = None

                    if upload.sock is not None:
                        try:
                            active_ip_address, _port = upload.sock.getpeername()
                        except OSError:
                            active_ip_address = None

                    if active_ip_address is None:
                        address = core.users.addresses.get(upload.username)

                        if address is not None:
                            active_ip_address, _port = address

                    if active_ip_address == ip_address:
                        username = upload.username
                        break

                if username:
                    break

        for uploads in (
            self.active_users.get(username, {}),
            self.queued_users.get(username, {}),
            self.failed_users.get(username, {})
        ):
            for upload in uploads.values():
                removed_uploads.append(upload)

        self.clear_uploads(uploads=removed_uploads, denied_message=status)
        self._check_upload_queue()

    def _peer_connection_error(self, username, conn_type, msgs, is_offline=False, is_timeout=True):

        if not msgs:
            return

        if conn_type not in {ConnectionType.FILE, ConnectionType.PEER}:
            return

        failed_msg_types = {TransferRequest, FileTransferInit}

        for msg in msgs:
            if msg.__class__ in failed_msg_types:
                self._cant_connect_upload(username, msg.token, is_offline, is_timeout)

    def _peer_connection_closed(self, username, conn_type, msgs):
        self._peer_connection_error(username, conn_type, msgs, is_timeout=False)

    def _cant_connect_upload(self, username, token, is_offline, is_timeout):
        """We can't connect to the user, either way (TransferRequest,
        FileTransferInit)."""

        upload = self.active_users.get(username, {}).get(token)

        if upload is None:
            return

        if is_offline:
            status = TransferStatus.USER_LOGGED_OFF

        elif is_timeout:
            status = TransferStatus.CONNECTION_TIMEOUT

        else:
            status = TransferStatus.CONNECTION_CLOSED

        log.add_transfer("Upload attempt for file %s with token %s to user %s failed "
                         "with status %s", (upload.virtual_path, token, username, status))

        upload_cleared = is_offline and self._auto_clear_transfer(upload)

        if not upload_cleared:
            self._abort_transfer(upload, status=status)

        self._check_upload_queue()

    def _queue_upload(self, msg):
        """Peer code 43.

        Peer remotely queued a download (upload here). This is the
        modern replacement to a TransferRequest with direction 0
        (download request). We will initiate the upload of the queued
        file later.
        """

        username = msg.username
        virtual_path = msg.file
        real_path = core.shares.virtual2real(virtual_path)
        allowed, reason, size = self._check_queue_upload_allowed(username, msg.addr, virtual_path, real_path, msg)

        log.add_transfer("Upload request for file %s from user: %s, allowed: %s, "
                         "reason: %s", (virtual_path, username, allowed, reason))

        if not allowed:
            if reason and reason != TransferRejectReason.QUEUED:
                self._send_upload_denied_message(username, virtual_path, reason)

            return

        transfer = self.get_transfer(username, virtual_path)
        folder_path = os.path.dirname(real_path)

        if transfer is not None:
            self._unfail_transfer(transfer)

            transfer.folder_path = folder_path
            transfer.size = size

            if transfer.status == TransferStatus.FINISHED:
                transfer.current_byte_offset = None
                transfer.speed = transfer.avg_speed = transfer.time_elapsed = transfer.time_left = 0
        else:
            transfer = Transfer(username, virtual_path, folder_path, size)
            self._append_transfer(transfer)

        self._enqueue_transfer(transfer)
        self._update_transfer(transfer)

        # Must be emitted after the final update to prevent inconsistent state
        core.pluginhandler.upload_queued_notification(username, virtual_path, real_path)

        self._check_upload_queue()

    def _transfer_request(self, msg):
        """Peer code 40."""

        username = msg.username

        if msg.direction != TransferDirection.DOWNLOAD:
            return

        response = self._transfer_request_uploads(msg)

        if response is None:
            return

        log.add_transfer("Responding to legacy upload request %s for file %s from user %s, "
                         "allowed: %s, reason: %s",
                         (response.token, msg.file, username, response.allowed, response.reason))

        if core.send_message_to_peer(username, response) is False:
            self._legacy_upload_response_rejected(msg, response)
            return

    def _legacy_upload_response_rejected(self, msg, response):
        """Undo started legacy-upload state when the response cannot be queued.

        TransferRequest(direction=DOWNLOAD) is the legacy upload-request path.
        A positive TransferResponse is the peer's only signal that it should
        initiate the file connection. If our bounded local queue rejects that
        response, keeping the upload active leaves a local GETTING_STATUS
        transfer waiting for a peer that was never told to connect. Requeue the
        transfer instead of letting the request timeout later with misleading
        state.
        """

        if not response.allowed:
            return

        upload = self.active_users.get(msg.username, {}).get(response.token)

        if upload is None:
            return

        log.add_transfer(
            "Legacy upload response for token %s to user %s was rejected by the local network queue; "
            "re-queueing upload %s", (response.token, msg.username, upload.virtual_path)
        )

        self._deactivate_transfer(upload)

        if upload.virtual_path not in self.queued_users.get(upload.username, {}):
            self._enqueue_transfer(upload)

        self._update_transfer(upload)
        self._schedule_upload_queue_check()

    def _transfer_request_uploads(self, msg):
        """Remote peer is requesting to download a file through your upload
        queue.

        Note that the QueueUpload peer message has replaced this method
        of requesting a download in most clients.
        """

        username = msg.username
        virtual_path = msg.file
        token = msg.token

        log.add_transfer("Received legacy upload request %s for file %s from user %s",
                         (token, virtual_path, username))

        # Is user allowed to download?
        real_path = core.shares.virtual2real(virtual_path)
        allowed, reason, size = self._check_queue_upload_allowed(username, msg.addr, virtual_path, real_path, msg)

        if not allowed:
            if reason:
                return TransferResponse(allowed=False, reason=reason, token=token)

            return None

        # All checks passed, user can queue file!
        transfer = self.get_transfer(username, virtual_path)
        folder_path = os.path.dirname(real_path)

        if transfer is not None:
            self._unfail_transfer(transfer)

            transfer.folder_path = folder_path
            transfer.size = size

            if transfer.status == TransferStatus.FINISHED:
                transfer.current_byte_offset = None
                transfer.speed = transfer.avg_speed = transfer.time_elapsed = transfer.time_left = 0
        else:
            transfer = Transfer(username, virtual_path, folder_path, size)
            self._append_transfer(transfer)

        if not self.is_new_upload_accepted() or username in self.active_users:
            self._enqueue_transfer(transfer)
            self._update_transfer(transfer)

            # Must be emitted after the final update to prevent inconsistent state
            core.pluginhandler.upload_queued_notification(username, virtual_path, real_path)

            return TransferResponse(allowed=False, reason=TransferRejectReason.QUEUED, token=token)

        # All checks passed, starting a new upload.
        current_size = self._get_current_file_size(real_path)

        if current_size is not None:
            transfer.size = current_size

        self._activate_transfer(transfer, token)
        self._update_transfer(transfer)

        # Must be emitted after the final update to prevent inconsistent state
        core.pluginhandler.upload_queued_notification(username, virtual_path, real_path)

        return TransferResponse(allowed=True, token=token, filesize=transfer.size)

    def _transfer_response(self, msg):
        """Peer code 41.

        Received a response to the file request from the peer
        """

        username = msg.username
        token = msg.token
        reason = msg.reason

        log.add_transfer("Received response for upload with token: %s, allowed: %s, "
                         "reason: %s, file size: %s", (token, msg.allowed, reason, msg.filesize))

        upload = self.active_users.get(username, {}).get(token)

        if upload is None:
            log.add_transfer("Received unknown upload response: %s", msg)
            return

        if upload.sock is not None:
            log.add_transfer("Upload with token %s already has an existing file connection", token)
            return

        if not msg.allowed:
            if reason is None:
                # Some clients can send a malformed denial without a reason.
                # Treat it as a cancellation instead of initiating a file connection.
                reason = TransferRejectReason.CANCELLED

            elif reason in TransferStatus.__dict__.values() or reason == TransferRejectReason.DISALLOWED_EXTENSION:
                # Don't allow internal statuses as reason
                reason = TransferRejectReason.CANCELLED

            self._abort_transfer(upload, status=reason)

            if reason == TransferRejectReason.COMPLETE:
                # A complete download of this file already exists on the user's end
                self._finish_transfer(upload, already_exists=True)

            elif reason == TransferRejectReason.CANCELLED:
                self._auto_clear_transfer(upload)

            self._check_upload_queue()
            return

        if core.send_message_to_peer(upload.username, FileTransferInit(token=token, is_outgoing=True)) is False:
            # Queue pressure rejected the file-connection setup message after
            # the peer accepted our upload request. Do not leave the upload in
            # active/GETTING_STATUS state with no way for the file connection to
            # arrive; put it back in the queue and retry once peer output can be
            # accepted again.
            log.add_transfer(
                "Re-queueing upload %s for user %s because the FileTransferInit message was rejected",
                (upload.virtual_path, upload.username)
            )
            self._deactivate_transfer(upload)
            self._enqueue_transfer(upload)
            self._update_transfer(upload)
            self._schedule_upload_queue_check()
            return

        self._check_upload_queue()

    def _transfer_timeout(self, transfer):

        if transfer.request_timer_id is None:
            return

        log.add_transfer("Upload %s with token %s for user %s timed out",
                         (transfer.virtual_path, transfer.token, transfer.username))

        super()._transfer_timeout(transfer)
        self._check_upload_queue()

    def _upload_file_error(self, username, token, error):
        """Networking thread encountered a local file error for upload."""

        upload = self.active_users.get(username, {}).get(token)

        if upload is None:
            return

        if isinstance(error, ValueError):
            status = TransferStatus.CANCELLED
            error = f"Remote client does not support large file transfers: {error}"
        else:
            status = TransferStatus.LOCAL_FILE_ERROR

        self._abort_transfer(upload, status=status)

        log.add(_("Upload I/O error: %s"), error)
        self._check_upload_queue()

    def _file_transfer_init(self, msg):
        """We are requesting to start uploading a file to a peer."""

        username = msg.username
        token = msg.token
        upload = self.active_users.get(username, {}).get(token)

        if upload is None or upload.sock is not None:
            return

        virtual_path = upload.virtual_path
        sock = msg.sock
        need_update = True
        upload_started = False

        log.add_transfer("Initializing upload with token %s for file %s to user %s",
                         (token, virtual_path, username))

        real_path = core.shares.virtual2real(virtual_path)

        try:
            file_handle, current_size = self._open_upload_file(virtual_path, real_path)

            if upload.size != current_size:
                file_handle.close()
                raise OSError(
                    f"Requested file size changed from {upload.size} to {current_size}: {virtual_path}"
                )

        except OSError as error:
            log.add(_("Upload I/O error: %s"), error)
            self._abort_transfer(upload, status=TransferStatus.LOCAL_FILE_ERROR)
            self._check_upload_queue()

        else:
            if upload.size > 0 and core.send_message_to_network_thread(UploadFile(
                    sock=sock, token=token, file=file_handle, size=upload.size, username=username)) is False:
                file_handle.close()
                log.add_transfer(
                    "Aborting upload %s to user %s because the UploadFile handoff was rejected",
                    (virtual_path, username)
                )
                self._abort_transfer(upload, status=TransferStatus.CONNECTION_CLOSED)
                self._check_upload_queue()
                return

            upload.sock = sock
            upload.file_handle = file_handle
            upload.start_time = time.monotonic() - upload.time_elapsed

            core.statistics.append_stat_value("started_uploads", 1)
            upload_started = True

            log.add_upload(
                _("Upload started: user %(user)s, IP address %(ip)s, file %(file)s"), {
                    "user": username,
                    "ip": core.users.addresses.get(username),
                    "file": virtual_path
                }
            )

            if upload.size > 0:
                upload.status = TransferStatus.TRANSFERRING

            else:
                self._finish_transfer(upload)
                need_update = False

        if need_update:
            self._update_transfer(upload)

        if upload_started:
            # Must be be emitted after the final update to prevent inconsistent state
            core.pluginhandler.upload_started_notification(username, virtual_path, real_path)

    def _file_upload_progress(self, username, token, offset, bytes_sent, speed=None):
        """A file upload is in progress."""

        upload = self.active_users.get(username, {}).get(token)

        if upload is None:
            return

        if upload.request_timer_id is not None:
            events.cancel_scheduled(upload.request_timer_id)
            upload.request_timer_id = None

        if upload.last_byte_offset is None:
            upload.last_byte_offset = offset

        self._update_transfer_progress(
            upload, stat_id="uploaded_size",
            current_byte_offset=(offset + bytes_sent) if offset is not None else None,
            speed=speed
        )
        self._update_transfer(upload)


    @staticmethod
    def _get_peer_transfer_notice_key(username, msg):
        return (
            msg.__class__, username,
            getattr(msg, "file", None),
            getattr(msg, "filename", None),
            getattr(msg, "reason", None),
            getattr(msg, "place", None)
        )

    def _clear_peer_transfer_notices(self):
        self._pending_peer_transfer_notices.clear()
        self._pending_peer_transfer_notice_keys.clear()
        self._pending_peer_transfer_notices_limit_logged = False
        self._peer_transfer_notice_timer_id = None

    def _schedule_peer_transfer_notices(self, delay=0):

        if self._peer_transfer_notice_timer_id is not None:
            return

        self._peer_transfer_notice_timer_id = events.schedule(
            delay=delay, callback=self._process_peer_transfer_notices)

    def _queue_peer_transfer_notice(self, username, msg):
        key = self._get_peer_transfer_notice_key(username, msg)

        if key in self._pending_peer_transfer_notice_keys:
            return

        if len(self._pending_peer_transfer_notices) >= self.MAX_PENDING_PEER_TRANSFER_NOTICES:
            if not self._pending_peer_transfer_notices_limit_logged:
                log.add_transfer(
                    "Dropping additional peer transfer notices; pending notice limit %s reached",
                    self.MAX_PENDING_PEER_TRANSFER_NOTICES
                )
                self._pending_peer_transfer_notices_limit_logged = True

            return

        self._pending_peer_transfer_notice_keys.add(key)
        self._pending_peer_transfer_notices.append((username, msg, key))
        self._schedule_peer_transfer_notices(delay=self.PEER_TRANSFER_NOTICE_RETRY_DELAY)

    def _send_peer_transfer_notice(self, username, msg):

        if core.send_message_to_peer(username, msg) is False:
            self._queue_peer_transfer_notice(username, msg)
            return False

        return True

    def _process_peer_transfer_notices(self):
        self._peer_transfer_notice_timer_id = None
        num_sent = 0

        while (self._pending_peer_transfer_notices
                and num_sent < self.MAX_PEER_TRANSFER_NOTICES_PER_TICK):
            username, msg, key = self._pending_peer_transfer_notices.popleft()
            self._pending_peer_transfer_notice_keys.discard(key)

            if core.send_message_to_peer(username, msg) is False:
                self._pending_peer_transfer_notice_keys.add(key)
                self._pending_peer_transfer_notices.appendleft((username, msg, key))
                self._schedule_peer_transfer_notices(delay=self.PEER_TRANSFER_NOTICE_RETRY_DELAY)
                return

            num_sent += 1

        if self._pending_peer_transfer_notices:
            self._schedule_peer_transfer_notices()
        else:
            self._pending_peer_transfer_notices_limit_logged = False

    def _send_upload_denied_message(self, username, virtual_path, denied_message):
        return self._send_peer_transfer_notice(
            username, UploadDenied(virtual_path, denied_message))


    def _schedule_upload_speed_report_retry(self):

        if self._upload_speed_report_timer_id is not None:
            return

        self._upload_speed_report_timer_id = events.schedule(
            delay=self.UPLOAD_SPEED_REPORT_RETRY_DELAY, callback=self._process_upload_speed_reports)

    def _queue_upload_speed_report(self, avg_speed):

        if len(self._pending_upload_speed_reports) >= self.MAX_PENDING_UPLOAD_SPEED_REPORTS:
            self._pending_upload_speed_reports.popleft()

        self._pending_upload_speed_reports.append(avg_speed)
        self._schedule_upload_speed_report_retry()

    def _send_upload_speed_report(self, avg_speed):

        if core.send_message_to_server(SendUploadSpeed(avg_speed)) is False:
            self._queue_upload_speed_report(avg_speed)
            return False

        return True

    def _process_upload_speed_reports(self):
        self._upload_speed_report_timer_id = None
        num_sent = 0

        while self._pending_upload_speed_reports and num_sent < self.MAX_UPLOAD_SPEED_REPORTS_PER_TICK:
            avg_speed = self._pending_upload_speed_reports.popleft()

            if core.send_message_to_server(SendUploadSpeed(avg_speed)) is False:
                self._pending_upload_speed_reports.appendleft(avg_speed)
                self._schedule_upload_speed_report_retry()
                return

            num_sent += 1

        if self._pending_upload_speed_reports:
            self._schedule_upload_speed_report_retry()


    def _server_message_unsent(self, msg):
        if msg.__class__ is not SendUploadSpeed:
            return

        # A completed upload speed report can be accepted into the local queue
        # but still fail below that boundary if the server socket vanishes or
        # the bounded output buffer refuses the packed message. Reuse the same
        # retry lane as public-queue rejection so transient backpressure does
        # not silently drop the report.
        self._queue_upload_speed_report(msg.speed)

    def _file_connection_closed(
            self, username, token, sock, timed_out, current_byte_offset=None, **_unused):
        """A file upload connection has closed for any reason."""

        upload = self.active_users.get(username, {}).get(token)

        if upload is None:
            return

        if upload.sock != sock:
            return

        if current_byte_offset is not None:
            current_byte_offset = max(0, min(upload.size, current_byte_offset))

        if (current_byte_offset is not None
                and current_byte_offset > (upload.current_byte_offset or 0)):
            self._update_transfer_progress(
                upload, stat_id="uploaded_size", current_byte_offset=current_byte_offset)

        if not timed_out and upload.current_byte_offset is not None and upload.current_byte_offset >= upload.size:
            # We finish the upload here in case the downloading peer has a slow/limited download
            # speed and finishes later than us

            self._finish_transfer(upload)

            if upload.avg_speed > 0:
                # Inform the server about the average upload speed for this transfer.
                # Treat the bounded server-output queue as the accepted-work boundary;
                # if the queue is under backpressure, retry a bounded number of speed
                # reports later instead of silently losing the report.
                log.add_transfer("Sending average upload speed %s to the server", upload.avg_speed)
                self._send_upload_speed_report(upload.avg_speed)

            return

        if core.users.statuses.get(upload.username) == UserStatus.OFFLINE:
            status = TransferStatus.USER_LOGGED_OFF
        else:
            status = TransferStatus.CANCELLED

            # Transfer ended abruptly. Tell the peer to re-queue the file. If the transfer was
            # intentionally cancelled, the peer should ignore this message.
            self._send_peer_transfer_notice(upload.username, UploadFailed(upload.virtual_path))

        if not self._auto_clear_transfer(upload):
            self._abort_transfer(upload, status=status)

        self._check_upload_queue()


    def _is_queue_position_request_limited(self, username, virtual_path):
        """Return True if a peer is asking for the same queue position too frequently."""

        request_time = time.monotonic()
        request_key = (username, virtual_path)
        previous_request_time = self._queue_position_request_times.get(request_key)

        if (previous_request_time is not None
                and request_time < previous_request_time + self.QUEUE_POSITION_REQUEST_INTERVAL):
            return True

        if request_time >= self._queue_position_request_window_time + self.QUEUE_POSITION_REQUEST_INTERVAL:
            self._queue_position_request_window_time = request_time
            self._queue_position_request_window_count = 0

        if self._queue_position_request_window_count >= self.MAX_QUEUE_POSITION_REQUESTS_PER_INTERVAL:
            return True

        if (request_key not in self._queue_position_request_times
                and len(self._queue_position_request_times) >= self.MAX_QUEUE_POSITION_REQUEST_TIMES):
            # Keep the rate-limit table bounded even if many peers ask for queue
            # positions. Requests older than the interval no longer affect
            # limiting, so they can be discarded safely.
            minimum_request_time = request_time - self.QUEUE_POSITION_REQUEST_INTERVAL
            self._queue_position_request_times = {
                key: timestamp for key, timestamp in self._queue_position_request_times.items()
                if timestamp >= minimum_request_time
            }

            if len(self._queue_position_request_times) >= self.MAX_QUEUE_POSITION_REQUEST_TIMES:
                return True

        self._queue_position_request_times[request_key] = request_time
        self._queue_position_request_window_count += 1
        return False

    def _place_in_queue_request(self, msg):
        """Peer code 51."""

        username = msg.username
        virtual_path = msg.file
        upload = self.queued_users.get(username, {}).get(virtual_path)

        if upload is None:
            return

        if self._is_queue_position_request_limited(username, virtual_path):
            return

        is_fifo_queue = config.sections["transfers"]["fifoqueue"]
        is_privileged_queue = self.is_privileged(username)
        privileged_queued_users = self._get_privileged_queued_users()
        queue_position = 0

        if is_fifo_queue:
            queue_mode = "fifo-privileged" if is_privileged_queue else "fifo"
            cached_position = self._get_cached_queue_position(queue_mode, upload)

            if cached_position is not None:
                queue_position = cached_position

            elif is_privileged_queue:
                for i_upload in self.queued_transfers:
                    if i_upload.username not in privileged_queued_users:
                        continue

                    queue_position += 1
                    self._cache_queue_position(queue_mode, i_upload, queue_position)

                    if i_upload is upload:
                        break
                else:
                    queue_position = 0
            else:
                for position, i_upload in enumerate(self.queued_transfers, start=1):
                    self._cache_queue_position(queue_mode, i_upload, position)

                    if i_upload is upload:
                        queue_position = position
                        break
        else:
            queue_mode = "non-fifo-privileged" if is_privileged_queue else "non-fifo"
            cached_position = self._get_cached_queue_position(queue_mode, upload)

            if cached_position is not None:
                queue_position = cached_position
            else:
                if is_privileged_queue:
                    queue_position_base = len(privileged_queued_users)
                else:
                    # Cycling through privileged users first
                    queue_position_base = (
                        sum(num_queued_uploads for num_queued_uploads in privileged_queued_users.values())
                        + len(self.queued_users)
                    )

                user_queue_positions = self._queue_position_users.get(username)
                user_queue_position = None if user_queue_positions is None else user_queue_positions.get(virtual_path)

                if user_queue_position is None:
                    for position, i_upload in enumerate(self.queued_users[username].values(), start=1):
                        self._cache_queue_position(
                            queue_mode, i_upload, queue_position_base + position, user_position=position)

                        if i_upload is upload:
                            user_queue_position = position
                            break

                if user_queue_position is None or user_queue_position <= 0:
                    return

                queue_position = queue_position_base + user_queue_position

        self._privileged_position_requested = is_privileged_queue

        if queue_position > 0:
            if core.send_message_to_peer(username, PlaceInQueueResponse(virtual_path, queue_position)) is False:
                log.add_transfer(
                    "Queue-position response for file %s to user %s was rejected by the local network queue",
                    (virtual_path, username)
                )
                return

        # Update queue position in our list of uploads only after the response
        # has been accepted locally. Otherwise local/UI state claims we answered
        # a queue-position request that may never reach the peer.
        upload.queue_position = queue_position
        self._update_transfer(upload, update_parent=False)
