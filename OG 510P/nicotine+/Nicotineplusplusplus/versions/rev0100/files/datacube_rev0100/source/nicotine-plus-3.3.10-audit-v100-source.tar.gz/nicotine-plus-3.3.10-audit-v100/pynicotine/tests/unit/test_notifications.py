# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from unittest import TestCase
from unittest.mock import patch

from pynicotine.config import config
from pynicotine.events import events
from pynicotine.notifications import Notifications


class FakeThread:

    def __init__(self, *args, **kwargs):
        pass

    @staticmethod
    def is_alive():
        return True

    @staticmethod
    def start():
        return None


class NotificationsTest(TestCase):

    def test_tts_queue_is_bounded(self):
        old_ui_section = config.sections.setdefault("ui", {}).copy()
        old_limit = Notifications.MAX_TTS_QUEUE
        config.sections["ui"]["speechenabled"] = True
        config.sections["ui"].setdefault("speechcommand", "")
        Notifications.MAX_TTS_QUEUE = 3

        try:
            notifications = Notifications()

            with patch("pynicotine.notifications.Thread", FakeThread):
                for index in range(5):
                    notifications.new_tts(f"message {index}")

            self.assertEqual(["message 0", "message 1", "message 2"], list(notifications.tts))
            self.assertTrue(notifications._tts_queue_limit_logged)

        finally:
            events.disconnect("quit", notifications._quit)
            config.sections["ui"].clear()
            config.sections["ui"].update(old_ui_section)
            Notifications.MAX_TTS_QUEUE = old_limit


    def test_tts_command_launches_are_rate_limited(self):
        old_ui_section = config.sections.setdefault("ui", {}).copy()
        old_limit = Notifications.MAX_TTS_COMMANDS_PER_MINUTE
        config.sections["ui"]["speechenabled"] = True
        config.sections["ui"]["speechcommand"] = "say $"
        Notifications.MAX_TTS_COMMANDS_PER_MINUTE = 2

        try:
            notifications = Notifications()
            notifications.tts.extend(["one", "two", "three"] )
            executed = []

            def fake_execute(command, replacement=None, **_kwargs):
                executed.append((command, replacement))

            with patch("pynicotine.notifications.execute_command", side_effect=fake_execute), \
                    patch("pynicotine.notifications.time.monotonic", return_value=100):
                notifications.play_tts()

            self.assertEqual([("say $", "one"), ("say $", "two")], executed)
            self.assertTrue(notifications._tts_command_limit_logged)

        finally:
            events.disconnect("quit", notifications._quit)
            config.sections["ui"].clear()
            config.sections["ui"].update(old_ui_section)
            Notifications.MAX_TTS_COMMANDS_PER_MINUTE = old_limit

    def test_popup_notifications_are_rate_limited(self):
        old_limit = Notifications.MAX_POPUP_NOTIFICATIONS_PER_MINUTE
        Notifications.MAX_POPUP_NOTIFICATIONS_PER_MINUTE = 2
        notifications = Notifications()
        emitted = []

        def callback(message, title=None):
            emitted.append((message, title))

        events.connect("show-notification", callback)

        try:
            notifications.show_notification("one", title="title")
            notifications.show_notification("two")
            notifications.show_notification("three")

            self.assertEqual([("one", "title"), ("two", None)], emitted)
            self.assertTrue(notifications._popup_notification_limit_logged)

        finally:
            events.disconnect("show-notification", callback)
            events.disconnect("quit", notifications._quit)
            Notifications.MAX_POPUP_NOTIFICATIONS_PER_MINUTE = old_limit


    def test_popup_notification_payload_is_truncated_before_emit(self):
        old_message_chars = Notifications.MAX_NOTIFICATION_MESSAGE_CHARS
        old_title_chars = Notifications.MAX_NOTIFICATION_TITLE_CHARS
        Notifications.MAX_NOTIFICATION_MESSAGE_CHARS = 4
        Notifications.MAX_NOTIFICATION_TITLE_CHARS = 3
        notifications = Notifications()
        emitted = []

        def callback(message, title=None):
            emitted.append((message, title))

        events.connect("show-notification", callback)

        try:
            notifications.show_notification("abcdef", title="title")

            self.assertEqual([("abcd", "tit")], emitted)

        finally:
            events.disconnect("show-notification", callback)
            events.disconnect("quit", notifications._quit)
            Notifications.MAX_NOTIFICATION_MESSAGE_CHARS = old_message_chars
            Notifications.MAX_NOTIFICATION_TITLE_CHARS = old_title_chars

    def test_tts_messages_are_truncated_before_queueing(self):
        old_ui_section = config.sections.setdefault("ui", {}).copy()
        old_max_chars = Notifications.MAX_TTS_MESSAGE_CHARS
        config.sections["ui"]["speechenabled"] = True
        config.sections["ui"].setdefault("speechcommand", "")
        Notifications.MAX_TTS_MESSAGE_CHARS = 4

        try:
            notifications = Notifications()

            with patch("pynicotine.notifications.Thread", FakeThread):
                notifications.new_tts("abcdef")

            self.assertEqual(["abcd"], list(notifications.tts))

        finally:
            events.disconnect("quit", notifications._quit)
            config.sections["ui"].clear()
            config.sections["ui"].update(old_ui_section)
            Notifications.MAX_TTS_MESSAGE_CHARS = old_max_chars
