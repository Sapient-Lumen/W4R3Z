# COPYRIGHT (C) 2021-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from collections import deque
from itertools import islice

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.slskmessages import AddThingIHate
from pynicotine.slskmessages import AddThingILike
from pynicotine.slskmessages import GLOBAL_RECOMMENDATIONS_ALLOWED
from pynicotine.slskmessages import GlobalRecommendations
from pynicotine.slskmessages import ITEM_RECOMMENDATIONS_ALLOWED
from pynicotine.slskmessages import ItemRecommendations
from pynicotine.slskmessages import ITEM_SIMILAR_USERS_ALLOWED
from pynicotine.slskmessages import ItemSimilarUsers
from pynicotine.slskmessages import RECOMMENDATIONS_ALLOWED
from pynicotine.slskmessages import Recommendations
from pynicotine.slskmessages import SIMILAR_USERS_ALLOWED
from pynicotine.slskmessages import RemoveThingILike
from pynicotine.slskmessages import RemoveThingIHate
from pynicotine.slskmessages import SimilarUsers
from pynicotine.slskmessages import clear_interests_response_grants
from pynicotine.watchbatch import WatchUserBatcher


class SimilarUser:
    __slots__ = ("username", "rating")

    def __init__(self, username, rating=None):
        self.username = username
        self.rating = rating


class Interests:
    __slots__ = (
        "similar_users", "_similar_users_limit_logged", "_watch_batcher", "_unwatch_queue",
        "_unwatch_keys", "_unwatch_timer_id", "_unwatch_limit_logged",
        "_pending_recommendations", "_pending_global_recommendations", "_pending_similar_users",
        "_pending_item_recommendations", "_pending_item_similar_users",
        "_pending_interest_response_limit_logged", "_interest_sync_queue",
        "_interest_sync_keys", "_interest_sync_timer_id", "_interest_sync_limit_logged",
        "_interest_request_retry_queue", "_interest_request_retry_keys",
        "_interest_request_retry_timer_id", "_interest_request_retry_limit_logged"
    )
    MAX_SIMILAR_USERS = 8192
    MAX_PENDING_ITEM_RECOMMENDATION_REQUESTS = 4096
    MAX_SIMILAR_USER_WATCHES_PER_TICK = 1000
    MAX_PENDING_SIMILAR_USER_WATCHES = 8192
    MAX_SIMILAR_USER_UNWATCHES_PER_TICK = 1000
    MAX_PENDING_SIMILAR_USER_UNWATCHES = 8192
    MAX_INTEREST_SYNC_ITEMS_PER_TICK = 1000
    MAX_PENDING_INTEREST_SYNC_ITEMS = 8192
    INTEREST_SYNC_RETRY_DELAY = 1
    MAX_INTEREST_REQUEST_RETRIES_PER_TICK = 64
    MAX_PENDING_INTEREST_REQUEST_RETRIES = 512
    INTEREST_REQUEST_RETRY_DELAY = 1

    def __init__(self):

        self.similar_users = {}
        self._similar_users_limit_logged = False
        self._watch_batcher = WatchUserBatcher(
            "interests", lambda username: username in self.similar_users,
            lambda: self.MAX_SIMILAR_USER_WATCHES_PER_TICK,
            lambda: self.MAX_PENDING_SIMILAR_USER_WATCHES
        )
        self._unwatch_queue = deque()
        self._unwatch_keys = set()
        self._unwatch_timer_id = None
        self._unwatch_limit_logged = False
        self._pending_recommendations = False
        self._pending_global_recommendations = False
        self._pending_similar_users = False
        self._pending_item_recommendations = set()
        self._pending_item_similar_users = set()
        self._pending_interest_response_limit_logged = False
        self._interest_sync_queue = deque()
        self._interest_sync_keys = set()
        self._interest_sync_timer_id = None
        self._interest_sync_limit_logged = False
        self._interest_request_retry_queue = deque()
        self._interest_request_retry_keys = set()
        self._interest_request_retry_timer_id = None
        self._interest_request_retry_limit_logged = False

        for event_name, callback in (
            ("global-recommendations", self._global_recommendations),
            ("item-recommendations", self._item_recommendations),
            ("item-similar-users", self._item_similar_users),
            ("quit", self._quit),
            ("recommendations", self._recommendations),
            ("server-login", self._server_login),
            ("server-disconnect", self._server_disconnect),
            ("server-message-unsent", self._server_message_unsent),
            ("server-response-delivery-failed", self._server_response_delivery_failed),
            ("similar-users", self._similar_users)
        ):
            events.connect(event_name, callback)

    def _quit(self):
        self._cancel_similar_user_batches()
        self._cancel_interest_sync_queue()
        self._clear_interest_request_retries()
        self._clear_pending_interest_responses()
        self.similar_users.clear()
        self._similar_users_limit_logged = False

    def _server_disconnect(self, _msg):
        self._cancel_similar_user_batches()
        self._cancel_interest_sync_queue()
        self._clear_interest_request_retries()
        self._clear_pending_interest_responses()
        self.similar_users.clear()
        self._similar_users_limit_logged = False

    def _clear_pending_interest_responses(self):
        clear_interests_response_grants()
        self._pending_recommendations = False
        self._pending_global_recommendations = False
        self._pending_similar_users = False
        self._pending_item_recommendations.clear()
        self._pending_item_similar_users.clear()
        self._pending_interest_response_limit_logged = False

    @staticmethod
    def _reject_interest_response(msg):
        try:
            msg.is_allowed = False
        except AttributeError:
            pass

        if hasattr(msg, "recommendations"):
            msg.recommendations = []
            msg.unrecommendations = []

        if hasattr(msg, "users"):
            msg.users = {} if isinstance(msg.users, dict) else []

    def _can_grant_item_interest_response(self, pending_items):
        if len(pending_items) >= self.MAX_PENDING_ITEM_RECOMMENDATION_REQUESTS:
            if not self._pending_interest_response_limit_logged:
                log.add_debug(
                    "Discarding item recommendation request; pending interest-response limit %s reached",
                    self.MAX_PENDING_ITEM_RECOMMENDATION_REQUESTS
                )
                self._pending_interest_response_limit_logged = True

            return False

        return True

    def _grant_item_interest_response(self, pending_items, item):
        if item in pending_items:
            return False

        if not self._can_grant_item_interest_response(pending_items):
            return False

        pending_items.add(item)
        self._pending_interest_response_limit_logged = False
        return True

    def _consume_item_interest_response(self, pending_items, msg):
        item = msg.thing

        if item not in pending_items:
            self._reject_interest_response(msg)
            return False

        pending_items.discard(item)
        return True

    def _cancel_similar_user_batches(self):
        self._watch_batcher.cancel()
        events.cancel_scheduled(self._unwatch_timer_id)
        self._unwatch_timer_id = None
        self._unwatch_queue.clear()
        self._unwatch_keys.clear()
        self._unwatch_limit_logged = False

    def _schedule_similar_user_unwatches(self):
        if not self._unwatch_queue or self._unwatch_timer_id is not None:
            return

        self._unwatch_timer_id = events.schedule(delay=0, callback=self._process_similar_user_unwatches)

        if self._unwatch_timer_id is None:
            self._unwatch_queue.clear()
            self._unwatch_keys.clear()

    def _queue_similar_user_unwatches(self, usernames):
        for username in usernames:
            if username in self._unwatch_keys:
                continue

            if len(self._unwatch_queue) >= self.MAX_PENDING_SIMILAR_USER_UNWATCHES:
                if not self._unwatch_limit_logged:
                    log.add_debug(
                        "Similar-user unwatch queue reached %s users; discarding additional users",
                        self.MAX_PENDING_SIMILAR_USER_UNWATCHES
                    )
                    self._unwatch_limit_logged = True

                break

            self._unwatch_queue.append(username)
            self._unwatch_keys.add(username)

        self._process_similar_user_unwatches()

    def _process_similar_user_unwatches(self):
        self._unwatch_timer_id = None
        num_processed = 0

        while self._unwatch_queue and num_processed < self.MAX_SIMILAR_USER_UNWATCHES_PER_TICK:
            username = self._unwatch_queue.popleft()
            self._unwatch_keys.discard(username)
            num_processed += 1

            if username in self.similar_users:
                continue

            core.users.unwatch_user(username, context="interests")

        if self._unwatch_queue:
            self._schedule_similar_user_unwatches()
        else:
            self._unwatch_limit_logged = False

    def _cancel_interest_sync_queue(self):
        events.cancel_scheduled(self._interest_sync_timer_id)
        self._interest_sync_timer_id = None
        self._interest_sync_queue.clear()
        self._interest_sync_keys.clear()
        self._interest_sync_limit_logged = False

    def _clear_interest_request_retries(self):
        events.cancel_scheduled(self._interest_request_retry_timer_id)
        self._interest_request_retry_timer_id = None
        self._interest_request_retry_queue.clear()
        self._interest_request_retry_keys.clear()
        self._interest_request_retry_limit_logged = False

    def _queue_interest_request_retry(self, kind, item=None):
        if kind in {"item-recommendations", "item-similar-users"}:
            item = self._normalize_interest_item(item)

            if item is None:
                return False

        elif kind not in {"recommendations", "global-recommendations", "similar-users"}:
            return False

        key = (kind, item)

        if key in self._interest_request_retry_keys:
            return True

        if len(self._interest_request_retry_queue) >= self.MAX_PENDING_INTEREST_REQUEST_RETRIES:
            if not self._interest_request_retry_limit_logged:
                log.add_debug(
                    "Interest response retry queue reached %s items; discarding additional retries",
                    self.MAX_PENDING_INTEREST_REQUEST_RETRIES
                )
                self._interest_request_retry_limit_logged = True

            return False

        self._interest_request_retry_keys.add(key)
        self._interest_request_retry_queue.append(key)
        self._schedule_interest_request_retries(delay=self.INTEREST_REQUEST_RETRY_DELAY)
        return True

    def _schedule_interest_request_retries(self, delay=0):
        if not self._interest_request_retry_queue or self._interest_request_retry_timer_id is not None:
            return

        self._interest_request_retry_timer_id = events.schedule(
            delay=delay, callback=self._process_interest_request_retries)

        if self._interest_request_retry_timer_id is None:
            self._clear_interest_request_retries()

    def _process_interest_request_retries(self):
        self._interest_request_retry_timer_id = None
        num_processed = 0

        while (self._interest_request_retry_queue
                and num_processed < self.MAX_INTEREST_REQUEST_RETRIES_PER_TICK):
            kind, item = self._interest_request_retry_queue.popleft()
            self._interest_request_retry_keys.discard((kind, item))
            num_processed += 1

            if kind == "recommendations":
                success = self.request_recommendations()
            elif kind == "global-recommendations":
                success = self.request_global_recommendations()
            elif kind == "similar-users":
                success = self.request_similar_users()
            elif kind == "item-recommendations":
                success = self.request_item_recommendations(item)
            elif kind == "item-similar-users":
                success = self.request_item_similar_users(item)
            else:
                success = True

            if success is False:
                self._interest_request_retry_queue.appendleft((kind, item))
                self._interest_request_retry_keys.add((kind, item))
                break

        if self._interest_request_retry_queue:
            self._schedule_interest_request_retries(delay=self.INTEREST_REQUEST_RETRY_DELAY)
        else:
            self._interest_request_retry_limit_logged = False

    @staticmethod
    def _normalize_interest_item(item):
        if not isinstance(item, str):
            return None

        item = item.strip().lower()
        return item or None

    @staticmethod
    def _make_interest_sync_message(kind, item):
        if kind in {"like", "add_like"}:
            return AddThingILike(item)

        if kind in {"hate", "add_hate"}:
            return AddThingIHate(item)

        if kind == "remove_like":
            return RemoveThingILike(item)

        if kind == "remove_hate":
            return RemoveThingIHate(item)

        return None

    @classmethod
    def _interest_config_contains(cls, items, item):
        return any(cls._normalize_interest_item(config_item) == item for config_item in items)

    @classmethod
    def _is_interest_sync_still_wanted(cls, kind, item):
        if kind in {"like", "add_like"}:
            return cls._interest_config_contains(config.sections["interests"]["likes"], item)

        if kind in {"hate", "add_hate"}:
            return cls._interest_config_contains(config.sections["interests"]["dislikes"], item)

        if kind == "remove_like":
            return not cls._interest_config_contains(config.sections["interests"]["likes"], item)

        if kind == "remove_hate":
            return not cls._interest_config_contains(config.sections["interests"]["dislikes"], item)

        return False

    def _queue_interest_sync_item(self, kind, item):
        item = self._normalize_interest_item(item)

        if item is None:
            return True

        if self._make_interest_sync_message(kind, item) is None:
            return False

        if not self._is_interest_sync_still_wanted(kind, item):
            return True

        key = (kind, item)

        if key in self._interest_sync_keys:
            return True

        if len(self._interest_sync_queue) >= self.MAX_PENDING_INTEREST_SYNC_ITEMS:
            if not self._interest_sync_limit_logged:
                log.add_debug(
                    "Interest sync queue reached %s items; discarding additional login-time interests",
                    self.MAX_PENDING_INTEREST_SYNC_ITEMS
                )
                self._interest_sync_limit_logged = True

            return False

        self._interest_sync_queue.append(key)
        self._interest_sync_keys.add(key)
        return True

    def _schedule_interest_sync_queue(self, delay=0):
        if not self._interest_sync_queue or self._interest_sync_timer_id is not None:
            return

        self._interest_sync_timer_id = events.schedule(delay=delay, callback=self._process_interest_sync_queue)

        if self._interest_sync_timer_id is None:
            # Scheduler is saturated. Drop the remaining replay queue instead of
            # retaining a potentially stale login-time backlog.
            self._interest_sync_queue.clear()
            self._interest_sync_keys.clear()

    def _process_interest_sync_queue(self):
        self._interest_sync_timer_id = None
        num_processed = 0

        while self._interest_sync_queue and num_processed < self.MAX_INTEREST_SYNC_ITEMS_PER_TICK:
            kind, item = self._interest_sync_queue.popleft()
            self._interest_sync_keys.discard((kind, item))
            num_processed += 1

            if not self._is_interest_sync_still_wanted(kind, item):
                continue

            msg = self._make_interest_sync_message(kind, item)

            if msg is None or core.send_message_to_server(msg) is not False:
                continue

            # The interest sync queue is replaying durable local config into
            # server state. If local network backpressure rejects one item, do
            # not drop the rest of the sync batch as if it had been sent. Put
            # the item back at the head and retry later.
            self._interest_sync_queue.appendleft((kind, item))
            self._interest_sync_keys.add((kind, item))

            if not self._interest_sync_limit_logged:
                log.add_debug(
                    "Interest sync message for %s was rejected by the network queue; retrying later", item
                )
                self._interest_sync_limit_logged = True

            self._schedule_interest_sync_queue(delay=self.INTEREST_SYNC_RETRY_DELAY)
            return

        if self._interest_sync_queue:
            if not self._interest_sync_limit_logged:
                log.add_debug(
                    "Synchronizing interests in batches of %s items to avoid login-time network bursts",
                    self.MAX_INTEREST_SYNC_ITEMS_PER_TICK
                )
                self._interest_sync_limit_logged = True

            self._schedule_interest_sync_queue()
            return

        self._interest_sync_limit_logged = False

    def _server_login(self, msg):

        if not msg.success:
            return

        self._cancel_interest_sync_queue()

        for item in config.sections["interests"]["likes"]:
            if not self._queue_interest_sync_item("add_like", item):
                break

        for item in config.sections["interests"]["dislikes"]:
            if not self._queue_interest_sync_item("add_hate", item):
                break

        self._process_interest_sync_queue()

    def add_thing_i_like(self, item):

        item = self._normalize_interest_item(item)

        if item is None:
            return False

        if item in config.sections["interests"]["likes"]:
            return True

        if core.send_message_to_server(AddThingILike(item)) is False:
            return False

        config.sections["interests"]["likes"].append(item)
        config.write_configuration()
        events.emit("add-interest", item)
        return True

    def add_thing_i_hate(self, item):

        item = self._normalize_interest_item(item)

        if item is None:
            return False

        if item in config.sections["interests"]["dislikes"]:
            return True

        if core.send_message_to_server(AddThingIHate(item)) is False:
            return False

        config.sections["interests"]["dislikes"].append(item)
        config.write_configuration()
        events.emit("add-dislike", item)
        return True

    def remove_thing_i_like(self, item):

        item = self._normalize_interest_item(item)

        if item is None:
            return False

        if item not in config.sections["interests"]["likes"]:
            return True

        if core.send_message_to_server(RemoveThingILike(item)) is False:
            return False

        config.sections["interests"]["likes"].remove(item)
        config.write_configuration()
        events.emit("remove-interest", item)
        return True

    def remove_thing_i_hate(self, item):

        item = self._normalize_interest_item(item)

        if item is None:
            return False

        if item not in config.sections["interests"]["dislikes"]:
            return True

        if core.send_message_to_server(RemoveThingIHate(item)) is False:
            return False

        config.sections["interests"]["dislikes"].remove(item)
        config.write_configuration()
        events.emit("remove-dislike", item)
        return True

    def request_global_recommendations(self):
        if self._pending_global_recommendations:
            return False

        if core.send_message_to_server(GlobalRecommendations()) is False:
            return False

        self._pending_global_recommendations = True
        GLOBAL_RECOMMENDATIONS_ALLOWED.add()
        return True

    def request_item_recommendations(self, item):
        if item in self._pending_item_recommendations:
            return False

        if not self._can_grant_item_interest_response(self._pending_item_recommendations):
            return False

        if core.send_message_to_server(ItemRecommendations(item)) is False:
            return False

        self._grant_item_interest_response(self._pending_item_recommendations, item)
        ITEM_RECOMMENDATIONS_ALLOWED.add(item)
        return True

    def request_item_similar_users(self, item):
        if item in self._pending_item_similar_users:
            return False

        if not self._can_grant_item_interest_response(self._pending_item_similar_users):
            return False

        if core.send_message_to_server(ItemSimilarUsers(item)) is False:
            return False

        self._grant_item_interest_response(self._pending_item_similar_users, item)
        ITEM_SIMILAR_USERS_ALLOWED.add(item)
        return True

    def request_recommendations(self):
        if self._pending_recommendations:
            return False

        if core.send_message_to_server(Recommendations()) is False:
            return False

        self._pending_recommendations = True
        RECOMMENDATIONS_ALLOWED.add()
        return True

    def request_similar_users(self):
        if self._pending_similar_users:
            return False

        if core.send_message_to_server(SimilarUsers()) is False:
            return False

        self._pending_similar_users = True
        SIMILAR_USERS_ALLOWED.add()
        return True

    def _server_message_unsent(self, msg):
        """Rollback or retry interest requests that failed below public queue acceptance."""

        msg_class = msg.__class__

        if msg_class is Recommendations:
            self._pending_recommendations = False
            RECOMMENDATIONS_ALLOWED.consume()
            return

        if msg_class is GlobalRecommendations:
            self._pending_global_recommendations = False
            GLOBAL_RECOMMENDATIONS_ALLOWED.consume()
            return

        if msg_class is SimilarUsers:
            self._pending_similar_users = False
            SIMILAR_USERS_ALLOWED.consume()
            return

        if msg_class is ItemRecommendations:
            self._pending_item_recommendations.discard(msg.thing)
            ITEM_RECOMMENDATIONS_ALLOWED.discard(msg.thing)
            return

        if msg_class is ItemSimilarUsers:
            self._pending_item_similar_users.discard(msg.thing)
            ITEM_SIMILAR_USERS_ALLOWED.discard(msg.thing)
            return

        if msg_class is AddThingILike:
            self._queue_interest_sync_item("add_like", msg.thing)
            self._schedule_interest_sync_queue(delay=self.INTEREST_SYNC_RETRY_DELAY)
            return

        if msg_class is AddThingIHate:
            self._queue_interest_sync_item("add_hate", msg.thing)
            self._schedule_interest_sync_queue(delay=self.INTEREST_SYNC_RETRY_DELAY)
            return

        if msg_class is RemoveThingILike:
            self._queue_interest_sync_item("remove_like", msg.thing)
            self._schedule_interest_sync_queue(delay=self.INTEREST_SYNC_RETRY_DELAY)
            return

        if msg_class is RemoveThingIHate:
            self._queue_interest_sync_item("remove_hate", msg.thing)
            self._schedule_interest_sync_queue(delay=self.INTEREST_SYNC_RETRY_DELAY)

    def _server_response_delivery_failed(self, msg_class, rollback_info):
        """Retry heavyweight server responses that parsed but could not reach handlers."""

        if not rollback_info:
            return

        rollback_kind = rollback_info[0]

        if msg_class is Recommendations and rollback_kind == "recommendations":
            self._pending_recommendations = False
            RECOMMENDATIONS_ALLOWED.consume()
            self._queue_interest_request_retry("recommendations")
            return

        if msg_class is GlobalRecommendations and rollback_kind == "global-recommendations":
            self._pending_global_recommendations = False
            GLOBAL_RECOMMENDATIONS_ALLOWED.consume()
            self._queue_interest_request_retry("global-recommendations")
            return

        if msg_class is SimilarUsers and rollback_kind == "similar-users":
            self._pending_similar_users = False
            SIMILAR_USERS_ALLOWED.consume()
            self._queue_interest_request_retry("similar-users")
            return

        if msg_class is ItemRecommendations and rollback_kind == "item-recommendations":
            item = rollback_info[1] if len(rollback_info) > 1 else None
            self._pending_item_recommendations.discard(item)
            ITEM_RECOMMENDATIONS_ALLOWED.discard(item)
            self._queue_interest_request_retry("item-recommendations", item)
            return

        if msg_class is ItemSimilarUsers and rollback_kind == "item-similar-users":
            item = rollback_info[1] if len(rollback_info) > 1 else None
            self._pending_item_similar_users.discard(item)
            ITEM_SIMILAR_USERS_ALLOWED.discard(item)
            self._queue_interest_request_retry("item-similar-users", item)

    def _global_recommendations(self, msg):
        """Server code 56."""

        if not self._pending_global_recommendations:
            self._reject_interest_response(msg)
            return

        self._pending_global_recommendations = False
        GLOBAL_RECOMMENDATIONS_ALLOWED.consume()

    def _recommendations(self, msg):
        """Server code 54."""

        if not self._pending_recommendations:
            self._reject_interest_response(msg)
            return

        self._pending_recommendations = False
        RECOMMENDATIONS_ALLOWED.consume()

    def _item_recommendations(self, msg):
        """Server code 111."""

        if self._consume_item_interest_response(self._pending_item_recommendations, msg):
            ITEM_RECOMMENDATIONS_ALLOWED.consume(msg.thing)

    def _similar_users(self, msg, has_ratings=True):
        """Server code 110."""

        if has_ratings:
            if not self._pending_similar_users:
                self._reject_interest_response(msg)
                return

            self._pending_similar_users = False
            SIMILAR_USERS_ALLOWED.consume()
        else:
            if not self._consume_item_interest_response(self._pending_item_similar_users, msg):
                return
            ITEM_SIMILAR_USERS_ALLOWED.consume(msg.thing)

        num_users = len(msg.users)

        if has_ratings:
            user_items = tuple(islice(msg.users.items(), self.MAX_SIMILAR_USERS))
            msg.users = dict(user_items)
        else:
            user_items = tuple((username, None) for username in islice(msg.users, self.MAX_SIMILAR_USERS))
            msg.users = [username for username, _rating in user_items]

        new_users = {username for username, _rating in user_items}

        if num_users > self.MAX_SIMILAR_USERS and not self._similar_users_limit_logged:
            log.add_debug("Discarding additional similar users from server response; "
                          "similar user limit %s reached", self.MAX_SIMILAR_USERS)
            self._similar_users_limit_logged = True

        stale_users = [username for username in self.similar_users if username not in new_users]

        self.similar_users.clear()

        # Add new users
        for username, rating in user_items:
            self.similar_users[username] = SimilarUser(username, rating)

        self._queue_similar_user_unwatches(stale_users)

        # Request user status, speed and number of shared files in bounded batches.
        self._watch_batcher.queue(new_users)

    def _item_similar_users(self, msg):
        """Server code 112."""

        self._similar_users(msg, has_ratings=False)
