# COPYRIGHT (C) 2020-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from collections import deque

from gi.repository import Gio

from pynicotine.events import events
from pynicotine.pluginsystem import BasePlugin


class Plugin(BasePlugin):

    MAX_BROADCAST_ROOMS = 256
    MAX_BROADCAST_ROOMS_PER_TICK = 16
    MAX_ROOM_NAME_CHARS = 1024
    MAX_MPRIS_PLAYER_CHARS = 256
    MAX_MPRIS_URL_CHARS = 8192

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        self.settings = {
            "rooms": ["testroom"]
        }
        self.metasettings = {
            "rooms": {
                "description": "Rooms to broadcast in",
                "type": "list string"
            }
        }

        self.last_song_url = ""
        self.stop = False
        self.pending_broadcast_rooms = deque()
        self.broadcast_timer_id = None
        self.broadcast_playing = None
        self.broadcast_limit_logged = False

        self.bus = Gio.bus_get_sync(bus_type=Gio.BusType.SESSION)
        self.signal_id = None
        self.dbus_mpris_service = "org.mpris.MediaPlayer2."

        self.add_mpris_signal_receiver()

    def disable(self):
        self.remove_mpris_signal_receiver()
        self._clear_broadcast_queue()

    def _clear_broadcast_queue(self):
        if self.broadcast_timer_id is not None:
            events.cancel_scheduled(self.broadcast_timer_id)
            self.broadcast_timer_id = None

        self.pending_broadcast_rooms.clear()
        self.broadcast_playing = None
        self.broadcast_limit_logged = False

    @classmethod
    def _normalize_broadcast_room(cls, room):
        if room is None:
            return None

        room = str(room).strip()

        if not room:
            return None

        if len(room) > cls.MAX_ROOM_NAME_CHARS:
            room = room[:cls.MAX_ROOM_NAME_CHARS]

        return room

    def _iter_broadcast_rooms(self):
        seen_rooms = set()

        for room in self.settings.get("rooms", ()):  # user-controlled plugin setting
            room = self._normalize_broadcast_room(room)

            if room is None or room in seen_rooms:
                continue

            seen_rooms.add(room)
            yield room

            if len(seen_rooms) >= self.MAX_BROADCAST_ROOMS:
                if not self.broadcast_limit_logged:
                    self.log("Now Playing Sender room limit reached, skipping remaining rooms")
                    self.broadcast_limit_logged = True

                break

    def _schedule_broadcast_queue(self):
        if not self.pending_broadcast_rooms or self.broadcast_timer_id is not None:
            return

        self.broadcast_timer_id = events.schedule(delay=0, callback=self._process_broadcast_queue)

        if self.broadcast_timer_id is None:
            self.log("Now Playing Sender could not schedule remaining room broadcasts")
            self._clear_broadcast_queue()

    def _process_broadcast_queue(self):
        self.broadcast_timer_id = None
        playing = self.broadcast_playing

        if not playing:
            self._clear_broadcast_queue()
            return

        processed_rooms = 0

        while self.pending_broadcast_rooms and processed_rooms < self.MAX_BROADCAST_ROOMS_PER_TICK:
            self.send_public(self.pending_broadcast_rooms.popleft(), playing)
            processed_rooms += 1

        if self.pending_broadcast_rooms:
            self._schedule_broadcast_queue()
            return

        self._clear_broadcast_queue()

    @classmethod
    def _normalize_mpris_text(cls, value, max_chars):
        if not value:
            return ""

        value = str(value)

        if len(value) > max_chars:
            return ""

        return value

    def add_mpris_signal_receiver(self):
        """Receive updates related to MPRIS."""

        self.signal_id = self.bus.signal_subscribe(
            sender=None,
            interface_name="org.freedesktop.DBus.Properties",
            member="PropertiesChanged",
            object_path="/org/mpris/MediaPlayer2",
            arg0=None,
            flags=Gio.DBusSignalFlags.NONE,
            callback=self.song_change,
            user_data=None
        )

    def remove_mpris_signal_receiver(self):
        """Stop receiving updates related to MPRIS."""

        self.bus.signal_unsubscribe(self.signal_id)

    def get_current_mpris_player(self):
        """Returns the MPRIS client currently selected in Now Playing."""

        player = self._normalize_mpris_text(
            self.config.sections["players"]["npothercommand"], self.MAX_MPRIS_PLAYER_CHARS)

        if not player:
            dbus_proxy = Gio.DBusProxy.new_sync(
                connection=self.bus,
                flags=Gio.DBusProxyFlags.NONE,
                info=None,
                name="org.freedesktop.DBus",
                object_path="/org/freedesktop/DBus",
                interface_name="org.freedesktop.DBus",
                cancellable=None
            )
            names = dbus_proxy.ListNames()

            for name in names:
                if name.startswith(self.dbus_mpris_service):
                    player = self._normalize_mpris_text(
                        name[len(self.dbus_mpris_service):], self.MAX_MPRIS_PLAYER_CHARS)
                    if player:
                        break

        return player

    def get_current_mpris_song_url(self, player):
        """Returns the current song url for the selected MPRIS client."""

        dbus_proxy = Gio.DBusProxy.new_sync(
            connection=self.bus,
            flags=Gio.DBusProxyFlags.NONE,
            info=None,
            name=self.dbus_mpris_service + player,
            object_path="/org/mpris/MediaPlayer2",
            interface_name="org.freedesktop.DBus.Properties",
            cancellable=None
        )
        metadata = dbus_proxy.Get("(ss)", "org.mpris.MediaPlayer2.Player", "Metadata")
        song_url = metadata.get("xesam:url")

        return self._normalize_mpris_text(song_url, self.MAX_MPRIS_URL_CHARS)

    def send_now_playing(self):
        """Broadcast Now Playing in selected rooms.

        The selected Now Playing backend can call D-Bus, HTTP or a custom
        command. Resolve it once per song change, then fan the resulting text
        out to a bounded, deduplicated room queue instead of repeating the
        expensive lookup once per configured room.
        """

        self._clear_broadcast_queue()
        playing = self.core.now_playing.get_np()

        if not playing:
            return

        self.broadcast_playing = playing
        self.pending_broadcast_rooms.extend(self._iter_broadcast_rooms())
        self._process_broadcast_queue()

    def song_change(self, _connection, _sender_name, _object_path, _interface_name,
                    _signal_name, parameters, _user_data):

        if self.config.sections["players"]["npplayer"] != "mpris":
            # MPRIS is not active, exit
            return

        # Get the changed song url received from the the signal
        try:
            changed_song_url = self._normalize_mpris_text(
                parameters[1].get("Metadata").get("xesam:url"), self.MAX_MPRIS_URL_CHARS)

        except AttributeError:
            return

        if not changed_song_url:
            # Song url empty, the player most likely stopped playing
            self.last_song_url = ""
            return

        if changed_song_url == self.last_song_url:
            # A new song didn't start playing, exit
            return

        try:
            player = self.get_current_mpris_player()
            selected_client_song_url = self.get_current_mpris_song_url(player)

        except Exception as error:
            # Selected player is invalid
            self.log("Cannot retrieve currently playing song. Error: %s", error)
            return

        if selected_client_song_url != changed_song_url:
            # Song change was from another MPRIS client than the selected one, exit
            return

        # Keep track of which song is playing
        self.last_song_url = changed_song_url

        self.send_now_playing()
