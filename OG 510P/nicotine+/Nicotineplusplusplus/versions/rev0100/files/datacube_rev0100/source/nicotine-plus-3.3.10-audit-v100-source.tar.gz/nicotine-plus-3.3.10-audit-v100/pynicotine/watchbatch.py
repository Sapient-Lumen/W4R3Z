# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from collections import deque

from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log


class WatchUserBatcher:
    """Batch watch_user() fanout for restored UI state after login."""

    __slots__ = (
        "context", "contains_user", "max_users_per_tick", "max_pending_users",
        "_queue", "_queued_users", "_timer_id", "_limit_logged"
    )

    RETRY_DELAY = 1

    def __init__(self, context, contains_user, max_users_per_tick, max_pending_users):
        self.context = context
        self.contains_user = contains_user
        self.max_users_per_tick = max_users_per_tick
        self.max_pending_users = max_pending_users
        self._queue = deque()
        self._queued_users = set()
        self._timer_id = None
        self._limit_logged = False

    @staticmethod
    def _get_limit(limit):
        return limit() if callable(limit) else limit

    def cancel(self):
        events.cancel_scheduled(self._timer_id)
        self._timer_id = None
        self._queue.clear()
        self._queued_users.clear()
        self._limit_logged = False

    def queue(self, usernames):
        self.cancel()

        max_pending_users = self._get_limit(self.max_pending_users)

        for username in usernames:
            if username in self._queued_users:
                continue

            if len(self._queue) >= max_pending_users:
                if not self._limit_logged:
                    log.add_debug(
                        "Server-login watch queue for context '%s' reached %s users; "
                        "discarding additional restored users",
                        (self.context, max_pending_users)
                    )
                    self._limit_logged = True
                break

            self._queue.append(username)
            self._queued_users.add(username)

        self.process()

    def _schedule(self, delay=0):
        if self._timer_id is not None:
            return

        self._timer_id = events.schedule(delay=delay, callback=self.process)

        if self._timer_id is None:
            self._queue.clear()
            self._queued_users.clear()

    def process(self):
        self._timer_id = None
        max_users_per_tick = self._get_limit(self.max_users_per_tick)
        num_processed = 0

        while self._queue and num_processed < max_users_per_tick:
            username = self._queue.popleft()
            self._queued_users.discard(username)
            num_processed += 1

            if not self.contains_user(username):
                continue

            if core.users.watch_user(username, context=self.context) is False:
                # watch_user() distinguishes local permanent refusals from
                # transient queue-output backpressure. Keep server-login watch
                # replay alive only for the latter; dropping these restored
                # watches can leave tabs/transfers/buddies without status
                # updates until the next reconnect.
                if getattr(core.users, "last_watch_failure_retryable", False):
                    self._queue.appendleft(username)
                    self._queued_users.add(username)
                    self._schedule(delay=self.RETRY_DELAY)
                    return

        if self._queue:
            self._schedule()
        else:
            self._limit_logged = False
