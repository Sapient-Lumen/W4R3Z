# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

from pynicotine.networkfilter import NetworkFilter


class IPFilterTest(TestCase):

    # pylint: disable=protected-access

    def test_wildcard_filter_lookup_does_not_write_configuration(self):
        network_filter = object.__new__(NetworkFilter)
        ip_list = {"1.2.*.*": ""}
        fake_config = SimpleNamespace(write_configuration=Mock())
        fake_core = SimpleNamespace(users=SimpleNamespace(addresses={"alice": ("1.2.3.4", 1234)}))

        with patch("pynicotine.networkfilter.config", fake_config), \
                patch("pynicotine.networkfilter.core", fake_core):
            self.assertTrue(network_filter._check_user_ip_filtered(ip_list, username="alice"))

        self.assertEqual({"1.2.*.*": "", "1.2.3.4": "alice"}, ip_list)
        fake_config.write_configuration.assert_not_called()

    def test_wildcard_filter_lookup_expansion_is_capped(self):
        network_filter = object.__new__(NetworkFilter)
        ip_list = {"1.2.*.*": ""}
        fake_config = SimpleNamespace(write_configuration=Mock())
        fake_core = SimpleNamespace(users=SimpleNamespace(addresses={"alice": ("1.2.3.4", 1234)}))
        old_limit = NetworkFilter.MAX_WILDCARD_IP_EXPANSIONS_PER_LIST

        try:
            NetworkFilter.MAX_WILDCARD_IP_EXPANSIONS_PER_LIST = 1

            with patch("pynicotine.networkfilter.config", fake_config), \
                    patch("pynicotine.networkfilter.core", fake_core):
                self.assertTrue(network_filter._check_user_ip_filtered(ip_list, username="alice"))

        finally:
            NetworkFilter.MAX_WILDCARD_IP_EXPANSIONS_PER_LIST = old_limit

        self.assertEqual({"1.2.*.*": ""}, ip_list)
        fake_config.write_configuration.assert_not_called()

    def test_username_and_previous_ip_lookup_use_cache(self):
        network_filter = object.__new__(NetworkFilter)
        ip_list = {
            "1.1.1.1": "alice",
            "2.2.2.2": "alice",
            "3.3.3.3": "bob"
        }

        self.assertTrue(network_filter._check_user_ip_filtered(ip_list, username="alice"))
        self.assertEqual(
            {"1.1.1.1", "2.2.2.2"},
            network_filter._get_previous_user_ip_addresses("alice", ip_list)
        )

    def test_wildcard_cache_is_invalidated_after_expansion(self):
        network_filter = object.__new__(NetworkFilter)
        ip_list = {"1.2.*.*": ""}
        fake_config = SimpleNamespace(write_configuration=Mock())
        fake_core = SimpleNamespace(users=SimpleNamespace(addresses={"alice": ("1.2.3.4", 1234)}))

        with patch("pynicotine.networkfilter.config", fake_config), \
                patch("pynicotine.networkfilter.core", fake_core):
            self.assertTrue(network_filter._check_user_ip_filtered(ip_list, username="alice"))

        self.assertEqual({"1.2.*.*": "", "1.2.3.4": "alice"}, ip_list)
        self.assertNotIn(id(ip_list), network_filter._ip_filter_cache)
        fake_config.write_configuration.assert_not_called()
    def test_ignores_peer_address_rejected_by_users_component(self):
        network_filter = object.__new__(NetworkFilter)
        network_filter.ip_ban_requested = {"alice": "add"}
        network_filter.ip_ignore_requested = {"alice": "add"}
        network_filter._ip_filter_cache = {}

        fake_config = SimpleNamespace(sections={
            "server": {
                "ipblocklist": {},
                "ipignorelist": {}
            }
        }, write_configuration=Mock())

        with patch("pynicotine.networkfilter.config", fake_config):
            network_filter._get_peer_address(SimpleNamespace(user=None, ip_address="1.2.3.4"))

        self.assertEqual({"alice": "add"}, network_filter.ip_ban_requested)
        self.assertEqual({"alice": "add"}, network_filter.ip_ignore_requested)
        self.assertEqual({}, fake_config.sections["server"]["ipblocklist"])
        self.assertEqual({}, fake_config.sections["server"]["ipignorelist"])
        fake_config.write_configuration.assert_not_called()



    def test_wildcard_rule_cache_is_capped(self):
        network_filter = object.__new__(NetworkFilter)
        network_filter._ip_filter_cache = {}
        ip_list = {
            "1.2.*.*": "",
            "5.6.*.*": ""
        }
        fake_core = SimpleNamespace(users=SimpleNamespace(addresses={"alice": ("5.6.7.8", 1234)}))
        old_rule_limit = NetworkFilter.MAX_WILDCARD_RULES_PER_LIST

        try:
            NetworkFilter.MAX_WILDCARD_RULES_PER_LIST = 1

            with patch("pynicotine.networkfilter.core", fake_core):
                self.assertFalse(network_filter._check_user_ip_filtered(ip_list, username="alice"))
        finally:
            NetworkFilter.MAX_WILDCARD_RULES_PER_LIST = old_rule_limit

    def test_remove_missing_user_ip_does_not_write_configuration(self):
        network_filter = object.__new__(NetworkFilter)
        network_filter._ip_filter_cache = {}
        fake_config = SimpleNamespace(write_configuration=Mock())
        ip_list = {"1.1.1.1": "alice"}

        with patch("pynicotine.networkfilter.config", fake_config):
            removed = network_filter._remove_user_ips_from_list(ip_list, ip_addresses={"2.2.2.2"})

        self.assertEqual({"2.2.2.2"}, removed)
        self.assertEqual({"1.1.1.1": "alice"}, ip_list)
        fake_config.write_configuration.assert_not_called()

    def test_request_ip_rolls_back_when_users_cap_rejects(self):
        network_filter = object.__new__(NetworkFilter)
        request_list = {}
        fake_core = SimpleNamespace(users=SimpleNamespace(request_ip_address=Mock(return_value=False)))

        with patch("pynicotine.networkfilter.core", fake_core):
            self.assertFalse(network_filter._request_ip("alice", "add", request_list))

        self.assertEqual({}, request_list)
        fake_core.users.request_ip_address.assert_called_once_with("alice")

    def test_request_ip_updates_existing_pending_action(self):
        network_filter = object.__new__(NetworkFilter)
        request_list = {"alice": "add"}
        fake_core = SimpleNamespace(users=SimpleNamespace(request_ip_address=Mock(return_value=True)))

        with patch("pynicotine.networkfilter.core", fake_core):
            self.assertTrue(network_filter._request_ip("alice", "remove", request_list))

        self.assertEqual({"alice": "remove"}, request_list)
        fake_core.users.request_ip_address.assert_called_once_with("alice")

    def test_request_ip_limits_pending_filter_actions(self):
        network_filter = object.__new__(NetworkFilter)
        old_limit = NetworkFilter.MAX_PENDING_IP_FILTER_REQUESTS
        request_list = {"alice": "add"}
        fake_core = SimpleNamespace(users=SimpleNamespace(request_ip_address=Mock(return_value=True)))

        try:
            NetworkFilter.MAX_PENDING_IP_FILTER_REQUESTS = 1

            with patch("pynicotine.networkfilter.core", fake_core):
                self.assertFalse(network_filter._request_ip("bob", "add", request_list))
        finally:
            NetworkFilter.MAX_PENDING_IP_FILTER_REQUESTS = old_limit

        self.assertEqual({"alice": "add"}, request_list)
        fake_core.users.request_ip_address.assert_not_called()

    def test_start_limits_persisted_user_filter_lists(self):
        network_filter = object.__new__(NetworkFilter)
        network_filter._banned_users = set()
        network_filter._ignored_users = set()

        fake_config = SimpleNamespace(sections={"server": {
            "banlist": ["bob", "ed"],
            "ignorelist": ["toolong", "ed"]
        }})

        old_user_limit = NetworkFilter.MAX_FILTERED_USERS_PER_LIST
        old_name_limit = NetworkFilter.MAX_FILTERED_USERNAME_BYTES

        try:
            NetworkFilter.MAX_FILTERED_USERS_PER_LIST = 1
            NetworkFilter.MAX_FILTERED_USERNAME_BYTES = 4

            with patch("pynicotine.networkfilter.config", fake_config):
                network_filter._start()

        finally:
            NetworkFilter.MAX_FILTERED_USERS_PER_LIST = old_user_limit
            NetworkFilter.MAX_FILTERED_USERNAME_BYTES = old_name_limit

        self.assertEqual({"bob"}, network_filter._banned_users)
        self.assertEqual({"ed"}, network_filter._ignored_users)

    def test_ban_user_rejects_new_user_when_filter_list_is_full(self):
        network_filter = object.__new__(NetworkFilter)
        network_filter._banned_users = {"bob"}
        fake_config = SimpleNamespace(
            sections={"server": {"banlist": ["bob"]}},
            write_configuration=Mock()
        )
        fake_events = SimpleNamespace(emit=Mock())
        old_limit = NetworkFilter.MAX_FILTERED_USERS_PER_LIST

        try:
            NetworkFilter.MAX_FILTERED_USERS_PER_LIST = 1

            with patch("pynicotine.networkfilter.config", fake_config), \
                    patch("pynicotine.networkfilter.events", fake_events):
                network_filter.ban_user("alice")

        finally:
            NetworkFilter.MAX_FILTERED_USERS_PER_LIST = old_limit

        self.assertEqual({"bob"}, network_filter._banned_users)
        self.assertEqual(["bob"], fake_config.sections["server"]["banlist"])
        fake_config.write_configuration.assert_not_called()
        fake_events.emit.assert_not_called()
