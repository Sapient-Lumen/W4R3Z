# SPDX-FileCopyrightText: 2026 Nicotine+ Team
# SPDX-License-Identifier: GPL-3.0-or-later

import io
import struct
from unittest import TestCase
from unittest.mock import patch

from pynicotine.external.tinytag import Aiff, Flac, ID3, MP4, Ogg, TinyTag, TinyTagException, Wave, Wma


class TinyTagTest(TestCase):

    @staticmethod
    def _minimal_flac_streaminfo(sample_rate=44100, total_samples=44100):
        """Return a minimal FLAC stream with one STREAMINFO metadata block."""

        bits_per_sample_minus_one = 15
        stream_info = bytearray(34)

        # min/max block size + min/max frame size fields can remain zero.
        stream_info[10] = (sample_rate >> 12) & 0xFF
        stream_info[11] = (sample_rate >> 4) & 0xFF
        stream_info[12] = ((sample_rate & 0x0F) << 4) | (bits_per_sample_minus_one >> 4)
        stream_info[13] = ((bits_per_sample_minus_one & 0x0F) << 4) | ((total_samples >> 32) & 0x0F)
        stream_info[14] = (total_samples >> 24) & 0xFF
        stream_info[15] = (total_samples >> 16) & 0xFF
        stream_info[16] = (total_samples >> 8) & 0xFF
        stream_info[17] = total_samples & 0xFF

        return b"fLaC" + bytes([0x80, 0x00, 0x00, len(stream_info)]) + bytes(stream_info)

    def test_flac_duration_scan_skips_id3_frames_when_tags_disabled(self):
        """Share scans request duration only, so FLAC ID3 frame bodies should not be parsed."""

        id3_frame = b"TIT2" + b"\x00\x00\x00\x01" + b"\x00\x00" + b"\x00"
        id3_header = b"ID3" + b"\x04\x00\x00" + b"\x00\x00\x00" + bytes([len(id3_frame)])
        file_obj = io.BytesIO(id3_header + id3_frame + self._minimal_flac_streaminfo())

        with patch.object(ID3, "_parse_frame", side_effect=AssertionError("ID3 frame parsed")):
            tag = TinyTag.get(filename="track.flac", file_obj=file_obj, tags=False, duration=True)

        self.assertEqual(1, tag.duration)

    @staticmethod
    def _ogg_page(segment_size=255, sequence_number=0, payload=None):
        if payload is None:
            payload = b"a" * segment_size

        header = struct.pack(
            "<4sBBqIIiB", b"OggS", 0, 0, 0, 12345, sequence_number, 0, 1)
        return header + bytes([segment_size]) + payload

    def test_ogg_continued_packet_size_is_bounded(self):
        """Malformed Ogg files should not accumulate unbounded continuation packets during scans."""

        old_max_packet_bytes = Ogg.MAX_OGG_PACKET_BYTES
        Ogg.MAX_OGG_PACKET_BYTES = 300

        try:
            file_obj = io.BytesIO(
                self._ogg_page(sequence_number=0)
                + self._ogg_page(sequence_number=1)
                + self._ogg_page(segment_size=1, sequence_number=2, payload=b"z")
            )
            ogg = Ogg(file_obj, filesize=len(file_obj.getvalue()))

            with self.assertRaises(TinyTagException):
                list(ogg._parse_pages(file_obj))

        finally:
            Ogg.MAX_OGG_PACKET_BYTES = old_max_packet_bytes

    def test_flac_streaminfo_reads_fixed_size_header_only(self):
        """Oversized STREAMINFO declarations should not be read fully during scans."""

        class CountingBytesIO(io.BytesIO):
            def __init__(self, data):
                super().__init__(data)
                self.read_sizes = []

            def read(self, size=-1):
                self.read_sizes.append(size)
                return super().read(size)

            def peek(self, size=-1):
                position = self.tell()
                data = super().read(size)
                self.seek(position)
                return data

        stream_info = self._minimal_flac_streaminfo()[8:]
        declared_size = Flac.STREAMINFO_SIZE + 1024
        file_obj = CountingBytesIO(
            b"fLaC" + bytes([0x80]) + declared_size.to_bytes(3, "big") + stream_info + (b"x" * 1024)
        )

        tag = Flac(file_obj, filesize=len(file_obj.getvalue()))
        tag.load(tags=False, duration=True, image=False)

        self.assertEqual(1, tag.duration)
        self.assertNotIn(declared_size, file_obj.read_sizes)
        self.assertIn(Flac.STREAMINFO_SIZE, file_obj.read_sizes)

    def test_mp4_parser_rejects_oversized_leaf_atom_without_full_read(self):
        """Oversized MP4 metadata atoms should not be read into memory during scans."""

        class CountingBytesIO(io.BytesIO):
            def __init__(self, data):
                super().__init__(data)
                self.read_sizes = []

            def read(self, size=-1):
                self.read_sizes.append(size)
                return super().read(size)

        old_max_atom_bytes = MP4.MAX_MP4_ATOM_DATA_BYTES
        MP4.MAX_MP4_ATOM_DATA_BYTES = 32

        try:
            declared_payload_size = MP4.MAX_MP4_ATOM_DATA_BYTES + 1
            atom = (declared_payload_size + 8).to_bytes(4, "big") + b"data" + b"x" * 8
            file_obj = CountingBytesIO(atom)
            mp4 = MP4(file_obj, filesize=len(atom))

            with self.assertRaises(TinyTagException):
                mp4._traverse_atoms(
                    file_obj,
                    path={b"data": MP4.Parser.make_data_atom_parser("title")}
                )

            self.assertNotIn(declared_payload_size, file_obj.read_sizes)

        finally:
            MP4.MAX_MP4_ATOM_DATA_BYTES = old_max_atom_bytes

    def test_vorbis_comment_count_is_bounded(self):
        """Malformed Vorbis comments should not allow millions of empty entries."""

        old_max_comments = Ogg.MAX_VORBIS_COMMENTS
        Ogg.MAX_VORBIS_COMMENTS = 2

        try:
            file_obj = io.BytesIO((0).to_bytes(4, "little") + (3).to_bytes(4, "little"))
            ogg = Ogg(file_obj, filesize=len(file_obj.getvalue()))

            with self.assertRaises(TinyTagException):
                ogg._parse_vorbis_comment(file_obj)

        finally:
            Ogg.MAX_VORBIS_COMMENTS = old_max_comments

    def test_wave_info_list_size_is_bounded(self):
        """WAVE INFO chunks should not be read wholesale when the declared size is gross."""

        old_max_info_bytes = Wave.MAX_WAVE_INFO_LIST_BYTES
        Wave.MAX_WAVE_INFO_LIST_BYTES = 8

        try:
            chunk_size = Wave.MAX_WAVE_INFO_LIST_BYTES + 5
            file_obj = io.BytesIO(
                b"RIFF" + (chunk_size + 16).to_bytes(4, "little") + b"WAVE"
                + b"LIST" + chunk_size.to_bytes(4, "little") + b"INFO" + b"x" * 4
            )
            wave = Wave(file_obj, filesize=len(file_obj.getvalue()))

            with self.assertRaises(TinyTagException):
                wave.load(tags=True, duration=False, image=False)

        finally:
            Wave.MAX_WAVE_INFO_LIST_BYTES = old_max_info_bytes

    def test_aiff_rejects_undersized_comm_chunk(self):
        """Malformed COMM chunks should not seek backwards during share scans."""

        file_obj = io.BytesIO(b"FORM" + (20).to_bytes(4, "big") + b"AIFF" + b"COMM" + (0).to_bytes(4, "big"))
        tag = Aiff(file_obj, filesize=len(file_obj.getvalue()))

        with self.assertRaises(TinyTagException):
            tag.load(tags=False, duration=True, image=False)

    def test_id3_large_text_frame_is_skipped(self):
        """Gross ID3 text frames should be skipped instead of read/decoded wholesale."""

        old_max_text_frame_bytes = ID3.MAX_ID3_TEXT_FRAME_BYTES
        ID3.MAX_ID3_TEXT_FRAME_BYTES = 4

        try:
            frame_body = b"\x03Title!!"
            frame = b"TIT2" + len(frame_body).to_bytes(4, "big") + b"\x00\x00" + frame_body
            id3_header = b"ID3" + b"\x03\x00\x00" + bytes([0, 0, 0, len(frame)])
            file_obj = io.BytesIO(id3_header + frame)
            tag = ID3(file_obj, filesize=len(file_obj.getvalue()))
            tag.load(tags=True, duration=False, image=False)

            self.assertIsNone(tag.title)

        finally:
            ID3.MAX_ID3_TEXT_FRAME_BYTES = old_max_text_frame_bytes



    def test_flac_metadata_block_count_is_bounded(self):
        """Malformed FLAC files should not iterate through unlimited zero-size metadata blocks."""

        old_max_blocks = Flac.MAX_FLAC_METADATA_BLOCKS
        Flac.MAX_FLAC_METADATA_BLOCKS = 2

        try:
            data = b"fLaC" + (b"\x01\x00\x00\x00" * 3)
            class PeekableBytesIO(io.BytesIO):
                def peek(self, size=-1):
                    position = self.tell()
                    data = self.read(size)
                    self.seek(position)
                    return data

            file_obj = PeekableBytesIO(data)
            tag = Flac(file_obj, filesize=len(data))

            with self.assertRaises(TinyTagException):
                tag.load(tags=False, duration=True, image=False)

        finally:
            Flac.MAX_FLAC_METADATA_BLOCKS = old_max_blocks

    def test_flac_metadata_block_size_is_bounded(self):
        """Gross FLAC metadata block declarations should be rejected before large seeks/parsers."""

        old_max_block_bytes = Flac.MAX_FLAC_METADATA_BLOCK_BYTES
        Flac.MAX_FLAC_METADATA_BLOCK_BYTES = 8

        try:
            data = b"fLaC" + bytes([Flac.METADATA_PADDING]) + (9).to_bytes(3, "big") + b"x" * 9
            class PeekableBytesIO(io.BytesIO):
                def peek(self, size=-1):
                    position = self.tell()
                    data = self.read(size)
                    self.seek(position)
                    return data

            file_obj = PeekableBytesIO(data)
            tag = Flac(file_obj, filesize=len(data))

            with self.assertRaises(TinyTagException):
                tag.load(tags=False, duration=True, image=False)

        finally:
            Flac.MAX_FLAC_METADATA_BLOCK_BYTES = old_max_block_bytes

    def test_id3_duration_scan_has_gross_byte_cap(self):
        """Malformed MP3 files should not be scanned end-to-end for a sync header during share scans."""

        class PeekableBytesIO(io.BytesIO):
            def peek(self, size=-1):
                position = self.tell()
                data = self.read(size)
                self.seek(position)
                return data

        old_max_scan_bytes = ID3.MAX_MP3_DURATION_SCAN_BYTES
        ID3.MAX_MP3_DURATION_SCAN_BYTES = 16

        try:
            file_obj = PeekableBytesIO(b"not an id3" + (b"x" * 1024))
            tag = ID3(file_obj, filesize=len(file_obj.getvalue()))
            tag.load(tags=False, duration=True, image=False)

            self.assertIsNone(tag.duration)
            self.assertLess(file_obj.tell(), len(file_obj.getvalue()))

        finally:
            ID3.MAX_MP3_DURATION_SCAN_BYTES = old_max_scan_bytes

    def test_id3_frame_count_is_bounded(self):
        """Malformed ID3 tags with many tiny frames should not loop through the entire tag body."""

        old_max_frames = ID3.MAX_ID3_FRAMES
        ID3.MAX_ID3_FRAMES = 2

        try:
            frame = b"TIT2" + (1).to_bytes(4, "big") + b"\x00\x00" + b"\x00"
            frames = frame * 3
            id3_header = b"ID3" + b"\x03\x00\x00" + bytes([0, 0, 0, len(frames)])
            file_obj = io.BytesIO(id3_header + frames)
            tag = ID3(file_obj, filesize=len(file_obj.getvalue()))

            with self.assertRaises(TinyTagException):
                tag.load(tags=True, duration=False, image=False)

        finally:
            ID3.MAX_ID3_FRAMES = old_max_frames

    def test_wma_rejects_undersized_object_without_seek_loop(self):
        """ASF objects smaller than their header should stop parsing instead of seeking backwards."""

        data = (
            b"0&\xb2u\x8ef\xcf\x11\xa6\xd9\x00\xaa\x00b\xcel"
            + (64).to_bytes(8, "little")
            + (1).to_bytes(4, "little")
            + b"\x01\x02"
            + (b"x" * 16)
            + (1).to_bytes(8, "little")
        )
        file_obj = io.BytesIO(data)
        tag = Wma(file_obj, filesize=len(data))
        tag.load(tags=False, duration=True, image=False)

        self.assertIsNone(tag.duration)

    def test_wma_descriptor_count_is_bounded(self):
        """Malformed ASF extended-content blocks should not loop over huge descriptor counts."""

        old_max_descriptors = Wma.MAX_ASF_DESCRIPTOR_COUNT
        Wma.MAX_ASF_DESCRIPTOR_COUNT = 1

        try:
            payload = (2).to_bytes(2, "little")
            object_size = 24 + len(payload)
            data = (
                b"0&\xb2u\x8ef\xcf\x11\xa6\xd9\x00\xaa\x00b\xcel"
                + (64).to_bytes(8, "little")
                + (1).to_bytes(4, "little")
                + b"\x01\x02"
                + Wma.ASF_EXTENDED_CONTENT_DESCRIPTION_OBJECT
                + object_size.to_bytes(8, "little")
                + payload
            )
            file_obj = io.BytesIO(data)
            tag = Wma(file_obj, filesize=len(data))

            with self.assertRaises(TinyTagException):
                tag.load(tags=True, duration=False, image=False)

        finally:
            Wma.MAX_ASF_DESCRIPTOR_COUNT = old_max_descriptors

    def test_aiff_text_chunk_size_is_bounded(self):
        """Gross AIFF text chunks should be skipped instead of read into memory."""

        old_max_text_chunk_bytes = Aiff.MAX_AIFF_TEXT_CHUNK_BYTES
        Aiff.MAX_AIFF_TEXT_CHUNK_BYTES = 4

        try:
            data = b"FORM" + (28).to_bytes(4, "big") + b"AIFF" + b"NAME" + (8).to_bytes(4, "big") + b"abcdefgh"
            file_obj = io.BytesIO(data)
            tag = Aiff(file_obj, filesize=len(data))
            tag.load(tags=True, duration=False, image=False)

            self.assertIsNone(tag.title)

        finally:
            Aiff.MAX_AIFF_TEXT_CHUNK_BYTES = old_max_text_chunk_bytes
