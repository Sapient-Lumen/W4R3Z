# COPYRIGHT (C) 2026 Nicotine+ Contributors

from unittest import TestCase
from unittest.mock import Mock

from pynicotine.plugins.multipaste import Plugin as MultipastePlugin
from pynicotine.plugins.spamfilter import Plugin as SpamfilterPlugin
from pynicotine.pluginsystem import returncode


class MultipastePluginBudgetTest(TestCase):

    def _plugin(self):
        plugin = MultipastePlugin()
        plugin.log = Mock()
        plugin.send_private = Mock()
        plugin.send_public = Mock()
        return plugin

    def test_private_paste_uses_bounded_line_cap_even_with_large_setting(self):
        plugin = self._plugin()
        old_limit = MultipastePlugin.MAX_PASTE_LINES
        MultipastePlugin.MAX_PASTE_LINES = 2
        plugin.settings["maxprivatelines"] = 999999

        try:
            result = plugin.outgoing_private_chat_event("alice", "one\ntwo\nthree\nfour")
        finally:
            MultipastePlugin.MAX_PASTE_LINES = old_limit

        self.assertEqual(returncode["zap"], result)
        self.assertEqual(
            [("alice", "one"), ("alice", "two")],
            [call.args for call in plugin.send_private.call_args_list]
        )

    def test_public_paste_truncates_gross_input_before_splitting(self):
        plugin = self._plugin()
        old_chars = MultipastePlugin.MAX_PASTE_CHARS
        old_lines = MultipastePlugin.MAX_PASTE_LINES
        MultipastePlugin.MAX_PASTE_CHARS = 7
        MultipastePlugin.MAX_PASTE_LINES = 10
        plugin.settings["maxpubliclines"] = 10

        try:
            result = plugin.outgoing_public_chat_event("room", "one\ntwo\nthree")
        finally:
            MultipastePlugin.MAX_PASTE_CHARS = old_chars
            MultipastePlugin.MAX_PASTE_LINES = old_lines

        self.assertEqual(returncode["zap"], result)
        self.assertEqual(
            [("room", "one"), ("room", "two")],
            [call.args for call in plugin.send_public.call_args_list]
        )


class SpamfilterPluginBudgetTest(TestCase):

    def _plugin(self):
        plugin = SpamfilterPlugin()
        plugin.log = Mock()
        return plugin

    def test_phrase_scan_lowercases_message_once_and_caps_phrase_count(self):
        plugin = self._plugin()
        old_limit = SpamfilterPlugin.MAX_BAD_PRIVATE_PHRASES
        SpamfilterPlugin.MAX_BAD_PRIVATE_PHRASES = 2
        plugin.settings["badprivatephrases"] = ["not", "used", "needle"]

        try:
            self.assertIsNone(plugin.check_phrases("alice", "contains NEEDLE"))
        finally:
            SpamfilterPlugin.MAX_BAD_PRIVATE_PHRASES = old_limit

        plugin.log.assert_not_called()

    def test_phrase_scan_matches_normalized_bounded_phrase(self):
        plugin = self._plugin()
        old_chars = SpamfilterPlugin.MAX_BAD_PRIVATE_PHRASE_CHARS
        SpamfilterPlugin.MAX_BAD_PRIVATE_PHRASE_CHARS = 6
        plugin.settings["badprivatephrases"] = ["NeedleSuffix"]

        try:
            result = plugin.check_phrases("alice", "the NEEDLE is here")
        finally:
            SpamfilterPlugin.MAX_BAD_PRIVATE_PHRASE_CHARS = old_chars

        self.assertEqual(returncode["zap"], result)
        plugin.log.assert_called_once()
