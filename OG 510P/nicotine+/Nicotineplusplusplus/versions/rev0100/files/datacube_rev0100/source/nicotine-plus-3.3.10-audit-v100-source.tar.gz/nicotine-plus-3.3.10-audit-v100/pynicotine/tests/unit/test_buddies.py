# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock

import pynicotine.buddies as buddies_module
from pynicotine.buddies import Buddies
from pynicotine.buddies import Buddy
from pynicotine.slskmessages import UserStatus


class patch_buddies_attr:

    def __init__(self, name, value):
        self.name = name
        self.value = value
        self.old_value = None

    def __enter__(self):
        self.old_value = getattr(buddies_module, self.name)
        setattr(buddies_module, self.name, self.value)

    def __exit__(self, *_args):
        setattr(buddies_module, self.name, self.old_value)


class DummyEvents:

    def __init__(self):
        self.emitted = []
        self.scheduled = []
        self.cancelled = []
        self.next_timer_id = 1

    def emit(self, *args, **kwargs):
        self.emitted.append((args, kwargs))

    def schedule(self, delay, callback):
        self.scheduled.append((delay, callback))
        timer_id = self.next_timer_id
        self.next_timer_id += 1
        return timer_id

    def cancel_scheduled(self, timer_id):
        self.cancelled.append(timer_id)


class BuddiesTest(TestCase):

    @staticmethod
    def _buddy(username, status=UserStatus.ONLINE, last_seen=""):
        return Buddy(
            username=username,
            note="",
            notify_status=False,
            is_prioritized=False,
            is_trusted=False,
            last_seen=last_seen,
            country="",
            status=status
        )

    def _buddies(self):
        buddies = object.__new__(Buddies)
        buddies.users = {
            "alice": self._buddy("alice"),
            "bob": self._buddy("bob"),
            "carol": self._buddy("carol")
        }
        buddies._allow_saving_buddies = True
        buddies._server_login_watch_batcher = SimpleNamespace(cancel=Mock())
        buddies._server_disconnect_buddy_queue = buddies_module.deque()
        buddies._server_disconnect_buddy_timer_id = None
        buddies._server_disconnect_save_pending = False
        buddies._server_disconnect_limit_logged = False
        return buddies

    def test_server_disconnect_batches_buddy_offline_updates(self):
        buddies = self._buddies()
        dummy_events = DummyEvents()
        dummy_config = SimpleNamespace(sections={"server": {"userlist": []}}, write_configuration=Mock())
        old_limit = Buddies.MAX_SERVER_DISCONNECT_BUDDIES_PER_TICK

        try:
            Buddies.MAX_SERVER_DISCONNECT_BUDDIES_PER_TICK = 2

            with patch_buddies_attr("events", dummy_events), patch_buddies_attr("config", dummy_config):
                buddies._server_disconnect(SimpleNamespace())

                self.assertEqual(UserStatus.OFFLINE, buddies.users["alice"].status)
                self.assertEqual(UserStatus.OFFLINE, buddies.users["bob"].status)
                self.assertEqual(UserStatus.ONLINE, buddies.users["carol"].status)
                self.assertEqual(0, dummy_config.write_configuration.call_count)
                self.assertEqual(1, len(dummy_events.scheduled))

                _delay, callback = dummy_events.scheduled.pop(0)
                callback()

        finally:
            Buddies.MAX_SERVER_DISCONNECT_BUDDIES_PER_TICK = old_limit

        self.assertEqual(UserStatus.OFFLINE, buddies.users["carol"].status)
        dummy_config.write_configuration.assert_called_once()
        self.assertEqual([], list(buddies._server_disconnect_buddy_queue))
        self.assertEqual(3, len(dummy_events.emitted))

    def test_quit_cancels_pending_buddy_disconnect_batch(self):
        buddies = self._buddies()
        dummy_events = DummyEvents()
        buddies._server_disconnect_buddy_queue.append("alice")
        buddies._server_disconnect_buddy_timer_id = 99
        buddies._server_disconnect_save_pending = True

        with patch_buddies_attr("events", dummy_events):
            buddies._quit()

        self.assertEqual([99], dummy_events.cancelled)
        self.assertEqual([], list(buddies._server_disconnect_buddy_queue))
        self.assertFalse(buddies._server_disconnect_save_pending)
        self.assertFalse(buddies._allow_saving_buddies)
        self.assertEqual({}, buddies.users)

    def test_start_caps_and_truncates_restored_buddy_rows(self):
        buddies = object.__new__(Buddies)
        buddies.users = {}
        buddies._allow_saving_buddies = False
        buddies._server_login_watch_batcher = SimpleNamespace(cancel=Mock())
        buddies._server_disconnect_buddy_queue = buddies_module.deque()
        buddies._server_disconnect_buddy_timer_id = None
        buddies._server_disconnect_save_pending = False
        buddies._server_disconnect_limit_logged = False

        old_limit = Buddies.MAX_BUDDIES
        old_note = Buddies.MAX_BUDDY_NOTE_BYTES
        old_last_seen = Buddies.MAX_BUDDY_LAST_SEEN_BYTES
        old_country = Buddies.MAX_BUDDY_COUNTRY_BYTES
        Buddies.MAX_BUDDIES = 1
        Buddies.MAX_BUDDY_NOTE_BYTES = 4
        Buddies.MAX_BUDDY_LAST_SEEN_BYTES = 4
        Buddies.MAX_BUDDY_COUNTRY_BYTES = 4

        dummy_config = SimpleNamespace(sections={"server": {"userlist": [
            ["alice", "note-long", True, True, True, "last-seen-long", "country-long"],
            ["bob", "ignored"]
        ]}})

        try:
            with patch_buddies_attr("config", dummy_config), patch_buddies_attr("log", SimpleNamespace(add_debug=Mock())):
                buddies._start()
        finally:
            Buddies.MAX_BUDDIES = old_limit
            Buddies.MAX_BUDDY_NOTE_BYTES = old_note
            Buddies.MAX_BUDDY_LAST_SEEN_BYTES = old_last_seen
            Buddies.MAX_BUDDY_COUNTRY_BYTES = old_country

        self.assertEqual(["alice"], list(buddies.users))
        self.assertEqual("note", buddies.users["alice"].note)
        self.assertEqual("last", buddies.users["alice"].last_seen)
        self.assertEqual("coun", buddies.users["alice"].country)
        self.assertTrue(buddies._allow_saving_buddies)

    def test_add_buddy_respects_restored_buddy_cap(self):
        buddies = self._buddies()
        old_limit = Buddies.MAX_BUDDIES
        Buddies.MAX_BUDDIES = len(buddies.users)

        try:
            with patch_buddies_attr("log", SimpleNamespace(add_debug=Mock())):
                buddies.add_buddy("dan")
        finally:
            Buddies.MAX_BUDDIES = old_limit

        self.assertNotIn("dan", buddies.users)
