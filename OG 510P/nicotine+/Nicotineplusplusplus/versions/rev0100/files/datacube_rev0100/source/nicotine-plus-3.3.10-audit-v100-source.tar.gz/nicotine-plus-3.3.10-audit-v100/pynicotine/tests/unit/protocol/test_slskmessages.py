# COPYRIGHT (C) 2020-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time
import zlib

from unittest import TestCase
from unittest.mock import patch

from pynicotine.slskmessages import AckNotifyPrivileges
from pynicotine.slskmessages import AllowedFolderTokenSet
from pynicotine.slskmessages import AllowedResponseUsers
from pynicotine.slskmessages import ChangePassword
from pynicotine.slskmessages import DISTRIBUTED_MESSAGE_CODES
from pynicotine.slskmessages import DistribBranchRoot
from pynicotine.slskmessages import DistribEmbeddedMessage
from pynicotine.slskmessages import DistribSearch
from pynicotine.slskmessages import EmbeddedMessage
from pynicotine.slskmessages import EmitNetworkMessageEvents
from pynicotine.slskmessages import FileAttribute
from pynicotine.slskmessages import FileSearch
from pynicotine.slskmessages import FileListMessage
from pynicotine.slskmessages import FileSearchResponse
from pynicotine.slskmessages import RoomTickerAdd
from pynicotine.slskmessages import PMessageUser
from pynicotine.slskmessages import MessageUser
from pynicotine.slskmessages import MessageUsers
from pynicotine.slskmessages import FileSearchRequest
from pynicotine.slskmessages import ExcludedSearchPhrases
from pynicotine.slskmessages import FolderContentsResponse
from pynicotine.slskmessages import FOLDER_TOKENS_ALLOWED
from pynicotine.slskmessages import GetPeerAddress
from pynicotine.slskmessages import GetUserStatus
from pynicotine.slskmessages import JoinGlobalRoom
from pynicotine.slskmessages import JoinRoom
from pynicotine.slskmessages import LeaveGlobalRoom
from pynicotine.slskmessages import Login
from pynicotine.slskmessages import NotifyPrivileges
from pynicotine.slskmessages import PeerInit
from pynicotine.slskmessages import PlaceInQueueResponse
from pynicotine.slskmessages import PlaceInQueueRequest
from pynicotine.slskmessages import PossibleParents
from pynicotine.slskmessages import PrivilegedUsers
from pynicotine.slskmessages import PrivateRoomAddUser
from pynicotine.slskmessages import PrivateRoomCancelMembership
from pynicotine.slskmessages import PrivateRoomDisown
from pynicotine.slskmessages import PrivateRoomOperators
from pynicotine.slskmessages import PrivateRoomRemoveUser
from pynicotine.slskmessages import PrivateRoomSomething
from pynicotine.slskmessages import PrivateRoomUsers
from pynicotine.slskmessages import RelatedSearch
from pynicotine.slskmessages import RecommendationsMessage
from pynicotine.slskmessages import RoomTickerState
from pynicotine.slskmessages import RoomList
from pynicotine.slskmessages import SayChatroom
from pynicotine.slskmessages import SetStatus
from pynicotine.slskmessages import SetWaitPort
from pynicotine.slskmessages import SharedFileListResponse
from pynicotine.slskmessages import SimilarRecommendations
from pynicotine.slskmessages import SlskMessage
from pynicotine.slskmessages import SEARCH_TOKENS_ALLOWED
from pynicotine.slskmessages import clear_search_response_users
from pynicotine.slskmessages import consume_search_response_user
from pynicotine.slskmessages import QueueUpload
from pynicotine.slskmessages import TransferDirection
from pynicotine.slskmessages import TransferRequest
from pynicotine.slskmessages import TransferResponse
from pynicotine.slskmessages import UploadDenied
from pynicotine.slskmessages import UnwatchUser
from pynicotine.slskmessages import UsersMessage
from pynicotine.slskmessages import UserInterests
from pynicotine.slskmessages import UserInfoResponse
from pynicotine.slskmessages import WatchUser


class SlskMessageTest(TestCase):


    def test_search_token_set_releases_one_outbound_grant(self):
        token = 123456

        try:
            SEARCH_TOKENS_ALLOWED.clear()
            SEARCH_TOKENS_ALLOWED.add(token)
            SEARCH_TOKENS_ALLOWED.add(token)

            self.assertIn(token, SEARCH_TOKENS_ALLOWED)
            self.assertTrue(consume_search_response_user(token, "alice"))

            SEARCH_TOKENS_ALLOWED.release(token)

            self.assertIn(token, SEARCH_TOKENS_ALLOWED)
            self.assertFalse(consume_search_response_user(token, "alice"))

            SEARCH_TOKENS_ALLOWED.release(token)

            self.assertNotIn(token, SEARCH_TOKENS_ALLOWED)
            self.assertTrue(consume_search_response_user(token, "alice"))

        finally:
            SEARCH_TOKENS_ALLOWED.clear()


    def test_allowed_folder_token_set_expire_and_evict_oldest(self):
        grants = AllowedFolderTokenSet()
        old_max = AllowedFolderTokenSet.MAX_TOKENS
        old_ttl = AllowedFolderTokenSet.TOKEN_TTL
        AllowedFolderTokenSet.MAX_TOKENS = 2
        AllowedFolderTokenSet.TOKEN_TTL = 100000

        try:
            with patch("pynicotine.slskmessages.time.monotonic", side_effect=(1, 2, 3)):
                grants.add(("user", 1))
                grants.add(("user", 2))
                grants.add(("user", 3))

            self.assertNotIn(("user", 1), grants)
            self.assertIn(("user", 2), grants)
            self.assertIn(("user", 3), grants)

            AllowedFolderTokenSet.TOKEN_TTL = 10

            with patch("pynicotine.slskmessages.time.monotonic", return_value=13):
                self.assertNotIn(("user", 2), grants)

        finally:
            AllowedFolderTokenSet.MAX_TOKENS = old_max
            AllowedFolderTokenSet.TOKEN_TTL = old_ttl

    def test_allowed_folder_token_set_refresh_uses_updated_age(self):
        grants = AllowedFolderTokenSet()
        old_max = AllowedFolderTokenSet.MAX_TOKENS
        old_ttl = AllowedFolderTokenSet.TOKEN_TTL
        AllowedFolderTokenSet.MAX_TOKENS = 2
        AllowedFolderTokenSet.TOKEN_TTL = 100000

        try:
            grants.add(("user", 1))
            grants.add(("user", 2))
            grants.add(("user", 1))
            grants.add(("user", 3))

            self.assertIn(("user", 1), grants)
            self.assertNotIn(("user", 2), grants)
            self.assertIn(("user", 3), grants)

        finally:
            AllowedFolderTokenSet.MAX_TOKENS = old_max
            AllowedFolderTokenSet.TOKEN_TTL = old_ttl

    def test_allowed_folder_token_set_drops_expired_from_order_head(self):
        grants = AllowedFolderTokenSet()
        old_ttl = AllowedFolderTokenSet.TOKEN_TTL
        AllowedFolderTokenSet.TOKEN_TTL = 10

        try:
            with patch("pynicotine.slskmessages.time.monotonic", side_effect=(1, 2, 20, 20, 20, 20)):
                grants.add(("user", 1))
                grants.add(("user", 2))
                grants.add(("user", 3))

                self.assertNotIn(("user", 1), grants)
                self.assertNotIn(("user", 2), grants)
                self.assertIn(("user", 3), grants)

        finally:
            AllowedFolderTokenSet.TOKEN_TTL = old_ttl

    def test_allowed_response_users_expire_and_evict_oldest(self):
        grants = AllowedResponseUsers()
        old_max = AllowedResponseUsers.MAX_GRANTS
        old_ttl = AllowedResponseUsers.GRANT_TTL
        AllowedResponseUsers.MAX_GRANTS = 2
        AllowedResponseUsers.GRANT_TTL = 100000

        try:
            current_time = time.monotonic()
            grants.add("first")
            grants.grant_times["first"] = current_time - 2
            grants.add("second")
            grants.grant_times["second"] = current_time - 1
            grants.add("third")

            self.assertNotIn("first", grants)
            self.assertIn("second", grants)
            self.assertIn("third", grants)

            AllowedResponseUsers.GRANT_TTL = 10
            grants.grant_times["second"] = 1
            self.assertFalse(grants.is_allowed("second", current_time=12))
            self.assertNotIn("second", grants)
            self.assertTrue(grants.is_allowed("third", current_time=12))

        finally:
            AllowedResponseUsers.MAX_GRANTS = old_max
            AllowedResponseUsers.GRANT_TTL = old_ttl

    def test_pack_objects(self):
        # Arrange
        obj = SlskMessage()

        # Act
        boolean_message = obj.pack_bool(123)
        unsigned_int8_message = obj.pack_uint8(123)
        unsigned_int32_message = obj.pack_uint32(123)
        signed_int32_message = obj.pack_int32(123)
        unsigned_int64_message = obj.pack_uint64(123)
        bytes_message = obj.pack_bytes(b"testbytes")
        str_message = obj.pack_string("teststring")

        # Assert
        self.assertEqual(b"\x01", boolean_message)
        self.assertEqual(b"\x7B", unsigned_int8_message)
        self.assertEqual(b"\x7B\x00\x00\x00", unsigned_int32_message)
        self.assertEqual(b"\x7B\x00\x00\x00", signed_int32_message)
        self.assertEqual(b"\x7B\x00\x00\x00\x00\x00\x00\x00", unsigned_int64_message)
        self.assertEqual(b"\t\x00\x00\x00testbytes", bytes_message)
        self.assertEqual(b"\n\x00\x00\x00teststring", str_message)


    def test_pack_string_caps_outgoing_utf8_without_splitting_codepoint(self):
        text = "é" * 10
        packed = SlskMessage.pack_string(text, max_length=5)
        pos, unpacked = SlskMessage.unpack_string(memoryview(packed))

        self.assertEqual(len(packed), pos)
        self.assertLessEqual(len(unpacked.encode("utf-8")), 5)
        self.assertEqual("é" * 2, unpacked)

    def test_outgoing_chat_message_is_capped_before_packing(self):
        message = "x" * (SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES + 1024)
        packed = SayChatroom("room", message).make_network_message()
        pos, room = SlskMessage.unpack_string(memoryview(packed))
        _pos, unpacked = SlskMessage.unpack_string(memoryview(packed), pos)

        self.assertEqual("room", room)
        self.assertEqual(SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES, len(unpacked.encode("utf-8")))

    def test_outgoing_peer_search_request_is_capped_before_packing(self):
        text = "x" * (SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES + 1024)
        packed = FileSearchRequest(token=123, text=text).make_network_message()
        pos, token = SlskMessage.unpack_uint32(memoryview(packed))
        _pos, unpacked = SlskMessage.unpack_string(memoryview(packed), pos)

        self.assertEqual(123, token)
        self.assertEqual(SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES, len(unpacked.encode("utf-8")))

    def test_outgoing_bulk_private_message_recipient_list_is_capped_before_packing(self):
        old_limit = MessageUsers.MAX_OUTGOING_BULK_USERS
        MessageUsers.MAX_OUTGOING_BULK_USERS = 2

        try:
            packed = MessageUsers(users=["one", "two", "three"], msg="hello").make_network_message()
            pos, num_users = SlskMessage.unpack_uint32(memoryview(packed))

            self.assertEqual(2, num_users)
            pos, first_user = SlskMessage.unpack_string(memoryview(packed), pos)
            pos, second_user = SlskMessage.unpack_string(memoryview(packed), pos)
            pos, message = SlskMessage.unpack_string(memoryview(packed), pos)

            self.assertEqual("one", first_user)
            self.assertEqual("two", second_user)
            self.assertEqual("hello", message)
            self.assertEqual(len(packed), pos)

        finally:
            MessageUsers.MAX_OUTGOING_BULK_USERS = old_limit


    def test_login_caps_username_and_password_before_hashing(self):
        username = "u" * (SlskMessage.MAX_USERNAME_FIELD_BYTES + 100)
        password = "é" * (SlskMessage.MAX_PASSWORD_FIELD_BYTES + 100)
        packed = Login(username=username, passwd=password, version=1, minorversion=2).make_network_message()

        pos, packed_username = SlskMessage.unpack_string(memoryview(packed))
        pos, packed_password = SlskMessage.unpack_string(memoryview(packed), pos)
        pos, version = SlskMessage.unpack_uint32(memoryview(packed), pos)
        pos, checksum = SlskMessage.unpack_string(memoryview(packed), pos)
        pos, minor_version = SlskMessage.unpack_uint32(memoryview(packed), pos)

        self.assertEqual(SlskMessage.MAX_USERNAME_FIELD_BYTES, len(packed_username.encode("utf-8")))
        self.assertLessEqual(len(packed_password.encode("utf-8")), SlskMessage.MAX_PASSWORD_FIELD_BYTES)
        self.assertEqual(1, version)
        self.assertEqual(2, minor_version)
        self.assertEqual(len(packed), pos)

        from hashlib import md5
        self.assertEqual(md5((packed_username + packed_password).encode()).hexdigest(), checksum)

    def test_change_password_uses_password_field_cap(self):
        password = "x" * (SlskMessage.MAX_PASSWORD_FIELD_BYTES + 100)
        packed = ChangePassword(password).make_network_message()
        pos, packed_password = SlskMessage.unpack_string(memoryview(packed))

        self.assertEqual(len(packed), pos)
        self.assertEqual(SlskMessage.MAX_PASSWORD_FIELD_BYTES, len(packed_password.encode("utf-8")))

    def test_message_stringification_truncates_large_strings_before_repr(self):
        message = MessageUser("user", "x" * (SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES + 1024))
        formatted = str(message)

        self.assertIn("truncated", formatted)
        self.assertLess(len(formatted), 10000)

    def test_unpack_uint16_advances_two_bytes(self):
        pos, value = SlskMessage.unpack_uint16(memoryview(b"\x34\x12XX"))

        self.assertEqual(2, pos)
        self.assertEqual(0x1234, value)

    def test_unpack_string_rejects_truncated_payload(self):
        message = SlskMessage.pack_uint32(4) + b"ab"

        with self.assertRaises(ValueError):
            SlskMessage.unpack_string(memoryview(message))

    def test_unpack_bytes_rejects_truncated_payload(self):
        message = SlskMessage.pack_uint32(4) + b"ab"

        with self.assertRaises(ValueError):
            SlskMessage.unpack_bytes(memoryview(message))

    def test_say_chatroom_rejects_oversized_message_field(self):
        message = (
            SlskMessage.pack_string("room")
            + SlskMessage.pack_string("user")
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            SayChatroom().parse_network_message(memoryview(message))

    def test_private_message_rejects_oversized_message_field(self):
        message = (
            SlskMessage.pack_uint32(1)
            + SlskMessage.pack_uint32(0)
            + SlskMessage.pack_string("user")
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES + 1))
            + SlskMessage.pack_bool(True)
        )

        with self.assertRaises(ValueError):
            MessageUser().parse_network_message(memoryview(message))

    def test_file_search_rejects_oversized_search_term(self):
        message = (
            SlskMessage.pack_string("user")
            + SlskMessage.pack_uint32(123)
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            FileSearch().parse_network_message(memoryview(message))

    def test_peer_file_search_rejects_oversized_search_term(self):
        message = (
            SlskMessage.pack_uint32(123)
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            FileSearchRequest().parse_network_message(memoryview(message))

    def test_room_ticker_state_rejects_oversized_ticker_message(self):
        message = (
            SlskMessage.pack_string("room")
            + SlskMessage.pack_uint32(1)
            + SlskMessage.pack_string("user")
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_TICKER_MESSAGE_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            RoomTickerState().parse_network_message(memoryview(message))

    def test_room_ticker_add_rejects_oversized_ticker_message(self):
        message = (
            SlskMessage.pack_string("room")
            + SlskMessage.pack_string("user")
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_TICKER_MESSAGE_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            RoomTickerAdd().parse_network_message(memoryview(message))

    def test_excluded_search_phrases_rejects_oversized_phrase(self):
        message = (
            SlskMessage.pack_uint32(1)
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_EXCLUDED_PHRASE_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            ExcludedSearchPhrases().parse_network_message(memoryview(message))

    def test_room_list_rejects_oversized_room_name(self):
        message = (
            SlskMessage.pack_uint32(1)
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_ROOM_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            RoomList().parse_network_message(memoryview(message))

    def test_users_message_rejects_oversized_username_and_country(self):
        username_message = (
            SlskMessage.pack_uint32(1)
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_USERNAME_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            UsersMessage.parse_users(memoryview(username_message))

        country_message = bytearray()
        country_message += SlskMessage.pack_uint32(1)
        country_message += SlskMessage.pack_string("user")
        country_message += SlskMessage.pack_uint32(0)  # statuses
        country_message += SlskMessage.pack_uint32(0)  # stats
        country_message += SlskMessage.pack_uint32(0)  # slots
        country_message += SlskMessage.pack_uint32(1)  # countries
        country_message += SlskMessage.pack_string("x" * (SlskMessage.MAX_COUNTRY_FIELD_BYTES + 1))

        with self.assertRaises(ValueError):
            UsersMessage.parse_users(memoryview(country_message))

    def test_peer_init_rejects_oversized_identity_fields(self):
        username_message = (
            SlskMessage.pack_string("x" * (SlskMessage.MAX_USERNAME_FIELD_BYTES + 1))
            + SlskMessage.pack_string("P")
        )

        with self.assertRaises(ValueError):
            PeerInit().parse_network_message(memoryview(username_message))

        conn_type_message = (
            SlskMessage.pack_string("user")
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_CONNECTION_TYPE_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            PeerInit().parse_network_message(memoryview(conn_type_message))

    def test_peer_transfer_control_declared_sizes_are_tightly_bounded(self):
        """Structured peer transfer-control messages should not inherit broad text/path budgets."""

        self.assertLess(TransferResponse.MAX_INCOMING_MESSAGE_SIZE, SlskMessage.MAX_TEXT_PEER_MESSAGE_SIZE)
        self.assertLess(QueueUpload.MAX_INCOMING_MESSAGE_SIZE, SlskMessage.MAX_PATH_PEER_MESSAGE_SIZE)
        self.assertLess(PlaceInQueueRequest.MAX_INCOMING_MESSAGE_SIZE, SlskMessage.MAX_PATH_PEER_MESSAGE_SIZE)
        self.assertLess(PlaceInQueueResponse.MAX_INCOMING_MESSAGE_SIZE, SlskMessage.MAX_PATH_PEER_MESSAGE_SIZE)
        self.assertLess(UploadDenied.MAX_INCOMING_MESSAGE_SIZE, SlskMessage.MAX_PATH_PEER_MESSAGE_SIZE)

    def test_transfer_control_messages_reject_oversized_path_and_reason(self):
        path = "x" * (FileListMessage.MAX_VIRTUAL_PATH_BYTES + 1)

        with self.assertRaises(ValueError):
            TransferRequest().parse_network_message(memoryview(
                SlskMessage.pack_uint32(TransferDirection.DOWNLOAD)
                + SlskMessage.pack_uint32(123)
                + SlskMessage.pack_string(path)
            ))

        with self.assertRaises(ValueError):
            QueueUpload().parse_network_message(memoryview(SlskMessage.pack_string(path)))

        with self.assertRaises(ValueError):
            TransferResponse().parse_network_message(memoryview(
                SlskMessage.pack_uint32(123)
                + SlskMessage.pack_bool(False)
                + SlskMessage.pack_string("x" * (SlskMessage.MAX_TRANSFER_REASON_FIELD_BYTES + 1))
            ))

    def test_peer_private_message_rejects_oversized_message_field(self):
        message = (
            SlskMessage.pack_uint32(1)
            + SlskMessage.pack_uint32(0)
            + SlskMessage.pack_string("user")
            + SlskMessage.pack_string("x" * (SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES + 1))
        )

        with self.assertRaises(ValueError):
            PMessageUser().parse_network_message(memoryview(message))

    def test_decompress_message_rejects_oversized_output(self):
        old_max_size = SharedFileListResponse.MAX_DECOMPRESSED_MESSAGE_SIZE
        SharedFileListResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = 8

        try:
            self.assertEqual(
                b"abcdefgh",
                SharedFileListResponse.decompress_message(zlib.compress(b"abcdefgh"))
            )

            with self.assertRaises(ValueError):
                SharedFileListResponse.decompress_message(zlib.compress(b"abcdefghi"))

        finally:
            SharedFileListResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = old_max_size

    def test_decompress_message_rejects_truncated_stream(self):
        with self.assertRaises(ValueError):
            SlskMessage.decompress_message(zlib.compress(b"abc")[:-1])

    def test_message_debug_string_summarizes_large_collections(self):
        message = RoomList()
        message.rooms = [(f"room{i}", i) for i in range(1000)]

        message_text = str(message)

        self.assertIn("<list len=1000 sample=", message_text)
        self.assertNotIn("room999", message_text)
        self.assertLess(len(message_text), 4096)

    def test_message_debug_string_truncates_large_strings(self):
        message = UserInfoResponse(descr="a" * 10000)

        message_text = str(message)

        self.assertIn("truncated", message_text)
        self.assertLess(len(message_text), 4096)

    def test_internal_message_debug_string_summarizes_nested_messages(self):
        message = EmitNetworkMessageEvents([WatchUser(f"user{i}") for i in range(1000)])

        message_text = str(message)

        self.assertIn("<list len=1000 sample=", message_text)
        self.assertNotIn("user999", message_text)
        self.assertLess(len(message_text), 4096)

    def test_shared_file_list_response_copy_does_not_mutate_cached_response(self):
        cached_response = SharedFileListResponse(
            public_shares={"Folder": SlskMessage.pack_uint32(0)},
            permission_level="public"
        )
        cached_message = cached_response.make_network_message()

        response_copy = cached_response.copy_without_results()
        response_copy.username = "requester"
        response_copy.parse_network_message(memoryview(response_copy.make_network_message()))

        self.assertIsNot(cached_response, response_copy)
        self.assertEqual(cached_message, response_copy.make_network_message())
        self.assertIsNone(cached_response.username)
        self.assertEqual([], cached_response.list)
        self.assertEqual("requester", response_copy.username)
        self.assertEqual({"Folder": []}, response_copy.list)
        self.assertEqual(1, response_copy.num_folders)
        self.assertEqual(0, response_copy.num_files)
        self.assertEqual(0, response_copy.shared_size)

    def test_compress_message_chunks_round_trips_chunks(self):
        chunks = [b"one", b"", b"two", b"three"]

        compressed = SlskMessage.compress_message_chunks(iter(chunks))

        self.assertEqual(b"onetwothree", zlib.decompress(compressed))

    def test_compress_message_chunks_rejects_oversized_output(self):
        with self.assertRaises(ValueError):
            SlskMessage.compress_message_chunks([b"a" * 1024], max_size=1, description="test response")

    def test_search_response_rejects_oversized_compressed_payload(self):
        old_max_size = FileSearchResponse.MAX_COMPRESSED_PEER_MESSAGE_SIZE
        FileSearchResponse.MAX_COMPRESSED_PEER_MESSAGE_SIZE = 1

        try:
            response = FileSearchResponse(
                search_username="me", token=1, shares=[("file.mp3", 1, None, None)],
                freeulslots=True, ulspeed=1, inqueue=0
            )

            with self.assertRaises(ValueError):
                response.make_network_message()

        finally:
            FileSearchResponse.MAX_COMPRESSED_PEER_MESSAGE_SIZE = old_max_size

    def test_privileged_users_retains_bounded_prefix_and_consumes_tail(self):
        old_max_retained = PrivilegedUsers.MAX_RETAINED_PRIVILEGED_USERS
        PrivilegedUsers.MAX_RETAINED_PRIVILEGED_USERS = 1

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(2)
            message += SlskMessage.pack_string("user1")
            message += SlskMessage.pack_string("user2")

            response = PrivilegedUsers()
            response.parse_network_message(memoryview(message))

            self.assertEqual(["user1"], response.users)

        finally:
            PrivilegedUsers.MAX_RETAINED_PRIVILEGED_USERS = old_max_retained

    def test_shared_file_list_response_streams_public_and_private_payloads(self):
        public_stream = (
            SlskMessage.pack_uint32(1)
            + FileListMessage.pack_file_info(("public.mp3", 10, None, None))
        )
        private_stream = (
            SlskMessage.pack_uint32(1)
            + FileListMessage.pack_file_info(("private.mp3", 20, None, None))
        )

        response = SharedFileListResponse(
            public_shares={"Public": public_stream},
            buddy_shares={"Buddy": private_stream},
            permission_level="public"
        )

        parsed_response = SharedFileListResponse()
        parsed_response.parse_network_message(memoryview(response.make_network_message()))

        self.assertEqual(["Public"], list(parsed_response.list))
        self.assertEqual(["Buddy"], list(parsed_response.privatelist))
        self.assertEqual(2, parsed_response.num_folders)
        self.assertEqual(2, parsed_response.num_files)
        self.assertEqual(30, parsed_response.shared_size)

    def test_file_record_rejects_gross_obsolete_extension_field(self):
        message = (
            FileListMessage.pack_uint8(1)
            + FileListMessage.pack_string("Song.mp3")
            + FileListMessage.pack_uint64(123)
            + FileListMessage.pack_uint32(FileListMessage.MAX_OBSOLETE_EXTENSION_BYTES + 1)
        )

        with self.assertRaises(ValueError):
            FileListMessage.skip_file_info(memoryview(message), 0)

    def test_file_search_response_streams_payload(self):
        token = 424242
        SEARCH_TOKENS_ALLOWED.add(token)

        try:
            response = FileSearchResponse(
                search_username="me",
                token=token,
                shares=[("public.mp3", 10, None, None)],
                private_shares=[("private.mp3", 20, None, None)],
                freeulslots=True,
                ulspeed=1234,
                inqueue=2
            )

            parsed_response = FileSearchResponse()
            parsed_response.parse_network_message(memoryview(response.make_network_message()))

            self.assertEqual("me", parsed_response.search_username)
            self.assertEqual(token, parsed_response.token)
            self.assertEqual(1, len(parsed_response.list))
            self.assertEqual(1, len(parsed_response.privatelist))
            self.assertEqual(1234, parsed_response.ulspeed)

        finally:
            SEARCH_TOKENS_ALLOWED.discard(token)

    def test_file_search_response_caps_public_and_private_results_together(self):
        token = 424245
        SEARCH_TOKENS_ALLOWED.add(token)
        old_max_results = FileSearchResponse.MAX_RESULT_FILES
        FileSearchResponse.MAX_RESULT_FILES = 3

        try:
            response = FileSearchResponse(
                search_username="me",
                token=token,
                shares=[("public1.mp3", 10, None, None), ("public2.mp3", 11, None, None)],
                private_shares=[("private1.mp3", 20, None, None), ("private2.mp3", 21, None, None)],
                freeulslots=True,
                ulspeed=1234,
                inqueue=2
            )

            # Outgoing responses should also respect the aggregate result cap,
            # instead of independently packing MAX_RESULT_FILES public and
            # MAX_RESULT_FILES private matches.
            parsed_response = FileSearchResponse()
            parsed_response.parse_network_message(memoryview(response.make_network_message()))
            self.assertEqual(2, len(parsed_response.list))
            self.assertEqual(1, len(parsed_response.privatelist))
            clear_search_response_users(token)

            message = zlib.compress(
                SlskMessage.pack_string("me")
                + SlskMessage.pack_uint32(token)
                + SlskMessage.pack_uint32(2)
                + FileListMessage.pack_file_info(("public1.mp3", 10, None, None))
                + FileListMessage.pack_file_info(("public2.mp3", 11, None, None))
                + SlskMessage.pack_bool(True)
                + SlskMessage.pack_uint32(1234)
                + SlskMessage.pack_uint32(2)
                + SlskMessage.pack_uint32(0)
                + SlskMessage.pack_uint32(2)
                + FileListMessage.pack_file_info(("private1.mp3", 20, None, None))
                + FileListMessage.pack_file_info(("private2.mp3", 21, None, None))
            )

            with self.assertRaises(ValueError):
                FileSearchResponse().parse_network_message(memoryview(message))

        finally:
            SEARCH_TOKENS_ALLOWED.discard(token)
            clear_search_response_users(token)
            FileSearchResponse.MAX_RESULT_FILES = old_max_results

    def test_file_search_response_ignores_duplicate_responder_before_decompressing_results(self):
        token = 424243
        username = "remoteuser"
        SEARCH_TOKENS_ALLOWED.add(token)

        try:
            first_response = FileSearchResponse(
                search_username="me",
                token=token,
                shares=[("public.mp3", 10, None, None)],
                freeulslots=True,
                ulspeed=1234,
                inqueue=2
            )

            parsed_response = FileSearchResponse()
            parsed_response.username = username
            parsed_response.parse_network_message(memoryview(first_response.make_network_message()))
            self.assertEqual(1, len(parsed_response.list))

            # The duplicate has a valid compressed username/token prefix but an
            # invalid result body. It must be dropped before result parsing.
            duplicate_message = zlib.compress(
                SlskMessage.pack_string("me")
                + SlskMessage.pack_uint32(token)
                + b"not a complete result list"
            )

            duplicate_response = FileSearchResponse()
            duplicate_response.username = username
            duplicate_response.parse_network_message(memoryview(duplicate_message))

            self.assertEqual([], duplicate_response.list)
            self.assertEqual([], duplicate_response.privatelist)

        finally:
            SEARCH_TOKENS_ALLOWED.discard(token)
            clear_search_response_users(token)

    def test_search_response_user_budget_removes_allowed_token(self):
        token = 424244
        # Exercise the parser-level responder budget directly with a small cap.
        from pynicotine import slskmessages as messages

        original_limit = messages.MAX_SEARCH_RESPONSE_USERS_PER_TOKEN
        messages.MAX_SEARCH_RESPONSE_USERS_PER_TOKEN = 1
        SEARCH_TOKENS_ALLOWED.add(token)

        try:
            first_response = FileSearchResponse(search_username="me", token=token, shares=[], freeulslots=True,
                                                ulspeed=0, inqueue=0)
            parsed_response = FileSearchResponse()
            parsed_response.username = "user1"
            parsed_response.parse_network_message(memoryview(first_response.make_network_message()))

            second_message = zlib.compress(
                SlskMessage.pack_string("me")
                + SlskMessage.pack_uint32(token)
                + b"not a complete result list"
            )
            second_response = FileSearchResponse()
            second_response.username = "user2"
            second_response.parse_network_message(memoryview(second_message))

            self.assertNotIn(token, SEARCH_TOKENS_ALLOWED)
            self.assertEqual([], second_response.list)

        finally:
            SEARCH_TOKENS_ALLOWED.discard(token)
            clear_search_response_users(token)
            messages.MAX_SEARCH_RESPONSE_USERS_PER_TOKEN = original_limit

    def test_folder_contents_response_streams_payload(self):
        token = 9001
        folder_stream = (
            SlskMessage.pack_uint32(1)
            + FileListMessage.pack_file_info(("folder-file.mp3", 30, None, None))
        )
        FOLDER_TOKENS_ALLOWED.add((None, token))

        try:
            response = FolderContentsResponse(directory="Folder", token=token, shares=folder_stream)

            parsed_response = FolderContentsResponse()
            parsed_response.parse_network_message(memoryview(response.make_network_message()))

            self.assertEqual(token, parsed_response.token)
            self.assertEqual("Folder", parsed_response.dir)
            self.assertEqual(["Folder"], list(parsed_response.list))
            self.assertEqual("folder-file.mp3", parsed_response.list["Folder"][0][1])

        finally:
            FOLDER_TOKENS_ALLOWED.discard((None, token))

    def test_folder_contents_response_consumes_token_before_malformed_body_parse(self):
        token = 9002
        FOLDER_TOKENS_ALLOWED.add((None, token))

        try:
            malformed_message = zlib.compress(SlskMessage.pack_uint32(token))

            try:
                FolderContentsResponse().parse_network_message(memoryview(malformed_message))
            except Exception:
                pass
            else:
                self.fail("Malformed folder contents response should fail parsing")

            self.assertNotIn((None, token), FOLDER_TOKENS_ALLOWED)

        finally:
            FOLDER_TOKENS_ALLOWED.discard((None, token))

    def test_distrib_embedded_message_round_trips_one_byte_code(self):
        message = DistribEmbeddedMessage(
            distrib_code=DISTRIBUTED_MESSAGE_CODES[DistribSearch],
            distrib_message=b"payload"
        ).make_network_message()

        parsed_message = DistribEmbeddedMessage()
        parsed_message.parse_network_message(memoryview(message))

        self.assertEqual(DISTRIBUTED_MESSAGE_CODES[DistribSearch], parsed_message.distrib_code)
        self.assertEqual(b"payload", parsed_message.distrib_message)

    def test_distrib_embedded_message_accepts_legacy_uint32_code(self):
        message = b"\x00\x00\x00" + SlskMessage.pack_uint8(DISTRIBUTED_MESSAGE_CODES[DistribSearch]) + b"payload"

        parsed_message = DistribEmbeddedMessage()
        parsed_message.parse_network_message(memoryview(message))

        self.assertEqual(DISTRIBUTED_MESSAGE_CODES[DistribSearch], parsed_message.distrib_code)
        self.assertEqual(b"payload", parsed_message.distrib_message)


    def test_distributed_message_caps_are_tight(self):
        self.assertLess(DistribSearch.MAX_INCOMING_MESSAGE_SIZE, SlskMessage.MAX_TEXT_PEER_MESSAGE_SIZE)
        self.assertLess(DistribBranchRoot.MAX_INCOMING_MESSAGE_SIZE, SlskMessage.MAX_TEXT_PEER_MESSAGE_SIZE)
        self.assertLess(DistribEmbeddedMessage.MAX_INCOMING_MESSAGE_SIZE, SlskMessage.MAX_TEXT_PEER_MESSAGE_SIZE)
        self.assertLess(EmbeddedMessage.MAX_INCOMING_MESSAGE_SIZE, SlskMessage.MAX_TEXT_PEER_MESSAGE_SIZE)

        self.assertEqual(
            1 + 4 + (4 + SlskMessage.MAX_USERNAME_FIELD_BYTES) + 4 + (4 + SlskMessage.MAX_SEARCH_TERM_FIELD_BYTES),
            DistribSearch.MAX_INCOMING_MESSAGE_SIZE
        )
        self.assertEqual(
            DistribSearch.MAX_INCOMING_MESSAGE_SIZE + 4,
            DistribEmbeddedMessage.MAX_INCOMING_MESSAGE_SIZE
        )

    def test_skip_file_info_advances_over_large_attribute_tail(self):
        num_attrs = FileListMessage.MAX_FILE_ATTRIBUTE_RECORDS + 100
        message = bytearray()
        message += SlskMessage.pack_uint8(1)
        message += SlskMessage.pack_string("file.mp3")
        message += SlskMessage.pack_uint64(123)
        message += SlskMessage.pack_uint32(0)  # Obsolete extension field
        message += SlskMessage.pack_uint32(num_attrs)
        message += b"\xff\x00\x00\x00\x01\x00\x00\x00" * num_attrs

        self.assertEqual(len(message), FileListMessage.skip_file_info(memoryview(message), 0))

    def test_file_attributes_reject_truncated_list(self):
        message = SlskMessage.pack_uint32(1) + b"\x00"

        with self.assertRaises(ValueError):
            FileListMessage.unpack_file_attributes(memoryview(message), 0)

    def test_room_list_rejects_mismatched_user_count_records(self):
        message = bytearray()
        message += SlskMessage.pack_uint32(1)
        message += SlskMessage.pack_string("room")
        message += SlskMessage.pack_uint32(2)
        message += SlskMessage.pack_uint32(10)
        message += SlskMessage.pack_uint32(20)

        with self.assertRaises(ValueError):
            RoomList().parse_network_message(memoryview(message))

    @staticmethod
    def _pack_room_list_segment(rooms, has_count=True):
        message = bytearray()
        message += SlskMessage.pack_uint32(len(rooms))

        for room in rooms:
            message += SlskMessage.pack_string(room[0] if has_count else room)

        if has_count:
            message += SlskMessage.pack_uint32(len(rooms))

            for _room, user_count in rooms:
                message += SlskMessage.pack_uint32(user_count)

        return message

    def test_room_list_retains_bounded_prefix_while_consuming_tail_sections(self):
        """The aggregate room cap should not reject otherwise valid tail sections."""

        old_limit = RoomList.MAX_TOTAL_ROOM_LIST_ITEMS
        RoomList.MAX_TOTAL_ROOM_LIST_ITEMS = 2

        try:
            message = bytearray()
            message += self._pack_room_list_segment((("public1", 10), ("public2", 20)))
            message += self._pack_room_list_segment((("owned", 1),))
            message += self._pack_room_list_segment((("other", 2),))
            message += self._pack_room_list_segment(("operated",), has_count=False)

            parsed = RoomList()
            parsed.parse_network_message(memoryview(message))

            self.assertEqual([["public1", 10], ["public2", 20]], parsed.rooms)
            self.assertEqual([], parsed.ownedprivaterooms)
            self.assertEqual([], parsed.otherprivaterooms)
            self.assertEqual([], parsed.operatedprivaterooms)

        finally:
            RoomList.MAX_TOTAL_ROOM_LIST_ITEMS = old_limit

    def test_room_list_still_rejects_malformed_tail_after_retention_cap(self):
        old_limit = RoomList.MAX_TOTAL_ROOM_LIST_ITEMS
        RoomList.MAX_TOTAL_ROOM_LIST_ITEMS = 1

        try:
            message = bytearray()
            message += self._pack_room_list_segment((("public", 10),))
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_uint32(RoomList.MAX_ROOM_FIELD_BYTES + 1)
            message += b"x" * (RoomList.MAX_ROOM_FIELD_BYTES + 1)
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_uint32(1)
            message += self._pack_room_list_segment(())
            message += self._pack_room_list_segment((), has_count=False)

            with self.assertRaises(ValueError):
                RoomList().parse_network_message(memoryview(message))

        finally:
            RoomList.MAX_TOTAL_ROOM_LIST_ITEMS = old_limit

    def test_users_message_rejects_mismatched_status_count(self):
        message = bytearray()
        message += SlskMessage.pack_uint32(1)
        message += SlskMessage.pack_string("user")
        message += SlskMessage.pack_uint32(2)
        message += SlskMessage.pack_uint32(1)
        message += SlskMessage.pack_uint32(2)

        with self.assertRaises(ValueError):
            UsersMessage.parse_users(memoryview(message))

    def test_recommendations_message_deduplicates_across_sections(self):
        message = bytearray()
        message += SlskMessage.pack_uint32(1)
        message += SlskMessage.pack_string("artist")
        message += SlskMessage.pack_int32(10)
        message += SlskMessage.pack_uint32(1)
        message += SlskMessage.pack_string("artist")
        message += SlskMessage.pack_int32(10)

        _pos, recommendations, unrecommendations = RecommendationsMessage.parse_recommendations(memoryview(message))

        self.assertEqual([("artist", 10)], recommendations)
        self.assertEqual([], unrecommendations)

    def test_similar_recommendations_parse_count_after_recommendation(self):
        message = bytearray()
        message += SlskMessage.pack_string("artist")
        message += SlskMessage.pack_uint32(1)
        message += SlskMessage.pack_string("similar artist")

        parsed_message = SimilarRecommendations()
        parsed_message.parse_network_message(memoryview(message))

        self.assertEqual("artist", parsed_message.recommendation)
        self.assertEqual(["similar artist"], parsed_message.similar_recommendations)

    def test_recommendations_message_rejects_excessive_count(self):
        original_max_items = RecommendationsMessage.MAX_RECOMMENDATION_ITEMS
        RecommendationsMessage.MAX_RECOMMENDATION_ITEMS = 0

        try:
            message = SlskMessage.pack_uint32(1)

            with self.assertRaises(ValueError):
                RecommendationsMessage.parse_recommendations(memoryview(message))

        finally:
            RecommendationsMessage.MAX_RECOMMENDATION_ITEMS = original_max_items

    def test_ui_facing_server_lists_use_specific_caps(self):
        """Server list counts should be bounded before large GTK/core fanout."""

        original_caps = {
            "room": RoomList.MAX_SERVER_LIST_ITEMS,
            "room_server": RoomList.MAX_SERVER_LIST_ITEMS,
            "interests": UserInterests.MAX_USER_INTEREST_ITEMS,
            "private_users": PrivateRoomUsers.MAX_PRIVATE_ROOM_USERS,
            "private_users_server": PrivateRoomUsers.MAX_SERVER_LIST_ITEMS,
            "private_operators": PrivateRoomOperators.MAX_PRIVATE_ROOM_OPERATORS,
            "private_operators_server": PrivateRoomOperators.MAX_SERVER_LIST_ITEMS,
            "related": RelatedSearch.MAX_RELATED_SEARCH_TERMS,
            "excluded": ExcludedSearchPhrases.MAX_EXCLUDED_SEARCH_PHRASES,
        }

        try:
            RoomList.MAX_SERVER_LIST_ITEMS = 0
            with self.assertRaises(ValueError):
                RoomList().parse_network_message(memoryview(SlskMessage.pack_uint32(1)))

            UserInterests.MAX_USER_INTEREST_ITEMS = 0
            with self.assertRaises(ValueError):
                UserInterests().parse_network_message(memoryview(
                    SlskMessage.pack_string("user") + SlskMessage.pack_uint32(1)))

            # Private-room parser retention caps may be lower than the gross
            # protocol count cap, but a per-class gross server-list cap still
            # rejects impossible server counts before looping.
            PrivateRoomUsers.MAX_SERVER_LIST_ITEMS = 0
            with self.assertRaises(ValueError):
                PrivateRoomUsers().parse_network_message(memoryview(
                    SlskMessage.pack_string("room") + SlskMessage.pack_uint32(1)))

            PrivateRoomOperators.MAX_SERVER_LIST_ITEMS = 0
            with self.assertRaises(ValueError):
                PrivateRoomOperators().parse_network_message(memoryview(
                    SlskMessage.pack_string("room") + SlskMessage.pack_uint32(1)))

            RelatedSearch.MAX_RELATED_SEARCH_TERMS = 0
            with self.assertRaises(ValueError):
                RelatedSearch().parse_network_message(memoryview(
                    SlskMessage.pack_string("query") + SlskMessage.pack_uint32(1)))

            ExcludedSearchPhrases.MAX_EXCLUDED_SEARCH_PHRASES = 0
            with self.assertRaises(ValueError):
                ExcludedSearchPhrases().parse_network_message(memoryview(SlskMessage.pack_uint32(1)))

        finally:
            RoomList.MAX_SERVER_LIST_ITEMS = original_caps["room"]
            RoomList.MAX_SERVER_LIST_ITEMS = original_caps["room_server"]
            UserInterests.MAX_USER_INTEREST_ITEMS = original_caps["interests"]
            PrivateRoomUsers.MAX_PRIVATE_ROOM_USERS = original_caps["private_users"]
            PrivateRoomUsers.MAX_SERVER_LIST_ITEMS = original_caps["private_users_server"]
            PrivateRoomOperators.MAX_PRIVATE_ROOM_OPERATORS = original_caps["private_operators"]
            PrivateRoomOperators.MAX_SERVER_LIST_ITEMS = original_caps["private_operators_server"]
            if "MAX_SERVER_LIST_ITEMS" in PrivateRoomUsers.__dict__:
                del PrivateRoomUsers.MAX_SERVER_LIST_ITEMS
            if "MAX_SERVER_LIST_ITEMS" in PrivateRoomOperators.__dict__:
                del PrivateRoomOperators.MAX_SERVER_LIST_ITEMS
            RelatedSearch.MAX_RELATED_SEARCH_TERMS = original_caps["related"]
            ExcludedSearchPhrases.MAX_EXCLUDED_SEARCH_PHRASES = original_caps["excluded"]

    def test_room_ticker_state_rejects_gross_excessive_count(self):
        original_max_items = RoomTickerState.MAX_SERVER_LIST_ITEMS
        RoomTickerState.MAX_SERVER_LIST_ITEMS = 0

        try:
            message = SlskMessage.pack_string("room") + SlskMessage.pack_uint32(1)

            with self.assertRaises(ValueError):
                RoomTickerState().parse_network_message(memoryview(message))

        finally:
            RoomTickerState.MAX_SERVER_LIST_ITEMS = original_max_items

    def test_room_ticker_state_retains_bounded_prefix(self):
        original_max_tickers = RoomTickerState.MAX_ROOM_TICKERS
        RoomTickerState.MAX_ROOM_TICKERS = 1

        try:
            message = bytearray()
            message += SlskMessage.pack_string("room")
            message += SlskMessage.pack_uint32(2)
            message += SlskMessage.pack_string("alice") + SlskMessage.pack_string("one")
            message += SlskMessage.pack_string("bob") + SlskMessage.pack_string("two")

            parsed_message = RoomTickerState()
            parsed_message.parse_network_message(memoryview(message))

        finally:
            RoomTickerState.MAX_ROOM_TICKERS = original_max_tickers

        self.assertEqual(2, parsed_message.num_tickers)
        self.assertEqual([("alice", "one")], parsed_message.msgs)

    def test_room_ticker_state_skips_decoding_discarded_tails(self):
        original_max_tickers = RoomTickerState.MAX_ROOM_TICKERS
        original_unpack_string = SlskMessage.unpack_string
        calls = []

        def counting_unpack_string(message, start=0):
            calls.append(start)
            return original_unpack_string(message, start)

        RoomTickerState.MAX_ROOM_TICKERS = 0

        try:
            message = bytearray()
            message += SlskMessage.pack_string("room")
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_string("alice") + SlskMessage.pack_string("one")

            SlskMessage.unpack_string = staticmethod(counting_unpack_string)
            parsed_message = RoomTickerState()
            parsed_message.parse_network_message(memoryview(message))

        finally:
            SlskMessage.unpack_string = staticmethod(original_unpack_string)
            RoomTickerState.MAX_ROOM_TICKERS = original_max_tickers

        self.assertEqual([], parsed_message.msgs)
        self.assertEqual(1, len(calls))

    def test_private_room_lists_retain_bounded_prefixes(self):
        old_users = PrivateRoomUsers.MAX_PRIVATE_ROOM_USERS
        old_operators = PrivateRoomOperators.MAX_PRIVATE_ROOM_OPERATORS
        PrivateRoomUsers.MAX_PRIVATE_ROOM_USERS = 1
        PrivateRoomOperators.MAX_PRIVATE_ROOM_OPERATORS = 1

        try:
            users_message = bytearray()
            users_message += SlskMessage.pack_string("room")
            users_message += SlskMessage.pack_uint32(2)
            users_message += SlskMessage.pack_string("alice")
            users_message += SlskMessage.pack_string("bob")

            users = PrivateRoomUsers()
            users.parse_network_message(memoryview(users_message))

            operators_message = bytearray()
            operators_message += SlskMessage.pack_string("room")
            operators_message += SlskMessage.pack_uint32(2)
            operators_message += SlskMessage.pack_string("carol")
            operators_message += SlskMessage.pack_string("dan")

            operators = PrivateRoomOperators()
            operators.parse_network_message(memoryview(operators_message))

        finally:
            PrivateRoomUsers.MAX_PRIVATE_ROOM_USERS = old_users
            PrivateRoomOperators.MAX_PRIVATE_ROOM_OPERATORS = old_operators

        self.assertEqual(2, users.numusers)
        self.assertEqual(["alice"], users.users)
        self.assertEqual(2, operators.number)
        self.assertEqual(["carol"], operators.operators)

    def test_private_room_lists_skip_decoding_discarded_tails(self):
        old_users = PrivateRoomUsers.MAX_PRIVATE_ROOM_USERS
        old_operators = PrivateRoomOperators.MAX_PRIVATE_ROOM_OPERATORS
        original_unpack_string = SlskMessage.unpack_string
        calls = []

        def counting_unpack_string(message, start=0):
            calls.append(start)
            return original_unpack_string(message, start)

        PrivateRoomUsers.MAX_PRIVATE_ROOM_USERS = 0
        PrivateRoomOperators.MAX_PRIVATE_ROOM_OPERATORS = 0

        try:
            users_message = bytearray()
            users_message += SlskMessage.pack_string("room")
            users_message += SlskMessage.pack_uint32(1)
            users_message += SlskMessage.pack_string("alice")

            operators_message = bytearray()
            operators_message += SlskMessage.pack_string("room")
            operators_message += SlskMessage.pack_uint32(1)
            operators_message += SlskMessage.pack_string("carol")

            SlskMessage.unpack_string = staticmethod(counting_unpack_string)
            users = PrivateRoomUsers()
            users.parse_network_message(memoryview(users_message))
            operators = PrivateRoomOperators()
            operators.parse_network_message(memoryview(operators_message))

        finally:
            SlskMessage.unpack_string = staticmethod(original_unpack_string)
            PrivateRoomUsers.MAX_PRIVATE_ROOM_USERS = old_users
            PrivateRoomOperators.MAX_PRIVATE_ROOM_OPERATORS = old_operators

        self.assertEqual([], users.users)
        self.assertEqual([], operators.operators)
        self.assertEqual(2, len(calls))

    def test_possible_parents_rejects_excessive_count(self):
        original_max_parents = PossibleParents.MAX_POSSIBLE_PARENTS
        PossibleParents.MAX_POSSIBLE_PARENTS = 0

        try:
            with self.assertRaises(ValueError):
                PossibleParents().parse_network_message(memoryview(SlskMessage.pack_uint32(1)))

        finally:
            PossibleParents.MAX_POSSIBLE_PARENTS = original_max_parents

    def test_join_room_retains_bounded_user_prefix_while_consuming_segmented_tail(self):
        old_limit = JoinRoom.MAX_JOIN_ROOM_USERS
        JoinRoom.MAX_JOIN_ROOM_USERS = 1

        try:
            message = bytearray()
            message += SlskMessage.pack_string("room")
            message += SlskMessage.pack_uint32(3)

            for username in ("one", "two", "three"):
                message += SlskMessage.pack_string(username)

            message += SlskMessage.pack_uint32(3)
            for status in (1, 2, 3):
                message += SlskMessage.pack_uint32(status)

            message += SlskMessage.pack_uint32(3)
            for index in range(3):
                message += SlskMessage.pack_uint32(10 + index)  # average speed
                message += SlskMessage.pack_uint32(20 + index)  # upload count
                message += SlskMessage.pack_uint32(30 + index)  # unknown
                message += SlskMessage.pack_uint32(40 + index)  # files
                message += SlskMessage.pack_uint32(50 + index)  # dirs

            message += SlskMessage.pack_uint32(3)
            for slotsfull in (0, 1, 0):
                message += SlskMessage.pack_uint32(slotsfull)

            message += SlskMessage.pack_uint32(3)
            for country in ("AA", "BB", "CC"):
                message += SlskMessage.pack_string(country)

            parsed = JoinRoom()
            parsed.parse_network_message(memoryview(message))

            self.assertEqual(1, len(parsed.users))
            self.assertEqual("one", parsed.users[0].username)
            self.assertEqual(1, parsed.users[0].status)
            self.assertEqual(10, parsed.users[0].avgspeed)
            self.assertEqual(20, parsed.users[0].uploadnum)
            self.assertEqual(30, parsed.users[0].unknown)
            self.assertEqual(40, parsed.users[0].files)
            self.assertEqual(50, parsed.users[0].dirs)
            self.assertEqual(0, parsed.users[0].slotsfull)
            self.assertEqual("AA", parsed.users[0].country)

        finally:
            JoinRoom.MAX_JOIN_ROOM_USERS = old_limit

    def test_join_room_retains_bounded_operator_prefix_while_consuming_tail(self):
        old_limit = JoinRoom.MAX_JOIN_ROOM_OPERATORS
        JoinRoom.MAX_JOIN_ROOM_OPERATORS = 1

        try:
            message = bytearray()
            message += SlskMessage.pack_string("room")
            message += SlskMessage.pack_uint32(0)  # user names
            message += SlskMessage.pack_uint32(0)  # user statuses
            message += SlskMessage.pack_uint32(0)  # user stats
            message += SlskMessage.pack_uint32(0)  # user slots
            message += SlskMessage.pack_uint32(0)  # user countries
            message += SlskMessage.pack_string("owner")
            message += SlskMessage.pack_uint32(3)

            for operator in ("op1", "op2", "op3"):
                message += SlskMessage.pack_string(operator)

            parsed = JoinRoom()
            parsed.parse_network_message(memoryview(message))

            self.assertTrue(parsed.private)
            self.assertEqual("owner", parsed.owner)
            self.assertEqual(["op1"], parsed.operators)

        finally:
            JoinRoom.MAX_JOIN_ROOM_OPERATORS = old_limit

    def test_join_room_skips_decoding_discarded_operator_tails(self):
        old_limit = JoinRoom.MAX_JOIN_ROOM_OPERATORS
        original_unpack_string = SlskMessage.unpack_string
        calls = []

        def counting_unpack_string(message, start=0):
            calls.append(start)
            return original_unpack_string(message, start)

        JoinRoom.MAX_JOIN_ROOM_OPERATORS = 0

        try:
            message = bytearray()
            message += SlskMessage.pack_string("room")
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_string("owner")
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_string("operator")

            SlskMessage.unpack_string = staticmethod(counting_unpack_string)
            parsed = JoinRoom()
            parsed.parse_network_message(memoryview(message))

        finally:
            SlskMessage.unpack_string = staticmethod(original_unpack_string)
            JoinRoom.MAX_JOIN_ROOM_OPERATORS = old_limit

        self.assertTrue(parsed.private)
        self.assertEqual([], parsed.operators)
        self.assertEqual(2, len(calls))

    def test_join_room_rejects_excessive_operator_count(self):
        original_max_items = JoinRoom.MAX_SERVER_LIST_ITEMS
        JoinRoom.MAX_SERVER_LIST_ITEMS = 0

        try:
            message = bytearray()
            message += SlskMessage.pack_string("room")
            message += SlskMessage.pack_uint32(0)  # user names
            message += SlskMessage.pack_uint32(0)  # user statuses
            message += SlskMessage.pack_uint32(0)  # user stats
            message += SlskMessage.pack_uint32(0)  # user slots
            message += SlskMessage.pack_uint32(0)  # user countries
            message += SlskMessage.pack_string("owner")
            message += SlskMessage.pack_uint32(1)  # operators

            with self.assertRaises(ValueError):
                JoinRoom().parse_network_message(memoryview(message))

        finally:
            JoinRoom.MAX_SERVER_LIST_ITEMS = original_max_items

    def test_file_attributes_skip_excessive_unknown_tail(self):
        original_max_records = FileListMessage.MAX_FILE_ATTRIBUTE_RECORDS
        FileListMessage.MAX_FILE_ATTRIBUTE_RECORDS = 1

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(3)
            message += SlskMessage.pack_uint32(FileAttribute.BITRATE)
            message += SlskMessage.pack_uint32(320)
            message += SlskMessage.pack_uint32(9999)
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_uint32(FileAttribute.DURATION)
            message += SlskMessage.pack_uint32(180)

            pos, attrs = FileListMessage.unpack_file_attributes(memoryview(message), 0)
        finally:
            FileListMessage.MAX_FILE_ATTRIBUTE_RECORDS = original_max_records

        self.assertEqual(pos, len(message))
        self.assertEqual(attrs, {FileAttribute.BITRATE: 320})

    def test_shared_file_list_response_rejects_excessive_folder_count(self):
        original_max_folders = SharedFileListResponse.MAX_RESULT_FOLDERS
        SharedFileListResponse.MAX_RESULT_FOLDERS = 0

        try:
            message = zlib.compress(SlskMessage.pack_uint32(1))

            with self.assertRaises(ValueError):
                SharedFileListResponse().parse_network_message(memoryview(message))

        finally:
            SharedFileListResponse.MAX_RESULT_FOLDERS = original_max_folders

    def test_shared_file_list_response_rejects_excessive_file_count(self):
        original_max_files = SharedFileListResponse.MAX_RESULT_FILES
        SharedFileListResponse.MAX_RESULT_FILES = 1

        try:
            message = zlib.compress(
                SlskMessage.pack_uint32(1)
                + SlskMessage.pack_string("Folder")
                + SlskMessage.pack_uint32(2)
            )

            with self.assertRaises(ValueError):
                SharedFileListResponse().parse_network_message(memoryview(message))

        finally:
            SharedFileListResponse.MAX_RESULT_FILES = original_max_files

    def test_shared_file_list_response_rejects_oversized_decompressed_message(self):
        old_max_size = SharedFileListResponse.MAX_DECOMPRESSED_MESSAGE_SIZE
        SharedFileListResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = 7

        try:
            message = zlib.compress(
                SlskMessage.pack_uint32(0)  # Public share folder count
                + SlskMessage.pack_uint32(0)  # Unknown value
            )

            with self.assertRaises(ValueError):
                SharedFileListResponse().parse_network_message(memoryview(message))

        finally:
            SharedFileListResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = old_max_size

    def test_shared_file_list_response_tracks_summary_stats_while_parsing(self):
        """Browse stats should be computed during parsing, not by a second UI-thread walk."""

        message = bytearray()
        message += SlskMessage.pack_uint32(1)  # Public folders
        message += SlskMessage.pack_string("Public")
        message += SlskMessage.pack_uint32(2)
        message += FileListMessage.pack_file_info(("one.mp3", 10, None, None))
        message += FileListMessage.pack_file_info(("two.mp3", 20, None, None))
        message += SlskMessage.pack_uint32(0)  # Unknown value
        message += SlskMessage.pack_uint32(1)  # Private folders
        message += SlskMessage.pack_string("Private")
        message += SlskMessage.pack_uint32(1)
        message += FileListMessage.pack_file_info(("three.mp3", 30, None, None))

        response = SharedFileListResponse()
        response.parse_network_message(memoryview(zlib.compress(message)))

        self.assertEqual(2, response.num_folders)
        self.assertEqual(3, response.num_files)
        self.assertEqual(60, response.shared_size)

    def test_shared_file_list_response_enforces_combined_public_private_file_cap(self):
        original_max_files = SharedFileListResponse.MAX_RESULT_FILES
        SharedFileListResponse.MAX_RESULT_FILES = 2

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_string("Public")
            message += SlskMessage.pack_uint32(2)
            message += FileListMessage.pack_file_info(("one.mp3", 10, None, None))
            message += FileListMessage.pack_file_info(("two.mp3", 20, None, None))
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_string("Private")
            message += SlskMessage.pack_uint32(1)
            message += FileListMessage.pack_file_info(("three.mp3", 30, None, None))

            with self.assertRaises(ValueError):
                SharedFileListResponse().parse_network_message(memoryview(zlib.compress(message)))

        finally:
            SharedFileListResponse.MAX_RESULT_FILES = original_max_files

    def test_shared_file_list_response_enforces_combined_public_private_folder_cap(self):
        original_max_folders = SharedFileListResponse.MAX_RESULT_FOLDERS
        SharedFileListResponse.MAX_RESULT_FOLDERS = 1

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_string("Public")
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_string("Private")
            message += SlskMessage.pack_uint32(0)

            with self.assertRaises(ValueError):
                SharedFileListResponse().parse_network_message(memoryview(zlib.compress(message)))

        finally:
            SharedFileListResponse.MAX_RESULT_FOLDERS = original_max_folders

    def test_shared_file_list_response_parses_into_folder_mapping(self):
        """Avoid retaining a huge list of folder pairs before UserBrowse converts it to a dict."""

        message = bytearray()
        message += SlskMessage.pack_uint32(1)
        message += SlskMessage.pack_string("Folder")
        message += SlskMessage.pack_uint32(1)
        message += FileListMessage.pack_file_info(("track.mp3", 10, None, None))

        response = SharedFileListResponse()
        response.parse_network_message(memoryview(zlib.compress(message)))

        self.assertIsInstance(response.list, dict)
        self.assertEqual(["Folder"], list(response.list))
        self.assertEqual("track.mp3", response.list["Folder"][0][1])

    def test_folder_contents_response_rejects_oversized_decompressed_message(self):
        old_max_size = FolderContentsResponse.MAX_DECOMPRESSED_MESSAGE_SIZE
        token = 12345
        FolderContentsResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = 7
        FOLDER_TOKENS_ALLOWED.add((None, token))

        try:
            message = zlib.compress(
                SlskMessage.pack_uint32(token)  # Token
                + SlskMessage.pack_uint32(0)   # Empty folder name
            )

            with self.assertRaises(ValueError):
                FolderContentsResponse().parse_network_message(memoryview(message))

        finally:
            FOLDER_TOKENS_ALLOWED.discard((None, token))
            FolderContentsResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = old_max_size

    def test_folder_contents_response_ignores_disallowed_token_before_decompressing_results(self):
        old_max_size = FolderContentsResponse.MAX_DECOMPRESSED_MESSAGE_SIZE
        token = 123456789
        FolderContentsResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = 7
        FOLDER_TOKENS_ALLOWED.discard((None, token))

        try:
            message = zlib.compress(
                SlskMessage.pack_uint32(token)
                + (b"a" * 1024)
            )

            response = FolderContentsResponse()
            response.parse_network_message(memoryview(message))

            self.assertEqual(token, response.token)
            self.assertIsNone(response.dir)
            self.assertEqual({}, response.list)

        finally:
            FolderContentsResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = old_max_size

    def test_folder_contents_response_reuses_decompression_after_token_check(self):
        """Authorized folder responses should not be decompressed from scratch twice."""

        token = 123456789
        folder = "Folder"
        original_decompress_message = FolderContentsResponse.decompress_message
        FOLDER_TOKENS_ALLOWED.add((None, token))

        def fail_if_called(cls, message, max_size=None):
            raise AssertionError("folder contents response was decompressed from scratch")

        try:
            message = zlib.compress(
                SlskMessage.pack_uint32(token)
                + SlskMessage.pack_string(folder)
                + SlskMessage.pack_uint32(1)
                + SlskMessage.pack_string(folder)
                + SlskMessage.pack_uint32(0)
            )

            FolderContentsResponse.decompress_message = classmethod(fail_if_called)
            response = FolderContentsResponse()
            response.parse_network_message(memoryview(message))

            self.assertEqual(token, response.token)
            self.assertEqual(folder, response.dir)
            self.assertEqual({folder: []}, response.list)

        finally:
            FolderContentsResponse.decompress_message = original_decompress_message
            FOLDER_TOKENS_ALLOWED.discard((None, token))

    def test_user_info_response_ignores_oversized_picture(self):
        old_picture_size = UserInfoResponse.MAX_PICTURE_SIZE
        UserInfoResponse.MAX_PICTURE_SIZE = 4

        try:
            message = bytearray()
            message += SlskMessage.pack_string("hello")
            message += SlskMessage.pack_bool(True)
            message += SlskMessage.pack_bytes(b"abcde")
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_uint32(2)
            message += SlskMessage.pack_bool(True)
            message += SlskMessage.pack_uint32(3)

            response = UserInfoResponse()
            response.parse_network_message(memoryview(message))

            self.assertEqual("hello", response.descr)
            self.assertIsNone(response.pic)
            self.assertEqual(1, response.totalupl)
            self.assertEqual(2, response.queuesize)
            self.assertTrue(response.slotsavail)
            self.assertEqual(3, response.uploadallowed)

        finally:
            UserInfoResponse.MAX_PICTURE_SIZE = old_picture_size

    def test_user_info_response_rejects_oversized_description(self):
        old_description_size = UserInfoResponse.MAX_DESCRIPTION_SIZE
        UserInfoResponse.MAX_DESCRIPTION_SIZE = 4

        try:
            message = SlskMessage.pack_string("hello")

            with self.assertRaises(ValueError):
                UserInfoResponse().parse_network_message(memoryview(message))

        finally:
            UserInfoResponse.MAX_DESCRIPTION_SIZE = old_description_size

    def test_user_info_response_omits_oversized_picture_when_packing(self):
        old_picture_size = UserInfoResponse.MAX_PICTURE_SIZE
        UserInfoResponse.MAX_PICTURE_SIZE = 4

        try:
            message = UserInfoResponse(
                descr="hello", pic=b"abcde", totalupl=1, queuesize=2, slotsavail=True, uploadallowed=3
            ).make_network_message()
            response = UserInfoResponse()
            response.parse_network_message(memoryview(message))

            self.assertEqual("hello", response.descr)
            self.assertFalse(response.has_pic)
            self.assertIsNone(response.pic)

        finally:
            UserInfoResponse.MAX_PICTURE_SIZE = old_picture_size

    def test_file_search_response_rejects_oversized_decompressed_message(self):
        old_max_size = FileSearchResponse.MAX_DECOMPRESSED_MESSAGE_SIZE
        FileSearchResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = 12
        token = 12345
        SEARCH_TOKENS_ALLOWED.add(token)

        try:
            message = zlib.compress(
                SlskMessage.pack_string("user")
                + SlskMessage.pack_uint32(token)
                + SlskMessage.pack_uint32(0)
                + SlskMessage.pack_bool(True)
                + SlskMessage.pack_uint32(0)
                + SlskMessage.pack_uint32(0)
                + SlskMessage.pack_uint32(0)
            )

            with self.assertRaises(ValueError):
                FileSearchResponse().parse_network_message(memoryview(message))

        finally:
            SEARCH_TOKENS_ALLOWED.discard(token)
            FileSearchResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = old_max_size

    def test_file_search_response_rejects_username_over_size_limit(self):
        old_username_size = FileSearchResponse.MAX_DECOMPRESSED_USERNAME_SIZE
        FileSearchResponse.MAX_DECOMPRESSED_USERNAME_SIZE = 4

        try:
            message = zlib.compress(
                SlskMessage.pack_string("largeuser")
                + SlskMessage.pack_uint32(12345)
            )

            with self.assertRaises(ValueError):
                FileSearchResponse().parse_network_message(memoryview(message))

        finally:
            FileSearchResponse.MAX_DECOMPRESSED_USERNAME_SIZE = old_username_size

    def test_file_search_response_rejects_oversized_username_before_decompressing_it(self):
        old_max_size = FileSearchResponse.MAX_DECOMPRESSED_MESSAGE_SIZE
        FileSearchResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = 12

        try:
            message = zlib.compress(SlskMessage.pack_uint32(1000))

            with self.assertRaises(ValueError):
                FileSearchResponse().parse_network_message(memoryview(message))

        finally:
            FileSearchResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = old_max_size

    def test_file_search_response_ignores_disallowed_token_before_decompressing_results(self):
        old_max_size = FileSearchResponse.MAX_DECOMPRESSED_MESSAGE_SIZE
        token = 123456789
        FileSearchResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = 12
        SEARCH_TOKENS_ALLOWED.discard(token)

        try:
            message = zlib.compress(
                SlskMessage.pack_string("user")
                + SlskMessage.pack_uint32(token)
                + (b"a" * 1024)
            )

            response = FileSearchResponse()
            response.parse_network_message(memoryview(message))

            self.assertEqual("user", response.search_username)
            self.assertEqual(token, response.token)
            self.assertEqual([], response.list)

        finally:
            FileSearchResponse.MAX_DECOMPRESSED_MESSAGE_SIZE = old_max_size

    def test_file_search_response_preserves_search_username(self):
        token = 123456789
        SEARCH_TOKENS_ALLOWED.add(token)

        try:
            message = FileSearchResponse(
                search_username="remoteuser",
                token=token,
                shares=[],
                freeulslots=True,
                ulspeed=1234,
                inqueue=5
            ).make_network_message()

            response = FileSearchResponse()
            response.parse_network_message(memoryview(message))

            self.assertEqual("remoteuser", response.search_username)
            self.assertEqual(token, response.token)
            self.assertEqual([], response.list)
            self.assertTrue(response.freeulslots)
            self.assertEqual(1234, response.ulspeed)
            self.assertEqual(5, response.inqueue)

        finally:
            SEARCH_TOKENS_ALLOWED.discard(token)

    def test_file_search_response_rejects_excessive_result_count(self):
        original_max_files = FileSearchResponse.MAX_RESULT_FILES
        token = 123456789
        FileSearchResponse.MAX_RESULT_FILES = 0
        clear_search_response_users(token)
        SEARCH_TOKENS_ALLOWED.add(token)

        try:
            message = zlib.compress(
                SlskMessage.pack_string("remoteuser")
                + SlskMessage.pack_uint32(token)
                + SlskMessage.pack_uint32(1)
            )

            with self.assertRaises(ValueError):
                FileSearchResponse().parse_network_message(memoryview(message))

        finally:
            SEARCH_TOKENS_ALLOWED.discard(token)
            clear_search_response_users(token)
            FileSearchResponse.MAX_RESULT_FILES = original_max_files

    def test_folder_contents_response_rejects_excessive_folder_count(self):
        original_max_folders = FolderContentsResponse.MAX_RESULT_FOLDERS
        token = 123456789
        FolderContentsResponse.MAX_RESULT_FOLDERS = 0
        FOLDER_TOKENS_ALLOWED.add((None, token))

        try:
            message = zlib.compress(
                SlskMessage.pack_uint32(token)
                + SlskMessage.pack_string("Folder")
                + SlskMessage.pack_uint32(1)
            )

            with self.assertRaises(ValueError):
                FolderContentsResponse().parse_network_message(memoryview(message))

        finally:
            FOLDER_TOKENS_ALLOWED.discard((None, token))
            FolderContentsResponse.MAX_RESULT_FOLDERS = original_max_folders

    def test_folder_contents_response_rejects_excessive_file_count(self):
        original_max_files = FolderContentsResponse.MAX_RESULT_FILES
        token = 123456789
        FolderContentsResponse.MAX_RESULT_FILES = 0
        FOLDER_TOKENS_ALLOWED.add((None, token))

        try:
            message = zlib.compress(
                SlskMessage.pack_uint32(token)
                + SlskMessage.pack_string("Folder")
                + SlskMessage.pack_uint32(1)
                + SlskMessage.pack_string("Folder")
                + SlskMessage.pack_uint32(1)
            )

            with self.assertRaises(ValueError):
                FolderContentsResponse().parse_network_message(memoryview(message))

        finally:
            FOLDER_TOKENS_ALLOWED.discard((None, token))
            FolderContentsResponse.MAX_RESULT_FILES = original_max_files

    def test_folder_contents_response_keeps_only_requested_folder(self):
        token = 123456789
        requested_folder = "Folder"
        ignored_folder = "Other"
        FOLDER_TOKENS_ALLOWED.add((None, token))

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(token)
            message += SlskMessage.pack_string(requested_folder)
            message += SlskMessage.pack_uint32(2)

            message += SlskMessage.pack_string(ignored_folder)
            message += SlskMessage.pack_uint32(2)
            message += FileListMessage.pack_file_info(("z.mp3", 1, None, None))
            message += FileListMessage.pack_file_info(("a.mp3", 1, None, None))

            message += SlskMessage.pack_string(requested_folder)
            message += SlskMessage.pack_uint32(1)
            message += FileListMessage.pack_file_info(("track.flac", 123, None, None))

            response = FolderContentsResponse()
            response.parse_network_message(memoryview(zlib.compress(message)))

            self.assertEqual({requested_folder}, set(response.list))
            self.assertEqual("track.flac", response.list[requested_folder][0][1])

        finally:
            FOLDER_TOKENS_ALLOWED.discard((None, token))


    def test_folder_contents_response_merges_duplicate_requested_folder_records(self):
        token = 123456790
        requested_folder = "Folder"
        FOLDER_TOKENS_ALLOWED.add((None, token))

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(token)
            message += SlskMessage.pack_string(requested_folder)
            message += SlskMessage.pack_uint32(2)

            message += SlskMessage.pack_string(requested_folder)
            message += SlskMessage.pack_uint32(1)
            message += FileListMessage.pack_file_info(("z-last.mp3", 1, None, None))

            message += SlskMessage.pack_string(requested_folder)
            message += SlskMessage.pack_uint32(1)
            message += FileListMessage.pack_file_info(("a-first.mp3", 1, None, None))

            response = FolderContentsResponse()
            response.parse_network_message(memoryview(zlib.compress(message)))

            self.assertEqual(
                ["a-first.mp3", "z-last.mp3"],
                [file_info[1] for file_info in response.list[requested_folder]]
            )

        finally:
            FOLDER_TOKENS_ALLOWED.discard((None, token))


    def test_folder_contents_response_skips_unrequested_file_details(self):
        token = 123456789
        requested_folder = "Folder"
        ignored_folder = "Other"
        FOLDER_TOKENS_ALLOWED.add((None, token))

        original_unpack_string = SlskMessage.unpack_string
        decoded_strings = []

        def tracking_unpack_string(message, pos=0):
            next_pos, value = original_unpack_string(message, pos)
            decoded_strings.append(value)
            return next_pos, value

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(token)
            message += SlskMessage.pack_string(requested_folder)
            message += SlskMessage.pack_uint32(2)

            message += SlskMessage.pack_string(ignored_folder)
            message += SlskMessage.pack_uint32(1)
            message += FileListMessage.pack_file_info(("ignored-large-name.mp3", 1, None, None))

            message += SlskMessage.pack_string(requested_folder)
            message += SlskMessage.pack_uint32(1)
            message += FileListMessage.pack_file_info(("wanted.mp3", 1, None, None))

            SlskMessage.unpack_string = staticmethod(tracking_unpack_string)

            response = FolderContentsResponse()
            response.parse_network_message(memoryview(zlib.compress(message)))

            self.assertEqual("wanted.mp3", response.list[requested_folder][0][1])
            self.assertIn("wanted.mp3", decoded_strings)
            self.assertNotIn("ignored-large-name.mp3", decoded_strings)

        finally:
            SlskMessage.unpack_string = staticmethod(original_unpack_string)
            FOLDER_TOKENS_ALLOWED.discard((None, token))


    def test_shared_file_list_response_rejects_oversized_directory_name(self):
        original_max_path = FileListMessage.MAX_VIRTUAL_PATH_BYTES
        FileListMessage.MAX_VIRTUAL_PATH_BYTES = 4

        try:
            message = (
                SlskMessage.pack_uint32(1)
                + SlskMessage.pack_string("abcde")
                + SlskMessage.pack_uint32(0)
            )

            with self.assertRaises(ValueError):
                SharedFileListResponse()._parse_network_message(memoryview(message))

        finally:
            FileListMessage.MAX_VIRTUAL_PATH_BYTES = original_max_path

    def test_file_search_response_rejects_oversized_result_path(self):
        original_max_path = FileListMessage.MAX_VIRTUAL_PATH_BYTES
        FileListMessage.MAX_VIRTUAL_PATH_BYTES = 4

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_uint8(1)
            message += SlskMessage.pack_string("abcde")
            message += SlskMessage.pack_uint64(1)
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_uint32(0)

            with self.assertRaises(ValueError):
                FileSearchResponse()._parse_remaining_network_message(memoryview(message))

        finally:
            FileListMessage.MAX_VIRTUAL_PATH_BYTES = original_max_path

    def test_folder_contents_response_rejects_oversized_requested_file_name(self):
        original_max_name = FileListMessage.MAX_BASENAME_BYTES
        token = 123456789
        FileListMessage.MAX_BASENAME_BYTES = 4
        FOLDER_TOKENS_ALLOWED.add((None, token))

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(token)
            message += SlskMessage.pack_string("Folder")
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_string("Folder")
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_uint8(1)
            message += SlskMessage.pack_string("abcde")
            message += SlskMessage.pack_uint64(1)
            message += SlskMessage.pack_uint32(0)
            message += SlskMessage.pack_uint32(0)

            with self.assertRaises(ValueError):
                FolderContentsResponse().parse_network_message(memoryview(zlib.compress(message)))

        finally:
            FOLDER_TOKENS_ALLOWED.discard((None, token))
            FileListMessage.MAX_BASENAME_BYTES = original_max_name

    def test_virtual_path_rejects_excessive_component_count(self):
        original_max_components = FileListMessage.MAX_VIRTUAL_PATH_COMPONENTS
        FileListMessage.MAX_VIRTUAL_PATH_COMPONENTS = 2

        try:
            message = SlskMessage.pack_string("a\\b\\c")

            with self.assertRaises(ValueError):
                SlskMessage.unpack_virtual_path(memoryview(message), field_name="test path")

        finally:
            FileListMessage.MAX_VIRTUAL_PATH_COMPONENTS = original_max_components

    def test_shared_file_list_skips_sorting_for_grossly_large_folders(self):
        original_max_sorted_files = FileListMessage.MAX_SORTED_RESULT_FILES
        FileListMessage.MAX_SORTED_RESULT_FILES = 1

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(1)
            message += SlskMessage.pack_string("Folder")
            message += SlskMessage.pack_uint32(2)
            message += FileListMessage.pack_file_info(("z.mp3", 1, None, None))
            message += FileListMessage.pack_file_info(("a.mp3", 1, None, None))

            response = SharedFileListResponse()
            response._parse_network_message(memoryview(message))

            self.assertEqual(["z.mp3", "a.mp3"], [file_info[1] for file_info in response.list["Folder"]])

        finally:
            FileListMessage.MAX_SORTED_RESULT_FILES = original_max_sorted_files

    def test_shared_file_list_skips_sorting_for_grossly_large_folder_list(self):
        original_max_sorted_folders = FileListMessage.MAX_SORTED_RESULT_FOLDERS
        FileListMessage.MAX_SORTED_RESULT_FOLDERS = 1

        try:
            message = bytearray()
            message += SlskMessage.pack_uint32(2)

            for folder in ("z", "a"):
                message += SlskMessage.pack_string(folder)
                message += SlskMessage.pack_uint32(0)

            response = SharedFileListResponse()
            response._parse_network_message(memoryview(message))

            self.assertEqual(["z", "a"], list(response.list))

        finally:
            FileListMessage.MAX_SORTED_RESULT_FOLDERS = original_max_sorted_folders

    def test_folder_contents_response_string_omits_result_list(self):
        response = FolderContentsResponse(directory="Folder", token=1, shares={
            "Folder": [(1, "file.mp3", 1024, None, {})]
        })

        stringified = str(response)

        self.assertIn("FolderContentsResponse", stringified)
        self.assertIn("token", stringified)
        self.assertNotIn("file.mp3", stringified)



class LoginMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = Login(username="test", passwd="s33cr3t", version=157, minorversion=19)

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            bytearray(b"\x04\x00\x00\x00test\x07\x00\x00\x00s33cr3t\x9d\x00\x00\x00 "
                      b"\x00\x00\x00dbc93f24d8f3f109deed23c3e2f8b74c\x13\x00\x00\x00"),
            message)


class ChangePasswordMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = ChangePassword(password="s33cr3t")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x07\x00\x00\x00s33cr3t",
            message)


class SetWaitPortMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = SetWaitPort(port=1337)

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"9\x05\x00\x00",
            message)


class GetPeerAddressMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = GetPeerAddress(user="user1")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00user1",
            message)


class WatchUserMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = WatchUser(user="user2")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00user2",
            message)


class UnwatchUserMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = UnwatchUser(user="user3")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00user3",
            message)


class GetUserStatusMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = GetUserStatus(user="user4")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00user4",
            message)


class FileSearchTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = FileSearch(token=524700074, text="70 gwen auto")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\xaaIF\x1f\x0c\x00\x00\x0070 gwen auto",
            message)


class SetStatusMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = SetStatus(status=1)

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x01\x00\x00\x00",
            message)


class NotifyPrivilegesMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = NotifyPrivileges(token=123456, user="user5")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"@\xe2\x01\x00\x05\x00\x00\x00user5",
            message)


class AckNotifyPrivilegesMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = AckNotifyPrivileges(token=123456)

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"@\xe2\x01\x00",
            message)


class JoinGlobalRoomMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = JoinGlobalRoom()

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"",
            message)


class LeaveGlobalRoomMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = LeaveGlobalRoom()

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"",
            message)


class GlobalRoomMessageMessageTest(TestCase):
    ...


class SayChatroomMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = SayChatroom(room="room1", message="Wassup?")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00room1\x07\x00\x00\x00Wassup?",
            message)


class JoinRoomMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = JoinRoom(room="room2", private=False)
        obj_private = JoinRoom(room="room2", private=True)

        # Act
        message = obj.make_network_message()
        message_private = obj_private.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00room2\x00\x00\x00\x00",
            message)
        self.assertEqual(
            b"\x05\x00\x00\x00room2\x01\x00\x00\x00",
            message_private)


class PrivateRoomUsersMessageTest(TestCase):
    ...


class PrivateRoomOwnedMessageTest(TestCase):
    ...


class PrivateRoomAddUserMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = PrivateRoomAddUser(room="room3", user="admin")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00room3\x05\x00\x00\x00admin",
            message)


class PrivateRoomCancelMembershipMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = PrivateRoomCancelMembership(room="room4")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00room4",
            message)


class PrivateRoomDisownMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = PrivateRoomDisown(room="room5")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00room5",
            message)


class PrivateRoomSomethingMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = PrivateRoomSomething(room="room6")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00room6",
            message)


class PrivateRoomRemoveUserMessageTest(TestCase):

    def test_make_network_message(self):
        # Arrange
        obj = PrivateRoomRemoveUser(room="room7", user="admin")

        # Act
        message = obj.make_network_message()

        # Assert
        self.assertEqual(
            b"\x05\x00\x00\x00room7\x05\x00\x00\x00admin",
            message)

    def test_parse_network_message(self):
        # Arrange
        message = b"\x05\x00\x00\x00room7\x05\x00\x00\x00admin"

        # Act
        obj = PrivateRoomRemoveUser()
        obj.parse_network_message(memoryview(message))

        # Assert
        self.assertEqual("room7", obj.room)
        self.assertEqual("admin", obj.user)
