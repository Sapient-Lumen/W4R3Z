# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from collections import deque
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

from pynicotine.config import config
from pynicotine.chatrooms import ChatRooms
from pynicotine.chatrooms import JoinedRoom
from pynicotine.slskmessages import JoinGlobalRoom
from pynicotine.slskmessages import JoinRoom
from pynicotine.slskmessages import LeaveRoom
from pynicotine.slskmessages import PrivateRoomAddUser
from pynicotine.slskmessages import PrivateRoomCancelMembership
from pynicotine.slskmessages import PrivateRoomDisown
from pynicotine.slskmessages import PrivateRoomToggle
from pynicotine.slskmessages import RoomList
from pynicotine.slskmessages import RoomTickerSet
from pynicotine.slskmessages import SayChatroom
from pynicotine.slskmessages import SlskMessage
from pynicotine.core import core
from pynicotine.slskmessages import UserData
from pynicotine.slskmessages import UserStatus


class DummyNetworkFilter:

    @staticmethod
    def is_user_ignored(_username):
        return False

    @staticmethod
    def is_user_ip_ignored(_username):
        return False


class DummyTickerAddMessage:

    def __init__(self, room, user, msg):
        self.room = room
        self.user = user
        self.msg = msg


class ChatRoomsTest(TestCase):


    def test_show_room_requires_accepted_join_request_before_local_state(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {}
        chatrooms._joined_rooms_limit_logged = False
        old_autojoin = list(config.sections["server"].get("autojoin", []))
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=False))
        fake_events = SimpleNamespace(emit=Mock())

        try:
            config.sections["server"]["autojoin"] = []

            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                self.assertFalse(chatrooms.show_room("room"))

            fake_core.send_message_to_server.assert_called_once()
            self.assertIsInstance(fake_core.send_message_to_server.call_args.args[0], JoinRoom)
            self.assertEqual({}, chatrooms.joined_rooms)
            self.assertEqual([], config.sections["server"]["autojoin"])
            fake_events.emit.assert_not_called()

            fake_core.send_message_to_server.reset_mock(return_value=True)
            fake_core.send_message_to_server.return_value = True

            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                self.assertTrue(chatrooms.show_room("room"))

            self.assertIn("room", chatrooms.joined_rooms)
            self.assertEqual(["room"], config.sections["server"]["autojoin"])
            fake_events.emit.assert_called_once_with("show-room", "room", False, True, False)

        finally:
            config.sections["server"]["autojoin"] = old_autojoin

    def test_remove_room_requires_accepted_leave_request_before_local_state_cleanup(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        chatrooms.joined_rooms["room"].users.update(("user1", "user2"))
        self._init_room_unwatch_state(chatrooms)
        old_autojoin = list(config.sections["server"].get("autojoin", []))
        fake_core = SimpleNamespace(
            send_message_to_server=Mock(return_value=False),
            users=SimpleNamespace(unwatch_user=Mock())
        )
        fake_events = SimpleNamespace(emit=Mock(), schedule=Mock(), cancel_scheduled=Mock())

        try:
            config.sections["server"]["autojoin"] = ["room"]

            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                self.assertFalse(chatrooms.remove_room("room"))

            fake_core.send_message_to_server.assert_called_once()
            self.assertIsInstance(fake_core.send_message_to_server.call_args.args[0], LeaveRoom)
            self.assertIn("room", chatrooms.joined_rooms)
            self.assertEqual(["room"], config.sections["server"]["autojoin"])
            fake_core.users.unwatch_user.assert_not_called()
            fake_events.emit.assert_not_called()

        finally:
            config.sections["server"]["autojoin"] = old_autojoin

    def test_private_room_destructive_actions_require_accepted_server_queue(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.private_rooms = {
            "owned": SimpleNamespace(name="owned", owner="me", members=set(), operators={"me"}),
            "member": SimpleNamespace(name="member", owner="owner", members={"me"}, operators=set()),
        }
        fake_core = SimpleNamespace(
            users=SimpleNamespace(login_username="me"),
            send_message_to_server=Mock(return_value=False)
        )

        with patch("pynicotine.chatrooms.core", fake_core):
            self.assertFalse(chatrooms.request_private_room_disown("owned"))
            self.assertFalse(chatrooms.request_private_room_cancel_membership("member"))

        self.assertIn("owned", chatrooms.private_rooms)
        self.assertIn("member", chatrooms.private_rooms)
        self.assertEqual([PrivateRoomDisown, PrivateRoomCancelMembership], [
            type(call.args[0]) for call in fake_core.send_message_to_server.call_args_list
        ])

        fake_core.send_message_to_server.reset_mock(return_value=True)
        fake_core.send_message_to_server.return_value = True

        with patch("pynicotine.chatrooms.core", fake_core):
            self.assertTrue(chatrooms.request_private_room_disown("owned"))
            self.assertTrue(chatrooms.request_private_room_cancel_membership("member"))

        self.assertNotIn("owned", chatrooms.private_rooms)
        self.assertNotIn("member", chatrooms.private_rooms)


    def test_private_room_member_controls_return_queue_acceptance(self):
        chatrooms = object.__new__(ChatRooms)
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=False))

        with patch("pynicotine.chatrooms.core", fake_core):
            self.assertFalse(chatrooms.add_user_to_private_room("room", "user"))

        fake_core.send_message_to_server.assert_called_once()
        self.assertIsInstance(fake_core.send_message_to_server.call_args.args[0], PrivateRoomAddUser)

        fake_core.send_message_to_server.reset_mock(return_value=True)
        fake_core.send_message_to_server.return_value = True

        with patch("pynicotine.chatrooms.core", fake_core):
            self.assertTrue(chatrooms.add_user_to_private_room("room", "user"))

    def test_server_login_retries_room_control_messages_when_queue_rejects(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {}
        self._init_autojoin_state(chatrooms)
        self._init_room_control_state(chatrooms)
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(side_effect=[False, False, True, True]))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )
        old_private_chatrooms = config.sections["server"].get("private_chatrooms")

        try:
            config.sections["server"]["private_chatrooms"] = True

            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                chatrooms._server_login(SimpleNamespace(success=True))

                self.assertEqual(2, fake_core.send_message_to_server.call_count)
                self.assertEqual(1, len(scheduled_callbacks))
                self.assertEqual([("room-list", None), ("private-room-toggle", True)], [
                    key for key, _message in chatrooms._room_control_queue
                ])

                _delay, callback = scheduled_callbacks.pop(0)
                callback()

            messages = [call.args[0] for call in fake_core.send_message_to_server.call_args_list]
            self.assertIsInstance(messages[0], RoomList)
            self.assertIsInstance(messages[1], PrivateRoomToggle)
            self.assertIsInstance(messages[2], RoomList)
            self.assertIsInstance(messages[3], PrivateRoomToggle)
            self.assertEqual([], list(chatrooms._room_control_queue))
            self.assertEqual(set(), chatrooms._room_control_keys)

        finally:
            config.sections["server"]["private_chatrooms"] = old_private_chatrooms


    def test_lower_unsent_room_control_message_is_requeued(self):
        chatrooms = object.__new__(ChatRooms)
        self._init_room_control_state(chatrooms)
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=True))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._server_message_unsent(RoomList())

            self.assertEqual(1, len(scheduled_callbacks))
            self.assertEqual([("room-list", None)], [key for key, _msg in chatrooms._room_control_queue])

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        fake_core.send_message_to_server.assert_called_once()
        self.assertIsInstance(fake_core.send_message_to_server.call_args.args[0], RoomList)
        self.assertEqual([], list(chatrooms._room_control_queue))

    def test_room_list_delivery_failure_retries_request(self):
        chatrooms = object.__new__(ChatRooms)
        self._init_room_control_state(chatrooms)
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=True))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._server_response_delivery_failed(RoomList, ("room-list",))

            self.assertEqual([("room-list", None)], [key for key, _msg in chatrooms._room_control_queue])
            self.assertEqual(1, len(scheduled_callbacks))
            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        fake_core.send_message_to_server.assert_called_once()
        self.assertIsInstance(fake_core.send_message_to_server.call_args.args[0], RoomList)

    def test_lower_unsent_join_room_is_requeued_only_while_room_is_retained(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        self._init_room_control_state(chatrooms)
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=True))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._server_message_unsent(JoinRoom("room"))

            self.assertEqual([("join-room", "room")], [key for key, _msg in chatrooms._room_control_queue])

            chatrooms.joined_rooms.clear()
            chatrooms._server_message_unsent(JoinRoom("room"))

        self.assertEqual(1, len(chatrooms._room_control_queue))

    def test_lower_unsent_private_room_member_control_is_requeued(self):
        chatrooms = object.__new__(ChatRooms)
        self._init_room_control_state(chatrooms)
        scheduled_callbacks = []
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._server_message_unsent(PrivateRoomAddUser("room", "user"))

        self.assertEqual(1, len(scheduled_callbacks))
        self.assertEqual(
            [("PrivateRoomAddUser", "room", "user")],
            [key for key, _msg in chatrooms._room_control_queue]
        )

    def test_remembered_room_restore_keeps_local_tab_without_network_queue(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {}
        chatrooms._joined_rooms_limit_logged = False
        old_autojoin = list(config.sections["server"].get("autojoin", []))
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=False))
        fake_events = SimpleNamespace(emit=Mock())

        try:
            config.sections["server"]["autojoin"] = []

            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                self.assertTrue(chatrooms.show_room("room", remembered=True, switch_page=False))

            fake_core.send_message_to_server.assert_not_called()
            self.assertIn("room", chatrooms.joined_rooms)
            self.assertEqual(["room"], config.sections["server"]["autojoin"])
            fake_events.emit.assert_called_once_with("show-room", "room", False, False, True)

        finally:
            config.sections["server"]["autojoin"] = old_autojoin

    def test_autojoin_retries_room_when_join_request_is_rejected(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room1": JoinedRoom("room1"), "room2": JoinedRoom("room2")}
        self._init_autojoin_state(chatrooms)
        chatrooms._queue_autojoin_room("room1")
        chatrooms._queue_autojoin_room("room2")
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(side_effect=[False, True, True]))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._process_autojoin_rooms()
            self.assertEqual(["room1", "room2"], list(chatrooms._autojoin_queue))
            self.assertEqual(1, len(scheduled_callbacks))
            self.assertEqual(ChatRooms.AUTOJOIN_RETRY_DELAY, scheduled_callbacks[0][0])

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        self.assertEqual([], list(chatrooms._autojoin_queue))
        self.assertEqual(3, fake_core.send_message_to_server.call_count)

    def test_server_login_room_control_retries_rejected_requests(self):
        chatrooms = object.__new__(ChatRooms)
        self._init_room_control_state(chatrooms)
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(side_effect=[False, False, True, True]))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            self.assertFalse(chatrooms.request_room_list(retry=True))
            self.assertFalse(chatrooms.request_private_room_toggle(True, retry=True))

            self.assertEqual(2, len(chatrooms._room_control_queue))
            self.assertEqual(1, len(scheduled_callbacks))

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        sent_types = [type(call.args[0]) for call in fake_core.send_message_to_server.call_args_list]
        self.assertEqual([RoomList, PrivateRoomToggle, RoomList, PrivateRoomToggle], sent_types)
        self.assertEqual([], list(chatrooms._room_control_queue))
        self.assertEqual(set(), chatrooms._room_control_keys)

    def test_unsent_room_control_message_is_requeued_after_lower_output_rejection(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        self._init_room_control_state(chatrooms)
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(side_effect=[False, True]))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._server_message_unsent(JoinRoom("room"))

            self.assertEqual(1, len(chatrooms._room_control_queue))
            self.assertEqual(1, len(scheduled_callbacks))

            _delay, callback = scheduled_callbacks.pop(0)
            callback()
            self.assertEqual(1, len(chatrooms._room_control_queue))

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        self.assertEqual([], list(chatrooms._room_control_queue))
        self.assertEqual(2, fake_core.send_message_to_server.call_count)
        self.assertTrue(all(isinstance(call.args[0], JoinRoom) for call in fake_core.send_message_to_server.call_args_list))

    def test_unsent_room_control_skip_stale_join_room(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {}
        self._init_room_control_state(chatrooms)
        fake_core = SimpleNamespace(send_message_to_server=Mock())
        fake_events = SimpleNamespace(schedule=Mock(), cancel_scheduled=Mock())

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._server_message_unsent(JoinRoom("stale"))

        self.assertEqual([], list(chatrooms._room_control_queue))
        fake_core.send_message_to_server.assert_not_called()
        fake_events.schedule.assert_not_called()

    def test_private_room_member_control_reports_queue_rejection(self):
        chatrooms = object.__new__(ChatRooms)
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=False))

        with patch("pynicotine.chatrooms.core", fake_core):
            self.assertFalse(chatrooms.add_user_to_private_room("room", "user"))

        fake_core.send_message_to_server.assert_called_once()
        self.assertIsInstance(fake_core.send_message_to_server.call_args.args[0], PrivateRoomAddUser)

        fake_core.send_message_to_server.reset_mock(return_value=True)
        fake_core.send_message_to_server.return_value = True

        with patch("pynicotine.chatrooms.core", fake_core):
            self.assertTrue(chatrooms.add_user_to_private_room("room", "user"))

    def test_quit_forces_local_room_cleanup_even_when_network_queue_is_closed(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.completions = {"x"}
        room_obj = JoinedRoom("room")
        room_obj.users.update(("user1", "user2"))
        chatrooms.joined_rooms = {"room": room_obj}
        self._init_room_unwatch_state(chatrooms)
        self._init_autojoin_state(chatrooms)
        self._init_unsolicited_leave_state(chatrooms)
        fake_core = SimpleNamespace(
            send_message_to_server=Mock(return_value=False),
            users=SimpleNamespace(unwatch_user=Mock())
        )
        fake_events = SimpleNamespace(emit=Mock(), schedule=Mock(), cancel_scheduled=Mock())

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._quit()

        fake_core.send_message_to_server.assert_not_called()
        self.assertEqual({}, chatrooms.joined_rooms)
        self.assertEqual(set(), chatrooms.completions)
        fake_events.emit.assert_called_once_with("remove-room", "room")


    def test_send_message_notifies_only_after_network_queue_accepts(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        self._init_room_message_retry_state(chatrooms)
        scheduled_callbacks = []
        fake_pluginhandler = SimpleNamespace(
            outgoing_public_chat_event=Mock(return_value=("room", "hello")),
            outgoing_public_chat_notification=Mock()
        )
        fake_core = SimpleNamespace(
            pluginhandler=fake_pluginhandler,
            send_message_to_server=Mock(return_value=False)
        )
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )
        old_replacewords = config.sections["words"].get("replacewords")

        try:
            config.sections["words"]["replacewords"] = False

            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                chatrooms.send_message("room", "hello")

            fake_core.send_message_to_server.assert_called_once()
            fake_pluginhandler.outgoing_public_chat_notification.assert_not_called()
            self.assertEqual(1, len(chatrooms._room_message_retry_queue))
            self.assertEqual(1, len(scheduled_callbacks))

            fake_core.send_message_to_server.reset_mock(return_value=True)
            fake_core.send_message_to_server.return_value = True

            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                _delay, callback = scheduled_callbacks.pop(0)
                callback()

        finally:
            if old_replacewords is None:
                config.sections["words"].pop("replacewords", None)
            else:
                config.sections["words"]["replacewords"] = old_replacewords

        fake_pluginhandler.outgoing_public_chat_notification.assert_called_once_with("room", "hello")
        self.assertFalse(chatrooms._room_message_retry_queue)

    def test_outgoing_public_chat_is_capped_before_queue_and_notification(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        long_message = "x" * (SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES + 100)
        sent_messages = []
        fake_pluginhandler = SimpleNamespace(
            outgoing_public_chat_event=Mock(return_value=("room", long_message)),
            outgoing_public_chat_notification=Mock()
        )
        fake_core = SimpleNamespace(
            pluginhandler=fake_pluginhandler,
            send_message_to_server=Mock(side_effect=lambda msg: sent_messages.append(msg) or True)
        )
        old_replacewords = config.sections["words"].get("replacewords")

        try:
            config.sections["words"]["replacewords"] = False

            with patch("pynicotine.chatrooms.core", fake_core):
                chatrooms.send_message("room", "hello")

        finally:
            if old_replacewords is None:
                config.sections["words"].pop("replacewords", None)
            else:
                config.sections["words"]["replacewords"] = old_replacewords

        self.assertEqual(SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES, len(sent_messages[0].message))
        fake_pluginhandler.outgoing_public_chat_notification.assert_called_once_with(
            "room", sent_messages[0].message)


    def test_send_message_truncates_plugin_and_replacement_output(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        long_room = "r" * (SlskMessage.MAX_ROOM_FIELD_BYTES + 100)
        long_message = "x" * (SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES + 100)
        fake_pluginhandler = SimpleNamespace(
            outgoing_public_chat_event=Mock(return_value=(long_room, "token")),
            outgoing_public_chat_notification=Mock()
        )
        fake_core = SimpleNamespace(
            pluginhandler=fake_pluginhandler,
            send_message_to_server=Mock(return_value=True)
        )
        old_replacewords = config.sections["words"].get("replacewords")
        old_replacements = config.sections["words"].get("autoreplaced")

        try:
            config.sections["words"]["replacewords"] = True
            config.sections["words"]["autoreplaced"] = {"token": long_message}

            with patch("pynicotine.chatrooms.core", fake_core):
                chatrooms.send_message("room", "hello")

        finally:
            if old_replacewords is None:
                config.sections["words"].pop("replacewords", None)
            else:
                config.sections["words"]["replacewords"] = old_replacewords

            if old_replacements is None:
                config.sections["words"].pop("autoreplaced", None)
            else:
                config.sections["words"]["autoreplaced"] = old_replacements

        sent_message = fake_core.send_message_to_server.call_args.args[0]
        self.assertLessEqual(len(sent_message.room.encode("utf-8")), SlskMessage.MAX_ROOM_FIELD_BYTES)
        self.assertLessEqual(len(sent_message.message.encode("utf-8")), SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES)


    def test_lower_unsent_room_message_retries_without_duplicate_notification(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        self._init_room_message_retry_state(chatrooms)
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=True))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._server_message_unsent(SayChatroom("room", "hello"))

            self.assertEqual(1, len(scheduled_callbacks))
            self.assertEqual(1, len(chatrooms._room_message_retry_queue))

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        fake_core.send_message_to_server.assert_called_once()
        sent = fake_core.send_message_to_server.call_args.args[0]
        self.assertIsInstance(sent, SayChatroom)
        self.assertEqual("room", sent.room)
        self.assertEqual("hello", sent.message)
        self.assertEqual([], list(chatrooms._room_message_retry_queue))
        self.assertEqual(0, chatrooms._room_message_retry_bytes)

    def test_public_chat_queue_rejection_is_bounded_and_retried(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        self._init_room_message_retry_state(chatrooms)
        scheduled_callbacks = []
        fake_pluginhandler = SimpleNamespace(
            outgoing_public_chat_event=Mock(return_value=("room", "hello")),
            outgoing_public_chat_notification=Mock()
        )
        fake_core = SimpleNamespace(
            pluginhandler=fake_pluginhandler,
            send_message_to_server=Mock(side_effect=[False, True])
        )
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )
        old_replacewords = config.sections["words"].get("replacewords")

        try:
            config.sections["words"]["replacewords"] = False

            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                chatrooms.send_message("room", "hello")
                fake_pluginhandler.outgoing_public_chat_notification.assert_not_called()
                self.assertEqual(1, len(chatrooms._room_message_retry_queue))

                _delay, callback = scheduled_callbacks.pop(0)
                callback()

        finally:
            if old_replacewords is None:
                config.sections["words"].pop("replacewords", None)
            else:
                config.sections["words"]["replacewords"] = old_replacewords

        self.assertEqual(2, fake_core.send_message_to_server.call_count)
        self.assertEqual([], list(chatrooms._room_message_retry_queue))
        fake_pluginhandler.outgoing_public_chat_notification.assert_called_once_with("room", "hello")

    def test_room_message_retry_skips_stale_room(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        self._init_room_message_retry_state(chatrooms)
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock())
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            self.assertTrue(chatrooms._queue_room_message_retry(RoomTickerSet("room", "ticker")))
            del chatrooms.joined_rooms["room"]
            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        fake_core.send_message_to_server.assert_not_called()
        self.assertEqual([], list(chatrooms._room_message_retry_queue))

    def test_ticker_add_keeps_room_ticker_cache_bounded(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        room_obj = chatrooms.joined_rooms["room"]
        room_obj.tickers = {"a": "1", "b": "2"}

        old_network_filter = core.network_filter
        old_max_tickers = ChatRooms.MAX_ROOM_TICKERS

        try:
            core.network_filter = DummyNetworkFilter()
            ChatRooms.MAX_ROOM_TICKERS = 2
            chatrooms._ticker_add(DummyTickerAddMessage("room", "c", "3"))
        finally:
            ChatRooms.MAX_ROOM_TICKERS = old_max_tickers
            core.network_filter = old_network_filter

        self.assertEqual({"b": "2", "c": "3"}, room_obj.tickers)

    def test_ticker_add_updates_existing_user_without_evicting(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}
        room_obj = chatrooms.joined_rooms["room"]
        room_obj.tickers = {"a": "1", "b": "2"}

        old_network_filter = core.network_filter
        old_max_tickers = ChatRooms.MAX_ROOM_TICKERS

        try:
            core.network_filter = DummyNetworkFilter()
            ChatRooms.MAX_ROOM_TICKERS = 2
            chatrooms._ticker_add(DummyTickerAddMessage("room", "b", "updated"))
        finally:
            ChatRooms.MAX_ROOM_TICKERS = old_max_tickers
            core.network_filter = old_network_filter

        self.assertEqual({"a": "1", "b": "updated"}, room_obj.tickers)

    def test_completion_updates_are_capped_and_prioritized(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.completions = set()
        chatrooms.server_rooms = ["room1", "room2", "room3", "room4"]
        chatrooms.joined_rooms = {}
        chatrooms.private_rooms = {}
        chatrooms._joined_room_users_limit_logged = False

        old_login = config.sections["server"].get("login")
        old_word_settings = {
            key: config.sections["words"].get(key)
            for key in ("buddies", "commands", "roomnames")
        }
        old_limit = ChatRooms.MAX_COMPLETIONS
        ChatRooms.MAX_COMPLETIONS = 3

        fake_core = SimpleNamespace(
            buddies=SimpleNamespace(users=["buddy1", "buddy2"]),
            pluginhandler=SimpleNamespace(get_command_list=Mock(return_value=["/cmd1"]))
        )
        fake_events = SimpleNamespace(emit=Mock())

        try:
            config.sections["server"]["login"] = "localuser"
            config.sections["words"].update({"buddies": True, "commands": True, "roomnames": True})

            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                chatrooms.update_completions()

            self.assertEqual({"localuser", "room1", "room2"}, chatrooms.completions)
            fake_core.pluginhandler.get_command_list.assert_not_called()
            fake_events.emit.assert_called_once_with("room-completions", chatrooms.completions.copy())

        finally:
            ChatRooms.MAX_COMPLETIONS = old_limit

            if old_login is None:
                config.sections["server"].pop("login", None)
            else:
                config.sections["server"]["login"] = old_login

            for key, value in old_word_settings.items():
                if value is None:
                    config.sections["words"].pop(key, None)
                else:
                    config.sections["words"][key] = value

    @staticmethod
    def _make_fake_core_for_room_users():
        watched = {}

        def watch_user(username, **_kwargs):
            watched.setdefault(
                username,
                SimpleNamespace(upload_speed=None, files=None, folders=None)
            )
            return True

        return SimpleNamespace(
            users=SimpleNamespace(
                watched=watched,
                statuses={},
                addresses={},
                countries={},
                watch_user=Mock(side_effect=watch_user),
                request_ip_address=Mock()
            ),
            pluginhandler=SimpleNamespace(
                join_chatroom_notification=Mock(),
                user_join_chatroom_notification=Mock()
            ),
            send_message_to_server=Mock()
        )

    def test_join_room_caps_user_fanout_and_mutates_message(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.server_rooms = set()
        chatrooms.private_rooms = {}
        chatrooms.joined_rooms = {"busyroom": JoinedRoom("busyroom")}
        chatrooms._joined_room_users_limit_logged = False

        old_limit = ChatRooms.MAX_JOINED_ROOM_USERS
        ChatRooms.MAX_JOINED_ROOM_USERS = 2
        fake_core = self._make_fake_core_for_room_users()

        msg = SimpleNamespace(
            room="busyroom",
            private=False,
            owner=None,
            operators=(),
            users=[
                UserData("user1", status=UserStatus.ONLINE),
                UserData("user2", status=UserStatus.AWAY),
                UserData("user3", status=UserStatus.ONLINE),
            ]
        )

        try:
            with patch("pynicotine.chatrooms.core", fake_core):
                chatrooms._join_room(msg)

            self.assertEqual({"user1", "user2"}, chatrooms.joined_rooms["busyroom"].users)
            self.assertEqual(["user1", "user2"], [user.username for user in msg.users])
            self.assertIn("user1", fake_core.users.watched)
            self.assertIn("user2", fake_core.users.watched)
            self.assertNotIn("user3", fake_core.users.watched)
            self.assertEqual(2, fake_core.users.request_ip_address.call_count)

        finally:
            ChatRooms.MAX_JOINED_ROOM_USERS = old_limit


    def test_room_user_status_is_normalized_before_cache_update(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms._joined_room_users_limit_logged = False
        chatrooms._room_user_status_limit_logged = False
        room_obj = JoinedRoom("busyroom")
        fake_core = self._make_fake_core_for_room_users()
        user_data = UserData("user1", status=99)

        with patch("pynicotine.chatrooms.core", fake_core):
            self.assertTrue(chatrooms._update_room_user(room_obj, user_data))

        self.assertEqual(UserStatus.OFFLINE, user_data.status)
        self.assertEqual(UserStatus.OFFLINE, fake_core.users.statuses["user1"])
        self.assertTrue(chatrooms._room_user_status_limit_logged)

    def test_user_joined_room_over_cap_is_suppressed(self):
        chatrooms = object.__new__(ChatRooms)
        room_obj = JoinedRoom("busyroom")
        room_obj.users.add("user1")
        chatrooms.joined_rooms = {"busyroom": room_obj}
        chatrooms._joined_room_users_limit_logged = False

        old_limit = ChatRooms.MAX_JOINED_ROOM_USERS
        ChatRooms.MAX_JOINED_ROOM_USERS = 1
        fake_core = self._make_fake_core_for_room_users()
        msg = SimpleNamespace(room="busyroom", userdata=UserData("user2", status=UserStatus.ONLINE))

        try:
            with patch("pynicotine.chatrooms.core", fake_core):
                chatrooms._user_joined_room(msg)

            self.assertIsNone(msg.room)
            self.assertEqual({"user1"}, room_obj.users)
            self.assertNotIn("user2", fake_core.users.watched)
            fake_core.pluginhandler.user_join_chatroom_notification.assert_not_called()

        finally:
            ChatRooms.MAX_JOINED_ROOM_USERS = old_limit


    def test_room_user_is_suppressed_when_global_watch_cap_is_reached(self):
        chatrooms = object.__new__(ChatRooms)
        room_obj = JoinedRoom("busyroom")
        chatrooms.joined_rooms = {"busyroom": room_obj}
        chatrooms._joined_room_users_limit_logged = False

        fake_core = self._make_fake_core_for_room_users()
        fake_core.users.watch_user = Mock(return_value=False)
        msg = SimpleNamespace(room="busyroom", userdata=UserData("user1", status=UserStatus.ONLINE))

        with patch("pynicotine.chatrooms.core", fake_core):
            chatrooms._user_joined_room(msg)

        self.assertIsNone(msg.room)
        self.assertEqual(set(), room_obj.users)
        fake_core.users.request_ip_address.assert_not_called()
        fake_core.pluginhandler.user_join_chatroom_notification.assert_not_called()

    def test_global_room_message_is_ignored_when_public_room_is_not_joined(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {}

        fake_core = SimpleNamespace(
            users=SimpleNamespace(login_username="me"),
            network_filter=DummyNetworkFilter(),
            pluginhandler=SimpleNamespace(public_room_message_notification=Mock())
        )
        msg = SimpleNamespace(room="some-room", user="peer", message="hello")

        with patch("pynicotine.chatrooms.core", fake_core):
            chatrooms._global_room_message(msg)

        self.assertIsNone(msg.room)
        fake_core.pluginhandler.public_room_message_notification.assert_not_called()

    def test_ignored_room_message_is_not_logged_before_filtering(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}

        fake_core = SimpleNamespace(
            network_filter=SimpleNamespace(
                is_user_ignored=Mock(return_value=True),
                is_user_ip_ignored=Mock(return_value=False)
            ),
            pluginhandler=SimpleNamespace(incoming_public_chat_event=Mock()),
            users=SimpleNamespace(login_username="me")
        )
        fake_log = SimpleNamespace(add_chat=Mock())
        msg = SimpleNamespace(room="room", user="ignoreduser", message="spam")

        with (patch("pynicotine.chatrooms.core", fake_core),
              patch("pynicotine.chatrooms.log", fake_log)):
            chatrooms._say_chat_room(msg)

        self.assertIsNone(msg.room)
        fake_log.add_chat.assert_not_called()
        fake_core.pluginhandler.incoming_public_chat_event.assert_not_called()


    def test_plugin_filtered_room_message_is_not_logged(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room": JoinedRoom("room")}

        fake_core = SimpleNamespace(
            network_filter=SimpleNamespace(
                is_user_ignored=Mock(return_value=False),
                is_user_ip_ignored=Mock(return_value=False)
            ),
            pluginhandler=SimpleNamespace(incoming_public_chat_event=Mock(return_value=None)),
            users=SimpleNamespace(login_username="me")
        )
        fake_log = SimpleNamespace(add_chat=Mock())
        msg = SimpleNamespace(room="room", user="remoteuser", message="spam")

        with (patch("pynicotine.chatrooms.core", fake_core),
              patch("pynicotine.chatrooms.log", fake_log)):
            chatrooms._say_chat_room(msg)

        self.assertIsNone(msg.room)
        fake_log.add_chat.assert_not_called()
        fake_core.pluginhandler.incoming_public_chat_event.assert_called_once()

    def test_server_room_cache_is_bounded(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.server_rooms = {"room1"}
        chatrooms.private_rooms = {}
        chatrooms._server_rooms_limit_logged = False

        old_limit = ChatRooms.MAX_SERVER_ROOMS
        ChatRooms.MAX_SERVER_ROOMS = 1

        try:
            self.assertTrue(chatrooms._add_server_room("room1"))
            self.assertFalse(chatrooms._add_server_room("room2"))
            self.assertEqual({"room1"}, chatrooms.server_rooms)
            self.assertTrue(chatrooms._server_rooms_limit_logged)

        finally:
            ChatRooms.MAX_SERVER_ROOMS = old_limit

    def test_private_room_member_and_room_caches_are_bounded(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.server_rooms = set()
        chatrooms.private_rooms = {}
        chatrooms._private_rooms_limit_logged = False
        chatrooms._private_room_members_limit_logged = False
        chatrooms._private_room_operators_limit_logged = False

        old_room_limit = ChatRooms.MAX_PRIVATE_ROOMS
        old_member_limit = ChatRooms.MAX_PRIVATE_ROOM_MEMBERS
        old_operator_limit = ChatRooms.MAX_PRIVATE_ROOM_OPERATORS
        ChatRooms.MAX_PRIVATE_ROOMS = 1
        ChatRooms.MAX_PRIVATE_ROOM_MEMBERS = 2
        ChatRooms.MAX_PRIVATE_ROOM_OPERATORS = 1

        try:
            room = chatrooms._update_private_room(
                "private1", members=("a", "b", "c"), operators=("op1", "op2"))

            self.assertIsNotNone(room)
            self.assertEqual({"a", "b"}, room.members)
            self.assertEqual({"op1"}, room.operators)
            self.assertTrue(chatrooms._private_room_members_limit_logged)
            self.assertTrue(chatrooms._private_room_operators_limit_logged)

            self.assertIsNone(chatrooms._update_private_room("private2"))
            self.assertEqual({"private1"}, set(chatrooms.private_rooms))
            self.assertTrue(chatrooms._private_rooms_limit_logged)

        finally:
            ChatRooms.MAX_PRIVATE_ROOMS = old_room_limit
            ChatRooms.MAX_PRIVATE_ROOM_MEMBERS = old_member_limit
            ChatRooms.MAX_PRIVATE_ROOM_OPERATORS = old_operator_limit

    def test_room_list_replaces_server_room_cache_and_caps_entries(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.completions = set()
        chatrooms.server_rooms = {"stale"}
        chatrooms.joined_rooms = {}
        chatrooms.private_rooms = {}
        chatrooms._joined_room_users_limit_logged = False
        chatrooms._server_rooms_limit_logged = False
        chatrooms._private_rooms_limit_logged = False
        chatrooms._private_room_members_limit_logged = False
        chatrooms._private_room_operators_limit_logged = False

        old_roomnames = config.sections["words"].get("roomnames")
        old_limit = ChatRooms.MAX_SERVER_ROOMS

        try:
            config.sections["words"]["roomnames"] = False
            ChatRooms.MAX_SERVER_ROOMS = 1
            chatrooms._room_list(SimpleNamespace(
                rooms=[("fresh", 1), ("dropped", 1)],
                ownedprivaterooms=[],
                otherprivaterooms=[]
            ))

        finally:
            ChatRooms.MAX_SERVER_ROOMS = old_limit
            config.sections["words"]["roomnames"] = old_roomnames

        self.assertEqual({"fresh"}, chatrooms.server_rooms)

    def test_private_room_user_snapshot_replaces_stale_entries_and_caps(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.private_rooms = {"room": SimpleNamespace(name="room", owner=None, members={"stale"}, operators=set())}
        chatrooms._private_room_members_limit_logged = False
        chatrooms._private_room_operators_limit_logged = False
        chatrooms._private_rooms_limit_logged = False

        old_limit = ChatRooms.MAX_PRIVATE_ROOM_MEMBERS

        try:
            ChatRooms.MAX_PRIVATE_ROOM_MEMBERS = 2
            msg = SimpleNamespace(room="room", users=["a", "b", "c"])
            chatrooms._private_room_users(msg)

        finally:
            ChatRooms.MAX_PRIVATE_ROOM_MEMBERS = old_limit

        self.assertEqual({"a", "b"}, chatrooms.private_rooms["room"].members)
        self.assertEqual({"a", "b"}, set(msg.users))
        self.assertNotIn("stale", chatrooms.private_rooms["room"].members)

    def test_private_room_operator_snapshot_replaces_stale_entries_and_caps(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.private_rooms = {"room": SimpleNamespace(name="room", owner=None, members=set(), operators={"stale"})}
        chatrooms._private_room_members_limit_logged = False
        chatrooms._private_room_operators_limit_logged = False
        chatrooms._private_rooms_limit_logged = False

        old_limit = ChatRooms.MAX_PRIVATE_ROOM_OPERATORS

        try:
            ChatRooms.MAX_PRIVATE_ROOM_OPERATORS = 1
            msg = SimpleNamespace(room="room", operators=["op1", "op2"])
            chatrooms._private_room_operators(msg)

        finally:
            ChatRooms.MAX_PRIVATE_ROOM_OPERATORS = old_limit

        self.assertEqual({"op1"}, chatrooms.private_rooms["room"].operators)
        self.assertEqual(["op1"], msg.operators)
        self.assertNotIn("stale", chatrooms.private_rooms["room"].operators)

    @staticmethod
    def _init_room_unwatch_state(chatrooms):
        from collections import deque

        chatrooms._room_unwatch_queue = deque()
        chatrooms._room_unwatch_keys = set()
        chatrooms._room_unwatch_timer_id = None
        chatrooms._room_unwatch_limit_logged = False

    def test_remove_room_batches_room_unwatches(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.completions = set()
        chatrooms.server_rooms = set()
        chatrooms.private_rooms = {}
        room_obj = JoinedRoom("room")
        room_obj.users.update(("user1", "user2", "user3", "user4"))
        chatrooms.joined_rooms = {"room": room_obj}
        self._init_room_unwatch_state(chatrooms)

        old_limit = ChatRooms.MAX_ROOM_UNWATCHES_PER_TICK
        ChatRooms.MAX_ROOM_UNWATCHES_PER_TICK = 2
        scheduled_callbacks = []
        fake_core = SimpleNamespace(
            users=SimpleNamespace(unwatch_user=Mock()),
            send_message_to_server=Mock()
        )
        fake_events = SimpleNamespace(
            emit=Mock(),
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        try:
            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                chatrooms.remove_room("room", is_permanent=False)
                self.assertEqual(2, fake_core.users.unwatch_user.call_count)
                self.assertEqual(1, len(scheduled_callbacks))

                _delay, callback = scheduled_callbacks.pop(0)
                callback()

            self.assertEqual(4, fake_core.users.unwatch_user.call_count)
            self.assertEqual([], list(chatrooms._room_unwatch_queue))
            self.assertNotIn("room", chatrooms.joined_rooms)
            fake_events.emit.assert_called_once_with("remove-room", "room")

        finally:
            ChatRooms.MAX_ROOM_UNWATCHES_PER_TICK = old_limit

    def test_deferred_room_unwatch_skips_rejoined_users(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {}
        self._init_room_unwatch_state(chatrooms)

        old_limit = ChatRooms.MAX_ROOM_UNWATCHES_PER_TICK
        ChatRooms.MAX_ROOM_UNWATCHES_PER_TICK = 1
        scheduled_callbacks = []
        fake_core = SimpleNamespace(users=SimpleNamespace(unwatch_user=Mock()))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        try:
            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                chatrooms._queue_room_unwatches("room", ("user1", "user2"))
                self.assertEqual(["user1"], [call.args[0] for call in fake_core.users.unwatch_user.call_args_list])

                rejoined_room = JoinedRoom("room")
                rejoined_room.users.add("user2")
                chatrooms.joined_rooms["room"] = rejoined_room
                _delay, callback = scheduled_callbacks.pop(0)
                callback()

            self.assertEqual(["user1"], [call.args[0] for call in fake_core.users.unwatch_user.call_args_list])
            self.assertEqual([], list(chatrooms._room_unwatch_queue))

        finally:
            ChatRooms.MAX_ROOM_UNWATCHES_PER_TICK = old_limit

    @staticmethod
    def _init_autojoin_state(chatrooms):
        chatrooms._autojoin_queue = deque()
        chatrooms._autojoin_keys = set()
        chatrooms._autojoin_timer_id = None
        chatrooms._autojoin_limit_logged = False

    @staticmethod
    def _init_room_control_state(chatrooms):
        chatrooms._room_control_queue = deque()
        chatrooms._room_control_keys = set()
        chatrooms._room_control_timer_id = None
        chatrooms._room_control_limit_logged = False

    @staticmethod
    def _init_unsolicited_leave_state(chatrooms):
        chatrooms._unsolicited_leave_queue = deque()
        chatrooms._unsolicited_leave_keys = set()
        chatrooms._unsolicited_leave_timer_id = None
        chatrooms._unsolicited_leave_limit_logged = False

    @staticmethod
    def _init_room_message_retry_state(chatrooms):
        chatrooms._room_message_retry_queue = deque()
        chatrooms._room_message_retry_timer_id = None
        chatrooms._room_message_retry_bytes = 0
        chatrooms._room_message_retry_limit_logged = False

    def test_server_login_batches_autojoin_rooms(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {
            ChatRooms.GLOBAL_ROOM_NAME: JoinedRoom(ChatRooms.GLOBAL_ROOM_NAME),
            "room1": JoinedRoom("room1"),
            "room2": JoinedRoom("room2", is_private=True),
        }
        self._init_autojoin_state(chatrooms)

        old_limit = ChatRooms.MAX_AUTOJOIN_ROOMS_PER_TICK
        ChatRooms.MAX_AUTOJOIN_ROOMS_PER_TICK = 2
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock())
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        try:
            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                for room in chatrooms.joined_rooms:
                    chatrooms._queue_autojoin_room(room)

                chatrooms._process_autojoin_rooms()

                self.assertEqual(2, fake_core.send_message_to_server.call_count)
                self.assertEqual(1, len(scheduled_callbacks))

                _delay, callback = scheduled_callbacks.pop(0)
                callback()

            messages = [call.args[0] for call in fake_core.send_message_to_server.call_args_list]
            self.assertIsInstance(messages[0], JoinGlobalRoom)
            self.assertIsInstance(messages[1], JoinRoom)
            self.assertIsInstance(messages[2], JoinRoom)
            self.assertEqual("room2", messages[2].room)
            self.assertTrue(messages[2].private)
            self.assertEqual([], list(chatrooms._autojoin_queue))
            self.assertEqual(set(), chatrooms._autojoin_keys)

        finally:
            ChatRooms.MAX_AUTOJOIN_ROOMS_PER_TICK = old_limit

    def test_deferred_autojoin_skips_removed_room(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {"room1": JoinedRoom("room1"), "room2": JoinedRoom("room2")}
        self._init_autojoin_state(chatrooms)

        old_limit = ChatRooms.MAX_AUTOJOIN_ROOMS_PER_TICK
        ChatRooms.MAX_AUTOJOIN_ROOMS_PER_TICK = 1
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock())
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        try:
            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                chatrooms._queue_autojoin_room("room1")
                chatrooms._queue_autojoin_room("room2")
                chatrooms._process_autojoin_rooms()

                del chatrooms.joined_rooms["room2"]
                _delay, callback = scheduled_callbacks.pop(0)
                callback()

            self.assertEqual(1, fake_core.send_message_to_server.call_count)
            self.assertEqual("room1", fake_core.send_message_to_server.call_args_list[0].args[0].room)
            self.assertEqual([], list(chatrooms._autojoin_queue))

        finally:
            ChatRooms.MAX_AUTOJOIN_ROOMS_PER_TICK = old_limit

    def test_unsolicited_join_room_leaves_are_batched_and_deduplicated(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {}
        chatrooms.server_rooms = set()
        chatrooms.private_rooms = {}
        self._init_unsolicited_leave_state(chatrooms)

        old_limit = ChatRooms.MAX_UNSOLICITED_LEAVE_ROOMS_PER_TICK
        ChatRooms.MAX_UNSOLICITED_LEAVE_ROOMS_PER_TICK = 2
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=True))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        try:
            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                for room in ("room1", "room2", "room1", "room3"):
                    chatrooms._join_room(SimpleNamespace(
                        room=room, private=False, owner=None, operators=(), users=()
                    ))

                self.assertEqual(0, fake_core.send_message_to_server.call_count)
                self.assertEqual(["room1", "room2", "room3"], list(chatrooms._unsolicited_leave_queue))
                self.assertEqual(1, len(scheduled_callbacks))

                _delay, callback = scheduled_callbacks.pop(0)
                self.assertEqual(0, _delay)
                callback()

                self.assertEqual(2, fake_core.send_message_to_server.call_count)
                self.assertEqual(["room1", "room2"], [
                    call.args[0].room for call in fake_core.send_message_to_server.call_args_list
                ])
                self.assertEqual(["room3"], list(chatrooms._unsolicited_leave_queue))
                self.assertEqual(1, len(scheduled_callbacks))

                _delay, callback = scheduled_callbacks.pop(0)
                callback()

            self.assertEqual(["room1", "room2", "room3"], [
                call.args[0].room for call in fake_core.send_message_to_server.call_args_list
            ])
            self.assertEqual([], list(chatrooms._unsolicited_leave_queue))
            self.assertEqual(set(), chatrooms._unsolicited_leave_keys)

        finally:
            ChatRooms.MAX_UNSOLICITED_LEAVE_ROOMS_PER_TICK = old_limit

    def test_unsolicited_join_room_leave_retries_after_queue_rejection(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {}
        chatrooms.server_rooms = set()
        chatrooms.private_rooms = {}
        self._init_unsolicited_leave_state(chatrooms)

        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(side_effect=[False, True]))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
            chatrooms._join_room(SimpleNamespace(room="room", private=False, owner=None, operators=(), users=()))

            self.assertEqual(["room"], list(chatrooms._unsolicited_leave_queue))
            self.assertEqual(1, len(scheduled_callbacks))
            self.assertEqual(0, scheduled_callbacks[0][0])

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

            self.assertEqual(["room"], list(chatrooms._unsolicited_leave_queue))
            self.assertEqual(1, len(scheduled_callbacks))
            self.assertEqual(ChatRooms.UNSOLICITED_LEAVE_RETRY_DELAY, scheduled_callbacks[0][0])

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        self.assertEqual(2, fake_core.send_message_to_server.call_count)
        self.assertEqual([], list(chatrooms._unsolicited_leave_queue))

    def test_deferred_unsolicited_leave_skips_room_joined_before_retry(self):
        chatrooms = object.__new__(ChatRooms)
        chatrooms.joined_rooms = {}
        self._init_unsolicited_leave_state(chatrooms)

        old_limit = ChatRooms.MAX_UNSOLICITED_LEAVE_ROOMS_PER_TICK
        ChatRooms.MAX_UNSOLICITED_LEAVE_ROOMS_PER_TICK = 1
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock())
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        try:
            with patch("pynicotine.chatrooms.core", fake_core), patch("pynicotine.chatrooms.events", fake_events):
                chatrooms._queue_unsolicited_leave_room("room1")
                chatrooms._queue_unsolicited_leave_room("room2")
                chatrooms._process_unsolicited_leave_rooms()

                chatrooms.joined_rooms["room2"] = JoinedRoom("room2")
                _delay, callback = scheduled_callbacks.pop(0)
                callback()

            self.assertEqual(1, fake_core.send_message_to_server.call_count)
            self.assertEqual("room1", fake_core.send_message_to_server.call_args.args[0].room)
            self.assertEqual([], list(chatrooms._unsolicited_leave_queue))

        finally:
            ChatRooms.MAX_UNSOLICITED_LEAVE_ROOMS_PER_TICK = old_limit

