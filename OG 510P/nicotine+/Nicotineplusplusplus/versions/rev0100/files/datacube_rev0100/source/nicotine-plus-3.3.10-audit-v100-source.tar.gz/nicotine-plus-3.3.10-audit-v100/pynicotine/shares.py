# COPYRIGHT (C) 2020-2025 Nicotine+ Contributors
# COPYRIGHT (C) 2016-2017 Michael Labouebe <gfarmerfr@free.fr>
# COPYRIGHT (C) 2016 Mutnick <muhing@yahoo.com>
# COPYRIGHT (C) 2009-2011 quinox <quinox@users.sf.net>
# COPYRIGHT (C) 2009 daelstorm <daelstorm@gmail.com>
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import gc
import mmap
import os
import stat
import sys
import time

from array import array
from collections import defaultdict
from collections import deque
from itertools import chain
from io import BytesIO
from os import SEEK_END
from os import SEEK_SET
from pickle import HIGHEST_PROTOCOL
from pickle import dumps
from pickle import Unpickler
from pickle import UnpicklingError
from queue import Empty
from struct import Struct
from threading import Thread

from pynicotine import rename_process
from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.external.tinytag import TinyTag
from pynicotine.logfacility import log
from pynicotine.slskmessages import FileListMessage
from pynicotine.slskmessages import FolderContentsResponse
from pynicotine.slskmessages import GetUserStats
from pynicotine.slskmessages import SharedFileListResponse
from pynicotine.slskmessages import SharedFoldersFiles
from pynicotine.utils import TRANSLATE_PUNCTUATION
from pynicotine.utils import UINT32_LIMIT
from pynicotine.utils import encode_path


class FileTypes:
    ARCHIVE = {
        "7z", "br", "bz2", "gz", "iso", "lz", "lzma", "rar", "tar", "tbz", "tbz2", "tgz", "xz", "zip", "zst"
    }
    AUDIO = {
        "aac", "ac3", "afc", "aifc", "aif", "aiff", "ape", "au", "bwav", "bwf", "dff", "dsd", "dsf", "dts", "flac",
        "gbs", "gym", "it", "m4a", "m4b", "mid", "midi", "mka", "mod", "mp1", "mp2", "mp3", "mp+", "mpc", "nsf", "nsfe",
        "ofr", "ofs", "oga", "ogg", "opus", "psf", "psf1", "psf2", "s3m", "sid", "spc", "spx", "ssf", "tak", "tta",
        "wav", "vgm", "vgz", "wma", "vqf", "wv", "xm"
    }
    EXECUTABLE = {
        "apk", "appimage", "bat", "deb", "dmg", "flatpak", "exe", "jar", "msi", "pkg", "rpm", "sh"
    }
    IMAGE = {
        "apng", "avif", "bmp", "gif", "heic", "heif", "ico", "jfif", "jp2", "jpg", "jpe", "jpeg", "jxl", "png", "psd",
        "raw", "svg", "svgz", "tif", "tiff", "webp"
    }
    DOCUMENT = {
        "doc", "docx", "epub", "mobi", "odp", "ods", "odt", "opf", "oxps", "pdf", "ppt", "pptx", "rtf", "xls", "xlsx",
        "xps"
    }
    TEXT = {
        "cue", "csv", "htm", "html", "m3u", "m3u8", "md5", "log", "lrc", "md", "mks", "nfo", "ps", "rst", "sfv",
        "sha1", "sha256", "srt", "txt"
    }
    VIDEO = {
        "3gp", "amv", "asf", "avi", "f4v", "flv", "m2ts", "m2v", "m4p", "m4v", "mov", "mp4", "mpe", "mpeg", "mpg",
        "mkv", "mts", "ogv", "ts", "vob", "webm", "wmv"
    }


class PermissionLevel:
    PUBLIC = "public"
    BUDDY = "buddy"
    TRUSTED = "trusted"
    BANNED = "banned"


class RestrictedUnpickler(Unpickler):
    """Don't allow code execution from pickles."""

    SAFE_GLOBALS = {
        ("array", "_array_reconstructor"),
        ("array", "array")
    }

    def find_class(self, module, name):
        if (module, name) in self.SAFE_GLOBALS:
            import array as array_module
            return getattr(array_module, name)

        # Forbid all other globals
        raise UnpicklingError(f"global '{module}.{name}' is forbidden")


class DatabaseError(Exception):
    pass


class Database:
    """Custom key-value database format for Nicotine+ shares."""

    __slots__ = ("_value_offsets", "_file_handle", "_file_offset", "_overwrite",
                 "_final_path", "_temp_path", "_is_closed")

    FILE_SIGNATURE = b"DBN+"
    VERSION = 3
    LENGTH_DATA_SIZE = 8
    PACK_LENGTHS = Struct("!II").pack
    UNPACK_LENGTHS = Struct("!II").unpack_from
    PICKLE_PROTOCOL = min(HIGHEST_PROTOCOL, 5)  # Use version 5 when available
    MAX_DATABASE_RECORDS = 2_000_000
    MAX_DATABASE_KEY_BYTES = 32768
    MAX_DATABASE_VALUE_BYTES = 512 * 1024 * 1024
    MAX_DATABASE_FILE_BYTES = 4 * 1024 * 1024 * 1024

    def __init__(self, file_path, overwrite=True):

        folder_path = os.path.dirname(file_path)
        mode = "ab+" if overwrite else "rb"

        if folder_path and not os.path.exists(folder_path):
            os.makedirs(folder_path)

        self._overwrite = overwrite
        self._final_path = file_path
        self._temp_path = None

        if overwrite:
            # Build replacement databases in a side file, then atomically swap
            # them into place on close(). A killed scanner process should not
            # destroy the last complete share database.
            self._temp_path = self._get_temp_path(file_path)
            self._remove_path(self._temp_path)

            if os.path.isdir(file_path):
                self._remove_path(file_path)

            file_path = self._temp_path

        self._value_offsets = self._load_value_offsets(file_path, mode)
        self._is_closed = False

        if overwrite:
            self._file_handle = open(file_path, mode)  # pylint: disable=consider-using-with
        else:
            with open(file_path, mode) as file_handle:
                self._file_handle = mmap.mmap(file_handle.fileno(), length=0, access=mmap.ACCESS_READ)

        self._file_offset = self._file_handle.seek(0, SEEK_END)

    @staticmethod
    def _get_temp_path(file_path):
        suffix = b".tmp" if isinstance(file_path, bytes) else ".tmp"
        return file_path + suffix

    @staticmethod
    def _remove_path(file_path):
        if os.path.isdir(file_path):
            import shutil
            shutil.rmtree(file_path)
        elif os.path.exists(file_path):
            os.remove(file_path)

    @staticmethod
    def _sync_parent_directory(file_path):
        """Best-effort fsync of the parent directory after atomic replace."""

        folder_path = os.path.dirname(file_path) or (b"." if isinstance(file_path, bytes) else ".")

        try:
            directory_fd = os.open(folder_path, os.O_RDONLY)

        except (AttributeError, OSError):
            return

        try:
            os.fsync(directory_fd)

        except OSError:
            pass

        finally:
            os.close(directory_fd)

    def _parse_content(self, content, total_size):

        value_offsets = {}
        file_signature_length = len(self.FILE_SIGNATURE)

        if content[:file_signature_length] != self.FILE_SIGNATURE:
            raise DatabaseError("Not a database file")

        if content[file_signature_length:file_signature_length + 1][0] != self.VERSION:
            raise DatabaseError("Incompatible version")

        current_offset = (file_signature_length + 1)
        record_count = 0

        while current_offset < total_size:
            if record_count >= self.MAX_DATABASE_RECORDS:
                raise DatabaseError("Database record count exceeds maximum")

            record_count += 1
            key_offset = (current_offset + self.LENGTH_DATA_SIZE)

            if key_offset > total_size:
                raise DatabaseError("Truncated database record header")

            key_length, value_length = self.UNPACK_LENGTHS(content[current_offset:key_offset])

            if key_length <= 0:
                raise DatabaseError("Database record key is empty")

            if key_length > self.MAX_DATABASE_KEY_BYTES:
                raise DatabaseError("Database record key exceeds maximum size")

            if value_length > self.MAX_DATABASE_VALUE_BYTES:
                raise DatabaseError("Database record value exceeds maximum size")

            value_offset = (key_offset + key_length)

            if value_offset > total_size:
                raise DatabaseError("Truncated database record key")

            record_end = (value_offset + value_length)

            if record_end > total_size:
                raise DatabaseError("Truncated database record value")

            key = content[key_offset:value_offset].tobytes().decode("utf-8")

            value_offsets[key] = (value_offset, value_length)
            current_offset = record_end

        return value_offsets

    def _load_value_offsets(self, file_path, mode):

        value_offsets = {}

        with open(file_path, mode) as file_handle:  # pylint: disable=unspecified-encoding
            file_size = os.fstat(file_handle.fileno()).st_size

            if file_size > self.MAX_DATABASE_FILE_BYTES:
                raise DatabaseError("Database file exceeds maximum size")

            if not file_size:
                file_handle.write(self.FILE_SIGNATURE)
                file_handle.write(bytes([self.VERSION]))
                return value_offsets

            file_handle.seek(0)

            with mmap.mmap(file_handle.fileno(), length=0, access=mmap.ACCESS_READ) as content:
                content_view = memoryview(content)

                try:
                    value_offsets = self._parse_content(content_view, file_size)
                finally:
                    content_view.release()

        return value_offsets

    def __contains__(self, key):
        return key in self._value_offsets

    def __iter__(self):
        yield from self._value_offsets

    def __len__(self):
        return len(self._value_offsets)

    def __getitem__(self, key):

        value_offset, value_length = self._value_offsets[key]

        self._file_handle.seek(value_offset, SEEK_SET)
        value_data = self._file_handle.read(value_length)

        if len(value_data) != value_length:
            raise DatabaseError("Truncated database record value")

        return RestrictedUnpickler(BytesIO(value_data)).load()

    def __setitem__(self, key, value):

        if not isinstance(key, str):
            raise DatabaseError("Database record key is not a string")

        encoded_key = key.encode("utf-8")
        key_length = len(encoded_key)

        if key_length <= 0:
            raise DatabaseError("Database record key is empty")

        if key_length > self.MAX_DATABASE_KEY_BYTES:
            raise DatabaseError("Database record key exceeds maximum size")

        if key not in self._value_offsets and len(self._value_offsets) >= self.MAX_DATABASE_RECORDS:
            raise DatabaseError("Database record count exceeds maximum")

        if isinstance(value, (bytes, bytearray, memoryview)) and len(value) > self.MAX_DATABASE_VALUE_BYTES:
            raise DatabaseError("Database record value exceeds maximum size")

        pickled_value = dumps(value, protocol=self.PICKLE_PROTOCOL)
        value_length = len(pickled_value)

        if value_length > self.MAX_DATABASE_VALUE_BYTES:
            raise DatabaseError("Database record value exceeds maximum size")

        length_data = self.PACK_LENGTHS(key_length, value_length)
        item_data = (length_data + encoded_key + pickled_value)

        if self._file_offset + len(item_data) > self.MAX_DATABASE_FILE_BYTES:
            raise DatabaseError("Database file exceeds maximum size")

        self._file_handle.write(item_data)

        self._value_offsets[key] = (self._file_offset + self.LENGTH_DATA_SIZE + key_length, value_length)
        self._file_offset += len(item_data)

    def get(self, key, default=None):

        if key in self._value_offsets:
            return self[key]

        return default

    def update(self, obj):
        for key, value in obj.items():
            self[key] = value

    def abort(self):
        """Close and discard an unfinished replacement database."""

        if self._is_closed:
            return

        self._is_closed = True

        try:
            self._file_handle.close()
        finally:
            if self._overwrite and self._temp_path is not None:
                self._remove_path(self._temp_path)

    def close(self):

        if self._is_closed:
            return

        self._is_closed = True

        if not self._overwrite:
            self._file_handle.close()
            return

        try:
            self._file_handle.flush()
            os.fsync(self._file_handle.fileno())
        except Exception:
            self._file_handle.close()

            if self._temp_path is not None:
                self._remove_path(self._temp_path)

            raise

        self._file_handle.close()
        os.replace(self._temp_path, self._final_path)
        self._sync_parent_directory(self._final_path)


def _new_word_index_postings():
    """Return a compact unsigned-int posting list for share search words."""

    return array("I")


class ScannerState:
    INITIALIZED = "initialized"
    RESCANNING = "rescanning"
    FAILURE = "failure"


class ScannerLogMessage:
    __slots__ = ("msg", "msg_args")

    def __init__(self, msg, msg_args=None):
        self.msg = msg
        self.msg_args = msg_args


class Scanner:
    """Separate process responsible for building shares.

    It handles scanning of folders and files, as well as building
    databases and writing them to disk.
    """

    __slots__ = ("queue", "share_groups", "share_dbs", "share_db_paths", "init",
                 "rescan", "rebuild", "reveal_buddy_shares", "reveal_trusted_shares",
                 "files", "streams", "mtimes", "word_index", "processed_share_names",
                 "processed_share_paths", "processed_share_path_keys",
                 "current_file_index", "current_folder_count", "current_file_path_bytes",
                 "current_folder_stream_bytes",
                 "scanner_log_count", "scanner_log_suppressed",
                 "_scanned_file_limit_logged", "_scanned_folder_limit_logged",
                 "_scanner_file_path_bytes_limit_logged", "_scanner_stream_bytes_limit_logged",
                 "word_index_limit_logged", "word_index_term_limit_logged",
                 "search_word_limit_logged")

    HIDDEN_FOLDER_NAMES = {"@eaDir", "#recycle", "#snapshot"}
    MAX_SCANNER_LOG_MESSAGES = 1000
    MAX_SCANNED_FILES = Database.MAX_DATABASE_RECORDS
    MAX_SCANNED_FOLDERS = SharedFileListResponse.MAX_RESULT_FOLDERS
    MAX_FOLDER_STREAM_BYTES = 256 * 1024 * 1024
    MAX_SCANNER_FOLDER_STREAM_BYTES = 512 * 1024 * 1024
    MAX_SCANNER_FILE_PATH_BYTES = 1024 * 1024 * 1024
    MAX_WORD_INDEX_POSTINGS = 1_000_000
    MAX_WORD_INDEX_TERMS = 2_000_000
    MAX_SEARCH_WORDS_PER_PATH = 1024

    def __init__(self, queue, share_groups, share_db_paths, init=False, rescan=True,
                 rebuild=False, reveal_buddy_shares=False, reveal_trusted_shares=False):

        self.queue = queue
        self.share_groups = share_groups
        self.share_dbs = {}
        self.share_db_paths = share_db_paths
        self.init = init
        self.rescan = rescan
        self.rebuild = rebuild
        self.reveal_buddy_shares = reveal_buddy_shares
        self.reveal_trusted_shares = reveal_trusted_shares
        self.files = {}
        self.streams = {}
        self.mtimes = {}
        self.word_index = defaultdict(_new_word_index_postings)
        self.processed_share_names = set()
        self.processed_share_paths = set()
        self.processed_share_path_keys = set()
        self.current_file_index = 0
        self.current_folder_count = 0
        self.current_file_path_bytes = 0
        self.current_folder_stream_bytes = 0
        self.scanner_log_count = 0
        self.scanner_log_suppressed = 0
        self._scanned_file_limit_logged = False
        self._scanned_folder_limit_logged = False
        self._scanner_file_path_bytes_limit_logged = False
        self._scanner_stream_bytes_limit_logged = False
        self.word_index_limit_logged = False
        self.word_index_term_limit_logged = False
        self.search_word_limit_logged = False

    def _put_scanner_log(self, msg, msg_args=None, critical=False):
        """Send a scanner log message without allowing unbounded error storms."""

        if critical or self.scanner_log_count < self.MAX_SCANNER_LOG_MESSAGES:
            self.queue.put(ScannerLogMessage(msg, msg_args))
            if not critical:
                self.scanner_log_count += 1
            return

        self.scanner_log_suppressed += 1

    def _flush_scanner_log_summary(self):
        if self.scanner_log_suppressed <= 0:
            return

        self.queue.put(
            ScannerLogMessage(
                _("Suppressed %(num)s additional share scanner messages during this scan."),
                {"num": self.scanner_log_suppressed}
            )
        )
        self.scanner_log_suppressed = 0

    def run(self):

        try:
            rename_process(b"nicotine-scan")

            if self.init:
                try:
                    self.create_compressed_shares()
                    self.create_file_path_index()

                except Exception:
                    # Failed to load shares or version is invalid, rebuild
                    self.rescan = self.rebuild = True

                self.queue.put(ScannerState.INITIALIZED)

            if self.rescan:
                self.queue.put(ScannerState.RESCANNING)
                self._put_scanner_log(
                    _("Rebuilding shares…") if self.rebuild else _("Rescanning shares…"),
                    critical=True
                )

                # Clear previous word index to prevent inconsistent state if the scanner fails
                self.set_shares(word_index={})

                # Scan shares
                for permission_level in (
                    PermissionLevel.PUBLIC,
                    PermissionLevel.BUDDY,
                    PermissionLevel.TRUSTED
                ):
                    self.rescan_dirs(permission_level)

                self.set_shares(word_index=self.word_index)
                self.word_index.clear()

                self.create_compressed_shares()
                self.create_file_path_index()

                self._flush_scanner_log_summary()
                self._put_scanner_log(
                    _("Rescan complete: %(num)s folders found"),
                    {"num": self.current_folder_count},
                    critical=True
                )

        except Exception:
            from traceback import format_exc

            self._put_scanner_log(
                _("Serious error occurred while rescanning shares. If this problem persists, "
                  "delete %(dir)s/*.dbn and try again. If that doesn't help, please file a bug "
                  "report with this stack trace included: %(trace)s"), {
                    "dir": os.path.dirname(next(iter(self.share_db_paths.values()))),
                    "trace": "\n" + format_exc()
                },
                critical=True
            )
            self.queue.put(ScannerState.FAILURE)

        finally:
            self._flush_scanner_log_summary()
            Shares.close_shares(self.share_dbs)

    def create_compressed_shares_message(self, permission_level):
        """Create a message that will later contain a compressed list of our
        shares."""

        public_streams = self.share_dbs["public_streams"]
        buddy_streams = self.share_dbs["buddy_streams"]
        trusted_streams = self.share_dbs["trusted_streams"]

        if permission_level == PermissionLevel.PUBLIC and not self.reveal_buddy_shares:
            buddy_streams = None

        if permission_level in {PermissionLevel.PUBLIC, PermissionLevel.BUDDY} and not self.reveal_trusted_shares:
            trusted_streams = None

        compressed_shares = SharedFileListResponse(
            public_shares=public_streams, buddy_shares=buddy_streams, trusted_shares=trusted_streams,
            permission_level=permission_level
        )
        compressed_shares.make_network_message()
        compressed_shares.public_shares = compressed_shares.buddy_shares = compressed_shares.trusted_shares = None

        self.queue.put(compressed_shares)

    def create_compressed_shares(self):

        Shares.load_shares(
            self.share_dbs, self.share_db_paths, destinations={"public_streams", "buddy_streams", "trusted_streams"}
        )

        for permission_level in (PermissionLevel.PUBLIC, PermissionLevel.BUDDY, PermissionLevel.TRUSTED):
            self.create_compressed_shares_message(permission_level)

        Shares.close_shares(self.share_dbs)

    def create_file_path_index(self):
        """Validate file-index databases without pickling paths across processes.

        The parent process loads the share databases after the scanner exits and
        can rebuild file_path_index from those mmap-backed DB keys directly.
        Sending a tuple containing every shared path through the scanner IPC
        channel duplicates large libraries in the scanner, in the pickle buffer
        and in the parent process.
        """

        Shares.load_shares(
            self.share_dbs, self.share_db_paths, destinations={"public_files", "buddy_files", "trusted_files"}
        )
        Shares.close_shares(self.share_dbs)

    def real2virtual(self, real_path):

        real_path = real_path.replace("/", "\\")

        for shared_folder_paths in self.share_groups:
            for virtual_name, folder_path, *_unused in shared_folder_paths:
                folder_path = folder_path.replace("/", "\\")

                if real_path == folder_path:
                    return virtual_name

                # Use rstrip to remove trailing separator from root folders
                folder_path = folder_path.rstrip("\\") + "\\"

                if real_path.startswith(folder_path):
                    real_path_no_prefix = real_path[len(folder_path):]
                    virtual_path = f"{virtual_name}\\{real_path_no_prefix}"
                    return virtual_path

        raise ValueError(f"Cannot find virtual path for {real_path}")


    @staticmethod
    def _normalize_share_path_key(folder_path):
        return os.path.normcase(os.path.normpath(folder_path))

    def _is_processed_share_path_or_child(self, folder_path):
        """Return True if a configured share root is already covered.

        The scanner historically called real2virtual() for every root, so a
        configured subfolder of an earlier share would resolve to the earlier
        virtual tree and be skipped when the folder stream already existed.
        Passing the root virtual name directly avoids repeated root matching,
        but we still need to preserve that no-reshare behavior without an
        O(num_roots) scan for every root. Walk the candidate's parents through
        a normalized processed-root set instead.
        """

        path_key = self._normalize_share_path_key(folder_path)

        while True:
            if path_key in self.processed_share_path_keys:
                return True

            parent_key = os.path.dirname(path_key)

            if parent_key == path_key:
                return False

            path_key = parent_key

    def set_shares(self, permission_level=None, files=None, streams=None, mtimes=None, word_index=None):

        for source, destination in (
            (files, "files"),
            (streams, "streams"),
            (mtimes, "mtimes"),
            (word_index, "words")
        ):
            if source is None:
                continue

            if destination != "words":
                destination = f"{permission_level}_{destination}"

            share_db = None
            success = False

            try:
                share_db_path = self.share_db_paths[destination]
                share_db = Shares.create_db_file(share_db_path)
                share_db.update(source)
                success = True

            finally:
                if share_db is not None:
                    if success:
                        share_db.close()
                    else:
                        share_db.abort()

    def rescan_dirs(self, permission_level):

        shared_public_folders, shared_buddy_folders, shared_trusted_folders = self.share_groups

        if permission_level == PermissionLevel.TRUSTED:
            shared_folder_paths = sorted(shared_trusted_folders)

        elif permission_level == PermissionLevel.BUDDY:
            shared_folder_paths = sorted(shared_buddy_folders)

        else:
            shared_folder_paths = sorted(shared_public_folders)

        try:
            Shares.load_shares(
                self.share_dbs, self.share_db_paths,
                destinations={f"{permission_level}_files", f"{permission_level}_mtimes"})

        except Exception:
            # No previous share databases, rebuild
            self.rebuild = True

        old_files = self.share_dbs.get(f"{permission_level}_files")
        old_mtimes = self.share_dbs.get(f"{permission_level}_mtimes")

        for virtual_name, folder_path, *_unused in shared_folder_paths:
            if virtual_name in self.processed_share_names:
                # No duplicate names
                continue

            if self._is_processed_share_path_or_child(folder_path):
                # No duplicate share roots, and no resharing subfolders of an
                # already processed share tree.
                continue

            self.scan_shared_folder(
                folder_path, old_mtimes, old_files, root_virtual_folder_path=virtual_name)

            self.processed_share_names.add(virtual_name)
            self.processed_share_paths.add(folder_path)
            self.processed_share_path_keys.add(self._normalize_share_path_key(folder_path))

        # Save data to databases
        Shares.close_shares(self.share_dbs)
        self.set_shares(permission_level, files=self.files, streams=self.streams, mtimes=self.mtimes)

        for dictionary in (self.files, self.streams, self.mtimes):
            dictionary.clear()

        self.current_file_path_bytes = 0
        self.current_folder_stream_bytes = 0
        self._scanner_file_path_bytes_limit_logged = False
        self._scanner_stream_bytes_limit_logged = False

        gc.collect()

    @classmethod
    def is_hidden(cls, folder, filename=None, entry=None):
        """Stop sharing any dot/hidden folders/files."""

        if filename is None:
            last_folder = os.path.basename(folder)

            if last_folder.startswith(".") or last_folder in cls.HIDDEN_FOLDER_NAMES:
                return True

        # If we're asked to check a file, we exclude it if it starts with a dot
        if filename is not None and filename.startswith("."):
            return True

        # Check if file is marked as hidden on Windows
        if sys.platform == "win32":
            if len(folder) == 3 and folder[1] == ":" and folder[2] == os.sep:
                # Root folders are marked as hidden, but we allow scanning them
                return False

            if entry is None:
                if filename is not None:
                    entry_stat = os.stat(encode_path(os.path.join(folder, filename)))
                else:
                    entry_stat = os.stat(encode_path(folder))
            else:
                entry_stat = entry.stat()

            return entry_stat.st_file_attributes & stat.FILE_ATTRIBUTE_HIDDEN

        return False

    @staticmethod
    def _extract_search_words(text):
        return frozenset(text.lower().translate(TRANSLATE_PUNCTUATION).split())

    def _limit_search_words(self, words):
        if len(words) <= self.MAX_SEARCH_WORDS_PER_PATH:
            return frozenset(words)

        if not self.search_word_limit_logged:
            self._put_scanner_log(
                _("Search-word path limit of %(limit)s reached; additional words from very deep "
                  "or verbose share paths will be omitted."),
                {"limit": self.MAX_SEARCH_WORDS_PER_PATH}
            )
            self.search_word_limit_logged = True

        # Make the retained prefix deterministic enough for tests and reproducible
        # scans. This branch is only taken for grossly large path word sets.
        return frozenset(sorted(words)[:self.MAX_SEARCH_WORDS_PER_PATH])

    def _merge_search_words(self, existing_words, text, prefer_new=True):
        new_words = self._extract_search_words(text)

        if not prefer_new:
            return self._limit_search_words(existing_words | new_words)

        # Preserve words from the immediate folder/file name where possible, even
        # when a very deep/verbose ancestor path already hit the search-word cap.
        # Otherwise files beneath a capped path could become unsearchable by their
        # own basename terms.
        if len(new_words) >= self.MAX_SEARCH_WORDS_PER_PATH:
            return self._limit_search_words(new_words)

        remaining_existing_words = max(0, self.MAX_SEARCH_WORDS_PER_PATH - len(new_words))
        retained_existing_words = sorted(existing_words - new_words)[:remaining_existing_words]
        return self._limit_search_words(set(retained_existing_words) | new_words)

    @staticmethod
    def _estimate_scanner_file_path_bytes(path, virtual_file_path, basename):
        return (
            len(str(path).encode("utf-8", "replace"))
            + len(str(virtual_file_path).encode("utf-8", "replace"))
            + len(str(basename).encode("utf-8", "replace"))
            + 128
        )

    def _reserve_scanner_file_path_bytes(self, path, virtual_file_path, basename):
        retained_size = self._estimate_scanner_file_path_bytes(path, virtual_file_path, basename)

        if self.current_file_path_bytes + retained_size <= self.MAX_SCANNER_FILE_PATH_BYTES:
            self.current_file_path_bytes += retained_size
            return True

        if not self._scanner_file_path_bytes_limit_logged:
            self._put_scanner_log(
                _("Skipping additional shared files because retained scanner file-path data "
                  "exceeds the safety limit."),
                critical=True
            )
            self._scanner_file_path_bytes_limit_logged = True

        return False

    def _store_folder_stream(self, virtual_folder_path, folder_stream):
        stream_size = len(folder_stream)

        if self.current_folder_stream_bytes + stream_size <= self.MAX_SCANNER_FOLDER_STREAM_BYTES:
            self.streams[virtual_folder_path] = bytes(folder_stream)
            self.current_folder_stream_bytes += stream_size
            return True

        if not self._scanner_stream_bytes_limit_logged:
            self._put_scanner_log(
                _("Skipping additional shared-folder browse streams because retained scanner "
                  "folder-stream data exceeds the safety limit."),
                critical=True
            )
            self._scanner_stream_bytes_limit_logged = True

        return False

    def _append_to_word_index(self, word, file_index):
        """Append a file index for a search word while bounding common-word lists.

        Shared libraries with many files often produce extremely common tokens
        such as an artist name, release type or extension. Search responses are
        capped later, so retaining every posting for these words can spend a lot
        of memory for little practical result. Keep a gross cap per word and
        continue indexing rarer tokens for the same file.
        """

        if word not in self.word_index and len(self.word_index) >= self.MAX_WORD_INDEX_TERMS:
            if not self.word_index_term_limit_logged:
                self._put_scanner_log(
                    _("Search word index term limit of %(limit)s reached; additional unique "
                      "words will be omitted."),
                    {"limit": self.MAX_WORD_INDEX_TERMS}
                )
                self.word_index_term_limit_logged = True

            return

        postings = self.word_index[word]

        if len(postings) >= self.MAX_WORD_INDEX_POSTINGS:
            if not self.word_index_limit_logged:
                self._put_scanner_log(
                    _("Search word index posting limit of %(limit)s reached; "
                      "additional matches for very common words will be omitted."),
                    {"limit": self.MAX_WORD_INDEX_POSTINGS}
                )
                self.word_index_limit_logged = True

            return

        postings.append(file_index)

    def scan_shared_folder(self, shared_folder_path, old_mtimes, old_files, root_virtual_folder_path=None):
        """Scan a shared folder for all subfolders, files and their metadata."""

        if root_virtual_folder_path is None:
            root_virtual_folder_path = self.real2virtual(shared_folder_path)
        root_search_words = self._limit_search_words(self._extract_search_words(root_virtual_folder_path))
        folder_paths = deque([(shared_folder_path, root_virtual_folder_path, root_search_words)])

        while folder_paths:
            folder_path, virtual_folder_path, folder_search_words = folder_paths.pop()

            if virtual_folder_path in self.streams:
                # Sharing a folder twice, no go
                continue

            file_count = 0
            folder_stream = bytearray(FileListMessage.pack_uint32(0))
            folder_stream_limit_logged = False

            try:
                with os.scandir(encode_path(folder_path, prefix=False)) as entries:
                    for entry in entries:
                        basename = entry.name.decode("utf-8", "replace")
                        path = os.path.join(folder_path, basename)

                        if entry.is_dir(follow_symlinks=False):
                            if self.is_hidden(path, entry=entry):
                                continue

                            if self.current_folder_count >= self.MAX_SCANNED_FOLDERS:
                                if not self._scanned_folder_limit_logged:
                                    self._put_scanner_log(
                                        _("Skipping additional shared folders because the share-scan "
                                          "folder count exceeds the safety limit."),
                                        critical=True
                                    )
                                    self._scanned_folder_limit_logged = True
                                continue

                            self.current_folder_count += 1
                            child_virtual_folder_path = f"{virtual_folder_path}\\{basename}"
                            child_search_words = self._merge_search_words(folder_search_words, basename)
                            folder_paths.append((path, child_virtual_folder_path, child_search_words))

                            if not self.current_folder_count % 100:
                                self.queue.put(self.current_folder_count)
                            continue

                        if entry.is_symlink():
                            # Avoid following symbolic links inside shares. Directory links can
                            # recurse into cycles and file links can expose files outside the
                            # configured share tree.
                            continue

                        try:
                            if self.is_hidden(folder_path, basename, entry):
                                continue

                            file_stat = entry.stat()

                            if not stat.S_ISREG(file_stat.st_mode):
                                # Avoid sharing special files such as FIFOs, sockets and devices.
                                # Opening them for upload can block or behave unlike a finite file.
                                continue

                            if self.current_file_index >= self.MAX_SCANNED_FILES:
                                if not self._scanned_file_limit_logged:
                                    self._put_scanner_log(
                                        _("Skipping additional shared files because the share-scan "
                                          "file count exceeds the safety limit."),
                                        critical=True
                                    )
                                    self._scanned_file_limit_logged = True
                                continue

                            file_index = self.current_file_index
                            file_mtime = file_stat.st_mtime
                            virtual_file_path = f"{virtual_folder_path}\\{basename}"

                            if not self._reserve_scanner_file_path_bytes(path, virtual_file_path, basename):
                                continue

                            self.mtimes[path] = file_mtime

                            if not self.rebuild and file_mtime == old_mtimes.get(path) and path in old_files:
                                full_path_file_data = old_files[path]
                                full_path_file_data[0] = virtual_file_path  # Virtual name might have changed
                            else:
                                full_path_file_data = self.get_file_info(virtual_file_path, path, file_stat)

                            basename_file_data = full_path_file_data[:]
                            basename_file_data[0] = basename
                            packed_file_info = FileListMessage.pack_file_info(basename_file_data)

                            if len(folder_stream) + len(packed_file_info) > self.MAX_FOLDER_STREAM_BYTES:
                                if not folder_stream_limit_logged:
                                    self._put_scanner_log(
                                        _("Skipping additional files in %(path)s because the shared-folder "
                                          "browse stream exceeds the safety limit."),
                                        {"path": folder_path}
                                    )
                                    folder_stream_limit_logged = True
                                continue

                            folder_stream += packed_file_info
                            file_count += 1

                            for k in self._merge_search_words(folder_search_words, basename):
                                self._append_to_word_index(k, file_index)

                            self.files[path] = full_path_file_data
                            self.current_file_index += 1

                        except OSError as error:
                            self._put_scanner_log(
                                _("Error while scanning file %(path)s: %(error)s"),
                                {"path": path, "error": error}
                            )

            except OSError as error:
                self._put_scanner_log(
                    _("Error while scanning folder %(path)s: %(error)s"),
                    {"path": folder_path, "error": error}
                )

            folder_stream[:4] = FileListMessage.pack_uint32(file_count)
            self._store_folder_stream(virtual_folder_path, folder_stream)

    def get_audio_tag(self, encoded_file_path, size):

        parser_class = TinyTag._get_parser_for_filename(encoded_file_path)  # pylint: disable=protected-access

        if parser_class is None:
            return None

        with open(encoded_file_path, "rb") as file_handle:
            tag = parser_class(file_handle, size)
            tag.load(tags=False, duration=True, image=False)

        return tag

    @staticmethod
    def _normalize_uint32_metadata(value, allow_zero=False):
        if value is None:
            return None

        try:
            value = int(value)

        except (TypeError, ValueError, OverflowError):
            return None

        if allow_zero:
            return value if 0 <= value < UINT32_LIMIT else None

        return value if 0 < value < UINT32_LIMIT else None

    @staticmethod
    def _normalize_vbr_metadata(value):
        try:
            return 1 if int(value) else 0

        except (TypeError, ValueError, OverflowError):
            return 0

    def get_file_info(self, virtual_file_path, file_path, file_stat):
        """Get file metadata."""

        tag = None
        quality = None
        duration = None
        encoded_file_path = encode_path(file_path)
        size = file_stat.st_size

        # We skip metadata scanning of files without meaningful content
        if size > 128:
            try:
                tag = self.get_audio_tag(encoded_file_path, size)

            except Exception as error:
                self._put_scanner_log(
                    _("Error while scanning metadata for file %(path)s: %(error)s"),
                    {"path": file_path, "error": error}
                )

        if tag is not None:
            bitrate = tag.bitrate
            samplerate = tag.samplerate
            bitdepth = tag.bitdepth
            duration = tag.duration

            if bitrate is not None:
                try:
                    bitrate = bitrate + 0.5  # Round the value with minimal performance loss
                except TypeError:
                    bitrate = None

            bitrate = self._normalize_uint32_metadata(bitrate)
            samplerate = self._normalize_uint32_metadata(samplerate)
            bitdepth = self._normalize_uint32_metadata(bitdepth)
            duration = self._normalize_uint32_metadata(duration, allow_zero=True)
            quality = (bitrate, self._normalize_vbr_metadata(tag.is_vbr), samplerate, bitdepth)

        return [virtual_file_path, size, quality, duration]

    @staticmethod
    def get_folder_stream(file_list):
        """Pack all files and metadata in folder."""

        stream = bytearray()
        stream += FileListMessage.pack_uint32(len(file_list))

        for fileinfo in file_list:
            stream += FileListMessage.pack_file_info(fileinfo)

        return bytes(stream)


class Shares:
    __slots__ = ("share_dbs", "requested_share_times", "requested_share_address_times",
                 "requested_folder_times", "requested_folder_address_times", "initialized", "rescanning",
                 "compressed_shares", "share_db_paths", "file_path_index", "_scanner_process",
                 "_virtual_share_root_map", "_virtual_share_root_map_key",
                 "_pending_shared_counts", "_shared_counts_retry_timer_id")

    SHARED_FILE_LIST_REQUEST_INTERVAL = 0.4
    SHARED_FILE_LIST_REQUEST_TTL = 60.0
    MAX_SHARED_FILE_LIST_REQUEST_TIMES = 4096
    MAX_SHARED_FILE_LIST_REQUESTS_PER_ADDRESS = 64
    MAX_REQUEST_ADDRESS_TIMES = 4096
    FOLDER_CONTENTS_REQUEST_INTERVAL = 0.4
    FOLDER_CONTENTS_REQUEST_TTL = 60.0
    MAX_FOLDER_CONTENTS_REQUEST_TIMES = 4096
    MAX_FOLDER_CONTENTS_REQUEST_TIMES_PER_USER = 1024
    MAX_FOLDER_CONTENTS_REQUESTS_PER_ADDRESS = 256
    SHARED_COUNTS_RETRY_DELAY = 1.0

    def __init__(self):

        self.share_dbs = {}
        self.requested_share_times = {}
        self.requested_share_address_times = {}
        self.requested_folder_times = {}
        self.requested_folder_address_times = {}
        self.initialized = False
        self.rescanning = False
        self.compressed_shares = {
            PermissionLevel.PUBLIC: SharedFileListResponse(permission_level=PermissionLevel.PUBLIC),
            PermissionLevel.BUDDY: SharedFileListResponse(permission_level=PermissionLevel.BUDDY),
            PermissionLevel.TRUSTED: SharedFileListResponse(permission_level=PermissionLevel.TRUSTED),
            PermissionLevel.BANNED: SharedFileListResponse(permission_level=PermissionLevel.BANNED)
        }
        self.share_db_paths = {
            "words": os.path.join(config.data_folder_path, "words.dbn"),
            "public_files": os.path.join(config.data_folder_path, "publicfiles.dbn"),
            "public_mtimes": os.path.join(config.data_folder_path, "publicmtimes.dbn"),
            "public_streams": os.path.join(config.data_folder_path, "publicstreams.dbn"),
            "buddy_files": os.path.join(config.data_folder_path, "buddyfiles.dbn"),
            "buddy_mtimes": os.path.join(config.data_folder_path, "buddymtimes.dbn"),
            "buddy_streams": os.path.join(config.data_folder_path, "buddystreams.dbn"),
            "trusted_files": os.path.join(config.data_folder_path, "trustedfiles.dbn"),
            "trusted_mtimes": os.path.join(config.data_folder_path, "trustedmtimes.dbn"),
            "trusted_streams": os.path.join(config.data_folder_path, "trustedstreams.dbn")
        }
        self.file_path_index = ()

        self._scanner_process = None
        self._virtual_share_root_map = {}
        self._virtual_share_root_map_key = None
        self._pending_shared_counts = None
        self._shared_counts_retry_timer_id = None

        for event_name, callback in (
            ("folder-contents-request", self._folder_contents_request),
            ("quit", self._quit),
            ("server-disconnect", self._server_disconnect),
            ("server-login", self._server_login),
            ("server-message-unsent", self._server_message_unsent),
            ("peer-response-unsent", self._peer_response_unsent),
            ("shared-file-list-request", self._shared_file_list_request),
            ("shares-ready", self._shares_ready),
            ("start", self._start)
        ):
            events.connect(event_name, callback)

    def _start(self):

        rescan_startup = (config.sections["transfers"]["rescanonstartup"]
                          and not config.need_config())

        self.convert_shares()
        self.rescan_shares(init=True, rescan=rescan_startup)

    def _quit(self):

        self._cancel_shared_counts_retry()
        self.close_shares(self.share_dbs)
        self.initialized = False

        if self._scanner_process is not None:
            self._scanner_process.terminate()

    def _peer_response_unsent(self, msg_class, _username, rollback_info):
        """Undo peer request limiter state when a queued response dies below peer output."""

        if not rollback_info:
            return

        rollback_kind, request_marker = rollback_info

        if msg_class is SharedFileListResponse and rollback_kind == "shared-file-list-request":
            self._rollback_shared_file_list_request(request_marker)
            return

        if msg_class is FolderContentsResponse and rollback_kind == "folder-contents-request":
            self._rollback_folder_contents_request(request_marker)

    def _server_login(self, msg):
        if msg.success:
            self.send_num_shared_folders_files()

    def _server_message_unsent(self, msg):
        if msg.__class__ is not SharedFoldersFiles:
            return

        # Public queue acceptance is only the first local boundary. The server
        # socket can still disappear, packing can fail, or a bounded output
        # buffer can reject the message later. Keep the latest shared-count
        # report alive so our server-visible share statistics eventually catch
        # up after transient lower-output backpressure.
        self._pending_shared_counts = (msg.folders, msg.files)
        self._schedule_shared_counts_retry()

    def _server_disconnect(self, _msg):
        self.requested_share_times.clear()
        self.requested_share_address_times.clear()
        self.requested_folder_times.clear()
        self.requested_folder_address_times.clear()
        self._cancel_shared_counts_retry()
        self._pending_shared_counts = None

    # Shares-related Actions #

    @classmethod
    def create_db_file(cls, db_path):
        # New share databases are written to ``<name>.tmp`` and atomically
        # replace the old file on close. Only remove a path up front if it is a
        # directory from older/corrupt state and therefore cannot be replaced by
        # os.replace().
        db_path_encoded = encode_path(db_path)

        if os.path.isdir(db_path_encoded):
            cls.remove_db_file(db_path)

        return Database(db_path_encoded)

    @staticmethod
    def remove_db_file(db_path):

        db_path_encoded = encode_path(db_path)

        if os.path.isfile(db_path_encoded):
            os.remove(db_path_encoded)

        elif os.path.isdir(db_path_encoded):
            import shutil
            shutil.rmtree(db_path_encoded)

    @staticmethod
    def _iter_configured_share_roots():
        transfers_config = config.sections.get("transfers", {})

        for shares in (
            transfers_config.get("shared", ()),
            transfers_config.get("buddyshared", ()),
            transfers_config.get("trustedshared", ())
        ):
            for virtual_name, folder_path, *_unused in shares:
                yield str(virtual_name), str(folder_path)

    def _get_virtual_share_root_map(self):
        """Return a cached virtual-root -> real-root map for upload lookups.

        Incoming QueueUpload/TransferRequest paths identify the configured share
        root in the first virtual-path component. Scanning every configured share
        root for every peer request is avoidable and becomes visible with many
        configured roots or request bursts. Rebuild lazily when the mutable config
        lists change.
        """

        share_roots = tuple(self._iter_configured_share_roots())

        if share_roots == self._virtual_share_root_map_key:
            return self._virtual_share_root_map

        root_map = {}

        for virtual_name, folder_path in share_roots:
            root_map.setdefault(virtual_name, folder_path)

        self._virtual_share_root_map_key = share_roots
        self._virtual_share_root_map = root_map
        return root_map

    def virtual2real(self, virtual_path):

        virtual_root, separator, virtual_tail = virtual_path.partition("\\")
        folder_path = self._get_virtual_share_root_map().get(virtual_root)

        if folder_path is None:
            return "__INVALID_SHARE__" + virtual_path

        if not separator:
            return folder_path

        return os.path.join(folder_path, *virtual_tail.split("\\"))

    def convert_shares(self):

        def _convert_share(shared_folder):
            if isinstance(shared_folder, tuple):
                virtual, shared_folder, *_unused = shared_folder
                virtual = str(virtual)
                shared_folder = str(shared_folder)
            else:
                # Convert fs-based shared to virtual shared (pre-1.4.0)
                virtual = str(shared_folder).replace("/", "_").replace("\\", "_").strip("_")
                log.add("Renaming shared folder '%s' to '%s'. A rescan of your share is required.",
                        (shared_folder, virtual))

            # Remove slashes from share name to avoid path conflicts
            virtual = virtual.replace("/", "_").replace("\\", "_")

            if shared_folder:
                shared_folder = os.path.normpath(shared_folder)

            return virtual, shared_folder

        config.sections["transfers"]["shared"] = [_convert_share(x)
                                                  for x in config.sections["transfers"]["shared"]]
        config.sections["transfers"]["buddyshared"] = [_convert_share(x)
                                                       for x in config.sections["transfers"]["buddyshared"]]

        # Remove old share databases (pre-3.3.0)
        for destination in (
            "wordindex", "fileindex", "files", "mtimes", "streams",
            "buddywordindex", "buddyfileindex", "buddyfiles", "buddymtimes", "buddystreams"
        ):
            file_path = os.path.join(config.data_folder_path, f"{destination}.db")

            try:
                self.remove_db_file(file_path)

            except OSError as error:
                log.add_debug("Failed to remove old share database %s: %s", (file_path, error))

    @classmethod
    def load_shares(cls, share_dbs, share_db_paths, destinations=None):

        exception = None

        for destination, db_path in share_db_paths.items():
            if destinations and destination not in destinations:
                continue

            try:
                share_dbs[destination] = Database(encode_path(db_path), overwrite=False)

            except Exception as error:
                exception = error
                cls.remove_db_file(db_path)

        if exception:
            cls.close_shares(share_dbs)
            raise exception

    def file_is_shared(self, username, virtual_path, real_path):

        log.add_transfer("Checking if file is shared: %s with real path %s",
                         (virtual_path, real_path))

        public_shared_files = self.share_dbs.get("public_files")
        buddy_shared_files = self.share_dbs.get("buddy_files")
        trusted_shared_files = self.share_dbs.get("trusted_files")
        file_is_shared = False
        size = None

        if not real_path.startswith("__INVALID_SHARE__"):
            if public_shared_files is not None and real_path in public_shared_files:
                file_is_shared = True
                _file_name, size, *_unused = public_shared_files[real_path]

            elif (buddy_shared_files is not None and username in core.buddies.users
                    and real_path in buddy_shared_files):
                file_is_shared = True
                _file_name, size, *_unused = buddy_shared_files[real_path]

            elif trusted_shared_files is not None:
                user_data = core.buddies.users.get(username)

                if user_data and user_data.is_trusted and real_path in trusted_shared_files:
                    file_is_shared = True
                    _file_name, size, *_unused = trusted_shared_files[real_path]

        if not file_is_shared:
            log.add_transfer("File is not present in the database of shared files, not sharing: "
                             "%s with real path %s", (virtual_path, real_path))
            return False, size

        return True, size

    def check_user_permission(self, username, ip_address=None):
        """Check if this user is banned, geoip-blocked, and which shares it is
        allowed to access based on transfer and shares settings."""

        if core.network_filter.is_user_banned(username) or core.network_filter.is_user_ip_banned(username, ip_address):
            if config.sections["transfers"]["usecustomban"]:
                ban_message = config.sections["transfers"]["customban"]
                return PermissionLevel.BANNED, ban_message

            return PermissionLevel.BANNED, ""

        user_data = core.buddies.users.get(username)

        if user_data:
            if user_data.is_trusted:
                return PermissionLevel.TRUSTED, ""

            return PermissionLevel.BUDDY, ""

        if ip_address is None or not config.sections["transfers"]["geoblock"]:
            return PermissionLevel.PUBLIC, ""

        country_code = core.network_filter.get_country_code(ip_address)

        # Please note that all country codes are stored in the same string at the first index
        # of an array, separated by commas (no idea why this decision was made...)

        if country_code and config.sections["transfers"]["geoblockcc"][0].find(country_code) >= 0:
            if config.sections["transfers"]["usecustomgeoblock"]:
                ban_message = config.sections["transfers"]["customgeoblock"]
                return PermissionLevel.BANNED, ban_message

            return PermissionLevel.BANNED, ""

        return PermissionLevel.PUBLIC, ""

    def get_shared_folders(self):

        shared_public_folders = config.sections["transfers"]["shared"]
        shared_buddy_folders = config.sections["transfers"]["buddyshared"]
        shared_trusted_folders = config.sections["transfers"]["trustedshared"]

        return shared_public_folders, shared_buddy_folders, shared_trusted_folders

    def get_normalized_virtual_name(self, virtual_name, shared_folders=None):

        if shared_folders is None:
            public_shares, buddy_shares, trusted_shares = self.get_shared_folders()
            shared_folders = (public_shares + buddy_shares + trusted_shares)

        # Provide a default name for root folders
        if not virtual_name:
            virtual_name = "Shared"

        # Remove slashes from share name to avoid path conflicts
        virtual_name = virtual_name.replace("/", "_").replace("\\", "_").strip(' "')
        new_virtual_name = str(virtual_name)

        # Check if virtual share name is already in use. Materialize existing
        # names once instead of rescanning all configured shares for every
        # generated suffix candidate.
        existing_virtual_names = {shared_folder[0] for shared_folder in shared_folders}

        counter = 1
        while new_virtual_name in existing_virtual_names:
            new_virtual_name = f"{virtual_name}{counter}"
            counter += 1

        return new_virtual_name

    def add_share(self, folder_path, permission_level=PermissionLevel.PUBLIC, virtual_name=None,
                  share_groups=None, validate_path=True):

        if validate_path and not os.access(encode_path(folder_path), os.R_OK):
            return None

        if share_groups is None:
            share_groups = self.get_shared_folders()

        # Remove previous share with same path if present
        core.shares.remove_share(folder_path, share_groups=share_groups)

        public_shares, buddy_shares, trusted_shares = share_groups
        virtual_name = core.shares.get_normalized_virtual_name(
            virtual_name or os.path.basename(folder_path),
            shared_folders=(public_shares + buddy_shares + trusted_shares)
        )
        permission_level_shares = {
            PermissionLevel.PUBLIC: public_shares,
            PermissionLevel.BUDDY: buddy_shares,
            PermissionLevel.TRUSTED: trusted_shares
        }
        shares = permission_level_shares.get(permission_level)

        shares.append((virtual_name, os.path.normpath(folder_path)))
        return virtual_name

    def remove_share(self, virtual_name_or_folder_path, share_groups=None):

        if share_groups is None:
            share_groups = self.get_shared_folders()

        normalized_folder_path = os.path.normpath(virtual_name_or_folder_path)

        for shares in share_groups:
            for virtual_name, folder_path in shares:
                if (virtual_name_or_folder_path in (virtual_name, folder_path)
                        or folder_path == normalized_folder_path):
                    shares.remove((virtual_name, folder_path))
                    return True

        return False

    @staticmethod
    def close_shares(share_dbs):

        for destination in share_dbs.copy():
            database = share_dbs.pop(destination, None)

            if database is not None:
                database.close()

    def _get_num_shared_folders_files(self):
        num_shared_folders = len(self.share_dbs.get("public_streams", {}))
        num_shared_files = len(self.share_dbs.get("public_files", {}))

        if config.sections["transfers"]["reveal_buddy_shares"]:
            num_shared_folders += len(self.share_dbs.get("buddy_streams", {}))
            num_shared_files += len(self.share_dbs.get("buddy_files", {}))

        if config.sections["transfers"]["reveal_trusted_shares"]:
            num_shared_folders += len(self.share_dbs.get("trusted_streams", {}))
            num_shared_files += len(self.share_dbs.get("trusted_files", {}))

        return num_shared_folders, num_shared_files

    def _cancel_shared_counts_retry(self):

        if self._shared_counts_retry_timer_id is None:
            return

        events.cancel_scheduled(self._shared_counts_retry_timer_id)
        self._shared_counts_retry_timer_id = None

    def _schedule_shared_counts_retry(self):

        if self._shared_counts_retry_timer_id is not None:
            return

        self._shared_counts_retry_timer_id = events.schedule(
            delay=self.SHARED_COUNTS_RETRY_DELAY, callback=self._retry_shared_counts)

    def _emit_local_shared_counts(self, num_shared_folders, num_shared_files):
        local_username = core.users.login_username

        if not local_username:
            # The shares module is initialized before the users module (to send updated share
            # stats to the server before watching our own username), and receives the login
            # event first, so local_username is still None when connecting. For this reason,
            # this check only happens after sending the SharedFoldersFiles server message.
            return

        # We've connected and rescanned our shares again. Fake a user stats message, since
        # server doesn't send updates for our own username after the first WatchUser message
        # response. Do this only after the server-count message was accepted locally, so
        # bounded queue backpressure cannot advance local stats for a count update that was
        # never queued.
        events.emit(
            "user-stats",
            GetUserStats(
                user=local_username,
                avgspeed=core.uploads.upload_speed, files=num_shared_files, dirs=num_shared_folders
            )
        )

    def _send_shared_counts(self, num_shared_folders, num_shared_files):

        if core.send_message_to_server(SharedFoldersFiles(num_shared_folders, num_shared_files)) is False:
            self._pending_shared_counts = (num_shared_folders, num_shared_files)
            self._schedule_shared_counts_retry()
            return False

        self._pending_shared_counts = None
        self._cancel_shared_counts_retry()
        self._emit_local_shared_counts(num_shared_folders, num_shared_files)
        return True

    def _retry_shared_counts(self):
        self._shared_counts_retry_timer_id = None

        if self._pending_shared_counts is None or self.rescanning:
            return

        num_shared_folders, num_shared_files = self._pending_shared_counts
        self._send_shared_counts(num_shared_folders, num_shared_files)

    def send_num_shared_folders_files(self):
        """Send number of publicly shared files to the server."""

        if self.rescanning:
            return False

        num_shared_folders, num_shared_files = self._get_num_shared_folders_files()
        return self._send_shared_counts(num_shared_folders, num_shared_files)

    # Scanning #

    def rebuild_shares(self, use_thread=True):
        return self.rescan_shares(rebuild=True, use_thread=use_thread)

    def rescan_shares(self, init=False, rescan=True, rebuild=False, use_thread=True, force=False):

        if self.rescanning:
            return None

        if rescan and not force:
            # Verify all shares are mounted before allowing destructive rescan
            unavailable_shares = self.check_shares_available()

            if unavailable_shares:
                log.add(_("Rescan aborted due to unavailable shares: %s"), unavailable_shares)
                rescan = False

                events.emit("shares-unavailable", unavailable_shares)

                if not init:
                    return None

        # Hand over database control to the scanner process
        self.rescanning = True
        self.close_shares(self.share_dbs)
        self.file_path_index = ()

        events.emit("shares-preparing")

        share_groups = self.get_shared_folders()

        try:
            self._scanner_process, scanner_queue = self._build_scanner_process(share_groups, init, rescan, rebuild)
            self._scanner_process.start()

        except Exception as error:
            # Process creation can fail under OS resource pressure, sandboxed
            # environments, or multiprocessing bootstrap errors. At this point
            # the live DB handles have already been closed and the in-memory
            # file-path index was cleared so the scanner could take ownership.
            # Fail closed by restoring the previous durable DB instead of
            # leaving the client permanently in a rescanning/no-shares state.
            log.add_debug("Failed to start share scanner process: %s", error)
            self._scanner_process = None
            self.rescanning = False

            if not self._restore_previous_shares_after_failed_scan():
                self.file_path_index = ()

            return False

        if use_thread:
            Thread(
                target=self._process_scanner, args=(scanner_queue, events.emit_main_thread),
                name="ProcessShareScanner", daemon=True
            ).start()
            return None

        successful = self._process_scanner(scanner_queue)

        # Synchronous scans are used by tests and headless tooling, bypassing the
        # main-thread ``shares-ready`` event. Mirror the essential reload/index
        # steps without emitting server share-count updates.
        if successful:
            try:
                self.load_shares(self.share_dbs, self.share_db_paths)
                self._rebuild_file_path_index()

            except Exception:
                successful = False

        self.rescanning = False

        if not successful and not self._restore_previous_shares_after_failed_scan():
            self.file_path_index = ()

        return successful

    def check_shares_available(self):

        share_groups = self.get_shared_folders()
        unavailable_shares = []

        for share in share_groups:
            for virtual_name, folder_path, *_unused in share:
                if not os.access(encode_path(folder_path), os.R_OK):
                    unavailable_shares.append((virtual_name, folder_path))

        return unavailable_shares

    def _build_scanner_process(self, share_groups=None, init=False, rescan=True, rebuild=False):

        import multiprocessing

        context = multiprocessing.get_context(method="spawn")
        scanner_queue = context.Queue()
        scanner_obj = Scanner(
            scanner_queue,
            share_groups,
            self.share_db_paths,
            init,
            rescan,
            rebuild,
            reveal_buddy_shares=config.sections["transfers"]["reveal_buddy_shares"],
            reveal_trusted_shares=config.sections["transfers"]["reveal_trusted_shares"]
        )
        scanner = context.Process(target=scanner_obj.run, daemon=True)
        return scanner, scanner_queue

    def _process_scanner(self, scanner_queue, emit_event=None):

        successful = True

        def process_scanner_queue(timeout=0):
            nonlocal successful

            while True:
                try:
                    if timeout:
                        item = scanner_queue.get(timeout=timeout)
                    else:
                        item = scanner_queue.get_nowait()

                except Empty:
                    break

                if item == ScannerState.FAILURE:
                    successful = False
                    continue

                if isinstance(item, int):
                    if emit_event is not None:
                        emit_event("shares-scanning", item)

                elif isinstance(item, ScannerLogMessage):
                    log.add(item.msg, item.msg_args)

                elif isinstance(item, tuple):
                    self.file_path_index = item

                elif isinstance(item, SharedFileListResponse):
                    self.compressed_shares[item.permission_level] = item

                elif item == ScannerState.RESCANNING:
                    if emit_event is not None:
                        emit_event("shares-scanning")

                elif item == ScannerState.INITIALIZED:
                    self.initialized = True

        while self._scanner_process.is_alive():
            # Cooldown
            time.sleep(0.05)
            process_scanner_queue()

        # The scanner can exit before the queue reader observes the final items.
        # Drain remaining messages before announcing that shares are ready. Legacy
        # scanner queues may still contain a file_path_index tuple, while current
        # scanners avoid sending the full path index across process boundaries.
        process_scanner_queue(timeout=0.05)

        self._scanner_process = None

        if emit_event is not None:
            emit_event("shares-ready", successful)

        return successful

    READY_SHARE_DB_DESTINATIONS = {
        "words", "public_files", "public_streams", "buddy_files", "buddy_streams",
        "trusted_files", "trusted_streams"
    }

    def _rebuild_file_path_index(self):
        """Build the search file-path index from already-loaded share DB keys."""

        self.file_path_index = tuple(chain(
            self.share_dbs.get("public_files", ()),
            self.share_dbs.get("buddy_files", ()),
            self.share_dbs.get("trusted_files", ())
        ))

    def _rebuild_compressed_shares_from_loaded_dbs(self):
        """Refresh cached browse responses from the currently loaded DBs.

        If a scanner process fails after closing the main process' DB handles,
        the old on-disk databases can still be valid. Rebuilding these cached
        responses avoids mixing an old file-path index with partially-emitted
        compressed share lists from the failed scan.
        """

        public_streams = self.share_dbs.get("public_streams")
        buddy_streams = self.share_dbs.get("buddy_streams")
        trusted_streams = self.share_dbs.get("trusted_streams")

        for permission_level in (PermissionLevel.PUBLIC, PermissionLevel.BUDDY, PermissionLevel.TRUSTED):
            compressed_shares = SharedFileListResponse(
                public_shares=public_streams, buddy_shares=buddy_streams, trusted_shares=trusted_streams,
                permission_level=permission_level
            )
            compressed_shares.make_network_message()
            compressed_shares.public_shares = compressed_shares.buddy_shares = compressed_shares.trusted_shares = None
            self.compressed_shares[permission_level] = compressed_shares

    def _restore_previous_shares_after_failed_scan(self):
        """Best-effort restore of the last good share DBs after a failed scan."""

        try:
            self.close_shares(self.share_dbs)
            self.load_shares(self.share_dbs, self.share_db_paths, destinations=self.READY_SHARE_DB_DESTINATIONS)
            self._rebuild_file_path_index()
            self._rebuild_compressed_shares_from_loaded_dbs()
            log.add_debug("Restored previous share database after failed share scan")
            return True

        except Exception as error:
            self.close_shares(self.share_dbs)
            log.add_debug("Failed to restore previous share database after failed share scan: %s", error)
            return False

    def _shares_ready(self, successful):

        # Scanning done, load shares in the main process again
        if successful:
            try:
                self.load_shares(
                    self.share_dbs, self.share_db_paths, destinations=self.READY_SHARE_DB_DESTINATIONS)
                self._rebuild_file_path_index()

            except Exception:
                successful = False

        self.rescanning = False

        if not successful:
            if self._restore_previous_shares_after_failed_scan():
                self.send_num_shared_folders_files()
            else:
                self.file_path_index = ()
            return

        self.send_num_shared_folders_files()

    # Network Messages #

    @staticmethod
    def _prune_address_request_times(request_times, request_time, ttl):
        request_time_cutoff = request_time - ttl

        for ip_address, address_request_times in tuple(request_times.items()):
            while address_request_times and address_request_times[0] < request_time_cutoff:
                address_request_times.popleft()

            if not address_request_times:
                request_times.pop(ip_address, None)

    def _allow_address_request(self, request_times, ip_address, request_time, ttl, max_addresses, max_per_address):
        if not ip_address:
            return True

        address_request_times = request_times.get(ip_address)
        request_time_cutoff = request_time - ttl

        if address_request_times is None:
            if len(request_times) >= max_addresses:
                self._prune_address_request_times(request_times, request_time, ttl)

                if len(request_times) >= max_addresses:
                    return False

            address_request_times = deque()
            request_times[ip_address] = address_request_times
        else:
            while address_request_times and address_request_times[0] < request_time_cutoff:
                address_request_times.popleft()

        if len(address_request_times) >= max_per_address:
            return False

        address_request_times.append(request_time)
        return True

    @staticmethod
    def _rollback_address_request(request_times, ip_address, request_time):

        if not ip_address:
            return

        address_request_times = request_times.get(ip_address)

        if not address_request_times:
            return

        try:
            address_request_times.remove(request_time)

        except ValueError:
            return

        if not address_request_times:
            request_times.pop(ip_address, None)

    def _prune_shared_file_list_request_times(self, request_time):
        request_time_cutoff = request_time - self.SHARED_FILE_LIST_REQUEST_TTL

        for username, last_request_time in tuple(self.requested_share_times.items()):
            if last_request_time < request_time_cutoff:
                self.requested_share_times.pop(username, None)

    def _record_shared_file_list_request(self, username, ip_address=None):
        request_time = time.monotonic()
        last_request_time = self.requested_share_times.get(username)

        if (last_request_time is not None
                and request_time < last_request_time + self.SHARED_FILE_LIST_REQUEST_INTERVAL):
            # Ignoring request, because it's less than half a second since the
            # last one by this user
            return None

        if (last_request_time is None
                and len(self.requested_share_times) >= self.MAX_SHARED_FILE_LIST_REQUEST_TIMES):
            self._prune_shared_file_list_request_times(request_time)

            if len(self.requested_share_times) >= self.MAX_SHARED_FILE_LIST_REQUEST_TIMES:
                return None

        if not self._allow_address_request(
                self.requested_share_address_times, ip_address, request_time, self.SHARED_FILE_LIST_REQUEST_TTL,
                self.MAX_REQUEST_ADDRESS_TIMES, self.MAX_SHARED_FILE_LIST_REQUESTS_PER_ADDRESS):
            return None

        self.requested_share_times[username] = request_time
        return username, ip_address, request_time, last_request_time

    def _allow_shared_file_list_request(self, username, ip_address=None):
        return self._record_shared_file_list_request(username, ip_address) is not None

    def _rollback_shared_file_list_request(self, marker):

        if marker is None:
            return

        username, ip_address, request_time, previous_time = marker

        if self.requested_share_times.get(username) == request_time:
            if previous_time is None:
                self.requested_share_times.pop(username, None)
            else:
                self.requested_share_times[username] = previous_time

        self._rollback_address_request(self.requested_share_address_times, ip_address, request_time)

    def _shared_file_list_request(self, msg):
        """Peer code 4."""

        username = msg.username
        ip_address, _port = msg.addr

        request_marker = self._record_shared_file_list_request(username, ip_address)

        if request_marker is None:
            return

        permission_level, _reject_reason = self.check_user_permission(username, ip_address)
        shares_list = self.compressed_shares.get(permission_level)

        if shares_list is None:
            self._rollback_shared_file_list_request(request_marker)
            return

        # Keep the cached compressed share-list object immutable after scans.
        # The network layer writes username/sock on outgoing peer messages, so
        # reusing one object for multiple browse requests can route both queued
        # sends to the last requester.
        response = shares_list.copy_without_results()
        response.unsent_rollback_info = ("shared-file-list-request", request_marker)

        if core.send_message_to_peer(username, response) is False:
            self._rollback_shared_file_list_request(request_marker)
            log.add_debug(
                "Discarding shared file list request from %s; peer output queue rejected the response",
                username
            )
            return

        log.add(_("User %(user)s is browsing your list of shared files"), {"user": username})

    def _prune_folder_contents_request_times(self, request_time):
        request_time_cutoff = request_time - self.FOLDER_CONTENTS_REQUEST_TTL

        for key, last_request_time in tuple(self.requested_folder_times.items()):
            if last_request_time < request_time_cutoff:
                self.requested_folder_times.pop(key, None)

    def _record_folder_contents_request(self, username, folder_path, ip_address=None):
        request_time = time.monotonic()
        request_key = (username, folder_path)
        last_request_time = self.requested_folder_times.get(request_key)

        if (last_request_time is not None
                and request_time < last_request_time + self.FOLDER_CONTENTS_REQUEST_INTERVAL):
            return None

        if last_request_time is None:
            if len(self.requested_folder_times) >= self.MAX_FOLDER_CONTENTS_REQUEST_TIMES:
                self._prune_folder_contents_request_times(request_time)

                if len(self.requested_folder_times) >= self.MAX_FOLDER_CONTENTS_REQUEST_TIMES:
                    return None

            if sum(1 for user, _folder in self.requested_folder_times if user == username) >= \
                    self.MAX_FOLDER_CONTENTS_REQUEST_TIMES_PER_USER:
                return None

        if not self._allow_address_request(
                self.requested_folder_address_times, ip_address, request_time, self.FOLDER_CONTENTS_REQUEST_TTL,
                self.MAX_REQUEST_ADDRESS_TIMES, self.MAX_FOLDER_CONTENTS_REQUESTS_PER_ADDRESS):
            return None

        self.requested_folder_times[request_key] = request_time
        return request_key, ip_address, request_time, last_request_time

    def _allow_folder_contents_request(self, username, folder_path, ip_address=None):
        return self._record_folder_contents_request(username, folder_path, ip_address) is not None

    def _rollback_folder_contents_request(self, marker):

        if marker is None:
            return

        request_key, ip_address, request_time, previous_time = marker

        if self.requested_folder_times.get(request_key) == request_time:
            if previous_time is None:
                self.requested_folder_times.pop(request_key, None)
            else:
                self.requested_folder_times[request_key] = previous_time

        self._rollback_address_request(self.requested_folder_address_times, ip_address, request_time)

    def _folder_contents_request(self, msg):
        """Peer code 36."""

        ip_address, _port = msg.addr
        username = msg.username
        folder_path = msg.dir

        request_marker = self._record_folder_contents_request(username, folder_path, ip_address)

        if request_marker is None:
            return

        permission_level, _reject_reason = self.check_user_permission(username, ip_address)
        folder_data = None

        if permission_level != PermissionLevel.BANNED:
            folder_data = self.share_dbs.get("public_streams", {}).get(folder_path)

            if (folder_data is None
                    and (config.sections["transfers"]["reveal_buddy_shares"]
                         or permission_level in {PermissionLevel.BUDDY, PermissionLevel.TRUSTED})):
                folder_data = self.share_dbs.get("buddy_streams", {}).get(folder_path)

            if (folder_data is None
                    and (config.sections["transfers"]["reveal_trusted_shares"]
                         or permission_level == PermissionLevel.TRUSTED)):
                folder_data = self.share_dbs.get("trusted_streams", {}).get(folder_path)

        response = FolderContentsResponse(directory=folder_path, token=msg.token, shares=folder_data)
        response.unsent_rollback_info = ("folder-contents-request", request_marker)

        if core.send_message_to_peer(username, response) is False:
            self._rollback_folder_contents_request(request_marker)
            log.add_debug(
                "Discarding folder contents request from %s; peer output queue rejected the response",
                username
            )
