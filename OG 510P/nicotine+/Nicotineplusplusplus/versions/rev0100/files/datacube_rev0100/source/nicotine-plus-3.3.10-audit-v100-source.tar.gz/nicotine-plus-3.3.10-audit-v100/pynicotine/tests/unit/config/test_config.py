# COPYRIGHT (C) 2021-2025 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import shutil

from unittest import TestCase

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.utils import encode_path

CURRENT_FOLDER_PATH = os.path.dirname(os.path.realpath(__file__))
DATA_FOLDER_PATH = os.path.join(CURRENT_FOLDER_PATH, "temp_data")


class ConfigTest(TestCase):

    def setUp(self):

        config.set_data_folder(DATA_FOLDER_PATH)
        config.set_config_file(os.path.join(DATA_FOLDER_PATH, "temp_config"))
        default_config_path = os.path.join(CURRENT_FOLDER_PATH, "config")

        if not os.path.exists(DATA_FOLDER_PATH):
            os.makedirs(DATA_FOLDER_PATH)

        shutil.copy(default_config_path, config.config_file_path)

        core.init_components(enabled_components={})

    def tearDown(self):
        core.quit()
        self.assertTrue(config.sections)


    def test_literal_eval_config_value_rejects_gross_inputs(self):
        """Oversized/nested config literals should fail before expensive parsing."""

        config_cls = type(config)
        old_literal_bytes = config_cls.MAX_CONFIG_LITERAL_BYTES
        old_literal_depth = config_cls.MAX_CONFIG_LITERAL_DEPTH
        old_collection_items = config_cls.MAX_CONFIG_COLLECTION_ITEMS

        try:
            config_cls.MAX_CONFIG_LITERAL_BYTES = 8
            with self.assertRaises(ValueError):
                config._literal_eval_config_value("'0123456789'")

            config_cls.MAX_CONFIG_LITERAL_BYTES = old_literal_bytes
            config_cls.MAX_CONFIG_LITERAL_DEPTH = 2
            with self.assertRaises(ValueError):
                config._literal_eval_config_value("[[[0]]]")

            config_cls.MAX_CONFIG_LITERAL_DEPTH = old_literal_depth
            config_cls.MAX_CONFIG_COLLECTION_ITEMS = 2
            with self.assertRaises(ValueError):
                config._literal_eval_config_value("[1, 2, 3]")

        finally:
            config_cls.MAX_CONFIG_LITERAL_BYTES = old_literal_bytes
            config_cls.MAX_CONFIG_LITERAL_DEPTH = old_literal_depth
            config_cls.MAX_CONFIG_COLLECTION_ITEMS = old_collection_items


    def test_parse_config_rejects_gross_file_before_configparser(self):
        """A grossly oversized config file should be rejected before configparser parses it."""

        config_cls = type(config)
        old_file_bytes = config_cls.MAX_CONFIG_FILE_BYTES

        try:
            config_cls.MAX_CONFIG_FILE_BYTES = 8

            with open(encode_path(config.config_file_path), "w", encoding="utf-8") as file_handle:
                file_handle.write("[server]\nlogin = " + ("x" * 100))

            with self.assertRaises(ValueError):
                config._parse_config(config.config_file_path)  # pylint: disable=protected-access

        finally:
            config_cls.MAX_CONFIG_FILE_BYTES = old_file_bytes

    def test_parse_config_rejects_gross_structure_before_configparser(self):
        """Tiny lines can still be gross if there are too many sections/options."""

        config_cls = type(config)
        old_sections = config_cls.MAX_CONFIG_SECTIONS
        old_options = config_cls.MAX_CONFIG_OPTIONS
        old_line_bytes = config_cls.MAX_CONFIG_LINE_BYTES

        try:
            config_cls.MAX_CONFIG_SECTIONS = 2
            with open(encode_path(config.config_file_path), "w", encoding="utf-8") as file_handle:
                file_handle.write("[one]\na = 1\n[two]\nb = 2\n[three]\nc = 3\n")

            with self.assertRaises(ValueError):
                config._parse_config(config.config_file_path)  # pylint: disable=protected-access

            config_cls.MAX_CONFIG_SECTIONS = old_sections
            config_cls.MAX_CONFIG_OPTIONS = 2
            with open(encode_path(config.config_file_path), "w", encoding="utf-8") as file_handle:
                file_handle.write("[server]\na = 1\nb = 2\nc = 3\n")

            with self.assertRaises(ValueError):
                config._parse_config(config.config_file_path)  # pylint: disable=protected-access

            config_cls.MAX_CONFIG_OPTIONS = old_options
            config_cls.MAX_CONFIG_LINE_BYTES = 16
            with open(encode_path(config.config_file_path), "w", encoding="utf-8") as file_handle:
                file_handle.write("[server]\nlogin = " + ("x" * 32) + "\n")

            with self.assertRaises(ValueError):
                config._parse_config(config.config_file_path)  # pylint: disable=protected-access

        finally:
            config_cls.MAX_CONFIG_SECTIONS = old_sections
            config_cls.MAX_CONFIG_OPTIONS = old_options
            config_cls.MAX_CONFIG_LINE_BYTES = old_line_bytes

    def test_load_config_resets_gross_literal_to_default(self):
        """A corrupted config value should be reset instead of parsed unboundedly."""

        with open(encode_path(config.config_file_path), "w", encoding="utf-8") as file_handle:
            file_handle.write("[server]\nctcpmsgs = [[[0]]]\n")

        config_cls = type(config)
        old_literal_depth = config_cls.MAX_CONFIG_LITERAL_DEPTH

        try:
            config_cls.MAX_CONFIG_LITERAL_DEPTH = 2
            core.quit()
            core.init_components(enabled_components={})
            self.assertEqual(config.sections["server"]["ctcpmsgs"], config.defaults["server"]["ctcpmsgs"])

        finally:
            config_cls.MAX_CONFIG_LITERAL_DEPTH = old_literal_depth

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(DATA_FOLDER_PATH)

    def test_load_config(self):
        """Test loading a config file."""

        self.assertEqual(config.defaults["server"]["login"], "")
        self.assertEqual(config.defaults["server"]["passw"], "")

        self.assertEqual(config.sections["server"]["login"], "user123")
        self.assertEqual(config.sections["server"]["passw"], "pass123")
        self.assertEqual(config.sections["server"]["autoreply"], "ääääääää")

    def test_write_config(self):
        """Test writing to a config file."""

        # Verify that changes are saved
        config.sections["server"]["login"] = "newname"
        config.write_configuration()

        with open(encode_path(config.config_file_path), encoding="utf-8") as file_handle:
            self.assertIn("newname", file_handle.read())

        # Verify that the backup is valid
        old_config = encode_path(f"{config.config_file_path}.old")
        self.assertTrue(os.path.exists(old_config))

        with open(old_config, encoding="utf-8") as file_handle:
            self.assertIn("user123", file_handle.read())

        # Reset
        config.sections["server"]["login"] = "user123"
        config.write_configuration()
