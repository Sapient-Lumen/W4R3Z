# Migration & Mobility Governance (Status + Rights as an Auditable Pipeline)

**Purpose:** make mobility governance contestable and humane where discretion and secrecy otherwise dominate.

**Problem class:** movement across borders and jurisdictions is a high-rights, high-discretion interface that blends **identity**, **administrative justice**, **service access**, and (sometimes) **coercion**. Failure modes include: *decision-by-queue* (delay as denial), *opaque inadmissibility filters*, *identity gating*, *coercive “administrative” detention without effective remedy*, and *offshore/outsourced enforcement that evades accountability*.

**Design goal:** treat migration status decisions and mobility controls as an **auditable pipeline** (registration → eligibility/status determination → conditions/work authorization → service access → enforcement/return (if any) → remedy + learning) using existing join-keys.

**This memo is intentionally minimal.** It composes existing interfaces: rules (`RULE-*`), decision receipts (`DRR-*`), reason codes (`RC-*`), remedy lanes (`AL-*`), identity/eligibility systems (`IDN-*`), service journeys (`SRV-*`), enforcement/custody events (`ENF-*`), releases (`REL-*`), and oversight closure (`OFR-*`).

**Anchors:** refugee status determination guidance ([BIB-UNHCR-HANDBOOK-2019], [BIB-UNHCR-RSD-PS-2020]); migration cooperation principles ([BIB-UN-GCM-2018]); data on migration dynamics ([BIB-IOM-WMR-2024]).


## Kernel anchors (do not repeat)
- Person-facing invariants: `98-persons-path-and-accessibility-invariants.md` (incl. non‑digital/non‑reading options), service journeys `47-...`, remedy lanes `36-...` / `08-...`.
- Protective legibility + adoption dynamics: `99-protective-legibility-and-adoption-dynamics.md` (transparency ≠ accountability; identify who loses discretion / who gains contestation capacity).
- Publication integrity (no silent edits; “as‑of” access): `53-...` and `31-...` where relevant.
- Coercion and custody controls: `05-...` and `43-...` (detention and returns are coercion even when labeled “administrative”).
- Pluralism / functional equivalents: representation and contestation must work across languages, cultures, and low‑infrastructure contexts (`98-persons-path-and-accessibility-invariants.md`).

## Named tensions (design must surface these)
- Border control/security vs human rights and non‑refoulement duties.
- Throughput/speed vs individualized assessment and due process (avoid “decision-by-queue”).
- Transparency/legibility vs evasion/retaliation risk and applicant privacy (see [TM-29]).
- Sovereignty vs international obligation (burden-sharing vs unilateral deterrence).
- Deterrence signaling vs humanitarian duty (policy posture can become coercive harm).

---

## A) Non-negotiable constraints (always-on)
1) **No “decision by queue”:** if a decision is required (status, work authorization, removal/return, detention review), it MUST have a **deadline**, a **no-response rule**, and a discoverable remedy lane (`AL-*`). Missed deadlines are governance incidents (pattern-auditable). (`36-...`, `08-...`, `31-...`)
2) **Rule traceability for gateways:** admissibility, eligibility, and evidence requirements MUST be expressible as `RULE-*` and queryable “as‑of” (no hidden rubrics or shifting checklists). (`39-...`, `25-...`)
3) **Receipts for status-affecting acts:** grants/denials/revocations/conditions/detentions/returns MUST emit `DRR-*` that cite controlling `RULE-*`, portable `RC-*`, any material evidence releases (`REL-*` where appropriate), and the remedy lane (`AL-*`). (`31-...`, `52-...`, `36-...`)
3a) **Comprehension + navigation duty:** receipts and notices MUST be understandable to the person affected (translation + disability access) and must tell them exactly what they can do next (who to contact, by when, what to submit, and whether help is available). (`98-persons-path-and-accessibility-invariants.md`, `31-...`, `08-...`)
3b) **Fear is a defect:** grievance/appeal channels MUST include anti-retaliation posture and safe reporting options; otherwise remedy is performative. (`98-persons-path-and-accessibility-invariants.md`, `08-...`, [TM-29])
3c) **Representation duty:** for minors and others who cannot realistically self-advocate, the system MUST trigger an independent advocate/guardian channel for high-stakes determinations. (`98-persons-path-and-accessibility-invariants.md`, `36-...`, `66-...`)
4) **Detention is exceptional and reviewable:** any deprivation of liberty requires an explicit basis, recorded time window, and scheduled review; custody events are logged as `ENF-*` and each custody authorization/extension emits a `DRR-*` with an appeal/review lane. (`43-...`, `05-...`, `66-...`)
5) **Outsourcing does not break accountability:** when enforcement, screening, shelter, or casework is delegated to contractors/NGOs or other jurisdictions, the same receipt + audit + remedy requirements apply via contract/compact clauses (`CON-*`/`CMP-*`) and independent follow-through (`OFR-*`). (`38-...`, `19-...`, `55-...`)
6) **Purpose limitation for data:** biometrics, watchlists, and case files require a bounded lawful basis; sharing and automated triage must be registered (`DPR-*`/`ADS-*`) and contestable. (`33-...`, `42-...`, `44-...`)

---

## B) Minimum Viable Mobility Governance Spine (MVMGS)

### B1) Public artifacts (what must be joinable)
- **Status decision receipts:** each status decision emits a `DRR-*` (grant/deny/revoke/renew/condition), with `RC-*` reasons and an `AL-*` lane.
- **Gateway rule inventory:** the PRR contains the admissibility/eligibility/evidence rules and any prioritization/triage policy (including “fast track” criteria). Publish “as‑of” access and changelogs. (`39-...`, `53-...`)
- **Service access map:** publish a simple crosswalk: status class → essential services access paths (`SRV-*`), including minimum access during pending status where required (health, shelter, schooling for minors, legal aid). (`47-...`, `64-...`, `57-...`)
- **Custody & enforcement logs:** custody events are logged in `ENF-*` and joined to the authorizing `DRR-*` (and to any contracts/compacts involved). Publish aggregate custody/return stats as `REL-*` with methods and revision logs. (`43-...`, `51-...`)
- **Return/removal pipeline receipts:** if return/removal is used, each order and its execution emits `DRR-*`/`ENF-*` artifacts with remedy lanes and non-refoulement safeguards.
- **Oversight closure:** material patterns (excessive delay, unlawful detention, high error/overturn rates, offshore harm) open `OFR-*` cases with duty‑to‑respond and closure verification (avoid “dashboard theater”; see [TM-33]). (`55-...`, `32-...`)

### B2) Decision typing (legitimacy routing)
- **Rule changes** that alter admissibility, evidence burdens, or detention/return powers are high-rights and require consultation logging (`ENG-*`) and a published impact note (`REL-*` methods) with a review/sunset trigger.
- **Individual determinations** are administrative but always receipt + remedy + correction channel.
- **Automation introductions** (risk scoring, triage, fraud flags, identity checks) must be registered (`ADS-*`), auditable, and appealable.

### B3) Multi-level boundary rules
Mobility governance often mixes scopes: local service delivery, national border/visa authority, supranational coordination, and global compacts.

Use the scope test (`54-...`) when:
- local units bear service burdens without aligned funding (unfunded mandate spillover),
- national enforcement practices create cross-border spillovers or rights risks,
- or interoperability (documents, readmission, asylum cooperation) requires shared standards.

Prefer compacts (`CMP-*`) for:
- reception and service funding formulas,
- shared casework standards + information-sharing limits,
- and return/readmission cooperation with rights-floor + oversight clauses.

---

## C) Typical failure modes to design against
- **Delay as denial (“queue weaponization”):** indefinite “pending” status, missed interviews, paper-only requests. Mitigation: publish queue metrics by service (`SRV-*`) and decision class; enforce no-response rules and urgent lanes.
- **Opaque inadmissibility filters:** hidden checklists, discretionary “risk” labels. Mitigation: PRR inventory of gateway rules, receipts for denials, and publish aggregate error/overturn rates.
- **Identity gating + correction backlog:** inability to correct identity records blocks status and services. Mitigation: define assurance tiers, publish correction timelines, and provide alternatives.
- **Administrative detention creep:** detention becomes default rather than exceptional. Mitigation: custody logs + scheduled review receipts + independent oversight cases.
- **Offshore/outsourced harm:** accountability gaps via private contractors or third-country processing. Mitigation: contract/compact receipt + audit + remedy clauses and mandatory independent follow-through (`OFR-*`).

---

## D) Reason code starter set (`RC-MIG-*`)
Use these *in addition to* `RC-PROC-*`, `RC-ELIG-*`, and (where coercion applies) `RC-ENF-*`.

- `RC-MIG-001` **Protection/status granted** — criteria met under as‑of `RULE-*` (cite key elements).
- `RC-MIG-002` **Status denied (criteria unmet)** — eligibility criteria not met (cite which element failed + evidence basis).
- `RC-MIG-003` **Inadmissible / barred** — statutory bar applies (cite the bar rule; name remedy lane and any waiver pathway).
- `RC-MIG-004` **Condition/work authorization decision** — authorization granted/denied/limited under a published rubric (cite rule + effective dates).
- `RC-MIG-005` **Detention/custody authorized or extended (time‑bounded)** — deprivation of liberty authorized/extended with review date and lane.
- `RC-MIG-006` **Return/removal order issued** — order issued under cited authority; MUST include remedy lane and documented safeguard checks.

---

## E) Where this plugs in
- Identity & eligibility gates: `44-identity-credential-and-eligibility-systems-register.md`
- Data protection + ADS governance: `33-...`, `42-...`, `06-digital-and-algorithmic-governance.md`
- Enforcement and custody logging: `43-enforcement-and-custody-event-register.md`, `05-public-safety-and-coercion.md`
- Remedy and administrative justice backstops: `08-remedy-and-grievance.md`, `36-...`, `66-justice-and-administrative-justice-governance.md`
- Social protection + essential services continuity joins: `64-...`, `57-...`, `47-...`
- Compacts/cooperation: `19-compacts-and-cooperative-governance.md`, `50-supranational.md`, `60-global.md`
