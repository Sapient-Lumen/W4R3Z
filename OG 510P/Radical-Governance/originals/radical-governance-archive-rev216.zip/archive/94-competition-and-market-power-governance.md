# Competition & Market Power Governance (Private Power as a Public Problem)

**Purpose:** prevent **private coercion** (market power, collusion, gatekeeping) from becoming a shadow government; keep markets contestable; and keep regulatory systems from being captured by incumbents. Competition governance is also a *procedural fairness* problem: investigations, remedies, and negotiated settlements must be reviewable.

This memo complements `13-regulation-utilities-and-soes.md` (sector regulation) and `22-public-integrity-and-procurement.md` (bid rigging + corruption). It is scoped to a **small portable spine** that works from municipal procurement cooperation to global cross-border enforcement.

**No new ID families:** competition investigations/decisions are handled as `DRR-*` (decision receipts) and published as `REL-*` case releases where needed. Cooperation instruments across units should use `CMP-*` (compacts) when formalized (`19-...`).

## Kernel anchors (do not repeat)
- Regulation/utility interfaces: `13-...`.
- Influence and interests (lobby/political economy): `46-...`, `79-...`.
- Oversight and binding hooks: `32-...`, `55-...`.
- Records + publication integrity for decisions and theories of harm: `31-...`, `53-...`.
- Person-facing contestability floors: `98-persons-path-and-accessibility-invariants.md`.
- Protective legibility / adoption dynamics (political economy): `99-protective-legibility-and-adoption-dynamics.md`.

## Named tensions (design must surface these)
- Enforcement against market power vs incentives for innovation/investment.
- Transparency of analysis vs trade secrets and strategic gaming.
- Consumer welfare vs broader political economy goals (labor, resilience, democracy).
- Central authority vs cross-border/sector fragmentation (and capture).
- Legibility of market power vs ability/will to act (private power persists even when visible; see [TM-33]).
- Complainant/whistleblower protection vs evidence needed for enforcement (retaliation/chilling; see [TM-29]).

---
## A. Minimum viable competition regime (MVCR)

### 1) Clear mandate and legal legibility
- MUST: publish the agency mandate, covered conduct, exemptions, and remedies in the competence ledger (`34-...`) and rules register (`RULE-*`).
- MUST: publish enforcement guidelines and remedy principles as versioned releases (`REL-*`) with change logs (`51/53`).
- SHOULD: require “competition assessment” for major regulations (not just ex post enforcement) using a standard checklist/toolkit.

### 2) Independence + procedural fairness
- SHOULD: appointment/removal rules that prevent day‑to‑day political retaliation; budget protection with audit.
- MUST: **procedural fairness** minimums for investigations (notice, opportunity to be heard, confidentiality protections, reasoned decisions, internal checks) and a clear appeal lane (`AL-*`).
- MUST: complainant safety is part of legitimacy—offer protected reporting and publish anti-retaliation posture; a remedy people fear is not remedy (`08-...`, `83-...`).
- SHOULD: define standing for representative/collective complaints (unions, trade associations, consumer orgs) where individual filing is unsafe or infeasible (`32-...`).
- MUST: publish time-to-decision targets and backlog measures as `REL-*`.

### 3) Enforcement ladder (proportional, predictable)
- MUST: define a remedy ladder (commitments/undertakings → behavioral remedies → structural remedies) with a preference for the *least discretion that works*.
- MUST: publish settlement/leniency criteria and logs (aggregate) to prevent “secret deals.”
- SHOULD: coordinate with sector regulators on joint fact-finding and remedy compatibility.

### 4) Merger review and concentration control
- MUST: a clear notification threshold regime (avoid discretionary gatekeeping).
- MUST: publish merger decisions and reasoning at a level compatible with confidentiality, including a short public summary that states the theory-of-harm, remedy, and how to challenge (so publication is usable, not theater).
- SHOULD: publish a concentration watch list (sectors/platforms) with methods and caveats.

### 5) Collusion and procurement bid rigging (high ROI)
- SHOULD: joint operating protocols between procurement and competition authorities:
  - detection triggers, safe reporting channel, rapid evidence preservation, and a referral pathway.
- SHOULD: require procurement systems to emit joinable data (OCDS/`CON-*`) so suspicious patterns are testable (`38-...`).

### 6) State-created monopolies and competitive neutrality
- MUST: when the state creates exclusive rights, publish the rationale, scope, and review/sunset plan as `DRR-TYPE: SCOPE` (or `DRR-TYPE: EXCEPTION` for exemptions) and pin conditions to `RULE-*` with an appeal lane.
- SHOULD: ensure SOEs competing with private firms follow competitive neutrality principles; publish state support and preferential terms (`07`, `13`).

### 7) Digital markets and data gatekeeping
- MUST: treat data access and platform rules as potentially competition‑relevant (interoperability, self‑preferencing, lock‑in).
- SHOULD: require transparency for algorithmic ranking/ads market changes when they materially shift contestability (link to `06/61/70`).

---

## B. Failure modes (and minimal countermeasures)

- **Weaponized antitrust (punish enemies / protect friends):** publish guidelines, publish case selection criteria at high level, protect appeal lanes, and use independent oversight (`32/55`).
- **Capture by dominant firms:** conflict-of-interest + revolving-door discipline (`79`), meeting transparency (`46`), publish consultations, and rotate staff on long cases.
- **Overreach / chilling innovation:** publish theory-of-harm and remedy proportionality; use ex post review and sunsetting where rules create heavy constraints (`74`).
- **Under-enforcement (cartel impunity):** prioritize bid rigging, leniency credibility, and procurement data quality.

---

## C. Minimal metrics (portable)
- **Timeliness:** median days from opening to decision (by case type).
- **Predictability:** % decisions aligned with published guidelines; % reversed/modified on appeal.
- **Advocacy impact:** count of major regulatory proposals screened with competition assessment; % amended.
- **Bid-rigging posture:** procurement tenders screened; referrals; confirmed collusion cases.
- **Transparency:** % decisions published with reasons; publication delay.

---

## Cross-scope notes

**Municipal / regional**
- Most competition leverage is via procurement integrity + licensing reform: use bid‑rigging guidance, joinable contract data, and “competition assessment” for licensing and permits.

**National**
- Independent competition authority + sector regulators with a coordination protocol; publish enforcement priorities and outcome dashboards.

**Supranational**
- Cooperation on mergers and cross-border conduct; minimum procedural fairness norms; information sharing compacts (`CMP-*`) with confidentiality rules.

**Global**
- Baseline norms: due process, transparency, investigative fairness, and cooperation channels.

---

## Anchors (start here)
- OECD Recommendation on Competition Assessment (PDF): [BIB-OECD-COMPASSESS-2019].
- OECD Competition Assessment Toolkit (Volumes 2–3; Version 4.0): [BIB-OECD-CAT-V4-V2] and [BIB-OECD-CAT-V4-V3].
- ICN Recommended Practices for Investigative Process (procedural fairness): [BIB-ICN-INVPROC-2019].
- ICN Recommended Practices on Dominance/Substantial Market Power (unilateral conduct): [BIB-ICN-DOMINANCE-2008].
- OECD Guidelines for Fighting Bid Rigging in Public Procurement (2025 update): [BIB-OECD-BIDRIGGING-2025].
- UNCTAD Model Law on Competition (developing-country legislative scaffolding): [BIB-UNCTAD-MODELLAW-COMP].