
# Global Warming Datacube rev0373

This package is the rev0373 linked revision of the Global Warming datacube. The active branch remains the Beaver Valley nuclear-emergency-preparedness subcube, but this revision is deliberately substance-first: public-meeting acquisition, records-route reverification, source-graph repair, and an active-surface capsule.

## Current focus

- Prevent the June 12, 2026 FEMA public-meeting evidence window from decaying into an uncollected notice-only trail.
- Convert the EN58200 EOF power-loss follow-up into an NRC ADAMS/FOIA request packet.
- Repair source graph drift through S1371 and recompute the source-use ledger from the index.
- Create a compact active-surface work package so future checks do not need to drag the whole historical cube through every pass.
- Preserve the real-evidence gate: no public readiness claim, no local readiness conclusion.

## Current state

The package still has **no real Beaver Valley exercise evidence packet**, and no records requests have been sent from this static archive. The correct state is:

**capture-ready / route-reverified / dispatch-ready / public-meeting-watch-open / source-graph-synced / active-surface-capsule-built / EOF-LER-watch-open / ANS-transition-gate-open / claim-frozen / no local readiness conclusion**

## Useful entry points

- `580-nuclear-emergency-preparedness-meetingwatch-sourcegraph-activesurface-refactor-compact-canon.md`
- `structural-audit-rev0373.md`
- `CHANGELOG-rev0373.md`
- `cube/bvps-public-meeting-acquisition-status-rev0373.csv`
- `cube/bvps-records-route-reverification-rev0373.csv`
- `cube/bvps-records-dispatch-triage-rev0373.csv`
- `records-requests/bvps-rev0373/rrt-0373-001-fema-region-3-online-foia-public-meeting-followup.md`
- `records-requests/bvps-rev0373/rrt-0373-002-nrc-adams-foia-eof-ler-fema-transmittal-followup.md`
- `cube/source-graph-sync-audit-rev0373.csv`
- `cube/bvps-active-surface-manifest-rev0373.csv`
- `evidence-bags/bvps-active-surface-capsule-rev0373.zip`
- `tools/validate_source_graph_sync_rev0373.py`
- `tools/validate_bvps_public_meeting_acquisition_rev0373.py`
- `tools/validate_route_reverification_rev0373.py`
- `tools/validate_bvps_active_surface_capsule_rev0373.py`
