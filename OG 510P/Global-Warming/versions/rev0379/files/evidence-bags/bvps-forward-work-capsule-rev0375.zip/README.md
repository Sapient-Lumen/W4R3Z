# Global Warming Datacube rev0375

This package is the rev0375 linked revision of the Global Warming datacube. The active branch remains the Beaver Valley nuclear-emergency-preparedness subcube, with the current pass focused on post-exercise evidence capture, custodian split, and dispatch-ready request specificity rather than more doctrine.

## Current focus

- Split the Pennsylvania/West Virginia FEMA Region 3 trail from the Ohio/Columbiana FEMA Region 5 trail.
- Treat the Columbiana 11:00 results announcement and the 17:30 FEMA/IPAWS meeting as two acquisition targets.
- Upgrade the Ohio/Columbiana records packets so they request evaluator materials, public statements, logs, exceptions, corrective actions, retest status, and redacted proof metadata.
- Keep the claim state frozen until official packets are imported, hashed, redacted where needed, and adjudicated.
- Give the next pass a compact forward-work capsule instead of forcing full-cube scan behavior.

## Current state

The package still has **no real Beaver Valley exercise evidence packet**, and no records requests have been sent from this static archive. The correct state is:

**region-split complete / packets upgraded and ready-not-sent / official-findings watch open / forward-work capsule built / source graph synced through S1384 / claim-frozen / no local readiness conclusion**

## Useful entry points

- `582-nuclear-emergency-preparedness-regionfork-requestcut-validationprune-refactor-compact-canon.md`
- `structural-audit-rev0375.md`
- `CHANGELOG-rev0375.md`
- `records-requests/bvps-rev0375/dispatch-order-rev0375.md`
- `records-requests/bvps-rev0375/rrt-0375-006-fema-region-v-ohio-columbiana-results-briefing-and-evaluator-materials.md`
- `records-requests/bvps-rev0375/rrt-0375-007-columbiana-county-ema-11am-results-briefing-evidence-packet.md`
- `records-requests/bvps-rev0375/rrt-0375-008-ohio-ema-radiological-branch-bvps-exercise-ipaws-afn-capa.md`
- `cube/bvps-fema-region-split-audit-rev0375.csv`
- `cube/bvps-official-findings-watchlist-rev0375.csv`
- `cube/bvps-request-specificity-upgrade-rev0375.csv`
- `cube/bvps-proofcut-request-crosswalk-rev0375.csv`
- `evidence-bags/bvps-forward-work-capsule-rev0375.zip`
