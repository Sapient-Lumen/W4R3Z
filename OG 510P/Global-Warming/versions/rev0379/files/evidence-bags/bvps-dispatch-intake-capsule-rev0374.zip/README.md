# Global Warming Datacube rev0374

This package is the rev0374 linked revision of the Global Warming datacube. The active branch remains the Beaver Valley nuclear-emergency-preparedness subcube, with the current pass focused on records acquisition, proofcut thresholds, and intake gates rather than more doctrine.

## Current focus

- Close the state/local request-packet gap left by rev0373.
- Treat the Columbiana County 11:00 FEMA results announcement as a separate acquisition fork from the 17:30 FEMA/IPAWS public-meeting watch.
- Make every ready packet dispatchable while preserving the fact that no packet has been sent from this static archive.
- Define proofcut thresholds for meeting materials, ANS/IPAWS, EN58200 EOF repair/retest, AFN/language access, corrective actions, and chain-of-custody.
- Add a DLP/redaction intake gate so future evidence can be used without leaking personal or security-sensitive data.

## Current state

The package still has **no real Beaver Valley exercise evidence packet**, and no records requests have been sent from this static archive. The correct state is:

**state-local packets ready / 11am results-capture fork open / proofcut thresholds explicit / DLP intake gate built / dispatch-intake capsule built / source graph synced through S1377 / claim-frozen / no local readiness conclusion**

## Useful entry points

- `581-nuclear-emergency-preparedness-localpackets-proofcuts-intakegate-refactor-compact-canon.md`
- `structural-audit-rev0374.md`
- `CHANGELOG-rev0374.md`
- `records-requests/bvps-rev0374/dispatch-bundle-cover-rev0374.md`
- `records-requests/bvps-rev0374/rrt-0374-003-pema-rtkl-ans-exercise-afn-capa.md`
- `records-requests/bvps-rev0374/rrt-0374-004-beaver-county-open-records-warning-afn-local-logs.md`
- `records-requests/bvps-rev0374/rrt-0374-005-ohio-ema-columbiana-bvps-exercise-records.md`
- `cube/bvps-records-dispatch-triage-rev0374.csv`
- `cube/bvps-proofcut-minimum-evidence-thresholds-rev0374.csv`
- `cube/bvps-evidence-adjudication-workbench-rev0374.csv`
- `cube/bvps-dlp-redaction-intake-gate-rev0374.csv`
- `evidence-intake/bvps-response-sidecar-template-rev0374.csv`
- `evidence-bags/bvps-dispatch-intake-capsule-rev0374.zip`
