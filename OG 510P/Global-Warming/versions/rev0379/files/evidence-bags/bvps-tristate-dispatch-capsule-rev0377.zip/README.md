# Global Warming Datacube rev0377

This package is the rev0377 linked revision of the Global Warming datacube. The active branch remains the Beaver Valley nuclear-emergency-preparedness subcube, with this pass focused on the missing West Virginia/Hancock acquisition lane, tri-state dispatch execution, and active-surface reduction.

## Current focus

- Add the missing West Virginia state and Hancock County local records-request lanes.
- Put all active requests on one tri-state dispatch board with proofcuts and follow-up clocks.
- Keep the ENS/IPAWS terminology correction from rev0376.
- Keep Region 3 and Region 5 acquisition split from rev0375.
- Keep all readiness claims frozen until official packets are imported, hashed, redacted where needed, and adjudicated.

## Current state

**WV/Hancock lane repaired / tri-state dispatch board built / request packets ready-not-sent / active dispatch capsule built / normalized tables rebuilt through file 584 / source graph synced through S1394 / claim-frozen / no local readiness conclusion**

## Useful entry points

- `584-nuclear-emergency-preparedness-wvlane-dispatchboard-activesurface-refactor-compact-canon.md`
- `structural-audit-rev0377.md`
- `CHANGELOG-rev0377.md`
- `records-requests/bvps-rev0377/dispatch-cut-sheet-rev0377.md`
- `records-requests/bvps-rev0377/dispatch-board-rev0377.csv`
- `records-requests/bvps-rev0377/rrt-0377-011-wv-dhs-wvemd-hancock-bvps-exercise-evaluator-materials.md`
- `records-requests/bvps-rev0377/rrt-0377-012-hancock-county-oem-bvps-exercise-alerting-eoc-afn-capa.md`
- `cube/bvps-tristate-custodian-dispatch-board-rev0377.csv`
- `cube/bvps-proofcut-dispatch-matrix-rev0377.csv`
- `cube/bvps-wv-hancock-route-gap-audit-rev0377.csv`
- `evidence-bags/bvps-tristate-dispatch-capsule-rev0377.zip`
