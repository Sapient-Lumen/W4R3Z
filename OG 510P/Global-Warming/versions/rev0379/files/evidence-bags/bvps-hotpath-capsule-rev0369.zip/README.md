# Global Warming Datacube rev0369

This package is the rev0369 linked revision of the Global Warming datacube. The active branch remains the nuclear-emergency-preparedness subcube, focused on BVPS evidence acquisition, not readiness conclusions.

## Current focus

- Use sendable records-request templates to acquire real or lawfully anonymized evidence instead of adding doctrine.
- Capture the June 12, 2026 preliminary findings/ANS demonstration materials with chain-of-custody metadata.
- Keep the March 2026 EOF power-loss event open until restoral, root cause, repair, retest, compensatory-measure, exercise-scope, and LER/no-LER artifacts are imported.
- Keep ANS/siren transition open until approval, current-system status, evaluated delivery/failure evidence, backup alerting, and accessibility evidence are imported.
- Use the reproducible rev0369 hotpath builder before scanning giant historical matrices.

## Current state

The package still has **no real Beaver Valley exercise evidence packet**. Its honest state is: capture-ready / request-template-ready / deadline-clock-open / EOF-LER-watch-open / ANS-transition-gate-open / claim-frozen / no local readiness conclusion.

## Primary new files

- `576-nuclear-emergency-preparedness-requesttemplates-deadlineclock-hotpathbuilder-refactor-compact-canon.md`
- `cube/nuclear-emergency-bvps-deadline-clock-rev0369.csv`
- `cube/nuclear-emergency-bvps-records-request-templates-rev0369.csv`
- `cube/nuclear-emergency-bvps-meeting-capture-runbook-rev0369.csv`
- `cube/nuclear-emergency-bvps-gap-to-request-map-rev0369.csv`
- `cube/nuclear-emergency-bvps-eof-corrective-action-proofchain-rev0369.csv`
- `cube/nuclear-emergency-bvps-alerting-proofchain-rev0369.csv`
- `cube/bvps-hotpath-source-list-rev0369.csv`
- `tools/build_bvps_hotpath_artifacts_rev0369.py`
- `tools/run_nuclear_emergency_bvps_validator_sweep_rev0369.py`
