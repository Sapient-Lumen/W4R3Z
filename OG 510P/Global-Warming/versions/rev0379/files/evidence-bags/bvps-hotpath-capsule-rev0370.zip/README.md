# Global Warming Datacube rev0370

This package is the rev0370 linked revision of the Global Warming datacube. The active branch remains the nuclear-emergency-preparedness subcube, focused on Beaver Valley Power Station evidence acquisition, not readiness conclusions.

## Current focus

- Convert rev0369 records templates into artifact-ready request packets under `records-requests/bvps-rev0370/`.
- Preserve the June 12, 2026 public-meeting capture path with an empty, reproducible lockbox and chain-of-custody templates.
- Verify records routes before use, especially the NRC ADAMS transition: routing sources are not evidence.
- Keep EOF recovery open until repair/root-cause/retest/compensatory-measure/exercise-scope/LER-or-no-LER artifacts are imported.
- Keep ANS/siren transition open until approval, current-system status, evaluated delivery/failure evidence, backup alerting, and accessibility evidence are imported.
- Use `tools/build_bvps_hotpath_artifacts_rev0370.py` for bounded active work instead of scanning giant historical matrices.

## Current state

The package still has **no real Beaver Valley exercise evidence packet** and no records requests have been sent from this static archive. Correct claim state:

**capture-ready / submission-packet-ready / ADAMS-route-verified / public-meeting-lockbox-ready / EOF-LER-watch-open / ANS-transition-gate-open / claim-frozen / no local readiness conclusion**

## Start here

1. Read `577-nuclear-emergency-preparedness-submissionpack-adamsroute-lockboxbuilder-refactor-compact-canon.md`.
2. Review `cube/nuclear-emergency-bvps-request-dispatch-ledger-rev0370.csv` and `records-requests/bvps-rev0370/`.
3. Before the public meeting or first artifact receipt, open `evidence-bags/bvps-public-meeting-lockbox-rev0370.zip` and use the sidecar/hash-ledger templates.
4. Run `python tools/run_nuclear_emergency_bvps_validator_sweep_rev0370.py` for the current-risk validation sweep.
