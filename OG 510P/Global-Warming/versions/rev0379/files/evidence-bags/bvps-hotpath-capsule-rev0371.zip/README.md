# Global Warming Datacube rev0371

This package is the rev0371 linked revision of the Global Warming datacube. The active branch remains the Beaver Valley nuclear-emergency-preparedness subcube, focused on acquiring and adjudicating evidence rather than making readiness conclusions.

## Current focus

- Add a receiving-end **response intake contract** so records, meeting artifacts, and docket releases cannot be scored without sidecar metadata, hashes, scope, and claim limits.
- Add a safe response-intake CLI and fixture ledger that demonstrates fixture/no-record material remains non-closure.
- Maintain hard P0 gates for EOF power-loss follow-up and ANS/siren transition evidence.
- Add a docket/release watch for NRC APS/PDR, FEMA final report timing, and records-route follow-up.
- Prune the active hotpath capsule so future work defaults to current-risk evidence/request/proofcut files rather than historical duplicate aliases.

## Current state

The package still has **no real Beaver Valley exercise evidence packet**, and no records requests have been sent from this static archive. The correct state is:

**capture-ready / submission-packet-ready / response-intake-lockbox-ready / docket-release-watch-open / EOF-LER-watch-open / ANS-transition-gate-open / claim-frozen / no local readiness conclusion**

## Useful entry points

- `578-nuclear-emergency-preparedness-responseintake-docketproof-hotpathprune-refactor-compact-canon.md`
- `tools/intake_bvps_records_response_rev0371.py`
- `cube/nuclear-emergency-bvps-response-intake-contract-rev0371.csv`
- `cube/nuclear-emergency-bvps-response-to-proofcut-map-rev0371.csv`
- `cube/nuclear-emergency-bvps-docket-release-watch-rev0371.csv`
- `evidence-bags/bvps-response-intake-lockbox-rev0371.zip`
- `tools/build_bvps_hotpath_artifacts_rev0371.py`
- `tools/run_nuclear_emergency_bvps_validator_sweep_rev0371.py`
