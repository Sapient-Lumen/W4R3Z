# Global Warming Datacube rev0376

This package is the rev0376 linked revision of the Global Warming datacube. The active branch remains the Beaver Valley nuclear-emergency-preparedness subcube, with this pass focused on dispatchable evidence acquisition and derived-table repair rather than adding another doctrine layer.

## Current focus

- Use the January 2026 Columbiana County BVPS RERP terminology correctly: WENS was replaced by ENS, so request/search/intake terms must include ENS, IPAWS, EAS, WEA, siren, and public warning.
- Keep the Region 3 and Region 5 acquisition split from rev0375.
- Make the next human action copy/paste-ready through online-form payloads and a dispatch cut sheet.
- Rebuild stale normalized file tables from `cube/index.csv` so file rows 580–583 are represented in derived query surfaces.
- Keep the claim state frozen until official packets are imported, hashed, redacted where needed, and adjudicated.

## Current state

**ENS/IPAWS alias gate added / dispatch payloads cut / response sidecar gate hardened / file-normalization derived layer rebuilt / source graph synced through S1387 / claim-frozen / no local readiness conclusion**

## Useful entry points

- `583-nuclear-emergency-preparedness-ensalias-normalizedtables-dispatchcut-refactor-compact-canon.md`
- `structural-audit-rev0376.md`
- `CHANGELOG-rev0376.md`
- `records-requests/bvps-rev0376/dispatch-cut-sheet-rev0376.md`
- `records-requests/bvps-rev0376/online-form-payloads-rev0376.csv`
- `records-requests/bvps-rev0376/rrt-0376-009-columbiana-ema-ens-ipaws-current-plan-exercise-logs.md`
- `records-requests/bvps-rev0376/rrt-0376-010-ohio-dps-public-records-center-ema-ens-ipaws-exercise-logs.md`
- `cube/bvps-columbiana-current-plan-gap-extraction-rev0376.csv`
- `cube/bvps-ens-ipaws-terminology-alias-audit-rev0376.csv`
- `cube/file-normalization-sync-audit-rev0376.csv`
- `cube/normalized-tail-coverage-rev0376.csv`
- `evidence-bags/bvps-dispatch-payload-capsule-rev0376.zip`
