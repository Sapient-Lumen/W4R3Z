# Boundary family map (v0)

Purpose: keep **all current `*-boundary-v0.md` docs** mechanically classed as either:
- members of a closed companion `*-boundary-index.md` family, or
- explicit standalone meaning pins whose entropy cost is accepted as a singleton for now.

Why this exists:
- the archive now has many closed companion boundary families, which is good for anti-amnesia,
- but once those families exist, the next real drift risk is **coverage**: a new `*-boundary-v0.md` can land outside both a family index and the tiny intentional-singleton set,
- this map keeps boundary coverage reviewable without inventing a new schema, decision surface, or workflow family.

This doc does **not** create new authority semantics.
It is a documentation/control-surface map for archive hygiene only.

## Closed boundary families

These companion discovery surfaces already own the current multi-doc boundary families:

- [`capshell-launch-boundary-index.md`](capshell-launch-boundary-index.md): closed D-CAPSHELL front-end + launch-boundary adjunct family
- [`sbom-boundary-index.md`](sbom-boundary-index.md): closed D-SBOM import-boundary family
- [`vex-boundary-index.md`](vex-boundary-index.md): closed D-VEX import-boundary family
- [`namecert-boundary-index.md`](namecert-boundary-index.md): closed D-NAMECERT boundary family
- [`quarantined-boundary-index.md`](quarantined-boundary-index.md): closed D-QUAR laundering-prevention family
- [`open-untrusted-boundary-index.md`](open-untrusted-boundary-index.md): closed D-PLUMB / D-QUAR / D-EPHEM safe-open family
- [`openuri-boundary-index.md`](openuri-boundary-index.md): closed D-PLUMB OpenURI companion boundary family
  - current family members: `openuri-scheme-support-boundary-v0.md`, `openuri-handler-selection-boundary-v0.md`, `openuri-opener-attribution-boundary-v0.md`, `openuri-activation-control-boundary-v0.md`, `openuri-callback-reentry-boundary-v0.md`, `openuri-launch-completion-boundary-v0.md`, `openuri-recent-items-boundary-v0.md`, `openuri-subject-echo-boundary-v0.md`, `openuri-materialization-boundary-v0.md`, `openuri-resource-grant-boundary-v0.md`, `openuri-request-shaping-boundary-v0.md`, `openuri-content-type-boundary-v0.md`, `openuri-url-safety-boundary-v0.md`, `openuri-preview-metadata-boundary-v0.md`, `openuri-content-extraction-boundary-v0.md`, `openuri-speculative-loading-boundary-v0.md`, `openuri-session-selection-boundary-v0.md`, `openuri-launch-disposition-boundary-v0.md`, `openuri-embedded-web-surface-boundary-v0.md`, `openuri-auth-session-boundary-v0.md`, `openuri-navigation-observation-boundary-v0.md`, `openuri-credential-mediation-boundary-v0.md`, `openuri-web-permission-boundary-v0.md`, `openuri-install-fallback-boundary-v0.md`, `openuri-verified-association-boundary-v0.md`, `openuri-showitem-exactness-boundary-v0.md`
- [`import-to-docref-boundary-index.md`](import-to-docref-boundary-index.md): closed D-CAPX / D-PLUMB / D-QUAR bearer→document bridge family
- [`signature-boundary-index.md`](signature-boundary-index.md): closed D-SIGENV / D-KEYLESS / D-TLOG verification-adjunct family
- [`attention-boundary-index.md`](attention-boundary-index.md): closed D-ATTN companion boundary family
  - current family members: `attention-durable-interrupt-boundary-v0.md`, `attention-durable-status-boundary-v0.md`
- [`confidential-computing-boundary-index.md`](confidential-computing-boundary-index.md): closed D-CC implementation/binding/trust/launch-context/report-field companion family
  - current family members: `confidential-computing-reference-target-boundary-v0.md`, `confidential-computing-reportdata-binding-boundary-v0.md`, `confidential-computing-snp-certificate-source-boundary-v0.md`, `confidential-computing-snp-vmpl-mode-boundary-v0.md`
  - current family members: `confidential-computing-snp-hostdata-claim-boundary-v0.md`, `confidential-computing-snp-launch-identity-claim-boundary-v0.md`, `confidential-computing-snp-tcb-field-claim-boundary-v0.md`, `confidential-computing-snp-policy-claim-boundary-v0.md`, `confidential-computing-snp-report-identity-claim-boundary-v0.md`
  - current family members: `confidential-computing-snp-chip-id-claim-boundary-v0.md`, `confidential-computing-snp-platform-info-claim-boundary-v0.md`, `confidential-computing-snp-guest-svn-claim-boundary-v0.md`, `confidential-computing-snp-measurement-claim-boundary-v0.md`, `confidential-computing-snp-version-metadata-claim-boundary-v0.md`, `confidential-computing-snp-gosvw-claim-boundary-v0.md`, `confidential-computing-snp-signing-metadata-claim-boundary-v0.md`
  - current family members: `confidential-computing-eat-payload-claim-boundary-v0.md`
- [`provenance-boundary-index.md`](provenance-boundary-index.md): closed D-PCP / D-ATOMICUPD provenance/update-adjunct family
- [`hybrid-topology-boundary-index.md`](hybrid-topology-boundary-index.md): closed D-MK / D-CLUSTERMAP / D-SKB topology-authority family
- [`replication-boundary-index.md`](replication-boundary-index.md): closed D-REPL / Hybrid object-family replication family
- [`cryptosvc-boundary-index.md`](cryptosvc-boundary-index.md): closed D-CRYPTOSVC / D-AUTHAGENT crypto-authority companion boundary family
  - current family members: `authagent-provider-role-boundary-v0.md`, `cryptosvc-inventory-boundary-v0.md`, `cryptosvc-forwarding-boundary-v0.md`, `cryptosvc-provider-selection-boundary-v0.md`, `cryptosvc-interactive-auth-boundary-v0.md`, `cryptosvc-mechanism-boundary-v0.md`, `cryptosvc-key-material-boundary-v0.md`, `cryptosvc-key-lifecycle-boundary-v0.md`, `cryptosvc-derived-material-boundary-v0.md`, `cryptosvc-attestation-boundary-v0.md`, `cryptosvc-verification-boundary-v0.md`
- [`attestation-boundary-index.md`](attestation-boundary-index.md): closed D-ATTEST companion boundary family
  - current family members: `attestation-endorsement-boundary-v0.md`, `attestation-freshness-boundary-v0.md`, `attestation-result-boundary-v0.md`, `attestation-identity-boundary-v0.md`, `attestation-collateral-status-boundary-v0.md`
- [`network-lease-boundary-index.md`](network-lease-boundary-index.md): closed D-NETLEASE companion boundary family
  - current family members: `network-lease-resolution-boundary-v0.md`, `network-lease-local-egress-boundary-v0.md`, `network-lease-path-property-boundary-v0.md`, `network-lease-proxy-boundary-v0.md`, `network-lease-tls-verifier-boundary-v0.md`, `network-lease-client-cert-boundary-v0.md`, `network-lease-application-protocol-boundary-v0.md`, `network-lease-server-name-boundary-v0.md`, `network-lease-session-resumption-boundary-v0.md`, `network-lease-transport-profile-boundary-v0.md`, `network-lease-dns-query-boundary-v0.md`, `network-lease-name-context-boundary-v0.md`, `network-lease-name-normalization-boundary-v0.md`, `network-lease-service-binding-boundary-v0.md`, `network-lease-port-inference-boundary-v0.md`, `network-lease-address-selection-boundary-v0.md`
- [`auth-mediation-boundary-index.md`](auth-mediation-boundary-index.md): closed D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB auth-mediation companion boundary family
  - current family members: `llm-elicitation-boundary-v0.md`, `mcp-elicitation-import-boundary-v0.md`, `mcp-client-registration-import-boundary-v0.md`, `mcp-auth-redirect-import-boundary-v0.md`, `mcp-pkce-import-boundary-v0.md`, `mcp-client-trust-policy-import-boundary-v0.md`, `mcp-auth-discovery-import-boundary-v0.md`, `mcp-auth-metadata-fetch-import-boundary-v0.md`, `mcp-auth-exact-match-import-boundary-v0.md`, `mcp-authorization-context-import-boundary-v0.md`, `mcp-step-up-auth-import-boundary-v0.md`, `mcp-refresh-token-import-boundary-v0.md`, `mcp-auth-response-packaging-import-boundary-v0.md`, `mcp-userinfo-import-boundary-v0.md`, `fedcm-import-boundary-v0.md`, `mcp-enterprise-managed-auth-import-boundary-v0.md`, `mcp-id-jag-import-boundary-v0.md`, `mcp-token-exchange-import-boundary-v0.md`, `mcp-client-credentials-import-boundary-v0.md`, `mcp-client-assertion-import-boundary-v0.md`, `mcp-auth-request-packaging-import-boundary-v0.md`, `mcp-authorization-details-import-boundary-v0.md`, `mcp-device-authorization-import-boundary-v0.md`, `mcp-jwks-import-boundary-v0.md`, `mcp-token-introspection-import-boundary-v0.md`, `mcp-token-revocation-import-boundary-v0.md`, `mcp-dpop-import-boundary-v0.md`, `mcp-token-passthrough-import-boundary-v0.md`, `mcp-caller-auth-binding-import-boundary-v0.md`, `appsecret-secret-ingress-boundary-v0.md`, `vault-credential-mediation-boundary-v0.md`, `credential-enrollment-boundary-v0.md`, `credential-exchange-boundary-v0.md`, `browser-session-export-boundary-v0.md`, `auth-continuation-export-boundary-v0.md`, `auth-link-ui-trigger-boundary-v0.md`, `auth-result-export-boundary-v0.md`, `auth-proof-export-boundary-v0.md`, `authorization-context-export-boundary-v0.md`, `identity-claim-export-boundary-v0.md`, `account-binding-export-boundary-v0.md`, `login-state-export-boundary-v0.md`, `auth-teardown-boundary-v0.md`
- [`verifiable-credential-ecosystem-boundary-index.md`](verifiable-credential-ecosystem-boundary-index.md): closed D-LLM / D-POLICY / IF-ACP browser-wallet / credential / DID / trust-registry-import companion family
  - current family members: `digital-credentials-api-import-boundary-v0.md`, `openid4vp-import-boundary-v0.md`, `openid4vci-import-boundary-v0.md`, `verifiable-credential-status-import-boundary-v0.md`, `did-document-import-boundary-v0.md`, `credential-trust-registry-import-boundary-v0.md`
- [`tool-ui-boundary-index.md`](tool-ui-boundary-index.md): closed D-LLM / D-UICAP / D-POWERBOX / IF-ACP / D-COMMUTE rendered-tool-UI companion boundary family
  - current family members: `tool-ui-authority-boundary-v0.md`, `tool-ui-toolcall-boundary-v0.md`, `tool-ui-model-context-boundary-v0.md`, `tool-ui-file-boundary-v0.md`, `tool-ui-followup-message-boundary-v0.md`, `tool-ui-navigation-boundary-v0.md`, `tool-ui-display-surface-boundary-v0.md`

## Standalone boundary docs (Phase 1)

The following boundary docs are **intentional singletons** today. They stay here until one of two things happens: either a real multi-doc family emerges and gets its own `*-boundary-index.md`, or the doc is retired/absorbed. The singleton side must also stay structurally honest under `boundary-singleton-contract-v0.md`.

- [`capshell-result-sidecar-boundary-v0.md`](capshell-result-sidecar-boundary-v0.md): pins the one narrow seam where command results might try to smuggle durable sidecar authority; broader D-CAPSHELL launch-side family already lives elsewhere.
- [`device-lease-ordering-boundary-v0.md`](device-lease-ordering-boundary-v0.md): pins the one narrow seam between D-IOLEASE ordering tokens and device-lease lifecycle semantics; no broader device-ordering family exists yet.
- [`lease-descriptor-state-boundary-v0.md`](lease-descriptor-state-boundary-v0.md): pins the one narrow seam between exact issued lease/grant descriptor bounds and current provider-owned live state; no broader lease-state boundary family exists yet.
- [`network-request-idempotency-boundary-v0.md`](network-request-idempotency-boundary-v0.md): pins the one narrow seam between exact-replay CH-NETREQ request identity and mutable request-upsert folklore on `portal.net.request`; no broader network-request boundary family exists yet.
- [`network-request-listen-subject-boundary-v0.md`](network-request-listen-subject-boundary-v0.md): pins the one narrow seam between local listener bind/exposure subjects and remote DNS/publication folklore on `portal.net.request`; no broader network-request boundary family exists yet.
- [`disposable-target-selection-boundary-v0.md`](disposable-target-selection-boundary-v0.md): pins the one narrow seam between asking for disposable routing and naming a concrete destination; no broader disposable-routing boundary family exists yet.
- [`profile-default-artifact-boundary-v0.md`](profile-default-artifact-boundary-v0.md): pins the one narrow seam between markdown profile matrices and generated CH-CFG / CH-POLICY artifacts; no broader profile-artifact boundary family exists yet.
- [`reqctx-sponsorship-evolution-boundary-v0.md`](reqctx-sponsorship-evolution-boundary-v0.md): pins the one narrow seam between sticky request-context sponsorship references and any future typed sponsorship/control plane; no broader D-REQCTX evolution family exists yet.
- [`connector-tool-policy-boundary-v0.md`](connector-tool-policy-boundary-v0.md): pins the one narrow seam between explicit tool catalogs and the host/request-local connector policy that shaped them; no broader reviewed connector-admin family exists yet.
- [`authzen-import-boundary-v0.md`](authzen-import-boundary-v0.md): pins the one narrow seam between imported external authorization APIs and real approval/policy/entitlement truth; no broader reviewed external-policy-import family exists yet.
- [`openid-federation-import-boundary-v0.md`](openid-federation-import-boundary-v0.md): pins the one narrow seam between imported external federation trust bootstrap and real issuer-registry/trust-root/app-trust/policy-selector/connected-entity truth; no broader reviewed external-federation-import family exists yet.
- [`openid-identity-assurance-import-boundary-v0.md`](openid-identity-assurance-import-boundary-v0.md): pins the one narrow seam between imported external verified-claims / assurance payloads and real KYC / identity-registry / verifier-policy / approval-basis / current-user truth; no broader reviewed external-identity-assurance-import family exists yet.
- [`shared-signals-import-boundary-v0.md`](shared-signals-import-boundary-v0.md): pins the one narrow seam between imported external auth-state event ecosystems and real login-state/auth-teardown/current-user/approval truth; no broader reviewed external-auth-event-import family exists yet.
- [`scim-import-boundary-v0.md`](scim-import-boundary-v0.md): pins the one narrow seam between imported external provisioning/directory APIs and real account-directory/group-entitlement/current-user/current-permission/lifecycle truth; no broader reviewed external-directory-import family exists yet.
- [`tool-annotation-semantics-boundary-v0.md`](tool-annotation-semantics-boundary-v0.md): pins the one narrow seam between imported tool-descriptor hints and real approval/authorization/commutativity truth; no broader reviewed tool-metadata family exists yet.
- [`tool-result-visibility-boundary-v0.md`](tool-result-visibility-boundary-v0.md): pins the one narrow seam between audience-scoped tool-result lanes and real approval/authority/evidence truth; no broader reviewed tool-result family exists yet.
- [`mcp-task-import-boundary-v0.md`](mcp-task-import-boundary-v0.md): pins the one narrow seam between provider-local MCP task wrappers and real background-work / queue-status / persistence semantics; no broader reviewed deferred-work import family exists yet.
- [`mcp-progress-import-boundary-v0.md`](mcp-progress-import-boundary-v0.md): pins the one narrow seam between provider-local MCP progress notifications and real queue/progress / completion / current-state semantics; no broader reviewed imported-progress family exists yet.
- [`mcp-roots-import-boundary-v0.md`](mcp-roots-import-boundary-v0.md): pins the one narrow seam between provider-local MCP workspace-root hints and real filesystem/file-document authority semantics; no broader reviewed imported-filesystem-context family exists yet.
- [`mcp-resource-import-boundary-v0.md`](mcp-resource-import-boundary-v0.md): pins the one narrow seam between provider-local MCP resource catalogs/bytes and real filesystem/document/watch/import semantics; no broader reviewed imported-resource family exists yet.
- [`mcp-logging-import-boundary-v0.md`](mcp-logging-import-boundary-v0.md): pins the one narrow seam between provider-local MCP diagnostic signaling and real transcript/observation-export/admin semantics; no broader reviewed imported-diagnostics family exists yet.
- [`mcp-prompt-import-boundary-v0.md`](mcp-prompt-import-boundary-v0.md): pins the one narrow seam between provider-local MCP prompt catalogs/templates and real workflow/policy/approval semantics; no broader reviewed imported-prompt family exists yet.
- [`mcp-completion-import-boundary-v0.md`](mcp-completion-import-boundary-v0.md): pins the one narrow seam between provider-local MCP argument suggestions and real selector/default/workflow semantics; no broader reviewed imported-completion family exists yet.
- [`mcp-sampling-import-boundary-v0.md`](mcp-sampling-import-boundary-v0.md): pins the one narrow seam between provider-local MCP nested model-generation mechanics and real planner/background/approval semantics; no broader reviewed imported-sampling family exists yet.

## Review rule

Before adding a new `*-boundary-v0.md` doc, answer these questions in order:
1) Does an existing `*-boundary-index.md` family already own this meaning pin?
2) If not, is this truly a **singleton seam** rather than the start of a new multi-doc family?
3) If it is a singleton, add it here **in the same revision**.
4) If it is the start of a family, introduce exactly one new `*-boundary-index.md` and justify the entropy cost in that same revision.

The guardrail for this map intentionally fails closed: every current `*-boundary-v0.md` file must be covered by one of the family indexes above or be explicitly named in the singleton list here. Companion family indexes themselves must stay structurally honest under `boundary-index-contract-v0.md`; intentional singleton docs themselves must stay structurally honest under `boundary-singleton-contract-v0.md`; neither route is allowed to survive as a stale placeholder.
