# D-NETLEASE local-egress boundary v0 (no portable local-interface / source-address / VRF seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed leased networking does **not** become a portable local-interface, source-address, VRF, or equivalent local-egress-binding surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable local-interface / source-address / VRF seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **destination predicate**, the granted **resolver binding**, and the transport class.
   - They do **not** grow a portable `bound_network`, `network_handle`, `interface_name`, `interface_type`, `required_interface`, `required_interface_type`, `source_ip`, `source_prefix`, `vrf`, `routing_mark`, `traffic_class`, or equivalent local-egress export surface.
   - Phase 1 portable truth is therefore: **what reachability predicate was reviewed/granted, through which resolver binding, over which transport class** — not which local interface, source address, VRF, or routing attachment a provider/runtime happened to use.

2) **Local egress selection stays portal-local or app-local.**
   - A lease may authorize reachability to a reviewed predicate.
   - That does **not** standardize which local network, NIC, interface type, source address, VRF, or source-dependent-routing policy a provider/runtime uses when actually sending packets.
   - Different product profiles or owner-local runtimes may therefore select different local egress attachments — or change them as topology changes — while still staying inside the same reviewed D-NETLEASE grant.

3) **No ambient inherited egress-binding fallback.**
   - Reviewed networking in Phase 1 must not silently inherit process-bound networks, per-socket bind-to-network state, host-global default-VRF assumptions, `SO_BINDTODEVICE`, interface-type requirements, or ad-hoc “use whichever VPN / Wi-Fi / tenant uplink the host already pinned” compatibility switches as substrate meaning.
   - That rule applies both to direct `portal.net` implementations and to wrappers/compat paths around them: host egress-selection residue is not by itself reviewed network authority.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient channels through inherited process binding, interface pinning, source-address forcing, or host-local VRF defaults.

4) **If portable egress pinning matters, pay for a new seam explicitly.**
   - A future product shape may want reviewed interface class selection, tenant/VRF pinning, source-prefix control, or management-plane vs data-plane egress policy.
   - That work must return **RFC-first** with its own schema/receipt family, redaction story, commutativity/conflict-key contract, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems expose per-network, per-interface, or per-socket binding APIs.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit egress-binding seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from per-process network binding, interface pinning, or VRF helpers.

6) **Current local-egress result is live topology/session state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove which local network, interface, source address, or VRF was chosen at connection time, whether that attachment still exists now, or whether the same local path would be chosen on retry.
   - As elsewhere in SlopOS, stable request/receipt artifacts are evidence of one reviewed action, not a portable oracle for mutable owner-local topology or route-selection state.

## Phase 1 non-goals (explicitly deferred)

- No portable `bound_network`, `interface_name`, `interface_type`, `required_interface`, `source_ip`, `source_prefix`, `vrf`, or `routing_mark` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a system network picker, interface selector, or VRF broker.
- No transcript-stable claim that an accepted network request or issued lease also proves which local interface / source address / VRF was used.
- No hidden `bindProcessToNetwork`, `Network.bindSocket`, `requiredInterface`, `requiredInterfaceType`, `SO_BINDTODEVICE`, or inherited-VRF compatibility promise around `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS, and the last passes kept answer/path telemetry, proxy policy, transport verifier policy, and client-auth identity out of CH-NETREQ / CH-NETLEASE portable meaning. The next quiet drift is to pretend the same lease also says **which local uplink or source identity** defined the real connection. Real systems do expose local-network, interface, and socket-binding controls, but they treat those as explicit per-process, per-socket, or topology-dependent choices — not harmless residue of “a network request was reviewed.”

If we leave that blurry, workstation and agent flows will start depending on whichever VPN, Wi-Fi, Ethernet, cellular, or tenant VRF the host happened to select, while cloud and embedded profiles will be forced to fake portability for local-egress semantics they do not actually share. Pinning the boundary now keeps D-NETLEASE honest: reviewed reachability is one seam, reviewed local-egress selection would be another future seam if we ever truly need it.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich per-network or per-interface policy locally, but that does not standardize VPN, Wi-Fi, Ethernet, or interface-picker choices as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound reachability explicit without pretending host-side VRF, ENI, veth, or source-address attachment choices are transcript-stable guest/runtime truth.
- **Embedded / separation appliance (C):** appliance builds can keep a narrow reachability seam without paying for a portable general-purpose local-network / interface-selection plane they do not want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “lease to this destination” with “portable instruction to use this interface / source address / VRF,” which reduces hidden dependence on host networking folklore.

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-resolution-boundary-v0.md`
  - `docs/30-architecture/network-lease-proxy-boundary-v0.md`
  - `docs/30-architecture/network-lease-tls-verifier-boundary-v0.md`
  - `docs/30-architecture/network-lease-client-cert-boundary-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-NETLEASE-DNSBIND**, **PO-CAPSHELL-NET-EXPLICIT**)

CI drift gate:
- `tools/check_network_lease_local_egress_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable local-interface / source-address / VRF seam / no ambient inherited egress-binding fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-635**).

## References

- REF-ANDROID-MULTINETWORK.
- REF-APPLE-NWPARAMETERS-REQUIREDINTERFACE.
- REF-LINUX-SO_BINDTODEVICE.
- REF-RFC6724-ADDRSELECT.
- REF-RFC8043-SADR.
