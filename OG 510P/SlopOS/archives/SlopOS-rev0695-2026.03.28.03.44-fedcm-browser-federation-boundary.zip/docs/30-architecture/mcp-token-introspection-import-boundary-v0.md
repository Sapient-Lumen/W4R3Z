# D-LLM MCP-token-introspection import boundary v0 (auth introspection is not portable live login / grant / account truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP authorization guidance that validates access tokens by calling a token introspection endpoint, interpreting returned metadata such as `active`, `scope`, `client_id`, `sub`, `aud`, `iss`, `exp`, or related fields, and optionally caching those results server-side is **provider-local verifier input only**. It does **not** create a portable live login-state oracle, grant inventory, subject/account export, connected-service registry, or current-session substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported token-introspection semantics may be interpreted next to already-pinned auth-discovery, auth-metadata-fetch, JWKS, client-credentials, enterprise-auth, auth-result, login-state, identity-claim, and authorization-context boundaries.

## Posture (v0)

1) **Imported introspection endpoints stay provider-local verifier endpoints only.**
   - Current MCP authorization guidance shows an MCP server delegating token validation to an OAuth 2.0 token introspection endpoint, using provider-owned credentials to ask an authorization server whether a presented token is valid for use.
   - That introspection endpoint remains provider-local verifier machinery only; it does **not** create a portable login-status API, current-user service, token-verdict plane, or connected-service registry on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, and caller-auth-binding boundaries stay authoritative instead of inheriting hidden platform meaning from one verifier endpoint URL.

2) **Returned introspection fields stay provider-local validation context only.**
   - RFC 7662 defines response metadata such as `active` plus optional token context including `scope`, `client_id`, `username`, `token_type`, `exp`, `iat`, `nbf`, `sub`, `aud`, `iss`, and `jti`.
   - Those fields remain provider-local validation context only; they do **not** become a portable current-user oracle, entitlement inventory, account/profile export, connected-app truth, or approval-basis substrate on existing SlopOS seams.
   - Existing login-state, identity-claim, authorization-context, account-binding, and auth-result boundaries stay authoritative instead of inheriting platform meaning from one introspection JSON object.

3) **`active` / inactive answers stay live provider policy only.**
   - RFC 7662 makes token activity a property answered by the authorization server for the protected resource's current query context rather than a transcript-stable platform fact.
   - That live answer remains provider-local policy only; it does **not** become a portable signed-in oracle, durable current-session truth, revocation ledger, or replayable approval/evidence artifact on existing SlopOS seams.
   - Existing login-state, auth-teardown, and evidence boundaries stay authoritative instead of inheriting liveness semantics from one introspection reply or cache row.

4) **Introspection credentials and caches stay provider-local verification machinery only.**
   - Current MCP guidance shows servers using their own introspection credentials and warns that any server-side token caching needs secure storage plus robust eviction so expired or invalid tokens are not reused.
   - Those credentials, cache rows, and eviction rules remain provider-local verification machinery only; they do **not** create a portable service-account substrate, auth-state cache plane, durable token/session broker, or transcript-stable policy fact on existing SlopOS seams.
   - Existing client-credentials, token-passthrough, caller-auth-binding, and auth-result boundaries stay authoritative instead of inheriting platform meaning from verifier-side cache reuse.

5) **No silent identity / grant / account widening rides in through introspection.**
   - Imported introspection handling does **not** authorize connected-account export, subject/email export, granted-scope export, tenant selection, or durable service-account truth by implication.
   - A successful introspection step may let one provider continue one authorization path, but it does **not** standardize portable identity/account/grant semantics on adjacent SlopOS seams.
   - If SlopOS ever needs a portable login-status API, token-verdict surface, introspection cache policy, or service-identity registry, that work must arrive on those explicit seams and validators directly.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth libraries, introspection helpers, cache middleware, or ambient verifier credentials must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient introspection credentials, hidden cache state, or implicit introspection egress must fail closed for portable D-LLM auth semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local token verification plus explicit reviewed result/evidence seams.
   - Any future native login-status / token-verdict / auth-cache governance workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported introspection helpers or cache middleware.

## Phase 1 non-goals (explicitly deferred)

- No portable `introspection_endpoint`, `token_introspection`, `active`, `token_metadata`, `token_status`, or equivalent live token-verdict substrate imported directly from MCP/OAuth helpers.
- No rule that introspection fields such as `scope`, `client_id`, `username`, `sub`, `aud`, `iss`, or `jti` stand in for portable identity/profile export, grant inventory, connected-service truth, or approval basis.
- No rule that `active` / inactive answers stand in for portable signed-in truth, durable current-session truth, or transcript-stable revocation fact.
- No rule that verifier-side introspection credentials, cache rows, or eviction policy stand in for portable service-account, token/session-broker, or auth-cache semantics.

## Why this is worth pinning

The archive already keeps auth discovery, fetched metadata, exact-match binding, enterprise routing, machine auth, verifier keys, auth proof export, login-state, identity claims, and account binding on separate explicit seams. Current MCP authorization guidance adds a nearby pressure surface those docs do not yet pin directly: **token verification by live OAuth token introspection, including introspection responses and server-side cache/eviction pressure**.

That looks like implementation detail, but it is exactly where hidden substrate grows. Once wrappers and agents see `active`, `scope`, `client_id`, `sub`, and introspection cache rows in both interactive and machine-auth stacks, “ask the authorization server if this token is still good” turns into “the platform knows who is signed in,” scope fields turn into “portable grant inventory,” introspection credentials turn into “connected service identity,” and verifier caches start masquerading as a durable session or approval registry.

Pinning the boundary now keeps the archive honest. Imported token introspection may remain a provider-local way to validate one presented token on one auth path, but it does not get to redefine login-state truth, grant inventory, identity export, service identity, or durable session/account semantics on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with remote MCP servers that introspect tokens, but verifier endpoint calls and returned token metadata still stay provider-local auth machinery rather than a portable signed-in/account truth story.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted workers and control planes will encounter opaque-token and live-introspection deployments often, but those checks do not become tenant-stable session/account/grant substrate by default.
- **Embedded / separation appliance (C):** appliances can omit remote token introspection entirely or terminate it in a narrow shim without importing a generalized login-status / token-verdict subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported introspection helpers may help one provider-owned auth path proceed, but they do not become a second identity/login/grant substrate beside explicit auth-result, login-state, identity-claim, and authorization-context seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_token_introspection_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “auth introspection is not portable live login / grant / account truth” posture drifts (**EVID-2026-685**).

## References

- `REF-MCP-AUTHORIZATION-TUTORIAL`
- `REF-RFC7662-TOKEN-INTROSPECTION`
- `REF-MCP-SECURITY-BEST-PRACTICES`
