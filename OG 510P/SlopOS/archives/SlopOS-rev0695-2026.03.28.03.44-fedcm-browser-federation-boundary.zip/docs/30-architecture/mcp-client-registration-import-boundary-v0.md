# D-LLM MCP-client-registration import boundary v0 (client registration is not portable client identity/callback/policy truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP authorization client-registration/bootstrap choices — preregistration, Dynamic Client Registration (DCR), and Client ID Metadata Documents / URL-based `client_id` flows — are **provider-local authorization bootstrap only**. They do **not** create a portable software-identity oracle, redirect/callback authority, durable client-registration inventory/admin plane, trust-policy oracle, or authorization-continuation substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP client-registration semantics may be interpreted next to already-pinned auth-continuation, auth-result, browser-session, account-binding, and login-state boundaries.

## Posture (v0)

1) **Client registration stays authorization-server-local bootstrap only.**
   - MCP’s authorization flow may rely on preregistration, DCR, or Client ID Metadata Documents so an authorization server can decide how to trust one client.
   - Those mechanics remain provider-local/bootstrap-local only; they do **not** create a portable SlopOS client-registration API, client catalog, or client-admin plane.
   - This keeps D-LLM honest: imported auth bootstrap does not silently widen into a second software-install / connector-governance / policy-management substrate.

2) **Client ID Metadata Documents are descriptions, not portable identity truth.**
   - A URL-based `client_id`, fetched client metadata document, advertised client name, redirect URLs, or related metadata may help one authorization server evaluate one client.
   - They do **not** become a portable software-identity oracle, trusted-app registry, connected-app inventory, or account-binding truth on existing SlopOS seams.
   - The fact that a provider fetched or accepted one metadata document is therefore not portable proof that the client is globally trusted or stably bound anywhere else.

3) **Redirect URLs and callback prerequisites stay provider-local only.**
   - Redirect URLs, loopback/native redirect patterns, and metadata-document callback prerequisites may be necessary for a provider-owned OAuth flow.
   - They do **not** create a portable callback registration, redirect-back channel, deep-link reentry seam, or pending-auth continuation handle on reviewed SlopOS surfaces.
   - Existing callback, auth-continuation, and OpenURI boundaries stay authoritative instead of inheriting folklore from auth bootstrap metadata.

4) **Registration rows, fetched metadata, and trust policy stay provider-local live state only.**
   - DCR-created registrations, preregistered client rows, fetched metadata documents, trusted-domain allowlists, and selective allow/deny policies may exist for one authorization server.
   - They do **not** become a portable client inventory, tenant policy oracle, app-governance substrate, or durable approval artifact on existing SlopOS seams.
   - Likewise, revocation, expiry, or deny decisions about one registration remain provider-local live state rather than portable truth.

5) **No silent token/broker widening rides in through registration.**
   - Imported client-registration/bootstrap semantics do **not** authorize token passthrough, callback-result export, account selection, granted-scope export, or browser-session continuity by implication.
   - If an eventual reviewed SlopOS seam needs auth continuation, auth result, authorization context, account binding, or login state, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: registration metadata and trust bootstrap remain killable by policy and do not smuggle ambient browser/callback/token channels into existing surfaces.

6) **Security pressure stays local to the provider-owned auth path.**
   - MCP’s current authorization/security guidance explicitly calls out DCR operational limits, SSRF risk from fetching client metadata URLs, and confused-deputy risk around client IDs, redirect URIs, and consent cookies.
   - SlopOS therefore treats imported registration/bootstrap semantics as provider-local auth path machinery only, not as reusable client/admin/callback substrate meaning.
   - Any future native client-identity or callback broker would need an RFC-first seam with its own policy, mediation, and evidence story instead of inheriting trust from registration folklore.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit approvals, explicit callback/login boundaries, and explicit evidence artifacts.
   - Any future native client-registration / app-identity / callback workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP auth bootstrap helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `client_registration_handle`, `client_registration_list`, `client_metadata_fetch_result`, `trusted_client_registry`, `redirect_uri_registry`, or `callback_registration` substrate imported directly from MCP auth bootstrap.
- No rule that preregistration, DCR, or Client ID Metadata Document acceptance stands in for portable app trust, portable connected-app identity, or durable approval truth.
- No rule that redirect URLs or URL-based `client_id` flows become a portable auth-continuation, callback-result, or deep-link reentry substrate.
- No rule that registration/bootstrap metadata authorizes token passthrough, account-linking truth, granted-scope export, or browser-session continuity on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps auth continuations, callback results, browser sessions, granted scopes, linked accounts, and login state on separate explicit seams. Current MCP authorization now adds another nearby pressure surface: preregistration, optional Dynamic Client Registration, and a newer Client ID Metadata Documents / URL-based `client_id` flow intended to avoid the operational problems DCR creates in open client/server environments.

That is useful, but it is also exactly where hosts and wrappers start to over-read auth bootstrap as durable platform truth. Once that drift lands, metadata URLs start masquerading as app identity, redirect URIs start masquerading as callback authority, trusted-domain policy starts masquerading as portable governance truth, and one provider’s client-registration state starts looking like a reusable connected-app inventory.

Pinning the boundary now keeps the archive honest. Imported MCP client registration may remain a provider-local way to bootstrap one authorization path, but it does not get to redefine what client identity, callback authority, auth continuation, or durable trust/policy/account truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may interoperate with current MCP auth bootstrap mechanisms, but app identity, callback meaning, and durable connected-app truth still stay on explicit reviewed seams rather than URL-based client metadata folklore.
- **Cloud micro-VM substrate (B):** hosted agents may encounter many remote MCP servers and auth paths, but provider-owned registration/bootstrap state does not become tenant-stable callback, policy, or app-inventory substrate.
- **Embedded / separation appliance (C):** appliances can omit MCP auth bootstrap entirely or terminate it in a narrow provider shim without importing a generic client-registration / callback story they do not want.
- **Agent/automation OS (D):** this matters most here: imported client-registration helpers may smooth one provider-owned authorization path, but they do not become a second app-governance / callback / policy substrate beside explicit approvals, auth continuation, auth result, and account-binding seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_client_registration_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “client registration is not portable client identity/callback/policy truth” posture drifts (**EVID-2026-672**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-MCP-SEP-991`
- `REF-OAUTH-CLIENT-ID-METADATA`
- `REF-MCP-AUTH-SECURITY`
