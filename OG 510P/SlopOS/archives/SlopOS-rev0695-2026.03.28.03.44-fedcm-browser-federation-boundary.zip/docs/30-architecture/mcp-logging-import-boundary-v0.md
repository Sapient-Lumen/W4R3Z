# D-LLM MCP-logging import boundary v0 (logging notifications are not portable transcript/export truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-OBS / IF-OBS** seam: current MCP logging (client-driven "logging/setLevel" plus server-sent "notifications/message" carrying `level`, optional `logger`, and structured `data`) is **provider-local / request-local diagnostics only**. It does **not** create a portable CH-LOG v0 transcript plane, CH-OBS v0 export substrate, durable evidence stream, validator truth surface, or observation-admin plane on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP logging semantics may be interpreted next to already-pinned transcript, observation-export, and LLM-control cuts.

This doc is an **intentional singleton** today. It is listed in `boundary-family-map.md` until a broader reviewed imported-diagnostics family exists.

## Posture (v0)

1) **No portable transcript or export substrate in imported MCP logging.**
   - MCP logging remains **provider-local / request-local protocol mechanics** on **D-LLM / D-OBS / IF-OBS**.
   - Provider log notifications may help a host show local diagnostics for one integration, but they do **not** by themselves mint CH-LOG v0 transcript entries, CH-OBS v0 exports, replay evidence, or a second portable observation stream beside `transcript-contract.md` and `observation-export-posture-v0.md`.

2) **Log-level requests are provider-local filtering hints, not portable log-policy or admin authority.**
   - The MCP logging/setLevel request may tune what one provider chooses to emit.
   - That request does **not** become a portable retention policy, exporter configuration surface, observer-role grant, log-access token, or transcript-admin control on existing SlopOS seams.
   - Exact export policy, retention, redaction, and transcript structure remain local SlopOS choices already pinned on **IF-OBS**, **CH-LOG v0**, and **CH-OBSPOL**.

3) **Imported log messages do not widen into validator truth, evidence, or durable state.**
   - Imported `level`, optional `logger`, and structured `data` fields remain descriptive diagnostics from one provider.
   - They may aid debugging or operator UX, but they do **not** by themselves prove validator acceptance, policy state, action completion, current provider-owned live state, filesystem truth, network truth, or any reviewed receipt semantics on existing SlopOS seams.
   - Provider-emitted diagnostics remain subject to the archive's existing non-authoritative observation rule rather than becoming hidden approval basis or portable evidence truth.

4) **No silent retention/search/history folklore.**
   - Imported MCP logging does **not** imply durable retention, replayable history, global search, structured indexing, export eligibility, or transcript inclusion by default.
   - Any persistence, indexing, search, bundling, forwarding, or external shareability must still cross explicit local observation/export policy and tooling seams rather than inheriting folklore from provider log traffic.

5) **No hidden secret or internal-detail waiver.**
   - The MCP logging spec already says logs must omit secrets, PII, and attack-aiding internal detail.
   - SlopOS does not relax its own redaction or evidence posture because an upstream provider labeled something as a log message.
   - Imported diagnostic payloads therefore remain untrusted observational material subject to local redaction, truncation, rejection, or drop rather than automatic durable evidence.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: exact reviewed actions and the transcript/export seams that already own their own serialization and evidence contracts.
   - Any future reviewed portable diagnostics/log-stream surface must state its own conflict keys, commutativity conditions, retention/search model, export/privacy semantics, and evidence story explicitly rather than inheriting folklore from MCP logging.

## Phase 1 non-goals (explicitly deferred)

- No portable `log_stream`, `log_history`, `log_search`, `log_cursor`, `set_log_level`, `logger_catalog`, or `diagnostic_export` substrate imported directly from MCP logging.
- No rule that imported provider diagnostics can stand in for CH-LOG v0 transcript entries, CH-OBS v0 exports, CH-ACPOUT receipts, or local validator evidence.
- No adapter shortcut that treats provider log levels or logger names as transcript policy, export policy, or durable operator-facing audit taxonomy.
- No transcript-stable statement that one provider's `notifications/message` traffic created durable history, searchability, or replay evidence on existing SlopOS seams.

## Why this is worth pinning

The archive already has explicit reviewed meaning for transcripts and observation export: CH-LOG v0 is the replay/audit substrate, IF-OBS exports are bounded and policy-killable, and untrusted observations do not become approval or capability truth. MCP now supplies the next tempting convenience surface: a standard logging utility with client-driven verbosity control and structured provider log notifications.

That is useful, but it is also exactly where providers and hosts can start to smuggle in a second diagnostics story. Once a provider can emit `info` / `warning` / `error` plus arbitrary JSON data, those payloads quickly get treated as if they were durable transcript records, export-ready evidence bundles, or current-state truth.

Pinning the boundary now keeps the archive honest. Imported MCP logging may remain a local runtime convenience for one provider, but it does not get to redefine what transcript binding, observation export, retention/search, or replay evidence mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may show provider-local diagnostics without silently importing a second audit log, retention, or search plane.
- **Cloud micro-VM substrate (B):** hosted agents and control planes avoid mistaking provider-emitted diagnostics for tenant-stable evidence, exporter policy, or replay truth.
- **Embedded / separation appliance (C):** appliance builds can ignore MCP logging entirely or map it to local debugging UX without promising any portable transcript/export semantics.
- **Agent/automation OS (D):** agents may read provider-local diagnostic hints, but reviewed transcript/evidence/export truth still returns through explicit SlopOS seams rather than drifting into imported logging folklore.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam; the current cut is only the narrow MCP-logging import boundary.

If a second closely related imported-diagnostics boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/observation-export-posture-v0.md`
- `docs/30-architecture/transcript-contract.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_logging_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “logging notifications are not portable transcript/export truth” posture drifts (**EVID-2026-665**).

## References

- `REF-MCP-LOGGING`
- `REF-MCP-SPEC`
