# D-LLM MCP-auth-request-packaging import boundary v0 (PAR / Request Objects are not portable pending-auth / approval / policy truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported OAuth/MCP authorization-request packaging — the PAR endpoint (`pushed_authorization_request_endpoint`), PAR-only policy (`require_pushed_authorization_requests`), returned `request_uri` handles, Request Objects carried by value (`request`) or by reference (`request_uri`), `require_signed_request_object`, and adjacent request-object capability / algorithm metadata such as `request_parameter_supported`, `request_uri_parameter_supported`, `require_request_uri_registration`, `request_object_signing_alg_values_supported`, `request_object_encryption_alg_values_supported`, and `request_object_encryption_enc_values_supported` — is **provider-local authorization-request staging and packaging only**. It does **not** create a portable pending-auth handle, approval object, request-template cache, request-policy blob, or durable auth-state / connected-account substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported authorization-request packaging semantics may be interpreted next to already-pinned redirect, PKCE, auth-discovery, auth-metadata-fetch, auth-exact-match, auth-proof, auth-result, authorization-context, client-assertion, caller-auth-binding, and token-passthrough boundaries.

## Posture (v0)

1) **Imported pushed authorization request endpoints stay provider-local request staging only.**
   - RFC 9126 defines the PAR endpoint as a direct request path where a client pushes authorization-request payload and receives a `request_uri` reference back.
   - Imported `pushed_authorization_request_endpoint` and `require_pushed_authorization_requests` stay provider-local request staging policy only; they do **not** create a portable auth-request mailbox, durable pending-auth queue, callback-broker precursor, or connected-service bootstrap registry on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, auth-continuation, and auth-result boundaries stay authoritative instead of inheriting platform meaning from one provider's PAR deployment.

2) **Returned `request_uri` handles stay provider-local authorization-request references only.**
   - RFC 9126 returns a `request_uri` value that references pushed authorization-request data at one authorization server, and RFC 9101 treats `request_uri` as a Request Object reference that can itself bring URI-guessing, rewrite, timeout, and recursion risks.
   - Returned `request_uri` values remain provider-local authorization-request references only; they do **not** become portable pending-auth handles, resumable approval tickets, replayable browser-session tokens, or durable account-link / login-state truth on existing SlopOS seams.
   - Existing auth-continuation export, browser-session export, login-state export, and account-binding boundaries stay authoritative instead of inheriting platform meaning from one provider-issued request reference.

3) **Imported Request Objects stay provider-local authorization-request payloads only.**
   - RFC 9101 defines the `request` parameter as a Request Object JWT whose claims hold authorization-request parameters, and allows that Request Object to be sent by value or by reference.
   - Imported Request Objects stay provider-local authorization-request payloads only; they do **not** become portable approval objects, policy-signed consent receipts, request-template stores, signer truth, or generic auth-proof artifacts on existing SlopOS seams.
   - Existing authorization-context, auth-proof export, auth-result export, and client-assertion boundaries stay authoritative instead of inheriting platform meaning from one provider's request-packaging JWT.

4) **Imported request-packaging capability / algorithm metadata stay provider-local compatibility hints only.**
   - RFC 9126 and OpenID Discovery expose capability and policy fields such as `pushed_authorization_request_endpoint`, `require_pushed_authorization_requests`, `request_parameter_supported`, `request_uri_parameter_supported`, `require_request_uri_registration`, `request_object_signing_alg_values_supported`, `request_object_encryption_alg_values_supported`, and `request_object_encryption_enc_values_supported`; RFC 9101 also defines `require_signed_request_object` to force Request Object use.
   - Those fields remain provider-local compatibility and policy hints only; they do **not** become a portable request-packaging capability oracle, approval-basis truth, signer-policy substrate, or durable metadata cache truth on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, client-trust-policy, and auth-exact-match boundaries stay authoritative instead of inheriting platform meaning from one provider's request-packaging metadata menu.

5) **No silent pending-auth / approval / policy widening rides in through request packaging.**
   - Imported PAR and Request Object mechanics do **not** authorize portable request-object export, cross-provider request replay, generic approval-ticket storage, request-policy templating, or hidden auth-state continuation by implication.
   - A provider may require PAR or signed Request Objects for one authorization path, but that does **not** standardize a portable pending-auth handle, approval object, or policy blob on adjacent SlopOS seams.
   - If SlopOS ever needs a native approval-object, request-template, or auth-resume workflow, that work must arrive on those explicit seams and validators directly.

6) **Cross-JWT confusion remains closed.**
   - RFC 9101 explicitly warns that a Request Object can be repurposed as a client-authentication JWT unless implementers keep purposes distinct.
   - Imported Request Objects therefore remain provider-local authorization-request packaging only; they do **not** become portable client-auth assertions, signer proofs, or account-binding artifacts on existing SlopOS seams.
   - Existing client-assertion, auth-proof export, and identity/account boundaries stay authoritative instead of inheriting meaning from cross-JWT reuse folklore.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth libraries, PAR helpers, Request Object fetchers, hosted request-object stores, or metadata-driven request-packaging selectors must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient request-object hosting, hidden request-template caches, or implicit metadata fetches must fail closed for portable D-LLM auth semantics.

8) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local authorization request assembly, explicit redirect/PKCE/auth-result boundaries, and explicit evidence artifacts.
   - Any future native auth-resume, approval-object, or request-template workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported PAR endpoints, `request_uri` references, or Request Object metadata.

## Phase 1 non-goals (explicitly deferred)

- No portable `pushed_authorization_request_endpoint`, `require_pushed_authorization_requests`, or equivalent auth-request staging substrate imported directly from MCP/OAuth helpers.
- No portable `request_uri` / Request Object handle / auth-resume / approval-ticket seam imported directly from provider-local authorization flows.
- No portable `request` Request Object / signed request JWT / encrypted request JWT / request-template store / policy blob substrate imported directly from provider-local authorization packaging.
- No portable rule that `request_parameter_supported`, `request_uri_parameter_supported`, `require_request_uri_registration`, `require_signed_request_object`, or request-object signing/encryption metadata stand in for durable approval-basis, signer policy, or cross-provider capability truth.

## Why this is worth pinning

The archive already keeps redirect handling, PKCE, verifier keys, token verification, token teardown, auth-proof export, auth-result export, and pending-auth export on separate explicit seams. But current OAuth ecosystems still add another adjacent surface: **authorization-request packaging**, where one provider may require PAR, issue a `request_uri` reference, insist on signed Request Objects, and advertise request-object capability/algorithm metadata.

That looks like harmless transport detail, but it is exactly where invisible substrate grows. Once wrappers and agents start seeing PAR endpoints and Request Object JWTs, `request_uri` becomes “the platform's resumable approval token”, a signed Request Object becomes “our portable approval object”, and request-object metadata becomes “our policy/capability oracle”.

Pinning the boundary now keeps the archive honest. Imported authorization-request packaging may remain a provider-local way to stage and protect one authorization request, but it does not get to redefine pending-auth handles, approval objects, request-policy blobs, signer truth, or durable connected-account/auth-state meaning on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with providers that require PAR or signed Request Objects, but provider-local auth request packaging still does not become a portable browser-resume, approval-ticket, or policy-blob story.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted gateways will be tempted to centralize `request_uri` handles and signed Request Object templates, but those helpers do not become tenant-stable approval-object or auth-resume substrate by default.
- **Embedded / separation appliance (C):** appliances can omit PAR/JAR entirely or terminate them in a narrow shim without importing a generalized request-object / auth-resume subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported `request_uri` handles and Request Object JWTs are exactly the kind of structure agents will over-read as durable auth workflow state unless the archive pins them provider-local now.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Dedicated checker:** `tools/check_mcp_auth_request_packaging_import_boundary.py`
- **Evidence id:** `EVID-2026-689`
- **What it fails on:** missing family membership, missing discovery wiring, or wording drift that would let imported PAR / Request Object semantics silently regrow a portable pending-auth handle, approval object, request-template cache, request-policy blob, or durable auth-state / connected-account substrate.

## References

- REF-MCP-AUTHORIZATION.
- REF-RFC9126-PAR.
- REF-RFC9101-JAR.
- REF-RFC8414-AS-METADATA.
- REF-OPENID-DISCOVERY.
