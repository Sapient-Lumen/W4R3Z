# D-LLM / D-POLICY / IF-ACP DID document import boundary v0 (DID documents are not portable controller / trust / endpoint / current-user truth)

Purpose: pin one compact Phase-1 rule on the existing **D-LLM / D-POLICY / IF-ACP** seams: imported DID Core / DID Resolution semantics — DID documents, resolution metadata, DID URL dereferencing results, DID controllers, verification methods, verification relationships, service endpoints, `alsoKnownAs` aliases, version/history metadata, and DID-method / registry-adjacent type labels — are **provider-local identifier-resolution and proof-routing only**. They do **not** create a portable issuer/account registry, trust root, signer inventory, endpoint-discovery plane, callback/browser/listen authority, approval-basis object, durable connected-wallet/account truth, or durable subject/current-user truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported DID/identifier artifacts may be interpreted next to already-pinned wallet-presentation, credential-issuance, credential-status, verification-policy-selection, identity-claim, account-binding, and observation/export cuts.

## Posture (v0)

1) **Imported DID documents stay provider-local identifier-control descriptions only.**
   - DID Core says each DID document can express cryptographic material, verification methods, or services that let a DID controller prove control of a DID and support interactions associated with the DID subject.
   - Imported DID documents, `id`, `controller`, `alsoKnownAs`, verification relationships (`authentication`, `assertionMethod`, `keyAgreement`, `capabilityInvocation`, `capabilityDelegation`), and adjacent core properties remain provider-local identifier-control descriptions only; they do **not** become a portable identity/profile registry, issuer/account registry, approval-basis object, trust root, or durable current-user/current-permission truth on existing SlopOS seams.
   - Existing identity-claim, account-binding, verification-policy-selection, and approval-basis seams stay authoritative instead of inheriting portable truth from one resolver's DID-document view.

2) **Imported verification methods and controller claims stay provider-local proof-routing only.**
   - DID Core and the DID Specification Registries standardize verification-method relationships and type labels, but they do not turn one resolver's method inventory into a portable signer registry or enduring controller truth.
   - Imported verification methods, controller references, method-type labels, multikey/JWK-style material, fragments, and verification-relationship attachments remain provider-local proof-routing only; they do **not** become a portable signer inventory, issuer-policy selector, account-binding proof, workload identity plane, or durable current-controller truth on existing SlopOS seams.
   - Existing signature-verification, federation, identity-assurance, and account-binding seams stay authoritative instead of inheriting durable approval or signer meaning from one DID resolver output.

3) **Imported services and DID-URL dereferencing results stay provider-local endpoint hints only.**
   - DID Core says service endpoints enable trusted interactions, and DID Resolution says DID controllers can independently change resources and service endpoints over time while DID URLs continue to dereference.
   - Imported `service` entries, service-endpoint URLs, dereferenced subordinate resources, method-specific service types, and DID-URL dereferencing results remain provider-local endpoint hints only; they do **not** become a portable callback registration, browser/session target, listen address, network-lease selector, document/resource import path, or durable connected-endpoint truth on existing SlopOS seams.
   - Existing callback, network-lease, resource/document, and browser-adjacent seams stay authoritative instead of inheriting ambient endpoint authority from DID-linked resources.

4) **Imported resolution metadata, version/history data, and resolver outcomes stay provider-local resolver results only.**
   - DID Core defines resolution as returning a DID document plus metadata, and DID Resolution adds version/time/auditability pressure, URL dereferencing results, and resolver-owned metadata/errors.
   - Imported resolver metadata, content-type hints, version/time selectors, historical-state results, dereferencing metadata, and method-specific error/status outcomes remain provider-local resolver results only; they do **not** become a portable audit ledger, live-control oracle, freshness proof, trust decision, or durable historical authority on existing SlopOS seams.
   - Existing attestation, evidence, verification-verdict, and observation-export seams stay authoritative instead of inheriting durable proof meaning from one resolver's historical or current metadata.

5) **No silent identifier/controller/endpoint widening rides in through DID imports.**
   - Imported DID documents, verification methods, controllers, services, aliases, resolver metadata, and dereferencing outputs do **not** authorize portable “this controller currently controls this subject” truth, portable endpoint authority, portable account linkage, portable signer/trust-root meaning, portable approval meaning, or durable current-user truth by implication.
   - A verifier may use DID documents plus local policy to route one proof check or one resource lookup, but that does **not** standardize a portable identifier-registry or endpoint-authority plane on D-LLM, D-POLICY, IF-ACP, or adjacent identity/account/network seams.
   - If SlopOS ever needs native DID resolution, controller history, endpoint discovery, or durable DID evidence, that work must arrive as an RFC on explicit schemas, validators, conflict keys, evidence hooks, cache/freshness rules, and kill switches rather than inheriting folklore from resolver outputs.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of DID resolution, DID-URL dereferencing, DID-method plugins, service-endpoint fetches, or resolver caches must be killable by policy and must not create authority via hidden paths, env vars, implicit network access, silently persistent resolver caches, or ambient method registries.
   - A compat layer that cannot proceed without hidden DID-method routing, implicit dereferencing, silent cache reuse, or hidden service-endpoint fetches must fail closed for portable SlopOS authority semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: IF-ACP validation, exact action bytes, explicit capabilities/approvals, explicit D-POLICY handles/bundles, explicit verifier-owner policy choice, and explicit network/document/resource grants.
   - Any future native DID import, resolver cache, controller-history, or DID-linked endpoint workflow must state its own conflict keys, commutativity conditions, serialization point, cache/freshness semantics, and evidence story explicitly rather than inheriting them from imported DID documents or resolver outputs.

## Phase 1 non-goals (explicitly deferred)

- No portable DID-controller / DID-subject / `alsoKnownAs` truth imported directly from DID documents or DID resolution.
- No portable rule that DID verification methods, controller fields, or registry type labels stand in for CH-ACP, account-binding, identity-claim export, issuer selection, or signature-verification policy truth.
- No portable service-endpoint discovery / callback registration / browser handoff / network-lease selection / resource-import surface imported from DID services or DID-URL dereferencing.
- No portable rule that DID-resolution history/version metadata stands in for attestation, audit, freshness, or durable evidence truth.

## Why this is worth pinning

This is the next small, high-leverage cut after OpenID4VP, OpenID4VCI, and VC status. Once wallet presentation, credential issuance, and credential validity are pinned as provider-local only, the next tempting shortcut is “fine, trust the DID document.” In practice that means over-reading DID controllers, verification methods, services, aliases, dereferenced resources, and historical-resolution metadata as if they were portable signer inventories, trust roots, endpoint registries, connected-wallet truth, or durable current-user truth.

DID ecosystems are useful and increasingly concrete. DID Core standardizes DID documents, verification relationships, and service entries; DID Resolution adds dereferencing and historical-state pressure; the DID Spec Registries keep global method/type/property names flowing. That is exactly why the archive should pin their meaning early: imported DID/identifier material is a valuable compatibility surface, but it does not get to redefine identity truth, endpoint authority, signer/trust meaning, or durable account/user state on SlopOS.

Pinning the boundary now keeps the archive honest. Imported DID documents may remain a provider-local way to route one proof check or one endpoint lookup, but they do not become a portable identifier registry, signer/trust plane, callback/browser authority surface, or durable current-user truth inside SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation agents may interoperate with digital-ID wallets or enterprise identifiers, but imported DID documents and services do not become a portable “this is the user” card, endpoint registry, or approval proof.
- **Cloud micro-VM / hosted compute substrate (B):** hosted control planes may resolve DIDs while verifying onboarding or tenant credentials, but imported DID/controller/service data does not become a portable issuer/account graph, trust root, or endpoint-control substrate.
- **Embedded / separation-kernel-ish appliance (C):** appliances may compile in a narrow resolver adapter, but DID resolution remains sealed compat only and policy-killable, with no hidden service fetch, cache, or method plugin becoming native authority.
- **Agent / automation OS (D):** first-class LLM/automation stacks are exactly where DID documents are easiest to over-read as “the resolver says this endpoint/key/user is current, therefore allow”; this boundary keeps agent memory/tooling from silently normalizing that widening.

## Family status (Phase 1)

This doc is a member of the closed verifiable-credential ecosystem companion family indexed by `verifiable-credential-ecosystem-boundary-index.md`.
It stays there with `openid4vp-import-boundary-v0.md`, `openid4vci-import-boundary-v0.md`, and `verifiable-credential-status-import-boundary-v0.md` so presentation, issuance, status, and DID-resolution meaning pins remain discoverable together.
If future reviewed wallet / credential / DID-import cuts appear, add them to that family **in the same revision** rather than letting them regrow as adjacent singletons.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/verifiable-credential-ecosystem-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Evidence id:** `EVID-2026-704`
- `tools/check_did_document_import_boundary.py` fails `make lint` if this boundary, its family membership, discovery wiring, or its “DID documents are not portable controller / trust / endpoint / current-user truth” posture drifts.
- Attached to existing assurance surfaces: **I-LLM-1**, **PO-ACT-VALIDATE**, **PO-POLICY-NONAMP**.

## References

- `REF-W3C-DID-CORE`
- `REF-W3C-DID-RESOLUTION`
- `REF-W3C-DID-SPEC-REGISTRIES`
