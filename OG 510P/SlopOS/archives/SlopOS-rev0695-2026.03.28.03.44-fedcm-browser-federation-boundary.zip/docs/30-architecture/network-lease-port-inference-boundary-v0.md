# D-NETLEASE port-inference boundary v0 (no portable default-port / service-name seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed network authority stays **explicitly port-shaped where numeric endpoints are requested**, and it does **not** become a portable default-port, URI-scheme, or service-name lookup surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable default-port / service-name seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry reviewed/granted numeric `port` / `port_range` values when they are explicitly present.
   - They do **not** grow a portable `default_port`, `implicit_port`, `uri_scheme`, `scheme_default_port`, `service_name`, `getservbyname`, `well_known_port`, `/etc/services`, `iana_service_name`, or equivalent hidden port-derivation surface.
   - Phase 1 portable truth is therefore: **which exact numeric port or port range was reviewed/granted, if any** — not which ambient runtime guessed 80, 443, `domain`, `smtp`, or another well-known port behind the caller's back.

2) **Connect/listen requests with numeric endpoint predicates stay explicitly port-shaped.**
   - For `kind in {connect, listen}` with `dest.kind in {dns_name, dns_suffix, ip_prefix}`, Phase 1 requires exactly one of `dest.port` or `dest.port_range`.
   - Omitting both MUST reject before effect rather than being repaired by `proto`-based defaults, higher-layer protocol assumptions, URL parsing, or library-specific service lookup.
   - This keeps reviewed numeric endpoint authority byte-stable across A/B/C/D and prevents `tls` / `quic` reachability from quietly inheriting HTTP, WebSocket, or other higher-layer default-port folklore.

3) **`service` labels are local policy classes, not service-name lookup.**
   - `dest.kind = service` remains a bounded local policy label such as `updates` or `telemetry`.
   - It is **not** a portable `/etc/services` / NSS / IANA service-name query, and it does not promise one transcript-stable numeric port mapping across machines, images, or product shapes.
   - If a portal or product profile chooses to map a local service label to one or more ports, that mapping stays portal-local policy unless a future explicit surface exports it.

4) **Portless reviewed naming does not become URI semantics.**
   - Reviewed `dns_name` / `dns_suffix` predicates remain naming predicates only.
   - They do **not** by themselves imply `http`, `https`, `ws`, `wss`, or any other URI scheme with registered default ports.
   - If a future product truly needs reviewed URI/scheme authority or portable default-port derivation, it must pay for an explicit future seam rather than inheriting that behavior from browser, SDK, or CLI folklore.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit URI/scheme or service-name surface must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting hidden port-derivation behavior.

6) **If reviewed default-port or service-name semantics matter, pay for a new seam explicitly.**
   - Future product shapes may want transcript-visible reviewed URI/scheme authority, service-name lookup, or well-known-port policy.
   - That work must return **RFC-first** with its own schema/receipt family, discovery/testing story, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because common stacks often guess ports.

## Phase 1 non-goals (explicitly deferred)

- No portable `scheme`, `default_port`, `service_name`, `iana_service_name`, `/etc/services`, or `getservbyname` field on CH-NETREQ or CH-NETLEASE.
- No transcript-stable claim that an accepted `dns_name` / `dns_suffix` / `ip_prefix` request without `port` or `port_range` can be repaired by HTTP/HTTPS/WebSocket defaults, browser URL parsing, or libc service lookup.
- No generic portal/settings API that turns D-NETLEASE into a well-known-port broker, URI parser, or service-name registry frontend.
- No ambient promise that `portal.net.request` will silently import port defaults from SDKs, browsers, CLIs, `/etc/services`, or the IANA service-name registry.

## Why this is worth pinning

The archive already pinned exact-name semantics, DNS-query semantics, and service-binding semantics, but one quiet ambiguity remained: **what happens when a reviewed network request names a host-ish thing without an explicit port?** Ecosystems are full of tempting fallback behavior — `https` defaults to 443, `http` to 80, `getaddrinfo()` can translate service names to ports via `services(5)`, and runtimes often mix URL parsing with socket setup.

Those are real semantics, not harmless residue. Pinning the boundary now keeps D-NETLEASE honest: **reviewed network authority either names an explicit numeric port/range or uses a local policy label**. It does not silently inherit URI-scheme defaults or service-name lookup folklore from the host runtime.

## Profile effect (A–D)

- **Secure workstation (A):** workstation apps may still use browser/SDK stacks locally, but reviewed leased-network meaning stays on explicit numeric ports or local service labels rather than hidden scheme/service lookup.
- **Cloud micro-VM substrate (B):** hosted compute keeps network authority byte-stable across images and guest stacks by refusing implicit port repair on exact host/IP predicates.
- **Embedded / separation appliance (C):** appliance builds keep outbound policy auditable by requiring explicit numeric ports unless the product defines a local service label.
- **Agent/automation OS (D):** agents/tools cannot confuse “connect to this host” with “connect to whatever default port this library guesses”; retries, receipts, and review prompts stay stable for LLM workflows.

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETREQ-VALIDATE**, **PO-NETLEASE-VALIDATE**, **PO-ACP-NET-REQUEST**)

CI drift gate:
- `tools/check_network_lease_port_inference_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable default-port / service-name seam / explicit numeric-port rule / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-647**).

## References

- REF-MAN7-GETADDRINFO.
- REF-MAN7-SERVICES.
- REF-RFC9205-HTTP-BCP.
- REF-IANA-SERVICE-NAMES.
