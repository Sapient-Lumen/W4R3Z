# D-NETLEASE service-binding boundary v0 (no portable SRV / SVCB / HTTPS service-binding seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed exact-name networking authority remains **host-address reachability plus resolver binding**, and it does **not** become a portable SRV / SVCB / HTTPS service-binding, alternate-endpoint, or endpoint-parameter surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable SRV / SVCB / HTTPS service-binding seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed exact-name predicate plus the granted resolver binding.
   - They do **not** grow a portable `srv_service`, `srv_proto`, `rrtype`, `svcb`, `https_rr`, `service_binding`, `alternate_endpoint`, `ipv4hint`, `ipv6hint`, `echconfig`, `alpn_set`, `port_hint`, `priority`, `weight`, or equivalent service-discovery / endpoint-parameter surface.
   - Phase 1 portable truth is therefore: **which exact name predicate was reviewed/granted, through which resolver binding** — not which service-binding RRset, alias mode, endpoint hint set, or bootstrap parameter bundle happened to be followed on one machine.

2) **Reviewed exact-name authority does not become service-binding authority.**
   - A reviewed `dns_name` / `dns_suffix` predicate authorizes host-address reachability decisions only.
   - It does **not** by itself authorize following SRV targets, SVCB alias chains, HTTPS RR alternate endpoints, service-mode parameter sets, or future service-binding-style indirections that can steer traffic toward different names, ports, or bootstrap metadata.
   - If a product truly wants transcript-visible reviewed service-discovery semantics, it must pay for a future explicit seam rather than inheriting them from modern DNS resolver/client folklore.

3) **Alternate endpoints and endpoint parameters stay portal-local.**
   - Resolver-side or portal-side use of SRV, SVCB, HTTPS, or similar records may exist as implementation detail.
   - But any discovered alternate origin name, port remap, hint address set, ALPN hint, ECH bootstrap material, or future endpoint-parameter bundle stays **portal-local** unless a future surface explicitly exports it.
   - Historical CH-NETREQ / CH-NETLEASE bytes therefore do **not** prove that every service-binding-derived endpoint or parameter set was reviewed/granted.

4) **Address resolution stays host-address oriented, not service-discovery oriented.**
   - The Phase 1 `kind=dns` seam remains address-resolution-only: name-shaped and portless.
   - Generic RR-type/class queries, raw replies, and resolver transport policy are already out of scope; this boundary further pins that host-address resolution does not silently widen into service discovery / alternate-endpoint selection just because modern ecosystems use SRV or SVCB/HTTPS for bootstrapping.
   - This keeps D-NETLEASE honest across A/B/C/D: reviewed network authority means exact host predicate + resolver binding, not “whatever service-binding indirections the current stack followed.”

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit service-discovery / alternate-endpoint surface must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting hidden resolver/client behavior.

6) **If reviewed service-binding semantics matter, pay for a new seam explicitly.**
   - Future product shapes may want transcript-visible reviewed SRV targets, SVCB/HTTPS alias following, endpoint-parameter receipts, or service-mode policy.
   - That work must return **RFC-first** with its own schema/receipt family, privacy posture, discovery/testing story, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because service-binding records exist in the ecosystem.

## Phase 1 non-goals (explicitly deferred)

- No portable SRV target/service/proto, SVCB/HTTPS RR, alias-mode, service-mode, endpoint-priority, or parameter-bundle field on CH-NETREQ or CH-NETLEASE.
- No transcript-stable claim that an accepted name-shaped request or issued lease also approves every SRV/SVCB/HTTPS-derived alternate endpoint, port remap, hint address set, ALPN hint, or ECH bootstrap bundle some local stack might follow.
- No generic portal/settings API that turns D-NETLEASE into a service-discovery broker, SVCB interpreter, or HTTPS-bootstrap policy plane.
- No ambient promise that `portal.net.request` will silently import service-binding semantics from browsers, CDNs, resolver libraries, or enterprise DNS products.

## Why this is worth pinning

The archive already pinned `kind=dns` to address-resolution-only, exact reviewed names to exact predicates, and reviewed exact names to one canonical ASCII form. The next quiet drift is to treat the same reviewed exact name as if it also carried **whatever service-binding discovery behavior the local stack prefers** — SRV targets, SVCB alias chains, HTTPS RR endpoint parameters, or bootstrap bundles like ECH/SVCB.

Primary specs treat those as distinct surfaces. SRV is a dedicated service-location RR, while SVCB/HTTPS records explicitly bind service names to alternate endpoints and parameter sets rather than merely returning host addresses. Pinning the boundary now keeps D-NETLEASE honest: **reviewed exact-name address reachability is one seam; reviewed service-binding / alternate-endpoint semantics would be another future seam if we ever truly need it.**

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use modern resolver/browser stacks locally, but reviewed leased-network meaning stays on exact host predicates rather than silently inheriting service-binding discovery behavior.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound naming explicit without promising one portable SRV/SVCB/HTTPS interpretation across guest images, sidecars, or resolver stacks.
- **Embedded / separation appliance (C):** appliance builds can keep reviewed networking small and auditable by rejecting service-binding complexity unless a product explicitly pays for it.
- **Agent/automation OS (D):** agents/tools cannot confuse “this exact name was reviewed” with “all SRV/SVCB/HTTPS-discovered alternates are blessed”; retries, receipts, and policy review stay byte-stable for LLM workflows.

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-lease-dns-query-boundary-v0.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETREQ-VALIDATE**, **PO-NETLEASE-VALIDATE**, **PO-ACP-NET-REQUEST**)

CI drift gate:
- `tools/check_network_lease_service_binding_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable SRV/SVCB/HTTPS seam / exact-name-is-not-service-binding-authority / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-646**).

## References

- REF-RFC2782-SRV.
- REF-RFC9460-SVCB.
- REF-RFC9848-ECH-SVCB.
