# D-LLM MCP-DPoP import boundary v0 (auth DPoP is not portable signer / nonce / token-binding truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP security/authorization direction that would add or import OAuth DPoP sender-constraining — DPoP proof JWTs in the `DPoP` header, embedded public keys, replay/nonces, DPoP-bound token metadata, and adjacent authorization-server/client metadata — is **provider-local sender-constraining and verifier machinery only**. It does **not** create a portable signer plane, proof cache, nonce cache, token-binding oracle, or current-account/session substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported DPoP sender-constraining semantics may be interpreted next to already-pinned auth-proof export, auth-discovery, auth-metadata-fetch, client-registration, client-credentials, JWKS, token-introspection, token-revocation, token-passthrough, auth-result, login-state, and identity/account boundaries.

## Posture (v0)

1) **Imported DPoP proof JWTs stay provider-local sender-constraining only.**
   - MCP’s current roadmap says sponsored DPoP work is underway, and RFC 9449 defines DPoP as a signed proof JWT carried in the `DPoP` HTTP header so a client can prove possession of a key when talking to OAuth endpoints and protected resources.
   - Those proof JWTs remain provider-local sender-constraining only; they do **not** create a portable signing service, auth-proof export seam, callback/result artifact, or durable approval/evidence object on existing SlopOS seams.
   - Existing auth-proof export, auth-result, and caller-auth-binding boundaries stay authoritative instead of inheriting platform meaning from one imported proof JWT.

2) **Imported proof fields and embedded JWK stay provider-local replay/request validation only.**
   - RFC 9449 requires DPoP proof JWTs to carry `typ=dpop+jwt`, an asymmetric `alg`, an embedded public `jwk`, and claims such as unique `jti`, `htm`, `htu`, `iat`, plus `ath` and `nonce` when applicable.
   - Those fields remain provider-local replay/request validation only; they do **not** become a portable key registry, request-signing substrate, replay ledger, current-URL/method truth source, or token-binding oracle on existing SlopOS seams.
   - Existing auth-proof export, JWKS, auth-result, and token-introspection boundaries stay authoritative instead of inheriting platform meaning from one provider’s proof layout.

3) **Imported `DPoP-Nonce` challenges stay provider-local live anti-replay only.**
   - RFC 9449 defines `use_dpop_nonce` plus the `DPoP-Nonce` response header, allowing authorization servers and resource servers to demand a recent nonce and to rotate that nonce over time.
   - Those nonce challenges and rotations remain provider-local live anti-replay only; they do **not** create a portable nonce cache, pending-auth continuation handle, browser/header-exposure policy surface, or durable login/session truth on existing SlopOS seams.
   - Existing auth-continuation, login-state, auth-teardown, and evidence boundaries stay authoritative instead of inheriting platform meaning from one nonce challenge or retry loop.

4) **Imported DPoP-bound token metadata stays provider-local verifier input only.**
   - RFC 9449 defines authorization-server metadata `dpop_signing_alg_values_supported`, client metadata `dpop_bound_access_tokens`, DPoP `token_type`, and `cnf.jkt` thumbprint confirmation for DPoP-bound tokens, including token introspection responses.
   - Those metadata and token-binding signals remain provider-local verifier input only; they do **not** become a portable signer-capability oracle, token-class taxonomy, client key registry, connected-service truth, or durable current-user/session substrate on existing SlopOS seams.
   - Existing auth-discovery, client-registration, JWKS, token-introspection, and client-credentials boundaries stay authoritative instead of inheriting platform meaning from one provider’s DPoP metadata profile.

5) **No silent signer / proof / replay / account widening rides in through DPoP.**
   - Imported DPoP handling does **not** authorize portable proof minting, key export, account selection, current-user export, token relay, or generic external-service signing by implication.
   - A successful DPoP step may let one provider continue one authorization path, but it does **not** standardize portable signer/proof/replay/account semantics on adjacent SlopOS seams.
   - If SlopOS ever needs a native auth-proof broker, replay cache policy surface, signer registry, or token-binding workflow, that work must arrive on those explicit seams and validators directly.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth libraries, DPoP proof builders, nonce stores, key caches, browser header exposure workarounds, or token-binding helpers must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient private keys, hidden nonce caches, or implicit proof-signing egress must fail closed for portable D-LLM auth semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local request verification, proof validation, anti-replay state, and explicit reviewed result/evidence seams.
   - Any future native signer/proof/replay workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported DPoP helpers, nonce retries, or proof caches.

## Phase 1 non-goals (explicitly deferred)

- No portable `DPoP` proof JWT, proof-signing helper, `jti` replay ledger, `ath` token-binding service, `cnf.jkt` registry, or equivalent signer/proof substrate imported directly from MCP/OAuth helpers.
- No rule that `typ`, `alg`, embedded `jwk`, `jti`, `htm`, `htu`, `iat`, `ath`, or `nonce` stand in for portable signer identity, request-verdict truth, replay-proof evidence, or token-binding/account truth.
- No rule that `DPoP-Nonce`, `use_dpop_nonce`, retry loops, or header-exposure guidance stand in for portable pending-auth, browser/header policy, or durable session/login-state semantics.
- No rule that `dpop_signing_alg_values_supported`, `dpop_bound_access_tokens`, DPoP `token_type`, or `cnf.jkt` stand in for portable signer-capability truth, client-key governance, connected-service truth, or durable current-user/session semantics.

## Why this is worth pinning

The archive already keeps auth-proof export, client bootstrap, verifier keys, token introspection, token revocation, token passthrough, and login/account semantics on separate explicit seams. But current MCP roadmap work now puts another adjacent pressure surface in flight: **DPoP sender-constraining**, including proof JWTs, embedded public keys, nonce/replay handling, and DPoP-bound token metadata.

That looks like a narrow security hardening detail, but it is exactly where hidden substrate grows. Once wrappers and agents see signed DPoP proofs, cached nonces, replay windows, `cnf.jkt` thumbprints, and DPoP-only token types next to existing MCP auth flows, “provider-local sender constraint” drifts into “the platform can sign auth proofs”, “the host owns a reusable external-service key”, “this cache is our replay ledger”, or “this bound token proves who is currently connected”.

Pinning the boundary now keeps the archive honest. Imported DPoP may remain a provider-local way to sender-constrain one auth path, but it does not get to redefine signer authority, replay state, token-binding truth, connected-service truth, or durable current-account/session semantics on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with providers that adopt DPoP, but provider-local proof signing and nonce/replay handling still do not become a portable signer or browser/session substrate.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted workers and gateways will be tempted to centralize DPoP keys/nonces for convenience, but those caches do not become tenant-stable signer, account, or session substrate by default.
- **Embedded / separation appliance (C):** appliances can omit DPoP entirely or terminate it in a narrow shim without importing a generalized signer, replay cache, or token-binding subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported DPoP helpers may help one provider-owned auth path proceed, but they do not become a second signer/proof/account substrate beside explicit auth-proof, auth-result, login-state, and account-binding seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_dpop_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “auth DPoP is not portable signer / nonce / token-binding truth” posture drifts (**EVID-2026-687**).

## References

- `REF-MCP-ROADMAP-2026`
- `REF-RFC9449-DPOP`
- `REF-MCP-AUTHORIZATION`
- `REF-MCP-SECURITY-BEST-PRACTICES`
