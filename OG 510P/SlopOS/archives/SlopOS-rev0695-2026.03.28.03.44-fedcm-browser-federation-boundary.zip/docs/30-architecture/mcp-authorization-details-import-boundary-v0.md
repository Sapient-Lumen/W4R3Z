# D-LLM MCP-authorization-details import boundary v0 (RAR `authorization_details` are not portable approval / policy / grant truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported OAuth/MCP Rich Authorization Request material — `authorization_details`, per-object `type`, common fields such as `actions`, `locations`, `datatypes`, `identifier`, and `privileges`, advertised `authorization_details_types_supported`, granted `authorization_details` returned in token or introspection responses, and emerging metadata/error-signaling surfaces such as `authorization_details_types_metadata_endpoint`, `authorization_details_types_metadata`, and `insufficient_authorization_details` — is **provider-local fine-grained authorization description and grant-shaping only**. It does **not** create a portable approval object, policy blob, entitlement registry, grant-template store, or durable connected-account / login-state substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported fine-grained authorization semantics may be interpreted next to already-pinned authorization-context, auth-request-packaging, auth-result, auth-proof, auth-teardown, account-binding, and login-state boundaries.

## Posture (v0)

1) **Imported `authorization_details` stay provider-local fine-grained authorization descriptions only.**
   - RFC 9396 defines `authorization_details` as a structured parameter for carrying fine-grained authorization data in OAuth messages, explicitly beyond coarse `scope` strings.
   - Imported `authorization_details` remain provider-local authorization descriptions only; they do **not** become portable approval objects, generic policy blobs, durable entitlements, or workflow-stable permission manifests on existing SlopOS seams.
   - Existing authorization-context export, auth-result export, and account-binding boundaries stay authoritative instead of inheriting platform meaning from one provider's fine-grained grant object.

2) **Imported per-object `type` and common RAR fields stay provider-local object vocabulary only.**
   - RFC 9396 defines per-object `type` plus common fields such as `actions`, `locations`, `datatypes`, `identifier`, and `privileges`, while also allowing type-specific extension fields.
   - Imported `type`, `actions`, `locations`, `datatypes`, `identifier`, `privileges`, and provider-specific extension keys remain provider-local request/grant vocabulary only; they do **not** become a portable capability taxonomy, policy DSL, account-resource inventory, or approval-basis language on existing SlopOS seams.
   - Existing CH-POLICY / CH-ACP / authorization-context seams stay authoritative instead of inheriting native SlopOS semantics from one provider's JSON grant dialect.

3) **Imported `authorization_details_types_supported` stays provider-local compatibility metadata only.**
   - RFC 9396 defines `authorization_details_types_supported` in authorization-server metadata to advertise supported fine-grained authorization object types.
   - Imported `authorization_details_types_supported` remains provider-local compatibility metadata only; it does **not** become a portable grant-capability oracle, entitlement registry, or durable connected-service feature contract on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, and auth-exact-match boundaries stay authoritative instead of inheriting platform meaning from one provider's supported-type list.

4) **Granted `authorization_details` in token and introspection responses stay provider-local token-rights descriptions only.**
   - RFC 9396 requires token responses to return granted `authorization_details` and registers `authorization_details` for token introspection responses as the rights of the access token.
   - Granted `authorization_details` attached to token or introspection responses remain provider-local token-rights descriptions only; they do **not** become a portable live grant ledger, durable approval receipt, current-account truth, or cross-provider authorization cache on existing SlopOS seams.
   - Existing auth-result, login-state, authorization-context, and evidence seams stay authoritative instead of inheriting durable platform meaning from one verifier or token issuer.

5) **Imported RAR metadata and inadequate-details signaling stay provider-local discovery/retry hints only.**
   - The active OAuth RAR metadata draft defines machine-readable metadata such as `authorization_details_types_metadata_endpoint`, `authorization_details_types_metadata`, `required_types`, and a `WWW-Authenticate` error `insufficient_authorization_details` with optional actionable response bodies.
   - Imported RAR metadata endpoints, type schemas/examples, required-type expressions, and inadequate-details errors remain provider-local discovery and retry hints only; they do **not** become a portable approval policy oracle, request-template store, grant-negotiation workflow, or hidden planning substrate on existing SlopOS seams.
   - Existing auth-request-packaging, approval-basis, and workflow seams stay authoritative instead of inheriting platform meaning from one provider's RAR metadata/error surface.

6) **No silent approval / policy / grant widening rides in through RAR.**
   - Imported RAR objects do **not** authorize portable policy compilation, cross-provider grant replay, durable approval-object storage, or hidden account/resource entitlement inference by implication.
   - A provider may require fine-grained JSON grant descriptions for one authorization path, but that does **not** standardize a portable approval object, policy blob, or entitlement substrate on adjacent SlopOS seams.
   - If SlopOS ever needs native fine-grained approval objects or policy-carrying grant descriptors, that work must arrive on those explicit seams and validators directly.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth libraries, RAR helpers, request builders, metadata fetchers, or schema validators must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient grant templates, hidden policy translation, or implicit schema fetches must fail closed for portable D-LLM auth semantics.

8) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local authorization request assembly, explicit auth-result and authorization-context seams, and explicit evidence artifacts.
   - Any future native fine-grained approval-object, grant-negotiation, or policy-carrying workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported `authorization_details` JSON.

## Phase 1 non-goals (explicitly deferred)

- No portable `authorization_details` / RAR-object / approval-object / entitlement-manifest substrate imported directly from provider-local authorization flows.
- No portable rule that `type`, `actions`, `locations`, `datatypes`, `identifier`, `privileges`, or provider-specific extension keys stand in for native SlopOS capability, policy, account-resource, or approval-basis semantics.
- No portable rule that `authorization_details_types_supported`, `authorization_details_types_metadata_endpoint`, `authorization_details_types_metadata`, `required_types`, or `insufficient_authorization_details` stand in for durable platform capability, policy, negotiation, or retry truth.
- No portable rule that granted `authorization_details` in token or introspection responses become durable login-state, connected-account, or transcript-stable evidence truth.

## Why this is worth pinning

The archive already keeps auth discovery, request packaging, verifier inputs, approval/result export, and authorization context on separate explicit seams. But current OAuth ecosystems still add another adjacent surface: **fine-grained grant objects**, where one provider may ask for structured `authorization_details`, advertise supported types, return filtered/enriched granted details, and increasingly publish schemas or actionable retry errors around those objects.

That looks like harmless provider detail, but it is exactly where invisible substrate grows. Once wrappers and agents start seeing RAR JSON, `authorization_details` becomes “the platform's approval object”, provider type vocabularies become “our policy language”, and token/introspection grant objects become “our durable entitlement ledger”.

Pinning the boundary now keeps the archive honest. Imported fine-grained authorization objects may remain a provider-local way to describe and grant one authorization request, but they do not get to redefine approval objects, policy blobs, entitlement registries, or connected-account/login-state meaning on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with providers that require structured fine-grained grants, but provider-local RAR JSON still does not become a portable approval object or permission manifest.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted gateways will be tempted to centralize RAR templates and granted-detail caches, but those helpers do not become tenant-stable approval, entitlement, or account substrate by default.
- **Embedded / separation appliance (C):** appliances can omit RAR entirely or terminate it in a narrow shim without importing a generalized policy or grant-template subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported `authorization_details` JSON is exactly the kind of structure agents will over-read as durable approval or permission truth unless the archive pins it provider-local now.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Dedicated checker:** `tools/check_mcp_authorization_details_import_boundary.py`
- **Evidence id:** `EVID-2026-691`
- **What it fails on:** missing family membership, missing discovery wiring, or wording drift that would let imported `authorization_details`, RAR type vocabularies, granted-detail responses, or RAR metadata/error signaling silently regrow a portable approval object, policy blob, entitlement registry, or durable connected-account/login-state substrate.

## References

- REF-MCP-AUTHORIZATION.
- REF-RFC9396-RICH-AUTHORIZATION-REQUESTS.
- REF-RFC8414-AS-METADATA.
- REF-RFC7662-TOKEN-INTROSPECTION.
- REF-DRAFT-ZEHAVI-RAR-METADATA.
