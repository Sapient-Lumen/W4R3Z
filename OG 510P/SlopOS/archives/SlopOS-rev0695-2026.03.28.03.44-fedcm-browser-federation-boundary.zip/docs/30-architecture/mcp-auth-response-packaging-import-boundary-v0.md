# D-LLM MCP-auth-response-packaging import boundary v0 (JARM is not portable auth-result / proof / approval truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported OAuth/MCP authorization-response packaging — JARM response modes (`query.jwt`, `fragment.jwt`, `form_post.jwt`, and `jwt`), authorization responses returned in a JWT-valued `response` parameter, JARM processing/validation requirements around `iss` / `aud` / `exp` / signature / decryption, and adjacent client/server response-packaging metadata such as `authorization_signed_response_alg`, `authorization_encrypted_response_alg`, `authorization_encrypted_response_enc`, `authorization_signing_alg_values_supported`, `authorization_encryption_alg_values_supported`, `authorization_encryption_enc_values_supported`, and `response_modes_supported` — is **provider-local authorization-response packaging and validation only**. It does **not** create a portable callback-result artifact, login-result export, auth-proof object, approval-basis blob, or durable account/session/auth-state substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported authorization-response packaging semantics may be interpreted next to already-pinned redirect, auth-exact-match, auth-proof, auth-result, login-state, account-binding, and authorization-context boundaries.

## Posture (v0)

1) **Imported JARM response modes stay provider-local authorization-response packaging only.**
   - OpenID JARM defines JWT-based authorization response modes including `query.jwt`, `fragment.jwt`, `form_post.jwt`, and the `jwt` shortcut, with authorization results carried in a JWT-valued `response` parameter.
   - Imported JARM response modes stay provider-local authorization-response packaging only; they do **not** create a portable callback-result channel, durable login-result export seam, approval-ticket substrate, or generic signed-response inbox on existing SlopOS seams.
   - Existing auth-redirect, auth-result export, auth-continuation export, and login-state boundaries stay authoritative instead of inheriting platform meaning from one provider's response-mode choice.

2) **Imported JARM `response` JWTs stay provider-local authorization responses only.**
   - JARM packages authorization success/error fields inside a JWT `response` whose claims include issuer/audience/expiry context together with authorization response parameters or errors.
   - Imported `response` JWTs remain provider-local authorization responses only; they do **not** become portable callback-result artifacts, replayable login-result blobs, portable auth-proof exports, account-binding truth, or transcript-stable approval receipts on existing SlopOS seams.
   - Existing auth-result export, auth-proof export, account-binding export, and authorization-context export boundaries stay authoritative instead of inheriting platform meaning from one provider-issued response JWT.

3) **Imported JARM response-packaging metadata stay provider-local compatibility hints only.**
   - JARM defines client metadata such as `authorization_signed_response_alg`, `authorization_encrypted_response_alg`, and `authorization_encrypted_response_enc`, plus authorization-server metadata such as `authorization_signing_alg_values_supported`, `authorization_encryption_alg_values_supported`, `authorization_encryption_enc_values_supported`, and `response_modes_supported`.
   - Those metadata rows remain provider-local compatibility and packaging hints only; they do **not** become a portable auth-response capability oracle, signer-policy substrate, approval-basis registry, or durable metadata-cache truth on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, auth-exact-match, and client-trust-policy boundaries stay authoritative instead of inheriting platform meaning from one provider's response-packaging menu.

4) **Imported JARM processing checks stay provider-local validation only.**
   - JARM requires client-side processing checks including issuer, audience, expiry, and signature/decryption validation before grant-specific response parameters are processed, and it forbids accepting `alg=none` for these JWT authorization responses.
   - Imported JARM processing checks stay provider-local validation only; they do **not** create a portable verifier verdict, issuer/account truth, approval-basis receipt, or durable current-session oracle on existing SlopOS seams.
   - Existing auth-exact-match, auth-proof export, auth-result export, and login-state export boundaries stay authoritative instead of inheriting platform meaning from one provider's signed/encrypted authorization response.

5) **No silent auth-result / proof / approval widening rides in through response packaging.**
   - Imported JARM response modes and response JWTs do **not** authorize portable signed callback exports, cross-provider response replay, generic approval receipts, issuer-proof storage, or hidden durable login/account/session truth by implication.
   - A provider may require signed or encrypted authorization responses for one authorization path, but that does **not** standardize a portable login-result artifact, auth-proof object, or approval-basis blob on adjacent SlopOS seams.
   - If SlopOS ever needs a native callback-result artifact, signed auth-result object, or approval-basis workflow, that work must arrive on those explicit seams and validators directly.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth libraries, JARM helpers, hosted callback wrappers, response-JWT validators, or metadata-driven response-mode selectors must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient response-JWT reuse, hidden callback-result caches, or implicit signed-response export must fail closed for portable D-LLM auth semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local authorization-response validation, explicit redirect/auth-result/auth-proof boundaries, and explicit evidence artifacts.
   - Any future native callback-result, signed auth-result, or approval-basis workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported JARM response modes, `response` JWTs, or response-packaging metadata.

## Phase 1 non-goals (explicitly deferred)

- No portable `response_mode=query.jwt|fragment.jwt|form_post.jwt|jwt` / signed auth-response / encrypted auth-response substrate imported directly from provider-local authorization flows.
- No portable JARM `response` JWT / callback-result / login-result / auth-result export seam imported directly from provider-local authorization-response packaging.
- No portable rule that JARM issuer/audience/expiry/signature/decryption checks stand in for durable issuer/account truth, approval-basis receipts, or transcript-stable auth proofs.
- No portable rule that JARM client/server response-packaging metadata stand in for cross-provider capability truth, signer-policy truth, or durable metadata-cache truth.

## Why this is worth pinning

The archive already keeps redirect handling, auth exact-match, auth-proof export, auth-result export, and refresh/login-state continuity on separate explicit seams. But current OAuth ecosystems still add another adjacent surface: **authorization-response packaging**, where one provider may insist on a signed/encrypted authorization response JWT, validate it before reading the code/error payload, and advertise response-packaging algorithms in discovery metadata.

That looks like harmless transport detail, but it is exactly where invisible substrate grows. Once wrappers and agents start seeing JARM response modes and response JWTs, a provider-local callback result becomes “the platform's signed login-result object”, issuer/audience checks become “our portable approval receipt”, and response-packaging metadata becomes “our auth-result policy/capability oracle”.

Pinning the boundary now keeps the archive honest. Imported authorization-response packaging may remain a provider-local way to protect one authorization response, but it does not get to redefine callback-result artifacts, auth-proof objects, approval basis, or durable account/session truth on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with providers that require signed or encrypted authorization responses, but provider-local response packaging still does not become a portable callback-result export, approval receipt, or durable signed-in/account-state truth.
- **Cloud micro-VM / hosted compute substrate (B):** hosted agents may validate a provider's response JWT for one authorization path, but that validation does not become a reusable auth-result substrate, issuer-truth oracle, or callback mailbox.
- **Embedded / separation-kernel-ish appliance (C):** appliances may embed provider-local response validation code, but response packaging remains sealed compat only and policy-killable, with no hidden callback export or signer-proof substrate.
- **Agent / automation OS (D):** first-class LLM/automation stacks are exactly where JARM can be over-read as a portable signed login-result or approval object; this boundary keeps agent memory/tooling from quietly normalizing that widening.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Dedicated checker:** `tools/check_mcp_auth_response_packaging_import_boundary.py`
- **Evidence id:** `EVID-2026-694`
- **What it fails on:** missing family membership, missing discovery wiring, or wording drift that would let imported JARM response modes, JWT `response` packaging, response-packaging metadata, or provider-local validation semantics silently regrow a portable callback-result artifact, login-result export, auth-proof object, approval-basis blob, or durable account/session/auth-state substrate.

## References

- REF-MCP-AUTHORIZATION
- REF-MCP-AUTHORIZATION-TUTORIAL
- REF-OPENID-JARM
- REF-RFC9700-OAUTH-SECURITY
