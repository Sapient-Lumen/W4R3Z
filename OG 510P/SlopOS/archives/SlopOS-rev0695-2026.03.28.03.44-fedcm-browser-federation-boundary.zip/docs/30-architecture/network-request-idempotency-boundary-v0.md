# D-NETLEASE request-idempotency boundary v0 (same `req_id` != mutable upsert payload)

Purpose: close one practical ambiguity on the `portal.net.request` seam before it turns into expensive implementation folklore: **same scoped `req_id` means exact replay/dedupe of one canonical CH-NETREQ v0 request, not mutable upsert/replace semantics under one key**.

This doc is intentionally narrow.
It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new portal family**.
It only freezes what Phase 1 is allowed to mean when callers retry or accidentally reuse the same `req_id` on `portal.net.request`.

## Why this is worth pinning

Real deployed idempotency systems keep this exact distinction honest:
- AWS EC2 client tokens replay **the same request** and reject parameter mismatches rather than silently retargeting the original operation (`REF-AWS-EC2-IDEMPOTENCY`).
- Stripe idempotency keys likewise compare incoming parameters to the original request and error on mismatch (`REF-STRIPE-IDEMPOTENT-REQUESTS`, `REF-STRIPE-ADVANCED-ERROR-HANDLING`).
- TCP Fast Open replay guidance is even harsher: if a request cannot tolerate replay, the application layer needs an explicit transaction-identity discipline (`REF-RFC7413-TFO`).

If SlopOS leaves `CH-NETREQ.req_id` vague here, wrappers will eventually disagree about whether “retry with edits” means replay, renew, replace, or broaden authority under one old key. That drift is expensive for D-NETLEASE, D-RETRYSAFE, and transcript reasoning.

## Posture (v0)

1) **Same scoped `req_id` only replays the same canonical request.**
   - The replay identity is the pair: `(scoped req_id, canonical CH-NETREQ bytes)`.
   - Retry/dedupe may return the original outcome, a deterministic duplicate-suppressed outcome, or a fresh portal-local renewal path **only when the canonical request is unchanged** and the existing seam already allows it.

2) **Same scoped `req_id` with different canonical CH-NETREQ bytes MUST reject before effect.**
   - Changing `kind`, `scope`, `proto`, `dest`, `bounds`, `purpose`, or any other canonical field under the same scoped `req_id` is **not** an in-place update operation.
   - Phase 1 validators/owner services/portal wrappers MUST reject that mismatch before effect rather than treating it as replace/merge/broaden semantics under one key.

3) **No portable mutable upsert-by-req_id seam in v0.**
   - Phase 1 exports no portable `replace_request`, `update_request`, `edit_pending_request`, `supersedes_req_id`, `request_generation`, or “latest request under this key” surface for `portal.net.request`.
   - A materially different request needs a **fresh** `req_id` and therefore a fresh review/dedupe identity.

4) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary does **not** change the `portal.net.request` conflict-key family, ordering rule, or serialization boundary.
   - Conflict keys still live on the existing `domain.id` family and ordered `svc:portal.net` execution path; this doc only constrains retry semantics within that already-pinned seam.

5) **Proof/evidence stance stays small.**
   - Existing proof obligations should show mismatch rejection before effect and transcript-visible duplicate suppression for exact replays.
   - This doc adds no new receipt kind and no new durable state schema.

## Phase 1 non-goals (explicitly deferred)

- No portable mutable upsert / replace / edit-pending-request API for `portal.net.request`.
- No `supersedes_req_id`, `request_generation`, or “latest request under this key” schema on CH-NETREQ v0 or CH-NETLEASE v0.
- No new ACP kind, receipt kind, or durable request-state schema just to express retry mismatch handling.
- No change to the existing `portal.net.request` conflict-key family, serialization locus, or commutativity stance.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam.

It is attached directly to the existing CH-NETREQ / request-state / ACP retry-dedupe seam rather than promoted into the closed `network-lease-boundary-index.md` family, because it pins request-identity semantics for `portal.net.request` rather than a new CH-NETLEASE v0 export field family.

If Phase 1 later adds more `network-request-*-boundary-v0.md` meaning pins, promote them into an explicit companion family index in the **same revision** rather than letting singleton count drift.

## Wiring

- Decision surface: `decision-map.md` (D-NETLEASE, D-RETRYSAFE)
- Schema/request posture: `network-request-schema-v0.md`, `network-request-state-posture-v0.md`
- Lease posture: `network-lease-posture-v0.md`, `network-lease-schema-v0.md`
- ACP surfaces: `../70-llm-control/acp-action-kind-registry.md`, `../70-llm-control/acp-validator-semantics.md`
- Proof/evidence: `../40-verification/portal-net-proof-slice-v0.md`, `../20-assurance/invariant-registry.md`, `../20-assurance/proof-obligation-registry.md` (`PO-ACP-NET-REQUEST`, `PO-RETRY-DEDUP`)
- RFC context: `../../rfcs/0056-outbound-network-leases-and-portals.md`

## References

- `REF-AWS-EC2-IDEMPOTENCY`
- `REF-STRIPE-IDEMPOTENT-REQUESTS`
- `REF-STRIPE-ADVANCED-ERROR-HANDLING`
- `REF-RFC7413-TFO`

## Evidence hook

- Drift gate: `../../tools/check_network_request_idempotency_boundary.py` (`EVID-2026-641`)
