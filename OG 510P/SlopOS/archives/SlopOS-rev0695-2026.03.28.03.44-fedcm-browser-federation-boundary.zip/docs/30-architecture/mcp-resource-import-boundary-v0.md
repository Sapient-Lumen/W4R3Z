# D-LLM MCP-resource import boundary v0 (resource catalogs are not file/document/watch truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam: current MCP resources (`resources/list`, `resources/read`, `resources/templates/list`, optional `notifications/resources/list_changed`, optional `resources/subscribe`, `notifications/resources/updated`, resource/resource-template metadata, URI schemes, annotations, and returned text/blob contents) are **provider-local context material only**. They do **not** create a portable filesystem/document grant, chooser-result plane, recursive inventory/watch plane, current-resource oracle, import-to-docref shortcut, or hidden policy/approval truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP resource semantics may be interpreted next to already-pinned file/document/import/observation seams.

This doc is an **intentional singleton** today. It is listed in `boundary-family-map.md` until a broader reviewed imported-resource family exists.

## Posture (v0)

1) **No portable filesystem/document/watch substrate in imported MCP resources.**
   - `resources/list`, `resources/read`, `resources/templates/list`, optional `notifications/resources/list_changed`, optional `resources/subscribe`, optional `notifications/resources/updated`, returned `Resource` / `ResourceTemplate` metadata, and returned `contents` remain **provider-local catalog/context material** on **D-LLM**.
   - They may help a host expose explicit selection UI, search/filter, or automatic context inclusion for one provider-owned interaction.
   - They do **not** by themselves grant permission, define a chooser result, mint a persistent bookmark, create a `portal.file` handle, create a `CH-DOCREF`, authorize recursive inventory/watch, or widen accepted action/schema meaning on existing SlopOS seams.

2) **Resource URIs and templates are descriptive locators only, not portable handles or authority carriers.**
   - Exact `uri`, `uriTemplate`, `name`, `title`, `description`, `mimeType`, optional `size`, optional `icons`, and common schemes such as the `https`, `file`, and `git` URI schemes, or custom URI schemes may help a provider describe what one host could request next.
   - Provider-side template-argument suggestion helpers such as MCP `completion/complete` stay separately pinned in `mcp-completion-import-boundary-v0.md` as provider-local suggestion mechanics only.
   - They do **not** become path truth, filesystem grants, document handles, chooser receipts, live sync promises, ambient network permission, or portable remote-object handles.
   - A `file`-scheme resource URI therefore does not stand in for a reviewed local file selection, and an `https`-scheme resource URI does not stand in for reviewed OpenURI or network authority.

3) **Resource bytes are imported context bytes only, not silent materialization or docref truth.**
   - Returned text/blob `contents` from `resources/read` remain exact imported bytes for one provider-owned read.
   - They do **not** by themselves create fresh local files, durable document-store objects, `CH-DOCREF`, quarantine exemptions, or import-to-docref shortcuts.
   - If document-like bytes need routine local document semantics, they still cross the explicit materialize/import bridge and existing `import-to-docref` / document-portal rules rather than silently materializing under MCP-resource folklore.

4) **List-change and subscription/update signals are not durable inventory/watch or current-state truth.**
   - `notifications/resources/list_changed`, `resources/subscribe`, and `notifications/resources/updated` may help one host refresh a provider-local view of which resources or templates it could request.
   - They do **not** become durable watch registrations, callback/mailbox authority, portable current-state truth, recursive changefeeds, or reviewed observation/export semantics.
   - A newly listed, updated, or subscribed resource therefore does not itself create local persistence, receipts, or validator truth.

5) **Resource annotations are advisory only.**
   - Optional annotations such as `audience`, `priority`, and `lastModified` may help a host filter, rank, or display resource context.
   - They do **not** become approval basis, policy truth, evidence timestamps, retention/admin truth, current-resource recency truth, or validator-only hidden fields.
   - Hosts and adapters must therefore not treat resource annotations as a substitute for explicit SlopOS policy/evidence artifacts.

6) **No auto-run or nested-authority folklore from resource reads.**
   - Listing or reading a resource does **not** itself authorize tool execution, browser/session actions, secret ingress, background work, or any other effectful follow-on behavior.
   - If a host later chooses to act on resource-derived bytes or URIs, that later effect must still cross an explicit reviewed seam with its own schema, validators, policy, receipts, conflict keys, and evidence hooks.
   - This keeps Hybrid + commutativity honest: imported resource catalogs may shape proposals and context, but they do not smuggle hidden action semantics or serialization rules into existing externally visible operations.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: exact reviewed actions, explicit workflow/portal seams, explicit receipts, and explicit evidence artifacts.
   - Any future reviewed portable resource/watch/import family must state its own conflict keys, commutativity conditions, serialization point, freshness semantics, and evidence story explicitly rather than inheriting folklore from MCP resource catalogs.

## Phase 1 non-goals (explicitly deferred)

- No portable `resource_handle`, `resource_mount`, `resource_watch`, `resource_inventory`, `resource_snapshot`, `resource_subscription`, or `current_resource` substrate imported directly from MCP resources.
- No rule that imported resource URIs/templates can stand in for reviewed local file/document selections, OpenURI launches, network leases, or recursive workspace binding.
- No rule that `resources/read` bytes, `mimeType`, or annotations can stand in for local document identity, quarantine clearance, approval basis, or evidence timestamps.
- No adapter shortcut that quietly turns resource listing/reading into automatic tool execution, browser/session control, import/materialization, or validator-only hidden fields.

## Why this is worth pinning

The archive already says imported tool annotations/results, prompt templates, task wrappers, progress notifications, roots, and logging signals do not become authority, evidence, or workflow truth by accident. MCP resources are the next obvious convenience surface: a server can expose named resources and templates, support paging, offer subscriptions/update notifications, attach ranking/display annotations, and return text/blob contents behind URIs that look familiar to file/web/git tooling.

That is useful, but it is also exactly where hosts and agent wrappers start to slide from “provider-local context material” into “remote filesystem/document/watch substrate someone else already approved for me.” Once that drift lands, resource URIs and resource bytes begin to masquerade as chooser results, document handles, inventory/watch registrations, or hidden current-state truth.

Pinning the boundary now keeps the archive honest. Imported MCP resources may remain a local UX and context convenience, but they do not get to redefine what reviewed file/document authority, import/materialization, watch semantics, or policy/evidence truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may expose provider resource pickers or search UI without silently importing a second file/document chooser or watch plane.
- **Cloud micro-VM substrate (B):** hosted agents avoid mistaking provider-owned resource catalogs, URIs, and bytes for tenant-stable file/document handles, watch registrations, or persistence truth.
- **Embedded / separation appliance (C):** appliance builds can omit MCP resource UX entirely or translate it to local hints without promising a portable filesystem/document/watch substrate.
- **Agent/automation OS (D):** agents may inspect or reuse provider resource catalogs and bytes, but reviewed file/document/import/evidence truth still lives on explicit SlopOS seams rather than drifting into resource folklore.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam; the current cut is only the narrow MCP-resource import boundary.

If a second closely related imported-resource boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `docs/30-architecture/import-to-docref-boundary-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_resource_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “resource catalogs are not file/document/watch truth” posture drifts (**EVID-2026-667**).

## References

- `REF-MCP-RESOURCES`
- `REF-MCP-SPEC`
