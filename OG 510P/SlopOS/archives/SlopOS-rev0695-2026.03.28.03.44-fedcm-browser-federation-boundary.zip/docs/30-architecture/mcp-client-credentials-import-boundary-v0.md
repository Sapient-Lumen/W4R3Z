# D-LLM MCP-client-credentials import boundary v0 (machine auth is not portable workload identity / service-account / secret truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP OAuth Client Credentials extension guidance — explicit extension negotiation, no-user machine-to-machine authorization, pre-connect token acquisition, JWT bearer assertions, client-secret authentication, token-endpoint auth-method selection, and associated secret-rotation / least-privilege guidance — is **provider-local machine-auth bootstrap only**. It does **not** create a portable workload identity plane, service-account registry, client-secret store, signer/JWKS discovery substrate, or durable external-service account truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP machine-auth semantics may be interpreted next to already-pinned client-registration, client-trust-policy, token-passthrough, auth-proof, account-binding, and auth-result boundaries.

## Posture (v0)

1) **Client-credentials support stays provider-local machine-auth bootstrap only.**
   - Current MCP authorization guidance and the OAuth Client Credentials extension explicitly allow machine-to-machine authorization for background services, CI pipelines, daemons, and server-to-server integrations when no end user is present.
   - That support remains provider-local authorization bootstrap only; it does **not** create a portable workload identity plane, service-account registry, application-principal catalog, or durable connected-service truth on existing SlopOS seams.
   - Existing account-binding, login-state, and auth-result boundaries stay authoritative instead of inheriting hidden meaning from one provider's no-user authorization path.

2) **JWT bearer assertions stay provider-local client-auth proof only.**
   - Current MCP guidance recommends JWT bearer assertions for client credentials, with client-auth material such as `iss`, `sub`, `aud`, `exp`, and `iat` interpreted by the authorization server for one token request.
   - Those JWT assertion mechanics remain provider-local client-auth proof only; they do **not** create a portable workload-identity token, signer registry, JWKS-discovery substrate, key-policy plane, or durable service-principal truth on existing SlopOS seams.
   - This matters even more because current MCP guidance explicitly leaves JWT contents and JWKS discovery/profile details under-specified for future work, so any portable service-identity meaning would be folklore rather than reviewed substrate.

3) **Client secrets stay provider-local long-lived credential handling only.**
   - Current MCP guidance also allows `client_id` + `client_secret` authentication for compatibility and explicitly warns that client secrets are long-lived credentials that must be stored in a secrets manager, rotated, and scoped to minimum permissions.
   - Those secret-handling rules remain provider-local credential hygiene only; they do **not** create a portable client-secret store, service-account enrollment plane, app-secret export seam, or ambient machine-credential substrate on existing SlopOS seams.
   - Existing app-secret, vault, and auth-proof boundaries stay authoritative instead of inheriting secret portability from one provider's machine-auth deployment.

4) **Issued access tokens stay provider-local resource access only.**
   - A token minted through client credentials may authorize one MCP client to call one MCP server or adjacent protected resource on its own behalf.
   - That token remains provider-local access state only; it does **not** create a portable external-service bearer relay, durable service-account binding, connected-service inventory, or generic workload-to-workload delegation seam on existing SlopOS surfaces.
   - Existing token-passthrough, authorization-context, and auth-result boundaries stay authoritative instead of inheriting platform meaning from provider-issued machine tokens.

5) **Auth-method metadata and extension support stay live provider policy only.**
   - Current OAuth metadata can advertise token endpoint auth methods, and MCP authorization extensions require explicit client/server support rather than activating by default.
   - Those support signals remain live provider/client policy only; they do **not** create a portable capability oracle, machine-auth compatibility matrix, signer acceptance plane, or transcript-stable governance fact on existing SlopOS seams.
   - Likewise, one provider supporting client secrets or JWT assertions does not imply portable support across other providers, tenants, product shapes, or future revisions.

6) **No silent user/account/token widening rides in through machine auth.**
   - Imported client-credentials semantics do **not** authorize connected-account export, selected-account truth, login-state truth, callback-token mailboxes, or browser-session continuity by implication.
   - If an eventual reviewed SlopOS seam needs portable workload identity, service-account management, machine-token brokerage, or signer/JWKS policy, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: machine auth remains killable by policy and does not smuggle ambient account/session/token channels into existing surfaces.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit auth/login boundaries, explicit token-proof boundaries, and explicit evidence artifacts.
   - Any future native workload-identity / service-account / machine-token workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP machine-auth helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `service_account`, `workload_principal`, `machine_identity`, `application_principal`, or `connected_service` substrate imported directly from MCP client-credentials support.
- No rule that JWT bearer assertions, client-auth claims, or authorization-server validation outcomes stand in for portable workload identity, signer trust, JWKS discovery, or durable connected-service truth.
- No rule that client-secret handling stand in for a portable client-secret store, service-account enrollment seam, or generic machine-credential substrate.
- No rule that machine-issued access tokens stand in for portable token relay, service-account binding, external-service credential export, or workload-to-workload delegation semantics.
- No rule that extension negotiation or token-endpoint auth-method metadata stand in for portable machine-auth capability, signer acceptance, or governance truth.

## Why this is worth pinning

The archive already keeps local login, client bootstrap, trust policy, token passthrough, auth proof export, account binding, and login state on separate explicit seams. Current MCP auth extensions add another nearby pressure surface: an explicit **OAuth Client Credentials** extension for background services, CI pipelines, daemons, and server-to-server integrations, with JWT bearer assertions recommended and client secrets still allowed.

That is useful, especially for the cloud substrate and agent/automation shapes. But it is also exactly the sort of convenience that grows invisible roots. Once wrappers and agents start seeing machine-auth support, client IDs become “service accounts,” JWT assertions become “portable workload identity,” client secrets become “the system's secret manager,” and machine-issued access tokens start masquerading as a generic outbound credential path.

Pinning the boundary now keeps the archive honest. Imported MCP client credentials may remain a provider-local way to bootstrap one no-user authorization path, but they do not get to redefine what workload identity, service-account management, signer policy, secret portability, or durable connected-service truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with MCP machine-auth endpoints for local automation, but client credentials still stay provider-local machine auth rather than becoming a portable service-account or secret-manager story.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted agents and workers will encounter many machine-auth integrations, but those integrations do not become tenant-stable workload identity, service-account inventory, or outbound credential substrate by default.
- **Embedded / separation appliance (C):** appliances can omit MCP machine auth entirely or terminate it in a narrow shim without importing a generalized workload-identity / service-account subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported client-credentials support may help one provider-owned automation path, but it does not become a second identity / secret / token substrate beside explicit vault, auth-result, auth-proof, and account-binding seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_client_credentials_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “machine auth is not portable workload identity / service-account / secret truth” posture drifts (**EVID-2026-682**).

## References

- `REF-MCP-AUTH-EXTENSIONS`
- `REF-MCP-OAUTH-CLIENT-CREDENTIALS`
- `REF-MCP-SEP-1046`
- `REF-RFC6749-OAUTH-AUTHZ-FRAMEWORK`
- `REF-RFC7523-JWT-BEARER`
- `REF-RFC8414-AS-METADATA`
