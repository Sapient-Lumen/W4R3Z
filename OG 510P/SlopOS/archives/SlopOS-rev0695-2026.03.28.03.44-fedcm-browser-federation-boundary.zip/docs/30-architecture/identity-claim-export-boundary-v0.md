# Identity-claim export boundary v0 (no portable subject / email / profile / account-identity export seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable subject / issuer / email / profile / account-identity export surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how identity/profile/account data may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the user completed a login locally” into a portable identity artifact.

## Posture (v0)

1. **No portable identity-claim export seam in v0**
   - Phase 1 does **not** export a portable `subject`, `issuer`, `sub`, `iss`, `email`, `email_verified`, `name`, `given_name`, `family_name`, `preferred_username`, `picture`, `profile`, `account_id`, `tenant`, `hosted_domain`, `userinfo`, `identity_claims`, `profile_claims`, `login_identity`, `account_identity`, `federated_identity`, `apple_identity`, `google_identity`, or equivalent identity/profile/account handoff on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, auth providers, and credential managers may maintain provider-local account state and request-local identity material, but that state remains provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user finished a local sign-in flow” as permission to mint or return a portable account/profile/subject bundle across components/cells.

2. **Identity/profile claims are not generic secret objects, approvals, or receipt outcomes**
   - Subject/profile/account claims may be privacy-sensitive, but they are not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because they matter operationally.
   - **D-APPSECRET** remains about provider-derived app seeds, not about returning `sub`, `email`, `full_name`, avatar/profile data, tenant/account membership, or equivalent identity claims.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about claiming that a user selected an account, authenticated as a given subject, or produced an app-consumable identity/profile result.
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about returning subject/profile/account identity as the outcome of local approval.

3. **Explicit local login/credential mediation is not permission to mint or relay subject/profile/account identity**
   - Existing ecosystems distinguish local authentication from generic identity-claim export. OpenID Connect defines subject/profile/email claims as dedicated protocol outputs delivered through the ID Token and UserInfo surfaces. Apple returns `ASAuthorizationAppleIDCredential` objects with explicit `email` / `fullName` fields. FedCM likewise treats federated login as a dedicated browser mediation API. The common lesson is narrow: account/profile identity is a first-class auth artifact, not harmless launch residue or secret-store side effect.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user complete a sign-in flow, but that does **not** justify returning `sub`, `iss`, `email`, `name`, `fullName`, account identifiers, tenant membership, or equivalent identity/profile material on existing generic seams.
   - If a future product shape needs reviewed identity-claim brokerage, it must return RFC-first with its own authority object, privacy budget, replay model, trusted-UI story, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to account scraping, profile reflection, or identity echo**
   - Agent tooling, shells, compat cells, and wrappers may propose “open this login page” or “use local sign-in,” but they must not silently read browser profile/account lists, scrape provider UI labels or avatars, echo callback/userinfo payloads, inspect provider-specific account managers, or relay subject/email/profile data back as generic outputs.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient account-state channels through paths, env, hidden browser helpers, implicit network reachability, account-manager side APIs, or cached profile metadata.
   - It also keeps **D-LLM** honest: a model may propose an auth workflow, but it does not gain portable identity/profile authority merely because the user authenticated somewhere locally.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local browser/auth/account internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed identity-claim brokerage seam must state its own conflict keys, commutativity preconditions, serialization point, trusted-UI bindings, replay/privacy boundaries, and evidence story explicitly rather than inheriting folklore from OIDC SDKs, browser account choosers, or provider callbacks.

## Phase 1 non-goals (explicitly deferred)

- No portable `sub` / `iss` / email / profile / account-identity export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded a reusable identity/profile/account artifact.
- No shell/helper fallback that quietly converts local sign-in into account scraping, profile reflection, or identity relay authority.
- No new CH-ACP kind or conflict-key family for identity/profile brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenient mistake after the recent LLM/secret/browser/auth-result cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” “vault refs are not credential mediation,” “local sign-in is not browser-session export,” and “local sign-in is not auth-result export,” the next convenience instinct is obvious: “fine, then just tell the tool which account it is.” That sounds narrower than handing over a token set, but in practice it still recreates a generic ambient identity bridge through subject claims, emails, account labels, and profile metadata that are difficult to reason about across product shapes and privacy regimes.

Pinning the boundary now keeps SlopOS from quietly turning reviewed local login mediation into portable account/profile export authority. It also leaves future work a clean choice: if the system ever needs explicit identity-claim brokerage, it can arrive as a small RFC-first seam with exact privacy, replay, and evidence semantics rather than as folklore smeared across launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local sign-in UX, but that does not standardize subject/email/profile return as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake account-profile brokers or “who just signed in?” helper machinery they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local login flows where useful without promising a general account/profile export/import substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user completed a login locally” with permission to receive `sub`, `email`, `fullName`, avatar/profile data, tenant membership, or equivalent identity claims; reviewed identity workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_identity_claim_export_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable identity-claim export seam / identity-profile claims are not generic secret objects or receipt outcomes / explicit login mediation is not permission to mint or relay subject-profile-account identity / no hidden account-scraping-profile-echo fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-619**).

## References

- REF-OPENID-CONNECT-CORE.
- REF-APPLE-APPLEID-CREDENTIAL.
- REF-W3C-FEDCM.
