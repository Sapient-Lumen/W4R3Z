# D-LLM MCP-JWKS import boundary v0 (auth verifier keys are not portable trust-root / signer / current-state truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP machine-auth and enterprise-auth guidance that relies on `jwks_uri`, fetched JWK Sets, key-selection fields such as `kid` / `kty` / `use`, and live key rotation/refresh for JWT verification is **provider-local verifier input only**. It does **not** create a portable trust-root plane, signer registry, issuer-identity truth, key-rotation oracle, or current-auth-state substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported JWKS/JWK verifier-key semantics may be interpreted next to already-pinned auth-discovery, auth-metadata-fetch, client-credentials, enterprise-managed-auth, auth-proof, and auth-result boundaries.

## Posture (v0)

1) **Imported JWKS pointers and JWK sets stay provider-local verifier inputs only.**
   - Current MCP client-credentials guidance says servers verify JWT signatures and claims against authorization-server public keys, usually via a JWKS endpoint. Current MCP enterprise-managed guidance likewise says authorization servers validate enterprise IdP-issued ID-JAGs against the IdP's JWKS endpoint.
   - Those `jwks_uri` pointers and fetched JWK Sets stay provider-local verifier inputs only; they do **not** create a portable trust-root plane, remote signing-key inventory, issuer registry, or durable enterprise/account truth on existing SlopOS seams.
   - Existing auth-discovery and auth-metadata-fetch boundaries stay authoritative instead of inheriting hidden trust semantics from fetched verifier-key material.

2) **Key selection fields stay provider-local validation mechanics only.**
   - JWK/JWK Set structures carry verifier-facing fields such as `kid`, `kty`, `use`, and related key properties that help one provider select and apply a verification key for one token or assertion.
   - Those fields remain provider-local validation mechanics only; they do **not** become a portable signer registry, approval-basis substrate, issuer-identity truth, or durable connected-service/account truth on existing SlopOS seams.
   - This keeps D-LLM honest: a provider choosing one JWK for one verification step is not the same thing as SlopOS standardizing who a signer is, which issuer owns a key, or which account/service is currently authoritative.

3) **Rotation and refresh stay live provider policy only.**
   - JWKS contents can change over time as issuers rotate keys, retire keys, or publish replacement verifier material.
   - That live rotation/refresh behavior remains provider-local policy only; it does **not** create a portable key-rotation oracle, revocation/current-auth-state substrate, transcript-stable policy fact, or replayable approval/evidence artifact on existing SlopOS seams.
   - Existing login-state, account-binding, auth-result, and evidence boundaries stay authoritative instead of inheriting liveness semantics from whether one verifier cache row or JWK member is still current.

4) **Imported verifier keys do not widen into generic crypto/trust-root semantics.**
   - Fetched JWK Sets may contain public verification keys, but Phase 1 does **not** reinterpret that as a portable trust-root distribution plane, generic key-import seam, signer enrollment workflow, or cryptosvc key-policy substrate.
   - Existing cryptosvc and signature/trust-root boundaries remain authoritative instead of inheriting meaning from auth-side verifier-key fetches.
   - This prevents a quiet category error where “the auth stack fetched some public keys” becomes “the platform now has a general signer registry or trust-root service.”

5) **No silent identity/account widening rides in through verifier-key material.**
   - Imported JWKS/JWK handling does **not** authorize connected-account export, current-user truth, subject/issuer export, tenant selection, or durable service-account truth by implication.
   - A successful verification step may let one provider proceed on one authorization path, but it does **not** standardize portable identity/account semantics on adjacent SlopOS seams.
   - If SlopOS ever needs portable signer policy, trust-root governance, workload identity, or live auth-state surfaces, that work must arrive on those explicit seams and validators directly.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of SDK JWKS caches, helper libraries, or ambient verifier-key refresh paths must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient verifier-key fetch/reuse must fail closed for portable D-LLM auth semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local auth negotiation/verification plus explicit reviewed result/evidence seams.
   - Any future native trust-root governance / signer enrollment / verifier-key cache policy workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP JWT/JWKS helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `jwks_uri`, `jwks`, `jwk_set`, `verification_keys`, `issuer_keys`, `active_kid`, or equivalent auth-verifier-key substrate imported directly from MCP/OAuth helpers.
- No rule that JWK fields such as `kid`, `kty`, `use`, or related key properties stand in for portable signer identity, trust-root policy, approval basis, or durable connected-account/service truth.
- No rule that JWKS rotation/refresh stands in for portable revocation truth, live auth-state truth, or transcript-stable governance fact.
- No rule that auth-side verifier-key fetches stand in for generic cryptosvc import, signer enrollment, trust-root distribution, or workload-identity semantics.

## Why this is worth pinning

The archive already keeps auth discovery, fetched metadata, exact-match binding, enterprise-managed routing, client credentials, auth proof, and result semantics on separate explicit seams. Current MCP auth guidance adds a nearby pressure surface that those docs do not yet pin directly: **JWT verification keys obtained from `jwks_uri` and used live for machine auth and enterprise IdP assertions**.

That sounds small, but it is exactly where hidden substrate grows. Once wrappers and agents start seeing JWKS validation in both machine-auth and enterprise-auth flows, shared key caches become “the platform trust store,” `kid` selection becomes “portable signer identity,” key rotation becomes “current authorization state,” and verifier-key fetches start masquerading as a general signer/trust-root service.

Pinning the boundary now keeps the archive honest. Imported JWKS/JWK handling may remain a provider-local way to verify one token or assertion on one auth path, but it does not get to redefine trust roots, signer governance, issuer identity, workload identity, or live auth-state truth on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with remote auth stacks that use JWKS, but verifier-key fetches still stay provider-local auth mechanics rather than a portable trust-root or signer registry story.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted agents and workers will see many JWT/JWKS-based integrations, but those integrations do not become tenant-stable trust-root, signer, or current-auth-state substrate by default.
- **Embedded / separation appliance (C):** appliances can omit remote JWKS-driven auth entirely or terminate it in a narrow shim without importing a generalized verifier-key / trust-root subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported JWKS validation may help one provider-owned auth path proceed, but it does not become a second identity/trust/governance substrate beside explicit auth-result, account-binding, and cryptographic policy seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_jwks_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “auth verifier keys are not portable trust-root / signer / current-state truth” posture drifts (**EVID-2026-683**).

## References

- `REF-MCP-AUTH-EXTENSIONS`
- `REF-MCP-OAUTH-CLIENT-CREDENTIALS`
- `REF-MCP-ENTERPRISE-MANAGED-AUTH`
- `REF-RFC7517-JWK`
- `REF-RFC8414-AS-METADATA`
