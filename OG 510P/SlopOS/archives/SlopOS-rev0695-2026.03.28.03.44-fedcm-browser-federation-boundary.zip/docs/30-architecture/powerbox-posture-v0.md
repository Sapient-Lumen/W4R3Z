# D-POWERBOX posture v0 (designation-scoped, chooser-owned mediation; no generic permission-store drift)

Purpose: pin an **implementable Phase 1** meaning for **D-POWERBOX** so consent mediation stays a small, reviewable authority-widening seam rather than widening into a generic permission store, target oracle, callback broker, or reusable “always allow” cache.
It narrows the already-present **D-PLUMB / IF-CONSENT / CH-AUTHZ / CH-VOL / CH-CAPDIFF** stack into one compact posture validators and harnesses can reason about: **designation-scoped grants, chooser-owned candidate sets, concrete capability outcomes, and no generic remembered-grant library**.

This doc is intentionally narrow: it does **not** design a global package-permission database, a delegated approval cache, a cross-host approval protocol, or a generic app-visible “which things can satisfy this?” discovery API.

## Posture (v0)

1) **User-space consent mediator, not a kernel or validator replacement**
   - D-POWERBOX remains a regular user-space consent mediator (`IF-CONSENT`), not a kernel subsystem and not the effect-enforcement seam.
   - `IF-CONSENT` may render approval UI, validate optional CH-VOL evidence, compute CH-CAPDIFF summaries, and issue **CH-AUTHZ v0** approvals.
   - `IF-ACP` / portal validators remain the only effect-enforcement seams; D-POWERBOX can narrow or deny, but does not directly mutate privileged state.

2) **Designation-scoped grants, not target-free permission toggles**
   - Phase 1 approvals stay tied to **one concrete action / one rendered summary / one designated target or bounded target class**.
   - The portable meaning is not “allow this app to use files forever”, “remember this decision for this whole capability family”, or “anything matching this label/provider later is OK”.
- If the approval is supposed to depend on a current mutable basis (for example one exact reviewed descriptor/revision), that basis must already be reflected in the bound action bytes; the consent mediator does not add a second floating “current basis” approval plane (`approval-basis-posture-v0.md`).
   - If a workflow widens authority, swaps the designated target, or changes the rendered summary, the old approval no longer applies.

3) **Chooser-owned candidate sets; requesters describe shape, not hidden inventory**
   - Requesters may describe the **kind of resource / authority** they can accept (capability type, portal family, bounded rights class, descriptor/query shape).
   - The mediator/provider chooses and presents the candidate set; untrusted callers do **not** enumerate hidden inventory, inject exact foreign object identities by host path/app id/handler id, or learn “who else could satisfy this?” as a side effect.
   - Host-owned modals or fullscreen tool widgets do **not** become chooser truth by accident; rendered tool/server UI chrome is pinned separately under `tool-ui-display-surface-boundary-v0.md`.
   - Tool/server auth challenges also do **not** become chooser/account-broker truth by accident; host-offered linking UI is pinned separately under `auth-link-ui-trigger-boundary-v0.md`.
   - Imported MCP roots likewise do **not** become chooser truth by accident; provider-local workspace roots stay hints only and do not replace designation-scoped mediation or candidate-set ownership (`mcp-roots-import-boundary-v0.md`).
   - The core seam therefore follows the **act-of-designation = act-of-authorization** pattern without turning designation into a caller-controlled oracle.

4) **Approvals and outcomes are concrete capability results, not ambient names**
   - Successful mediation returns **CH-AUTHZ**, typed handles/capabilities, typed artifact descriptors such as CH-DOCREF or CH-AREF v0, or a transcript-visible deny/receipt path.
   - Phase 1 does **not** treat host paths, callback URLs, package names, printer ids, route names, or other ambient naming artifacts as the portable result of a powerbox decision.
   - Any durable continuity object stays on its own family seam (for example CH-DOCREF), not on D-POWERBOX itself.

5) **No generic remembered-grant library or app-visible approval inventory in v0**
   - Phase 1 declines a generic “previous approvals” database/list/watch API on D-POWERBOX itself.
   - Family-specific persistence may exist where already pinned (for example document reopen), but the generic powerbox core does **not** standardize broad “always allow”, “all future matching objects”, or reusable approval-library semantics.
   - Audit/review uses receipts/digests/summaries rather than a second grant-management control plane.

6) **Summary and diff stay shell-owned and canonical**
   - The rendered approval summary comes from canonical action inputs plus relevant policy/state (`D-EXPLAIN` / `CH-CAPDIFF`), not requester prose.
   - Requester text/hints may decorate the UI, but they do **not** define the bound summary, the designated target identity, or the granted rights.
   - `CH-AUTHZ` stays action-bound approval evidence, not an app-authored permission note.

7) **Ordering stays request-local; no new portable conflict-key family**
   - Mediation ordering lives inside the relevant consent / portal provider (`svc:consent` and/or `svc:portal.<family>`).
   - Re-prompts and superseding decisions on the same live request do **not** commute and serialize there; unrelated requests do not require a new global order stream.
   - Phase 1 introduces **no new CH-ACP kind and no new portable conflict-key family** for D-POWERBOX itself.

8) **Sealed compat remains killable and non-ambient**
   - Foreign Cells and legacy shims may request additional authority only through explicit portals / IF-CONSENT.
   - They do not gain ambient package-visibility queries, remembered-grant stores, callback registries, or hidden host chooser APIs under a compatibility name.

## Phase 1 non-goals (explicitly deferred)

- Generic “always allow this app/class” approvals on the D-POWERBOX core seam.
- Generic list/watch/export APIs for prior approvals or candidate inventories.
- Returning host paths / callback URLs / package ids / route names as the portable result of mediation.
- A new CH-ACP automation/admin surface or portable conflict-key family for consent mediation itself.
- Cross-host export/import or delegated approval-cache semantics on D-POWERBOX itself.

## Wiring

- Decision surface:
  - `decision-map.md` (D-POWERBOX)
- Core approval / summary surfaces:
  - `authorization-token-schema-v0.md` (CH-AUTHZ v0)
  - `volition-token-schema-v0.md` (CH-VOL v0)
  - `capability-diff-schema-v0.md` (CH-CAPDIFF v0)
  - `consent-receipt-schema-v0.md` (CH-RECEIPT v0)
  - `interface-registry.md` (IF-CONSENT)
- Adjacent mediation surfaces:
  - `plumb-posture-v0.md`
  - `portal-session-posture-v0.md`
  - `document-portal-posture-v0.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-AUTHZ-1, I-CONSENT-1, I-EXPLAIN-1, I-EXPLAIN-2, I-PLUMB-1)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-CONSENT-VALIDATE, PO-EXPLAIN-SUMMARY, PO-EXPLAIN-RECEIPT-BIND)
  - `docs/10-threat-model/abuse-cases.md` (AC-036, AC-042)

CI drift gate:
- `tools/check_powerbox_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **designation-scoped / chooser-owned / concrete-cap-result / no generic remembered-grant-library** constraints, or drops its primary REF wiring.
- Companion mutable-basis honesty seam: `approval-basis-posture-v0.md`.

## References

- REF-ERIGHTS-POWERBOX.
- REF-DARPABROWSER-REPORT.
- REF-SANDSTORM-POWERBOX.
- REF-XDG-PORTAL.
- REF-XDG-PORTAL-REQUEST.
- REF-POLARIS-SOUPS05.
