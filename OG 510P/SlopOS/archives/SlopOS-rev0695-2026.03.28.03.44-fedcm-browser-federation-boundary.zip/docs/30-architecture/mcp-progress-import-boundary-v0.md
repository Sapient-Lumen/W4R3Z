# D-LLM MCP-progress import boundary v0 (progress notifications are not portable progress/completion truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-JOBS / D-BGLEASE / IF-ACP** seam: current MCP progress tracking (`progressToken` plus `notifications/progress`) is **provider-local / request-local liveness signaling only**. It does **not** create a portable queue/progress substrate, progress-watch plane, completion receipt, or current-state oracle on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP progress semantics may be interpreted next to already-pinned request-state, deferred-work, and acceptance/completion cuts.

This doc is an **intentional singleton** today. It is listed in `boundary-family-map.md` until a broader reviewed imported-progress family exists.

## Posture (v0)

1) **No portable progress/watch substrate in imported MCP progress tracking.**
   - MCP `progressToken` metadata in a request and `notifications/progress` responses with `progress`, `total`, and `message` remain **provider-local / request-local protocol mechanics** on **D-LLM**.
   - They may help a host show liveness, pacing, or rough completion estimates for one in-flight request, but they do **not** by themselves mint a reviewed `portal.jobs` progress API, a `portal.background` watch plane, a generic progress-subscribe surface, or a second portable live-status family.

2) **Progress tokens are correlation only, not portable authority or durable handles.**
   - `progressToken` values identify one active request lifecycle only.
   - They do **not** become portable job IDs, background-grant handles, resume handles, dedupe keys, cancellation authority, durable watch registrations, or transcript-stable current-state truth on existing SlopOS seams.

3) **Progress values do not widen completion, effect, or current-state meaning.**
   - Numeric `progress` / `total` values and human-readable `message` strings may aid UX, but they stay descriptive hints about one provider-owned in-flight request.
   - They do **not** by themselves prove downstream completion, durable mutation success, current provider-owned live state, or any reviewed effect/receipt semantics beyond the exact provider-local request they describe.

4) **Task-lifetime progress still stays local.**
   - MCP 2025-11-25 requires task-augmented requests to keep using the original `progressToken` across the task lifetime until terminal status.
   - That continuity may improve UX around one wrapped request, but it does **not** convert provider-local progress notifications into a portable queue browser, task watch plane, scheduler telemetry surface, or durable completion receipt on `portal.jobs` / `portal.background`.

5) **No silent polling/subscription folklore.**
   - Progress notifications are optional, receiver-controlled, rate-shaped, and tied to active requests.
   - They do **not** imply a durable subscribe/watch lease, replayable history stream, guaranteed update frequency, portable “still running?” oracle, or hidden mailbox/callback plane.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: exact reviewed actions and their existing request keys / serialization boundaries.
   - Any future reviewed portable progress/watch family must state its own conflict keys, commutativity conditions, rate/ordering guarantees, retention model, cancellation semantics, privacy rules, and evidence story explicitly rather than inheriting folklore from MCP progress notifications.

## Phase 1 non-goals (explicitly deferred)

- No portable `progress_handle`, `progress_watch`, `progress_history`, `progress_snapshot`, `progress_receipt`, or `percent_complete` substrate imported directly from MCP progress tracking.
- No rule that provider-generated `progressToken` values or `notifications/progress` messages can stand in for `CH-JOBREQ.job_id`, `CH-BGREQ.req_id`, or live portal-issued queue/grant truth.
- No adapter shortcut that treats task-lifetime progress continuity as reviewed scheduler telemetry, background-work liveness, or completion truth.
- No transcript-stable statement that a provider-local progress stream created a durable watch registration, completion receipt, or current-state oracle on existing SlopOS seams.

## Why this is worth pinning

The archive already says accepted requests and receipts do not by themselves prove downstream completion or current provider-owned live state, and the adjacent MCP-task boundary already refuses to let deferred result wrappers become a second scheduler story. MCP now adds the next tempting convenience surface: explicit progress tracking through `progressToken` and `notifications/progress`, including the rule that task-augmented requests keep the same token alive for the whole task lifetime.

That is useful, but it is also exactly where hosts, wrappers, and agents start to smuggle in a second live-state story. Once a provider can say “here is the token, here is 43/100, here is a status message,” those hints quickly get treated as if they were portable queue telemetry, durable job liveness, or completion evidence.

Pinning the boundary now keeps the archive honest. SlopOS already has explicit reviewed seams for request admission, deferred/background work, and exact request-state identity. Imported MCP progress tracking may remain a local protocol/runtime convenience around one provider-owned in-flight request, but it does not get to redefine what progress truth, queue state, or completion mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may show rough provider-local progress for expensive tool calls without silently importing a second queue browser or durable liveness oracle.
- **Cloud micro-VM substrate (B):** hosted agents avoid treating provider-local progress tokens and percentages as portable job telemetry or tenant-stable current-state truth.
- **Embedded / separation appliance (C):** appliance builds can ignore MCP progress machinery entirely or translate it to local UX without promising a portable progress/watch plane.
- **Agent/automation OS (D):** agents may observe provider-local liveness hints, but reviewed background work and completion truth still return through explicit seams rather than drifting into progress folklore.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam; the current cut is only the narrow progress/liveness import boundary.

If a second closely related imported-progress boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_progress_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “progress notifications are not portable progress/completion truth” posture drifts (**EVID-2026-663**).

## References

- `REF-MCP-PROGRESS`
- `REF-MCP-TASKS`
