# D-NETLEASE name-normalization boundary v0 (no portable Unicode / IDNA / normalization seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed name-shaped networking authority records an exact **canonical ASCII name predicate** plus **resolver binding**, but it does **not** become a portable Unicode / IDNA / browser-host-normalization surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable Unicode / IDNA / normalization seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **canonical ASCII name predicate** plus the granted **resolver binding**.
   - They do **not** grow a portable `unicode_host`, `u_label`, `idna_profile`, `uts46`, `nameprep`, `stringprep`, `casefolded_host`, `trailing_dot_ok`, `host_canonicalization`, or equivalent normalization-policy surface.
   - Phase 1 portable truth is therefore: **which canonical ASCII predicate was reviewed/granted, through which resolver binding** — not which Unicode mapping, compatibility fold, browser host parser, or locale-sensitive canonicalizer happened to prepare it on one machine.

2) **`dns_name` / `dns_suffix` use one exact canonical ASCII authoring profile.**
   - `dns_name` and `dns_suffix` carry **exact-byte lowercase ASCII** only.
   - Labels are dot-separated **NR-LDH labels or A-labels** (`xn--...`), not U-labels; interior empty labels reject.
   - `dns_name` has **no trailing dot**; `dns_suffix` begins with exactly one leading dot and the remainder obeys the same label profile.
   - This keeps reviewed naming authority crisp across A/B/C/D and avoids later arguments about whether uppercase, trailing-dot, or Unicode spellings were “really the same reviewed destination”.

3) **User-input mapping stays local UI / tool logic, not D-NETLEASE portable meaning.**
   - RFC 5895 explicitly separates user-input mapping from the IDNA protocol itself; WHATWG URL host parsing makes its own UTS #46 `domain to ASCII` choice.
   - SlopOS therefore treats any Unicode→ASCII mapping, width folding, locale-sensitive lowercasing, bidi/joiner policy, or trailing-dot trimming as **local pre-validation logic** that must happen before CH-NETREQ construction if a product wants it.
   - If local tooling cannot produce one admitted canonical ASCII predicate, the request rejects before effect instead of smuggling browser/libc/application normalization folklore into the reviewed substrate seam.

4) **Receipt truth is the canonical predicate, not alternate spellings.**
   - Historical CH-NETREQ / CH-NETLEASE bytes prove the exact canonical predicate that was reviewed/granted.
   - They do **not** by themselves prove that every Unicode spelling, browser host parser, UTS #46 profile, or trailing-dot variant that some local stack might accept is also reviewed/granted.
   - This keeps evidence stable and machine-comparable instead of tying approval history to whichever host parser happened to run first.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit Unicode/IDNA or rich host-parsing surface must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from browsers, libc, or URL toolkits.

6) **If Unicode-facing reviewed naming matters, pay for a new seam explicitly.**
   - A future product shape may want transcript-visible reviewed U-label input, per-profile UTS #46 behavior, registry-policy-aware IDN validation, or human-facing display-name receipts.
   - That work must return **RFC-first** with its own schema/receipt family, privacy posture, discovery/testing story, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because browsers and UI toolkits already ship host-normalization algorithms.

## Phase 1 non-goals (explicitly deferred)

- No portable Unicode U-label, IDNA profile, UTS #46, Nameprep/Stringprep, locale-casefolding, or confusable-management field on CH-NETREQ or CH-NETLEASE.
- No transcript-stable claim that an accepted name-shaped request or issued lease also approves every alternate uppercase, Unicode, or trailing-dot spelling some local host parser might accept.
- No browser/libc compatibility promise that `portal.net.request` will silently run `domain to ASCII`, trim trailing dots, or apply locale/compatibility mappings behind the caller’s back.
- No generic portal/settings API that turns D-NETLEASE into a browser-host canonicalization broker or IDNA-profile negotiation plane.

## Why this is worth pinning

The archive already pinned reviewed name predicates as exact and kept host search-path / local-name-resolution context outside portable D-NETLEASE meaning. The next quiet drift is to treat the same reviewed predicate as if it also carried **whatever Unicode / IDNA / host-normalization algorithm a local stack prefers** — browser UTS #46 processing, libc/library ToASCII helpers, locale lowercasing, or trailing-dot cleanup.

Real ecosystems do expose those behaviors, but the primary specs treat them as distinct processing layers. DNS itself is case-insensitive for comparisons, RFC 5890 distinguishes NR-LDH labels from A-labels and U-labels, RFC 5895 makes input mapping a pre-protocol implementation choice, and the WHATWG URL Standard picks an explicit UTS #46-based host algorithm for the web platform. Pinning the boundary now keeps D-NETLEASE honest: **reviewed canonical ASCII name authority is one seam; reviewed Unicode/IDNA/host-normalization semantics would be another future seam if we ever truly need it.**

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still accept Unicode host input locally, but reviewed leased-network meaning stays on exact canonical ASCII predicates rather than whatever browser or desktop host parser was nearest.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound naming explicit without promising one portable browser/libc IDNA stack or trailing-dot policy across guests and images.
- **Embedded / separation appliance (C):** appliance builds can keep naming small and auditable by rejecting Unicode/normalization complexity unless a product explicitly pays for it.
- **Agent/automation OS (D):** agents/tools cannot confuse “this exact canonical predicate was reviewed” with “all parser-equivalent spellings are blessed”; retries and receipts stay byte-stable for LLM workflows.

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-lease-name-context-boundary-v0.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETREQ-VALIDATE**, **PO-NETLEASE-VALIDATE**, **PO-ACP-NET-REQUEST**)

CI drift gate:
- `tools/check_network_lease_name_normalization_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **canonical-ASCII-only / no Unicode-or-IDNA seam / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-645**).

## References

- REF-RFC1035-DNS.
- REF-RFC5890-IDNA-DEFS.
- REF-RFC5895-IDNA-MAPPING.
- REF-WHATWG-URL-HOST.
