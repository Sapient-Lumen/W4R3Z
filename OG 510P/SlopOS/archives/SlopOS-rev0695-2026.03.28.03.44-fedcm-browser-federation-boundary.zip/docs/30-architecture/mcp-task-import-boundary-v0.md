# D-LLM MCP-task import boundary v0 (deferred result wrappers are not a background-work substrate)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-JOBS / D-BGLEASE / IF-ACP** seam: current MCP task augmentation may wrap requests in durable receiver-owned task state plus deferred result retrieval, but that import is **request-tracking convenience only**. It does **not** create a portable background-work substrate, queue/status plane, cancellation/control plane, or persistence surface on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP task semantics may be interpreted next to the already-pinned `portal.jobs` / `portal.background` surfaces.

This doc is an **intentional singleton** today. It is listed in `boundary-family-map.md` until a broader reviewed task/deferred-work family exists.

## Posture (v0)

1) **No portable scheduler/background substrate in imported task wrappers.**
   - Task-augmented MCP methods `tools.call`, `sampling.createMessage`, `elicitation.create`, `tasks/get`, `tasks/result`, `tasks/list`, `tasks/cancel`, and `notifications.tasks.status`, plus `CreateTaskResult`, `execution.taskSupport`, and `io.modelcontextprotocol/model-immediate-response`, remain **provider-local / request-local protocol mechanics** on **D-LLM**.
   - They may help a host return control to the model, poll progress, or retrieve deferred results, but they do **not** by themselves mint `portal.jobs.submit`, `portal.background.request`, `CH-JOBREQ v0`, `CH-BGREQ v0`, `CH-BGLEASE v0`, or a second reviewed deferred-work workflow family.

2) **Task IDs and task state are correlation only, not portable authority or current-state truth.**
   - `taskId`, `status`, `statusMessage`, `ttl`, `pollInterval`, `input_required`, and `io.modelcontextprotocol/related-task` metadata correlate one provider-owned wrapped request lifecycle only.
   - They do **not** become portable job IDs, background-grant handles, dedupe keys, resume handles, cancellation authority, durable request-state receipts, or current scheduler/live-grant truth on existing SlopOS seams.

3) **Deferred result retrieval does not widen effect or completion meaning.**
   - Returning a `CreateTaskResult` immediately and the underlying result later through `tasks/result` may improve UX and host scheduling, but any effectful work still has to arrive on exact reviewed seams with explicit validators, policy, conflict keys, and receipts.
   - Task terminal states such as `completed`, `failed`, or `cancelled` therefore do **not** by themselves prove reviewed completion semantics, durable mutation success, or current live-state truth beyond the exact provider-local request they wrap.

4) **No portable queue inventory, watch, or polling plane.**
   - `tasks/list`, `tasks/get`, `notifications/tasks/status`, task progress, and task retention/TTL behavior remain provider-local introspection for that peer/session.
   - They do **not** become an app-visible scheduler inventory, generic watch/subscribe surface, portal-owned queue browser, durable callback/mailbox plane, or transcript-stable truth about current `portal.jobs` / `portal.background` state.

5) **No silent persistence widening or retry folklore.**
   - A tool advertising `execution.taskSupport = "optional"` or `"required"`, a host returning an immediate model-facing placeholder via `io.modelcontextprotocol/model-immediate-response`, or a receiver integrating with an external job API still does **not** create hidden keep-running, retry-loop, login-autostart, or ambient background-presence semantics.
   - If a SlopOS workflow truly needs deferrable work, it returns to **D-JOBS** / `portal.jobs`; if it truly needs continuous presence or autostart, it returns to **D-BGLEASE** / `portal.background`.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: exact reviewed portal actions (`portal.jobs.submit`, `portal.background.request`), their existing request keys (`job_id`, `req_id`), and the existing serialization boundaries (`svc:portal.jobs`, `svc:portal.background`).
   - Any future reviewed portable task/deferred-work family must state its own conflict keys, commutativity conditions, cancellation semantics, listing/watch semantics, state/receipt model, and evidence story explicitly rather than inheriting folklore from MCP task wrappers.

## Phase 1 non-goals (explicitly deferred)

- No portable `task_handle`, `task_status`, `task_list`, `task_watch`, `task_cancel`, or `task_result_receipt` substrate imported directly from MCP task augmentation.
- No rule that receiver-generated `taskId` values or task status notifications can stand in for `CH-JOBREQ.job_id`, `CH-BGREQ.req_id`, or live portal-issued grant/queue truth.
- No adapter shortcut that treats external job-API integration behind MCP tasks as reviewed SlopOS background-work, retry, persistence, or autostart semantics.
- No transcript-stable statement that a provider-local task wrapper created a durable scheduler object, keep-running exception, or current-state receipt on existing SlopOS seams.

## Why this is worth pinning

The archive already says LLM operations stay proposal-only, explicit portal workflows own deferred/background work, and requester-chosen request keys must stay separate from provider-owned live mutable state. MCP now adds a tempting adjacent convenience surface: task-augmented requests with durable task state, polling, deferred result retrieval, task listing/cancellation, and immediate placeholder messages so a host can hand control back to the model while the wrapped work continues.

That is useful, but it is also exactly where agent/tool ecosystems start to smuggle in a second scheduler story. Once a host can say “this tool call became a durable task and you can poll/list/cancel it later,” wrappers quickly start treating those provider-local task mechanics as if they were a portable queue browser, retry substrate, or background-work API.

Pinning the boundary now keeps the archive honest. SlopOS already has explicit reviewed seams for **deferrable jobs** and **long-lived background presence**. Imported MCP tasks may remain a local transport/runtime convenience around one provider-owned request, but they do not get to redefine what deferred work, current state, cancellation, or persistence mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may use provider-local task wrappers for expensive tool calls without silently importing a second queue browser, background agent, or persistent autostart substrate.
- **Cloud micro-VM substrate (B):** hosted agents avoid treating provider-local task IDs/status as portable job control or current-state truth across tenants, runtimes, or wrappers.
- **Embedded / separation appliance (C):** appliance builds can ignore MCP task machinery entirely or translate it to local UX without promising a portable deferred-work/watch plane.
- **Agent/automation OS (D):** agents may reason about provider-local deferred tool execution, but reviewed background work still returns through `portal.jobs` / `portal.background` rather than drifting into unbounded task folklore.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam; the current cut is only the narrow task/deferred-work import boundary.

If a second closely related task/deferred-work boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/30-architecture/job-portal-posture-v0.md`
- `docs/30-architecture/background-lease-posture-v0.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_task_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “deferred result wrappers are not a background-work substrate” posture drifts (**EVID-2026-662**).

## References

- `REF-MCP-TASKS`
