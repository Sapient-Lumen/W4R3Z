# Auth-mediation companion boundary index (v0)

Purpose: keep the **closed set of explicit-local-auth / credential-mediation companion boundary docs** enumerable.

Why this exists:
- the archive now pins multiple small boundaries that all defend the same expensive seam: agent/tool/server requests for user input, secret ingress, credential mediation, credential portability, pending-auth continuation, and local login do **not** silently regrow a generic browser, credential manager, password manager, enrollment surface, token/proof/session/account export, or account-control substrate,
- those boundary docs are individually crisp but easy to forget piecemeal because they span D-LLM, D-POWERBOX, D-UICAP, D-APPSECRET, D-VAULT, and D-PLUMB,
- current MCP/OAuth registered redirect URIs, exact redirect matching, `localhost`/HTTPS constraints, state verification, localhost warning/display guidance, and native-app private-use / app-claimed-HTTPS / loopback return patterns stay provider-local authorization return-channel mechanics only, so imported auth redirect handling does not quietly regrow portable callback/browser/listen truth,
- `llm-operations-posture-v0.md`, `app-secret-posture-v0.md`, and `vault-posture-v0.md` keep the underlying Phase-1 meanings small, while this index is the **discovery surface** that says which companion boundaries currently keep explicit local auth/credential mediation bounded and non-portable.

This doc does **not** add a new schema, workflow family, or credential broker.
It is an entropy-reducing companion to `llm-operations-posture-v0.md`, `app-secret-posture-v0.md`, `vault-posture-v0.md`, and `secret-authority-adjunct-index.md`.

## Posture (v0)

1. **Closed family, not adjacent singleton folklore**
   - The current explicit-local-auth / credential-mediation meaning cuts are treated as one closed recovery surface, not neighboring facts readers are expected to rediscover manually.
2. **Entropy reduction only**
   - This index does not widen D-LLM, D-APPSECRET, D-VAULT, D-POWERBOX, D-UICAP, or D-PLUMB, and it does not introduce a browser API, callback protocol, account broker, password manager, token/session store, pending-auth broker, or credential exchange broker.
3. **Same-revision family maintenance**
   - Future auth/credential-mediation boundary growth must either attach to this family in the same revision or justify a different explicit discovery surface in the same revision.

## Phase 1 non-goals (explicitly deferred)

- No portable hidden-browser or embedded-webview authority path.
- No generic password / API-key / OAuth-token paste-store or account-linking seam.
- No portable password-manager / autofill / passkey / account-selection seam.
- No portable passkey-registration / authenticator-enrollment / credential-provisioning seam.
- No portable password-manager migration / passkey portability / credential import-export seam.
- No portable cookie-jar / authenticated-browser-session / replay-blob export seam.
- No portable pending-auth / continuation-handle / PKCE-device-backchannel relay seam.
- No portable session-auth-state / current-user / caller-identity / per-tool-authorization seam.
- No portable client-credentials / service-account / workload-identity / client-secret / connected-service seam.
- No portable `client_assertion` / `client_assertion_type` / `private_key_jwt` / `client_secret_jwt` / token-endpoint client-auth / assertion-store seam.
- No portable PAR endpoint / `request_uri` / Request Object / signed request JWT / request-template / approval-object / auth-request-policy seam.
- No portable `device_authorization_endpoint` / `device_code` / `user_code` / `verification_uri` / `verification_uri_complete` / device-flow polling / cross-device auth-broker seam.
- No portable `refresh_token` / `grant_type=refresh_token` / `offline_access` / refreshed token-set metadata / client-local token-cache / background-renewal / durable connected-service-session seam.
- No portable `response_mode=query.jwt|fragment.jwt|form_post.jwt|jwt` / JARM `response` JWT / signed auth-response / encrypted auth-response / callback-result / login-result / auth-proof / approval-basis seam.
- No portable `userinfo_endpoint` / UserInfo claim bundle / profile lookup / current-user / account-card seam.
- No portable FedCM `navigator.credentials.get({identity})` / Login Status map / connected accounts set / account chooser / disconnect / browser-federation seam.
- No portable `identity_assertion` / `id_token` / `saml_assertion` / `subject_token` / `id_jag` / enterprise-SSO-proof seam.
- No portable token exchange / `actor_token` / delegation / impersonation / workload-identity / token-broker seam.
- No portable `jwks_uri` / JWK Set / verifier-key / key-rotation / trust-root seam.
- No portable `introspection_endpoint` / token introspection / `active` / token-metadata / live-auth-state seam.
- No portable `revocation_endpoint` / revoke / disconnect / unlink-account / linked-service-control seam.
- No portable client-registration / client-metadata / redirect-registry / connected-app-governance seam.
- No portable redirect registration / loopback callback / deep-link return / browser-auth session seam.
- No portable PKCE verifier / code-challenge / verifier-proof / PKCE-capability oracle seam.
- No portable protected-resource metadata / authorization-server metadata / issuer-registry / metadata-cache trust seam.
- No portable auth-metadata fetch / cache / issuer-pinset / egress-policy seam.
- No portable exact-match resource / issuer / response binding / issuer-verdict seam.
- No portable challenged-scope / `scopes_supported` / step-up authorization / resource-targeting / grant-inventory seam.
- No portable token passthrough / bearer-relay / reverse-proxy / external-service-token seam.
- No portable session-auth-state / current-user / caller-identity / per-tool-authorization seam smuggled through imported auth/session guidance.
- No portable scope/permission catalog, granted-scope truth, entitlement export, or service-identity registry smuggled through imported auth guidance.
- No portable account-linking / connect-account / auth-link trigger / choose-account seam.
- No portable authorization-code / token-set / callback-result / login-result export seam.
- No portable proof-of-possession / auth-assertion export seam.
- No portable granted-scope / resource-indicator / authorization-details / entitlement export seam.
- No portable subject / issuer / email / profile / account-identity export seam.
- No portable linked-account / connected-account / selected-account / default-account export seam.
- No portable signed-in / login-status / session-state / account-availability export seam.
- No portable logout / disconnect / revoke / unlink-account control seam.
- No hidden prompt-defined auth broker, token relay, or account-control family smuggled through this index.

## Inclusion rule

A doc belongs here if it removes exactly one tempting explicit-local-auth / credential-mediation meaning widening from Phase 1 by constraining one of:
- server/tool/model requests for more user input that would otherwise regrow a hidden browser, token relay, or generic inline secret-ingress plane,
- imported enterprise-auth routing that would otherwise regrow enterprise-policy, tenant/account/session, or token/callback-broker semantics on generic SlopOS seams,
- imported client registration/bootstrap that would otherwise regrow portable software identity, redirect/callback authority, trust-policy, or client-governance semantics on generic SlopOS seams,
- imported redirect URI / native-app return-channel guidance that would otherwise regrow portable callback registration, deep-link reentry, browser-auth/session, loopback-listener allocation, or auth-result semantics on generic SlopOS seams,
- imported PKCE verifier/challenge handling, `S256` preference, metadata-confirmed `code_challenge_methods_supported`, or refusal-to-proceed gating that would otherwise regrow portable verifier/proof truth, PKCE-capability oracles, pending-auth continuation handles, or approval-basis folklore on generic SlopOS seams,
- imported authorization discovery metadata that would otherwise regrow portable issuer/tenant identity, authorization-server catalogs, scope/policy oracle semantics, callback authority, or metadata-cache trust semantics on generic SlopOS seams,
- imported authorization metadata fetch / caching policy that would otherwise regrow portable metadata-cache, issuer-pinset, SSRF-policy, egress-policy, or fetched-metadata provenance semantics on generic SlopOS seams,
- imported exact-match resource / issuer / response binding that would otherwise regrow portable issuer truth, resource identity, account-binding truth, response-verdict semantics, or auth-topology folklore on generic SlopOS seams,
- imported scope/resource guidance that would otherwise regrow portable granted-scope truth, permission/entitlement inventories, approval-basis folklore, service-identity truth, or account-binding semantics on generic SlopOS seams,
- imported step-up-authentication challenges, authentication-strength vocabularies, recency bounds, or verifier-visible auth-assurance claims that would otherwise regrow portable assurance registries, recent-login truth, user-presence proof, approval-basis folklore, or durable account/session semantics on generic SlopOS seams,
- imported refresh tokens, refresh grants, `offline_access`, refreshed token-set metadata, client-local token caches, or refresh-token rotation/replay handling that would otherwise regrow portable background-renewal substrates, durable login/account truth, connected-account semantics, generic token-wallet storage, or unattended-delegation folklore on generic SlopOS seams,
- imported OIDC UserInfo endpoint locations, Bearer-token profile fetches, returned subject/profile/email claims, `sub`-match rules, or signed/encrypted UserInfo metadata that would otherwise regrow portable subject/account/profile export, current-user truth, contact-card semantics, approval-basis folklore, or durable account/session semantics on generic SlopOS seams,
- imported FedCM browser mediation, Login Status signaling, connected-account/account-list handling, or disconnect choreography that would otherwise regrow portable account chooser truth, current-user/login-state oracles, connected-account inventories, disconnect control semantics, browser-session folklore, or approval-basis receipts on generic SlopOS seams,
- imported enterprise Identity Assertions, ID-JAG token exchange, `subject_token` handling, optional refresh-driven renewal, and carried identity/authorization claims that would otherwise regrow portable SSO proof, subject-token storage, cross-domain account binding, approval-basis, or durable login-state semantics on generic SlopOS seams,
- imported audience-bound token checks, no-token-passthrough rules, resource-specific upstream token handling, or URL-mode third-party auth token splits that would otherwise regrow portable token relay, reverse-proxy, external-service credential export, callback-token-mailbox, or durable token/session-broker semantics on generic SlopOS seams,
- imported OAuth Client Credentials extension support, no-user machine auth, JWT bearer assertions, client-secret authentication, or token-endpoint auth-method selection that would otherwise regrow portable workload identity, service-account registries, client-secret stores, signer/JWKS discovery, or durable connected-service semantics on generic SlopOS seams,
- imported JWT client assertions / token-endpoint client-auth metadata that would otherwise regrow portable signer services, assertion stores, client-identity registries, auth-method oracles, or endpoint-trust semantics on generic SlopOS seams,
- imported PAR endpoints, returned `request_uri` handles, Request Objects carried by value or reference, `require_signed_request_object`, or request-object capability / algorithm metadata that would otherwise regrow portable pending-auth handles, approval objects, request-template caches, request-policy blobs, or durable auth-state / connected-account semantics on generic SlopOS seams,
- imported JARM response modes, JWT-valued `response` artifacts, issuer/audience/expiry/signature/decryption checks, or response-packaging metadata that would otherwise regrow portable callback-result artifacts, login-result exports, auth-proof objects, approval-basis blobs, or durable account/session semantics on generic SlopOS seams,
- imported `jwks_uri`, fetched JWK Sets, verifier-key selection fields such as `kid` / `kty` / `use`, or live key rotation/refresh that would otherwise regrow portable trust-root, signer-registry, issuer-identity, key-rotation, or current-auth-state semantics on generic SlopOS seams,
- imported token introspection endpoints, verifier-side `active` / token metadata responses, or verifier cache/eviction pressure that would otherwise regrow portable live login-state, grant inventory, subject/account identity, connected-service truth, or current-session semantics on generic SlopOS seams,
- imported revocation endpoints, revoke requests, success-on-invalid semantics, propagation-delay / grant-cascade policy, or revocation-endpoint auth-method metadata that would otherwise regrow a portable disconnect control plane, linked-account / connected-service truth, durable live-login-state semantics, account-unlink substrate, or transcript-stable revocation ledger on generic SlopOS seams,
- imported session IDs, inbound-request verification, “sessions are not authentication”, URL-mode same-user verification, or persistent-auth/per-tool-auth behavior that would otherwise regrow portable current-user export, caller-identity truth, per-tool authorization registries, or durable server-authorized-for-user semantics on generic SlopOS seams,
- minimal app-seed ingress that would otherwise regrow password/API-key/OAuth-token paste-store or account-linking semantics,
- ref-bound secret storage that would otherwise regrow password-manager, autofill, passkey, or account-selection semantics,
- credential-enrollment control that would otherwise regrow passkey-registration, authenticator-enrollment, or account-upgrade semantics,
- credential portability or password-manager migration that would otherwise regrow password-manager export/import, passkey portability, or equivalent credential-exchange semantics,
- browser/session continuity that would otherwise regrow cookie-jar handoff, authenticated-browser-profile export, or replayable session-blob semantics,
- pending-auth continuation that would otherwise regrow PKCE verifier relay, device-flow code handoff, verification-URL relay, or backchannel polling semantics,
- auth-link/account-link triggers that would otherwise regrow `auth_required`, connect-account, account-choice, or account-broker trigger semantics,
- local-auth results that would otherwise regrow authorization-code, token-set, callback-result, or generic login-result export semantics,
- local-auth proof surfaces that would otherwise regrow DPoP / challenge-signing / authenticator-assertion / certificate-proof export semantics,
- local-auth authorization-context surfaces that would otherwise regrow granted-scope / resource-indicator / authorization-details / entitlement export semantics,
- local-auth identity surfaces that would otherwise regrow subject / issuer / email / profile / account-identity export semantics,
- local-auth account-binding surfaces that would otherwise regrow linked-account / connected-account / selected-account / default-account export semantics,
- local-auth status surfaces that would otherwise regrow signed-in / login-status / session-state / account-availability export semantics,
- local-auth teardown surfaces that would otherwise regrow logout / disconnect / revoke / unlink-account control semantics.

If future work needs a native credential-manager surface, portable client-registration / app-identity / redirect-registry API, portable redirect-return / browser-auth / loopback-listener API, portable credential-enrollment API, portable credential-exchange API, portable pending-auth / continuation-handle broker, portable approval-object / request-template / request-policy API, portable browser/login continuation API, portable callback/token broker, portable bearer-relay / service-delegation broker, portable auth-proof broker, portable authorization-context export API, portable assurance-level / recent-login / presence-proof API, portable identity/profile export API, portable connected-account / account-binding export API, portable account-chooser / browser-federation API, portable login-status API, portable sign-out/disconnect/revocation API, or portable DPoP signer / replay-policy / token-binding API instead, that work must return **RFC-first** as its own decision surface rather than hiding behind existing auth-adjacent convenience semantics.

## Member contract

Every auth-mediation family member doc must remain a **small tightening doc**, not a stealth workflow/spec expansion. Concretely, each member must:
- say the boundary is intentionally small and introduces **no new schema family**,
- preserve an explicit **no new ACP** / **no new conflict-key family** posture for v0,
- carry `## Family status (Phase 1)`, `## Wiring`, `## Evidence hook`, and `## References` sections so recovery/discovery shape stays uniform,
- restate that future nearby growth attaches to this family in the **same revision** rather than re-creating singleton lore,
- point its `## Evidence hook` at exactly one dedicated drift gate under `tools/` so family-member drift is machine-checked instead of reviewer-memory-only.

This contract does **not** add a new schema or workflow. It only keeps the closed family readable, enumerable, and LLM-recoverable as the member set grows.

## Closed companion boundary set (Phase 1)

### 1) User-input requests stay proposal-only until explicit local mediation

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`llm-elicitation-boundary-v0.md`](llm-elicitation-boundary-v0.md) | server/tool/model requests for more user input | requests for login/OAuth/payment/secret entry stay untrusted proposal material only; no hidden browser, token relay, or generic inline secret-ingress plane | explicit IF-CONSENT / trusted UI / secret portal workflow if ever needed |
| [`mcp-elicitation-import-boundary-v0.md`](mcp-elicitation-import-boundary-v0.md) | imported MCP `elicitation/create` mechanics | current MCP form/url request flows, bounded request schemas/defaults, response actions, URL-mode completion notices, and required request association stay provider-local request-scoped user-input mechanics only; no portable secret-ingress, browser/session, or callback/completion plane | explicit local mediation / OpenURI / secret / auth-result seams if ever needed |
| [`mcp-client-registration-import-boundary-v0.md`](mcp-client-registration-import-boundary-v0.md) | imported MCP client registration/bootstrap | current MCP preregistration, DCR, and Client ID Metadata Documents / URL-based `client_id` flows stay provider-local authorization bootstrap only; no portable software-identity oracle, redirect/callback authority, client-registration inventory/admin plane, trust-policy oracle, or authorization-continuation substrate | explicit auth-continuation / auth-result / account-binding / OpenURI seams if ever needed |
| [`mcp-client-trust-policy-import-boundary-v0.md`](mcp-client-trust-policy-import-boundary-v0.md) | imported MCP client trust evaluation / domain-host allowlists / reputation policy | current MCP trusted-client host/domain allowlists, open-server `accept any HTTPS client_id` posture, reputation checks, domain-age / certificate-validation restrictions, and prominent client/CIMD hostname display stay provider-local client trust evaluation only; no portable trusted-app registry, approval-basis substrate, signer/trust-root plane, or durable connected-app/account truth | explicit approval-basis / auth-result / identity-claim / account-binding seams if ever needed |
| [`mcp-pkce-import-boundary-v0.md`](mcp-pkce-import-boundary-v0.md) | imported MCP PKCE handling | current MCP PKCE handling — verifier/challenge pairs, `S256` preference, metadata-confirmed `code_challenge_methods_supported`, and refusal to proceed without confirmed support — stays provider-local authorization code-binding only; no portable verifier/proof truth, PKCE-capability oracle, pending-auth continuation handle, or durable approval/account truth | explicit auth-continuation / auth-proof / auth-result seams if ever needed |
| [`mcp-auth-discovery-import-boundary-v0.md`](mcp-auth-discovery-import-boundary-v0.md) | imported MCP authorization discovery metadata | current MCP Protected Resource Metadata, `WWW-Authenticate` `resource_metadata` / `scope` challenges, `authorization_servers`, and Authorization Server Metadata / OIDC discovery stay provider-local authorization discovery only; no portable issuer registry, authorization-server catalog, scope/tenant/policy oracle, callback authority, or trust/cache substrate | explicit auth-continuation / auth-result / authorization-context / OpenURI seams if ever needed |
| [`mcp-auth-metadata-fetch-import-boundary-v0.md`](mcp-auth-metadata-fetch-import-boundary-v0.md) | imported MCP/OAuth authorization metadata fetch / caching policy | current MCP/OAuth `resource_metadata` URL following, `authorization_servers` URL following, Authorization Server Metadata / OIDC fetches, normal HTTP caching, and related network validation stay provider-local fetch/caching policy only; no portable metadata-cache substrate, issuer-trust oracle, endpoint pinset, SSRF policy plane, or durable approval/evidence artifact | explicit auth-proof / auth-result / authorization-context / OpenURI / network-policy seams if ever needed |
| [`mcp-auth-exact-match-import-boundary-v0.md`](mcp-auth-exact-match-import-boundary-v0.md) | imported MCP/OAuth exact-match resource / issuer / response binding | current MCP/OAuth Protected Resource Metadata `resource` equality, Authorization Server Metadata / OIDC `issuer` equality, and authorization-response `iss` equality stay provider-local exact-match validation only; no portable issuer/resource identity, account-binding truth, response-verdict plane, or durable approval/evidence artifact | explicit auth-result / identity-claim / account-binding / evidence seams if ever needed |
| [`mcp-authorization-context-import-boundary-v0.md`](mcp-authorization-context-import-boundary-v0.md) | imported MCP scope/resource guidance | current MCP `scope` challenges, `scopes_supported`, step-up scope handling, and OAuth `resource` targeting stay provider-local authorization guidance only; no portable grant inventory, entitlement oracle, service-identity registry, or durable approval/account truth | explicit authorization-context / account-binding / login-state / auth-result seams if ever needed |
| [`mcp-step-up-auth-import-boundary-v0.md`](mcp-step-up-auth-import-boundary-v0.md) | imported MCP step-up authentication | current `insufficient_user_authentication`, `acr_values`, `max_age`, and verifier-visible `acr` / `auth_time` / `amr` stay provider-local reauthentication guidance and verifier context only; no portable assurance registry, recent-login oracle, user-presence proof, approval basis, or durable account/session truth | explicit auth-result / login-state / identity-claim / approval-basis / future RFC-first assurance or recent-login workflow if ever needed |
| [`mcp-refresh-token-import-boundary-v0.md`](mcp-refresh-token-import-boundary-v0.md) | refresh tokens / offline_access / background renewal | current `refresh_token`, `grant_type=refresh_token`, `offline_access`, refreshed token-set metadata, client-local token caches, and refresh-token rotation stay provider-local renewal mechanics and provider-owned live auth state only; no portable background-renewal substrate, unattended-delegation policy bit, connected-account truth, token-wallet storage, or durable login-state truth appears on existing seams | explicit background-renewal / offline-delegation / connected-account / login-state continuity seams if ever needed |
| [`mcp-enterprise-managed-auth-import-boundary-v0.md`](mcp-enterprise-managed-auth-import-boundary-v0.md) | imported MCP enterprise-managed auth routing | current MCP enterprise-managed auth routing, enterprise-IdP redirect negotiation, organization-level IdP configuration, IdP-issued token/claim handling, and centralized enterprise policy/revocation stay provider-local authorization routing only; no portable enterprise-policy oracle, account-binding export, authorization-context export, login-state oracle, browser-session continuity plane, or token/callback broker | explicit auth-result / account-binding / authorization-context / login-state seams if ever needed |
| [`mcp-id-jag-import-boundary-v0.md`](mcp-id-jag-import-boundary-v0.md) | imported enterprise identity assertions / ID-JAG token exchange | current saved Identity Assertions (OpenID ID Tokens / SAML assertions), token-exchange `subject_token` use, typed ID-JAGs, optional refresh-driven renewal, and carried identity/authorization claims stay provider-local cross-domain authorization bootstrap only; no portable SSO-proof plane, subject-token store, cross-domain account-binding substrate, approval-basis seam, or durable login-state truth | explicit identity-claim / account-binding / auth-proof / auth-result / future RFC-first cross-domain auth workflow if ever needed |
| [`mcp-token-exchange-import-boundary-v0.md`](mcp-token-exchange-import-boundary-v0.md) | imported OAuth token exchange | current OAuth token exchange — `subject_token`, optional `actor_token`, delegation/impersonation semantics, `resource` / `audience` / `scope` / `requested_token_type`, and exchanged-token response fields — stays provider-local authorization-server token-shaping only; no portable token broker, delegation plane, impersonation substrate, workload-identity bridge, approval-basis seam, or durable login/account truth | explicit auth-result / auth-proof / authorization-context / account-binding / future RFC-first delegation or workload-identity workflow if ever needed |
| [`mcp-client-credentials-import-boundary-v0.md`](mcp-client-credentials-import-boundary-v0.md) | imported MCP client-credentials / machine-auth bootstrap | current MCP OAuth Client Credentials extension support, no-user machine auth, JWT bearer assertions, client-secret authentication, and token-endpoint auth-method selection stay provider-local machine-auth bootstrap only; no portable workload identity plane, service-account registry, client-secret store, signer/JWKS discovery substrate, or durable connected-service truth | explicit vault / auth-proof / auth-result / future RFC-first workload-identity workflow if ever needed |
| [`mcp-client-assertion-import-boundary-v0.md`](mcp-client-assertion-import-boundary-v0.md) | imported JWT client assertions / token-endpoint client-auth metadata | current `client_assertion`, `client_assertion_type`, JWT client-auth claims, `private_key_jwt` / `client_secret_jwt` method choice, and token-endpoint signing/auth-method metadata stay provider-local endpoint client authentication only; no portable signer plane, JWT-assertion store, client-identity registry, auth-method oracle, or endpoint-trust substrate | explicit auth-proof / auth-result / account-binding / future RFC-first signer or endpoint-client-auth workflow if ever needed |
| [`mcp-auth-request-packaging-import-boundary-v0.md`](mcp-auth-request-packaging-import-boundary-v0.md) | imported MCP PAR / Request Object packaging | current PAR endpoints, `require_pushed_authorization_requests`, returned `request_uri` handles, Request Objects carried by value or reference, `require_signed_request_object`, and request-object capability / algorithm metadata stay provider-local authorization-request staging and packaging only; no portable pending-auth handle, approval object, request-template cache, request-policy blob, or durable auth-state / connected-account substrate | explicit auth-continuation / auth-result / auth-proof / future RFC-first approval-object or auth-resume workflow if ever needed |
| [`mcp-auth-response-packaging-import-boundary-v0.md`](mcp-auth-response-packaging-import-boundary-v0.md) | imported JARM response packaging | current JARM response modes, JWT-valued `response` artifacts, issuer/audience/expiry/signature/decryption checks, and response-packaging metadata stay provider-local authorization-response packaging and validation only; no portable callback-result artifact, login-result export, auth-proof object, approval-basis blob, or durable account/session/auth-state substrate | explicit auth-result / auth-proof / approval-basis / login-state / future RFC-first signed-callback or auth-result-object workflow if ever needed |
| [`mcp-userinfo-import-boundary-v0.md`](mcp-userinfo-import-boundary-v0.md) | imported OIDC UserInfo | current `userinfo_endpoint` locations, Bearer-token profile fetches, returned subject/profile/email claims, `sub`-match validation, and signed/encrypted UserInfo metadata stay provider-local identity/profile retrieval and validation only; no portable subject/account/profile export, current-user oracle, approval-basis receipt, contact-card substrate, or durable account/session/auth-state truth | explicit identity-claim export / account-binding / login-state / future RFC-first profile-disclosure or current-account workflow if ever needed |
| [`fedcm-import-boundary-v0.md`](fedcm-import-boundary-v0.md) | imported FedCM browser mediation / Login Status / connected accounts / disconnect | current `navigator.credentials.get({identity: ...})`, provider entries such as `configURL` / `clientId` / `nonce` / `loginHint` / `domainHint`, Login Status API signaling, browser-managed connected accounts/account lists, disconnect choreography, and returned `IdentityCredential.token` stay provider-local browser federated-sign-in mediation only; no portable account chooser, current-user/login-state oracle, connected-account inventory, disconnect control plane, browser-session substrate, or approval-basis receipt | explicit auth-result / identity-claim / account-binding / login-state / auth-teardown / browser-session / future RFC-first browser-federation workflow if ever needed |
| [`mcp-authorization-details-import-boundary-v0.md`](mcp-authorization-details-import-boundary-v0.md) | imported MCP authorization details | current `authorization_details`, per-object `type`, common RAR fields, `authorization_details_types_supported`, granted-detail token/introspection responses, and adjacent RAR metadata/error signaling stay provider-local fine-grained authorization description only; no portable approval object, policy blob, entitlement registry, grant-template store, or durable connected-account/login-state substrate | explicit authorization-context / auth-result / account-binding / future RFC-first fine-grained grant workflow if ever needed |
| [`mcp-device-authorization-import-boundary-v0.md`](mcp-device-authorization-import-boundary-v0.md) | imported MCP device authorization | current `device_authorization_endpoint`, `device_code`, `user_code`, `verification_uri`, optional `verification_uri_complete`, expiry / interval / polling-error semantics, and device-flow token acquisition stay provider-local authorization continuation only; no portable cross-device auth broker, verification-link handoff plane, polling-status oracle, linked-account selector, or durable connected-account/login-state substrate | explicit auth-continuation / auth-result / account-binding / login-state / future RFC-first cross-device auth workflow if ever needed |
| [`mcp-jwks-import-boundary-v0.md`](mcp-jwks-import-boundary-v0.md) | imported MCP JWKS / verifier-key handling | current `jwks_uri`, fetched JWK Sets, verifier-key selection fields, and live key rotation/refresh stay provider-local verifier inputs only; no portable trust-root plane, signer registry, issuer-identity oracle, key-rotation oracle, or durable current-auth-state truth | explicit auth-proof / auth-result / identity-claim / future RFC-first trust-root governance workflow if ever needed |
| [`mcp-token-introspection-import-boundary-v0.md`](mcp-token-introspection-import-boundary-v0.md) | imported MCP token introspection / verifier-response handling | current `introspection_endpoint`, verifier-side `active` / token metadata responses, and verifier cache/eviction pressure stay provider-local verifier inputs only; no portable live login-state oracle, grant inventory, subject/account export, connected-service registry, or durable current-session truth | explicit login-state / identity-claim / authorization-context / auth-result / future RFC-first token-verdict workflow if ever needed |
| [`mcp-token-revocation-import-boundary-v0.md`](mcp-token-revocation-import-boundary-v0.md) | imported MCP token revocation / disconnect handling | current `revocation_endpoint`, revocation requests carrying `token` / optional `token_type_hint`, success-on-invalid behavior, propagation-delay / grant-cascade policy, and revocation-endpoint auth-method metadata stay provider-local auth-teardown machinery only; no portable disconnect control plane, linked-account / connected-service truth, durable live-login-state oracle, account-unlink substrate, or transcript-stable revocation ledger | explicit auth-teardown / account-binding / login-state / auth-result / future RFC-first integration-disconnect workflow if ever needed |
| [`mcp-dpop-import-boundary-v0.md`](mcp-dpop-import-boundary-v0.md) | imported MCP DPoP sender-constraining | current DPoP proof JWTs, embedded public keys, `DPoP-Nonce` challenges, DPoP-bound token metadata, and adjacent authorization-server/client metadata stay provider-local sender-constraining and verifier machinery only; no portable signer plane, proof cache, nonce cache, token-binding oracle, replay ledger, or durable current-account/session truth | explicit auth-proof / auth-result / login-state / account-binding / future RFC-first signer or replay-policy workflow if ever needed |
| [`mcp-token-passthrough-import-boundary-v0.md`](mcp-token-passthrough-import-boundary-v0.md) | imported MCP token audience / no-passthrough semantics | current MCP audience-bound access-token checks, no-token-passthrough rule, resource-specific upstream token handling, and URL-mode third-party auth token split stay provider-local token-boundary mechanics only; no portable token relay, reverse-proxy API substrate, external-service credential export path, callback-token mailbox, or durable token/session broker | explicit auth-result / auth-proof / authorization-context / account-binding / browser-session / auth-continuation seams if ever needed |
| [`mcp-caller-auth-binding-import-boundary-v0.md`](mcp-caller-auth-binding-import-boundary-v0.md) | imported MCP auth/session guidance | current MCP session IDs, inbound-request verification, “sessions are not authentication”, URL-mode same-user checks, and adjacent persistent-auth/per-tool-auth pressure stay provider-local caller-binding and live auth-state mechanics only; no portable current-user export, caller-identity oracle, per-tool authorization registry, tenant-selection substrate, or durable server-authorized-for-user truth | explicit account-binding / login-state / auth-result / auth-proof / future RFC-first caller-auth workflow if ever needed |


### 1a) Imported redirect handling stays provider-local return-channel mechanics only

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`mcp-auth-redirect-import-boundary-v0.md`](mcp-auth-redirect-import-boundary-v0.md) | redirect URIs / native-app return channels / loopback callbacks | registered `redirect_uri` values, exact redirect matching, `localhost`/HTTPS constraints, state verification, localhost warning/display guidance, and native-app private-use / app-claimed-HTTPS / loopback return patterns stay provider-local authorization return-channel mechanics only; they do not become a portable callback registration, deep-link reentry seam, browser-auth/session plane, loopback-listener allocation, or auth-result truth | explicit auth-continuation / auth-result / OpenURI auth-session / loopback-listener seams if ever needed |

### 1b) Imported PKCE handling stays provider-local code-binding only

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`mcp-pkce-import-boundary-v0.md`](mcp-pkce-import-boundary-v0.md) | verifier/challenge pairs / PKCE support detection / `S256` preference | current MCP PKCE handling — verifier/challenge pairs, `S256` preference, metadata-confirmed `code_challenge_methods_supported`, and refusal to proceed without confirmed support — stays provider-local authorization code-binding only; it does not become portable verifier/proof truth, a PKCE-capability oracle, a pending-auth continuation handle, or durable approval/account truth | explicit auth-continuation / auth-proof / auth-result seams if ever needed |

### 2) App-secret ingress stays provider-issued seed issuance only

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`appsecret-secret-ingress-boundary-v0.md`](appsecret-secret-ingress-boundary-v0.md) | app-seed ingress/import semantics | `portal.secret` issues provider-derived app seeds only; it does not become a portable password/API-key/OAuth-token paste-store or account-linking seam | future RFC-first credential-ingress workflow if ever needed |

### 3) Vault refs stay secret-object authority, not credential mediation

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`vault-credential-mediation-boundary-v0.md`](vault-credential-mediation-boundary-v0.md) | vault-vs-credential-mediation surface split | D-VAULT / CH-SECRETREF stay secret-object authority only; they do not become a portable password-manager, autofill, passkey, account-selection, or auth-result seam | future RFC-first credential-provider / account-choice workflow if ever needed |

### 4) Local sign-in does not become credential-enrollment control

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`credential-enrollment-boundary-v0.md`](credential-enrollment-boundary-v0.md) | passkey-registration / authenticator-enrollment / account-upgrade control semantics | explicit local login or credential mediation does not yield a portable credential-enrollment, passkey-registration, or equivalent control seam | future RFC-first credential-enrollment workflow if ever needed |

### 5) Local sign-in does not become credential exchange

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`credential-exchange-boundary-v0.md`](credential-exchange-boundary-v0.md) | password-manager migration / passkey portability / credential import-export semantics | explicit local login or credential mediation does not yield a portable password-manager migration, passkey portability, or equivalent credential-exchange seam | future RFC-first credential portability workflow if ever needed |

### 6) Local sign-in does not become browser-session export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`browser-session-export-boundary-v0.md`](browser-session-export-boundary-v0.md) | cookie-jar / authenticated-browser-session / replay-blob semantics | explicit local login or credential mediation does not yield a portable cookie jar, authenticated browser profile, or replayable browser-session export seam | future RFC-first session-continuity workflow if ever needed |

### 7) Local sign-in does not become auth continuation export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-continuation-export-boundary-v0.md`](auth-continuation-export-boundary-v0.md) | pending-auth / continuation-handle / PKCE-device-backchannel relay semantics | explicit local login or credential mediation does not yield a portable PKCE verifier, device-flow code bundle, verification URL, `auth_req_id`, or equivalent pending-auth / continuation-handle seam | future RFC-first auth-resume / pending-auth brokerage workflow if ever needed |

### 8) Auth challenges do not become account-linking trigger authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-link-ui-trigger-boundary-v0.md`](auth-link-ui-trigger-boundary-v0.md) | auth-linking / account-choice / auth-broker trigger semantics | auth metadata/challenges may ask the host to offer local linking UI, but they do not yield a portable account-linking, account-choice, or auth-broker trigger seam | future RFC-first account-broker / linking workflow if ever needed |

### 9) Local sign-in does not become auth-result export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-result-export-boundary-v0.md`](auth-result-export-boundary-v0.md) | authorization-code / token-set / callback-result export semantics | explicit local login or credential mediation does not yield a portable authorization code, token set, callback result, or generic login-result export seam | future RFC-first callback / token broker if ever needed |

### 10) Local sign-in does not become auth-proof export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-proof-export-boundary-v0.md`](auth-proof-export-boundary-v0.md) | DPoP / challenge-signing / authenticator-assertion / certificate-proof export semantics | explicit local login or credential mediation does not yield a portable DPoP proof, client assertion, WebAuthn assertion, challenge signature, or equivalent auth-proof export seam | future RFC-first proof-broker workflow if ever needed |

### 11) Local sign-in does not become authorization-context export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`authorization-context-export-boundary-v0.md`](authorization-context-export-boundary-v0.md) | granted-scope / resource-indicator / authorization-details / entitlement export semantics | explicit local login or credential mediation does not yield a portable granted-scope, resource-indicator, authorization-details, permission, or entitlement export seam | future RFC-first grant-context workflow if ever needed |

### 12) Local sign-in does not become identity/profile export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`identity-claim-export-boundary-v0.md`](identity-claim-export-boundary-v0.md) | subject / issuer / email / profile / account-identity export semantics | explicit local login or credential mediation does not yield a portable subject, issuer, email, profile, or account-identity export seam | future RFC-first identity/profile disclosure workflow if ever needed |

### 13) Local sign-in does not become account-binding export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`account-binding-export-boundary-v0.md`](account-binding-export-boundary-v0.md) | linked-account / connected-account / default-account export semantics | explicit local login, linking, or provider-owned account mapping does not yield a portable linked-account, connected-account, selected-account, or default-account export seam | future RFC-first account-binding / connected-account workflow if ever needed |

### 14) Local sign-in does not become login-state export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`login-state-export-boundary-v0.md`](login-state-export-boundary-v0.md) | signed-in / login-status / session-state / account-availability semantics | explicit local login or credential mediation does not yield a portable signed-in status, session-state, or account-availability export seam | future RFC-first login-status workflow if ever needed |

### 15) Local sign-in does not become auth teardown

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-teardown-boundary-v0.md`](auth-teardown-boundary-v0.md) | logout / disconnect / revoke / unlink-account control semantics | explicit local login or credential mediation does not yield a portable logout, disconnect, revoke, or unlink-account control seam | future RFC-first sign-out / disconnect / revocation workflow if ever needed |

## Review rule

Before adding another explicit-local-auth / credential-mediation companion boundary doc, answer these questions in order:
1) Is the change really an **auth-mediation meaning pin** rather than a new schema, workflow, or provider family?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported browser/credential/login folklore?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.

The closed-set row/table, `boundary-family-map.md` member list, and runbook family-member bullet must enumerate the **same member set in the same revision**; do not let a new family member land in only one recovery surface.

## Wiring

This index must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_auth_mediation_boundary_index.py` fails `make lint` if this companion family stops being discoverable, loses its closed member set, or drops its same-revision maintenance contract (**EVID-2026-622**).
- `tools/check_auth_mediation_family_contract.py` fails `make lint` if any auth-mediation family member drops the shared member-contract shape (family attachment clause, required recovery sections, explicit no-new-schema / no-new-ACP / no-new-conflict-key posture, or single dedicated checker) (**EVID-2026-628**).
- `tools/check_auth_mediation_member_coverage.py` fails `make lint` if the auth-mediation closed-set row/table, `boundary-family-map.md` member list, or runbook family-member bullet drift out of sync (**EVID-2026-708**).

## References

- REF-MCP-ELICITATION.
- REF-MCP-SECURITY-BEST-PRACTICES.
- REF-MCP-AUTHORIZATION-TUTORIAL.
- REF-MCP-CALLER-IDENTITY-CONFUSION.
- REF-MCP-AUTH-EXTENSIONS.
- REF-MCP-AUTHORIZATION.
- REF-MCP-ROADMAP-2026.
- REF-MCP-OAUTH-CLIENT-CREDENTIALS.
- REF-MCP-ENTERPRISE-MANAGED-AUTH.
- REF-IETF-DRAFT-ID-JAG.
- REF-RFC8693-TOKEN-EXCHANGE.
- REF-MCP-SEP-991.
- REF-MCP-SEP-985.
- REF-OAUTH-CLIENT-ID-METADATA.
- REF-MCP-AUTH-SECURITY.
- REF-RFC8252-NATIVE-APPS.
- REF-RFC9700-OAUTH-SECURITY.
- REF-OPENID-JARM.
- REF-RFC7517-JWK.
- REF-XDG-PORTAL-SECRET.
- REF-ANDROID-CREDENTIAL-MANAGER.
- REF-W3C-PASSKEY-ENDPOINTS.
- REF-ANDROID-PASSKEY-CREATE.
- REF-APPLE-PASSKEY-REGISTRATION-REQUEST.
- REF-APPLE-CREDENTIAL-EXPORT-MANAGER.
- REF-APPLE-CREDENTIAL-IMPORT-MANAGER.
- REF-FIDO-CXF.
- REF-RFC7636-PKCE.
- REF-OPENAI-APPS-SDK-AUTH.
- REF-RFC9728-PROTECTED-RESOURCE-METADATA.
- REF-RFC8414-AS-METADATA.
- REF-RFC9126-PAR.
- REF-RFC9101-JAR.
- REF-RFC9207-AUTHZ-SERVER-ISSUER.
- REF-OPENID-DISCOVERY.
- REF-RFC9470-STEP-UP-AUTH.
- REF-RFC6749-OAUTH-AUTHZ-FRAMEWORK.
- REF-OPENID-CONNECT-CORE.
- REF-RFC9700-OAUTH-SECURITY.
- REF-RFC8628-DEVICE-GRANT.
- REF-OPENID-CIBA-CORE.
- REF-RFC9449-DPOP.
- REF-RFC8705-OAUTH-MTLS.
- REF-RFC6749-OAUTH-AUTHZ-FRAMEWORK.
- REF-RFC8707-RESOURCE-INDICATORS.
- REF-RFC9396-RICH-AUTHORIZATION-REQUESTS.
- REF-DRAFT-ZEHAVI-RAR-METADATA.
- REF-RFC7662-TOKEN-INTROSPECTION.
- REF-OPENID-CONNECT-CORE.
- REF-W3C-FEDCM.
- REF-W3C-LOGIN-STATUS.
- REF-OPENAI-APPS-SDK-STATE.
- REF-MCP-ENTERPRISE-MANAGED-AUTH.
- REF-MCP-OAUTH-CLIENT-CREDENTIALS.
- REF-MCP-SEP-1046.
- REF-OPENID-CONNECT-SESSION.
- REF-RFC7009-TOKEN-REVOCATION.
- REF-RFC7523-JWT-BEARER.
- REF-OPENID-RP-INITIATED-LOGOUT.
