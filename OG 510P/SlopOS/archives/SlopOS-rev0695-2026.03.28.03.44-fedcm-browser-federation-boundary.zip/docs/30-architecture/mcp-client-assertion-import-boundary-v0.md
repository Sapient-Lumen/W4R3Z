# D-LLM MCP-client-assertion import boundary v0 (endpoint client auth is not portable signer / assertion / client-identity truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported OAuth/MCP token-endpoint client-auth material — `client_assertion`, `client_assertion_type`, JWT client-auth claims (`iss`, `sub`, `aud`, `exp`, `iat`, `jti`), `private_key_jwt` / `client_secret_jwt` method selection, and advertised token-endpoint signing/auth-method metadata — is **provider-local endpoint client authentication only**. It does **not** create a portable signer plane, JWT-assertion store, client-identity registry, auth-method oracle, or endpoint-trust substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported client-auth assertion semantics may be interpreted next to already-pinned client-credentials, DPoP, auth-proof, auth-discovery, auth-metadata-fetch, JWKS, token-introspection, token-revocation, caller-auth-binding, and identity/account boundaries.

## Posture (v0)

1) **Imported `client_assertion` material stays provider-local endpoint client authentication only.**
   - Current MCP machine-auth guidance recommends JWT bearer assertions, and RFC 7523 defines JWT bearer use for OAuth client authentication at the token endpoint.
   - That assertion material remains provider-local endpoint client authentication only; it does **not** create a portable auth-proof export seam, reusable signer service, or durable approval/evidence artifact on existing SlopOS seams.
   - Existing auth-proof export, auth-result, and client-credentials boundaries stay authoritative instead of inheriting hidden meaning from one provider's client assertion format.

2) **Imported JWT client-auth claims stay provider-local verifier input only.**
   - RFC 7523 profiles client-auth JWTs with claims such as `iss`, `sub`, `aud`, `exp`, `iat`, and optional replay-relevant identifiers such as `jti`, all interpreted by one authorization server for one client-auth decision.
   - Those claims remain provider-local verifier input only; they do **not** become a portable client-identity registry, workload-identity token, account-binding receipt, or transcript-stable proof object on existing SlopOS seams.
   - Existing identity-claim, account-binding, login-state, and client-credentials boundaries stay authoritative instead of inheriting platform meaning from one client-auth JWT.

3) **Imported `private_key_jwt` / `client_secret_jwt` method choice stays provider-local auth-method policy only.**
   - RFC 8414 advertises `token_endpoint_auth_methods_supported` and `token_endpoint_auth_signing_alg_values_supported`, explicitly naming JWT-based methods such as `private_key_jwt` and `client_secret_jwt`.
   - Those method names and advertised signing algorithms remain provider-local auth-method policy only; they do **not** become a portable signer-capability oracle, secret-policy truth, token-endpoint trust plane, or current-provider compatibility receipt on existing SlopOS seams.
   - Existing client-trust-policy, auth-metadata-fetch, JWKS, and auth-proof boundaries stay authoritative instead of inheriting platform meaning from one provider's advertised client-auth menu.

4) **Imported client-auth verifier outcomes stay provider-local endpoint admission only.**
   - A provider validating one client assertion or one JWT-based client-auth method may admit a token request, reject it, or require different client-auth policy for that one endpoint interaction.
   - Those verifier outcomes remain provider-local endpoint admission only; they do **not** become a portable connected-service verdict, service-account truth, signer approval basis, or durable current-auth-state oracle on existing SlopOS seams.
   - Existing account-binding, login-state, caller-auth-binding, and token-passthrough boundaries stay authoritative instead of inheriting platform meaning from one token-endpoint verifier decision.

5) **No silent signer / assertion / client-identity widening rides in through endpoint client auth.**
   - Imported endpoint client-auth mechanics do **not** authorize portable key export, assertion caching, cross-provider replay, current-user export, connected-account export, or generic external-service signing by implication.
   - A successful `client_assertion` may let one provider continue one machine-auth path, but it does **not** standardize portable signer/assertion/client-identity semantics on adjacent SlopOS seams.
   - If SlopOS ever needs a native signer broker, assertion lifecycle workflow, or endpoint-client-auth registry, that work must arrive on those explicit seams and validators directly.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth libraries, JWT client-auth helpers, key stores, or metadata-driven auth-method selectors must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient signing keys, hidden assertion caches, or implicit endpoint metadata fetches must fail closed for portable D-LLM auth semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local endpoint verification, explicit reviewed auth/login boundaries, explicit proof/export boundaries, and explicit evidence artifacts.
   - Any future native signer/assertion/client-auth workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported `client_assertion` helpers or token-endpoint auth-method metadata.

## Phase 1 non-goals (explicitly deferred)

- No portable `client_assertion`, `client_assertion_type`, signed JWT assertion store, or equivalent endpoint-client-auth substrate imported directly from MCP/OAuth helpers.
- No rule that JWT client-auth claims such as `iss`, `sub`, `aud`, `exp`, `iat`, or `jti` stand in for portable client identity, workload identity, account binding, or durable auth-proof truth.
- No rule that `private_key_jwt`, `client_secret_jwt`, `token_endpoint_auth_methods_supported`, or `token_endpoint_auth_signing_alg_values_supported` stand in for portable signer capability, secret policy, endpoint trust, or cross-provider compatibility truth.
- No rule that successful token-endpoint client-auth validation stands in for portable connected-service truth, signer approval, service-account registration, or durable current-auth-state semantics.

## Why this is worth pinning

The archive already keeps machine auth, verifier keys, token introspection, token revocation, token passthrough, auth-proof export, and login/account semantics on separate explicit seams. But current MCP machine-auth guidance leans on another adjacent surface: **JWT-based endpoint client authentication**, where one provider may accept a signed `client_assertion`, advertise `private_key_jwt` / `client_secret_jwt` support, and expose signing-alg metadata for token-endpoint admission.

That looks like a narrow implementation detail, but it is exactly where invisible substrate grows. Once wrappers and agents start seeing JWT client assertions and advertised auth methods, `client_assertion` becomes “the platform's reusable signer”, token-endpoint auth metadata becomes “our compatibility oracle”, and one provider's client-auth verifier outcome starts masquerading as generic service-account or connected-service truth.

Pinning the boundary now keeps the archive honest. Imported endpoint client authentication may remain a provider-local way to authenticate one client to one token endpoint, but it does not get to redefine signer authority, assertion lifecycle, client identity, endpoint trust, or durable connected-service truth on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with providers that require JWT client assertions, but provider-local endpoint client auth still does not become a portable signer or connected-account story.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted workers and gateways will be tempted to centralize client assertions and auth-method compatibility, but those helpers do not become tenant-stable signer, identity, or service-account substrate by default.
- **Embedded / separation appliance (C):** appliances can omit JWT endpoint client auth entirely or terminate it in a narrow shim without importing a generalized signer/assertion subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported client-auth assertions may help one provider-owned machine-auth path proceed, but they do not become a second signer/assertion/identity substrate beside explicit auth-proof, vault, account-binding, and login-state seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_client_assertion_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “endpoint client auth is not portable signer / assertion / client-identity truth” posture drifts (**EVID-2026-688**).

## References

- `REF-MCP-OAUTH-CLIENT-CREDENTIALS`
- `REF-RFC7523-JWT-BEARER`
- `REF-RFC8414-AS-METADATA`
- `REF-RFC9700-OAUTH-SECURITY`
