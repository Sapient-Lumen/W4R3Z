# D-LLM / D-POLICY / IF-ACP Digital Credentials API import boundary v0 (browser wallet mediation is not portable wallet / chooser / approval truth)

Purpose: pin one compact Phase-1 rule on the existing **D-LLM / D-POLICY / IF-ACP** seams, attached to the existing verifiable-credential ecosystem companion family in `verifiable-credential-ecosystem-boundary-index.md`: imported W3C Digital Credentials API semantics — `navigator.credentials.get()` / `navigator.credentials.create()` with `digital.requests[]`, protocol gating via `DigitalCredential.userAgentAllowsProtocol()`, `DigitalCredentialGetRequest` / `DigitalCredentialCreateRequest`, `DigitalCredential.data`, user-agent credential chooser mediation, `digital-credentials-get` Permissions Policy delegation, and adjacent abort / encryption / cross-device wallet handoff expectations — are **provider-local browser wallet mediation only**. They do **not** create a portable wallet chooser result, wallet inventory, current-user oracle, credential-wallet substrate, approval-basis object, connected-device truth, or durable account/session truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported browser credential-mediation material may be interpreted next to already-pinned OpenURI credential mediation, OpenID4VP / OpenID4VCI, DID / trust-registry, approval-basis, identity-claim, login-state, and auth-mediation meaning cuts.

## Posture (v0)

1) **Imported browser credential requests stay provider-local chooser mediation only.**
   - The W3C Digital Credentials API specifies a browser-mediated way to request presentation or issuance of digital credentials through `navigator.credentials.get()` / `navigator.credentials.create()` with `digital.requests[]`, where each request names one protocol and protocol-specific `data`.
   - Imported `digital.requests[]`, `DigitalCredentialGetRequest`, `DigitalCredentialCreateRequest`, protocol strings, protocol-specific request `data`, and returned `DigitalCredential.data` stay provider-local browser wallet mediation only; they do **not** become a portable wallet chooser result, pending-proof handle, callback result, credential import, approval-basis object, or durable subject/account/current-user truth on existing SlopOS seams.
   - Existing OpenID4VP / OpenID4VCI, auth-result, identity-claim, approval-basis, and verification-verdict seams stay authoritative instead of inheriting portable truth from one browser-mediated credential exchange.

2) **Imported chooser and protocol-support hints stay provider-local browser capability checks only.**
   - The Digital Credentials API allows user agents to expose protocol support checks such as `DigitalCredential.userAgentAllowsProtocol()` and to mediate presentation/issuance through a user-agent-managed chooser when the platform supports it.
   - Imported protocol-support answers, chooser availability, browser-local wallet mediation behavior, and platform capability hints stay provider-local browser capability checks only; they do **not** become a portable wallet inventory, verifier-policy selector, current-user oracle, device-capability registry, or approval receipt on existing SlopOS seams.
   - Existing D-LLM planning, D-POLICY choice, and explicit verification-policy-selection surfaces stay authoritative instead of inheriting portable chooser or capability truth from one browser runtime.

3) **Imported cross-origin and cross-device mediation mechanics stay provider-local transport choreography only.**
   - The Digital Credentials API defines a `digital-credentials-get` Permissions Policy delegation path for cross-origin iframe use and supports same-device and cross-device wallet mediation patterns depending on platform/user-agent capabilities.
   - Imported permissions-policy delegation, iframe mediation, cross-device handoff expectations, and browser transport choreography stay provider-local mediation only; they do **not** become a portable callback/browser/listen authority, connected-device truth, background watch plane, or durable linked-account/session substrate on existing SlopOS seams.
   - Existing OpenURI/browser/auth-mediation boundaries stay authoritative instead of inheriting portable browser-session, callback, device-link, or login-state meaning from Digital Credentials API handoff mechanics.

4) **Imported privacy/security affordances stay provider-local protocol expectations only.**
   - The Digital Credentials API is designed around browser mediation, encrypted credential responses, and protocol-defined privacy properties such as minimizing linkability and reducing “phone home” dependence where possible.
   - Imported encrypted-response expectations, unlinkability claims, issuer-involvement limits, and abort/cancel semantics stay provider-local protocol expectations only; they do **not** become a portable approval proof, privacy verdict, evidence receipt, revocation/account-state oracle, or durable current-user truth on existing SlopOS seams.
   - Existing evidence, verification-verdict, approval-basis, and policy surfaces stay authoritative instead of inheriting portable “browser-mediated therefore trustworthy” meaning from one credential protocol or user-agent.

5) **No silent wallet/browser widening rides in through the Digital Credentials API.**
   - Imported browser credential mediation does **not** authorize portable wallet chooser receipts, wallet-provider selection truth, current-user truth, credential inventory, approval-basis meaning, connected-device truth, or durable login/account truth by implication.
   - A verifier or issuer may use the Digital Credentials API plus OpenID4VP, OpenID4VCI, or ISO mdoc-compatible protocol data to complete one provider-local browser-mediated credential exchange, but that does **not** standardize a native wallet substrate, chooser/result API, or browser-trusted identity plane on D-LLM, D-POLICY, IF-ACP, or adjacent browser/identity/approval seams.
   - If SlopOS ever needs native wallet mediation, credential chooser results, or browser-trusted credential exchange artifacts, that work must arrive RFC-first on explicit schemas, validators, conflict keys, evidence hooks, and kill switches rather than inheriting folklore from Digital Credentials API convenience.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of browser wallet mediation, protocol-support checks, cross-origin delegation, cross-device helpers, or wallet-provider adapters must be killable by policy and must not create authority via hidden paths, env vars, implicit network access, silently persistent browser state, or ambient wallet defaults.
   - A compat layer that cannot proceed without ambient browser identity state, hidden wallet selection defaults, implicit device pairing, or hidden protocol/provider allowlists must fail closed for portable SlopOS authority semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: IF-ACP validation, exact action bytes, explicit capabilities/approvals, explicit D-POLICY handles/bundles, explicit OpenURI / auth-mediation seams, and explicit verifier-owner policy choice.
   - Any future native wallet chooser result, browser-mediated credential exchange receipt, or browser-trusted identity workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting them from `navigator.credentials.*`, chooser UI, protocol-support hints, or returned credential payloads.

## Phase 1 non-goals (explicitly deferred)

- No portable wallet chooser result or wallet-provider selection receipt imported directly from browser credential mediation.
- No portable rule that `DigitalCredential.data`, protocol-specific request/response objects, or cross-device handoff results stand in for CH-ACP, identity-claim export, account-binding, verification-verdict, or approval-basis truth.
- No portable rule that browser protocol support checks, chooser availability, or permissions-policy delegation stand in for SlopOS policy choice, wallet inventory, device capability, or callback/browser authority.
- No portable rule that encrypted-response expectations, abort/cancel behavior, or user-agent mediation imply a privacy verdict, approval proof, or durable current-user/login-state truth.

## Why this is worth pinning

This is the next small, high-leverage cut next to the existing OpenID4VP / OpenID4VCI / VC-status / DID / trust-registry family. Once those imported credential ecosystems are pinned provider-local only, the next tempting shortcut is “fine, trust what the browser’s wallet chooser returned.” In practice that means over-reading `navigator.credentials.get()` / `.create()`, protocol-support probes, chooser UI, permissions-policy delegation, and returned `DigitalCredential.data` as if they were portable wallet selection truth, browser-trusted current-user truth, approval proof, or a native wallet substrate.

The Digital Credentials API is useful precisely because it standardizes browser mediation for presentation and issuance. That is exactly why the archive should pin its meaning early: imported browser wallet mediation is a valuable compatibility surface, but it does not get to redefine wallet truth, identity truth, approval basis, or connected-device/account truth on SlopOS.

Pinning the boundary now keeps the archive honest. Imported browser-mediated credential exchanges may remain a provider-local way to request or issue one credential interaction, but they do not become a portable wallet chooser API, credential-wallet substrate, browser-trusted identity plane, approval-basis object, or durable current-user truth inside SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may interoperate with browser-mediated wallet UX, but chooser results and returned digital credentials do not become portable current-user cards, approval proofs, or wallet-import semantics.
- **Cloud micro-VM / hosted compute substrate (B):** hosted control planes may terminate browser-mediated credential exchanges at an edge or admin console, but imported chooser and credential payloads do not become a portable account registry, issuer-policy selector, or durable connected-device/session substrate.
- **Embedded / separation-kernel-ish appliance (C):** appliance builds can omit browser wallet mediation entirely or terminate it in a narrow shim without importing a generic chooser/browser/device-pairing story they do not want.
- **Agent / automation OS (D):** first-class agents are exactly where browser-mediated credential results are easiest to over-read as “the browser authenticated this user”; this boundary keeps agent memory/tooling from silently normalizing that widening.

## Family status (Phase 1)

This doc is a member of the closed verifiable-credential ecosystem companion family indexed by `verifiable-credential-ecosystem-boundary-index.md`.
It stays there with `openid4vp-import-boundary-v0.md`, `openid4vci-import-boundary-v0.md`, `verifiable-credential-status-import-boundary-v0.md`, `did-document-import-boundary-v0.md`, and `credential-trust-registry-import-boundary-v0.md` so browser mediation, presentation, issuance, status, DID, and trust-registry meaning pins remain discoverable together.
If future reviewed wallet / credential / DID-import cuts appear, add them to that family **in the same revision** rather than letting them regrow as adjacent singletons.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/verifiable-credential-ecosystem-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Evidence id:** `EVID-2026-709`
- `tools/check_digital_credentials_api_import_boundary.py` fails `make lint` if this boundary, its family membership, discovery wiring, or its “browser wallet mediation is not portable wallet / chooser / approval truth” posture drifts.
- Attached to existing assurance surfaces: **I-LLM-1**, **PO-ACT-VALIDATE**, **PO-POLICY-NONAMP**.

## References

- `REF-W3C-DIGITAL-CREDENTIALS`
- `REF-OPENID-4VP-1-0`
- `REF-OPENID-4VCI-1-0`
