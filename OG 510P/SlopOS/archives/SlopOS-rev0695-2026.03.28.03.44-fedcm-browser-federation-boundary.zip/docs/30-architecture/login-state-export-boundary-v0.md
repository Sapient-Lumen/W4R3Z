# Login-state export boundary v0 (no portable signed-in / login-status / session-state export seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable signed-in / logged-in / account-available / session-state export surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how login/account/session state may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the user appears signed in locally” into a portable status oracle.

## Posture (v0)

1. **No portable login-state export seam in v0**
   - Phase 1 does **not** export a portable `logged_in`, `logged_out`, `login_status`, `session_state`, `signed_in`, `signed_out`, `has_session`, `has_login`, `auth_state`, `idp_state`, `account_state`, `active_account`, `default_account`, `primary_account`, `available_accounts`, `account_count`, `reauth_available`, `silent_sign_in_available`, `fedcm_status`, or equivalent signed-in/account-state handoff on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, auth providers, and credential managers may maintain provider-local session/login/account state and request-local account-availability knowledge, but that state remains provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user finished or currently has a local sign-in session” as permission to mint or return a reusable signed-in / account-available / session-state result across components/cells.

2. **Login/account/session state is not a generic secret object, approval, or receipt outcome**
   - Signed-in state, account availability, and session-status bits may be security- and privacy-sensitive, but they are not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because they matter operationally.
   - **D-APPSECRET** remains about provider-derived app seeds, not about returning `logged_in`, `has_session`, `active_account`, or equivalent account/session state.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about claiming that a user is currently signed in, that one provider session remains live, or that one exact account is available/selectable.
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about returning login/account/session status as the outcome of local approval.

3. **Explicit local login/credential mediation is not permission to mint or relay login/account state**
   - Existing ecosystems distinguish user-mediated sign-in from generic login-state export. OpenID Connect Session Management defines an explicit opaque `session_state` parameter and dedicated login-status checking flow at the OpenID Provider. The W3C Login Status API likewise defines a dedicated browser-maintained Login Status map keyed by origin, with states such as `unknown`, `logged-in`, and `logged-out`. The common lesson is narrow: signed-in/session/account-availability state is a first-class auth/browser artifact, not harmless launch residue or secret-store side effect.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user complete a sign-in flow, but that does **not** justify returning `logged_in`, `session_state`, `active_account`, `available_accounts`, or equivalent signed-in/account-state material on existing generic seams.
   - If a future product shape needs reviewed login-state brokerage, it must return RFC-first with its own authority object, privacy model, freshness/replay story, trusted-UI bindings, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to signed-in probing, account availability scraping, or session-state echo**
   - Agent tooling, shells, compat cells, and wrappers may propose “open this login page” or “use local sign-in,” but they must not silently inspect browser account lists, probe provider-specific signed-in state, infer account availability from hidden browser/account-manager APIs, scrape chooser UI, or relay session-status/account-availability bits back as generic outputs.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient account/session-state channels through paths, env, hidden browser helpers, browser/profile stores, account-manager side APIs, or implicit network reachability.
   - It also keeps **D-LLM** honest: a model may propose an auth workflow, but it does not gain portable signed-in/account-state authority merely because the user authenticated somewhere locally.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local browser/auth/account/session internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed login-state brokerage seam must state its own conflict keys, commutativity preconditions, serialization point, freshness model, trusted-UI bindings, privacy boundaries, and evidence story explicitly rather than inheriting folklore from browser session-check APIs, IdP status headers, or account-manager helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `logged_in` / `login_status` / `session_state` / `active_account` / `available_accounts` export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded reusable signed-in/account/session state.
- No shell/helper fallback that quietly converts local sign-in into signed-in probing, account-availability scraping, or session-state relay authority.
- No new CH-ACP kind or conflict-key family for login/account-state brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenient mistake after the recent browser/auth-result/identity cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” “vault refs are not credential mediation,” “local sign-in is not browser-session export,” “local sign-in is not auth-result export,” and “local sign-in is not identity-claim export,” the next convenience instinct is obvious: “fine, then just tell the tool whether the user is signed in and which account is available.” That sounds narrower than handing over a token set or profile payload, but in practice it still recreates a generic ambient identity/session oracle through signed-in bits, session-state echoes, and account-availability results that are difficult to reason about across product shapes and privacy regimes.

Pinning the boundary now keeps SlopOS from quietly turning reviewed local login mediation into portable signed-in/account-state export authority. It also leaves future work a clean choice: if the system ever needs explicit login-state brokerage, it can arrive as a small RFC-first seam with exact freshness, privacy, and evidence semantics rather than as folklore smeared across launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local sign-in UX, but that does not standardize `logged_in`, `session_state`, or account-availability return as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake session-oracle or “is the user signed in?” helper machinery they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local login flows where useful without promising a general signed-in/account-state export/import substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user completed or still has a login locally” with permission to receive `logged_in`, `session_state`, `active_account`, `available_accounts`, or equivalent account/session-state artifacts; reviewed login-state workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_login_state_export_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable login-state export seam / login-account-session state is not a generic secret object-approval-or-receipt outcome / explicit login mediation is not permission to mint or relay login-account state / no hidden signed-in-probing-account-availability-session-state fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-620**).

## References

- REF-OPENID-CONNECT-SESSION.
- REF-W3C-LOGIN-STATUS.
