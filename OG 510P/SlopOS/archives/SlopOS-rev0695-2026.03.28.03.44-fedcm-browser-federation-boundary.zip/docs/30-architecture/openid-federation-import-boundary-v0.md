# D-LLM / D-POLICY / IF-ACP OpenID Federation import boundary v0 (federation trust bootstrap is not portable issuer / app-trust / policy truth)

Purpose: pin one compact Phase-1 rule on the existing **D-LLM / D-POLICY / IF-ACP** seams: imported OpenID Federation semantics — Entity Configurations, Subordinate Statements / Entity Statements, Trust Chains, `authority_hints`, `trust_anchor_hints`, metadata and `metadata_policy`, `constraints`, Trust Marks and Trust Mark delegations, resolver/subordinate-listing responses, Trust Mark status/listing responses, federation historical keys, and endpoint metadata such as `federation_fetch_endpoint` / `federation_list_endpoint` / `federation_resolve_endpoint` — are **provider-local federation trust bootstrap only**. They do **not** create a portable issuer registry, trust-root plane, app-trust oracle, policy selector, approval-basis object, or durable connected-entity/account truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported federation trust-bootstrap material may be interpreted next to already-pinned D-POLICY, approval-basis, identity-claim, account-binding, login-state, signer/trust-root, and metadata-fetch meaning cuts.

## Posture (v0)

1) **Imported Entity Configurations, Entity Statements, and Trust Chains stay provider-local federation trust bootstrap only.**
   - OpenID Federation standardizes signed Entity Configurations and Entity Statements that can be assembled into Trust Chains rooted in one chosen Trust Anchor.
   - Imported Entity Configurations, Subordinate Statements, Trust Chains, header-carried trust chains, and chain-validation outcomes remain provider-local federation trust bootstrap only; they do **not** become a portable issuer registry, trusted-app registry, signer/trust-root plane, approval object, or durable connected-entity/account truth on existing SlopOS seams.
   - Existing approval, account-binding, identity-claim, and signature-trust-root boundaries stay authoritative instead of inheriting portable trust meaning from one external federation chain.

2) **Imported metadata and federation policy stay provider-local compatibility/narrowing only.**
   - OpenID Federation carries protocol metadata plus `metadata_policy` and `constraints` so superiors and trust anchors can narrow or constrain subordinate metadata.
   - Imported metadata blobs, policy operators, naming/path/entity-type constraints, and resolved metadata remain provider-local compatibility/narrowing only; they do **not** become a portable policy catalog, tenant-governance plane, endpoint-trust selector, approval-basis object, or global app-compatibility oracle on existing SlopOS seams.
   - Existing D-POLICY selection, auth-metadata-fetch, and trust-root boundaries stay authoritative instead of inheriting portable policy/trust meaning from one federation policy tree.

3) **Imported Trust Marks and Trust Mark delegations stay provider-local conformance hints only.**
   - OpenID Federation standardizes Trust Marks, Trust Mark delegation JWTs, status checks, and listings so a federation can express scoped conformance or accreditation signals.
   - Imported Trust Marks, Trust Mark delegation JWTs, Trust Mark status responses, and trust-mark listing results remain provider-local conformance hints only; they do **not** become a portable approval basis, certification registry, trusted-app badge plane, or durable entitlement/account truth on existing SlopOS seams.
   - Existing approval-basis, signer/trust-root, and identity/account surfaces stay authoritative instead of inheriting durable truth from one federation accreditation signal.

4) **Imported federation endpoints and resolve/list responses stay provider-local discovery/cache only.**
   - OpenID Federation defines fetch, list, resolve, Trust Mark, Trust Mark status/listing, and historical-keys endpoints, and resolve responses may return resolved metadata plus the Trust Chain used.
   - Imported endpoint URLs, resolve responses, subordinate listings, cached resolved metadata, historical-key responses, and resolver caches remain provider-local discovery/cache only; they do **not** become a portable issuer catalog, current-trust oracle, connected-service inventory, account directory, or durable policy/account truth on existing SlopOS seams.
   - Existing chooser, inventory, metadata-fetch, and explicit export seams stay authoritative instead of inheriting portable catalog/current-state meaning from one federation resolver.

5) **Imported authority hints and trust-anchor selection stay provider-local routing only.**
   - OpenID Federation lets entities publish `authority_hints` and `trust_anchor_hints`, and lets resolvers choose one Trust Anchor when assembling and validating a Trust Chain.
   - Imported authority hints, trust-anchor hints, and chosen-trust-anchor identifiers remain provider-local routing only; they do **not** become a portable trust-root selector, app-governance default, tenant/issuer chooser result, or durable approval/policy identity on existing SlopOS seams.
   - Existing selection, trust-root, and approval surfaces stay authoritative instead of inheriting portable selection meaning from one federation deployment's path-building choices.

6) **No silent external-federation widening rides in through OpenID Federation.**
   - Imported entity statements, chains, metadata policies, Trust Marks, endpoint metadata, resolver outputs, historical keys, and trust-anchor hints do **not** authorize portable issuer/app-trust truth, portable policy selection, portable approval meaning, portable connected-account truth, or durable “who is trusted right now?” truth by implication.
   - A provider may use OpenID Federation to bootstrap trust for one external identity, OAuth, or application interaction, but that does **not** standardize a portable federation-trust substrate on D-LLM, D-POLICY, IF-ACP, or adjacent issuer/account/trust seams.
   - If SlopOS ever needs native external-federation import, issuer governance, or imported-federation evidence, that work must arrive as an RFC on explicit schemas, validators, conflict keys, evidence hooks, and kill switches rather than inheriting folklore from OpenID Federation compatibility.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of federation resolvers, trust-chain builders, trust-mark verifiers, or metadata caches must be killable by policy and must not create authority via hidden paths, env vars, implicit network access, silently persistent caches, or ambient trust-anchor configuration.
   - A compat layer that cannot proceed without ambient federation discovery, hidden trust-anchor stores, or implicit resolver caches must fail closed for portable SlopOS authority semantics.

8) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: IF-ACP validation, exact action bytes, explicit capabilities/approvals, and explicit D-POLICY handles/bundles.
   - Any future native external-federation import or issuer-governance workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting them from imported chains, Trust Marks, resolver caches, endpoint metadata, or trust-anchor hints.

## Phase 1 non-goals (explicitly deferred)

- No portable issuer/app registry imported directly from OpenID Federation compatibility.
- No portable rule that Trust Chains, Trust Marks, or resolved metadata stand in for CH-AUTHZ, CH-ACP, CH-POLICY, CH-POLICYHANDLE, or approval-basis truth.
- No portable rule that authority hints, trust anchors, or historical-key responses stand in for SlopOS trust-root selection, signer identity, or endpoint-trust truth.
- No portable rule that resolver outputs, subordinate listings, or Trust Mark status/listing responses stand in for chooser receipts, current-state proofs, or durable connected-account/service truth.

## Why this is worth pinning

This is the next small, high-leverage cut after AuthZEN, Shared Signals, and SCIM. Once external authorization decisions, external auth-state events, and external provisioning APIs are pinned as provider-local only, the next tempting shortcut is “fine, trust the federation.” In practice that means over-reading imported entity statements, trust chains, metadata policies, Trust Marks, resolver outputs, and authority hints as if they were portable issuer truth, trusted-app truth, approval basis, or current policy/trust state.

OpenID Federation is useful and now a Final Specification. It gives real ecosystems a way to bootstrap multilateral trust, apply federation policy, publish trust marks, and resolve metadata through signed chains. That is exactly why the archive should pin its meaning early: external federation bootstrap is a valuable compatibility surface, but it does not get to redefine issuer identity, trust roots, approval basis, or durable connected-entity truth on SlopOS.

Pinning the boundary now keeps the archive honest. Imported federation semantics may remain a provider-local way to bootstrap trust for one external interaction, but they do not become a portable issuer registry, app-trust substrate, policy selector, or durable account/service truth inside SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation agents or enterprise helpers may interoperate with federated OIDC/OAuth ecosystems, but imported Trust Chains and Trust Marks do not become a portable trusted-app registry, account-binding truth, or approval basis.
- **Cloud micro-VM / hosted compute substrate (B):** hosted control planes may use external federation bootstrap for tenant-facing identity/application integration, but imported federation metadata does not become a portable issuer catalog, trust-root plane, or durable connected-service registry.
- **Embedded / separation-kernel-ish appliance (C):** appliances may compile in a narrow federation adapter, but OpenID Federation remains sealed compat only and policy-killable, with no hidden resolver dependency or trust-anchor cache becoming native authority.
- **Agent / automation OS (D):** first-class LLM/automation stacks are exactly where federation trust signals are easiest to over-read as “which issuer/app should I trust?” or “what policy applies?”; this boundary keeps agent memory/tooling from silently normalizing that widening.

## Singleton status (Phase 1)

This doc is an **intentional singleton** in `boundary-family-map.md`.
It attaches to existing D-LLM / D-POLICY / IF-ACP decision surfaces plus adjacent approval-basis / identity-claim / account-binding / trust-root cuts, but no broader reviewed external-federation-import family exists yet; no broader multi-doc boundary family exists yet.
If more reviewed external-federation or external-trust-bootstrap import cuts appear, promote them into one explicit family index in the same revision rather than letting singleton count drift by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Evidence id:** `EVID-2026-699`
- `tools/check_openid_federation_import_boundary.py` fails `make lint` if this boundary, its singleton status, discovery wiring, or its “federation trust bootstrap is not portable issuer / app-trust / policy truth” posture drifts.
- Attached to existing assurance surfaces: **I-LLM-1**, **PO-ACT-VALIDATE**, **PO-POLICY-NONAMP**.

## References

- `REF-OPENID-FEDERATION-1-0`
- `REF-OPENID-FEDERATION-FINAL`
