# D-LLM MCP-caller-auth-binding import boundary v0 (session/auth state is not portable caller identity or tool-authorization truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP authorization/session guidance — persistent session IDs, mandatory inbound-request verification, “sessions are not authentication”, URL-mode same-user verification, and adjacent ecosystem pressure around persistent authorization state / per-tool authorization — is **provider-local caller-binding and live auth-state mechanics only**. It does **not** create a portable current-user export, caller-identity oracle, per-tool authorization registry, tenant-selection substrate, or durable “server authorized for user X” truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP auth/session behavior may be interpreted next to already-pinned auth-result, login-state, account-binding, enterprise-managed-auth, token-passthrough, and tool-annotation boundaries.

## Posture (v0)

1) **Persistent session IDs stay provider-local routing state only.**
   - MCP security guidance says servers that implement authorization **MUST verify all inbound requests**, **MUST NOT use sessions for authentication**, and **SHOULD bind session IDs to user-specific information**.
   - Those mechanics remain provider-local request/session handling only; they do **not** become a portable auth-state export, signed-in proof, account-binding artifact, or caller-identity oracle on existing SlopOS seams.
   - Existing login-state, account-binding, and auth-result boundaries stay authoritative instead of inheriting truth from a provider's session cache.

2) **URL-mode same-user checks stay provider-local user-binding only.**
   - Current MCP elicitation requires a server using URL mode to verify that the user who opens the URL is the same user who initiated the elicitation and to use a mechanism resilient to attacker-controlled URL changes.
   - That same-user check remains provider-local live identity verification only; it does **not** become a portable `current_user`, `current_subject`, `caller_identity`, `selected_account`, or durable account-binding export on existing SlopOS seams.
   - One provider's cookie/session comparison or subject-binding rule is therefore not portable proof of who the current caller is elsewhere in SlopOS.

3) **One-time authorization does not become durable multi-caller trust.**
   - Recent MCP security research highlights a real ecosystem failure mode: many servers keep persistent authorization state after one initial authorization and then continue serving tool calls without re-authentication or robust caller distinction.
   - SlopOS therefore treats imported persistent auth state, “already signed in”, “already connected”, or “this server is authorized for the user” behavior as provider-owned live state only; it does **not** become portable durable caller truth, reusable server-authorization state, or ambient multi-caller trust on existing seams.
   - Existing enterprise-managed-auth, token-passthrough, login-state, and account-binding boundaries stay authoritative instead of inheriting meaning from provider-owned auth caches.

4) **Fine-grained tool authorization stays provider-local policy only.**
   - Whether an MCP server chooses to authenticate/authorize every request, gate selected tools more strictly, or layer finer-grained policy over one session remains provider-local policy and implementation detail in Phase 1.
   - Those choices do **not** create a portable per-tool authorization registry, tool-security label plane, `tool_authorized_for_user`, `requires_sign_in`, or generic multi-user token-at-call-time substrate on IF-ACP, tool catalogs, or adjacent reviewed SlopOS seams.
   - If a future product shape needs reviewed caller-auth binding, per-tool authorization metadata, or explicit multi-user on-behalf-of semantics, it must return RFC-first on a dedicated seam rather than inheriting folklore from imported MCP auth/session behavior.

5) **No hidden session/cookie/header fallback may smuggle caller truth into generic seams.**
   - Agent hosts, shells, wrappers, compat cells, and proxies may interoperate with provider-local MCP auth/session state, but they must not silently turn session IDs, browser cookies, bearer-session caches, `X-User-*` headers, or tenant-selection headers into portable current-caller truth on generic action/result surfaces.
   - This keeps sealed compat honest: interop remains killable by policy and must not create ambient caller-identity channels through paths, env, cookies, resumable-stream state, shared queues, or implicit network headers.
   - It also keeps D-LLM honest: a model may propose using an authenticated MCP server, but it does not gain portable knowledge of who the current caller is or which tools are authorized merely because one provider maintains live auth state.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit approvals, explicit auth/login boundaries, and provider-local request/session handling.
   - Any future native caller-auth binding / multi-user / per-tool authorization workflow must state its own conflict keys, commutativity conditions, serialization point, freshness model, and evidence story explicitly rather than inheriting folklore from MCP session or authorization helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `current_user`, `current_subject`, `caller_identity`, `active_tenant`, `server_authorized_for_user`, `tool_authorized_for_user`, or `session_auth_state` substrate imported directly from MCP auth/session behavior.
- No rule that MCP session IDs, resumable-stream state, or same-user URL checks stand in for portable login-state, account-binding, or approval truth.
- No rule that provider-owned persistent authorization state authorizes generic multi-user trust, cross-caller reuse, or per-tool authorization truth on existing SlopOS seams.
- No new CH-ACP kind or conflict-key family for caller-auth binding, multi-user token passing, or per-tool auth labeling in v0.

## Why this is worth pinning

The archive already keeps auth results, account binding, login state, token relay, and enterprise routing on separate explicit seams. Current MCP guidance leaves one nearby pressure surface easy to over-read: official security guidance says sessions must not be authentication, URL-mode flows must verify the same initiating user, and recent security research shows that many real MCP deployments still treat one authorization event as durable trust for later tool calls without robust caller distinction.

That combination is exactly how “works in practice” turns into accidental platform meaning. Once that drift lands, session caches start masquerading as caller identity, “already connected” starts masquerading as durable account binding, and ad hoc tool gating starts masquerading as a portable authorization plane. Agent wrappers then begin depending on hidden session/cookie/header state that the archive never reviewed.

Pinning the boundary now keeps the archive honest. Imported MCP auth/session behavior may remain a provider-local way to keep one server's live authorization path working, but it does not get to redefine what caller identity, current user, per-tool authorization, or durable server-authorization state mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with authenticated MCP servers and URL-mode auth flows, but session continuity still does not become portable current-user or tool-authorization truth.
- **Cloud micro-VM substrate (B):** multi-tenant and pooled-agent deployments benefit most from this cut; provider-local auth caches do not become tenant-stable caller identity or per-tool authorization substrate.
- **Embedded / separation appliance (C):** appliances can keep MCP auth terminated inside a narrow shim without importing a general session/caller-identity plane they do not want.
- **Agent/automation OS (D):** this matters most here: imported MCP auth/session behavior must not let agent hosts quietly turn “already authenticated to that server” into a second caller-identity / authorization substrate beside explicit account-binding, login-state, and reviewed action semantics.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_caller_auth_binding_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “MCP session/auth state is not portable caller identity or tool-authorization truth” posture drifts (**EVID-2026-681**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-MCP-ELICITATION`
- `REF-MCP-SECURITY-BEST-PRACTICES`
- `REF-MCP-CALLER-IDENTITY-CONFUSION`
