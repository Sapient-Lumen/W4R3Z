# D-LLM / D-POLICY / IF-ACP OpenID4VCI import boundary v0 (credential issuance is not portable credential / wallet / approval truth)

Purpose: pin one compact Phase-1 rule on the existing **D-LLM / D-POLICY / IF-ACP** seams: imported OpenID for Verifiable Credential Issuance semantics — Credential Offers by value or `credential_offer_uri`, `credential_configuration_ids`, `openid_credential` authorization details, Authorization Code and Pre-Authorized Code grant material, `issuer_state`, `pre-authorized_code`, optional `tx_code`, Credential Issuer metadata/endpoints, `c_nonce`, proof/key-attestation material, deferred issuance `transaction_id`, notification flows, encryption metadata, and issued VC / SD-JWT VC / mdoc payloads plus HAIP-constrained format/profile material — are **provider-local credential-issuance coordination only**. They do **not** create a portable credential-wallet import, portable issued-credential store, issuer-policy selector, approval-basis object, pending-issuance handle, or durable subject/account/current-user truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported wallet-mediated credential-issuance material may be interpreted next to already-pinned identity-claim, account-binding, approval-basis, verification-policy-selection, verification-material-discovery, verification-verdict, OpenID4VP, and auth/profile import cuts.

## Posture (v0)

1) **Imported Credential Offers, grant objects, and authorization details stay provider-local credential-issuance coordination only.**
   - OpenID4VCI standardizes Credential Offers by value or reference, offered `credential_configuration_ids`, Authorization Code and Pre-Authorized Code flows, `issuer_state`, `pre-authorized_code`, optional `tx_code`, and the `openid_credential` authorization-details type.
   - Imported Credential Offers, `credential_offer_uri` references, `credential_configuration_ids`, grant objects, `issuer_state`, `pre-authorized_code`, optional `tx_code`, and `openid_credential` authorization-details material remain provider-local credential-issuance coordination only; they do **not** become a portable approval-basis object, pending-issuance handle, account-linking result, credential template store, or durable subject/account/current-user truth on existing SlopOS seams.
   - Existing approval-basis, auth-result, auth-proof, identity-claim, and explicit export seams stay authoritative instead of inheriting portable truth from one issuer's wallet-onboarding protocol.

2) **Imported Credential Issuer metadata and endpoint descriptions stay provider-local issuer capability signaling only.**
   - OpenID4VCI defines Credential Issuer metadata including Credential, Nonce, Deferred Credential, and Notification endpoints plus request/response encryption and batch-issuance capabilities.
   - Imported issuer metadata, `credential_issuer`, endpoint URLs, supported credential configurations/formats, request/response encryption metadata, batch-issuance capabilities, display metadata, and notification/deferred endpoint discovery remain provider-local issuer capability signaling only; they do **not** become a portable issuer registry, verifier-policy selector, wallet registry, trust-root plane, or approved-issuer inventory on existing SlopOS seams.
   - Existing federation, app-trust, verification-policy-selection, and connected-account/binding boundaries stay authoritative instead of inheriting portable policy or registry meaning from issuer metadata.

3) **Imported nonce, proof, deferred, notification, and encryption mechanics stay provider-local issuance mechanics only.**
   - OpenID4VCI defines `c_nonce` freshness, proof/key-attestation inputs, deferred issuance `transaction_id`, Wallet notifications, and optional encryption of Credential Requests and Responses on top of TLS.
   - Imported `c_nonce`, DPoP nonce, proof objects, key attestations, deferred `transaction_id`, polling intervals, `notification_id`, notification acknowledgements, encryption-required flags, JWK/JWE capability metadata, and batch proof bundles remain provider-local issuance mechanics only; they do **not** become a portable freshness oracle, callback-result artifact, background job handle, wallet-control plane, or durable issuance-status truth on existing SlopOS seams.
   - Existing auth-proof, callback/completion, background-request-state, and evidence surfaces stay authoritative instead of inheriting portable workflow or liveness meaning from issuer-local issuance mechanics.

4) **Imported issued-credential payloads and response objects stay provider-local issuance payload/validation only.**
   - OpenID4VCI standardizes issuance of VC / SD-JWT VC / ISO mdoc payloads and allows one or more credentials of the same configuration/dataset to be returned after OAuth-authorized issuance.
   - Imported credential responses, issued credential payloads, selective-disclosure material, mdoc/VC/SD-JWT VC encodings, proof-bound key material, and credential-response packaging remain provider-local issuance payload/validation only; they do **not** become a portable identity card, account-binding proof, KYC verdict, generic credential-wallet import, approval receipt, or durable current-user/current-permission truth on existing SlopOS seams.
   - Existing identity-claim export, account-binding, approval-basis, verification-verdict, and CH-WALLET posture stay authoritative instead of inheriting portable identity or wallet meaning from one issued-credential payload.

5) **No silent credential/wallet widening rides in through OpenID4VCI.**
   - Imported Credential Offers, issuer metadata, nonce/proof/deferred/notification mechanics, encryption metadata, and issued credential payloads do **not** authorize portable credential-wallet import, portable issued-credential storage, portable issuer-policy choice, portable approval meaning, or durable “who is this and what may they do?” truth by implication.
   - An issuer may use OpenID4VCI plus HAIP to offer and issue one provider-local credential, but that does **not** standardize a portable credential-wallet substrate, issuer registry, approval plane, or identity store on D-LLM, D-POLICY, IF-ACP, or adjacent identity/account/verification seams.
   - If SlopOS ever needs native verifiable-credential issuance import, wallet management, or issued-credential evidence, that work must arrive as an RFC on explicit schemas, validators, conflict keys, evidence hooks, and kill switches rather than inheriting folklore from OpenID4VCI, HAIP, or VC issuance compatibility.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of credential offers, issuer metadata, `credential_offer_uri` fetches, `c_nonce` retrieval, deferred-issuance polling, notifications, encryption helpers, or issued-credential caches must be killable by policy and must not create authority via hidden paths, env vars, implicit network access, silently persistent wallet stores, or ambient issuer/trust configuration.
   - A compat layer that cannot proceed without ambient issuer discovery, hidden `credential_offer_uri` retrieval, implicit credential caching, silent deferred polling, or hidden wallet defaults must fail closed for portable SlopOS authority semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: IF-ACP validation, exact action bytes, explicit capabilities/approvals, explicit D-POLICY handles/bundles, and explicit verifier/issuer-owner policy choice.
   - Any future native credential issuance import, wallet receipt, or issuer-policy workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting them from imported Credential Offers, `transaction_id`, notifications, or issued credential payloads.

## Phase 1 non-goals (explicitly deferred)

- No portable credential-wallet import or export imported directly from OpenID4VCI or HAIP compatibility.
- No portable rule that Credential Offers, `openid_credential` authorization details, `pre-authorized_code`, `issuer_state`, deferred `transaction_id`, or notifications stand in for CH-ACP, approval-basis, callback/completion, or background-job truth.
- No portable rule that Credential Issuer metadata, supported credential configurations/formats, encryption metadata, or batch-issuance capabilities stand in for SlopOS policy choice, issuer registry semantics, trust-root choice, or wallet registry truth.
- No portable rule that issued VC / SD-JWT VC / mdoc payloads stand in for identity-claim export, account-binding, approval-basis, verification-verdict, CH-WALLET import, or durable current-user truth.

## Why this is worth pinning

This is the next small, high-leverage cut after AuthZEN, Shared Signals, SCIM, OpenID Federation, OpenID Identity Assurance, and OpenID4VP. Once external authorization decisions, auth-state events, provisioning APIs, federation bootstrap, verified claims, and wallet presentations are pinned as provider-local only, the next tempting shortcut is “fine, trust the issuer offer/issuance result.” In practice that means over-reading `credential_offer_uri`, `pre-authorized_code`, issuer metadata, `c_nonce`, deferred `transaction_id`, notifications, and issued credential payloads as if they were portable approval proofs, wallet imports, current-user truth, or a native credential store.

OpenID4VCI and HAIP are useful and final. They give ecosystems standard ways to advertise issuer capabilities, offer credentials to wallets, authorize issuance with OAuth, and deliver credentials in reusable formats. That is exactly why the archive should pin their meaning early: imported credential-issuance material is a valuable compatibility surface, but it does not get to redefine identity truth, approval basis, issuer policy, or durable wallet/account bindings on SlopOS.

Pinning the boundary now keeps the archive honest. Imported wallet-mediated credential issuance may remain a provider-local way to offer and deliver one credential, but it does not become a portable credential-wallet substrate, issuer registry, approval-basis object, or durable current-user truth inside SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation agents may interoperate with enterprise or consumer credential issuers, but imported Credential Offers, issuer metadata, deferred handles, and issued credentials do not become a portable current-user card, wallet import path, or approval proof.
- **Cloud micro-VM / hosted compute substrate (B):** hosted control planes may consume issuer-local credential issuance for onboarding or tenant flows, but imported issuance material does not become a portable issuer registry, identity store, or durable connected-wallet/account substrate.
- **Embedded / separation-kernel-ish appliance (C):** appliances may compile in a narrow issuer adapter, but OpenID4VCI remains sealed compat only and policy-killable, with no hidden `credential_offer_uri` fetch, deferred polling loop, or credential cache becoming native authority.
- **Agent / automation OS (D):** first-class LLM/automation stacks are exactly where issuer offers and issued credentials are easiest to over-read as “who the user is”, “the wallet now contains this”, or “the issuer approved this”; this boundary keeps agent memory/tooling from silently normalizing that widening.

## Family status (Phase 1)

This doc is a member of the closed verifiable-credential ecosystem companion family indexed by `verifiable-credential-ecosystem-boundary-index.md`.
It stays there with `openid4vp-import-boundary-v0.md`, `openid4vci-import-boundary-v0.md`, `verifiable-credential-status-import-boundary-v0.md`, and `did-document-import-boundary-v0.md` so presentation, issuance, status, and DID-resolution meaning pins remain discoverable together.
If future reviewed wallet / credential / DID-import cuts appear, add them to that family **in the same revision** rather than letting them regrow as adjacent singletons.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/verifiable-credential-ecosystem-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Evidence id:** `EVID-2026-702`
- `tools/check_openid4vci_import_boundary.py` fails `make lint` if this boundary, its family membership, discovery wiring, or its “credential issuance is not portable credential / wallet / approval truth” posture drifts.
- Attached to existing assurance surfaces: **I-LLM-1**, **PO-ACT-VALIDATE**, **PO-POLICY-NONAMP**.

## References

- `REF-OPENID-4VCI-1-0`
- `REF-OPENID-4VCI-FINAL`
- `REF-OPENID4VC-HAIP-1-0`
- `REF-W3C-VC-DM-2-0`
