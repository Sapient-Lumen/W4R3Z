# D-NETLEASE TLS-verifier boundary v0 (no portable trust-root / hostname-verifier / certificate-exception seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: leases that allow `proto = tls` or `proto = quic` do **not** become a portable TLS trust-root, hostname-verifier, certificate-exception, or current certificate-verdict surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable trust-root / hostname-verifier / certificate-exception seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **destination predicate**, the granted **resolver binding**, and the transport class (`tls` / `quic`).
   - They do **not** grow a portable `ca_bundle`, `ca_store`, `trust_profile`, `trust_anchor_set`, `verify_peer`, `verify_hostname`, `expected_hostname_override`, `cert_exception`, `allow_self_signed`, `verify_result`, `peer_cert_digest`, or equivalent export surface.
   - Phase 1 portable truth is therefore: **what reachability predicate was reviewed/granted, through which resolver binding, over which transport class** — not which verifier policy or certificate exception state a provider/runtime happened to use.

2) **Transport reachability is portable; TLS verifier policy stays portal-local or app-local.**
   - A lease may authorize transport reachability to a reviewed predicate using `proto = tls` or `proto = quic`.
   - That does **not** standardize which trust roots, hostname-matching policy, certificate-transparency policy, or certificate pinning inputs a provider/runtime uses when authenticating the remote peer.
   - Different product profiles or owner-local runtimes may therefore accept or reject the same peer certificate while still staying inside the same reviewed D-NETLEASE reachability grant.

3) **No ambient cert-store / certificate-exception fallback.**
   - Reviewed networking in Phase 1 must not silently inherit browser exception databases, host-global trust stores, debug-only local roots, tool-specific CA environment variables, or generic “disable verification” compatibility switches as substrate meaning.
   - That rule applies both to direct `portal.net` implementations and to wrappers/compat paths around them: host trust-policy residue is not by itself reviewed network authority.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient trust-bypass channels through host settings, per-user certificate exceptions, or ad-hoc verifier-disable toggles.

4) **If portable transport-auth policy matters, pay for a new seam explicitly.**
   - A future product shape may want reviewed TLS pinsets, explicit trust-profile artifacts, mTLS identity binding, or verifier-result receipts.
   - That work must return **RFC-first** with its own schema/receipt family, redaction story, commutativity/conflict-key contract, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems expose CA stores, debug overrides, or hostname-verifier APIs.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit transport-auth seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from system trust stores or library defaults.

6) **Current certificate verdict is live session state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove which CA store was in force, whether hostname verification was enabled, whether a certificate exception was applied, which peer certificate chain was accepted, or whether a later connection would verify successfully now.
   - As elsewhere in SlopOS, stable request/receipt artifacts are evidence of one reviewed action, not a portable oracle for mutable owner-local verifier state.

## Phase 1 non-goals (explicitly deferred)

- No portable `trust_profile`, `ca_bundle`, `trust_anchor_set`, `verify_hostname`, `cert_exception`, or `verify_result` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a browser/system trust-store broker.
- No transcript-stable claim that an accepted network request or issued lease also proves a current TLS certificate verdict.
- No hidden browser/system trust-exception compatibility promise around `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS. Once `proto = tls` or `proto = quic` is present, the next quiet drift is to pretend the transport lease also says what CA bundle, hostname rules, or certificate exceptions define “trust.” Real systems treat those as significant verifier-policy choices, not harmless connection residue.

If we leave that blurry, workstations and agents will start depending on whatever browser/session/tool trust settings happen to exist on the host, while cloud and embedded profiles will have to fake portability for verifier semantics they do not actually share. Pinning the boundary now keeps D-NETLEASE honest: reachability is one explicit seam, transport-auth policy is another future seam if we ever truly need it.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich OS/browser trust policy, but that does not standardize trust stores, certificate exceptions, or verifier results as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound reachability explicit without pretending the host’s CA bundle or debug trust exceptions are transcript-stable guest/runtime truth.
- **Embedded / separation appliance (C):** appliance builds can keep a narrow reachability seam without paying for a portable general-purpose trust-store or certificate-exception plane they do not want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “lease to this TLS destination” with “portable certificate verifier policy” or “proof that the peer would verify now.”

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-resolution-boundary-v0.md`
  - `docs/30-architecture/network-lease-proxy-boundary-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-NETLEASE-DNSBIND**, **PO-CAPSHELL-NET-EXPLICIT**)

CI drift gate:
- `tools/check_network_lease_tls_verifier_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable trust-root / hostname-verifier / certificate-exception seam / no ambient cert-store fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-632**).

## References

- REF-CURL-SSLCERTS.
- REF-OPENSSL-TLS-CLIENT.
- REF-OPENSSL-SSL-SET1-HOST.
- REF-ANDROID-NETSEC-CONFIG.
