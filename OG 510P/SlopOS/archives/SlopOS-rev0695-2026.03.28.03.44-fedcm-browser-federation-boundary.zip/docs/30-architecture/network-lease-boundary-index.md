# D-NETLEASE boundary index (v0)

Purpose: keep the **closed set of D-NETLEASE companion boundary docs** enumerable.

Why this exists:
- the archive now pins multiple small `network-lease-*-boundary-v0.md` docs so explicit leased networking does not quietly regrow into resolver-answer telemetry, local-egress folklore, path-property folklore, proxy-policy discovery, transport-trust folklore, generic DNS-query folklore, host/local name-resolution folklore, Unicode/IDNA/host-normalization folklore, service-name/default-port folklore, dual-stack address-selection folklore, or TLS/QUIC transport-profile folklore,
- those docs are individually crisp but easy to forget piecemeal because they sit next to the core CH-NETREQ / CH-NETLEASE posture and all look like “small caveats” unless one discovery surface enumerates them together,
- `network-lease-posture-v0.md` keeps the overall meaning of D-NETLEASE, while this index is the **discovery surface** that says which companion boundaries currently keep leased networking small, non-ambient, and transcript-honest.

This doc does **not** add a new schema, workflow family, or receipt kind.
It is an entropy-reducing companion to `network-lease-posture-v0.md`, `network-request-schema-v0.md`, `network-lease-schema-v0.md`, and RFC-0056.

## Posture (v0)

- D-NETLEASE keeps a **small closed companion boundary family** for adjacent semantics that would otherwise regrow answer/path telemetry, local-egress folklore, path-property folklore, proxy-policy discovery, transport-trust folklore, higher-layer protocol folklore, TLS server-name folklore, transport-resumption folklore, generic DNS-query folklore, host search-path / local-name-resolution folklore, Unicode/IDNA/host-normalization folklore, service-name/default-port folklore, or IPv4 / IPv6 preference / Happy Eyeballs folklore behind `portal.net` / CH-NETREQ / CH-NETLEASE.
- This index is a **discovery and maintenance surface**, not a new protocol: it enumerates the current companion boundaries and forces same-revision maintenance when that family changes.
- Phase 1 meaning remains in `network-lease-posture-v0.md`; this index only keeps the current companion-boundary set recoverable by humans, CI, and LLM handoff surfaces.

## Phase 1 non-goals (explicitly deferred)

- This doc does **not** define a new DNS-answer receipt, route-observation API, local-egress/interface-selection API, proxy-broker policy API, trust-profile schema, certificate-verdict receipt, or transport-auth workflow.
- This doc does **not** create a new ACP kind, conflict-key family, portal family, or evidence format.
- If future work needs a broader networking/admin surface, it must return RFC-first rather than being smuggled in as an index edit.

## Inclusion rule

A doc belongs here if it removes exactly one tempting adjacent meaning from Phase 1 by constraining how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted, especially where real ecosystems would otherwise tempt us to import:
- current resolver answers / selected endpoints / route or path identity,
- local interface / source address / VRF / local-egress attachment policy,
- metered / validated / captive / expensive / constrained path-property or connectivity-state hints,
- proxy-selection / PAC / WPAD / system-proxy policy,
- transport trust-root / hostname-verifier / certificate-exception semantics,
- client-certificate / mTLS identity / certificate-bound-token semantics,
- ALPN / application-protocol / HTTP-version negotiation semantics,
- SNI / server-name / public-name / ECH name-presentation semantics,
- session-resumption / PSK / ticket-cache / 0-RTT semantics,
- TLS / QUIC version / cipher / group / transport-parameter profile semantics,
- DNS RR type / class / raw-reply / resolver-transport semantics on `kind=dns`,
- host search-path / `/etc/hosts` / split-DNS / mDNS / LLMNR semantics around exact name predicates,
- Unicode U-label / IDNA / UTS #46 / casefold / trailing-dot normalization semantics around exact name predicates,
- numeric-port explicitness vs default-port / service-name inference semantics,
- IPv4 / IPv6 family preference / address ordering / Happy-Eyeballs racing semantics.

Adjacent posture docs such as `network-lease-posture-v0.md` and `network-request-state-posture-v0.md` remain important, but they pin the core D-NETLEASE contract rather than the narrow `network-lease-*-boundary-v0.md` companion cluster tracked here.

If future work needs a real DNS-answer receipt, generic DNS RR-query / raw-reply surface, local-egress/interface-selection surface, connectivity-state/path-quality surface, proxy-broker policy surface, transport-auth schema, application-protocol negotiation surface, TLS server-name-presentation surface, transport-resumption surface, transport-profile / handshake-policy surface, service-name/default-port surface, IPv4 / IPv6 preference / address-ordering surface, or Unicode/IDNA/host-normalization surface instead, that work must return **RFC-first** as its own schema/decision surface rather than hiding behind CH-NETREQ / CH-NETLEASE evidence.

## Closed companion boundary set (Phase 1)

### 1) Explicit resolver binding does not become answer/path telemetry

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-resolution-boundary-v0.md`](network-lease-resolution-boundary-v0.md) | resolved addresses / selected endpoints / route labels | leased networking exports reviewed destination predicates plus resolver binding only; exact answer/path state stays portal-local rather than portable receipt truth | future RFC-first DNS-answer / route-observation surface if truly needed |

### 2) Explicit reachability does not become local-egress policy

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-local-egress-boundary-v0.md`](network-lease-local-egress-boundary-v0.md) | local interfaces / source addresses / VRFs / inherited network binding | leased networking does not export a portable local-interface / source-address / VRF seam; local egress selection stays portal-local or app-local rather than transcript-stable receipt truth | future RFC-first local-egress / interface-selection surface if truly needed |

### 3) Explicit reachability does not become path-property or connectivity-state truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-path-property-boundary-v0.md`](network-lease-path-property-boundary-v0.md) | metered / validated / captive / expensive / constrained hints / connectivity-state folklore | leased networking does not export a portable metered / validated / captive / expensive / constrained path-property or connectivity-state seam; current path hints stay portal-local rather than transcript-stable receipt truth | future RFC-first connectivity-state / path-quality / network-monitor surface if truly needed |

### 4) Explicit leased networking does not become proxy-policy authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-proxy-boundary-v0.md`](network-lease-proxy-boundary-v0.md) | proxy selection / PAC / WPAD / system proxy | leased networking does not export a portable proxy-selection / PAC / WPAD / system-proxy seam; env/settings-driven proxy policy stays portal-local rather than transcript-stable receipt truth | future RFC-first proxy-broker / enterprise-egress surface if truly needed |

### 5) Explicit reachability does not become transport-auth policy

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-tls-verifier-boundary-v0.md`](network-lease-tls-verifier-boundary-v0.md) | CA stores / trust roots / hostname verification / certificate exceptions / current verify verdicts | leased networking may authorize `tls` / `quic` reachability but does not export a portable trust-root / hostname-verifier / certificate-exception seam or current certificate-verdict receipt | future RFC-first transport-auth / pinset / verifier-result surface if truly needed |

### 6) Explicit reachability does not become client-auth identity

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-client-cert-boundary-v0.md`](network-lease-client-cert-boundary-v0.md) | client certificates / keychain alias selection / PKCS#11 objects / certificate-bound tokens | leased networking may authorize `tls` / `quic` reachability but does not export a portable client-certificate / mTLS identity seam or certificate-bound-token receipt | future RFC-first transport-auth identity / secret-bound client-cert surface if truly needed |

### 7) Explicit transport class does not become application-protocol negotiation truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-application-protocol-boundary-v0.md`](network-lease-application-protocol-boundary-v0.md) | ALPN / application-protocol / HTTP-version negotiation | leased networking may authorize `tls` / `quic` reachability but does not export a portable ALPN / application-protocol negotiation seam or transcript-stable selected-protocol receipt | future RFC-first application-protocol / HTTP-substrate negotiation surface if truly needed |

### 8) Explicit transport class does not become TLS server-name presentation truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-server-name-boundary-v0.md`](network-lease-server-name-boundary-v0.md) | SNI / server-name / public-name / ECH name presentation | leased networking may authorize `tls` / `quic` reachability but does not export a portable SNI / server-name / ECH seam or transcript-stable on-wire name-presentation receipt; TLS server-name presentation seam stays portal-local unless a future explicit surface pays for it | future RFC-first TLS name-presentation / privacy-profile surface if truly needed |

### 9) Explicit transport class does not become transport-resumption truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-session-resumption-boundary-v0.md`](network-lease-session-resumption-boundary-v0.md) | session tickets / PSK reuse / QUIC session continuity / 0-RTT | leased networking may authorize `tls` / `quic` reachability but does not export a portable session-resumption / PSK / 0-RTT seam or transcript-stable resumed-session / early-data receipt; transport-resumption seam stays portal-local unless a future explicit surface pays for it | future RFC-first transport-resumption / early-data profile surface if truly needed |

### 10) Explicit transport class does not become transport-profile truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-transport-profile-boundary-v0.md`](network-lease-transport-profile-boundary-v0.md) | TLS versions / cipher suites / groups / signature algorithms / QUIC versions / transport parameters | leased networking may authorize `tls` / `quic` reachability but does not export a portable version / cipher / group / transport-parameter transport-profile seam or transcript-stable negotiated transport-profile receipt; TLS/QUIC handshake-profile semantics stay portal-local unless a future explicit surface pays for it | future RFC-first transport-profile / handshake-policy surface if truly needed |

### 11) Explicit name resolution does not become generic DNS query/export truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-dns-query-boundary-v0.md`](network-lease-dns-query-boundary-v0.md) | DNS RR types / classes / raw replies / resolver transport selection | leased `kind=dns` authority stays address-resolution-only and does not export a portable RR-query / raw-reply / resolver-transport seam; generic DNS query semantics stay portal-local unless a future explicit surface pays for it | future RFC-first DNS RR-query / raw-reply / resolver-evidence surface if truly needed |

### 12) Explicit exact-name authority does not become search-path / local-name-resolution truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-name-context-boundary-v0.md`](network-lease-name-context-boundary-v0.md) | search paths / hosts-file policy / split-DNS views / mDNS / LLMNR | leased name-shaped authority stays exact-predicate-only and does not export a portable search-path / local-name-resolution truth; host resolver context stays portal-local unless a future explicit surface pays for it | future RFC-first search-path / local-name-resolution / enterprise-name-context surface if truly needed |

### 13) Explicit exact-name authority does not become Unicode / IDNA / normalization truth

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`network-lease-name-normalization-boundary-v0.md`](network-lease-name-normalization-boundary-v0.md) | Unicode U-label input / IDNA mapping / UTS #46 / casefold / trailing-dot cleanup | leased name-shaped authority stays one canonical ASCII predicate and does not export a portable Unicode / IDNA / normalization truth; browser/libc/tool canonicalization stays portal-local unless a future explicit surface pays for it | future RFC-first Unicode-facing reviewed name / IDNA / host-normalization surface if truly needed |

### 14) Explicit exact-name authority does not become service-binding / alternate-endpoint truth

| Boundary doc | Hidden import we refuse in Phase 1 | Resulting honest rule | If we ever want it later |
| --- | --- | --- | --- |
| [`network-lease-service-binding-boundary-v0.md`](network-lease-service-binding-boundary-v0.md) | SRV targets / SVCB aliasing / HTTPS RR alternate endpoints / endpoint-parameter bundles | leased exact-name authority stays host-address oriented and does not export a portable service-binding / alternate-endpoint truth; SRV / SVCB / HTTPS-derived endpoint selection stays portal-local unless a future explicit surface pays for it | future RFC-first service-discovery / alternate-endpoint / endpoint-parameter surface if truly needed |

### 15) Explicit exact-name authority does not become IPv4 / IPv6 preference / Happy Eyeballs truth

| Boundary doc | Hidden import we refuse in Phase 1 | Resulting honest rule | If we ever want it later |
| --- | --- | --- | --- |
| [`network-lease-address-selection-boundary-v0.md`](network-lease-address-selection-boundary-v0.md) | IPv4 / IPv6 preference tables / dual-stack answer ordering / Happy-Eyeballs racing / selected-family folklore | leased exact-name authority stays destination predicate + resolver binding only and does not export a portable IPv4 / IPv6 preference / Happy-Eyeballs / answer-ordering truth; dual-stack sorting/racing stays portal-local unless a future explicit surface pays for it | future RFC-first address-selection / dual-stack-policy / Happy-Eyeballs surface if truly needed |

### 16) Explicit numeric endpoint authority does not become default-port / service-name truth

| Boundary doc | Hidden import we refuse in Phase 1 | Resulting honest rule | If we ever want it later |
| --- | --- | --- | --- |
| [`network-lease-port-inference-boundary-v0.md`](network-lease-port-inference-boundary-v0.md) | URI-scheme default ports / `/etc/services` service-name lookup / well-known-port folklore | leased connect/listen authority for `dns_name` / `dns_suffix` / `ip_prefix` stays explicitly port-shaped and does not export a portable default-port / service-name truth; absent numeric ports reject before effect and `service` labels stay portal-local policy unless a future explicit surface pays for it | future RFC-first URI/scheme or service-name / port-inference surface if truly needed |

## Review rule

Before adding another `network-lease-*-boundary-v0.md` doc, answer these questions in order:
1) Is the change really a **D-NETLEASE meaning pin** rather than a new schema or workflow?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported networking semantics?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.

## Wiring

- Discovery surfaces: `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, and `docs/30-architecture/boundary-family-map.md`.
- Decision surfaces: `docs/30-architecture/decision-map.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, and `rfcs/0056-outbound-network-leases-and-portals.md`.
- Drift enforcement: `tools/check_network_lease_boundary_index.py`, `tools/check_network_lease_resolution_boundary.py`, `tools/check_network_lease_local_egress_boundary.py`, `tools/check_network_lease_path_property_boundary.py`, `tools/check_network_lease_proxy_boundary.py`, `tools/check_network_lease_tls_verifier_boundary.py`, `tools/check_network_lease_client_cert_boundary.py`, `tools/check_network_lease_application_protocol_boundary.py`, `tools/check_network_lease_server_name_boundary.py`, `tools/check_network_lease_session_resumption_boundary.py`, `tools/check_network_lease_transport_profile_boundary.py`, `tools/check_network_lease_dns_query_boundary.py`, `tools/check_network_lease_name_context_boundary.py`, and `tools/check_network_lease_name_normalization_boundary.py`, `tools/check_network_lease_service_binding_boundary.py`, and `tools/check_network_lease_address_selection_boundary.py`.
- Evidence hook: `docs/00-meta/evidence-index.md` entry `EVID-2026-633 / EVID-2026-647 / EVID-2026-648`.

## References

- `REF-FREEBSD-CAP-DNS` / `REF-XDG-PORTAL-REQUEST` / `REF-ANDROID-READ-NETWORK-STATE` — explicit resolver binding is useful, but answer/path state is still a separate seam.
- `REF-ANDROID-MULTINETWORK` / `REF-APPLE-NWPARAMETERS-REQUIREDINTERFACE` / `REF-LINUX-SO_BINDTODEVICE` / `REF-RFC6724-ADDRSELECT` / `REF-RFC8043-SADR` — local egress binding is a real topology/routing surface, not harmless request residue.
- `REF-ANDROID-NETWORKCAPABILITIES` / `REF-APPLE-NWPATH` / `REF-XDG-PORTAL-NETWORKMONITOR` / `REF-RFC8908-CAPPORT-API` — path-property and connectivity-state hints are real dynamic APIs/protocols, not harmless request residue.
- `REF-LIBPROXY` / `REF-CHROMIUM-PROXY` / `REF-CHROMIUM-WPAD` / `REF-LIBCURL-ENV` — proxy policy is a real discovery/evaluation subsystem, not harmless request residue.
- `REF-CURL-SSLCERTS` / `REF-OPENSSL-TLS-CLIENT` / `REF-OPENSSL-SSL-SET1-HOST` / `REF-ANDROID-NETSEC-CONFIG` — transport trust policy is an explicit verifier/configuration surface, not merely “networking happened over TLS”.
- `REF-CURL-CLIENTCERT` / `REF-ANDROID-KEYCHAIN-CHOOSEPRIVATEKEYALIAS` / `REF-RFC8705-OAUTH-MTLS` — client-auth identity and certificate-bound token handling are explicit configuration/mediation surfaces, not merely “networking happened over TLS”.
- `REF-RFC7301-ALPN` / `REF-RFC9113-HTTP2` / `REF-RFC9114-HTTP3` / `REF-RFC9205-HTTP-BCP` — higher-layer protocol negotiation and HTTP-substrate requirements are explicit protocol surfaces, not merely “networking happened over TLS/QUIC”.
- `REF-RFC6066-TLS-SNI` / `REF-RFC9849-ECH` / `REF-RFC9848-ECH-SVCB` / `REF-CURL-CONNECT-TO` — TLS server-name presentation and ECH bootstrapping are explicit transport/policy surfaces, not merely “networking happened over TLS/QUIC”.
- `REF-RFC2782-SRV` / `REF-RFC9460-SVCB` / `REF-RFC9848-ECH-SVCB` — service discovery and service binding are explicit DNS surfaces for alternate endpoints and endpoint parameters, not merely “a reviewed exact name was resolved”.
- `REF-RFC6724-ADDRSELECT` / `REF-RFC8305-HAPPY-EYEBALLS` / `REF-MAN7-GETADDRINFO` — IPv4/IPv6 family preference, address ordering, and Happy-Eyeballs racing are explicit resolver/client policy surfaces, not merely “a reviewed exact name was resolved”.
- `REF-RFC8446-TLS13` / `REF-RFC9001-QUIC-TLS` / `REF-RFC9325-TLS-BCP` / `REF-RFC9308-QUIC-APPLICABILITY` — session tickets, PSK reuse, and 0-RTT are explicit transport-state and replay/privacy surfaces, not merely “networking happened over TLS/QUIC”.
- `REF-RFC8446-TLS13` / `REF-RFC9000-QUIC-TRANSPORT` / `REF-CURL-SSL-CIPHERS` / `REF-APPLE-ATS-COCOAKEYS` — TLS/QUIC transport profiles (versions, ciphers, groups, QUIC versions, transport parameters) are explicit configuration/negotiation surfaces, not merely “networking happened over TLS/QUIC”.
- `REF-MAN7-GETADDRINFO` / `REF-MAN7-RESOLVER` / `REF-ANDROID-DNSRESOLVER` / `REF-RFC1035-DNS` — address resolution and generic DNS RR-query APIs are distinct surfaces; RR type/class and raw replies are not merely “name resolution happened”.
- `REF-MAN7-RESOLV-CONF` / `REF-MAN7-SYSTEMD-RESOLVED` / `REF-RFC6762-MDNS` / `REF-RFC4795-LLMNR` — host search lists, split-DNS routing, and local-link name-resolution protocols are explicit resolver-context surfaces, not merely “a reviewed name predicate existed”.
- `REF-RFC1035-DNS` / `REF-RFC5890-IDNA-DEFS` / `REF-RFC5895-IDNA-MAPPING` / `REF-WHATWG-URL-HOST` — canonical DNS label syntax, A-label/U-label distinctions, input mapping, and browser host parsing are explicit processing layers, not merely “a reviewed name predicate existed”.
- `REF-MAN7-GETADDRINFO` / `REF-MAN7-SERVICES` / `REF-RFC9205-HTTP-BCP` / `REF-IANA-SERVICE-NAMES` — default ports and service-name → port translation are explicit URI/libc/registry semantics, not merely “a reviewed host predicate existed”.
