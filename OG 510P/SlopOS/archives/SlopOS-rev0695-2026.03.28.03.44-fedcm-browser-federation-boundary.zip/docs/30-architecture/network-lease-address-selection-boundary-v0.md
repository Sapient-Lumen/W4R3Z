# D-NETLEASE address-selection boundary v0 (no portable IPv4 / IPv6 preference / Happy Eyeballs seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed exact-name networking authority remains **destination predicate + resolver binding only**, and it does **not** become a portable IPv4/IPv6 family-preference, destination-address ordering, or Happy-Eyeballs connection-racing surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable IPv4 / IPv6 preference / Happy Eyeballs seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed destination predicate plus the granted resolver binding.
   - They do **not** grow a portable `address_family_preference`, `ipv6_first`, `ipv4_fallback`, `happy_eyeballs`, `racing_delay_ms`, `dns_answer_order`, `candidate_order`, `selected_family`, `selected_ip`, `addrconfig_mode`, or equivalent dual-stack selection / answer-ordering / connection-racing surface.
   - Phase 1 portable truth is therefore: **which exact destination predicate was reviewed/granted, through which resolver binding** — not which address family was preferred first, how returned answers were sorted, or which race winner happened to connect on one machine.

2) **Reviewed exact-name authority does not become dual-stack policy authority.**
   - A reviewed `dns_name` / `dns_suffix` predicate authorizes host-address reachability decisions only.
   - It does **not** by itself authorize one transcript-stable IPv6-over-IPv4 preference, one Happy-Eyeballs fallback delay, one answer-ordering contract, or one promise about how many candidate addresses were raced or in what order.
   - If a product truly wants transcript-visible family preference or address-racing policy, it must pay for a future explicit seam rather than inheriting it from resolver/runtime/browser folklore.

3) **Address ordering and racing stay portal-local.**
   - Resolver-side or portal-side use of RFC 6724 sorting, Happy Eyeballs racing, cached address-family preference, `AI_ADDRCONFIG`-style heuristics, or runtime-specific fallback delays may exist as implementation detail.
   - But any ordered candidate list, family preference, race timer, or winning selected address stays **portal-local** unless a future surface explicitly exports it.
   - Historical CH-NETREQ / CH-NETLEASE bytes therefore do **not** prove that IPv6 was tried first, that IPv4 was preferred, or that one exact Happy-Eyeballs algorithm was in force.

4) **Address resolution stays reachability-oriented, not connection-racing-oriented.**
   - The Phase 1 `kind=dns` seam remains address-resolution-only: name-shaped and portless.
   - Predicate review plus resolver binding do not silently widen into a portable address-family preference policy or connection-racing algorithm just because dual-stack client stacks commonly sort and race addresses.
   - This keeps D-NETLEASE honest across A/B/C/D: reviewed network authority means exact destination predicate + resolver binding, not “whatever dual-stack answer ordering and fallback logic the current stack happened to run.”

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit dual-stack family-preference / answer-ordering / Happy-Eyeballs surface must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting hidden resolver/client behavior.

6) **If reviewed address-selection semantics matter, pay for a new seam explicitly.**
   - Future product shapes may want transcript-visible IPv6 preference, IPv4 fallback delay, answer-ordering receipts, or reviewed Happy-Eyeballs policy.
   - That work must return **RFC-first** with its own schema/receipt family, performance/privacy posture, discovery/testing story, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because dual-stack client stacks do it today.

## Phase 1 non-goals (explicitly deferred)

- No portable `ipv6_first`, `ipv4_only`, `ipv4_first`, `happy_eyeballs`, `racing_delay_ms`, `candidate_order`, `selected_family`, or `selected_ip` field on CH-NETREQ or CH-NETLEASE.
- No transcript-stable claim that an accepted name-shaped request or issued lease also approves one exact destination-address ordering, one exact Happy-Eyeballs algorithm, or one exact winner among IPv4/IPv6 candidates.
- No generic portal/settings API that turns D-NETLEASE into a dual-stack policy broker, address-sorter, or connection-racing plane.
- No ambient promise that `portal.net.request` will silently import address-ordering semantics from libc, browsers, mobile SDKs, or enterprise network stacks.

## Why this is worth pinning

The archive already pinned exact reviewed names, resolver binding, and exact-name service-discovery boundaries. The next quiet drift is to treat the same reviewed exact name as if it also carried **whatever dual-stack answer ordering or fallback behavior the local stack prefers** — IPv6-first precedence tables, IPv4 fallback heuristics, Happy-Eyeballs racing, or cached address-family policy.

Primary specs treat those as distinct surfaces. RFC 6724 defines destination/source address-selection algorithms plus administrator policy hooks, and RFC 8305 defines multi-stage connection setup for dual-stack hosts including address ordering and racing. Pinning the boundary now keeps D-NETLEASE honest: **reviewed exact-name reachability is one seam; reviewed address-family preference / connection-racing semantics would be another future seam if we ever truly need it.**

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use browser/libc/mobile-style dual-stack heuristics locally, but reviewed leased-network meaning stays on destination predicates rather than silently inheriting one host’s IPv4/IPv6 preference folklore.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound naming explicit without promising one portable Happy-Eyeballs or address-sorting policy across guest images, sidecars, or resolver libraries.
- **Embedded / separation appliance (C):** appliance builds can keep reviewed networking small and auditable by rejecting dual-stack racing complexity unless a product explicitly pays for it.
- **Agent/automation OS (D):** agents/tools cannot confuse “this name was reviewed” with “IPv6 first was approved” or “this selected address is transcript truth”; retries, receipts, and policy review stay byte-stable for LLM workflows.

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-lease-resolution-boundary-v0.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETREQ-VALIDATE**, **PO-NETLEASE-VALIDATE**, **PO-ACP-NET-REQUEST**)

CI drift gate:
- `tools/check_network_lease_address_selection_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable IPv4 / IPv6 preference / Happy-Eyeballs seam / exact-name-is-not-address-selection-authority / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-648**).

## References

- REF-RFC6724-ADDRSELECT.
- REF-RFC8305-HAPPY-EYEBALLS.
- REF-MAN7-GETADDRINFO.
