# D-NETLEASE name-context boundary v0 (no portable search-path / local-name-resolution seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed name-shaped networking authority records an exact **name predicate** plus **resolver binding**, but it does **not** become a portable host search-path, local-name-resolution, or resolver-context surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable search-path / local-name-resolution seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **exact name predicate** plus the granted **resolver binding**.
   - They do **not** grow a portable `search_domains`, `search_path`, `ndots`, `res_search`, `hosts_file_mode`, `nss_hosts_order`, `split_dns_view`, `mdns`, `llmnr`, `bonjour`, `wins`, or equivalent resolver-context surface.
   - Phase 1 portable truth is therefore: **which exact name predicate was reviewed/granted, through which resolver binding** — not which host search list, local naming protocol, or enterprise resolver view happened to reinterpret that name on one machine.

2) **`dns_name` remains exact; `dns_suffix` remains an explicit suffix predicate.**
   - A reviewed `dns_name` does **not** implicitly widen through host search domains, single-label completion, or process-local resolver heuristics.
   - A reviewed `dns_suffix` is an explicit policy suffix predicate, not a request to import `/etc/resolv.conf` search lists or workstation-local completion behavior.
   - This keeps reviewed name authority crisp across A/B/C/D even when real ecosystems layer suffix search, short-name expansion, or enterprise namespace routing on top of ordinary DNS APIs.

3) **Search-list / hosts / split-DNS / mDNS / LLMNR mechanics stay portal-local.**
   - Reviewed name authority does **not** standardize `/etc/resolv.conf` `search` / `ndots`, `/etc/hosts` / NSS host-order behavior, per-link split-DNS routing, `.local` Multicast DNS behavior, LLMNR fallback, or any hidden host resolver stack.
   - Real runtimes may still expose those behaviors locally or not at all, but D-NETLEASE v0 does not turn them into transcript-stable reviewed substrate meaning.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient channels through hidden short-name expansion, host-file fallbacks, local-link multicast resolution, or enterprise resolver-view inheritance.

4) **If host/local name-context semantics matter, pay for a new seam explicitly.**
   - A future product shape may want reviewed split-DNS policy, local-link discovery naming, exact host search-path semantics, or transcript-visible local-name-resolution evidence.
   - That work must return **RFC-first** with its own schema/receipt family, conflict keys, privacy posture, discovery/testing story, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems expose search lists, NSS order, `.local` discovery, or link-local name-resolution protocols.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit split-DNS / search-path / local-name-resolution seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from libc resolvers, NSS, or local-link discovery stacks.

6) **Current host resolver context remains portal-local live state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove which search list, hosts-file mapping, split-DNS view, mDNS responder set, or LLMNR result a later resolution attempt observed.
   - `network-lease-resolution-boundary-v0.md` already keeps exact answer/path state out of portable lease meaning; this boundary keeps the *name-interpretation context itself* from drifting into a portable host resolver contract.

## Phase 1 non-goals (explicitly deferred)

- No portable `search_domains`, `search_path`, `ndots`, `res_search`, `hosts_file_mode`, `nss_hosts_order`, `split_dns_view`, `mdns`, `llmnr`, `bonjour`, or `wins` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a host search-path broker, `/etc/hosts`/NSS compatibility promise, split-DNS policy plane, or mDNS/LLMNR/local-link naming broker.
- No transcript-stable claim that an accepted name-shaped request or issued lease also proves the search list, hosts-file mapping, or local-link name responders that were consulted.
- No hidden libc/browser/system compatibility promise that `dns_name` silently inherits ambient short-name expansion, hosts-file lookup, split-DNS routing, mDNS `.local` behavior, or LLMNR fallback around `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS, and the recent passes kept exact answer/path state and generic DNS query/export semantics out of CH-NETREQ / CH-NETLEASE portable meaning. The next quiet drift is to treat the same reviewed name predicate as if it also carried **whatever host resolver context would reinterpret it here** — search lists, short-name expansion, `/etc/hosts`, split DNS, `.local` mDNS, or LLMNR.

Real systems do expose those behaviors, but they treat them as resolver-stack policy and local network context rather than a harmless consequence of “a reviewed name was granted.” If we leave that blurry, workstation and agent flows will start depending on ambient enterprise or local-link naming behavior that cloud and embedded profiles neither share nor want to standardize. Pinning the boundary now keeps D-NETLEASE honest: **reviewed exact name authority is one seam; reviewed host/local name-context semantics would be another future seam if we ever truly need it.**

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still ship rich local resolver stacks, but reviewed leased-network meaning stays at exact name predicates rather than inheriting short-name expansion, hosts-file/NSS policy, or local-link discovery folklore.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound naming explicit without promising one portable split-DNS, search-path, or local-link naming plane across guests, runtimes, or enterprise environments.
- **Embedded / separation appliance (C):** appliance builds can support narrow reviewed name authority without paying for a general-purpose host-name-context compatibility layer they do not want to maintain.
- **Agent/automation OS (D):** agents/tools cannot confuse “may resolve this exact predicate” with “portable approval to rely on ambient search domains, hosts-file lookups, or local-link name-discovery behavior.”

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-lease-resolution-boundary-v0.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETREQ-VALIDATE**, **PO-NETLEASE-VALIDATE**, **PO-ACP-NET-REQUEST**)

CI drift gate:
- `tools/check_network_lease_name_context_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **exact-name-only / no search-path-or-local-name-resolution seam / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-644**).

## References

- REF-MAN7-RESOLV-CONF.
- REF-MAN7-SYSTEMD-RESOLVED.
- REF-RFC6762-MDNS.
- REF-RFC4795-LLMNR.
