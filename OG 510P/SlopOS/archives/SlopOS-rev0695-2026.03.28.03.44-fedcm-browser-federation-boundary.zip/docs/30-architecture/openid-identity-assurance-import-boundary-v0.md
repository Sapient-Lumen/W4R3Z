# D-LLM / D-POLICY / IF-ACP OpenID Identity Assurance import boundary v0 (verified claims are not portable KYC / identity / policy truth)

Purpose: pin one compact Phase-1 rule on the existing **D-LLM / D-POLICY / IF-ACP** seams: imported OpenID Connect for Identity Assurance semantics — `verified_claims`, `verification`, `claims`, trust-framework identifiers, verification process metadata, evidence objects, assurance-level / verification-method details, additional IDA claims registered for natural persons, OP metadata, aggregated/distributed verified claims, and verified-claims delivery through ID Tokens / UserInfo / OAuth access tokens / token introspection responses — are **provider-local identity-assurance transport only**. They do **not** create a portable identity-claim export, KYC/eligibility verdict, approval-basis object, verification-policy selector, trust-framework registry, account-binding proof, or durable subject/account/current-user truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported verified-claim / assurance / evidence material may be interpreted next to already-pinned identity-claim, account-binding, approval-basis, verification-policy-selection, verification-material-discovery, verification-verdict, and auth/profile import cuts.

## Posture (v0)

1) **Imported `verified_claims` containers stay provider-local identity-assurance transport only.**
   - OpenID Connect for Identity Assurance standardizes how relying parties request and receive `verified_claims` with assurance metadata for end-user claims.
   - Imported `verified_claims` containers, nested `claims`, nested `verification` objects, and verified-claim delivery outcomes remain provider-local identity-assurance transport only; they do **not** become a portable subject/profile export, KYC verdict, account-binding proof, current-user oracle, approval-basis object, or durable account truth on existing SlopOS seams.
   - Existing identity-claim, account-binding, login-state, and approval-basis boundaries stay authoritative instead of inheriting portable truth from one provider's verified-claims payload.

2) **Imported assurance metadata, trust-framework identifiers, and evidence stay provider-local explanation only.**
   - OpenID Identity Assurance carries trust-framework identifiers, verification details, evidence/process metadata, and assurance-level information so an RP can assess what an OP or claim provider is asserting.
   - Imported trust-framework identifiers, verification-method details, evidence/process metadata, assurance levels, and timestamps remain provider-local explanation only; they do **not** become a portable trust-framework registry, verifier-policy selector, compliance basis, approval proof, or global assurance oracle on existing SlopOS seams.
   - Existing verification-policy-selection, verification-material-discovery, verification-verdict, and approval-basis boundaries stay authoritative instead of inheriting local policy or portable verdict meaning from one provider's assurance metadata.

3) **Imported Identity Assurance claims-registration fields stay provider-local claim vocabulary only.**
   - OpenID Connect for Identity Assurance Claims Registration 1.0 registers additional JWT claims relating to the identity of a natural person, and the IDA schema standardizes `verified_claims` as a reusable container across protocols.
   - Imported additional IDA claims, schema-defined nested claim structures, and registered natural-person claim names remain provider-local claim vocabulary only; they do **not** become a portable canonical subject schema, attribute registry, entitlement vocabulary, or durable account/profile truth on existing SlopOS seams.
   - Existing identity-claim export, account-binding, and schema/validator surfaces stay authoritative instead of inheriting global identity-schema meaning from one imported claim vocabulary.

4) **Imported delivery modes, aggregated/distributed claims, and OP metadata stay provider-local protocol mechanics only.**
   - OpenID Identity Assurance allows verified claims to be carried in ID Tokens, UserInfo responses, OAuth access tokens, token introspection responses, and aggregated/distributed claims assertions; it also defines OP metadata and request syntax for verified-claim requests.
   - Imported delivery channels, aggregated/distributed claims assertions, request syntax, OP metadata, and related provider capabilities remain provider-local protocol mechanics only; they do **not** become a portable document/evidence store, callback/result substrate, verification-material discovery plane, or durable connected-provider/current-state truth on existing SlopOS seams.
   - Existing auth-result, auth-proof, verification-material-discovery, and explicit export seams stay authoritative instead of inheriting portable inventory or retrieval meaning from one provider's verified-claim transport path.

5) **No silent identity-assurance widening rides in through OpenID Identity Assurance.**
   - Imported `verified_claims`, assurance metadata, evidence/process descriptions, additional IDA claim names, aggregated/distributed claims assertions, request syntax, and OP metadata do **not** authorize portable KYC truth, portable subject/account/profile truth, portable verification policy, portable approval meaning, portable entitlement meaning, or durable “who is this and what assurance do we have?” truth by implication.
   - A provider may use OpenID Identity Assurance to communicate high-assurance identity data for one relying-party interaction, but that does **not** standardize a portable identity-assurance substrate on D-LLM, D-POLICY, IF-ACP, or adjacent identity/account/verification seams.
   - If SlopOS ever needs native identity-assurance import, verified-claims storage, or imported-assurance evidence, that work must arrive as an RFC on explicit schemas, validators, conflict keys, evidence hooks, and kill switches rather than inheriting folklore from OpenID Identity Assurance compatibility.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of identity-assurance payloads, claim-provider connectors, assurance-evidence fetches, or verified-claims caches must be killable by policy and must not create authority via hidden paths, env vars, implicit network access, silently persistent caches, or ambient trust-framework configuration.
   - A compat layer that cannot proceed without ambient assurance-policy defaults, hidden evidence fetches, or implicit verified-claims caches must fail closed for portable SlopOS authority semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: IF-ACP validation, exact action bytes, explicit capabilities/approvals, explicit D-POLICY handles/bundles, and explicit verifier-owner policy choice.
   - Any future native identity-assurance import, assurance evidence store, or verifier-policy workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting them from imported `verified_claims`, assurance metadata, evidence/process descriptions, or OP metadata.

## Phase 1 non-goals (explicitly deferred)

- No portable KYC / identity-verification verdict imported directly from OpenID Identity Assurance compatibility.
- No portable rule that `verified_claims`, assurance metadata, or evidence/process descriptions stand in for CH-ACP, verifier-local verification-verdict results, or approval-basis truth.
- No portable rule that trust-framework identifiers, assurance levels, or registered claim names stand in for SlopOS policy choice, trust-root choice, or canonical identity/account schema.
- No portable rule that aggregated/distributed claims assertions, OP metadata, or verified-claim delivery endpoints stand in for document/evidence stores, callback-result seams, or durable connected-provider/account truth.

## Why this is worth pinning

This is the next small, high-leverage cut after AuthZEN, Shared Signals, SCIM, and OpenID Federation. Once external authorization decisions, external auth-state events, external provisioning APIs, and external federation trust bootstrap are pinned as provider-local only, the next tempting shortcut is “fine, treat the verified claims as the truth.” In practice that means over-reading imported `verified_claims`, assurance metadata, evidence/process details, trust-framework identifiers, and natural-person claim registrations as if they were portable KYC verdicts, global identity/account truth, policy selectors, or approval basis.

OpenID Identity Assurance is useful and final. It gives ecosystems a standard way to request and deliver verified claims with structured assurance metadata and reusable schema definitions. That is exactly why the archive should pin its meaning early: imported verified-claim material is a valuable compatibility surface, but it does not get to redefine identity truth, approval basis, verifier policy, or durable account bindings on SlopOS.

Pinning the boundary now keeps the archive honest. Imported OpenID Identity Assurance semantics may remain a provider-local way to communicate high-assurance identity data for one interaction, but they do not become a portable KYC substrate, identity registry, verifier-policy plane, or durable account/profile truth inside SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation agents may interoperate with enterprise identity providers and high-assurance sign-in flows, but imported `verified_claims` and evidence metadata do not become a portable current-user card, KYC verdict, or approval basis.
- **Cloud micro-VM / hosted compute substrate (B):** hosted control planes may consume high-assurance identity data for tenant onboarding or enterprise workflows, but imported IDA payloads do not become a portable identity registry, verifier-policy selector, or durable connected-account substrate.
- **Embedded / separation-kernel-ish appliance (C):** appliances may compile in a narrow identity-assurance adapter, but OpenID Identity Assurance remains sealed compat only and policy-killable, with no hidden evidence fetch or trust-framework default becoming native authority.
- **Agent / automation OS (D):** first-class LLM/automation stacks are exactly where imported verified claims are easiest to over-read as “who the user is”, “KYC passed”, or “policy allows this”; this boundary keeps agent memory/tooling from silently normalizing that widening.

## Singleton status (Phase 1)

This doc is an **intentional singleton** in `boundary-family-map.md`.
It attaches to existing D-LLM / D-POLICY / IF-ACP decision surfaces plus adjacent identity/account/verification cuts, but no broader reviewed external-identity-assurance-import family exists yet; no broader multi-doc boundary family exists yet.
If more reviewed external identity-assurance or verified-claims import cuts appear, promote them into one explicit family index in the same revision rather than letting singleton count drift by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Evidence id:** `EVID-2026-700`
- `tools/check_openid_identity_assurance_import_boundary.py` fails `make lint` if this boundary, its singleton status, discovery wiring, or its “verified claims are not portable KYC / identity / policy truth” posture drifts.
- Attached to existing assurance surfaces: **I-LLM-1**, **PO-ACT-VALIDATE**, **PO-POLICY-NONAMP**.

## References

- `REF-OPENID-IDA-1-0`
- `REF-OPENID-IDA-CLAIMS-1-0`
- `REF-OPENID-IDA-SCHEMA-1-0`
- `REF-OPENID-IDA-FINAL`
