# D-LLM MCP-token-exchange import boundary v0 (token exchange is not portable delegation / impersonation / token-broker / account truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current OAuth token exchange semantics that may appear next to MCP authorization flows — `grant_type=urn:ietf:params:oauth:grant-type:token-exchange`, `subject_token`, optional `actor_token`, `resource`, `audience`, `scope`, `requested_token_type`, and exchanged-token response fields such as `issued_token_type` / `token_type` / `expires_in` — are **provider-local authorization-server token-shaping and delegation/impersonation machinery only**. They do **not** create a portable token broker, delegation plane, impersonation substrate, workload-identity bridge, connected-account truth, approval-basis seam, or durable login/account truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported token-exchange semantics may be interpreted next to already-pinned enterprise-managed-auth, ID-JAG, client-credentials, client-assertion, authorization-context, login-state, account-binding, auth-result, auth-proof, token-passthrough, introspection, and revocation boundaries.

## Posture (v0)

1) **Imported token exchange stays provider-local STS machinery only.**
   - RFC 8693 defines token exchange as an HTTP/JSON security-token-service style grant on the authorization server: one security token is presented so the server can mint another token that is narrower, differently targeted, or otherwise better suited to one downstream protected resource.
   - That imported flow remains provider-local authorization-server machinery only; it does **not** create a portable token-broker API, cross-provider bearer relay, generic delegation fabric, or durable connected-service/session substrate on existing SlopOS seams.
   - Existing auth-result, token-passthrough, and authorization-context boundaries stay authoritative instead of inheriting platform meaning from one provider's STS helper.

2) **`subject_token` handling stays provider-local presented-token bootstrap only.**
   - RFC 8693 lets a client submit a `subject_token` plus `subject_token_type`, and the current MCP enterprise-managed-authorization profile uses token exchange in that narrow way to obtain an ID-JAG before continuing one provider-owned enterprise flow.
   - Those `subject_token` mechanics remain provider-local presented-token bootstrap only; they do **not** create a portable subject-token store, reusable login bridge, current-user export, or generic cross-domain account-binding seam on existing SlopOS seams.
   - Existing ID-JAG, identity-claim, account-binding, and login-state boundaries stay authoritative instead of inheriting account truth from one token-exchange request.

3) **`actor_token` plus delegation/impersonation semantics stay provider-local AS policy only.**
   - RFC 8693 explicitly distinguishes delegation from impersonation and allows optional `actor_token` input when an authorization server wants to model one actor acting for another subject.
   - Those semantics remain provider-local authorization-server policy only; they do **not** create a portable “act as user”, tenant-switching, service-account assumption, or agent-delegation substrate on existing SlopOS seams.
   - Existing auth-proof, account-binding, and future RFC-first delegation workflows stay authoritative instead of inheriting platform meaning from one provider's delegation/impersonation claims.

4) **`resource`, `audience`, `scope`, and `requested_token_type` stay provider-local token-shaping only.**
   - RFC 8693 lets exchange requests name `resource`, `audience`, `scope`, and `requested_token_type` so the authorization server can target or shape the returned token, while OAuth security guidance recommends audience restriction and sender-constraining where possible.
   - Those request knobs remain provider-local token-shaping only; they do **not** create a portable entitlement catalog, service-identity registry, workload-selector plane, approval object, or generic “mint the right token for me” API on existing SlopOS seams.
   - Existing authorization-context, token-passthrough, client-credentials, DPoP, and policy seams stay authoritative instead of inheriting durable grant or service truth from one exchange request.

5) **Issued exchanged tokens stay provider-local auth artifacts only.**
   - RFC 8693 returns one exchanged token plus metadata such as `issued_token_type`, `token_type`, and `expires_in`; the current MCP enterprise-managed-authorization profile shows the same shape when using token exchange to obtain an ID-JAG.
   - Those outputs remain provider-local auth artifacts only; they do **not** create a portable token wallet, durable integration-secret substrate, connected-account receipt, or transcript-stable approval artifact on existing SlopOS seams.
   - Existing auth-result, vault, token-passthrough, and evidence seams stay authoritative instead of inheriting platform meaning from one exchanged-token response.

6) **No silent delegation / impersonation / workload-identity widening rides in through token exchange.**
   - Imported token-exchange handling does **not** authorize connected-account export, durable signed-in truth, service-account inventory, workload-identity brokerage, or generic actor-for-subject delegation by implication.
   - A provider may use token exchange to continue one authorization path, but that does **not** standardize portable delegation, impersonation, token brokerage, account binding, or current-login semantics on adjacent SlopOS seams.
   - If SlopOS ever needs native delegation, impersonation, workload identity, or token-broker workflows, that work must arrive on those explicit seams and validators directly.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth libraries, exchanged tokens, refresh-driven exchange helpers, or provider-specific STS adapters must be killable by policy and must not create authority via hidden paths, env vars, ambient signer state, or implicit network access.
   - A compat layer that cannot proceed without ambient exchanged-token caches, hidden actor/subject binding state, or implicit STS egress must fail closed for portable D-LLM auth semantics.

8) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local authorization-server token exchange plus explicit reviewed auth-result / auth-proof / account-binding / login-state seams.
   - Any future native delegation / impersonation / token-broker / workload-identity workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported token-exchange helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `grant_type=urn:ietf:params:oauth:grant-type:token-exchange`, `subject_token`, `actor_token`, `requested_token_type`, `resource`, `audience`, or equivalent generic token-broker substrate imported directly from MCP/OAuth helpers.
- No rule that exchanged tokens or `issued_token_type` responses stand in for portable delegation receipts, impersonation proof, workload-identity handles, connected-account truth, or durable signed-in truth.
- No rule that RFC 8693 delegation/impersonation language stands in for portable agent-delegation, tenant-switching, or service-account assumption semantics on existing SlopOS seams.
- No rule that token-exchange request shaping (`resource`, `audience`, `scope`, `requested_token_type`) stands in for portable entitlement catalogs, approval objects, service selectors, or grant inventory truth.

## Why this is worth pinning

The archive already keeps enterprise routing, enterprise identity assertions, client credentials, endpoint client auth, token passthrough, verifier inputs, account binding, identity claims, and login state on separate explicit seams. Current OAuth guidance adds a nearby pressure surface those docs do not yet pin directly: **generic token exchange itself, especially its delegation/impersonation language, actor-vs-subject split, and token-shaping knobs**.

That looks like protocol plumbing, but it is exactly where hidden substrate grows. Once wrappers and agents see a generic STS grant, `subject_token` / `actor_token`, and “delegation” or “impersonation” language, provider-local exchange flows drift into “the platform can mint downstream tokens for anything”, “the agent can act as the user”, or “this exchanged token is the connected-account receipt”.

Pinning the boundary now keeps the archive honest. Imported token exchange may remain a provider-local way to mint one better-targeted token on one authorization path, but it does not get to redefine delegation, impersonation, token brokerage, workload identity, account binding, or durable login/account truth on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with providers that use token exchange internally, but those flows still do not become a generic “mint downstream tokens for this user/service” substrate or durable connected-account truth.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted agents and workers will meet token-exchange and broker-like stories often, but imported STS helpers do not become tenant-stable workload identity, delegation, or account-binding substrate by default.
- **Embedded / separation appliance (C):** appliances can omit token exchange entirely or terminate it in a narrow shim without importing a generalized delegation / impersonation / workload-identity subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported token-exchange helpers may help one provider-owned automation path proceed, but they do not become a second delegation, token-wallet, service-identity, or account-state substrate beside explicit auth-proof, auth-result, account-binding, and future governance seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_token_exchange_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “token exchange is not portable delegation / impersonation / token-broker / account truth” posture drifts (**EVID-2026-707**).

## References

- `REF-MCP-ENTERPRISE-MANAGED-AUTH`
- `REF-RFC8693-TOKEN-EXCHANGE`
- `REF-RFC8707-RESOURCE-INDICATORS`
- `REF-RFC9700-OAUTH-SECURITY`
