# D-LLM / D-POLICY / IF-ACP AuthZEN import boundary v0 (external authorization APIs are not portable approval / policy / entitlement truth)

Purpose: pin one compact Phase-1 rule on the existing **D-LLM / D-POLICY / IF-ACP** seams: imported AuthZEN / OpenID Authorization API semantics — Access Evaluation requests/responses, Access Evaluations batch requests/responses, Subject / Resource / Action Search APIs, Policy Decision Point metadata and discovery (`/.well-known/authzen-configuration`, endpoint URLs, capabilities, signed metadata), request identifiers such as `X-Request-ID`, response `decision`, optional response `context`, and search pagination tokens — are **provider-local PDP↔PEP coordination only**. They do **not** create a portable approval object, CH-POLICY / CH-POLICYHANDLE substitute, entitlement registry, current-permission oracle, chooser-result surface, or durable policy-state truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported external authorization APIs may be interpreted next to already-pinned D-POLICY, IF-ACP validation, tool-result visibility, tool-annotation semantics, approval-basis, and rendered-tool-UI meaning cuts.

## Posture (v0)

1) **Imported access evaluations stay provider-local authorization queries only.**
   - The AuthZEN Authorization API lets a Policy Enforcement Point ask a Policy Decision Point for one access decision over explicit `subject`, `resource`, `action`, and optional `context` inputs.
   - Imported access-evaluation requests and returned `decision` booleans remain provider-local authorization-query mechanics only; they do **not** become a portable approval object, CH-AUTHZ / CH-ACP substitute, CH-POLICYHANDLE substitute, or generic “can I do this?” oracle on existing SlopOS seams.
   - Existing IF-ACP validation, explicit capabilities, and veto-only D-POLICY bundles stay authoritative instead of inheriting portable admission truth from one external PDP call.

2) **Imported batch evaluations stay provider-local aggregation only.**
   - AuthZEN also standardizes batch evaluation requests/responses so one PEP can ask for multiple related authorization decisions in one round trip.
   - Imported batch evaluation payloads and returned per-entry `decision` values remain provider-local aggregation only; they do **not** become a portable bulk-approval surface, entitlement materialization shortcut, action planner oracle, or transcript-stable grant ledger on existing SlopOS seams.
   - Existing action batching, approval review, and explicit receipt/evidence surfaces stay authoritative instead of inheriting portable bulk-effect meaning from one PDP's multi-evaluation response.

3) **Imported search APIs stay provider-local discovery only.**
   - AuthZEN search APIs let a caller ask which subjects, resources, or actions would be permitted within one authorization context, and the spec explicitly warns that pagination is not an atomic snapshot.
   - Imported Subject / Resource / Action Search requests, `results`, and pagination tokens remain provider-local discovery only; they do **not** become a portable entitlement registry, chooser-result surface, current-permission inventory, account/resource browser, or durable policy-state truth on existing SlopOS seams.
   - Existing chooser, designation, inventory, and explicit export seams stay authoritative instead of inheriting portable inventory truth from one PDP's search response.

4) **Imported PDP metadata and discovery stay provider-local compatibility hints only.**
   - AuthZEN defines well-known PDP discovery plus metadata such as `policy_decision_point`, evaluation/search endpoint URLs, optional capabilities, and signed metadata.
   - Imported discovery documents, endpoint URLs, capability URNs, and signed metadata remain provider-local compatibility hints only; they do **not** become a portable policy registry, trust-root plane, endpoint-pinset truth, entitlement capability catalog, or current-policy selector on existing SlopOS seams.
   - Existing D-POLICY selection, verification-policy-selection, and network/auth metadata boundaries stay authoritative instead of inheriting portable policy/trust meaning from one external PDP's discovery surface.

5) **Imported request identifiers and decision context stay correlation/explanation only.**
   - AuthZEN allows request identifiers such as `X-Request-ID` and may return provider-defined response `context` alongside a decision.
   - Imported request IDs, response `context`, deny reasons, and provider-local explanation fields remain correlation/explanation only; they do **not** become portable approval-basis receipts, current-policy proofs, durable audit truth, or commutativity metadata on existing SlopOS seams.
   - Existing CH-ACPOUT / CH-DENY / CH-LOG receipts stay authoritative instead of inheriting transcript meaning from one external authorization API's correlation or explanation fields.

6) **No silent external-policy widening rides in through AuthZEN.**
   - Imported access-evaluation endpoints, batch evaluation payloads, search results, discovery metadata, capability rows, request IDs, and provider-defined decision context do **not** authorize portable approval, policy selection, entitlement inventory, chooser semantics, or durable “who can do what right now?” truth by implication.
   - A provider may use AuthZEN to coordinate one PDP↔PEP policy check, but that does **not** standardize a portable external-policy substrate on D-LLM, D-POLICY, IF-ACP, or adjacent chooser/export seams.
   - If SlopOS ever needs native external PDP bridging, entitlement search, or imported-authorization evidence, that work must arrive as an RFC on explicit schemas, validators, conflict keys, evidence hooks, and kill switches rather than inheriting folklore from AuthZEN compatibility.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of PDP clients, policy-query SDKs, cached decision helpers, or search adapters must be killable by policy and must not create authority via hidden paths, env vars, implicit network access, or silently persistent caches.
   - A compat layer that cannot proceed without ambient external policy queries, hidden entitlement caches, or implicit PDP discovery must fail closed for portable SlopOS authority semantics.

8) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: IF-ACP validation, exact action bytes, explicit capabilities/approvals, and explicit D-POLICY handles/bundles.
   - Any future native external-policy evaluation or entitlement-search workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting them from imported AuthZEN decisions, search results, request IDs, or metadata.

## Phase 1 non-goals (explicitly deferred)

- No portable policy-evaluate / policy-search / external-PDP bridge imported directly from AuthZEN compatibility.
- No portable rule that AuthZEN `decision` booleans or search `results` stand in for CH-AUTHZ, CH-ACP, CH-POLICY, or CH-POLICYHANDLE truth.
- No portable rule that PDP metadata, capabilities, signed metadata, or discovery documents stand in for current policy selection, trust roots, or endpoint-trust truth.
- No portable rule that AuthZEN request identifiers or provider-defined `context` fields stand in for SlopOS receipts, approval basis, or commutativity/ordering metadata.

## Why this is worth pinning

AuthZEN is exactly the kind of juicy ecosystem feature that can help real implementations without fitting our native authority story verbatim. It gives external PDPs and PEPs a crisp interoperable wire format for access checks, batch checks, search, and discovery. That is useful and likely to spread.

It is also a classic widening hazard. Once agents, wrappers, or policy helpers can call a standard external authorization API, one provider-local PDP result quickly turns into “the platform's approval oracle”, search results turn into “our entitlement registry”, and PDP discovery turns into “our policy/trust catalog”. That would collapse existing SlopOS seams: approvals, policy handles, chooser/inventory, and current live state would all quietly inherit semantics from one external API.

Pinning the boundary now keeps the archive honest. Imported AuthZEN semantics may remain a provider-local way to query one external PDP, but they do not get to redefine approval, policy, entitlement, chooser, or current-permission truth on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation agents or enterprise helpers may consult external PDPs for one workflow, but those results do not become a portable approval/permission UI, account/resource chooser, or durable policy state substrate.
- **Cloud micro-VM / hosted compute substrate (B):** hosted control planes may integrate with external policy engines, but imported decisions/search results do not become a portable tenant entitlement inventory, mutable policy cache, or current-permission oracle.
- **Embedded / separation-kernel-ish appliance (C):** appliances may compile in a narrow external-policy adapter, but AuthZEN remains sealed compat only and policy-killable, with no hidden network dependency or entitlement cache becoming native authority.
- **Agent / automation OS (D):** first-class LLM/automation stacks are exactly where external authorization APIs can be over-read as “the answer” to approval or permission questions; this boundary keeps agent memory/tooling from silently normalizing that widening.

## Singleton status (Phase 1)

This doc is an **intentional singleton** in `boundary-family-map.md`.
It attaches to existing D-LLM / D-POLICY / IF-ACP decision surfaces, but no broader multi-doc boundary family exists yet for external-policy-import seams.
If more reviewed external-policy import cuts appear, promote them into one explicit family index in the same revision rather than letting singleton count drift by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Evidence id:** `EVID-2026-696`
- `tools/check_authzen_import_boundary.py` fails `make lint` if this boundary, its singleton status, discovery wiring, or its “external authorization APIs are not portable approval / policy / entitlement truth” posture drifts.
- Attached to existing assurance surfaces: **I-LLM-1**, **PO-ACT-VALIDATE**, **PO-POLICY-NONAMP**.

## References

- `REF-AUTHZEN-AUTHORIZATION-API`
- `REF-AUTHZEN-FINAL`
- `REF-CEDAR`
