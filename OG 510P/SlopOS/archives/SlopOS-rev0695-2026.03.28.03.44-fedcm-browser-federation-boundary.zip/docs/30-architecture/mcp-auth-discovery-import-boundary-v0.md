# D-LLM MCP-auth-discovery import boundary v0 (auth discovery metadata is not issuer/tenant/policy/callback truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP authorization discovery — OAuth 2.0 Protected Resource Metadata, `WWW-Authenticate` `resource_metadata` / `scope` challenges, `authorization_servers`, and OAuth 2.0 Authorization Server Metadata / OpenID Connect Discovery endpoint lookup — is **provider-local authorization discovery only**. It does **not** create a portable issuer registry, authorization-server catalog, scope/tenant/policy oracle, callback authority, or trust/cache substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP authorization discovery semantics may be interpreted next to already-pinned client-registration, enterprise-auth, auth-continuation, auth-result, authorization-context, browser-session, and OpenURI boundaries.

## Posture (v0)

1) **Protected Resource Metadata stays provider-local discovery only.**
   - MCP servers may expose OAuth 2.0 Protected Resource Metadata and may point clients to it via `WWW-Authenticate` `resource_metadata` or well-known URIs.
   - Those documents and pointers remain provider-local authorization discovery only; they do **not** create a portable SlopOS issuer registry, authorization-server catalog, or trusted metadata-discovery substrate.
   - This keeps D-LLM honest: imported discovery hints do not silently widen into a second connected-app / account / policy inventory plane.

2) **`authorization_servers` is candidate routing, not portable issuer or tenant truth.**
   - Protected Resource Metadata may advertise one or more authorization servers, and MCP explicitly leaves selection among multiple authorization servers to the client.
   - That list may guide one provider-owned authorization path, but it does **not** become portable issuer identity, tenant binding, default authorization-server selection, or durable connected-account truth on existing SlopOS seams.
   - One provider’s advertised authorization-server list is therefore not portable proof that some issuer, tenant, or account relationship exists elsewhere.

3) **Challenge metadata and challenged scopes stay request-local guidance only.**
   - `WWW-Authenticate` challenges may carry `resource_metadata` and `scope` so a client can discover the right metadata and request the least privilege needed for one request.
   - Those fields do **not** become portable approval basis, durable granted-scope truth, entitlement inventory, or reusable account/session policy state.
   - Existing authorization-context, approval-basis, and auth-result boundaries remain authoritative instead of inheriting folklore from challenge headers.

4) **Authorization Server Metadata / OIDC discovery stays fetched interaction metadata only.**
   - OAuth 2.0 Authorization Server Metadata and OpenID Connect Discovery may reveal issuer identifiers, endpoints, supported capabilities, PKCE support, and related interaction prerequisites.
   - Those fetched metadata documents do **not** create a portable callback authority, redirect-policy substrate, tenant-policy oracle, `jwks_uri` trust root, or generic sign-in/admin plane on existing SlopOS seams.
   - Existing callback, auth-proof, authorization-context, login-state, and trust-root boundaries stay authoritative instead of inheriting ambient meaning from fetched `.well-known` metadata.

5) **Fetched URLs, cache rows, and network validation stay local operator responsibility only.**
   - MCP’s current security guidance calls out SSRF risk across the full discovery chain: `resource_metadata` URLs from `WWW-Authenticate`, `authorization_servers` URLs from Protected Resource Metadata, and endpoint URLs from Authorization Server Metadata.
   - SlopOS therefore treats fetched discovery URLs, cached metadata rows, endpoint rotation, and URL-validation policy as provider-local / client-local live state only, not as portable trust facts or durable approval artifacts.
   - Any future native metadata-fetch or issuer-policy substrate would need an RFC-first seam with its own provenance, caching, network policy, and evidence story instead of inheriting trust from fetched auth metadata folklore.

6) **No silent continuation/token/account widening rides in through discovery.**
   - Imported auth-discovery semantics do **not** authorize callback-result export, pending-auth continuation handles, browser-session continuity, granted-scope export, linked-account truth, or token/proof relay by implication.
   - If an eventual reviewed SlopOS seam needs auth continuation, auth result, authorization context, login state, or browser/session semantics, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: imported discovery metadata remains killable by policy and does not smuggle ambient callback, session, or token channels into existing surfaces.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit approvals, explicit auth/login boundaries, and explicit evidence artifacts.
   - Any future native issuer-discovery / metadata-fetch / auth-routing workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP authorization discovery helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `authorization_server_catalog`, `issuer_registry`, `oauth_metadata_cache`, `resource_metadata_watch`, or `scope_challenge_cache` substrate imported directly from MCP auth discovery.
- No rule that Protected Resource Metadata, `authorization_servers`, or Authorization Server Metadata acceptance stands in for portable issuer trust, tenant/account binding, durable policy truth, or callback authority.
- No rule that `WWW-Authenticate` `scope` / `resource_metadata` challenges become portable approval basis, granted-scope truth, or current auth state.
- No rule that fetched metadata URLs, endpoint locations, or discovery caches authorize token passthrough, callback-result export, account-linking truth, or browser-session continuity on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps auth continuations, callback results, browser sessions, granted scopes, linked accounts, and login state on separate explicit seams. Current MCP authorization now makes another nearby pressure surface mandatory: protected MCP servers must expose Protected Resource Metadata, clients must use it for authorization-server discovery, and clients must walk a specific chain of `WWW-Authenticate`, `authorization_servers`, Authorization Server Metadata, and OIDC discovery to learn where and how to authorize.

That is useful, but it is also exactly where hosts and wrappers start to over-read fetched metadata as durable platform truth. Once that drift lands, `authorization_servers` starts masquerading as tenant/account binding, scope challenges start masquerading as durable entitlements, fetched endpoints start masquerading as callback authority, and one provider’s metadata cache starts looking like a reusable issuer/policy registry.

Pinning the boundary now keeps the archive honest. Imported MCP auth discovery may remain a provider-local way to locate and configure one authorization path, but it does not get to redefine what issuer trust, callback authority, approval basis, granted scopes, or durable account/policy truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may interoperate with modern MCP authorization discovery, but fetched metadata and challenge headers still stay local routing hints rather than portable issuer/account/policy truth.
- **Cloud micro-VM substrate (B):** hosted agents may fetch many remote metadata documents, but provider-owned discovery state does not become tenant-stable callback, trust-policy, or connected-account substrate.
- **Embedded / separation appliance (C):** appliances can omit dynamic discovery entirely or terminate it in a narrow provider shim without importing a generic issuer-registry / callback / policy story they do not want.
- **Agent/automation OS (D):** this matters most here: imported auth discovery may smooth one provider-owned authorization path, but it does not become a second issuer-policy / callback / account substrate beside explicit auth continuation, auth result, authorization context, and login-state seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_auth_discovery_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “auth discovery metadata is not issuer/tenant/policy/callback truth” posture drifts (**EVID-2026-673**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-MCP-SEP-985`
- `REF-MCP-AUTH-SECURITY`
- `REF-RFC9728-PROTECTED-RESOURCE-METADATA`
- `REF-RFC8414-AS-METADATA`
- `REF-OPENID-DISCOVERY`
