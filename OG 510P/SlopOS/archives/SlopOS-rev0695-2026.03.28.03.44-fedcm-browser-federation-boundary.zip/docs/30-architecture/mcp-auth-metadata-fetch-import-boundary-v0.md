# D-LLM MCP-auth-metadata-fetch import boundary v0 (fetched auth metadata is not portable trust/cache/provenance truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP/OAuth authorization metadata fetching and caching — `resource_metadata` URL following, `authorization_servers` URL following, Authorization Server Metadata / OIDC discovery fetches, normal HTTP caching, and related network validation — is **provider-local fetch/caching policy only**. It does **not** create a portable metadata-cache substrate, issuer-trust oracle, endpoint pinset, SSRF policy plane, or durable approval/evidence artifact on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP/OAuth auth-metadata fetch semantics may be interpreted next to already-pinned auth-discovery, client-registration, token-passthrough, auth-result, auth-proof, authorization-context, browser-session, and OpenURI boundaries.

## Posture (v0)

1) **Discovery fetch chains stay provider-local network behavior only.**
   - Current MCP auth walks a discovery chain that may involve `WWW-Authenticate` `resource_metadata`, Protected Resource Metadata `authorization_servers`, and Authorization Server Metadata / OIDC endpoint documents.
   - Following those URLs remains provider-local/client-local network behavior only; it does **not** create a portable SlopOS metadata-fetch service, issuer-validation workflow, or trusted online discovery substrate.
   - Existing auth-discovery and login/auth-result boundaries stay authoritative instead of inheriting ambient meaning from fetched URL chains.

2) **Fetched metadata cache rows stay performance artifacts only.**
   - RFC 9728 says normal HTTP caching applies to Protected Resource Metadata retrieval, and fetched OAuth metadata may therefore be cached according to ordinary HTTP cache directives.
   - Those cache rows remain provider-local/client-local performance artifacts only; they do **not** become portable trust evidence, approval basis, durable issuer/account state, or reusable policy truth on existing SlopOS seams.
   - A cached metadata row is therefore never portable proof that some issuer, endpoint, tenant, or authorization relationship remains correct elsewhere.

3) **“Use the correct metadata for this resource” stays local policy, not imported truth.**
   - RFC 9728 explicitly assumes the client has a means to determine the appropriate authorization servers for a protected resource and that it is using the correct metadata for that resource; when both sides enumerate each other, the lists may be cross-checked by the application profile.
   - That cross-checking and “correct metadata” judgment remain provider-local/client-local policy only; they do **not** become a portable issuer-binding proof, resource-binding receipt, or generic auth-topology registry on existing SlopOS seams.
   - Existing account-binding, authorization-context, and proof/evidence seams stay authoritative instead of inheriting durable truth from metadata reconciliation folklore.

4) **URL validation, HTTPS policy, DNS pinning, and egress controls stay local operator policy only.**
   - MCP security guidance calls out SSRF risk across the full OAuth metadata-discovery chain and recommends HTTPS requirements, egress restrictions/proxies, and care around DNS TOCTOU during validation.
   - Those protections remain provider-local/client-local live policy only; they do **not** become a portable URL-allowlist, internal-network classification service, DNS-pinset export, or generic trust-policy substrate on existing SlopOS seams.
   - Any future native metadata-fetch / egress-policy workflow would need RFC-first treatment with its own provenance, caching, commutativity, and evidence story rather than inheriting trust from fetched auth metadata helpers.

5) **Fetched endpoint and key-locator fields stay interaction metadata only.**
   - Authorization Server Metadata and OIDC discovery may expose endpoint URLs, issuer values, `jwks_uri`, supported capabilities, and related interaction prerequisites.
   - Those fetched fields remain online interaction metadata only; they do **not** become portable callback authority, trust-root selection, verifier policy, account identity, or durable admin truth on existing SlopOS seams.
   - Existing auth-proof, auth-result, identity-claim, and key/trust-root boundaries stay authoritative instead of inheriting hidden meaning from endpoint or key-locator fields.

6) **No silent continuation/token/account widening rides in through metadata fetches or caches.**
   - Imported auth-metadata fetch/caching semantics do **not** authorize callback-result export, pending-auth continuation handles, token relay, linked-account truth, login-state truth, or browser-session continuity by implication.
   - If an eventual reviewed SlopOS seam needs metadata fetch, issuer-policy, callback, grant, or session semantics, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: fetched metadata remains killable by policy and does not smuggle ambient network, callback, token, or account channels into existing surfaces.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit approvals, explicit network/evidence policy, and explicit auth/login boundaries.
   - Any future native metadata-fetch / issuer-cache / online-discovery workflow must state its own conflict keys, commutativity conditions, serialization point, freshness model, and evidence story explicitly rather than inheriting folklore from MCP/OAuth metadata helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `oauth_metadata_fetch`, `oauth_metadata_cache`, `issuer_policy_cache`, `authorization_server_pinset`, `resource_metadata_watch`, or `auth_metadata_validation_profile` substrate imported directly from MCP/OAuth discovery helpers.
- No rule that fetched Protected Resource Metadata, Authorization Server Metadata, or OIDC discovery documents stand in for portable issuer trust, callback authority, durable tenant/account truth, or approval evidence.
- No rule that cache freshness, HTTP cache-control state, DNS validation results, or egress-proxy decisions become portable trust-policy or verifier-policy facts on existing SlopOS seams.
- No rule that endpoint URLs, `jwks_uri`, or metadata cross-check results authorize token relay, callback-result export, linked-account truth, or browser-session continuity on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps authorization discovery, callback results, browser sessions, auth proofs, granted scopes, and linked-account truth on separate explicit seams. But current MCP authorization plus RFC 9728 leave one nearby pressure surface easy to over-read: clients must walk online metadata chains, RFC 9728 says normal HTTP caching applies, RFC 9728 explicitly assumes the client has some way to determine the right authorization server and correct metadata for a resource, and MCP security guidance puts SSRF / DNS / egress controls squarely on the client/operator side.

That is useful, but it is also exactly where hosts and wrappers start to over-read fetched online metadata as durable platform truth. Once that drift lands, cached rows start masquerading as issuer trust, endpoint URLs start masquerading as callback or trust-root authority, and one provider's local SSRF/egress policy starts looking like a portable auth-policy substrate.

Pinning the boundary now keeps the archive honest. Imported MCP/OAuth auth-metadata fetches may remain a provider-local way to locate and cache one authorization path, but they do not get to redefine what issuer trust, callback authority, proof material, approval basis, or durable account/policy truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may interoperate with modern MCP/OAuth discovery chains, but fetched metadata and cache rows still stay local routing/performance artifacts rather than portable issuer/account/policy truth.
- **Cloud micro-VM substrate (B):** hosted agents may fetch and cache many remote metadata documents, but that live online state does not become tenant-stable trust-policy, callback, or connected-account substrate.
- **Embedded / separation appliance (C):** appliances can omit dynamic auth-metadata fetch entirely or terminate it in a narrow provider shim without importing a generic metadata-cache / issuer-policy / callback story they do not want.
- **Agent/automation OS (D):** this matters most here: imported auth metadata must not let agent hosts quietly turn fetched URLs, cache rows, or DNS/egress policy into a second issuer-policy / callback / account substrate beside explicit auth-discovery, auth-result, auth-proof, and login-state seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_auth_metadata_fetch_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “fetched auth metadata is not portable trust/cache/provenance truth” posture drifts (**EVID-2026-676**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-MCP-AUTH-SECURITY`
- `REF-RFC9728-PROTECTED-RESOURCE-METADATA`
- `REF-RFC8414-AS-METADATA`
- `REF-OPENID-DISCOVERY`
