# D-LLM MCP-userinfo import boundary v0 (OIDC UserInfo is not portable identity / account / login truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported OpenID Connect UserInfo semantics — `userinfo_endpoint`, Bearer-token profile fetches, returned subject/profile/email claims such as `sub`, `name`, `given_name`, `family_name`, `preferred_username`, `email`, `email_verified`, `picture`, `profile`, `locale`, and `updated_at`, the required `sub` match against the ID Token when both are used, and adjacent signed/encrypted UserInfo metadata such as `userinfo_signed_response_alg`, `userinfo_encrypted_response_alg`, and `userinfo_encrypted_response_enc` — are **provider-local identity/profile retrieval and validation only**. They do **not** create a portable subject/account/profile export, current-user oracle, approval-basis receipt, contact-card substrate, or durable account/session/auth-state truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported UserInfo semantics may be interpreted next to already-pinned auth-discovery, auth-exact-match, auth-result export, identity-claim export, account-binding export, and login-state export boundaries.

## Posture (v0)

1) **Imported `userinfo_endpoint` stays provider-local identity/profile retrieval only.**
   - OpenID Connect defines a UserInfo Endpoint where a client can present an Access Token to retrieve Claims about the End-User.
   - Imported `userinfo_endpoint` locations and profile-fetch mechanics remain provider-local identity/profile retrieval only; they do **not** create a portable current-user lookup API, generic profile-card service, account-directory seam, or durable connected-account substrate on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, and auth-result boundaries stay authoritative instead of inheriting platform meaning from one provider's profile endpoint.

2) **Imported UserInfo claims stay provider-local profile payload only.**
   - OpenID Connect UserInfo responses may carry subject/profile/email claims such as `sub`, `name`, `given_name`, `family_name`, `preferred_username`, `email`, `email_verified`, `picture`, `profile`, `locale`, and `updated_at`.
   - Imported claims remain provider-local profile payload only; they do **not** become portable subject/account/profile export semantics, a contact-card substrate, durable linked-account truth, or transcript-stable identity receipt on existing SlopOS seams.
   - Existing identity-claim export, account-binding export, and login-state export boundaries stay authoritative instead of inheriting portable meaning from one provider's returned claim set.

3) **Imported UserInfo token use and `sub` matching stay provider-local validation only.**
   - OpenID Connect requires the `sub` Claim in the UserInfo Response to be verified as identical to the `sub` Claim in the ID Token when both are used, preventing token substitution across users.
   - That bearer-token use and `sub`-matching rule stay provider-local validation only; they do **not** become portable account-binding truth, a durable caller-identity oracle, approval-basis evidence, or reusable session-auth-state substrate on existing SlopOS seams.
   - Existing auth-exact-match, caller-auth-binding, account-binding export, and login-state export boundaries stay authoritative instead of inheriting platform meaning from one provider's profile-check rule.

4) **Imported signed/encrypted UserInfo metadata stay provider-local compatibility hints only.**
   - OpenID Connect defines client metadata such as `userinfo_signed_response_alg`, `userinfo_encrypted_response_alg`, and `userinfo_encrypted_response_enc` so one provider/client pair can agree on how UserInfo responses are protected.
   - Those metadata rows remain provider-local compatibility hints only; they do **not** become a portable identity-proof format registry, signer-policy substrate, approval-basis registry, or durable metadata-cache truth on existing SlopOS seams.
   - Existing client-registration, client-trust-policy, auth-metadata-fetch, and identity-claim export boundaries stay authoritative instead of inheriting platform meaning from one provider's UserInfo protection menu.

5) **No silent identity / account / login widening rides in through UserInfo.**
   - Imported UserInfo endpoint locations, claim payloads, subject matches, and signed/encrypted response preferences do **not** authorize portable current-user export, generic account-card lookup, linked-account truth, approval receipts, or hidden durable login/account/session state by implication.
   - A provider may use UserInfo to complete one authorization path, but that does **not** standardize a portable identity/profile export seam, current-account oracle, or login-state substrate on adjacent SlopOS seams.
   - If SlopOS ever needs a native profile-disclosure workflow, current-account lookup, or durable identity receipt, that work must arrive on those explicit seams and validators directly.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of OIDC helpers, profile-fetch wrappers, account-avatar caches, or claim-normalization shims must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient profile fetches, hidden account caches, or implicit claim export must fail closed for portable D-LLM auth semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local identity/profile retrieval, explicit auth/login boundaries, and explicit evidence artifacts.
   - Any future native profile-disclosure, current-account, or identity-receipt workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported UserInfo endpoints, claims, or profile-protection metadata.

## Phase 1 non-goals (explicitly deferred)

- No portable `userinfo_endpoint` / profile lookup / current-user query substrate imported directly from provider-local OIDC flows.
- No portable UserInfo claim bundle / subject-profile-email export seam imported directly from provider-local identity/profile retrieval.
- No portable rule that UserInfo bearer-token use or `sub` matching stands in for durable account-binding truth, caller identity, approval-basis evidence, or login-state truth.
- No portable rule that UserInfo signing/encryption metadata stands in for cross-provider identity-proof formats, signer-policy truth, or durable metadata-cache truth.

## Why this is worth pinning

The archive already keeps identity/profile export, account binding, login state, and auth-result handling on separate explicit seams. But current OAuth/OIDC ecosystems still add another adjacent pressure surface: after authorization, many clients fetch one provider's UserInfo response to populate account labels, avatars, profile cards, email routing, or “who am I signed in as?” UI.

That looks harmless, but it is exactly where invisible substrate grows. Once wrappers and agents start seeing UserInfo endpoint locations and returned claims, one provider-local profile fetch becomes “the platform's current-user API”, `sub` match becomes “our durable account-binding proof”, and signed/encrypted UserInfo preferences become “our identity-proof format registry”.

Pinning the boundary now keeps the archive honest. Imported UserInfo semantics may remain a provider-local way to retrieve or validate one profile payload, but they do not get to redefine subject/account/profile export, current-user truth, approval basis, or durable account/session truth on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with providers that return names, avatars, or email via UserInfo, but provider-local profile lookup still does not become a portable account-card API, current-user oracle, or durable signed-in/account-state truth.
- **Cloud micro-VM / hosted compute substrate (B):** hosted agents may fetch provider-local profile payloads for one authorization path, but those payloads do not become a reusable identity directory, durable account-binding substrate, or tenant-stable current-user truth.
- **Embedded / separation-kernel-ish appliance (C):** appliances may embed provider-local profile parsing in a narrow shim, but UserInfo remains sealed compat only and policy-killable, with no hidden profile cache or account export substrate.
- **Agent / automation OS (D):** first-class LLM/automation stacks are exactly where UserInfo can be over-read as a portable “who is signed in?” or profile-card API; this boundary keeps agent memory/tooling from quietly normalizing that widening.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Dedicated checker:** `tools/check_mcp_userinfo_import_boundary.py`
- **Evidence id:** `EVID-2026-695`
- **What it fails on:** missing family membership, missing discovery wiring, or wording drift that would let imported `userinfo_endpoint` locations, UserInfo claims, bearer-token / `sub`-match validation, or signed/encrypted UserInfo metadata silently regrow a portable subject/account/profile export, current-user oracle, approval-basis receipt, contact-card substrate, or durable account/session/auth-state truth.

## References

- REF-MCP-AUTHORIZATION
- REF-OPENID-CONNECT-CORE
- REF-RFC9700-OAUTH-SECURITY
