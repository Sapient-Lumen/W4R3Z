# D-LLM MCP-elicitation import boundary v0 (form/url user-input requests are not secret/browser/callback truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-mediation cuts in `llm-elicitation-boundary-v0.md`: current MCP elicitation (`elicitation/create`, `mode: "form"|"url"`, bounded `requestedSchema`, response `action: "accept"|"decline"|"cancel"`, optional `notifications/elicitation/complete`, and `URLElicitationRequiredError`) is **provider-local request-scoped user-input mechanics only**. It does **not** create a portable inline secret-ingress plane, browser/session authority, callback/completion substrate, login-result artifact, or durable auth state oracle on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP elicitation semantics may be interpreted next to already-pinned explicit-local-mediation, secret-ingress, browser-handoff, and auth-result boundaries.

## Posture (v0)

1) **Imported elicitation stays request-scoped and reactive only.**
   - `elicitation/create` remains a provider-local nested request that happens while processing an originating client action such as an MCP tool call, `resources/read`, or `prompts/get`.
   - It does **not** create a portable unsolicited server-push, background questionnaire, mailbox, or ambient callback plane.
   - This keeps D-LLM and Hybrid honest: imported user-input requests do not silently widen into D-JOBS / D-BGLEASE semantics or a second request-orchestration substrate.

2) **Form mode stays bounded proposal collection only.**
   - MCP form mode may describe a bounded `requestedSchema`, including flat primitive fields, enums, validation hints, and optional defaults.
   - Those schema/default hints may help the host render one request-local form, but they do **not** become portable local defaults, durable profile fields, hidden approval basis, or generic secret-ingress semantics.
   - Sensitive data still stays off this lane: the generic secret boundary remains explicit and separate under `appsecret-secret-ingress-boundary-v0.md` and `llm-elicitation-boundary-v0.md`.

3) **URL mode is an explicit handoff proposal only, not browser/session authority.**
   - `mode: "url"`, `url`, `elicitationId`, and `URLElicitationRequiredError` may ask the host to offer an inspect-and-approve external handoff.
   - They do **not** authorize silent browser open, embedded-webview control, authenticated browser-session export, callback registration, or hidden page-state observation.
   - An accepted URL-mode elicitation means the user consented to the handoff only; it is not proof that an OAuth/payment/credential flow completed, nor that the remote service granted durable authority on any reviewed SlopOS seam.

4) **Response actions are mediation outcomes only, not portable approvals or receipts.**
   - MCP’s `action: "accept"|"decline"|"cancel"` triad may help providers distinguish submitted data, explicit refusal, and dismissal.
   - Those outcomes do **not** become portable CH-AUTHZ receipts, durable approval artifacts, login results, or current-state truth.
   - Any privileged follow-on effect still needs its own explicit reviewed SlopOS seam, validators, policy gates, receipts, and evidence hooks.

5) **Completion notifications remain provider-local liveness only.**
   - Optional `notifications/elicitation/complete` may help a host resume or retry one provider-owned interaction.
   - They do **not** become a portable queue/watch API, durable completion receipt, auth-success oracle, or background resumption plane.
   - Likewise, the absence of such a notification is not portable proof that a remote flow failed; reviewed completion truth still lives where the eventual explicit outcome artifact lives, if any.

6) **No credential/token/account-result import from elicitation itself.**
   - Imported MCP elicitation does **not** authorize third-party credentials, bearer tokens, cookie jars, authorization codes, granted scopes, linked-account state, or profile identity claims to transit through the host as generic elicitation payload.
   - Any such semantics remain fenced by the existing auth-mediation family (`browser-session-export-boundary-v0.md`, `auth-result-export-boundary-v0.md`, `authorization-context-export-boundary-v0.md`, `identity-claim-export-boundary-v0.md`, `account-binding-export-boundary-v0.md`, and friends).
   - This keeps sealed compat honest too: imported auth/login handoffs remain killable by policy and do not smuggle ambient browser/session channels back across reviewed boundaries.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit approvals, explicit workflow/portal seams, and explicit evidence artifacts.
   - Any future native user-input / auth-hand-off / callback workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP elicitation helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `elicitation_handle`, `elicitation_queue`, `elicitation_watch`, `callback_registration`, `browser_handoff_receipt`, or `login_completion_receipt` substrate imported directly from MCP elicitation.
- No rule that form-mode `requestedSchema` or optional defaults stand in for local profile fields, remembered defaults, secret-entry authority, or trusted approval text.
- No rule that URL-mode `accept`, `notifications/elicitation/complete`, or `URLElicitationRequiredError` become a portable browser/session control plane, auth-success oracle, or durable background-resume API.
- No rule that imported elicitation responses/results authorize token passthrough, account-linking truth, connected-account selection, or generic callback/result export.

## Why this is worth pinning

The archive already says generic extra user input stays on explicit local mediation seams, and it already keeps auth results, browser sessions, granted scopes, and connected-account truth on separate narrow boundaries. MCP elicitation is the next specific pressure surface: current MCP now standardizes form mode, URL mode, bounded request schemas with defaults, a three-action response model, optional completion notifications, and explicit request-association rules for `elicitation/create`.

That is useful, but it is also exactly where hosts and agent wrappers start to slide from “provider-local request for more user input” into “remote login wizard the platform now understands.” Once that drift lands, form schemas start masquerading as trusted local fields, URL accepts start masquerading as auth completion, completion notifications start masquerading as callback receipts, and provider-owned state starts looking like a portable login/session substrate.

Pinning the boundary now keeps the archive honest. Imported MCP elicitation may remain a local UX convenience for bounded request-scoped user-input flows, but it does not get to redefine what secret ingress, browser handoff, auth completion, approval receipts, or durable account/session truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may support modern MCP form/url interaction flows, but login/payment/credential completion still stays on explicit trusted mediation seams rather than a hidden protocol-native browser/auth plane.
- **Cloud micro-VM substrate (B):** hosted agents can surface request-scoped user-input needs without pretending provider-owned elicitation state is a tenant-stable callback, browser session, or account-binding substrate.
- **Embedded / separation appliance (C):** appliances can omit MCP elicitation entirely or translate it to narrow local prompts without importing a generic browser/auth callback story they do not want.
- **Agent/automation OS (D):** this matters most here: imported MCP elicitation may guide one local request, but it does not become a second planner/login/runtime substrate alongside explicit approvals, secret seams, and job/background workflows.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/llm-elicitation-boundary-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_elicitation_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “form/url user-input requests are not secret/browser/callback truth” posture drifts (**EVID-2026-670**).

## References

- `REF-MCP-ELICITATION`
- `REF-MCP-REQ-ASSOCIATION`
- `REF-MCP-SPEC`
