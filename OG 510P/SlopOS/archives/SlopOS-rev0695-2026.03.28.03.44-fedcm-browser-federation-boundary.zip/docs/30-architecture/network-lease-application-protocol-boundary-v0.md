# D-NETLEASE application-protocol boundary v0 (no portable ALPN / application-protocol negotiation seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed leased networking over `tls` / `quic` does **not** become a portable ALPN / application-protocol negotiation surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable ALPN / application-protocol negotiation seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **destination predicate**, the granted **resolver binding**, and the transport class.
   - They do **not** grow a portable `alpn`, `alpn_offer`, `selected_alpn`, `app_proto`, `protocol_profile`, `http_version`, `http2`, `http3`, `grpc_profile`, `webtransport_profile`, or equivalent application-protocol negotiation/export surface.
   - Phase 1 portable truth is therefore: **what reachability predicate was reviewed/granted, through which resolver binding, over which transport class** — not which higher-layer protocol the runtime offered, selected, upgraded to, or required on top of that transport.

2) **Application-protocol choice stays portal-local or app-local.**
   - A lease may authorize reachability over `tls` or `quic`.
   - That does **not** standardize which ALPN list, HTTP version, gRPC profile, WebTransport mode, or other application-protocol selection a provider/runtime uses for a concrete connection.
   - Different product profiles or owner-local runtimes may therefore expose different higher-layer defaults locally — or none at all — while still staying inside the same reviewed D-NETLEASE grant.

3) **No hidden default-protocol folklore.**
   - Reviewed networking in Phase 1 must not silently inherit browser, SDK, or library defaults for ALPN lists, automatic HTTP/2 or HTTP/3 negotiation, opportunistic upgrade behavior, or similar “the stack chose a protocol for me” residue as substrate meaning.
   - That rule applies both to direct `portal.net` implementations and to wrappers/compat paths around them: hidden protocol-selection defaults are not by themselves reviewed network authority.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient channels through hidden HTTP-version / ALPN / protocol-profile assumptions.

4) **If portable application-protocol semantics matter, pay for a new seam explicitly.**
   - A future product shape may want reviewed HTTP-substrate semantics, protocol-profile negotiation, or transcript-visible ALPN/application-protocol receipts.
   - That work must return **RFC-first** with its own schema/receipt family, conflict keys, commutativity story, freshness rules, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems negotiate HTTP/2, HTTP/3, gRPC, or other protocols on top of TLS/QUIC.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit application-protocol seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from ALPN registries, browser defaults, or HTTP library heuristics.

6) **Current selected application protocol is connection-local live state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove which ALPN token or higher-layer protocol a given connection selected, whether the same protocol would be selected on retry, or whether a runtime later changed its higher-layer fallback/upgrade behavior.
   - As elsewhere in SlopOS, stable request/receipt artifacts are evidence of one reviewed action, not a portable oracle for mutable connection-local protocol negotiation results.

## Phase 1 non-goals (explicitly deferred)

- No portable `alpn`, `alpn_offer`, `selected_alpn`, `app_proto`, `protocol_profile`, `http_version`, `http2`, `http3`, `grpc_profile`, or `webtransport_profile` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a protocol-negotiation broker, HTTP-version selector, or app-protocol policy plane.
- No transcript-stable claim that an accepted network request or issued lease also proves a selected ALPN token, negotiated HTTP version, or current application-protocol result.
- No hidden browser/SDK/library compatibility promise that `tls` / `quic` reachability implies `h2`, `h3`, gRPC, or other higher-layer protocol semantics on `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS, and the recent passes kept answer/path telemetry, local-egress policy, path-property state, proxy policy, transport verifier policy, and client-auth identity out of CH-NETREQ / CH-NETLEASE portable meaning. The next quiet drift is to pretend the same lease also says **which higher-layer protocol stack is in play**. Real systems do negotiate ALPN and then layer HTTP/2, HTTP/3, gRPC, or other protocols on top, but the standards treat that as explicit higher-layer protocol machinery — not harmless residue of “a network request was reviewed.”

If we leave that blurry, workstation and agent flows will start depending on whichever ALPN lists, HTTP-version upgrades, or protocol defaults the local browser/runtime happened to ship, while cloud and embedded profiles will be forced to fake portability for protocol-negotiation semantics they do not actually share. Pinning the boundary now keeps D-NETLEASE honest: reviewed reachability is one seam, reviewed application-protocol negotiation would be another future seam if we ever truly need it.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich HTTP/2 / HTTP/3 stacks locally, but that does not standardize those defaults as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound reachability explicit without pretending guest/runtime HTTP-version or ALPN defaults are transcript-stable reviewed truth.
- **Embedded / separation appliance (C):** appliance builds can keep a narrow leased-network seam without paying for a portable general-purpose application-protocol negotiation plane they do not want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “lease to this destination over TLS/QUIC” with “portable statement that HTTP/2, HTTP/3, gRPC, or another higher-layer protocol is reviewed, selected, or guaranteed.”

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-tls-verifier-boundary-v0.md`
  - `docs/30-architecture/network-lease-client-cert-boundary-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-CAPSHELL-NET-EXPLICIT**)

CI drift gate:
- `tools/check_network_lease_application_protocol_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable ALPN / application-protocol negotiation seam / no hidden default-protocol folklore / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-637**).

## References

- REF-RFC7301-ALPN.
- REF-RFC9113-HTTP2.
- REF-RFC9114-HTTP3.
- REF-RFC9205-HTTP-BCP.
