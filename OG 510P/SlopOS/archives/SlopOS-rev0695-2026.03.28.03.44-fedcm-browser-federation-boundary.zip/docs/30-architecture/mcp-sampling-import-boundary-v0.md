# D-LLM / D-JOBS / D-BGLEASE / IF-ACP MCP-sampling import boundary v0 (nested sampling is not portable planner/background truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-JOBS / D-BGLEASE / IF-ACP** seam: current MCP sampling (`sampling/createMessage`, returned assistant messages, optional nested tool use, model preferences, and associated request-correlation rules) is **provider-local / request-local nested model-generation mechanics only**. It does **not** create a portable planner/assistant substrate, background-autonomy plane, durable conversation thread, queue/completion oracle, or hidden approval/policy truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP sampling semantics may be interpreted next to already-pinned LLM, workflow, task/progress, and approval cuts.

This doc is an **intentional singleton** today. It is listed in `boundary-family-map.md` until a broader reviewed imported-sampling family exists.

## Posture (v0)

1) **No portable planner/background substrate in imported MCP sampling.**
   - `sampling/createMessage`, request `messages`, optional `systemPrompt`, optional `maxTokens`, returned assistant-role content, returned `model`, and returned `stopReason` remain **provider-local / request-local nested model-generation mechanics** on **D-LLM**.
   - They may help one host let a provider request local model assistance while processing a tool call, resource read, or prompt retrieval.
   - They do **not** by themselves mint a reviewed planner handle, autonomous agent lease, durable conversation/session substrate, hidden workflow engine, or a second portable model-execution plane on existing SlopOS seams.

2) **Tool-enabled sampling stays local and request-scoped.**
   - Optional sampling `tools` arrays, `toolChoice`, multi-turn tool loops, and returned tool-result messages may help one provider ask the host LLM to reason with the host's declared tools during one nested request.
   - They do **not** become portable connector/tool authority, validator-approved action semantics, hidden widget/tool plane, retry-policy truth, or commutativity truth.
   - Any later real effect still crosses an explicit reviewed seam with its own schema, validators, conflict keys, receipts, and evidence hooks.

3) **Model-selection and review hints stay advisory only.**
   - `modelPreferences`, `hints`, `intelligencePriority`, `speedPriority`, returned concrete `model`, and the spec's human-review guidance may help one host choose and present a provider-local generation.
   - They do **not** become portable approval basis, policy truth, billing/procurement truth, review receipts, safety verdicts, or durable evidence about which exact model a reviewed SlopOS action used.

4) **Context inclusion remains local and non-authoritative.**
   - Optional sampling context inclusion and the current soft-deprecated `includeContext` values remain provider-local request-shaping convenience only.
   - They do **not** become ambient all-server context authority, hidden cross-connector data import, durable memory truth, filesystem/document grant, or approval-visible evidence substrate.
   - If context bytes later need explicit file/document/evidence meaning, they still cross the existing reviewed import/materialization and observation seams rather than arriving by sampling folklore.

5) **Request association is mandatory; no standalone server-push sampler plane.**
   - Current MCP guidance plus accepted SEP-2260 require `sampling/createMessage` requests to stay associated with an originating client request such as `tools call`, `resources/read`, or `prompts/get` processing.
   - Standalone server-initiated sampling on independent streams or background timers therefore remains out of scope in Phase 1.
   - Imported MCP sampling does **not** become a cron-like autonomous background planner, unsolicited assistant plane, or durable requestless callback channel beside `portal.jobs` / `portal.background`.

6) **Returned generations are proposals only, not approval or completion truth.**
   - Returned assistant messages, tool-call reasoning loops, and `stopReason` values may help a provider propose the next local step.
   - They do **not** by themselves prove reviewed action admission, downstream effect completion, current live state, or durable transcript/evidence truth.
   - If a sampled answer should trigger a real effect, that effect still crosses explicit CH-ACP / portal / receipt seams rather than being smuggled in as “the model already decided.”

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: exact reviewed actions, explicit workflow/portal seams, explicit receipts, and explicit evidence artifacts.
   - Any future reviewed portable sampling/planner family must state its own conflict keys, commutativity conditions, serialization point, retention model, cost/accounting semantics, and evidence story explicitly rather than inheriting folklore from MCP nested sampling.

## Phase 1 non-goals (explicitly deferred)

- No portable `sampling_session`, `assistant_thread`, `planner_handle`, `model_run`, `agent_loop`, `tool_loop_receipt`, or `background_sampler` substrate imported directly from MCP sampling.
- No rule that returned assistant content, `stopReason`, or tool-enabled sampling loops stand in for CH-ACP admission, durable workflow state, completion truth, or current provider-owned live state.
- No rule that `modelPreferences`, model hints, or returned `model` become portable policy/admin/billing/approval truth.
- No adapter shortcut that turns nested sampling into hidden autonomous background work, hidden cross-connector context import, or a requestless server-push agent plane.

## Why this is worth pinning

The archive already says imported task wrappers, progress signals, roots, resources, logging, and prompt catalogs do not become native SlopOS authority, evidence, or workflow truth by accident. MCP sampling is the next obvious pressure surface: a provider can ask the host for a nested model call, optionally request tool use, optionally shape context/model preferences, and receive assistant output while handling one tool/resource/prompt request.

That is useful, but it is also exactly where hosts and adapters start to slide from “provider-local nested model assistance” into “the provider now has a second planner/runtime inside the OS.” Once that drift lands, returned assistant text starts to masquerade as approval, model preferences start to masquerade as policy, and nested sampling starts to masquerade as an autonomous background agent plane.

The accepted request-association clarification makes this worth freezing now. Current MCP intentionally keeps `sampling/createMessage` reactive and nested inside an originating client request rather than a free-floating server-push channel. Pinning the boundary now keeps SlopOS honest: imported MCP sampling may remain a provider-local nested-generation convenience, but it does not get to redefine reviewed planner/background/action semantics on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may let providers request nested local model help for one reviewed interaction without silently importing a second assistant/session/workflow substrate.
- **Cloud micro-VM substrate (B):** hosted agents avoid mistaking provider-owned nested sampling loops for tenant-stable planner handles, background work, or durable conversation state.
- **Embedded / separation appliance (C):** appliance builds can ignore MCP sampling entirely or translate it to local proposal UX without promising a portable model-execution/control plane.
- **Agent/automation OS (D):** agents may use provider-local nested model assistance, but reviewed planning, background work, approval, and evidence truth still live on explicit SlopOS seams rather than drifting into sampling folklore.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam; the current cut is only the narrow MCP-sampling import boundary.

If a second closely related imported-sampling boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_sampling_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “nested sampling is not portable planner/background truth” posture drifts (**EVID-2026-668**).

## References

- `REF-MCP-SAMPLING`
- `REF-MCP-REQ-ASSOCIATION`
