# D-NETLEASE transport-profile boundary v0 (no portable TLS / QUIC version / cipher / group / transport-parameter seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed leased networking over `tls` / `quic` does **not** become a portable transport-profile surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable transport-profile seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **destination predicate**, the granted **resolver binding**, and the transport class.
   - They do **not** grow a portable `tls_min_version`, `tls_max_version`, `tls_versions`, `tls13_ciphers`, `cipher_suites`, `groups`, `signature_algorithms`, `quic_version`, `quic_versions`, `transport_profile`, `transport_params`, `max_idle_timeout`, `max_udp_payload_size`, `initial_max_data`, `active_connection_id_limit`, or equivalent transport-profile/export surface.
   - Phase 1 portable truth is therefore: **what reachability predicate was reviewed/granted, through which resolver binding, over which transport class** — not which TLS/QUIC versions, cipher suites, groups, signature-algorithm lists, or transport-parameter profile a later connection offered/negotiated/enforced.

2) **Transport profile stays portal-local or app-local.**
   - A lease may authorize reachability over `tls` or `quic`.
   - That does **not** standardize whether an implementation pins minimum/maximum TLS versions, narrows cipher/group preference, constrains signature algorithms, requires a particular QUIC version, or clamps QUIC transport parameters such as idle timeout, payload size, or flow-control defaults.
   - Different product profiles or owner-local runtimes may therefore expose different transport-profile defaults locally — or none at all — while still staying inside the same reviewed D-NETLEASE grant.

3) **No hidden TLS/QUIC handshake-profile folklore.**
   - Reviewed networking in Phase 1 must not silently inherit browser, SDK, proxy, or library defaults for TLS-version floors, cipher lists, group preference, signature-algorithm preference, QUIC version choice, or QUIC transport-parameter defaults as substrate meaning.
   - That rule applies both to direct `portal.net` implementations and to wrappers/compat paths around them: hidden transport-profile defaults are not by themselves reviewed network authority.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient channels through host-local handshake policy, version/cipher downgrade expectations, or library-specific QUIC transport tuning residue.

4) **If portable transport-profile semantics matter, pay for a new seam explicitly.**
   - A future product shape may want reviewed TLS-version floors, transcript-visible cipher/profile selection, or explicit QUIC transport-parameter policy.
   - That work must return **RFC-first** with its own schema/receipt family, conflict keys, commutativity story, downgrade/privacy posture, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems expose TLS version/cipher controls or QUIC transport-parameter knobs.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit transport-profile seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from library TLS defaults, browser ATS policies, or QUIC stack tuning knobs.

6) **Current negotiated version/profile is connection-local live state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove whether a given connection negotiated TLS 1.3 vs TLS 1.2, selected one cipher suite over another, used one key-share group, ran one QUIC version over another, or accepted a concrete transport-parameter profile.
   - As elsewhere in SlopOS, stable request/receipt artifacts are evidence of one reviewed action, not a portable oracle for mutable connection-local handshake policy or negotiated transport-profile behavior.

## Phase 1 non-goals (explicitly deferred)

- No portable `tls_min_version`, `tls_max_version`, `tls_versions`, `tls13_ciphers`, `cipher_suites`, `groups`, `signature_algorithms`, `quic_version`, `quic_versions`, `transport_profile`, or `transport_params` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a TLS-version floor broker, cipher/group policy broker, or QUIC transport-parameter policy plane.
- No transcript-stable claim that an accepted network request or issued lease also proves a negotiated TLS/QUIC profile.
- No hidden browser/SDK/library compatibility promise that `tls` / `quic` reachability implies one reviewed transport-profile behavior on `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS, and the recent passes kept resolver answers, local-egress policy, path-state folklore, proxy policy, transport verifier policy, client-auth identity, application-protocol negotiation, TLS server-name presentation, and session resumption out of CH-NETREQ / CH-NETLEASE portable meaning. The next quiet drift is to pretend the same lease also says **how the handshake/transport profile is shaped**. Real systems treat TLS versions, cipher lists, key-share groups, per-domain ATS exceptions, QUIC versions, and QUIC transport parameters as explicit configuration and negotiation surfaces, not as harmless residue of “a network request was reviewed.”

If we leave that blurry, workstation and agent flows will start depending on whichever TLS floors, cipher defaults, or QUIC parameter knobs the local browser/runtime happened to ship, while cloud and embedded profiles will be forced to fake portability for handshake behavior they do not actually share. Pinning the boundary now keeps D-NETLEASE honest: reviewed reachability is one seam, reviewed transport-profile policy would be another future seam if we ever truly need it.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use richer TLS/QUIC stacks with ATS policies, version floors, and transport tuning locally, but that does not standardize those defaults as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound reachability explicit without pretending guest/runtime TLS policy or QUIC transport tuning are transcript-stable reviewed truth.
- **Embedded / separation appliance (C):** appliance builds can keep a narrow leased-network seam without paying for a portable general-purpose TLS/QUIC profile plane they do not want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “lease to this destination over TLS/QUIC” with “portable statement that one reviewed TLS-version/cipher/group/QUIC-parameter profile was selected or guaranteed.”

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-application-protocol-boundary-v0.md`
  - `docs/30-architecture/network-lease-session-resumption-boundary-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-CAPSHELL-NET-EXPLICIT**)

CI drift gate:
- `tools/check_network_lease_transport_profile_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable TLS / QUIC version / cipher / group / transport-parameter seam / no hidden handshake-profile folklore / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-640**).

## References

- REF-RFC8446-TLS13.
- REF-RFC9000-QUIC-TRANSPORT.
- REF-CURL-SSL-CIPHERS.
- REF-APPLE-ATS-COCOAKEYS.
