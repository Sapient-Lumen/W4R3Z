# D-LLM MCP-step-up-auth import boundary v0 (`acr_values` / `max_age` are not portable assurance / recent-login truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported OAuth/MCP step-up-authentication material — `insufficient_user_authentication`, `acr_values`, `max_age`, and carried authentication-assurance data such as `acr`, `auth_time`, and `amr` in access tokens or token introspection responses — is **provider-local reauthentication guidance and verifier context only**. It does **not** create a portable assurance-level registry, recent-login oracle, user-presence proof, approval basis, or durable account/session truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported step-up-authentication semantics may be interpreted next to already-pinned authorization-context, token-introspection, auth-result, identity-claim, login-state, and account-binding boundaries.

## Posture (v0)

1) **Imported `insufficient_user_authentication` stays provider-local reauthentication demand only.**
   - RFC 9470 defines `insufficient_user_authentication` as a resource-access error indicating that the authentication event associated with the presented access token does not meet the protected resource's requirements.
   - Imported `insufficient_user_authentication` remains provider-local retry / reauthentication demand only; it does **not** become a portable assurance-failure verdict, approval denial basis, current-user-presence truth, or durable account/session-state artifact on existing SlopOS seams.
   - Existing auth-result, approval-basis, login-state, and account-binding boundaries stay authoritative instead of inheriting platform meaning from one provider's step-up error.

2) **Imported `acr_values` stays provider-local authentication-strength vocabulary only.**
   - RFC 9470 introduces `acr_values` on the `Bearer` challenge so a protected resource can indicate the required authentication context class reference values in order of preference.
   - Imported `acr_values` remains provider-local authentication-strength vocabulary only; it does **not** become a portable assurance taxonomy, trust-tier registry, approval class, or account-selection language on existing SlopOS seams.
   - Existing approval-basis, identity-claim, and authorization-context seams stay authoritative instead of inheriting native SlopOS meaning from one provider's ACR labels.

3) **Imported `max_age` stays provider-local recent-authentication bound only.**
   - RFC 9470 introduces `max_age` on the `Bearer` challenge to indicate the allowable elapsed time since the last active authentication event associated with the access token.
   - Imported `max_age` remains provider-local recent-authentication bound only; it does **not** become a portable recency SLA, current-user-presence oracle, durable session-freshness truth, or generic policy timer on existing SlopOS seams.
   - Existing timeproof, login-state, and approval-basis seams stay authoritative instead of inheriting platform meaning from one provider's auth-recency demand.

4) **Imported `acr` / `auth_time` / `amr` stay provider-local verifier context only.**
   - RFC 9470 defines how authentication information can be conveyed to protected resources via access tokens or token introspection, while OpenID Connect Core defines `acr`, `auth_time`, and `amr` claim meanings.
   - Imported `acr`, `auth_time`, and `amr` in access tokens or introspection responses remain provider-local verifier context only; they do **not** become a portable assurance ledger, recent-login receipt, user-presence proof, or durable account/session truth on existing SlopOS seams.
   - Existing token-introspection, identity-claim, auth-result, and login-state boundaries stay authoritative instead of inheriting durable platform meaning from one verifier-visible auth-context claim set.

5) **No silent assurance / presence widening rides in through step-up auth.**
   - Imported step-up-auth challenges and returned auth-context values do **not** authorize portable assurance-policy compilation, cross-provider reauthentication replay, hidden current-user-presence inference, or durable recent-login caching by implication.
   - A provider may require stronger or fresher authentication on one path, but that does **not** standardize a portable assurance registry, recent-login truth, or approval-basis substrate on adjacent SlopOS seams.
   - If SlopOS ever needs native assurance-level workflows, reviewed recent-auth gates, or user-presence receipts, that work must arrive on those explicit seams and validators directly.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth libraries, challenge parsers, token validators, or policy shims that handle step-up-auth challenges must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient assurance caches, implicit reauthentication policy, or hidden session-freshness state must fail closed for portable D-LLM auth semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local reauthentication handling, explicit auth-result and login-state seams, and explicit evidence artifacts.
   - Any future native assurance-level, recent-login, or presence-proof workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported `acr_values`, `max_age`, or step-up-auth claim sets.

## Phase 1 non-goals (explicitly deferred)

- No portable `insufficient_user_authentication` / step-up-required / reauthenticate-now control plane imported directly from provider-local authorization flows.
- No portable rule that `acr_values` labels stand in for native SlopOS assurance tiers, approval classes, tenant policy levels, or account-selection truth.
- No portable rule that `max_age` or returned `auth_time` becomes durable recent-login truth, a generic freshness SLA, or a user-presence receipt on existing seams.
- No portable rule that `acr`, `auth_time`, or `amr` in access tokens or introspection responses becomes a portable assurance registry, recent-login receipt, or durable login/account-state truth.

## Why this is worth pinning

The archive already keeps scope/resource guidance, verifier inputs, login-state, account-binding, and approval/result export on separate explicit seams. But current OAuth ecosystems still add another adjacent surface: **step-up authentication**, where one provider may return `insufficient_user_authentication`, ask for specific `acr_values`, demand a bounded `max_age`, and reflect authentication context back to the resource server through token or introspection claims.

That looks like harmless provider detail, but it is exactly where invisible substrate grows. Once wrappers and agents start seeing step-up challenges, `acr_values` becomes “the platform's assurance taxonomy”, `max_age` becomes “our portable recent-login rule”, and verifier-visible `acr` / `auth_time` / `amr` becomes “our current-user-presence receipt”.

Pinning the boundary now keeps the archive honest. Imported step-up-authentication mechanics may remain a provider-local way to recover one authorization path, but they do not get to redefine assurance levels, recent-login truth, approval basis, or durable account/session meaning on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with providers that require stronger or fresher authentication, but provider-local step-up hints still do not become portable assurance or recent-login truth.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted gateways will be tempted to centralize assurance tiers and recent-login caches, but those helpers do not become tenant-stable approval, presence, or account substrate by default.
- **Embedded / separation appliance (C):** appliances can omit step-up-auth entirely or terminate it in a narrow shim without importing a generalized assurance-registry or recent-login subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported `acr_values`, `max_age`, and verifier-visible auth-context claims are exactly the kind of structure agents will over-read as durable assurance or presence truth unless the archive pins them provider-local now.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Dedicated checker:** `tools/check_mcp_step_up_auth_import_boundary.py`
- **Evidence id:** `EVID-2026-692`
- **What it fails on:** missing family membership, missing discovery wiring, or wording drift that would let imported `insufficient_user_authentication`, `acr_values`, `max_age`, or verifier-visible `acr` / `auth_time` / `amr` silently regrow a portable assurance registry, recent-login oracle, user-presence proof, approval basis, or durable account/session truth.

## References

- REF-MCP-AUTHORIZATION.
- REF-RFC9470-STEP-UP-AUTH.
- REF-OPENID-CONNECT-CORE.
- REF-RFC7662-TOKEN-INTROSPECTION.
