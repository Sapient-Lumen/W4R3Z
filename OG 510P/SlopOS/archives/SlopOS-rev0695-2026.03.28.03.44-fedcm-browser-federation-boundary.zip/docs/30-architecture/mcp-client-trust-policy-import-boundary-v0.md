# D-LLM MCP-client-trust-policy import boundary v0 (client trust evaluation is not portable app-trust/policy/approval truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP authorization trust-policy guidance — protected-server domain allowlists for trusted client hosts, open-server `accept any HTTPS client_id` policy, reputation checks for unknown domains, restrictions based on domain age or certificate validation, and prominent display of client/CIMD hostnames to reduce phishing risk — is **provider-local client trust evaluation only**. It does **not** create a portable app-trust registry, trust-policy oracle, approval-basis substrate, signer/trust-root plane, or durable connected-app/account truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP/OAuth client trust-evaluation semantics may be interpreted next to already-pinned client-registration, auth-metadata-fetch, auth-result, auth-proof, identity-claim, account-binding, and approval-basis boundaries.

## Posture (v0)

1) **Client-host trust policies stay provider-local trust evaluation only.**
   - Current MCP authorization guidance explicitly allows authorization servers to keep domain-based trust policies such as allowlists for trusted client hosts on protected servers, broad acceptance of HTTPS `client_id` values on open servers, and further restrictions based on local operator policy.
   - Those policies remain provider-local/client-local trust evaluation only; they do **not** create a portable app-trust registry, trusted-client oracle, connector-governance substrate, or durable approval artifact on existing SlopOS seams.
   - Existing approval-basis, signer/trust-root, and account-binding boundaries stay authoritative instead of inheriting hidden meaning from one provider's client-host allow/deny rules.

2) **Reputation, domain-age, and certificate-validation checks stay provider-local verifier policy only.**
   - MCP's trust-policy guidance also permits reputation checks for unknown domains plus restrictions based on domain age or certificate validation when an authorization server evaluates a fetched `client_id` / metadata-host pair.
   - Those heuristics remain provider-local/client-local verifier policy only; they do **not** become a portable URL-safety verdict, trust-root selection plane, app-identity proof, or durable approval/evidence result on existing SlopOS seams.
   - Existing OpenURI URL-safety, signature trust-root, and evidence boundaries stay authoritative instead of inheriting durable truth from auth-provider reputation folklore.

3) **Displayed hostnames are phishing mitigations, not portable identity/account truth.**
   - Current MCP guidance says authorization servers may display the Client ID Metadata Document hostname and related client hostnames prominently to help users recognize who is requesting access.
   - That display guidance remains provider-local phishing mitigation only; it does **not** create a portable app-identity registry, linked-account truth, selected-account truth, or durable approval-basis artifact on existing SlopOS seams.
   - Existing identity-claim, account-binding, and auth-result boundaries stay authoritative instead of inheriting durable truth from UI presentation conventions.

4) **Accept/deny outcomes and trust-policy changes stay provider-local live state only.**
   - A provider may revise allowlists, reputation thresholds, certificate-validation posture, or open-server acceptance rules over time, and may accept or deny one fetched client metadata document under those local policies.
   - Those outcomes remain provider-local live policy state only; they do **not** become a portable approval receipt, tenant-policy export, durable connected-app inventory, or transcript-stable app-governance fact on existing SlopOS seams.
   - Likewise, a provider's decision to accept one HTTPS `client_id` does not create portable trust in the same client across other providers, accounts, or product shapes.

5) **No silent callback/token/account widening rides in through trust evaluation.**
   - Imported client trust-evaluation semantics do **not** authorize callback registration, authorization continuation handles, token passthrough, linked-account truth, login-state truth, or browser-session continuity by implication.
   - If an eventual reviewed SlopOS seam needs portable app trust, approval basis, connected-app truth, or auth-governance artifacts, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: client trust evaluation remains killable by policy and does not smuggle ambient callback, token, account, or session channels into existing surfaces.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit approvals, explicit auth/login boundaries, and explicit evidence artifacts.
   - Any future native app-trust / client-governance / approval-basis workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP client trust-evaluation helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `trusted_client_registry`, `client_trust_verdict`, `client_reputation_score`, `client_domain_policy`, `approved_client_hosts`, or `client_metadata_risk_report` substrate imported directly from MCP trust-policy helpers.
- No rule that provider-side host allowlists, broad HTTPS acceptance, domain-age filters, certificate-validation posture, or reputation checks stand in for portable app trust, portable approval basis, connected-account truth, or durable evidence truth.
- No rule that prominently displayed client/CIMD hostnames stand in for portable app identity, selected-account truth, or durable approval/account artifacts.
- No rule that provider-side trust evaluation authorizes callback registration, token relay, authorization continuation, or browser-session continuity on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps client registration/bootstrap, auth discovery/fetch, callback results, approval basis, linked accounts, and login state on separate explicit seams. Current MCP authorization now adds another nearby pressure surface: an explicit **Trust Policies** section that tells authorization servers they may keep domain allowlists for trusted client hosts, accept any HTTPS `client_id` for open servers, run reputation checks for unknown domains, restrict based on domain age or certificate validation, and prominently display client/CIMD hostnames to reduce phishing risk.

Those trust-policy moves are useful, but they are also easy for hosts and wrappers to over-read as durable platform truth. Once that drift lands, provider-side allowlists start masquerading as a portable trusted-app registry, reputation checks start masquerading as durable approval basis, displayed client hostnames start masquerading as connected-account truth, and one provider's HTTPS-acceptance posture starts looking like a reusable governance policy across other providers and product shapes.

Pinning the boundary now keeps the archive honest. Imported MCP client trust evaluation may remain a provider-local way to decide whether to continue one authorization path, but it does not get to redefine what app trust, approval basis, connected-app truth, or durable policy/evidence mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may interoperate with modern MCP/OAuth client trust checks, but provider-side allowlists/reputation/certificate checks still stay local policy rather than portable app-trust or approval-basis truth.
- **Cloud micro-VM substrate (B):** hosted agents may encounter many remote authorization servers with different client-host policies, but those trust decisions do not become tenant-stable connector governance, trusted-app inventory, or connected-account substrate.
- **Embedded / separation appliance (C):** appliances can omit rich client trust evaluation entirely or terminate it in a narrow provider shim without importing a generic app-trust / approval-basis story they do not want.
- **Agent/automation OS (D):** this matters most here: imported client trust-evaluation helpers may smooth one provider-owned authorization path, but they do not become a second app-governance / approval-basis / connected-app substrate beside explicit approvals, auth results, identity claims, and account-binding seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_client_trust_policy_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “client trust evaluation is not portable app-trust/policy/approval truth” posture drifts (**EVID-2026-678**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-MCP-SEP-991`
- `REF-OAUTH-CLIENT-ID-METADATA`
- `REF-MCP-AUTH-SECURITY`
