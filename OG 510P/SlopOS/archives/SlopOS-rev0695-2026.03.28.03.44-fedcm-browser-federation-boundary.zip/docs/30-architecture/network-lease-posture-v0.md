# D-NETLEASE posture v0 (no ambient sockets/DNS; portal-issued leased network authority)

Purpose: pin an **implementable Phase 1** meaning for D-NETLEASE that keeps networking non-ambient (I-NETLEASE-1), keeps sealed-compat honest (policy-killable; no ambient channels), and keeps Hybrid/commutativity evidence coherent on the automation surface (D-COMMUTE).

This doc is intentionally narrow: it does **not** design a full firewall UI, per-packet filtering, or “compat sockets” shims.

## Posture (v0)

1) **No ambient socket constructors (networking is explicit authority)**
   - If D-NETLEASE is enabled, the platform MUST NOT expose ambient `socket()/connect()/bind()/listen()` constructors to post-init components.
   - Outbound networking authority is obtained only via `portal.net` (manual workflow) or ACP kind `portal.net.request` (automation), which returns an opaque network authority handle plus a redaction-aware bounds descriptor (CH-NETLEASE v0).
   - Any interop/compat layer that would recreate ambient sockets is out of scope in Phase 1.

2) **No ambient DNS / resolver or proxy configuration**
   - If D-NETLEASE is enabled, there is no ambient resolver/proxy surface (`/etc/resolv.conf`, `getaddrinfo`-style global resolver APIs, `$http_proxy` / `$HTTPS_PROXY` / `ALL_PROXY` / `NO_PROXY`, PAC URLs/scripts, WPAD, or implicit “use system proxy” routing).
   - Domain-name resolution occurs only inside the leased authority:
     - Connect-side requests describe destination intent via CH-NETREQ `dest.kind in {dns_name,dns_suffix,service}`.
     - Listen-side requests describe a **local bind/exposure subject** instead: `kind=listen` admits `ip_prefix` or local-policy `service` labels only, not `dns_name` / `dns_suffix` listener predicates (`network-request-listen-subject-boundary-v0.md`).
     - Leases record the granted resolver binding via CH-NETLEASE `resolver.kind="portal"` (v0).
   - Rationale: DNS is both authority and metadata. Treating it as ambient breaks “killable by policy” and creates covert channels.

3) **Scope is a policy label; enforcement is in the leased authority**
   - CH-NETREQ/CH-NETLEASE carry a closed `scope` enum (`internet | local | loopback | explicit`).
   - The portal clamps/denies by policy; the granted `scope` value is part of the receipt surface.
   - Enforcement lives in the leased authority object (PO-NETLEASE-ENFORCE); there is no “bypass” path (I-NETLEASE-2).

4) **Resolver binding is explicit (DNS bind obligation is satisfiable)**
   - For any lease that can resolve names (`kind=="dns"` or `kind=="connect"` with `dest.kind in {dns_name,dns_suffix,service}`), CH-NETLEASE MUST include `resolver`. Listen-side `service` labels do not by themselves require a resolver because they name local exposure classes rather than remote lookup inputs (`network-request-listen-subject-boundary-v0.md`).
   - v0 only admits `resolver.kind="portal"`.
   - This keeps PO-NETLEASE-DNSBIND evidenceable without introducing a second, ambient resolver channel.
   - Companion `network-lease-resolution-boundary-v0.md` further pins that this explicit resolver binding does **not** widen CH-NETLEASE into a portable answer-set / selected-endpoint / route-selection surface; exact answer/path state stays portal-local rather than transcript-stable receipt truth.
  - Companion `network-lease-dns-query-boundary-v0.md` further pins that `kind=dns` stays address-resolution-only: RR-type/class queries, raw DNS replies, and resolver-transport mechanics do **not** widen CH-NETREQ / CH-NETLEASE into a portable generic DNS-query seam.
   - Companion `network-lease-name-context-boundary-v0.md` further pins that reviewed name predicates stay exact-predicate-only: host search-path, hosts-file/NSS policy, split-DNS views, mDNS, and LLMNR do **not** widen CH-NETREQ / CH-NETLEASE into a portable local-name-resolution seam.
   - Companion `network-lease-name-normalization-boundary-v0.md` further pins that reviewed `dns_name` / `dns_suffix` predicates stay one exact-byte canonical ASCII predicate: Unicode U-label input, IDNA / UTS #46 mapping, locale casefolding, and trailing-dot cleanup do **not** widen CH-NETREQ / CH-NETLEASE into a portable Unicode / IDNA / normalization seam.
   - Companion `network-lease-port-inference-boundary-v0.md` further pins that `connect` / `listen` requests using `dns_name` / `dns_suffix` / `ip_prefix` stay explicitly port-shaped: absent numeric ports do **not** widen CH-NETREQ / CH-NETLEASE into a portable default-port / service-name seam.
  - Companion `network-lease-service-binding-boundary-v0.md` further pins that reviewed `dns_name` / `dns_suffix` predicates stay host-address-oriented only: SRV / SVCB / HTTPS alternate endpoints, endpoint parameters, and service-binding / alternate-endpoint semantics do **not** widen CH-NETREQ / CH-NETLEASE into a portable service-discovery seam.
  - Companion `network-lease-address-selection-boundary-v0.md` further pins that reviewed `dns_name` / `dns_suffix` predicates stay destination-predicate-only: IPv4 / IPv6 family preference, RFC 6724 sorting, and Happy-Eyeballs address racing do **not** widen CH-NETREQ / CH-NETLEASE into a portable address-selection seam.
   - Companion `network-lease-local-egress-boundary-v0.md` further pins that CH-NETREQ / CH-NETLEASE do **not** widen into a portable local-interface / source-address / VRF seam; local egress selection remains portal-local or app-local rather than transcript-stable receipt truth.
   - Companion `network-lease-path-property-boundary-v0.md` further pins that CH-NETREQ / CH-NETLEASE do **not** widen into a portable metered / validated / captive / expensive / constrained path-property or connectivity-state seam; current path hints remain portal-local or app-local rather than transcript-stable receipt truth.
   - Companion `network-lease-proxy-boundary-v0.md` further pins that CH-NETREQ / CH-NETLEASE do **not** widen into a portable proxy-selection / PAC / WPAD / system-proxy seam; any proxied routing remains portal-local policy rather than transcript-stable receipt truth.
   - Companion `network-lease-tls-verifier-boundary-v0.md` further pins that `tls` / `quic` reachability does **not** widen CH-NETREQ / CH-NETLEASE into a portable trust-root / hostname-verifier / certificate-exception seam or a current certificate-verdict receipt; transport verifier policy remains portal-local or app-local unless a future explicit surface pays for it.
   - Companion `network-lease-client-cert-boundary-v0.md` further pins that `tls` / `quic` reachability does **not** widen CH-NETREQ / CH-NETLEASE into a portable client-certificate / mTLS identity seam or certificate-bound-token receipt; transport client-auth policy remains portal-local or app-local unless a future explicit surface pays for it.
   - Companion `network-lease-application-protocol-boundary-v0.md` further pins that `tls` / `quic` reachability does **not** widen CH-NETREQ / CH-NETLEASE into a portable ALPN / application-protocol negotiation seam; higher-layer protocol choice remains portal-local or app-local unless a future explicit surface pays for it.
   - Companion `network-lease-server-name-boundary-v0.md` further pins that `tls` / `quic` reachability does **not** widen CH-NETREQ / CH-NETLEASE into a portable SNI / server-name / ECH server-name presentation seam; TLS name presentation remains portal-local or app-local unless a future explicit surface pays for it.
   - Companion `network-lease-session-resumption-boundary-v0.md` further pins that `tls` / `quic` reachability does **not** widen CH-NETREQ / CH-NETLEASE into a portable session-resumption / PSK / 0-RTT transport-resumption seam; ticket caches, resumed-session state, and early-data policy remain portal-local or app-local unless a future explicit surface pays for it.
   - Companion `network-lease-transport-profile-boundary-v0.md` further pins that `tls` / `quic` reachability does **not** widen CH-NETREQ / CH-NETLEASE into a portable version / cipher / group / transport-parameter transport-profile seam; handshake profile and transport tuning remain portal-local or app-local unless a future explicit surface pays for it.

5) **Externally visible requests are transcripted and commutativity-scoped**
   - `portal.net.request` is an externally visible action:
     - Conflict key family: `domain.id` (so requests in disjoint domains commute).
     - Ordering: **ordered within a domain** (grants are stateful) and requires CH-ORDERTOK v0.
     - Serialization boundary is explicit (`svc:portal.net`) in `serialization-boundary-registry.md`.
   - Dedupe: when the ACP kind claims at-least-once-safe, portals SHOULD dedupe by CH-NETREQ `req_id` and make duplicate suppression transcript-visible (D-RETRYSAFE).
   - CH-NETREQ `req_id` is a requester-chosen stable request key for dedupe and review, not a portal-issued CH-NETLEASE handle or current lease-state proof.
   - Same scoped `CH-NETREQ.req_id` only replays the same canonical CH-NETREQ request; changed bytes under one key MUST reject before effect rather than acting like mutable upsert/replace semantics (`network-request-idempotency-boundary-v0.md`).

6) **Sealed compat constraints (keep “interop” killable and non-ambient)**
   - Any bridge from leased networking to a legacy interface (e.g., “compat sockets”) MUST be:
     - policy-killable by `cfg.params.lane.portal.net` (fail closed), and
     - incapable of creating ambient channels (no implicit proxy env, no implicit DNS, no inherited interface/VRF/source-address pinning, no implicit “system network”).
   - v0 stance: do **not** standardize such bridges in Phase 1; keep them behind an RFC/ADR.

## Phase 1 non-goals (explicitly deferred)

- **Inbound-by-default networking**: inbound listeners are possible only via explicit leases; “ambient listening” is out of scope.
- **Generic DNS RR-query semantics**: `kind=dns` stays address-resolution-only; Phase 1 adds no RR-type/class query surface, raw DNS reply export, resolver-transport selector, or DNSSEC/EDNS policy seam on D-NETLEASE (`network-lease-dns-query-boundary-v0.md`).
- **Host search-path / local-name-resolution semantics**: exact reviewed name predicates stay exact; Phase 1 adds no portable search domains, `/etc/hosts` / NSS host-order policy, split-DNS view, mDNS `.local`, or LLMNR seam on D-NETLEASE (`network-lease-name-context-boundary-v0.md`).
- **Unicode / IDNA / normalization semantics**: exact reviewed name predicates stay one canonical ASCII predicate; Phase 1 adds no portable Unicode U-label input, UTS #46 / browser-host canonicalization, locale casefolding, or trailing-dot cleanup seam on D-NETLEASE (`network-lease-name-normalization-boundary-v0.md`).
- **Default-port / service-name semantics**: connect/listen host-or-IP predicates stay explicitly port-shaped; Phase 1 adds no portable URI-scheme default-port, `/etc/services`, or service-name lookup seam on D-NETLEASE (`network-lease-port-inference-boundary-v0.md`).
- **Service-binding / alternate-endpoint semantics**: exact reviewed name predicates stay host-address-oriented only; Phase 1 adds no portable SRV / SVCB / HTTPS service-binding, alternate-endpoint, or endpoint-parameter seam on D-NETLEASE (`network-lease-service-binding-boundary-v0.md`).
- **IPv4 / IPv6 preference / Happy-Eyeballs semantics**: exact reviewed name predicates stay destination-predicate-only; Phase 1 adds no portable address-family preference, RFC 6724 destination ordering, or Happy-Eyeballs racing seam on D-NETLEASE (`network-lease-address-selection-boundary-v0.md`).
- **Bind-by-hostname / publication semantics**: `kind=listen` names local bind/exposure subjects only; Phase 1 adds no hostname bind, DNS publication, mDNS advertisement, NAT/public-endpoint allocation, or loopback-callback capture seam on D-NETLEASE (`network-request-listen-subject-boundary-v0.md`).
- **Per-packet filtering / firewall rule language**: any rule UI is a portal policy implementation detail.
- **Legacy transparency**: no “drop-in POSIX sockets” promise.
- **Cross-host capability networking (CeNet-style)**: useful inspiration for future distributed authority models, but not required for v0. (REF-CENET)

## Wiring

- Schemas:
  - `network-request-schema-v0.md` (CH-NETREQ v0)
  - `network-lease-schema-v0.md` (CH-NETLEASE v0)
- Decision surface: `decision-map.md` (D-NETLEASE)
- Portal family: `portal-family-registry.md` (`portal.net`)
- ACP surfaces:
  - `docs/70-llm-control/acp-action-kind-registry.md` (`portal.net.request`)
  - `docs/70-llm-control/acp-validator-semantics.md` (PO-ACP-NET-REQUEST)

CI drift gate:
- `tools/check_netlease_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “no ambient sockets/DNS” constraints, or drops minimal REF wiring.
- Adjacent launch posture: `capshell-network-posture-v0.md` keeps `capshell.exec` from reintroducing ambient sockets/DNS as a runner baseline when D-CAPSHELL is enabled.
- Adjacent boundary: under `ext.microvm`, reusable warm-start templates are cut before issued CH-NETLEASE/network-authority handles enter guest memory, and any post-restore networking authority is reacquired explicitly rather than inherited from copied snapshot state (`microvm-template-snapshot-cut-posture-v0.md`).

## References

- Capability-based sandboxing precedents: REF-CAPSICUM, REF-CLOUDABI.
- Desktop precedents for per-app connection mediation/visibility: REF-LITTLESNITCH, REF-MACOS-NETWORKEXT.
- Least-privilege networking research: REF-CENET.
