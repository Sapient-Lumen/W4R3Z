# D-LLM / D-POLICY / IF-ACP credential trust-registry import boundary v0 (trust registries are not portable issuer / verifier / wallet / policy / approval truth)

Purpose: pin one compact Phase-1 rule on the existing **D-LLM / D-POLICY / IF-ACP** seams: imported wallet/credential trust-registry semantics — trusted-authority lists, issuer/verifier/wallet directories, trust documents, federation-wallet role metadata, accreditation-style registry entries, registry-query results, and similar ecosystem trust-establishment hints — are **provider-local ecosystem trust-establishment hints only**. They do **not** create a portable issuer registry, verifier/wallet chooser, trust-root plane, policy selector, approval-basis object, ecosystem-membership oracle, or durable current-user truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported credential-ecosystem trust material may be interpreted next to already-pinned wallet-presentation, credential-issuance, credential-status, DID-document, federation, identity-assurance, and approval/account cuts.

This is a **closed verifiable-credential ecosystem companion family** member: see `verifiable-credential-ecosystem-boundary-index.md`.

## Posture (v0)

1) **Imported trust-registry listings stay provider-local candidate lists only.**
   - OpenID Federation for Wallet Architectures and DIF Trust Establishment both make ecosystem trust metadata more explicit and more reusable.
   - Imported trusted-authority lists, issuer/verifier/wallet directories, accreditation records, trust marks, federation-wallet role metadata, and registry-query results remain provider-local candidate lists only; they do **not** become a portable issuer/verifier/wallet registry, durable connected-entity truth, or global ecosystem-membership oracle on existing SlopOS seams.
   - Existing local policy, verification, approval, and evidence seams stay authoritative instead of inheriting durable truth from one registry operator's published view.

2) **Imported trust documents stay provider-local trust-establishment hints only.**
   - DIF Trust Establishment is explicit that trust-establishment data is a building block, not a complete interoperable truth plane by itself.
   - Imported trust documents, trust frameworks, trust-chain hints, eligibility statements, accreditation metadata, verifier/issuer/wallet role assertions, and resolver/discovery results remain provider-local trust-establishment hints only; they do **not** become a portable trust root, signer inventory, approval-basis object, policy selector, or current-permission oracle on existing SlopOS seams.
   - Existing federation, verifier policy, attestation, account-binding, and approval seams stay authoritative instead of inheriting global truth from third-party registry material.

3) **Imported wallet-federation metadata stays provider-local ecosystem coordination only.**
   - OpenID Federation for Wallet Architectures defines wallet ecosystem roles, metadata exchange, and policy application, which makes it especially tempting to over-read one ecosystem’s trust metadata as native OS trust.
   - Imported wallet-provider metadata, entity-role metadata, trusted-authority query results, policy hints, and secure metadata exchange artifacts remain provider-local ecosystem coordination only; they do **not** become a portable wallet chooser, issuer-policy selector, verifier-policy selector, approval surface, or durable account/user truth on existing SlopOS seams.
   - Existing local capability, policy-handle, verifier-choice, network/document, and identity seams stay authoritative instead of inheriting ambient trust from registry-mediated ecosystem metadata.

4) **No silent issuer/verifier/wallet-registry widening rides in through trust registries.**
   - Imported trust registries, trusted-authority lists, issuer/verifier/wallet directories, trust documents, wallet-federation role metadata, and registry-query results do **not** authorize portable “this issuer/verifier/wallet is currently trusted everywhere” truth by implication.
   - A verifier or wallet may use registry material plus local policy to narrow one provider-local trust decision, but that does **not** standardize a portable issuer registry, verifier registry, wallet-provider chooser, trust-root plane, policy selector, or durable ecosystem-membership truth on D-LLM, D-POLICY, IF-ACP, or adjacent identity/account/verification surfaces.
   - If SlopOS ever needs native trust registries, wallet-provider selection, accreditation stores, or durable credential-ecosystem evidence, that work must arrive as an RFC on explicit schemas, validators, conflict keys, evidence hooks, cache/freshness rules, and kill switches rather than inheriting folklore from imported registry semantics.

5) **Sealed compat remains honest.**
   - Any compat/runtime use of trust registries, trusted-authority queries, wallet-federation metadata, or trust-establishment documents must be killable by policy and must not create authority via hidden paths, env vars, implicit network access, silently persistent registry caches, or ambient policy/config files.
   - A compat layer that cannot proceed without hidden registry fetches, implicit trust-root reuse, or ambient ecosystem metadata must fail closed for portable SlopOS authority semantics.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: IF-ACP validation, exact action bytes, explicit capabilities/approvals, explicit D-POLICY handles/bundles, explicit verifier-owner policy choice, and explicit network/document/resource grants.
   - Any future native trust-registry import, cache, accreditation, or ecosystem-membership workflow must state its own conflict keys, commutativity conditions, serialization point, cache/freshness semantics, and evidence story explicitly rather than inheriting them from imported registry documents.

## Phase 1 non-goals (explicitly deferred)

- No portable issuer/verifier/wallet registry imported directly from registry listings or trusted-authority queries.
- No portable rule that trust documents, accreditations, or role metadata stand in for CH-ACP, CH-POLICYHANDLE, approval basis, verifier policy, or current-permission truth.
- No portable wallet chooser, issuer chooser, verifier chooser, or ecosystem-membership substrate imported from registry material.
- No portable rule that registry fetch/discovery/version metadata stands in for attestation, freshness, audit, or durable evidence truth.

## Why this is worth pinning

Once wallet presentation, credential issuance, credential validity, and DID resolution are already pinned as provider-local only, the next tempting shortcut is “fine, trust the registry.” In practice that means over-reading trusted-authority lists, ecosystem registries, accreditation documents, and wallet-federation metadata as if they were a portable issuer/verifier/wallet registry, a global trust root, a policy selector, or an approval substrate.

The ecosystem is converging here. OpenID Federation for Wallet Architectures makes wallet-ecosystem trust and policy coordination more explicit, while DIF Trust Establishment makes reusable trust-establishment data easier to transport across participants. That is exactly why the archive should pin the meaning early: imported registry material is a compatibility input, not native SlopOS trust.

Pinning the boundary now keeps the archive honest. Imported trust registries may remain a provider-local way to narrow one trust decision, but they do not become a portable issuer registry, verifier registry, wallet-provider chooser, trust-root plane, approval surface, or durable current-user truth inside SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation agents may consume issuer/verifier/wallet trust lists, but those lists do not become a local trust-root or approval substrate.
- **Cloud micro-VM / hosted compute substrate (B):** hosted verifiers may consult ecosystem registries, but registry results do not become a portable control-plane trust oracle.
- **Embedded / separation-kernel-ish appliance (C):** appliances may ingest curated trust documents, but imported lists do not widen into ambient policy or durable account truth.
- **Agent / automation OS (D):** agents may see rich registry material, but it remains provider-local input rather than a native “trusted issuer/verifier/wallet” fact plane.

## Wiring

- Discovery family: `verifiable-credential-ecosystem-boundary-index.md`
- Decision recovery: `decision-map.md`
- Evidence hook: `EVID-2026-706`
- Drift gate: `tools/check_credential_trust_registry_import_boundary.py`

## References

- `REF-OPENID-4VP-1-0`
- `REF-OPENID-FEDERATION-WALLET-1-0-DRAFT`
- `REF-DIF-TRUST-ESTABLISHMENT-1-0X`

