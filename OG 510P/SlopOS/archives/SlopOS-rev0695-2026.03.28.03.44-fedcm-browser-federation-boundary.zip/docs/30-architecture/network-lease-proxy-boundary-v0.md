# D-NETLEASE proxy boundary v0 (no portable proxy-selection / PAC / WPAD / system-proxy seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: leased networking does **not** become a portable proxy-selection, PAC-script, WPAD-autodiscovery, or generic “use system proxy” surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable proxy-selection / PAC / system-proxy seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **destination predicate** plus the granted **resolver binding**.
   - They do **not** grow a portable `proxy_uri`, `proxy_list`, `proxy_mode`, `proxy_bypass`, `proxy_scope`, `pac_url`, `pac_digest`, `pac_result`, `wpad_enabled`, `wpad_status`, `use_system_proxy`, `http_proxy`, `https_proxy`, `all_proxy`, `no_proxy`, or equivalent export surface.
   - Phase 1 portable truth is therefore: **what destination predicate was reviewed/granted, and which resolver strategy bound that lease** — not what proxy-selection engine or host policy happened to route one request.

2) **Proxy choice is portal-local transport policy, not descriptor truth.**
   - A portal/provider may route some connections directly and others through local explicit proxy infrastructure according to owner-local policy.
   - That does **not** make proxy selection part of CH-NETLEASE meaning, and historical lease/request/receipt artifacts do **not** by themselves prove which proxy path would be chosen now.
   - Repeated uses of the same lease may therefore traverse different direct/proxied paths over time while still remaining inside the same granted predicate and resolver policy.

3) **No ambient `$http_proxy` / PAC / WPAD / “system proxy” fallback.**
   - Reviewed networking in Phase 1 must not silently inherit process environment proxy variables, PAC URLs/scripts, WPAD discovery, desktop/session proxy settings, or a generic “use the machine proxy” baseline.
   - That rule applies both to direct `portal.net` implementations and to wrappers/compat paths around them: env bytes, host settings, and autodiscovery results are not by themselves reviewed network authority.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient network-routing channels through env, PAC JavaScript, DNS-based WPAD, or host-session settings.

4) **If explicit proxy brokerage ever matters, pay for a new seam explicitly.**
   - A future product shape may want reviewed proxy brokerage, explicit PAC evaluation artifacts, or a bounded enterprise-egress policy surface.
   - That work must return **RFC-first** with its own schema/receipt family, redaction story, commutativity/conflict-key contract, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal/settings surfaces just because real ecosystems expose proxy APIs, PAC engines, or system proxy profiles internally.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit proxy-brokerage seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from PAC engines, WPAD helpers, or browser/system proxy stacks.

6) **Current proxy path is live service state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove which PAC result was in force, whether WPAD was enabled or reachable, which bypass rule matched, which proxy was selected, or whether a future connection would go direct.
   - As elsewhere in SlopOS, stable request/receipt artifacts are evidence of one reviewed action, not a portable oracle for mutable owner-local routing state.

## Phase 1 non-goals (explicitly deferred)

- No portable `proxy_uri`, `proxy_list`, `pac_url`, `pac_digest`, `wpad_status`, `use_system_proxy`, or `no_proxy` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a desktop/session proxy-profile broker.
- No hidden env / PAC / WPAD / “use system proxy” compatibility promise around `portal.net.request`.
- No transcript-stable claim that an accepted network request or issued lease also proves a current proxy path.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS. The next convenience drift is narrower but very real: once explicit network requests exist, tools and compat layers will try to sneak route policy back in through `$http_proxy`, PAC scripts, WPAD, or “just use system proxy” defaults.

That would quietly widen a compact authority seam into a second ambient policy/discovery plane. It would also make product behavior depend on session settings, PAC JavaScript, network-local WPAD answers, or process environment that is hard to review and easy for LLM-authored automation to forget. Pinning the boundary now keeps all four product shapes honest: workstations can still have rich enterprise egress under owner-local portal policy, cloud/microVM deployments avoid pretending that host proxy policy is transcript-stable guest truth, embedded builds need not standardize a PAC/WPAD stack, and agent/automation flows cannot treat env or desktop settings as reviewed network authority.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still obey local enterprise egress policy, but that does not standardize PAC/WPAD/system-proxy behavior as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound authority explicit without inheriting the host’s ambient proxy env or PAC/WPAD policy as guest/runtime truth.
- **Embedded / separation appliance (C):** appliance builds can allow tightly bounded egress without paying for a portable PAC/WPAD/system-proxy stack they do not want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse environment/session proxy hints with reviewed network-routing authority; any explicit proxy brokerage must land on a future dedicated seam.

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-resolution-boundary-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-NETLEASE-DNSBIND**, **PO-CAPSHELL-NET-EXPLICIT**)

CI drift gate:
- `tools/check_network_lease_proxy_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable proxy-selection / PAC / WPAD / system-proxy seam / no ambient env-or-settings fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-631**).

## References

- REF-LIBPROXY.
- REF-CHROMIUM-PROXY.
- REF-CHROMIUM-WPAD.
- REF-XDG-PORTAL-SETTINGS.
- REF-LIBCURL-ENV.
