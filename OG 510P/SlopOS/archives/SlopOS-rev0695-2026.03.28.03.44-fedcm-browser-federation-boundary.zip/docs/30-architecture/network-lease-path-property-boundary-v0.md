# D-NETLEASE path-property boundary v0 (no portable metered / validated / captive / expensive / constrained seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed leased networking does **not** become a portable metered / validated / captive / expensive / constrained path-property or connectivity-state surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable path-property / connectivity-state seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **destination predicate**, the granted **resolver binding**, and the transport class.
   - They do **not** grow a portable `available`, `connectivity`, `metered`, `validated`, `captive_portal`, `expensive`, `constrained`, `roaming`, `network_cost`, `bytes_remaining`, `seconds_remaining`, or equivalent path-property / connectivity-state export surface.
   - Phase 1 portable truth is therefore: **what reachability predicate was reviewed/granted, through which resolver binding, over which transport class** — not whether the current host path happened to be metered, validated, captive, expensive, constrained, or otherwise policy-tagged right now.

2) **Path-property evaluation stays portal-local or app-local.**
   - A lease may authorize reachability to a reviewed predicate.
   - That does **not** standardize which current path state, captive-portal verdict, meteredness flag, cost/constraint hint, or internet-validation signal a provider/runtime uses when deciding retries, user prompts, or scheduling.
   - Different product profiles or owner-local runtimes may therefore expose different path-state APIs locally — or change them as attachment state changes — while still staying inside the same reviewed D-NETLEASE grant.

3) **No ambient inherited network-monitor fallback.**
   - Reviewed networking in Phase 1 must not silently inherit host-global reachability monitors, browser “online/offline” state, network-monitor daemons, captive-portal helpers, meteredness heuristics, or platform path-status callbacks as substrate meaning.
   - That rule applies both to direct `portal.net` implementations and to wrappers/compat paths around them: host path-status residue is not by itself reviewed network authority.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient channels through hidden network-monitor, captive-portal, or cost/constraint state APIs.

4) **If portable path-state matters, pay for a new seam explicitly.**
   - A future product shape may want reviewed network-monitor semantics, captive-portal workflows, cost-aware scheduling hints, or explicit path-quality/state receipts.
   - That work must return **RFC-first** with its own schema/receipt family, freshness story, redaction rules, commutativity/conflict-key contract, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems expose metered/validated/captive or expensive/constrained state APIs.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit connectivity-state/path-quality seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from platform network monitors or captive-portal helpers.

6) **Current path-property result is live attachment state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove whether a connection path was validated, captive, metered, expensive, constrained, or cost-limited at request time, whether that state still holds now, or whether the same hint values would be observed on retry.
   - As elsewhere in SlopOS, stable request/receipt artifacts are evidence of one reviewed action, not a portable oracle for mutable owner-local connectivity state.

## Phase 1 non-goals (explicitly deferred)

- No portable `available`, `connectivity`, `metered`, `validated`, `captive_portal`, `expensive`, `constrained`, `roaming`, or `network_cost` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a system network monitor, captive-portal broker, or cost/constraint advisory plane.
- No transcript-stable claim that an accepted network request or issued lease also proves current path status, internet validation, or captive/session remaining-state truth.
- No hidden `NetworkCapabilities`, `NWPath`, `GNetworkMonitor`, or captive-portal helper compatibility promise around `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS, and the recent passes kept answer/path telemetry, local-egress policy, proxy policy, transport verifier policy, and client-auth identity out of CH-NETREQ / CH-NETLEASE portable meaning. The next quiet drift is to pretend the same lease also says **what the host currently thinks about the path**. Real systems do expose meteredness, captive state, validation, and cost/constraint hints, but they treat those as explicit dynamic OS or protocol surfaces — not harmless residue of “a network request was reviewed.”

If we leave that blurry, workstation and agent flows will start depending on whichever reachability monitor, captive-portal detector, or cost heuristic the host happened to expose, while cloud and embedded profiles will be forced to fake portability for path-state semantics they do not actually share. Pinning the boundary now keeps D-NETLEASE honest: reviewed reachability is one seam, reviewed path-state/quality would be another future seam if we ever truly need it.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich network monitors and cost/captive hints locally, but that does not standardize those host hints as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound reachability explicit without pretending host-side validation, metering, or captive/session state is transcript-stable guest/runtime truth.
- **Embedded / separation appliance (C):** appliance builds can keep a narrow reachability seam without paying for a portable general-purpose connectivity-state plane they do not want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “lease to this destination” with “portable statement that the path is validated / unmetered / not captive right now,” which reduces hidden dependence on host networking folklore.

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-local-egress-boundary-v0.md`
  - `docs/30-architecture/network-lease-proxy-boundary-v0.md`
  - `docs/30-architecture/network-lease-tls-verifier-boundary-v0.md`
  - `docs/30-architecture/network-lease-client-cert-boundary-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-NETLEASE-DNSBIND**, **PO-CAPSHELL-NET-EXPLICIT**)

CI drift gate:
- `tools/check_network_lease_path_property_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable metered / validated / captive / expensive / constrained seam / no ambient inherited network-monitor fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-636**).

## References

- REF-ANDROID-NETWORKCAPABILITIES.
- REF-APPLE-NWPATH.
- REF-XDG-PORTAL-NETWORKMONITOR.
- REF-RFC8908-CAPPORT-API.
