# D-NETLEASE transport-resumption boundary v0 (no portable session-resumption / PSK / 0-RTT seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed leased networking over `tls` / `quic` does **not** become a portable transport-resumption surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable transport-resumption seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **destination predicate**, the granted **resolver binding**, and the transport class.
   - They do **not** grow a portable `session_ticket`, `session_ticket_ref`, `psk_identity`, `resumption_secret_ref`, `allow_0rtt`, `early_data_profile`, `resumed_session`, `resume_token`, `new_token`, or equivalent transport-resumption/export surface.
   - Phase 1 portable truth is therefore: **what reachability predicate was reviewed/granted, through which resolver binding, over which transport class** — not whether a later connection reused PSK/ticket state, attempted 0-RTT, or was accepted as a resumed transport session.

2) **Session continuity stays portal-local or app-local.**
   - A lease may authorize reachability over `tls` or `quic`.
   - That does **not** standardize whether an implementation stores TLS session tickets, carries PSK resumable state forward, reuses QUIC `NEW_TOKEN` / session metadata, or permits/rejects 0-RTT for a concrete connection.
   - Different product profiles or owner-local runtimes may therefore expose different resumption defaults locally — or none at all — while still staying inside the same reviewed D-NETLEASE grant.

3) **No hidden ticket / PSK / 0-RTT folklore.**
   - Reviewed networking in Phase 1 must not silently inherit browser, SDK, proxy, or library defaults for TLS ticket caches, PSK resumption, QUIC session continuity, or 0-RTT retry behavior as substrate meaning.
   - That rule applies both to direct `portal.net` implementations and to wrappers/compat paths around them: hidden resumption caches and 0-RTT enablement are not by themselves reviewed network authority.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient channels through hidden cross-connection correlation, replay-prone early-data defaults, or ticket-cache stickiness.

4) **If portable transport-resumption semantics matter, pay for a new seam explicitly.**
   - A future product shape may want reviewed ticket-cache policy, transcript-visible 0-RTT eligibility, or explicit resumption receipts.
   - That work must return **RFC-first** with its own schema/receipt family, conflict keys, commutativity story, freshness rules, privacy posture, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems use session resumption and sometimes 0-RTT.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit resumption / 0-RTT seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from browser ticket caches, QUIC retry machinery, or library defaults.

6) **Current resumption / 0-RTT choice is connection-local live state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove whether a given connection resumed a TLS/QUIC session, whether 0-RTT was attempted or accepted, or whether the same implementation would do so on retry.
   - As elsewhere in SlopOS, stable request/receipt artifacts are evidence of one reviewed action, not a portable oracle for mutable connection-local transport-resumption behavior.

## Phase 1 non-goals (explicitly deferred)

- No portable `session_ticket`, `psk_identity`, `resumption_secret_ref`, `allow_0rtt`, `early_data_profile`, `resumed_session`, `resume_token`, or `new_token` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a transport ticket-cache broker, PSK reuse plane, or 0-RTT policy plane.
- No transcript-stable claim that an accepted network request or issued lease also proves a selected resumption path or accepted early-data result.
- No hidden browser/SDK/library compatibility promise that `tls` / `quic` reachability implies one reviewed session-resumption / 0-RTT behavior on `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS, and the recent passes kept resolver answers, local-egress policy, path-state folklore, proxy policy, transport verifier policy, client-auth identity, application-protocol negotiation, and TLS server-name presentation out of CH-NETREQ / CH-NETLEASE portable meaning. The next quiet drift is to pretend the same lease also says **how transport continuity works across connections**. Real systems treat session tickets, PSK reuse, and 0-RTT as explicit transport machinery with replay, privacy, and cross-connection state consequences, not as harmless residue of “a network request was reviewed.”

If we leave that blurry, workstation and agent flows will start depending on whichever ticket-cache, resumed-session, or 0-RTT defaults the local browser/runtime happened to ship, while cloud and embedded profiles will be forced to fake portability for cross-connection behavior they do not actually share. Pinning the boundary now keeps D-NETLEASE honest: reviewed reachability is one seam, reviewed transport resumption would be another future seam if we ever truly need it.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich TLS/QUIC stacks with ticket caches and selective 0-RTT locally, but that does not standardize those defaults as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound reachability explicit without pretending guest/runtime resumption caches or 0-RTT policy are transcript-stable reviewed truth.
- **Embedded / separation appliance (C):** appliance builds can keep a narrow leased-network seam without paying for a portable general-purpose ticket-cache / early-data policy plane they do not want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “lease to this destination over TLS/QUIC” with “portable statement that session tickets, PSKs, or 0-RTT were reviewed, selected, or guaranteed.”

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-application-protocol-boundary-v0.md`
  - `docs/30-architecture/network-lease-server-name-boundary-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-CAPSHELL-NET-EXPLICIT**)

CI drift gate:
- `tools/check_network_lease_session_resumption_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable session-resumption / PSK / 0-RTT seam / no hidden ticket folklore / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-639**).

## References

- REF-RFC8446-TLS13.
- REF-RFC9001-QUIC-TLS.
- REF-RFC9325-TLS-BCP.
- REF-RFC9308-QUIC-APPLICABILITY.
