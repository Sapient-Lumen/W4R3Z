# D-LLM MCP-completion import boundary v0 (argument suggestions are not selector/default/workflow truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam: current MCP completion (`completion/complete`, `completions` capability, prompt/resource references, argument-prefix matching, optional prior-argument context, and bounded completion results) is **provider-local suggestion mechanics only**. It does **not** create a portable selector/default plane, chooser receipt, workflow/policy shortcut, file/document/workspace grant, or current-state oracle on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP completion semantics may be interpreted next to already-pinned prompt/resource, document/import, and LLM-control cuts.

This doc is an **intentional singleton** today. It is listed in `boundary-family-map.md` until a broader reviewed imported-completion family exists.

## Posture (v0)

1) **No portable selector/default/workflow substrate in imported MCP completion.**
   - `completions` capability, `completion/complete`, `ref/prompt`, `ref/resource`, `argument.name`, `argument.value`, optional `context.arguments`, and any returned `completion.values` remain **provider-local suggestion mechanics** on **D-LLM**.
   - They may help a host expose dropdown/popup-style argument suggestions while a user or agent fills in one provider-owned prompt or resource-template invocation.
   - They do **not** by themselves register a reviewed command, choose a durable default, bind workflow/policy state, mint a chooser receipt, widen an action schema, or create a new local selector/automation substrate on existing SlopOS seams.

2) **Completion references and argument context are advisory selectors only, not portable handles or hidden grants.**
   - `ref/prompt` names, `ref/resource` URI-template references, `argument.name`, partial `argument.value`, and optional `context.arguments` may help one provider rank likely strings for one template slot.
   - They do **not** become file/document handles, workspace grants, hidden payer/account selectors, approval-basis fields, validator-only hidden parameters, or import-to-docref shortcuts.
   - A suggested resource-template argument therefore does not stand in for reviewed filesystem/document authority, and a suggested prompt argument does not stand in for remembered local policy or hidden account binding truth.

3) **Completion results are bounded suggestions only, not chooser receipts or current-state truth.**
   - Returned `completion.values` plus optional `total` and `hasMore` may help a host present a bounded list of strings for one in-progress argument edit.
   - They do **not** become durable selector receipts, current inventory truth, resource existence proofs, approved defaults, completion-history truth, or evidence that a later prompt/resource invocation used the same values.
   - A host choosing to prefill or display one suggestion is therefore local UX only, not proof that the provider's suggested value became reviewed SlopOS state.

4) **Completion UX remains host-owned and non-authoritative.**
   - MCP frames completion as optional IDE-like UX and does not require one exact interaction pattern.
   - Hosts may show suggestions in menus, inline chips, or ignore completion entirely.
   - That host-owned presentation choice does **not** let providers smuggle in a hidden chooser-control plane, silent auto-select/auto-run semantics, or remembered local-default store.

5) **Progress and pagination hints stay advisory only.**
   - Optional request `_meta.progressToken` and any provider-local out-of-band progress around completion requests may help a host keep a responsive UI while suggestions are computed.
   - They do **not** become durable progress/watch truth, queue/completion receipts, or proof that suggestion generation finished with a stable provider-owned set.
   - Likewise, `total` and `hasMore` describe one provider-owned suggestion response only; they do not create a portable browse/list/watch substrate for prompt/resource arguments.

6) **No follow-on authority folklore from accepting a suggestion.**
   - Accepting or inserting a suggested value does **not** itself authorize prompt execution, resource reads, tool execution, browser/session control, document import, or any other effectful follow-on behavior.
   - If a host later acts on a completed argument value, that later effect still crosses an explicit reviewed seam with its own schema, validators, policy, receipts, conflict keys, and evidence hooks.
   - This keeps Hybrid + commutativity honest: imported completion suggestions may shape proposals and forms, but they do not smuggle hidden action semantics or serialization rules into existing externally visible operations.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: exact reviewed actions, explicit workflow/portal seams, explicit receipts, and explicit evidence artifacts.
   - Any future reviewed portable completion/selector family must state its own conflict keys, commutativity conditions, serialization point, suggestion provenance semantics, and evidence story explicitly rather than inheriting folklore from MCP completion helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `argument_completion`, `selector_handle`, `default_value_store`, `completion_history`, `completion_receipt`, or `completion_watch` substrate imported directly from MCP completion.
- No rule that prompt/resource-template argument suggestions can stand in for reviewed local defaults, chooser results, workflow selection, file/document grants, or current inventory truth.
- No adapter shortcut that quietly turns suggestion acceptance into automatic prompt execution, resource reads, browser/session control, import/materialization, or validator-only hidden fields.
- No rule that returned `completion.values`, `total`, or `hasMore` become durable provider-state evidence, approval basis, or portable browse/list semantics.

## Why this is worth pinning

The archive already says imported prompts are not workflow/policy truth, imported resources are not file/document/watch truth, and imported sampling/task/progress signals do not become local authority or current-state truth by accident. MCP completion is the next small but real pressure surface: a server can expose argument suggestions for prompts and resource templates, use already-filled arguments as context, and return bounded candidate sets that look suspiciously like approved defaults or chooser outcomes.

That is useful, but it is also exactly where hosts and agent wrappers start to slide from “provider-local string suggestions” into “remote selector someone else already validated for me.” Once that drift lands, completion values start to masquerade as remembered defaults, hidden selectors, resource existence proofs, or workflow shortcuts.

Pinning the boundary now keeps the archive honest. Imported MCP completion may remain a local UX convenience for prompt/resource-template argument entry, but it does not get to redefine what reviewed defaults, chooser results, workflow selection, file/document authority, or evidence truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may show provider-suggested prompt/resource arguments without silently importing a second chooser/default/workflow plane.
- **Cloud micro-VM substrate (B):** hosted agents avoid mistaking provider-owned suggestion sets for tenant-stable selectors, file/document authority, or current inventory truth.
- **Embedded / separation appliance (C):** appliance builds can omit completion UX entirely or translate it to local hints without promising a portable selector/default substrate.
- **Agent/automation OS (D):** agents may inspect or reuse provider-local suggestions, but reviewed selection, approval, and document/import truth still lives on explicit SlopOS seams rather than drifting into completion folklore.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam; the current cut is only the narrow MCP-completion import boundary.

If a second closely related imported-completion boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/mcp-prompt-import-boundary-v0.md`
- `docs/30-architecture/mcp-resource-import-boundary-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_completion_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “argument suggestions are not selector/default/workflow truth” posture drifts (**EVID-2026-669**).

## References

- `REF-MCP-COMPLETION`
- `REF-MCP-SPEC`
