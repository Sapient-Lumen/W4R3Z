# D-LLM MCP-ID-JAG import boundary v0 (enterprise identity assertions are not portable SSO proof / subject-token / account truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP Enterprise-Managed Authorization guidance around saving an Identity Assertion (OpenID ID Token or SAML assertion), using it or a Refresh Token as `subject_token` in token exchange to obtain an Identity Assertion JWT Authorization Grant (ID-JAG), exchanging that typed ID-JAG for an access token, and carrying claims such as `sub`, `email`, `aud_sub`, `scope`, `resource`, `auth_time`, `amr`, or `authorization_details` is **provider-local cross-domain authorization bootstrap only**. It does **not** create a portable SSO-proof plane, subject-token store, cross-domain account-binding substrate, identity/profile export surface, approval-basis seam, or durable login-state truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported enterprise identity-assertion / ID-JAG semantics may be interpreted next to already-pinned enterprise-managed-auth, account-binding, identity-claim, login-state, auth-proof, auth-result, and authorization-context boundaries.

## Posture (v0)

1) **Saved Identity Assertions stay provider-local SSO artifacts only.**
   - Current MCP enterprise-managed auth says the client should authenticate to the enterprise IdP and save the resulting Identity Assertion, either an OpenID ID Token or a SAML assertion, for later use.
   - That saved assertion remains provider-local SSO artifact state only; it does **not** create a portable login-proof cache, identity-assertion wallet, signed-in oracle, or requester-visible account/profile export seam on existing SlopOS surfaces.
   - Existing identity-claim, login-state, and auth-proof boundaries stay authoritative instead of inheriting hidden meaning from one provider's saved SSO artifact.

2) **`subject_token` exchange stays provider-local cross-domain bootstrap only.**
   - Current MCP enterprise-managed auth says the client requests an ID-JAG from the enterprise IdP using the previously obtained Identity Assertion. The current ID-JAG draft further profiles this as OAuth token exchange using a `subject_token`, and allows a Refresh Token as `subject_token` when the IdP supports that path.
   - Those `subject_token` mechanics remain provider-local cross-domain bootstrap only; they do **not** create a portable subject-token store, token-exchange broker, pending-auth relay, or reusable cross-domain login bridge on existing SlopOS seams.
   - Existing auth-continuation, browser-session, and auth-result boundaries stay authoritative instead of inheriting continuation or relay meaning from one provider's token-exchange helper.

3) **ID-JAGs stay provider-local grant assertions only.**
   - The current ID-JAG draft defines the Identity Assertion JWT Authorization Grant as a profile of the JWT Authorization Grant, uses the typed JWT media value `oauth-id-jag+jwt`, and requires the Resource Authorization Server to validate audience and client binding before issuing an access token.
   - That ID-JAG remains provider-local grant assertion state only; it does **not** create a portable enterprise login proof, cross-domain account-binding receipt, approval-basis artifact, or generic bearer-to-bearer brokerage seam on existing SlopOS surfaces.
   - Existing auth-proof, auth-result, authorization-context, and account-binding boundaries stay authoritative instead of inheriting platform meaning from one provider's grant assertion.

4) **Identity-assertion and ID-JAG claims stay provider-local authorization inputs only.**
   - Current enterprise-managed auth and the current ID-JAG draft let provider flows carry claims such as `sub`, `email`, `aud_sub`, `scope`, `resource`, `auth_time`, `amr`, and `authorization_details` so one IdP and one Resource Authorization Server can identify the employee and evaluate access.
   - Those claims remain provider-local authorization inputs only; they do **not** become portable identity/profile export, active-tenant truth, connected-account truth, entitlement export, or approval-basis semantics on existing SlopOS seams.
   - Existing identity-claim, account-binding, authorization-context, and login-state boundaries stay authoritative instead of inheriting hidden substrate meaning from claim carriage inside enterprise auth assertions.

5) **Refresh-driven ID-JAG renewal stays live provider policy only.**
   - The current ID-JAG draft allows an IdP to accept a Refresh Token as `subject_token` so a client can obtain a new ID-JAG without sending the user through a fresh SSO round trip.
   - That renewal path remains live provider policy only; it does **not** create a portable refresh-token vault, session-continuity substrate, current-login oracle, or durable cross-domain access-state seam on existing SlopOS surfaces.
   - Existing auth-teardown, login-state, browser-session, and token-passthrough boundaries stay authoritative instead of inheriting liveness semantics from one provider's ID-JAG refresh path.

6) **No silent SSO/account/proof widening rides in through enterprise chaining helpers.**
   - Imported enterprise identity assertions and ID-JAG helpers do **not** authorize connected-account export, subject/email export, signed-in truth, callback-free approval truth, or generic enterprise SSO proof by implication.
   - If SlopOS ever needs portable cross-domain identity chaining, token exchange, enterprise account binding, or subject-token storage, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: enterprise auth interop remains killable by policy and does not smuggle ambient assertion/token channels through hidden paths, env vars, or implicit network callbacks.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local enterprise auth negotiation plus explicit reviewed proof/result/evidence seams.
   - Any future native cross-domain identity-chaining / token-exchange / enterprise-account workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported identity assertions, `subject_token` handling, or ID-JAG exchange helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `identity_assertion`, `id_token`, `saml_assertion`, `subject_token`, `id_jag`, `enterprise_sso_proof`, or equivalent cross-domain assertion substrate imported directly from MCP enterprise-managed auth.
- No rule that saved Identity Assertions, `subject_token` exchange, or typed ID-JAGs stand in for portable login proof, subject-token storage, enterprise account binding, approval basis, or durable signed-in truth.
- No rule that carried claims such as `sub`, `email`, `aud_sub`, `scope`, `resource`, `auth_time`, `amr`, or `authorization_details` stand in for portable identity/profile export, entitlement truth, or active-tenant/account truth.
- No rule that refresh-driven ID-JAG renewal stands in for a portable refresh-token vault, session-continuity substrate, or current enterprise-access oracle.

## Why this is worth pinning

The archive already keeps enterprise routing, caller/session auth state, client registration, auth proof export, account binding, identity claims, and login state on separate explicit seams. Current MCP enterprise-managed auth adds a nearby pressure surface that those docs do not yet pin directly: **the saved identity assertions and ID-JAG / token-exchange artifacts that glue enterprise SSO to cross-domain access tokens**.

That looks like implementation detail, but it is exactly where hidden substrate grows. Once wrappers and agents see “save the Identity Assertion,” “use it as `subject_token`,” and “exchange the resulting ID-JAG for an access token,” saved ID Tokens become “portable enterprise login proof,” refresh-capable `subject_token` flows become “the platform's SSO token cache,” and carried claims start masquerading as portable tenant/account/approval truth.

Pinning the boundary now keeps the archive honest. Imported enterprise identity assertions and ID-JAG exchange may remain a provider-local way to bootstrap one cross-domain authorization path, but they do not get to redefine SSO proof, token exchange, account binding, identity export, or durable login-state truth on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with enterprise-managed MCP servers, but saved identity assertions and ID-JAG exchange still stay provider-local auth machinery rather than a portable enterprise login-proof or account-binding story.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted agents and workers will meet enterprise cross-domain auth more often, but those integrations do not become tenant-stable subject-token storage, enterprise SSO proof, or cross-domain account substrate by default.
- **Embedded / separation appliance (C):** appliances can omit enterprise identity chaining entirely or terminate it in a narrow shim without importing a generalized token-exchange / account-binding subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported enterprise SSO helpers may help one provider-owned enterprise auth path proceed, but they do not become a second identity/login/proof substrate beside explicit auth-proof, auth-result, account-binding, and identity-claim seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_id_jag_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “enterprise identity assertions are not portable SSO proof / subject-token / account truth” posture drifts (**EVID-2026-684**).

## References

- `REF-MCP-ENTERPRISE-MANAGED-AUTH`
- `REF-IETF-DRAFT-ID-JAG`
- `REF-RFC8693-TOKEN-EXCHANGE`
- `REF-RFC7523-JWT-BEARER`
- `REF-OPENID-CONNECT-CORE`
