# Network request listen-subject boundary v0

Purpose: pin one narrow D-NETLEASE / CH-NETREQ meaning cut: `kind=listen` names a **local bind/exposure subject**, not a remote DNS predicate, publish-by-name request, or public-endpoint allocation contract.

This keeps Phase 1 listener authority honest across the four product shapes. A reviewed listener request can authorize binding or exposing a local port/class, but it does not quietly pull in hostname bind semantics, resolver contracts, mDNS/DNS publication, NAT/public-endpoint assignment, or loopback-callback folklore.

## Posture (v0)

1) **`kind=listen` names a local bind/exposure subject.**
   - `kind=listen` on `portal.net.request` / CH-NETREQ v0 names a **local bind/exposure subject**.
   - The reviewed subject is a local exposure class the platform is willing to mediate, not a remote DNS predicate or publication target.

2) **`kind=listen` admits `dest.kind in {ip_prefix, service}` only.**
   - `ip_prefix` covers explicit local-address / wildcard bind classes.
   - Listen-side `service` labels are **local policy metadata**, not remote resolver contracts.

3) **`kind=listen` with `dest.kind in {dns_name, dns_suffix}` MUST reject before effect.**
   - Phase 1 validators, owner services, and compat membranes MUST reject listener DNS predicates before effect.
   - Assurance anchor: `PO-ACP-NET-REQUEST` carries this validator obligation.

4) **No portable bind/publication/public-endpoint seam in v0.**
   - No portable `bind_hostname`, `listen_hostname`, `publish_dns_name`, `register_service`, `advertise_mdns`, `public_endpoint`, `nat_mapping`, or `loopback_callback` seam exists in v0.
   - A reviewed listener request authorizes local bind/exposure only; any later publication or callback semantics must earn their own explicit seam.

## Why this cut exists
Mainstream listener APIs make listening a **local bind** problem:
- local address selection happens at `bind()` / `listen()` time rather than through remote-name predicates (REF-MAN7-BIND; REF-MAN7-LISTEN; REF-MAN7-IP), and
- passive name-resolution helpers produce wildcard/local bind addresses when explicitly asked for passive results, rather than turning hostnames into a generic listener publication plane (REF-MAN7-GETADDRINFO).

Translated into SlopOS terms: a reviewed listener request should talk about the local exposure subject the platform is willing to mediate, not smuggle in a second DNS/publication subsystem under D-NETLEASE.

## Consequences for existing artifacts
- CH-NETREQ v0 / CH-NETLEASE v0 keep one destination field shape, but `kind=listen` narrows its valid predicate forms.
- CH-NETLEASE `resolver` remains required only for `kind=dns` and connect-side name-resolving requests; a listen-side `service` label does not by itself imply resolver semantics.
- `portal.net.request` wrappers and compat membranes MUST NOT reinterpret `kind=listen` as bind-by-hostname, publish-by-name, mDNS advertisement, NAT/public-endpoint allocation, or loopback-callback capture.

## Phase 1 non-goals (explicitly deferred)

- No portable `bind_hostname`, `listen_hostname`, or hostname-driven local bind control surface on `portal.net.request`.
- No DNS publication / registration / advertisement seam (`publish_dns_name`, `register_service`, `advertise_mdns`) piggybacking on `kind=listen`.
- No public-endpoint / NAT-mapping / loopback-callback allocation receipt attached to CH-NETLEASE v0 for listener requests.
- No new ACP kind, receipt schema, or listener-specific family index just to express this validation cut.

## Commutativity / conflict-key stance stays on the existing seam
- No new externally visible action is introduced.
- Existing action: `portal.net.request`.
- Conflict keys remain `domain.id`; ordering/serialization remain where the existing seam already puts them.
- This boundary only narrows request validity and Phase 1 meaning; it adds **no new ACP kind**, no new conflict-key family, and no new serialization boundary.

## Wiring

- Decision surface: `decision-map.md` (D-NETLEASE)
- Request/lease schema posture: `network-request-schema-v0.md`, `network-lease-schema-v0.md`, `network-lease-posture-v0.md`
- Portal/ACP surfaces: `portal-net-proof-slice-v0.md`, `../70-llm-control/acp-action-kind-registry.md`, `../70-llm-control/acp-validator-semantics.md`, `portal-family-registry.md`
- Assurance/discovery: `../20-assurance/invariant-registry.md`, `../20-assurance/proof-obligation-registry.md`, `../00-meta/resolved-history.md`, `../00-meta/evidence-index.md`, `boundary-family-map.md`
- RFC context: `../../rfcs/0056-outbound-network-leases-and-portals.md`

## Evidence hook
- Drift gate: `tools/check_network_request_listen_subject_boundary.py`
- Evidence id: `EVID-2026-642`

## References
- `network-request-schema-v0.md`
- `network-lease-schema-v0.md`
- `network-lease-posture-v0.md`
- `portal-net-proof-slice-v0.md`
- `acp-action-kind-registry.md`
- `acp-validator-semantics.md`
- `portal-family-registry.md`
- `decision-map.md`
- `rfcs/0056-outbound-network-leases-and-portals.md`
- `../00-meta/bibliography.md` (`REF-MAN7-BIND`, `REF-MAN7-LISTEN`, `REF-MAN7-IP`, `REF-MAN7-GETADDRINFO`)

## Singleton status (Phase 1)
This doc is an **intentional singleton** recorded in `boundary-family-map.md` because it pins exactly one narrow network-request meaning cut without opening a broader family. In this revision, **no broader multi-doc boundary family exists yet** for network-request semantics beyond request-state/idempotency/listen-subject singletons.

If a later revision adds another network-request companion boundary, update `boundary-family-map.md` in the **same revision** and either keep the singleton list explicit or promote the set into a dedicated family index.
