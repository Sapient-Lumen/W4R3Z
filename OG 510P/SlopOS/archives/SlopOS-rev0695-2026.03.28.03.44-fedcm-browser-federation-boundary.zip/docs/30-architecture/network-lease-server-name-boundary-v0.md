# D-NETLEASE server-name boundary v0 (no portable SNI / server-name / ECH seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed leased networking over `tls` / `quic` does **not** become a portable TLS server-name presentation surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable TLS server-name presentation seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **destination predicate**, the granted **resolver binding**, and the transport class.
   - They do **not** grow a portable `server_name`, `sni_name`, `sni_disabled`, `tls_name_override`, `public_name`, `ech`, `ech_config`, `ech_policy`, or equivalent server-name presentation/export surface.
   - Phase 1 portable truth is therefore: **what reachability predicate was reviewed/granted, through which resolver binding, over which transport class** — not which name the runtime presented in TLS/QUIC, whether SNI was suppressed or overridden, or whether ECH/public-name machinery was used.

2) **Server-name presentation stays portal-local or app-local.**
   - A lease may authorize reachability over `tls` or `quic`.
   - That does **not** standardize whether an implementation derives SNI from the reviewed destination name, presents a different public name, omits SNI, or attempts ECH for a concrete connection.
   - Different product profiles or owner-local runtimes may therefore expose different TLS name-presentation defaults locally — or none at all — while still staying inside the same reviewed D-NETLEASE grant.

3) **No hidden TLS-name folklore.**
   - Reviewed networking in Phase 1 must not silently inherit browser, SDK, proxy, or library defaults for SNI generation, server-name overrides, public-name fallbacks, or ECH bootstrapping as substrate meaning.
   - That rule applies both to direct `portal.net` implementations and to wrappers/compat paths around them: hidden TLS server-name presentation defaults are not by themselves reviewed network authority.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient channels through hidden on-wire name leakage or implicit name-substitution behavior.

4) **If portable TLS name-presentation semantics matter, pay for a new seam explicitly.**
   - A future product shape may want reviewed SNI policy, transcript-visible public-name/ECH policy, or explicit TLS name-presentation receipts.
   - That work must return **RFC-first** with its own schema/receipt family, conflict keys, commutativity story, freshness rules, privacy posture, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems use SNI and increasingly ECH.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit TLS name-presentation seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from browser stacks, proxy overrides, or ECH bootstrapping defaults.

6) **Current on-wire TLS name choice is connection-local live state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove which SNI or public name a given connection used, whether ECH was attempted or accepted, or whether the same implementation would present the same on-wire name on retry.
   - As elsewhere in SlopOS, stable request/receipt artifacts are evidence of one reviewed action, not a portable oracle for mutable connection-local TLS name-presentation results.

## Phase 1 non-goals (explicitly deferred)

- No portable `server_name`, `sni_name`, `sni_disabled`, `tls_name_override`, `public_name`, `ech`, `ech_config`, or `ech_policy` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a TLS name-presentation broker, ECH policy plane, or public-name policy plane.
- No transcript-stable claim that an accepted network request or issued lease also proves a selected SNI/public-name/ECH result.
- No hidden browser/SDK/library compatibility promise that `tls` / `quic` reachability implies one reviewed server-name presentation behavior on `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS, and the recent passes kept resolver answers, local-egress policy, path-state folklore, proxy policy, transport verifier policy, client-auth identity, and application-protocol negotiation out of CH-NETREQ / CH-NETLEASE portable meaning. The next quiet drift is to pretend the same lease also says **which TLS server name goes on the wire**. Real systems treat SNI and ECH as explicit transport machinery with privacy and interoperability consequences, not as harmless residue of “a network request was reviewed.”

If we leave that blurry, workstation and agent flows will start depending on whichever SNI derivation, public-name fallback, or ECH defaults the local browser/runtime happened to ship, while cloud and embedded profiles will be forced to fake portability for TLS name-presentation semantics they do not actually share. Pinning the boundary now keeps D-NETLEASE honest: reviewed reachability is one seam, reviewed TLS name presentation would be another future seam if we ever truly need it.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich TLS stacks with SNI and ECH locally, but that does not standardize those defaults as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound reachability explicit without pretending guest/runtime SNI or ECH behavior is transcript-stable reviewed truth.
- **Embedded / separation appliance (C):** appliance builds can keep a narrow leased-network seam without paying for a portable general-purpose TLS name-presentation policy plane they do not want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “lease to this destination over TLS/QUIC” with “portable statement that a specific SNI, public name, or ECH policy is reviewed, selected, or guaranteed.”

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-tls-verifier-boundary-v0.md`
  - `docs/30-architecture/network-lease-application-protocol-boundary-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-CAPSHELL-NET-EXPLICIT**)

CI drift gate:
- `tools/check_network_lease_server_name_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable SNI / server-name / ECH seam / no hidden TLS-name folklore / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-638**).

## References

- REF-RFC6066-TLS-SNI.
- REF-RFC9849-ECH.
- REF-RFC9848-ECH-SVCB.
- REF-CURL-CONNECT-TO.
