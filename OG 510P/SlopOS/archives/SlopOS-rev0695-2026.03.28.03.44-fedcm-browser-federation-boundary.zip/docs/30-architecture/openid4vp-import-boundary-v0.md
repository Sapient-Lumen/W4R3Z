# D-LLM / D-POLICY / IF-ACP OpenID4VP import boundary v0 (wallet presentations are not portable identity / approval / wallet truth)

Purpose: pin one compact Phase-1 rule on the existing **D-LLM / D-POLICY / IF-ACP** seams: imported OpenID for Verifiable Presentations semantics — `vp_token`, `dcql_query`, Claims Path Pointer selections, Trusted Authorities Query objects, `response_uri`, `nonce` / `wallet_nonce`, `response_mode=direct_post` / `direct_post.jwt`, wallet metadata, verifier metadata, Verifier Attestation JWTs, wallet invocation flows, and presented W3C VC / SD-JWT VC / ISO mdoc payloads plus HAIP-constrained format/profile material — are **provider-local credential-presentation coordination only**. They do **not** create a portable identity-card export, credential-wallet import, verifier-policy selector, trust-framework registry, approval-basis object, document/evidence store, or durable subject/account/current-user truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported wallet-mediated credential-presentation material may be interpreted next to already-pinned identity-claim, account-binding, approval-basis, verification-policy-selection, verification-material-discovery, verification-verdict, and auth/profile import cuts.

## Posture (v0)

1) **Imported OpenID4VP request/response/query objects stay provider-local credential-presentation coordination only.**
   - OpenID4VP standardizes how a Verifier requests presentations with authorization-request parameters such as `vp_token`, `dcql_query`, `response_uri`, `nonce`, `wallet_nonce`, request-URI transport, and response modes including `direct_post` and `direct_post.jwt`.
   - Imported request objects, response objects, `vp_token` packaging, DCQL query structures, Claims Path Pointer selections, `response_uri`, `nonce` / `wallet_nonce`, wallet-invocation parameters, and response-mode mechanics remain provider-local credential-presentation coordination only; they do **not** become a portable pending-proof handle, callback-result artifact, approval-basis object, document/evidence store, or durable subject/account/current-user truth on existing SlopOS seams.
   - Existing auth-result, auth-proof, identity-claim, verification-material-discovery, and explicit export seams stay authoritative instead of inheriting portable truth from one provider's wallet-presentation protocol.

2) **Imported wallet/verifier metadata and verifier attestations stay provider-local trust signaling only.**
   - OpenID4VP defines wallet metadata, verifier metadata, client identifier prefixes, and Verifier Attestation JWTs so a Wallet and Verifier can negotiate supported formats, algorithms, and verifier authentication.
   - Imported wallet metadata, verifier metadata, `vp_formats_supported`, client identifier prefixes, verifier info, Verifier Attestation JWTs, confirmation keys, and related metadata/signaling remain provider-local trust signaling only; they do **not** become a portable wallet registry, verifier-policy selector, trust-root plane, approved-app inventory, or durable connected-wallet/verifier truth on existing SlopOS seams.
   - Existing trust-root, app-trust, verification-policy-selection, and connected-account/binding boundaries stay authoritative instead of inheriting portable policy or connected-entity meaning from wallet/verifier metadata.

3) **Imported trusted-authority queries, format/profile constraints, and HAIP material stay provider-local verifier policy hints only.**
   - OpenID4VP includes Trusted Authorities Query objects for identifying issuers or trust frameworks, and HAIP profiles OpenID4VC presentation/issuance behavior for SD-JWT VC and ISO mdoc ecosystems where high security and privacy are required.
   - Imported Trusted Authorities Query objects, trust-framework identifiers, issuer/federation matching hints, credential-format/profile constraints, HAIP format requirements, wallet-attestation requirements, and key-attestation/profile material remain provider-local verifier policy hints only; they do **not** become a portable trust-framework registry, issuer-registry selector, verifier-policy engine, approval proof, or global high-assurance eligibility oracle on existing SlopOS seams.
   - Existing federation, verification-policy-selection, approval-basis, and verification-verdict boundaries stay authoritative instead of inheriting global trust or approval meaning from one wallet ecosystem's profile settings.

4) **Imported credential payloads, transaction data, and presentation selections stay provider-local payload/validation only.**
   - W3C VC Data Model 2.0 defines the issuer/holder/verifier model and core credential/presentation concepts, and OpenID4VP profiles how W3C VCs, SD-JWT VCs, and ISO mdocs are selected, disclosed, and presented.
   - Imported presented credentials, verifiable presentations, SD-JWT VC / mdoc payloads, transaction data, selective-disclosure selections, and claims-path selection results remain provider-local payload/validation only; they do **not** become a portable identity card, KYC verdict, entitlement registry, account-binding proof, generic credential-wallet import, or durable current-user/current-permission truth on existing SlopOS seams.
   - Existing identity-claim export, account-binding, approval-basis, verification-verdict, and CH-WALLET posture stay authoritative instead of inheriting portable identity/wallet meaning from one presented-credential payload.

5) **No silent wallet/credential widening rides in through OpenID4VP.**
   - Imported `vp_token`, DCQL query structures, trusted-authority queries, wallet/verifier metadata, verifier attestations, HAIP profile material, and presented credential payloads do **not** authorize portable credential-wallet import, portable identity-card truth, portable verifier-policy choice, portable approval meaning, portable document/evidence storage, or durable “who is this and what may they do?” truth by implication.
   - A verifier may use OpenID4VP plus HAIP to request and validate one provider-local wallet presentation, but that does **not** standardize a portable identity-wallet substrate on D-LLM, D-POLICY, IF-ACP, or adjacent identity/account/verification seams.
   - If SlopOS ever needs native verifiable-credential import, credential-wallet handling, or wallet-presentation evidence, that work must arrive as an RFC on explicit schemas, validators, conflict keys, evidence hooks, and kill switches rather than inheriting folklore from OpenID4VP, HAIP, or VC transport compatibility.

6) **Sealed compat remains honest.**
   - Any compat/runtime use of wallet invocation, verifier attestations, request-URI fetches, wallet metadata, credential caches, or presented-credential validation helpers must be killable by policy and must not create authority via hidden paths, env vars, implicit network access, silently persistent wallet stores, or ambient trust-framework configuration.
   - A compat layer that cannot proceed without ambient verifier policy, hidden request-URI retrieval, implicit credential caching, or hidden wallet selection defaults must fail closed for portable SlopOS authority semantics.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: IF-ACP validation, exact action bytes, explicit capabilities/approvals, explicit D-POLICY handles/bundles, and explicit verifier-owner policy choice.
   - Any future native verifiable-credential import, wallet-presentation receipt, or verifier-policy workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting them from imported `vp_token`, verifier attestations, trusted-authority queries, or presented credential payloads.

## Phase 1 non-goals (explicitly deferred)

- No portable credential-wallet import or export imported directly from OpenID4VP or HAIP compatibility.
- No portable rule that presented credentials, verifiable presentations, SD-JWT VC / mdoc payloads, or claims-path selections stand in for CH-ACP, identity-claim export, account-binding, verification-verdict, or approval-basis truth.
- No portable rule that Trusted Authorities Queries, verifier metadata, wallet metadata, verifier attestations, or HAIP profile requirements stand in for SlopOS policy choice, trust-root choice, or issuer/verifier registry semantics.
- No portable rule that request/response packaging, `response_uri`, `direct_post` / `direct_post.jwt`, or transaction data stand in for callback-result seams, document/evidence stores, or durable connected-wallet/current-user truth.

## Why this is worth pinning

This is the next small, high-leverage cut after AuthZEN, Shared Signals, SCIM, OpenID Federation, and OpenID Identity Assurance. Once external authorization decisions, auth-state events, provisioning APIs, federation bootstrap, and verified claims are pinned as provider-local only, the next tempting shortcut is “fine, trust the wallet presentation.” In practice that means over-reading `vp_token`, trusted-authority filters, verifier attestations, wallet metadata, presented credential payloads, and HAIP profile requirements as if they were portable identity cards, approval proofs, current-user truth, or a native credential-wallet substrate.

OpenID4VP and W3C VC 2.0 are useful and final. They give ecosystems standard ways to request and deliver credential presentations with selective disclosure, verifier metadata, trusted-authority filters, and reusable credential/presentation models. That is exactly why the archive should pin their meaning early: imported wallet-presentation material is a valuable compatibility surface, but it does not get to redefine identity truth, approval basis, verifier policy, or durable wallet/account bindings on SlopOS.

Pinning the boundary now keeps the archive honest. Imported wallet-mediated credential presentations may remain a provider-local way to request and validate one credential exchange, but they do not become a portable identity-wallet substrate, trust-framework registry, verifier-policy plane, approval-basis object, or durable current-user truth inside SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation agents may interoperate with enterprise or consumer wallets, but imported wallet presentations and verifier attestations do not become a portable current-user card, approval proof, or wallet import path.
- **Cloud micro-VM / hosted compute substrate (B):** hosted control planes may consume verifier-local credential presentations for onboarding or tenant flows, but imported VP payloads do not become a portable identity registry, issuer-policy selector, or durable connected-wallet/account substrate.
- **Embedded / separation-kernel-ish appliance (C):** appliances may compile in a narrow verifier adapter, but OpenID4VP remains sealed compat only and policy-killable, with no hidden request-URI fetch, wallet default, or credential cache becoming native authority.
- **Agent / automation OS (D):** first-class LLM/automation stacks are exactly where wallet presentations are easiest to over-read as “who the user is”, “wallet approved this”, or “the credential means allow”; this boundary keeps agent memory/tooling from silently normalizing that widening.

## Family status (Phase 1)

This doc is a member of the closed verifiable-credential ecosystem companion family indexed by `verifiable-credential-ecosystem-boundary-index.md`.
It stays there with `openid4vp-import-boundary-v0.md`, `openid4vci-import-boundary-v0.md`, `verifiable-credential-status-import-boundary-v0.md`, and `did-document-import-boundary-v0.md` so presentation, issuance, status, and DID-resolution meaning pins remain discoverable together.
If future reviewed wallet / credential / DID-import cuts appear, add them to that family **in the same revision** rather than letting them regrow as adjacent singletons.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/verifiable-credential-ecosystem-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Evidence id:** `EVID-2026-701`
- `tools/check_openid4vp_import_boundary.py` fails `make lint` if this boundary, its family membership, discovery wiring, or its “wallet presentations are not portable identity / approval / wallet truth” posture drifts.
- Attached to existing assurance surfaces: **I-LLM-1**, **PO-ACT-VALIDATE**, **PO-POLICY-NONAMP**.

## References

- `REF-OPENID-4VP-1-0`
- `REF-OPENID-4VP-FINAL`
- `REF-OPENID4VC-HAIP-1-0`
- `REF-W3C-VC-DM-2-0`
