# D-NETLEASE client-cert boundary v0 (no portable client-certificate / mTLS identity seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: leases that allow `proto = tls` or `proto = quic` do **not** become a portable client-certificate, mTLS identity, or certificate-bound token surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable client-certificate / mTLS identity seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the reviewed/granted **destination predicate**, the granted **resolver binding**, and the transport class (`tls` / `quic`).
   - They do **not** grow a portable `client_cert`, `client_cert_alias`, `client_key_ref`, `pkcs11_uri`, `mtls_identity`, `proxy_client_cert`, `tls_client_auth`, `certificate_bound_token`, or equivalent export surface.
   - Phase 1 portable truth is therefore: **what reachability predicate was reviewed/granted, through which resolver binding, over which transport class** — not which local client certificate, key holder, or certificate-bound token policy a provider/runtime happened to use.

2) **Client-auth selection stays portal-local or app-local.**
   - A lease may authorize transport reachability to a reviewed predicate using `proto = tls` or `proto = quic`.
   - That does **not** standardize which local certificate alias, keychain entry, HSM / PKCS#11 object, or certificate-bound token discipline a provider/runtime uses when authenticating the client to a remote peer.
   - Different product profiles or owner-local runtimes may therefore select different local client-auth mechanisms — or none at all — while still staying inside the same reviewed D-NETLEASE reachability grant.

3) **No ambient keychain / PKCS#11 / proxy-client-cert fallback.**
   - Reviewed networking in Phase 1 must not silently inherit browser certificate pickers, host-global keychains, default PKCS#11 providers, HTTPS-proxy client-certificate settings, or generic “reuse whatever client cert the host would send” compatibility switches as substrate meaning.
   - That rule applies both to direct `portal.net` implementations and to wrappers/compat paths around them: host credential-selection residue is not by itself reviewed network authority.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient client-auth channels through host key stores, smartcard middleware, browser certificate prompts, or ad-hoc proxy-cert defaults.

4) **If portable transport-auth or certificate-bound proof matters, pay for a new seam explicitly.**
   - A future product shape may want reviewed mTLS identity binding, explicit client-cert selection policy, or certificate-bound token/result receipts.
   - That work must return **RFC-first** with its own schema/receipt family, redaction story, commutativity/conflict-key contract, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems expose certificate pickers, client-cert files, or certificate-bound tokens.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit transport-auth seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from keychains, PKCS#11 stacks, or browser certificate prompts.

6) **Current client-auth result is live local secret/session state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove which client certificate or key holder was selected, whether the key is still present/usable, whether a proxy certificate was involved, or whether a certificate-bound token remains usable now.
   - As elsewhere in SlopOS, stable request/receipt artifacts are evidence of one reviewed action, not a portable oracle for mutable owner-local credential state.

## Phase 1 non-goals (explicitly deferred)

- No portable `client_cert`, `client_cert_alias`, `client_key_ref`, `pkcs11_uri`, `tls_client_auth`, or `certificate_bound_token` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a browser/system/client-cert chooser or keychain broker.
- No transcript-stable claim that an accepted network request or issued lease also proves which client certificate or certificate-bound token policy was used.
- No hidden browser/system/client-cert compatibility promise around `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS, and the last pass kept `tls` / `quic` reachability separate from verifier policy. The next quiet drift is to pretend the same lease also says which client certificate, key holder, or certificate-bound token discipline defines “client auth.” Real systems treat those as explicit configuration or mediated selection surfaces, not harmless residue of opening a transport path.

If we leave that blurry, workstation and agent flows will start depending on whichever browser picker, keychain alias, HTTPS-proxy client cert, or local mTLS setup happens to exist on the host, while cloud and embedded profiles will have to fake portability for client-auth semantics they do not actually share. Pinning the boundary now keeps D-NETLEASE honest: reviewed reachability is one seam, reviewed transport-auth identity would be another future seam if we ever truly need it.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich client-cert UX locally, but that does not standardize certificate pickers, alias selection, or certificate-bound token policy as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound reachability explicit without pretending host keychains or mTLS bootstrap choices are transcript-stable guest/runtime truth.
- **Embedded / separation appliance (C):** appliance builds can keep a narrow reachability seam without paying for a portable general-purpose client-cert or keychain plane they do not want to support.
- **Agent/automation OS (D):** agents/tools cannot confuse “lease to this TLS destination” with “portable client certificate selection” or “proof that a certificate-bound token would work now.”

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-lease-resolution-boundary-v0.md`
  - `docs/30-architecture/network-lease-proxy-boundary-v0.md`
  - `docs/30-architecture/network-lease-tls-verifier-boundary-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-NETLEASE-DNSBIND**, **PO-CAPSHELL-NET-EXPLICIT**)

CI drift gate:
- `tools/check_network_lease_client_cert_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable client-certificate / mTLS identity seam / no ambient keychain-or-proxy-cert fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-634**).

## References

- REF-CURL-CLIENTCERT.
- REF-ANDROID-KEYCHAIN-CHOOSEPRIVATEKEYALIAS.
- REF-RFC8705-OAUTH-MTLS.
