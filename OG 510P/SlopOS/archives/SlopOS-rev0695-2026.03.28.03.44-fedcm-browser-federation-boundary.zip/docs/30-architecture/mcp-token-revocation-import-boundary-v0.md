# D-LLM MCP-token-revocation import boundary v0 (auth revocation is not portable disconnect / account / live-state truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP/OAuth authorization-server discovery plus OAuth token revocation semantics — imported `revocation_endpoint`, revocation requests carrying `token` and optional `token_type_hint`, success-on-invalid response behavior, related-token / grant cascade policy, propagation-delay pressure, retry-after / error handling, and revocation-endpoint client-auth metadata — is **provider-local auth-teardown machinery only**. It does **not** create a portable disconnect control plane, linked-account / connected-service truth, durable live-login-state oracle, account-unlink substrate, or transcript-stable revocation ledger on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported token-revocation semantics may be interpreted next to already-pinned auth-discovery, auth-metadata-fetch, client-credentials, introspection, auth-teardown, auth-result, login-state, account-binding, and token-passthrough boundaries.

## Posture (v0)

1) **Imported revocation endpoints stay provider-local auth-teardown endpoints only.**
   - Current MCP authorization requires authorization-server discovery via OAuth Authorization Server Metadata or OIDC discovery, and RFC 8414 defines an optional `revocation_endpoint` plus revocation-endpoint client-auth metadata.
   - That imported endpoint remains provider-local auth-teardown machinery only; it does **not** create a portable disconnect API, connected-service inventory, account-unlink surface, or generic “revoke this integration” control plane on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, and auth-teardown boundaries stay authoritative instead of inheriting platform meaning from one discovered endpoint URL.

2) **Revocation requests stay provider-local token/grant teardown only.**
   - RFC 7009 defines revocation as an HTTPS POST carrying a `token` and optional `token_type_hint`, with client authentication as appropriate, and with server-side checks that the token was issued to the requesting client.
   - Those request mechanics remain provider-local token/grant teardown only; they do **not** create a portable token-control verb, account-disconnect workflow, service-admin action, or durable revocation receipt on existing SlopOS seams.
   - Existing token-passthrough, auth-result, and auth-teardown boundaries stay authoritative instead of inheriting platform action meaning from one provider's revoke request.

3) **Success-on-invalid and ignored bad hints stay provider-local teardown semantics only.**
   - RFC 7009 says the authorization server returns HTTP 200 both when revocation succeeds and when the submitted token is already invalid, ignores invalid `token_type_hint` values, and tells clients to ignore the response body.
   - Those semantics remain provider-local teardown behavior only; they do **not** create a portable disconnect-success receipt, connected-account truth bit, or durable “this token/service is gone” ledger on existing SlopOS seams.
   - Existing account-binding, login-state, and evidence boundaries stay authoritative instead of inheriting platform truth from one 200 response or ignored hint.

4) **Propagation delay and cascade policy stay provider-local live policy only.**
   - RFC 7009 says token invalidation takes effect immediately, but acknowledges propagation delay in practice; it also allows revocation policy to cascade to related tokens or the underlying authorization grant.
   - That liveness and cascade behavior remain provider-local live policy only; they do **not** create a portable live logout-state oracle, cross-provider revocation ledger, linked-account teardown guarantee, or durable current-session truth on existing SlopOS seams.
   - Existing login-state, account-binding, and auth-teardown boundaries stay authoritative instead of inheriting durable state meaning from one provider's propagation or cascade policy.

5) **Revocation-endpoint auth-method metadata stays provider-local client-auth policy only.**
   - RFC 8414 defines `revocation_endpoint_auth_methods_supported` and `revocation_endpoint_auth_signing_alg_values_supported` so a provider can advertise how clients authenticate to the revocation endpoint.
   - Those metadata fields remain provider-local client-auth policy only; they do **not** create a portable signer-acceptance plane, secret/signer store, machine-auth compatibility oracle, or durable governance fact on existing SlopOS seams.
   - Existing client-credentials, auth-proof, and JWKS boundaries stay authoritative instead of inheriting platform meaning from one provider's revocation-endpoint auth profile.

6) **No silent disconnect / account / live-state widening rides in through revocation.**
   - Imported token-revocation handling does **not** authorize linked-account export, selected-account truth, durable signed-out truth, current-user invalidation APIs, or generic connected-service management by implication.
   - A revoke path may let one provider tear down one token or grant, but it does **not** standardize portable disconnect/account/live-state semantics on adjacent SlopOS seams.
   - If SlopOS ever needs a native integration-disconnect workflow, revocation ledger, or service-connection governance seam, that work must arrive on those explicit seams and validators directly.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth libraries, discovered `revocation_endpoint` URLs, stored revocation credentials, or retry/backoff helpers must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient revocation credentials, hidden connected-service state, or implicit revoke egress must fail closed for portable D-LLM auth semantics.

8) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local token/grant teardown plus explicit reviewed result/login/account/evidence seams.
   - Any future native disconnect / revoke / unlink workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported revocation helpers or 200-on-invalid semantics.

## Phase 1 non-goals (explicitly deferred)

- No portable `revocation_endpoint`, `token_revoke`, `disconnect_service`, `unlink_account`, or equivalent disconnect-control substrate imported directly from MCP/OAuth helpers.
- No rule that revocation requests carrying `token` / `token_type_hint`, or revocation responses returning HTTP 200 on success-or-invalid, stand in for portable connected-account truth, durable signed-out truth, or transcript-stable teardown evidence.
- No rule that revocation propagation delay, cascade-to-related-tokens policy, or `Retry-After` handling stand in for portable login-state, revocation-ledger, or current-session semantics.
- No rule that `revocation_endpoint_auth_methods_supported` or `revocation_endpoint_auth_signing_alg_values_supported` stand in for portable signer acceptance, secret storage, or machine-auth governance truth.

## Why this is worth pinning

The archive already keeps auth discovery/fetch, verifier keys, introspection, token passthrough, auth-result export, login-state export, account-binding export, and generic auth-teardown on separate explicit seams. Current MCP/OAuth guidance adds a nearby pressure surface those docs do not yet pin directly: **discovered token revocation endpoints and their odd-but-standard teardown semantics, including success-on-invalid responses, possible propagation delay, and grant/token cascade behavior**.

That looks operational rather than architectural, but it is exactly where hidden substrate grows. Once hosts and agents see a discovered `revocation_endpoint`, an HTTP 200 that means either “revoked” or “already invalid”, and enterprise guidance promising centralized revocation, “provider-local token teardown” drifts into “the platform knows this account is disconnected”, “this service is signed out everywhere”, or “we have a durable revoke receipt for this integration”.

Pinning the boundary now keeps the archive honest. Imported token revocation may remain a provider-local way to tear down one token or grant on one auth path, but it does not get to redefine disconnect control, connected-account truth, login-state truth, or durable revocation evidence on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with remote providers that advertise revocation endpoints, but a provider-local revoke call still does not become a generic “disconnect this account” substrate or durable signed-out truth.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted agents and workers will accumulate many external integrations, but provider-local revocation endpoints do not become tenant-stable connected-service governance, logout truth, or revocation-ledger substrate by default.
- **Embedded / separation appliance (C):** appliances can omit remote token revocation entirely or terminate it in a narrow shim without importing a generalized disconnect/account-management subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported revocation helpers may help one provider-owned teardown path proceed, but they do not become a second integration-management or account-state substrate beside explicit auth-result, login-state, account-binding, and future governance seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_token_revocation_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “auth revocation is not portable disconnect / account / live-state truth” posture drifts (**EVID-2026-686**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-MCP-ENTERPRISE-MANAGED-AUTH`
- `REF-RFC7009-TOKEN-REVOCATION`
- `REF-RFC8414-AS-METADATA`
