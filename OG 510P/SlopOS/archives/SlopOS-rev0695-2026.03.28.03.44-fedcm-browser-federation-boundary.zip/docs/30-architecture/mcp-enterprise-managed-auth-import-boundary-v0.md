# D-LLM MCP-enterprise-managed-auth import boundary v0 (enterprise IdP routing is not portable policy/account/session truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported MCP Enterprise-Managed Authorization (`io.modelcontextprotocol/enterprise-managed-authorization`, extension negotiation during `initialize`, enterprise-IdP authorization redirection, organization-level IdP configuration, scope-restricted IdP-issued tokens, and centralized enterprise policy/revocation) is **provider-local authorization routing only**. It does **not** create a portable enterprise-policy oracle, account-binding export, authorization-context export, login-state oracle, browser-session continuity plane, or token/callback broker on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP enterprise auth semantics may be interpreted next to already-pinned auth-result, authorization-context, account-binding, login-state, browser-session, and callback/token boundaries.

## Posture (v0)

1) **Imported enterprise-managed auth stays extension-negotiated routing only.**
   - Support for `io.modelcontextprotocol/enterprise-managed-authorization` remains an extension-negotiated capability between MCP client and MCP server.
   - It may tell the host that a protected remote MCP server expects enterprise-managed auth via an enterprise IdP rather than the server's default authorization endpoint.
   - It does **not** create a portable enterprise-connector registry, enterprise-auth capability oracle, per-server support matrix, or generic host-visible policy/admin surface on D-LLM.

2) **Enterprise IdP handoff stays local auth routing only, not browser/session or callback truth.**
   - Redirecting the user to an enterprise IdP authorization endpoint may be part of one provider-owned authorization flow.
   - That handoff does **not** authorize embedded-browser control, authenticated browser-session export, callback registration, authorization-code relay, token relay, or generic login-completion receipts on existing SlopOS seams.
   - Existing browser/session, continuation, and auth-result cuts remain in force under `browser-session-export-boundary-v0.md`, `auth-continuation-export-boundary-v0.md`, and `auth-result-export-boundary-v0.md`.

3) **IdP-issued tokens and claims stay provider/server authorization inputs only.**
   - MCP's enterprise-managed auth overview explicitly frames enterprise IdP tokens and claims as inputs the MCP server validates and maps to access policy.
   - Those tokens, scopes, roles, groups, departments, audiences, issuers, and related claims do **not** become portable requester-visible `token_set`, `granted_scopes`, `permissions`, `linked_account`, `connected_workspace`, `active_tenant`, `subject`, or equivalent artifacts on existing SlopOS seams.
   - Existing auth-result, authorization-context, identity-claim, and account-binding boundaries remain the only reviewed places where such meaning would need to be paid for explicitly.

4) **Centralized enterprise policy and revocation stay provider-local live state only.**
   - The extension may let the enterprise IdP make policy decisions and revoke access centrally across approved MCP servers.
   - That is useful operationally, but it does **not** become a portable `logged_in`, `access_available`, `server_authorized`, `policy_version`, `revocation_state`, `tenant_enabled`, or equivalent current-state oracle for agents, widgets, or requesters.
   - This keeps D-LLM honest: imported enterprise auth routing may influence whether a provider can proceed, but it does not export enterprise access truth as a reviewed substrate artifact.

5) **Organization configuration stays host/provider policy, not requester-visible control.**
   - Organization-level IdP endpoints, admin configuration, server registration, and enterprise policy plumbing may exist locally.
   - They do **not** become portable requester-visible knobs such as `set_enterprise_idp`, `select_org_auth`, `list_enterprise_servers`, `set_policy_source`, or equivalent admin/configuration surfaces on D-LLM.
   - If SlopOS ever needs reviewed enterprise-auth configuration or connector-governance APIs, that work must return RFC-first on its own seam.

6) **No token passthrough or upstream-relay exception leaks in through the extension.**
   - MCP core authorization still requires resource-specific tokens and says servers must not pass client-received tokens through to upstream APIs.
   - Imported enterprise-managed auth does **not** relax that rule by folklore, and it does **not** justify treating enterprise IdP routing as permission to mint, forward, cache, or replay bearer material across generic host/tool seams.
   - This keeps sealed compat honest too: interop remains killable by policy and must not smuggle ambient auth channels through hidden browser helpers, path/env residue, or implicit network callbacks.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local auth negotiation, explicit reviewed approvals, and explicit reviewed result artifacts.
   - Any future native enterprise-auth brokerage / account-selection / policy-snapshot workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP enterprise extensions or enterprise IdPs.

## Phase 1 non-goals (explicitly deferred)

- No portable `enterprise_auth`, `enterprise_idp`, `enterprise_policy`, `org_sso`, `server_access_matrix`, or equivalent provider-independent enterprise-policy oracle imported directly from MCP enterprise-managed auth.
- No rule that enterprise IdP redirect/routing implies portable browser-session continuity, callback completion, authorization-code relay, or token relay.
- No rule that IdP-issued scopes/roles/groups/departments become portable granted-scope, connected-account, active-tenant, profile-identity, or login-state truth on existing seams.
- No requester-visible org-level admin/configuration control plane for enterprise IdP selection, policy source, or approved-server registry in v0.

## Why this is worth pinning

The archive already keeps auth results, granted scopes, connected-account state, browser sessions, and login-state truth on separate narrow boundaries. MCP's Enterprise-Managed Authorization extension is the next concrete place those meanings could blur together. The official extension makes enterprise SSO and centralized IdP policy a first-class import path for MCP clients and servers; that is useful, but it also creates the exact temptation to say “the platform now knows the user's enterprise account, permissions, and allowed servers.”

That is too much meaning to smuggle through one extension flag. In SlopOS terms, imported enterprise auth should stay what it is: provider-local authorization routing plus provider/server-local policy evaluation. Without this pin, agents and wrappers will start inferring account-binding truth from SSO reachability, entitlement truth from IdP claims, current-state truth from centralized revocation, and callback/token truth from enterprise redirects. Once that lands in transcripts and automation, it becomes expensive to retract.

Pinning the boundary now keeps the archive honest. Enterprises can still use current MCP auth extensions, but existing SlopOS seams do not silently widen into an enterprise policy oracle, connected-account broker, entitlement export API, or browser/session continuity substrate.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may support enterprise-managed remote MCP auth, but enterprise SSO does not standardize connected-account, policy, or login-state exports as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted agents can connect to enterprise-managed MCP servers without inheriting a fake tenant/account/policy API or browser-session continuity contract.
- **Embedded / separation appliance (C):** appliances can omit enterprise-managed auth entirely or front it with narrow local policy without importing a generic enterprise account/state substrate.
- **Agent/automation OS (D):** this matters most here: enterprise-managed auth may help a provider get the right token from the right IdP, but it does not grant agents a portable oracle for who is connected, which tenant is active, what scopes were granted, or whether access remains live.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_enterprise_managed_auth_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “enterprise IdP routing is not portable policy/account/session truth” posture drifts (**EVID-2026-671**).

## References

- `REF-MCP-ENTERPRISE-MANAGED-AUTH`
- `REF-MCP-AUTH-EXTENSIONS`
- `REF-MCP-AUTHORIZATION`
- `REF-RFC8707-RESOURCE-INDICATORS`
- `REF-RFC9728-PROTECTED-RESOURCE-METADATA`
