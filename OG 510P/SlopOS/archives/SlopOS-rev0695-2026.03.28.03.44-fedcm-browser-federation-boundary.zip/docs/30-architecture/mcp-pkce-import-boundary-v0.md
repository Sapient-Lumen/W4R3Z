# D-LLM MCP-PKCE import boundary v0 (PKCE handling is not portable verifier/proof truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP PKCE handling — required PKCE for authorization-code flows, verifier/challenge pair creation, `S256` preference, authorization-server metadata checks for `code_challenge_methods_supported`, and refusal to proceed when PKCE support is not confirmed — is **provider-local authorization code-binding only**. It does **not** create a portable verifier export, proof-of-possession substrate, PKCE-capability oracle, pending-auth continuation handle, or durable approval/account truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP PKCE semantics may be interpreted next to already-pinned auth-discovery, auth-metadata-fetch, auth-redirect, auth-continuation, auth-proof, and auth-result boundaries.

## Posture (v0)

1) **`code_verifier` / `code_challenge` stays request-local code-binding only.**
   - Current MCP requires clients to implement PKCE and RFC 7636 defines PKCE around one verifier/challenge pair for one authorization-code transaction.
   - That pair remains provider-local request binding only; it does **not** become a portable verifier export, reusable continuation handle, generic login residue, or bearer-independent proof object on existing SlopOS seams.
   - Existing auth-continuation, auth-proof, and auth-result boundaries stay authoritative instead of inheriting folklore from verifier/challenge material.

2) **`S256` preference stays provider-local transform policy only.**
   - Current MCP requires `S256` when technically possible, and RFC 7636 treats `S256` as the mandatory-to-implement code-challenge method on servers.
   - That requirement remains provider-local authorization-code protection only; it does **not** become a portable signing mechanism, cryptographic capability badge, verifier-format registry, or generic proof-strength verdict on existing SlopOS seams.
   - A successful `S256` path therefore says nothing durable about user identity, approval quality, account binding, or future proof/export semantics.

3) **`code_challenge_methods_supported` stays provider-local support detection only.**
   - Current MCP says clients must verify PKCE support before proceeding and must use authorization-server metadata / provider metadata to look for `code_challenge_methods_supported`.
   - That check remains provider-local compatibility gating only; it does **not** become a portable PKCE-capability oracle, client-trust verdict, issuer certification signal, or app-approval basis on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, and client-trust-policy boundaries stay authoritative instead of inheriting durable platform truth from discovered PKCE support bits.

4) **Refusal to proceed without confirmed PKCE stays provider-local safety gating only.**
   - Current MCP says clients must refuse to proceed when PKCE support cannot be confirmed from metadata.
   - That refusal remains provider-local authorization safety logic only; it does **not** become a portable deny receipt, durable policy verdict, connected-account truth, or generic auth-failure object on existing SlopOS seams.
   - If a future product shape needs explicit reviewed auth-compatibility verdicts, it must return RFC-first on its own seam rather than inheriting meaning from imported PKCE preflight checks.

5) **No silent proof/continuation widening rides in through imported PKCE helpers.**
   - Imported MCP PKCE semantics do **not** authorize verifier export, challenge export, callback-result export, proof-of-possession export, token relay, or browser-session continuity by implication.
   - Tools, shells, wrappers, and compat layers may stage provider-local PKCE state for one authorization path, but they must not quietly turn that into a portable verifier mailbox, proof cache, or “resume this login elsewhere” substrate.
   - This keeps sealed compat honest too: imported PKCE handling remains killable by policy and does not smuggle ambient callback, browser, or continuation channels into existing surfaces.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit auth/login boundaries, and explicit evidence artifacts.
   - Any future native PKCE brokerage / reviewed continuation / proof-carrying auth workflow must state its own conflict keys, commutativity conditions, serialization point, replay/expiry model, and evidence story explicitly rather than inheriting folklore from imported PKCE helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `code_verifier`, `code_challenge`, `code_challenge_method`, `pkce_required`, `pkce_supported`, or `code_challenge_methods_supported` substrate imported directly from MCP auth handling.
- No rule that successful PKCE setup, `S256` use, or metadata-confirmed PKCE support stands in for portable proof-of-possession, app trust, issuer trust, approval basis, or account binding.
- No rule that “refused to proceed because PKCE support is absent/unknown” yields a portable deny receipt, auth-result artifact, or durable policy/account truth.
- No shell/helper fallback that quietly converts provider-local PKCE state into verifier relay, callback-state export, auth-resume brokerage, or proof cache authority.

## Why this is worth pinning

The archive already keeps auth continuation, auth proof, auth results, redirect handling, discovery/fetch, and token separation on explicit seams. Current MCP authorization still leaves one nearby pressure surface easy to over-read: clients must implement PKCE, prefer `S256`, verify PKCE support from authorization-server metadata, and refuse to proceed when support is absent or unconfirmed.

That is useful, but it is also exactly where hosts and wrappers start to over-read provider-local code-protection mechanics as durable platform truth. Once that drift lands, PKCE support starts masquerading as a generic trust/capability signal, verifier/challenge material starts masquerading as a reusable continuation or proof object, and “refuse to proceed without PKCE” starts masquerading as a portable auth-policy verdict.

Pinning the boundary now keeps the archive honest. Imported MCP PKCE handling may remain a provider-local way to protect one authorization-code path, but it does not get to redefine what proofs, continuations, approval basis, auth results, or account truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with PKCE-heavy OAuth/MCP providers, but verifier/challenge state and PKCE-support checks still do not become portable proof, callback, or account truth.
- **Cloud micro-VM substrate (B):** hosted agents may touch many provider-specific PKCE conventions, but those mechanics do not become a tenant-stable verifier broker or app-trust substrate.
- **Embedded / separation appliance (C):** appliances can omit dynamic authorization-code flows entirely or terminate them in a narrow provider shim without importing a generic PKCE/verifier/proof story they do not want.
- **Agent/automation OS (D):** this matters most here: imported PKCE helpers must not let agent hosts quietly turn provider-local verifier/challenge/supported-method checks into a second proof/continuation/account substrate beside explicit auth-continuation, auth-proof, and auth-result seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_pkce_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “MCP PKCE handling is not portable verifier/proof truth” posture drifts (**EVID-2026-680**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-RFC7636-PKCE`
- `REF-RFC8414-AS-METADATA`
