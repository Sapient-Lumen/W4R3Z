# CH-NETREQ v0: network lease request (optional; D-NETLEASE)

Purpose: a **bounded, normalized request descriptor** for obtaining a scoped outbound-network lease from the network portal.

CH-NETREQ is a stable, digestable input for **LLM-proposed / validator-executed** network lease issuance:
- ACP proposals bind `netreq_digest = digest(CH-NETREQ v0)`.
- Validators verify the request shape (fail closed) and invoke the portal using explicit capabilities.
- The portal returns a **CH-NETLEASE v0** descriptor (bounds receipt) plus an opaque network authority handle.

This schema is **not** authority and MUST NOT contain bearer capability material.

Related:
- `network-lease-schema-v0.md` (CH-NETLEASE v0)
- D-NETLEASE: `docs/30-architecture/decision-map.md`
- Portal family: `docs/30-architecture/portal-family-registry.md` (`portal.net`)

References: REF-LITTLESNITCH, REF-MACOS-NETWORKEXT, REF-XDG-PORTAL-NETWORKMONITOR.

Posture: `network-lease-posture-v0.md` (Phase 1 meaning; no ambient sockets/DNS when D-NETLEASE enabled).

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected (fail-closed).

## Top-level fields

```text
CH-NETREQ-v0 {
  schema: "CH-NETREQ";
  version: 0;

  # Request identity (for dedupe/replay correlation).
  # Validators/portals MUST treat stable req_id as an exact-replay/dedupe key only; changed canonical CH-NETREQ bytes under one key reject before effect.
  req_id: bytes16;             # random (>=128 bits)

  # Lease class requested (v0 seed).
  kind: enum { connect, listen, dns };

  # Scope requested (portal may clamp or deny by policy).
  scope: enum { internet, local, loopback, explicit };

  # Transport class requested (portal may clamp).
  proto: enum { tcp, udp, tls, quic };

  # Destination predicate (required for connect/listen; optional for dns).
  # NOTE: this is a *policy request*, not a permission grant. For `kind=listen`, `dest` names a local bind/exposure subject rather than a remote DNS predicate. Listen-side `service` labels are local policy metadata, not resolver contracts (`network-request-listen-subject-boundary-v0.md`). For `kind in {connect,listen}` with `dest.kind in {dns_name,dns_suffix,ip_prefix}`, Phase 1 also requires exactly one of `port` or `port_range`; absent numeric ports reject rather than silently inheriting default-port / service-name folklore (`network-lease-port-inference-boundary-v0.md`).
  dest?: {
    kind: enum { dns_name, dns_suffix, ip_prefix, service };

    dns_name?: string;         # bounded exact-byte canonical ASCII DNS name; e.g., "api.example.com"
    dns_suffix?: string;       # bounded exact-byte canonical ASCII suffix; e.g., ".example.com"

    ip_prefix?: {
      family: enum { v4, v6 };
      addr: bytes;             # 4 or 16 bytes
      prefix_len: u16;         # 0..32 or 0..128
    };

    service?: string;          # bounded, policy-resolved stable label (e.g., "updates")

    port?: u16;                # 1..65535
    port_range?: { lo: u16; hi: u16 };
  };

  # Optional bounds (veto-only hints; the portal may clamp or deny).
  bounds?: {
    ttl_s?: u32;               # requested TTL cap; portal clamps
    max_conns?: u32;
    max_bytes?: u64;
    max_seconds?: u32;
    deadline_mono?: u64;       # optional local monotonic deadline (units profile-defined)
  };

  # Optional non-authoritative purpose label (bounded).
  purpose?: string;            # ≤ 96 bytes (e.g., "fetch_updates", "telemetry")

  # Optional export posture hint.
  sensitive?: bool;            # if true, exports are redacted/blocked by CH-OBSPOL profiles
}
```

## Validation rules (summary)
A CH-NETREQ validator MUST be total and fail closed:
1) `schema == "CH-NETREQ"` and `version == 0`.
2) `req_id` is exactly 16 bytes.
3) `kind`, `scope`, and `proto` are allowlisted closed enums.
4) `dest` is required iff `kind` is `connect` or `listen`.
5) If `dest` is present:
   - `dest.kind` selects exactly one predicate form (dns_name | dns_suffix | ip_prefix | service).
   - `dns_name`/`dns_suffix`/`service` are bounded strings.
   - `dns_name` / `dns_suffix` MUST satisfy the Phase 1 exact-byte canonical ASCII DNS profile: lowercase ASCII only; labels are NR-LDH or A-label (`xn--...`); `dns_name` has no trailing dot; `dns_suffix` begins with one leading dot; Unicode U-label input and hidden IDNA / UTS #46 / casefold / trailing-dot normalization reject before effect (`network-lease-name-normalization-boundary-v0.md`).
   - `ip_prefix.addr` length matches `family`, and `prefix_len` is in range.
   - `port` is 1..65535; `port_range.lo <= port_range.hi` and each bound is 1..65535.
   - If `kind in {"connect","listen"}` and `dest.kind in {"dns_name","dns_suffix","ip_prefix"}`, exactly one of `port` or `port_range` MUST be present; omitted numeric ports MUST reject before effect rather than being repaired by default-port / service-name inference (`network-lease-port-inference-boundary-v0.md`).
   - If `kind == "listen"`, `dest.kind` MUST be `ip_prefix` or `service`; `dns_name` / `dns_suffix` listener predicates MUST reject before effect (`network-request-listen-subject-boundary-v0.md`).
   - If `kind == "dns"`, `dest.kind` MUST be `dns_name` or `dns_suffix`; `service` / `ip_prefix` MUST reject, and `port` / `port_range` MUST be absent (`network-lease-dns-query-boundary-v0.md`).
6) If `bounds` is present, each numeric field is bounded/clamped by profile; `deadline_mono` is interpreted as a **veto-only** hint.
7) `purpose` length ≤ 96 bytes.

## Security posture
- CH-NETREQ is **non-authoritative**. It records a request shape for mediation and audit; it never grants network authority.
- The portal selects resolvers/providers and may clamp destinations by policy.
- CH-NETREQ intentionally carries **no** portable `dns_qtype`, `dns_qclass`, `dns_opcode`, `raw_dns_reply`, `rrset`, `dns_message`, `edns`, `dnssec_ok`, `ad_bit`, `cd_bit`, `doh_uri`, `doq_profile`, or `resolver_transport` surface; `kind=dns` stays address-resolution-only unless a future explicit seam pays for it (`network-lease-dns-query-boundary-v0.md`).
- CH-NETREQ intentionally carries **no** portable `search_domains`, `search_path`, `ndots`, `res_search`, `hosts_file_mode`, `nss_hosts_order`, `split_dns_view`, `mdns`, `llmnr`, `bonjour`, or `wins` surface; reviewed name-shaped authority stays exact-predicate-only and host/local name-resolution context stays portal-local unless a future explicit seam pays for it (`network-lease-name-context-boundary-v0.md`).
- CH-NETREQ intentionally carries **no** portable `unicode_host`, `u_label`, `idna_profile`, `uts46`, `nameprep`, `stringprep`, `casefolded_host`, `trailing_dot_ok`, `host_canonicalization`, or `display_host` surface; reviewed name predicates stay one canonical ASCII predicate and Unicode/IDNA/host-normalization behavior stays portal-local unless a future explicit seam pays for it (`network-lease-name-normalization-boundary-v0.md`).
- CH-NETREQ intentionally carries **no** portable `default_port`, `implicit_port`, `uri_scheme`, `scheme_default_port`, `service_name`, `getservbyname`, `well_known_port`, `/etc/services`, or `iana_service_name` surface; numeric endpoint predicates stay explicitly port-shaped and service-name / default-port inference stays portal-local unless a future explicit seam pays for it (`network-lease-port-inference-boundary-v0.md`).
- CH-NETREQ intentionally carries **no** portable `srv_service`, `srv_proto`, `rrtype`, `svcb`, `https_rr`, `service_binding`, `alternate_endpoint`, `ipv4hint`, `ipv6hint`, `echconfig`, `alpn_set`, `port_hint`, `priority`, or `weight` surface; exact name predicates stay host-address-oriented and SRV / SVCB / HTTPS service-binding behavior stays portal-local unless a future explicit seam pays for it (`network-lease-service-binding-boundary-v0.md`).
- CH-NETREQ intentionally carries **no** portable `address_family_preference`, `ipv6_first`, `ipv4_first`, `ipv4_fallback`, `happy_eyeballs`, `racing_delay_ms`, `dns_answer_order`, `candidate_order`, `selected_family`, `selected_ip`, or `addrconfig_mode` surface; exact name predicates stay destination-predicate-only and dual-stack address sorting / racing stays portal-local unless a future explicit seam pays for it (`network-lease-address-selection-boundary-v0.md`).
- CH-NETREQ intentionally carries **no** portable `bound_network` / `network_handle` / `interface_name` / `interface_type` / `required_interface` / `source_ip` / `source_prefix` / `vrf` / `routing_mark` surface; local egress selection remains portal-local unless a future explicit seam pays for it (`network-lease-local-egress-boundary-v0.md`).
- CH-NETREQ intentionally carries **no** portable `available` / `connectivity` / `metered` / `validated` / `captive_portal` / `expensive` / `constrained` / `network_cost` surface; path-property and connectivity-state evaluation stays portal-local unless a future explicit seam pays for it (`network-lease-path-property-boundary-v0.md`).
- CH-NETREQ intentionally carries **no** portable `proxy_uri` / `proxy_list` / `pac_url` / `wpad_status` / `use_system_proxy` surface; proxy selection remains portal-local unless a future explicit seam pays for it (`network-lease-proxy-boundary-v0.md`).
- CH-NETREQ also intentionally carries **no** portable `trust_profile` / `ca_bundle` / `trust_anchor_set` / `verify_hostname` / `cert_exception` / `verify_result` surface; transport verifier policy stays outside leased reachability semantics unless a future explicit seam pays for it (`network-lease-tls-verifier-boundary-v0.md`).
- CH-NETREQ likewise carries **no** portable `client_cert`, `client_cert_alias`, `client_key_ref`, `pkcs11_uri`, `proxy_client_cert`, `tls_client_auth`, or `certificate_bound_token` surface; transport client-auth policy stays outside leased reachability semantics unless a future explicit seam pays for it (`network-lease-client-cert-boundary-v0.md`).
- CH-NETREQ likewise carries **no** portable `alpn`, `alpn_offer`, `selected_alpn`, `app_proto`, `protocol_profile`, `http_version`, `http2`, `http3`, `grpc_profile`, or `webtransport_profile` surface; higher-layer protocol negotiation stays outside leased reachability semantics unless a future explicit seam pays for it (`network-lease-application-protocol-boundary-v0.md`).
- CH-NETREQ likewise carries **no** portable `server_name`, `sni_name`, `sni_disabled`, `tls_name_override`, `public_name`, `ech`, `ech_config`, or `ech_policy` surface; TLS server-name presentation stays outside leased reachability semantics unless a future explicit seam pays for it (`network-lease-server-name-boundary-v0.md`).
- CH-NETREQ likewise carries **no** portable `session_ticket`, `session_ticket_ref`, `psk_identity`, `resumption_secret_ref`, `allow_0rtt`, `early_data_profile`, `resumed_session`, `resume_token`, or `new_token` surface; transport resumption stays outside leased reachability semantics unless a future explicit seam pays for it (`network-lease-session-resumption-boundary-v0.md`).
- CH-NETREQ likewise carries **no** portable `tls_min_version`, `tls_max_version`, `tls_versions`, `tls13_ciphers`, `cipher_suites`, `groups`, `signature_algorithms`, `quic_version`, `quic_versions`, `transport_profile`, `transport_params`, `max_idle_timeout`, `max_udp_payload_size`, `initial_max_data`, or `active_connection_id_limit` surface; TLS/QUIC transport-profile policy stays outside leased reachability semantics unless a future explicit seam pays for it (`network-lease-transport-profile-boundary-v0.md`).
- CH-NETREQ likewise carries **no** portable `bind_hostname`, `listen_hostname`, `publish_dns_name`, `register_service`, `advertise_mdns`, `public_endpoint`, `nat_mapping`, or `loopback_callback` surface; `kind=listen` stays a local bind/exposure subject rather than a hostname/publication/public-endpoint seam unless a future explicit surface pays for it (`network-request-listen-subject-boundary-v0.md`).
- Requests can reveal sensitive intent (destination predicates). Export via IF-OBS should respect CH-OBSPOL and consider hashing/redaction.

ACP integration (optional):
- Network lease requests SHOULD be mediated via ACP kind `portal.net.request`, binding `netreq_digest = digest(CH-NETREQ v0)` and enforcing lane gate `cfg.params.lane.portal.net` fail-closed (PO-ACP-NET-REQUEST; PO-LANE-KILL).
- For retry safety, portals SHOULD dedupe by `req_id` when the kind claims **at-least-once-safe** and SHOULD make duplicate suppression transcript-visible (D-RETRYSAFE).
- Exact replay only: same scoped `req_id` only replays the same canonical CH-NETREQ request, and same scoped `req_id` with different canonical CH-NETREQ bytes MUST reject before effect rather than acting like mutable upsert/replace semantics (`network-request-idempotency-boundary-v0.md`; PO-ACP-NET-REQUEST; PO-RETRY-DEDUP).
- `req_id` is a requester-chosen stable request/dedupe key only; it is NOT a portal-issued CH-NETLEASE handle, connection/session identifier, or proof that a current lease still exists (`network-request-state-posture-v0.md`; I-NETREQ-2).
- Even for name-resolving requests, CH-NETREQ asks for a **predicate** (`dns_name` / `dns_suffix` / `service`) rather than a portable DNS-answer inventory or selected-endpoint receipt; exact answer/path state stays portal-local unless a future explicit surface says otherwise (`network-lease-resolution-boundary-v0.md`).
- Even for name-shaped requests, CH-NETREQ asks for an **exact reviewed predicate** rather than a portable host search-domain / hosts-file / split-DNS / mDNS / LLMNR contract; local name-interpretation context stays portal-local unless a future explicit surface says otherwise (`network-lease-name-context-boundary-v0.md`).
- Even for exact name-shaped requests, CH-NETREQ records one **canonical ASCII predicate** rather than a portable Unicode / IDNA / trailing-dot normalization contract; any ToASCII / UTS #46 / browser-host canonicalization must happen before CH-NETREQ construction or the request rejects (`network-lease-name-normalization-boundary-v0.md`).
- Even for exact name-shaped requests, CH-NETREQ asks for **host-address reachability only** rather than a portable SRV / SVCB / HTTPS service-binding or alternate-endpoint contract; endpoint discovery/binding semantics stay portal-local unless a future explicit surface says otherwise (`network-lease-service-binding-boundary-v0.md`).
- For `kind=dns`, CH-NETREQ stays **address-resolution-only**: `dest`, when present, is name-shaped (`dns_name` / `dns_suffix`) and portless, and Phase 1 exports no RR-type/class/raw-reply/resolver-transport semantics on the leased-network seam (`network-lease-dns-query-boundary-v0.md`).
- For `kind in {connect,listen}` with `dest.kind in {dns_name,dns_suffix,ip_prefix}`, Phase 1 requires explicit numeric `port` or `port_range`; absent numeric ports do not silently inherit URI-scheme defaults or service-name lookup semantics (`network-lease-port-inference-boundary-v0.md`).
- For `kind=listen`, CH-NETREQ `dest` names a local bind/exposure subject only: `dns_name` / `dns_suffix` listener predicates reject, and listen-side `service` labels stay local policy metadata rather than resolver contracts (`network-request-listen-subject-boundary-v0.md`).
