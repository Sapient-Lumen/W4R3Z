# D-LLM MCP-device-authorization import boundary v0 (device auth is not portable cross-device continuation / polling / account truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported OAuth/MCP device-authorization semantics — the discovered `device_authorization_endpoint`, device authorization responses carrying `device_code`, `user_code`, `verification_uri`, optional `verification_uri_complete`, `expires_in`, and `interval`, token polling with the device grant type, and device-flow polling / timeout / denial errors such as `authorization_pending`, `slow_down`, `access_denied`, and `expired_token` — is **provider-local authorization continuation only**. It does **not** create a portable cross-device auth broker, verification-URL handoff plane, polling scheduler/status oracle, linked-account selector, or durable connected-account / login-state substrate on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported device-flow mechanics may be interpreted next to already-pinned auth-discovery, auth-metadata-fetch, auth-request-packaging, auth-continuation, auth-result, account-binding, login-state, and auth-teardown boundaries.

## Posture (v0)

1) **Imported device-authorization endpoints stay provider-local flow-bootstrap endpoints only.**
   - RFC 8628 defines a distinct device authorization endpoint where the client obtains device-flow verification artifacts, and RFC 8414 metadata/discovery is how authorization-server endpoint capabilities are surfaced in current MCP auth deployments.
   - That imported endpoint remains provider-local flow-bootstrap machinery only; it does **not** create a portable “start cross-device auth” API, generic device-linking broker, verification-URL dispatcher, or connected-service control surface on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, and auth-continuation boundaries stay authoritative instead of inheriting platform meaning from one discovered device-flow endpoint.

2) **Imported `device_code` / `user_code` stay provider-local authorization-transaction artifacts only.**
   - RFC 8628 defines `device_code` as the transaction handle used by the polling client and `user_code` as the user-facing code that helps bind one remote user interaction to one constrained-input client request.
   - Those artifacts remain provider-local continuation state only; they do **not** create a portable continuation handle, approval token, account-selection token, or generic auth-resume substrate on existing SlopOS seams.
   - Existing auth-continuation, auth-result, and account-binding boundaries stay authoritative instead of inheriting portable meaning from one provider's device-flow handles.

3) **Imported `verification_uri` / `verification_uri_complete` stay provider-local user-handoff hints only.**
   - RFC 8628 requires `verification_uri`, allows optional `verification_uri_complete`, and says clients MAY present the complete URI non-textually while still showing the `user_code` so the authorization server can confirm the correct device and mitigate phishing/confusion.
   - Those URIs remain provider-local user-handoff hints only; they do **not** create a portable browser-launch obligation, cross-device callback/mailbox plane, approval object, or durable linked-account truth on existing SlopOS seams.
   - Existing auth-link-ui-trigger, browser-session, auth-result, and account-binding boundaries stay authoritative instead of inheriting portable meaning from one provider's verification URL shape.

4) **Imported expiry / interval / polling errors stay provider-local liveness rules only.**
   - RFC 8628 defines `expires_in`, optional `interval`, polling with the device grant type, `authorization_pending`, `slow_down`, `access_denied`, and `expired_token`, and recommends backoff on connection timeouts.
   - Those timing and polling semantics remain provider-local liveness rules only; they do **not** create a portable polling scheduler, queue/status oracle, durable pending-login truth, or login-state substrate on existing SlopOS seams.
   - Existing auth-continuation, login-state, and job/progress-style seams stay authoritative instead of inheriting platform status meaning from one provider's polling contract.

5) **Imported device-flow grant semantics stay provider-local token acquisition only.**
   - RFC 8628 defines token acquisition by polling the token endpoint with `grant_type=urn:ietf:params:oauth:grant-type:device_code` plus the issued `device_code`, after which normal provider token handling continues.
   - That grant semantics remains provider-local token acquisition only; it does **not** create a portable machine-auth mode, background authorization worker, cross-device account broker, or generic “approve on another device then continue here” substrate on existing SlopOS seams.
   - Existing client-credentials, token-passthrough, auth-result, and auth-continuation boundaries stay authoritative instead of inheriting platform meaning from one provider's device-flow token exchange.

6) **No silent cross-device continuation / polling / account widening rides in through device auth.**
   - Imported device-flow handling does **not** authorize generic QR-login brokering, verification-link dispatch, polling delegation, account chooser truth, durable “waiting for approval” state, or transcript-stable cross-device auth receipts by implication.
   - A constrained-input/device flow may help one provider complete one authorization path, but it does **not** standardize portable cross-device auth semantics on adjacent SlopOS seams.
   - If SlopOS ever needs a native reviewed cross-device login broker or pending-auth polling workflow, that work must arrive on those explicit seams and validators directly.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth device-flow helpers, displayed verification URIs, stored `device_code` / `user_code` state, or background polling loops must be killable by policy and must not create authority via hidden paths, env vars, implicit browser launch, or implicit network access.
   - A compat layer that cannot proceed without ambient verification-link dispatch, hidden polling workers, or ambient account/link state must fail closed for portable D-LLM auth semantics.

8) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local device-flow continuation plus explicit reviewed auth-result / account-binding / login-state seams.
   - Any future native cross-device auth / polling workflow must state its own conflict keys, commutativity conditions, serialization point, expiry/replay model, and evidence story explicitly rather than inheriting folklore from imported device-flow polling helpers or verification URLs.

## Phase 1 non-goals (explicitly deferred)

- No portable `device_authorization_endpoint`, `device_code`, `user_code`, `verification_uri`, `verification_uri_complete`, `device_authorization_request`, or equivalent cross-device auth-broker substrate imported directly from MCP/OAuth helpers.
- No rule that `expires_in`, `interval`, polling cadence, `authorization_pending`, `slow_down`, `access_denied`, `expired_token`, or timeout/backoff behavior stand in for portable pending-login truth, queue/progress semantics, or durable login-state/account-state meaning.
- No rule that device-flow verification URLs, QR/NFC presentation shortcuts, or user-code confirmation semantics stand in for portable browser-launch, account-linking, or approval-object semantics.
- No rule that device-flow token polling with `grant_type=urn:ietf:params:oauth:grant-type:device_code` stands in for a portable background auth worker, machine-auth mode, or generic auth-resume substrate.

## Why this is worth pinning

The archive already keeps local auth-continuation export, auth-request packaging, auth-result export, account binding, and login-state on separate explicit seams. Current OAuth/MCP interop adds a nearby pressure surface those docs do not yet pin directly: **device authorization for constrained-input or browser-poor deployments, where the provider returns an explicit cross-device handoff tuple and expects client-side polling until a remote user interaction completes**.

That sounds like an implementation detail, but it is exactly where ambient substrate grows for product shapes C and D. Once the archive permits provider-local device auth, the next convenience instinct is obvious: “just hand the agent the verification URL and user code,” or “let the platform remember the device code and poll until the human approves it elsewhere.” That is smaller than exporting a token set, but it still recreates a generic cross-device auth broker with hidden polling, status, and account-binding implications.

Pinning the boundary now keeps SlopOS honest. Imported device authorization may remain a provider-local way to complete one constrained-input authorization path, but it does not get to redefine cross-device continuation, polling, account truth, or durable login-state semantics on existing SlopOS seams.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may interoperate with providers that prefer device flow for CLI or terminal UX, but provider-local device auth still does not become a generic cross-device login broker, polling daemon, or connected-account truth surface.
- **Cloud micro-VM substrate (B):** hosted agents and workers avoid inheriting fake pending-login schedulers or polling/status semantics just because one provider uses a constrained-input auth flow.
- **Embedded / separation appliance (C):** this matters strongly here: appliance builds can support narrow constrained-input/provider-owned login continuation where needed without importing a generalized cross-device auth broker they do not want.
- **Agent/automation OS (D):** this matters most here: imported verification URLs, user codes, and device-code polling may help one provider-owned auth path proceed, but they do not become a second durable auth-resume/account-state substrate beside explicit auth-continuation, auth-result, account-binding, and login-state seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_device_authorization_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “device auth is not portable cross-device continuation / polling / account truth” posture drifts (**EVID-2026-690**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-RFC8628-DEVICE-GRANT`
- `REF-RFC8414-AS-METADATA`
