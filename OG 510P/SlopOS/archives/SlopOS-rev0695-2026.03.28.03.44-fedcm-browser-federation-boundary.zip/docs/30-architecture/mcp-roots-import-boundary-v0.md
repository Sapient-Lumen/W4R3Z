# D-LLM MCP-roots import boundary v0 (roots are not portable filesystem grant or inventory truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam: current MCP roots (`roots/list`, `notifications/roots/list_changed`, exact `Root.uri`, and optional `Root.name`) are **provider-local / request-local workspace hints only**. They do **not** create a portable filesystem grant, directory chooser result, recursive inventory/watch plane, import-to-docref shortcut, or current-workspace oracle on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP roots semantics may be interpreted next to already-pinned file/document/consent/import seams.

This doc is an **intentional singleton** today. It is listed in `boundary-family-map.md` until a broader reviewed imported-filesystem-context family exists.

## Posture (v0)

1) **No portable filesystem grant or chooser-result substrate in imported MCP roots.**
   - MCP `roots/list` responses and `notifications/roots/list_changed` remain **provider-local / request-local protocol mechanics** on **D-LLM**.
   - They may help a host or provider scope one workspace-style interaction, but they do **not** by themselves mint a reviewed `portal.file` chooser result, a D-POWERBOX designation, a CH-DOCREF, or any other portable local-object authority on SlopOS seams.

2) **Root URIs are scope hints only, not portable handles or authority carriers.**
   - In the current MCP specification, each root is represented by a `file://` `uri` plus an optional human-readable `name`.
   - Those fields may describe where a provider thinks it may operate locally, but they do **not** become portable host paths, capability handles, docrefs, persistent bookmarks, attachment grants, or import tokens on existing SlopOS seams.

3) **Root boundaries do not outrun explicit file/document mediation.**
   - A provider may locally validate candidate paths against roots it was given, but imported roots do **not** by themselves authorize descendant reads, directory traversal, sibling enumeration, recursive watch, background sync, or later reopen rights.
   - Actual file/document authority still arrives only through explicit reviewed seams such as D-POWERBOX / `portal.file.*`, explicit D-CAPX import, or the exact import-to-docref bridge.

4) **Root-list change signals do not widen into durable inventory or current-state truth.**
   - `notifications/roots/list_changed` may tell a provider that its current workspace-hint set changed.
   - That signal does **not** become a portable directory inventory feed, durable watch registration, current-root oracle, or transcript-stable claim that the same roots or descendants remain available now.

5) **No silent import/materialization/docref folklore.**
   - Imported roots are **not** an alternate file picker, **not** a hidden “approve this workspace” grant, and **not** a shortcut to mint CH-DOCREF or bypass quarantine-first materialization.
   - If bytes or objects discovered under a provider-local root need routine document semantics, they still cross explicit local mediation and the reviewed import/materialization seams rather than inheriting authority from the root hint itself.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: exact reviewed chooser/import/document actions and their existing request keys / serialization boundaries.
   - Any future reviewed portable workspace-root or filesystem-context family must state its own conflict keys, commutativity conditions, retention/watch model, privacy rules, and evidence story explicitly rather than inheriting folklore from MCP roots.

## Phase 1 non-goals (explicitly deferred)

- No portable `workspace_root`, `root_handle`, `root_watch`, `root_inventory`, `root_snapshot`, or `current_root` substrate imported directly from MCP roots.
- No rule that `file://` root URIs or optional root names can stand in for `portal.file.*` chooser results, CH-DOCREF, security-scoped bookmarks, attachment grants, or import tokens.
- No adapter shortcut that treats imported roots as permission to recursively read descendants, enumerate siblings, watch for changes, or mint durable reopen handles.
- No transcript-stable statement that a provider-local roots list created durable workspace binding, current availability truth, or a second file/document authority plane on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps file/document authority explicit: D-POWERBOX mediation is chooser-owned, CH-DOCREF is non-bearer reopen only, and bearer/import flows must materialize a fresh local object before routine document semantics begin. MCP now standardizes a tempting nearby convenience surface: clients can expose filesystem “roots” to servers, roots are typically chosen through workspace/project UI, servers can request the list and receive change notifications, and the current spec says each root is a `file://` URI.

That is useful, but it is also exactly where hosts, wrappers, and agents start to smuggle in a second file-authority story. Once a provider can say “this is my current root” or “the roots list changed,” those hints quickly get treated as if they were approved directory mounts, durable workspace binding, or permission to skip explicit file/document mediation.

Pinning the boundary now keeps the archive honest. Imported MCP roots may remain a local protocol/runtime convenience around one provider-owned workspace interaction, but they do not get to redefine what filesystem authority, chooser results, document handles, or current workspace truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** local tools may receive workspace hints without silently acquiring approved directory mounts, recursive document grants, or durable workspace bindings outside explicit chooser/document workflows.
- **Cloud micro-VM substrate (B):** hosted agents may use provider-local roots as narrow planning context without turning them into tenant-visible file inventories, import shortcuts, or current-workspace truth.
- **Embedded / separation appliance (C):** appliance builds can ignore MCP roots entirely or map them to local policy hints without promising a portable filesystem grant or watch plane.
- **Agent/automation OS (D):** agents may observe provider-local workspace hints, but real file/document authority still returns through explicit reviewed seams rather than drifting into workspace-root folklore.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam; the current cut is only the narrow MCP-roots import boundary.

If a second closely related imported-filesystem-context boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/powerbox-posture-v0.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `docs/30-architecture/import-to-docref-boundary-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_roots_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “roots are not portable filesystem grant or inventory truth” posture drifts (**EVID-2026-664**).

## References

- `REF-MCP-ROOTS`
- `REF-MCP-SPEC`
