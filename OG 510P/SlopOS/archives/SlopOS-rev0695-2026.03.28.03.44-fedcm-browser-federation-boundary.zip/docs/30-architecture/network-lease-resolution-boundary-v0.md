# D-NETLEASE network-resolution boundary v0 (no portable resolved-answer / endpoint-selection seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: leased networking records the granted **destination predicate** and **resolver binding**, but it does **not** become a portable resolved-address set, selected-endpoint, route-selection, or live path-telemetry surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

1) **No portable resolved-answer / endpoint-selection seam in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry the requested/granted **predicate** (`dest`) plus the granted **resolver binding** (`resolver`).
   - They do **not** grow a portable `resolved_addrs`, `answer_set`, `selected_addr`, `selected_endpoint`, `dns_rcode`, `cname_chain`, `ttl_remaining`, `network_id`, `interface_id`, `route_label`, `proxy_path`, or equivalent export surface.
   - Phase 1 portable truth is therefore: **what destination predicate was reviewed/granted, and which resolver strategy bound that lease** — not which exact address/path choice happened at one moment inside the portal.

2) **Resolver binding is portable; answer selection stays portal-local.**
   - CH-NETLEASE already carries `resolver.kind="portal"` for any name-resolving lease.
   - That is the portable evidence we need in v0: name resolution is explicit, policy-owned, and non-ambient.
   - It is **not** a promise that the portal will export or freeze the exact DNS answer set, chosen A/AAAA ordering, Happy-Eyeballs race outcome, selected proxy, or concrete route/interface decision as transcript-stable product truth.
   - Repeated uses of the same lease may therefore reach different concrete endpoints over time while still remaining inside the same granted predicate and resolver policy.

3) **Current answer/path state is live service state, not descriptor truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove what addresses the resolver would return now, which address/path a connection attempt used, whether the same path is still available, or whether a different route/network object would now be selected under current portal policy.
   - This is the same discipline SlopOS already uses elsewhere: request/receipt artifacts are stable evidence of a reviewed action, not a portable oracle for mutable owner-local live state.

4) **If exact DNS answers or route evidence ever matter, pay for a new seam explicitly.**
   - A future reviewed product need may want explicit DNS-answer artifacts, transport-path proofs, or route-observation receipts.
   - That work must return **RFC-first** with its own schema/receipt family, redaction story, commutativity/conflict-key contract, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETLEASE, CH-ACPOUT `receipt_refs`, or `portal.net.request` outcomes just because real ecosystems expose route/network objects or resolver APIs internally.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit DNS-answer or route-observation seam must state its own conflict keys, commutativity, and evidence/test story rather than inheriting folklore from operating-system network APIs.

6) **Sealed compat remains killable and non-ambient.**
   - Compat layers do not regain a hidden “tell me the current resolved addresses / route / interface / proxy path” side channel through host helper fallbacks, resolver cache scraping, or process-global network objects.
   - If compat ever needs reviewed answer/path observation, it still pays for an explicit future seam instead of widening D-NETLEASE in place.

## Phase 1 non-goals (explicitly deferred)

- No portable `resolved_addrs`, `answer_set`, `selected_addr`, or `selected_endpoint` field on CH-NETLEASE.
- No portable DNS-answer receipt surface on `portal.net.request` or CH-ACPOUT.
- No portable `network_id`, `interface_id`, `route_label`, `proxy_path`, or equivalent current-path export seam on D-NETLEASE.
- No hidden resolver-cache, routing-table, or host-network-object fallback that lets leased networking smuggle ambient path telemetry back into reviewed automation.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS. The next subtle drift risk is narrower: once the lease carries a destination predicate and explicit resolver binding, it becomes tempting to treat the lease descriptor as if it also ought to expose the resolver’s current answer set or the transport stack’s current path choice.

That would quietly widen a compact authority seam into an observation and topology seam. It would also create privacy/export pressure exactly where the archive is trying to stay digest-first and redaction-first. Pinning the boundary now keeps all four product shapes honest: workstation and agent flows keep explicit egress without acquiring a fake route-telemetry API; hosted compute avoids pretending that transient network-object identity is transcript-stable; and embedded/separation profiles do not have to standardize a path-observation plane just because explicit name resolution exists.

## Profile effect (A–D)

- **Secure workstation (A):** explicit egress remains usable without turning every lease into a browser-style or system-network path telemetry object.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound authority explicit while avoiding fake stable route/network-object claims across churn, failover, or reconnect.
- **Embedded / separation appliance (C):** appliance builds can allow tightly bounded egress without paying for a portable DNS-answer or route-observation API they do not actually want to support.
- **Agent/automation OS (D):** automation gets one narrow reviewed egress seam; agents cannot confuse “lease to this predicate” with “portable current answer/path telemetry.”

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/network-request-state-posture-v0.md`
  - `docs/30-architecture/lease-descriptor-state-boundary-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETLEASE-VALIDATE**, **PO-NETLEASE-DNSBIND**)

CI drift gate:
- `tools/check_network_lease_resolution_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **predicate+resolver portable / answer+path portal-local / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-630**).

## References

- REF-FREEBSD-CAP-DNS.
- REF-XDG-PORTAL-REQUEST.
- REF-ANDROID-READ-NETWORK-STATE.
