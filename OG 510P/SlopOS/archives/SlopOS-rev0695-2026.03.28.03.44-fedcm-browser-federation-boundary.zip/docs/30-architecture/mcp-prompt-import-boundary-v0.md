# D-LLM MCP-prompt import boundary v0 (prompt templates are not workflow/policy truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-PLUMB / IF-ACP** seam: current MCP prompts (`prompts/list`, `prompts/get`, optional `notifications/prompts/list_changed`, prompt metadata/arguments, returned `PromptMessage`s, and embedded resources) are **provider-local proposal material only**. They do **not** create a portable command/workflow plane, prompt-policy plane, approval basis, account/payer binding plane, or hidden resource/file/document grant on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP prompt-template semantics may be interpreted next to already-pinned LLM, workflow, consent, and document/import cuts.

This doc is an **intentional singleton** today. It is listed in `boundary-family-map.md` until a broader reviewed imported-prompt family exists.

## Posture (v0)

1) **No portable workflow or policy plane in imported MCP prompts.**
   - `prompts/list`, `prompts/get`, prompt `name` / `title` / `description`, prompt `arguments`, returned `messages`, and optional prompt `icons` remain **provider-local proposal/catalog material** on **D-LLM / D-PLUMB / IF-ACP**.
   - They may help a host expose slash-command-like UX, quick-start templates, or reusable drafting context, but they do **not** by themselves grant permission, define local workflow kinds, override local policy, bind approvals, select a payer/account, widen accepted action schema/field sets, or mint a reviewed command surface on existing SlopOS seams.

2) **Prompt catalogs and list-change notices are not durable command registration or push control planes.**
   - `prompts/list` and `notifications/prompts/list_changed` may help one host refresh its local view of available templates.
   - They do **not** become a portable command registry, durable slash-command installation plane, background push channel, callback/mailbox surface, or hidden hot-update authority.
   - A newly listed prompt name therefore does not itself create a reviewed action, a remembered consent, or a stable local automation primitive.

3) **Prompt messages stay descriptive proposal material, not authority or receipt truth.**
   - Returned `PromptMessage.role` values (`user` / `assistant`), text/image/audio content, optional annotations, and embedded resource payloads may inform drafting, review, or local proposal construction.
   - They do **not** become trusted system policy, transcript authority, approval basis, workflow-completion receipts, current provider-owned live-state truth, or a substitute for explicit SlopOS evidence artifacts.
   - Embedded prompt resources likewise remain exact imported bytes for one provider-owned prompt response; they do **not** by themselves grant filesystem/document authority, durable file handles, recursive resource inventory, or import-to-docref shortcuts.

4) **Prompt arguments are local inputs, not hidden selector truth.**
   - Prompt argument schemas and values may help a host gather user-supplied parameters for one template invocation.
   - Provider-side argument suggestion helpers such as MCP `completion/complete` stay separately pinned in `mcp-completion-import-boundary-v0.md` as provider-local suggestion mechanics only.
   - They do **not** become hidden payer/account selectors, hidden path/document grants, hidden approval parameters, or validator-only fields that bypass existing reviewed seams.
   - Hosts and adapters must therefore not treat prompt arguments or provider-suggested defaults as durable local configuration, capability selection, or policy truth.

5) **No auto-run or nested-authority folklore from prompt retrieval.**
   - Retrieving a prompt template does **not** itself authorize tool execution, browser/session actions, secret ingress, background work, or any other effectful follow-on behavior.
   - If a host later chooses to act on prompt-derived text, that later effect must still cross an explicit reviewed seam with its own schema, validators, policy, receipts, conflict keys, and evidence hooks.
   - This keeps Hybrid + commutativity honest: imported prompt templates may shape proposal text, but they do not smuggle hidden action semantics or serialization rules into existing externally visible operations.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: exact reviewed actions, explicit workflow/portal seams, explicit receipts, and explicit evidence artifacts.
   - Any future reviewed portable prompt/workflow family must state its own conflict keys, commutativity conditions, serialization point, approval semantics, and evidence story explicitly rather than inheriting folklore from MCP prompt templates.

## Phase 1 non-goals (explicitly deferred)

- No portable `prompt_install`, `prompt_enable`, `prompt_run`, `slash_command_registry`, `template_policy`, or equivalent substrate imported directly from MCP prompts.
- No rule that imported prompt names, titles, descriptions, or icons can stand in for approved local commands, durable automation macros, or remembered consent.
- No rule that prompt messages, assistant-role content, annotations, or embedded resources can stand in for local system prompt policy, approval basis, file/document authority, or workflow-completion receipts.
- No adapter shortcut that quietly turns prompt retrieval into automatic tool execution, browser/session control, secret ingress, background work, or validator-only hidden fields.

## Why this is worth pinning

The archive already says text cannot create authority, prompt templates and descriptions are non-authoritative, rendered tool UI cannot regrow a hidden action plane, and imported tool/result metadata do not become approval or evidence truth. MCP prompts are the next obvious convenience surface: a server can expose named templates, surface them like slash commands, accept arguments, return structured messages, and even embed provider-managed resources directly into the resulting conversation material.

That is useful, but it is also exactly where hosts and agent wrappers start to slide from “template for user-controlled drafting” into “remote workflow someone else registered for me.” Once that drift lands, prompt names and prompt-returned messages begin to masquerade as stable local commands, policy bundles, or hidden action parameters.

Pinning the boundary now keeps the archive honest. Imported MCP prompts may remain a local UX and drafting convenience, but they do not get to redefine what reviewed workflow kinds, approvals, transcript truth, file/document authority, or policy mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may expose provider prompt templates as slash commands or drafting aids without silently importing a second command/install/policy plane.
- **Cloud micro-VM substrate (B):** hosted agents avoid mistaking provider-owned prompt catalogs for tenant-stable workflow primitives, approval shortcuts, or file/document authority.
- **Embedded / separation appliance (C):** appliance builds can omit prompt UX entirely or surface local templates without promising portable remote prompt/workflow semantics.
- **Agent/automation OS (D):** agents may inspect or reuse provider prompt material, but reviewed action, approval, and evidence truth still lives on explicit SlopOS seams rather than drifting into template folklore.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam; the current cut is only the narrow MCP-prompt import boundary.

If a second closely related imported-prompt boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_prompt_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “prompt templates are not workflow/policy truth” posture drifts (**EVID-2026-666**).

## References

- `REF-MCP-PROMPTS`
- `REF-MCP-SPEC`
