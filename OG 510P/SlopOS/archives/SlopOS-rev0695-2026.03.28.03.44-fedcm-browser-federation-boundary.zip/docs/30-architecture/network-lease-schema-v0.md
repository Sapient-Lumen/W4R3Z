# CH-NETLEASE v0: Network lease descriptor

Purpose: a redaction-safe, audit-friendly descriptor for **scoped network authority** granted by a network portal (D-NETLEASE).
This schema is **not** the authority itself; it describes the bounds of a capability (e.g., a `NetDialer`/`NetListener` handle).

References: REF-LITTLESNITCH, REF-MACOS-NETWORKEXT, REF-XDG-PORTAL-NETWORKMONITOR.

Posture: `network-lease-posture-v0.md` (Phase 1 meaning; no ambient sockets/DNS).

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-NETLEASE v0 := {
  v: 0,

  kind: tstr,                ; closed enum: "connect" | "listen" | "dns"

  scope: tstr,               ; closed enum: "internet" | "local" | "loopback" | "explicit"

  proto: tstr,               ; closed enum: "tcp" | "udp" | "tls" | "quic"

  ; destination predicate (required for connect/listen; optional for dns)
  ; for `kind="listen"`, `dest` names a local bind/exposure subject rather than a remote DNS predicate or publication target
  dest?: {
    kind: tstr,              ; closed enum: "dns_name" | "dns_suffix" | "ip_prefix" | "service"

    dns_name?: tstr,         ; exact-byte canonical ASCII DNS name; e.g., "api.example.com" (bounded)
    dns_suffix?: tstr,       ; exact-byte canonical ASCII suffix; e.g., ".example.com" (bounded)

    ip_prefix?: {
      family: tstr,          ; "v4" | "v6"
      addr: bstr,            ; 4 or 16 bytes
      prefix_len: uint,      ; 0..32 or 0..128
    },

    service?: tstr,          ; policy-resolved stable label (e.g., "updates"), bounded; not a portable service-name lookup

    port?: uint,             ; 1..65535
    port_range?: { lo: uint, hi: uint },
  },

  ; resolver binding (required for any name-resolving lease; v0 only admits portal)
  resolver?: {
    kind: tstr,              ; closed enum: "portal"
    label?: tstr,            ; bounded, non-authoritative (e.g., "default", "corp")
  },

  ; lifetime
  issued_at_s: uint,         ; monotonic time or policy-defined epoch seconds
  ttl_s: uint,               ; lease duration (portal may clamp)

  ; optional budget limits
  budget?: {
    max_conns?: uint,
    max_bytes?: uint,
    max_seconds?: uint,
  },

  ; stable identifiers for attribution (no secrets)
  origin: {
    comp_id: tstr,           ; canonical component name/id (e.g., CH-COMP name), bounded
    instance?: tstr,         ; optional instance label (bounded)
  },

  purpose?: tstr,            ; bounded, non-authoritative note; for UI/audit only

  redaction?: {
    mode: tstr,              ; closed enum: "none" | "dest_hash" | "drop_dest"
    dest_hash?: bstr,        ; if mode==dest_hash: digest of canonical dest predicate
  }
}

Notes:
- `redaction` exists because destinations can be sensitive in some settings; export tools may choose to hash or drop the destination predicate.
- `service` is a *policy label*; the lease descriptor does not embed a mutable endpoint list.
- Historical CH-NETLEASE bytes remain exact issued-bounds evidence only; they do **not** by themselves prove that a corresponding lease is still active/unexpired/unrevoked now (`lease-descriptor-state-boundary-v0.md`).
- `resolver` binds the name-resolution strategy for the lease. v0 only admits `resolver.kind="portal"` (no ambient resolvers). Listen-side `service` labels do not by themselves create resolver semantics (`network-request-listen-subject-boundary-v0.md`).
- CH-NETLEASE does **not** export a portable `resolved_addrs` / selected-endpoint / route-selection seam; the descriptor carries the granted predicate plus resolver binding, while exact answer/path state stays portal-local unless a future explicit surface pays for it (`network-lease-resolution-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `dns_qtype`, `dns_qclass`, `dns_opcode`, `raw_dns_reply`, `rrset`, `dns_message`, `edns`, `dnssec_ok`, `ad_bit`, `cd_bit`, `doh_uri`, `doq_profile`, or `resolver_transport` seam; `kind=dns` stays address-resolution-only rather than a transcript-stable generic DNS query/export result (`network-lease-dns-query-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `search_domains`, `search_path`, `ndots`, `res_search`, `hosts_file_mode`, `nss_hosts_order`, `split_dns_view`, `mdns`, `llmnr`, `bonjour`, or `wins` seam; exact reviewed name predicates do not become a transcript-stable host search-path / local-name-resolution contract (`network-lease-name-context-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `unicode_host`, `u_label`, `idna_profile`, `uts46`, `nameprep`, `stringprep`, `casefolded_host`, `trailing_dot_ok`, `host_canonicalization`, or `display_host` seam; exact reviewed name predicates do not become a transcript-stable Unicode / IDNA / normalization contract (`network-lease-name-normalization-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `srv_service`, `srv_proto`, `rrtype`, `svcb`, `https_rr`, `service_binding`, `alternate_endpoint`, `ipv4hint`, `ipv6hint`, `echconfig`, `alpn_set`, `port_hint`, `priority`, or `weight` seam; exact reviewed name predicates do not become a transcript-stable SRV / SVCB / HTTPS service-binding or alternate-endpoint contract (`network-lease-service-binding-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `default_port`, `implicit_port`, `uri_scheme`, `scheme_default_port`, `service_name`, `getservbyname`, `well_known_port`, `/etc/services`, or `iana_service_name` seam; connect/listen host-or-IP predicates stay explicitly port-shaped and do not become a transcript-stable default-port / service-name contract (`network-lease-port-inference-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `address_family_preference`, `ipv6_first`, `ipv4_first`, `ipv4_fallback`, `happy_eyeballs`, `racing_delay_ms`, `dns_answer_order`, `candidate_order`, `selected_family`, `selected_ip`, or `addrconfig_mode` seam; exact reviewed name predicates do not become a transcript-stable IPv4 / IPv6 preference / Happy-Eyeballs / answer-ordering contract (`network-lease-address-selection-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `bound_network` / `network_handle` / `interface_name` / `interface_type` / `required_interface` / `source_ip` / `source_prefix` / `vrf` / `routing_mark` seam; local interface / source-address / VRF selection stays portal-local rather than transcript-stable descriptor truth (`network-lease-local-egress-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `available` / `connectivity` / `metered` / `validated` / `captive_portal` / `expensive` / `constrained` / `network_cost` seam; current path-property and connectivity-state hints stay portal-local rather than transcript-stable descriptor truth (`network-lease-path-property-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `proxy_uri` / `proxy_list` / `pac_url` / `wpad_status` / `use_system_proxy` seam; proxy policy stays portal-local rather than transcript-stable descriptor truth (`network-lease-proxy-boundary-v0.md`).
- CH-NETLEASE likewise does **not** export a portable `trust_profile` / `ca_store` / `trust_anchor_set` / `verify_hostname` / `cert_exception` / `verify_result` seam; `tls` / `quic` reachability does not by itself define a transcript-stable transport-verifier policy or certificate verdict (`network-lease-tls-verifier-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `client_cert`, `client_cert_alias`, `client_key_ref`, `pkcs11_uri`, `proxy_client_cert`, `tls_client_auth`, or `certificate_bound_token` seam; `tls` / `quic` reachability does not by itself define a transcript-stable client-auth identity or certificate-bound-token result (`network-lease-client-cert-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `alpn`, `alpn_offer`, `selected_alpn`, `app_proto`, `protocol_profile`, `http_version`, `http2`, `http3`, `grpc_profile`, or `webtransport_profile` seam; `tls` / `quic` reachability does not by itself define a transcript-stable application-protocol negotiation result (`network-lease-application-protocol-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `server_name`, `sni_name`, `sni_disabled`, `tls_name_override`, `public_name`, `ech`, `ech_config`, or `ech_policy` seam; `tls` / `quic` reachability does not by itself define a transcript-stable TLS server-name / public-name / ECH result (`network-lease-server-name-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `session_ticket`, `session_ticket_ref`, `psk_identity`, `resumption_secret_ref`, `allow_0rtt`, `early_data_profile`, `resumed_session`, `resume_token`, or `new_token` seam; `tls` / `quic` reachability does not by itself define a transcript-stable transport-resumption or early-data result (`network-lease-session-resumption-boundary-v0.md`).
- CH-NETLEASE also does **not** export a portable `tls_min_version`, `tls_max_version`, `tls_versions`, `tls13_ciphers`, `cipher_suites`, `groups`, `signature_algorithms`, `quic_version`, `quic_versions`, `transport_profile`, `transport_params`, `max_idle_timeout`, `max_udp_payload_size`, `initial_max_data`, or `active_connection_id_limit` seam; `tls` / `quic` reachability does not by itself define a transcript-stable negotiated TLS/QUIC transport-profile result (`network-lease-transport-profile-boundary-v0.md`).
- CH-NETLEASE likewise does **not** export a portable `bind_hostname`, `listen_hostname`, `publish_dns_name`, `register_service`, `advertise_mdns`, `public_endpoint`, `nat_mapping`, or `loopback_callback` seam; `kind=listen` stays a local bind/exposure subject rather than a hostname/publication/public-endpoint receipt (`network-request-listen-subject-boundary-v0.md`).

## Validation rules (minimum)
A CH-NETLEASE validator MUST be total and fail closed:
1) `v == 0`.
2) `kind`, `scope`, `proto` are allowlisted closed enums.
3) `issued_at_s` and `ttl_s` are present and bounded; `ttl_s` is clamped by profile.
4) `dest` is required iff `kind` is "connect" or "listen".
5) If `dest` is present, `dest.kind` selects exactly one predicate form (dns_name | dns_suffix | ip_prefix | service), and ports/ranges/prefixes are valid and bounded. If `kind in {"connect","listen"}` and `dest.kind in {"dns_name","dns_suffix","ip_prefix"}`, exactly one of `port` or `port_range` MUST be present; omitted numeric ports reject rather than being repaired by default-port / service-name inference (`network-lease-port-inference-boundary-v0.md`). If `kind == "listen"`, `dest.kind` MUST be `ip_prefix` or `service`; `dns_name` / `dns_suffix` listener predicates reject (`network-request-listen-subject-boundary-v0.md`). If `kind == "dns"`, `dest.kind` MUST be `dns_name` or `dns_suffix`; `service` / `ip_prefix` reject and `port` / `port_range` are absent (`network-lease-dns-query-boundary-v0.md`). Name-shaped `dns_name` / `dns_suffix` values MUST satisfy the Phase 1 exact-byte canonical ASCII DNS profile: lowercase ASCII only; labels are NR-LDH or A-label (`xn--...`); `dns_name` has no trailing dot; `dns_suffix` begins with one leading dot; Unicode U-label input and hidden IDNA / UTS #46 / casefold / trailing-dot normalization reject (`network-lease-name-normalization-boundary-v0.md`).
6) `resolver` is required iff the lease can resolve names:
   - `kind == "dns"`, OR
   - `kind == "connect"` and `dest.kind in {"dns_name","dns_suffix","service"}`.
7) If `resolver` is present, `resolver.kind` MUST be "portal" (v0 posture) and `label` is bounded.
8) `origin.comp_id` is present and bounded; unknown fields reject (or are rejected by canonical CBOR decode).
9) If `redaction.mode != "none"`, either `dest` is absent (drop_dest) or `dest_hash` present (dest_hash).

## Privacy notes
CH-NETLEASE may reveal user/application intent via destinations. Export via IF-OBS should apply redaction by default (C-OBS-1) and prefer `dest_hash` unless explicit authorization exists.
