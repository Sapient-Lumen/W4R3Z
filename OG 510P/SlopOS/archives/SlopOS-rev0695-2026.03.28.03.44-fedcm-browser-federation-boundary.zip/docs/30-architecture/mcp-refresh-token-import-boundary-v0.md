# D-LLM MCP-refresh-token import boundary v0 (`offline_access` / refresh tokens are not portable durable auth/session truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported OAuth/MCP refresh-token material — `refresh_token`, `grant_type=refresh_token`, `offline_access`, refreshed token-set metadata such as replacement refresh tokens / returned scope / expiry fields, and client-side token caching around those artifacts — is **provider-local renewal mechanics and provider-owned live auth state only**. It does **not** create a portable offline-access grant, background-renewal scheduler, durable login/account truth, connected-account substrate, or generic external-token vault on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported refresh-token and offline-access semantics may be interpreted next to already-pinned auth-result, token-passthrough, ID-JAG, authorization-context, login-state, and account-binding boundaries.

## Posture (v0)

1) **Imported `refresh_token` stays provider-local renewal credential only.**
   - RFC 6749 defines refresh tokens as credentials used to obtain new access tokens, requires them to be kept confidential, and requires the authorization server to maintain the binding between a refresh token and the client to whom it was issued.
   - Imported `refresh_token` material therefore remains provider-local renewal credential state only; it does **not** become a portable durable login handle, connected-account artifact, generic secret object, or reusable external-service credential on existing SlopOS seams.
   - Existing auth-result, token-passthrough, vault, and login-state boundaries stay authoritative instead of inheriting platform meaning from one provider's refresh-token handling.

2) **Imported `offline_access` stays provider-local absent-user consent only.**
   - OpenID Connect Core defines `offline_access` as a scope value requesting a Refresh Token that can be used even when the end user is not present, with explicit consent requirements.
   - Imported `offline_access` remains provider-local consent and issuance guidance only; it does **not** become a portable unattended-execution permission, background-job approval, or generic durable-delegation policy bit on existing SlopOS seams.
   - Existing volition, jobs, background-lease, and approval-basis seams stay authoritative instead of inheriting durable meaning from one provider's offline-access scope handling.

3) **Imported `grant_type=refresh_token` stays provider-local renewal path only.**
   - OAuth refresh grants let a client present a refresh token back to the authorization server in exchange for a fresh access token (and sometimes a replacement refresh token).
   - That exchange remains provider-local token renewal only; it does **not** become a portable background-renewal API, queueable token-maintenance action, or generic session-resume workflow on existing SlopOS seams.
   - Existing jobs/background seams and explicit auth-result boundaries stay authoritative instead of inheriting platform meaning from one provider's token-refresh loop.

4) **Imported refresh-token rotation / replay defenses stay provider-local breach handling only.**
   - RFC 9700 treats refresh tokens as high-value credentials and requires public-client deployments to sender-constrain refresh tokens or use refresh-token rotation to detect replay.
   - Imported rotation, replay detection, inactivity expiry, and security-event revocation semantics remain provider-local compromise-handling machinery only; they do **not** become a portable replay ledger, current-session oracle, or durable risk/verdict surface on existing SlopOS seams.
   - Existing auth-proof, auth-teardown, login-state, and evidence seams stay authoritative instead of inheriting durable truth from one provider's refresh-token replay controls.

5) **Imported refreshed token-set metadata stays provider-owned live state only.**
   - MCP/OAuth flows may return refreshed access-token metadata such as `expires_in`, returned `scope`, and replacement refresh tokens, and clients may cache those artifacts locally to continue one provider-owned session.
   - Those returned fields and caches remain provider-owned live state only; they do **not** become a portable grant inventory, durable login-state receipt, connected-service registry, or reusable token wallet on existing SlopOS seams.
   - Existing authorization-context, login-state, account-binding, and token-passthrough boundaries stay authoritative instead of inheriting durable platform meaning from one provider's token cache rows.

6) **No silent background-renewal or durable auth continuity rides in through refresh tokens.**
   - Imported refresh-token / offline-access semantics do **not** authorize silent token refresh daemons, generic third-party account continuity, hidden token-wallet persistence, or durable per-agent/per-tool auth caches by implication.
   - A provider may cache and refresh one token set for one auth path, but that does **not** standardize a portable background-renewal substrate or durable connected-account story on adjacent SlopOS seams.
   - If SlopOS ever needs reviewed offline delegation or native token-renewal workflows, that work must arrive on explicit seams with their own approval, conflict-key, storage, and evidence story.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of OAuth SDK token caches, refresh-token storage helpers, or background renewal loops must be killable by policy and must not create authority via hidden paths, env vars, or implicit network access.
   - A compat layer that cannot proceed without ambient token caches, implicit refresh daemons, or hidden durable auth state must fail closed for portable D-LLM semantics.

8) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: provider-local token issuance/refresh, explicit auth-result and login-state seams, and explicit evidence artifacts.
   - Any future native offline-delegation, background-renewal, or token-wallet workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from imported refresh-token helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `refresh_token`, `grant_type=refresh_token`, `offline_access`, `token_refresh`, `token_cache`, or `background_token_renewal` substrate imported directly from MCP/OAuth semantics.
- No portable rule that `offline_access` stands in for native unattended execution permission, durable job approval, or generic agent autonomy on existing SlopOS seams.
- No portable rule that refresh-token rotation, replay detection, inactivity expiry, or security-event revocation becomes a replay ledger, current-session oracle, or durable risk/verdict substrate.
- No portable rule that refreshed token-set metadata (`scope`, `expires_in`, replacement `refresh_token`) or client-local token caches becomes durable granted-scope truth, connected-account truth, login-state truth, or a generic token wallet on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps auth results, auth proofs, continuations, granted scopes, linked accounts, and login state on separate explicit seams. But current OAuth/MCP practice still adds another tempting adjacent surface: **durable auth continuity**, where a client caches token sets, requests `offline_access`, uses `grant_type=refresh_token`, rotates refresh tokens, and keeps long-running integrations alive without re-prompting the user.

That looks like harmless provider detail, but it is exactly where an agent OS or hosted automation substrate quietly grows a second authority story. Once wrappers and agents start seeing refresh tokens and offline-access grants, provider-local token caches become “the platform's connected accounts”, refresh loops become “our background auth scheduler”, and replacement refresh tokens become “our durable account/session handle”.

Pinning the boundary now keeps the archive honest. Imported refresh-token and offline-access mechanics may remain a provider-local way to keep one authorization path alive, but they do not get to redefine background renewal, connected-account truth, durable login state, or unattended delegation on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation hosts may interoperate with providers that cache and refresh token sets, but those helpers still do not become a portable token wallet, connected-account registry, or unattended-execution grant.
- **Cloud micro-VM substrate (B):** this matters strongly here: hosted runtimes are especially tempted to centralize token refresh and treat it as tenant-stable session state, but provider-local renewal mechanics do not become substrate auth continuity by default.
- **Embedded / separation appliance (C):** appliances can omit refresh-token handling entirely or terminate it in a narrow provider shim without importing a generalized token-wallet or background-renewal subsystem they do not want.
- **Agent/automation OS (D):** this matters most here: imported `refresh_token`, `offline_access`, and token-cache rows are exactly the kind of structure agents will over-read as durable connected-account and background-autonomy truth unless the archive pins them provider-local now.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`

## Evidence hook

- Drift gate: `tools/check_mcp_refresh_token_import_boundary.py`.
- Evidence: **EVID-2026-693** records that imported `refresh_token`, `grant_type=refresh_token`, `offline_access`, refreshed token-set metadata, and refresh-token rotation stay provider-local renewal mechanics only, so existing seams do not silently widen into a portable background-renewal substrate, durable login-state oracle, connected-account plane, or generic token wallet.

## References

- REF-MCP-AUTHORIZATION
- REF-MCP-AUTHORIZATION-TUTORIAL
- REF-RFC6749-OAUTH-AUTHZ-FRAMEWORK
- REF-OPENID-CONNECT-CORE
- REF-RFC9700-OAUTH-SECURITY
