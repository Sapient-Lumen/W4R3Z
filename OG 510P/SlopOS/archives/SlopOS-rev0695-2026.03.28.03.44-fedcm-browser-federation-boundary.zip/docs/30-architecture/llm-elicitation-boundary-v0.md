# LLM elicitation boundary v0 (explicit local mediation only; no hidden browser or token-passthrough plane)

Purpose: pin the Phase 1 meaning of **server/tool/model requests for additional user input** across **D-LLM**, **D-POWERBOX**, **D-UICAP**, and **D-APPSECRET** so the agent/automation shape does not quietly regrow a portable browser-launch, credential-ingress, or token-passthrough control plane under tool ecosystems such as MCP.

This boundary is intentionally small. It introduces **no new schema family**. Instead, it narrows how already-pinned seams fit together:
- `mcp-elicitation-import-boundary-v0.md` keeps the current MCP form/url request details attached to this generic mediation cut, so protocol specifics do not regrow a second browser/secret/callback story.
- **D-LLM** keeps model/tool output proposal-only.
- **IF-CONSENT** / **CH-VOL v0** / **CH-AUTHZ v0** keep human approval explicit and action-bound.
- **D-UICAP** keeps high-risk input/display flows on a trusted UI path when interactive profiles claim them.
- **D-APPSECRET** keeps durable secret material on explicit secret seams rather than generic inline prompt/form capture.

## Posture (v0)

1) **User-input requests are proposal material only.**
   - Requests from tools, prompts, remote servers, or model output for “more information”, “log in”, “authorize this account”, “paste an API key”, or “complete payment” are untrusted proposal material only.
   - They do not by themselves authorize data release, browser launch, secret disclosure, payer selection, or approval.
   - Any privileged effect still requires explicit local mediation under **I-LLM-1**, **I-CONSENT-1**, **I-AUTHZ-1**, **PO-CONSENT-VALIDATE**, and **PO-ACT-BIND**.

2) **Sensitive entry stays on explicit local mediation seams.**
   - When a workflow truly needs user consent, account linking, credential entry, payment approval, or other high-risk interaction, the portable meaning is **explicit local mediation** through already-reviewed seams such as **IF-CONSENT**, a trusted UI path under **D-UICAP**, or an explicit secret portal under **D-APPSECRET**.
  - Companion boundary `appsecret-secret-ingress-boundary-v0.md` keeps that explicit secret portal honest: “use the secret portal” does **not** mean generic password/API-key/OAuth-token paste-store or hidden account-linking semantics.
   - The remote tool/server may describe what it wants, but it does not get to define the trusted UI, the canonical approval summary, or the resulting local authority object.

3) **No token passthrough or client-held secret relay.**
   - Phase 1 declines any portable pattern where the client blindly forwards its own bearer tokens, ambient cookies, stored credentials, or freshly entered third-party credentials to a remote MCP/tool server as part of generic elicitation.
   - If third-party credentials are acquired at all, they must land on an explicit local secret/approval seam and remain subject to local policy rather than being treated as ordinary tool-call payload.
   - This keeps D-LLM honest: prompt/tool text cannot smuggle a hidden credential broker into the authority substrate.

4) **URL/open-browser requests are explicit handoff only.**
   - A tool/server may propose an external URL or out-of-band authorization/payment handoff, but the URL remains an untrusted proposal until the local system renders it through explicit user-visible mediation.
   - Phase 1 imports no automatic URL prefetch, no silent browser open, no hidden embedded-webview authority path, and no “tool-provided URL means proceed” rule.
   - If a profile supports such handoffs, the user must be able to inspect and explicitly approve the destination before any open occurs.

5) **Inline forms stay bounded and non-secret.**
   - Generic inline elicitation/forms may gather bounded non-secret inputs when local policy allows.
   - Passwords, API keys, bearer tokens, recovery codes, private keys, payment-card data, and equivalent high-risk secrets do **not** ride the generic inline elicitation seam in v0.
   - If a workflow needs durable secret storage or later reuse, it must return to an explicit secret/approval workflow rather than widening the form surface in place (**PO-APPSECRET-ENF**).

6) **Resulting credentials/approvals land on existing seams, not a hidden callback plane.**
   - Successful mediation may yield explicit local outcomes such as **CH-AUTHZ v0**, a provider-owned local session object, or a secret descriptor under an already-pinned portal.
   - Phase 1 does **not** add a generic server-initiated callback, browser-cookie reflection, hidden OAuth token-return channel, or “client completed elicitation so the remote tool now implicitly has authority” shortcut.
   - Observations about completed interaction remain non-authoritative unless the explicit approval/secret seam says otherwise (**PO-OBS-NOTAUTH**).

7) **No new workflow / ACP / conflict-key family in v0.**
   - This boundary only narrows how existing human-mediation and secret seams are interpreted when agent/tool ecosystems ask for extra user input.
   - Any future portable server-initiated elicitation, login, payment, or callback workflow must return RFC-first with an explicit schema, conflict keys, commutativity story, serialization boundary, approval semantics, and evidence plan.

## Phase 1 non-goals (explicitly deferred)

- No portable server-initiated browser/embedded-webview control plane in privileged code.
- No generic inline secret-capture or payment-entry surface for agent/tool ecosystems.
- No token passthrough from client-held credentials to remote tool servers.
- No portable callback / redirect / token-return registry on D-LLM itself.
- No new CH-ACP kind or conflict-key family for elicitation in v0.

## Why this is worth pinning

The surrounding agent ecosystem is converging on explicit user-interaction hooks, but the same specs also surface the exact drift hazards we want to avoid:
- MCP’s top-level security guidance requires explicit user consent/control and says hosts must obtain explicit user consent before invoking tools.
- The current MCP tools spec says tool annotations/descriptions are untrusted unless the server is trusted and recommends human-in-the-loop confirmation for tool invocation.
- The current MCP elicitation spec allows server requests for additional user information, but explicitly forbids token passthrough, forbids clients from automatically pre-fetching or opening elicitation URLs, and requires the user to inspect and explicitly consent before opening a URL.

Pinning that split now lets SlopOS learn from the ecosystem’s useful interop shape without importing a hidden browser, credential relay, or prompt-defined approval plane.

## Profile effect (A–D)

- **Secure workstation (A):** account-linking or payment-like agent flows can exist, but only through explicit trusted mediation; tools do not silently inherit browser/cookie authority.
- **Cloud micro-VM substrate (B):** automation may propose account setup or operator handoff, but cloud control planes do not gain a portable hidden login/browser/token relay surface.
- **Embedded / separation appliance (C):** most deployments can omit this seam entirely; if present, it remains explicit and reviewable rather than webview-driven folklore.
- **Agent/automation OS (D):** this matters most here: tools may ask, but user-input / OAuth / secret-entry remains local explicit mediation rather than ambient authority conveyed by prompts, URLs, or server-owned forms.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

- Decision surfaces:
  - `decision-map.md` → **D-LLM**, **D-POWERBOX**, **D-UICAP**, **D-APPSECRET**.
- Adjacent meaning pins:
  - `llm-operations-posture-v0.md`
  - `powerbox-posture-v0.md`
  - `uicap-scope-posture-v0.md`
  - `app-secret-posture-v0.md`
  - `volition-posture-v0.md`
- Engineering / threat surfaces:
  - `../70-llm-control/README.md`
  - `../70-llm-control/llm-threats.md`
  - `interface-registry.md`
- Assurance anchors:
  - **I-LLM-1**, **I-AUTHZ-1**, **I-CONSENT-1**, **I-UICAP-1**, **I-UICAP-2**.
  - **PO-ACT-BIND**, **PO-CONSENT-VALIDATE**, **PO-APPSECRET-ENF**, **PO-OBS-NOTAUTH**.
- Discovery / CI:
  - `posture-index.md` and `docs/00-meta/profile-posture-matrix.md` index this boundary.
  - `docs/00-meta/llm-runbook.md` adds it to the must-read set so future archive passes do not forget the boundary.

## Evidence hook

- `tools/check_llm_elicitation_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its explicit-local-mediation-only / no hidden browser / no token-passthrough / no generic inline secret-ingress posture, or drops its MCP reference wiring (**EVID-2026-614**).

## References

- **REF-MCP-SPEC**
- **REF-MCP-TOOLS**
- **REF-MCP-ELICITATION**
