# D-LLM MCP-authorization-context import boundary v0 (scope/resource guidance is not portable grant truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP authorization-context guidance — `WWW-Authenticate` `scope` challenges, Protected Resource Metadata `scopes_supported`, step-up scope handling, and the OAuth `resource` parameter / canonical MCP server URI — is **provider-local authorization guidance only**. It does **not** create a portable grant inventory, resource catalog, entitlement oracle, service-identity registry, or durable approval/account truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP scope/resource semantics may be interpreted next to already-pinned auth-discovery, token-passthrough, authorization-context-export, account-binding, login-state, and auth-result boundaries.

## Posture (v0)

1) **Challenged `scope` stays request-local guidance only.**
   - Current MCP authorization lets servers include `scope` in `WWW-Authenticate` responses and says clients must treat the challenged scope set as authoritative for satisfying the current request.
   - That guidance remains provider-local request handling only; it does **not** become portable granted-scope truth, durable entitlement state, approval basis, or reusable permission inventory on existing SlopOS seams.
   - Existing authorization-context, approval-basis, and auth-result boundaries stay authoritative instead of inheriting folklore from challenge headers.

2) **`scopes_supported` stays provider-local capability guidance only.**
   - Protected Resource Metadata may advertise `scopes_supported`, and MCP tells clients to use it as a fallback when an initial `scope` challenge is absent.
   - That metadata stays provider-local authorization guidance only; it does **not** become a portable permission catalog, user-entitlement menu, default approval scope set, or policy oracle on existing SlopOS seams.
   - One provider's fallback scope list is therefore not portable proof of what a user, tenant, account, or product shape should be allowed to do elsewhere.

3) **Step-up scope handling stays provider-local re-authorization control only.**
   - MCP defines runtime `insufficient_scope` handling, step-up authorization, retry limits, and scope-upgrade tracking so one client can recover one provider-owned authorization path.
   - Those mechanics remain provider-local live-flow control only; they do **not** create a portable privilege-escalation API, approval replay rule, entitlement upgrade receipt, or generic consent-upgrade substrate on existing SlopOS seams.
   - If a future product shape needs reviewed grant-escalation or approval-rebind semantics, it must return RFC-first on an explicit seam rather than inheriting meaning from imported step-up helpers.

4) **The OAuth `resource` parameter stays provider-local audience targeting only.**
   - Current MCP requires clients to send the OAuth `resource` parameter in authorization and token requests and to use the canonical URI of the MCP server they intend to access.
   - That targeting hint remains provider-local audience binding only; it does **not** become a portable service-identity registry, connected-account selector, cross-provider resource namespace, or durable resource-binding truth on existing SlopOS seams.
   - Existing account-binding, auth-discovery, and token-passthrough boundaries stay authoritative instead of inheriting service identity or durable routing semantics from OAuth resource targeting.

5) **No silent grant/account/session widening rides in through imported auth guidance.**
   - Imported MCP scope/resource semantics do **not** authorize granted-scope export, entitlement export, linked-account truth, login-state truth, callback-result export, token relay, or browser-session continuity by implication.
   - If an eventual reviewed SlopOS seam needs grant context, account binding, callback, or login-state semantics, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: imported scope/resource guidance remains killable by policy and does not smuggle ambient account, session, or approval channels into existing surfaces.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit approvals, explicit auth/login boundaries, and explicit evidence artifacts.
   - Any future native grant-context / entitlement / account-selection workflow must state its own conflict keys, commutativity conditions, serialization point, freshness model, and evidence story explicitly rather than inheriting folklore from MCP scope/resource helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `scope_catalog`, `scopes_supported_cache`, `grant_context`, `permission_inventory`, `resource_namespace`, or `resource_target_registry` substrate imported directly from MCP auth guidance.
- No rule that challenged `scope`, `scopes_supported`, step-up retries, or `resource` parameter targeting stands in for portable granted-scope truth, user entitlement truth, approval basis, account binding, or service identity.
- No rule that MCP step-up authorization yields a portable grant-escalation receipt, approval replay surface, or generic privilege-upgrade API.
- No rule that canonical MCP server URIs used as OAuth `resource` targets authorize callback-result export, connected-account truth, token relay, or browser-session continuity on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps auth results, authorization-context export, linked-account truth, login state, and token relay on separate explicit seams. Current MCP authorization still leaves one nearby pressure surface easy to over-read: the spec tells clients to treat challenged scopes as authoritative for the current request, to fall back to `scopes_supported` when needed, to perform step-up authorization on `insufficient_scope`, and to send a canonical-server `resource` parameter in authorization and token requests.

That is useful, but it is also exactly where hosts and wrappers start to over-read provider-local guidance as durable platform truth. Once that drift lands, challenge scopes start masquerading as granted entitlements, `scopes_supported` starts masquerading as a permission catalog, and canonical `resource` URIs start masquerading as portable service/account identity.

Pinning the boundary now keeps the archive honest. Imported MCP scope/resource guidance may remain a provider-local way to complete one authorization path, but it does not get to redefine what granted scopes, entitlements, approval basis, account binding, or durable service identity mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may interoperate with MCP scope challenges and step-up flows, but challenged/fallback scopes still do not become portable granted-permission or connected-account truth.
- **Cloud micro-VM substrate (B):** hosted agents may see many provider-specific scope/resource conventions, but those hints do not become tenant-stable permission catalogs or service-identity substrate.
- **Embedded / separation appliance (C):** appliances can omit dynamic scope negotiation entirely or terminate it in a narrow provider shim without importing a generic grant/entitlement/account story they do not want.
- **Agent/automation OS (D):** this matters most here: imported auth guidance must not let agent hosts quietly turn provider-local scope/resource hints into a second grant/account/session substrate beside explicit authorization-context, account-binding, and login-state seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_authorization_context_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “MCP scope/resource guidance is not portable grant/account truth” posture drifts (**EVID-2026-675**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-MCP-AUTH-SECURITY`
- `REF-RFC8707-RESOURCE-INDICATORS`
- `REF-RFC9728-PROTECTED-RESOURCE-METADATA`
