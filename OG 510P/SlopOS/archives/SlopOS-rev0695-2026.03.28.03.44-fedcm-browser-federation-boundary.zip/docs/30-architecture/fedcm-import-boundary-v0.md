# D-LLM FedCM import boundary v0 (browser federated sign-in is not portable account / chooser / disconnect / login truth)

Purpose: pin one compact Phase-1 rule on the existing **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: imported W3C FedCM semantics — `navigator.credentials.get({identity: ...})`, provider entries such as `configURL`, `clientId`, `nonce`, `loginHint`, and `domainHint`, the config / well-known / accounts / client-metadata / identity-assertion / disconnect endpoints, the Login Status API (`Set-Login`, `navigator.login.setStatus()`, and `unknown` / `logged-in` / `logged-out` status), the browser-managed connected accounts set and account chooser, returned `IdentityCredential.token`, and `IdentityCredential.disconnect()` — are **provider-local browser federated-sign-in mediation only**. They do **not** create a portable account chooser, current-user/login-state oracle, connected-account inventory, disconnect/logout control plane, browser-session substrate, approval-basis receipt, or durable account/session truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported browser-federation material may be interpreted next to already-pinned auth-result export, identity-claim export, account-binding export, login-state export, auth-teardown, browser-session export, and auth-mediation meaning cuts.

## Posture (v0)

1) **Imported browser sign-in requests stay provider-local browser mediation only.**
   - FedCM defines a browser-mediated sign-in flow where an RP calls `navigator.credentials.get({ identity: { providers: [...] } })` and passes provider-local inputs such as `configURL`, `clientId`, optional `nonce`, `loginHint`, and `domainHint`.
   - Imported sign-in request structure, provider entries, request hints, browser dialog behavior, and returned `IdentityCredential.token` stay provider-local browser mediation only; they do **not** become a portable account chooser result, login-result artifact, callback-result seam, approval-basis receipt, or durable current-user/account/session truth on existing SlopOS seams.
   - Existing auth-result export, identity-claim export, login-state export, and browser-session export boundaries stay authoritative instead of inheriting portable truth from one browser-mediated sign-in path.

2) **Imported Login Status signaling stays provider-local browser hinting only.**
   - FedCM and the companion Login Status API let an IdP signal browser-local login state through `Set-Login` or `navigator.login.setStatus()`, with browser-managed `unknown`, `logged-in`, and `logged-out` states.
   - Imported login-status headers, JavaScript status updates, login-status map state, and any browser decisions that follow from them stay provider-local browser hinting only; they do **not** become a portable current-user oracle, signed-in/account-state export, approval-basis fact, or durable auth-state registry on existing SlopOS seams.
   - Existing login-state export, caller-auth-binding, shared-signals, and account-binding boundaries stay authoritative instead of inheriting portable truth from one browser-maintained status map.

3) **Imported accounts lists and connected-account tracking stay provider-local chooser/account mediation only.**
   - FedCM defines an accounts endpoint, browser-managed connected accounts set, and account metadata used to render chooser UX and mediate reauthentication/disconnect behavior.
   - Imported account lists, `IdentityUserInfo`, account metadata, connected-account tracking, chooser affordances, and auto-reauth/account-selection behavior stay provider-local chooser/account mediation only; they do **not** become a portable connected-account inventory, subject/profile export, account-binding receipt, linked-account substrate, or durable account/session truth on existing SlopOS seams.
   - Existing identity-claim export, account-binding export, login-state export, and auth-link-ui-trigger boundaries stay authoritative instead of inheriting portable connected-account truth from one browser federated-login stack.

4) **Imported disconnect mechanics stay provider-local browser teardown choreography only.**
   - FedCM defines disconnect coordination through `IdentityCredential.disconnect()` and the provider's disconnect endpoint.
   - Imported disconnect requests, account hints, disconnect endpoints, and browser-mediated disconnect choreography stay provider-local teardown coordination only; they do **not** become a portable logout/disconnect/revoke control plane, account-unlink substrate, approval receipt, or transcript-stable revocation truth on existing SlopOS seams.
   - Existing auth-teardown, browser-session export, and login-state export boundaries stay authoritative instead of inheriting portable sign-out/unlink semantics from one browser API.

5) **Imported config/discovery and browser branding stay provider-local browser-federation setup only.**
   - FedCM defines a well-known file, config file, accounts/client-metadata/assertion/disconnect endpoints, and high-level branding hints used by the browser when mediating one IdP↔RP relationship.
   - Imported well-known/config discovery, endpoint menus, client metadata, IdP branding hints, and browser privacy choreography stay provider-local browser-federation setup only; they do **not** become a portable IdP registry, browser-session plane, trust-root store, issuer-verdict surface, or approval-basis object on existing SlopOS seams.
   - Existing auth-discovery, auth-metadata-fetch, auth-exact-match, browser-session export, and OpenURI/auth-session boundaries stay authoritative instead of inheriting portable truth from one browser federation stack.

6) **No silent account / chooser / login widening rides in through FedCM.**
   - Imported FedCM request fields, login-status bits, account lists, connected-account tracking, chooser UI, disconnect mechanics, discovery files, and returned tokens do **not** authorize portable current-user export, connected-account truth, browser-session continuity, approval-basis receipts, or hidden durable account/login/session state by implication.
   - A browser may use FedCM to help one RP and one IdP complete one provider-local sign-in or disconnect path, but that does **not** standardize a native account chooser API, connected-account registry, current-user oracle, disconnect broker, or browser-trusted login substrate on D-LLM or adjacent SlopOS seams.
   - If SlopOS ever needs native browser-federation workflows, account-chooser results, or disconnect receipts, that work must arrive on those explicit seams and validators directly.

7) **Sealed compat remains honest.**
   - Any compat/runtime use of FedCM shims, browser account choosers, login-status helpers, or disconnect wrappers must be killable by policy and must not create authority via hidden paths, env vars, implicit network access, hidden browser state, or silently persistent account defaults.
   - A compat layer that cannot proceed without ambient browser login state, hidden account caches, or implicit connected-account defaults must fail closed for portable D-LLM auth semantics.

8) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit auth-result / account-binding / login-state / auth-teardown seams, explicit approvals, and explicit local browser/session boundaries.
   - Any future native account-chooser result, browser-federation receipt, or browser-trusted sign-in workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from FedCM request fields, login-status maps, chooser UI, account lists, or returned tokens.

## Phase 1 non-goals (explicitly deferred)

- No portable `navigator.credentials.get({ identity })` / `IdentityCredential.token` / browser sign-in-result seam imported directly from FedCM.
- No portable rule that `Set-Login`, `navigator.login.setStatus()`, or browser `unknown` / `logged-in` / `logged-out` status stands in for current-user, signed-in/account-state, approval-basis, or durable login-state truth.
- No portable rule that accounts endpoints, `IdentityUserInfo`, connected accounts sets, chooser/account metadata, or auto-reauth behavior stand in for linked-account inventory, subject/profile export, or connected-account truth.
- No portable rule that `IdentityCredential.disconnect()` or disconnect endpoints stand in for logout/disconnect/revoke/unlink control semantics on existing SlopOS seams.
- No portable rule that FedCM well-known/config discovery, endpoint menus, or branding hints stand in for an IdP registry, trust-root plane, browser-session continuity, or issuer-verdict surface.

## Why this is worth pinning

FedCM is useful precisely because it gives browsers an explicit way to mediate federated sign-in, account selection, login-status hinting, and disconnect without old third-party-cookie assumptions. That is also why it is dangerous to leave semantically loose inside this archive.

If we do not pin it, the next drift step is predictable: browser chooser UI turns into “portable account chooser truth”, the login-status map turns into “our current-user/login oracle”, connected-account tracking turns into “the platform's linked-account registry”, and disconnect turns into “generic logout/unlink control”. None of those widenings are honest. They smuggle durable account/session semantics, control-plane meaning, and approval folklore in through a browser compatibility surface.

Pinning the boundary now keeps the archive honest. Imported FedCM semantics may remain a provider-local way for one browser, one RP, and one IdP to coordinate one federated sign-in or disconnect path, but they do not get to redefine account chooser truth, connected-account truth, login-state truth, auth teardown, or browser-session authority on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may interoperate with browser-mediated federated sign-in, but chooser results, login-status bits, and disconnect flows do not become portable account cards, current-user truth, or browser-session continuity semantics.
- **Cloud micro-VM / hosted compute substrate (B):** hosted consoles may terminate browser-mediated sign-in at an edge or admin UI, but imported account lists and login-status bits do not become a durable tenant/account registry or a generic disconnect broker.
- **Embedded / separation-kernel-ish appliance (C):** appliances can omit browser federation entirely or terminate it in a narrow shim without importing a generic chooser/browser/account/session story they do not want.
- **Agent / automation OS (D):** first-class agents are exactly where browser-fed account/session folklore is easiest to over-read as “the browser already knows who this is”; this boundary keeps agent memory/tooling from silently normalizing that widening.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- **Dedicated checker:** `tools/check_fedcm_import_boundary.py`
- **Evidence id:** `EVID-2026-711`
- **What it fails on:** missing family membership, missing discovery wiring, or wording drift that would let imported FedCM request fields, login-status signals, connected-account/account-list mechanics, disconnect choreography, discovery/config metadata, or returned identity tokens silently regrow a portable account chooser, current-user/login-state oracle, connected-account inventory, disconnect control plane, browser-session substrate, approval-basis receipt, or durable account/session truth.

## References

- REF-W3C-FEDCM
- REF-W3C-LOGIN-STATUS
- REF-OPENID-CONNECT-SESSION
