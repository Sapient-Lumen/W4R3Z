# D-LLM MCP-token-passthrough import boundary v0 (audience-bound MCP tokens are not a relay/proxy/external-token plane)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP authorization’s audience-binding, no-token-passthrough rule, and URL-mode third-party authorization split are **provider-local token-boundary mechanics only**. They do **not** create a portable upstream token relay, downstream bearer exchange plane, generic reverse-proxy API substrate, third-party credential export path, or durable token/session broker on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP token-separation semantics may be interpreted next to already-pinned elicitation, client-registration, auth-discovery, auth-result, auth-proof, browser-session, and authorization-context boundaries.

## Posture (v0)

1) **Audience-bound MCP access tokens stay MCP-server-local only.**
   - Current MCP authorization requires MCP servers, acting as OAuth resource servers, to validate that access tokens were issued specifically for them as the intended audience and to reject tokens that are invalid for their own resources.
   - Those audience checks remain provider-local resource-server mechanics only; they do **not** create a portable SlopOS token-audience oracle, bearer-routing API, or reusable downstream-API credential substrate.
   - This keeps D-LLM honest: one provider’s accepted token audience does not silently widen into a generic “this token is safe to forward elsewhere” story.

2) **No token passthrough or transit exception leaks in through imported auth.**
   - MCP clients must not send the MCP server tokens other than ones issued by the MCP server’s authorization server, and MCP servers must not accept or transit other tokens.
   - That rule stays a provider-local authorization invariant only; it does **not** become a portable pass-through proxy plane, token relay API, or generic upstream/downstream bearer-exchange seam on reviewed SlopOS surfaces.
   - Existing auth-result, auth-proof, and browser-session boundaries remain authoritative instead of inheriting folklore from transporting bearer material.

3) **URL-mode third-party authorization stays server-owned and stateful.**
   - MCP URL-mode elicitation may help a server launch a third-party OAuth flow, but current MCP requires the third-party credentials not to transit through the client, forbids the server from using the client’s credentials for the third-party service, and makes the server responsible for storing and managing the third-party tokens it obtains.
   - Those mechanics remain provider/server-local external-auth handling only; they do **not** create a portable external-service credential export plane, callback-token mailbox, or generic “authorize one service through another” substrate on existing SlopOS seams.
   - One provider’s stateful external-auth pattern is therefore not portable proof that third-party tokens, refresh tokens, or connected-service sessions should ever surface on generic agent/tool seams.

4) **Resource-specific upstream tokens stay provider-owned live state only.**
   - MCP’s authorization guidance requires MCP servers to obtain resource-specific tokens for the correct upstream protected resource rather than forwarding the client’s MCP token.
   - Those upstream tokens, resource bindings, and any refresh/rotation behavior stay provider-owned live state only; they do **not** become portable durable account bindings, token inventories, or reusable authorization-context artifacts.
   - Existing authorization-context, account-binding, and login-state boundaries stay authoritative instead of inheriting meaning from provider-owned upstream token state.

5) **Proxy/security consequences stay local to the provider-owned auth path.**
   - MCP’s security guidance explains why token passthrough is unsafe: it bypasses downstream service controls, weakens audit/accountability boundaries, and can turn an MCP server into a confused-deputy proxy for stolen or over-broad tokens.
   - SlopOS therefore treats imported MCP token-separation semantics as provider-local security machinery only, not as a reusable reverse-proxy, service-delegation, or token brokerage substrate.
   - Any future native token broker, delegation exchange, or service-to-service relay would need an RFC-first seam with its own policy, audience, mediation, storage, revocation, and evidence story instead of inheriting trust from MCP auth folklore.

6) **No silent callback/session/credential widening rides in through token handling.**
   - Imported MCP token-boundary semantics do **not** authorize callback-result export, pending-auth continuation handles, browser-session continuity, granted-scope export, connected-account truth, or auth-proof relay by implication.
   - If an eventual reviewed SlopOS seam needs callback, token broker, external-service delegation, or connected-account semantics, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: imported token handling remains killable by policy and does not smuggle ambient token/session channels into existing surfaces.

7) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit approvals, explicit auth/login boundaries, and explicit evidence artifacts.
   - Any future native token-broker / delegation / relay workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP token-separation helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `token_passthrough`, `upstream_token_exchange`, `downstream_bearer_relay`, `external_service_token_export`, or `connected_service_session` substrate imported directly from MCP auth semantics.
- No rule that audience validation, bearer-token rejection, or resource-specific upstream token minting stands in for portable service identity, callback authority, or durable connected-account truth.
- No rule that URL-mode third-party authorization yields a portable third-party token mailbox, callback-result export, or generic credential-forwarding seam.
- No rule that provider-owned upstream token refresh/rotation/cache state authorizes browser-session continuity, granted-scope export, or login-state truth on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps auth results, auth proofs, continuations, browser sessions, granted scopes, linked accounts, and login state on separate explicit seams. Current MCP authorization now makes one simpler but equally important rule normative: MCP tokens are audience-bound to the MCP server, servers must not accept or transit other tokens, and third-party authorization via URL-mode elicitation must keep third-party credentials out of the client while the server owns token storage and lifecycle.

That is useful, but it is also exactly where hosts and wrappers start to over-read “working OAuth plumbing” as durable platform truth. Once that drift lands, accepted MCP bearer tokens start masquerading as generic relay credentials, provider-owned upstream tokens start masquerading as portable connected-account state, and URL-mode third-party authorization starts looking like a reusable callback/token mailbox.

Pinning the boundary now keeps the archive honest. Imported MCP token separation may remain a provider-local way to keep one authorization path safe, but it does not get to redefine what token relay, external-service delegation, callback authority, or durable account/session truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may interoperate with MCP auth and server-owned external-service authorization, but audience-bound bearer checks still do not become a generic token relay or connected-service credential surface.
- **Cloud micro-VM substrate (B):** hosted agents may traverse many remote auth paths, but provider-owned upstream token state does not become tenant-stable service delegation, callback, or connected-account substrate.
- **Embedded / separation appliance (C):** appliances can omit third-party OAuth entirely or terminate it in a narrow provider shim without importing a generic reverse-proxy or token-broker story they do not want.
- **Agent/automation OS (D):** this matters most here: imported MCP auth must not let agent hosts quietly turn server-local token handling into a second callback/token/account substrate beside explicit auth-result, auth-proof, account-binding, and login-state seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_token_passthrough_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “audience-bound MCP tokens are not a relay/proxy/external-token plane” posture drifts (**EVID-2026-674**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-MCP-AUTH-SECURITY`
- `REF-MCP-ELICITATION`
- `REF-RFC8707-RESOURCE-INDICATORS`
