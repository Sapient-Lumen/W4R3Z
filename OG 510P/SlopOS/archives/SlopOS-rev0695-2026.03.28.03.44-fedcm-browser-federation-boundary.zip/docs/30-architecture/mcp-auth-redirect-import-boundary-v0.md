# D-LLM MCP-auth-redirect import boundary v0 (auth redirect return-channel is not portable callback/browser/listen truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP/OAuth redirect handling — registered `redirect_uri` values, exact redirect matching, `localhost`/HTTPS constraints, state verification, `localhost` warning/display guidance, and native-app private-use / app-claimed-HTTPS / loopback return patterns — is **provider-local authorization return-channel mechanics only**. It does **not** create a portable callback registration, deep-link reentry seam, browser-auth/session plane, loopback-listener allocation, auth-result export, or durable selected-browser/account truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP/OAuth redirect / return-channel semantics may be interpreted next to already-pinned client-registration, auth-continuation, auth-result, browser-session, OpenURI callback/auth-session, and listener-subject boundaries.

## Posture (v0)

1) **Redirect URIs stay provider-local return-channel mechanics only.**
   - Current MCP authorization requires registered redirect URIs, exact redirect validation, and state verification for one authorization path.
   - Those mechanics remain provider-local/request-local return-channel handling only; they do **not** create a portable callback registration, redirect-back rendezvous, or generic browser-auth/session substrate on existing SlopOS seams.
   - Existing auth-continuation, auth-result, and OpenURI callback/auth-session boundaries stay authoritative instead of inheriting folklore from imported OAuth redirect handling.

2) **Native-app redirect patterns stay provider-local transport choices only.**
   - Private-use URI schemes, app-claimed HTTPS redirects, and loopback-interface redirects may all be valid ways for a native client to receive one authorization response.
   - Those patterns remain provider-local/native-app transport choices only; they do **not** become a portable deep-link receiver, verified-app-link trust seam, selected-browser truth, or durable connected-app/account substrate on existing SlopOS seams.
   - Existing OpenURI verified-association, callback-reentry, and browser-auth/session boundaries stay authoritative instead of inheriting durable meaning from auth redirect folklore.

3) **Loopback listeners stay local bind subjects, not portable callback allocation.**
   - Some native OAuth flows use loopback-IP redirect URIs (for example `127.0.0.1` or `[::1]` with an `http` redirect and an ephemeral port chosen near request time).
   - That loopback usage remains provider-local return-channel mechanics only; it does **not** create a portable loopback-listener allocation, local callback mailbox, NAT/public-endpoint story, or durable pending-auth receipt on existing SlopOS seams.
   - Existing D-NETLEASE listener-subject and auth-continuation boundaries stay authoritative instead of inheriting hidden callback meaning from loopback redirect conventions.

4) **Localhost warnings and redirect-host display are phishing mitigations, not portable identity/account truth.**
   - Current MCP guidance explicitly calls out `localhost` impersonation risk, recommends extra warnings for localhost-only redirect URIs, and requires clear display of the redirect URI hostname during authorization.
   - Those presentation rules remain provider-local phishing mitigation only; they do **not** create portable app identity, linked-account truth, approval-basis truth, or durable browser/account evidence on existing SlopOS seams.
   - Existing approval-basis, identity-claim, and account-binding boundaries stay authoritative instead of inheriting durable truth from one provider's redirect-host UI.

5) **Return-channel success does not silently widen into auth-result, browser-session, or token truth.**
   - Imported redirect/return-channel semantics do **not** authorize callback-result export, token passthrough, browser-session continuity, signed-in status, or login-state truth by implication.
   - If an eventual reviewed SlopOS seam needs portable auth results, browser-auth/session state, callback capture, or loopback-listener allocation, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: redirect handling remains killable by policy and does not smuggle ambient browser, callback, listener, or token channels into existing surfaces.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit callback/login boundaries, explicit listener requests, and explicit evidence artifacts.
   - Any future native callback broker / browser-auth session / loopback-listener workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP/OAuth redirect helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `redirect_registration`, `callback_receiver`, `redirect_back_handle`, `loopback_callback`, `browser_auth_session`, `selected_browser`, or `auth_redirect_receipt` substrate imported directly from MCP/OAuth redirect handling.
- No rule that registered redirect URIs, exact redirect matching, `state`, or redirect-host display stand in for portable callback authority, app identity, account truth, or durable approval/evidence truth.
- No rule that private-use URI schemes, app-claimed HTTPS redirects, or loopback-interface redirects become a portable deep-link reentry, verified-association, browser-session, or listener-allocation seam.
- No rule that successful return-channel handling authorizes auth-result export, token relay, browser-session continuity, or login-state truth on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps callback capture, auth continuation, auth results, browser sessions, OpenURI callback/reentry, OpenURI auth-session, verified associations, and listener allocation on separate explicit seams. Current MCP authorization still adds another nearby pressure surface: it hardens redirect handling with registered redirect URIs, exact redirect matching, `state` verification, `localhost`/HTTPS constraints, and explicit localhost warning/display guidance, while OAuth native-app practice keeps private-use URI schemes, app-claimed HTTPS redirects, and loopback-interface redirects in active use.

That is useful, but it is also exactly where hosts and wrappers start to over-read a provider-owned redirect path as durable platform truth. Once that drift lands, registered redirect URIs start masquerading as callback authority, loopback listeners start masquerading as a generic local callback mailbox, claimed HTTPS redirects start masquerading as verified-app-link truth, and one provider's redirect-host display starts looking like reusable app/account evidence.

Pinning the boundary now keeps the archive honest. Imported MCP/OAuth redirect handling may remain a provider-local way to get one authorization response back to one client, but it does not get to redefine what callback authority, browser-auth/session state, listener allocation, app identity, or auth-result truth mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may interoperate with modern MCP/OAuth native-app redirect patterns, but registered redirects, loopback callbacks, and redirect-host display still stay local return-channel mechanics rather than portable callback/session/account truth.
- **Cloud micro-VM substrate (B):** hosted agents may encounter many remote authorization paths, but provider-owned redirect handling does not become tenant-stable callback registration, selected-browser, or loopback-listener substrate.
- **Embedded / separation appliance (C):** appliances can omit rich browser/native-app redirect handling entirely or terminate it in a narrow provider shim without importing a generic callback/browser/listener story they do not want.
- **Agent/automation OS (D):** this matters most here: imported redirect helpers may smooth one provider-owned authorization path, but they do not become a second callback / browser-auth / loopback-listener / app-identity substrate beside explicit auth continuation, auth result, OpenURI auth-session, and network-listen seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_auth_redirect_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “auth redirect return-channel is not portable callback/browser/listen truth” posture drifts (**EVID-2026-679**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-OAUTH-CLIENT-ID-METADATA`
- `REF-RFC8252-NATIVE-APPS`
- `REF-RFC9700-OAUTH-SECURITY`
