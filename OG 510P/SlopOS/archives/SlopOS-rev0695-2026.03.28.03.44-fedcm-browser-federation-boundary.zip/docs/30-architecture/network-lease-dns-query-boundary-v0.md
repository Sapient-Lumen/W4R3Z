# D-NETLEASE DNS-query boundary v0 (no portable RR-query / raw-reply seam)

Purpose: pin one compact Phase-1 rule on the **D-NETLEASE** seam: reviewed `kind=dns` authority stays **address-resolution only** and does **not** become a portable generic DNS RR-query or raw-reply surface.

This doc is a **family member of the closed D-NETLEASE companion boundary family** rooted at `network-lease-boundary-index.md`.

This boundary is intentionally small. It introduces **no new schema family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt type**. It only narrows how existing `portal.net` / `portal.net.request` / **CH-NETREQ v0** / **CH-NETLEASE v0** semantics may be interpreted.

## Posture (v0)

**No portable RR-query / raw-reply seam.**

1) **`kind=dns` is address-resolution authority only in v0.**
   - `portal.net.request`, CH-NETREQ, CH-NETLEASE, and adjacent digest-only receipt surfaces may carry a reviewed/granted **name predicate** plus the granted **resolver binding**.
   - They do **not** grow a portable `qtype`, `qclass`, `opcode`, `rrset`, `answer_section`, `authority_section`, `additional_section`, `raw_dns_reply`, `dns_message`, or equivalent RR-query/export surface.
   - Phase 1 portable truth is therefore: **which name predicate may be resolved, through which resolver binding** — not which DNS CLASS / RR TYPE / raw reply bytes were queried or returned.

2) **`kind=dns` stays name-shaped and portless.**
   - If a request or lease uses `kind=dns` and carries `dest`, then `dest.kind` MUST be `dns_name` or `dns_suffix`.
   - `service` and `ip_prefix` do not become portable `kind=dns` subjects in Phase 1, and `port` / `port_range` are absent for `kind=dns`.
   - This keeps DNS authority attached to names for later network reachability rather than drifting into reverse-lookups, policy-label resolution, or service-port discovery folklore on the same seam.

3) **Resolver protocol mechanics stay portal-local.**
   - Reviewed `kind=dns` authority does **not** standardize whether the implementation uses classic DNS messages, a stub resolver, `getaddrinfo`-style address resolution, Do53, DoT, DoH, DoQ, ODoH, EDNS options, DNSSEC validation, or portal-side caches.
   - Real runtimes may expose those behaviors locally or not at all, but D-NETLEASE v0 does not turn them into transcript-stable reviewed substrate meaning.
   - This keeps **sealed compat** honest: interop remains killable by policy and does not recreate ambient resolver channels through hidden RR-type queries, host resolver libraries, or transport-specific DNS defaults.

4) **If generic DNS semantics matter, pay for a new seam explicitly.**
   - A future product shape may want reviewed RR-type queries, transcript-visible raw replies, DNSSEC evidence, or explicit resolver-transport selection.
   - That work must return **RFC-first** with its own schema/receipt family, conflict keys, cache/freshness rules, privacy posture, and proof obligations.
   - Phase 1 does **not** smuggle that meaning into CH-NETREQ, CH-NETLEASE, CH-ACPOUT `receipt_refs`, or generic portal settings just because real ecosystems expose resolver libraries and raw DNS query APIs.

5) **Commutativity / conflict-key stance stays on the existing seam.**
   - This boundary adds **no new externally visible action family**.
   - Existing `portal.net.request` semantics remain exactly where the archive already pinned them:
     - conflict-key family `domain.id`,
     - **ordered** within a domain,
     - required **CH-ORDERTOK v0**, and
     - explicit serialization boundary `svc:portal.net`.
   - Any future explicit DNS RR-query / reply-export seam must state its own conflict keys, commutativity preconditions, and evidence/test story rather than inheriting folklore from libc resolvers or raw-query APIs.

6) **Current DNS answers remain portal-local live state, not transcript-stable receipt truth.**
   - Historical CH-NETLEASE bytes remain exact issued-bounds evidence only.
   - They do **not** by themselves prove which RRsets, TTLs, or raw DNS replies a later resolution attempt observed.
   - `network-lease-resolution-boundary-v0.md` already keeps current answer/path state out of portable lease meaning; this boundary keeps the *query shape itself* from drifting into a portable RR-query protocol.

## Phase 1 non-goals (explicitly deferred)

- No portable `qtype`, `qclass`, `opcode`, `raw_dns_reply`, `rrset`, `dns_message`, `edns`, `dnssec_ok`, `ad_bit`, or `cd_bit` field on CH-NETREQ or CH-NETLEASE.
- No generic portal/settings API that turns D-NETLEASE into a DNS RR-query broker, raw DNS export plane, or resolver-transport selector.
- No transcript-stable claim that an accepted `kind=dns` request or issued lease also proves a specific RR-type lookup, TTL, or raw resolver transcript.
- No hidden browser/SDK/libc compatibility promise that `kind=dns` implies one reviewed RR-query / DoH / DoQ / EDNS / DNSSEC behavior on `portal.net.request`.

## Why this is worth pinning

The archive already made the expensive decision that networking is explicit leased authority rather than ambient sockets plus ambient DNS, and the recent passes kept resolver answers, path telemetry, proxy policy, and multiple TLS/QUIC folklore seams out of CH-NETREQ / CH-NETLEASE portable meaning. The next quiet drift is to treat `kind=dns` as a portable generic DNS client API instead of a narrow address-resolution authority surface. Real systems split those meanings: mainstream address-resolution APIs talk about names turning into socket-usable addresses, while lower-level resolver APIs and raw-query APIs explicitly take RR type/class and return raw answers.

If we leave that blurry, workstation and agent flows will start depending on TXT/MX/SRV/raw-reply behaviors that cloud and embedded profiles neither want nor can safely standardize as reviewed substrate meaning. Pinning the boundary now keeps D-NETLEASE honest: **reviewed name-resolution authority is one seam; reviewed generic DNS query/export semantics would be another future seam if we ever truly need it.**

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still ship rich DNS stacks locally, but reviewed leased-network meaning stays at address resolution rather than silently inheriting generic RR-query folklore from browsers or SDKs.
- **Cloud micro-VM substrate (B):** hosted compute keeps outbound naming explicit without promising one portable raw-DNS client plane across guests, runtimes, or enterprise resolver policy.
- **Embedded / separation appliance (C):** appliance builds can support narrow reviewed name resolution without paying for a general-purpose DNS RR-query/export plane they do not want to maintain.
- **Agent/automation OS (D):** agents/tools cannot confuse “may resolve this name predicate” with “portable approval to run arbitrary RR-type lookups or consume raw DNS replies.”

## Family status (Phase 1)

This doc is a **member of the closed D-NETLEASE companion boundary family** in `network-lease-boundary-index.md`.

Any future closely related D-NETLEASE boundary doc must update that index in the **same revision** so the network-lease boundary cluster stays closed, explicit, and discoverable.

## Wiring

- Decision surface:
  - `docs/30-architecture/decision-map.md` → **D-NETLEASE**
- Adjacent network semantics:
  - `docs/30-architecture/network-lease-boundary-index.md`
  - `docs/30-architecture/network-lease-resolution-boundary-v0.md`
  - `docs/30-architecture/network-request-schema-v0.md`
  - `docs/30-architecture/network-lease-schema-v0.md`
  - `docs/30-architecture/network-lease-posture-v0.md`
  - `docs/30-architecture/capshell-network-posture-v0.md`
- ACP / proof slice:
  - `docs/70-llm-control/acp-action-kind-registry.md`
  - `docs/70-llm-control/acp-validator-semantics.md`
  - `docs/40-verification/portal-net-proof-slice-v0.md`
- Assurance:
  - `docs/20-assurance/invariant-registry.md` (**I-NETLEASE-2**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-NETREQ-VALIDATE**, **PO-NETLEASE-VALIDATE**, **PO-ACP-NET-REQUEST**)

CI drift gate:
- `tools/check_network_lease_dns_query_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **address-resolution-only / no RR-query-or-raw-reply seam / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-643**).

## References

- REF-MAN7-GETADDRINFO.
- REF-MAN7-RESOLVER.
- REF-ANDROID-DNSRESOLVER.
- REF-RFC1035-DNS.
