# D-LLM MCP-auth-exact-match import boundary v0 (exact-match auth binding is not portable issuer/account/resource truth)

Purpose: pin one compact Phase-1 rule on the **D-LLM** seam, attached to the existing explicit-local-auth meaning cuts in `auth-mediation-boundary-index.md`: current MCP/OAuth exact-match auth binding — Protected Resource Metadata `resource` equality, Authorization Server Metadata / OIDC discovery `issuer` equality, and authorization-response `iss` equality when RFC 9207 is in play — is **provider-local exact-match validation only**. It does **not** create portable resource identity, issuer identity, tenant/account binding, auth-topology truth, or durable approval/evidence truth on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, **no new portal family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**. It only narrows how imported MCP/OAuth exact-match validation semantics may be interpreted next to already-pinned auth-discovery, auth-metadata-fetch, authorization-context, enterprise-auth, token-passthrough, auth-result, auth-proof, identity-claim, and account-binding boundaries.

## Posture (v0)

1) **Protected Resource Metadata `resource` equality stays local validation only.**
   - RFC 9728 requires the returned `resource` value to be identical to the protected-resource identifier used to construct the metadata request, and requires rejection when that equality fails; when metadata is reached through `WWW-Authenticate` `resource_metadata`, the returned `resource` must also match the URL the client actually used for the resource request.
   - That equality check remains provider-local/client-local validation only; it does **not** create a portable resource-identity registry, resource-binding receipt, connected-service truth, or durable approval artifact on existing SlopOS seams.
   - Existing account-binding, auth-result, and evidence boundaries stay authoritative instead of inheriting durable truth from fetched resource identifiers.

2) **Authorization Server Metadata `issuer` equality stays local validation only.**
   - RFC 8414 requires the returned `issuer` value to be identical to the issuer identifier used to derive the well-known metadata URL, and the metadata must not be used when that equality fails.
   - That equality check remains provider-local/client-local validation only; it does **not** create a portable issuer registry, tenant identity oracle, trust-anchor export, or durable connected-account truth on existing SlopOS seams.
   - Existing identity-claim, account-binding, and trust/evidence surfaces stay authoritative instead of inheriting hidden meaning from fetched issuer strings.

3) **Authorization response `iss` equality stays local validation only.**
   - RFC 9207 defines the authorization-response `iss` parameter so clients can compare it to the issuer identifier of the authorization server they intended to use, and requires rejection when the value does not match; the comparison uses simple string comparison, and clients must not let multiple authorization servers share one accepted issuer identifier.
   - That equality check remains provider-local/client-local response validation only; it does **not** create portable issuer truth, linked-account truth, callback-result truth, or durable login-state truth on existing SlopOS seams.
   - Existing auth-result, login-state, browser-session, and account-binding boundaries stay authoritative instead of inheriting durable truth from one provider’s response-binding checks.

4) **Cross-document consistency checks stay local verifier policy only.**
   - RFC 9728 notes that when protected-resource metadata and authorization-server metadata both enumerate one another, an application profile may cross-check those lists for consistency; RFC 8414 likewise assumes the client is using the correct metadata for each authorization server.
   - Those cross-checks remain provider-local/client-local verifier policy only; they do **not** become a portable auth-topology registry, tenant-account map, or service-binding proof on existing SlopOS seams.
   - Existing approval-basis, authorization-context, and account-binding seams stay authoritative instead of inheriting durable truth from metadata-consistency folklore.

5) **No silent continuation/token/account widening rides in through exact-match checks.**
   - Imported exact-match validation semantics do **not** authorize callback-result export, pending-auth continuation handles, token relay, linked-account truth, login-state truth, or browser-session continuity by implication.
   - If an eventual reviewed SlopOS seam needs issuer truth, account binding, callback-result semantics, or verified auth-topology artifacts, it must arrive on those explicit seams and validators directly.
   - This keeps sealed compat honest too: exact-match checks remain killable by policy and do not smuggle ambient callback, token, session, tenant, or account channels into existing surfaces.

6) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible SlopOS action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit reviewed actions, explicit approvals, explicit auth/login boundaries, and explicit evidence artifacts.
   - Any future native issuer-binding / resource-binding / response-issuer validation workflow must state its own conflict keys, commutativity conditions, serialization point, and evidence story explicitly rather than inheriting folklore from MCP/OAuth exact-match checks.

## Phase 1 non-goals (explicitly deferred)

- No portable `auth_binding_receipt`, `issuer_identity_registry`, `resource_identity_registry`, `authorization_server_binding_cache`, `response_issuer_verdict`, or `auth_topology_consistency_report` substrate imported directly from MCP/OAuth validation helpers.
- No rule that `resource`, `issuer`, or authorization-response `iss` equality checks stand in for portable issuer trust, linked-account truth, tenant identity, service identity, or durable approval evidence.
- No rule that metadata cross-checks, simple-string-comparison success, or uniqueness-of-issuer enforcement become portable verifier-policy facts on existing SlopOS seams.
- No rule that exact-match binding semantics authorize token relay, callback-result export, browser-session continuity, or connected-account truth on existing SlopOS seams.

## Why this is worth pinning

The archive already keeps authorization discovery, auth-metadata fetch, callback results, browser sessions, identity claims, and linked-account truth on separate explicit seams. But current MCP authorization now requires a multi-step discovery chain and explicitly allows multiple authorization servers for a protected resource. That means MCP clients live next to exactly the class of multi-issuer ambiguity that RFC 9728, RFC 8414, and RFC 9207 are trying to contain.

Those exact-match checks are useful, but they are also easy for hosts and wrappers to over-read as durable platform truth. Once that drift lands, a fetched `resource` starts masquerading as a stable service identity, a fetched `issuer` starts masquerading as portable tenant/account truth, and a successful authorization-response `iss` check starts masquerading as a reusable callback-result or login-state proof.

Pinning the boundary now keeps the archive honest. Imported exact-match auth binding may remain a provider-local way to reject mismatched metadata and authorization responses, but it does not get to redefine what issuer truth, resource identity, account binding, callback results, or durable approval/evidence mean on SlopOS.

## Profile effect (A–D)

- **Secure workstation (A):** hosts may interoperate with modern MCP/OAuth discovery and response-binding checks, but successful `resource` / `issuer` / `iss` comparisons still stay local validation state rather than portable issuer/account/resource truth.
- **Cloud micro-VM substrate (B):** hosted agents may interact with many issuers and protected resources, but per-request exact-match validation does not become tenant-stable service identity, callback-result, or connected-account substrate.
- **Embedded / separation appliance (C):** appliances can omit dynamic auth flows entirely or terminate them in a narrow provider shim without importing a generic issuer/resource registry or response-verdict plane.
- **Agent/automation OS (D):** this matters most here: imported exact-match checks must not let agent hosts quietly turn fetched identifiers or response `iss` values into a second issuer/account/resource substrate beside explicit auth-result, identity-claim, account-binding, and evidence seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_mcp_auth_exact_match_import_boundary.py` fails `make lint` if this boundary, its discovery wiring, or its “exact-match auth binding is not portable issuer/account/resource truth” posture drifts (**EVID-2026-677**).

## References

- `REF-MCP-AUTHORIZATION`
- `REF-RFC9728-PROTECTED-RESOURCE-METADATA`
- `REF-RFC8414-AS-METADATA`
- `REF-RFC9207-AUTHZ-SERVER-ISSUER`
- `REF-OPENID-DISCOVERY`
