# LLM runbook (avoid archive amnesia)

This runbook is a **process guardrail** for editing this living archive.
It exists to reduce “LLM drift” and keep revisions **tight, composable, and reviewable**.
Current imported-elicitation meaning pin: `docs/30-architecture/mcp-elicitation-import-boundary-v0.md` keeps MCP form/url user-input requests provider-local only, so imported request flows do not quietly turn into secret/browser/callback truth. In short, form/url user-input requests are not secret/browser/callback truth.
Current MCP client-registration meaning pin: `docs/30-architecture/mcp-client-registration-import-boundary-v0.md` keeps imported MCP preregistration, Dynamic Client Registration, and Client ID Metadata Documents / URL-based `client_id` flows provider-local only, so provider-owned auth bootstrap does not quietly turn into portable client identity/callback/policy truth. In short, client registration is not portable client identity/callback/policy truth.
Current MCP client-trust-policy meaning pin: `docs/30-architecture/mcp-client-trust-policy-import-boundary-v0.md` keeps imported MCP trusted-client host allowlists, open-server `accept any HTTPS client_id` posture, reputation checks, domain-age / certificate-validation restrictions, and prominent client/CIMD hostname display provider-local only, so provider-owned client trust evaluation does not quietly turn into portable app-trust/policy/approval truth. In short, client trust evaluation is not portable app-trust/policy/approval truth.
Current MCP auth-redirect meaning pin: `docs/30-architecture/mcp-auth-redirect-import-boundary-v0.md` keeps imported MCP/OAuth registered redirects, localhost/HTTPS return rules, redirect-host display, and native-app private-use / app-claimed-HTTPS / loopback return patterns provider-local only, so provider-owned redirect handling does not quietly turn into portable callback/browser/listen truth. In short, auth redirect return-channel is not portable callback/browser/listen truth.
Current MCP auth-discovery meaning pin: `docs/30-architecture/mcp-auth-discovery-import-boundary-v0.md` keeps imported MCP Protected Resource Metadata, `WWW-Authenticate` `resource_metadata` / `scope` challenges, `authorization_servers`, and Authorization Server Metadata / OIDC discovery provider-local only, so fetched auth metadata does not quietly turn into portable issuer/tenant/policy/callback truth. In short, auth discovery metadata is not issuer/tenant/policy/callback truth.
Current MCP auth-metadata-fetch meaning pin: `docs/30-architecture/mcp-auth-metadata-fetch-import-boundary-v0.md` keeps imported MCP/OAuth auth metadata fetches, cache rows, and network validation provider-local only, so fetched auth metadata does not quietly turn into portable trust/cache/provenance truth. In short, fetched auth metadata is not portable trust/cache/provenance truth.
Current MCP auth-exact-match meaning pin: `docs/30-architecture/mcp-auth-exact-match-import-boundary-v0.md` keeps imported MCP/OAuth exact-match `resource` / `issuer` / `iss` binding provider-local only, so exact-match auth binding does not quietly turn into portable issuer/account/resource truth. In short, exact-match auth binding is not portable issuer/account/resource truth.
Current MCP PKCE meaning pin: `docs/30-architecture/mcp-pkce-import-boundary-v0.md` keeps imported MCP PKCE handling — verifier/challenge pairs, `S256` preference, metadata checks for `code_challenge_methods_supported`, and refusal to proceed without confirmed support — provider-local only, so imported PKCE handling does not quietly turn into portable verifier/proof truth. In short, MCP PKCE handling is not portable verifier/proof truth.
Current MCP authorization-context meaning pin: `docs/30-architecture/mcp-authorization-context-import-boundary-v0.md` keeps imported MCP `scope` challenges, `scopes_supported`, step-up scope handling, and OAuth `resource` targeting provider-local only, so imported auth guidance does not quietly turn into portable grant/account truth. In short, MCP scope/resource guidance is not portable grant/account truth.
Current imported-step-up-auth meaning pin: `docs/30-architecture/mcp-step-up-auth-import-boundary-v0.md` keeps imported `insufficient_user_authentication`, `acr_values`, `max_age`, and verifier-visible `acr` / `auth_time` / `amr` provider-local only, so step-up auth does not quietly turn into portable assurance, recent-login, or user-presence truth. In short, step-up auth is not portable assurance / recent-login truth.
Current imported-refresh-token meaning pin: `docs/30-architecture/mcp-refresh-token-import-boundary-v0.md` keeps imported `refresh_token`, `grant_type=refresh_token`, `offline_access`, refreshed token-set metadata, client-local token caches, and refresh-token rotation provider-local only, so refresh/offline access does not quietly turn into portable background renewal, unattended delegation, or durable login-state truth. In short, refresh/offline access is not portable background-renewal / durable login-state truth.
Current imported-auth-response-packaging meaning pin: `docs/30-architecture/mcp-auth-response-packaging-import-boundary-v0.md` keeps imported JARM response modes, JWT-valued `response` artifacts, response-packaging metadata, and issuer/audience/expiry/signature/decryption checks provider-local only, so auth response packaging does not quietly turn into portable callback-result artifacts, login-result exports, auth-proof objects, or approval truth. In short, JARM is not portable auth-result / proof / approval truth.
Current imported-userinfo meaning pin: `docs/30-architecture/mcp-userinfo-import-boundary-v0.md` keeps imported `userinfo_endpoint` locations, Bearer-token profile fetches, subject/profile/email claims, `sub`-match validation, and signed/encrypted UserInfo metadata provider-local only, so UserInfo does not quietly turn into portable subject/account/profile exports, current-user truth, or login-state truth. In short, OIDC UserInfo is not portable identity / account / login truth.
Current FedCM meaning pin: `docs/30-architecture/fedcm-import-boundary-v0.md` keeps imported `navigator.credentials.get({identity})`, Login Status API signaling, connected accounts/account lists, disconnect choreography, config discovery, and returned identity tokens provider-local only, so browser federated sign-in does not quietly turn into portable account chooser, current-user/login-state, disconnect, or browser-session truth. In short, browser federated sign-in is not portable account / chooser / disconnect / login truth.
Current AuthZEN meaning pin: `docs/30-architecture/authzen-import-boundary-v0.md` keeps imported AuthZEN access evaluations, batch evaluations, search APIs, PDP metadata/discovery, and request identifiers provider-local only, so external authorization APIs do not quietly turn into portable approval, policy, entitlement, chooser, or current-permission truth. In short, AuthZEN is not portable approval / policy / entitlement truth.
Current OpenID Federation meaning pin: `docs/30-architecture/openid-federation-import-boundary-v0.md` keeps imported entity configurations/statements, trust chains, metadata policy/constraints, trust marks/delegations, resolve/list responses, authority hints, and historical-key metadata provider-local only, so federation trust bootstrap does not quietly turn into portable issuer, app-trust, policy-selection, trust-root, or connected-entity truth. In short, OpenID Federation is not portable issuer / app-trust / policy truth.
Current OpenID Identity Assurance meaning pin: `docs/30-architecture/openid-identity-assurance-import-boundary-v0.md` keeps imported `verified_claims`, assurance metadata, evidence/process details, registered IDA claim names, aggregated/distributed claims, and OP metadata provider-local only, so verified claims do not quietly turn into portable KYC, identity, verifier-policy, approval-basis, or current-user truth. In short, OpenID Identity Assurance verified claims are not portable KYC / identity / policy truth.
Current verifiable-credential ecosystem family recovery surface: `docs/30-architecture/verifiable-credential-ecosystem-boundary-index.md` keeps the current Digital Credentials API, OpenID4VP, OpenID4VCI, VC-status, DID-document, and trust-registry meaning pins discoverable together, so wallet / browser mediation / credential / DID / trust-registry imports do not quietly regrow as portable identity, wallet, chooser, endpoint, or approval truth.
Current Digital Credentials API meaning pin: `docs/30-architecture/digital-credentials-api-import-boundary-v0.md` keeps imported `navigator.credentials.get()` / `.create()` `digital.requests[]`, protocol-support checks, chooser mediation, `digital-credentials-get` Permissions Policy delegation, and returned `DigitalCredential.data` provider-local only, so browser wallet mediation does not quietly turn into portable wallet chooser, current-user, approval, or account/session truth. In short, browser wallet mediation is not portable wallet / chooser / approval truth.
Current OpenID4VP meaning pin: `docs/30-architecture/openid4vp-import-boundary-v0.md` keeps imported `vp_token`, DCQL queries, trusted-authority queries, wallet/verifier metadata, verifier attestations, and presented credential payloads provider-local only, so wallet presentations do not quietly turn into portable identity, approval, credential-wallet, or current-user truth. In short, OpenID4VP wallet presentations are not portable identity / approval / wallet truth.
Current OpenID4VCI meaning pin: `docs/30-architecture/openid4vci-import-boundary-v0.md` keeps imported Credential Offers, `openid_credential` authorization details, issuer metadata/endpoints, `c_nonce`, deferred issuance handles, notifications, and issued VC / SD-JWT VC / mdoc payloads provider-local only, so credential issuance does not quietly turn into portable credential-wallet, issued-credential-store, issuer-policy, approval-basis, or current-user truth. In short, OpenID4VCI credential issuance is not portable credential / wallet / approval truth.
Current VC status meaning pin: `docs/30-architecture/verifiable-credential-status-import-boundary-v0.md` keeps imported W3C VC `credentialStatus`, Bitstring Status List entries/list credentials, SD-JWT VC `status` claims, Status List Tokens, and verifier-side status outcomes provider-local only, so credential status does not quietly turn into portable current-validity, approval, account-state, or current-user truth. In short, VC credential status is not portable current-validity / approval / account truth.
Current DID document meaning pin: `docs/30-architecture/did-document-import-boundary-v0.md` keeps imported DID documents, controllers, verification methods, services, dereferencing outputs, and resolver metadata provider-local only, so DID documents do not quietly turn into portable controller, signer/trust-root, endpoint, or current-user truth. In short, DID documents are not portable controller / trust / endpoint / current-user truth.
Current credential trust-registry meaning pin: `docs/30-architecture/credential-trust-registry-import-boundary-v0.md` keeps imported trusted-authority lists, issuer/verifier/wallet directories, trust documents, wallet-federation role metadata, and registry-query results provider-local only, so trust registries do not quietly turn into portable issuer, verifier, wallet, policy, approval, or current-user truth. In short, trust registries are not portable issuer / verifier / wallet / policy / approval truth.
Current Shared Signals meaning pin: `docs/30-architecture/shared-signals-import-boundary-v0.md` keeps imported Shared Signals / CAEP / RISC event streams, SET claims, stream metadata, and event types provider-local only, so external auth-state events do not quietly turn into portable login-state, auth-teardown, current-user, approval-basis, or current-permission truth. In short, Shared Signals are not portable login / approval / teardown truth.
Current SCIM meaning pin: `docs/30-architecture/scim-import-boundary-v0.md` keeps imported SCIM users/groups, memberships, lifecycle operations, search/pagination, discovery/config resources, and version metadata provider-local only, so external provisioning APIs do not quietly turn into portable account directories, group/entitlement truth, current-user/current-permission truth, or lifecycle-control truth. In short, SCIM is not portable account / group / entitlement / lifecycle truth.
Current imported-enterprise-auth meaning pin: `docs/30-architecture/mcp-enterprise-managed-auth-import-boundary-v0.md` keeps MCP enterprise IdP routing provider-local only, so imported auth extensions do not quietly turn into policy/account/session truth. In short, enterprise IdP routing is not portable policy/account/session truth.
Current imported-token-separation meaning pin: `docs/30-architecture/mcp-token-passthrough-import-boundary-v0.md` keeps audience-bound MCP access tokens, no-token-passthrough rules, resource-specific upstream token handling, and URL-mode third-party auth token splits provider-local only, so imported auth plumbing does not quietly turn into a relay/proxy/external-token plane. In short, audience-bound MCP tokens are not a relay/proxy/external-token plane.
Current imported-caller-auth-binding meaning pin: `docs/30-architecture/mcp-caller-auth-binding-import-boundary-v0.md` keeps imported MCP session IDs, inbound-request verification, “sessions are not authentication”, URL-mode same-user checks, and adjacent persistent-auth/per-tool-auth pressure provider-local only, so imported auth/session behavior does not quietly turn into portable current-user, caller-identity, or tool-authorization truth. In short, MCP session/auth state is not portable caller identity or tool-authorization truth.
Current imported-client-credentials meaning pin: `docs/30-architecture/mcp-client-credentials-import-boundary-v0.md` keeps imported MCP OAuth Client Credentials extension support provider-local only, so machine auth does not quietly turn into portable workload identity, service-account, or client-secret truth. In short, machine auth is not portable workload identity / service-account / secret truth.
Current imported-client-assertion meaning pin: `docs/30-architecture/mcp-client-assertion-import-boundary-v0.md` keeps imported `client_assertion`, `client_assertion_type`, JWT client-auth claims, `private_key_jwt` / `client_secret_jwt` method choice, and token-endpoint signing/auth-method metadata provider-local only, so endpoint client auth does not quietly turn into portable signer, assertion, or client-identity truth. In short, endpoint client auth is not portable signer / assertion / client-identity truth.
Current imported-auth-request-packaging meaning pin: `docs/30-architecture/mcp-auth-request-packaging-import-boundary-v0.md` keeps imported PAR endpoints, `require_pushed_authorization_requests`, returned `request_uri` handles, Request Objects carried by value or reference, `require_signed_request_object`, and request-object capability / algorithm metadata provider-local only, so auth request packaging does not quietly turn into portable pending-auth handles, approval objects, or request-policy truth. In short, PAR / Request Objects are not portable pending-auth / approval / policy truth.
Current imported-authorization-details meaning pin: `docs/30-architecture/mcp-authorization-details-import-boundary-v0.md` keeps imported `authorization_details`, RAR object vocabularies, granted-detail responses, and adjacent RAR metadata/error signaling provider-local only, so fine-grained grant JSON does not quietly turn into portable approval, policy, or grant truth. In short, RAR auth details are not portable approval / policy / grant truth.
Current imported-device-authorization meaning pin: `docs/30-architecture/mcp-device-authorization-import-boundary-v0.md` keeps imported `device_authorization_endpoint`, `device_code`, `user_code`, `verification_uri`, optional `verification_uri_complete`, expiry/interval fields, and device-flow polling/error semantics provider-local only, so device auth does not quietly turn into a portable cross-device auth broker, polling-status plane, or connected-account truth. In short, device auth is not portable cross-device continuation / polling / account truth.
Current imported-ID-JAG meaning pin: `docs/30-architecture/mcp-id-jag-import-boundary-v0.md` keeps saved enterprise identity assertions, `subject_token` exchange, typed ID-JAGs, and refresh-driven ID-JAG renewal provider-local only, so enterprise identity assertions do not quietly turn into portable SSO proof, subject-token, or account truth. In short, enterprise identity assertions are not portable SSO proof / subject-token / account truth.
Current imported-token-exchange meaning pin: `docs/30-architecture/mcp-token-exchange-import-boundary-v0.md` keeps imported OAuth token exchange — `subject_token`, optional `actor_token`, delegation/impersonation semantics, `resource` / `audience` / `scope` / `requested_token_type`, and exchanged-token response fields — provider-local only, so token exchange does not quietly turn into portable delegation, impersonation, token-broker, workload-identity, or account truth. In short, token exchange is not portable delegation / impersonation / token-broker / account truth.
Current imported-JWKS meaning pin: `docs/30-architecture/mcp-jwks-import-boundary-v0.md` keeps imported `jwks_uri`, fetched JWK Sets, verifier-key selection, and live key rotation/refresh provider-local only, so auth verifier keys do not quietly turn into portable trust-root, signer, or live-auth-state truth. In short, auth verifier keys are not portable trust-root / signer / current-state truth.
Current imported-token-introspection meaning pin: `docs/30-architecture/mcp-token-introspection-import-boundary-v0.md` keeps imported `introspection_endpoint`, verifier-side introspection responses including `active` and token metadata, and verifier cache/eviction pressure provider-local only, so auth introspection does not quietly turn into portable live login-state, grant, or account truth. In short, auth introspection is not portable live login / grant / account truth.
Current imported-token-revocation meaning pin: `docs/30-architecture/mcp-token-revocation-import-boundary-v0.md` keeps imported `revocation_endpoint`, revoke requests carrying `token` / optional `token_type_hint`, success-on-invalid behavior, propagation-delay / grant-cascade policy, and revocation-endpoint auth-method metadata provider-local only, so auth revocation does not quietly turn into portable disconnect, account, or live-state truth. In short, auth revocation is not portable disconnect / account / live-state truth.
Current imported MCP DPoP meaning pin: `docs/30-architecture/mcp-dpop-import-boundary-v0.md` keeps imported DPoP proof JWTs, embedded public keys, `DPoP-Nonce` challenges, DPoP-bound token metadata, and adjacent auth/client metadata provider-local only, so imported DPoP sender-constraining does not quietly turn into portable signer/proof/nonce/token-binding/account truth. In short, auth DPoP is not portable signer / nonce / token-binding truth.

Current imported-completion meaning pin: `docs/30-architecture/mcp-completion-import-boundary-v0.md` keeps MCP argument suggestions provider-local only, so imported completion helpers do not quietly turn into selector/default/workflow truth. In short, argument suggestions are not selector/default/workflow truth.

## Non-negotiables (must not degrade)

1) **No ambient authority**: authority must be explicit, inspectable, and reviewable end-to-end (especially in workflows: shell/automation/CLI/UI).
2) **Sealed compatibility**: POSIX/legacy runs only as a **Foreign Cell** behind a fail-closed membrane; interop only via portals/intents/receipts; killable by policy.
3) **Multicore verification is required**: no “single-core-only” proof plan.
4) **Scalability direction**:
   - Hybrid multicore (ADR-0005): multikernel across clusters/NUMA/chiplets; SMP within a cluster.
   - Interface-first scalability: design hot-path actions to **commute** under explicit preconditions when possible; make non-commutative boundaries explicit.
5) **LLM-first ecosystem**: LLMs propose; deterministic validators execute. Schemas + validators + receipts are the stable product surface.

## Must-read set (refresh before making changes)

Closed companion `*-boundary-index.md` docs are amnesia-critical discovery surfaces: every current family index in `docs/30-architecture/` must stay here so future passes re-find the family-level drift gates before editing member docs.

- `README.md`
- `docs/README.md`
- `docs/00-meta/charter.md`
- `docs/00-meta/trajectory-map.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/30-architecture/profile-default-artifact-boundary-v0.md`
- `docs/00-meta/profile-claim-matrix.md`
- `docs/30-architecture/posture-index.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/boundary-index-contract-v0.md`
- `docs/30-architecture/boundary-singleton-contract-v0.md`
- `docs/30-architecture/lease-descriptor-state-boundary-v0.md`
- `docs/30-architecture/adjunct-index-contract-v0.md`
- `docs/30-architecture/adjunct-family-map.md`
- `docs/30-architecture/posture-doc-conventions.md`
- `docs/00-meta/archive-policy.md`
- `docs/00-meta/id-conventions.md`
- `docs/00-meta/bibliography.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/external-source-head-register.md`
- `docs/00-meta/external-source-review-queue.md`
- `docs/10-threat-model/threat-model.md`
- `docs/10-threat-model/assumption-registry.md`
- `docs/20-assurance/claim-registry.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/20-assurance/non-claims.md`
- `docs/20-assurance/traceability.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/connector-tool-policy-boundary-v0.md`
- `docs/30-architecture/tool-annotation-semantics-boundary-v0.md`
- `docs/30-architecture/tool-result-visibility-boundary-v0.md`
- `docs/30-architecture/mcp-task-import-boundary-v0.md`
- `docs/30-architecture/mcp-progress-import-boundary-v0.md`
- `docs/30-architecture/mcp-roots-import-boundary-v0.md`
- `docs/30-architecture/mcp-resource-import-boundary-v0.md`
- `docs/30-architecture/mcp-logging-import-boundary-v0.md`
- `docs/30-architecture/mcp-prompt-import-boundary-v0.md`
- `docs/30-architecture/mcp-completion-import-boundary-v0.md`
- `docs/30-architecture/mcp-elicitation-import-boundary-v0.md`
- `docs/30-architecture/mcp-client-registration-import-boundary-v0.md`
- `docs/30-architecture/mcp-client-trust-policy-import-boundary-v0.md`
- `docs/30-architecture/mcp-auth-discovery-import-boundary-v0.md`
- `docs/30-architecture/mcp-auth-metadata-fetch-import-boundary-v0.md`
- `docs/30-architecture/mcp-auth-exact-match-import-boundary-v0.md`
- `docs/30-architecture/mcp-pkce-import-boundary-v0.md`
- `docs/30-architecture/mcp-authorization-context-import-boundary-v0.md`
- `docs/30-architecture/mcp-step-up-auth-import-boundary-v0.md`
- `docs/30-architecture/mcp-refresh-token-import-boundary-v0.md`
- `docs/30-architecture/mcp-auth-response-packaging-import-boundary-v0.md`
- `docs/30-architecture/mcp-userinfo-import-boundary-v0.md`
- `docs/30-architecture/fedcm-import-boundary-v0.md`
- `docs/30-architecture/authzen-import-boundary-v0.md`
- `docs/30-architecture/openid-federation-import-boundary-v0.md`
- `docs/30-architecture/openid-identity-assurance-import-boundary-v0.md`
- `docs/30-architecture/openid4vp-import-boundary-v0.md`
- `docs/30-architecture/openid4vci-import-boundary-v0.md`
- `docs/30-architecture/verifiable-credential-status-import-boundary-v0.md`
- `docs/30-architecture/credential-trust-registry-import-boundary-v0.md`
- `docs/30-architecture/shared-signals-import-boundary-v0.md`
- `docs/30-architecture/scim-import-boundary-v0.md`
- `docs/30-architecture/mcp-enterprise-managed-auth-import-boundary-v0.md`
- `docs/30-architecture/mcp-id-jag-import-boundary-v0.md`
- `docs/30-architecture/mcp-token-exchange-import-boundary-v0.md`
- `docs/30-architecture/mcp-token-passthrough-import-boundary-v0.md`
- `docs/30-architecture/mcp-caller-auth-binding-import-boundary-v0.md`
- `docs/30-architecture/mcp-client-credentials-import-boundary-v0.md`
- `docs/30-architecture/mcp-client-assertion-import-boundary-v0.md`
- `docs/30-architecture/mcp-auth-request-packaging-import-boundary-v0.md`
- `docs/30-architecture/mcp-authorization-details-import-boundary-v0.md`
- `docs/30-architecture/mcp-device-authorization-import-boundary-v0.md`
- `docs/30-architecture/mcp-jwks-import-boundary-v0.md`
- `docs/30-architecture/mcp-token-introspection-import-boundary-v0.md`
- `docs/30-architecture/mcp-token-revocation-import-boundary-v0.md`
- `docs/30-architecture/mcp-dpop-import-boundary-v0.md`
- `docs/30-architecture/mcp-sampling-import-boundary-v0.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/llm-elicitation-boundary-v0.md`
- `docs/30-architecture/tool-ui-boundary-index.md`
- `docs/30-architecture/tool-ui-authority-boundary-v0.md`
- `docs/30-architecture/tool-ui-toolcall-boundary-v0.md`
- `docs/30-architecture/tool-ui-model-context-boundary-v0.md`
- `docs/30-architecture/tool-ui-file-boundary-v0.md`
- `docs/30-architecture/tool-ui-followup-message-boundary-v0.md`
- `docs/30-architecture/tool-ui-navigation-boundary-v0.md`
- `docs/30-architecture/tool-ui-display-surface-boundary-v0.md`
- `docs/30-architecture/appsecret-secret-ingress-boundary-v0.md`
- `docs/30-architecture/vault-credential-mediation-boundary-v0.md`
- `docs/30-architecture/browser-session-export-boundary-v0.md`
- `docs/30-architecture/auth-link-ui-trigger-boundary-v0.md`
- `docs/30-architecture/auth-result-export-boundary-v0.md`
- `docs/30-architecture/credential-enrollment-boundary-v0.md`
- `docs/30-architecture/credential-exchange-boundary-v0.md`
- `docs/30-architecture/auth-continuation-export-boundary-v0.md`
- `docs/30-architecture/auth-proof-export-boundary-v0.md`
- `docs/30-architecture/authorization-context-export-boundary-v0.md`
- `docs/30-architecture/login-state-export-boundary-v0.md`
- `docs/30-architecture/auth-teardown-boundary-v0.md`
- `docs/30-architecture/identity-claim-export-boundary-v0.md`
- `docs/30-architecture/account-binding-export-boundary-v0.md`
- `docs/30-architecture/acp-precondition-witness-posture-v0.md`
- `docs/30-architecture/approval-basis-posture-v0.md`
- `docs/30-architecture/acp-denial-precedence-posture-v0.md`
- `docs/30-architecture/acp-acceptance-completion-posture-v0.md`
- `docs/30-architecture/schema-registry.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/commutativity-and-interface-scalability.md`
- `docs/30-architecture/state-projection-schema-v0.md`
- `docs/30-architecture/typed-id-contract-v0.md`
- `docs/30-architecture/profile-hash-suite-v0.md`
- `docs/30-architecture/schema-canonical-bytes-v0.md`
- `docs/30-architecture/nondet-posture-v0.md`
- `docs/30-architecture/waitset-posture-v0.md`
- `docs/30-architecture/ioq-posture-v0.md`
- `docs/30-architecture/quiesce-posture-v0.md`
- `docs/30-architecture/rcu-posture-v0.md`
- `docs/30-architecture/uwait-posture-v0.md`
- `docs/30-architecture/robustlock-posture-v0.md`
- `docs/30-architecture/runtime-coordination-adjunct-index.md`
- `docs/30-architecture/rseq-posture-v0.md`
- `docs/30-architecture/activation-posture-v0.md`
- `docs/30-architecture/timeproof-posture-v0.md`
- `docs/30-architecture/transparency-log-posture-v0.md`
- `docs/30-architecture/transparency-witness-acceptance-boundary-v0.md`
- `docs/30-architecture/transparency-proof-import-boundary-v0.md`
- `docs/30-architecture/proof-bundle-role-boundary-v0.md`
- `docs/30-architecture/update-evidence-subject-boundary-v0.md`
- `docs/30-architecture/provenance-required-subject-boundary-v0.md`
- `docs/30-architecture/provenance-coverage-policy-boundary-v0.md`
- `docs/30-architecture/provenance-container-selection-boundary-v0.md`
- `docs/30-architecture/provenance-evidence-set-boundary-v0.md`
- `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`
- `docs/30-architecture/sbom-bomref-identity-boundary-v0.md`
- `docs/30-architecture/sbom-purl-identity-boundary-v0.md`
- `docs/30-architecture/sbom-component-version-boundary-v0.md`
- `docs/30-architecture/sbom-supplier-origin-boundary-v0.md`
- `docs/30-architecture/sbom-license-metadata-boundary-v0.md`
- `docs/30-architecture/sbom-external-reference-locator-boundary-v0.md`
- `docs/30-architecture/sbom-document-supersession-boundary-v0.md`
- `docs/30-architecture/sbom-spdx-reference-boundary-v0.md`
- `docs/30-architecture/sbom-spdx-relationship-boundary-v0.md`
- `docs/30-architecture/vex-component-absence-boundary-v0.md`
- `docs/30-architecture/vex-product-graph-boundary-v0.md`
- `docs/30-architecture/vex-distribution-marking-boundary-v0.md`
- `docs/30-architecture/vex-justification-boundary-v0.md`
- `docs/30-architecture/vex-remediation-selection-boundary-v0.md`
- `docs/30-architecture/vex-investigation-deferral-boundary-v0.md`
- `docs/30-architecture/vex-vulnerability-identity-boundary-v0.md`
- `docs/30-architecture/vex-statement-key-boundary-v0.md`
- `docs/30-architecture/vex-priority-signal-boundary-v0.md`
- `docs/30-architecture/vex-cpe-applicability-boundary-v0.md`
- `docs/30-architecture/vex-reference-locator-boundary-v0.md`
- `docs/30-architecture/vex-document-supersession-boundary-v0.md`
- `docs/30-architecture/vex-producer-identity-boundary-v0.md`
- `docs/30-architecture/vex-osv-range-boundary-v0.md`
- `docs/30-architecture/sbom-boundary-index.md`
- `docs/30-architecture/vex-boundary-index.md`
- `docs/30-architecture/namecert-boundary-index.md`
- `docs/30-architecture/quarantined-boundary-index.md`
- `docs/30-architecture/open-untrusted-boundary-index.md`
- `docs/30-architecture/import-to-docref-boundary-index.md`
- `docs/30-architecture/signature-boundary-index.md`
- `docs/30-architecture/provenance-boundary-index.md`
- `docs/30-architecture/hybrid-topology-boundary-index.md`
- `docs/30-architecture/replication-boundary-index.md`
- `docs/30-architecture/signing-time-evidence-boundary-v0.md`
- `docs/30-architecture/certificate-path-input-boundary-v0.md`
- `docs/30-architecture/certificate-status-evidence-boundary-v0.md`
- `docs/30-architecture/certificate-identity-evidence-boundary-v0.md`
- `docs/30-architecture/signature-trust-root-boundary-v0.md`
- `docs/30-architecture/keyless-issuer-discovery-boundary-v0.md`
- `docs/30-architecture/verification-material-discovery-boundary-v0.md`
- `docs/30-architecture/signature-algorithm-acceptance-boundary-v0.md`
- `docs/30-architecture/signature-signer-acceptance-boundary-v0.md`
- `docs/30-architecture/signature-countersignature-boundary-v0.md`
- `docs/30-architecture/proof-bundle-role-boundary-v0.md`
- `docs/30-architecture/verification-policy-selection-boundary-v0.md`
- `docs/30-architecture/reqctx-posture-v0.md`
- `docs/30-architecture/reqctx-adjunct-index.md`
- `docs/30-architecture/turns-posture-v0.md`
- `docs/30-architecture/caprpc-adjunct-index.md`
- `docs/30-architecture/caprpc-session-posture-v0.md`
- `docs/30-architecture/caprpc-promise-posture-v0.md`
- `docs/30-architecture/caprpc-oneway-posture-v0.md`
- `docs/30-architecture/bracket-posture-v0.md`
- `docs/30-architecture/ordering-token-posture-v0.md`
- `docs/30-architecture/io-lease-posture-v0.md`
- `docs/30-architecture/device-lease-ordering-boundary-v0.md`
- `docs/30-architecture/capability-lease-posture-v0.md`
- `docs/30-architecture/lease-adjunct-index.md`
- `docs/30-architecture/seal-posture-v0.md`
- `docs/30-architecture/capmode-posture-v0.md`
- `docs/30-architecture/reqctx-budget-ref-posture-v0.md`
- `docs/30-architecture/reqctx-sponsorship-evolution-boundary-v0.md`
- `docs/30-architecture/capshell-adjunct-index.md`
- `docs/30-architecture/capshell-launch-boundary-index.md`
- `docs/30-architecture/capshell-output-normal-form-v0.md`
- `docs/30-architecture/capshell-result-sidecar-boundary-v0.md`
- `docs/30-architecture/capshell-pipeline-posture-v0.md`
- `docs/30-architecture/capshell-learnmode-posture-v0.md`
- `docs/30-architecture/capshell-script-entry-posture-v0.md`
- `docs/30-architecture/capshell-exec-object-posture-v0.md`
- `docs/30-architecture/quarantined-execution-boundary-v0.md`
- `docs/30-architecture/quarantined-code-input-boundary-v0.md`
- `docs/30-architecture/open-untrusted-active-content-boundary-v0.md`
- `docs/30-architecture/open-untrusted-viewer-residue-boundary-v0.md`
- `docs/30-architecture/quarantined-content-index-boundary-v0.md`
- `docs/30-architecture/quarantined-derived-attribute-boundary-v0.md`
- `docs/30-architecture/quarantined-derived-match-boundary-v0.md`
- `docs/30-architecture/quarantined-result-preview-boundary-v0.md`
- `docs/30-architecture/capshell-argv0-posture-v0.md`
- `docs/30-architecture/capshell-env-startup-posture-v0.md`
- `docs/30-architecture/capshell-code-closure-posture-v0.md`
- `docs/30-architecture/capshell-env-baseline-posture-v0.md`
- `docs/30-architecture/capshell-cwd-root-posture-v0.md`
- `docs/30-architecture/capshell-handle-table-posture-v0.md`
- `docs/30-architecture/capshell-umask-posture-v0.md`
- `docs/30-architecture/capshell-rlimit-posture-v0.md`
- `docs/30-architecture/capshell-signalstate-posture-v0.md`
- `docs/30-architecture/capshell-scheduling-posture-v0.md`
- `docs/30-architecture/capshell-affinity-posture-v0.md`
- `docs/30-architecture/capshell-resource-envelope-posture-v0.md`
- `docs/30-architecture/capshell-personality-posture-v0.md`
- `docs/30-architecture/capshell-mac-profile-posture-v0.md`
- `docs/30-architecture/capshell-peer-inspection-posture-v0.md`
- `docs/30-architecture/capshell-launcher-lifetime-posture-v0.md`
- `docs/30-architecture/capshell-syscall-filter-posture-v0.md`
- `docs/30-architecture/capshell-privgain-posture-v0.md`
- `docs/30-architecture/capshell-credential-baseline-posture-v0.md`
- `docs/30-architecture/capshell-network-posture-v0.md`
- `docs/30-architecture/capshell-local-ipc-posture-v0.md`
- `docs/30-architecture/capshell-filesystem-posture-v0.md`
- `docs/30-architecture/capshell-nondet-posture-v0.md`
- `docs/30-architecture/capshell-command-string-posture-v0.md`
- `docs/30-architecture/capshell-startup-profile-posture-v0.md`
- `docs/30-architecture/capshell-word-expansion-posture-v0.md`
- `docs/30-architecture/capshell-job-control-posture-v0.md`
- `docs/30-architecture/capshell-interrupt-cancel-posture-v0.md`
- `docs/30-architecture/background-lease-posture-v0.md`
- `docs/30-architecture/background-request-state-posture-v0.md`
- `docs/30-architecture/network-request-state-posture-v0.md`
- `docs/30-architecture/network-request-idempotency-boundary-v0.md`
- `docs/30-architecture/network-lease-dns-query-boundary-v0.md`
- `docs/30-architecture/network-lease-name-normalization-boundary-v0.md`
- `docs/30-architecture/network-lease-port-inference-boundary-v0.md`
- `docs/30-architecture/network-lease-service-binding-boundary-v0.md`
- `docs/30-architecture/network-lease-address-selection-boundary-v0.md`
- `docs/30-architecture/network-lease-name-context-boundary-v0.md`
- `docs/30-architecture/network-request-listen-subject-boundary-v0.md`
- `docs/30-architecture/network-lease-boundary-index.md`
- `docs/30-architecture/network-lease-resolution-boundary-v0.md`
- `docs/30-architecture/network-lease-local-egress-boundary-v0.md`
- `docs/30-architecture/network-lease-path-property-boundary-v0.md`
- `docs/30-architecture/network-lease-proxy-boundary-v0.md`
- `docs/30-architecture/network-lease-tls-verifier-boundary-v0.md`
- `docs/30-architecture/network-lease-client-cert-boundary-v0.md`
- `docs/30-architecture/network-lease-application-protocol-boundary-v0.md`
- `docs/30-architecture/network-lease-server-name-boundary-v0.md`
- `docs/30-architecture/network-lease-session-resumption-boundary-v0.md`
- `docs/30-architecture/network-lease-transport-profile-boundary-v0.md`
- `docs/30-architecture/network-lease-dns-query-boundary-v0.md`
- `docs/30-architecture/entropy-request-state-posture-v0.md`
- `docs/30-architecture/inhibit-lease-posture-v0.md`
- `docs/30-architecture/notification-request-schema-v0.md`
- `docs/30-architecture/attention-lease-posture-v0.md`
- `docs/30-architecture/attention-boundary-index.md`
- `docs/30-architecture/verifiable-credential-ecosystem-boundary-index.md`
- `docs/30-architecture/credential-trust-registry-import-boundary-v0.md`
- `docs/30-architecture/attention-durable-interrupt-boundary-v0.md`
- `docs/30-architecture/attention-durable-status-boundary-v0.md`
- `docs/30-architecture/location-lease-posture-v0.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/auth-mediation-boundary-index.md`
- `docs/30-architecture/vault-credential-mediation-boundary-v0.md`
- `docs/30-architecture/browser-session-export-boundary-v0.md`
- `docs/30-architecture/auth-link-ui-trigger-boundary-v0.md`
- `docs/30-architecture/auth-result-export-boundary-v0.md`
- `docs/30-architecture/credential-enrollment-boundary-v0.md`
- `docs/30-architecture/credential-exchange-boundary-v0.md`
- `docs/30-architecture/auth-continuation-export-boundary-v0.md`
- `docs/30-architecture/auth-proof-export-boundary-v0.md`
- `docs/30-architecture/authorization-context-export-boundary-v0.md`
- `docs/30-architecture/login-state-export-boundary-v0.md`
- `docs/30-architecture/auth-teardown-boundary-v0.md`
- `docs/30-architecture/identity-claim-export-boundary-v0.md`
- `docs/30-architecture/account-binding-export-boundary-v0.md`
- `docs/30-architecture/cryptosvc-posture-v0.md`
- `docs/30-architecture/cryptosvc-boundary-index.md`
- `docs/30-architecture/authagent-provider-role-boundary-v0.md`
- `docs/30-architecture/cryptosvc-inventory-boundary-v0.md`
- `docs/30-architecture/cryptosvc-forwarding-boundary-v0.md`
- `docs/30-architecture/cryptosvc-provider-selection-boundary-v0.md`
- `docs/30-architecture/cryptosvc-interactive-auth-boundary-v0.md`
- `docs/30-architecture/cryptosvc-mechanism-boundary-v0.md`
- `docs/30-architecture/cryptosvc-key-material-boundary-v0.md`
- `docs/30-architecture/cryptosvc-key-lifecycle-boundary-v0.md`
- `docs/30-architecture/cryptosvc-derived-material-boundary-v0.md`
- `docs/30-architecture/cryptosvc-attestation-boundary-v0.md`
- `docs/30-architecture/cryptosvc-verification-boundary-v0.md`
- `docs/30-architecture/namecert-posture-v0.md`
- `docs/30-architecture/namecert-projection-boundary-v0.md`
- `docs/30-architecture/namecert-time-boundary-v0.md`
- `docs/30-architecture/namecert-revocation-boundary-v0.md`
- `docs/30-architecture/namecert-selection-boundary-v0.md`
- `docs/30-architecture/namecert-search-boundary-v0.md`
- `docs/30-architecture/namecert-redelegation-boundary-v0.md`
- `docs/30-architecture/namecert-trust-root-boundary-v0.md`
- `docs/30-architecture/namecert-string-profile-v0.md`
- `docs/30-architecture/namecert-label-atom-boundary-v0.md`
- `docs/30-architecture/namecert-principal-profile-v0.md`
- `docs/30-architecture/namecert-signature-profile-v0.md`
- `docs/30-architecture/namecert-metadata-boundary-v0.md`
- `docs/30-architecture/namecert-normal-form-boundary-v0.md`
- `docs/30-architecture/namecert-bearer-boundary-v0.md`
- `docs/30-architecture/capx-posture-v0.md`
- `docs/30-architecture/sturdyref-posture-v0.md`
- `docs/30-architecture/import-to-docref-boundary-v0.md`
- `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`
- `docs/30-architecture/import-to-docref-bearer-provenance-boundary-v0.md`
- `docs/30-architecture/wallet-posture-v0.md`
- `docs/30-architecture/trusted-ui-adjunct-index.md`
- `docs/30-architecture/volition-posture-v0.md`
- `docs/30-architecture/powerbox-posture-v0.md`
- `docs/30-architecture/explain-posture-v0.md`
- `docs/30-architecture/ui-automation-posture-v0.md`
- `docs/30-architecture/portal-adjunct-index.md`
- `docs/30-architecture/capture-portal-posture-v0.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `docs/30-architecture/openuri-portal-posture-v0.md`
- `docs/30-architecture/openuri-boundary-index.md`
- `docs/30-architecture/openuri-scheme-support-boundary-v0.md`
- `docs/30-architecture/openuri-handler-selection-boundary-v0.md`
- `docs/30-architecture/openuri-opener-attribution-boundary-v0.md`
- `docs/30-architecture/openuri-activation-control-boundary-v0.md`
- `docs/30-architecture/openuri-callback-reentry-boundary-v0.md`
- `docs/30-architecture/openuri-launch-completion-boundary-v0.md`
- `docs/30-architecture/openuri-recent-items-boundary-v0.md`
- `docs/30-architecture/openuri-subject-echo-boundary-v0.md`
- `docs/30-architecture/openuri-materialization-boundary-v0.md`
- `docs/30-architecture/openuri-resource-grant-boundary-v0.md`
- `docs/30-architecture/openuri-request-shaping-boundary-v0.md`
- `docs/30-architecture/openuri-preview-metadata-boundary-v0.md`
- `docs/30-architecture/openuri-content-extraction-boundary-v0.md`
- `docs/30-architecture/openuri-speculative-loading-boundary-v0.md`
- `docs/30-architecture/openuri-session-selection-boundary-v0.md`
- `docs/30-architecture/openuri-launch-disposition-boundary-v0.md`
- `docs/30-architecture/openuri-content-type-boundary-v0.md`
- `docs/30-architecture/openuri-url-safety-boundary-v0.md`
- `docs/30-architecture/openuri-embedded-web-surface-boundary-v0.md`
- `docs/30-architecture/openuri-auth-session-boundary-v0.md`
- `docs/30-architecture/openuri-navigation-observation-boundary-v0.md`
- `docs/30-architecture/openuri-credential-mediation-boundary-v0.md`
- `docs/30-architecture/openuri-web-permission-boundary-v0.md`
- `docs/30-architecture/openuri-install-fallback-boundary-v0.md`
- `docs/30-architecture/openuri-verified-association-boundary-v0.md`
- `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`
- `docs/30-architecture/open-untrusted-posture-v0.md`
- `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`
- `docs/30-architecture/open-untrusted-export-classification-v0.md`
- `docs/30-architecture/open-untrusted-export-destination-boundary-v0.md`
- `docs/30-architecture/open-untrusted-export-lineage-boundary-v0.md`
- `docs/30-architecture/plumb-posture-v0.md`
- `docs/30-architecture/portal-session-posture-v0.md`
- `docs/30-architecture/print-portal-posture-v0.md`
- `docs/30-architecture/disposable-domain-posture-v0.md`
- `docs/30-architecture/disposable-target-selection-boundary-v0.md`
- `docs/30-architecture/quarantine-posture-v0.md`
- `docs/30-architecture/attrfs-posture-v0.md`
- `docs/30-architecture/quarantined-content-index-boundary-v0.md`
- `docs/30-architecture/quarantined-derived-match-boundary-v0.md`
- `docs/30-architecture/constructor-posture-v0.md`
- `docs/30-architecture/constructor-boundary-pattern-v0.md`
- `docs/30-architecture/worker-pool-constructor-family-v0.md`
- `docs/30-architecture/worker-pool-constructor-index.md`
- `docs/30-architecture/microvm-adjunct-index.md`
- `docs/30-architecture/confidential-computing-boundary-index.md`
- `docs/30-architecture/confidential-computing-reference-target-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-certificate-source-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-hostdata-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-vmpl-mode-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-launch-identity-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-tcb-field-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-policy-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-report-identity-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-chip-id-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-platform-info-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-measurement-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-version-metadata-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-gosvw-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-signing-metadata-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-eat-payload-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-snp-guest-svn-claim-boundary-v0.md`
- `docs/30-architecture/confidential-computing-reportdata-binding-boundary-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/30-architecture/worker-pool-constructor-invocation-v0.md`
- `docs/30-architecture/worker-pool-parameter-schema-v0.md`
- `docs/30-architecture/worker-pool-sponsor-surface-v0.md`
- `docs/30-architecture/worker-pool-install-target-surface-v0.md`
- `docs/30-architecture/worker-pool-seed-surface-v0.md`
- `docs/30-architecture/worker-pool-invocation-manifest-v0.md`
- `docs/30-architecture/worker-pool-control-surface-v0.md`
- `docs/30-architecture/worker-pool-describe-summary-v0.md`
- `docs/30-architecture/worker-pool-quiesce-state-v0.md`
- `docs/30-architecture/worker-pool-restart-budget-v0.md`
- `docs/30-architecture/worker-pool-slot-state-v0.md`
- `docs/30-architecture/worker-pool-worker-surface-v0.md`
- `docs/40-verification/worker-pool-constructor-harness-v0.md`
- `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`
- `docs/40-verification/worker-pool-capgraph-snapshots-v0.md`
- `docs/40-verification/worker-pool-target-projection-v0.md`
- `docs/40-verification/worker-pool-transcript-slice-v0.md`
- `docs/40-verification/worker-pool-verdict-summary-v0.md`
- `docs/40-verification/portal-net-proof-slice-v0.md`
- `docs/30-architecture/translator-posture-v0.md`
- `docs/30-architecture/pager-posture-v0.md`
- `docs/30-architecture/verity-posture-v0.md`
- `docs/30-architecture/provenance-posture-v0.md`
- `docs/30-architecture/attestation-endorsement-boundary-v0.md`
- `docs/30-architecture/attestation-freshness-boundary-v0.md`
- `docs/30-architecture/attestation-result-boundary-v0.md`
- `docs/30-architecture/attestation-identity-boundary-v0.md`
- `docs/30-architecture/attestation-collateral-status-boundary-v0.md`
- `docs/30-architecture/attestation-boundary-index.md`
- `docs/30-architecture/release-identity-boundary-v0.md`
- `docs/30-architecture/verification-verdict-boundary-v0.md`
- `docs/30-architecture/certificate-path-input-boundary-v0.md`
- `docs/30-architecture/certificate-status-evidence-boundary-v0.md`
- `docs/30-architecture/certificate-identity-evidence-boundary-v0.md`
- `docs/30-architecture/signature-trust-root-boundary-v0.md`
- `docs/30-architecture/signature-algorithm-acceptance-boundary-v0.md`
- `docs/30-architecture/signature-signer-acceptance-boundary-v0.md`
- `docs/30-architecture/signature-countersignature-boundary-v0.md`
- `docs/30-architecture/keyless-issuer-discovery-boundary-v0.md`
- `docs/30-architecture/update-posture-v0.md`
- `docs/30-architecture/update-evidence-subject-boundary-v0.md`
- `docs/30-architecture/provenance-required-subject-boundary-v0.md`
- `docs/30-architecture/job-portal-posture-v0.md`
- `docs/30-architecture/job-request-state-posture-v0.md`
- `docs/30-architecture/network-request-state-posture-v0.md`
- `docs/30-architecture/network-request-idempotency-boundary-v0.md`
- `docs/30-architecture/entropy-request-state-posture-v0.md`
- `docs/30-architecture/notification-request-state-posture-v0.md`
- `docs/30-architecture/timeproof-request-state-posture-v0.md`
- `docs/30-architecture/request-state-adjunct-index.md`
- `docs/30-architecture/transfer-portal-posture-v0.md`
- `docs/30-architecture/hot-action-surface-v0.md`
- `docs/30-architecture/quota-replication-boundary-v0.md`
- `docs/30-architecture/budget-replication-boundary-v0.md`
- `docs/30-architecture/namecert-replication-boundary-v0.md`
- `docs/30-architecture/caprpc-proxy-replication-boundary-v0.md`
- `docs/30-architecture/view-replication-boundary-v0.md`
- `docs/30-architecture/tlog-replication-boundary-v0.md`
- `docs/30-architecture/receipt-replication-boundary-v0.md`
- `docs/30-architecture/transcript-replication-boundary-v0.md`
- `docs/30-architecture/cache-topology-authority-boundary-v0.md`
- `docs/30-architecture/cpu-capacity-authority-boundary-v0.md`
- `docs/30-architecture/memory-locality-authority-boundary-v0.md`
- `docs/30-architecture/hybrid-phase1-boundary-v0.md`
- `docs/30-architecture/hot-action-boundaries-v0.md`
- `docs/30-architecture/foreign-cell-contract.md`

## When working on multicore direction (refresh before edits touching concurrency/placement)

- `docs/30-architecture/multicore-architecture-options.md`
- `docs/30-architecture/cluster-derivation.md`
- `docs/30-architecture/cluster-auto-boundary-v0.md`
- `docs/30-architecture/cluster-phase1-envelope-v0.md`
- `docs/30-architecture/cache-topology-authority-boundary-v0.md`
- `docs/30-architecture/cpu-capacity-authority-boundary-v0.md`
- `docs/30-architecture/memory-locality-authority-boundary-v0.md`
- `docs/30-architecture/hybrid-phase1-boundary-v0.md`
- `docs/30-architecture/commutativity-and-interface-scalability.md`
- `docs/30-architecture/state-projection-schema-v0.md`

## How to make changes

- Prefer **small, composable edits** (one concept per doc).
- New ideas must:
  - attach to an existing decision/schema/invariant/PO/evidence hook, **or**
  - introduce exactly one new decision surface or schema with an explicit entropy justification.
- Keep sealed-compat honest:
  - no ambient channels (implicit paths/env/implicit net);
  - foreign-cell interop must be portalized and policy-killable.
- Keep Hybrid + commutativity honest:
  - for any new/modified externally visible action, specify conflict keys and commutativity conditions;
  - if non-commutative, state the minimal required serialization boundary and where it lives.
- Keep links and registries wired:
  - update `docs/README.md` for new key docs;
  - if adding/modifying a v0 posture doc (`*-posture-v0.md`), update `docs/30-architecture/posture-index.md`;
  - if adding/modifying a closed `*-adjunct-index.md` family surface, keep `docs/30-architecture/adjunct-index-contract-v0.md` aligned in the same revision so purpose/inclusion/review/wiring/evidence rules and explicit member enumeration remain honest;
  - if adding a new `*-adjunct-index.md` family surface, add it to `docs/30-architecture/adjunct-family-map.md` in the same revision so the implementation-facing family layer stays closed and reviewable;
  - if adding/modifying a microVM posture doc, keep `docs/30-architecture/microvm-profile-posture-v0.md` as the umbrella posture, keep `docs/30-architecture/microvm-adjunct-index.md` as the closed adjunct discovery surface, and add/refresh the matching `check_microvm_<name>_posture.py` drift gate;
  - if adding/modifying `plumb-posture-v0.md`, `portal-session-posture-v0.md`, or any direct `*-portal-posture-v0.md` workflow doc, keep `docs/30-architecture/portal-adjunct-index.md` closed in the same revision and keep lease-backed portal families separate under `docs/30-architecture/lease-adjunct-index.md`;
  - if adding/modifying any auth-mediation family member (`llm-elicitation-boundary-v0.md`, `mcp-elicitation-import-boundary-v0.md`, `mcp-client-registration-import-boundary-v0.md`, `mcp-auth-redirect-import-boundary-v0.md`, `mcp-pkce-import-boundary-v0.md`, `mcp-client-trust-policy-import-boundary-v0.md`, `mcp-auth-discovery-import-boundary-v0.md`, `mcp-auth-metadata-fetch-import-boundary-v0.md`, `mcp-auth-exact-match-import-boundary-v0.md`, `mcp-authorization-context-import-boundary-v0.md`, `mcp-step-up-auth-import-boundary-v0.md`, `mcp-refresh-token-import-boundary-v0.md`, `mcp-auth-response-packaging-import-boundary-v0.md`, `mcp-userinfo-import-boundary-v0.md`, `fedcm-import-boundary-v0.md`, `mcp-enterprise-managed-auth-import-boundary-v0.md`, `mcp-id-jag-import-boundary-v0.md`, `mcp-token-exchange-import-boundary-v0.md`, `mcp-client-credentials-import-boundary-v0.md`, `mcp-client-assertion-import-boundary-v0.md`, `mcp-auth-request-packaging-import-boundary-v0.md`, `mcp-authorization-details-import-boundary-v0.md`, `mcp-device-authorization-import-boundary-v0.md`, `mcp-jwks-import-boundary-v0.md`, `mcp-token-introspection-import-boundary-v0.md`, `mcp-token-revocation-import-boundary-v0.md`, `mcp-dpop-import-boundary-v0.md`, `mcp-token-passthrough-import-boundary-v0.md`, `mcp-caller-auth-binding-import-boundary-v0.md`, `appsecret-secret-ingress-boundary-v0.md`, `vault-credential-mediation-boundary-v0.md`, `credential-enrollment-boundary-v0.md`, `credential-exchange-boundary-v0.md`, `browser-session-export-boundary-v0.md`, `auth-continuation-export-boundary-v0.md`, `auth-link-ui-trigger-boundary-v0.md`, `auth-result-export-boundary-v0.md`, `auth-proof-export-boundary-v0.md`, `authorization-context-export-boundary-v0.md`, `identity-claim-export-boundary-v0.md`, `account-binding-export-boundary-v0.md`, `login-state-export-boundary-v0.md`, `auth-teardown-boundary-v0.md`, or `auth-mediation-boundary-index.md`), keep the family member contract aligned in the same revision so each member still declares its family attachment, required **Family status / Wiring / Evidence hook / References** sections, and explicit no-new-schema / no-new-ACP / no-new-conflict-key posture, and keep the closed-set row/table, `boundary-family-map.md` member list, and `tools/check_auth_mediation_member_coverage.py` coverage checker aligned in the same revision so no live family member quietly disappears from one recovery surface while the rest stay green;
  - if adding/modifying any verifiable-credential ecosystem family member (`digital-credentials-api-import-boundary-v0.md`, `openid4vp-import-boundary-v0.md`, `openid4vci-import-boundary-v0.md`, `verifiable-credential-status-import-boundary-v0.md`, `did-document-import-boundary-v0.md`, `credential-trust-registry-import-boundary-v0.md`, or `verifiable-credential-ecosystem-boundary-index.md`), keep the family member contract aligned in the same revision so each member still declares its family attachment, required **Family status / Wiring / Evidence hook / References** sections, and explicit no-new-schema / no-new-ACP / no-new-conflict-key posture, and keep the closed-set row/table, `boundary-family-map.md` member list, and `tools/check_verifiable_credential_ecosystem_member_coverage.py` coverage checker aligned in the same revision so no live family member quietly disappears from one recovery surface while the rest stay green;
  - when auth docs mention imported `refresh_token`, `grant_type=refresh_token`, `offline_access`, refreshed token-set metadata, client-local token caches, or refresh-token rotation, keep them provider-local only unless a future RFC introduces an explicit seam; do not let those artifacts silently regrow portable background renewal, unattended execution permission, durable login-state, connected-account, or generic token-wallet semantics on existing D-LLM/auth-mediation surfaces;
  - if adding/modifying any `*-request-state-posture-v0.md` doc, keep `docs/30-architecture/request-state-adjunct-index.md` closed in the same revision so reviewed request identity vs provider-owned live-state honesty stays discoverable as one family instead of drifting back into piecemeal recovery;
  - if tightening any portal-issued lease/grant schema or lease-backed portal posture, keep `docs/30-architecture/lease-descriptor-state-boundary-v0.md` aligned in the same revision so historical descriptors/receipts do not drift back into fake current-state truth;
  - if adding/modifying `uicap-scope-posture-v0.md`, `volition-posture-v0.md`, `approval-basis-posture-v0.md`, `powerbox-posture-v0.md`, or `ui-automation-posture-v0.md`, keep `docs/30-architecture/trusted-ui-adjunct-index.md` closed in the same revision and keep adjacent portal / lease / capture / explanation seams explicit instead of broadening “trusted UI” by accident;
  - if adding/modifying `tool-ui-boundary-index.md`, `tool-ui-authority-boundary-v0.md`, `tool-ui-toolcall-boundary-v0.md`, `tool-ui-model-context-boundary-v0.md`, `tool-ui-file-boundary-v0.md`, `tool-ui-followup-message-boundary-v0.md`, `tool-ui-navigation-boundary-v0.md`, or `tool-ui-display-surface-boundary-v0.md`, keep the family explicit: rendered tool/server UI stays presentation-only, widget-triggered follow-on actions stay on existing reviewed seams, widget-originated model-context updates plus persisted widget state stay proposal-only and request-local, widget uploads/file params/temporary preview-download helpers stay staged/explicit, widget-authored follow-up messages stay attributed host-mediated continuation requests rather than direct user speech, widget-local routing / browser handoff stay presentation-local or host-mediated launch-only, and widget-requested fullscreen/PiP/modals/close stay host-owned presentation choreography only; do not let examples smuggle trusted approval, browser-session, filesystem, hidden validator-bypass, hidden memory/cache, direct widget file-export semantics, silent transcript-mutation / user-impersonation semantics, widget-owned browser/callback/page-state semantics, or fake trusted-modal/foreground/workflow-completion semantics into widgets;
  - if adding/modifying `tool-annotation-semantics-boundary-v0.md`, keep the D-LLM singleton narrow: imported `readOnlyHint` / `destructiveHint` / `openWorldHint` / `idempotentHint` metadata may shape UX or planning, but they must not silently become approval truth, authorization truth, conflict-key truth, or commutativity truth; any real effect taxonomy must return RFC-first on explicit action/policy surfaces;
  - if adding/modifying `tool-result-visibility-boundary-v0.md`, keep the D-LLM / D-UICAP / IF-ACP singleton narrow: keep the stance explicit — **audience lanes are not authority lanes** — so model-visible `structuredContent` / `content` and component-only `_meta` remain audience-scoped only; they may aid transcript rendering or widget hydration, but they must not silently become hidden approval basis, hidden action parameters, hidden file/account grants, hidden conflict keys, or durable evidence/receipt truth;
  - if adding/modifying `mcp-task-import-boundary-v0.md`, keep the D-LLM / D-JOBS / D-BGLEASE / IF-ACP singleton narrow: imported MCP task augmentation may wrap one provider-owned request in deferred result mechanics, but deferred result wrappers are not a background-work substrate; `CreateTaskResult`, `tasks/get|result|list|cancel`, task status, task-required execution, and immediate placeholder responses must not silently become portable job control, queue inventory, cancel authority, persistence, or current-state truth on existing SlopOS seams;
  - if adding/modifying `mcp-progress-import-boundary-v0.md`, keep the D-LLM / D-JOBS / D-BGLEASE / IF-ACP singleton narrow: imported MCP progress tracking may provide request-scoped liveness hints, but progress notifications are not portable progress/completion truth; `progressToken`, `notifications/progress`, task-lifetime progress continuity, numeric `progress` / `total`, and human-readable `message` must not silently become portable queue telemetry, durable watch registrations, percent-complete truth, completion receipts, or current-state truth on existing SlopOS seams;
  - if adding/modifying `mcp-roots-import-boundary-v0.md`, keep the D-LLM singleton narrow: imported MCP roots may provide provider-local workspace hints, but roots are not portable filesystem grant or inventory truth; `roots/list`, `notifications/roots/list_changed`, exact `Root.uri`, and optional `Root.name` must not silently become directory chooser results, durable workspace bindings, recursive inventory/watch authority, import-to-docref shortcuts, or current-workspace truth on existing SlopOS seams;
  - if adding/modifying `mcp-resource-import-boundary-v0.md`, keep the D-LLM singleton narrow: imported MCP resources may provide provider-local resource catalogs, URI/templates, subscriptions/update notifications, annotations, and text/blob contents, but resource catalogs are not file/document/watch truth; `resources/list`, `resources/read`, `resources/templates/list`, `notifications/resources/list_changed`, `resources/subscribe`, `notifications/resources/updated`, URI/templates, annotations, and returned bytes must not silently become filesystem/document grants, chooser results, recursive inventory/watch authority, import-to-docref shortcuts, current-resource truth, or validator truth on existing SlopOS seams;
  - if adding/modifying `mcp-logging-import-boundary-v0.md`, keep the D-LLM / D-OBS / IF-OBS singleton narrow: imported MCP logging may provide provider-local diagnostics, but logging notifications are not portable transcript/export truth; logging/setLevel plus notifications/message carrying `level`, optional `logger`, and structured `data` must not silently become CH-LOG entries, CH-OBS exports, durable evidence streams, retention/search/admin truth, or validator truth on existing SlopOS seams;
  - if adding/modifying `mcp-prompt-import-boundary-v0.md`, keep the D-LLM / D-PLUMB / IF-ACP singleton narrow: imported MCP prompts may provide provider-local prompt catalogs, slash-command-like templates, prompt messages, and embedded resources, but prompt templates are not workflow/policy truth; `prompts/list`, `prompts/get`, `notifications/prompts/list_changed`, prompt messages, and embedded resources must not silently become durable command registration, local workflow install, hidden selector truth, approval basis, file/document authority, or receipt/evidence truth on existing SlopOS seams;
  - if adding/modifying `mcp-client-registration-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported MCP preregistration, Dynamic Client Registration, and Client ID Metadata Documents / URL-based `client_id` flows may help providers bootstrap one authorization path, but they must not silently become portable software identity, redirect/callback authority, client-registration inventory/admin truth, trust-policy truth, or pending-auth / continuation semantics on existing SlopOS seams;
  - if adding/modifying `mcp-client-trust-policy-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported MCP trusted-client host allowlists, open-server `accept any HTTPS client_id` posture, reputation checks, domain-age / certificate-validation restrictions, and prominent client/CIMD hostname display may help providers decide whether to continue one authorization path, but those mechanics must not silently become portable trusted-app registry, approval-basis, signer/trust-root, or connected-app/account truth on existing SlopOS seams;
  - if adding/modifying `mcp-enterprise-managed-auth-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported MCP Enterprise-Managed Authorization may provide enterprise-IdP redirect/routing, organization-level IdP configuration, IdP-issued token/claim handling, and centralized enterprise policy/revocation, but those mechanics must not silently become portable enterprise-policy, account-binding, authorization-context, login-state, browser-session continuity, or token/callback semantics on existing SlopOS seams;
  - if adding/modifying `mcp-id-jag-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: saved enterprise Identity Assertions (OpenID ID Tokens / SAML assertions), token-exchange `subject_token` use, typed ID-JAGs, carried `sub` / `email` / `aud_sub` / authorization claims, and refresh-driven ID-JAG renewal may help providers stage one enterprise cross-domain authorization path, but those mechanics must not silently become portable SSO proof, subject-token storage, cross-domain account binding, approval basis, or durable login-state truth on existing SlopOS seams;
  - if adding/modifying `mcp-token-exchange-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported OAuth token exchange — `subject_token`, optional `actor_token`, delegation/impersonation semantics, `resource` / `audience` / `scope` / `requested_token_type`, and exchanged-token response fields — may help providers mint one better-targeted token on one auth path, but those mechanics must not silently become a portable token broker, delegation plane, impersonation substrate, workload-identity bridge, approval basis, or durable login/account truth on existing SlopOS seams;
  - if adding/modifying `mcp-token-passthrough-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported MCP audience-bound access tokens, no-token-passthrough rules, resource-specific upstream token handling, and URL-mode third-party auth token splits may help providers keep one authorization path safe, but those mechanics must not silently become portable token-relay, reverse-proxy, external-service-credential-export, callback-token-mailbox, or durable token/session-broker semantics on existing SlopOS seams;
  - if adding/modifying `mcp-dpop-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported DPoP proof JWTs, embedded public keys, `DPoP-Nonce` challenges, DPoP-bound token metadata, and adjacent auth/client metadata may provide provider-local sender-constraining and verifier machinery, but those mechanics must not silently become portable signer/proof services, nonce caches, token-binding or replay ledgers, or durable current-account/session truth on existing SlopOS seams;
  - if adding/modifying `mcp-caller-auth-binding-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported MCP session IDs, inbound-request verification, “sessions are not authentication”, URL-mode same-user checks, and adjacent persistent-auth/per-tool-auth pressure may provide provider-local caller-binding and live auth-state mechanics, but those mechanics must not silently become portable current-user export, caller-identity oracle, per-tool authorization registry, tenant-selection substrate, or durable server-authorized-for-user truth on existing SlopOS seams;
  - if adding/modifying `mcp-client-credentials-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported MCP OAuth Client Credentials extension support — extension negotiation, no-user machine auth, pre-connect token acquisition, JWT bearer assertions, client-secret authentication, and token-endpoint auth-method selection — may help providers bootstrap one machine-auth path, but those mechanics must not silently become portable workload identity, service-account registry, client-secret store, signer/JWKS discovery, or durable connected-service truth on existing SlopOS seams;
  - if adding/modifying `mcp-client-assertion-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported `client_assertion`, `client_assertion_type`, JWT client-auth claims, `private_key_jwt` / `client_secret_jwt` method choice, and token-endpoint signing/auth-method metadata may help providers authenticate one client to one token endpoint, but those mechanics must not silently become portable signer services, assertion stores, client-identity registries, auth-method oracles, or endpoint-trust truth on existing SlopOS seams;
  - if adding/modifying `mcp-auth-request-packaging-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported PAR endpoints, `require_pushed_authorization_requests`, returned `request_uri` handles, Request Objects carried by value or reference, `require_signed_request_object`, and request-object capability / algorithm metadata may help providers stage one authorization request, but those mechanics must not silently become portable pending-auth handles, approval objects, request-template caches, request-policy blobs, or durable auth-state / connected-account truth on existing SlopOS seams;
  - if adding/modifying `mcp-auth-response-packaging-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported JARM response modes, JWT-valued `response` artifacts, response-packaging metadata, and issuer/audience/expiry/signature/decryption checks may help providers protect one authorization response, but those mechanics must not silently become portable callback-result artifacts, login-result exports, auth-proof objects, approval-basis blobs, or durable account/session truth on existing SlopOS seams;
  - if adding/modifying `mcp-authorization-details-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported `authorization_details`, per-object `type`, common RAR fields, supported-type metadata, granted-detail token/introspection responses, and adjacent RAR metadata/error signaling may help providers describe one fine-grained authorization request, but those mechanics must not silently become portable approval objects, policy blobs, entitlement registries, grant-template stores, or durable connected-account / login-state truth on existing SlopOS seams;
  - if adding/modifying `mcp-device-authorization-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported `device_authorization_endpoint`, `device_code`, `user_code`, `verification_uri`, optional `verification_uri_complete`, expiry/interval fields, and device-flow polling/error semantics may help providers continue one constrained-input authorization path, but those mechanics must not silently become a portable cross-device auth broker, verification-URL handoff plane, polling scheduler/status oracle, linked-account selector, or durable connected-account / login-state truth on existing SlopOS seams;
  - if adding/modifying `mcp-jwks-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported `jwks_uri`, fetched JWK Sets, verifier-key selection fields, and live key rotation/refresh may help providers verify JWTs on one auth path, but those mechanics must not silently become portable trust-root, signer-registry, issuer-identity, key-rotation, or live-auth-state truth on existing SlopOS seams;
  - if adding/modifying `mcp-token-introspection-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported `introspection_endpoint`, verifier-side introspection responses including `active`, `scope`, `client_id`, `sub`, `aud`, and `iss`, plus verifier cache/eviction pressure, may help providers validate one presented token on one auth path, but those mechanics must not silently become portable live login-state, grant inventory, subject/account export, connected-service truth, or durable current-session semantics on existing SlopOS seams;
  - if adding/modifying `mcp-auth-exact-match-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported MCP/OAuth exact-match `resource`, `issuer`, and authorization-response `iss` checks may help providers reject mismatched metadata and responses on one authorization path, but those mechanics must not silently become portable issuer truth, resource identity, account-binding truth, response-verdict truth, or durable approval/evidence semantics on existing SlopOS seams;
  - if adding/modifying `mcp-authorization-context-import-boundary-v0.md`, keep the D-LLM auth-mediation family narrow: imported MCP `scope` challenges, `scopes_supported`, step-up scope handling, and OAuth `resource` targeting may help providers complete one authorization path, but those mechanics must not silently become portable grant inventory, entitlement truth, service identity, approval basis, or account-binding semantics on existing SlopOS seams;
  - if adding/modifying `acp-precondition-witness-posture-v0.md`, `acp-denial-precedence-posture-v0.md`, `acp-acceptance-completion-posture-v0.md`, or ACP deny/receipt semantics, keep `docs/70-llm-control/acp-validator-semantics.md`, `docs/30-architecture/acp-outcome-receipt-schema-v0.md`, `docs/30-architecture/deny-code-registry.md`, and `docs/30-architecture/denial-receipt-schema-v0.md` aligned in the same revision so stale-basis, dead-authority, and acceptance-vs-completion meaning do not drift into folklore;
  - if adding/modifying `caprpc-session-posture-v0.md`, `caprpc-promise-posture-v0.md`, or `caprpc-oneway-posture-v0.md`, keep `docs/30-architecture/caprpc-adjunct-index.md` closed in the same revision and keep restore/import, turn discipline, and replication seams explicit instead of broadening “CapRPC” into one blurry runtime-control bucket;
  - if adding/modifying `waitset-posture-v0.md`, `uwait-posture-v0.md`, `robustlock-posture-v0.md`, or `ioq-posture-v0.md`, keep `docs/30-architecture/runtime-coordination-adjunct-index.md` closed in the same revision and keep quiesce / RCU / RSEQ / scheduling seams explicit instead of broadening “runtime coordination” into one blurry control bucket;
  - register new CH/IF/D/REF/EVID IDs where appropriate.

## Per-iteration requirement

Each iteration must include at least ONE of:
- an entropy-reducing refactor (dedupe/simplify/unify/wiring),
- a new guardrail/tool/check that prevents drift/amnesia,
- or a new integrated feature/idea explicitly profiled and wired into registries + discovery.

## Required outputs for each run

1) A high-level summary of what changed and why (tie back to the non-negotiables and the four product shapes).
2) A concise list of new/updated files.
3) Any new/updated open questions captured (prefer `docs/00-meta/trajectory-map.md`).
   - Use stable **OQ-####** ids so follow-ups can reference open questions without copying prose.
   - When resolving an OQ, keep the stable `OQ-####` id under **Recently resolved**, link the closing boundary/posture doc, and mention at least one attached surface or evidence hook.
   - Keep `docs/00-meta/trajectory-map.md` **OQ-only and short** (max 8 bullets); move posture-only closure notes or older overflow to `docs/00-meta/resolved-history.md`.
4) Confirm `make lint` was run and fix failures.
5) Keep `out/context_pack.md` honest: it must carry both current open questions and a compact recently-resolved OQ summary, it must point back to `docs/00-meta/resolved-history.md` so future passes retain full closure history even when the short window rotates, and its `## New in latest revision` bullets must stay a faithful mirror of the top `CHANGELOG.md` entry.
6) Provide a working link to the latest zipped archive (prefer the canonical `make handoff-release ...` one-shot path, or `make package-release ...` when debugging the split steps, rather than a manually renamed zip). `make package-release ...` must self-verify the produced bundle against its embedded `RELEASE-MANIFEST.json` before reporting success, and you should still use `make verify-release ...` when re-checking an existing artifact. Do not treat extracted residue copies in the workspace as authoritative.

## Commands

- Lint/hygiene: `make lint` (runs archive lints + discovery-surface checks)
- Generate a compact context pack for future runs: `make context-pack` (writes `out/context_pack.md`; must keep closed companion boundary + adjunct family indexes visible during handoff).
- Preferred one-shot handoff path: `make handoff-release STAMP=YYYY.MM.DD.HH.MM SLUG=<slug>` (regenerates `out/context_pack.md`, runs `make lint`, then builds the canonical self-verifying zip via `make package-release ...`).
- Package the canonical handoff zip directly when debugging split steps: `make package-release STAMP=YYYY.MM.DD.HH.MM SLUG=<slug>` (derives `rev####` from the top `CHANGELOG.md` entry, requires a fresh `out/context_pack.md` whose header revision/date and `## New in latest revision` bullets still mirror that top changelog entry, includes it in the bundle, embeds a fresh `RELEASE-MANIFEST.json`, ignores any extracted residue copy in the workspace, normalizes member metadata to `STAMP`, excludes `out/_ci_*`, and self-verifies the just-built bundle before reporting success).
- Verify the produced handoff zip: `make verify-release BUNDLE=/abs/path/to/SlopOS-rev####-YYYY.MM.DD.HH.MM-<slug>.zip` (checks the bundle filename, embedded `RELEASE-MANIFEST.json`, exact file list / size / SHA-256s, and canonical zip metadata on the artifact being handed off).
