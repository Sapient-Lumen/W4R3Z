## Revised695 (2026-03-28)

- FedCM import boundary / browser-federation honesty tightening:
  - add `docs/30-architecture/fedcm-import-boundary-v0.md`, pinning imported `navigator.credentials.get({identity: ...})`, provider entries such as `configURL` / `clientId` / `nonce` / `loginHint` / `domainHint`, Login Status signaling, browser-managed connected accounts/account lists, disconnect choreography, config discovery, and returned `IdentityCredential.token` to provider-local browser federated-sign-in mediation only rather than letting browser federation quietly regrow into a portable account chooser, current-user/login-state oracle, connected-account inventory, disconnect control plane, browser-session substrate, approval-basis receipt, or durable account/session truth on existing SlopOS seams
  - wire the new auth-mediation family member through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so the new browser-federation meaning pin is recoverable across discovery, family, assurance, and tooling surfaces
  - add `tools/check_fedcm_import_boundary.py`, register `EVID-2026-711`, and tighten `tools/check_auth_mediation_boundary_index.py` so the auth-mediation family and its machine checks now explicitly cover FedCM / Login Status alongside the already-pinned UserInfo, enterprise auth, token exchange, device flow, introspection, revocation, and DPoP cuts rather than leaving browser federation as ambient browser folklore

## Revised694 (2026-03-28)
- Digital Credentials API import boundary:
  - add `docs/30-architecture/digital-credentials-api-import-boundary-v0.md`, freezing the rule that imported W3C Digital Credentials API browser mediation — `navigator.credentials.get()` / `.create()` `digital.requests[]`, protocol-support checks, chooser mediation, `digital-credentials-get` Permissions Policy delegation, and returned `DigitalCredential.data` — stays provider-local browser wallet mediation only rather than widening into a portable wallet chooser result, wallet inventory, current-user oracle, approval-basis object, connected-device truth, or durable account/session truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/verifiable-credential-ecosystem-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so browser wallet mediation stays discoverable as provider-local-only archive meaning rather than silently widening into portable chooser, wallet, identity, approval, or account truth
- Family recovery / tooling / hygiene:
  - add `tools/check_digital_credentials_api_import_boundary.py` (`EVID-2026-709`) and retighten `tools/check_verifiable_credential_ecosystem_boundary_index.py` so the new browser-wallet family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only
  - add `tools/check_verifiable_credential_ecosystem_member_coverage.py` (`EVID-2026-710`), forcing the verifiable-credential ecosystem closed-set table in `docs/30-architecture/verifiable-credential-ecosystem-boundary-index.md`, the `docs/30-architecture/boundary-family-map.md` member list, and the `docs/00-meta/llm-runbook.md` family-member bullet to enumerate the same live member set in the same revision so browser / wallet / credential / DID / trust-registry family growth cannot silently fall out of one recovery surface while the others remain green
- Research / bibliography:
  - add `REF-W3C-DIGITAL-CREDENTIALS` in `docs/00-meta/bibliography.md`, translating current browser wallet mediation / chooser / permissions-policy / encrypted-response pressure into SlopOS D-LLM / D-POLICY import language instead of ambient browser-trust or wallet-choice folklore

## Revised693 (2026-03-28)
- auth-mediation family coverage / guardrail tightening:
  - tighten `tools/check_auth_mediation_boundary_index.py` so the closed auth-mediation family guard now explicitly covers `mcp-auth-exact-match-import-boundary-v0.md`, `mcp-authorization-context-import-boundary-v0.md`, and `mcp-userinfo-import-boundary-v0.md` instead of leaving those live family members outside the machine-checker's required-member set
  - add `tools/check_auth_mediation_member_coverage.py` (`EVID-2026-708`), forcing the auth-mediation closed-set row/table in `docs/30-architecture/auth-mediation-boundary-index.md`, the `docs/30-architecture/boundary-family-map.md` member list, and the `docs/00-meta/llm-runbook.md` family-member bullet to enumerate the same live member set in the same revision so family growth cannot silently fall out of one recovery surface while the others remain green
- archive wiring / hygiene:
  - tighten `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so auth-mediation family maintenance now explicitly includes closed-set row/table/family-map/runbook alignment rather than reviewer memory alone

## Revised692 (2026-03-28)
- MCP-token-exchange import boundary:
  - add `docs/30-architecture/mcp-token-exchange-import-boundary-v0.md`, freezing the rule that imported OAuth token exchange — `subject_token`, optional `actor_token`, delegation/impersonation semantics, `resource` / `audience` / `scope` / `requested_token_type`, and exchanged-token response fields — stays provider-local authorization-server token-shaping only rather than widening into a portable token broker, delegation plane, impersonation substrate, workload-identity bridge, approval-basis seam, or durable login/account truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the token-exchange / delegation cut instead of rediscovering it from STS folklore or actor-vs-subject confusion
- Research / tooling / hygiene:
  - retighten `REF-RFC8693-TOKEN-EXCHANGE` and `REF-RFC8707-RESOURCE-INDICATORS` in `docs/00-meta/bibliography.md`, translating current OAuth STS/token-targeting pressure into SlopOS D-LLM auth language instead of leaving delegation/workload/account meaning as ambient ecosystem lore
  - add `tools/check_mcp_token_exchange_import_boundary.py` (`EVID-2026-707`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised691 (2026-03-26)
- added `docs/30-architecture/credential-trust-registry-import-boundary-v0.md` to pin imported trusted-authority lists, issuer/verifier/wallet directories, trust documents, wallet-federation role metadata, and registry-query results to provider-local ecosystem trust-establishment hints only
- added `tools/check_credential_trust_registry_import_boundary.py` and rewired discovery/assurance/bibliography surfaces so credential trust-registry folklore cannot regrow as portable issuer/verifier/wallet/policy/approval/current-user truth
- extended the verifiable-credential ecosystem family index to include trust-registry adjuncts and refreshed the evidence/history surfaces accordingly

## Revised690 (2026-03-25)
- DID-document import boundary + verifiable-credential ecosystem family:
  - add `docs/30-architecture/did-document-import-boundary-v0.md`, freezing the rule that imported DID documents, controllers, verification methods, services, dereferencing outputs, and resolver metadata stay provider-local identifier-resolution and proof-routing only rather than widening into a portable controller inventory, signer/trust-root plane, endpoint-discovery substrate, approval-basis object, or durable current-user truth on existing SlopOS seams
  - add `docs/30-architecture/verifiable-credential-ecosystem-boundary-index.md`, promoting the OpenID4VP / OpenID4VCI / VC-status cuts into one closed companion family and adding DID-document imports as the next adjacent family member so wallet / credential / DID ecosystems stay discoverable as reviewed provider-local-only meaning rather than silently regrowing into a portable identity / wallet / endpoint / approval substrate
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the new family closure and DID seam stay discoverable wherever future archive work will look
- Research / tooling / hygiene:
  - add `REF-W3C-DID-CORE`, `REF-W3C-DID-RESOLUTION`, and `REF-W3C-DID-SPEC-REGISTRIES` in `docs/00-meta/bibliography.md`, translating current DID-document / dereferencing / resolver pressure into SlopOS D-LLM / D-POLICY import language instead of ambient DID-controller / endpoint folklore
  - add `tools/check_did_document_import_boundary.py` (`EVID-2026-704`) and `tools/check_verifiable_credential_ecosystem_boundary_index.py` (`EVID-2026-705`) so the DID seam and closed family wiring fail lint if DID / wallet / credential meaning starts drifting back into ambient archive truth

## Revised689 (2026-03-25)
- VC status import boundary:
  - add `docs/30-architecture/verifiable-credential-status-import-boundary-v0.md`, freezing the rule that imported W3C VC `credentialStatus` objects, Bitstring Status List entries/list credentials, status purpose/index/list URLs, SD-JWT VC `status` claims, associated Status List Tokens, HAIP-constrained status handling, and verifier-side status outcomes stay provider-local credential-status checking only rather than widening into a portable current-validity oracle, revocation/suspension feed, approval-basis object, entitlement/account-state truth, issuer-policy selector, or durable current-user truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so imported credential-status meaning stays discoverable as provider-local-only archive meaning rather than silently widening into portable validity, approval, account-state, or current-user truth
- Research / tooling / hygiene:
  - add `REF-W3C-VC-BITSTRING-STATUS-LIST-1-0` and `REF-IETF-SD-JWT-VC-DRAFT` in `docs/00-meta/bibliography.md`, translating current credential-status / revocation / status-list pressure into SlopOS D-LLM / D-POLICY import language instead of ambient “currently valid credential” folklore
  - add `tools/check_verifiable_credential_status_import_boundary.py` (`EVID-2026-703`) so VC status singleton status, discovery, references, and anti-drift wording fail lint if external status/revocation folklore starts widening existing seams

## Revised688 (2026-03-25)
- OpenID4VCI import boundary:
  - add `docs/30-architecture/openid4vci-import-boundary-v0.md`, freezing the rule that imported Credential Offers, `openid_credential` authorization details, issuer metadata/endpoints, `c_nonce`, deferred issuance handles, notifications, encryption metadata, and issued VC / SD-JWT VC / mdoc payloads stay provider-local credential-issuance coordination only rather than widening into a portable credential-wallet import, issued-credential store, issuer-policy selector, approval-basis object, pending-issuance handle, or durable current-user truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so imported issuer-offer / issuance meaning stays discoverable as provider-local-only archive meaning rather than silently widening into portable credential-wallet, approval-basis, or current-user truth
- Research / tooling / hygiene:
  - add `REF-OPENID-4VCI-1-0` and `REF-OPENID-4VCI-FINAL` in `docs/00-meta/bibliography.md`, translating current credential-offer / pre-authorized-code / deferred-issuance / notification pressure into SlopOS D-LLM auth language instead of ambient wallet/issuer folklore
  - add `tools/check_openid4vci_import_boundary.py` (`EVID-2026-702`) so OpenID4VCI singleton status, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised687 (2026-03-25)
- add `docs/30-architecture/openid4vp-import-boundary-v0.md`, a tight singleton boundary that pins imported OpenID4VP `vp_token`, DCQL queries, trusted-authority queries, wallet/verifier metadata, verifier attestations, and presented VC / SD-JWT VC / mdoc payloads to provider-local credential-presentation coordination only, so wallet-mediated presentations do not silently become portable identity-card / credential-wallet / verifier-policy / approval-basis / current-user truth on D-LLM / D-POLICY / IF-ACP
  - wire the new boundary through README/docs indexes, the LLM runbook, posture/profile/history surfaces, boundary singleton coverage, D-POLICY / D-LLM posture docs, assurance registries, bibliography, and tools registry
  - add `tools/check_openid4vp_import_boundary.py` (`EVID-2026-701`) so singleton status, discovery, references, and anti-drift wording fail lint if wallet-presentation folklore starts widening existing seams
- research / bibliography:
  - add `REF-OPENID-4VP-1-0`, `REF-OPENID-4VP-FINAL`, `REF-OPENID4VC-HAIP-1-0`, and `REF-W3C-VC-DM-2-0`, translating current wallet-presentation / verifier-attestation / trusted-authority / verifiable-credential pressure into SlopOS D-LLM / D-POLICY import language instead of ambient identity-wallet folklore

## Revised686 (2026-03-25)
- add `docs/30-architecture/openid-identity-assurance-import-boundary-v0.md`, a tight singleton boundary that pins imported OpenID Identity Assurance `verified_claims`, assurance metadata, evidence/process details, registered IDA claim names, aggregated/distributed claims, and OP metadata to provider-local identity-assurance transport only, so external verified-claim payloads do not silently become portable KYC / identity-registry / verifier-policy / approval-basis / current-user truth on D-LLM / D-POLICY / IF-ACP
  - wire the new boundary through README/docs indexes, the LLM runbook, posture/profile/history surfaces, boundary singleton coverage, D-POLICY / D-LLM posture docs, assurance registries, bibliography, and tools registry
  - add `tools/check_openid_identity_assurance_import_boundary.py` (`EVID-2026-700`) so singleton status, discovery, references, and anti-drift wording fail lint if external verified-claim folklore starts widening existing seams
- research / bibliography:
  - add `REF-OPENID-IDA-1-0`, `REF-OPENID-IDA-CLAIMS-1-0`, `REF-OPENID-IDA-SCHEMA-1-0`, and `REF-OPENID-IDA-FINAL`, translating current high-assurance identity / verified-claims pressure into SlopOS D-LLM / D-POLICY import language instead of ambient KYC / identity folklore

## Revised685 (2026-03-25)
- add `docs/30-architecture/openid-federation-import-boundary-v0.md`, a tight singleton boundary that pins imported OpenID Federation entity configurations/statements, trust chains, metadata policy/constraints, trust marks/delegations, resolve/list responses, authority hints, and historical-key metadata to provider-local federation trust bootstrap only, so external federation bootstrap does not silently become portable issuer registry / trust-root / app-trust / policy-selector / connected-entity truth on D-LLM / D-POLICY / IF-ACP
  - wire the new boundary through README/docs indexes, the LLM runbook, posture/profile/history surfaces, boundary singleton coverage, D-POLICY / D-LLM posture docs, assurance registries, bibliography, and tools registry
  - add `tools/check_openid_federation_import_boundary.py` (`EVID-2026-699`) so singleton status, discovery, references, and anti-drift wording fail lint if external federation folklore starts widening existing seams
- research / bibliography:
  - add `REF-OPENID-FEDERATION-1-0` and `REF-OPENID-FEDERATION-FINAL`, translating current multilateral trust-chain / trust-mark / resolver pressure into SlopOS D-LLM / D-POLICY import language instead of ambient issuer/app-trust folklore

## Revised684 (2026-03-25)
- add `docs/30-architecture/scim-import-boundary-v0.md`, a tight singleton boundary that pins imported SCIM users/groups, memberships, lifecycle operations, search/pagination, discovery/config resources, and version metadata to provider-local provisioning and directory coordination only, so external provisioning APIs do not silently become portable account-directory / group-entitlement / current-user / current-permission / lifecycle-control truth on D-LLM / D-POLICY / IF-ACP
  - wire the new boundary through README/docs indexes, the LLM runbook, posture/profile/history surfaces, boundary singleton coverage, D-POLICY / D-LLM posture docs, assurance registries, bibliography, and tools registry
  - add `tools/check_scim_import_boundary.py` (`EVID-2026-698`) so singleton status, discovery, references, and anti-drift wording fail lint if external provisioning folklore starts widening existing seams
- research / bibliography:
  - add `REF-RFC7642-SCIM-OVERVIEW`, `REF-RFC7643-SCIM-SCHEMA`, `REF-RFC7644-SCIM-PROTOCOL`, and `REF-RFC9865-SCIM-CURSOR`, translating current SCIM provisioning/schema/search pressure into SlopOS D-LLM / D-POLICY import language instead of ambient directory-truth folklore

## Revised683 (2026-03-25)
- add `docs/30-architecture/shared-signals-import-boundary-v0.md`, a tight singleton boundary that pins imported Shared Signals / CAEP / RISC event streams, SET claims, stream metadata, and event types to provider-local security-event coordination only, so external auth-state feeds do not silently become portable login-state / auth-teardown / current-user / approval-basis / current-permission truth on D-LLM / D-POLICY / IF-ACP
  - wire the new boundary through README/docs indexes, the LLM runbook, posture/profile/history surfaces, boundary singleton coverage, D-POLICY / D-LLM posture docs, assurance registries, bibliography, and tools registry
  - add `tools/check_shared_signals_import_boundary.py` (`EVID-2026-697`) so singleton status, discovery, references, and anti-drift wording fail lint if continuous-security folklore starts widening existing seams
- research / bibliography:
  - add `REF-OPENID-SSF-1-0`, `REF-OPENID-CAEP-1-0`, `REF-OPENID-RISC-1-0`, and `REF-RFC8417-SET`, translating current external security-event transport and event vocabularies into SlopOS D-LLM / D-POLICY import language instead of ambient “continuous login state” folklore

## Revised682 (2026-03-25)
- add `docs/30-architecture/authzen-import-boundary-v0.md`, a tight singleton boundary that pins imported AuthZEN access evaluations, batch evaluations, search APIs, PDP metadata/discovery, and request identifiers to provider-local PDP↔PEP coordination only, so external authorization APIs do not silently become portable approval / policy / entitlement / chooser / current-permission truth on D-LLM / D-POLICY / IF-ACP
  - wire the new boundary through README/docs indexes, the LLM runbook, posture/profile/history surfaces, boundary singleton coverage, D-POLICY / D-LLM posture docs, assurance registries, bibliography, and tools registry
  - add `tools/check_authzen_import_boundary.py` (`EVID-2026-696`) so singleton status, discovery, references, and anti-drift wording fail lint if external-authorization folklore starts widening existing seams

## Revised681 (2026-03-23)
- MCP-userinfo import boundary:
  - add `docs/30-architecture/mcp-userinfo-import-boundary-v0.md`, freezing the rule that imported `userinfo_endpoint` locations, Bearer-token profile fetches, returned subject/profile/email claims, `sub`-match validation, and signed/encrypted UserInfo metadata stay provider-local identity/profile retrieval and validation only rather than widening into a portable subject/account/profile export, current-user oracle, approval-basis receipt, contact-card substrate, or durable account/session/auth-state truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so imported UserInfo meaning stays discoverable as provider-local-only archive meaning rather than silently widening into portable profile/account/login truth
- Research / tooling / hygiene:
  - retighten `REF-OPENID-CONNECT-CORE` in `docs/00-meta/bibliography.md`, translating current UserInfo endpoint / claim-set / `sub`-match pressure into SlopOS D-LLM auth language instead of ambient OIDC profile folklore
  - add `tools/check_mcp_userinfo_import_boundary.py` (`EVID-2026-695`) so UserInfo family membership, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised680 (2026-03-23)
- MCP-auth-response-packaging import boundary:
  - add `docs/30-architecture/mcp-auth-response-packaging-import-boundary-v0.md`, freezing the rule that imported JARM response modes, JWT-valued `response` artifacts, response-packaging metadata, and issuer/audience/expiry/signature/decryption validation stay provider-local authorization-response packaging and validation only rather than widening into a portable callback-result artifact, login-result export, auth-proof object, approval-basis blob, or durable account/session/auth-state substrate on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so imported JARM response packaging stays discoverable as provider-local-only archive meaning rather than silently widening into portable callback-result, auth-proof, approval-basis, or durable account/session truth
- Research / tooling / hygiene:
  - add `REF-OPENID-JARM` in `docs/00-meta/bibliography.md`, and retighten `REF-RFC9700-OAUTH-SECURITY` so signed/encrypted authorization-response packaging pressure is translated into SlopOS D-LLM auth language instead of ambient OAuth/OIDC folklore
  - add `tools/check_mcp_auth_response_packaging_import_boundary.py` (`EVID-2026-694`) and retighten `tools/check_auth_mediation_boundary_index.py` so JARM family membership, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised679 (2026-03-23)
- MCP-refresh-token import boundary:
  - add `docs/30-architecture/mcp-refresh-token-import-boundary-v0.md`, freezing the rule that imported `refresh_token`, `grant_type=refresh_token`, `offline_access`, refreshed token-set metadata, client-side token caches, and refresh-token rotation stay provider-local renewal mechanics and provider-owned live auth state only rather than widening into a portable background-renewal substrate, durable login-state oracle, connected-account plane, generic token wallet, or unattended-delegation truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so imported refresh/offline-access meaning stays discoverable as provider-local-only archive meaning rather than silently widening into portable background renewal, durable login-state, connected-account, or token-wallet truth
- Research / tooling / hygiene:
  - retighten `REF-MCP-AUTHORIZATION`, `REF-MCP-AUTHORIZATION-TUTORIAL`, `REF-RFC6749-OAUTH-AUTHZ-FRAMEWORK`, `REF-OPENID-CONNECT-CORE`, and `REF-RFC9700-OAUTH-SECURITY` in `docs/00-meta/bibliography.md`, translating current refresh-token / offline-access / rotation pressure into SlopOS D-LLM auth language instead of ambient OAuth/MCP folklore
  - add `tools/check_mcp_refresh_token_import_boundary.py` (`EVID-2026-693`) and retighten `tools/check_auth_mediation_boundary_index.py` so refresh-token family membership, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised678 (2026-03-23)
- MCP-step-up-auth import boundary:
  - add `docs/30-architecture/mcp-step-up-auth-import-boundary-v0.md`, freezing the rule that imported `insufficient_user_authentication`, `acr_values`, `max_age`, and verifier-visible `acr` / `auth_time` / `amr` stay provider-local reauthentication guidance and verifier context only rather than widening into a portable assurance registry, recent-login oracle, user-presence proof, approval basis, or durable account/session truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so imported step-up-auth meaning stays discoverable as provider-local-only archive meaning rather than silently widening into portable assurance, recent-login, presence, approval-basis, or durable account/session truth
- Research / tooling / hygiene:
  - add `REF-RFC9470-STEP-UP-AUTH` in `docs/00-meta/bibliography.md`, and retighten `REF-MCP-AUTHORIZATION`, `REF-OPENID-CONNECT-CORE`, and `REF-RFC7662-TOKEN-INTROSPECTION` so step-up challenge / auth-assurance / recent-login pressure is translated into SlopOS D-LLM auth language instead of ambient OAuth/OIDC folklore
  - add `tools/check_mcp_step_up_auth_import_boundary.py` (`EVID-2026-692`) and retighten `tools/check_auth_mediation_boundary_index.py` so step-up-auth family membership, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised677 (2026-03-23)
- MCP-authorization-details import boundary:
  - add `docs/30-architecture/mcp-authorization-details-import-boundary-v0.md`, freezing the rule that imported `authorization_details`, per-object `type`, common RAR fields, `authorization_details_types_supported`, granted-detail token/introspection responses, and adjacent RAR metadata/error signaling stay provider-local fine-grained authorization description only rather than widening into a portable approval object, policy blob, entitlement registry, grant-template store, or durable connected-account / login-state substrate on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so imported RAR meaning stays discoverable as provider-local-only archive meaning rather than silently widening into portable approval, policy, entitlement, or durable account truth
- Research / tooling / hygiene:
  - retighten `REF-RFC9396-RICH-AUTHORIZATION-REQUESTS` and add `REF-DRAFT-ZEHAVI-RAR-METADATA` in `docs/00-meta/bibliography.md`, translating current fine-grained OAuth authorization-object, metadata, and inadequate-details signaling pressure into SlopOS D-LLM auth language instead of leaving approval/policy/entitlement meaning as ambient ecosystem folklore
  - add `tools/check_mcp_authorization_details_import_boundary.py` (`EVID-2026-691`) and retighten `tools/check_auth_mediation_boundary_index.py` so RAR family membership, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised676 (2026-03-23)
- MCP-device-authorization import boundary:
  - add `docs/30-architecture/mcp-device-authorization-import-boundary-v0.md`, freezing the rule that imported `device_authorization_endpoint`, `device_code`, `user_code`, `verification_uri`, optional `verification_uri_complete`, expiry / interval / polling-error semantics, and device-flow token acquisition stay provider-local authorization continuation only rather than widening into a portable cross-device auth broker, verification-link handoff plane, polling-status oracle, linked-account selector, or durable connected-account/login-state substrate on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so imported device-flow meaning stays discoverable as provider-local-only archive meaning rather than silently widening into a cross-device auth broker, verification-link handoff plane, polling-status oracle, or durable connected-account/login-state truth
- Research / tooling / hygiene:
  - retighten `REF-RFC8628-DEVICE-GRANT` in `docs/00-meta/bibliography.md` so the exact constrained-input device-flow artifacts and polling/error semantics map into SlopOS auth language instead of ambient OAuth folklore
  - add `tools/check_mcp_device_authorization_import_boundary.py` (`EVID-2026-690`) and retighten `tools/check_auth_mediation_boundary_index.py` so device-flow family membership, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised675 (2026-03-23)
- MCP-auth-request-packaging import boundary:
  - add `docs/30-architecture/mcp-auth-request-packaging-import-boundary-v0.md`, freezing the rule that imported PAR endpoints, `require_pushed_authorization_requests`, returned `request_uri` handles, Request Objects carried by value or reference, `require_signed_request_object`, and request-object capability / algorithm metadata stay provider-local authorization-request staging and packaging only rather than widening into a portable pending-auth handle, approval object, request-template cache, request-policy blob, or durable auth-state / connected-account substrate on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the PAR / Request Object packaging cut instead of rediscovering it from provider metadata, signed request JWT folklore, or `request_uri` convenience wrappers
- Research / tooling / hygiene:
  - retighten `REF-OPENID-DISCOVERY` and `REF-RFC8414-AS-METADATA`, add `REF-RFC9126-PAR` and `REF-RFC9101-JAR` in `docs/00-meta/bibliography.md`, and translate current OAuth request-packaging pressure into SlopOS D-LLM auth language instead of leaving pending-auth / approval / request-policy meaning as ambient ecosystem lore
  - add `tools/check_mcp_auth_request_packaging_import_boundary.py` (`EVID-2026-689`) and retighten `tools/check_auth_mediation_boundary_index.py` so PAR / Request Object family membership, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised674 (2026-03-23)
- MCP-client-assertion import boundary:
  - add `docs/30-architecture/mcp-client-assertion-import-boundary-v0.md`, freezing the rule that imported `client_assertion`, `client_assertion_type`, JWT client-auth claims, `private_key_jwt` / `client_secret_jwt` method choice, and token-endpoint signing/auth-method metadata stay provider-local endpoint client authentication only rather than widening into a portable signer plane, JWT-assertion store, client-identity registry, auth-method oracle, or endpoint-trust substrate on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so imported endpoint client-auth meaning stays discoverable as provider-local-only archive meaning rather than silently widening into signer, assertion-store, client-identity, auth-method, or endpoint-trust truth
- Research / tooling / hygiene:
  - retighten `docs/00-meta/bibliography.md` so `REF-MCP-OAUTH-CLIENT-CREDENTIALS`, `REF-RFC7523-JWT-BEARER`, and `REF-RFC8414-AS-METADATA` explicitly carry current JWT endpoint client-auth pressure — `client_assertion`, verifier-interpreted JWT client-auth claims, `private_key_jwt` / `client_secret_jwt`, and token-endpoint signing/auth-method metadata — instead of leaving endpoint client authentication as ambient OAuth folklore
  - add `tools/check_mcp_client_assertion_import_boundary.py` (`EVID-2026-688`) and retighten `tools/check_auth_mediation_boundary_index.py` so auth-family membership, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised673 (2026-03-23)
- MCP-DPoP import boundary:
  - add `docs/30-architecture/mcp-dpop-import-boundary-v0.md`, freezing the rule that imported DPoP proof JWTs, embedded public keys, `DPoP-Nonce` challenges, DPoP-bound token metadata, and adjacent authorization-server/client metadata stay provider-local sender-constraining and verifier machinery only rather than widening into a portable signer plane, proof cache, nonce cache, token-binding oracle, replay ledger, or durable current-account/session truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so imported DPoP sender-constraining remains discoverable as provider-local-only meaning rather than silently widening into signer, replay, token-binding, or durable account/session truth
- Research / tooling / hygiene:
  - add `REF-MCP-ROADMAP-2026` to `docs/00-meta/bibliography.md`, retighten `REF-RFC9449-DPOP`, and use them to justify freezing active upstream DPoP work as provider-local-only archive meaning before portable signer/proof folklore regrows
  - add `tools/check_mcp_dpop_import_boundary.py` (`EVID-2026-687`) and retighten `tools/check_auth_mediation_boundary_index.py` so DPoP family membership, discovery, references, and anti-drift wording fail lint if they fall out of sync

## Revised672 (2026-03-23)
- MCP-token-revocation import boundary:
  - add `docs/30-architecture/mcp-token-revocation-import-boundary-v0.md`, freezing the rule that imported `revocation_endpoint`, revocation requests carrying `token` / optional `token_type_hint`, success-on-invalid response behavior, propagation-delay / grant-cascade policy, and revocation-endpoint auth-method metadata stay provider-local auth-teardown machinery only rather than widening into a portable disconnect control plane, linked-account / connected-service truth, durable live-login-state oracle, account-unlink substrate, or transcript-stable revocation ledger on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the revocation / disconnect cut instead of rediscovering it from endpoint metadata, 200-on-invalid folklore, or centralized-revocation promises
- Research / tooling / hygiene:
  - retighten `REF-RFC7009-TOKEN-REVOCATION`, `REF-RFC8414-AS-METADATA`, and `REF-MCP-ENTERPRISE-MANAGED-AUTH` in `docs/00-meta/bibliography.md`, translating current OAuth/MCP revocation pressure into SlopOS D-LLM auth language instead of leaving disconnect/account/live-state meaning as ambient ecosystem lore
  - add `tools/check_mcp_token_revocation_import_boundary.py` (`EVID-2026-686`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised671 (2026-03-23)
- MCP-token-introspection import boundary:
  - add `docs/30-architecture/mcp-token-introspection-import-boundary-v0.md`, freezing the rule that imported `introspection_endpoint`, verifier-side `active` / token metadata responses, and verifier cache/eviction pressure stay provider-local verifier input only rather than widening into a portable live login-state oracle, grant inventory, subject/account export, connected-service registry, or durable current-session truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the verifier-response cut instead of rediscovering it from `active` bits, token metadata, or verifier-side cache folklore
- Research / tooling / hygiene:
  - add `REF-MCP-AUTHORIZATION-TUTORIAL` to `docs/00-meta/bibliography.md`, and retighten `REF-RFC7662-TOKEN-INTROSPECTION`, translating current MCP verifier-side token introspection pressure into SlopOS D-LLM auth language instead of leaving live token-verdict and cache meaning as ambient OAuth/MCP lore
  - add `tools/check_mcp_token_introspection_import_boundary.py` (`EVID-2026-685`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised670 (2026-03-23)
- MCP-ID-JAG import boundary:
  - add `docs/30-architecture/mcp-id-jag-import-boundary-v0.md`, freezing the rule that saved enterprise Identity Assertions (OpenID ID Tokens / SAML assertions), token-exchange `subject_token` use, typed ID-JAGs, carried identity/authorization claims, and refresh-driven ID-JAG renewal stay provider-local cross-domain authorization bootstrap only rather than widening into a portable SSO-proof plane, subject-token store, cross-domain account-binding substrate, approval-basis seam, or durable login-state truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the enterprise identity-assertion / ID-JAG cut instead of rediscovering it from SSO, token-exchange, or account-linking folklore
- Research / tooling / hygiene:
  - add `REF-IETF-DRAFT-ID-JAG` and `REF-RFC8693-TOKEN-EXCHANGE` to `docs/00-meta/bibliography.md`, and retighten `REF-MCP-ENTERPRISE-MANAGED-AUTH` plus `REF-RFC7523-JWT-BEARER`, translating current MCP enterprise identity-assertion / ID-JAG exchange pressure into SlopOS D-LLM auth language instead of leaving cross-domain enterprise auth meaning as ambient OAuth/MCP lore
  - add `tools/check_mcp_id_jag_import_boundary.py` (`EVID-2026-684`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised669 (2026-03-23)
- MCP-JWKS import boundary:
  - add `docs/30-architecture/mcp-jwks-import-boundary-v0.md`, freezing the rule that imported JWT verifier-key handling (`jwks_uri`, fetched JWK Sets, verifier-key selection fields such as `kid` / `kty` / `use`, and live key rotation/refresh) stays provider-local verifier input only rather than widening into a portable trust-root plane, signer registry, issuer-identity oracle, key-rotation oracle, or durable current-auth-state truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the verifier-key cut instead of rediscovering it from JWKS caches, `kid` selection, or key-rotation folklore
- Research / tooling / hygiene:
  - add `REF-RFC7517-JWK` to `docs/00-meta/bibliography.md`, and retighten `REF-MCP-OAUTH-CLIENT-CREDENTIALS` plus `REF-MCP-ENTERPRISE-MANAGED-AUTH`, translating current MCP JWT/JWKS verifier-key pressure into SlopOS D-LLM auth language instead of leaving verifier-key meaning as ambient OAuth/MCP lore
  - add `tools/check_mcp_jwks_import_boundary.py` (`EVID-2026-683`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised668 (2026-03-23)
- MCP-client-credentials import boundary:
  - add `docs/30-architecture/mcp-client-credentials-import-boundary-v0.md`, freezing the rule that imported MCP OAuth Client Credentials extension support (extension negotiation, no-user machine auth, pre-connect token acquisition, JWT bearer assertions, client-secret authentication, and token-endpoint auth-method selection) stays provider-local machine-auth bootstrap only rather than widening into portable workload identity, service-account registry, client-secret store, signer/JWKS discovery, or durable connected-service truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the machine-auth cut instead of rediscovering it from service-account, workload-identity, or client-secret folklore
- Research / tooling / hygiene:
  - add `REF-MCP-OAUTH-CLIENT-CREDENTIALS`, `REF-MCP-SEP-1046`, and `REF-RFC7523-JWT-BEARER` to `docs/00-meta/bibliography.md`, translating the current MCP machine-auth extension and its intentionally incomplete JWT/JWKS profiling into SlopOS D-LLM auth language instead of leaving service-account / workload-identity pressure as ambient ecosystem lore
  - add `tools/check_mcp_client_credentials_import_boundary.py` (`EVID-2026-682`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised667 (2026-03-23)
- MCP-caller-auth-binding import boundary:
  - add `docs/30-architecture/mcp-caller-auth-binding-import-boundary-v0.md`, freezing the rule that imported MCP session IDs, inbound-request verification, “sessions are not authentication”, URL-mode same-user checks, and adjacent persistent-auth / per-tool-auth pressure stay provider-local caller-binding and live auth-state mechanics only rather than widening into portable current-user export, caller-identity truth, per-tool authorization registries, tenant-selection substrate, or durable server-authorized-for-user truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the caller/session-auth cut instead of rediscovering it from session caches, same-user URL checks, or per-tool-auth folklore
- Research / tooling / hygiene:
  - add `REF-MCP-SECURITY-BEST-PRACTICES` and `REF-MCP-CALLER-IDENTITY-CONFUSION` to `docs/00-meta/bibliography.md`, translating official MCP session-auth guidance and current caller-identity confusion findings into SlopOS D-LLM auth language instead of leaving current-user / per-tool-auth pressure as ambient ecosystem lore
  - add `tools/check_mcp_caller_auth_binding_import_boundary.py` (`EVID-2026-681`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised666 (2026-03-23)
- MCP-PKCE import boundary:
  - add `docs/30-architecture/mcp-pkce-import-boundary-v0.md`, freezing the rule that imported MCP PKCE handling (`code_verifier` / `code_challenge` pairs, `S256` preference, metadata checks for `code_challenge_methods_supported`, and refusal to proceed without confirmed support) stays provider-local authorization code-binding only rather than widening into portable verifier/proof truth, a PKCE-capability oracle, pending-auth continuation handles, or durable approval/account truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the PKCE code-binding cut instead of rediscovering it from verifier/challenge, S256, support-detection, or continuation folklore
- Research / tooling / hygiene:
  - retighten `docs/00-meta/bibliography.md` so `REF-MCP-AUTHORIZATION`, `REF-RFC7636-PKCE`, and `REF-RFC8414-AS-METADATA` explicitly carry the current PKCE pressure around verifier/challenge pairs, `S256`, metadata-confirmed support detection, and refusal-to-proceed rules instead of leaving provider-local PKCE handling as ambient OAuth/MCP lore
  - add `tools/check_mcp_pkce_import_boundary.py` (`EVID-2026-680`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised665 (2026-03-23)
- MCP-auth-redirect import boundary:
  - add `docs/30-architecture/mcp-auth-redirect-import-boundary-v0.md`, freezing the rule that imported MCP/OAuth redirect handling (registered `redirect_uri`, exact redirect matching, `localhost`/HTTPS constraints, state verification, localhost warning/display guidance, and native-app private-use / app-claimed-HTTPS / loopback return patterns) stays provider-local authorization return-channel mechanics only rather than widening into portable callback registration, deep-link reentry, browser-auth/session, loopback-listener allocation, or auth-result truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, the assurance registries, and `tools/README.md` so future auth/LLM passes re-find the redirect-return cut instead of rediscovering it from callback, deep-link, selected-browser, or loopback-listener folklore
- Research / tooling / hygiene:
  - retighten `docs/00-meta/bibliography.md` so `REF-MCP-AUTHORIZATION`, `REF-OAUTH-CLIENT-ID-METADATA`, `REF-RFC8252-NATIVE-APPS`, and `REF-RFC9700-OAUTH-SECURITY` explicitly carry the current redirect/return-channel pressure around exact redirect matching, localhost warnings, native-app private-use / claimed-HTTPS / loopback patterns, and loopback-port flexibility instead of leaving callback/browser/listen meaning as ambient OAuth/MCP lore
  - add `tools/check_mcp_auth_redirect_import_boundary.py` (`EVID-2026-679`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised664 (2026-03-23)
- MCP-client-trust-policy import boundary:
  - add `docs/30-architecture/mcp-client-trust-policy-import-boundary-v0.md`, freezing the rule that imported MCP authorization trust policies (trusted-client host/domain allowlists, open-server `accept any HTTPS client_id` posture, reputation checks, domain-age / certificate-validation restrictions, and prominent client/CIMD hostname display) stay provider-local client trust evaluation only rather than widening into a portable trusted-app registry, approval-basis substrate, signer/trust-root plane, or durable connected-app/account truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the client-trust-policy cut instead of rediscovering it from trusted-host allowlists, HTTPS-acceptance posture, reputation checks, or phishing-hostname folklore
- Research / tooling / hygiene:
  - retighten `docs/00-meta/bibliography.md` so `REF-MCP-AUTHORIZATION`, `REF-MCP-SEP-991`, `REF-OAUTH-CLIENT-ID-METADATA`, and `REF-MCP-AUTH-SECURITY` explicitly carry the current MCP trust-policy pressure around trusted client hosts, open-server HTTPS acceptance, reputation/certificate checks, and hostname-display phishing mitigation instead of leaving provider-side client trust evaluation as ambient OAuth/MCP lore
  - add `tools/check_mcp_client_trust_policy_import_boundary.py` (`EVID-2026-678`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised663 (2026-03-23)
- MCP-auth-exact-match import boundary:
  - add `docs/30-architecture/mcp-auth-exact-match-import-boundary-v0.md`, freezing the rule that imported MCP/OAuth exact-match auth binding (Protected Resource Metadata `resource` equality, Authorization Server Metadata / OIDC `issuer` equality, and authorization-response `iss` equality) stays provider-local exact-match validation only rather than widening into portable issuer/resource identity, account-binding truth, response-verdict semantics, or durable approval/evidence artifacts on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future auth/LLM passes re-find the exact-match binding cut instead of rediscovering it from fetched `resource`, fetched `issuer`, or authorization-response `iss` folklore
- Research / tooling / hygiene:
  - add `REF-RFC9207-AUTHZ-SERVER-ISSUER` to `docs/00-meta/bibliography.md`, and retighten `REF-RFC9728-PROTECTED-RESOURCE-METADATA` plus `REF-RFC8414-AS-METADATA`, translating current exact-match resource/issuer/response-binding pressure into SlopOS D-LLM auth language instead of leaving it as ambient OAuth lore
  - add `tools/check_mcp_auth_exact_match_import_boundary.py` (`EVID-2026-677`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised662 (2026-03-23)
- MCP-auth-metadata-fetch import boundary:
  - add `docs/30-architecture/mcp-auth-metadata-fetch-import-boundary-v0.md`, freezing the rule that imported MCP/OAuth authorization metadata fetches, cache rows, and network validation stay provider-local fetch/caching policy only rather than widening into a portable metadata-cache substrate, issuer-trust oracle, endpoint pinset, SSRF policy plane, or durable approval/evidence artifact on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future auth/LLM passes re-find the fetched-metadata/cache cut instead of rediscovering it from issuer pinning, cache reuse, DNS validation, or egress-policy folklore
- Research / tooling / hygiene:
  - retighten `docs/00-meta/bibliography.md` so `REF-MCP-AUTHORIZATION`, `REF-MCP-AUTH-SECURITY`, `REF-RFC9728-PROTECTED-RESOURCE-METADATA`, and `REF-RFC8414-AS-METADATA` explicitly carry the current MCP/OAuth metadata-fetch, cache, and network-validation pressure instead of leaving fetched auth metadata as ambient OAuth/MCP lore
  - add `tools/check_mcp_auth_metadata_fetch_import_boundary.py` (`EVID-2026-676`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised661 (2026-03-23)
- MCP-authorization-context import boundary:
  - add `docs/30-architecture/mcp-authorization-context-import-boundary-v0.md`, freezing the rule that imported MCP `scope` challenges, `scopes_supported`, step-up scope handling, and OAuth `resource` targeting stay provider-local authorization guidance only rather than widening into a portable grant inventory, entitlement oracle, service-identity registry, or durable approval/account truth on existing SlopOS seams
  - wire the new auth-mediation family member through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the discovery/control/assurance surfaces keep the new meaning pin recoverable
  - add `tools/check_mcp_authorization_context_import_boundary.py` and register **EVID-2026-675**, so the new boundary and its same-revision archive wiring are machine-checked instead of reviewer-memory-only

## Revised660 (2026-03-23)
- MCP-token-passthrough import boundary:
  - add `docs/30-architecture/mcp-token-passthrough-import-boundary-v0.md`, freezing the rule that imported MCP audience-bound access-token checks, no-token-passthrough requirements, resource-specific upstream token handling, and URL-mode third-party auth token splits stay provider-local token-boundary mechanics only rather than widening into a portable token relay, reverse-proxy API substrate, external-service credential export path, callback-token mailbox, or durable token/session broker on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future auth/LLM passes re-find the imported token-separation cut instead of rediscovering it from bearer-proxy, reverse-proxy, or external-service-credential folklore
- Research / tooling / hygiene:
  - retighten `docs/00-meta/bibliography.md` so `REF-MCP-AUTHORIZATION`, `REF-MCP-AUTH-SECURITY`, `REF-MCP-ELICITATION`, and `REF-RFC8707-RESOURCE-INDICATORS` explicitly carry the current MCP audience-binding, no-token-passthrough, URL-mode third-party auth, and upstream-resource-token distinctions instead of leaving token-boundary meaning as ambient OAuth/MCP lore
  - add `tools/check_mcp_token_passthrough_import_boundary.py` (`EVID-2026-674`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised659 (2026-03-22)
- MCP-auth-discovery import boundary:
  - add `docs/30-architecture/mcp-auth-discovery-import-boundary-v0.md`, freezing the rule that imported MCP authorization discovery (Protected Resource Metadata, `WWW-Authenticate` `resource_metadata` / `scope` challenges, `authorization_servers`, and Authorization Server Metadata / OpenID discovery) stays provider-local authorization discovery only rather than widening into a portable issuer registry, authorization-server catalog, scope/tenant/policy oracle, callback authority, or trust/cache substrate on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future auth/LLM passes re-find the imported discovery cut instead of rediscovering it from issuer, scope, callback, or trust-cache folklore
- Research / tooling / hygiene:
  - add `REF-MCP-SEP-985` to `docs/00-meta/bibliography.md` and retighten `REF-MCP-AUTH-SECURITY`, translating the current MCP protected-resource / authorization-server discovery chain plus its SSRF pressure into SlopOS D-LLM auth language instead of leaving fetched auth metadata as ambient OAuth folklore
  - add `tools/check_mcp_auth_discovery_import_boundary.py` (`EVID-2026-673`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised658 (2026-03-22)
- MCP-client-registration import boundary:
  - add `docs/30-architecture/mcp-client-registration-import-boundary-v0.md`, freezing the rule that imported MCP authorization client-registration/bootstrap (preregistration, Dynamic Client Registration, and Client ID Metadata Documents / URL-based `client_id` flows) stays provider-local authorization bootstrap only rather than widening into a portable software-identity oracle, redirect/callback authority, client-registration inventory/admin plane, trust-policy oracle, or authorization-continuation substrate on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/auth passes re-find the imported client-registration cut instead of rediscovering it from app identity, callback, or policy folklore
- Research / tooling / hygiene:
  - add `REF-MCP-SEP-991`, `REF-OAUTH-CLIENT-ID-METADATA`, and `REF-MCP-AUTH-SECURITY` to `docs/00-meta/bibliography.md`, translating the current MCP client-registration direction plus its security pressure into SlopOS D-LLM/auth language instead of leaving URL-based `client_id` and DCR semantics as ambient OAuth folklore
  - add `tools/check_mcp_client_registration_import_boundary.py` (`EVID-2026-672`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised657 (2026-03-22)
- MCP-enterprise-managed-auth import boundary:
  - add `docs/30-architecture/mcp-enterprise-managed-auth-import-boundary-v0.md`, freezing the rule that imported MCP Enterprise-Managed Authorization (`io.modelcontextprotocol/enterprise-managed-authorization`, enterprise-IdP redirect/routing, organization-level IdP configuration, scope-restricted IdP-issued tokens, and centralized policy/revocation) stays provider-local authorization routing only rather than widening into a portable enterprise-policy oracle, account-binding export, authorization-context export, login-state oracle, browser-session continuity plane, or token/callback broker
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future auth/LLM passes re-find the imported enterprise-auth cut instead of rediscovering it from enterprise policy, connected-account, or login-state folklore
- Research / tooling / hygiene:
  - add `REF-MCP-AUTHORIZATION` and `REF-MCP-AUTH-EXTENSIONS` to `docs/00-meta/bibliography.md`, expand `REF-MCP-ENTERPRISE-MANAGED-AUTH`, and repair the `REF-OPENAI-APPS-SDK-AUTH` / enterprise-auth bibliography split so current MCP enterprise auth semantics stay translated into SlopOS D-LLM language rather than drifting as vendor-memory residue
  - add `tools/check_mcp_enterprise_managed_auth_import_boundary.py` (`EVID-2026-671`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised656 (2026-03-22)
- MCP-elicitation import boundary:
  - add `docs/30-architecture/mcp-elicitation-import-boundary-v0.md`, freezing the rule that imported MCP elicitation (`elicitation/create`, `mode: "form"|"url"`, bounded `requestedSchema`, response `action: "accept"|"decline"|"cancel"`, optional `notifications/elicitation/complete`, and `URLElicitationRequiredError`) stays provider-local request-scoped user-input mechanics only rather than widening into a portable inline secret-ingress plane, browser/session authority, callback/completion substrate, login-result artifact, or durable auth-state oracle on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/llm-elicitation-boundary-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/auth passes re-find the imported elicitation cut instead of rediscovering it from hidden browser, callback, or login folklore
- Research / tooling / hygiene:
  - tighten `docs/00-meta/bibliography.md` so `REF-MCP-ELICITATION` now records current MCP form/url modes, bounded request-schema defaults, response actions, URL-mode completion notifications, and the no-token-passthrough split, and keep `REF-MCP-REQ-ASSOCIATION` carrying the request-association rule for `elicitation/create`
  - add `tools/check_mcp_elicitation_import_boundary.py` (`EVID-2026-670`), so the new discovery/assurance wiring and its “form/url user-input requests are not secret/browser/callback truth” posture remain machine-checked rather than reviewer-memory-only
  - repair `docs/00-meta/profile-posture-matrix.md` so the existing MCP-completion singleton boundary regains an explicit profile row instead of surviving only as a note

## Revised655 (2026-03-22)
- MCP-completion import boundary:
  - add `docs/30-architecture/mcp-completion-import-boundary-v0.md`, freezing the rule that imported MCP completion (`completion/complete`, `ref/prompt`, `ref/resource`, argument-prefix matching, optional `context.arguments`, and bounded `completion.values` / `total` / `hasMore`) stays provider-local suggestion mechanics only rather than widening into a portable selector/default plane, chooser receipt, workflow/policy shortcut, file/document/workspace grant, or current-state oracle on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/mcp-prompt-import-boundary-v0.md`, `docs/30-architecture/mcp-resource-import-boundary-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/completion passes re-find the new argument-suggestion cut instead of rediscovering it from chooser/default/workflow folklore
- Research / tooling:
  - add `REF-MCP-COMPLETION` to `docs/00-meta/bibliography.md`, translating the current MCP completion spec (prompt/resource-template references, argument-prefix matching, optional argument context, bounded `completion.values`, and `total` / `hasMore`) into SlopOS D-LLM language instead of letting provider-local suggestion helpers turn into a second selector/default story
  - add `tools/check_mcp_completion_import_boundary.py` (`EVID-2026-669`), so the new discovery/assurance wiring and its “argument suggestions are not selector/default/workflow truth” posture remain machine-checked rather than reviewer-memory-only

## Revised654 (2026-03-22)
- MCP-sampling import boundary:
  - add `docs/30-architecture/mcp-sampling-import-boundary-v0.md`, freezing the rule that imported MCP sampling (`sampling/createMessage`, returned assistant messages, optional nested tool use, model preferences, and request-association rules) stays provider-local nested model-generation mechanics only rather than widening into a portable planner/assistant substrate, background-autonomy plane, durable conversation thread, queue/completion oracle, or hidden approval/policy truth on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/sampling passes re-find the new nested-model cut instead of rediscovering it from planner, assistant-thread, or background-agent folklore
- Research / tooling:
  - add `REF-MCP-SAMPLING` and `REF-MCP-REQ-ASSOCIATION` to `docs/00-meta/bibliography.md`, translating the current MCP sampling spec plus the accepted request-association clarification into SlopOS D-LLM / D-JOBS / D-BGLEASE / IF-ACP language instead of letting nested provider-local model calls turn into a second planner/background story
  - add `tools/check_mcp_sampling_import_boundary.py` (`EVID-2026-668`), so the new discovery/assurance wiring and its “nested sampling is not portable planner/background truth” posture remain machine-checked rather than reviewer-memory-only

## Revised653 (2026-03-22)
- MCP-resource import boundary:
  - add `docs/30-architecture/mcp-resource-import-boundary-v0.md`, freezing the rule that imported MCP resources (`resources/list`, `resources/read`, `resources/templates/list`, subscriptions/update notifications, URI/templates, annotations, and text/blob contents) stay provider-local context material only rather than widening into a portable filesystem/document grant, chooser-result, recursive inventory/watch plane, import-to-docref shortcut, or current-resource oracle on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/import-to-docref-boundary-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/resource passes re-find the new resource/import cut instead of rediscovering it from workspace, picker, or file-handle folklore
- Research / tooling:
  - add `REF-MCP-RESOURCES` to `docs/00-meta/bibliography.md`, translating the current MCP resources spec (resource catalogs, direct reads, parameterized templates, list/update notifications, subscriptions, URI identities, annotations, and text/blob contents) into SlopOS D-LLM / D-PLUMB language instead of letting provider-local resource catalogs turn into a second filesystem/document/watch story
  - add `tools/check_mcp_resource_import_boundary.py` (`EVID-2026-667`), so the new discovery/document-import/assurance wiring and its “resource catalogs are not file/document/watch truth” posture remain machine-checked rather than reviewer-memory-only

## Revised652 (2026-03-22)
- MCP-prompt import boundary:
  - add `docs/30-architecture/mcp-prompt-import-boundary-v0.md`, freezing the rule that imported MCP prompts (`prompts/list`, `prompts/get`, `notifications/prompts/list_changed`, prompt messages, and embedded resources) stay provider-local proposal/catalog material only rather than widening into a portable workflow/policy plane, command-registration substrate, hidden-selector truth, or approval/evidence plane on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, and the assurance registries so future LLM/prompt passes re-find the new prompt/import cut instead of rediscovering it from slash-command or template folklore
- Research / tooling:
  - add `REF-MCP-PROMPTS` to `docs/00-meta/bibliography.md`, translating the current MCP prompts spec (user-controlled prompt catalogs, prompt retrieval, list-changed notices, structured prompt messages, embedded resources, and validation/injection warnings) into SlopOS D-LLM / D-PLUMB / IF-ACP language instead of letting provider-local prompt templates turn into a second workflow/policy story
  - add `tools/check_mcp_prompt_import_boundary.py` (`EVID-2026-666`), so the new discovery/assurance wiring and its “prompt templates are not workflow/policy truth” posture remain machine-checked rather than reviewer-memory-only

## Revised651 (2026-03-22)
- MCP-logging import boundary:
  - add `docs/30-architecture/mcp-logging-import-boundary-v0.md`, freezing the rule that imported MCP logging (logging/setLevel plus notifications/message carrying `level`, optional `logger`, and structured `data`) stays provider-local diagnostic signaling only rather than widening into a portable transcript/export substrate, durable evidence stream, or log-policy/admin plane on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/observation-export-posture-v0.md`, `docs/30-architecture/transcript-contract.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/diagnostics passes re-find the new logging/import cut instead of rediscovering it from provider log folklore
- Research / tooling:
  - add `REF-MCP-LOGGING` to `docs/00-meta/bibliography.md`, translating the current MCP logging utility (logging/setLevel, notifications/message, syslog-style severities, optional logger names, JSON data payloads, and explicit secret/PII/internal-detail warnings) into SlopOS D-LLM / D-OBS / IF-OBS language instead of letting provider-local diagnostics turn into a second transcript/evidence story
  - add `tools/check_mcp_logging_import_boundary.py` (`EVID-2026-665`), so the new discovery/transcript/observation/assurance wiring and its “logging notifications are not portable transcript/export truth” posture remain machine-checked rather than reviewer-memory-only

## Revised650 (2026-03-22)
- MCP-roots import boundary:
  - add `docs/30-architecture/mcp-roots-import-boundary-v0.md`, freezing the rule that imported MCP roots (`roots/list`, `notifications/roots/list_changed`, exact `Root.uri`, and optional `Root.name`) stay provider-local workspace hints only rather than widening into a portable filesystem grant, directory chooser result, recursive inventory/watch plane, import-to-docref shortcut, or current-workspace oracle on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/powerbox-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/import-to-docref-boundary-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/filesystem passes re-find the new roots/import cut instead of rediscovering it from workspace or editor folklore
- Research / tooling:
  - add `REF-MCP-ROOTS` to `docs/00-meta/bibliography.md`, translating the current MCP roots utility (explicit `roots/list`, optional `notifications/roots/list_changed`, current `file://` root URIs, and consent-oriented workspace/root management guidance) into SlopOS D-LLM / D-POWERBOX / D-CAPX language instead of letting provider-local workspace hints turn into a second filesystem-authority story
  - add `tools/check_mcp_roots_import_boundary.py` (`EVID-2026-664`), so the new discovery/assurance wiring and its “roots are not portable filesystem grant or inventory truth” posture remain machine-checked rather than reviewer-memory-only

## Revised649 (2026-03-22)
- MCP-progress import boundary:
  - add `docs/30-architecture/mcp-progress-import-boundary-v0.md`, freezing the rule that imported MCP progress tracking (`progressToken`, `notifications/progress`, task-lifetime progress continuity, numeric `progress` / `total`, and human-readable `message`) stays provider-local liveness signaling only rather than widening into a portable queue/progress watch, completion receipt, or current-state plane on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/protocol passes re-find the new progress/liveness cut instead of rediscovering it from host/runtime folklore
- Research / tooling:
  - add `REF-MCP-PROGRESS` to `docs/00-meta/bibliography.md`, translating the current MCP progress utility (active-request-scoped `progressToken`, optional `notifications/progress`, receiver-chosen rate/frequency, and task-lifetime token continuity) into SlopOS D-LLM / D-JOBS / D-BGLEASE / IF-ACP language instead of letting provider-local liveness hints turn into a second queue/progress story
  - add `tools/check_mcp_progress_import_boundary.py` (`EVID-2026-663`), so the new discovery/assurance wiring and its “progress notifications are not portable progress/completion truth” posture remain machine-checked rather than reviewer-memory-only

## Revised648 (2026-03-22)
- MCP-task import boundary:
  - add `docs/30-architecture/mcp-task-import-boundary-v0.md`, freezing the rule that imported MCP task augmentation (`CreateTaskResult`, `tasks/get|result|list|cancel`, status notifications, and task-required tool execution) stays provider-local deferred-result mechanics rather than widening into a portable background-work, queue/status, or persistence plane on existing SlopOS seams
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, and the adjacent D-JOBS / D-BGLEASE posture docs so future LLM/deferred-work passes re-find the new task-wrapper cut instead of rediscovering it from host/runtime folklore
- Research / tooling:
  - add `REF-MCP-TASKS` to `docs/00-meta/bibliography.md`, translating the current MCP task model (durable task state, polling/deferred result retrieval, task-required tool execution, and model-immediate-response guidance) into SlopOS D-LLM / D-JOBS / D-BGLEASE / IF-ACP language instead of letting provider-local task wrappers turn into a second scheduler story
  - add `tools/check_mcp_task_import_boundary.py` (`EVID-2026-662`), so the new discovery/assurance wiring and its “deferred result wrappers are not a background-work substrate” posture remain machine-checked rather than reviewer-memory-only

## Revised647 (2026-03-22)
- Tool-result visibility boundary:
  - add `docs/30-architecture/tool-result-visibility-boundary-v0.md`, freezing the rule that model-visible `structuredContent` / `content` and component-only `_meta` are audience-scoped tool-result lanes only rather than a hidden approval, authority, or evidence plane
  - tighten `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, and the assurance registries so future LLM/tooling passes re-find the result-lane cut instead of relearning it from provider folklore
- Research / tooling:
  - translate the current Apps SDK tool-result split (`structuredContent` / `content` transcript-visible, `_meta` component-only) into SlopOS D-LLM / D-UICAP / IF-ACP language using the existing primary references `REF-MCP-TOOLS`, `REF-OPENAI-APPS-SDK-REFERENCE`, and `REF-OPENAI-APPS-SDK-SERVER`
  - add `tools/check_tool_result_visibility_boundary.py` (`EVID-2026-661`), so the result-visibility cut stays machine-checked instead of drifting back into reviewer memory

## Revised646 (2026-03-22)
- Tool-annotation semantics boundary:
  - add `docs/30-architecture/tool-annotation-semantics-boundary-v0.md`, freezing the rule that imported `readOnlyHint`, `destructiveHint`, `openWorldHint`, and `idempotentHint` metadata stay advisory only rather than widening into portable approval, authorization, retry-safety, or commutativity truth on existing SlopOS seams
  - tighten `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/llm-runbook.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM passes re-find the new hint-semantics cut together with the existing explicit-catalog / no-hidden-discovery posture and explicit D-COMMUTE evidence surfaces
  - wire the new cut into `docs/20-assurance/invariant-registry.md` and `docs/20-assurance/proof-obligation-registry.md`, so imported tool hints cannot silently regrow a hidden effect taxonomy, approval shortcut, or commutativity oracle
- Research / tooling:
  - reuse `REF-MCP-TOOLS`, `REF-OPENAI-APPS-SDK-REFERENCE`, `REF-OPENAI-APPS-SDK-SUBMISSION-GUIDELINES`, and `REF-OPENAI-API-DEVELOPER-MODE`, translating current tool-annotation / approval-filter pressure into SlopOS D-LLM / IF-ACP / D-COMMUTE language instead of leaving effect classification as host/provider folklore
  - add `tools/check_tool_annotation_semantics_boundary.py` (`EVID-2026-660`), so the new discovery/assurance wiring and its “tool hints are advisory only” posture remain machine-checked rather than reviewer-memory-only

## Revised645 (2026-03-22)
- Connector/tool-policy boundary:
  - add `docs/30-architecture/connector-tool-policy-boundary-v0.md`, freezing the rule that host-local/request-local connector toggles, enabled-tool policy, metadata refresh, usage limits, and `allowed_tools` filters do not widen into a portable connector-admin or tool-policy plane on existing SlopOS seams
  - tighten `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/llm-runbook.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM passes re-find the connector/tool-policy cut together with the existing explicit-catalog / no-hidden-discovery posture
  - wire the new cut into `docs/20-assurance/invariant-registry.md` and `docs/20-assurance/proof-obligation-registry.md`, so visible tool catalogs cannot silently regrow a hidden connector-admin, disabled-tool-introspection, or request-policy-truth plane
- Research / tooling:
  - add `REF-OPENAI-API-DEVELOPER-MODE`, `REF-OPENAI-APPS-SDK-CONNECT-CHATGPT`, `REF-OPENAI-API-MCP-CONNECTORS`, and `REF-MCP-REMOTE-CONNECTORS` to `docs/00-meta/bibliography.md`, translating current connector toggles, metadata refresh, usage limits, and request-local `allowed_tools` pressure into SlopOS D-LLM language instead of leaving connector-management semantics as host/provider folklore
  - add `tools/check_connector_tool_policy_boundary.py` (`EVID-2026-659`), so the new discovery/assurance wiring and its “no portable connector-admin or tool-policy export seam” posture remain machine-checked rather than reviewer-memory-only

## Revised644 (2026-03-22)
- Account-binding export boundary:
  - add `docs/30-architecture/account-binding-export-boundary-v0.md`, freezing the rule that explicit local login, linking, or provider-owned account mapping do not widen into a portable linked-account / connected-account / selected-account / default-account plane on existing SlopOS seams
  - tighten `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/llm-runbook.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future auth/LLM passes re-find the new account-binding cut together with the existing auth-link trigger, auth-result, identity-claim, login-state, and auth-teardown cuts
  - wire the new cut into `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md`, so provider-local account mapping cannot silently regrow a hidden connector/account oracle through secret, approval, or vault prose
- Research / tooling:
  - add `REF-MCP-ENTERPRISE-MANAGED-AUTH` to `docs/00-meta/bibliography.md` and reuse `REF-OPENAI-APPS-SDK-AUTH` / `REF-OPENAI-APPS-SDK-STATE`, translating current “map ChatGPT identities to your internal accounts” and enterprise SSO/cross-app-access pressure into SlopOS D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB language instead of leaving connected-account behavior as host/provider folklore
  - add `tools/check_account_binding_export_boundary.py` (`EVID-2026-658`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery/assurance wiring are machine-checked rather than reviewer-memory-only

## Revised643 (2026-03-22)
- Auth-link UI trigger boundary:
  - add `docs/30-architecture/auth-link-ui-trigger-boundary-v0.md`, freezing the rule that auth metadata/challenges may ask the host to offer local linking UI, but they do not widen into a portable account-linking, account-choice, or auth-broker trigger plane
  - tighten `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/llm-runbook.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future auth/LLM passes re-find the auth-link trigger seam together with the existing elicitation, browser-session-export, continuation-export, auth-result-export, auth-proof-export, authorization-context-export, identity-claim-export, login-state-export, and auth-teardown cuts
  - wire the new cut into `docs/30-architecture/powerbox-posture-v0.md` and `docs/30-architecture/plumb-posture-v0.md`, so host-offered linking UI cannot silently regrow chooser truth, callback/mailbox behavior, or an account-broker plane outside existing explicit seams
- Research / tooling:
  - add `REF-OPENAI-APPS-SDK-AUTH` and `REF-RFC9728-PROTECTED-RESOURCE-METADATA` to `docs/00-meta/bibliography.md`, translating current auth-linking metadata/challenge semantics into SlopOS D-LLM / D-POWERBOX / D-UICAP / D-PLUMB language instead of leaving connector/linking behavior as host folklore
  - add `tools/check_auth_link_ui_trigger_boundary.py` (`EVID-2026-657`) and retighten `tools/check_auth_mediation_boundary_index.py`, so the new auth-family member and its discovery wiring are machine-checked rather than reviewer-memory-only

## Revised642 (2026-03-22)
- Rendered tool-UI display-surface boundary:
  - add `docs/30-architecture/tool-ui-display-surface-boundary-v0.md`, freezing the rule that widget-requested display modes, host-owned modals, and widget close requests stay host-owned presentation choreography rather than widening into a hidden widget-owned foreground/focus/trusted-modal plane or workflow-truth shortcut
  - tighten `docs/30-architecture/tool-ui-boundary-index.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/llm-runbook.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/UI passes re-find the widget display-surface seam together with the existing presentation-only, no-hidden-widget-action-plane, no-hidden-widget-memory/policy, no-hidden-widget-file/materialization/export, no-hidden-widget-user-speech/transcript-mutation, and no-hidden-widget-browser/navigation/session cuts
  - wire the new cut into `docs/30-architecture/uicap-scope-posture-v0.md` and `docs/30-architecture/powerbox-posture-v0.md`, so fullscreen/PiP/modal convenience cannot silently regrow trusted UI, chooser, or workflow-completion meaning outside existing explicit seams
- Research / tooling:
  - reuse `REF-OPENAI-APPS-SDK-REFERENCE` and `REF-OPENAI-APPS-SDK-CHATGPT-UI` in the new boundary, translating current `requestDisplayMode`, `requestModal`, `requestClose`, and host display globals into SlopOS D-LLM / D-UICAP / D-POWERBOX language instead of letting fullscreen/modal convenience drift into trusted-window folklore
  - add `tools/check_tool_ui_display_surface_boundary.py` (`EVID-2026-656`) and retighten `tools/check_tool_ui_boundary_index.py`, so rendered-tool-UI family discovery now keeps the widget display-mode/modal/close cut machine-checked alongside the existing widget-authority, widget-toolcall, widget-model-context, widget-file, widget-follow-up, and widget-navigation cuts

## Revised641 (2026-03-22)
- Rendered tool-UI navigation/browser-handoff boundary:
  - add `docs/30-architecture/tool-ui-navigation-boundary-v0.md`, freezing the rule that widget-local routing stays presentation-local and widget-triggered browser handoff stays host-mediated launch-only/OpenURI meaning rather than widening into a hidden widget-owned browser/session/callback plane
  - tighten `docs/30-architecture/tool-ui-boundary-index.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/llm-runbook.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/UI passes re-find the widget navigation/browser-handoff seam together with the existing presentation-only, no-hidden-widget-action-plane, no-hidden-widget-memory/policy, no-hidden-widget-file/materialization/export, and no-hidden-widget-user-speech/transcript-mutation cuts
  - wire the new cut into `docs/30-architecture/openuri-portal-posture-v0.md` and `docs/30-architecture/openuri-navigation-observation-boundary-v0.md`, so widget navigation convenience cannot silently regrow a second browser-control, callback/deep-link, or page-state observation plane outside existing OpenURI meaning pins
- Research / tooling:
  - add `REF-MCP-APPS-API-OPEN-LINK` to `docs/00-meta/bibliography.md`, translating current `ui/open-link` / host browser-handoff semantics into SlopOS D-LLM / D-UICAP / D-PLUMB language instead of letting widget navigation drift into browser/session folklore
  - add `tools/check_tool_ui_navigation_boundary.py` (`EVID-2026-655`) and retighten `tools/check_tool_ui_boundary_index.py`, so rendered-tool-UI family discovery now keeps the widget navigation/browser-handoff cut machine-checked alongside the existing widget-authority, widget-toolcall, widget-model-context, widget-file, and widget-follow-up cuts

## Revised640 (2026-03-22)
- Rendered tool-UI follow-up-message boundary:
  - add `docs/30-architecture/tool-ui-followup-message-boundary-v0.md`, freezing the rule that widget-authored follow-up messages stay attributed host-mediated continuation requests rather than widening into direct user speech, silent transcript mutation, or a durable callback/mailbox plane
  - tighten `docs/30-architecture/tool-ui-boundary-index.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/llm-runbook.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/UI passes re-find the widget follow-up seam together with the existing presentation-only, no-hidden-widget-action-plane, no-hidden-widget-memory/policy, and no-hidden-widget-file/materialization/export cuts
  - wire the new cut into `docs/30-architecture/plumb-posture-v0.md`, so widget follow-up convenience cannot silently reintroduce a durable inbox/outbox, callback registry, or transcript-native routing plane under D-PLUMB
- Research / tooling:
  - add `REF-MCP-APPS-API-MESSAGE` and `REF-MCP-APPS-PATTERNS` to `docs/00-meta/bibliography.md`, translating current component-authored follow-up semantics into SlopOS D-LLM / D-UICAP / D-PLUMB language instead of letting host-posted continuation requests turn into user-speech or mailbox folklore
  - add `tools/check_tool_ui_followup_message_boundary.py` (`EVID-2026-654`) and retighten `tools/check_tool_ui_boundary_index.py`, so rendered-tool-UI family discovery now keeps the widget follow-up/user-speech cut machine-checked alongside the existing widget-authority, widget-toolcall, widget-model-context, and widget-file cuts

## Revised639 (2026-03-22)
- Rendered tool-UI file/materialization/export boundary:
  - add `docs/30-architecture/tool-ui-file-boundary-v0.md`, freezing the rule that widget uploads, file params, temporary preview/download URLs, and widget-triggered file export stay staged/explicit rather than widening into a hidden local-object/materialization/export plane
  - tighten `docs/30-architecture/tool-ui-boundary-index.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/trusted-ui-adjunct-index.md`, `docs/00-meta/llm-runbook.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/UI passes re-find the widget file seam together with the existing presentation-only, no-hidden-widget-action-plane, and no-hidden-widget-memory/policy cuts
  - wire the new cut into `docs/30-architecture/document-portal-posture-v0.md` and `docs/30-architecture/import-to-docref-boundary-v0.md`, so widget file convenience does not silently create a second bearer→document bridge or a direct export tunnel outside existing document/import workflows
- Research / tooling:
  - add `REF-OPENAI-APPS-SDK-CHATGPT-UI`, `REF-OPENAI-APPS-SDK-CHANGELOG`, `REF-OPENAI-APPS-SDK-SUBMISSION-GUIDELINES`, and `REF-MCP-APPS-API-DOWNLOAD-FILE` to `docs/00-meta/bibliography.md`, translating current widget upload/download/file-param semantics into SlopOS D-LLM / D-UICAP / D-PLUMB language instead of letting file helpers turn into local-object or export folklore
  - add `tools/check_tool_ui_file_boundary.py` (`EVID-2026-653`) and retighten `tools/check_tool_ui_boundary_index.py`, so rendered-tool-UI family discovery now keeps the widget-file/materialization/export cut machine-checked alongside the existing widget-authority, widget-toolcall, and widget-model-context cuts

## Revised638 (2026-03-22)
- Rendered tool-UI model-context boundary:
  - add `docs/30-architecture/tool-ui-model-context-boundary-v0.md`, freezing the rule that widget-originated model-context updates and persisted widget state stay proposal-only and request-local rather than widening into a hidden durable memory/policy plane or implicit docref/file-grant semantics
  - tighten `docs/30-architecture/tool-ui-boundary-index.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/trusted-ui-adjunct-index.md`, `docs/00-meta/llm-runbook.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/UI passes re-find the widget-context seam together with the existing presentation-only and no-hidden-widget-action-plane cuts
- Research / tooling:
  - add `REF-OPENAI-APPS-SDK-STATE` and `REF-MCP-APPS-API-MODEL-CONTEXT` to `docs/00-meta/bibliography.md`, translating current widget-state persistence and `ui/update-model-context` bridge semantics into SlopOS D-LLM / D-UICAP / D-OBS language instead of importing them as hidden memory or prompt-authority folklore
  - add `tools/check_tool_ui_model_context_boundary.py` (`EVID-2026-652`) and retighten `tools/check_tool_ui_boundary_index.py`, so rendered-tool-UI family discovery now keeps the widget-context cut machine-checked alongside the existing widget-authority and widget-toolcall cuts rather than reviewer-memory-only

## Revised637 (2026-03-22)
- Rendered tool-UI tool-call boundary + family promotion:
  - add `docs/30-architecture/tool-ui-toolcall-boundary-v0.md`, freezing the rule that component-initiated tool calls stay host-mediated re-entry onto existing reviewed seams rather than growing a private widget-only privileged action plane
  - promote rendered tool UI from an intentional singleton into a closed companion family via `docs/30-architecture/tool-ui-boundary-index.md`, and rewire `docs/30-architecture/tool-ui-authority-boundary-v0.md` as a family member so future UI-shaped cuts attach to one machine-checked discovery surface instead of singleton folklore
  - wire the new family member + family index through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/trusted-ui-adjunct-index.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/UX passes re-find both the presentation-only widget cut and the no-hidden-widget-action-plane cut together
- Research / tooling:
  - add `REF-OPENAI-APPS-SDK-REFERENCE` and `REF-OPENAI-APPS-SDK-SERVER` to `docs/00-meta/bibliography.md`, translating current Apps SDK widget bridge semantics (the `tools call` method, model-vs-widget visibility, widget-private `_meta`) into SlopOS D-LLM / IF-ACP / D-UICAP language instead of importing them as host folklore
  - add `tools/check_tool_ui_toolcall_boundary.py` (`EVID-2026-650`) and `tools/check_tool_ui_boundary_index.py` (`EVID-2026-651`), and retighten `tools/check_tool_ui_authority_boundary.py`, so rendered-tool-UI family discovery and widget re-entry semantics stay machine-checked rather than reviewer-memory-only

## Revised636 (2026-03-22)
- Rendered tool/server UI authority boundary:
  - add `docs/30-architecture/tool-ui-authority-boundary-v0.md`, freezing the rule that inline tool/server widgets stay presentation-only rather than silently becoming trusted approval, browser-session, filesystem, or ambient host-authority seams
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/trusted-ui-adjunct-index.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/README.md`, and `docs/70-llm-control/llm-threats.md` so future LLM/UX passes re-find the rendered-tool-UI seam instead of rediscovering it from app/webview folklore
- Research / tooling:
  - add `REF-MCP-APPS-SEP` and `REF-MCP-APPS` to `docs/00-meta/bibliography.md`, translating the now-official MCP Apps interactive-UI extension into SlopOS D-LLM / D-UICAP / D-POWERBOX language instead of letting host-rendered widget semantics arrive as vendor folklore
  - add `tools/check_tool_ui_authority_boundary.py`, register `EVID-2026-649`, and wire the checker through `tools/README.md` / `docs/00-meta/evidence-index.md` / `docs/00-meta/resolved-history.md` so the presentation-vs-authority split stays machine-checked rather than reviewer-memory-only

## Revised635 (2026-03-22)
- Network-lease address-selection boundary:
  - add `docs/30-architecture/network-lease-address-selection-boundary-v0.md`, freezing the rule that reviewed exact-name authority stays destination predicate + resolver binding only rather than widening into a portable IPv4 / IPv6 preference / Happy-Eyeballs / answer-ordering seam
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0056-outbound-network-leases-and-portals.md` so reviewed exact-name authority does not silently inherit RFC 6724 destination ordering, Happy-Eyeballs racing, or selected-family folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the dual-stack-selection cut instead of rediscovering it from libc/browser/mobile runtime habit
- Research / tooling:
  - add `REF-RFC8305-HAPPY-EYEBALLS` to `docs/00-meta/bibliography.md`, translating dual-stack address ordering and connection racing into SlopOS D-NETLEASE language instead of leaving exact-name semantics to host runtime folklore
  - add `tools/check_network_lease_address_selection_boundary.py`, register `EVID-2026-648`, and extend `tools/check_network_lease_boundary_index.py` so the new family member and its schema/portal/ACP/proof/discovery wiring are machine-checked rather than reviewer-memory-only

## Revised634 (2026-03-22)
- Network-lease port-inference boundary:
  - add `docs/30-architecture/network-lease-port-inference-boundary-v0.md`, freezing the rule that connect/listen host-or-IP predicates stay explicitly port-shaped rather than widening into a portable default-port / service-name seam
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0056-outbound-network-leases-and-portals.md` so absent numeric ports reject before effect, URI-scheme defaults stay out of lease truth, and `service` labels remain portal-local policy rather than `/etc/services` / service-name lookup folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the explicit-port cut instead of rediscovering it from browser/libc/runtime habit
- Research / tooling:
  - add `REF-MAN7-SERVICES` and `REF-IANA-SERVICE-NAMES` to `docs/00-meta/bibliography.md`, and broaden `REF-RFC9205-HTTP-BCP` usage notes, translating default-port and service-name lookup behavior into SlopOS D-NETLEASE language instead of leaving numeric-port semantics as folklore
  - add `tools/check_network_lease_port_inference_boundary.py`, register `EVID-2026-647`, and extend `tools/check_network_lease_boundary_index.py` so the new family member and its schema/portal/ACP/proof/discovery wiring are machine-checked rather than reviewer-memory-only

## Revised633 (2026-03-22)
- Network-lease service-binding boundary:
  - add `docs/30-architecture/network-lease-service-binding-boundary-v0.md`, freezing the rule that reviewed exact-name network authority stays host-address reachability only rather than widening into a portable SRV / SVCB / HTTPS service-binding / alternate-endpoint seam
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0056-outbound-network-leases-and-portals.md` so reviewed exact-name authority does not silently inherit SRV targets, SVCB aliasing, HTTPS RR alternate endpoints, or endpoint-parameter folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the service-binding cut instead of rediscovering it from resolver/CDN/browser habit
- Research / tooling:
  - add `REF-RFC2782-SRV` and `REF-RFC9460-SVCB` to `docs/00-meta/bibliography.md`, translating modern service-discovery and service-binding records into SlopOS D-NETLEASE language instead of leaving exact-name semantics as resolver folklore
  - add `tools/check_network_lease_service_binding_boundary.py`, register `EVID-2026-646`, and extend `tools/check_network_lease_boundary_index.py` so the new family member and its schema/portal/ACP/proof/discovery wiring are machine-checked rather than reviewer-memory-only

## Revised632 (2026-03-22)
- Network-lease name-normalization boundary:
  - add `docs/30-architecture/network-lease-name-normalization-boundary-v0.md`, freezing the rule that reviewed `dns_name` / `dns_suffix` predicates stay one canonical ASCII predicate rather than widening into a portable Unicode / IDNA / trailing-dot normalization seam
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0056-outbound-network-leases-and-portals.md` so exact reviewed name predicates do not silently inherit Unicode U-label input, UTS #46 / browser host parsing, locale casefolding, or trailing-dot cleanup folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the canonical-name cut instead of rediscovering it from browser or libc host-parser habit
- Research / tooling:
  - add `REF-RFC5890-IDNA-DEFS`, `REF-RFC5895-IDNA-MAPPING`, and `REF-WHATWG-URL-HOST` to `docs/00-meta/bibliography.md`, translating IDNA label classes and host canonicalization choices into SlopOS D-NETLEASE language instead of leaving exact-name normalization semantics as client-stack folklore
  - add `tools/check_network_lease_name_normalization_boundary.py`, register `EVID-2026-645`, and extend `tools/check_network_lease_boundary_index.py` so the new family member and its schema/portal/ACP/proof/discovery wiring are machine-checked rather than reviewer-memory-only

## Revised631 (2026-03-22)
- Network-lease name-context boundary:
  - add `docs/30-architecture/network-lease-name-context-boundary-v0.md`, freezing the rule that reviewed `dns_name` / `dns_suffix` predicates stay exact reviewed names rather than widening into a portable search-path / hosts-file / split-DNS / mDNS / LLMNR seam
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0056-outbound-network-leases-and-portals.md` so exact reviewed name predicates do not silently inherit host search-path, hosts-file/NSS, split-DNS, mDNS, or LLMNR folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the name-context cut instead of rediscovering it from workstation or enterprise resolver habit
- Research / tooling:
  - add `REF-MAN7-SYSTEMD-RESOLVED`, `REF-RFC6762-MDNS`, and `REF-RFC4795-LLMNR` to `docs/00-meta/bibliography.md`, and broaden `REF-MAN7-RESOLV-CONF` usage notes, translating host search-path, split-DNS, and local-link name-resolution behavior into SlopOS D-NETLEASE language instead of leaving exact-name semantics as resolver folklore
  - add `tools/check_network_lease_name_context_boundary.py`, extend `tools/check_network_lease_boundary_index.py`, and register `EVID-2026-644` so the new boundary and the expanded D-NETLEASE family are machine-checked rather than reviewer-memory-only

## Revised630 (2026-03-22)
- Network-lease DNS-query boundary:
  - add `docs/30-architecture/network-lease-dns-query-boundary-v0.md`, freezing the rule that D-NETLEASE `kind=dns` stays address-resolution-only rather than widening into a portable RR-type/class query, raw DNS reply, or resolver-transport seam
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0056-outbound-network-leases-and-portals.md` so `kind=dns` stays name-shaped and portless, generic RR-query/raw-reply semantics stay portal-local, and `portal.net.request` does not silently become a reviewed DNS-client API
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the DNS-query cut instead of rediscovering it from libc / browser / SDK resolver habit
- Research / tooling:
  - add `REF-MAN7-RESOLVER`, `REF-ANDROID-DNSRESOLVER`, and `REF-RFC1035-DNS` to `docs/00-meta/bibliography.md`, translating the difference between address resolution and explicit RR-query APIs into SlopOS D-NETLEASE language instead of leaving `kind=dns` semantics as folklore
  - add `tools/check_network_lease_dns_query_boundary.py`, register `EVID-2026-643`, and extend `tools/check_network_lease_boundary_index.py` so the new family member and its schema/portal/ACP/proof/discovery wiring are machine-checked rather than reviewer-memory-only

## Revised629 (2026-03-22)
- Network request listen-subject boundary:
  - add `docs/30-architecture/network-request-listen-subject-boundary-v0.md`, freezing the rule that CH-NETREQ / CH-NETLEASE `kind=listen` names a local bind/exposure subject rather than a remote DNS predicate, so `dns_name` / `dns_suffix` listener predicates reject instead of turning into bind-by-hostname / publish-by-name folklore
  - tighten `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0056-outbound-network-leases-and-portals.md` so listen-side `service` labels stay local policy metadata rather than resolver contracts and `portal.net.request` does not silently become a bind-by-hostname / DNS-publication / public-endpoint seam
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/portal-family-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the local-listener-subject cut instead of rediscovering it from wrapper habit
- Research / tooling:
  - add `REF-MAN7-BIND`, `REF-MAN7-LISTEN`, and `REF-MAN7-IP` to `docs/00-meta/bibliography.md`, and broaden `REF-MAN7-GETADDRINFO` usage notes, translating mainstream listener/bind semantics into SlopOS CH-NETREQ / CH-NETLEASE language instead of leaving listener meaning as hostname/publication folklore
  - add `tools/check_network_request_listen_subject_boundary.py` and register `EVID-2026-642`, so the new boundary and its schema/portal/ACP/proof/discovery wiring are machine-checked rather than reviewer-memory-only

## Revised628 (2026-03-22)
- Network request idempotency boundary:
  - add `docs/30-architecture/network-request-idempotency-boundary-v0.md`, freezing the rule that same scoped CH-NETREQ `req_id` only replays the same canonical request and that changed CH-NETREQ bytes under one key reject before effect instead of acting like mutable upsert/replace semantics
  - tighten `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-request-state-posture-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0056-outbound-network-leases-and-portals.md` so `portal.net.request` retry semantics stay exact-replay-only rather than drifting into mutable request-upsert folklore
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/portal-family-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the replay-vs-upsert cut instead of rediscovering it from wrapper habit
- Research / tooling:
  - add `REF-AWS-EC2-IDEMPOTENCY`, `REF-STRIPE-IDEMPOTENT-REQUESTS`, `REF-STRIPE-ADVANCED-ERROR-HANDLING`, and `REF-RFC7413-TFO` to `docs/00-meta/bibliography.md`, translating production idempotency-key and replay-protection precedents into SlopOS CH-NETREQ / D-RETRYSAFE language instead of leaving retry meaning as folklore
  - add `tools/check_network_request_idempotency_boundary.py` and register `EVID-2026-641`, so the new boundary and its proof/assurance/discovery wiring are machine-checked rather than reviewer-memory-only

## Revised627 (2026-03-22)
- Network-lease transport-profile boundary:
  - add `docs/30-architecture/network-lease-transport-profile-boundary-v0.md`, freezing the rule that leased networking over `tls` / `quic` does **not** widen into a portable version / cipher / group / transport-parameter seam or transcript-stable negotiated transport-profile receipt
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md` so explicit leased networking stays distinct from TLS-version floors, cipher/group policy, QUIC version selection, and QUIC transport-parameter folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the transport-profile cut instead of rediscovering it from browser/runtime/TLS-stack habit
- Research / tooling:
  - add `REF-CURL-SSL-CIPHERS`, `REF-APPLE-ATS-COCOAKEYS`, and `REF-RFC9000-QUIC-TRANSPORT` to `docs/00-meta/bibliography.md`, and broaden `REF-RFC8446-TLS13` usage notes, translating explicit TLS-version/cipher controls and QUIC version/transport-parameter negotiation into SlopOS network-lease language instead of treating them as harmless reachability residue
  - add `tools/check_network_lease_transport_profile_boundary.py`, extend `tools/check_network_lease_boundary_index.py`, and register `EVID-2026-640` so the new boundary and the expanded D-NETLEASE family are machine-checked rather than reviewer-memory-only

## Revised626 (2026-03-22)
- Network-lease transport-resumption boundary:
  - add `docs/30-architecture/network-lease-session-resumption-boundary-v0.md`, freezing the rule that leased networking over `tls` / `quic` does **not** widen into a portable session-resumption / PSK / 0-RTT seam or transcript-stable resumed-session / early-data receipt
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md` so explicit leased networking stays distinct from ticket caches, PSK reuse, resumed-session behavior, and 0-RTT folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the transport-resumption cut instead of rediscovering it from browser/runtime habit
- Research / tooling:
  - add `REF-RFC8446-TLS13`, `REF-RFC9001-QUIC-TLS`, `REF-RFC9325-TLS-BCP`, and `REF-RFC9308-QUIC-APPLICABILITY` to `docs/00-meta/bibliography.md`, translating TLS/QUIC resumption, 0-RTT replay/privacy constraints, and reconnect-vs-keepalive tradeoffs into SlopOS network-lease language instead of treating resumed transport state as harmless reachability residue
  - add `tools/check_network_lease_session_resumption_boundary.py`, extend `tools/check_network_lease_boundary_index.py`, and register `EVID-2026-639`, so the new boundary and the tightened “no unindexed extras” family guardrail are machine-checked rather than reviewer-memory-only

## Revised625 (2026-03-22)
- Network-lease server-name boundary:
  - add `docs/30-architecture/network-lease-server-name-boundary-v0.md`, freezing the rule that leased networking over `tls` / `quic` does **not** widen into a portable SNI / server-name / ECH seam or transcript-stable on-wire name-presentation receipt
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md` so explicit leased networking stays distinct from SNI derivation, server-name overrides, public-name fallbacks, and ECH bootstrapping folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the TLS name-presentation cut instead of rediscovering it from browser/runtime habit
- Research / tooling:
  - add `REF-RFC6066-TLS-SNI`, `REF-RFC9849-ECH`, `REF-RFC9848-ECH-SVCB`, and `REF-CURL-CONNECT-TO` to `docs/00-meta/bibliography.md`, translating TLS server-name presentation, ECH bootstrapping, and connect-vs-name separation into SlopOS network-lease language instead of treating on-wire name choice as harmless transport residue
  - add `tools/check_network_lease_server_name_boundary.py`, extend `tools/check_network_lease_boundary_index.py`, and register `EVID-2026-638`, so the new boundary and the expanded D-NETLEASE family are machine-checked rather than reviewer-memory-only

## Revised624 (2026-03-22)
- Network-lease application-protocol boundary:
  - add `docs/30-architecture/network-lease-application-protocol-boundary-v0.md`, freezing the rule that leased networking over `tls` / `quic` does **not** widen into a portable ALPN / application-protocol negotiation seam or transcript-stable selected-protocol / HTTP-version receipt
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md` so explicit leased networking stays distinct from browser/runtime ALPN defaults, HTTP/2 / HTTP/3 negotiation, and higher-layer protocol-selection folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the application-protocol cut instead of rediscovering it from browser/runtime habit
- Research / tooling:
  - add `REF-RFC7301-ALPN`, `REF-RFC9113-HTTP2`, `REF-RFC9114-HTTP3`, and `REF-RFC9205-HTTP-BCP` to `docs/00-meta/bibliography.md`, translating ALPN and HTTP-substrate negotiation semantics into SlopOS network-lease language instead of treating selected higher-layer protocol as harmless transport residue
  - add `tools/check_network_lease_application_protocol_boundary.py`, extend `tools/check_network_lease_boundary_index.py`, and register `EVID-2026-637`, so the new boundary and the expanded D-NETLEASE family are machine-checked rather than reviewer-memory-only

## Revised623 (2026-03-22)
- Network-lease path-property boundary:
  - add `docs/30-architecture/network-lease-path-property-boundary-v0.md`, freezing the rule that leased networking does **not** widen into a portable metered / validated / captive / expensive / constrained path-property or connectivity-state seam and that current path hints stay portal-local rather than transcript-stable receipt truth
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md` so explicit leased networking stays distinct from inherited host network-monitor state, captive-portal verdicts, meteredness/cost hints, and generic connectivity-status folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the path-property cut instead of rediscovering it from platform network-monitor habit
- Research / tooling:
  - add `REF-ANDROID-NETWORKCAPABILITIES`, `REF-APPLE-NWPATH`, and `REF-RFC8908-CAPPORT-API` to `docs/00-meta/bibliography.md`, translating dynamic path-status / cost / captive-portal APIs into SlopOS network-lease language instead of treating current connectivity hints as harmless reachability residue
  - add `tools/check_network_lease_path_property_boundary.py` and register `EVID-2026-636`, extending the closed D-NETLEASE family so the new path-property boundary is machine-checked rather than reviewer-memory-only

## Revised622 (2026-03-22)
- Network-lease local-egress boundary:
  - add `docs/30-architecture/network-lease-local-egress-boundary-v0.md`, freezing the rule that leased networking does **not** widen into a portable local-interface / source-address / VRF seam or transcript-stable local egress-selection receipt
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md` so explicit leased networking stays distinct from inherited process/network binding, interface pinning, source-address forcing, and VRF folklore
  - wire the new boundary + expanded family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the local-egress cut instead of rediscovering it from VPN/interface/VRF habit
- Research / tooling:
  - add `REF-ANDROID-MULTINETWORK`, `REF-APPLE-NWPARAMETERS-REQUIREDINTERFACE`, `REF-LINUX-SO_BINDTODEVICE`, `REF-RFC6724-ADDRSELECT`, and `REF-RFC8043-SADR` to `docs/00-meta/bibliography.md`, translating explicit per-process/per-socket network binding and source-address-dependent routing into SlopOS network-lease language instead of treating local egress choice as harmless reachability residue
  - add `tools/check_network_lease_local_egress_boundary.py` and extend `tools/check_network_lease_boundary_index.py`, registering `EVID-2026-635`, so the new local-egress boundary and the expanded D-NETLEASE family are machine-checked rather than reviewer-memory-only

## Revised621 (2026-03-22)
- Network-lease client-cert boundary:
  - add `docs/30-architecture/network-lease-client-cert-boundary-v0.md`, freezing the rule that leased networking over `tls` / `quic` does **not** widen into a portable client-certificate / mTLS identity seam or certificate-bound-token receipt
  - tighten `docs/30-architecture/network-lease-boundary-index.md`, `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md` so explicit leased networking stays distinct from client-cert selection, keychain / PKCS#11 residue, HTTPS-proxy client-cert fallback, and certificate-bound-token folklore
  - wire the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the transport client-auth cut instead of rediscovering it from browser/keychain/tooling habit
- Research / tooling:
  - add `REF-CURL-CLIENTCERT` to `docs/00-meta/bibliography.md` and extend `REF-ANDROID-KEYCHAIN-CHOOSEPRIVATEKEYALIAS` / `REF-RFC8705-OAUTH-MTLS` usage notes, translating explicit client-cert files, alias-pickers, and certificate-bound-token semantics into SlopOS network-lease language instead of treating them as harmless reachability residue
  - add `tools/check_network_lease_client_cert_boundary.py` and register `EVID-2026-634` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised620 (2026-03-22)
- Network-lease trust boundary + family cleanup:
  - add `docs/30-architecture/network-lease-tls-verifier-boundary-v0.md`, freezing the rule that leased networking over `tls` / `quic` does **not** widen into a portable trust-root / hostname-verifier / certificate-exception seam or current certificate-verdict receipt
  - add `docs/30-architecture/network-lease-boundary-index.md`, promoting the current D-NETLEASE boundary cluster from singleton lore into one closed companion family covering the resolution / proxy / TLS-verifier meaning pins
  - tighten `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/network-lease-resolution-boundary-v0.md`, and `docs/30-architecture/network-lease-proxy-boundary-v0.md` so explicit leased networking stays distinct from transport verifier policy and the network-boundary cluster stays family-indexed rather than singleton-fragile
  - wire the new boundary + family index through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find both the transport-trust cut and the family discovery surface
- Research / tooling:
  - add `REF-CURL-SSLCERTS`, `REF-OPENSSL-TLS-CLIENT`, `REF-OPENSSL-SSL-SET1-HOST`, and `REF-ANDROID-NETSEC-CONFIG` to `docs/00-meta/bibliography.md`, translating CA-store diversity, explicit hostname verification, and per-app trust-policy overrides into SlopOS network-lease language instead of treating TLS trust as harmless transport residue
  - add `tools/check_network_lease_tls_verifier_boundary.py`, `tools/check_network_lease_boundary_index.py`, and register `EVID-2026-632` / `EVID-2026-633` so the new trust boundary and the promoted D-NETLEASE companion family are machine-checked rather than reviewer-memory-only

## Revised619 (2026-03-22)
- Network-lease proxy boundary:
  - add `docs/30-architecture/network-lease-proxy-boundary-v0.md`, freezing the rule that leased networking does **not** widen into a portable proxy-selection / PAC / WPAD / system-proxy seam and that env/settings-driven proxy policy remains portal-local rather than transcript-stable receipt truth
  - tighten `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/30-architecture/network-lease-resolution-boundary-v0.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md` so explicit network requests do not quietly re-import `$http_proxy`, PAC scripts, WPAD, or generic “use system proxy” folklore
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the proxy-policy cut instead of rediscovering it from browser/session lore
- Research / tooling:
  - add `REF-LIBPROXY`, `REF-CHROMIUM-PROXY`, `REF-CHROMIUM-WPAD`, `REF-XDG-PORTAL-SETTINGS`, and `REF-LIBCURL-ENV` to `docs/00-meta/bibliography.md`, translating PAC/WPAD/system-proxy complexity and env-driven proxy routing into SlopOS network-lease language rather than treating proxy policy as harmless request residue
  - add `tools/check_network_lease_proxy_boundary.py` and register `EVID-2026-631` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised618 (2026-03-22)
- Network-lease resolution boundary:
  - add `docs/30-architecture/network-lease-resolution-boundary-v0.md`, freezing the rule that D-NETLEASE exports reviewed **destination predicates + resolver binding** only, not a portable resolved-address / selected-endpoint / route-selection seam
  - tighten `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/40-verification/portal-net-proof-slice-v0.md`, `docs/20-assurance/invariant-registry.md`, and `docs/20-assurance/proof-obligation-registry.md` so explicit resolver binding stays sharp without turning CH-NETLEASE or receipt refs into fake current path truth
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future portal/net passes re-find the cut instead of re-importing route/answer telemetry folklore piecemeal
- Research / tooling:
  - add `REF-FREEBSD-CAP-DNS` and `REF-ANDROID-READ-NETWORK-STATE` to `docs/00-meta/bibliography.md`, translating explicit capability-mode DNS and ephemeral network-object lessons into SlopOS network-lease language rather than treating current answer/path state as harmless receipt residue
  - add `tools/check_network_lease_resolution_boundary.py` and register `EVID-2026-630` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised617 (2026-03-22)
- Proof-slice narrowing:
  - add `docs/40-verification/portal-net-proof-slice-v0.md`, making the first proof-bearing mediated action explicit: MVP-A2 now chooses **`portal.net.request`** rather than leaving the first portal workflow generic
  - tighten `docs/40-verification/minimum-viable-proof-slice.md` and `docs/00-meta/trajectory-map.md` so the proof-bearing slice reuses the existing **CH-NETREQ v0 / CH-NETLEASE v0** seam, `domain.id` conflict-key family, required **CH-ORDERTOK v0** ordering witness, and explicit `svc:portal.net` serialization boundary
  - wire the new decision through `README.md`, `docs/README.md`, and `docs/00-meta/llm-runbook.md` so future archive passes re-find the first mediated control-plane target instead of re-opening “which portal do we prove first?” by prose drift
- Guardrails / tooling:
  - add `tools/check_portal_net_proof_slice.py`, register `EVID-2026-629`, and wire `tools/README.md` plus `docs/00-meta/evidence-index.md` so `make lint` fails if the archive drifts back to a generic first-portal placeholder

## Revised616 (2026-03-22)
- Auth-mediation family contract hygiene:
  - tighten `docs/30-architecture/auth-mediation-boundary-index.md` with an explicit member contract so family members stay intentionally small, keep same-revision attachment to the closed auth-mediation family, and retain the required **Family status / Wiring / Evidence hook / References** recovery shape instead of drifting into uneven singleton lore
  - tighten `docs/30-architecture/llm-elicitation-boundary-v0.md` so the oldest auth-mediation family member now carries the same explicit **Evidence hook** section shape as the rest of the family instead of relying on an inline wiring bullet
  - tighten `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, and `docs/30-architecture/posture-index.md` so future archive passes re-find the family-level member contract and do not widen auth-mediation docs by forgetting the shared section/checker shape
- Guardrails / tooling:
  - add `tools/check_auth_mediation_family_contract.py`, register `EVID-2026-628`, and wire `tools/README.md` plus `docs/00-meta/evidence-index.md` so `make lint` fails if any auth-mediation family member drops its family attachment clause, required recovery sections, or explicit no-new-schema / no-new-ACP / no-new-conflict-key posture

## Revised615 (2026-03-22)
- Auth-continuation export boundary hygiene:
  - add `docs/30-architecture/auth-continuation-export-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable pending-auth / continuation-handle seam on D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local login remains distinct from PKCE verifiers, device-flow code bundles, verification URLs, backchannel polling handles, and adjacent pending-auth folklore
  - wire the new family-member boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-APPSECRET / D-VAULT passes re-find the pending-auth / continuation-handle cut instead of re-importing PKCE/device/CIBA folklore piecemeal
- Research / tooling:
  - add `REF-RFC7636-PKCE`, `REF-RFC8628-DEVICE-GRANT`, and `REF-OPENID-CIBA-CORE` to `docs/00-meta/bibliography.md`, translating dedicated PKCE/device/backchannel continuation surfaces into our auth-continuation language instead of treating pending-auth state as harmless login residue
  - add `tools/check_auth_continuation_export_boundary.py` and register `EVID-2026-627` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised614 (2026-03-22)
- Credential-exchange boundary hygiene:
  - add `docs/30-architecture/credential-exchange-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable credential-exchange / password-manager migration / passkey-portability seam on D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local login remains distinct from password-manager migration, passkey portability, and credential import/export folklore
  - wire the new family-member boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-APPSECRET / D-VAULT passes re-find the credential-exchange cut instead of re-importing password-manager / passkey portability folklore piecemeal
- Research / tooling:
  - add `REF-APPLE-CREDENTIAL-EXPORT-MANAGER`, `REF-APPLE-CREDENTIAL-IMPORT-MANAGER`, and `REF-FIDO-CXF` to `docs/00-meta/bibliography.md`, translating dedicated passkey/password exchange surfaces into our credential-exchange language instead of treating portability as harmless login residue
  - add `tools/check_credential_exchange_boundary.py` and register `EVID-2026-626` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised613 (2026-03-22)
- Credential-enrollment boundary hygiene:
  - add `docs/30-architecture/credential-enrollment-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable credential-enrollment / passkey-registration / authenticator-provisioning control seam on D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local login remains distinct from passkey registration, authenticator enrollment, and credential-upgrade folklore
  - wire the new family-member boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-APPSECRET / D-VAULT passes re-find the credential-enrollment cut instead of re-importing passkey/security-key enrollment folklore piecemeal
- Research / tooling:
  - add `REF-W3C-PASSKEY-ENDPOINTS`, `REF-ANDROID-PASSKEY-CREATE`, and `REF-APPLE-PASSKEY-REGISTRATION-REQUEST` to `docs/00-meta/bibliography.md`, translating explicit passkey-upgrade / create-passkey / registration-request surfaces into our credential-enrollment language instead of treating credential creation as harmless login residue
  - add `tools/check_credential_enrollment_boundary.py` and register `EVID-2026-625` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised612 (2026-03-22)
- Auth-proof export boundary hygiene:
  - add `docs/30-architecture/auth-proof-export-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable proof-of-possession / auth-assertion export seam on D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local login remains distinct from DPoP proofs, WebAuthn assertions, challenge signatures, and certificate-bound proof folklore
  - wire the new family-member boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-APPSECRET / D-VAULT passes re-find the auth-proof-export cut instead of re-importing proof-broker folklore piecemeal
- Research / tooling:
  - add `REF-RFC9449-DPOP` and `REF-RFC8705-OAUTH-MTLS` to `docs/00-meta/bibliography.md`, translating dedicated OAuth proof-of-possession / certificate-bound proof surfaces into our auth-proof-export language instead of treating signed challenge/proof artifacts as harmless login residue
  - add `tools/check_auth_proof_export_boundary.py` and register `EVID-2026-624` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised611 (2026-03-22)
- Authorization-context export boundary hygiene:
  - add `docs/30-architecture/authorization-context-export-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable granted-scope / resource-indicator / authorization-details / entitlement export seam on D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/auth-mediation-boundary-index.md`, `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local login remains distinct from granted-scope, resource-indicator, authorization-details, and entitlement folklore
  - wire the new family-member boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-APPSECRET / D-VAULT passes re-find the authorization-context-export cut instead of re-importing grant/entitlement folklore piecemeal
- Research / tooling:
  - add `REF-RFC6749-OAUTH-AUTHZ-FRAMEWORK`, `REF-RFC8707-RESOURCE-INDICATORS`, `REF-RFC9396-RICH-AUTHORIZATION-REQUESTS`, and `REF-RFC7662-TOKEN-INTROSPECTION` to `docs/00-meta/bibliography.md`, translating dedicated OAuth authorization-context surfaces into our authorization-context-export language instead of treating granted scope/resource/entitlement state as harmless login residue
  - add `tools/check_authorization_context_export_boundary.py` and register `EVID-2026-623` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised610 (2026-03-22)
- Auth-mediation family promotion:
  - add `docs/30-architecture/auth-mediation-boundary-index.md`, promoting the recent explicit-local-auth / credential-mediation singleton chain into one closed companion family so LLM elicitation, app-secret ingress, vault mediation, browser-session export, auth-result export, identity-claim export, login-state export, and auth-teardown cuts stay recoverable together instead of as adjacent singleton lore
  - reclassify `docs/30-architecture/llm-elicitation-boundary-v0.md`, `docs/30-architecture/appsecret-secret-ingress-boundary-v0.md`, `docs/30-architecture/vault-credential-mediation-boundary-v0.md`, `docs/30-architecture/browser-session-export-boundary-v0.md`, `docs/30-architecture/auth-result-export-boundary-v0.md`, `docs/30-architecture/identity-claim-export-boundary-v0.md`, `docs/30-architecture/login-state-export-boundary-v0.md`, and `docs/30-architecture/auth-teardown-boundary-v0.md` as family members instead of intentional singletons, and tighten `docs/30-architecture/boundary-family-map.md`, `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/app-secret-posture-v0.md`, and `docs/30-architecture/vault-posture-v0.md` so future passes rediscover the whole auth-mediation cluster from one stable surface
- Tooling:
  - add `tools/check_auth_mediation_boundary_index.py` and register `EVID-2026-622` so the new family index is machine-checked rather than reviewer-memory-only

## Revised609 (2026-03-22)
- Auth-teardown boundary hygiene:
  - add `docs/30-architecture/auth-teardown-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable logout / sign-out / disconnect / revocation / unlink-account control seam on D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local login remains distinct from logout/disconnect/revocation control folklore
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-APPSECRET / D-VAULT passes re-find the auth-teardown cut instead of re-importing logout/disconnect folklore piecemeal
- Research / tooling:
  - add `REF-RFC7009-TOKEN-REVOCATION` and `REF-OPENID-RP-INITIATED-LOGOUT` to `docs/00-meta/bibliography.md`, translating explicit revocation/logout protocol surfaces into our auth-teardown language instead of treating sign-out/disconnect as harmless login residue
  - add `tools/check_auth_teardown_boundary.py` and register `EVID-2026-621` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised608 (2026-03-22)
- Login-state export boundary hygiene:
  - add `docs/30-architecture/login-state-export-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable signed-in / login-status / session-state / account-availability export seam on D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local login remains distinct from signed-in status, session-state, and account-availability folklore
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-APPSECRET / D-VAULT passes re-find the login-state-export cut instead of re-importing signed-in/session-state folklore piecemeal
- Research / tooling:
  - add `REF-OPENID-CONNECT-SESSION` and `REF-W3C-LOGIN-STATUS` to `docs/00-meta/bibliography.md`, translating dedicated session/login-status surfaces into our login-state-export language instead of treating signed-in/account-state as harmless login residue
  - add `tools/check_login_state_export_boundary.py` and register `EVID-2026-620` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised607 (2026-03-22)
- Identity-claim export boundary hygiene:
  - add `docs/30-architecture/identity-claim-export-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable subject / issuer / email / profile / account-identity export seam on D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local login remains distinct from subject/email/profile/account export folklore
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-APPSECRET / D-VAULT passes re-find the identity-claim-export cut instead of re-importing account/profile folklore piecemeal
- Research / tooling:
  - add `REF-OPENID-CONNECT-CORE`, `REF-APPLE-APPLEID-CREDENTIAL`, and `REF-W3C-FEDCM` to `docs/00-meta/bibliography.md`, translating dedicated identity/profile claim surfaces into our identity-claim-export language instead of treating account/profile return as harmless login residue
  - add `tools/check_identity_claim_export_boundary.py` and register `EVID-2026-619` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised606 (2026-03-22)
- Auth-result export boundary hygiene:
  - add `docs/30-architecture/auth-result-export-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable authorization-code, token-set, callback-result, or generic login-result export seam on D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local login remains distinct from callback capture, token relay, and portable auth-result folklore
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-APPSECRET / D-VAULT passes re-find the auth-result-export cut instead of re-importing callback/token-return folklore piecemeal
- Research / tooling:
  - add `REF-RFC9700-OAUTH-SECURITY` to `docs/00-meta/bibliography.md`, translating OAuth redirect-handling and credential-leak pitfalls into our auth-result-export language instead of treating callback/token return as harmless launch residue
  - add `tools/check_auth_result_export_boundary.py` and register `EVID-2026-618` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised605 (2026-03-22)
- Browser-session export boundary hygiene:
  - add `docs/30-architecture/browser-session-export-boundary-v0.md`, freezing the rule that explicit local login or credential mediation does not create a portable cookie-jar handoff, authenticated-browser-session export, browser-profile replay blob, or equivalent web-session artifact on D-LLM / D-POWERBOX / D-UICAP / D-VAULT / D-PLUMB
  - tighten `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so reviewed local sign-in remains distinct from browser-profile scraping, cookie export, and session replay semantics
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM / D-VAULT / D-POWERBOX passes re-find the browser-session-export cut instead of re-importing cookie-jar/session-replay folklore piecemeal
- Research / tooling:
  - add `REF-W3C-DBSC` to `docs/00-meta/bibliography.md`, translating Device Bound Session Credentials into our browser-session-export language instead of treating cookie portability as the default auth-continuity story
  - add `tools/check_browser_session_export_boundary.py` and register `EVID-2026-617` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised604 (2026-03-22)
- Vault credential-mediation boundary hygiene:
  - add `docs/30-architecture/vault-credential-mediation-boundary-v0.md`, freezing the rule that D-VAULT / CH-SECRETREF remain explicit secret-object authority only; vault refs do not become a portable password-manager/autofill/passkey/account-selection/auth-result seam
  - tighten `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0070-sealed-secrets-and-vault-service.md` so Phase 1 keeps ref-bound secret storage distinct from credential-provider UI, autofill, passkey ceremonies, and account/auth-result semantics
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-VAULT / D-LLM passes re-find the secret-storage-vs-credential-mediation cut instead of re-importing credential-manager folklore piecemeal
- Research / tooling:
  - add `REF-APPLE-CREDENTIAL-PROVIDER` to `docs/00-meta/bibliography.md`, translating AuthenticationServices credential-provider/autofill semantics into our D-VAULT boundary language instead of copying password-manager/passkey UI folklore directly
  - add `tools/check_vault_credential_mediation_boundary.py` and register `EVID-2026-616` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised603 (2026-03-22)
- App-secret secret-ingress boundary hygiene:
  - add `docs/30-architecture/appsecret-secret-ingress-boundary-v0.md`, freezing the rule that `portal.secret` issues provider-derived per-app protection seeds only; it does not become a portable password/API-key/OAuth-token import, paste/store, account-linking, or generic user-supplied credential-ingress seam
  - tighten `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/app-secret-descriptor-schema-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/30-architecture/llm-elicitation-boundary-v0.md`, `docs/70-llm-control/llm-threats.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0104-application-secrets-and-secret-portal.md` so the minimal app-seed seam stays distinct from vault-style credential storage and from interactive login/account mediation
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-APPSECRET / D-LLM passes re-find the app-seed-vs-credential-ingress cut instead of re-importing “paste your API key into the secret portal” folklore piecemeal
- Research / tooling:
  - translate existing primary-source evidence from the XDG Secret portal, Secret Service, RFC 8252, WebAuthn, and Android Credential Manager into one explicit SlopOS boundary instead of leaving the app-seed / credential-workflow split as reviewer-memory-only
  - add `tools/check_appsecret_secret_ingress_boundary.py` and register `EVID-2026-615` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised602 (2026-03-22)
- LLM elicitation boundary hygiene:
  - add `docs/30-architecture/llm-elicitation-boundary-v0.md`, pinning server/tool/model requests for additional user input, OAuth, payment, or secrets to explicit local mediation only so D-LLM does not quietly regrow a hidden browser, token-passthrough, or generic inline secret-ingress plane
  - tighten `docs/30-architecture/llm-operations-posture-v0.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/30-architecture/interface-registry.md`, and `docs/30-architecture/decision-map.md` so prompt/tool ecosystems may request interaction but they still do not define the trusted UI, approval summary, resulting authority object, or credential return path
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future D-LLM passes re-find the human-mediation cut instead of re-importing hidden browser/token relay folklore piecemeal
- Research / tooling:
  - refresh `REF-MCP-TOOLS` to the latest MCP tools spec and add `REF-MCP-ELICITATION` to `docs/00-meta/bibliography.md`, translating MCP’s explicit-consent, no-token-passthrough, and no-prefetch URL rules into our D-LLM / D-POWERBOX artifacts instead of copying protocol folklore directly
  - add `tools/check_llm_elicitation_boundary.py` and register `EVID-2026-614` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised601 (2026-03-22)
- Attestation collateral-status boundary hygiene:
  - add `docs/30-architecture/attestation-collateral-status-boundary-v0.md`, freezing the rule that imported collateral status artifacts such as certificate chains, CRLs, OCSP responses, TCB-info / identity blobs, and cache snapshots stay exact evidence under verifier-local freshness/status policy rather than becoming a native approval, latest-collateral, or ambient fetch/cache plane
  - tighten `docs/30-architecture/attestation-boundary-index.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/attestation-token-schema-v0.md`, `docs/30-architecture/attestation-pack-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0064-confidential-computing-profile.md` so IF-ATTEST still exports exact evidence while collateral freshness, cache reuse, and soft-fail policy stay explicit verifier-local policy rather than vendor-service truth
  - wire the new family member through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the attestation cuts as a set rather than re-importing collateral-cache folklore piecemeal
- Research / tooling:
  - add `REF-INTEL-TRUSTEDSERVICES-API` to `docs/00-meta/bibliography.md`, translating Intel quote-verification collateral update metadata (`issueDate`, `nextUpdate`, `tcbEvaluationDataNumber`) into our D-ATTEST boundary language instead of copying “latest vendor collateral” folklore directly
  - add `tools/check_attestation_collateral_status_boundary.py`, register `EVID-2026-613`, and tighten `tools/check_attestation_boundary_index.py` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised600 (2026-03-22)
- Attestation identity/enrollment boundary hygiene:
  - add `docs/30-architecture/attestation-identity-boundary-v0.md`, freezing the rule that `CH-ATTEST.device_id`, embedded UEID / implementation-id / instance-id claims, and provider-native attester identifiers stay exact evidence/signing context rather than becoming a native machine/asset/workload identity, attester inventory, or enrollment-query plane
  - tighten `docs/30-architecture/attestation-boundary-index.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/attestation-token-schema-v0.md`, `docs/30-architecture/attestation-pack-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0064-confidential-computing-profile.md` so IF-ATTEST still exports evidence/signing context rather than portable attester identity truth, and any identity mapping stays verifier-local enrollment and policy
  - wire the new family member through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the attestation cuts as a set rather than re-importing asset-directory folklore piecemeal
- Research / tooling:
  - add `REF-DICE-HW-REQ` to `docs/00-meta/bibliography.md`, translating DICE-derived identifiers into our D-ATTEST boundary language instead of copying portable asset/enrollment semantics directly
  - add `tools/check_attestation_identity_boundary.py`, register `EVID-2026-612`, and tighten `tools/check_attestation_boundary_index.py` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised599 (2026-03-22)
- Attestation result/verifier-verdict boundary hygiene:
  - add `docs/30-architecture/attestation-result-boundary-v0.md`, freezing the rule that verifier-generated attestation results stay imported evidence about one appraisal event; imported EAR / AR4SI-style result vocabularies do not become a native approval, current-trust, or result-query plane
  - tighten `docs/30-architecture/attestation-boundary-index.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/attestation-token-schema-v0.md`, `docs/30-architecture/attestation-pack-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0064-confidential-computing-profile.md` so IF-ATTEST still exports evidence rather than verifier verdict objects, and result meaning stays scoped to verifier identity, trust roots, appraisal policy revision, and freshness context
  - wire the new family member through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the attestation cuts as a set rather than re-importing verifier-result folklore piecemeal
- Research / tooling:
  - add `REF-RATS-EAR-DRAFT` and `REF-RATS-AR4SI-DRAFT` to `docs/00-meta/bibliography.md`, translating RATS attestation-result artifacts and reusable trustworthiness/result vocabularies into our D-ATTEST boundary language instead of copying “current trust” or approval folklore directly
  - add `tools/check_attestation_result_boundary.py`, register `EVID-2026-611`, and tighten `tools/check_attestation_boundary_index.py` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised598 (2026-03-22)
- Attestation freshness/family hygiene:
  - add `docs/30-architecture/attestation-freshness-boundary-v0.md`, freezing the rule that freshness/challenge inputs remain explicit verifier-local policy; exported attestation evidence does not become a portable currentness oracle, session-continuity shortcut, or hidden online freshness client plane
  - promote the attestation endorsement seam into a closed D-ATTEST companion family with `docs/30-architecture/attestation-boundary-index.md`, and tighten `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/attestation-token-schema-v0.md`, `docs/30-architecture/attestation-pack-schema-v0.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0064-confidential-computing-profile.md` so nonce/challenge semantics stay distinct from endorsement lookup, verdicts, and provider-native continuity folklore
  - reclassify `docs/30-architecture/attestation-endorsement-boundary-v0.md` as a family member instead of an intentional singleton, and wire the new family through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, and `tools/README.md`
- Research / tooling:
  - add `REF-RFC9783-PSA-TOKEN` to `docs/00-meta/bibliography.md`, translating EAT/PSA caller-provided nonce freshness into our D-ATTEST boundary language instead of copying “current token” folklore directly
  - add `tools/check_attestation_freshness_boundary.py` and `tools/check_attestation_boundary_index.py`, register `EVID-2026-609` and `EVID-2026-610`, and tighten `tools/check_attestation_endorsement_boundary.py` so the attestation boundary family is machine-checked rather than reviewer-memory-only

## Revised597 (2026-03-22)
- Signature countersignature boundary hygiene:
  - add `docs/30-architecture/signature-countersignature-boundary-v0.md`, freezing the rule that nested signatures / countersignatures / timestamp-token signatures stay exact second-order evidence only; a signature over an envelope/checkpoint/token does not by itself retarget to the underlying payload/release meaning, auto-upgrade verification verdict/quorum policy, or create a native recursive-verification / countersignature-inventory seam
  - tighten `docs/30-architecture/signature-boundary-index.md`, `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so wrapper-over-wrapper evidence does not quietly become payload approval, recursive verification, or countersigner-role authority
  - wire the new verifier-family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the second-order signature cuts as a set rather than re-importing countersignature folklore piecemeal
- Research / tooling:
  - add `REF-RFC9338` to `docs/00-meta/bibliography.md`, translating COSE countersignature semantics into our D-SIGENV boundary language instead of copying recursive-wrapper folklore directly
  - add `tools/check_signature_countersignature_boundary.py`, register `EVID-2026-608`, and tighten `tools/check_signature_boundary_index.py` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised596 (2026-03-22)
- Signature signer-acceptance boundary hygiene:
  - add `docs/30-architecture/signature-signer-acceptance-boundary-v0.md`, freezing the rule that multiple signatures remain exact signer evidence while required signer sets, thresholds, role mappings, and duplicate-counting rules stay explicit verifier-local policy; signature arrays and signer hints do not become a portable signer-quorum or maintainer-lookup seam
  - tighten `docs/30-architecture/signature-boundary-index.md`, `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so CH-SIGENV cannot quietly widen into hidden any-one-of/all-of/threshold acceptance, duplicate-record counting, or signer-role directory folklore
  - wire the new verifier-family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the signature cuts as a set rather than re-importing signer-quorum folklore piecemeal
- Research / tooling:
  - add `REF-TUF-SURVIVABLE-KEY-COMPROMISE`, `REF-IN-TOTO-SPEC`, and `REF-IN-TOTO-AUDIT-2023` to `docs/00-meta/bibliography.md`, translating TUF role-threshold, in-toto authorized-functionary, and in-toto duplicate-counting precedents into our D-SIGENV boundary language rather than copying multi-signature wrapper folklore directly
  - add `tools/check_signature_signer_acceptance_boundary.py`, register `EVID-2026-607`, and tighten `tools/check_signature_boundary_index.py` so the new boundary is machine-checked rather than reviewer-memory-only

## Revised595 (2026-03-22)
- Cryptosvc attestation/evidence boundary hygiene:
  - add `docs/30-architecture/cryptosvc-attestation-boundary-v0.md`, freezing the rule that generic key use does not become a portable quote/report/token selector, nonce/challenge broker, evidence-format chooser, endorsement fetcher, or attestation-verifier-policy/result seam; attestation meaning stays on explicit D-ATTEST / CH-ATTEST / CH-ATTESTPACK surfaces rather than generic IF-CRYPTOSVC truth
  - tighten `docs/30-architecture/cryptosvc-boundary-index.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/key-policy-schema-v0.md`, `docs/30-architecture/keyref-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/attestation-pack-schema-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0067-capability-crypto-services-and-key-handles.md` so IF-CRYPTOSVC cannot quietly widen into a hidden quote broker, challenge relay, endorsement fetcher, or verifier-policy oracle
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the cryptosvc cuts as a set rather than re-importing attestation/evidence folklore piecemeal
- Research / tooling:
  - add `REF-TPM2-PART3-QUOTE` to `docs/00-meta/bibliography.md`, and widen the existing Android/RATS imports so TPM 2.0 quote helpers, Android key-attestation certificate-chain retrieval, and RATS role separation translate into our D-CRYPTOSVC attestation boundary language rather than copying provider quote/verifier folklore directly
  - add `tools/check_cryptosvc_attestation_boundary.py`, register `EVID-2026-606`, and tighten the cryptosvc drift surfaces so the new boundary is machine-checked rather than reviewer-memory-only

## Revised594 (2026-03-22)
- Cryptosvc key-lifecycle/admin boundary hygiene:
  - add `docs/30-architecture/cryptosvc-key-lifecycle-boundary-v0.md`, freezing the rule that generic key use does not become a portable key generation, rotation, alias-retargeting, deletion, or lifecycle-admin seam; key use stays about already-held authority rather than provider-owned rollover/delete workflows
  - tighten `docs/30-architecture/cryptosvc-boundary-index.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/key-policy-schema-v0.md`, `docs/30-architecture/keyref-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0067-capability-crypto-services-and-key-handles.md` so IF-CRYPTOSVC cannot quietly widen from explicit key-use authority into a hidden key-generator, rotation broker, delete/archive helper, or provider-admin plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the cryptosvc cuts as a set rather than re-importing lifecycle/admin folklore piecemeal
- Research / tooling:
  - add `REF-MICROSOFT-NCRYPT-CREATEPERSISTEDKEY`, `REF-MICROSOFT-NCRYPT-DELETEKEY`, `REF-APPLE-SECKEYCREATERANDOMKEY`, `REF-APPLE-SECITEMDELETE`, and `REF-ORACLE-JAVA-KEYPAIRGENERATOR` to `docs/00-meta/bibliography.md`, translating CNG / Apple / Java lifecycle precedents into our D-CRYPTOSVC boundary language rather than copying create/rotate/delete folklore directly
  - add `tools/check_cryptosvc_key_lifecycle_boundary.py`, register `EVID-2026-605`, and tighten the cryptosvc drift surfaces so the new boundary is machine-checked rather than reviewer-memory-only

## Revised593 (2026-03-22)
- Cryptosvc key-material boundary hygiene:
  - add `docs/30-architecture/cryptosvc-key-material-boundary-v0.md`, freezing the rule that generic key use does not become a portable secret-bearing key import/export, backup/restore, escrow, or provider-bridge migration seam; key use stays about already-held authority rather than PEM/JWK/PKCS#8/PFX/blob lifecycle workflows
  - tighten `docs/30-architecture/cryptosvc-boundary-index.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/key-policy-schema-v0.md`, `docs/30-architecture/keyref-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0067-capability-crypto-services-and-key-handles.md` so IF-CRYPTOSVC cannot quietly widen from explicit key-use authority into a hidden key-material loader, export helper, backup/restore workflow, or migration plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the cryptosvc cuts as a set rather than re-importing key-material lifecycle folklore piecemeal
- Research / tooling:
  - add `REF-MICROSOFT-NCRYPT-IMPORTKEY`, `REF-APPLE-SECITEMIMPORT`, `REF-APPLE-SECITEMEXPORT`, and `REF-KMIP-SPEC` to `docs/00-meta/bibliography.md`, and widen the `REF-MICROSOFT-NCRYPT-EXPORTKEY` import so CNG / Apple / KMIP key-material precedents translate into our D-CRYPTOSVC boundary language rather than copying provisioning/recovery folklore directly
  - add `tools/check_cryptosvc_key_material_boundary.py`, register `EVID-2026-604`, and tighten the cryptosvc drift surfaces so the new boundary is machine-checked rather than reviewer-memory-only

## Revised592 (2026-03-22)
- Cryptosvc verification/trust-evaluation boundary hygiene:
  - add `docs/30-architecture/cryptosvc-verification-boundary-v0.md`, freezing the rule that generic key use does not become a portable signature-verification, certificate-path, trust-store, revocation, or verifier-policy seam; verification meaning stays on explicit D-SIGENV / D-KEYLESS surfaces rather than generic IF-CRYPTOSVC truth
  - tighten `docs/30-architecture/cryptosvc-boundary-index.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/key-policy-schema-v0.md`, `docs/30-architecture/keyref-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0067-capability-crypto-services-and-key-handles.md` so IF-CRYPTOSVC cannot quietly widen from explicit key-use authority into a hidden verifier broker, certificate-path service, or trust-policy oracle
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the cryptosvc cuts as a set rather than re-importing verifier/trust-store folklore piecemeal
- Research / tooling:
  - add `REF-APPLE-SECTRUST-EVALUATEWITHERROR`, `REF-MICROSOFT-CERTGETCERTIFICATECHAIN`, and `REF-ORACLE-JAVA-PKIXBUILDERPARAMETERS` to `docs/00-meta/bibliography.md`, translating SecTrust, Windows chain-building, and Java PKIX trust-anchor precedents into our D-CRYPTOSVC boundary language rather than copying verifier/trust-store folklore directly
  - add `tools/check_cryptosvc_verification_boundary.py`, register `EVID-2026-603`, and tighten the cryptosvc drift surfaces so the new boundary is machine-checked rather than reviewer-memory-only

## Revised591 (2026-03-22)
- Cryptosvc derived-material boundary hygiene:
  - add `docs/30-architecture/cryptosvc-derived-material-boundary-v0.md`, freezing the rule that generic `derive` use does not become a portable `deriveBits`/`deriveKey`, raw shared-secret export, wrap/unwrap, or derived-key materialization seam; derived-material shaping stays provider-local/setup-local rather than generic IF-CRYPTOSVC meaning
  - tighten `docs/30-architecture/cryptosvc-boundary-index.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/key-policy-schema-v0.md`, `docs/30-architecture/keyref-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0067-capability-crypto-services-and-key-handles.md` so IF-CRYPTOSVC cannot quietly widen from explicit key-use authority into a hidden shared-secret export, wrapped-key interchange, or provider-lifecycle result-shaping plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the cryptosvc cuts as a set rather than re-importing derive/export folklore piecemeal
- Research / tooling:
  - add `REF-MICROSOFT-NCRYPT-DERIVEKEY` and `REF-MICROSOFT-NCRYPT-EXPORTKEY` to `docs/00-meta/bibliography.md`, and widen the `REF-W3C-WEBCRYPTO-2` import so CNG/WebCrypto derived-material precedents translate into our D-CRYPTOSVC boundary language rather than copying deriveBits/wrapKey folklore directly
  - add `tools/check_cryptosvc_derived_material_boundary.py`, register `EVID-2026-602`, and tighten the cryptosvc drift surfaces so the new boundary is machine-checked rather than reviewer-memory-only

## Revised590 (2026-03-22)
- Cryptosvc mechanism/capability boundary hygiene:
  - add `docs/30-architecture/cryptosvc-mechanism-boundary-v0.md`, freezing the rule that generic key use does not become a portable mechanism-selection, algorithm-capability discovery, provider-property query, or caller-tunable padding/mode/hash/curve seam; `CH-KEYPOL.alg` stays policy pin/hint rather than negotiation transcript
  - tighten `docs/30-architecture/cryptosvc-boundary-index.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/key-policy-schema-v0.md`, `docs/30-architecture/keyref-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0067-capability-crypto-services-and-key-handles.md` so IF-CRYPTOSVC cannot quietly widen from explicit key-use authority into a hidden mechanism browser, provider-property broker, or retry-until-supported negotiation plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`; also fill the missing `posture-index.md` rows for the other live cryptosvc family members so discovery reflects the actual closed set
- Research / tooling:
  - add `REF-MICROSOFT-CNG-TYPICAL-PROGRAMMING`, `REF-ORACLE-JAVA-PROVIDER`, and `REF-W3C-WEBCRYPTO-2` to `docs/00-meta/bibliography.md`, translating CNG algorithm-provider/property, JCA provider-service enumeration, and WebCrypto algorithm/capability/privacy precedents into our D-CRYPTOSVC boundary language rather than copying mechanism-discovery folklore directly
  - add `tools/check_cryptosvc_mechanism_boundary.py`, register `EVID-2026-601`, and tighten the cryptosvc drift surfaces so the new boundary is machine-checked rather than reviewer-memory-only

## Revised589 (2026-03-21)
- Cryptosvc inventory/search boundary hygiene:
  - add `docs/30-architecture/cryptosvc-inventory-boundary-v0.md`, freezing the rule that generic key use does not become a portable key inventory, alias-listing, certificate-search, or metadata-query seam; provider-held discovery remains provider-local rather than generic IF-CRYPTOSVC meaning
  - tighten `docs/30-architecture/cryptosvc-boundary-index.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/keyref-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0067-capability-crypto-services-and-key-handles.md` so IF-CRYPTOSVC cannot quietly widen from explicit key-use authority into a hidden key-browser, alias-query, or certificate-search broker
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the cryptosvc cuts as a set rather than re-importing key-browser folklore piecemeal
- Research / tooling:
  - add `REF-APPLE-KEYCHAIN-ITEMS`, `REF-MICROSOFT-CERTFINDCERTIFICATEINSTORE`, and `REF-ORACLE-JAVA-KEYSTORE` to `docs/00-meta/bibliography.md`, translating keychain query, certificate-store search, and keystore-alias precedents into our D-CRYPTOSVC boundary language rather than copying inventory/search folklore directly
  - add `tools/check_cryptosvc_inventory_boundary.py`, register `EVID-2026-600`, and tighten the existing cryptosvc drift surfaces so the new boundary is machine-checked rather than reviewer-memory-only

## Revised588 (2026-03-21)
- Cryptosvc interactive-auth boundary hygiene:
  - add `docs/30-architecture/cryptosvc-interactive-auth-boundary-v0.md`, freezing the rule that generic key use does not become a portable PIN, biometric, user-presence, unlock workflow, or auth-state seam; prompt modality, cached-auth windows, and token-login state stay provider-local rather than generic IF-CRYPTOSVC meaning
  - tighten `docs/30-architecture/cryptosvc-boundary-index.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/key-policy-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0067-capability-crypto-services-and-key-handles.md` so IF-CRYPTOSVC cannot quietly widen from explicit key-use authority into a hidden unlock, biometric-prompt, or auth-state broker
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the cryptosvc cuts as a set rather than re-importing prompt/presence folklore piecemeal
- Research / tooling:
  - add `REF-APPLE-LOCALAUTH-KEYCHAIN` and `REF-MICROSOFT-NCRYPT-UIPOLICY` to `docs/00-meta/bibliography.md`, translating LocalAuthentication/keychain user-presence and CNG strong-key UI / PIN-property precedents into our D-CRYPTOSVC boundary language rather than copying prompt/unlock folklore directly
  - add `tools/check_cryptosvc_interactive_auth_boundary.py`, register `EVID-2026-599`, and tighten the existing cryptosvc drift surfaces so the new boundary is machine-checked rather than reviewer-memory-only

## Revised587 (2026-03-21)
- Cryptosvc boundary-family closure + provider-selection hygiene:
  - add `docs/30-architecture/cryptosvc-boundary-index.md`, promoting the current D-CRYPTOSVC / D-AUTHAGENT meaning pins into one closed companion discovery surface so provider-role, forwarding/delegation, and provider-selection semantics stop living as neighboring singleton lore
  - add `docs/30-architecture/cryptosvc-provider-selection-boundary-v0.md`, freezing the rule that generic crypto use does not become a portable provider/backend, PKCS#11 slot/token/session, smartcard-reader, or alias-selection seam; key use stays bound to explicit CH-KEYREF/routes rather than caller-chosen backend folklore
  - tighten `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/keyref-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/secret-authority-adjunct-index.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, and `rfcs/0067-capability-crypto-services-and-key-handles.md` so IF-CRYPTOSVC cannot quietly widen from explicit key-use authority into a hidden provider/token selection broker
  - wire the new family/index through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the cryptosvc cuts as a set rather than re-importing token/provider folklore piecemeal
- Research / tooling:
  - add `REF-MICROSOFT-NCRYPT-OPENSTORAGEPROVIDER` and `REF-ANDROID-KEYCHAIN-CHOOSEPRIVATEKEYALIAS` to `docs/00-meta/bibliography.md`, translating CNG key-storage-provider selection and Android alias-picker precedents into our D-CRYPTOSVC boundary language rather than copying backend-selection folklore directly
  - add `tools/check_cryptosvc_boundary_index.py`, `tools/check_cryptosvc_provider_selection_boundary.py`, register `EVID-2026-597` / `EVID-2026-598`, and tighten the existing cryptosvc drift surfaces so the new family/boundary are machine-checked rather than reviewer-memory-only

## Revised586 (2026-03-21)
- OpenURI navigation-observation boundary hygiene:
  - add `docs/30-architecture/openuri-navigation-observation-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable page-load callback, redirect telemetry, final-URL observation, or browser/page-state seam; post-launch navigation state stays handler-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden post-launch browser telemetry or final-URL observation plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing browser callback folklore piecemeal
- Research / tooling:
  - add `REF-CHROME-CUSTOM-TABS-ENGAGEMENT`, `REF-WEBVIEW2-NAVIGATION-EVENTS`, `REF-WEBKIT-WKNAVIGATIONDELEGATE`, and `REF-SP24-TABBED-OUT` to `docs/00-meta/bibliography.md`, translating browser/webview navigation-event precedents and callback-leak research into our D-PLUMB boundary language rather than copying browser callback folklore directly
  - add `tools/check_openuri_navigation_observation_boundary.py`, register `EVID-2026-596`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised585 (2026-03-21)
- OpenURI web-permission boundary hygiene:
  - add `docs/30-architecture/openuri-web-permission-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable browser/web permission broker, powerful-feature prompt surface, or downstream site-permission seam; permission prompting and permission-state truth stay request-local or provider-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden browser permission-query, prompt, or remembered-grant control plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing browser permission folklore piecemeal
- Research / tooling:
  - add `REF-W3C-PERMISSIONS`, `REF-W3C-GEOLOCATION`, `REF-W3C-MEDIACAPTURE-STREAMS`, and `REF-W3C-NOTIFICATIONS` to `docs/00-meta/bibliography.md`, translating browser powerful-feature permission precedents into our D-PLUMB boundary language rather than copying browser/runtime folklore directly
  - add `tools/check_openuri_web_permission_boundary.py`, register `EVID-2026-595`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised584 (2026-03-21)
- OpenURI credential-mediation boundary hygiene:
  - add `docs/30-architecture/openuri-credential-mediation-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable credential-provider, password-autofill, passkey, or account-selection seam; credential mediation stays on explicit auth/credential workflows rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden credential/autofill/passkey broker
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing browser/credential folklore piecemeal
- Research / tooling:
  - add `REF-ANDROID-CREDENTIAL-MANAGER` and `REF-APPLE-PASSKEYS` to `docs/00-meta/bibliography.md`, translating credential-provider, passkey, and autofill precedents into our D-PLUMB boundary language rather than copying browser/login folklore directly
  - add `tools/check_openuri_credential_mediation_boundary.py`, register `EVID-2026-594`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised583 (2026-03-21)
- OpenURI URL-safety boundary hygiene:
  - add `docs/30-architecture/openuri-url-safety-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable URL-safety, phishing, malware, deceptive-site, or reputation-verdict seam; threat classification and warning/block policy stay provider-local or policy-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden URL-classification, phishing-check, or reputation-verdict broker
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing browser/OS threat-verdict folklore piecemeal
- Research / tooling:
  - add `REF-GOOGLE-SAFE-BROWSING`, `REF-MICROSOFT-DEFENDER-SMARTSCREEN`, and `REF-APPLE-SAFARI-FRAUDULENT-WEBSITE-WARNING` to `docs/00-meta/bibliography.md`, translating current URL-warning and reputation-check precedents into our D-PLUMB boundary language rather than copying browser security-folklore directly
  - add `tools/check_openuri_url_safety_boundary.py`, register `EVID-2026-593`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised582 (2026-03-21)
- OpenURI resource-grant boundary hygiene:
  - add `docs/30-architecture/openuri-resource-grant-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable URI-permission, security-scoped-bookmark, attachment, or docref-handoff seam; local-object authority transfer stays on explicit file/document/transfer workflows
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/transfer-portal-posture-v0.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden local-resource grant or attachment-handoff plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing URI-permission or security-scope semantics piecemeal
- Research / tooling:
  - add `REF-ANDROID-FILEPROVIDER-SHARE-FILE` and `REF-ANDROID-PERSISTABLE-URI-PERMISSIONS` to `docs/00-meta/bibliography.md`, translating FileProvider and SAF URI-permission precedents into our D-PLUMB boundary language rather than copying mobile attachment folklore
  - add `tools/check_openuri_resource_grant_boundary.py`, register `EVID-2026-592`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised581 (2026-03-21)
- OpenURI content-type boundary hygiene:
  - add `docs/30-architecture/openuri-content-type-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable MIME, UTI, content-type, sniffing, or handler-by-type seam; content classification and type-based routing stay provider-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden MIME-sniffing, preflight-classification, or handler-by-type control plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing type-resolution semantics piecemeal
- Research / tooling:
  - add `REF-WHATWG-MIME-SNIFFING`, `REF-ANDROID-INTENTS-DATA-AND-TYPE`, `REF-APPLE-NSWORKSPACE-URLSFORAPPLICATIONS-TOOPEN-CONTENTTYPE`, and `REF-APPLE-LSCOPYALLROLEHANDLERSFORCONTENTTYPE` to `docs/00-meta/bibliography.md`, translating MIME-sniffing and handler-by-type precedents into our D-PLUMB boundary language rather than copying launcher/classifier folklore
  - add `tools/check_openuri_content_type_boundary.py`, register `EVID-2026-591`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised580 (2026-03-21)
- OpenURI launch-disposition boundary hygiene:
  - add `docs/30-architecture/openuri-launch-disposition-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable tab/window/task placement, browsing-context target, named-window reuse, or app-instance reuse/new-instance seam; placement and reuse stay provider-local rather than generic OpenURI truth
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing placement/reuse semantics piecemeal
  - add `REF-WHATWG-WINDOW-OPEN`, `REF-ANDROID-INTENTS-FLAGS`, `REF-ANDROID-RECENTS`, `REF-APPLE-NSWORKSPACE-CREATESNEWAPPLICATIONINSTANCE`, and `REF-APPLE-NSWORKSPACE-RUNNING-APPLICATION-SUBSTITUTION` to `docs/00-meta/bibliography.md`, translating current tab/window/task/app-instance placement precedents into our D-PLUMB boundary language rather than copying browser/window-manager folklore
  - add `tools/check_openuri_launch_disposition_boundary.py`, register `EVID-2026-590`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised579 (2026-03-21)
- OpenURI embedded-web-surface boundary hygiene:
  - add `docs/30-architecture/openuri-embedded-web-surface-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable embedded-web, in-app-browser, custom-tab, Safari-view-controller, or browser-chrome customization seam; browser-surface choice, presentation chrome, and in-app browsing mode stay provider-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden embedded-browser presentation or browser-chrome control plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing in-app-browser semantics piecemeal
- Research / tooling:
  - add `REF-ANDROID-CUSTOM-TABS-OVERVIEW`, `REF-CHROME-CUSTOM-TABS-UI-CUSTOMIZATION`, `REF-CHROME-CUSTOM-TABS-INTERACTIVITY`, and `REF-APPLE-SFSAFARIVIEWCONTROLLER` to `docs/00-meta/bibliography.md`, translating current embedded-browser precedents into our D-PLUMB boundary language rather than copying mobile in-app-browsing folklore
  - add `tools/check_openuri_embedded_web_surface_boundary.py`, register `EVID-2026-589`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised578 (2026-03-21)
- OpenURI verified-association boundary hygiene:
  - add `docs/30-architecture/openuri-verified-association-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable verified-app-link, associated-domain, universal-link trust, or domain-verification seam; association state, trusted deep-link routing, and verified-match outcomes stay shell-local or policy-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden domain-association trust broker or verified-route control plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing verified-app-link semantics piecemeal
- Research / tooling:
  - add `REF-ANDROID-APP-LINKS`, `REF-ANDROID-VERIFY-APP-LINKS`, and `REF-APPLE-ASSOCIATED-DOMAINS` to `docs/00-meta/bibliography.md`, translating current verified-deep-link / associated-domain precedents into our D-PLUMB boundary language rather than copying mobile deep-link folklore
  - add `tools/check_openuri_verified_association_boundary.py`, register `EVID-2026-588`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised577 (2026-03-21)
- OpenURI auth-session boundary hygiene:
  - add `docs/30-architecture/openuri-auth-session-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable browser-auth / SSO / OAuth login seam; redirect capture, auth-session UX, and auth-result handling stay request-local/provider-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden browser-auth or redirect-capture control plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing browser-auth semantics piecemeal
- Research / tooling:
  - add `REF-APPLE-ASWEBAUTHSESSION` and `REF-CHROME-AUTH-TAB` to `docs/00-meta/bibliography.md`, translating current browser-auth session precedents into our D-PLUMB boundary language rather than copying login-API folklore
  - add `tools/check_openuri_auth_session_boundary.py`, register `EVID-2026-587`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised576 (2026-03-21)
- OpenURI speculative-loading boundary hygiene:
  - add `docs/30-architecture/openuri-speculative-loading-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable browser warmup, DNS-prefetch, preconnect, prefetch, or prerender seam; speculative network/process/cache work stays request-local/provider-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden speculative-loading or pre-navigation performance/control plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing speculative-loading semantics piecemeal
- Research / tooling:
  - add `REF-WHATWG-LINK-TYPE-DNS-PREFETCH`, `REF-WHATWG-LINK-TYPE-PRECONNECT`, `REF-WHATWG-LINK-TYPE-PREFETCH`, `REF-CHROME-CUSTOM-TABS-WARMUP-PREFETCH`, and `REF-CHROME-SPECULATION-RULES-PRERENDER` to `docs/00-meta/bibliography.md`, translating current browser performance/speculation precedents into our D-PLUMB boundary language rather than copying browser folklore
  - add `tools/check_openuri_speculative_loading_boundary.py`, register `EVID-2026-586`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised575 (2026-03-21)
- OpenURI content-extraction boundary hygiene:
  - add `docs/30-architecture/openuri-content-extraction-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable reader mode, article-distillation, extracted-text/markdown, or summary seam; distillation stays request-local/provider-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden reader, distiller, or extracted-content plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing content-extraction semantics piecemeal
- Research / tooling:
  - add `REF-MOZILLA-READABILITY`, `REF-CHROMIUM-READER-MODE`, `REF-POSTLIGHT-PARSER`, and `REF-APPLE-SAFARI-READER` to `docs/00-meta/bibliography.md`, translating current reader/distillation precedents into our D-PLUMB boundary language rather than copying browser/parser folklore
  - add `tools/check_openuri_content_extraction_boundary.py`, register `EVID-2026-585`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised574 (2026-03-21)
- OpenURI preview-metadata boundary hygiene:
  - add `docs/30-architecture/openuri-preview-metadata-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable link-preview, unfurl, title/icon/image extraction, or metadata-fetch seam; preview generation stays request-local/provider-local rather than generic OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden crawler, rich-link, or metadata-card plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, and `docs/00-meta/evidence-index.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing preview/unfurl semantics piecemeal
- Research / tooling:
  - add `REF-APPLE-LINKPRESENTATION`, `REF-SLACK-UNFURLING-LINKS`, `REF-SLACK-ROBOTS`, and `REF-OPEN-GRAPH-PROTOCOL` to `docs/00-meta/bibliography.md`, translating current rich-link / unfurl precedents into our D-PLUMB boundary language rather than copying browser/chat folklore
  - add `tools/check_openuri_preview_metadata_boundary.py`, register `EVID-2026-584`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised573 (2026-03-21)
- add `docs/30-architecture/openuri-install-fallback-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable browser-fallback, app-store redirect, inline-install, or install-if-missing seam; missing-handler outcomes stay request-local rather than silently becoming software-acquisition authority
- tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden browser/store/install fallback or software-acquisition plane
- wire the new boundary across `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, and `docs/00-meta/evidence-index.md` so discovery surfaces stay closed under the larger OpenURI family
- add `REF-CHROME-ANDROID-INTENTS`, `REF-GOOGLE-PLAY-LINKING`, `REF-GOOGLE-PLAY-INLINE-INSTALL`, and `REF-APPLE-UNIVERSAL-LINKS` to `docs/00-meta/bibliography.md`, translating mainstream browser/store/install fallback patterns into our D-PLUMB language rather than importing launcher folklore verbatim
- add `tools/check_openuri_install_fallback_boundary.py`, register `EVID-2026-583`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised572 (2026-03-21)
- OpenURI session-selection boundary hygiene:
  - add `docs/30-architecture/openuri-session-selection-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable browser-session, profile, cookie-jar, or private/incognito/ephemeral selection seam; browsing-state choice stays handler-local rather than portable OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden browser-session, cookie-jar, or auth-state control plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing browser-session/profile semantics piecemeal
- Research / tooling:
  - add `REF-ANDROID-INAPP-BROWSING-CUSTOM-TABS`, `REF-CHROME-EPHEMERAL-CUSTOM-TABS`, and `REF-APPLE-ASWEBAUTH-EPHEMERAL` to `docs/00-meta/bibliography.md`, translating current shared-vs-private browser-state precedents into our D-PLUMB boundary language rather than copying launcher folklore
  - add `tools/check_openuri_session_selection_boundary.py`, register `EVID-2026-582`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised571 (2026-03-21)
- OpenURI request-shaping boundary hygiene:
  - add `docs/30-architecture/openuri-request-shaping-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable request-header, method, body, or equivalent downstream-request customization seam; downstream dereference stays handler-local rather than portable OpenURI truth
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden browser-control or request-customization plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing request-shaping semantics piecemeal
- Research / tooling:
  - add `REF-ANDROID-BROWSER-EXTRA-HEADERS` and `REF-CHROME-CUSTOM-TABS-REQUEST-HEADERS` to `docs/00-meta/bibliography.md`, translating current browser/header-shaping precedents into our D-PLUMB boundary language rather than copying launcher folklore
  - add `tools/check_openuri_request_shaping_boundary.py`, register `EVID-2026-581`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised570 (2026-03-20)
- OpenURI materialization boundary hygiene:
  - add `docs/30-architecture/openuri-materialization-boundary-v0.md`, freezing the rule that generic URI launch does not become a portable download, staged-copy, import, local-path, or docref-minting seam; durable bytes and local-object identity stay on explicit file/document workflows
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a hidden fetch/import/persistence plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing download/materialization semantics piecemeal
- Research / tooling:
  - add `REF-ANDROID-DOWNLOADMANAGER-REQUEST` to `docs/00-meta/bibliography.md`, translating explicit download/materialization controls into our D-PLUMB boundary language rather than copying browser/launcher folklore
  - add `tools/check_openuri_materialization_boundary.py`, register `EVID-2026-580`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised569 (2026-03-20)
- OpenURI subject-echo boundary hygiene:
  - add `docs/30-architecture/openuri-subject-echo-boundary-v0.md`, freezing the rule that full launched URIs stay request-local rather than becoming a portable `opened_uri` / normalized-URI receipt/history/logging seam; durable audit prefers digests or bounded redacted summaries over verbatim URI text
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/30-architecture/plumb-message-schema-v0.md`, `docs/30-architecture/transcript-contract.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a durable raw-URI side channel
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing full-subject echo/history semantics piecemeal
- Research / tooling:
  - add `REF-RFC3986-URI-GENERIC-SYNTAX` and `REF-RFC6819-OAUTH-SECURITY` to `docs/00-meta/bibliography.md`, translating URI-sensitive-information and URL-history/log leakage precedents into our D-PLUMB boundary language rather than copying launcher folklore
  - add `tools/check_openuri_subject_echo_boundary.py`, register `EVID-2026-579`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised568 (2026-03-20)
- OpenURI recent-items boundary hygiene:
  - add `docs/30-architecture/openuri-recent-items-boundary-v0.md`, freezing the rule that generic URI launch exports no portable add-to-recents, suppress-history, reopen-token, or durable-history receipt seam; any shell-local launch history stays non-authoritative and separate from explicit document persistence
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a durable reopen/history plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing recent-items semantics piecemeal
- Research / tooling:
  - add `REF-WINDOWS-SHADDTORECENTDOCS` and `REF-WINDOWS-FOS-DONTADDTORECENT` to `docs/00-meta/bibliography.md`, translating current recent-items mutation and suppression precedents into our D-PLUMB boundary language rather than copying launcher folklore
  - add `tools/check_openuri_recent_items_boundary.py`, register `EVID-2026-578`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised567 (2026-03-20)
- OpenURI callback-reentry boundary hygiene:
  - add `docs/30-architecture/openuri-callback-reentry-boundary-v0.md`, freezing the rule that mediated URI launch stays a one-way request with request-local completion rather than a portable callback URL, deep-link reentry, redirect-back, or x-callback-style rendezvous channel on `portal.uri.*`
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a second rendezvous bus with hidden wakeup/reentry semantics
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing callback/redirect-back semantics piecemeal
- Research / tooling:
  - add `REF-RFC8252-NATIVE-APPS` to `docs/00-meta/bibliography.md`, translating native-app redirect-back precedents into our D-PLUMB boundary language rather than copying auth / deep-link folklore
  - add `tools/check_openuri_callback_reentry_boundary.py`, register `EVID-2026-577`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised566 (2026-03-20)
- OpenURI activation-control boundary hygiene:
  - add `docs/30-architecture/openuri-activation-control-boundary-v0.md`, freezing the rule that foregrounding, activation handoff, and focus-steering stay shell/compositor-owned rather than a portable `activation_token`, foreground-control knob, or frontmost receipt seam on `portal.uri.*`
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into an attention-steering or focus-stealing control plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so future revisions re-find the OpenURI cuts as a set instead of re-importing activation-token / foreground-control semantics piecemeal
- Research / tooling:
  - add `REF-WAYLAND-XDG-ACTIVATION` and `REF-APPLE-NSWORKSPACE-ACTIVATES` to `docs/00-meta/bibliography.md`, translating compositor-owned activation tokens and AppKit foregrounding controls into our D-PLUMB boundary language rather than copying launcher folklore
  - add `tools/check_openuri_activation_control_boundary.py`, register `EVID-2026-576`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised565 (2026-03-20)
- OpenURI launch-completion boundary hygiene:
  - add `docs/30-architecture/openuri-launch-completion-boundary-v0.md`, freezing the rule that mediated OpenURI outcomes stay admission-scoped rather than becoming a portable launched-handler completion, liveness, exit, or “the user definitely saw this” oracle
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/acp-acceptance-completion-posture-v0.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a fake completion or current-live-state plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, and `docs/30-architecture/decision-map.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing launcher-folklore success semantics piecemeal
- Research / tooling:
  - add `REF-APPLE-OPENURL-COMPLETION` and `REF-WINDOWS-SHELLEXECUTEEX` to `docs/00-meta/bibliography.md`, translating current launch-success/completion precedents into our D-PLUMB boundary language rather than copying ecosystem helper folklore
  - add `tools/check_openuri_launch_completion_boundary.py`, register `EVID-2026-575`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised564 (2026-03-20)
- OpenURI opener-attribution boundary hygiene:
  - add `docs/30-architecture/openuri-opener-attribution-boundary-v0.md`, freezing the rule that opener identity, referrer-like metadata, and caller-attribution context stay portal/shell-owned local routing state rather than a portable requester-controlled payload or target-visible cross-app channel
  - tighten `docs/30-architecture/openuri-boundary-index.md`, `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a source-app / referrer / opener-window attribution plane
  - wire the new family member through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, and `docs/30-architecture/decision-map.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing source-app attribution semantics piecemeal
- Research / tooling:
  - add `REF-XDG-PORTAL-APPCHOOSER`, `REF-ANDROID-ACTIVITY-REFERRER`, and `REF-APPLE-OPENURL-SOURCEAPPLICATION` to `docs/00-meta/bibliography.md`, translating current app/window/referrer attribution precedents into our D-PLUMB boundary language rather than copying launcher folklore
  - add `tools/check_openuri_opener_attribution_boundary.py`, register `EVID-2026-574`, and tighten the existing OpenURI drift gates so the new boundary is machine-checked rather than reviewer-memory-only

## Revised563 (2026-03-20)
- OpenURI boundary-family promotion + handler-selection boundary hygiene:
  - add `docs/30-architecture/openuri-boundary-index.md`, promoting the adjacent OpenURI meaning pins into one closed companion family so scheme-support, handler-selection, and show-item-fidelity seams stop lingering as neighboring singleton docs and remain discoverable from one stable surface
  - add `docs/30-architecture/openuri-handler-selection-boundary-v0.md`, freezing the rule that concrete handler choice, chooser/default policy, and selected-handler identity stay shell/policy-owned; Phase 1 exports no requester-visible `open_with(app)` / `ask` / chooser/default controls or selected-handler receipts
  - tighten `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/openuri-scheme-support-boundary-v0.md`, `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI cannot quietly widen from mediated launch into a target-selection, chooser-control, or selected-handler-reporting plane
  - wire the new family + boundary through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, and `docs/00-meta/llm-runbook.md` so future revisions re-find the OpenURI cuts as a set rather than re-importing ecosystem chooser semantics piecemeal
- Research / tooling:
  - tighten `REF-XDG-PORTAL-OPENURI` and add `REF-ANDROID-CREATECHOOSER` to `docs/00-meta/bibliography.md`, translating current xdg `ask` / default-or-last-choice semantics plus Android chooser forcing into our D-PLUMB boundary language rather than copying launcher folklore
  - add `tools/check_openuri_boundary_index.py` and `tools/check_openuri_handler_selection_boundary.py`, register `EVID-2026-572` and `EVID-2026-573`, and tighten the existing OpenURI drift gates so the family promotion and new boundary are machine-checked rather than reviewer-memory-only

## Revised562 (2026-03-20)
- OpenURI show-item exactness boundary hygiene:
  - add `docs/30-architecture/openuri-showitem-exactness-boundary-v0.md`, freezing the rule that “show this item” keeps exact reveal/select meaning and does not silently degrade into opening the parent directory or a generic browse surface when a backend lacks faithful selection support
  - tighten `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/effect-contract-schema-v0.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so show-item/reveal semantics stay path-free, non-amplifying, and transcript-honest across runtimes instead of collapsing into approximate folder-open success
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, and `docs/30-architecture/decision-map.md` so future revisions re-find the exactness decision instead of re-importing xdg-style fallback behavior by accident
- Research / tooling:
  - add `REF-FDO-FILEMANAGER-SHOWITEMS`, `REF-WINDOWS-SHOPENFOLDERANDSELECTITEMS`, and `REF-APPLE-ACTIVATEFILEVIEWERSELECTING` to `docs/00-meta/bibliography.md`, translating cross-platform “reveal/select this item in a file viewer” precedents into D-PLUMB boundary language rather than generic launcher prose
  - add `tools/check_openuri_showitem_exactness_boundary.py`, register `EVID-2026-571`, and tighten `tools/check_openuri_portal_posture.py`, making the new boundary machine-checked so exact reveal/select cannot silently widen into approximate parent-browse semantics

## Revised561 (2026-03-20)
- OpenURI scheme-support boundary hygiene:
  - add `docs/30-architecture/openuri-scheme-support-boundary-v0.md`, freezing the rule that exact scheme-support knowledge stays shell/policy-owned and does not become a portable requester-visible `SchemeSupported` / `canOpenURL` / `queryIntentActivities` oracle, handler inventory surface, or future-success promise
  - tighten `docs/30-architecture/openuri-portal-posture-v0.md`, `docs/30-architecture/portal-family-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md` so OpenURI imports mediated launch from current portal/platform precedents without inheriting an app-visible support-probing surface
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/boundary-family-map.md`, and `docs/30-architecture/decision-map.md` so future revisions re-find the no-probe decision instead of relaxing it piecemeal
- Research / tooling:
  - tighten `REF-XDG-PORTAL-OPENURI` in `docs/00-meta/bibliography.md` so the current OpenURI reference explicitly notes the tempting `SchemeSupported` import and why SlopOS declines to export it as portable requester semantics
  - add `tools/check_openuri_scheme_support_boundary.py` and register `EVID-2026-570`, making the new boundary machine-checked so exact scheme-support knowledge cannot silently widen into an installed-handler oracle

## Revised560 (2026-03-20)
- D-EPHEM disposable-target selection boundary:
  - add `docs/30-architecture/disposable-target-selection-boundary-v0.md`, freezing the rule that callers may request a fresh disposable destination but may not name or discover the concrete template/domain target; exact disposable selection stays policy/supervisor-owned, fails closed when unavailable, and does not create a new ACP kind or conflict-key family
  - tighten `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `rfcs/0050-disposable-domains-and-one-shot-sandboxes.md`, `rfcs/0003-ecosystem-features-to-bake-in.md`, and `docs/90-inspirations/os-lessons.md` so Qubes-style disposable routing is imported only as a policy-owned fresh-per-request destination pattern rather than a caller-visible VM/template selector or ambient cross-domain naming plane
  - wire the new singleton boundary through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/boundary-family-map.md`, and `docs/30-architecture/decision-map.md` so future revisions re-find the disposable-target decision instead of re-deciding it piecemeal
- Research / tooling:
  - add `REF-QUBES-RPC-POLICY` and `REF-QUBES-POLICY-DAEMON` to `docs/00-meta/bibliography.md`, translating current Qubes qrexec policy/target-selection docs into our D-EPHEM / D-PLUMB boundary language rather than copying ecosystem semantics
  - add `tools/check_disposable_target_selection_boundary.py` and register `EVID-2026-569`, making the new boundary machine-checked so disposable routing cannot silently widen into template inventory, VM-name probing, or a hidden cross-domain service selector

## Revised559 (2026-03-20)
- Request-state family promotion hygiene:
  - add `docs/30-architecture/request-state-adjunct-index.md`, promoting the repeated jobs/background/network/entropy/notification/timeproof request-identity honesty seams into one explicit companion family so the archive stops rediscovering the same request-vs-live-state split piecemeal
  - tighten `docs/30-architecture/portal-adjunct-index.md` and `docs/30-architecture/lease-adjunct-index.md` so direct portal workflows, leased-authority semantics, and request-state honesty stay explicitly separate discovery surfaces instead of letting “portal” blur them back together
  - tighten `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/adjunct-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/00-meta/llm-runbook.md`, and `docs/00-meta/resolved-history.md` so the new family is wired into the stable archive discovery layer rather than living only in six scattered posture docs
- Tooling / assurance:
  - add `tools/check_request_state_adjunct_index.py` and register `EVID-2026-568`, making the new family machine-checked and keeping every current `*-request-state-posture-v0.md` member explicitly enumerated from one stable discovery surface

## Revised558 (2026-03-20)
- D-LEASE lease-descriptor live-state boundary hygiene:
  - add `docs/30-architecture/lease-descriptor-state-boundary-v0.md`, freezing the rule that portal-issued lease/grant descriptors prove exact issued bounds only and do not by themselves prove current provider-owned active/revoked/expired/session-live state, so historical descriptors and receipts stop sounding like a generic status oracle
  - tighten `docs/30-architecture/capability-lease-posture-v0.md`, `docs/30-architecture/network-lease-schema-v0.md`, `docs/30-architecture/location-lease-schema-v0.md`, `docs/30-architecture/background-lease-schema-v0.md`, `docs/30-architecture/inhibit-lease-schema-v0.md`, `docs/30-architecture/ui-automation-lease-schema-v0.md`, `docs/30-architecture/lease-adjunct-index.md`, `docs/30-architecture/decision-map.md`, `rfcs/0066-capability-leases-and-limited-use-proxies.md`, `rfcs/0101-location-leases-and-portals.md`, and `rfcs/0102-inhibit-leases-and-power-inhibition-portal.md` so lease/grant descriptors stay issuance evidence even when the corresponding runtime state remains provider-local and mutable
- Tooling / assurance:
  - add `I-LEASE-4`, `PO-LEASE-STATE`, `tools/check_lease_descriptor_state_boundary.py`, and register `EVID-2026-567`, wiring the new boundary through README/docs indexes, the profile posture matrix, resolved history, the LLM runbook, the boundary-family map, and tools README so future revisions cannot silently let historical lease/grant descriptors masquerade as current live-state truth

## Revised557 (2026-03-20)
- D-ATTN boundary-family promotion hygiene:
  - add `docs/30-architecture/attention-boundary-index.md`, promoting the adjacent D-ATTN urgent-interrupt and transient-vs-durable-truth meaning pins into one explicit companion boundary family so attention semantics stop lingering as nominal singletons after the seam clearly grew beyond one doc
  - tighten `docs/30-architecture/boundary-family-map.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/attention-lease-posture-v0.md`, `rfcs/0055-attention-authority-and-notifications.md`, `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, and `docs/00-meta/llm-runbook.md` so D-ATTN discovery routes through one closed family index rather than reviewer memory or two adjacent singleton entries
  - update `docs/30-architecture/attention-durable-interrupt-boundary-v0.md` and `docs/30-architecture/attention-durable-status-boundary-v0.md` so both docs explicitly say they are members of the D-ATTN companion family instead of claiming no broader family exists yet
- Tooling / assurance:
  - add `tools/check_attention_boundary_index.py` and register `EVID-2026-566`, making the new D-ATTN companion boundary family machine-checked and discoverable so future attention-boundary growth pays for same-revision family maintenance instead of drifting back into singleton folklore

## Revised556 (2026-03-20)
- ACP acceptance/completion boundary hygiene:
  - add `docs/30-architecture/acp-acceptance-completion-posture-v0.md`, freezing the rule that accepted CH-ACP requests and CH-ACPOUT receipts prove exact admission of one reviewed request, not downstream completion or current provider-owned live state, so receipt trails do not silently turn into a generic async-status oracle
  - tighten `docs/30-architecture/acp-outcome-receipt-schema-v0.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/README.md`, and `docs/30-architecture/decision-map.md` so CH-ACPOUT `outcome="accept"` / `effect` stay bounded admission-path evidence even when jobs/background/notifications/timeproof/network/entropy/openuri flows continue later on provider-local or request-local completion paths
- Assurance / hygiene:
  - add `I-ACPOUT-2`, `PO-ACPOUT-BOUNDARY`, and register `EVID-2026-565`, making the acceptance-vs-completion split explicit across CH-ACPOUT / ACP / assurance surfaces instead of leaving it as reviewer inference
  - add `tools/check_acp_acceptance_completion_posture.py`, wire the new posture through README/docs indexes, the profile posture matrix, the LLM runbook, resolved history, and tools README, and add `REF-HTTP-SEM-202` to the bibliography so future revisions cannot silently let accepted-request receipts stand in for downstream completion or current live-state truth

## Revised555 (2026-03-20)
- External-source review-queue hygiene:
  - extend `docs/00-meta/external-source-locks.json` so each compact lock row now carries `retrieved_on` + `review_by`, turning the existing byte-lock surface into a bounded same-revision review surface instead of leaving mutable-head refresh to maintainer memory
  - add `docs/00-meta/external-source-review-queue.md`, a generated no-URL maintainer queue that sorts the locked refs by next review date, publication-surface risk, and in-repo reference count so the current confidential-computing / attestation sources stay reviewable over time without vendoring upstream artifacts
  - tighten `docs/60-engineering/external-source-lock-contract.md`, `docs/README.md`, and `docs/00-meta/llm-runbook.md` so the lock contract explicitly names the review queue, requires `retrieved_on` / `review_by`, and makes the queue part of the amnesia-resistant discovery surface
- Tooling / assurance:
  - add `tools/gen_external_source_review_queue.py` and `tools/check_external_source_review_queue.py`, and extend the shared external-source rendering helpers so the head register and review queue stay generated from one compact lock JSON instead of drifting apart by hand
  - register `EVID-2026-564` and tighten `tools/README.md` / `docs/00-meta/evidence-index.md` so future revisions cannot keep exact byte locks while silently dropping bounded review dates and the no-URL maintainer refresh queue

## Revised554 (2026-03-20)
- D-ATTN / D-TIMEPROOF request-state split hygiene:
  - add `docs/30-architecture/notification-request-state-posture-v0.md`, freezing the rule that CH-NOTIF `id` is a requester-chosen stable request/upsert/withdraw identity rather than portal-issued live notification presentation truth, so reviewed request identity stays distinct from current portal-owned shown/suppressed/withdrawn/dismissed state
  - add `docs/30-architecture/timeproof-request-state-posture-v0.md`, freezing the rule that CH-TIMEREQ `req_id` is a requester-chosen stable request/dedupe identity rather than portal-issued live timeproof-sample truth, so reviewed request identity stays distinct from current portal-owned pending/cached/superseded sample state
  - tighten `docs/30-architecture/notification-request-schema-v0.md`, `docs/30-architecture/timeproof-request-schema-v0.md`, `docs/30-architecture/attention-lease-posture-v0.md`, `docs/30-architecture/timeproof-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/portal-family-registry.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `rfcs/0055-attention-authority-and-notifications.md`, and `rfcs/0090-secure-time-sync-and-timeproofs.md` so retries, withdrawals, receipts, and automation use one exact request key without implying that a current notification presentation or timeproof sample still exists
- Assurance / hygiene:
  - add `I-ATTN-5`, `I-TIMEREQ-2`, `PO-ATTN-STATE`, `PO-TIMEPROOF-STATE`, and register `EVID-2026-562` / `EVID-2026-563`, making request-vs-live-state truth explicit across CH-NOTIF / CH-TIMEREQ / ACP / assurance surfaces instead of leaving it as reviewer inference
  - add `tools/check_notification_request_state_posture.py` and `tools/check_timeproof_request_state_posture.py`, and wire both postures through README/docs indexes, the posture index, the profile posture matrix, the LLM runbook, resolved history, and tools README so future revisions cannot silently turn stale request artifacts or historical receipts into fake current attention/timeproof truth

## Revised553 (2026-03-20)
- D-NETLEASE / D-NONDET request-state split hygiene:
  - add `docs/30-architecture/network-request-state-posture-v0.md`, freezing the rule that CH-NETREQ `req_id` is a requester-chosen stable request/dedupe key rather than portal-issued live network-lease truth, so reviewed request identity stays distinct from current portal-owned lease/revoke/expiry state
  - add `docs/30-architecture/entropy-request-state-posture-v0.md`, freezing the rule that CH-ENTREQ `req_id` is a requester-chosen stable request/dedupe key rather than portal-issued live entropy-handle truth, so reviewed request identity stays distinct from current portal-owned entropy-handle/revoke/expiry/exhaustion state
  - tighten `docs/30-architecture/network-request-schema-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/30-architecture/entropy-request-schema-v0.md`, `docs/30-architecture/nondet-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/portal-family-registry.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `rfcs/0056-outbound-network-leases-and-portals.md`, and `rfcs/0063-nondeterminism-capabilities-clock-and-entropy.md` so retry safety, receipts, and automation use one exact request key without implying that a current lease/handle still exists
- Assurance / hygiene:
  - add `I-NETREQ-2`, `I-ENTREQ-1`, `PO-NETLEASE-STATE`, `PO-ENTROPY-STATE`, and register `EVID-2026-560` / `EVID-2026-561`, making request-vs-live-state truth explicit across CH-NETREQ / CH-ENTREQ / ACP / assurance surfaces instead of leaving it as reviewer inference
  - add `tools/check_network_request_state_posture.py` and `tools/check_entropy_request_state_posture.py`, and wire both postures through README/docs indexes, the posture index, the profile posture matrix, the LLM runbook, resolved history, and tools README so future revisions cannot silently turn stale request artifacts or historical receipts into fake current network/entropy truth

## Revised552 (2026-03-20)
- D-BGLEASE request-state split hygiene:
  - add `docs/30-architecture/background-request-state-posture-v0.md`, freezing the rule that CH-BGREQ `req_id` is a requester-chosen stable request/dedupe key rather than portal-issued live background/autostart truth, so reviewed request identity stays distinct from current portal-owned granted/revoked/expired/disabled state
  - tighten `docs/30-architecture/background-request-schema-v0.md`, `docs/30-architecture/background-lease-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, and `rfcs/0103-background-execution-and-autostart-leases.md` so D-BGLEASE retry safety, receipts, and automation use one exact request key without implying that a current grant still exists
- Assurance / hygiene:
  - add `I-BGREQ-2`, `PO-BGLEASE-STATE`, and register `EVID-2026-559`, making request-vs-live-grant truth explicit across CH-BGREQ / ACP / assurance surfaces instead of leaving it as reviewer inference
  - add `tools/check_background_request_state_posture.py` and wire the new posture through README/docs indexes, the posture index, the profile posture matrix, the LLM runbook, resolved history, and tools README so future revisions cannot silently turn stale request artifacts or historical receipts into fake current background/autostart truth

## Revised551 (2026-03-20)
- D-JOBS request-state split hygiene:
  - add `docs/30-architecture/job-request-state-posture-v0.md`, freezing the rule that CH-JOBREQ `job_id` is a requester-chosen stable request/dedupe key rather than portal-issued live queue truth, so reviewed request identity stays distinct from current portal-owned pending/replaced/cancelled/expired state
  - tighten `docs/30-architecture/job-request-schema-v0.md`, `docs/30-architecture/job-portal-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, and `rfcs/0096-job-portal-and-constraint-based-background-work.md` so D-JOBS retry safety, receipts, and automation use one exact request key without implying that a current scheduled job still exists
- Assurance / hygiene:
  - add `I-JOB-3`, `PO-JOBS-STATE`, and register `EVID-2026-558`, making request-vs-live-state truth explicit across CH-JOBREQ / ACP / assurance surfaces instead of leaving it as reviewer inference
  - add `tools/check_job_request_state_posture.py` and wire the new posture through README/docs indexes, the posture index, the profile posture matrix, the LLM runbook, resolved history, and tools README so future revisions cannot silently turn stale request artifacts or historical receipts into fake current queue truth

## Revised550 (2026-03-20)
- ACP deny-precedence hygiene:
  - add `docs/30-architecture/acp-denial-precedence-posture-v0.md`, closing the small but expensive overlap between live authority gates and exact witness drift by pinning one deterministic CH-DENY ladder: `lane-disabled|cfg-deny` → `missing-approval|expired-approval` → `policy-deny` → `precondition-failed`
  - tighten `docs/70-llm-control/acp-validator-semantics.md`, `docs/70-llm-control/acp-action-schema-v0.md`, `docs/30-architecture/deny-code-registry.md`, `docs/30-architecture/denial-receipt-schema-v0.md`, and `docs/30-architecture/decision-map.md` so stale basis is only reported after the action still had live authority to proceed, instead of letting CH-DENY vary by incidental validator branch order
- Assurance / hygiene:
  - add `I-DENY-4`, `PO-DENY-PRECEDENCE`, and register `EVID-2026-557`, making deny-precedence part of the stable receipt semantics rather than a reviewer inference
  - add `tools/check_acp_deny_precedence.py` and wire the new posture through README/docs indexes, the LLM runbook, the posture matrix/index, and ACP docs so future revisions cannot silently let dead-authority denials decay into stale-basis folklore

## Revised549 (2026-03-20)
- Mutable-basis approval honesty:
  - add `docs/30-architecture/approval-basis-posture-v0.md`, pinning the rule that if approval or acceptance depends on mutable reviewed state, that basis must already be encoded in the exact action bytes rather than floating as a hidden “current head/current revision/current descriptor” meaning on CH-VOL / CH-AUTHZ / CH-RECEIPT
  - tighten `docs/70-llm-control/acp-action-schema-v0.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/30-architecture/authorization-token-schema-v0.md`, `docs/30-architecture/volition-token-schema-v0.md`, `docs/30-architecture/consent-receipt-schema-v0.md`, `docs/30-architecture/volition-posture-v0.md`, `docs/30-architecture/powerbox-posture-v0.md`, and `docs/30-architecture/decision-map.md` so stale mutable-basis drift fails closed and old approvals cannot silently follow newer local state
- Assurance / hygiene:
  - add `I-AUTHZ-2`, `PO-ACT-BASIS`, and register `EVID-2026-556`, making mutable-basis approval completeness explicit across ACP / consent / volition / receipt surfaces instead of leaving it as a reviewer inference
  - add `tools/check_approval_basis_posture.py` and extend `trusted-ui-adjunct-index.md` so the approval-basis seam stays machine-checked, discoverable, and grouped with the current trusted-UI / human-mediation family instead of drifting into piecemeal folklore

## Revised548 (2026-03-20)
- ACP conditional-basis hygiene:
  - add `docs/30-architecture/acp-precondition-witness-posture-v0.md`, closing the small CH-ACP `preconditions` seam by freezing preconditions as **veto-only exact witness gates** over explicit local inputs rather than ambient `latest`/query/history folklore, remote fetch, or a hidden second policy engine
  - tighten `docs/70-llm-control/acp-action-schema-v0.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/30-architecture/llm-operations-posture-v0.md`, `docs/30-architecture/decision-map.md`, and `docs/30-architecture/deny-code-registry.md` so conditional automation can honestly say what exact reviewed/observed basis it depends on, fails closed when the witness is missing or stale, and keeps denial/outcome semantics receipt-shaped
- Assurance / hygiene:
  - add `I-ACP-PRECOND-1`, `PO-ACT-PRECOND`, denial guidance for `precondition-failed`, and register `EVID-2026-555` so the exact-vs-ambient rule is pinned across ACP/LLM/deny surfaces instead of surviving as one prose note
  - add `tools/check_acp_precondition_wiring.py` and wire the new posture through README/docs indexes, the profile posture matrix/index, and the LLM runbook so future revisions cannot silently turn CH-ACP `preconditions` into an ambient review/history/query plane

## Revised547 (2026-03-20)
- External-source citation hygiene:
  - add `docs/00-meta/external-source-head-register.md` plus `tools/gen_external_source_head_register.py`, so the small external-source lock surface now distinguishes **operational/discovery heads** from **citation-ready exact reviewed heads** instead of leaving reviewers to infer that split from raw lock rows by hand
  - tighten `docs/60-engineering/external-source-lock-contract.md` and `tools/check_external_source_locks.py` so the lock surface explicitly names the operational-head vs citation-head split, keeps the generated head map in sync with the JSON register, and stays small/no-vendor even while mutable upstream references become easier to review correctly
- Attention / outcome-visibility boundary:
  - add `docs/30-architecture/attention-durable-status-boundary-v0.md`, freezing the rule that transient notifications/toasts/status cues cannot become the sole durable carrier of consequential outcome, approval, or next-step truth; durable meaning must remain reconstructible from explicit receipt/state surfaces instead
  - wire the new D-ATTN boundary through `docs/30-architecture/decision-map.md`, `docs/30-architecture/attention-lease-posture-v0.md`, `docs/30-architecture/notification-request-schema-v0.md`, `docs/30-architecture/explain-posture-v0.md`, `rfcs/0055-attention-authority-and-notifications.md`, the boundary-family map, and the LLM runbook so transient attention chrome cannot quietly turn into hidden durable truth by prose drift
- Tooling / hygiene:
  - add `tools/check_attention_durable_status_boundary.py` and register `EVID-2026-554` so the new boundary stays machine-checked and discoverable

## Revised546 (2026-03-20)
- External-source lock hygiene for active confidential-computing references:
  - add `docs/60-engineering/external-source-lock-contract.md` plus `docs/00-meta/external-source-locks.json`, creating one compact lock surface for a *small selected* subset of load-bearing mutable upstream references so AMD SEV-SNP / GHCB / VLEK and core RATS/EAT artifacts can be cited as exact reviewed bytes instead of silently inheriting moving-head or landing-page semantics by folklore
  - keep the boundary explicit: bibliography pointers remain the broad discovery surface, the new lock register stays intentionally narrow, and the archive still refuses to vendor large external PDFs/RFCs into handoff bundles just to preserve byte identity
  - make mutable publication risk legible by requiring each locked row to spell out `bibliography_url`, exact `lock_url`, `sha256`, and a concrete `head_warning` whenever the upstream surface is a moving artifact path or convenience landing page
- Tooling / hygiene:
  - add `tools/check_external_source_locks.py` and register `EVID-2026-553` so the lock register must stay JSON-valid, digest-shaped, bibliography-linked, discoverable from docs/tools indexes, and honest about mutable-head risk rather than decaying into a stale side file

## Revised545 (2026-03-19)
- Confidential-computing archive hygiene:
  - refactor `docs/30-architecture/confidential-computing-boundary-index.md` so the current provider-native SNP field inventory is **authorship-bucketed** (host/hypervisor-authored, owner-authored, firmware/hardware-generated, and mixed signer/endorsement linkage) instead of living as one flat list
  - tighten `rfcs/0064-confidential-computing-profile.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/attestation-posture-v0.md`, and `docs/30-architecture/attestation-pack-schema-v0.md` so D-CC verifier-facing discovery points at that authorship taxonomy instead of re-enumerating a long folklore-prone field list in multiple places
  - keep the hard Phase 1 decision explicit: provider-native SNP field meaning is still closed and exact-evidence-only, but the archive now treats **field authorship** as the first discovery lens for verifier work
- Tooling / hygiene:
  - add `tools/check_confidential_computing_boundary_authorship.py` and register `EVID-2026-552` so the authorship taxonomy stays machine-checked and future D-CC edits cannot silently blur host/owner/firmware/mixed-linkage trust semantics back together
  - update `tools/check_confidential_computing_boundary_index.py` so the D-CC family index must retain the new authorship buckets and rationale

## Revised544 (2026-03-19)
- SNP GOSVW claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-gosvw-claim-boundary-v0.md`, making the hard Phase 1 decision that hypervisor-provided SNP `GOSVW` / `guest-visible-workarounds` stays **exact provider-native evidence only** rather than becoming a portable SlopOS feature vector, machine-class taxonomy, compatibility tier, or hidden approval plane
  - wire the boundary through README/docs indexes, the LLM runbook, the D-CC boundary index, the boundary-family map, the profile posture matrix, decision map, deployment profiles, attestation docs, RFC-0064, and bibliography so the first verifier / secret-release / rollout path cannot quietly inherit one hypervisor-defined workaround blob as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_gosvw_claim_boundary.py` and register `EVID-2026-551` so future D-CC edits cannot silently widen SNP `GOSVW` into a normalized `CH-ATTEST` capability, compatibility, or approval plane

## Revised543 (2026-03-19)
- SNP version-metadata claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-version-metadata-claim-boundary-v0.md`, making the hard Phase 1 decision that report `VERSION` / `CURRENT_*` / `COMMITTED_*` stay **exact provider-native evidence only** rather than becoming a portable SlopOS platform-maturity, capability, parser-negotiation, or hidden approval plane
  - wire the boundary through README/docs indexes, the LLM runbook, the D-CC boundary index, the boundary-family map, the profile posture matrix, decision map, deployment profiles, attestation docs, and RFC-0064 so the first verifier / secret-release / rollout path cannot quietly inherit provider firmware-version folklore as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_version_metadata_claim_boundary.py` and register `EVID-2026-550` so future D-CC edits cannot silently widen SNP report/firmware version metadata into a normalized `CH-ATTEST` platform-maturity, capability, or approval plane

## Revised542 (2026-03-19)
- Embedded-EAT claim boundary:
  - add `docs/30-architecture/confidential-computing-eat-payload-claim-boundary-v0.md`, making the hard Phase 1 decision that optional embedded `eat_payload` EAT claims stay **profile-local evidence only** rather than widening `CH-ATTEST` / `CH-ATTESTPACK` into a portable SlopOS claim registry, approval language, or a hidden shortcut around explicit boot/provenance/report-data/freshness checks
  - wire the boundary through README/docs indexes, the LLM runbook, the D-CC boundary index, the boundary-family map, the profile posture matrix, decision map, deployment profiles, attestation docs, and RFC-0064 so the first cloud/agent verifier path cannot silently promote convenient token vocabulary into OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_eat_payload_claim_boundary.py` and register `EVID-2026-549` so future D-CC edits cannot silently widen embedded `eat_payload` claims into a normalized `CH-ATTEST` claim registry or hidden approval plane
  - update `tools/check_confidential_computing_boundary_index.py` so the closed D-CC companion family explicitly includes imported-profile-claim seams alongside implementation/binding/trust/report-field pins

## Revised541 (2026-03-19)
- Confidential-computing archive hygiene:
  - add `docs/30-architecture/confidential-computing-boundary-index.md`, a closed companion discovery surface for the current D-CC boundary set so SNP-first implementation/binding/trust/report-field meaning pins stay enumerable and stop living as accidental singletons
  - wire the index through README/docs indexes, the LLM runbook, posture index, decision map, attestation docs, RFC-0064, and the boundary-family map so D-CC discovery stays compact and machine-checkable
  - promote the current confidential-computing companion docs out of the boundary-family singleton list into one explicit family index, reducing lookup tax and future drift pressure without adding a new schema or workflow family
- Tooling / hygiene:
  - add `tools/check_confidential_computing_boundary_index.py` and register `EVID-2026-548` so the closed D-CC companion boundary set must stay explicitly enumerated, discoverable, and wired from stable archive surfaces

## Revised540 (2026-03-19)
- SNP report-signing metadata claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-signing-metadata-claim-boundary-v0.md`, making the hard Phase 1 decision that SNP report `SIGNATURE_ALGO` / `SIGNING_KEY` / `MASK_CHIP_KEY` stay **exact provider-native evidence only** rather than becoming a portable SlopOS provider-class, trust-profile, or hidden approval claim
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, the profile posture matrix, and the LLM must-read set so the first SNP verifier / secret-release / rollout path cannot quietly inherit signer-mode folklore as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_signing_metadata_claim_boundary.py` and register `EVID-2026-547` so future D-CC edits cannot silently widen SNP report signing metadata into a normalized `CH-ATTEST` provider/trust or approval plane

## Revised539 (2026-03-19)
- SNP measurement claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-measurement-claim-boundary-v0.md`, making the hard Phase 1 decision that report `MEASUREMENT` stays **exact provider-native launch evidence only** rather than becoming a portable SlopOS boot identity, rollout selector, or hidden approval shortcut
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, the profile posture matrix, and the LLM must-read set so the first SNP verifier / secret-release / rollout path cannot quietly inherit one provider-native launch digest as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_measurement_claim_boundary.py`, register `REF-LINUX-AMD-MEMENC`, and register `EVID-2026-546` so future D-CC edits cannot silently widen SNP `MEASUREMENT` into a normalized `CH-ATTEST` boot-identity, rollout-selector, or approval plane

## Revised538 (2026-03-19)
- SNP GUEST_SVN claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-guest-svn-claim-boundary-v0.md`, making the hard Phase 1 decision that owner-authored SNP `GUEST_SVN` stays **exact provider-native evidence only** rather than becoming a portable SlopOS release order, rollback floor, secret-release namespace, or hidden approval shortcut
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, the profile posture matrix, and the LLM must-read set so the first SNP verifier / secret-release / rollout path cannot quietly inherit one provider-native guest-version taxonomy as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_guest_svn_claim_boundary.py` and register `EVID-2026-545` so future D-CC edits cannot silently widen SNP `GUEST_SVN` into a normalized `CH-ATTEST` release-order, anti-rollback, secret-release, or approval plane

## Revised537 (2026-03-19)
- SNP PLATFORM_INFO claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-platform-info-claim-boundary-v0.md`, making the hard Phase 1 decision that SNP `PLATFORM_INFO` stays **exact provider-native evidence only** rather than becoming a portable SlopOS security profile, machine class, capability vector, or hidden approval language
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, the profile posture matrix, and the LLM must-read set so the first SNP verifier / secret-release / rollout path cannot quietly inherit one provider-native platform-feature taxonomy as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_platform_info_claim_boundary.py` and register `EVID-2026-544` so future D-CC edits cannot silently widen SNP `PLATFORM_INFO` into a normalized `CH-ATTEST` security-profile, machine-class, capability-vector, or approval plane

## Revised536 (2026-03-19)
- SNP CHIP_ID claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-chip-id-claim-boundary-v0.md`, making the hard Phase 1 decision that SNP `CHIP_ID` stays **exact provider-native evidence only** rather than becoming a portable SlopOS machine identity, asset selector, anti-cloning shortcut, or hidden secret-release namespace
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, the profile posture matrix, and the LLM must-read set so the first SNP verifier / secret-release / rollout path cannot quietly inherit one provider-native chip-identity taxonomy as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_chip_id_claim_boundary.py` and register `EVID-2026-543` so future D-CC edits cannot silently widen SNP `CHIP_ID` into a normalized `CH-ATTEST` machine/asset identity or anti-cloning plane

## Revised535 (2026-03-19)
- SNP report-identity claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-report-identity-claim-boundary-v0.md`, making the hard Phase 1 decision that firmware-generated SNP `REPORT_ID` / `REPORT_ID_MA` stay **exact provider-native evidence only** rather than becoming a portable SlopOS instance identity, migration truth, replay/freshness shortcut, or hidden secret-release/session selector
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, the profile posture matrix, and the LLM must-read set so the first SNP verifier / secret-release / rollout path cannot quietly inherit a provider-native report-id taxonomy as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_report_identity_claim_boundary.py` and register `EVID-2026-542` so future D-CC edits cannot silently widen SNP `REPORT_ID` / `REPORT_ID_MA` into a normalized `CH-ATTEST` instance/migration identity or replay/freshness plane

## Revised534 (2026-03-19)
- SNP guest-policy claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-policy-claim-boundary-v0.md`, making the hard Phase 1 decision that SNP `POLICY` stays **exact provider-native evidence only** rather than becoming a portable SlopOS security-profile claim, capability vector, or hidden approval language
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, the profile posture matrix, and the LLM must-read set so the first SNP verifier / secret-release / rollout path cannot quietly inherit one AMD launch-policy bitfield as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_policy_claim_boundary.py` and register `EVID-2026-541` so future D-CC edits cannot silently widen SNP `POLICY` into a normalized `CH-ATTEST` security-profile or approval plane

## Revised533 (2026-03-19)
- SNP TCB-field claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-tcb-field-claim-boundary-v0.md`, making the hard Phase 1 decision that SNP `CURRENT_TCB`, `COMMITTED_TCB`, `REPORTED_TCB`, and `LAUNCH_TCB` stay **exact provider-native evidence with distinct meanings** instead of collapsing into one portable baseline or patch-level claim, and that `REPORTED_TCB` in particular remains signer/certificate-linkage evidence rather than a hidden “current platform patch level” shortcut
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, the profile posture matrix, and the LLM must-read set so the first SNP verifier / secret-release / rollout path cannot quietly inherit a provider-specific TCB folklore rule as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_tcb_field_claim_boundary.py` and register `EVID-2026-540` so future D-CC edits cannot silently widen SNP TCB report fields into a normalized `CH-ATTEST` baseline/patch-level plane

## Revised532 (2026-03-19)
- SNP launch-identity claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-launch-identity-claim-boundary-v0.md`, making the hard Phase 1 decision that owner-authored SNP launch labels (`FAMILY_ID` / `IMAGE_ID`) and owner-signer digests (`ID_KEY_DIGEST` / `AUTHOR_KEY_DIGEST`) stay **exact provider-native evidence only** rather than becoming portable SlopOS image/release identity claims, hidden allow/deny channels, or substitutes for `boot_digest` / `prov_digest` / exact `cc_report_data_v0` binding
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, and the LLM must-read set so the first SNP verifier / secret-release / rollout path cannot quietly inherit a cloud- or owner-local image taxonomy as portable OS truth
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_launch_identity_claim_boundary.py` and register `EVID-2026-539` so future D-CC edits cannot silently widen owner-authored SNP launch labels or signer digests into a normalized `CH-ATTEST` claim space

## Revised531 (2026-03-19)
- SNP-first VMPL-mode boundary:
  - add `docs/30-architecture/confidential-computing-snp-vmpl-mode-boundary-v0.md`, making the hard Phase 1 decision that the portable SNP-first D-CC target is a **fully enlightened VMPL0 guest only**, while Multi-VMPL / SVSM / paravisor layouts and non-zero-VMPL conformance stay future annex work instead of silently widening the first implementation target
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, the profile posture matrix, the LLM must-read set, and the bibliography so “SNP-first” stops hiding a second guest architecture behind one label
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_vmpl_mode_boundary.py`, register `EVID-2026-538`, and add `REF-AMD-SVSM` plus `REF-LINUX-HYPERV-COCO` so future D-CC edits cannot silently broaden the Phase 1 target from one direct VMPL0 guest path into SVSM/paravisor semantics by folklore

## Revised530 (2026-03-19)
- SNP `HOST_DATA` claim boundary:
  - add `docs/30-architecture/confidential-computing-snp-hostdata-claim-boundary-v0.md`, making the hard Phase 1 decision that host-supplied SNP `HOST_DATA` stays **exact provider-native evidence only** rather than becoming a portable SlopOS attestation claim, substitute binder field, or hidden policy/automation channel
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, and the LLM must-read set so the SNP-first verifier/secret-release path cannot quietly inherit provider-authored claim meaning from one opaque launch field
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_hostdata_claim_boundary.py` and register `EVID-2026-537` so future D-CC edits cannot silently widen `HOST_DATA` into normalized claim space or a hidden approval shortcut

## Revised529 (2026-03-19)
- SNP-first certificate-source trust boundary:
  - add `docs/30-architecture/confidential-computing-snp-certificate-source-boundary-v0.md`, making the hard Phase 1 decision that GHCB/host-memory SNP certificate tables are **transport only** while verifier trust roots, accepted signer class, and any KDS/CRL freshness handling remain explicit local policy/tooling instead of drifting into host-provided authority
  - wire the boundary through attestation posture/packaging, deployment profiles, RFC-0064, README/docs indexes, the posture and boundary maps, and the LLM must-read set so SNP-first verification cannot quietly inherit “whatever certs the host handed us” semantics
- Tooling / hygiene:
  - add `tools/check_confidential_computing_snp_certificate_source_boundary.py`, register `EVID-2026-536`, and add `REF-AMD-GHCB` plus `REF-AMD-VLEK-CERT` so the first SNP verifier path stays cited, discoverable, and machine-checked instead of regrowing an ambient trust-source bug

## Revised528 (2026-03-19)
- Confidential-computing binder contract:
  - add `docs/30-architecture/confidential-computing-reportdata-binding-boundary-v0.md`, making the hard Phase 1 decision that D-CC binder/verifier work uses one exact `ccbind_input_v0` → `cc_report_data_v0` contract for 64-byte provider report-data fields instead of drifting between `H(boot_digest || nonce)`, `H(boot_digest || policy_rev || nonce)`, or vague “canonical equivalent” wording
  - wire the boundary through `decision-map.md`, `attestation-posture-v0.md`, deployment profiles, abuse cases, RFC-0064, README/docs indexes, the boundary-family map, and the LLM must-read set so SNP-first implementation work has one exact byte contract before code starts
- Tooling / hygiene:
  - add `tools/check_confidential_computing_reportdata_binding_boundary.py` and register `EVID-2026-535` so future D-CC edits cannot silently fork the binder/verifier preimage or 64-byte report-data carrier contract

## Revised527 (2026-03-19)
- Confidential-computing implementation sequencing:
  - add `docs/30-architecture/confidential-computing-reference-target-boundary-v0.md`, making the hard Phase 1 decision that **AMD SEV-SNP** is the first end-to-end **D-CC** binder/verifier implementation target so coding can start against one concrete report-data path while **TDX/CCA** remain future annexes instead of co-equal blockers
  - wire the boundary through `decision-map.md`, deployment profiles, RFC-0064, README/docs indexes, the boundary-family map, and the LLM must-read set so D-CC stops being a purely abstract optional profile when implementation planning reaches the cloud/agent shapes
- Tooling / hygiene:
  - add `tools/check_confidential_computing_reference_target_boundary.py`, register `EVID-2026-534`, and add `REF-SNPGUEST` so the SNP-first coding target stays discoverable, cited, and machine-checked instead of drifting back into provider-plurality procrastination

## Revised526 (2026-03-19)
- Secret-authority / auth-agent boundary:
  - add `docs/30-architecture/authagent-provider-role-boundary-v0.md`, making the hard Phase 1 decision that **D-AUTHAGENT** is a provider/deployment role behind **IF-CRYPTOSVC / D-CRYPTOSVC** rather than a second portable caller-visible agent API; ambient agent discovery, PKCS#11-style portable object models, and separate forwarding/admin planes stay out of scope
  - wire the boundary through `decision-map.md`, `interface-registry.md`, `mechanisms.md`, `secret-authority-adjunct-index.md`, RFC-0067 history, README/docs indexes, the boundary-family map, and the LLM must-read set so secret-bearing authority keeps one small portable seam
- Tooling / hygiene:
  - add `tools/check_authagent_provider_role_boundary.py`, register `EVID-2026-533`, and add `REF-PKCS11-SPEC` so the new boundary stays discoverable, cited, and machine-checked instead of drifting back into duplicate “auth agent vs crypto service” folklore

## Revised525 (2026-03-19)
- Secret-authority family / archive hygiene:
  - add `docs/30-architecture/secret-authority-adjunct-index.md`, a closed discovery surface for the current D-APPSECRET / D-VAULT / D-CRYPTOSVC posture family so minimal app-seed, ref-bound vault, and explicit-route crypto authority semantics stay recoverable together instead of being rediscovered piecemeal from three separate posture docs
- Tooling / hygiene:
  - add `tools/check_secret_authority_adjunct_index.py`, wire the index through README/docs indexes, the LLM runbook, the posture index, the decision map, the adjunct-family map, and register `EVID-2026-532` so future secret-bearing authority posture changes cannot drift into piecemeal recovery


## Revised524 (2026-03-19)
- CapRPC family / archive hygiene:
  - add `docs/30-architecture/caprpc-adjunct-index.md`, a closed discovery surface for the current live D-CAPRPC posture family so session continuity plus promise/oneway adjuncts stay recoverable together instead of being rediscovered piecemeal from three separate posture docs
- Tooling / hygiene:
  - add `tools/check_caprpc_adjunct_index.py`, wire the index through README/docs indexes, the LLM runbook, the adjunct-family map, the posture index, the decision map, and register `EVID-2026-531` so future live CapRPC posture changes cannot drift into piecemeal recovery


## Revised523 (2026-03-19)
- Adjunct-family archive hygiene:
  - add `docs/30-architecture/adjunct-family-map.md`, a compact coverage map that lists every current companion adjunct family surface so new `*-adjunct-index.md` discovery surfaces cannot stay individually wired while drifting outside one stable human-readable map
- Tooling / hygiene:
  - add `tools/check_adjunct_family_map.py`, wire the map through README/docs indexes, the LLM runbook, the posture index, and register `EVID-2026-530` so adjunct-family coverage stays machine-checked instead of relying on memory


## Revised522 (2026-03-19)
- Adjunct-family handoff / archive hygiene:
  - teach `tools/gen_context_pack.py` to emit a dedicated `## Closed companion adjunct indexes` section so the current implementation-facing family discovery surfaces stay compactly visible in the continuation prompt instead of hiding only inside the long must-read list
- Tooling / hygiene:
  - add `tools/check_adjunct_index_handoff.py`, wire the guardrail through README/docs indexes, the LLM runbook, the context-pack contract, and tooling, and register `EVID-2026-529` so every current `*-adjunct-index.md` doc under `docs/30-architecture/` must stay present in both the runbook must-read set and generated handoff context pack


## Revised521 (2026-03-19)
- Adjunct-family archive hygiene:
  - add `docs/30-architecture/adjunct-index-contract-v0.md`, a compact shared contract for companion adjunct family indexes so every current `*-adjunct-index.md` surface keeps explicit purpose/inclusion/review/wiring/evidence rules, a closed-set section, direct member enumeration, and same-revision maintenance instead of surviving as a thin placeholder
- Tooling / hygiene:
  - add `tools/check_adjunct_index_contract.py`, wire the contract through README/docs indexes, the LLM runbook, the posture index, and register `EVID-2026-528` so implementation-facing family indexes cannot drift into ceremonial placeholders


## Revised520 (2026-03-19)
- Runtime-coordination family / archive hygiene:
  - add `docs/30-architecture/runtime-coordination-adjunct-index.md`, a closed discovery surface for the current D-WAITSET / D-UWAIT / D-ROBUSTLOCK / D-IOQ posture family so the low-level wait/completion/blocking substrate stays recoverable together instead of being rediscovered piecemeal from several low-level posture docs
- Tooling / hygiene:
  - add `tools/check_runtime_coordination_adjunct_index.py`, wire the index through README/docs indexes, the LLM runbook, the posture index, the decision map, and register `EVID-2026-527` so future runtime-coordination posture adjuncts cannot drift into piecemeal recovery


## Revised519 (2026-03-19)
- Trusted-UI family / archive hygiene:
  - add `docs/30-architecture/trusted-ui-adjunct-index.md`, a closed discovery surface for the current D-UICAP / D-VOLITION / D-POWERBOX / D-UIAUT posture family so trusted local UI, fresh gesture evidence, chooser-owned consent mediation, and manual-only accessibility/automation stay recoverable together instead of being rediscovered piecemeal from four separate docs
- Tooling / hygiene:
  - add `tools/check_trusted_ui_adjunct_index.py`, wire the index through README/docs indexes, the LLM runbook, the posture index, the decision map, and register `EVID-2026-526` so future trusted-UI posture adjuncts cannot drift into piecemeal recovery


## Revised518 (2026-03-19)
- Request-context family / archive hygiene:
  - add `docs/30-architecture/reqctx-adjunct-index.md`, a closed discovery surface for the current D-REQCTX core plus consumer-typed sponsorship-reference posture family so sticky propagation and explicit sponsorship interpretation stay recoverable together instead of being rediscovered piecemeal from schema notes and the decision map
- Tooling / hygiene:
  - add `tools/check_reqctx_adjunct_index.py`, wire the index through README/docs indexes, the LLM runbook, the posture index, the decision map, and register `EVID-2026-525` so future request-context posture adjuncts cannot drift into piecemeal recovery


## Revised517 (2026-03-19)
- Portal workflow family / archive hygiene:
  - add `docs/30-architecture/portal-adjunct-index.md`, a closed discovery surface for the current D-PLUMB portal core plus direct `*-portal-posture-v0.md` workflow family so portal workflows stop being rediscovered piecemeal from the taxonomy registry and scattered posture rows while lease-backed portal families remain explicitly separate
- Tooling / hygiene:
  - add `tools/check_portal_adjunct_index.py`, wire the index through README/docs indexes, the LLM runbook, the posture index, the decision map, and register `EVID-2026-524` so new direct portal workflow postures cannot drift into piecemeal recovery


## Revised516 (2026-03-19)
- Leased-authority family / archive hygiene:
  - add `docs/30-architecture/lease-adjunct-index.md`, a closed discovery surface for the current `*-lease-posture-v0.md` family so the generic D-LEASE anchor plus network/location/device/background/inhibit/attention leased-authority pins stay recoverable as one implementation-facing surface instead of being rediscovered piecemeal from portal rows and scattered posture docs
- Tooling / hygiene:
  - add `tools/check_lease_adjunct_index.py`, wire the index through README/docs indexes, the LLM runbook, the posture index, the decision map, and register `EVID-2026-523` so future lease posture docs cannot drift into piecemeal recovery


## Revised515 (2026-03-19)
- Capshell family / archive hygiene:
  - add `docs/30-architecture/capshell-adjunct-index.md`, a closed discovery surface for the current `capshell-*-posture-v0.md` family so the full shell/automation posture stays recoverable as one implementation-facing surface while the narrower launch-boundary subset remains separately closed
- Tooling / hygiene:
  - add `tools/check_capshell_adjunct_index.py`, wire the index through README/docs indexes, the LLM runbook, the posture index, the decision map, and register `EVID-2026-522` so future capshell posture adjuncts cannot drift into piecemeal recovery


## Revised514 (2026-03-19)
- MicroVM archive hygiene / product-shape-B discovery:
  - add `docs/30-architecture/microvm-adjunct-index.md`, a closed discovery surface for the current `ext.microvm` adjunct posture family so the many guest-visible topology/backing, channel/peripheral/control-surface, and warm-state/attestation-continuity meaning pins stay recoverable as one profile-B-facing cluster instead of only through one very long umbrella posture
- Tooling / hygiene:
  - add `tools/check_microvm_adjunct_index.py`, wire the index through README/docs indexes, the LLM runbook, the posture index, the decision map, the umbrella microVM posture, and register `EVID-2026-521` so the `ext.microvm` adjunct family stays closed and machine-checkable


## Revised513 (2026-03-19)
- Constructor family / archive hygiene:
  - add `docs/30-architecture/worker-pool-constructor-index.md`, a closed discovery surface for the current first concrete D-CONSTR family so the sandboxed worker-pool contract, invocation/state members, and verification/harness members stay enumerable as one implementation target instead of being recovered piecemeal from a long spec
- Tooling / hygiene:
  - add `tools/check_worker_pool_constructor_index.py`, wire the index through README/docs indexes, the LLM runbook, the posture index, the constructor family spec, the decision map, and register `EVID-2026-520` so the first worth-coding constructor family stays closed and discoverable


## Revised512 (2026-03-19)
- Archive hygiene / singleton boundary quality:
  - add `docs/30-architecture/boundary-singleton-contract-v0.md`, a compact shared contract for intentional singleton boundary docs so every current singleton meaning pin stays explicit about why no broader family exists yet and when it must be promoted into one companion family index
  - add `## Singleton status (Phase 1)` sections to every current intentional singleton boundary doc so singleton status is stated inside the doc itself rather than living only in the coverage map
- Tooling / hygiene:
  - add `tools/check_boundary_singleton_contract.py`, wire the contract through README/docs indexes, the LLM runbook, the posture index, the boundary-family map, and register `EVID-2026-519` so singleton status cannot linger as a stale label after adjacent seams appear


## Revised511 (2026-03-19)
- Archive hygiene / boundary-index quality:
  - add `docs/30-architecture/boundary-index-contract-v0.md`, a compact shared contract for companion family indexes so every current `*-boundary-index.md` surface keeps explicit purpose/inclusion/review rules, a closed-set section, direct member enumeration, and same-revision maintenance instead of surviving as a thin placeholder
- Tooling / hygiene:
  - add `tools/check_boundary_index_contract.py`, wire the contract through README/docs indexes, the LLM runbook, the posture index, the boundary-family map, and register `EVID-2026-518` so companion family indexes stay structurally honest rather than merely existing


## Revised510 (2026-03-19)
- Archive hygiene / boundary coverage:
  - add `docs/30-architecture/boundary-family-map.md`, a compact coverage map that classifies every current `*-boundary-v0.md` doc as either part of an existing closed family index or an intentional singleton so future meaning pins cannot hide outside both routes
- Tooling / hygiene:
  - add `tools/check_boundary_family_map.py`, wire the map through README/docs indexes, the LLM runbook, the posture index, and register `EVID-2026-517` so boundary-family coverage stays machine-checked instead of relying on memory


## Revised509 (2026-03-19)
- Hybrid replication / archive hygiene:
  - add `docs/30-architecture/replication-boundary-index.md`, a closed companion discovery surface for the current `*-replication-boundary-v0.md` object-family set so the D-REPL / Hybrid RC meaning pins stay enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_replication_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, Hybrid/replication contract surfaces, and register `EVID-2026-516` so future replication-boundary docs cannot land as orphan prose or drift by omission


## Revised508 (2026-03-19)
- Hybrid topology / archive hygiene:
  - add `docs/30-architecture/hybrid-topology-boundary-index.md`, a closed companion discovery surface for the current coarse-clustering / hint-only Hybrid topology boundary set so the D-MK / D-CLUSTERMAP / D-SKB OQ-0001 closure stays enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_hybrid_topology_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, the Hybrid Phase 1 closure surface, and register `EVID-2026-515` so future topology-authority meaning pins cannot land as orphan prose or drift by omission


## Revised507 (2026-03-19)
- Import→docref / archive hygiene:
  - add `docs/30-architecture/import-to-docref-boundary-index.md`, a closed companion discovery surface for the current `import-to-docref-*-boundary-v0.md` bridge set so D-CAPX / D-PLUMB / D-QUAR bearer→document semantics stay enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_import_to_docref_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, capx/sturdyref/document-portal surfaces, and register `EVID-2026-514` so future bridge-boundary docs cannot land as orphan prose or drift by omission


## Revised506 (2026-03-19)
- Safe-open / archive hygiene:
  - add `docs/30-architecture/open-untrusted-boundary-index.md`, a closed companion discovery surface for the current `open-untrusted-*-boundary-v0.md` set so D-PLUMB / D-QUAR / D-EPHEM safe-open semantics stay enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_open_untrusted_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, `open_untrusted` / quarantine / RFC-0053 surfaces, and register `EVID-2026-513` so future safe-open boundary docs cannot land as orphan prose or drift by omission

## Revised505 (2026-03-19)
- Archive handoff / anti-amnesia hygiene:
  - teach `tools/gen_context_pack.py` to emit a dedicated `## Closed companion boundary indexes` section so the current family-level anti-drift surfaces stay compactly visible in the continuation prompt instead of hiding only inside the long must-read list
- Tooling / hygiene:
  - add `tools/check_boundary_index_handoff.py`, wire the guardrail through README/docs indexes, the LLM runbook, context-pack contract, and tooling, and register `EVID-2026-512` so every current the current `*-boundary-index.md` docs under `docs/30-architecture/` doc must stay present in both the runbook must-read set and generated handoff context pack

## Revised504 (2026-03-19)
- Provenance / archive hygiene:
  - add `docs/30-architecture/provenance-boundary-index.md`, a closed companion discovery surface for the current provenance / update-adjacent boundary set so the D-PCP / D-ATOMICUPD adjunct cluster stays enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_provenance_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, provenance/update/PCP + RFC surfaces, and register `EVID-2026-511` so future provenance boundary docs cannot land as orphan prose or drift by omission

## Revised503 (2026-03-19)
- Signature / verification / archive hygiene:
  - add `docs/30-architecture/signature-boundary-index.md`, a closed companion discovery surface for the current signature / certificate / keyless / transparency boundary set so the D-SIGENV / D-KEYLESS / D-TLOG adjunct cluster stays enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_signature_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, signature/transparency posture + RFC surfaces, and register `EVID-2026-510` so future signature/verification boundary docs cannot land as orphan prose or drift by omission

## Revised502 (2026-03-19)
- Quarantine / archive hygiene:
  - add `docs/30-architecture/quarantined-boundary-index.md`, a closed companion discovery surface for the current `quarantined-*-boundary-v0.md` set so the D-QUAR laundering-prevention boundary cluster stays enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_quarantined_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, D-QUAR posture/RFC surfaces, and register `EVID-2026-509` so future quarantined boundary docs cannot land as orphan prose or drift by omission

## Revised501 (2026-03-19)
- NAMECERT / archive hygiene:
  - add `docs/30-architecture/namecert-boundary-index.md`, a closed companion discovery surface for the current `namecert-*-boundary-v0.md` set so the D-NAMECERT boundary cluster stays enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_namecert_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, D-NAMECERT posture/RFC surfaces, and register `EVID-2026-508` so future NAMECERT boundary docs cannot land as orphan prose or drift by omission

## Revised500 (2026-03-19)
- SBOM / archive hygiene:
  - add `docs/30-architecture/sbom-boundary-index.md`, a closed companion discovery surface for the current `sbom-*-boundary-v0.md` set so the growing D-SBOM import-boundary cluster stays enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_sbom_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, SBOM posture/RFC surfaces, and register `EVID-2026-507` so future SBOM boundary docs cannot land as orphan prose or drift by omission

## Revised499 (2026-03-19)
- VEX / archive hygiene:
  - add `docs/30-architecture/vex-boundary-index.md`, a closed companion discovery surface for the current `vex-*-boundary-v0.md` set so the growing D-VEX import-boundary cluster stays enumerable, reviewable, and harder for humans/LLMs to lose piecemeal
- Tooling / hygiene:
  - add `tools/check_vex_boundary_index.py`, wire the index through README/docs indexes, the LLM runbook, the decision map, VEX posture/RFC surfaces, and register `EVID-2026-506` so future VEX boundary docs cannot land as orphan prose or drift by omission

## Revised498 (2026-03-19)
- VEX / advisory import boundaries:
  - add `docs/30-architecture/vex-justification-boundary-v0.md`, fixing Phase 1 so **imported OpenVEX `justification` / `impact_statement` / `status_notes`, CSAF impact/flag/threat detail, and CycloneDX vulnerability-analysis rationale stay explanatory evidence rather than native mitigation or waiver authority**; exact subject binding stays on CH-VEX / CH-SBOM / CH-AREF digests plus explicit local evidence, and any install/defer/exception policy remains verifier-local
- Tooling / hygiene:
  - add `tools/check_vex_justification_boundary.py`, wire the boundary through discovery/history surfaces, bibliography, posture indexes, supply-chain notes, and RFC-0092, and register `EVID-2026-505` so explanation-shaped advisory semantics cannot quietly regrow as archive meaning

## Revised497 (2026-03-19)
- VEX / advisory import boundaries:
  - add `docs/30-architecture/vex-distribution-marking-boundary-v0.md`, fixing Phase 1 so **imported CSAF `/document/distribution/*`, TLP labels, and related sharing-group metadata stay handling evidence rather than native export/share/redaction authority**; exact artifact binding stays on CH-VEX / CH-AREF digests plus explicit CH-OBSPOL / local policy, and any TLP-to-action translation remains verifier-local
- Tooling / hygiene:
  - add `tools/check_vex_distribution_marking_boundary.py` and wire it through discovery/history surfaces, bibliography, posture indexes, supply-chain notes, and RFC-0092 so imported advisory handling labels cannot quietly regrow as archive meaning

## Revised496 (2026-03-19)
- pin the exact **VEX product-graph boundary v0** so imported advisory product identity/topology material stops inheriting fuzzy “same product / same subtree / same install target” folklore and instead stays on one small explicit verifier seam:
  - add `docs/30-architecture/vex-product-graph-boundary-v0.md`, fixing Phase 1 so **imported OpenVEX `products[]` / `subcomponents[]` and CSAF `/product_tree/*` product graph semantics stay advisory matching evidence rather than a native component graph, same-product oracle, install-topology rule, or update/applicability selector**; exact binding stays on CH-VEX / CH-SBOM / CH-AREF digests plus explicit local policy, and any product-id/purl/group/path resolution remains verifier-local
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so imported advisory product trees, groups, paths, IDs, and subcomponent edges cannot silently regrow into native component-graph or install-topology semantics
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so advisory product-graph meaning is discoverable instead of being inferred from OpenVEX/CSAF ecosystem habit
- add `tools/check_vex_product_graph_boundary.py`, register `EVID-2026-503`, and make `make lint` reject drift where imported advisory product IDs, PURLs, groups, paths, and subcomponent structure quietly regrow into a native component-graph / same-product / install-topology oracle

## Revised495 (2026-03-19)
- pin the exact **VEX producer identity boundary v0** so imported advisory producer/publisher metadata stops inheriting fuzzy “vendor said it, therefore trust or prioritize it” folklore and instead stays on one small explicit verifier seam:
  - add `docs/30-architecture/vex-producer-identity-boundary-v0.md`, fixing Phase 1 so **CH-VEX `author` / `generator`, imported OpenVEX `author` / `role` / `tooling`, and CSAF `/document/publisher/*` metadata stay provenance evidence rather than native trust-root, precedence, support-owner, or remediation-owner authority**; exact binding still rides on CH-VEX / CH-AREF digests plus explicit signature/admission policy, and any issuer ranking or trust mapping remains verifier-local
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so producer/publisher labels cannot silently regrow into a native trusted-vendor / preferred-issuer / support-owner plane
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so advisory producer identity remains discoverable instead of being inferred from ecosystem habit
- add `tools/check_vex_producer_identity_boundary.py`, register `EVID-2026-502`, and make `make lint` reject drift where imported OpenVEX/CSAF producer metadata quietly regrows into a native trust, precedence, or support-owner oracle

## Revised494 (2026-03-19)
- pin the exact **VEX external-document supersession boundary v0** so imported OpenVEX/CSAF advisory revision metadata stops inheriting fuzzy “same advisory id + newer version/date means replace what we previously reviewed” folklore and instead stays on one small explicit verifier seam:
  - add `docs/30-architecture/vex-document-supersession-boundary-v0.md`, fixing Phase 1 so **imported OpenVEX `@id` / `timestamp` / `last_updated` / `version` and CSAF `/document/tracking/*` revision metadata stay advisory-document evidence rather than native latest-wins, freshness, hold/resume, or replacement authority**; exact binding stays on CH-VEX / CH-AREF digests, and any revision comparison remains verifier-local
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so imported advisory document ids / versions / revision dates cannot silently regrow into a native latest-by-advisory or document-supersession plane
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so external advisory revision meaning is discoverable instead of being inferred from OpenVEX/CSAF repository habits
- add `tools/check_vex_document_supersession_boundary.py`, register `EVID-2026-501`, and make `make lint` reject drift where imported advisory document identity/version metadata quietly regrows into a native latest-wins or replacement oracle

## Revised493 (2026-03-19)
- pin the exact **VEX OSV range boundary v0** so imported OSV advisory package/range material stops inheriting fuzzy “this package/range match means same component / this fixed event means choose that update” folklore and instead stays on one small explicit verifier seam:
  - add `docs/30-architecture/vex-osv-range-boundary-v0.md`, fixing Phase 1 so **imported OSV `affected[].package` / `ecosystem` / `ranges` / `versions` semantics stay advisory-matching evidence rather than native same-component, version-ordering, or update-selection authority**; exact install/boot cohort meaning stays on subject digests and reviewed carriers, and any OSV package/range evaluation remains verifier-local
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so imported OSV package/range semantics cannot silently regrow into same-component / version-ordering / update-selection semantics
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so OSV package/range meaning is discoverable instead of being inferred from ecosystem-specific advisory tooling habit
- add `tools/check_vex_osv_range_boundary.py`, register `EVID-2026-500`, and make `make lint` reject drift where imported OSV package/range semantics quietly regrow into a native same-component / version-ordering / update-selection oracle

## Revised492 (2026-03-19)
- pin the exact **VEX reference/locator boundary v0** so imported advisory links stop inheriting fuzzy “follow this vendor KB / advisory / remediation URL to complete meaning” folklore and instead stay on one small explicit verifier seam:
  - add `docs/30-architecture/vex-reference-locator-boundary-v0.md`, fixing Phase 1 so **imported advisory references, URLs, and locator fields stay descriptive evidence rather than a native fetch or resolver rule**; exact VEX/evidence binding stays on CH-VEX / CH-AREF digests, and any dereference/prioritization remains verifier-local or imported tooling only
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so imported advisory references / locator fields cannot silently regrow into a native fetch / discovery / resolver or latest-by-link plane
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so advisory-link meaning is discoverable instead of being inferred from VEX/advisory interoperability habit
- add `tools/check_vex_reference_locator_boundary.py`, register `EVID-2026-499`, and make `make lint` reject drift where imported advisory references, URLs, and locator fields quietly regrow into a native fetch / discovery / resolver oracle

## Revised491 (2026-03-19)
- pin the exact **VEX CPE/applicability boundary v0** so imported advisory product-targeting material stops inheriting fuzzy “matched CPE means this is the same product / this update applies / this boot should be blocked” folklore and instead stays on one small explicit verifier seam:
  - add `docs/30-architecture/vex-cpe-applicability-boundary-v0.md`, fixing Phase 1 so **imported CPE names, match strings, and applicability expressions stay targeting evidence rather than native install-scope authority**; exact install/boot cohort meaning stays on subject digests and reviewed carriers, and any CPE matching/dictionary/applicability evaluation remains verifier-local
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so imported CPE targeting cannot silently regrow into install-target / same-product / applicability-closure semantics
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so CPE/applicability meaning is discoverable instead of being inferred from advisory/scanner folklore
- add `tools/check_vex_cpe_applicability_boundary.py`, register `EVID-2026-498`, and make `make lint` reject drift where imported CPE names / applicability expressions quietly regrow into a native install-target / same-product / applicability oracle

## Revised490 (2026-03-19)
- pin the exact **VEX priority-signal boundary v0** so imported vulnerability scoring and threat-prioritization material stops inheriting fuzzy “this score means update now / block boot / skip because low priority” folklore and instead stays on one small explicit verifier seam:
  - add `docs/30-architecture/vex-priority-signal-boundary-v0.md`, fixing Phase 1 so **imported CVSS / EPSS / KEV / vendor-severity style signals stay evidence rather than native install/boot authority**; exact carrier meaning stays on subject digests and staged cohorts, and any thresholds, score fusion, or urgency policy remain verifier-local
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so advisory-priority signals cannot silently regrow into install-veto / rollout-priority / boot-veto / update-selection semantics
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so vulnerability-priority meaning is discoverable instead of being inferred from ecosystem habit or release packaging
- add `tools/check_vex_priority_signal_boundary.py`, register `EVID-2026-497`, and make `make lint` reject drift where imported CVSS / EPSS / KEV / vendor-severity style signals quietly regrow into a native install/boot authority plane

## Revised489 (2026-03-19)
- pin the exact **SBOM external-reference locator boundary v0** so imported SPDX/CycloneDX URL/locator fields stop inheriting fuzzy “follow this link” / “use this mirror” / “this advisory or BOM URL completes the evidence set” folklore and instead stay on one small explicit verifier seam:
  - add `docs/30-architecture/sbom-external-reference-locator-boundary-v0.md`, fixing Phase 1 so **imported SPDX `PackageDownloadLocation` / `PackageHomePage` / `ExternalRef` locators and CycloneDX `externalReferences` / URLs stay descriptive evidence rather than a native fetch, discovery, or resolver rule**; exact SBOM/evidence binding stays on CH-SBOM / CH-AREF digests, and any dereference/prioritization remains verifier-local or imported tooling only
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0091-sbom-artifacts-and-closure-binding.md` so imported URL/locator fields cannot silently become a native mirror/fallback/fetch or evidence-closure plane
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so imported-link meaning is discoverable instead of being inferred from SPDX/CycloneDX link-following folklore
- add `tools/check_sbom_external_reference_locator_boundary.py`, register `EVID-2026-496`, and make `make lint` reject drift where imported SPDX/CycloneDX URL/locator fields quietly regrow into a native fetch / discovery / resolver oracle

## Revised488 (2026-03-18)
- pin the exact **SBOM supplier/origin boundary v0** so imported SPDX/CycloneDX provenance labels stop inheriting fuzzy “supplier/manufacturer/originator means trusted vendor / support owner / remediation source” folklore and instead stay on one small explicit verifier seam:
  - add `docs/30-architecture/sbom-supplier-origin-boundary-v0.md`, fixing Phase 1 so **imported `supplier`, SPDX `PackageSupplier` / `PackageOriginator`, and richer CycloneDX `manufacturer` / `authors` metadata stay provenance evidence rather than a native trust, support-owner, or remediation-owner rule**; exact binding stays on CH-SBOM / CH-AREF digests, and any vendor/provenance interpretation remains verifier-local or imported evidence only
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0091-sbom-artifacts-and-closure-binding.md` so imported supplier/origin labels cannot silently become a native vendor-trust or support-routing oracle
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so supplier/origin meaning is discoverable instead of being inferred from SPDX/CycloneDX provenance folklore
- add `tools/check_sbom_supplier_origin_boundary.py`, register `EVID-2026-495`, and make `make lint` reject drift where imported `supplier`, SPDX `PackageSupplier` / `PackageOriginator`, or richer SBOM provenance metadata quietly regrow into a native trust / support-owner / remediation-owner oracle

# Changelog

## Revised487 (2026-03-18)
- pin the exact **SBOM license-metadata boundary v0** so imported SPDX/CycloneDX licensing fields stop inheriting fuzzy “license text means native allow/deny / waiver / obligations” folklore and instead stay on one small explicit verifier seam:
  - add `docs/30-architecture/sbom-license-metadata-boundary-v0.md`, fixing Phase 1 so **imported `licenses`, SPDX expressions, and richer SPDX/CycloneDX license metadata stay evidence rather than a native allow/deny, waiver, or obligation rule**; exact binding stays on CH-SBOM / CH-AREF digests, and any parsing/compliance interpretation remains verifier-local or imported evidence only
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0091-sbom-artifacts-and-closure-binding.md` so imported license metadata cannot silently become a native compliance-policy oracle
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so license-metadata meaning is discoverable instead of being inferred from SPDX/CycloneDX compliance folklore
- add `tools/check_sbom_license_metadata_boundary.py`, register `EVID-2026-494`, and make `make lint` reject drift where imported `licenses`, SPDX expressions, or richer SBOM license metadata quietly regrow into a native allow/deny / waiver / obligation oracle

## Revised486 (2026-03-18)
- pin the exact **SBOM SPDX relationship boundary v0** so imported SPDX graph edges stop inheriting fuzzy “dependency edge means native prerequisite / closure / causality” folklore and instead stay on one small explicit verifier seam:
  - add `docs/30-architecture/sbom-spdx-relationship-boundary-v0.md`, fixing Phase 1 so **imported SPDX `Relationship` edges stay document-graph evidence rather than a native dependency, closure, or causality rule**; `DEPENDS_ON` / `CONTAINS` / `GENERATED_FROM` / `DESCRIBES` and `NONE` / `NOASSERTION` may inform local tooling but do not widen install meaning, prove graph completeness, or create fetch/solver semantics
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0091-sbom-artifacts-and-closure-binding.md` so imported SPDX relationship graphs cannot silently become a native dependency / closure / causality plane
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so SPDX relationship meaning is discoverable instead of being inferred from upstream SBOM graph folklore
- add `tools/check_sbom_spdx_relationship_boundary.py`, register `EVID-2026-493`, and make `make lint` reject drift where imported SPDX relationship edges quietly regrow into a native dependency / closure / causality rule

## Revised485 (2026-03-18)
- pin the exact **SBOM SPDX reference boundary v0** so imported SPDX element-reference syntax stops inheriting fuzzy “prefixed reference means same component everywhere” / “external document ref implies follow it” folklore and instead stays on one small explicit verifier seam:
  - add `docs/30-architecture/sbom-spdx-reference-boundary-v0.md`, fixing Phase 1 so **imported SPDX `SPDXID` / `ExternalDocumentRef` syntax stays document-scoped evidence rather than a native cross-artifact join or resolver rule**; exact document binding stays on CH-AREF digests, and any reference traversal/correlation remains verifier-local or imported evidence only
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0091-sbom-artifacts-and-closure-binding.md` so imported SPDX reference syntax cannot silently become a native same-component / evidence-closure / resolver plane
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so SPDX reference meaning is discoverable instead of being inferred from SPDX document-graph folklore
- add `tools/check_sbom_spdx_reference_boundary.py`, register `EVID-2026-492`, and make `make lint` reject drift where imported SPDX `SPDXID` / `ExternalDocumentRef` syntax quietly regrows into a native cross-artifact join / resolver oracle

## Revised484 (2026-03-18)
- pin the exact **SBOM external-document supersession boundary v0** so imported SPDX/CycloneDX document-identity folklore stops inheriting fuzzy “newer BOM wins” / “updated namespace replaces prior evidence” semantics and instead stays on one small explicit verifier seam:
  - add `docs/30-architecture/sbom-document-supersession-boundary-v0.md`, fixing Phase 1 so **external SBOM document identity/version fields such as CycloneDX `serialNumber` + BOM `version` and SPDX document namespace stay imported document metadata rather than a native latest-wins / freshness / replacement rule**; exact document binding stays on CH-AREF digests, and any document selection/supersession logic stays verifier-local or imported evidence only
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0091-sbom-artifacts-and-closure-binding.md` so external document-version metadata cannot silently become a native inventory-supersession or freshness rule
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so document-version meaning is discoverable instead of being inferred from SPDX/CycloneDX document-management folklore
- add `tools/check_sbom_document_supersession_boundary.py`, register `EVID-2026-491`, and make `make lint` reject drift where external SBOM document identity/version fields quietly regrow into a native latest-wins / freshness / replacement oracle

## Revised483 (2026-03-18)
- pin the exact **SBOM/VEX component-version boundary v0** so imported package/advisory version labels stop inheriting fuzzy “same version means same component” / “higher version means fixed” folklore and instead stay on one small explicit verifier seam:
  - add `docs/30-architecture/sbom-component-version-boundary-v0.md`, fixing Phase 1 so **imported component / subject `version` labels stay descriptive rather than a native cross-artifact same-component or version-ordering rule**; matching or ordered version strings do not create portable suppression, completeness, remediation, or applicability semantics, and any richer comparison/canonicalization/range logic stays verifier-local or imported evidence only
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, `rfcs/0091-sbom-artifacts-and-closure-binding.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so imported component/advisory version labels cannot silently become a native same-component / newer-than / fixed-by-successor rule across SBOM/VEX/update/boot evidence
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so component-version meaning is discoverable instead of being inferred from package-ecosystem folklore
- add `tools/check_sbom_component_version_boundary.py`, register `EVID-2026-490`, and make `make lint` reject drift where imported component/advisory version labels quietly regrow into a native same-component / version-ordering / remediation oracle

## Revised482 (2026-03-18)
- pin the exact **SBOM/VEX `purl` identity boundary v0** so imported package-URL labels stop inheriting fuzzy “same purl means same component/package everywhere” folklore and instead stay on one small explicit verifier seam:
  - add `docs/30-architecture/sbom-purl-identity-boundary-v0.md`, fixing Phase 1 so **imported `purl` stays a package label rather than a native cross-artifact component identity**; matching or normalized package URLs do not create portable suppression, completeness, remediation, or applicability semantics, Phase 1 adds no qualifier-dropping / alias / canonicalization rule, and any richer package correlation stays verifier-local or imported evidence only
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, `rfcs/0091-sbom-artifacts-and-closure-binding.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so one imported package label cannot silently become a native same-component join key across SBOM/VEX/update/boot evidence
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so package-label meaning is discoverable instead of being inferred from package-ecosystem folklore
- add `tools/check_sbom_purl_identity_boundary.py`, register `EVID-2026-489`, and make `make lint` reject drift where one imported `purl` quietly regrows into a native cross-artifact component-identity / suppression / applicability join rule

## Revised481 (2026-03-18)
- pin the exact **SBOM `bom-ref` identity boundary v0** so imported CycloneDX graph-local labels stop inheriting fuzzy “same `bom-ref` means same component everywhere” folklore and instead stay on one small explicit verifier-local seam:
  - add `docs/30-architecture/sbom-bomref-identity-boundary-v0.md`, fixing Phase 1 so **imported CycloneDX `bom-ref` stays a document-local join label rather than a native cross-artifact component identity**; matching `bom-ref` strings do not create portable suppression, completeness, or applicability semantics, and any richer graph correlation stays imported evidence or explicit local policy only
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-component-absence-boundary-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0091-sbom-artifacts-and-closure-binding.md` so one external BOM label cannot silently become a native same-component join key across SBOM/VEX/update/boot evidence
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so CycloneDX label meaning is discoverable instead of being inferred from BOM-graph folklore
- add `tools/check_sbom_bomref_identity_boundary.py`, register `EVID-2026-488`, and make `make lint` reject drift where one external CycloneDX `bom-ref` quietly regrows into a native cross-artifact component-identity / suppression / applicability join rule

## Revised480 (2026-03-18)
- pin the exact **VEX statement-key boundary v0** so one CH-VEX artifact stops inheriting fuzzy “latest row wins” / timestamp-precedence / within-document supersession folklore and instead keeps repeated-or-contradictory advisory rows on one small explicit verifier seam:
  - add `docs/30-architecture/vex-statement-key-boundary-v0.md`, fixing Phase 1 so **`statements[]` is one unordered exact-key snapshot rather than a native history/conflict-resolution plane**; for one exact scoped issue key there is at most one live statement, duplicate/conflicting rows fail closed, `issued_at_s` stays evidence rather than precedence authority, and richer advisory history remains verifier-local or imported evidence only
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so row order, timestamp cadence, or repeated status rows cannot silently become a native last-wins / conflict-resolution rule
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so repeated-row meaning is discoverable instead of being inferred from advisory update folklore
- add `tools/check_vex_statement_key_boundary.py`, register `EVID-2026-487`, and make `make lint` reject drift where one CH-VEX artifact quietly regrows duplicate/contradictory same-key rows or a native last-wins / timestamp-precedence rule

## Revised479 (2026-03-18)
- pin the exact **VEX vulnerability-identity boundary v0** so one exploitability statement keyed by one vulnerability label stops inheriting fuzzy “this covers the whole alias family” folklore and instead keeps cross-database correlation on explicit verifier-local policy seams:
  - add `docs/30-architecture/vex-vulnerability-identity-boundary-v0.md`, fixing Phase 1 so **`vuln_id` remains an exact statement label rather than a native alias / upstream / related graph, canonical-vulnerability selector, or cross-ID suppression key**; imported OpenVEX / OSV / CSAF identity relations stay imported evidence unless another seam explicitly admits more
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so one VEX statement for one label cannot silently suppress, confirm, or canonicalize every equivalent-looking advisory ID
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so vulnerability-label meaning is discoverable instead of being inferred from external advisory alias folklore
- add `tools/check_vex_vulnerability_identity_boundary.py`, register `EVID-2026-486`, and make `make lint` reject drift where `vuln_id`, external advisory aliases, or bundle adjacency quietly regrow into a native alias/canonicalization/suppression rule

## Revised478 (2026-03-18)
- pin the exact **VEX investigation-deferral boundary v0** so unresolved advisories stop inheriting fuzzy “hold this rollout until the vendor finishes investigating” folklore and instead keep caution/review posture on explicit local policy seams:
  - add `docs/30-architecture/vex-investigation-deferral-boundary-v0.md`, fixing Phase 1 so **`under_investigation` and VEX timing fields remain exploitability evidence about an already-bound subject rather than a native install hold / grace window / defer-update / temporary-waiver selector**; unresolved-advisory handling stays verifier-local unless another seam explicitly admits more
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so under-investigation status and VEX timing hints can inform local review but cannot silently select hold / grace / defer behavior on CH-UPD or CH-BOOT
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so investigation-shaped advisory meaning is discoverable instead of being inferred from timestamp cadence or advisory state folklore
- add `tools/check_vex_investigation_deferral_boundary.py`, register `EVID-2026-485`, and make `make lint` reject drift where `under_investigation` or VEX timing fields quietly regrow into a native install-hold / defer-update / grace-period selector

## Revised477 (2026-03-18)
- pin the exact **VEX remediation-selection boundary v0** so fixed-status advisories and remediation hints stop inheriting fuzzy “this advisory chooses the patch you should install” folklore and instead keep update selection on the existing digest-first seams:
  - add `docs/30-architecture/vex-remediation-selection-boundary-v0.md`, fixing Phase 1 so **`fixed` and remediation/action text remain exploitability evidence about an already-bound subject rather than a native patch-plan / successor-target / minimum-safe-version selector**; version labels and richer imported remediation semantics stay observational or verifier-local unless another seam explicitly admits them
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, and `rfcs/0092-vex-artifacts-and-exploitability-statements.md` so fixed-status or remediation text can inform local policy but cannot silently select a CH-UPD / TUF target / rollout plan
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so remediation-selection meaning is discoverable instead of being inferred from advisory prose or version-label folklore
- add `tools/check_vex_remediation_selection_boundary.py`, register `EVID-2026-484`, and make `make lint` reject drift where `fixed` or remediation text quietly regrow into a native patch-plan / update-target selector

## Revised476 (2026-03-18)
- pin the exact **VEX component-absence boundary v0** so one `component_not_present` statement plus one linked inventory stops inheriting fuzzy “absence oracle” folklore and becomes one small explicit split across the existing VEX/SBOM/update/boot seams:
  - add `docs/30-architecture/vex-component-absence-boundary-v0.md`, fixing Phase 1 so **`component_not_present` remains exact evidence about one already-bound subject rather than a native total-absence verdict**; absence from one selected CH-SBOM is not a portable completeness proof by itself, stable digest/build-id identifiers carry any portable component match when present, and richer naming/completeness semantics remain verifier-local or imported evidence only
  - tighten `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/vex-schema-v0.md`, `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/sbom-schema-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`, `docs/30-architecture/decision-map.md`, and `docs/60-engineering/supply-chain-repro.md` so missing-from-one-inventory / one VEX absence statement cannot quietly become a native component-absence oracle
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so component-scoped absence meaning is discoverable instead of being inferred from package-label folklore or one selected inventory
- add `tools/check_vex_component_absence_boundary.py`, register `EVID-2026-483`, and make `make lint` reject drift where `component_not_present` or missing-from-one-inventory quietly regrow into a native absence/completeness oracle

## Revised475 (2026-03-18)
- pin the exact **SBOM/VEX evidence-set boundary v0** so release bundles stop inheriting fuzzy “all nearby inventory/advisory artifacts form one authoritative applicability set” folklore and instead keep each exact supply-chain evidence artifact on its own seam:
  - add `docs/30-architecture/sbom-vex-evidence-set-boundary-v0.md`, fixing Phase 1 so **multiple exact SBOM/VEX artifacts do not become one native vulnerability/applicability closure**; cross-artifact union/fallback/completeness remains verifier-local, and there is no native evidence-set preference rule
  - tighten `docs/30-architecture/sbom-posture-v0.md`, `docs/30-architecture/vex-posture-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/decision-map.md`, and `docs/60-engineering/supply-chain-repro.md` so several exact inventory/exploitability artifacts remain several exact evidence inputs rather than a hidden applicability-closure language
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so cross-artifact SBOM/VEX-set meaning is discoverable instead of being inferred indirectly from bundle layout or sidecar habit
- add `tools/check_sbom_vex_evidence_set_boundary.py`, register `EVID-2026-482`, and make `make lint` reject drift where several exact SBOM/VEX artifacts quietly regrow into a native applicability-closure/fallback/completeness rule

## Revised474 (2026-03-18)
- pin the exact **provenance-evidence set boundary v0** so carriers stop inheriting fuzzy “all nearby provenance-ish artifacts form one authoritative closure” folklore and instead keep each exact evidence artifact on its own seam:
  - add `docs/30-architecture/provenance-evidence-set-boundary-v0.md`, fixing Phase 1 so **multiple exact provenance-bearing artifacts do not become one native provenance closure**; cross-artifact union/fallback/completeness remains verifier-local, and there is no native evidence-set preference rule
  - tighten `docs/30-architecture/provenance-posture-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, and `docs/60-engineering/supply-chain-repro.md` so `prov_attestation_digest` plus adjacent proof/evidence artifacts remain several exact evidence inputs rather than a hidden closure language
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so cross-artifact provenance-set meaning is discoverable instead of being inferred indirectly from bundle layout or sidecar habit
- add `tools/check_provenance_evidence_set_boundary.py`, register `EVID-2026-481`, and make `make lint` reject drift where several exact provenance-bearing artifacts quietly regrow into a native closure/fallback/completeness rule

## Revised473 (2026-03-18)
- pin the exact **provenance-container selection boundary v0** so one exact `prov_attestation_digest` stops inheriting fuzzy "the container decides the provenance set" folklore and becomes one small explicit split across the existing provenance/signature/update/boot seams:
  - add `docs/30-architecture/provenance-container-selection-boundary-v0.md`, fixing Phase 1 so **one exact provenance container may package multiple attestations, but statement selection/reconciliation stays verifier-local**; carriers do not choose a preferred statement, extra statements stay extra evidence context only, and there is **no native union/preference/completeness/supersession rule**
  - tighten `docs/30-architecture/provenance-posture-v0.md`, `docs/30-architecture/provenance-attestation-schema-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, and `docs/60-engineering/supply-chain-repro.md` so imported multi-statement provenance packaging remains packaging rather than a hidden native selection/completeness language
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so provenance-container selection meaning is discoverable instead of being inferred indirectly from bundle habit
- add `tools/check_provenance_container_selection_boundary.py`, register `EVID-2026-480`, and make `make lint` reject drift where bundle order, statement count, or container completeness quietly become native provenance semantics

## Revised472 (2026-03-18)
- pin the exact **provenance-coverage policy boundary v0** so boot/update carriers stop inheriting fuzzy “artifact asks for strict provenance mode” folklore and remain one small explicit split across the existing provenance/update/boot/policy seams:
  - add `docs/30-architecture/provenance-coverage-policy-boundary-v0.md`, fixing Phase 1 so **carrier-borne provenance fields pin exact evidence bytes only**; CH-UPD/CH-BOOT do **not** carry or select a portable provenance-profile/policy-tier selector, owner-local coverage labels stay off-carrier, attached provenance does not auto-escalate or relax verifier policy, and there is **no native provenance-profile / policy-tier plane**
  - tighten `docs/30-architecture/provenance-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, and `docs/60-engineering/supply-chain-repro.md` so `prov_attestation_digest` remains exact evidence binding rather than a hidden verifier-policy selector
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so provenance-coverage policy meaning is discoverable instead of being inferred indirectly from release-tier or bundle folklore
- add `tools/check_provenance_coverage_policy_boundary.py`, register `EVID-2026-479`, and make `make lint` reject drift where CH-UPD/CH-BOOT quietly regrow provenance-profile / policy-tier semantics

## Revised471 (2026-03-18)
- pin the exact **provenance-required subject boundary v0** so stricter verifier policy stops inheriting fuzzy “all provenance subjects matter equally” folklore and becomes one small explicit split across the existing boot/update/provenance seams:
  - add `docs/30-architecture/provenance-required-subject-boundary-v0.md`, fixing Phase 1 so **local policy may require provenance only for exact already-pinned carrier digests**; CH-UPD/CH-BOOT choose the candidate digest universe first, verifiers may select a bounded exact subset from that cohort, and extra CH-PROV subjects remain extra evidence context rather than broader install/boot meaning
  - tighten `docs/30-architecture/provenance-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, and `docs/60-engineering/supply-chain-repro.md` so required provenance coverage stays digest-exact and carrier-pinned instead of turning larger release attestations into implicit multi-subject admission rules
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so provenance-required subject semantics are discoverable instead of being inferred from verifier folklore
- add `tools/check_provenance_required_subject_boundary.py`, register `EVID-2026-478`, and make `make lint` reject drift where extra CH-PROV subjects quietly become broader install/boot meaning or where stricter policy stops being carrier-pinned

## Revised470 (2026-03-18)
- pin the exact **update-evidence subject boundary v0** so adjunct provenance / SBOM / VEX / proof artifacts stop inheriting fuzzy “release-wide” applicability and become one small explicit split across the existing update/provenance/evidence seams:
  - add `docs/30-architecture/update-evidence-subject-boundary-v0.md`, fixing Phase 1 so **CH-UPD defines the install subject first** (`target_root_digest` + `cfg_digest`), attached evidence may only appraise that pinned cohort, provenance extra subjects do not widen install meaning, SBOM/VEX subject mismatches stay evidence mismatches, and bundled/transparency evidence cannot silently redefine what the update installs
  - tighten `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, and `docs/60-engineering/supply-chain-repro.md` so supporting evidence can fail a local verdict without turning grouped artifacts or broader provenance subject sets into a second install-subject language
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so update/evidence applicability is discoverable instead of being inferred indirectly from release-bundle habit
- add `tools/check_update_evidence_subject_boundary.py`, register `EVID-2026-477`, and make `make lint` reject drift where supporting evidence quietly widens CH-UPD into a release-wide or bundle-wide subject definition

## Revised469 (2026-03-18)
- pin the exact **proof-bundle role boundary v0** so the loose `proof_bundle` example role stops inheriting hidden bundle/verdict semantics and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/proof-bundle-role-boundary-v0.md`, fixing Phase 1 so **`proof_bundle` means one descriptive role label for one exact adjunct evidence artifact digest only**; imported bundles remain evidence rather than verdict/install shortcuts, generic bundle presence does not choose verifier policy, `proof_bundle_digest` anchors exact bytes only, and there is **no native proof-bundle / recursive-fetch plane**
  - tighten `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/provenance-attestation-schema-v0.md`, `docs/30-architecture/transparency-log-anchor-schema-v0.md`, `docs/30-architecture/update-posture-v0.md`, `docs/30-architecture/provenance-posture-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, and `docs/60-engineering/supply-chain-repro.md` so packaged proof material keeps distinct meaning from verdicts, fetch plans, or schema-level completeness claims
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so proof-bundle meaning is discoverable instead of being inferred indirectly from Sigstore/tlog tooling habit
- add `tools/check_proof_bundle_role_boundary.py`, register `EVID-2026-476`, and make `make lint` reject drift where `proof_bundle` quietly regrows into a native schema family, a verifier-policy selector, or a recursive fetch/discovery authority

## Revised468 (2026-03-18)
- pin the exact **transparency-proof import boundary v0** so offline witnessed-inclusion evidence stops drifting between inline `CH-TLOG` blobs, ad-hoc witness bundles, and fetch-at-verify folklore, and instead becomes one small explicit interop seam over the existing D-TLOG / D-WITNESS / D-AREF surfaces:
  - add `docs/30-architecture/transparency-proof-import-boundary-v0.md`, fixing Phase 1 so **portable offline transparency proofs travel as exact external artifacts** (prefer C2SP `tlog-proof@v1`) referenced by `CH-AREF` / release-bundle manifests, while `CH-TLOG` stays the small native anchor and witness/inclusion proof bytes remain imported evidence under explicit local verifier policy
  - tighten `docs/30-architecture/transparency-log-posture-v0.md`, `docs/30-architecture/transparency-log-anchor-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, `rfcs/0029-transparency-log-anchors-for-evidence.md`, and `rfcs/0082-witnessed-checkpoints-and-split-view-resistance.md` so transparency proof transport, witness acceptance, and install/admission meaning stay distinct instead of collapsing into inline proof cargo, proof-selected trust, or ambient online transparency clients
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so offline transparency-proof transport is discoverable instead of being inferred indirectly from witness ecosystem habit
- add `tools/check_transparency_proof_import_boundary.py`, add `REF-TLOG-PROOF`, register `EVID-2026-475`, and make `make lint` reject drift where `CH-TLOG` quietly regrows inline witness/proof payloads, bespoke native proof schemas, or proof-carried discovery/fetch authority

## Revised467 (2026-03-18)
- pin the exact **transparency-witness acceptance boundary v0** so witnessed checkpoints stop inheriting checkpoint-present-signatures folklore and become one small, explicit, auditable adjunct over existing D-TLOG / D-WITNESS seams:
  - add `docs/30-architecture/transparency-witness-acceptance-boundary-v0.md`, fixing Phase 1 so **accepted witness identities, quorum rules, and any extra witness statements stay explicit local policy**; extra/unknown checkpoint signatures do **not** auto-enroll witnesses or raise the quorum, witness timestamps stay evidence rather than ambient freshness/time authority, and “audit-complete” remains a local policy conclusion instead of a checkpoint-carried grant
  - tighten `docs/30-architecture/transparency-log-posture-v0.md`, `docs/30-architecture/transparency-log-anchor-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, and `rfcs/0082-witnessed-checkpoints-and-split-view-resistance.md` so witness evidence, witness trust policy, and release gating keep distinct meanings instead of collapsing into checkpoint-selected quorum, witness-name folklore, or bearer-grade audit-complete badges
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so witness-policy meaning is discoverable instead of being inferred indirectly from transparency ecosystem habit
- add `tools/check_transparency_witness_acceptance_boundary.py`, add `REF-TLOG-CHECKPOINT`, `REF-TLOG-COSIGNATURE`, and `REF-SIGSUM-GETTING-STARTED`, register `EVID-2026-474`, and make `make lint` reject drift where checkpoint signatures, witness names, or witness timestamps quietly regrow into portable witness-policy authority

## Revised466 (2026-03-18)
- pin the exact **signature-algorithm acceptance boundary v0** so signature/keyless verification stops inheriting library-default crypto policy and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/signature-algorithm-acceptance-boundary-v0.md`, fixing Phase 1 so **algorithm identifiers remain exact signed evidence while accepted signature/message algorithms stay explicit verifier-local policy**; `alg` labels and certificate OIDs do **not** choose verifier crypto policy, multiple signatures do **not** imply strongest-wins negotiation, OS/library/FIPS defaults remain verifier-local implementation policy, and there is **no native algorithm-negotiation / capability-advertisement plane**
  - tighten `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so signature meaning, local algorithm policy, keyless certificate handling, and future crypto agility keep distinct meanings instead of collapsing into `alg`-selected fallback, multi-signature strongest-wins folklore, or machine-default crypto policy
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so algorithm-policy meaning is discoverable instead of being inferred indirectly from JOSE/COSE library behavior or local runtime defaults
- add `tools/check_signature_algorithm_acceptance_boundary.py`, add `REF-JWS-RFC7515` and `REF-JWT-BCP-RFC8725`, register `EVID-2026-473`, and make `make lint` reject drift where `alg` labels, certificate OIDs, multi-signature records, or machine-default crypto policy quietly regrow into portable verifier authority

## Revised465 (2026-03-18)
- pin the exact **verification-policy selection boundary v0** so verification/appraisal policy stops being inherited from tool defaults and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/verification-policy-selection-boundary-v0.md`, fixing Phase 1 so **verification/appraisal policy stays explicit verifier-owner input**; evidence and bundle fields do **not** choose which policy is in force, deployment-local policy resolution stays tooling-only and killable, policy changes affect future verification rather than rewriting past evidence, and there is **no native policy-discovery / policy-ID resolution / latest-policy plane**
  - tighten `docs/30-architecture/policy-bundle-schema-v0.md`, `docs/30-architecture/policy-handle-schema-v0.md`, `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/decision-map.md`, `rfcs/0028-veto-only-policy-bundles-for-automation.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so policy identity, evidence export, and verifier expectations keep distinct meanings instead of collapsing into artifact-selected policy IDs, default TUF-policy lookup, or repo/issuer-selected evaluation folklore
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so verification-policy selection is discoverable instead of being inferred indirectly from RATS / SLSA / Docker / Sigstore ecosystem habit
- add `tools/check_verification_policy_selection_boundary.py`, add `REF-DOCKER-ATTEST` and `REF-SIGSTORE-POLICY-CONTROLLER-API`, register `EVID-2026-472`, and make `make lint` reject drift where artifact fields, bundle IDs, or remote/default policy lookup quietly regrow into portable verifier authority

## Revised464 (2026-03-18)
- pin the exact **verification-material discovery boundary v0** so signature/keyless verification stops inheriting sidecar/registry/attachment folklore and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/verification-material-discovery-boundary-v0.md`, fixing Phase 1 so **verification consumes explicit artifact bytes plus explicit verification-material artifacts only**; neighboring-file sidecars stay tooling-only, OCI referrers / registry attachments stay tooling-only and policy-killable, bundle presence does not define “the right” verification materials, and there is **no native sidecar/referrer/registry-discovery plane**
  - tighten `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so signed meaning, trust roots, issuer discovery, and verification-material transport all keep distinct meanings instead of collapsing into sibling-file search, OCI referrer enumeration, or “first bundle found wins” folklore
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so verification-material discovery is discoverable instead of being inferred indirectly from Sigstore/OCI ecosystem habit
- add `tools/check_verification_material_discovery_boundary.py`, add `REF-OCI-DISTRIBUTION-REFERRERS`, register `EVID-2026-471`, and make `make lint` reject drift where sibling-sidecar lookup, OCI referrer enumeration, or bundle-discovery order quietly regrow into portable verifier authority

## Revised463 (2026-03-18)
- pin the exact **keyless issuer-discovery boundary v0** so keyless/cert-bearing verification stops inheriting browser/SDK/IdP discovery folklore and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/keyless-issuer-discovery-boundary-v0.md`, fixing Phase 1 so **OIDC/OAuth issuer metadata and SigningConfig-style service descriptors stay signer/client online config rather than verifier authority**; keyless verification does **not** require `.well-known` / OAuth metadata / JWKS / UserInfo / introspection fetch, issuer-metadata rotation cannot retroactively rewrite verification or approval, and there is **no native issuer-discovery / login / repo-membership plane**
  - tighten `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so keyless issuer/identity policy, verifier trust, and signer-side online configuration keep distinct meanings instead of collapsing into ambient `.well-known` discovery, hidden JWKS refresh, or browser login state
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so issuer-discovery meaning is discoverable instead of being inferred indirectly from OIDC/OAuth ecosystem habit
- add `tools/check_keyless_issuer_discovery_boundary.py`, add `REF-OPENID-DISCOVERY` and `REF-RFC8414-AS-METADATA`, register `EVID-2026-470`, and make `make lint` reject drift where signer-side metadata or live issuer queries quietly regrow into portable verifier authority

## Revised462 (2026-03-18)
- pin the exact **signature trust-root boundary v0** so signature/keyless verification stops inheriting browser/SDK/cache folklore and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/signature-trust-root-boundary-v0.md`, fixing Phase 1 so **trusted roots remain explicit local verifier input or explicit D-TUF/provisioning artifacts only**; trusted-root carriers stay adjunct artifacts rather than native authority objects, signer-side service URLs do not define verifier authority, artifact bundles cannot self-anchor or rotate trust, and there is **no native trusted-root / self-anchoring / signer-service-discovery plane**
  - tighten `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/update-repository-metadata-and-key-rotation.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so signature meaning, keyless identity policy, and TUF distribution all keep their own meanings instead of collapsing into bundle-contained roots, machine-global trust stores, or signer-service discovery folklore
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so trust-root meaning is discoverable instead of being inferred indirectly from RFC 5280 / TUF / Sigstore ecosystem habit
- add `REF-SIGSTORE-TRUSTROOT-PROTO`, `REF-SIGSTORE-CUSTOM-COMPONENTS`, register `EVID-2026-469`, and make `make lint` reject drift where trusted-root carriers, machine-local defaults, or signer-side service descriptors quietly regrow into portable approval authority

## Revised461 (2026-03-18)
- pin the exact **certificate-identity evidence boundary v0** so keyless/cert-bearing signer identity stops being shared PKI/forge folklore and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/certificate-identity-evidence-boundary-v0.md`, fixing Phase 1 so **SAN / subject / issuer / custom OID fields remain exact signed evidence under explicit local interpretation only**; there is **no universal best-identity grammar**, EKU / certificatePolicies / custom policy OIDs remain verifier-local admission predicates rather than portable signer-class authority, wildcard/regex/canonicalization rules stay local policy, and there is **no native repo-owner / forge-policy / identity-lookup plane** on the substrate
  - tighten `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so keyless issuer/identity checks now explicitly depend on local interpretation of cert-borne claims instead of hidden SAN/CN/OID folklore
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md` so certificate identity has one discoverable meaning instead of being inferred indirectly from RFC 5280, Fulcio claim mapping, and cosign verifier habit
- add `tools/check_certificate_identity_evidence_boundary.py`, register `EVID-2026-468`, and make `make lint` reject drift where SAN / subject / issuer / custom OID / EKU / policy-OID semantics quietly regrow into portable signer authority, wildcard grammar, or repo-owner lookup folklore

## Revised460 (2026-03-18)
- pin the exact **certificate-status evidence boundary v0** so cert-status handling stops being inherited PKI/browser folklore and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/certificate-status-evidence-boundary-v0.md`, fixing Phase 1 so **certificate status consumes explicit local evidence and explicit local policy only**; CRL / delta-CRL / OCSP locator fields stay hints only, status artifacts remain exact evidence rather than portable approval/install authority, freshness/soft-fail policy stays local, and there is **no native OCSP/CRL/status-cache plane**
  - tighten `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so signed meaning, signing-time evidence, certificate/path inputs, and certificate-status handling keep their own meanings instead of collapsing into ambient revocation fetching, cached-status folklore, or hidden account-status lookups
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so cert-status meaning is discoverable instead of being inferred indirectly from RFC 5280 / RFC 6960 / Sigstore ecosystem habit
- add `REF-RFC6960-OCSP`, `REF-SIGSTORE-SECURITY-MODEL`, `REF-SIGSTORE-THREAT-MODEL`, register `EVID-2026-467`, and make `make lint` reject drift where OCSP/CRL/status artifacts quietly regrow into ambient fetch, latest-status, or approval authority

## Revised459 (2026-03-17)
- pin the exact **certificate-path input boundary v0** so cert-bearing verification stops inheriting PKI library/browser folklore and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/certificate-path-input-boundary-v0.md`, fixing Phase 1 so **certificate/path inputs stay explicit verifier-local policy inputs**; AIA / `caIssuers` locator fields stay hints only, presented chains remain evidence inputs rather than trust-set expansion, certification path building stays verifier-local policy rather than portable substrate meaning, and there is **no native AIA/alternate-chain/trust-store search plane**
  - tighten `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0093-signature-envelopes-and-keyless-signing.md` so signed meaning, keyless identity policy, signing-time evidence, and certificate/path input policy all keep their own meanings instead of collapsing into ambient AIA chasing or “whatever chain verified on this machine today”
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so cert/path input meaning is discoverable instead of being inferred indirectly from RFC 5280 / RFC 4158 / Sigstore ecosystem habit
- add `REF-RFC5280-PKIX`, `REF-RFC4158-PATHBUILD`, `REF-SIGSTORE-CLIENT-SPEC`, register `EVID-2026-466`, and make `make lint` reject drift where AIA chasing, alternate-chain synthesis, or trust-set growth quietly become native substrate meaning

## Revised458 (2026-03-17)
- pin the exact **signing-time evidence boundary v0** so timestamp material stops being shared keyless/transparency folklore and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/signing-time-evidence-boundary-v0.md`, fixing Phase 1 so **signing-time evidence must bind exact signing-event bytes rather than raw unsigned payload bytes**; RFC 3161 / COSE / transparency timestamp material remains exact evidence rather than freshness/approval/time-admin authority, and there is **no native TSA / OCSP / latest-timestamp plane** on the authority substrate
  - tighten `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/30-architecture/transparency-log-posture-v0.md`, `docs/30-architecture/transparency-log-anchor-schema-v0.md`, `docs/30-architecture/security-time-posture-v0.md`, `docs/60-engineering/pcp-posture-v0.md`, `docs/60-engineering/supply-chain-repro.md`, `rfcs/0093-signature-envelopes-and-keyless-signing.md`, and `rfcs/0029-transparency-log-anchors-for-evidence.md` so signatures, signing-time evidence, transparency anchoring, and security-time policy all keep their own meanings instead of collapsing into payload-only timestamp shortcuts or ambient online trust
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so signing-time meaning is discoverable instead of being inferred indirectly from RFC 3161 / RFC 9921 / Sigstore ecosystem habit
- add `REF-RFC3161-TSP`, `REF-RFC9921-TST-HEADER`, `REF-SIGSTORE-TIMESTAMPS`, register `EVID-2026-465`, and make `make lint` reject drift where payload-only timestamps quietly count as signature-validity proof or where timestamp evidence regrows into freshness, approval, or time-admin authority

## Revised457 (2026-03-17)
- pin the exact **D-TLOG / D-WITNESS posture v0** so transparency anchors stop meaning “whatever the surrounding ecosystem usually implies” and become one small, explicit, auditable evidence seam:
  - add `docs/30-architecture/transparency-log-posture-v0.md`, fixing Phase 1 so **CH-TLOG binds one exact artifact digest to one exact append-only log state**; inclusion evidence does **not** silently imply complete log verification, checkpoint order/tree size never become freshness/time/runtime authority, witness policy stays explicit local corroboration, and there is **no native latest/query/watch/admin plane** on the authority substrate
  - tighten `docs/30-architecture/transparency-log-anchor-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/pcp-posture-v0.md`, `docs/60-engineering/supply-chain-repro.md`, `rfcs/0029-transparency-log-anchors-for-evidence.md`, and `rfcs/0082-witnessed-checkpoints-and-split-view-resistance.md` so transparency anchors, witnessed checkpoints, and supply-chain audit notes all keep their own meanings instead of collapsing into a discovery protocol, freshness oracle, or approval shortcut
- wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so D-TLOG has one discoverable meaning instead of being inferred indirectly from CT / witness / SCITT ecosystem habit
- add `REF-TRANSPARENCY-VERIFY`, register `EVID-2026-464`, and make `make lint` reject drift where transparency receipts quietly regrow into latest-wins truth, query/watch APIs, witness auto-trust, or a hidden freshness/runtime authority plane

## Revised456 (2026-03-17)
- pin the exact **attestation endorsement/reference boundary v0** so attestation export stops inheriting verifier-side retrieval folklore and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/attestation-endorsement-boundary-v0.md`, fixing Phase 1 so **endorsements/reference values remain verifier-local appraisal inputs**; IF-ATTEST and CH-ATTESTPACK do **not** imply live vendor fetch/query/discovery behavior, `endorsement_aref_digests` stay exact artifact hints rather than latest-applicable truth, and there is **no native endorsement/reference inventory or latest-applicable plane** on the authority substrate
  - tighten `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/attestation-pack-schema-v0.md`, `docs/30-architecture/attestation-token-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/decision-map.md`, and `rfcs/0064-confidential-computing-profile.md` so attestation export, supporting-artifact pointers, verifier policy, and attestation-gated secret release all keep their own meanings instead of collapsing into an attester-side endorsement-discovery protocol
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so endorsement/reference handling is discoverable instead of being inferred indirectly from RATS / CoRIM / CoSERV ecosystem habit
- add `REF-RATS-ENDORSEMENTS-DRAFT` + `REF-COSERV-DRAFT`, register `EVID-2026-463`, and make `make lint` reject drift where attestation export quietly regrows into a native vendor-fetch client, endorsement inventory, or latest-applicable trust plane

## Revised455 (2026-03-17)
- pin the exact **verification-verdict boundary v0** so supply-chain verification stops being inferred from ecosystem habit and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/verification-verdict-boundary-v0.md`, fixing Phase 1 so **verification stays consumer-local evaluation of exact evidence under local policy**; imported summaries or reviewer statements remain evidence rather than install authority, stale passes do not outrun local trust roots/freshness, and there is **no native verified-good / waiver / latest-verified plane** on the authority substrate
  - tighten `docs/30-architecture/provenance-attestation-schema-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/30-architecture/signature-envelope-posture-v0.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/60-engineering/pcp-posture-v0.md`, `docs/60-engineering/supply-chain-repro.md`, and `docs/60-engineering/update-repository-metadata-and-key-rotation.md` so provenance, signatures, update intent, and TUF repository handling all keep their own meanings while verification conclusions remain local-policy outputs rather than portable authority objects
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so verification meaning is discoverable instead of being inferred indirectly from SLSA/TUF/in-toto/SCITT ecosystem lore
- update the bibliography to point `REF-SLSA-VERIFYING-ARTIFACTS` at the current approved SLSA v1.2 build-verification guidance and add `REF-SLSA-VSA-RETIRED` + `REF-IN-TOTO-VSA` as explicit primary-source anchors for delegated verification-summary artifacts
- add `tools/check_verification_verdict_boundary.py`, register `EVID-2026-462`, and make `make lint` reject drift where signatures/provenance/update metadata quietly regrow into portable approval, waiver, or latest-verified semantics

## Revised454 (2026-03-17)
- pin the exact **release-identity boundary v0** so “release” stops being shared registry/update/provenance folklore and becomes one small, explicit, auditable adjunct split across existing seams:
  - add `docs/30-architecture/release-identity-boundary-v0.md`, fixing Phase 1 so **release names/version strings/purls/slugs stay observational distribution identifiers**; exact install/boot authority stays on digests, registry/package release attestations remain evidence rather than install/verdict authority, repository freshness stays on D-TUF metadata, and there is **no native release-discovery / latest-wins plane** on the authority substrate
  - tighten `docs/30-architecture/provenance-attestation-schema-v0.md`, `docs/30-architecture/update-manifest-schema-v0.md`, `docs/60-engineering/supply-chain-repro.md`, `docs/60-engineering/update-repository-metadata-and-key-rotation.md`, `docs/60-engineering/pcp-posture-v0.md`, `docs/60-engineering/release-packaging-contract.md`, and `docs/60-engineering/release-bundle-manifest-contract.md` so provenance stays artifact/build-bound, update stays digest-bound install intent, and handoff bundle integrity stays `files[].sha256`-authoritative instead of name/slug-driven
- wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so release identity has one discoverable meaning instead of being inferred indirectly from in-toto Release, SLSA distribution guidance, TUF, and archive handoff habit
- add `tools/check_release_identity_boundary.py`, register `EVID-2026-461`, and make `make lint` reject drift where release labels quietly regrow into install authority, repository freshness, verification verdicts, or archive-name folklore

## Revised453 (2026-03-17)
- pin the exact **D-ATOMICUPD / CH-UPD posture v0** so update intent stops being shared A/B-style + repository folklore and becomes one small, explicit, auditable boundary:
  - add `docs/30-architecture/update-posture-v0.md`, fixing Phase 1 so **CH-UPD is digest-bound install intent only**; one manifest binds one exact `target_root_digest` plus one exact `cfg_digest`, `artifacts[]` stays a bounded adjunct digest set rather than a fetch/dependency/install-order protocol, `created_at` / `expires_at` stay informational until explicit policy validates them, and there is **no channel/ring/percentage-rollout, repository-metadata, or verification-summary / approval-verdict meaning** on the native seam
  - tighten `docs/30-architecture/update-manifest-schema-v0.md` so the schema itself points back to the posture: digest fields are authoritative, labels/version strings/paths stay observational, freshness stays on D-TUF / D-TIME + verifier policy, and CH-UPD does not become a package inventory, rollout object, or health/admission verdict carrier
- wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/schema-registry.md`, `docs/60-engineering/update-repository-metadata-and-key-rotation.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so CH-UPD has one discoverable meaning instead of being inferred indirectly from RFC-0051 + TUF and A/B ecosystem habit
- add `tools/check_update_posture.py`, register `EVID-2026-460`, and make `make lint` reject drift where CH-UPD quietly regrows into channel metadata, rollout policy, repository state, or a hidden approval/verdict object

## Revised452 (2026-03-17)
- pin the exact **D-PCP / CH-PROV posture v0** so provenance stops being shared supply-chain folklore and becomes one small, explicit, auditable boundary:
  - add `docs/30-architecture/provenance-posture-v0.md`, fixing Phase 1 so **CH-PROV is digest-bound build provenance evidence only**; one artifact names one bounded build/release cohort, subject matching is by digest rather than filenames/version strings, builder/timestamp/invocation metadata stays informational until explicit policy validates it, and there is **no release-registry, verification-summary, or live query/fetch plane** on the native seam
  - tighten `docs/30-architecture/provenance-attestation-schema-v0.md` so the schema itself points back to the posture: `subjects[]` are one reviewed cohort, digest binding is authoritative, metadata fields are informational, materials/evidence digests are references rather than fetch instructions, and release-version mapping / verdict semantics stay on separate seams
- wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/schema-registry.md`, `docs/60-engineering/pcp-posture-v0.md`, `docs/60-engineering/supply-chain-repro.md`, `docs/60-engineering/update-repository-metadata-and-key-rotation.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so CH-PROV has one discoverable meaning instead of being inferred indirectly from PCP prose + SLSA/in-toto/SCITT ecosystem habit
- add `tools/check_provenance_posture.py`, register `EVID-2026-459`, and make `make lint` reject drift where provenance quietly regrows into package-registry naming, verification-summary / waiver semantics, or an ambient transparency query/discovery protocol

## Revised451 (2026-03-17)
- pin the exact **D-SBOM / D-VEX posture v0** so supply-chain evidence stops being shared tooling folklore and becomes two small, explicit, auditable boundaries:
  - add `docs/30-architecture/sbom-posture-v0.md`, fixing Phase 1 so **CH-SBOM is digest-bound inventory evidence only**; one artifact names one subject digest, stable component identifiers carry the portable binding, generator metadata stays informational, and there is **no merge/union/delta/fetch service or package-manager authority semantics** on the native seam
  - add `docs/30-architecture/vex-posture-v0.md`, fixing Phase 1 so **CH-VEX is digest-bound exploitability evidence only**; one artifact names one subject digest with a closed status/justification vocabulary, inventory linkage stays explicit through CH-SBOM, and there are **no scanner-suppression, feed-discovery, or latest-advisory-wins semantics** on the native seam
- wire the new posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/supply-chain-repro.md`, `rfcs/0091-sbom-artifacts-and-closure-binding.md`, `rfcs/0092-vex-artifacts-and-exploitability-statements.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so inventory/advisory evidence has one discoverable meaning instead of being inferred indirectly from schema docs + RFCs + ecosystem habit
- add `tools/check_supply_chain_evidence_posture.py`, register `EVID-2026-458`, and make `make lint` reject drift where SBOM/VEX quietly regrow into package-manager authority, scanner suppression, feed discovery, or other ambient supply-chain control planes

## Revised450 (2026-03-17)
- pin the exact **D-RECOVERY posture v0** so recovery stops being shared platform folklore and becomes one small, explicit, auditable boundary:
  - add `docs/30-architecture/recovery-posture-v0.md`, fixing Phase 1 so recovery is one **sealed dedicated `recovery_root` boot target**; entry is **manual/physical-presence-first** or an explicit bounded trial-boot assist only, recovery boot **never counts as main-boot success**, there is **no hidden repeated-failure auto-entry state**, and recovery remains a **bounded transcript-visible workflow set** rather than a generic admin shell or portable remote rescue plane
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `docs/30-architecture/boot-selector-state-schema-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `rfcs/0098-recovery-mode-and-rescue-environment.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so D-RECOVERY has one discoverable meaning instead of being inferred indirectly from RFC-0098 + boot-selector/update folklore
- add `tools/check_recovery_posture.py`, register `EVID-2026-457`, and make `make lint` reject drift where recovery quietly regrows into a hidden automatic repair state machine, a generic privileged admin shell, or a portable remote rescue plane

## Revised449 (2026-03-17)
- pin the exact **D-LLM posture v0** so the agent/control seam stops being shared prompt/tool folklore and becomes one small, explicit, auditable boundary:
  - add `docs/30-architecture/llm-operations-posture-v0.md`, fixing Phase 1 so **LLM output is proposal-only**; effectful automation stays on explicit **CH-ACP + existing reviewed seams**, tool/resource/prompt catalogs must be **explicit and bounded**, prompts/tool descriptions/retrieved text stay **non-authoritative**, durable memory only counts when attached through explicit artifact/observation seams, and there is **no portable dynamic connector-install/discovery or hidden cross-run memory plane**
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/70-llm-control/README.md`, `docs/70-llm-control/llm-threats.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so D-LLM has one discoverable meaning instead of being inferred indirectly from ACP semantics + threat notes + agent papers
- add `tools/check_llm_posture.py`, register `EVID-2026-456`, and make `make lint` reject drift where prompts become policy, hidden memory becomes trusted state, or dynamic tool/connector discovery quietly becomes native portable authority

## Revised448 (2026-03-17)
- pin the exact **D-INITSNAP posture v0** so `CH-INIT` stops being shared capDL/template folklore and becomes one small, explicit, auditable boundary:
  - add `docs/30-architecture/init-snapshot-posture-v0.md`, fixing Phase 1 so **`CH-INIT` is a boot-bound description of time-0 authority only**; there is **no portable runtime create/apply/patch/list/watch/export plane**, warm restore/checkpoint/continuity stay on explicit **D-CHKPT / D-EPHEM** seams, constructors may consume `digest(CH-INIT)` but `CH-INIT` itself does **not** become a constructor control plane, and any future live install/admin surface must return RFC-first with explicit commutativity + serialization + evidence
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/init-state-snapshot-schema-v0.md`, `rfcs/0024-initial-state-snapshots-and-cap-distribution-language.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so D-INITSNAP has one discoverable meaning instead of being inferred indirectly from CH-INIT + capDL/Microkit lore
- add `tools/check_initsnap_posture.py`, register `EVID-2026-455`, and make `make lint` reject drift where CH-INIT quietly regrows into a runtime snapshot API, checkpoint format, or generic constructor/template control plane

## Revised447 (2026-03-17)
- pin the exact **D-UPCALL posture v0** so scheduler-activation / user-mode-scheduler folklore does not quietly become a portable callback ABI or hidden runtime contract:
  - add `docs/30-architecture/upcall-posture-v0.md`, fixing Phase 1 so **portable kernel→user scheduling upcalls are simply absent**; existing **D-TCAP / D-SCHED / D-WAITSET / D-IOQ / D-REQCTX / D-QUIESCE** seams already own the useful event vocabulary, there is **no scheduler registration ABI, no timeout-fault callback plane, and no event-driven vCPU contract**, and any future reviewed scheduler-event surface must return RFC-first with explicit commutativity + serialization + evidence
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/scheduling-posture-v0.md`, `rfcs/0049-temporal-capabilities-and-scheduling-contexts.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so D-UPCALL has one discoverable meaning instead of being inferred indirectly from RFC-0049 + scheduler-activations lore
- add `tools/check_upcall_posture.py`, register `EVID-2026-454`, and make `make lint` reject drift where generic scheduler callbacks, timeout-fault delivery, or event-driven vCPU ideas quietly regrow into native portable meaning without an RFC-first seam

## Revised446 (2026-03-17)
- pin the exact **D-SIGENV / D-KEYLESS posture v0** so signed-artifact meaning stops being shared wrapper/online-trust folklore and becomes one small, explicit, auditable boundary:
  - add `docs/30-architecture/signature-envelope-posture-v0.md`, fixing Phase 1 so accepted signed meaning is the verified binding of **`(payload.schema, payload.digest)`** under local policy; verification stays **offline-first and policy-local**, `key_id` / identity fields stay **non-authoritative hints**, keyless remains **optional explicit issuer/identity policy** under D-TIME rather than ambient Fulcio/Rekor/network trust, and transparency material stays **evidence** instead of a hidden mandatory service dependency
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/signature-envelope-schema-v0.md`, `docs/60-engineering/supply-chain-repro.md`, `docs/60-engineering/pcp-posture-v0.md`, `rfcs/0093-signature-envelopes-and-keyless-signing.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so CH-SIGENV / keyless policy has one discoverable meaning instead of being inferred indirectly from RFC-0093 + Sigstore lore
- add `tools/check_signature_envelope_posture.py`, register `EVID-2026-453`, and make `make lint` reject drift where typed digest signing quietly regrows into filename/tag signing, online PKI dependence, or identity-by-hint acceptance

## Revised445 (2026-03-17)
- pin the exact **D-TIME posture v0** so security time stops being shared wall-clock folklore and becomes one small, explicit, auditable boundary:
  - add `docs/30-architecture/security-time-posture-v0.md`, fixing Phase 1 so expiry / anti-rollback use **policy-local monotonic lower-bound security time**; app-visible `CH-CLOCK kind="realtime"` stays observational/application-facing, there is **no portable wall-clock setting / RTC-write / timezone-calendar admin plane**, and secure RTC readings, authenticated timeproofs, and rollback floors are provider-local inputs to one fail-closed model rather than competing portable time domains
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/clock-descriptor-schema-v0.md`, `docs/30-architecture/nondet-posture-v0.md`, `docs/30-architecture/timeproof-posture-v0.md`, `rfcs/0090-secure-time-sync-and-timeproofs.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so D-TIME has one discoverable meaning instead of being inferred indirectly from RFC-0090 + timeproof lore
- add `tools/check_security_time_posture.py`, register `EVID-2026-452`, and make `make lint` reject drift where security time quietly decays back into host wall-clock/admin folklore or splits into competing RTC / timeproof / rollback-counter semantics

## Revised444 (2026-03-17)
- pin the exact **D-SCHED posture v0** so scheduler meaning stops being shared folklore and becomes one small, explicit, auditable boundary:
  - add `docs/30-architecture/scheduling-posture-v0.md`, fixing Phase 1 so portable scheduling stays **TCap-first**; reviewed scheduler intent is the closed **CH-TCAP** envelope (`budget/period/priority/overrun`), passive services run only on explicit donated time, and there is **no ambient self/peer priority-class mutation plane, no portable scheduler inventory/admin surface, and no generic fairness/share/latency promise**
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/temporal-capability-schema-v0.md`, `rfcs/0049-temporal-capabilities-and-scheduling-contexts.md`, `docs/30-architecture/capshell-scheduling-posture-v0.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so scheduling has one discoverable meaning instead of being inferred indirectly from TCap schema + launch adjuncts
- add `tools/check_scheduling_posture.py`, register `EVID-2026-451`, and make `make lint` reject drift where explicit CPU-time authority quietly decays back into ambient host scheduler folklore
- tighten nearby scheduler/TCap wording while touching the seam: `temporal-capability-schema-v0.md` now explicitly says CH-TCAP carries the **closed urgency vocabulary** for reviewed scheduler intent, and `capshell-scheduling-posture-v0.md` now records itself as the launch-boundary corollary of the system-wide D-SCHED posture

## Revised443 (2026-03-17)
- pin the exact **D-SKB posture v0** so hardware-knowledge reasoning stops being scattered RFC folklore and becomes one small, explicit, auditable boundary:
  - add `docs/30-architecture/skb-posture-v0.md`, fixing Phase 1 so hardware knowledge is an **explicit CH-HWFACT / CH-HWEVENT fact base** queried from **user space**; portable policy-driving queries stay **named + bounded**, **pure and epoch-bound**, results remain recommendations until another seam authorizes them, and there is **no ambient inventory/probing tree, no portable free-form query language, and no new workflow / ACP family**
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/hardware-facts-schema-v0.md`, `docs/30-architecture/hardware-event-schema-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0018-system-knowledge-base-and-hardware-facts.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the SKB seam is discoverable from the main architecture, schema, and assurance surfaces instead of living as diffuse RFC prose
- add `tools/check_skb_posture.py`, register `EVID-2026-450`, and make `make lint` reject drift where D-SKB quietly regrows into ambient host inventory/probing, a privileged-core logic engine, or a generic query/programming surface that outruns the proof story
- tighten nearby assurance wording while touching the seam: `I-HWFACT-1` and `PO-SKB-PURITY` now explicitly account for **CH-HWEVENT** as part of the declared fact base/evolution path rather than talking as if only the boot-time snapshot mattered

## Revised442 (2026-03-17)
- pin the exact **D-SUPV posture v0** so supervision stops being a shared assumption and becomes one small, explicit lifecycle boundary:
  - add `docs/30-architecture/supervision-posture-v0.md`, fixing Phase 1 so supervision is **component-rooted user-space policy over CH-COMP identities**; lifecycle control is bounded `Stop(grace) → Kill()`, restart is manifest/activation replay only, `critical` stays manifest-bool + profile policy, and there is **no portable pidfd / Job Object / process-tree control plane**
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/component-manifest-schema-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `rfcs/0017-supervision-trees-and-restart-policy.md`, `rfcs/0041-crash-only-services-and-microreboots.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so supervision has a compact discoverable meaning instead of living as diffuse RFC/adjunct prose
- add `tools/check_supervision_posture.py`, register `EVID-2026-449`, and make `make lint` reject drift where D-SUPV quietly regrows into ambient host process-manager semantics
- add `REF-LINUX-PIDFD` to record the explicit import boundary: Linux-style handle-based process control is a useful precedent, but it remains owner-local rather than portable SlopOS lifecycle meaning

## Revised441 (2026-03-17)
- pin the exact **D-BUDGET / D-METER payer-semantics posture v0** so “explicit payer” stops being aspirational prose and becomes one reviewed authority boundary:
  - add `docs/30-architecture/budget-payer-semantics-v0.md`, fixing Phase 1 so payer authority is **explicit and non-ambient**; there is no portable current-payer register, no cgroup / Job Object / container-membership payer identity, no silent callee sponsorship default, no hidden sponsor rebinding, and no payer lookup / inventory / admin plane
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/budget-lease-schema-v0.md`, `docs/30-architecture/meter-descriptor-schema-v0.md`, `rfcs/0012-resource-meters-space-banks-and-budgets.md`, `rfcs/0058-operation-scoped-budget-leases.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the meter/budget seams say clearly what they refuse to become
- add `tools/check_budget_payer_posture.py`, register `EVID-2026-448`, and make `make lint` reject drift where explicit payer quietly decays into ambient billing context folklore

## Revised440 (2026-03-17)
- pin the exact **D-PRESSURE posture v0** so practical resource-pressure mechanisms do not quietly become a portable ambient oracle or trigger-registration API:
  - add `docs/30-architecture/pressure-posture-v0.md`, fixing Phase 1 so pressure meaning is **scoped observational CH-PRESSURE over IF-OBS only**; there is no portable `/proc/pressure/*` / cgroup file contract, no portable `$MEMORY_PRESSURE_WATCH` / `$MEMORY_PRESSURE_WRITE` env-var or socket watch protocol, no portable writable PSI trigger / `poll()`-FD plane, and delivery stays coarse/coalesced/rate-limited rather than becoming a workflow / ACP / admin surface
  - wire the posture through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/pressure-signal-schema-v0.md`, `docs/30-architecture/schema-registry.md`, `rfcs/0057-pressure-signals-and-backpressure.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the pressure seam is discoverable from the main architecture surfaces instead of living as loose RFC prose
- add `tools/check_pressure_posture.py`, register `EVID-2026-447`, and make `make lint` reject drift where pressure regrows as an ambient procfs/cgroup/env/socket protocol, a writable threshold-registration API, or a hidden workflow surface
- refresh `REF-SYSTEMD-PRESSURE` to the current systemd documentation URL and record the explicit import boundary: we take the low-overhead userspace-reactivity lesson, but not its ambient env/path/socket transport as portable SlopOS contract

## Revised439 (2026-03-17)
- pin the exact **microVM page-tracking posture v0** so host-side dirty/access-tracking folklore does not quietly become a portable ambient migration / snapshot / observation / throttling plane:
  - add `docs/30-architecture/microvm-page-tracking-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient host-side guest-memory page-tracking contract**; there is no portable dirty-log / dirty-ring / page-access-bitmap / dirty-rate / working-set-estimation plane, owner-local write-protect / clear-and-reprotect / ring-sizing / throttling / diff-snapshot accounting policy stays implementation-local, and reviewed snapshot / migration / observation / performance meaning stays on explicit snapshot / migration / admission / observation seams rather than ambient VMM page-tracking machinery
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the seam is discoverable from the main microVM narrative instead of existing as an orphan
- add `tools/check_microvm_page_tracking_posture.py`, register `I-MICROVM-52`, `PO-MICROVM-PAGETRACK`, and `EVID-2026-446`, and make `make lint` reject drift where `ext.microvm` quietly grows reviewed dirty-log / dirty-ring / page-access-bitmap / dirty-rate / working-set-estimation meaning as a portable contract
- repair a malformed `EVID-2026-444` row while touching the nearby microVM evidence block so memory-backing and the new page-tracking seam remain machine-checkable and readable

## Revised438 (2026-03-17)
- pin the exact **microVM network-feature posture v0** so virtio-net throughput/steering folklore does not quietly become a portable ambient performance / control / status plane:
  - add `docs/30-architecture/microvm-network-feature-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible NIC acceleration/tuning contract**; there is no portable virtio-net multiqueue / RSS / hash-report / offload / queue-size / speed-duplex plane, owner-local queue-count / ring-size / offload-toggle / RSS-steering choice stays implementation-local, and reviewed network authority / performance / observation meaning stays on explicit D-NETLEASE / topology / observation seams rather than ambient virtio-net tuning knobs
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the seam is discoverable from the main microVM narrative instead of existing as an orphan
- add `tools/check_microvm_network_feature_posture.py`, register `I-MICROVM-51`, `PO-MICROVM-NETFEATURE`, and `EVID-2026-445`, and make `make lint` reject drift where `ext.microvm` quietly grows reviewed multiqueue / RSS / hash-report / offload / queue-size / speed-duplex meaning as a portable contract

## Revised437 (2026-03-17)
- pin the exact **microVM memory-backing posture v0** so host-side guest-RAM backing folklore does not quietly become a portable ambient density / snapshot / helper-sharing plane:
  - add `docs/30-architecture/microvm-memory-backing-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient host-side guest-RAM backing contract**; there is no portable anonymous-vs-file-vs-memfd-vs-shm backing plane, no portable hugepages / THP / prefault / prealloc / shared-mapping plane, owner-local backing-file / page-size / mapping-sharing / sealing choice stays implementation-local, and reviewed memory / snapshot / backend-offload / performance meaning stays on explicit topology / snapshot / offload seams rather than ambient host memory-backing modes
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the seam is discoverable from the main microVM narrative instead of existing as an orphan
- add `tools/check_microvm_memory_backing_posture.py`, register `I-MICROVM-50`, `PO-MICROVM-MEMBACK`, and `EVID-2026-444`, and make `make lint` reject drift where `ext.microvm` quietly grows reviewed hugepages / file-backed-RAM / memfd / shared-mapping / helper-sharing meaning as a portable contract

## Revised436 (2026-03-17)
- pin the exact **microVM cache-hierarchy posture v0** so cache descriptors, shared-cache topology, and cache-QoS folklore do not quietly become a portable ambient placement / performance / control plane:
  - add `docs/30-architecture/microvm-cache-hierarchy-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient cache-hierarchy / cache-QoS contract**; there is no portable guest-visible L1/L2/L3 cache inventory or cache-sharing-topology plane, no portable CAT / CDP / CMT cache-allocation-or-monitoring plane, owner-local cache masking / partitioning / monitoring stays implementation-local, and reviewed CPU / placement / performance meaning stays on explicit admission / topology / observation seams rather than ambient cache descriptors or QoS knobs
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the seam is discoverable from the main microVM narrative instead of existing as an orphan
- add `tools/check_microvm_cache_hierarchy_posture.py`, register `I-MICROVM-49`, `PO-MICROVM-CACHEHIER`, and `EVID-2026-443`, and make `make lint` reject drift where `ext.microvm` quietly grows reviewed cache-descriptor / cache-sharing / cache-partition-or-monitor meaning as a portable contract

## Revised435 (2026-03-17)
- pin the exact **microVM NUMA-topology posture v0** so guest-visible NUMA nodes, locality matrices, and heterogeneous-memory hint folklore do not quietly become a portable ambient placement / compatibility plane:
  - add `docs/30-architecture/microvm-numa-topology-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible NUMA / proximity-domain contract**; there is no portable guest NUMA-node / CPU-to-node / memory-to-node plane, no portable SLIT-distance or HMAT latency-bandwidth-memory-side-cache plane, owner-local locality shaping stays implementation-local, and reviewed memory / CPU / placement meaning stays on explicit admission / topology seams rather than ambient guest locality tables
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the seam is discoverable from the main microVM narrative instead of existing as an orphan
- add `tools/check_microvm_numa_topology_posture.py`, register `I-MICROVM-48`, `PO-MICROVM-NUMA`, and `EVID-2026-442`, and make `make lint` reject drift where `ext.microvm` quietly grows reviewed guest NUMA-node / CPU-to-node / memory-to-node meaning, SLIT/HMAT locality tables, or heterogeneous-memory folklore as a portable contract

## Revised434 (2026-03-17)
- pin the exact **microVM nested-virtualization posture v0** so guest hypervisor capability and nested-specific assist folklore do not quietly become a portable ambient compatibility / control plane:
  - add `docs/30-architecture/microvm-nested-virt-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible nested-virtualization contract**; there is no portable VMX / SVM / guest-hypervisor-acceleration plane, no portable nested-specific enlightenment-or-assist plane, owner-local nested enablement and CPU-feature passthrough stay implementation-local, and reviewed compatibility / isolation meaning stays on explicit `D-FCELL` and activation seams rather than ambient guest hypervisor capability
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-cpu-topology-posture-v0.md`, `docs/30-architecture/microvm-paravirt-enlightenment-posture-v0.md`, `docs/30-architecture/foreign-cell-contract.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_nested_virt_posture.py`, register `EVID-2026-441`, and make lint reject drift where `ext.microvm` quietly grows a reviewed VMX / SVM / guest-hypervisor-acceleration plane, where owner-local nested enablement / CPU-feature passthrough or nested-specific assists become portable API meaning, or where ambient guest-hypervisor capability displaces explicit sealed-compat / activation seams without an RFC-first design

## Revised433 (2026-03-17)
- pin the exact **microVM memory-dedup posture v0** so host-side page sharing and mergeable-memory tuning do not quietly become a portable ambient density / tenancy plane:
  - add `docs/30-architecture/microvm-memory-dedup-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient host-side guest-memory-dedup contract**; there is no portable `mem-merge` / mergeable-memory / KSM plane, no portable merged-page / page-sharing-status plane, owner-local `MADV_MERGEABLE` / KSM scan policy stays implementation-local, and reviewed memory-isolation / tenancy meaning stays on explicit admission / topology seams rather than ambient content-based page sharing
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_memory_dedup_posture.py`, register `EVID-2026-440`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `mem-merge` / mergeable-memory / KSM plane, where owner-local `MADV_MERGEABLE` / KSM scan policy becomes portable API meaning, or where ambient content-based page sharing displaces explicit admission / topology seams without an RFC-first design

## Revised432 (2026-03-17)
- pin the exact **microVM debug/introspection posture v0** so host-side debugger sockets and memory-dump workflows do not quietly become a portable ambient observation / control plane:
  - add `docs/30-architecture/microvm-debug-introspection-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient host-side guest-debug or memory-introspection contract**; there is no portable gdbstub / remote-debug plane, no portable guest-memory-dump / vmcore-export plane, no portable physical-memory-exam or debug-attach transport/auth contract, owner-local debug socket / dump file / monitor relay setup stays implementation-local, and reviewed observation / inspection / crash evidence stays on explicit `D-OBS` / `D-INSPECT` / `CH-CRASHCAP` seams rather than ambient VMM debug endpoints
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_debug_introspection_posture.py`, register `EVID-2026-439`, and make lint reject drift where `ext.microvm` quietly grows a reviewed gdbstub / remote-debug / dump-guest-memory / vmcore-export plane, where owner-local debug socket / dump file / monitor relay setup becomes portable API meaning, or where ambient VMM debugging folklore displaces explicit observation / inspection / crash-evidence seams without an RFC-first design

## Revised431 (2026-03-17)
- pin the exact **microVM persistent-memory posture v0** so guest-visible durable-memory devices and pmem-backed rootfs shortcuts do not quietly become a portable ambient storage / durability / boot plane:
  - add `docs/30-architecture/microvm-persistent-memory-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible persistent-memory contract**; there is no portable `virtio-pmem` / NVDIMM / persistent-memory-flush-or-durability plane, no portable boot-from-pmem or DAX-rootfs contract, owner-local backing-file / DAX / flush discipline stays implementation-local, and reviewed storage / provenance / boot meaning stays on explicit block / verity / activation seams rather than ambient guest pmem devices
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_persistent_memory_posture.py`, register `EVID-2026-438`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `virtio-pmem` / NVDIMM / persistent-memory-flush-or-durability plane, where owner-local backing-file / DAX / flush discipline becomes portable API meaning, or where pmem-backed rootfs folklore displaces explicit block / verity / activation seams without an RFC-first design

## Revised430 (2026-03-17)
- add a focused **microVM posture-family coverage guardrail** so the growing microVM posture-doc line stays discoverable as one reviewed profile surface instead of drifting into orphan docs:
  - add `tools/check_microvm_posture_family_coverage.py`, making lint require every non-profile microVM posture doc to stay referenced from `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, and `docs/00-meta/profile-posture-matrix.md`, and to keep a matching `check_microvm_<name>_posture.py` drift gate plus a `tools/README.md` entry
  - fix the concrete discovery miss the new guardrail found by wiring `docs/30-architecture/microvm-snapshot-posture-v0.md` back into `docs/30-architecture/microvm-profile-posture-v0.md`, and update `docs/00-meta/llm-runbook.md` so future microVM posture edits keep the central profile doc + matching drift gate honest
- register `EVID-2026-437` so archive hygiene can reject future microVM posture-family omissions before they become LLM amnesia or review drift

## Revised429 (2026-03-17)
- pin the exact **microVM live-migration posture v0** so cross-host switchover and failover machinery do not quietly become a portable ambient continuity / transport / orchestration plane:
  - add `docs/30-architecture/microvm-live-migration-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient live-migration contract**; there is no portable precopy / postcopy / stop-and-copy / failover plane, no portable migration-channel / URI / auth contract, no portable convergence / downtime / device-state-transfer contract, owner-local migration orchestration stays implementation-local, and reviewed continuity / activation / snapshot / topology meaning stays on already-pinned explicit seams rather than ambient VMM migration machinery
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_live_migration_posture.py`, register `EVID-2026-436`, and make lint reject drift where `ext.microvm` quietly grows a reviewed live-migration / postcopy / failover plane, where owner-local migration-channel / URI / auth or convergence / device-transfer semantics become portable API meaning, or where ambient VMM migration machinery displaces explicit activation / evidence / snapshot seams without an RFC-first design

## Revised428 (2026-03-17)
- pin the exact **microVM management-API posture v0** so host-side VMM control endpoints do not quietly become a portable ambient lifecycle/observation/admin plane:
  - add `docs/30-architecture/microvm-management-api-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient host-side microVM management API contract**; there is no portable monitor / QMP / REST / D-Bus control plane, no portable lifecycle-config-mutation plane, no portable VM-info-events-counters plane, owner-local API socket/path/transport/auth setup stays implementation-local, and reviewed lifecycle / observation / topology / snapshot meaning stays on already-pinned explicit seams rather than ambient VMM control endpoints
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_management_api_posture.py`, register `EVID-2026-435`, and make lint reject drift where `ext.microvm` quietly grows a reviewed monitor / QMP / REST / D-Bus control plane, where owner-local API socket/path/transport/auth setup becomes portable API meaning, or where ambient VMM control endpoints displace explicit lifecycle / observation / topology / snapshot seams without an RFC-first design

## Revised427 (2026-03-17)
- pin the exact **microVM virtio-serial/named-port posture v0** so console-adjacent helper channels do not quietly become a portable ambient data / control / helper plane:
  - add `docs/30-architecture/microvm-virtio-serial-port-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible `virtio-serial` / named-port contract**; there is no portable `virtio-serial` / `virtconsole` / `virtserialport` / guest-named-port plane, owner-local channel naming and host-path wiring stay implementation-local, and reviewed transfer / lifecycle / helper meaning rides on already-pinned explicit seams rather than ambient guest ports
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_virtio_serial_port_posture.py`, register `EVID-2026-434`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `virtio-serial` / `virtconsole` / `virtserialport` / guest-named-port plane, where owner-local channel naming or host-path wiring becomes portable API meaning, or where named-port helper folklore displaces explicit console / transfer / guest-agent seams without an RFC-first design

## Revised426 (2026-03-17)
- pin the exact **microVM clipboard/drag-drop posture v0** so desktop helper conveniences do not quietly become a portable ambient host↔guest transfer plane:
  - add `docs/30-architecture/microvm-clipboard-dragdrop-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient host↔guest clipboard/drag-drop integration contract**; there is no portable shared-clipboard / drag-drop / guest-tools file-transfer plane, owner-local desktop-helper integration setup stays implementation-local, and reviewed transfer / file / clipboard meaning rides on explicit D-PLUMB seams rather than ambient desktop-helper channels
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_clipboard_dragdrop_posture.py`, register `EVID-2026-433`, and make lint reject drift where `ext.microvm` quietly grows a reviewed shared-clipboard / drag-drop / guest-tools file-transfer plane, where owner-local desktop-helper integration setup becomes portable API meaning, or where desktop-helper convenience transfer folklore displaces explicit D-PLUMB seams without an RFC-first design

## Revised425 (2026-03-17)
- pin the exact **microVM USB-redirection posture v0** so remote USB forwarding and client-device redirection do not quietly become a portable ambient device / control / credential plane:
  - add `docs/30-architecture/microvm-usb-redirection-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible USB-redirection contract**; there is no portable `usbredir` / SPICE USB-redirection / smartcard-redirection / host-USB-forwarding plane, owner-local client-device forwarding setup stays implementation-local, and reviewed device / capture / credential meaning rides on already-pinned explicit seams rather than ambient redirected USB buses
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_usb_redirection_posture.py`, register `EVID-2026-432`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `usbredir` / SPICE USB-redirection / smartcard-redirection / host-USB-forwarding plane, where owner-local client-device forwarding setup becomes portable API meaning, or where redirected USB folklore displaces explicit device / capture / credential seams without an RFC-first design

## Revised424 (2026-03-17)
- pin the exact **microVM guest-agent posture v0** so in-guest management helpers do not quietly become a portable ambient lifecycle / file / metadata / time / snapshot / control plane:
  - add `docs/30-architecture/microvm-guest-agent-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-agent contract**; there is no portable lifecycle-file-admin plane, no portable metadata-heartbeat-observation plane, no portable quiesce-time-sync-snapshot-assist plane, owner-local guest-agent installation/enabling stays implementation-local, and reviewed lifecycle / file / observation / time / bootstrap meaning rides on already-pinned explicit seams rather than ambient host↔guest management daemons
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/30-architecture/microvm-lifecycle-signal-posture-v0.md`, `docs/30-architecture/microvm-bootstrap-metadata-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_guest_agent_posture.py`, register `EVID-2026-431`, and make lint reject drift where `ext.microvm` quietly grows a reviewed QEMU Guest Agent / Hyper-V integration-services / VMware Tools lifecycle, exec/file-copy, metadata/heartbeat, or quiesce/time-sync plane without an RFC-first design

## Revised423 (2026-03-17)
- pin the exact **microVM semihosting posture v0** so trap-driven debug-host facilities do not quietly become a portable ambient guest-visible file / console / bootstrap / time plane:
  - add `docs/30-architecture/microvm-semihosting-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible semihosting contract**; there is no portable Arm semihosting trap / operation plane, no portable semihosting target / userspace / arg plane, no portable host file / debugger-console / command / time plane, owner-local semihosting enablement/routing stays implementation-local, and reviewed file / console / time / bootstrap meaning rides on already-pinned explicit seams rather than ambient debug-host trap calls
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/30-architecture/microvm-bootstrap-metadata-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_semihosting_posture.py`, register `EVID-2026-430`, and make lint reject drift where `ext.microvm` quietly grows a reviewed semihosting trap / operation contract, target-routing/userspace/arg admin plane, or ambient host file / debugger-console / command / time channel without an RFC-first design

## Revised422 (2026-03-17)
- pin the exact **microVM paravirtual-enlightenment posture v0** so hypervisor-specific KVM PV features, Hyper-V enlightenments, Xen PV coordination ABIs, and helper hypercalls do not quietly become a portable ambient guest-visible control/observation/time plane:
  - add `docs/30-architecture/microvm-paravirt-enlightenment-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible paravirtual-enlightenment contract**; there is no portable KVM-paravirt-feature / MSR / shared-page / hypercall plane, no portable Hyper-V-enlightenment / SynIC / VMBus plane, no portable Xen-hypercall / event-channel / grant-table / XenStore plane, owner-local hypervisor-assist exposure stays implementation-local, and reviewed time / interrupt / profiling / channel meaning rides on already-pinned explicit seams rather than ambient hypervisor-specific guest ABIs
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/30-architecture/observation-export-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_paravirt_enlightenment_posture.py`, register `EVID-2026-429`, and make lint reject drift where `ext.microvm` quietly grows a reviewed KVM / Hyper-V / Xen paravirt-assist plane, where owner-local hypervisor-assist exposure becomes portable API meaning, or where ambient hypervisor-specific guest ABIs displace explicit time / interrupt / observation / channel seams without an RFC-first design

## Revised421 (2026-03-17)
- pin the exact **microVM PMU/profiling posture v0** so guest perf counters, overflow interrupts, and hardware-tracing folklore do not quietly become a portable ambient observation/admin plane:
  - add `docs/30-architecture/microvm-pmu-profiling-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible PMU/profiling contract**; there is no portable PMU-version / counter / PMI / PMU-filter plane and no portable `LBR` / `Intel PT` / `PEBS` / `IBS` / `SPE` profiling plane, owner-local vPMU/profiler virtualization stays implementation-local, and reviewed profiling/observation meaning rides on explicit D-OBS / D-TRACE seams rather than ambient guest counters, interrupts, or trace buffers
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/observation-export-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_pmu_profiling_posture.py`, register `EVID-2026-428`, and make lint reject drift where `ext.microvm` quietly grows a reviewed PMU version / PMI / PMU-filter or hardware-tracing plane, where owner-local vPMU/profiler virtualization becomes portable API meaning, or where ambient guest counters displace explicit D-OBS / D-TRACE seams without an RFC-first design

## Revised420 (2026-03-17)
- pin the exact **microVM crash-report surface posture v0** so guest panic devices, dump-note channels, and persistent crash stores do not quietly become a portable ambient evidence/admin plane:
  - add `docs/30-architecture/microvm-crash-report-surface-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible crash-reporting contract**; there is no portable `pvpanic` / `vmcoreinfo` / `pstore`-ERST-ramoops plane, owner-local panic notification and crash-record storage stay implementation-local, and shareable failure evidence rides on explicit D-OBS / D-INSPECT / D-FLIGHTREC / `CH-CRASHCAP` seams rather than ambient guest devices, firmware tables, or filesystems
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/observation-export-posture-v0.md`, `docs/30-architecture/crash-capsule-schema-v0.md`, `docs/30-architecture/flight-recorder-policy-schema-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_crash_report_surface_posture.py`, register `EVID-2026-427`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `pvpanic` / `vmcoreinfo` / `pstore`-ERST-ramoops plane, where owner-local panic notification or crash-record storage become portable API meaning, or where guest-visible crash folklore displaces explicit observation and crash-capsule seams without an RFC-first design

## Revised419 (2026-03-17)
- pin the exact **microVM firmware-state posture v0** so UEFI variable storage, boot-order NVRAM, and Secure Boot enrollment folklore do not quietly become a portable ambient guest-visible admin/provenance plane:
  - add `docs/30-architecture/microvm-firmware-state-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible firmware-state contract**; there is no portable UEFI variable-store / `Boot####`-`BootOrder`-`BootNext` plane, no portable Secure-Boot key-enrollment or signature-database plane, owner-local firmware-state persistence/protection stays implementation-local, and provenance/lifecycle meaning stays on explicit activation and attestation evidence rather than ambient firmware-variable reads
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-firmware-description-posture-v0.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_firmware_state_posture.py`, register `EVID-2026-426`, and make lint reject drift where `ext.microvm` quietly grows a reviewed UEFI variable-store / boot-order / Secure-Boot-key plane, where owner-local firmware-state persistence/protection becomes portable API meaning, or where firmware-variable folklore displaces explicit activation/attestation evidence without an RFC-first design

## Revised418 (2026-03-17)
- pin the exact **microVM time-source posture v0** so `kvm-clock`, RTC mode, and guest-visible wall-clock repair/admin folklore do not quietly become a portable ambient guest-time contract:
  - add `docs/30-architecture/microvm-time-source-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible time-source contract**; there is no portable clocksource-name / RTC-base / clock-progression or guest-visible set-clock plane, owner-local clocksource shaping remains implementation-local, and authority-bearing time still rides on explicit D-NONDET / D-TIMEPROOF seams rather than ambient guest time reads
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-clock-disruption-posture-v0.md`, `docs/30-architecture/nondet-posture-v0.md`, `docs/30-architecture/timeproof-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_time_source_posture.py`, register `EVID-2026-425`, and make lint reject drift where `ext.microvm` quietly grows a reviewed clocksource-name or RTC-policy contract, where owner-local wall-clock shaping becomes portable API meaning, or where a guest-visible set-clock / source-switch admin plane appears without an explicit RFC-first design

## Revised417 (2026-03-17)
- pin the exact **microVM firmware-description posture v0** so `ext.microvm` does not quietly grow a guest-visible ACPI / device-tree / firmware-table hardware-description contract:
  - add `docs/30-architecture/microvm-firmware-description-posture-v0.md`, fixing Phase 1 so `ext.microvm` adds no portable ACPI table-set / namespace / AML plane, no portable device-tree node/path/property vocabulary, and no portable EFI configuration-table / firmware-table inventory or override plane; owner-local ACPI-vs-DTB-vs-firmware choice remains implementation-local and portable meaning stays on the already-pinned bus / interrupt / lifecycle / bootstrap / identity seams rather than ambient table probes
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_firmware_description_posture.py`, register `EVID-2026-424`, and make lint reject drift where `ext.microvm` quietly grows a reviewed ACPI / device-tree / EFI hardware-description plane, where firmware-table vocabulary becomes portable API meaning, or where live table override/update semantics appear without an explicit RFC-first design

## Revised416 (2026-03-17)

- add `docs/30-architecture/microvm-shared-memory-doorbell-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible shared-memory / doorbell device contract**; there is no portable `ivshmem-plain` / `ivshmem-doorbell` / `ivshmem-flat` / peer-id / shared-memory-region / interrupt-doorbell plane, owner-local shared-memory server / FD / eventfd distribution stays implementation-local, and reviewed shared-region meaning stays on explicit D-IOBUF / D-PLUMB seams rather than ambient guest BARs or peer-notify devices
- wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_shared_memory_doorbell_posture.py`, register `EVID-2026-423`, and make lint reject drift where `ext.microvm` quietly grows a reviewed ivshmem / peer-doorbell / guest-visible shared-memory plane, where owner-local shared-memory server or FD/eventfd distribution becomes portable API meaning, or where ambient guest BARs displace explicit D-IOBUF / D-PLUMB seams without an RFC-first design

## Revised415 (2026-03-16)

- add `docs/30-architecture/microvm-audio-capture-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible audio/capture device contract**; there is no portable `virtio-snd` / playback-capture-stream-mixer-jack-chmap plane, owner-local audio-backend/media-graph choice stays implementation-local, and microphone/system-audio capture meaning stays on explicit D-CAPTURE / D-UICAP / D-PLUMB seams rather than ambient guest devices
- wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/capture-portal-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_audio_capture_posture.py`, register `EVID-2026-422`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `virtio-snd` / playback-capture-stream-mixer-jack-chmap plane, where owner-local audio-routing or media-graph choices become portable API meaning, or where guest sound devices displace explicit D-CAPTURE / D-UICAP / D-PLUMB seams without an RFC-first design

## Revised414 (2026-03-16)

- add `docs/30-architecture/microvm-interrupt-topology-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible interrupt topology / irqchip contract**; there is no portable APIC / PIC / IOAPIC / GIC controller-model plane, no portable IRQ / GSI / vector / MSI routing or interrupt-remapping plane, owner-local irqchip mode / controller placement / vector-allocation policy stay implementation-local, and policy-significant interrupt-topology changes require new admission rather than a live guest-visible rewire plane
- wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_interrupt_topology_posture.py`, register `EVID-2026-421`, and make lint reject drift where `ext.microvm` quietly grows a reviewed APIC / PIC / IOAPIC / GIC controller-model contract, stable IRQ / GSI / vector / MSI routing or interrupt-remapping semantics, or a live irqchip-admin plane without an RFC-first design

## Revised413 (2026-03-16)

- add `docs/30-architecture/microvm-platform-identity-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible platform identity / fingerprinting contract**; there is no portable CPUID vendor / brand / hypervisor-signature plane, no portable SMBIOS / DMI manufacturer / product / serial / UUID / OEM-string identity plane, owner-local branding and feature-masking stay implementation-local, and provenance / attestation meaning stays on explicit evidence rather than ambient guest probes
- wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_platform_identity_posture.py`, register `EVID-2026-420`, and make lint reject drift where `ext.microvm` quietly grows a reviewed CPUID or SMBIOS/DMI identity contract, live retag plane, or ambient attestation-by-branding story without an RFC-first design

## Revised412 (2026-03-16)
- pin the exact **microVM bus-topology posture v0** so PCI-vs-MMIO transport choice, BDF/slot naming, and bus-rescan folklore do not quietly become a portable ambient guest-visible admin plane:
  - add `docs/30-architecture/microvm-bus-topology-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible device-bus topology contract**; there is no portable PCI-vs-MMIO transport promise, no stable PCI-BDF / segment / root-port / slot / ACPI-device-path inventory contract, and no portable bus-rescan / hotplug / address-assignment plane, so owner-local bus layout stays implementation-local and policy-significant topology changes still require new admission rather than a live bus-admin control plane
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-device-passthrough-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_bus_topology_posture.py`, register `EVID-2026-419`, and make lint reject drift where `ext.microvm` quietly grows a reviewed PCI-vs-MMIO transport contract, stable BDF / slot / ACPI-path inventory meaning, or a bus-rescan / hotplug / address-assignment plane without an RFC-first design

## Revised411 (2026-03-16)
- pin the exact **microVM display/input posture v0** so paravirtual GPUs, scanouts, and host-backed input plumbing do not quietly become a portable ambient host↔guest UI/control plane:
  - add `docs/30-architecture/microvm-display-input-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible display/input device contract**; there is no portable `virtio-gpu` / scanout-EDID-cursor-capset / `virtio-input` / raw-input-event-device-inventory plane, owner-local renderer-backend/input-plumbing choice remains implementation-local, and UI/capture/remote-control meaning still rides on explicit D-UICAP / D-PLUMB seams rather than ambient guest devices
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/30-architecture/uicap-scope-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_display_input_posture.py`, register `EVID-2026-418`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `virtio-gpu` / scanout / EDID / cursor / capset / `virtio-input` / raw-input-event-device-inventory plane, where owner-local renderer stacks or host input plumbing become portable API meaning, or where guest UI devices displace explicit D-UICAP / D-PLUMB seams without an RFC-first design

## Revised410 (2026-03-16)
- pin the exact **microVM lifecycle-signal posture v0** so graceful shutdown/reset/watchdog folklore does not quietly become a portable ambient host↔guest lifecycle control plane:
  - add `docs/30-architecture/microvm-lifecycle-signal-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible lifecycle-signal contract**; there is no portable ACPI power-button / i8042-or-PL061 shutdown-reboot key / suspend-wakeup / reset-cause / watchdog-action plane, owner-local lifecycle-signal injection and reaction policy remain implementation-local, and microVM start-stop-reset authority still rides on explicit D-ACTIVATE supervision rather than ambient in-band guest device signals
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/activation-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_lifecycle_signal_posture.py`, register `EVID-2026-417`, and make lint reject drift where `ext.microvm` quietly grows a reviewed ACPI power-button / shutdown-reboot-key / suspend-wakeup / reset-cause / watchdog-action plane, where owner-local lifecycle-signal policy becomes portable API meaning, or where graceful shutdown ergonomics displace explicit D-ACTIVATE supervision without an RFC-first design

## Revised409 (2026-03-16)
- pin the exact **microVM backend-offload posture v0** so `vhost-user`, vDPA/VDUSE, and backend socket folklore do not quietly become a portable ambient host control plane:
  - add `docs/30-architecture/microvm-backend-offload-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient host-side backend-offload contract**; there is no portable `vhost-user` / `vhost-vdpa` / `VDUSE` / backend-socket / queue-handoff / backend-rebind-status plane, owner-local backend process/device selection remains implementation-local, and device/network authority still rides on explicit D-IOLEASE / D-NETLEASE seams plus already-pinned guest-visible topology postures rather than ambient backend channels
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_backend_offload_posture.py`, register `EVID-2026-416`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `vhost-user` / `vhost-vdpa` / `VDUSE` / backend-socket / queue-handoff / backend-rebind-status plane, where owner-local backend process or device selection becomes portable API meaning, or where backend daemons/socket plumbing displace explicit D-IOLEASE / D-NETLEASE seams without an RFC-first design

## Revised408 (2026-03-16)
- pin the exact **microVM virtual-IOMMU posture v0** so `virtio-iommu`, endpoint attachment, and guest DMA-remap controls do not quietly become a portable ambient host↔guest authority plane:
  - add `docs/30-architecture/microvm-virtual-iommu-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible vIOMMU contract**; there is no portable `virtio-iommu` / domain-endpoint-attach / map-unmap / fault-status / address-width plane, owner-local vIOMMU enablement and endpoint placement remain implementation-local, and DMA meaning still rides on explicit D-DMA / D-IOLEASE seams rather than ambient guest remap control
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/dma-posture-v0.md`, `docs/30-architecture/microvm-device-passthrough-posture-v0.md`, `docs/30-architecture/virtio-iommu-mechanism-note.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_virtual_iommu_posture.py`, register `EVID-2026-415`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `virtio-iommu` / endpoint-attach / map-unmap / fault-status / address-width plane, where owner-local enablement or address-width choices become portable API meaning, or where guest vIOMMU control displaces explicit D-DMA / D-IOLEASE seams without an RFC-first design

## Revised407 (2026-03-16)
- pin the exact **microVM device-passthrough posture v0** so VFIO, mediated devices, and direct-assigned hardware do not quietly become the ambient DMA/device authority path:
  - add `docs/30-architecture/microvm-device-passthrough-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible device-passthrough contract**; there is no portable VFIO / PCI-BDF / IOMMU-group / SR-IOV-VF / mediated-device / BAR-reset-interrupt plane, owner-local host binding and attachment details remain implementation-local, and DMA-class device authority still rides on explicit D-DMA / D-IOLEASE seams rather than ambient guest passthrough devices
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/dma-posture-v0.md`, `docs/30-architecture/io-lease-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_device_passthrough_posture.py`, register `EVID-2026-414`, and make lint reject drift where `ext.microvm` quietly grows a reviewed VFIO / PCI-BDF / IOMMU-group / SR-IOV / mediated-device / reset-interrupt device plane, where owner-local host binding or group selection becomes portable API meaning, or where guest passthrough devices displace explicit D-DMA / D-IOLEASE seams without an RFC-first design

## Revised406 (2026-03-16)
- pin the exact **microVM TPM-surface posture v0** so guest-visible TPM devices do not quietly become the ambient attestation / sealing authority path:
  - add `docs/30-architecture/microvm-tpm-surface-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible TPM/vTPM contract**; there is no portable TPM2 command-status / PCR-bank / NV-index / sealing-unsealing / attestation-document plane, owner-local TPM enablement and backend choice remain implementation-local, and attestation/key-sealing meaning still rides on explicit D-ATTEST / D-CRYPTOSVC seams rather than ambient guest TPM device calls
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_tpm_surface_posture.py`, register `EVID-2026-413`, and make lint reject drift where `ext.microvm` quietly grows a reviewed TPM 2.0 / PCR / NV / sealing / attestation-document device plane, where owner-local NitroTPM / `swtpm` / passthrough choices become portable API meaning, or where guest TPM calls displace explicit D-ATTEST / D-CRYPTOSVC seams without an RFC-first design

## Revised405 (2026-03-16)
- pin the exact **microVM entropy-surface posture v0** so host-backed RNG devices and source-selection folklore do not quietly become an ambient guest authority plane:
  - add `docs/30-architecture/microvm-entropy-surface-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no portable ambient guest-visible entropy device/source contract**; there is no portable `virtio-rng` / CPU-HWRNG / RNG-backend-source / entropy-quality-status plane, owner-local boot seeding remains implementation-local, and when D-NONDET is enabled post-init entropy authority still rides on explicit `portal.entropy` / `CH-ENTROPY` seams rather than ambient guest device reads
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/nondet-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_entropy_surface_posture.py`, register `EVID-2026-412`, and make lint reject drift where `ext.microvm` quietly grows a reviewed `virtio-rng` / CPU-HWRNG / entropy-source-status contract, where owner-local boot seeding becomes a portable post-init authority path, or where changing the entropy surface under the same admitted leaf identity is treated as a live control plane without an explicit RFC-first design

## Revised404 (2026-03-16)
- pin the exact **microVM bootstrap-metadata posture v0** so `ext.microvm` does not quietly grow an ambient guest-readable metadata / config-injection plane:
  - add `docs/30-architecture/microvm-bootstrap-metadata-posture-v0.md`, fixing Phase 1 so `ext.microvm` exposes **no ambient guest-readable metadata/bootstrap channel**; there is no portable MMDS / IMDS / fw_cfg / config-drive / cloud-init datasource plane, and bootstrap authority must ride on reviewed boot artifacts or explicit post-boot seams rather than a hidden host control path
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_bootstrap_metadata_posture.py`, register `EVID-2026-411`, and make lint reject drift where `ext.microvm` quietly grows a reviewed MMDS / IMDS / fw_cfg / config-drive / cloud-init datasource plane, where bootstrap bytes/credentials become ambient guest-readable runtime API meaning, or where changing bootstrap data under the same admitted leaf identity is treated as a live metadata-update control surface without an explicit RFC-first design

## Revised403 (2026-03-16)
- pin the exact **microVM serial/console posture v0** so debug plumbing does not quietly grow into an ambient host↔guest control path:
  - add `docs/30-architecture/microvm-console-channel-posture-v0.md`, fixing Phase 1 so guest-visible serial/console presence + directionality stay **fixed at admission**; `ext.microvm` adds no portable interactive serial/console input, no console/monitor multiplex, no runtime backend-rebind/status plane, and any admitted serial/console surface is off/null or a write-only diagnostic sink rather than a host control channel
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/host-guest-channel-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_console_channel_posture.py`, register `EVID-2026-410`, and make lint reject drift where `ext.microvm` quietly grows a reviewed interactive console input path, where console/monitor multiplex or backend-status semantics become portable API meaning, or where debug serial plumbing becomes an ambient host control channel without an explicit RFC-first design

## Revised402 (2026-03-16)
- pin the exact **microVM block-topology posture v0** so `ext.microvm` does not quietly grow a guest-visible disk hotplug / media-insert-eject / tray-status control plane:
  - add `docs/30-architecture/microvm-block-topology-posture-v0.md`, fixing Phase 1 so guest-visible block-device inventory/topology stays **fixed at admission**; `ext.microvm` adds no portable disk hotplug / hot-remove / media-insert-eject / tray-or-device-status plane, no max-disk-or-slot inventory API, and changing guest-visible block-device inventory/topology means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_block_topology_posture.py`, register `EVID-2026-409`, and make lint reject drift where `ext.microvm` quietly grows a reviewed disk hotplug / media-insert-eject / tray-status plane, where max-disk / hotpluggable-slot / removable-media semantics become portable API meaning, or where guest-visible block-device topology changes under the same admitted leaf identity without an explicit RFC-first design

## Revised401 (2026-03-16)
- pin the exact **microVM network-topology posture v0** so `ext.microvm` does not quietly grow a guest-visible NIC hotplug / attach-detach / link-state control plane:
  - add `docs/30-architecture/microvm-network-topology-posture-v0.md`, fixing Phase 1 so guest-visible network-interface inventory/topology stays **fixed at admission**; `ext.microvm` adds no portable NIC hotplug / attach-detach / link-state / interface-status plane, no max-interface-or-slot inventory API, and changing guest-visible NIC inventory/topology means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_network_topology_posture.py`, register `EVID-2026-408`, and make lint reject drift where `ext.microvm` quietly grows a reviewed NIC hotplug / attach-detach / link-state plane, where interface-slot or link-status semantics become portable API meaning, or where guest-visible NIC topology changes under the same admitted leaf identity without an explicit RFC-first design

## Revised400 (2026-03-16)
- pin the exact **microVM CPU-topology posture v0** so `ext.microvm` does not quietly grow a guest-visible vCPU hotplug / online-offline / slot-status control plane:
  - add `docs/30-architecture/microvm-cpu-topology-posture-v0.md`, fixing Phase 1 so guest-visible vCPU count/topology stays **fixed at admission**; `ext.microvm` adds no portable vCPU hotplug / CPU online-offline / hotpluggable-slot semantics, no max-vCPU / boot-vCPU-vs-max-vCPU / slot-inventory API, and changing guest-visible CPU topology or SMT means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_cpu_topology_posture.py`, register `EVID-2026-407`, and make lint reject drift where `ext.microvm` quietly grows a reviewed vCPU hotplug / CPU online-offline / hotpluggable-slot plane, where max-vCPU-or-slot semantics become portable API meaning, or where guest-visible CPU topology changes under the same admitted leaf identity without an explicit RFC-first design

## Revised399 (2026-03-16)
- pin the exact **microVM memory-topology posture v0** so `ext.microvm` does not quietly grow a guest-visible balloon / hotplug / resize-status control plane:
  - add `docs/30-architecture/microvm-memory-topology-posture-v0.md`, fixing Phase 1 so guest-visible RAM size/topology stays **fixed at admission**; `ext.microvm` adds no portable balloon / virtio-mem / ACPI memory-hotplug semantics, no target-size / plugged-size / stats / hinting API, and changing guest-visible RAM means admitting a new reviewed leaf/activation rather than mutating a running guest under the same portable identity
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_memory_topology_posture.py`, register `EVID-2026-406`, and make lint reject drift where `ext.microvm` quietly grows a reviewed balloon / virtio-mem / ACPI memory-hotplug plane, where target-size/stats/hinting semantics become portable API meaning, or where guest-visible RAM changes under the same admitted leaf identity without an explicit RFC-first design

- pin the exact **microVM template-availability posture v0** so reusable warm-start leaves do not quietly become a cache-residency or readiness contract:
  - add `docs/30-architecture/microvm-template-availability-posture-v0.md`, fixing Phase 1 so reusable warm-start leaves remain **owner-local, semantically optional accelerators**; owners may evict/deactivate/regenerate them locally without changing the reviewed cold parent lineage, portable correctness cannot depend on one exact leaf remaining cached, and Phase 1 adds no public warm-cache hit/miss or `Pending` / `Active` / `Inactive` lifecycle plane
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/30-architecture/microvm-template-distribution-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_template_availability_posture.py`, register `EVID-2026-405`, and make lint reject drift where one warm leaf quietly becomes a portable cache-residency promise, where owner-local evict/regenerate behavior is mistaken for a release-identity change, or where Phase 1 grows a public warm-cache status / lifecycle plane without an RFC-first design

## Revised397 (2026-03-16)
- pin the exact **microVM template-distribution posture v0** so reusable warm-start leaves do not quietly become a portable/public artifact class:
  - add `docs/30-architecture/microvm-template-distribution-posture-v0.md`, fixing Phase 1 so reusable warm-start template leaves and owner-local recovery checkpoints remain **owner-local admission accelerators**; portable distribution ships cold parent lineage such as `CH-BOOT` / `CH-INIT` / ordinary deployment artifacts, and each owner/runtime cuts/adopts warm leaves locally instead of importing shareable warm-state blobs
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/30-architecture/microvm-template-snapshot-cut-posture-v0.md`, `docs/30-architecture/microvm-template-lineage-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_template_distribution_posture.py`, register `EVID-2026-404`, and make lint reject drift where warm-state leaves become portable publish/share/import artifacts, where provider-local encrypted caching is mistaken for a public artifact contract, or where Phase 1 silently grows a new CH-schema / ACP / registry plane for warm-state distribution

## Revised396 (2026-03-16)
- pin the exact **microVM resume-admission evidence posture v0** so “which reusable warm-start leaf or owner-local checkpoint was resumed?” stops drifting into a guest-visible identity API or a hidden attestation/control-plane claim:
  - add `docs/30-architecture/microvm-resume-admission-evidence-posture-v0.md`, fixing Phase 1 so exact resumed leaf identity remains **admission-local provenance only** under the deployment owner; `VMGenID` / VMClock generation signals remain hygiene-only, resumed software cannot self-assert one exact admitted leaf as authority-bearing truth, and any exported leaf digest must ride on existing `CH-BOOT` / `CH-PROV` / deployment-receipt evidence rather than a new warm-state identity schema
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-attestation-scope-posture-v0.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/attestation-token-schema-v0.md`, `docs/30-architecture/boot-manifest-schema-v0.md`, `rfcs/0064-confidential-computing-profile.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_resume_admission_evidence_posture.py`, register `EVID-2026-403`, and make lint reject drift where exact resumed leaf identity becomes a guest-visible API, where `CH-ATTEST` or generation signals silently become warm-state identity claims, or where Phase 1 grows a new schema/ACP/control plane for snapshot-leaf identity instead of keeping it on owner-local provenance/admission evidence

## Revised395 (2026-03-16)
- pin the exact **microVM attestation-scope posture v0** so a fresh post-restore quote/report/token does not quietly become a proof of the exact resumed warm-start leaf:
  - add `docs/30-architecture/microvm-attestation-scope-posture-v0.md`, fixing Phase 1 so fresh post-restore `CH-ATTEST` remains bound to the current boot/provenance lineage and freshness exchange, while exact reusable leaf / checkpoint identity stays on separate explicit lineage/admission evidence rather than being inferred from attestation alone
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/microvm-attestation-reacquire-posture-v0.md`, `rfcs/0064-confidential-computing-profile.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_attestation_scope_posture.py`, register `EVID-2026-402`, and make lint reject drift where fresh post-restore attestation is treated as portable proof of one exact resumed warm-state leaf, where provider-specific runtime measurements silently become a cross-provider resumed-state contract, or where Phase 1 overloads `CH-ATTEST` / ACP with a new leaf-identity plane without explicit RFC/evidence cost

## Revised394 (2026-03-16)
- pin the exact **microVM restore-repair barrier posture v0** so reusable warm-start leaves cannot quietly discover restore hygiene by probing the outside world after resume:
  - add `docs/30-architecture/microvm-restore-repair-barrier-posture-v0.md`, fixing Phase 1 so resumed reusable leaves complete clone-sensitive repair **before any externally visible action or readiness claim**; the primary generation witness is observed first, clone-sensitive state is repaired/revalidated, and generation-scoped sessions/leases/attestation state are reacquired explicitly instead of being tested opportunistically
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-snapshot-posture-v0.md`, `docs/30-architecture/microvm-generation-witness-posture-v0.md`, `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_restore_repair_barrier_posture.py`, register `EVID-2026-401`, and make lint reject drift where resumed leaves emit externally visible effects before repair completes, where broken or apparently-still-live sessions become the restore oracle, or where Phase 1 silently standardizes a portable checkpoint-hook / restore-complete control plane

## Revised393 (2026-03-16)
- pin the exact **microVM template resume-class posture v0** so reusable warm-start leaves do not quietly turn host/kernel/CPU compatibility folklore into an ambient restore-anywhere promise:
  - add `docs/30-architecture/microvm-template-resume-class-posture-v0.md`, fixing Phase 1 so each reusable `ext.microvm` template leaf is admitted only under one exact reviewed resume class covering the relevant VMM/profile version, guest architecture, CPU feature class, and required kernel/microcode floors; heterogeneous fleets are normalized before the cut, and cross-class restore fails closed
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-template-lineage-posture-v0.md`, `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_template_resume_class_posture.py`, register `EVID-2026-400`, and make lint reject drift where reusable templates become best-effort cross-host portability promises, where heterogeneous fleets are normalized at restore time instead of before the cut, or where Phase 1 silently standardizes a new CH-schema / ACP surface for compatibility negotiation

## Revised392 (2026-03-16)
- pin the exact **microVM template-lineage posture v0** so reusable warm-start templates do not quietly become a public diff/base snapshot plane or a mutable deployment surface:
  - add `docs/30-architecture/microvm-template-lineage-posture-v0.md`, fixing Phase 1 so any reusable `ext.microvm` template is a **parent-bound, leaf-resumable derived accelerator** rather than a standalone deployable artifact; fan-out selects one resumable leaf bound to an exact parent deployment/template lineage, while diff/base layering, merge order, and chain maintenance remain implementation-local
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-template-snapshot-cut-posture-v0.md`, `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/60-engineering/system-generation-pipeline.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_template_lineage_posture.py`, register `EVID-2026-399`, and make lint reject drift where reusable templates become standalone deployment roots, where callers must reason about public diff/base layer chains or merge order, where template meaning mutates in place instead of publishing a new leaf, or where Phase 1 silently standardizes a snapshot-chain management surface without explicit ACP/ordering semantics

## Revised391 (2026-03-16)
- pin the exact **microVM template snapshot-cut posture v0** so warm-start fan-out cannot quietly freeze secret material or live imported authority into reusable templates:
  - add `docs/30-architecture/microvm-template-snapshot-cut-posture-v0.md`, fixing Phase 1 so any reusable `ext.microvm` warm-start template is cut **before** freshness-bound attestation state, unsealed secret material, live D-CAPRPC sessions/imports, or issued D-LEASE / D-NETLEASE handles enter guest memory; snapshots taken after that point remain owner-local recovery artifacts rather than ordinary fan-out bases
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-snapshot-posture-v0.md`, `docs/30-architecture/microvm-attestation-reacquire-posture-v0.md`, `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `docs/30-architecture/caprpc-session-posture-v0.md`, `docs/30-architecture/capability-lease-posture-v0.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_template_snapshot_cut_posture.py`, register `EVID-2026-398`, and make lint reject drift where reusable templates start including unsealed secret material or live imported authority, where post-secret checkpoints are rebranded as ordinary fan-out bases, or where the archive starts standardizing a new portable checkpoint-hook / wipe plane instead of keeping hook mechanisms implementation-local

## Revised390 (2026-03-16)
- pin the exact **microVM attestation-reacquire posture v0** so clone/restore acceleration cannot quietly turn cached attestation evidence or attestation-gated secret-release sessions into a hidden continuity plane:
  - add `docs/30-architecture/microvm-attestation-reacquire-posture-v0.md`, fixing Phase 1 so generation-witness change invalidates freshness-bound `CH-ATTEST` / `CH-ATTESTPACK` exports and attestation-gated release sessions; any later freshness/current-instance claim requires a fresh nonce/reportdata-style exchange, while provider-owned `D-APPSECRET` / `D-VAULT` objects keep their own narrower posture instead of being blanket-deleted
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/attestation-posture-v0.md`, `docs/30-architecture/app-secret-posture-v0.md`, `docs/30-architecture/vault-posture-v0.md`, `rfcs/0064-confidential-computing-profile.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_attestation_reacquire_posture.py`, register `EVID-2026-397`, and make lint reject drift where pre-restore attestation blobs/sessions get reused as current-instance freshness, where snapshot success silently resumes attestation-gated secret-release sessions, where generation change is detected via incidental transport breakage instead of the explicit witness, or where the archive starts claiming blanket deletion/rotation of all local app/vault secrets on clone/restore

## Revised389 (2026-03-16)
- pin the exact **microVM clock-disruption posture v0** so guest-visible precision time after clone/restore cannot quietly become a trusted continuity or secure-time story:
  - add `docs/30-architecture/microvm-clock-disruption-posture-v0.md`, fixing Phase 1 so clone-identity repair and clock-quality repair stay **orthogonal** under `ext.microvm`: VMClock `disruption_marker` / `clock_status` invalidate local clock refinements, `vm_generation_counter` / VMGenID remain the clone-identity witness, and guest clocks stay observational rather than proof/lease authority
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-generation-witness-posture-v0.md`, `docs/30-architecture/nondet-posture-v0.md`, `docs/30-architecture/timeproof-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_clock_disruption_posture.py`, register `EVID-2026-396`, and make lint reject drift where generation-witness and clock-disruption repair collapse back together, where broken transport/session side effects become the clock-quality detector, or where guest-visible clocks start masquerading as proof/lease authority outside explicit time seams

## Revised388 (2026-03-16)
- pin the exact **microVM generation-witness posture v0** so guest software has one explicit way to notice clone/restore events instead of inferring them from broken sessions or copied entropy:
  - add `docs/30-architecture/microvm-generation-witness-posture-v0.md`, fixing Phase 1 so any `ext.microvm` profile that depends on guest-side adaptation after snapshot/clone must surface **one explicit guest-visible generation witness** before first payload; prefer VMClock `vm_generation_counter` when available, otherwise VMGenID, and use that witness to reseed entropy, regenerate ephemeral instance ids/tokens, and invalidate clone-sensitive caches
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/microvm-profile-posture-v0.md`, `docs/30-architecture/microvm-snapshot-posture-v0.md`, `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/30-architecture/nondet-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_generation_witness_posture.py`, register `EVID-2026-395`, and make lint reject drift where snapshot/clone acceleration exists without a guest-visible generation witness, where VMClock/VMGenID folklore becomes a new interop/authority plane, or where restore detection is deferred to broken network/vsock/session side effects

## Revised387 (2026-03-16)
- pin the exact **microVM warm-restore boundary v0** so hosted-compute fast-start work cannot quietly become an ambient continuity plane:
  - add `docs/30-architecture/microvm-snapshot-posture-v0.md`, fixing Phase 1 so `ext.microvm` snapshot/restore/clone is an **implementation-local accelerator only**; restore resumes declared machine bytes, not ambient network/vsock/session continuity, and clone/restore must refresh entropy plus instance identity before first payload
  - wire the posture through `README.md`, `docs/README.md`, `docs/10-threat-model/deployment-profiles.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_microvm_snapshot_posture.py`, register `EVID-2026-394`, and make lint reject drift where warm restore starts implying ambient host↔guest continuity, copied entropy/instance identity folklore, or a hidden host-agent/resource-rebind contract outside explicit seams such as D-ACTIVATE / D-NETLEASE / D-CAPX

## Revised386 (2026-03-09)
- pin the exact **quarantined result-preview boundary v0** so even correct search/query hits cannot quietly regrow an ambient preview channel through snippets, thumbnails, preview panes, Quick Look cards, or hover previews:
  - add `docs/30-architecture/quarantined-result-preview-boundary-v0.md`, fixing Phase 1 so result rendering for quarantined objects stays **metadata-safe only**; even when the exact quarantined or derived artifact is the right hit, richer preview must be a separate explicit review/open step on the exact handle rather than a consequence of selection, focus, hover, or top-match suggestion UI
  - wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/attrfs-posture-v0.md`, `docs/30-architecture/attribute-query-schema-v0.md`, `docs/30-architecture/quarantined-content-index-boundary-v0.md`, `docs/30-architecture/quarantined-derived-match-boundary-v0.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/open-untrusted-viewer-residue-boundary-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0100-attribute-query-predicates-and-smart-folders.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_quarantined_result_preview_boundary.py`, register `EVID-2026-393`, and make lint reject drift where quarantined search/query results start auto-rendering snippets / thumbnails / preview panes / Quick Look cards / hover previews from risky bytes, or where selection/focus becomes a hidden open/review path outside the existing explicit seams

## Revised385 (2026-03-09)
- pin the exact **quarantined derived-match boundary v0** so search/query/smart-folder surfaces cannot launder risky sources back into discovery after explicit analysis merely by following lineage or picking a prettier representative:
  - add `docs/30-architecture/quarantined-derived-match-boundary-v0.md`, fixing Phase 1 so when OCR / summarize / classify / embed semantics live on a **separate derived artifact**, CH-ATTRQ/search results stay on that exact matching artifact; the quarantined source object does **not** resurface by hidden `origin.parent_digest` joins, source-preferred representative substitution, or dedup-style result collapse unless the relation is followed explicitly
  - wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/attrfs-posture-v0.md`, `docs/30-architecture/attribute-query-schema-v0.md`, `docs/30-architecture/origin-quarantine-attrset.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0100-attribute-query-predicates-and-smart-folders.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_quarantined_derived_match_boundary.py`, register `EVID-2026-392`, and make lint reject drift where a sibling derived artifact's semantic hit gets silently lifted back onto the risky source object through hidden lineage joins, source-preferred query results, or dedup-style representative collapse

## Revised384 (2026-03-09)
- pin the exact **quarantined derived-attribute boundary v0** so explicit OCR / summarize / classify / embed workflows cannot launder risky bytes back into queryable source metadata:
  - add `docs/30-architecture/quarantined-derived-attribute-boundary-v0.md`, fixing Phase 1 so quarantined source objects stay **metadata-safe** even after explicit analysis; durable semantic results live on a **new quarantined derived artifact** instead of being written back as OCR text, semantic labels, classifier outputs, or other content-derived attributes on the risky source object
  - wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/quarantined-content-index-boundary-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/attrfs-posture-v0.md`, `docs/30-architecture/attribute-schema-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0100-attribute-query-predicates-and-smart-folders.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_quarantined_derived_attribute_boundary.py`, register `EVID-2026-391`, and make lint reject drift where explicit analysis starts writing semantic tags/text/classifier outputs back onto quarantined source-object attributes, where smart-folder/query surfaces start matching risky sources by those back-written fields, or where the archive loses the explicit discovery/assurance wiring that keeps this boundary real

## Revised383 (2026-03-09)
- pin the exact **quarantined content-index boundary v0** so risky bytes cannot quietly re-enter the system through “helpful” search, OCR, embedding, or assistant summarization side effects after import/safe-open:
  - add `docs/30-architecture/quarantined-content-index-boundary-v0.md`, fixing Phase 1 so quarantined objects may still appear in authorized **metadata-safe** discovery surfaces, but their bytes do **not** silently feed ambient full-text indexes, OCR sidecars, embedding stores, assistant memory, or summary caches; any later analysis is a separate explicit workflow that yields a **new quarantined artifact** with explicit parent linkage
  - wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/open-untrusted-viewer-residue-boundary-v0.md`, `docs/30-architecture/attrfs-posture-v0.md`, `docs/30-architecture/observation-export-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0100-attribute-query-predicates-and-smart-folders.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_quarantined_content_index_boundary.py`, register `EVID-2026-390`, and make lint reject drift where quarantined bytes silently gain ambient full-text / OCR / embedding / summary extraction, where metadata-safe discovery widens into provider-global content indexing or assistant memory, or where explicit analysis stops yielding a new quarantined artifact

## Revised382 (2026-03-09)
- pin the exact **safe-open viewer-residue boundary v0** so risky-open cannot quietly regrow a persistence lane through recent-doc / MRU / thumbnail / autosave / crash-recovery side effects outside the disposable:
  - add `docs/30-architecture/open-untrusted-viewer-residue-boundary-v0.md`, fixing Phase 1 so merely previewing/opening a quarantined document does **not** auto-enroll the source object into durable recent-doc / MRU / reopen surfaces or leave viewer-derived residue outside the disposable; any durable reopen/persistence starts only from explicit keep/export or a later mediated `portal.file.*` choice, while shell hints remain non-authoritative
  - wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/30-architecture/document-handle-schema-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_open_untrusted_viewer_residue_boundary.py`, register `EVID-2026-389`, and make lint reject drift where risky-open preview silently gains durable recent-doc / MRU / reopen / thumbnail / autosave / crash-recovery residue outside the disposable, or where shell-owned convenience hints widen into a reopen-capable authority surface

## Revised381 (2026-03-09)
- pin an exact **safe-open active-content boundary v0** so risky-open stops at inert document inspection instead of quietly regrowing a hidden run-untrusted lane through macros, document scripts, external submit/fetch actions, or helper-launch callbacks:
  - add `docs/30-architecture/open-untrusted-active-content-boundary-v0.md`, fixing Phase 1 so `intent.kind=open_untrusted` stays document-shaped and **inert-by-default**: safe-open may render/inspect and allow bounded local editing, but embedded active content cannot execute or cause network/helper/print/file side effects behind the original request, and any such effect must cross a new explicit workflow on the existing portal seam
  - wire the boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_open_untrusted_active_content_boundary.py`, register `EVID-2026-388`, and make lint reject drift where document-shaped safe-open quietly regains embedded active-content execution, document-driven network/helper side effects, or hidden promotion from risky-open into a generic launcher/runtime surface

## Revised380 (2026-03-09)
- pin the exact **quarantined code-input boundary** so deny-by-default risky execution cannot quietly be bypassed by a cleared interpreter/runtime that re-ingests a quarantined bound object as `stdin`, `-c`, `--eval`, module/archive entry, or a similar code-bearing input form:
  - add `docs/30-architecture/quarantined-code-input-boundary-v0.md`, fixing Phase 1 so quarantine gating covers **bound code-bearing input objects**, not just the main executable object; runners/front-ends may not launder quarantined code by restaging object bytes into eval/stdin entry positions, while user-authored literals remain a separate question and v0 adds no generic source-taint subsystem or portable `run_untrusted` lane
  - wire the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/quarantined-execution-boundary-v0.md`, `docs/30-architecture/capshell-script-entry-posture-v0.md`, `docs/30-architecture/capshell-command-string-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_quarantined_code_input_boundary.py`, register `EVID-2026-387`, and make lint reject drift where a cleared interpreter/runtime regains a laundering path for quarantined bound code via `stdin` / `-c` / `--eval` / module-entry convenience, or where the archive loses the explicit discovery/assurance wiring that keeps this boundary real

## Revised379 (2026-03-09)
- pin the exact **quarantined-execution boundary** so the archive stops implying that docref-only safe-open also covers risky exact execution:
  - add `docs/30-architecture/quarantined-execution-boundary-v0.md`, fixing Phase 1 so quarantined exact executable/script objects do **not** auto-coerce into `open_untrusted`; ordinary exact execution stays deny-by-default until explicit object-local clear/override, and v0 adds no portable `run_untrusted` lane
  - wire the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/capshell-exec-object-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_quarantined_execution_boundary.py`, register `EVID-2026-386`, and make lint reject drift where quarantined exact executable/script objects silently gain a document-shaped safe-open fallback, where `open_untrusted` widens into a portable `run_untrusted` lane, or where sandboxed execution success implies clear/persistence blessing

## Revised378 (2026-03-09)
- pin the exact **bearer-import provenance boundary** so a fresh local document object does not become parentless amnesia or leak raw bearer material into routine metadata:
  - add `docs/30-architecture/import-to-docref-bearer-provenance-boundary-v0.md`, fixing Phase 1 so CH-SREF / CH-CAPX driven import may record one exact **`origin.import_ref_digest`** naming the accepted bearer handoff, but provenance stays digest-only evidence rather than raw bearer bytes/capability URLs, hidden restore/re-fetch authority, or a replacement for ordinary object lineage
  - extend `docs/30-architecture/origin-quarantine-attrset.md` with `origin.import_ref_digest`, and wire the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/import-to-docref-boundary-v0.md`, `docs/30-architecture/capx-posture-v0.md`, `docs/30-architecture/sturdyref-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/document-handle-schema-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0004-networked-capabilities-and-delegation-tokens.md`, `rfcs/0014-sturdyrefs-and-capability-uris.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_import_to_docref_bearer_provenance_boundary.py`, register `EVID-2026-385`, and make lint reject drift where raw bearer material leaks into routine object metadata, where `origin.import_ref_digest` becomes hidden restore/re-fetch authority, or where the import breadcrumb silently replaces ordinary object/parent lineage

## Revised377 (2026-03-09)
- pin the exact **bearer-import fresh-identity boundary** so “materialize a fresh local object” cannot quietly degrade into “reuse an existing local document/docref because the bytes match” folklore:
  - add `docs/30-architecture/import-to-docref-fresh-identity-boundary-v0.md`, fixing Phase 1 so CH-SREF / CH-CAPX driven import into routine document workflows is **fresh-object-identity-first** even for equal bytes; XDG-style `reuse_existing` / `as-needed` shortcuts stay off this seam, quarantine/origin remain object-local rather than content-addressed trust, and any storage dedupe is allowed only below the object boundary
  - wire the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/import-to-docref-boundary-v0.md`, `docs/30-architecture/capx-posture-v0.md`, `docs/30-architecture/sturdyref-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/document-handle-schema-v0.md`, `docs/30-architecture/origin-quarantine-attrset.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0004-networked-capabilities-and-delegation-tokens.md`, `rfcs/0014-sturdyrefs-and-capability-uris.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_import_to_docref_fresh_identity_boundary.py`, register `EVID-2026-384`, and make lint reject drift where equal imported bytes collapse onto an existing local object/docref, where `reuse_existing` / cache-hit shortcuts reappear on the bearer→docref seam, or where quarantine/trust becomes content-addressed instead of object-local

## Revised376 (2026-03-09)
- pin the exact **D-CAPX / CH-SREF import-to-docref boundary** so “restore/import first, then obtain a `docref`” stops floating as an underspecified bridge between bearer material and routine document workflows:
  - add `docs/30-architecture/import-to-docref-boundary-v0.md`, fixing Phase 1 so workflows that start from **CH-SREF / CH-CAPX** and want `portal.file.*` / `open_untrusted` must first **materialize a fresh local object**, classify it as outside-world input, and only then mint a provider-local **CH-DOCREF**; the resulting docref is not a hidden bearer-backed wrapper, does not silently re-fetch remote bytes on reopen, and does not turn local save into remote write-back
  - wire the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capx-posture-v0.md`, `docs/30-architecture/sturdyref-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/document-handle-schema-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0004-networked-capabilities-and-delegation-tokens.md`, `rfcs/0014-sturdyrefs-and-capability-uris.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_import_to_docref_boundary.py`, register `EVID-2026-383`, and make lint reject drift where CH-SREF / CH-CAPX bearer material quietly becomes a disguised docref, skips quarantine-first classification for imported document-like content, or regains hidden refetch/write-back semantics on docref reopen

## Revised375 (2026-03-09)
- pin the exact **safe-open export lineage boundary** so `open_untrusted` output cannot quietly become a fresh quarantined artifact with no mechanically queryable parent evidence:
  - add `docs/30-architecture/open-untrusted-export-lineage-boundary-v0.md`, fixing Phase 1 so ordinary kept output records one exact **`origin.parent_digest`** for the risky source object; lineage stays explicit evidence rather than hidden `docref`/grant continuity, locator/path folklore, or a new provenance subsystem
  - extend `docs/30-architecture/origin-quarantine-attrset.md` with `origin.parent_digest`, and wire the new lineage boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`, `docs/30-architecture/open-untrusted-export-classification-v0.md`, `docs/30-architecture/open-untrusted-export-destination-boundary-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_open_untrusted_export_lineage_boundary.py`, register `EVID-2026-382`, and make lint reject drift where ordinary safe-open kept output loses its exact-parent lineage hook, regains source-identity/docref continuity as lineage shorthand, or falls back to locator/path folklore

## Revised374 (2026-03-09)
- pin the exact **safe-open export destination boundary** so `open_untrusted` cannot quietly slide back into “save from disposable, therefore overwrite the original/trusted file” folklore:
  - add `docs/30-architecture/open-untrusted-export-destination-boundary-v0.md`, fixing Phase 1 so ordinary safe-open keep/export is **fresh-destination-first**; the kept result lands as a new quarantined artifact on existing `portal.file.*` / `portal.xfer.*` seams, while overwrite-original / replace-existing remains a separate explicit publish step if policy later allows it
  - wire the new destination boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`, `docs/30-architecture/open-untrusted-export-classification-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_open_untrusted_export_destination_boundary.py`, register `EVID-2026-381`, and make lint reject drift where ordinary safe-open keep/export stops being **fresh-destination-first**, regains overwrite-original / replace-existing semantics inside the same workflow, or drops the explicit later publish/replace boundary on existing destination mutation seams

## Revised373 (2026-03-09)
- pin the exact **safe-open export classification boundary** so `open_untrusted` output cannot quietly drift into “saved from disposable, therefore trusted” folklore:
  - add `docs/30-architecture/open-untrusted-export-classification-v0.md`, fixing Phase 1 so ordinary safe-open export creates a **new artifact** on existing `portal.file.*` / `portal.xfer.*` seams, remains **quarantined by default**, and keeps sanitize/clear as separate explicit workflows rather than side effects of export, destination choice, or copy-back UX
  - wire the new export-classification boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/origin-quarantine-attrset.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_open_untrusted_export_classification.py`, register `EVID-2026-380`, and make lint reject drift where ordinary safe-open export stops being **new-artifact + quarantined-by-default**, or where sanitize/clear are smuggled back in as hidden side effects of export/copy-back/destination choice

## Revised372 (2026-03-09)
- pin the exact **safe-open materialization boundary** so `open_untrusted` cannot quietly degrade into “CH-DOCREF reopen, but in a sandbox” folklore:
  - add `docs/30-architecture/open-untrusted-materialization-boundary-v0.md`, fixing risky-open to **resolve once** from one exact `docref` into a **request-local stable input object** (snapshot/staged-copy style), forbidding live alias/write-through semantics back to the mutable source, keeping ordinary save disposable-local, and requiring any kept output to leave only via explicit `portal.file.*` / `portal.xfer.*` / IF-CONSENT export/publish seams
  - wire the new materialization boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/open-untrusted-posture-v0.md`, `docs/30-architecture/document-portal-posture-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_open_untrusted_materialization_boundary.py`, register `EVID-2026-379`, and make lint reject drift where safe-open stops being resolve-once + stable-materialization, regains live alias/save-through semantics to the source object, or hides kept-output publication behind an implicit copy-back path

## Revised371 (2026-03-09)
- make the **safe-open handle class** explicit so `open_untrusted` cannot quietly become a CH-SREF restore/import shortcut just because both are “object-ish”:
  - tighten `docs/30-architecture/open-untrusted-posture-v0.md` so Phase 1 safe-open is not merely object-only but **`docref`-only**; `uri` stays on `open_uri`, `sturdyref` stays on explicit D-CAPX / CH-SREF restore/import seams, and safe-open remains bound to CH-DOCREF / `portal.file.*` rather than secret-bearing restore material
  - wire the narrowed handle boundary through `README.md`, `docs/README.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/30-architecture/plumb-message-schema-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/sturdyref-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- tighten `tools/check_open_untrusted_posture.py` so lint now rejects drift where `open_untrusted` stops being `docref`-only, allows `sturdyref` selection on the portable safe-open seam, or drops the D-CAPX / CH-SREF boundary evidence that keeps restore/import explicit

## Revised370 (2026-03-09)
- pin the exact **`open_untrusted` safe-open request shape** so risky-open workflows stop floating between quarantine, workflow routing, and disposables as “some sandboxed open thing” folklore:
  - add `docs/30-architecture/open-untrusted-posture-v0.md`, fixing `intent.kind=open_untrusted` as an **object-only request-local** workflow on one exact handle; keeping URIs on `open_uri`; making the disposable/template/reuse posture policy-chosen rather than caller-chosen; requiring export and quarantine clear to stay on their existing explicit seams; and declining callback/template-inventory/session-reuse drift on the portable surface
  - wire the new safe-open posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/intent-kind-registry.md`, `docs/30-architecture/plumb-message-schema-v0.md`, `docs/30-architecture/quarantine-posture-v0.md`, `docs/30-architecture/disposable-domain-posture-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0053-origin-quarantine-and-safe-open.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_open_untrusted_posture.py`, register `EVID-2026-378`, and make lint reject drift where `open_untrusted` stops being an object-only safe-open path, regains caller-chosen disposable/profile semantics, quietly treats preview as export/clear, or grows callback/template-inventory/session-reuse side channels

## Revised369 (2026-03-09)
- pin the first **D-EPHEM Phase-1 posture** so disposable domains stop floating as generic ‘temporary VM/process’ lore and become a small, implementable decision about clone hygiene:
  - add `docs/30-architecture/disposable-domain-posture-v0.md`, fixing D-EPHEM as a **user-space posture** over existing isolation primitives; allowing warm templates / preloaded clones / snapshot-restore only when template identity is digest-pinned; requiring disposables to remain **fresh one-shot instances** with explicit export-only persistence; forbidding hidden handle/background/network continuity; requiring entropy/identity refresh before first user payload; and declining any new generic `portal.disposable.*` / ACP/admin plane in Phase 1
  - wire the new disposable-domain posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/60-engineering/system-generation-pipeline.md`, `rfcs/0050-disposable-domains-and-one-shot-sandboxes.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_disposable_domain_posture.py`, register `EVID-2026-377`, and make lint reject drift where D-EPHEM stops being a digest-pinned, fresh-instance, continuity-free disposable posture or regains a generic automation/admin plane

## Revised368 (2026-03-08)
- pin the exact **worker-pool restart-budget semantics** so the first concrete D-CONSTR family cannot quietly drift into pool-wide crash scores, timer folklore, or implementation-defined reset rules:
  - add `docs/30-architecture/worker-pool-restart-budget-v0.md`, fixing `restart.max_restarts` / `restart.window_ms` as a **per-slot sliding admission budget** over automatic `backoff -> starting` replacement only; making the initial fresh occupant not consume budget; making disabled budgets (`0` / `0`) fail closed directly to `failed`; making successful occupancy age admissions out of the trailing window instead of side-resetting them; and declining pool-wide crash-score or portable retry-timer folklore on the canonical family surface
  - wire the new restart-budget semantics through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-parameter-schema-v0.md`, `docs/30-architecture/worker-pool-slot-state-v0.md`, `docs/30-architecture/worker-pool-control-surface-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_restart_budget.py`, register `EVID-2026-376`, and make lint reject drift where worker-pool restart policy stops being one per-slot sliding admission budget over automatic `backoff -> starting` re-entry, where the initial fresh occupant silently starts consuming budget, where disabled budgets no longer fail closed directly to `failed`, or where pool-wide crash-score / portable retry-timer folklore leaks onto the canonical family surface

## Revised367 (2026-03-08)
- pin the exact **worker-pool `quiesce_state` meaning** so the first concrete D-CONSTR family cannot quietly drift into mixed/partial drain folklore, hidden mode/result bags, or equivalent-but-different pool lifecycle summaries:
  - add `docs/30-architecture/worker-pool-quiesce-state-v0.md`, fixing the portable pool-level summary vocabulary to exactly `running`, `quiescing`, and `quiescent`; making `qid` absent only in `running`; requiring `quiescent` to keep the active `qid` in force until `EndQuiesce(qid)`; and declining mixed/partial/mode folklore on the canonical summary surface
  - wire the new quiesce-state meaning through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-control-surface-v0.md`, `docs/30-architecture/worker-pool-describe-summary-v0.md`, `docs/30-architecture/worker-pool-slot-state-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_quiesce_state.py`, register `EVID-2026-375`, and make lint reject drift where worker-pool `quiesce_state` stops being a closed `running` / `quiescing` / `quiescent` vocabulary, loses the exact `qid` rule, or regains mixed/partial/mode folklore on the canonical summary surface

## Revised366 (2026-03-08)
- pin the exact **worker-pool `Describe()` result contract** so the first concrete D-CONSTR family cannot quietly drift into status-tree folklore, host-defined extension bags, or equivalent-but-different pool summaries:
  - add `docs/30-architecture/worker-pool-describe-summary-v0.md`, fixing the portable `Describe()` object to one closed top-level field set (`v`, `invocation_manifest_digest`, `pool_size`, `quiesce_state`, optional `qid`, and `worker_slots`), one exact `qid` presence rule, one ordered gap-free `worker_slots` table, and no metrics/debug/locator or implementation-defined extension drift on the canonical summary surface
  - wire the new Describe-summary contract through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-control-surface-v0.md`, `docs/30-architecture/worker-pool-slot-state-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_describe_summary.py`, register `EVID-2026-374`, and make lint reject drift where the worker-pool `Describe()` result stops being one closed data-only object, loses the exact `qid` presence rule, or regains metrics/debug/extension-bag folklore on the canonical summary surface

## Revised365 (2026-03-08)
- pin the exact **worker-pool `worker_slots[*].state` model** so the first concrete D-CONSTR family cannot quietly drift into per-slot `quiescent` folklore, restart/debug telemetry, or equivalent-but-different temporary-unavailable meanings:
  - add `docs/30-architecture/worker-pool-slot-state-v0.md`, fixing the portable slot vocabulary to exactly `starting`, `running`, `backoff`, `failed`, and `quiescing`; making `backoff` the only temporary-unavailable state; deliberately declining a separate per-slot `quiescent` state; and requiring active pool quiesce to suppress automatic `backoff -> starting` re-entry until `EndQuiesce(qid)` releases ordinary admission again
  - wire the new slot-state model through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-control-surface-v0.md`, `docs/30-architecture/worker-pool-parameter-schema-v0.md`, `docs/30-architecture/worker-pool-worker-surface-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_slot_state.py`, register `EVID-2026-373`, and make lint reject drift where `worker_slots[*].state` stops being a closed five-state vocabulary, regains a separate per-slot `quiescent` or restart/debug taxonomy, or allows automatic `backoff -> starting` re-entry while an active `qid` is still gating admission

## Revised364 (2026-03-08)
- pin the exact **worker-pool `capgraph.before` / `capgraph.after` contract** so the first concrete D-CONSTR family cannot quietly drift into whole-system graph dumps, helper-visible graph cuts, or equivalent-but-different confinement snapshots:
  - add `docs/40-verification/worker-pool-capgraph-snapshots-v0.md`, fixing the canonical pair as caller-scoped same-profile `CH-CAPG v0` receipts over one shared observation scope, comparing only the normalized caller-reachable delta, allowing only the declared `pool.control` + `worker[i]` export surface to become newly caller-visible, and declining target/install-state or helper-inventory folklore on the canonical pair
  - wire the new cap-graph snapshot contract through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_capgraph_snapshots.py`, register `EVID-2026-372`, and make lint reject drift where `capgraph.before` / `capgraph.after` stop being a caller-scoped same-profile `CH-CAPG v0` pair, regain whole-system/helper-visible graph folklore, or stop proving only the normalized caller-reachable delta over the canonical `pool.control` + `worker[i]` export surface

## Revised363 (2026-03-08)
- pin the exact **worker-pool `target.before` / `target.after` contract** so the first concrete D-CONSTR family cannot quietly drift into target-name folklore, ambient inventory dumps, or equivalent-but-different install-order evidence:
  - add `docs/40-verification/worker-pool-target-projection-v0.md`, fixing the install-only target-seam pair as `CH-SPROJ v0` receipts over the same `(family, key_digest)` identity, requiring `kind = digest`, binding one canonical publication digest over exactly `pool.control` plus `worker[i]`, omitting the pair entirely for fresh return-only cases, and declining target-name / alias / list-watch / dump-style drift on the canonical evidence surface
  - wire the new target-projection contract through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/worker-pool-transcript-slice-v0.md`, `docs/40-verification/worker-pool-verdict-summary-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_target_projection.py`, register `EVID-2026-371`, and make lint reject drift where install-mode worker-pool evidence stops using a same-key target-seam `CH-SPROJ v0` pair, regains target-name or inventory/list/watch folklore, or stops binding one canonical publication digest over exactly `pool.control` plus `worker[i]`

## Revised362 (2026-03-08)
- pin the exact **worker-pool `verdict.summary` contract** so the first concrete D-CONSTR family cannot quietly drift into prose-only result reports, flaky/warning folklore, or equivalent-but-different case tables:
  - add `docs/40-verification/worker-pool-verdict-summary-v0.md`, fixing `verdict.summary` as one stable case-id verdict table over the canonical worker-pool export shape: top-level fields are closed to `family`, `invocation_manifest_digest`, `pool_size`, `export_shape`, `overall_verdict`, and `cases`; each case row is fixed to `case_id`, `order_variants`, `verdict`, `delta_predicate_ok`, `replay_predicate_ok`, and install-only `target_projection_required`; and Phase 1 declines warning/flaky/skipped states, target-name folklore, or prose-only result surfaces
  - wire the new verdict-summary contract through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_verdict_summary.py`, register `EVID-2026-370`, and make lint reject drift where `verdict.summary` stops being one exact case-indexed verdict table over the canonical worker-pool export shape, loses explicit `delta_predicate_ok` / `replay_predicate_ok` bits, or regains prose-only/flaky-warning result folklore on the canonical evidence surface

## Revised361 (2026-03-08)
- pin the exact **worker-pool `transcript.slice` contract** so the first concrete D-CONSTR family cannot drift into whole-log dumps, per-tool transcript layouts, or ambiguous replay windows:
  - add `docs/40-verification/worker-pool-transcript-slice-v0.md`, fixing `transcript.slice` as a **case-indexed bounded window set** over ordered `CH-LOG v0` refs: stable case ids own the layout, `fresh-commute` / `install-conflict` each carry `primary` + `swapped` windows, every window binds `invocation_manifest_digest` plus ordered `event_refs`, install cases may add `target_projection_digest`, and the whole slice stays bounded at `<= 8` windows / `<= 24` total refs
  - wire the new transcript-slice contract through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_transcript_slice.py`, register `EVID-2026-369`, and make lint reject drift where `transcript.slice` stops being a case-indexed bounded window set over ordered `CH-LOG v0` refs, loses the stable case-id / `primary`+`swapped` layout, or starts requiring whole-log exports or tool-local transcript vocabularies

## Revised360 (2026-03-08)
- pin the exact **worker-pool `CH-WPOOLPARAM v0` schema** so the first concrete D-CONSTR family has one real digest target for `param_digest` instead of equivalent-but-different parameter folklore:
  - add `docs/30-architecture/worker-pool-parameter-schema-v0.md`, introducing exactly one new family-local schema `CH-WPOOLPARAM v0` for the data-only worker-pool parameter object: it carries only `pool_size` plus the per-slot restart budget (`restart.max_restarts`, `restart.window_ms`), disables automatic replacement exactly when both are `0`, and keeps capability material, import digests, target identity, and caller-chosen export labels out of the object
  - wire the new parameter schema through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/schema-registry.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, `docs/30-architecture/worker-pool-invocation-manifest-v0.md`, `docs/30-architecture/worker-pool-control-surface-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_param_schema.py`, register `EVID-2026-368`, and make lint reject drift where `param_digest` stops meaning `digest(CH-WPOOLPARAM v0)`, `pool_size`/restart policy fork into equivalent-but-different encodings, automatic replacement semantics cease to fail closed at `0/0`, or capability material/import digests/export-label folklore re-enters the first worker-pool parameter object

## Revised359 (2026-03-08)
- pin the exact required **worker-pool `sponsor` surface** so the first concrete D-CONSTR family cannot quietly regain ambient payer/session fallback, sponsor rotation, or sponsor-inventory/admin folklore:
  - add `docs/30-architecture/worker-pool-sponsor-surface-v0.md`, fixing `sponsor` as one explicit pool-wide reviewed sponsorship root: it is required exactly once, stays immutable for one pool instance, remains constructor-input-only, keeps sponsor identity out of the canonical invocation manifest/runtime summary surface, and declines per-worker sponsor splits or `RotateSponsor`-style widening in Phase 1
  - wire the new sponsor surface through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, `docs/30-architecture/worker-pool-invocation-manifest-v0.md`, `docs/30-architecture/worker-pool-control-surface-v0.md`, `docs/30-architecture/worker-pool-worker-surface-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_sponsor_surface.py`, register `EVID-2026-367`, and make lint reject drift where `sponsor` stops being one explicit pool-wide sponsorship root, regains ambient caller/session fallback, widens into sponsor rotation or per-worker payer splits, or becomes a reflected sponsor-inventory/admin surface on `pool.control` / `worker[i]`

## Revised358 (2026-03-08)
- pin the exact **worker-pool `invocation.manifest` / `invocation_manifest_digest` contract** so the first concrete D-CONSTR family cannot drift into equivalent-but-different runtime/evidence manifests:
  - add `docs/30-architecture/worker-pool-invocation-manifest-v0.md`, fixing one digest-first canonical field set (`template_set_digest`, `execpack_digest`, `param_digest`, `pool_size`, import/export contract digests, exact sorted `worker_seed_labels`, and `install_mode`) and explicitly excluding target identity, helper handles, or fresh instance state from the manifest
  - wire the new invocation-manifest contract through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, `docs/30-architecture/worker-pool-control-surface-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_invocation_manifest.py`, register `EVID-2026-366`, and make lint reject drift where worker-pool runtime/evidence tooling stop sharing one exact digest-first manifest object, stop sorting/closing over the reviewed seed-label set and exact `install_mode`, or quietly regain target-identity/helper-state folklore in `invocation.manifest`

## Revised357 (2026-03-08)
- pin the exact optional **worker-pool `install_target` surface** so the first concrete D-CONSTR family cannot quietly regain aliasing, partial publication, or duplicate return/install folklore:
  - add `docs/30-architecture/worker-pool-install-target-surface-v0.md`, fixing `install_target` as a **publication-only owner-visible target seam**: the install set is exactly canonical `pool.control` + `worker[i]`, publication is all-or-nothing, install mode stays distinct from return-only mode, and Phase 1 declines rename/remap/catalog or duplicate direct-return drift
  - wire the new install-target surface through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_install_target_surface.py`, register `EVID-2026-365`, and make lint reject drift where `install_target` stops being a publication-only owner-visible target seam, stops being exact/all-or-nothing for canonical `pool.control` + `worker[i]`, or quietly widens into rename/remap/catalog or duplicate direct-return semantics

## Revised356 (2026-03-08)
- pin the exact **worker-pool `worker_seed/<label>` surface** so the first concrete D-CONSTR family cannot quietly regain per-worker import folklore, reflected import inventories, or reseed-after-construction semantics:
  - add `docs/30-architecture/worker-pool-seed-surface-v0.md`, fixing `worker_seed/<label>` as a reviewed worker-import binding only, making the seed-label set pool-wide and uniform across all worker slots, requiring missing/extra labels to fail closed, and declining per-worker seed maps, import reflection, or post-construction reseeding in Phase 1
  - wire the new seed surface through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, `docs/30-architecture/worker-pool-control-surface-v0.md`, `docs/30-architecture/worker-pool-worker-surface-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- add `tools/check_constructor_worker_pool_seed_surface.py`, register `EVID-2026-364`, and make lint reject drift where repeated `worker_seed/<label>` imports stop being reviewed-import bindings, stop being pool-wide uniform, start allowing missing/extra labels by convention, or quietly widen into per-worker maps / reflected import inventories / reseed-after-construction control surfaces

## Revised355 (2026-03-08)
- pin the exact exported **worker-pool `worker[i]` surface** so the first concrete D-CONSTR family does not drift into per-worker admin wrappers or fake continuity promises:
  - added `docs/30-architecture/worker-pool-worker-surface-v0.md`, fixing `worker[i]` as a **slot-stable typed entry handle**: the worker closure’s reviewed interface stays authoritative, the family adds no `Restart` / `Kill` / `Describe` / `Inspect` / `GetPid` / `GetEpoch` / `SwapImports` / `PublishElsewhere` verb family, future calls/new sessions MAY reach a restarted slot occupant, but Phase 1 explicitly declines transparent in-flight replay or live-session continuity across worker replacement
  - tightened `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, `docs/30-architecture/worker-pool-control-surface-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the worker-pool family/invocation/control/harness/RFC/discovery surfaces all agree on one narrow exported worker-entry contract instead of leaving `worker[i]` semantics as folklore
- added `tools/check_constructor_worker_pool_worker_surface.py` and registered `EVID-2026-363`, so lint now rejects drift where the first worker-pool family silently regains per-worker lifecycle/admin verbs, raw occupant identity semantics, or transparent session-continuity promises on `worker[i]` instead of staying a slot-stable typed entry handle

## Revised354 (2026-03-08)
- pin the exact exported **worker-pool `pool.control` surface** so the first concrete D-CONSTR family does not regrow an ad-hoc scheduler/admin plane:
  - added `docs/30-architecture/worker-pool-control-surface-v0.md`, fixing `pool.control` as a bounded family-local observation + maintenance handle: `Describe()` returns one fixed-slot summary (`invocation_manifest_digest`, `pool_size`, `quiesce_state`/`qid`, and per-slot worker states), `BeginQuiesce(mode)` / `EndQuiesce(qid)` are the only mutators, and Phase 1 explicitly declines scale, reseed, per-worker restart, template/import rewrite, job-submission, and inventory/metrics/admin semantics on that handle
  - tightened `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/worker-pool-constructor-evidence-pack-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the worker-pool family/invocation/harness/RFC/discovery surfaces all agree on one narrow exported control contract instead of leaving `pool.control` as folklore
- added `tools/check_constructor_worker_pool_control_surface.py` and registered `EVID-2026-362`, so lint now rejects drift where the first worker-pool family silently regains scale/reseed/restart/job/inventory/admin verbs on `pool.control` instead of staying a bounded summary + cooperative-quiesce handle

## Revised352 (2026-03-08)
- make the first **D-CONSTR worker-pool family** more directly implementable instead of leaving its family-local call shape as lore:
  - added `docs/30-architecture/worker-pool-constructor-invocation-v0.md`, pinning the exact first-family invocation boundary: required imports are one `sponsor`, zero or more explicit `worker_seed/<label>` slots, and optional `install_target`; the parameter object stays data-only and bounded; exported names are canonically `pool.control` plus `worker[i]`; and install cases reuse target-seam conflict keys instead of caller-chosen label maps or constructor-global ordering
  - tightened `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `docs/40-verification/worker-pool-constructor-harness-v0.md`, `docs/40-verification/verification-strategy.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the family choice, exact invocation profile, and first harness contract now agree on one closed worker-pool boundary instead of leaving import-slot names and exported-handle labels to future folklore
- added `tools/check_constructor_worker_pool_invocation.py` and registered `EVID-2026-360`, so lint now rejects drift where the first worker-pool constructor quietly regains caller-chosen export aliases, hidden imports, authority-bearing params, or constructor-global sequencing instead of staying on one exact family-local invocation contract

## Revised351 (2026-03-08)
- make the first **D-CONSTR verification target** concrete instead of leaving the worker-pool family at “we know the shape”:
  - added `docs/40-verification/worker-pool-constructor-harness-v0.md`, pinning the first D-CONSTR harness contract to one closed evidence bundle: freeze the worker-pool invocation digest set up front, compare caller-scoped baseline/post-state `CH-CAPG v0` deltas, allow only the declared pool-control + bounded worker-set export surface, reuse target-seam conflict keys for install cases, and require replay evidence to stay digest-first rather than prose-first
  - tightened `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/roadmap.md`, `docs/40-verification/verification-strategy.md`, `docs/30-architecture/worker-pool-constructor-family-v0.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so the D-CONSTR discovery/history/RFC/verification surfaces now agree on one concrete first harness contract instead of leaving “what evidence must the first constructor emit?” as lore
- added `tools/check_constructor_worker_pool_harness.py` and registered `EVID-2026-359`, so lint now rejects drift where the first D-CONSTR harness quietly drops caller-scoped cap-graph deltas, target-seam ordering tests, or ambient-acquisition/export-widening negatives in favor of ad-hoc constructor evidence

## Revised350 (2026-03-08)
- resolve RFC-0042's remaining **first concrete constructor-family** choice instead of adding another generic D-CONSTR layer:
  - added `docs/30-architecture/worker-pool-constructor-family-v0.md`, pinning the **sandboxed worker-pool family** as the first D-CONSTR evidence target: one pool instance reuses one exact `digest(CH-EXECPACK v2)` worker closure plus explicit imports/exports, emits only a pool control handle plus a bounded worker-set surface, reuses target-seam conflict keys for any installs, and explicitly declines autoscaling/admin planes, heterogeneous mixed-image pools, and constructor-specific job protocols in Phase 1
  - tightened `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so D-CONSTR discovery/history/mechanism/RFC surfaces now agree on the same first concrete family and RFC-0042 no longer leaves the initial evidence target open
- added `tools/check_constructor_worker_pool_family.py` and registered `EVID-2026-358`, so lint now rejects drift where the first D-CONSTR harness quietly broadens into an autoscaling control plane, mixed-image worker pool, constructor-specific job protocol, or constructor-global ordering service instead of staying a bounded explicit-import/export family

## Revised349 (2026-03-08)
- pin a **constructor boundary pattern v0** so D-CONSTR has one reusable Phase-1 family shape instead of each constructor inventing its own invocation folklore:
  - added `docs/30-architecture/constructor-boundary-pattern-v0.md`, freezing the reusable split as **template digests + data-only parameters + explicit authority-import slots + bounded export contracts + digest-only receipt bindings**, while explicitly declining any generic constructor request/receipt protocol, authority-bearing parameter objects, ambient import lookup, or constructor-global ordering/admin surface
  - tightened `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `rfcs/0042-constructors-and-confinement-tests.md`, `docs/00-meta/roadmap.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md` so all D-CONSTR discovery/mechanism/RFC surfaces now agree on the same narrow boundary pattern and RFC-0042 no longer leaves the smallest reusable parameter-object pattern open
- added `tools/check_constructor_boundary_pattern.py` and registered `EVID-2026-357`, so lint now rejects drift where constructor families quietly smuggle authority through parameter objects, grow a generic constructor request/receipt protocol, or invent a constructor-global ordering/admin plane without an explicit new RFC/ADR

## Revised348 (2026-03-08)
- pin a **constructor/confinement posture v0** so D-CONSTR stops living as loose RFC/roadmap prose and becomes an implementable Phase-1 boundary:
  - added `docs/30-architecture/constructor-posture-v0.md`, freezing D-CONSTR around **ordinary user-space factories** that consume **digest-pinned templates** plus **schema-pinned data-only parameter objects**, return only an **explicit exported surface**, and rely on **cap-graph diff + transcript evidence** instead of a constructor brand
  - tightened `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `rfcs/0042-constructors-and-confinement-tests.md`, and `docs/00-meta/roadmap.md` so all D-CONSTR discovery/narrative surfaces now agree on the same narrow Phase-1 choice: **no kernel constructor framework, no constructor catalog/inventory, no generic constructor portal family / ACP / workflow plane, and no generic constructor conflict-key family**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_constructor_posture.py` and registered `EVID-2026-356`, so lint now rejects drift where constructors quietly regain a kernel framework, ambient lookup semantics in parameter objects, a constructor inventory/control plane, or a constructor-global commutativity story without an explicit new RFC/ADR

## Revised347 (2026-03-08)
- pin a **verified-read posture v0** so D-VERITY stops living as loose RFC/schema prose and becomes an implementable Phase-1 boundary:
  - added `docs/30-architecture/verity-posture-v0.md`, freezing D-VERITY around **explicit immutable VerifiedBlob handles** plus optional **deployment-local verity roots**: file-level verified blobs are the portable artifact unit, `CH-VBLOB v0` stays descriptor-only/non-authoritative, reads fail closed on mismatch, and Phase 1 declines mutable writeback/repair, generic proof export, or a verity inventory/admin plane
  - tightened `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/verified-blob-descriptor-schema-v0.md`, `docs/30-architecture/schema-registry.md`, and `rfcs/0114-verified-blobs-and-merkle-integrity.md` so all D-VERITY discovery/schema/RFC surfaces now agree on **VerifiedBlob-first immutable reads in v0** instead of quietly leaving volume-vs-file scope, mutable repair, or proof/admin semantics half-open
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_verity_posture.py` and registered `EVID-2026-355`, so lint now rejects drift where D-VERITY quietly regains mutable verified objects, ambient path/mount enablement, generic proof/admin surfaces, or CH-VBLOB authority semantics without an explicit new RFC/ADR

## Revised346 (2026-03-08)
- pin an **authority-diff / consent-receipt posture v0** so D-EXPLAIN stops living as loose RFC/schema prose and becomes an implementable Phase-1 boundary:
  - added `docs/30-architecture/explain-posture-v0.md`, freezing D-EXPLAIN as **canonical shell-owned CH-CAPDIFF summaries plus non-authoritative CH-RECEIPT evidence**: requester prose may decorate prompts but never define `summary_digest`; receipts remain audit artifacts rather than approvals; wildcard/batch approval reuse is out of scope; conflict/order/deny metadata stays observability-only; and Phase 1 declines any generic receipt ledger / list / watch / sync / permission-store/admin plane on D-EXPLAIN itself
  - tightened `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/capability-diff-schema-v0.md`, `docs/30-architecture/consent-receipt-schema-v0.md`, `docs/30-architecture/interface-registry.md`, and `rfcs/0069-capability-diffs-for-consent-and-receipts.md` so all D-EXPLAIN discovery/schema/RFC surfaces now agree on **canonical diff + non-authoritative receipt evidence only in v0** instead of quietly implying a reusable permission store or receipt-admin plane
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_explain_posture.py` and registered `EVID-2026-354`, so lint now rejects drift where D-EXPLAIN quietly regains requester-authored bound summaries, receipt replay-as-approval semantics, or a generic receipt ledger / permission-store control plane without an explicit new RFC/ADR

## Revised345 (2026-03-08)
- pin a **user-mode pager posture v0** so D-PAGER stops living as loose RFC/decision-map prose and becomes an implementable Phase-1 boundary:
  - added `docs/30-architecture/pager-posture-v0.md`, freezing `ext.user_mode_pager` as an **object-backed fault-routing seam only** in Phase 1: CH-FAULT requests stay object+offset based, per-address-space / raw-virtual-address pager mode is deferred, pager authority remains explicit/non-amplifying, mutable writeback is out of scope, and self-paging stays a future/profile experiment rather than default meaning
  - tightened `docs/30-architecture/fault-message-schema-v0.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/schema-registry.md`, `docs/30-architecture/config-toggle-registry.md`, `docs/30-architecture/profile-feature-flag-defaults.md`, `docs/10-threat-model/deployment-profiles.md`, and `rfcs/0044-user-mode-paging-and-external-pagers.md` so all D-PAGER discovery/config/RFC surfaces now agree on **object-backed only in v0** instead of quietly leaving a generic per-address-space pager path half-open
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_pager_posture.py` and registered `EVID-2026-353`, so lint now rejects drift where D-PAGER quietly regains per-address-space vaddr fault routing, a pager inventory/admin plane, or mutable writeback semantics without an explicit new RFC/ADR

## Revised344 (2026-03-08)
- pin a **translator/service-tree posture v0** so D-TRANS stops living as loose RFC/decision-map prose and becomes an implementable Phase-1 boundary:
  - added `docs/30-architecture/translator-posture-v0.md`, freezing translators as **view-local user-space components** attached only through existing `view.attach` / `view.detach` mutations on concrete `view.slot` keys, reusing `view.slot` conflict keys plus `svc:view` ordering, forbidding host-global pathspace registration / translator inventory / translator stacks in Phase 1, and keeping service-tree/9P-like bridges user-space only
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/view-objects.md`, `docs/30-architecture/mechanisms.md`, `rfcs/0032-view-namespace-semantics-v1.md`, `rfcs/0036-rump-kernel-compatibility-domains.md`, `rfcs/0083-driver-hosts-and-compatibility-runtimes.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_translator_posture.py` and registered `EVID-2026-352`, so lint now rejects drift where translator attachment quietly regains host-global pathspace semantics, a second translator-specific admin plane, or chain-by-default behavior instead of staying on explicit view-local mutations

## Revised343 (2026-03-08)
- pin a **capshell confinement label/profile posture v0** so `capshell.exec` cannot quietly depend on wrapper-/service-manager-selected SELinux / AppArmor / SMACK execution label/profile state as hidden launch baseline:
  - added `docs/30-architecture/capshell-mac-profile-posture-v0.md`, freezing Phase 1 launch posture so `capshell.exec` adds no reviewed per-step confinement-label/profile surface, child launch normalizes to the **default confinement label/profile baseline for the active execution compartment**, inherited `setexeccon()` / `/proc/pid/attr/exec` / `SELinuxContext=` / `AppArmorProfile=` / `SmackProcessLabel=` policy is not reviewed workflow meaning, and compat membranes that cannot guarantee that posture fail closed
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, `tools/check_capshell_launch_boundary_index.py`, and `tools/README.md`
- added `tools/check_capshell_mac_profile_posture.py`, registered `EVID-2026-351`, and extended the bibliography with `REF-MAN7-GETEXECCON` + `REF-MAN7-PROC-PID-ATTR` + `REF-UBUNTU-AA-CHANGE-PROFILE`, so lint now rejects drift where reviewed automation quietly regains inherited execution-label/profile selection instead of staying on one default compartment-level confinement baseline

## Revised342 (2026-03-08)
- pin a **capshell resource-controller envelope posture v0** so `capshell.exec` cannot quietly depend on inherited cgroup / Job Object resource limits as hidden launch baseline:
  - added `docs/30-architecture/capshell-resource-envelope-posture-v0.md`, freezing Phase 1 launch posture so `capshell.exec` adds no reviewed per-step resource-envelope surface, child launch normalizes to the **default resource-controller envelope for the active execution compartment**, inherited cgroup membership / `CPUQuota=` / `MemoryMax=` / `TasksMax=` / Job Object resource limits are not reviewed workflow meaning, and compat membranes that cannot guarantee that posture fail closed
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, `tools/check_capshell_launch_boundary_index.py`, and `tools/README.md`
- added `tools/check_capshell_resource_envelope_posture.py`, registered `EVID-2026-350`, and extended the bibliography with `REF-MAN7-CGROUPS` + `REF-CGROUPV2` + `REF-MAN7-SYSTEMD-RESOURCE-CONTROL` + `REF-MS-JOB-OBJECTS`, so lint now rejects drift where reviewed automation quietly regains inherited cgroup / slice / Job Object resource ceilings instead of staying on one default compartment-level resource-controller envelope

## Revised341 (2026-03-08)
- pin a **capshell syscall-admission / syscall-filter posture v0** so `capshell.exec` cannot quietly depend on wrapper-/service-manager-installed seccomp policy as hidden launch baseline:
  - added `docs/30-architecture/capshell-syscall-filter-posture-v0.md`, freezing Phase 1 launch posture so `capshell.exec` adds no reviewed per-step syscall-filter surface, child launch normalizes to the **default syscall-admission baseline for the active execution compartment**, inherited `seccomp()` / `PR_SET_SECCOMP` / `SystemCallFilter=` policy is not reviewed workflow meaning, and compat membranes that cannot guarantee that posture fail closed
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, `tools/check_capshell_launch_boundary_index.py`, and `tools/README.md`; also tightened `tools/check_capshell_launch_boundary_index.py` so the closed capshell launch-boundary set now machine-requires the newer exact-object / argv0 / code-closure / handle-table / credential / personality / peer-inspection / syscall-admission adjuncts instead of only the earlier subset
- added `tools/check_capshell_syscall_filter_posture.py`, registered `EVID-2026-349`, and extended the bibliography with `REF-MAN7-SECCOMP` + `REF-KERNEL-SECCOMP`, so lint now rejects drift where reviewed automation quietly regains inherited seccomp / `SystemCallFilter=` policy instead of staying on one default compartment-level syscall-admission baseline

## Revised340 (2026-03-08)
- pin a **capshell launcher-lifetime posture v0** so `capshell.exec` cannot quietly depend on wrapper-/session-defined parent-death or kill-on-launcher-exit coupling as hidden launch baseline:
  - added `docs/30-architecture/capshell-launcher-lifetime-posture-v0.md`, freezing Phase 1 launch posture so `capshell.exec` adds no reviewed per-step die-with-parent / detach surface, child launch stays **independent of transient launcher/wrapper death inside the active execution compartment**, wrapper-imposed `PR_SET_PDEATHSIG` / inherited Job Object kill-on-close / equivalent launcher/session liveness lore is not reviewed workflow meaning, and compat membranes that cannot guarantee that posture fail closed
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, `tools/check_capshell_launch_boundary_index.py`, and `tools/README.md`
- added `tools/check_capshell_launcher_lifetime_posture.py`, registered `EVID-2026-348`, and extended the bibliography with `REF-MAN7-PR-SET-PDEATHSIG` + `REF-MS-ASSIGNPROCESSTOJOBOBJECT` + `REF-MS-JOB-OBJECTS`, so lint now rejects drift where reviewed automation quietly regains wrapper-/session-defined launcher-death coupling instead of staying on one explicit request/job/background-lifetime story

## Revised339 (2026-03-08)
- pin a **capshell CPU-affinity / placement posture v0** so `capshell.exec` cannot quietly depend on parent-shell, wrapper, or service-manager core pinning as hidden launch baseline:
  - added `docs/30-architecture/capshell-affinity-posture-v0.md`, freezing Phase 1 launch posture so `capshell.exec` adds no reviewed per-step affinity / placement surface, child launch normalizes to the **default eligible CPU set for the active execution compartment**, inherited `taskset` / `sched_setaffinity()` / `CPUAffinity=` / process-affinity-mask lore is not reviewed workflow meaning, and compat membranes that cannot guarantee that posture fail closed
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, `tools/check_capshell_launch_boundary_index.py`, and `tools/README.md`
- added `tools/check_capshell_affinity_posture.py`, registered `EVID-2026-347`, and extended the bibliography with `REF-MAN7-SCHED-AFFINITY` + `REF-MAN7-TASKSET` + `REF-MAN7-SYSTEMD-SYSTEM-CONF` + `REF-MS-SETPROCESSAFFINITYMASK`, so lint now rejects drift where reviewed automation quietly regains inherited CPU masks or service-manager/wrapper placement bias instead of staying on one default eligible CPU-set baseline

## Revised338 (2026-03-08)
- pin a **capshell peer-inspection / dumpability posture v0** so `capshell.exec` cannot quietly depend on host-default same-principal debugger / ptrace / `/proc` visibility as hidden launch baseline:
  - added `docs/30-architecture/capshell-peer-inspection-posture-v0.md`, freezing Phase 1 launch posture so `capshell.exec` adds no reviewed per-step debugger / peer-inspection surface, child launch normalizes to a **non-dumpable / non-peer-inspectable baseline**, ambient same-user `ptrace` / `/proc` visibility is not reviewed workflow meaning, and compat membranes that cannot guarantee that posture fail closed
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_peer_inspection_posture.py`, registered `EVID-2026-346`, and extended the bibliography with `REF-MAN7-PR-SET-DUMPABLE` + `REF-MAN7-PTRACE`, so lint now rejects drift where reviewed automation quietly regains ambient same-principal debugger / ptrace / `/proc` visibility instead of staying on one non-ambient peer-inspection baseline

## Revised337 (2026-03-08)
- pin a **capshell execution-domain / personality posture v0** so `capshell.exec` cannot quietly depend on wrapper-/session-defined ABI/emulation quirks, ASLR suppression, or legacy execution-domain flags as hidden launch baseline:
  - added `docs/30-architecture/capshell-personality-posture-v0.md`, freezing Phase 1 launch posture so `capshell.exec` adds no reviewed per-step personality/ABI selector, child launch normalizes to the **default native execution-domain / personality baseline**, inherited `setarch` / `Personality=` / `ADDR_NO_RANDOMIZE` / `READ_IMPLIES_EXEC` / `ADDR_COMPAT_LAYOUT` / `STICKY_TIMEOUTS` / `UNAME26` lore is not reviewed workflow meaning, and compat membranes that cannot guarantee that posture fail closed
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_personality_posture.py`, registered `EVID-2026-345`, and extended the bibliography with `REF-MAN7-PERSONALITY` + `REF-MAN7-SETARCH` + `REF-MAN7-SYSTEMD-EXEC`, so lint now rejects drift where reviewed automation quietly regains inherited `setarch` / service-manager personality state, ASLR suppression, or legacy execution-domain quirks instead of staying on one default native execution-domain/personality baseline

## Revised336 (2026-03-08)
- pin a **capshell `argv[0]` posture v0** so `capshell.exec` cannot quietly regain a hidden second launch selector through caller-/wrapper-controlled program-name text:
  - added `docs/30-architecture/capshell-argv0-posture-v0.md`, freezing Phase 1 launch posture so child `argv[0]` is derived from the reviewed CH-ARGV `role="exec"` selector, the remaining non-`exec` tokens preserve order as child `argv[1..]`, `exec -a` / alias / login-shell-prefix spoofing is not reviewed meaning, and mode-by-name tools are non-portable on the generic seam unless ordinary reviewed argv already expresses the same mode
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/argv-schema-v0.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_argv0_posture.py`, registered `EVID-2026-344`, and extended the bibliography with `REF-BUSYBOX-FAQ`, so lint now rejects drift where reviewed automation quietly regains caller-/wrapper-controlled invocation-name semantics instead of staying on one selector-derived child program name

## Revised335 (2026-03-08)
- pin a **capshell native code-closure posture v0** so `capshell.exec` cannot quietly depend on ambient loader / system-library search after the main executable is already bound:
  - added `docs/30-architecture/capshell-code-closure-posture-v0.md`, freezing Phase 1 launch posture to **one exact startup native code closure** — the reviewed launch meaning now includes the exact executable object plus any loader/interpreter and startup shared-library set needed to reach entry, host-global search state such as `/etc/ld.so.cache`, default `/lib*` / `/usr/lib*`, current-directory lookup, package aliases, and standard DLL search order are not reviewed meaning, and compat membranes must preserve the whole reviewed closure (or an exact staged equivalent) or fail closed
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-object-posture-v0.md`, `docs/30-architecture/argv-schema-v0.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_code_closure_posture.py`, registered `EVID-2026-343`, and extended the bibliography with `REF-MAN7-DLOPEN` + `REF-MS-DLL-SEARCHORDER` + `REF-MS-SETDEFAULTDLLDIRECTORIES`, so lint now rejects drift where reviewed automation quietly regains ambient `/lib` / `/usr/lib`, `/etc/ld.so.cache`, current-directory, or DLL-search-order startup dependency resolution instead of staying on one exact startup native code closure

## Revised334 (2026-03-08)
- pin a **capshell executable-object posture v0** so `capshell.exec` cannot quietly retarget a reviewed exec selector through late pathname/document-name reopen, portal lookup, or retarget-by-rename semantics:
  - added `docs/30-architecture/capshell-exec-object-posture-v0.md`, freezing Phase 1 launch posture to **one exact bound executable object** — after CH-ARGV `role="exec"` resolution, the runner executes that exact object (or an exact-byte staged equivalent when direct exact-object execution is unavailable), mutable document/path aliases are not reviewed executable identity, and compat membranes that cannot preserve that posture fail closed instead of reintroducing “whatever object is there now” behavior
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/argv-schema-v0.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_exec_object_posture.py`, registered `EVID-2026-342`, and extended the bibliography with `REF-MAN7-FEXECVE` + `REF-MAN7-EXECVEAT` + `REF-NIX-STORE-OBJECT`, so lint now rejects drift where reviewed automation quietly regains late name/path reopen or retarget-by-rename behavior instead of staying pinned to one exact executable object

## Revised333 (2026-03-08)
- pin a **capshell launch credential-baseline posture v0** so `capshell.exec` cannot quietly depend on ambient caller identity, inherited supplementary groups, or borrowed login/access-token state as hidden authority baseline:
  - added `docs/30-architecture/capshell-credential-baseline-posture-v0.md`, freezing Phase 1 launch posture to **no ambient caller identity** — reviewed automation gets no portable per-step UID/GID/supplementary-group/access-token selector, runners must launch under a provider-/membrane-fixed least-privilege executor identity (or fail closed), and supplementary-group / token memberships that would widen child authority must be stripped or pinned rather than inherited by wrapper/session convention
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_credential_baseline_posture.py`, registered `EVID-2026-341`, and extended the bibliography with `REF-MAN7-CREDENTIALS` + `REF-MAN7-PATH-RESOLUTION` + `REF-MS-CREATEPROCESSASUSER`, so lint now rejects drift where reviewed automation quietly regains ambient caller identity, supplementary-group widening, or borrowed login/access-token semantics instead of staying on a fixed least-privilege executor posture

## Revised332 (2026-03-08)
- pin a **capshell exact child handle-table posture v0** so `capshell.exec` cannot quietly depend on ambient parent descriptor inheritance, `FD_CLOEXEC` / inheritable-handle hygiene, or platform-specific “inherit whatever is currently open” lore:
  - added `docs/30-architecture/capshell-handle-table-posture-v0.md`, freezing Phase 1 launch posture to **exact child bindings only** — the child gets exactly CH-STDIO slots `0..2` plus CH-FDSET slots `>=3`, Phase 1 adds **no reviewed `pass_fds` / inherit-handles surface**, runners must construct an exact child table (or exact allowlist) instead of trusting ambient inheritance state, peer stages still cannot leak handles across pipeline boundaries, and compat membranes that cannot guarantee that posture fail closed
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/capshell-launch-boundary-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/30-architecture/stdio-schema-v0.md`, `docs/30-architecture/fdset-schema-v0.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_handle_table_posture.py`, registered `EVID-2026-340`, and extended the bibliography with `REF-OPENGROUP-FCNTL` + `REF-MAN7-OPEN` + `REF-MS-CREATEPROCESS` + `REF-MS-UPDATETHREADATTR`, so lint now rejects drift where reviewed automation quietly regains ambient parent handle/FD inheritance instead of constructing an exact child handle table from explicit CH-STDIO / CH-FDSET bindings

## Revised331 (2026-03-08)
- make a sharper **D-CRYPTOSVC cross-boundary decision**: SlopOS does **not** standardize transparent agent forwarding, inherited `SSH_AUTH_SOCK`-style channels, or a generic “forward my whole crypto provider” seam:
  - added `docs/30-architecture/cryptosvc-forwarding-boundary-v0.md`, which freezes Phase 1 cross-domain/compat delegation to **explicit narrowed routes only** — any remote use must arrive through a provider-issued proxy/lease or request object bound to one concrete key authority target and one effective policy pin, delegation may only preserve-or-narrow `CH-KEYPOL` constraints (never widen `ops`/`contexts`/`confirm`/rate/time bounds), confirmation/session integrity fail closed, compat adapters remain transcript-visible and policy-killable, and Phase 1 adds **no ACP kind / background broker / durable forwarding surface** for crypto authority
  - promoted D-CRYPTOSVC to an explicit privileged-surface row in `docs/30-architecture/interface-registry.md` as **IF-CRYPTOSVC**, and wired the new boundary through `README.md`, `docs/README.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/cryptosvc-posture-v0.md`, `docs/30-architecture/mechanisms.md`, `rfcs/0067-capability-crypto-services-and-key-handles.md`, `docs/00-meta/bibliography.md`, and `docs/00-meta/evidence-index.md`
- added `tools/check_cryptosvc_forwarding_boundary.py`, extended `tools/check_cryptosvc_posture.py` to require IF-CRYPTOSVC discovery wiring, registered `EVID-2026-339`, and added `REF-OPENBSD-SSHADD`, so lint now rejects drift where crypto authority quietly regains transparent forwarding, hidden widening across delegation, or a missing privileged-surface registry entry

## Revised330 (2026-03-08)
- add a **capshell launch-boundary index** so the growing D-CAPSHELL front-end + launch-boundary adjunct set stays enumerable instead of being discoverable only by walking many posture docs:
  - added `docs/30-architecture/capshell-launch-boundary-index.md`, a closed companion surface for the current Phase-1 `capshell.exec` meaning pins (front-end interpretation, launch process state, ambient namespace/nondeterminism, and interactive-control boundaries), and made it explicit that future no-ambient launch promises must register there in the same revision rather than landing as orphan prose
  - wired the new index through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_capshell_launch_boundary_index.py`, registered `EVID-2026-338`, and made lint fail if the closed capshell launch-boundary subset stops being indexed or discoverable across the archive

## Revised329 (2026-03-08)
- pin a **D-CAPSHELL launch nondeterminism posture v0** so `capshell.exec` cannot quietly inherit ambient time or entropy as hidden launch context when **D-NONDET** is enabled:
  - added `docs/30-architecture/capshell-nondet-posture-v0.md`, freezing Phase 1 launch posture to **no ambient time/RNG baseline when D-NONDET is enabled** — runners/wrappers must not preserve ambient `clock_gettime()` / timer-style time reads, host wall-clock / monotonic defaults, ambient `getrandom()` / machine-RNG behavior, or a hidden “normal machine clock/RNG” baseline across the reviewed boundary, Phase 1 adds **no reviewed per-step clock / entropy surface**, portable time/entropy stays on explicit `portal.clock` / `portal.entropy` seams, and compat membranes that cannot guarantee that posture fail closed instead of preserving host nondeterminism lore
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/nondet-posture-v0.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_nondet_posture.py`, registered `EVID-2026-337`, and extended the bibliography with `REF-MAN7-CLOCK_GETTIME`, so lint now rejects drift where `capshell.exec` quietly regains ambient `clock_gettime()` / timer-style time reads, ambient `getrandom()` / machine-RNG behavior, or a hidden “normal machine clock/RNG” baseline instead of keeping portable nondeterminism on explicit `portal.clock` / `portal.entropy` seams

## Revised328 (2026-03-08)
- pin a **D-CAPSHELL launch filesystem posture v0** so `capshell.exec` cannot quietly inherit ambient host-global filesystem reachability or absolute-path lookup as hidden launch context:
  - added `docs/30-architecture/capshell-filesystem-posture-v0.md`, freezing Phase 1 launch posture to **no ambient absolute-path filesystem baseline** — runners/wrappers must not preserve host-global absolute-path reachability, process-global root/mount-namespace visibility, or a hidden "normal host filesystem" baseline across the reviewed boundary, Phase 1 adds **no reviewed per-step `open(path)` / namespace-lookup surface**, portable file authority stays on explicit CH-CWD / CH-FDSET / D-NS / D-POWERBOX seams, and compat membranes that cannot guarantee that posture fail closed instead of preserving host-path lore
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_filesystem_posture.py`, registered `EVID-2026-336`, and extended the bibliography with `REF-FREEBSD-OPEN-CAPMODE`, so lint now rejects drift where `capshell.exec` quietly regains host absolute-path or host-filesystem baseline behavior instead of keeping file authority on explicit CH-CWD / CH-FDSET / D-NS / D-POWERBOX seams

## Revised327 (2026-03-08)
- pin a **D-CAPSHELL launch local-IPC posture v0** so `capshell.exec` cannot quietly inherit ambient AF_UNIX/session-bus reachability, bus autolaunch, or machine-local IPC defaults as hidden launch context:
  - added `docs/30-architecture/capshell-local-ipc-posture-v0.md`, freezing Phase 1 launch posture to **no ambient AF_UNIX / session-bus baseline** — runners/wrappers must not preserve filesystem-path AF_UNIX sockets, abstract-namespace reachability, session/system/user bus defaults, or autolaunch conventions across the reviewed boundary, Phase 1 adds **no reviewed per-step AF_UNIX / session-bus surface**, portable local IPC stays on explicit CH-STDIO / CH-FDSET / route-bound service seams only, and compat membranes that cannot guarantee that posture fail closed instead of preserving machine-local IPC lore
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_local_ipc_posture.py`, registered `EVID-2026-335`, and extended the bibliography with `REF-MAN7-UNIX` + `REF-DBUS-SPECIFICATION` + `REF-DBUS-LAUNCH`, so lint now rejects drift where `capshell.exec` quietly inherits AF_UNIX/session-bus defaults, bus autolaunch, or “normal machine-local IPC” instead of keeping local IPC on explicit descriptor/route seams

## Revised326 (2026-03-08)
- pin a **D-CAPSHELL launch network posture v0** so `capshell.exec` cannot quietly inherit ambient socket constructors or host-global DNS / resolver state as hidden launch context:
  - added `docs/30-architecture/capshell-network-posture-v0.md`, freezing Phase 1 launch posture to **no ambient sockets or resolver baseline** — runners/wrappers must not preserve raw `socket()` / `connect()` / `bind()` / `listen()` authority, host-global DNS / resolver configuration, or an implicit “machine network stack” baseline across the reviewed boundary, Phase 1 adds **no reviewed per-step raw socket / resolver surface**, portable network behavior stays on explicit D-NETLEASE / `portal.net` / `CH-NETLEASE` seams, and compat membranes that cannot guarantee that posture fail closed instead of preserving host stack defaults
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/30-architecture/network-lease-posture-v0.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_network_posture.py`, registered `EVID-2026-334`, and extended the bibliography with `REF-MAN7-SOCKET` + `REF-MAN7-CONNECT` + `REF-MAN7-GETADDRINFO` + `REF-MAN7-RESOLV-CONF`, so lint now rejects drift where `capshell.exec` quietly inherits host socket constructors, resolver defaults, or "normal machine networking" instead of keeping networked behavior on explicit `portal.net` / `CH-NETLEASE` seams

## Revised325 (2026-03-08)
- pin a **D-CAPSHELL launch privilege-gain posture v0** so `capshell.exec` cannot quietly gain authority through privileged-exec metadata or ambient capability state:
  - added `docs/30-architecture/capshell-privgain-posture-v0.md`, freezing Phase 1 launch posture to **no privilege gain across exec** — runners/wrappers must not widen child authority through setuid/setgid bits, file capabilities, ambient capability carry-over, or similar privileged-exec lore, Phase 1 adds **no reviewed per-step credential/capability elevation surface**, runners SHOULD use one-way `no_new_privs` / equivalent controls where available, and compat membranes that cannot guarantee that posture fail closed instead of preserving host defaults
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_privgain_posture.py`, registered `EVID-2026-333`, and extended the bibliography with `REF-MAN7-EXECVE` + `REF-MAN7-PR-SET-NNP` + `REF-MAN7-CAPABILITIES`, so lint now rejects drift where `capshell.exec` can gain privilege via setuid/setgid bits, file capabilities, or ambient capability carry-over instead of preserving a no-privilege-gain launch boundary

## Revised324 (2026-03-08)
- pin a **D-CAPSHELL launch scheduling posture v0** so `capshell.exec` cannot quietly inherit ambient `nice` / scheduler-policy state as hidden launch context:
  - added `docs/30-architecture/capshell-scheduling-posture-v0.md`, freezing Phase 1 launch posture to **no ambient inherited scheduling baseline** — runners/wrappers must not carry parent/login-shell/service-manager `nice` or scheduler-policy state across the reviewed boundary, Phase 1 adds **no reviewed per-step scheduling surface**, child launch must normalize to the **default non-real-time time-sharing policy** with **neutral nice `0`**, and compat membranes that cannot preserve that posture fail closed instead of reusing host defaults
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_scheduling_posture.py`, registered `EVID-2026-332`, and extended the bibliography with `REF-MAN7-SCHED` + `REF-MAN7-SETPRIORITY` + `REF-MAN7-SCHED-SETSCHEDULER`, so lint now rejects drift where `capshell.exec` quietly inherits parent shell/session/service-manager CPU-scheduling bias instead of normalizing launch to the default non-real-time policy with neutral nice `0`

## Revised323 (2026-03-08)
- pin a **D-CAPSHELL launch signal-state posture v0** so `capshell.exec` cannot quietly inherit blocked-signal masks or ignored shell trap state as hidden launch context:
  - added `docs/30-architecture/capshell-signalstate-posture-v0.md`, freezing Phase 1 launch posture to **no ambient inherited signal-state baseline** — runners/wrappers must not carry parent/login-shell blocked-signal or trap-ignore state across the reviewed boundary, Phase 1 adds **no reviewed per-step signal-state surface**, child launch must normalize to an **empty blocked-signal mask** plus **default dispositions for catchable signals**, and compat membranes that cannot preserve that posture fail closed instead of reusing host defaults
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_signalstate_posture.py`, registered `EVID-2026-331`, and extended the bibliography with `REF-MAN7-SIGPROCMASK` + `REF-MAN7-SIGACTION` + `REF-MAN7-POSIX-SPAWN`, so lint now rejects drift where `capshell.exec` quietly inherits blocked/ignored shell signal state instead of normalizing launch to an empty mask plus default dispositions at the boundary

## Revised322 (2026-03-08)
- pin a **D-CAPSHELL resource-limit posture v0** so `capshell.exec` cannot quietly inherit parent shell/session `ulimit` / `getrlimit()` state as hidden launch context:
  - added `docs/30-architecture/capshell-rlimit-posture-v0.md`, freezing Phase 1 launch posture to **no ambient inherited resource-limit baseline** — runners/wrappers must not carry parent/login-shell `ulimit` state across the reviewed boundary, Phase 1 adds **no reviewed per-step `rlimit` surface**, child launch must force **`RLIMIT_CORE = 0`**, and compat membranes that cannot preserve that posture fail closed instead of reusing host defaults
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_rlimit_posture.py`, registered `EVID-2026-330`, and extended the bibliography with `REF-OPENGROUP-GETRLIMIT` + `REF-OPENGROUP-ULIMIT`, so lint now rejects drift where `capshell.exec` quietly inherits login-shell/session resource limits or ambient core-dump policy instead of keeping launch ceilings independent of parent shell state and forcing `RLIMIT_CORE = 0` at the boundary

## Revised321 (2026-03-08)
- pin a **D-CAPSHELL umask posture v0** so `capshell.exec` cannot quietly inherit host/login-shell file-creation defaults as hidden process state:
  - added `docs/30-architecture/capshell-umask-posture-v0.md`, freezing Phase 1 launch posture to **no ambient inherited file mode creation mask** — runners/wrappers must not inherit the parent/session `umask`, the child launch `umask` is fixed to **`0o077`**, other execution-pack seams do not secretly mint or repair it, and compat membranes that cannot preserve that posture fail closed instead of carrying host shell state across the boundary
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_umask_posture.py`, registered `EVID-2026-329`, and extended the bibliography with `REF-OPENGROUP-UMASK`, so lint now rejects drift where `capshell.exec` quietly inherits the parent/login-shell/session file mode creation mask or reintroduces profile-specific `umask` defaults instead of keeping launch file-creation posture fixed and review-independent

## Revised320 (2026-03-07)
- pin a **D-CAPSHELL cwd-root posture v0** so explicit working-directory binding cannot quietly degrade into best-effort host cwd semantics, parent traversal escape, or hidden root rebasing inside compat/path-based launches:
  - added `docs/30-architecture/capshell-cwd-root-posture-v0.md`, freezing Phase 1 **CH-CWD as a bound cwd-root seam** — `cwd.kind="empty"` must yield a fresh/sealed empty cwd root, relative/path-based resolution must stay beneath the bound root (no `..` escape, no host-root fallback, no hidden pathname re-resolution), and runtimes that cannot prove that bar must fail closed instead of treating CH-CWD as advisory only
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/cwd-schema-v0.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_cwd_root_posture.py`, registered `EVID-2026-328`, and extended the bibliography with `REF-OPENAT2`, so lint now rejects drift where explicit CH-CWD quietly downgrades into advisory-path launch behavior, tolerates `..` / host-root escape, or relies on compat membranes that cannot preserve a no-escape cwd-root boundary

## Revised319 (2026-03-07)
- pin a **D-CAPSHELL env-baseline posture v0** so CH-ENV cannot quietly regain ambient host/session context through runner defaults or “helpful” compatibility injection:
  - added `docs/30-architecture/capshell-env-baseline-posture-v0.md`, freezing Phase 1 child environments to **exact CH-ENV only** — no profile-defined baseline append step, no synthetic `HOME` / `PWD` / `TMPDIR` / `TERM` / locale / timezone / `XDG_*` injection from login/session/TTY/cwd state, and no hidden derivation of env from CH-CWD / CH-STDIO / CH-REQCTX
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/env-schema-v0.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_env_baseline_posture.py`, registered `EVID-2026-327`, and extended the bibliography with `REF-OPENGROUP-ENVVARS` + `REF-XDG-BASEDIR`, so lint now rejects drift where `capshell.exec` quietly appends a host/session convenience env baseline or synthesizes `HOME` / `PWD` / `TERM` / locale / `XDG_*` from other seams instead of keeping child env exact and review-visible

## Revised318 (2026-03-07)
- pin a **D-CAPSHELL interrupt/cancel posture v0** so integrated shell UX cannot quietly grow a second control plane through Unix/POSIX signal lore, jobspecs, or shell-exit/SIGHUP conventions:
  - added `docs/30-architecture/capshell-interrupt-cancel-posture-v0.md`, freezing Phase 1 `capshell.exec` interruption to **explicit request/workflow seams only** — local UX may map Ctrl-C into cancellation, but the portable seam adds no signal-send rights, no jobspec namespace, and no shell-owned hangup lifecycle contract
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_interrupt_cancel_posture.py`, registered `EVID-2026-326`, and extended the bibliography with `REF-OPENGROUP-SH` + `REF-BASH-SIGNALS`, so lint now rejects drift where `capshell.exec` quietly acquires a signal-send / jobspec / shell-exit-SIGHUP lifecycle plane instead of staying on explicit D-REQCTX / D-JOBS / D-BGLEASE / D-QUIESCE seams

## Revised317 (2026-03-07)
- pin a **D-CAPSHELL terminal/job-control posture v0** so the integrated shell story cannot quietly grow a second authority plane through PTYs, controlling terminals, or shell-owned foreground/background process state:
  - added `docs/30-architecture/capshell-job-control-posture-v0.md`, freezing Phase 1 `capshell.exec` to an **execution-pack launch seam only** — no implicit PTY allocation, no controlling-terminal/process-group/session control, and no portable `fg` / `bg` / `jobs` workflow plane; background/deferred presence stays on D-JOBS / D-BGLEASE instead of shell session state
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/stdio-schema-v0.md`, `docs/30-architecture/fdset-schema-v0.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_job_control_posture.py`, registered `EVID-2026-325`, and extended the bibliography with `REF-BASH-JOB-CONTROL` + `REF-OPENGROUP-TERMINAL-IFACE`, so lint now rejects drift where integrated capshell quietly acquires a PTY / controlling-terminal / foreground-background control plane or smuggles deferred/background execution back in through shell session state

## Revised316 (2026-03-07)
- pin a **D-CAPSHELL word-expansion posture v0** so the integrated/front-end shell story cannot quietly reintroduce ambient namespace reads or token synthesis through shell convenience before reviewed execution begins:
  - added `docs/30-architecture/capshell-word-expansion-posture-v0.md`, freezing integrated/front-end capshell to an **exact-token** boundary — Phase 1 declines globbing, `~` lookup, brace expansion, `$VAR` / `${...}` expansion, `$(...)`, process substitution, word splitting, and pathname expansion before reviewed CH-ARGV is formed, so literal tokens stay exact unless an explicitly chosen interpreter later expands them under its own semantics
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/argv-schema-v0.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_word_expansion_posture.py` and registered `EVID-2026-324`, so lint now rejects drift where integrated/front-end capshell quietly synthesizes argv words or descriptor bindings through hidden glob/tilde/variable/command-substitution/word-splitting/pathname-expansion behavior before CH-ARGV review

## Revised315 (2026-03-07)
- pin a **D-CAPSHELL startup-profile posture v0** so the integrated shell story cannot quietly reintroduce ambient code-loading through login dotfiles, prompt hooks, or project-local auto-activation:
  - added `docs/30-architecture/capshell-startup-profile-posture-v0.md`, freezing integrated capshell startup to **explicit-only** session state — Phase 1 declines implicit rc/profile file loading (`/etc/profile`, `~/.profile`, `~/.bashrc`) and per-directory hooks (`.envrc`, `.env`, venv auto-activation), so prompt/cwd transitions are not code-loading events and any future startup customization must return as an explicit digest-bound surface
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_startup_profile_posture.py` and registered `EVID-2026-323`, so lint now rejects drift where integrated capshell startup stops being explicit-only, begins consulting host/user/project rc/profile files, or lets per-directory hooks such as `.envrc` become hidden code-loading events around prompt/cwd transitions

## Revised314 (2026-03-07)
- pin a **D-CAPSHELL command-string posture v0** so explicit exec selection does not quietly collapse back into shell parsing, quoting, or hidden `sh -c` convenience inside the runner:
  - added `docs/30-architecture/capshell-command-string-posture-v0.md`, freezing Phase 1 `capshell.exec` to **structured CH-ARGV only** — no free-form command-string execution form, no runner-side auto-tokenization or shell expansions, and no hidden `sh -c` / `system()` adapter; explicit shells remain allowed only as the bound `role="exec"` selector, with any command string left as ordinary argv data
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/argv-schema-v0.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_command_string_posture.py` and registered `EVID-2026-322`, so lint now rejects drift where workflow automation quietly reintroduces a second shell-language plane through free-form command strings, runner-side auto-tokenization, or hidden `sh -c` / `system()` indirection inside `capshell.exec`

## Revised313 (2026-03-07)
- pin a **D-CAPSHELL environment posture v0** so explicit exec selection cannot be bypassed by startup-file hooks, loader-search env, or runtime bootstrap/import-path env hidden in CH-ENV:
  - added `docs/30-architecture/capshell-env-startup-posture-v0.md`, freezing Phase 1 child environments to **complete+explicit only** — the runner injects only the declared CH-ENV entries, and validators/runners reject startup/resolution hook names instead of silently scrubbing or inheriting them (`PATH`, `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, `PYTHONSTARTUP`, `LD_*`, `BASH_FUNC_*`)
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/env-schema-v0.md`, `docs/30-architecture/capshell-exec-pack-schema-v2.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/deny-code-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_env_startup_posture.py` and registered `EVID-2026-321`, so lint now rejects drift where capshell quietly reintroduces code selection through inherited host env, shell startup files/functions, loader-search/injection env, or runtime bootstrap/import-path env inside CH-ENV

## Revised312 (2026-03-07)
- pin a **D-CAPSHELL script-entry posture v0** so explicit executable selection stays honest even when workflows run script/text artifacts:
  - added `docs/30-architecture/capshell-script-entry-posture-v0.md`, freezing Phase 1 script launch to **explicit interpreter binding only** — the interpreter itself remains the one CH-ARGV `role="exec"` selector, shebangs are non-authoritative metadata, and the runner must fail closed instead of honoring `#!/usr/bin/env`, filename-suffix association, or ENOEXEC-style shell fallback
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/30-architecture/argv-schema-v0.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_capshell_script_entry_posture.py` and registered `EVID-2026-320`, so lint now rejects drift where script launch quietly reintroduces interpreter lookup through shebangs, `#!/usr/bin/env`, filename associations, or ENOEXEC-style shell fallback inside the capshell runner

## Revised311 (2026-03-07)
- pin a **D-CAPSHELL learn-mode posture v0** so the archive’s “adoptable automation” story cannot quietly drift into allow-and-remember behavior, hidden contract mutation, or a self-healing approval plane:
  - added `docs/30-architecture/capshell-learnmode-posture-v0.md`, freezing learn mode as **observational only** — `capshell.exec` still follows the same fail-closed validator/runner path, denied effects/bind failures stay denials, reports stay **non-authoritative** and **stage-local** (bound at least to CH-EFFCON `contract_id`, `wallet_core_digest`, and the exact exec selector), and Phase 1 forbids auto-edit / auto-approve / auto-rerun behavior or any new `capshell.learn.*` ACP/admin surface
  - wired the new posture through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `docs/60-engineering/authority-bracketing-and-promise-learning.md`, `docs/70-llm-control/acp-action-kind-registry.md`, `docs/70-llm-control/acp-validator-semantics.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_capshell_learnmode_posture.py` and registered `EVID-2026-319`, so lint now rejects drift where learn mode stops being observational, starts auto-editing/auto-approving/auto-rerunning workflows, loses stage-local binding to the active execution shape, or grows a new `capshell.learn.*` action/admin plane

## Revised310 (2026-03-07)
- pin a **D-CAPMODE v0 posture** so “no ambient authority” stops floating as an aspirational slogan and becomes a small, enforceable Phase 1 execution posture:
  - added `docs/30-architecture/capmode-posture-v0.md`, freezing **capability mode as one-way, no ambient acquire after entry** — existing explicit handles remain usable, explicit handoff remains allowed, but path/env/default-service/DNS/global-namespace fallback must fail closed, D-CAPMODE adds **no new IF-/CH-/ACP/admin surface**, and long-lived services are expected to compose it with D-SEAL rather than treating capmode alone as sufficient narrowing
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `rfcs/0010-ambient-authority-and-capability-mode.md`, `docs/10-threat-model/abuse-cases.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_capmode_posture.py` and registered `EVID-2026-318`, so lint now rejects drift where D-CAPMODE quietly grows a query/admin plane, reintroduces ambient fallback after entry, or stops being discoverable as the explicit “no ambient acquire” posture across the archive

## Revised309 (2026-03-07)
- pin a **D-NAMECERT label-atom boundary v0** so local naming cannot quietly widen into dotted hierarchy, wildcard/prefix matching, or an implicit path/query language just because punctuation is allowed inside labels:
  - added `docs/30-architecture/namecert-label-atom-boundary-v0.md`, freezing Phase 1 `Binding.name` / `Delegation.role` semantics to **single opaque atoms after validation** — `.` / `_` / `-` remain ordinary bytes, **no hierarchy / wildcard / prefix-suffix / path grammar exists on the core seam**, and exact-label matches never split `ops.admin` into hidden sublookups
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/10-threat-model/abuse-cases.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_label_atom_boundary.py` and registered `EVID-2026-317`, so lint now rejects drift where punctuation inside CH-NAMECERT labels silently becomes hierarchy, wildcard/prefix expansion, or subtree inference on the authority-bearing naming seam

## Revised308 (2026-03-07)
- pin a **D-NAMECERT redelegation boundary v0** so local naming cannot quietly widen into hidden propagation-depth policy, “delegated once means trusted to delegate”, or accidental SPKI-style multi-hop delegation semantics:
  - added `docs/30-architecture/namecert-redelegation-boundary-v0.md`, freezing Phase 1 to **no implied onward delegation** — admitted `Delegation` statements grant authority only from bundle issuer to subject, **CH-NAMECERT v0 carries no `may_delegate` / propagation-bit / depth field**, and multi-hop delegation chains reject unless each issuer is independently authorized under explicit evaluator-local policy
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/10-threat-model/abuse-cases.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_redelegation_boundary.py` and registered `EVID-2026-316`, so lint now rejects drift where delegated subjects silently gain onward delegation power, multi-hop chains are accepted without an explicit propagation seam, or implied redelegation semantics leak into D-NAMECERT v0

## Revised307 (2026-03-07)
- pin a **D-NAMECERT metadata boundary v0** so local naming cannot quietly widen into latest-bundle-wins resolver behavior, implicit replacement lineage, or metadata-driven freshness/obsolescence semantics:
  - added `docs/30-architecture/namecert-metadata-boundary-v0.md`, freezing **`bundle_id` / `created_ms` as signed provenance metadata only** in Phase 1 — they may aid audit/correlation, but they do **not** rank candidates, supersede earlier bundles, define freshness by themselves, or justify attach/detach without the exact source digest and explicit target-seam action
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/10-threat-model/abuse-cases.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_metadata_boundary.py` and registered `EVID-2026-315`, so lint now rejects drift where `bundle_id` / `created_ms` silently become winner-selection, replacement, or freshness/obsolescence inputs on the D-NAMECERT seam

## Revised306 (2026-03-07)
- pin a **D-NAMECERT signature-profile boundary v0** so local naming cannot quietly widen into wrapper confusion, keyless/X.509 identity policy, or multisignature/quorum semantics:
  - added `docs/30-architecture/namecert-signature-profile-v0.md`, freezing admitted Phase 1 CH-NAMECERT bundles to **one inline direct Ed25519 signature profile** — **the inline `sig` field is mandatory**, **`sig.alg="ed25519"` only**, **verification uses the canonical unsigned bundle bytes**, and **wrapper-only / keyless / multisignature admissions reject**
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/bibliography.md`, `docs/10-threat-model/abuse-cases.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_signature_profile.py`, registered `EVID-2026-314`, and extended the bibliography with `REF-EDDSA-RFC8032`, so lint now rejects drift where CH-NAMECERT silently accepts wrapper-only/keyless/X.509 admission, multisignature semantics, or non-canonical inline signature preimages on the authority-bearing seam

## Revised305 (2026-03-07)
- pin a **D-NAMECERT normal-form boundary v0** so local naming cannot quietly widen into order-sensitive resolver behavior, duplicate-weighted delegation semantics, or many-digests-for-the-same-practical-statement-set drift:
  - added `docs/30-architecture/namecert-normal-form-boundary-v0.md`, freezing admitted Phase 1 `bindings` / `delegations` arrays to one **duplicate-free strict normal form** — elements are **strictly sorted by canonical bytes**, **exact duplicates reject**, and statement order/repetition is **non-authoritative** (no first-match, no last-match, no duplicate weighting)
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/10-threat-model/abuse-cases.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_normal_form_boundary.py` and registered `EVID-2026-313`, so lint now rejects drift where CH-NAMECERT silently accepts reordered/duplicate statement arrays, first/last-match semantics, or duplicate-by-repetition authority inflation inside admitted bundles

## Revised304 (2026-03-07)
- pin a **D-NAMECERT principal-profile boundary v0** so local naming cannot quietly widen into mixed raw-key/digest aliases, ad-hoc key-distribution semantics, or bundle-carried verifier identity rules:
  - added `docs/30-architecture/namecert-principal-profile-v0.md`, freezing admitted Phase 1 `issuer` / `subject` identities to one canonical **hash-only** profile — **`PrincipalRef.kind="key_hash"` only**, **`alg="cose_key_thumbprint_sha256"` only**, **exact 32-byte thumbprints**, and **raw `PrincipalRef.kind="pubkey"` admissions reject**
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/bibliography.md`, `docs/10-threat-model/abuse-cases.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_principal_profile.py`, registered `EVID-2026-312`, and extended the bibliography with `REF-COSEKEYTHUMBPRINT-RFC9679`, so lint now rejects drift where admitted CH-NAMECERT bundles silently accept raw `PrincipalRef.kind="pubkey"` identities, mixed principal-id schemes, or non-canonical thumbprint semantics on the authority-bearing seam

## Revised303 (2026-03-07)
- pin a **D-NAMECERT bearer boundary v0** so local naming cannot quietly widen into a bearer-secret transport, a stealth capability wallet, or a hidden CH-SREF / CH-CAPX import path:
  - added `docs/30-architecture/namecert-bearer-boundary-v0.md`, freezing admitted Phase 1 CH-NAMECERT bundles as **non-bearer naming evidence only** — raw **CH-SREF** / **CH-CAPX** / raw capability material is forbidden, **`TargetRef.kind="sturdyref"` is reserved+rejected**, `proxy` targets remain descriptor-only, and any capability-bearing import/restore stays on explicit **D-CAPX / CH-SREF** seams rather than piggybacking on naming evidence
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/10-threat-model/abuse-cases.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-projection-boundary-v0.md`, `docs/30-architecture/namecert-replication-boundary-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `docs/30-architecture/sturdyref-posture-v0.md`, `docs/30-architecture/capx-posture-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_bearer_boundary.py` and registered `EVID-2026-311`, so lint now rejects drift where CH-NAMECERT silently embeds bearer restore/import material, treats `TargetRef.kind="sturdyref"` as an active restore path, or lets capability-bearing import leak out of the explicit D-CAPX / CH-SREF seams

## Revised302 (2026-03-07)
- pin a **D-NAMECERT string-profile boundary v0** so local naming cannot quietly widen into Unicode preparation, locale-aware comparison, or confusable-management policy on the authority-bearing seam:
  - added `docs/30-architecture/namecert-string-profile-v0.md`, freezing Phase 1 `Binding.name` / `Delegation.role` labels to a tiny **exact-byte lowercase ASCII** class (`[a-z0-9._-]`, 1..64 bytes, first/last alnum), with **no Unicode normalization**, **no case-folding**, **no PRECIS/Stringprep**, and **no confusable-policy dataset** imported onto D-NAMECERT itself
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/bibliography.md`, `docs/10-threat-model/abuse-cases.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_string_profile.py`, registered `EVID-2026-310`, and extended the bibliography with `REF-PRECIS-RFC8264` + `REF-UNICODE-UTS39`, so lint now rejects drift where D-NAMECERT silently grows Unicode normalization/case-folding aliases, locale-aware matching, or confusable-policy machinery on authority-bearing labels

## Revised301 (2026-03-07)
- pin a **D-NAMECERT trust-root boundary v0** so local naming cannot quietly widen into a self-certifying PKI, ambient/system-root inheritance, or replicated root-store distribution plane:
  - added `docs/30-architecture/namecert-trust-root-boundary-v0.md`, freezing trust anchoring as **explicit evaluator-local input** only — **CH-NAMECERT is not itself a trust root or trust-policy container**, bundles cannot self-anchor or auto-promote issuers they mention, replicated arrivals cannot auto-install anchors or rewrite issuer allowlists, and changing local trust policy changes only **future** admissions rather than silently rewriting live `view.slot` bindings
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `docs/30-architecture/namecert-replication-boundary-v0.md`, `docs/30-architecture/replication-contracts-v0.md`, `docs/30-architecture/view-namespace-posture-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_trust_root_boundary.py` and registered `EVID-2026-309`, so lint now rejects drift where D-NAMECERT silently grows bundle self-anchoring, ambient/system-root inheritance, replicated trust-root distribution, or trust-policy changes that magically mutate live namespace state

## Revised300 (2026-03-07)
- pin a **D-NAMECERT search boundary v0** so local naming cannot quietly widen into a distributed credential-discovery protocol, unbounded graph chase, or daemonized resolver engine:
  - added `docs/30-architecture/namecert-search-boundary-v0.md`, freezing Phase 1 evaluation to **closed-world, bounded local search over one explicit CH-NAMECERT bundle set**, allowing local goal-directed evaluation but forbidding **ambient fetch**, **suspend/resume credential retrieval**, **hidden background retry**, and **distributed chain discovery**; cyclic or duplicate structures must use deterministic visited-state suppression (or equivalent) and bound exhaustion must **fail closed** rather than widen authority or continue in the background
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `docs/30-architecture/namecert-projection-boundary-v0.md`, `docs/30-architecture/namecert-replication-boundary-v0.md`, `docs/30-architecture/view-namespace-posture-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_search_boundary.py` and registered `EVID-2026-308`, so lint now rejects drift where D-NAMECERT silently grows distributed chain discovery, hidden retry/fetch behavior, nondeterministic cycle handling, or unbounded search semantics on the naming seam

## Revised299 (2026-03-07)
- pin a **D-NAMECERT selection boundary v0** so multi-candidate local naming never quietly becomes a hidden resolver-preference engine:
  - added `docs/30-architecture/namecert-selection-boundary-v0.md`, freezing Phase 1 evaluation as **set-valued** whenever multiple admissible candidates survive local policy, with **no default ranking/winner rule** on D-NAMECERT itself, **no arrival-order/chain-length/signature-count tie-break semantics**, and **mandatory exact-candidate `digest(CH-NAMECERT v0)` provenance** for any live `view.slot` materialization
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `docs/30-architecture/namecert-projection-boundary-v0.md`, `docs/30-architecture/namecert-replication-boundary-v0.md`, `docs/30-architecture/view-namespace-posture-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_selection_boundary.py`, registered `EVID-2026-307`, and extended the bibliography with `REF-RT0-DISCOVERY`, so lint now rejects drift where D-NAMECERT silently grows hidden ranking/default-winner semantics, loses exact-candidate provenance, or imports a credential-graph / chooser engine onto the core naming seam

## Revised298 (2026-03-07)
- pin a **D-NAMECERT revocation boundary v0** so later issuer withdrawal / negative evidence cannot quietly become an ambient CRL/OCSP dependency, a hidden latest-wins resolver, or an automatic live-namespace mutation plane:
  - added `docs/30-architecture/namecert-revocation-boundary-v0.md`, freezing Phase 1 to **explicit evaluator-local negative evidence only** (deny/replacement/epoch-style inputs under local policy), with **no portable revocation/status artifact on CH-NAMECERT itself**, **no ambient revocation/discovery service**, **no latest-bundle-wins semantics**, and **no automatic `view.detach` / receipt rewriting** when revocation is learned later
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-projection-boundary-v0.md`, `docs/30-architecture/namecert-time-boundary-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `docs/30-architecture/view-namespace-posture-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_revocation_boundary.py` and registered `EVID-2026-306`, so lint now rejects drift where CH-NAMECERT learns ambient revocation/discovery semantics, latest-wins resolver behavior, or hidden auto-detach authority over live `view.slot` bindings

## Revised297 (2026-03-07)
- pin a **D-NAMECERT time boundary v0** so local naming validity/freshness cannot quietly turn into an ambient lease manager or time-driven namespace control plane:
  - added `docs/30-architecture/namecert-time-boundary-v0.md`, freezing Phase 1 to **admission-only** time/freshness checks under explicit **D-NONDET / D-TIMEPROOF** policy, with **no automatic `view.detach` on expiry**, **no background re-evaluation/sweeper**, **no timeproof-triggered reconcile**, and **no retroactive receipt rewriting** for already-materialized `view.slot` bindings
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `docs/30-architecture/namecert-projection-boundary-v0.md`, `docs/30-architecture/view-namespace-posture-v0.md`, `docs/30-architecture/timeproof-posture-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_time_boundary.py` and registered `EVID-2026-305`, so lint now rejects drift where CH-NAMECERT expiry/freshness silently becomes auto-detach authority, background reconcile logic, or an ambient time-driven namespace control plane

## Revised296 (2026-03-07)
- pin a **D-NAMECERT projection boundary v0** so accepted local naming results cannot quietly become live namespace state through hidden resolver cache state or bulk bundle install:
  - added `docs/30-architecture/namecert-projection-boundary-v0.md`, freezing Phase 1 authority-bearing materialization to explicit **D-NS `view.attach` / `view.detach`** on concrete **`view.slot`** keys only, requiring retained source **`digest(CH-NAMECERT v0)`** provenance on target-seam proposal/receipt surfaces, keeping ordering at **`svc:view`**, and declining any bulk install / watch-sync / hidden resolver-cache activation path
  - wired the new boundary through `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/00-meta/resolved-history.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-posture-v0.md`, `docs/30-architecture/namecert-schema-v0.md`, `docs/30-architecture/view-namespace-posture-v0.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, `docs/00-meta/bibliography.md`, and `tools/README.md`
- added `tools/check_namecert_projection_boundary.py`, registered `EVID-2026-304`, and extended the bibliography with `REF-KEYNOTE-RFC2704`, so lint now rejects drift where D-NAMECERT silently grows a hidden bundle→namespace activation path, loses source-digest retention for materialized bindings, or imports a portable compliance/policy checker onto the core seam

## Revised295 (2026-03-07)
- pin a **D-NAMECERT v0 posture** so local naming/delegation stops floating as an open-ended global resolver / PKI / policy-language idea:
  - added `docs/30-architecture/namecert-posture-v0.md`, freezing Phase 1 to **issuer-local**, **user-space** CH-NAMECERT evaluation over **explicit bundle sets** only, with **no privileged-core chain evaluator**, **no ambient fetch/global resolver**, **no auto-install into views**, **fail-closed unsupported constraints**, and **no new workflow / ACP / conflict-key / admin surface** on D-NAMECERT itself
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/30-architecture/namecert-schema-v0.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0023-local-naming-certificates-spki-sdsi.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_namecert_posture.py`, registered `EVID-2026-303`, and extended the bibliography with `REF-UCAN-SPEC`, so lint now rejects drift where D-NAMECERT stops being discoverable, regresses into ambient/global resolution or automatic view install, or quietly grows a portable policy/caveat VM on the authority substrate

## Revised294 (2026-03-07)
- pin a **D-CAPX v0 posture** so cross-boundary delegation stops floating as an open-ended “remote token becomes local cap” / hidden caveat-VM idea:
  - added `docs/30-architecture/capx-posture-v0.md`, freezing Phase 1 to a **gateway-owned, proxy-first import seam** where accepted CH-CAPX binds only to local **proxy/service** objects, remote delegation stays **off by default**, routine workflow/observation surfaces carry **`digest(CH-CAPX v0)`** rather than raw bytes, and D-CAPX declines any ambient resolver, token inventory/probing API, or portable macaroon/biscuit/captp caveat VM in the core seam
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0004-networked-capabilities-and-delegation-tokens.md`, `rfcs/0026-object-capability-rpc-profile.md`, `docs/30-architecture/capability-export-schema-v0.md`, `docs/30-architecture/schema-registry.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_capx_posture.py` and registered `EVID-2026-302`, so lint now rejects drift where D-CAPX stops being discoverable, regresses into raw-cap binding / ambient resolution / token inventory drift, or quietly grows a portable caveat-policy VM on the authority substrate

## Revised293 (2026-03-07)
- pin a **D-CAPRPC oneway v0 posture** so pulse-style notifications stop floating as an open-ended mailbox / callback-bus / hidden scheduler idea:
  - added `docs/30-architecture/caprpc-oneway-posture-v0.md`, freezing Phase 1 to **interface-marked oneway only**, **no third CH-CAPRPC frame kind**, **enqueue-or-error semantics**, **payload <= 256 bytes**, **zero capability attachments**, **no pipelined/promised-answer oneway**, and **no durable backlog / workflow / ACP / admin surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0026-object-capability-rpc-profile.md`, `docs/30-architecture/capability-rpc-frame-schema-v0.md`, `docs/30-architecture/capability-rpc-frame-schema-v1.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_caprpc_oneway_posture.py`, registered `EVID-2026-301`, and extended the bibliography with `REF-GENODE-SIGNALS`, so lint now rejects drift where D-CAPRPC oneway stops being discoverable, regresses into a durable mailbox/callback surface, or quietly widens into capability-smuggling, bulk-transfer, or hidden scheduling semantics

## Revised292 (2026-03-07)
- pin a **D-CAPRPC session v0 posture** so live capability-RPC state stops floating as an open-ended reconnect/resume / endpoint-inventory idea:
  - added `docs/30-architecture/caprpc-session-posture-v0.md`, freezing Phase 1 to **explicit, connection-specific, session-scoped live refs**, **fail-stop disconnect**, **explicit bootstrap/introducer or CH-CAPX / CH-SREF restore for continuity**, **runtime-private non-replicated session bookkeeping**, and **no transparent reconnect/resume, session/object inventory, or workflow/ACP/admin surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0026-object-capability-rpc-profile.md`, `docs/30-architecture/capability-rpc-frame-schema-v0.md`, `docs/30-architecture/capability-rpc-frame-schema-v1.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_caprpc_session_posture.py`, registered `EVID-2026-300`, and reused the existing Cap’n Proto / CapTP bibliography wiring, so lint now rejects drift where D-CAPRPC live-session semantics stop being discoverable, regress into transparent reconnect/resume or public session/object inventory, or quietly widen into an ambient endpoint namespace / hidden connection-manager control plane

## Revised291 (2026-03-07)
- pin a **D-CAPRPC promise v0 posture** so capability-RPC latency tolerance stops floating as an open-ended promise-broker / hidden-scheduler idea:
  - added `docs/30-architecture/caprpc-promise-posture-v0.md`, freezing Phase 1 to **caller-local, session-scoped, one-shot promise handles**, **capability-result-only pipelining**, **deterministic broken-promise/disconnect outcomes**, **no public promise inventory/combinator/admin surface**, and **no new workflow/ACP/conflict-key surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0026-object-capability-rpc-profile.md`, `docs/30-architecture/capability-rpc-frame-schema-v0.md`, `docs/30-architecture/capability-rpc-frame-schema-v1.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_caprpc_promise_posture.py`, registered `EVID-2026-299`, and extended the bibliography with `REF-CAPNP-CXXRPC` + `REF-E-REFMECH`, so lint now rejects drift where D-CAPRPC promise/pipelining stops being discoverable, regresses into a promise inventory/combinator/admin seam, or quietly widens into a hidden scheduler / cross-session export surface
- fixed the current-tree lint regression in `docs/30-architecture/turns-posture-v0.md` by restoring the exact required “no new workflow / ACP / admin surface on D-TURNS” anchor phrase expected by `tools/check_turns_posture.py`

## Revised290 (2026-03-07)
- pin a **D-TURNS v0 posture** so turn-based services stop floating as an open-ended scheduler/reentrancy idea:
  - added `docs/30-architecture/turns-posture-v0.md`, freezing Phase 1 to a **per-component runtime discipline** with **exactly one active turn per vat**, **far-call async only**, **no hidden inbox pumping**, **no portable reentrancy/interleaving knob**, and **no new workflow/ACP/conflict-key surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0078-turn-based-concurrency-and-reentrancy-guards.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_turns_posture.py`, registered `EVID-2026-298`, and extended the bibliography with `REF-ORLEANS-REQUEST-SCHED`, so lint now rejects drift where D-TURNS stops being discoverable, regresses into a scheduler contract or portable reentrancy/interleaving surface, or quietly loses the "one active turn, no hidden inbox pumping" posture

## Revised289 (2026-03-07)
- pin a **D-POWERBOX v0 posture** so consent mediation stops floating as an open-ended permission-store / target-oracle idea:
  - added `docs/30-architecture/powerbox-posture-v0.md`, freezing Phase 1 to a **designation-scoped**, **chooser-owned** seam where requesters describe only a bounded authority shape, results are **concrete capability outcomes** rather than ambient names, and the core seam declines any generic remembered-grant library, approval/candidate inventory, callback/path result surface, or new CH-ACP/conflict-key surface
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, `docs/30-architecture/authorization-token-schema-v0.md`, `docs/30-architecture/interface-registry.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_powerbox_posture.py` and registered `EVID-2026-297`, so lint now rejects drift where D-POWERBOX stops being discoverable, regresses into a generic remembered-grant library or app-visible approval/candidate inventory, or quietly turns ambient names/paths/callback routes into the portable result of consent mediation

## Revised288 (2026-03-07)
- pin a **D-PLUMB portal-session v0 posture** so generic portal lifecycle stops floating as an open-ended resumable-broker / live-object-inventory idea:
  - added `docs/30-architecture/portal-session-posture-v0.md`, freezing Phase 1 to **provider-owned request/session objects**, **one terminal outcome per request**, **family-local long-lived sessions only**, **no generic resume/list/watch/callback surface**, and **no new CH-ACP/conflict-key surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `docs/60-engineering/portal-design-playbook.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_portal_session_posture.py`, registered `EVID-2026-296`, and extended the bibliography with `REF-XDG-PORTAL-SESSION`, so lint now rejects drift where generic portal request/session objects stop being discoverable, regress into a resumable callback/inventory surface, or quietly widen family-specific persistence semantics back into the D-PLUMB core

## Revised287 (2026-03-07)
- pin a **D-PLUMB v0 core posture** so workflow routing stops floating as an open-ended message-bus / callback / launcher-oracle idea:
  - added `docs/30-architecture/plumb-posture-v0.md`, freezing Phase 1 to an **explicit-invocation**, **request-local** seam with **no generic `Subscribe(port)` durable inbox/outbox**, **no callback URL/port registry**, **no app-visible handler/route inventory**, and **no new CH-ACP/conflict-key surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0117-plumb-messages-and-cli-intents.md`, `docs/30-architecture/plumb-message-schema-v0.md`, `docs/30-architecture/route-rules-schema-v0.md`, `docs/60-engineering/cli-plumbing-tooling.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_plumb_posture.py`, registered `EVID-2026-295`, and extended the bibliography with `REF-XDG-PORTAL-REQUEST` + `REF-XCALLBACK-URL`, so lint now rejects drift where D-PLUMB stops being discoverable, regresses into a durable inbox/outbox or callback-registry seam, or quietly grows an app-visible handler/route inventory oracle

## Revised286 (2026-03-07)
- pin a **D-BRACKET / CH-CALLCHAIN v0 posture** so helper hygiene stops floating as an open-ended stack-inspection / ambient thread-local idea:
  - added `docs/30-architecture/bracket-posture-v0.md`, freezing Phase 1 to a **borrowed-mode-by-default** runtime seam with **task/request-local dynamic scope**, **explicit exception-safe privileged blocks**, **bounded optional CH-CALLCHAIN metadata**, **no portable stack inspection/kernel enforcement**, and **no new workflow/ACP surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0118-privilege-bracketing-and-call-chain-contexts.md`, `docs/30-architecture/call-chain-schema-v0.md`, `docs/30-architecture/request-context-schema-v1.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_bracket_posture.py`, registered `EVID-2026-294`, and extended the bibliography with `REF-OPENJDK-SCOPEDVALUES`, `REF-PEP-567`, and `REF-PY-CONTEXTVARS`, so lint now rejects drift where D-BRACKET stops being discoverable, regresses into ambient/global privilege toggles or kernel stack inspection, or quietly loses the borrowed-mode / task-local scoped-privilege / deny-only call-chain posture

## Revised285 (2026-03-07)
- pin a **CH-ORDERTOK / D-COMMUTE v0 posture** so ordered actions stop floating as an open-ended sequencing-service idea:
  - added `docs/30-architecture/ordering-token-posture-v0.md`, freezing Phase 1 to a **scope-bound**, **owner-minted witness** seam with **exactly one conflict-key stream per portable scope**, **digest-first evidence**, **no portable sequencer / range-allocation / global-stream surface**, and **no new workflow/ACP/admin surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/commutativity-and-interface-scalability.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0119-ordering-streams-and-tokens.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_ordering_token_posture.py`, registered `EVID-2026-293`, and extended the bibliography with `REF-KAFKA-PARTITION-ORDER`, `REF-ZK-ZXID`, and `REF-FDB-VERSIONSTAMP`, so lint now rejects drift where CH-ORDERTOK stops being discoverable, regresses into a portable sequencer/global-stream/range-allocation surface, or quietly loses the “one conflict-key stream, owner-minted witness” posture

## Revised284 (2026-03-07)
- pin a **D-REQCTX v0 posture** so request contexts stop floating as an open-ended baggage/detach/control idea:
  - added `docs/30-architecture/reqctx-posture-v0.md`, freezing Phase 1 to a **sticky, tree-shaped coordination seam** with **one absolute monotonic deadline intent**, **bounded correlation-only tags**, **no portable detach/shield/cancel-cause fields**, and **no new workflow/ACP surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0105-request-contexts-deadlines-and-cancellation.md`, `docs/30-architecture/request-context-schema-v0.md`, `docs/30-architecture/request-context-schema-v1.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_reqctx_posture.py`, registered `EVID-2026-292`, and extended the bibliography with `REF-GO-PKG-CONTEXT` + `REF-TRIO-CANCELSCOPE`, so lint now rejects drift where D-REQCTX stops being discoverable, regresses into a baggage/detach/cancel-cause seam, or quietly grows a second workflow/control surface

## Revised283 (2026-03-07)
- pin a **D-IOQ v0 posture** so performance batching stops floating as an open-ended async syscall / packet-routing idea:
  - added `docs/30-architecture/ioq-posture-v0.md`, freezing Phase 1 to a **provider-owned**, **explicit-handle-only**, **single-op** seam with **completion payloads staying on the queue ring**, **no path/open/create constructors**, **no linked chains / multishot / queue-to-queue message injection**, **no per-SQE credential override or public preregistered inventory**, and **no new workflow/ACP surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0107-io-submission-queues-and-completions.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_ioq_posture.py`, registered `EVID-2026-291`, and extended the bibliography with `REF-LINUX-IOURING-REGISTER`, `REF-WIN-IORING-REGISTERFILEHANDLES`, and `REF-WIN-IORING-REGISTERBUFFERS`, so lint now rejects drift where D-IOQ stops being discoverable, regresses into path-based/linked/message-ring queue semantics, or quietly grows a second authority/inventory surface

## Revised282 (2026-03-07)
- pin a **D-QUIESCE v0 posture** so maintenance control stops floating as an open-ended freezer/orchestrator idea:
  - added `docs/30-architecture/quiesce-posture-v0.md`, freezing Phase 1 to a **cooperative**, **component-local** seam with **one active qid**, **`DRAIN|CANCEL` only**, **no force-kill/global freeze semantics**, and **no new workflow/ACP surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0108-quiescence-and-drain-protocol.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_quiesce_posture.py` and registered `EVID-2026-290`, so lint now rejects drift where D-QUIESCE stops being discoverable, regresses into a force-kill/global-freeze/admin seam, or quietly loses the single-active-qid / supervisor-owned escalation posture

## Revised281 (2026-03-07)
- pin a **D-WAITSET v0 posture** so scalable event loops stop floating as an open-ended packet/filter/control-plane idea:
  - added `docs/30-architecture/waitset-posture-v0.md`, freezing Phase 1 to an **observational**, **explicit-binding**, **level-triggered-by-default** seam with **`tag + observed_mask` only**, **no user-injected packet queue**, **no edge/one-shot default contract**, and **no new workflow/ACP surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0106-wait-sets-and-object-signals.md`, `rfcs/0107-io-submission-queues-and-completions.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_waitset_posture.py`, registered `EVID-2026-289`, and extended the bibliography with `REF-ZIRCON-OBJECT-WAIT-ASYNC` + `REF-WIN-POSTQUEUEDCOMPLETIONSTATUS`, so lint now rejects drift where D-WAITSET stops being discoverable, regresses into a packet/control-plane seam, or quietly inherits edge-triggered/user-injected semantics by accident

## Revised280 (2026-03-07)
- pin a **D-ROBUSTLOCK v0 posture** so owner-death recovery stops floating as an open-ended shared-lock / scheduler idea:
  - added `docs/30-architecture/robustlock-posture-v0.md`, freezing Phase 1 to a **runtime-owned per-thread RobustSet**, **mutex-only**, **component-local** seam with explicit **`OWNER_DIED` / `NOT_RECOVERABLE`** recovery states, **no cross-process robust recovery claim**, and **no new workflow/ACP surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0111-robust-locks-and-owner-death.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_robustlock_posture.py` and registered `EVID-2026-288`, so lint now rejects drift where D-ROBUSTLOCK stops being discoverable, regresses into cross-process/kernel-lock-manager semantics, or quietly loses the explicit make-consistent-or-poison contract

## Revised279 (2026-03-07)
- pin a **D-UWAIT v0 posture** so fast lock blocking stops floating as an open-ended shared-memory/scheduler seam:
  - added `docs/30-architecture/uwait-posture-v0.md`, freezing Phase 1 to a **process-local**, **aligned-32-bit**, **wait+wake-only** seam with **no cross-process wait channel**, **no in-core requeue/PI/owner semantics**, **explicit re-check-after-wake discipline**, and **no new workflow/ACP surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0110-wait-on-address-and-futex-primitives.md`, `rfcs/0111-robust-locks-and-owner-death.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_uwait_posture.py` and registered `EVID-2026-287`, so lint now rejects drift where D-UWAIT stops being discoverable, regresses into a cross-process/shared wait channel, or quietly widens into requeue/PI/workflow surface area

## Revised278 (2026-03-07)
- pin a **D-RSEQ v0 posture** so CPU-local fast paths stop floating as an open-ended ABI/scheduler idea:
  - added `docs/30-architecture/rseq-posture-v0.md`, freezing Phase 1 to a **runtime-owned, single-slot, thread-local rseq seam** with **no ambient `getcpu` / topology oracle**, **no nested or multiplexed registrations**, **explicit abort-to-slow-path behavior**, and **no new workflow/ACP surface**
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0113-restartable-sequences-and-cpu-local-fast-paths.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_rseq_posture.py` and registered `EVID-2026-286`, so lint now rejects drift where D-RSEQ stops being discoverable, regresses into an ambient CPU-id/topology oracle, or quietly widens into a new admin/workflow seam

## Revised277 (2026-03-07)
- pin a **D-RCU v0 posture** so read-mostly sharing stops floating as an open-ended concurrency idea:
  - added `docs/30-architecture/rcu-posture-v0.md`, freezing Phase 1 to **QSBR-first**, **per-subsystem/user-space GraceDomains**, **no ambient/global collector**, **bounded/attributable limbo**, and **no new workflow/ACP surface**; EBR stays runtime-local when needed rather than becoming a platform-wide policy seam
  - wired the new posture through `README.md`, `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/profile-posture-matrix.md`, `docs/30-architecture/decision-map.md`, `docs/30-architecture/mechanisms.md`, `docs/00-meta/resolved-history.md`, `docs/00-meta/llm-runbook.md`, `rfcs/0112-grace-periods-and-deferred-reclamation.md`, `docs/00-meta/bibliography.md`, `docs/00-meta/evidence-index.md`, and `tools/README.md`
- added `tools/check_rcu_posture.py` and registered `EVID-2026-285`, so lint now rejects drift where D-RCU stops being discoverable, regresses into a hidden global collector, or loses its primary user-space/QSBR-first posture

## Revised276 (2026-03-06)
- add a preferred **one-shot handoff command** so release packaging no longer depends on remembering a multi-step sequence:
  - added `make handoff-release STAMP=YYYY.MM.DD.HH.MM SLUG=<slug>` as `context-pack -> lint -> package-release`, keeping the canonical zip handoff on one explicit path while preserving `make package-release ...` for split-step debugging
  - updated `tools/gen_context_pack.py`, `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/60-engineering/release-packaging-contract.md`, `docs/20-assurance/invariant-registry.md`, `docs/20-assurance/proof-obligation-registry.md`, `docs/00-meta/evidence-index.md`, `tools/README.md`, and `tools/check_release_packaging_contract.py` so the archive's continuation/handoff surfaces advertise the same preferred command
- added `tools/check_release_handoff_command.py` and registered `EVID-2026-284`, so lint now rejects drift where the one-shot handoff path disappears from the Makefile or diverges from the docs/context-pack surfaces

## Revised275 (2026-03-06)
- tighten the canonical zip handoff's continuation-memory freshness check so `make package-release ...` now refuses `out/context_pack.md` unless its **header revision/date and `## New in latest revision` bullets** both mirror the top `CHANGELOG.md` entry, closing the remaining loophole where a manually edited header could still package stale latest-change memory
- add `tools/check_release_context_pack_summary_mirror.py` (`EVID-2026-283`) and tighten `tools/check_release_context_pack_freshness.py`, `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `docs/60-engineering/release-packaging-contract.md`, and `tools/README.md` so the release path explicitly treats the context pack's latest-summary section as part of the fail-closed handoff contract

## Revised274 (2026-03-06)
- make the canonical zip handoff **refuse stale continuation memory**:
  - updated `tools/package_release.py` so `make package-release ...` now rejects `out/context_pack.md` when its header revision/date no longer match the top `CHANGELOG.md` entry, instead of packaging a stale continuation prompt by mere existence
  - tightened `docs/60-engineering/release-packaging-contract.md`, `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, and `tools/README.md` so the release path explicitly requires a fresh context pack before packaging
- added `tools/check_release_context_pack_freshness.py` and registered `EVID-2026-282`, so lint now rejects drift where the handoff zip can quietly bundle stale archive-memory even after the docs have moved on

## Revised273 (2026-03-06)
- make the canonical zip handoff **fail closed at packaging time**:
  - updated `tools/package_release.py` so `make package-release ...` now runs the canonical bundle verifier on the just-built zip before reporting success, rather than relying on a separate manual verification step to catch packager/verifier drift
  - updated `tools/verify_release_bundle.py` to expose shared `verify_bundle(...)` logic, keeping package-time and standalone verification on the same code path
- wired the self-verifying packaging contract through `docs/60-engineering/release-packaging-contract.md`, `docs/60-engineering/release-bundle-manifest-contract.md`, `docs/60-engineering/release-bundle-verification-contract.md`, `README.md`, `docs/README.md`, `docs/00-meta/llm-runbook.md`, `tools/README.md`, and the assurance/evidence surfaces
- added `tools/check_release_package_self_verify.py` and registered `EVID-2026-281`, so lint now rejects drift where `make package-release` and `make verify-release` silently diverge again

## Revised272 (2026-03-06)
- make the canonical zip handoff **explicitly verifiable as a first-class artifact**:
  - added `docs/60-engineering/release-bundle-verification-contract.md`, `tools/verify_release_bundle.py`, and `make verify-release BUNDLE=/abs/path/to/SlopOS-rev####-YYYY.MM.DD.HH.MM-<slug>.zip` so the archive can verify the produced bundle against its embedded `RELEASE-MANIFEST.json`, canonical filename shape, exact file list / sizes / SHA-256s, and normalized zip metadata before handoff
  - wired the new verification contract through `docs/60-engineering/release-packaging-contract.md`, `docs/60-engineering/release-bundle-manifest-contract.md`, `docs/README.md`, `README.md`, `docs/00-meta/llm-runbook.md`, `tools/README.md`, and `docs/00-meta/bibliography.md`
- added `tools/check_release_bundle_verification_contract.py` and registered `EVID-2026-280`, so lint now rejects drift where bundle verification stops being a first-class part of the handoff path

## Revised271 (2026-03-06)
- make the canonical zip handoff **round-trip-safe after unpacking**:
  - updated `tools/package_release.py` so extracted root-level `RELEASE-MANIFEST.json` residue from a prior handoff zip is ignored instead of blocking the next `make package-release`
  - added `RELEASE-MANIFEST.json` to `.gitignore` and tightened the release docs/runbook/README surfaces so extracted manifest copies are treated as non-authoritative handoff residue, not working-tree source of truth
- added `tools/check_release_manifest_roundtrip_posture.py` and registered `EVID-2026-279`, so lint now rejects drift where unpack→edit→package breaks again on stale embedded-manifest leftovers

## Revised270 (2026-03-06)
- make the canonical zip handoff **self-describing and less host-dependent**:
  - added `docs/60-engineering/release-bundle-manifest-contract.md`
  - updated `tools/package_release.py` so `make package-release ...` now embeds root-level `RELEASE-MANIFEST.json` with sorted path/size/SHA-256 rows, normalizes member timestamps to the explicit `STAMP`, and canonicalizes member permissions instead of leaking host mtimes/umask into the handoff artifact
- wire the release-manifest contract through discovery and anti-drift surfaces:
  - updated `docs/60-engineering/release-packaging-contract.md`, `docs/00-meta/llm-runbook.md`, `docs/README.md`, `README.md`, `tools/README.md`, `docs/00-meta/bibliography.md`, and `docs/00-meta/evidence-index.md`
- added `tools/check_release_bundle_manifest_contract.py` and registered `EVID-2026-278`, so lint now rejects drift where the packaged zip stops being self-describing or starts leaking host-dependent archive metadata again

## Revised269 (2026-03-06)
- Turned zip handoff into a **canonical release-packaging contract** instead of a manual naming convention:
  - added `docs/60-engineering/release-packaging-contract.md`
  - added `tools/package_release.py` plus a new `make package-release STAMP=YYYY.MM.DD.HH.MM SLUG=<slug>` target that derives `rev####` from the top `CHANGELOG.md` entry, includes `out/context_pack.md`, and excludes CI scratch such as `out/_ci_*`
- Hardened continuation/output wiring so future runs remember the canonical packaging path:
  - updated `tools/gen_context_pack.py`, `tools/check_context_pack_contract.py`, `docs/00-meta/llm-runbook.md`, `docs/README.md`, `README.md`, `tools/README.md`, and the I-CTXPACK-1 / PO-CTXPACK-CONTRACT wording to include the package-release command surface
- Added `tools/check_release_packaging_contract.py` and registered `EVID-2026-277`, so lint now rejects drift where the handoff zip stops being changelog-derived, stops carrying `out/context_pack.md`, or quietly re-absorbs CI scratch into the packaged archive

## Revised268 (2026-03-06)
- strengthen the continuation-memory contract: `out/context_pack.md` now points from its **Recently resolved** OQ window back to `docs/00-meta/resolved-history.md`, so the prompt surface keeps the short closure window compact without losing the full closure history handoff
- add `tools/check_context_pack_resolved_handoff.py` (`EVID-2026-276`) and tighten `tools/check_context_pack_contract.py` / the assurance surfaces so CI rejects any drift where the context-pack resolved-OQ summary stops mirroring the canonical trajectory-map window
- regenerate `out/context_pack.md` so the latest revision header and continuation memory reflect the new resolved-history handoff contract

## Revised267 (2026-03-06)
- split closure memory into two explicit surfaces: keep `docs/00-meta/trajectory-map.md`'s **Recently resolved** section as a short **OQ-only** window, and move non-OQ posture/boundary closure notes into the new `docs/00-meta/resolved-history.md` so the mile-high map stays compact without losing discovery
- add `tools/check_recently_resolved_window.py` (`EVID-2026-275`) and wire it through the runbook / docs index / evidence/tooling surfaces so CI enforces the new short-window contract and prevents non-OQ closure prose from bloating the trajectory map again
- regenerate `out/context_pack.md` so the continuation prompt reflects the trimmed trajectory-map closure window while preserving the same stable OQ history surface

## Revised266 (2026-03-06)
- extend the continuation context-pack contract so `out/context_pack.md` now carries a compact **Recently resolved** section with stable `OQ-####` bullets from the trajectory map, keeping closure history visible even when the archive has zero current open questions
- tighten `tools/gen_context_pack.py` and `tools/check_context_pack_contract.py`, and align the runbook / assurance / evidence / tooling surfaces, so the continuation prompt must preserve both active decision surfaces (`Open questions`) and recent closure memory (`Recently resolved`) without copying the full trajectory map
- regenerate `out/context_pack.md` so the latest revision header and prompt surface reflect the new resolved-history memory contract

## Revised265 (2026-03-06)
- add a resolved-OQ history contract to the trajectory/runbook surfaces: once an `OQ-####` is closed it stays listed under **Recently resolved**, names the closing boundary/posture doc, and points at least one attached surface/evidence hook so later passes do not silently re-open decisions by forgetting why they were closed
- add `tools/check_resolved_oq_history.py` (`EVID-2026-274`) and wire it through `tools/README.md` / the evidence index so CI lint-enforces stable resolved-OQ ids, forbids closed ids from reappearing under active open questions, and requires each resolved bullet to remain traceable to both docs and surfaces
- regenerate `out/context_pack.md` so the latest revision header and recent-changes summary reflect the new resolved-OQ-history guardrail

## Revised264 (2026-03-06)
- align the context-pack assurance contract with the now-valid zero-current-OQ state: `I-CTXPACK-1`, `PO-CTXPACK-CONTRACT`, `EVID-2026-180`, and the tooling index now require an explicit open-questions section that may say `None currently.` once all current OQs are resolved, rather than stale 'non-empty open questions' wording
- tighten `tools/check_context_pack_contract.py` so the generated context pack must either carry stable `OQ-####` bullets or explicitly say `None currently.` in its open-questions section, matching the resolved trajectory-map shape exactly
- add `tools/check_zero_oq_posture.py` (`EVID-2026-273`) to keep the zero-current-OQ archive contract discoverable and lint-enforced across assurance, evidence, tooling, the trajectory map, and `out/context_pack.md`

## Revised263 (2026-03-06)
- resolve OQ-0001 by freezing the Phase 1 Hybrid multicore posture as a **closed boundary**: auto clustering stays **NUMA → socket → core_group**, richer cache/perf/locality facts stay **placement hints only**, CH-REPLCONTRACT family meanings remain registry-closed, and the flagship claim envelope stays **<=64 logical CPUs / <=8 clusters / <=16 logical CPUs per cluster**
- add `docs/30-architecture/hybrid-phase1-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, ADR-0005, the decision map, cluster derivation/multicore docs, and the trajectory map so Hybrid no longer remains an archive-wide “open follow-up” after its sub-boundaries have already been pinned
- add `tools/check_hybrid_phase1_boundary.py` (`EVID-2026-272`) and relax the open-question/context-pack guardrails so the archive can honestly carry **zero current OQs** while still requiring stable OQ ids for any future unresolved decision surfaces

## Revised262 (2026-03-06)
- narrow OQ-0001 again by freezing future NUMA-distance / HMAT latency-bandwidth / memory-tier facts as **placement hints only** in Phase 1: richer locality matrices may guide placement and migration ranking, but they cannot silently change auto clustering, create distance/tier authority kinds, or become replication/admission authority
- add `docs/30-architecture/memory-locality-authority-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, CH-HWFACT / CH-CLUSTERMAP / cluster-derivation / multicore docs, RFC-0018, the decision map, the non-claims surface, and the trajectory map so richer locality matrices cannot quietly become Hybrid authority semantics by doc drift
- add `tools/check_memory_locality_authority_boundary.py` (`EVID-2026-271`) and primary-source bibliography entries (`REF-HWLOC-DISTANCES`, `REF-ACPI-HMAT`, `REF-LINUX-NUMA-BALANCING`) so the new locality-hint-only boundary stays lint-enforced and explicitly sourced

## Revised261 (2026-03-06)
- narrow OQ-0001 again by freezing asymmetric CPU-capacity / performance-class facts as **placement hints only** in Phase 1: heterogeneous-core data may guide scheduler ranking or explicit performance hints, but it cannot silently change cluster derivation, create perf-class ownership kinds, or become budget/replay/authority semantics
- add `docs/30-architecture/cpu-capacity-authority-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, CH-HWFACT / cluster-derivation / multicore docs, RFC-0018, the decision map, and the trajectory map so richer heterogeneous-core metadata cannot quietly become Hybrid authority semantics by doc drift
- add `tools/check_cpu_capacity_authority_boundary.py` (`EVID-2026-270`) and primary-source bibliography entries (`REF-LINUX-SCHED-CAPACITY`, `REF-LINUX-UTILCLAMP`, `REF-ACPI-CPPC-HETERO`) so the new perf-hint-only boundary stays lint-enforced and explicitly sourced

## Revised260 (2026-03-06)
- narrow OQ-0001 again by freezing CH-HWFACT cache/LLC facts as **placement hints only** in Phase 1: `l3_cache_id` and future bounded cache-sharing hints may improve in-cluster locality and annotate CH-CLUSTERMAP, but they cannot silently change `preferred_boundary=auto`, create cache-scoped authority kinds, or merge NUMA domains into new ownership boundaries
- add `docs/30-architecture/cache-topology-authority-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, CH-HWFACT / CH-CLUSTERMAP / cluster-derivation docs, RFC-0018, the decision map, and the trajectory map so richer cache topology data cannot quietly become Hybrid authority semantics by doc drift
- add `tools/check_cache_topology_authority_boundary.py` (`EVID-2026-269`) and a primary-source bibliography entry (`REF-LINUX-CACHEINFO`) so the new cache-hint-only boundary stays lint-enforced and explicitly sourced

## Revised259 (2026-03-06)
- resolve OQ-0005 by freezing D-ATTN urgent notifications as an **ephemeral CH-NOTIF request seam**: `importance="urgent"` stays a policy-gated hint only, and any future TTL/renew/revoke or stronger interruption semantics must live in a separate RFC-first surface rather than widening CH-NOTIF or delivery outcomes in place
- add `docs/30-architecture/attention-durable-interrupt-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `attention-lease-posture-v0.md`, `notification-request-schema-v0.md`, RFC-0055, the decision map, and the trajectory map so D-ATTN keeps one small Phase 1 meaning instead of a latent second authority surface
- add `tools/check_attention_durable_interrupt_boundary.py` (`EVID-2026-268`) and refresh `tools/check_attention_posture.py` so the archive lint-enforces the new evolution boundary and no longer treats OQ-0005 as unresolved

## Revised258 (2026-03-06)
- narrow OQ-0001 again by freezing the **numeric Phase 1 Hybrid/multicore claim envelope**: flagship claims now stop at **<=64 logical CPUs**, **<=8 clusters**, and **<=16 logical CPUs per cluster**; larger or more cache-/distance-adaptive cluster policies remain explicit non-claims / RFC-first work rather than implied scope
- add `docs/30-architecture/cluster-phase1-envelope-v0.md`, wire it through `docs/README.md`, the LLM runbook multicore must-read set, `multicore-architecture-options.md`, `cluster-derivation.md`, `cluster-auto-boundary-v0.md`, the decision map, the MVP proof slice, `non-claims.md`, and the trajectory map so “verified multicore” has one small honest Phase 1 meaning
- add `tools/check_cluster_phase1_envelope.py` (`EVID-2026-267`) to keep the new claim envelope lint-enforced and to force any future >64-CPU / >8-cluster / >16-CPU-per-cluster expansion to pay for explicit D-MK/CH-CLUSTERMAP evolution rather than silent claim drift

## Revised257 (2026-03-06)
- narrow OQ-0001 again by freezing the Hybrid `object_family = budget` boundary: replicated `budget` state is **owner-routed issuer / lease-lineage metadata only**, while local spend authority still requires an explicit payer object and cached replicas cannot mint credit, widen leases, or infer portable budget rights
- add `docs/30-architecture/budget-replication-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`, the budget/hot-action surfaces, RFC-0058, the decision map, and the trajectory map so cross-cluster budget metadata cannot silently become portable payer authority
- add `tools/check_budget_replication_boundary.py` (`EVID-2026-266`) to keep the new owner-routed-only boundary lint-enforced and to force any future cross-cluster credit-transfer/import design to pay for a distinct RFC-first surface rather than widening `object_family = budget` in place

## Revised256 (2026-03-06)
- narrow OQ-0001 again by freezing the Hybrid `object_family = transcript` boundary: replicated CH-LOG material is **content-addressed event-set evidence only**, while local approval/policy/capability checks, replay authority, and any runtime sequencing remain on explicit local seams
- add `docs/30-architecture/transcript-replication-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`, `transcript-contract.md`, the hot-action surfaces, the decision map, and the trajectory map so cross-cluster transcript sharing cannot silently become portable effect authority or a distributed sequencer
- add `tools/check_transcript_replication_boundary.py` (`EVID-2026-265`) to keep the new evidence-only boundary lint-enforced and to force any future replay-ticket / ordered-control work to pay for a distinct RFC-first surface rather than widening `object_family = transcript` in place

## Revised255 (2026-03-06)
- narrow OQ-0001 again by freezing the Hybrid `object_family = receipt` boundary: replicated receipts are **immutable digest-addressed evidence only**, while local approval/policy/capability checks, replay/resubmission authority, and any handle/lease resurrection remain on explicit local seams
- add `docs/30-architecture/receipt-replication-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`, the receipt schema docs, the decision map, and the trajectory map so cross-cluster receipt sharing cannot silently become portable effect authority
- add `tools/check_receipt_replication_boundary.py` (`EVID-2026-264`) to keep the new boundary lint-enforced and to force any future portable approval/result-token work to pay for a distinct RFC-first surface rather than widening `object_family = receipt` in place

## Revised254 (2026-03-06)
- narrow OQ-0001 again by freezing the Hybrid `object_family = tlog` boundary: RC4 stays an **append-only evidence lane only**, while local explicit policy still pins accepted log origins/pubkeys/witness thresholds and replicated checkpoints/proofs cannot silently become runtime admission, control, or time authority
- add `docs/30-architecture/tlog-replication-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`, `transparency-log-anchor-schema-v0.md`, RFC-0029, the decision map, and the trajectory map so Hybrid cannot reinterpret the one admitted RC4 family as a general ordered control plane
- add `tools/check_tlog_replication_boundary.py` (`EVID-2026-263`) to keep the new evidence-only boundary lint-enforced and to force any future online admission/sequencer use of transparency logs to pay for a distinct RFC-first surface rather than widening `object_family = tlog` in place

## Revised253 (2026-03-06)
- narrow OQ-0001 again by freezing the Hybrid `object_family = view` boundary: authoritative cross-cluster namespace state stays **owner-routed slot-binding metadata only**, while any non-owner summaries remain read-only/cache-shaped and replicated arrivals cannot auto-attach, auto-detach, or otherwise activate bindings inside a receiver's local active view
- add `docs/30-architecture/view-replication-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`, `view-objects.md`, `view-namespace-posture-v0.md`, RFC-0032, the hot-action surfaces, the decision map, and the trajectory map so Hybrid cannot silently reinterpret replicated namespace metadata as ambient cross-cluster attach authority
- add `tools/check_view_replication_boundary.py` (`EVID-2026-262`) to keep the new boundary lint-enforced and to force any future live namespace mirroring or multi-owner view semantics to pay for a distinct RFC-first surface rather than widening `object_family = view` in place

## Revised252 (2026-03-06)
- narrow OQ-0001 again by freezing the Hybrid `object_family = caprpc_proxy` boundary: replication stays **owner-routed endpoint/proxy metadata only**, while callable authority still requires an explicit live proxy handle or explicit CH-CAPX / CH-SREF import/restore event bound to local policy
- add `docs/30-architecture/caprpc-proxy-replication-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`, `capability-rpc-frame-schema-v0.md`, `capability-export-schema-v0.md`, RFC-0026, RFC-0004, the decision map, and the trajectory map so Hybrid cannot silently reinterpret replicated route hints as copied capability authority
- add `tools/check_caprpc_proxy_replication_boundary.py` (`EVID-2026-261`) to keep the new boundary lint-enforced and to force any future endpoint migration/failover work to pay for a distinct RFC-first surface rather than widening `caprpc_proxy` in place

## Revised251 (2026-03-06)
- narrow OQ-0001 again by freezing the Hybrid `object_family = namecert` boundary: RC3 replication moves only **signed CH-NAMECERT bundle-set evidence**, while trust/visibility/activation stay local explicit naming policy and replicated arrivals cannot silently become a global or privileged resolver
- add `docs/30-architecture/namecert-replication-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`, `namecert-schema-v0.md`, RFC-0023, the decision map, and the trajectory map so D-NAMECERT stays local-authority-first even when Hybrid replicas share bundle artifacts
- add `tools/check_namecert_replication_boundary.py` (`EVID-2026-260`) to keep the new boundary lint-enforced and to prevent replicated naming evidence from drifting into ambient/global resolution semantics

## Revised250 (2026-03-06)
- narrow OQ-0001 again by freezing the Phase 1 Hybrid cluster auto-boundary: `preferred_boundary = auto` now derives CH-CLUSTERMAP as **NUMA → socket → core_group** only, while `die` remains explicit-policy-only so richer topology probes cannot silently become default ownership/replication boundaries
- add `docs/30-architecture/cluster-auto-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook multicore must-read set, `cluster-derivation.md`, `multicore-architecture-options.md`, the decision map, and the trajectory map so topology richness remains input data rather than ambient authority-surface drift
- add `REF-HWLOC-OBJTYPES`, `REF-LINUX-NUMA`, `REF-ACPI-PPTT`, and `tools/check_cluster_auto_boundary.py` (`EVID-2026-259`) to ground the boundary in topology/NUMA primary docs while keeping any future die/cache-distance clustering expansion explicit-policy-only and lint-enforced

## Revised249 (2026-03-06)
- narrow OQ-0001 by pinning a hard Hybrid boundary for quota replication: `object_family = quota` now means **observational additive spend summaries only** under already-issued local credit, while authorization still comes from local explicit payer authority and mint/grant/revoke/rebalance remains on the owner-routed `budget` seam
- add `docs/30-architecture/quota-replication-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `replication-contracts-v0.md`, `replication-object-family-registry.md`, `profile-repl-defaults.md`, the hot-action surfaces, `budget-lease-schema-v0.md`, RFC-0012, the decision map, and the trajectory map so Hybrid cannot silently reinterpret merged quota replicas into remote spending authority
- add `REF-ESCROW-TODS86`, `REF-BOUNDED-COUNTER-SRDS15`, and `tools/check_quota_replication_boundary.py` (`EVID-2026-258`) to ground the boundary in escrow/bounded-counter literature while keeping any future cross-cluster credit-transfer design RFC-first and lint-enforced

## Revised248 (2026-03-06)
- resolve OQ-0009 by freezing future generic `portal.device.*` automation at **per-device** ordering only: attach/grant/revoke actions serialize on `CH-CONFLICTKEY family="device.id"` / explicit typed `device_id`, while queue/endpoint/vector details stay inside the granted lease / driver host rather than becoming a second portal-policy conflict-key family
- add `docs/30-architecture/device-lease-ordering-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook, `io-lease-posture-v0.md`, `io-lease-schema-v0.md`, RFC-0085, RFC-0045, the conflict-key surfaces, the decision map, and the trajectory map so device-automation scope cannot silently drift from attach policy into dataplane internals
- add `tools/check_device_lease_ordering_boundary.py` (`EVID-2026-257`) and tighten the earlier device-id staging/wiring so the archive keeps one small generic device-authorization ordering surface while leaving richer queue-local work RFC-first under D-IOLEASE / D-DRVDOM

## Revised247 (2026-03-06)
- resolve OQ-0007 by freezing the replay-stable `capshell.exec` result seam: duplicate suppression stays keyed by CH-EFFCON `contract_id`, canonical exportable outputs stay `digest(CH-AREF v0)`, and any future named-output / resource-usage structure must live in **one separate digest-referenced sidecar descriptor family** rather than changing CH-EXECPACK / CH-ACPOUT meaning in place
- add `docs/30-architecture/capshell-result-sidecar-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook must-read set, `capshell-output-normal-form-v0.md`, `acp-outcome-receipt-schema-v0.md`, `decision-map.md`, and the trajectory map so replay safety stays crisp and path-based result drift cannot silently re-enter the archive
- add `REF-OTEL-PROCESS-METRICS` and `tools/check_capshell_result_sidecar_boundary.py` (`EVID-2026-256`) to ground the “telemetry is separate from result identity” decision in an existing observability ecosystem while keeping richer result work RFC-first and lint-enforced

## Revised246 (2026-03-06)
- resolve OQ-0008 by freezing CH-REQCTX sponsorship semantics: `budget_desc_digests` / `tcap_desc_digests` remain bare digest lists, and any future typed or multi-schema sponsorship must live **outside CH-REQCTX** as its own explicit descriptor/sidecar surface rather than reinterpreting old request-context transcripts in place
- add `docs/30-architecture/reqctx-sponsorship-evolution-boundary-v0.md`, wire it through `docs/README.md`, the LLM runbook, CH-REQCTX v0/v1 schema notes, the budget/tcap posture docs, the decision map, and the trajectory map so request context stays small, non-authoritative, and resistant to semantic drift
- add `REF-OCI-DESCRIPTOR`, update the reqctx budget drift gate for the resolved boundary, and add `tools/check_reqctx_sponsorship_boundary.py` (`EVID-2026-255`) to keep any future typed sponsorship work RFC-first and out of CH-REQCTX proper

## Revised245 (2026-03-06)
- resolve OQ-0006 by pinning a hard archive boundary: the A–D profile default matrices remain the canonical **review surfaces** for recommended defaults, while any concrete CH-CFG / CH-POLICY defaults stay derived tooling outputs only; Phase 1 declines a standardized template DSL or authoritative generated default bundles
- add `docs/30-architecture/profile-default-artifact-boundary-v0.md`, wire it through `docs/README.md`, `docs/00-meta/llm-runbook.md`, ADR-0004, `config-schema-v0.md`, the four profile-default matrices, and the trajectory map so config-template debates cannot silently become a second source of truth
- add `REF-CUE-DOCS`, `REF-DHALL-HOME`, `REF-DHALL-SAFETY`, `REF-JSONNET-HOME`, `REF-JSONNET-DESIGN`, and `tools/check_profile_default_artifact_boundary.py` (`EVID-2026-254`) to ground the tooling-vs-core boundary in real configuration ecosystems while keeping privileged semantics fixed at canonical artifact validation

## Revised244 (2026-03-06)
- narrow OQ-0009 by making one concrete future-facing D-IOLEASE/D-DEVGUARD decision now: if SlopOS later automates device attach/lease, commutativity and ordered-stream scoping MUST use `CH-CONFLICTKEY family="device.id"` bound to an explicit typed `device_id`, never `/dev` names, port paths, raw serials, or UI labels
- wire the decision through the core commutativity surfaces (`conflict-key-family-registry.md`, `conflict-key-schema-v0.md`, `conflict-key-derivation-registry.md`, `typed-id-contract-v0.md`), the Phase-1 device posture (`io-lease-posture-v0.md`), the decision map, the trajectory map, and RFC-0085 so future automation cannot silently fall back to ambient naming
- add `REF-ANDROID-USB-HOST` and `tools/check_device_conflictkey_staging.py` (`EVID-2026-253`) to keep the new per-device ordering choice grounded in deployed mediation precedents and lint-enforced while `portal.device.*` remains manual-only in Phase 1

## Revised243 (2026-03-06)
- add `docs/30-architecture/sturdyref-posture-v0.md` and pin D-CAPX / CH-SREF as **explicit restore-only bearer refs** in Phase 1: remote delegation stays off by default, there is no ambient resolver or app-visible sturdyref inventory, and routine workflow/observation surfaces carry `digest(CH-SREF)` rather than raw sturdyref bytes
- add `tools/check_sturdyref_posture.py` (`EVID-2026-252`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the decision map, CH-SREF / CH-CAPX notes, feature-flag defaults, the assurance registries, and RFC-0004 / RFC-0014 history
- tighten D-CAPX / CH-SREF assurance so `I-SREF-3` and `PO-SREF-EXPLICIT` explicitly preserve the rule that sturdyref restore is explicit-route only, there is no ambient resolver or app-visible inventory/probing surface, and default workflow/observation artifacts carry only digests rather than raw CH-SREF bytes

## Revised242 (2026-03-06)
- add `docs/30-architecture/activation-posture-v0.md` and pin D-ACTIVATE as a **supervisor-owned, inbound-only continuity** seam in Phase 1: stable handles are activation-delivered public endpoints, CH-ACTSET stays descriptive-only, and any optional handle store remains per-`cid`, manifest-closed, bounded, and non-inventory rather than a generic persistence/export substrate
- add `tools/check_activation_posture.py` (`EVID-2026-251`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, CH-ACTSET / CH-COMP notes, the assurance registries, and RFC-0081 history
- tighten D-ACTIVATE assurance so `I-ACTIVATE-3` and `PO-ACTIVATE-CONTINUITY` explicitly preserve the rule that activation continuity is same-component / activation-delivered only, with no app-visible inventory/search/watch API and no cross-component export/import semantics for the handle store

## Revised241 (2026-03-06)
- add `docs/30-architecture/volition-posture-v0.md` and pin D-VOLITION as a **fresh, local-only, one-shot** Phase-1 trusted-UI seam: CH-VOL binds one exact action digest and one exact summary digest, while batch/wildcard approvals, export/import semantics, and session-restore / cached approval reuse stay out of scope
- add `tools/check_volition_posture.py` (`EVID-2026-250`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, CH-VOL / CH-RECEIPT notes, IF-CONSENT, the assurance registries, and RFC-0039 / RFC-0055 / RFC-0069 history
- tighten D-VOLITION assurance so `I-VOLITION-2` and `PO-VOL-LOCAL` explicitly preserve the rule that CH-VOL is local gesture evidence rather than a reusable approval ticket, and that biometric/passkey-style factors stay bound to one exact approval interaction inside the trusted prompt
- add a new primary reference for system-owned biometric prompts to the bibliography and extend the WebAuthn reference notes so the volition posture is grounded in deployed challenge-bound / shell-owned approval precedents rather than generic consent prose

## Revised240 (2026-03-06)
- add `docs/30-architecture/attrfs-posture-v0.md` and pin D-ATTRFS as a **view-scoped, snapshot-first, handle-returning** Phase-1 smart-query seam: queries remain bounded over CH-ATTR/CH-ATTRQ, saved queries / smart folders stay **shell-owned manifests**, and Phase 1 declines raw-path results, count-only probes, full-text/regex/ranking expansion, or app-visible saved-query inventory/background watch semantics
- add `tools/check_attrfs_posture.py` (`EVID-2026-249`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, CH-ATTR / CH-ATTRQ schema notes, AC-085, the assurance registries, and RFC-0100 history
- tighten D-ATTRFS assurance so `I-ATTRQ-2` and `PO-ATTRQ-ENF` explicitly preserve the rule that metadata search is snapshot-first/handle-returning and that live queries or saved-query UX cannot silently widen into ambient inventory or background-watch behavior

## Revised239 (2026-03-06)
- add `docs/30-architecture/quarantine-posture-v0.md` and pin D-QUAR as a **monotonic, object-local safe-open** Phase-1 seam: quarantine clear remains manual-only and non-recursive, safe-open/view does not mutate source trust, and any dequarantined/sanitized materialization is a **new artifact** rather than in-place laundering
- add `tools/check_quarantine_posture.py` (`EVID-2026-248`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the decision map, the origin/quarantine attrset, the assurance registries, and RFC-0053 history
- tighten D-QUAR assurance so `I-QUAR-5` and `PO-QUAR-LOCAL` explicitly preserve object-local clearing, reject implicit/background auto-clear, and make “safe export creates a new artifact” part of the Phase-1 contract rather than app-defined behavior

## Revised238 (2026-03-06)
- add `docs/30-architecture/vault-posture-v0.md` and pin D-VAULT as a **ref-bound, provider-owned, non-inventory** Phase-1 seam: portable secret authority is CH-SECRETPOL/CH-SECRETREF plus the closed op set, while collection/item/session/search semantics and recovery/federation remain explicit future/profile work
- add `tools/check_vault_posture.py` (`EVID-2026-247`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, CH-SECRETPOL / CH-SECRETREF notes, the assurance registries, mechanisms, and RFC-0070 history
- tighten vault assurance so `I-VAULT-3` and `PO-VAULT-REFONLY` explicitly preserve the rule that vault portability is by explicit CH-SECRETREF rather than inventory/search semantics, and that recovery/federation cannot silently appear as ambient provider behavior

## Revised237 (2026-03-06)
- add `docs/30-architecture/wallet-posture-v0.md` and pin D-WALLET as a **summary-only, `wallet_core_digest`-bound** Phase-1 review surface: wallets remain prompts/receipt/CI artifacts rather than an authority container, import/merge protocol, or hidden descriptor-reopen path
- add `tools/check_wallet_posture.py` (`EVID-2026-246`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, CH-WALLET / CH-EFFCON / CH-PLUMBMSG notes, the assurance registries, and RFC-0115 / RFC-0116 history
- tighten wallet assurance so `I-WALLET-4` and `PO-WALLET-BIND` explicitly preserve the rule that `wallet_core_digest` is the only normative binding key and that wallet artifacts may only narrow/audit already-held authority, never resolve or acquire it

## Revised236 (2026-03-06)
- added `docs/30-architecture/cryptosvc-posture-v0.md`, pinning D-CRYPTOSVC as an **op-only, context-bound, explicit-route-only** Phase-1 seam: no ambient `SSH_AUTH_SOCK`/path/env discovery, no provider-global key inventory, no PKCS#11-style slot/session/object core seam
- added `tools/check_cryptosvc_posture.py` and registered `EVID-2026-245` to keep the new crypto-service posture discoverable and lint-enforced across decision map, schema notes, mechanisms, assurance, and RFC history
- tightened D-CRYPTOSVC assurance/wiring: added `I-CRYPTO-3` + `PO-CRYPTOSVC-ENF`, updated AC-015 / RFC-0067 / trajectory/profile/runbook surfaces, and annotated CH-KEYPOL / CH-KEYREF / CH-CRYPTOAUDIT with the pinned posture

## Revised235 (2026-03-06)

- add `docs/30-architecture/timeproof-posture-v0.md` and pin **D-TIMEPROOF** as an **evidence-first, lower-bound-only** authenticated-time seam in Phase 1: verified samples may advance `secure_time_lb`, but they do not become an ambient clock-setting or scheduler surface.
- make one concrete hard decision in the proof format: Phase 1 portable/exported `CH-TIMEPROOF v0` is **Roughtime-only** (`kind=roughtime`, `authority.kind=pubkey_hash`); NTS may discipline portal-local time for steady state, but it does not become a second exported proof kind without a future RFC.
- add `tools/check_timeproof_posture.py` (`EVID-2026-244`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the decision map, the portal-family registry, CH-TIMEREQ / CH-TIMEPROOF schema notes, ACP validator semantics, assurance registries, and RFC-0090 history.
- tighten D-TIMEPROOF assurance so `I-TIMEPROOF-3` and `PO-TIMEPROOF-ENF` explicitly preserve lower-bound-only application, v0 proof-kind closure, and the rule that accepted timeproofs do not silently widen into ambient realtime/timer authority.

## Revised234 (2026-03-06)

- add `docs/30-architecture/print-portal-posture-v0.md` and pin `portal.print.*` as a **manual-only, render-first, shell-spooled** workflow in Phase 1: apps submit bounded rendered artifacts via a prepare→submit flow, but get no app-visible printer inventory, no durable queue authority, and no print-to-file/path loophole around `portal.file.*`.
- add `tools/check_print_portal_posture.py` (`EVID-2026-243`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the portal-family registry, the effect-contract and intent-kind docs, the assurance registries, and RFC-0046 / CLI history.
- tighten D-PLUMB assurance language so `I-PRINT-1`, `I-PRINT-2`, and `PO-PRINT-ENF` explicitly preserve manual-only print mediation, render-first shell spooling, the absence of app-visible printer inventory/queue authority, and the rule that print-to-file remains a `portal.file.*` decision rather than a printing convenience loophole.
- add print research anchors to the bibliography: XDG Print, Android Print Framework + KitKat printing mediation, and Apple `UIPrintInteractionController`, grounding the print posture in primary mediation precedents rather than generic spooler lore.

## Revised233 (2026-03-06)

- add `docs/30-architecture/openuri-portal-posture-v0.md` and pin `portal.uri.*` as a **manual-only, scheme-gated, launch-only** workflow in Phase 1: opening a link / showing an item stays a shell-owned mediation flow rather than an installed-app oracle or callback channel; `file://` and raw paths remain a `portal.file.*` / CH-DOCREF problem.
- add `tools/check_openuri_portal_posture.py` (`EVID-2026-242`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the portal-family registry, the effect-contract and intent-kind docs, the assurance registries, and RFC-0046 / RFC-0117 history.
- tighten D-PLUMB assurance language so `I-OPENURI-1`, `I-OPENURI-2`, and `PO-OPENURI-ENF` explicitly preserve manual-only OpenURI, shell-owned scheme gating, no handler inventory/probing, no callback/return channel, and the rule that OpenURI does not silently widen into file or network authority.
- add mobile URI-handler privacy references to the bibliography: Android package-visibility filtering plus Apple `canOpenURL` / `LSApplicationQueriesSchemes`, grounding the “no handler inventory/probing” posture in primary ecosystem precedents rather than generic launcher lore.

## Revised232 (2026-03-06)

- add `docs/30-architecture/document-portal-posture-v0.md` and pin `portal.file.*` / CH-DOCREF as a **manual-only, explicit-persistence, non-bearer reopen** workflow in Phase 1: chooser results stay ephemeral by default, reopen cannot widen rights/scope, and remembered-file management remains shell-owned rather than app-enumerable.
- add `tools/check_document_portal_posture.py` (`EVID-2026-241`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the portal-family registry, the CH-DOCREF notes, the assurance registries, and RFC-0089 history.
- tighten D-PLUMB / CH-DOCREF assurance language so `I-DOCREF-3` and `PO-DOCREF-ENF` explicitly preserve manual-only `portal.file.*`, explicit persistence, no app-visible grant inventory, and the rule that reopen does not silently widen file authority into directory/inventory scope.
- add Android SAF as a bibliography anchor beside XDG Documents/FileChooser and Apple security-scoped bookmarks, keeping the document-portal posture grounded in primary user-mediated file-access precedents rather than generic sandbox prose.

## Revised231 (2026-03-06)

- add `docs/30-architecture/capture-portal-posture-v0.md` and pin D-CAPTURE as **manual-only, indicator-bound, and non-persistent** in Phase 1: no ACP automation kind for `portal.capture.*`, no restore-token / remembered-session semantics, and no background/headless capture start.
- add `tools/check_capture_portal_posture.py` (`EVID-2026-240`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the portal-family registry, the CH-CAPTURE notes, the assurance registries, and RFC-0095 history.
- tighten D-CAPTURE assurance language so `I-CAPTURE-1..3` and `PO-CAPTURE-ENF` explicitly preserve interactive start, shell-owned indicator discipline, and the rule that capture does not quietly widen into a persistence/resume substrate.
- add capture research anchors to the bibliography: XDG ScreenCast/RemoteDesktop session persistence as a contrast case, Android MediaProjection’s single-use consent/token posture, and Apple’s ScreenCaptureKit + Control Center privacy indicators.

## Revised230 (2026-03-06)

- add `docs/30-architecture/transfer-portal-posture-v0.md` and pin D-PLUMB transfer workflows as **manual-only, sink-pull, one-shot/auto-clear across trust boundaries, and non-history** in Phase 1: `copy` publishes an offer, but cross-component delivery happens only on explicit paste/drop/share; no background clipboard observation or clipboard-history service is claimed.
- add `tools/check_transfer_portal_posture.py` (`EVID-2026-239`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the portal-family registry, the CH-XFER notes, the assurance registries, and RFC-0094 history.
- tighten D-PLUMB / CH-XFER language so transfer invariants explicitly preserve sink-pull semantics, one-shot/auto-clear cross-boundary posture, and the rule that transfer workflows do not silently drift back into ambient clipboard behavior.

## Revised229 (2026-03-06)

- add `docs/30-architecture/ui-automation-posture-v0.md` and pin D-UIAUT as a **manual-only, observation-first** workflow in Phase 1: no ACP automation kind for `portal.a11y.*`, no hidden persistence/relaunch seam, and explicit `observe ≠ inject` separation for accessibility vs injection-capable sessions.
- add `tools/check_uiaut_posture.py` (`EVID-2026-238`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the portal-family registry, the CH-UIAUT notes, the assurance registries, and RFC-0099 history.
- tighten D-UIAUT assurance language so `I-UIAUT-1..3` and `PO-UIAUT-ENF` explicitly preserve manual-only v0 semantics, observation/injection separation, and the rule that UI automation sessions do not become a hidden persistence surface.

## Revised228 (2026-03-06)

- add `docs/30-architecture/app-secret-posture-v0.md` and pin D-APPSECRET as a **minimal app-scoped seed seam** in Phase 1: not a vault, no named secret inventory/collection model, `scope="profile"` as the default posture, no silent auto-rotation, and no ACP automation kind for `portal.secret.*`.
- add `tools/check_appsecret_posture.py` (`EVID-2026-237`) and wire the new posture through discovery, the profile posture matrix, the runbook must-read set, the trajectory map, the portal-family registry, the CH-APPSECRET notes, the assurance registries, and RFC-0104 history.
- tighten the secret-store research wiring by correcting `REF-SECRET-SERVICE-SPEC` to the current freedesktop specification URL, keeping the bibliography closer to the primary source actually used by the posture.

## Revised227 (2026-03-06)

- add `docs/30-architecture/location-lease-posture-v0.md` and pin D-LOCLEASE as **manual-only, coarse-first, and non-persistent** in Phase 1: no ACP automation kind, no `background="always"` product claim, and no geofence wakeup semantics without a future RFC/evidence pass.
- add `tools/check_loclease_posture.py` (`EVID-2026-236`) and wire the new location posture through discovery, the profile posture matrix, trajectory map, portal family registry, assurance registries, RFC-0101 history, and the schema notes.
- tighten location references by switching `REF-APPLE-LOCATION-PRECISE` to an Apple Developer Core Location accuracy-authorization source rather than a support article, keeping the archive closer to primary-source posture.
## Revised226 (2026-03-06)
- Pinned the Phase-1 meaning of **D-INHIBITLEASE** so keep-awake/session-transition inhibition stays a live, reviewable workflow instead of drifting into persistence or scheduling:
  - New `docs/30-architecture/inhibit-lease-posture-v0.md`: D-INHIBITLEASE v0 is now explicitly **close-to-release**, current-session scoped, and **non-durable**; Phase 1 forbids future-dated/reboot-carried inhibit records, keeps `portal.inhibit.*` **manual-only**, and treats D-INHIBITLEASE as distinct from both D-JOBS and D-BGLEASE.
  - Wired into discovery + assurance: `docs/README.md`, posture index, profile posture matrix, runbook must-read set, decision map, trajectory map, CH-INHIBITLEASE notes, portal-family registry, RFC-0102, invariant registry (`I-INHIBIT-1..3`), and proof-obligation registry (`PO-INHIBIT-VALIDATE`, `PO-INHIBIT-ENF`).
- Research anchors (URLs only in bibliography): reused XDG Inhibit portal, systemd inhibitor locks, and Android wake-lock guidance to sharpen one implementable import for SlopOS terms: inhibit should be a **live, bounded handle** that protects active work, not a durable background/scheduling substrate.
- New CI drift gate:
  - Added `tools/check_inhibitlease_posture.py` and registered **EVID-2026-235** (pins the v0 close-to-release / no-durable-carryover / manual-only rule + discovery wiring; prevents keep-awake drift into persistence or scheduler semantics).

## Revised225 (2026-03-06)
- Pinned the Phase-1 meaning of **D-JOBS** so deferred work stays a bounded portal surface rather than drifting into cron semantics or hidden persistence:
  - New `docs/30-architecture/job-portal-posture-v0.md`: D-JOBS v0 now explicitly treats `portal.jobs` requests as **best-effort windows**, not exact schedules; periodic work is coalesced and **missed windows are not replay debt** (after downtime/pressure deferral, the portal may do at most one catch-up run before cadence resumes).
  - Wired into discovery + assurance: `docs/README.md`, posture index, profile posture matrix, runbook must-read set, decision map, trajectory map, CH-JOBREQ notes, portal family registry, ACP validator/kind registry, invariant registry (`I-JOB-2`), and proof-obligation registry (`PO-JOBS-ENF`).
  - Sharpened the adjacent RFC/spec seam without adding a subsystem: RFC-0096 and CH-JOBREQ now explicitly reject “replay every missed tick” semantics, keeping D-JOBS separate from D-BGLEASE.
- Research anchors (URLs only in bibliography): reused the existing Android/Apple/systemd precedents to make one concrete import legible in SlopOS terms: background jobs should be **constraint-based, coalesced, and non-exact**, while exact wakeups/persistent presence remain exceptional or separately gated.
- New CI drift gate:
  - Added `tools/check_job_portal_posture.py` and registered **EVID-2026-234** (pins the v0 no-ambient-cron / best-effort-window / no-replay-debt rule + discovery wiring; prevents D-JOBS from silently turning into a scheduler-compat surface).

## Revised224 (2026-03-06)
- Pinned the Phase-1 meaning of **D-ATTN urgent notifications** so attention stays a bounded, policy-killable interrupt surface rather than turning into a hidden approval or persistence channel:
  - Added a dedicated CI guardrail, `tools/check_attention_posture.py`, and rewired `docs/30-architecture/posture-index.md` so `attention-lease-posture-v0.md` is no longer an unguarded posture seam.
  - Tightened discovery + history to match the pinned v0 stance: `decision-map.md`, `trajectory-map.md`, `notification-request-schema-v0.md`, `portal-family-registry.md`, `docs/README.md`, and `rfcs/0055-attention-authority-and-notifications.md` now consistently treat `importance="urgent"` as a **policy-gated hint** (not a capability, not a lease, not a bypass).
  - Explicitly deferred the older `attention.urgent` / “attention lease” idea to a future RFC-only expansion path if durable TTL/renew/revoke semantics are ever needed.
- Research anchors (URLs only in bibliography): reused the existing XDG Notification portal, Android notification channels / notification importance guidance, and Apple critical-alert / notification guidance to keep the v0 decision aligned with a common ecosystem pattern: interruption level is tightly policy/user mediated, while action execution remains separately gated.
- New CI drift gate:
  - Added `tools/check_attention_posture.py` and registered **EVID-2026-233** (pins the v0 urgent-is-a-hint rule + discovery/history wiring; prevents older “urgent capability/lease” prose from silently re-entering the archive).

## Revised223 (2026-03-06)
- Pinned the Phase-1 meaning of **background execution + login autostart** so persistence stays explicit, review-bound, and distinct from ordinary scheduled work:
  - New `docs/30-architecture/background-lease-posture-v0.md`: D-BGLEASE v0 now clearly prefers D-JOBS for deferrable work, treats `background` and `autostart` as separate grant bits, and forbids renew/retry flows from silently widening a live background-only grant into autostart.
  - Wired into discovery + assurance: `docs/README.md`, posture index, profile posture matrix, runbook must-read set, decision map, trajectory map, portal-family registry, CH-BGREQ/CH-BGLEASE schema notes, ACP validator semantics, ACP kind registry, invariant registry (`I-BGLEASE-2`), and proof-obligation registry (`PO-BGLEASE-ENF`).
- Research anchors (URLs only in bibliography): reused the existing XDG/Android/Apple background precedents and leaned on the already-curated **REF-APPLE-BGTASKS** split to sharpen “prefer jobs for deferrable work.”
- New CI drift gate:
  - Added `tools/check_bglease_posture.py` and registered **EVID-2026-232** (pins the v0 no-ambient-persistence / no-silent-widening rule + discovery wiring; prevents agent/workstation persistence semantics from drifting back into implicit daemon/autostart behavior).

## Revised222 (2026-03-06)
- Pinned the Phase-1 meaning of **capshell pipelines** so agent automation stays explicit, auditable, and LLM-resilient:
  - New `docs/30-architecture/capshell-pipeline-posture-v0.md`: pipelines are sequences of **stage-local** `capshell.exec` actions; Phase 1 forbids direct peer handle/FD passing (including SCM_RIGHTS-style hidden handoff); cross-stage handoff uses existing explicit surfaces such as **CH-AREF** digests, **CH-PLUMBMSG** digests, or explicit portal outputs rebound into the next stage's own CH-EXECPACK.
  - Wired into discovery + assurance: `decision-map.md`, `trajectory-map.md`, `docs/README.md`, posture index, profile posture matrix, runbook must-read set, RFC-0115 history, invariant registry (`I-CAPSHELL-PIPE-1`), and proof-obligation registry (`PO-CAPSHELL-PIPELINE-EXPLICIT`).
  - Tightened workflow seams so the decision is local and enforceable: `CH-STDIO v0`, `CH-FDSET v0`, `CH-EXECPACK v2`, and ACP validator/kind registry docs now explicitly treat multi-stage workflows as **multiple** actions rather than hidden runner-private handle passing.
- Research anchors (URLs only in bibliography): reused SHILL, Capsicum, and Plan 9 plumbing precedents; added **REF-FUCHSIA-DICTCAP** as a concrete precedent for explicit grouped capability routing if we ever need an authoritative future handoff bundle.
- New CI drift gate:
  - Added `tools/check_capshell_pipeline_posture.py` and registered **EVID-2026-231** (pins the v0 no-peer-handoff rule + discovery/assurance wiring; prevents hidden authority-transfer channels from creeping into capshell pipelines).









## Revised221 (2026-03-04)
- Pinned Phase-1 host↔guest interop semantics under `ext.microvm` so D-MICROVM's "no hidden host channels" rule stays implementable:
  - New `docs/30-architecture/host-guest-channel-posture-v0.md`: v0 forbids **virtio-vsock** (AF_VSOCK) and host filesystem sharing devices (**virtio-fs/9p**); disallows an implicit host control plane; any future admission must be explicit, portal/lease-shaped, and policy-killable.
  - Wired into discovery: decision map, posture index, profile posture matrix, docs index, and the base microVM posture doc.
- Research anchors (URLs only in bibliography): added refs for Firecracker vsock design, Cloud Hypervisor vsock notes, Linux vsock man page, and virtiofs design/kernel docs.
- New CI drift gate: `tools/check_host_guest_channel_posture.py` registered as **EVID-2026-230** (pins the exclusion set + discovery/REF wiring; prevents ambient host-channel drift).

## Revised220 (2026-03-04)
- Made D-ATTEST implementable without protocol sprawl by standardizing the **export artifact** returned by IF-ATTEST:
  - New `docs/30-architecture/attestation-pack-schema-v0.md`: **CH-ATTESTPACK v0** bundles canonical CH-ATTEST bytes with optional provider-native evidence blobs (opaque) and endorsement pointers; export is explicitly **bounded** to avoid exfil-surface drift.
  - Wired into discovery and contracts: schema registry, IF registry, D-ATTEST posture, CH-ATTEST schema notes, docs index.
- Research anchors (primary sources; URLs only in bibliography):
  - Added REF entries for COSE algorithms (RFC 9053), AMD SNP Firmware ABI spec, Intel TDX quoting extension, Arm CCA token draft, and CoRIM/CRIM reference-value precedents.
- New CI drift gate:
  - Added `tools/check_attestation_pack_wiring.py` and registered **EVID-2026-229** (requires CH-ATTESTPACK to stay bounded, cited, and wired into discovery surfaces).

## Revised219 (2026-03-04)
- Pinned the Phase-1 meaning of **D-ATTEST** to keep remote attestation from drifting into an ambient channel or privileged protocol sprawl:
  - New `docs/30-architecture/attestation-posture-v0.md`: CH-ATTEST is **boot-bound and observational**, freshness is explicit/optional, and provider-specific parsing (TPM quotes / SNP / TDX / CCA) stays out of the privileged core.
  - Introduced an explicit interop kill switch: `cfg.params.lane.attest.export` (wired from IF-ATTEST; profiled in `profile-lane-defaults.md`).
  - Wired into discovery: decision map, posture index, profile posture matrix, docs index; and tightened B’s claim intent for C-ATTEST-1 in the profile claim matrix.
- New CI drift gate:
  - Added `tools/check_attestation_posture.py` and registered **EVID-2026-228** (pins v0 semantics + lane gate wiring + minimal REF anchors).

## Revised218 (2026-03-04)
- Pinned the Phase-1 meaning of **D-SEAL** as a v0 posture “meaning pin” so init-only authority cannot silently become permanent:
  - New `docs/30-architecture/seal-posture-v0.md`: explicit init→seal transition; post-seal authority is **one-way attenuation** (no regain/widen except via explicitly authorized reconfiguration actions); composes with CH-PLEDGE subset-only masks and view narrowing.
  - Wired into discovery: `decision-map.md`, `docs/README.md`, posture index, profile posture matrix, and runbook must-read set.
- New CI drift gate:
  - Added `tools/check_seal_posture.py` and registered **EVID-2026-227** (pins v0 semantics + discovery + minimal precedent refs).

## Revised217 (2026-03-04)
- Added an explicit **profile claim matrix** to prevent accidental over-claiming drift:
  - New `docs/00-meta/profile-claim-matrix.md`: maps every C-ID from `docs/20-assurance/claim-registry.md` across the four product shapes (A–D) using a small REQ/REC/OPT/NO legend.
  - Wired into discovery: linked from `docs/README.md` and included in the runbook must-read set.
- New CI drift gate:
  - Added `tools/check_profile_claim_matrix.py` and registered **EVID-2026-226** (requires the matrix to exist/be discoverable and list every claim id).

## Revised216 (2026-03-04)
- Pinned an implementable Phase-1 posture for **D-OBS** so observability doesn’t drift into an ambient exfil/indexing channel:
  - Added `docs/30-architecture/observation-export-posture-v0.md` (pull-only exports; bounded/redaction-first; no ambient global indexing; exports are policy-killable).
  - Introduced an explicit export kill switch: `cfg.params.lane.obs.export` (wired in `config-toggle-registry.md` + `profile-lane-defaults.md`; referenced from IF-OBS registry).
  - Wired posture into discovery: `decision-map.md`, `docs/README.md`, IF-OBS registry, and CH-OBS/CH-OBSPOL schema docs now link the posture.
- New CI drift gate:
  - Added `tools/check_obs_export_posture.py` and registered **EVID-2026-225** (pins D-OBS v0 meaning + wiring + minimal REF anchors).
- Research anchors:
  - Added **REF-FUCHSIA-INSPECT-TREE** and **REF-FUCHSIA-DIAGNOSTICS-SCHEMA** (keeps “on-demand, capability-mediated diagnostics exports” precedent reviewable).

## Revised215 (2026-03-04)
- Standardized **v0 posture doc shape** to reduce drift and improve LLM resilience:
  - Added `docs/30-architecture/posture-doc-conventions.md` (required section order: Posture v0 → Phase 1 non-goals → Wiring → References).
  - Refactored all v0 posture docs listed in `docs/30-architecture/posture-index.md` to conform (adds missing Wiring/References/non-goals where needed; keeps semantics unchanged).
- New CI drift gate:
  - Added `tools/check_posture_doc_conventions.py` and registered **EVID-2026-224** (enforces posture doc section shape, requires `decision-map.md` wiring and ≥1 REF anchor per posture doc).
- Discovery wiring:
  - Linked `posture-doc-conventions.md` from `docs/README.md` and from `posture-index.md`.
## Revised214 (2026-03-04)
- Added a **profile posture matrix** as an explicit amnesia resistor: `docs/00-meta/profile-posture-matrix.md` maps every v0 posture meaning-pin across the four product shapes (A–D) using a small REQ/REC/OPT/NO legend (prevents “wrong profile assumptions” drift while keeping posture docs fork-free).
  - Wired into discovery: linked from `docs/README.md` and included in the runbook must-read set.
- New CI drift gate:
  - Added `tools/check_profile_posture_matrix.py` and registered **EVID-2026-223** (requires the matrix to be present/discoverable and to list every `*-posture-v0.md` posture doc).
- Research anchors:
  - Added **REF-QUBES-DOC-ARCH** (living Qubes architecture docs) and **REF-AIOS-ARXIV24** (AIOS: LLM Agent Operating System) to keep A/D profile precedents reviewable.
## Revised213 (2026-03-04)
- Added a **v0 posture index** as an explicit amnesia resistor: `docs/30-architecture/posture-index.md` enumerates every `*-posture-v0.md` meaning-pin and records its CI hook (or explicit lack thereof), reducing drift and improving discovery.
  - New CI drift gate: `tools/check_posture_index.py` registered as **EVID-2026-222** (requires the posture index to exist, be referenced from `docs/README.md`, and list every v0 posture doc).
- Added a small research-backed mechanism note for **virtio-iommu** and wired it into the relevant posture seams without changing claims:
  - New `docs/30-architecture/virtio-iommu-mechanism-note.md` (attaches to D-MICROVM + D-DMA; vIOMMU is declared/killable; not a substitute for host IOMMU/SMMU).
  - Tight wiring updates: `microvm-profile-posture-v0.md`, `dma-posture-v0.md`, and `mechanisms.md` now link the mechanism note.
- Research anchors: added primary REF entries for Cloud Hypervisor IOMMU notes, a Linux virtio-iommu binding note, and the virtio spec source repo (for diff tracking).

## Revised212 (2026-03-04)
- Made a Phase-1 **fail-closed** decision for **D-DMA** so DMA-aware isolation claims don’t drift into “IOMMU optional” folklore: if **C-ISO-2** is claimed, the active posture is **IOMMU/SMMU-required**; otherwise DMA-class attach/lease workflows must deny-by-default and C-ISO-2 is not claimed.
  - Added `docs/30-architecture/dma-posture-v0.md`: pins v0 posture vocabulary (`iommu_required` / `devices_in_tcb` / `no_dma`) and wires it to D-DMA + C-ISO-2 + I-DMA-1 + PO-IOLEASE-CONFINE/PO-PART-DMA.
  - Tightened wiring: `decision-map.md`, `claim-registry.md`, `deployment-profiles.md`, `io-lease-posture-v0.md`, `mechanisms.md`, and `docs/README.md` now point at the pinned posture.
- Research anchors: added primary references for DMA remapping/enforcement and for IOMMU integration pitfalls:
  - **REF-AMD-IOMMU** (AMD IOMMU spec), **REF-ARM-SMMUV3** (Arm SMMUv3 spec), and **REF-THUNDERCLAP** (NDSS 2019).
- New CI drift gate:
  - Added `tools/check_dma_posture.py` and registered **EVID-2026-221** (prevents D-DMA/C-ISO-2 drift; enforces discovery + minimal REF wiring).

## Revised211 (2026-03-04)
- Made a hard Phase-1 decision for **D-IOLEASE/D-DEVGUARD** to keep peripherals non-ambient and consent-visible: device attach/lease flows are **manual-only** via `portal.device.*` (**no CH-ACP kind in v0**), with **no ambient device namespace** and mandatory **CH-RECEIPT** consent receipts for any lease grant/revoke.
  - Added `docs/30-architecture/io-lease-posture-v0.md`: pins “manual-only / deny-by-default hotplug / DMA-class fail-closed behind D-DMA” posture and wires it to existing I/PO anchors.
  - Tightened wiring: `portal-family-registry.md`, `config-toggle-registry.md`, `io-lease-schema-v0.md`, `decision-map.md`, `docs/README.md`, and `docs/00-meta/llm-runbook.md` now point at the pinned posture.
- Research anchor: added **REF-LINUX-USB-AUTHZ** (Linux kernel USB device authorization docs) to ground deny-by-default hotplug and to support prototyping portal flows.
- New CI drift gate:
  - Added `tools/check_iolease_posture.py` and registered **EVID-2026-220** (prevents device access drift into ambient `/dev`/udev conventions; enforces “no ACP kind” v0 decision + discovery/REF wiring).
- Captured follow-up scope explicitly as **OQ-0009** (when device leasing becomes automatable: conflict-key family vs single serialization point).

## Revised210 (2026-03-04)
- Pinned a Phase-1 scope posture for **D-LEASE** so “temporary authority” stays implementable and auditable: leases are **proxy authority** (not hints), with **no raw cap export**, **no unbounded renewal**, and **no ambient time authority** (time-based bounds require explicit Clock handles under D-NONDET).
  - Added `docs/30-architecture/capability-lease-posture-v0.md`: nails down v0 meaning and binds it to I-LEASE-1..3 + PO-LEASE-VALIDATE/ENF/NOAMP.
  - Tightened wiring: `docs/30-architecture/decision-map.md`, `docs/30-architecture/capability-semantics.md`, `docs/30-architecture/capability-lease-schema-v0.md`, `docs/60-engineering/portal-design-playbook.md`, `docs/00-meta/llm-runbook.md`, and `docs/README.md` now point at the pinned posture.
- New CI drift gate:
  - Added `tools/check_caplease_posture.py` and registered **EVID-2026-219** (prevents D-LEASE drift into raw-cap sharing / implicit renewal / ambient time semantics).

## Revised209 (2026-03-04)
- Made an explicit v0 posture decision for **D-NONDET** to prevent drift back into ambient time/RNG channels: **no ambient time APIs and no ambient RNG APIs** when enabled; time/entropy enter domains only via explicit portal-issued handles (CH-CLOCK/CH-ENTROPY).
  - Added `docs/30-architecture/nondet-posture-v0.md`: pins v0 constraints (coarse-by-default clocks; fine clocks are explicit authority; entropy is seed-by-default; replay binding is fail-closed; timeproof remains separately killable).
  - Tightened wiring: `docs/30-architecture/decision-map.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/config-toggle-registry.md`, `docs/README.md`, and the must-read set now point at the pinned posture.
- Research anchors: added REF-SEL4-IRQ-TUTORIAL (timer IRQs as explicit capability authority) and REF-ROUGHTIME-REPO (reference implementation pointer) to keep the posture implementable and reviewable.
- New CI drift gate:
  - Added `tools/check_nondet_posture.py` and registered **EVID-2026-218** (prevents ambient nondeterminism drift; enforces discovery + minimal REF wiring).

## Revised208 (2026-03-04)
- Made a Phase-1 scope decision for D-NETLEASE to keep networking killable-by-policy and non-ambient: **no ambient sockets/DNS**; outbound networking exists only as **portal-issued leased authority** (manual `portal.net` workflow or ACP kind `portal.net.request`).
  - Added `docs/30-architecture/network-lease-posture-v0.md`: pins v0 semantics (no ambient resolver/proxy config; name resolution is lease-bound; commutativity/ordering wiring remains explicit).
  - Tightened CH-NETLEASE v0 formality: `docs/30-architecture/network-lease-schema-v0.md` now includes an explicit `resolver` binding for any name-resolving lease (v0 admits `resolver.kind="portal"` only), keeping PO-NETLEASE-DNSBIND evidenceable without ambient resolver channels.
  - Tightened wiring: `docs/30-architecture/decision-map.md`, `docs/30-architecture/portal-family-registry.md`, `docs/30-architecture/config-toggle-registry.md`, `docs/70-llm-control/acp-action-kind-registry.md`, and `docs/README.md` now point at the pinned posture.
- Research anchor: added **REF-CENET** (capability-enabled networking thesis) to ground the “no ambient communication; explicit grants” posture.
- New CI drift gate:
  - Added `tools/check_netlease_posture.py` and registered **EVID-2026-217** (prevents ambient networking drift; keeps D-NETLEASE posture + schema wiring discoverable).

## Revised207 (2026-03-04)
- Made a Phase-1 scope decision for D-NS to keep namespaces least-authority and implementable: **explicit view objects**, **single-slot binding**, and **no privileged `open(path)`** surface.
  - Added `docs/30-architecture/view-namespace-posture-v0.md`: pins the v0 meaning of namespaces and wires `view.attach`/`view.detach` commutativity/ordering to the `view.slot` conflict-key family.
  - Entropy reduction: trimmed `docs/30-architecture/view-objects.md` back to v0 semantics and deferred v1 ergonomics (union/clones/service trees) to RFC-0032.
  - Tightened wiring: `docs/30-architecture/decision-map.md`, `docs/70-llm-control/acp-action-kind-registry.md`, and `docs/README.md` now point at the pinned posture.
- Research anchors: added REF-FUCHSIA-NS, REF-FUCHSIA-LIFEOFOPEN, and REF-UNIONMOUNT-44BSD (and referenced them from RFC-0032) to ground the “explicit namespace table / no kernel path parsing” posture.
- New CI drift gate:
  - Added `tools/check_view_namespace_posture.py` and registered **EVID-2026-216** (prevents ambient namespace drift; keeps Phase-1 constraints discoverable).


## Revised206 (2026-03-04)
- Made a Phase-1 scope decision for D-MICROVM to keep `ext.microvm` implementable and the exit/device-model TCB reviewable:
  - Added `docs/30-architecture/microvm-profile-posture-v0.md`: v0 is **virtio-first, declared, and fail-closed**, with **no legacy emulation** and **no hidden host channels**.
  - Tightened wiring: `docs/30-architecture/decision-map.md`, `docs/30-architecture/config-toggle-registry.md`, `docs/10-threat-model/deployment-profiles.md`, and `docs/README.md` now point at the pinned posture.
  - Research anchors: added REF-VIRTIO-1.3, REF-KVM-API, REF-QEMU-MICROVM, REF-CHYP-DEVICE-MODEL, and REF-FIRECRACKER-KERNEL-POLICY.
- New CI drift gate:
  - Added `tools/check_microvm_profile_posture.py` and registered **EVID-2026-215** (prevents “microvm means everything” drift; keeps Phase-1 “not a compat escape hatch” stance explicit).

## Revised205 (2026-03-04)
- Made a hard scope decision to keep sealed compat implementable in Phase 1: **no second compat runtime family**.
  - Updated `docs/30-architecture/rumpk-selection-posture-v0.md` (resolves OQ-0003): v0 remains **rump-only** and **filesystem-image handling only**; Phase 1 explicitly forbids adding LKL/userspace-kernel/libOS/POSIX facades without a new RFC + evidence.
  - Tightened `docs/30-architecture/foreign-cell-contract.md` definition to avoid implying in-scope runtime diversity; explicitly calls out the rump-only v0 posture.
  - Updated `docs/00-meta/trajectory-map.md`: records OQ-0003 as **recently resolved** and removes it from the open-questions list (reduces entropy; keeps discovery coherent).
  - Updated `docs/README.md` to reflect the Phase-1 ban and the OQ-0003 resolution.
- Drift gate hardened (EVID-2026-210):
  - Updated `tools/check_rumpk_selection_posture.py` to enforce that OQ-0003 is recorded as resolved (not open), and that both CH-FCELL and the membrane contract reflect the rump-only v0 posture.

## Revised204 (2026-03-04)
- Made a hard D-REPL/Hybrid decision to reduce entropy: **close CH-REPLCONTRACT `object_family` tokens** and make RC4 admission explicit.
  - Added `docs/30-architecture/replication-object-family-registry.md`: v0 allowlist for `object_family` (strict profiles reject unknown families).
  - Added `docs/30-architecture/profile-repl-defaults.md`: non-authoritative A–D default guidance for replication classes; **RC4 reserved to `tlog`** in v0.
  - Tightened CH-REPLCONTRACT docs: `replication-contract-schema-v0.md` now calls out registry-closure and the RC4 admission rule; `replication-contracts-v0.md` adds an explicit “RC4 admission posture (v0)” section.
  - Updated OQ-0001 to reflect the narrowed RC4 posture and to point at the new stable diff surfaces.
  - Research anchors: added **REF-CT-RFC9162** (Certificate Transparency v2) and **REF-COSI-2015** (witness cosigning) and referenced them from the RC4 posture section.
- New CI drift gate:
  - Added `tools/check_profile_repl_defaults.py` and registered **EVID-2026-214** (pins the allowlist + A–D defaults + RC4 admission; keeps global ordering rare and reviewable).

## Revised203 (2026-03-04)
- Made a hard scope decision to keep D-UICAP implementable: pinned a **narrow v0 UI-capability posture** without picking a UI stack (toolkit/compositor protocol/remote display remain out of scope).
  - Added `docs/30-architecture/uicap-scope-posture-v0.md` (resolves OQ-0004): surface isolation + focus-gated input are required when enabled; capture/remote-control/automation authority is portal-mediated (and ideally leased); spoof-resistant interactive profiles require SAS + secure UI mode.
  - Wired the posture from `decision-map.md` (D-UICAP) and `docs/README.md`; added a crosslink from `docs/90-inspirations/os-lessons.md` to reduce duplication.
  - Research anchor: added **REF-MS-UAC-SECUREDESKTOP** (Microsoft Learn UAC secure desktop prompts) to the bibliography and referenced it from the posture doc.
- New CI drift gate:
  - Added `tools/check_uicap_scope_posture.py` and registered **EVID-2026-213** (prevents UI scope drift; keeps OQ-0004 retired).

## Revised202 (2026-03-04)
- Made an explicit D-PCP posture decision (keeps proof-carrying provenance implementable): **release-only PCP**; boot-time verification stays small (verify binding, not bulky proofs).
  - Added `docs/60-engineering/pcp-posture-v0.md` and wired it from the decision map (D-PCP) and the supply-chain posture doc.
  - Added SCITT interop anchors (tooling-only): REF-SCITT-ARCH / REF-SCITT-SCRAPI / REF-SCITT-CCF-RECEIPTS.
- New CI drift gate:
  - Added `tools/check_pcp_posture.py` and registered EVID-2026-212.

## Revised201 (2026-03-04)
- Made a hard, high-leverage D-ENC decision without expanding schema entropy: pinned **canonical bytes** for all `digest(CH-XYZ vN)` references.
  - Added `docs/30-architecture/schema-canonical-bytes-v0.md`: v0 `digest(CH-XYZ vN)` hashes **Deterministically Encoded CBOR** bytes (RFC 8949 §4.2); JSON authoring is optional and must canonicalize (JCS) before transcoding.
  - Updated `encoding-policy.md`, `decision-map.md` (D-ENC), `profile-hash-suite-v0.md`, and the conflict-key derivation helpers to reference the canonical-bytes posture.
- Research anchors (informative): added REF-IPLD-DAG-CBOR and REF-WEBAUTHN-3 as cross-ecosystem precedent for “reject non-canonical CBOR” when hashes are binding primitives.
- New CI drift gate:
  - Added `tools/check_canonical_bytes_posture.py` and registered EVID-2026-211.

## Revised200 (2026-03-04)
- Made sealed compat Hybrid/commutativity evidence less drift-prone by pinning **Foreign Cell identities** to D-TYPEDID.
  - Updated `typed-id-contract-v0.md` to include `cell_id` (digest-sized `bstr` of length `hashlen`).
  - Updated `foreign-cell-manifest-schema-v0.md`, `conflict-key-schema-v0.md`, `conflict-key-derivation-registry.md`, and CH-FADAPT v0/v1 receipts so `cell_id` is consistently digest-sized `bstr` (keeps `cell.id`/`cell.adapter` scoping mechanical; avoids string encoding ambiguity).
- Drift gate hardened:
  - Updated `tools/check_fcell_commutativity_contract.py` to require `cell_id: bstr` in CH-FADAPT and typed-id wiring in CH-FCELL + D-TYPEDID.

## Revised199 (2026-03-04)
- Entropy reduction: made the CH-FCELL manifest doc reflect the pinned D-RUMPK v0 runtime posture (keeps sealed compat honest).
  - Updated `docs/30-architecture/foreign-cell-manifest-schema-v0.md`: `runtime.kind` is **rump-only** in v0; other names remain reserved and MUST be rejected unless a later RFC expands D-RUMPK.
  - Reduced duplication: `portal_token` is now defined as the CH-PLEDGE portal-token closed set (mirrors `portal-family-registry.md`) instead of copying a long token list into CH-FCELL.
  - Updated the D-FCELL note in `docs/30-architecture/decision-map.md` to call out the rump-only CH-FCELL validator rule.
- Drift gate hardened:
  - Updated `tools/check_rumpk_selection_posture.py` (EVID-2026-210) to also fail if the CH-FCELL manifest doc stops enforcing the rump-only `runtime.kind` posture.

## Revised198 (2026-03-04)
- Reduced entropy in sealed compatibility without adding schema bloat: pinned a hard, narrow v0 **D-RUMPK internal runtime** posture.
  - Added `docs/30-architecture/rumpk-selection-posture-v0.md`: v0 compat runtime is **rump kernels** and scope is **filesystem-image handling only** (keeps D-RUMPK implementable; keeps sealed-compat honest under OQ-0003).
  - Updated discovery wiring: decision map + trajectory map OQ-0003 + docs index now point at the posture doc.
- Research anchors (comparison-only, not v0): added `REF-RUMPRUN-GITHUB` and `REF-GVISOR-GITHUB`.
- New CI drift gate:
  - Added `tools/check_rumpk_selection_posture.py` (wired via `make lint` runner + documented in `tools/README.md`) and registered **EVID-2026-210**.

## Revised197 (2026-03-04)
- Made a big-but-contained D-COMMUTE decision to stop “state digest” hand-waving: introduced a tiny **state projection receipt** seam and wired it end-to-end.
  - Added **CH-SPROJ v0** (`docs/30-architecture/state-projection-schema-v0.md`): bounded, deterministic, non-authoritative key-scoped post-state projection receipt (digest-friendly; no ambient identifiers).
  - Updated the ACP commutativity predicate registry to use `sproj_digest = digest(CH-SPROJ v0)` as the normalized “final state” hook for swap-order tests (reduces drift; keeps PO-COMMUTE-TEST implementable).
  - Updated ACP receipt obligations + assurance anchors: added **I-SPROJ-1** and **PO-ACP-SPROJ-EMIT** so CH-SPROJ emission/wiring can’t regress into prose-only expectations.
- New CI drift gate:
  - Added `tools/check_sproj_wiring.py` (wired via `make lint` runner + documented in `tools/README.md`) and registered **EVID-2026-209**.

## Revised196 (2026-03-04)
- Made sealed compat “no ambient host effects” testable and hard to hand-wave:
  - Added `docs/40-verification/foreign-cell-escape-suite-v0.md`: AC-071 negative-test contract for compatibility capsules (EVID-2026-206).
  - Wired AC-071 + compat proof obligations to cite the suite; added CI drift gate `tools/check_compat_escape_suite_wiring.py` (EVID-2026-207).
- Pinned CH-REQCTX temporal capability reference posture without schema bloat:
  - Added `docs/30-architecture/reqctx-tcap-ref-posture-v0.md` and wired from CH-REQCTX v0/v1 security notes + D-REQCTX note in `decision-map.md`.
  - Added CI drift gate `tools/check_reqctx_tcap_ref_posture.py` (EVID-2026-208).

## Revised195 (2026-03-04)
- Tightened the “explicit sponsorship” seam without changing CH-REQCTX’s schema surface:
  - Added `docs/30-architecture/reqctx-budget-ref-posture-v0.md`: v0 posture is that CH-REQCTX v1 `budget_desc_digests` is an **untyped** digest list, but consumers that require sponsorship are **type-strict** (only CH-BUDGET v0 counts) and **non-ambient** (no locator deref; schema mismatches count as missing).
  - Wired the posture into CH-REQCTX security notes, ACP validator semantics, and PO-CAPSHELL-BUDGET-REQ; updated OQ-0008 to point at the pinned v0 posture (future typed refs only if needed).
- New CI drift gate:
  - Added `tools/check_reqctx_budget_ref_posture.py` (wired via `make lint` runner + documented in `tools/README.md`) and registered **EVID-2026-205**.

## Revised194 (2026-03-04)
- Made a hard-but-boring decision explicit (reduces drift everywhere): pinned the archive-wide v0 **profile hash suite**.
  - Added `docs/30-architecture/profile-hash-suite-v0.md` and decision-map node **D-HASH**: `digest(bytes) := SHA-256(bytes)` and `hashlen := 32`.
  - Wired this definition into the seams that previously said “profile hash” ambiguously: `typed-id-contract-v0.md`, `conflict-key-derivation-registry.md`, and `encoding-policy.md`.
- New CI drift gate:
  - Added `tools/check_profile_hash_suite.py` (wired via `make lint` runner + documented in `tools/README.md`) and registered **EVID-2026-204**.
- Research anchors:
  - Added **REF-FIPS180-4** and **REF-RFC6234** (primary SHA-256 specs) to the bibliography.

## Revised193 (2026-03-04)
- Practical discovery wiring: made the portal-family registry explicitly declare its **automation surface**.
  - Updated `docs/30-architecture/portal-family-registry.md` to add an “ACP kind(s)” column: each portal family now either lists its `portal.<family>.*` CH-ACP action kind token(s) or explicitly says `none` (manual-only v0; no TBD).
  - This makes Hybrid + D-COMMUTE metadata discoverable from the portal taxonomy without inventing a new schema surface.
- New CI drift gate:
  - Added `tools/check_portal_registry_acp_kinds.py` (wired via `make lint` runner + documented in `tools/README.md`) and registered **EVID-2026-203**.

## Revised192 (2026-03-04)
- Made a harder D-CAPSHELL choice explicit and non-drifting: **executable selection is always explicit + unique** for `capshell.exec`.
  - Added `docs/30-architecture/capshell-exec-selector-posture-v0.md` (v0 posture: exactly one CH-ARGV `role="exec"` selector; no ambient PATH).
  - Updated CH-ARGV schema + ACP control docs to require **exactly one** exec selector across all profiles (not just “strict” or `minimal_context`).
- Entropy reduction: removed redundant exec-selector wording from the `cfg.params.capshell.minimal_context` knob surfaces (the knob now only narrows env/cwd/stdio/fdset), keeping “killable knobs” honest and minimizing duplication.
- New CI drift gate:
  - Added `tools/check_capshell_exec_selector.py` (wired via `make lint` runner + documented in `tools/README.md`) and registered **EVID-2026-202**.
- Research anchor:
  - Added **REF-OPENGROUP-EXEC** (POSIX `exec*` PATH-search semantics) to justify why PATH resolution is treated as an ambient authority seam.

## Revised190 (2026-03-04)
- Tightened sealed-compat Hybrid + commutativity posture without adding any new schema surface:
  - Added `docs/30-architecture/fcell-commutativity-contract-v0.md`: pins how CH-FADAPT adapter receipts participate in D-COMMUTE (derived `cell.adapter` conflict keys; optional explicit ordering via CH-ORDERTOK; no hidden serialization).
  - Updated `foreign-cell-contract.md` and CH-FADAPT v0/v1 docs to reference the pinned posture (keeps compat interop audit surfaces aligned with Hybrid requirements).
- Entropy reduction: moved **OQ-0002** out of the open-questions list into a short “Recently resolved” note in `docs/00-meta/trajectory-map.md` (remaining work is evidence/harnessing, not a design decision).
- New CI drift gate:
  - Added `tools/check_fcell_commutativity_contract.py` (wired via `make lint` runner + documented in `tools/README.md`) and registered **EVID-2026-201**.

## Revised189 (2026-03-04)
- Entropy-reducing amnesia resistor: made open questions a stable, referenceable surface.
  - Updated `docs/00-meta/trajectory-map.md` so every open question has a stable **OQ-####** id and explicitly attaches to at least one existing surface token (D-/CH-/I-/PO-/ADR-/...).
  - Updated `tools/gen_context_pack.py` and `tools/check_context_pack_contract.py` so the generated context pack preserves OQ ids (keeps follow-up work linkable across revisions).
- New CI drift gate:
  - Added `tools/check_open_questions.py` (wired via `make lint` runner + documented in `tools/README.md`) and registered **EVID-2026-200**.

## Revised188 (2026-03-04)
- Tightened D-AREF in a way that keeps “sealed compat” and “no ambient channels” honest **without introducing a new schema surface**:
  - Added `docs/30-architecture/artifact-resolution-posture-v0.md`: v0 rule is **no privileged dereference** of CH-AREF `locator` hints; bytes are obtained only via explicit portal workflows (net/file) and then verified against the digest.
  - Updated `artifact-reference-schema-v0.md` and the D-AREF decision text to link to the posture so locator semantics can’t drift back into implicit `file:`/`https:` authority.
- Assurance wiring:
  - Strengthened **I-AREF-1** and **PO-AREF-VERIFY** to state “no ambient deref” and that resolution is lane-killable (PO-LANE-KILL).
- New CI drift gate:
  - Added `tools/check_aref_resolution_posture.py` (wired via `make lint` runner + documented in `tools/README.md`) and registered **EVID-2026-199**.

## Revised187 (2026-03-04)
- Closed the D-ATTN “attention lease” follow-up **without adding a new schema surface**:
  - Added `docs/30-architecture/attention-lease-posture-v0.md`: v0 stance is **no dedicated attention-lease descriptor**; urgency is a policy-gated CH-NOTIF `importance="urgent"` hint.
  - Updated `notification-request-schema-v0.md` and `portal-family-registry.md` so “urgent/critical” cannot drift into an ambient bypass (still origin-branded, budgeted, volition-gated).
- Assurance wiring:
  - Added **I-ATTN-4** and **PO-ATTN-URGENT** (urgent is non-amplifying; deterministic deny/downgrade under policy).
- Discovery wiring:
  - Linked the posture doc from `docs/README.md` and updated `trajectory-map.md` + the D-ATTN note in `decision-map.md`.

## Revised186 (2026-03-04)
- Entropy-reducing hygiene refactor: made `make lint` practical in constrained environments without weakening any guardrails.
  - Added `tools/run_lint_suite.py`: runs `lint_archive.py` + every drift gate script under `tools/` (matching `check_*.py`) in a single Python process (reduces interpreter spawn overhead).
  - Updated `tools/check_guardrail_wiring.py` to treat `run_lint_suite.py` as a valid wiring mode (still enforces that all `check_*.py` scripts run and are documented).
  - Updated `tools/README.md` and registered **EVID-2026-198**.

## Revised185 (2026-03-04)
- Made D-RETRYSAFE **practically implementable** for `capshell.exec` by pinning a minimal output normal form that reuses existing artifacts (no new schema surface):
  - Added `docs/30-architecture/capshell-output-normal-form-v0.md`: exportable workflow outputs are `digest(CH-AREF v0)`; duplicate suppression returns the same output digests; no ambient path/env/implicit net output channels.
  - Wired the contract into `decision-map.md`, `trajectory-map.md`, and ACP validator semantics (`docs/70-llm-control/acp-validator-semantics.md`).
  - Strengthened PO/Invariant anchors so the requirement can’t drift back into prose: updated **PO-RETRY-DEDUP** and **I-RETRY-1** to explicitly mention `capshell.exec` output digests.
- New CI drift gate:
  - Added `tools/check_capshell_output_normal_form.py` (wired into `make lint` + documented in `tools/README.md`) and registered **EVID-2026-197**.
- Research / ecosystem import:
  - Added **REF-REAPI-PROTO** (Bazel Remote Execution API proto) and **REF-NIX-CA-OUTPUTS** (Nix content-addressed outputs) to the bibliography.

## Revised184 (2026-03-04)
- Closed the D-COMMUTE follow-up on “profile-defined typed id encodings” by pinning a v0 **typed-id contract** for the ids that feed `ck_id(..)` and ordering scopes:
  - Added `docs/30-architecture/typed-id-contract-v0.md` and a decision-map node **D-TYPEDID**: `as_id`/`endpoint_id`/`view_id`/`log_id`/`meter_id`/`budget_id` (and `domain_id` when used as an action scope) are digest-sized `bstr` values (single canonical encoding: raw bytes).
  - Updated `conflict-key-derivation-registry.md` to reference the typed-id contract and treat those ids as digest-sized inputs (so `ck_id(..)` deterministically returns `x`, avoiding double-hashing without a structured tuple encoding surface).
  - Updated the trajectory map shared-substrate section to surface D-TYPEDID and removed the now-resolved open question about `ck_id(..)` input canonicalization.
- New amnesia/drift guardrail:
  - Added `tools/check_typed_id_contract.py` (wired into `make lint` + documented in `tools/README.md`) to fail CI if the typed-id contract becomes unlinked/unreferenced.
  - Added **I-TYPEDID-1** to the invariant registry to keep the assurance substrate aware of the pinned id representation.
- Research / ecosystem import (content-addressed naming):
  - Added **REF-RFC6920**, **REF-GIT-HASH-TRANSITION**, and **REF-MULTIHASH** to the bibliography and updated **CH-AREF v0** to include `ni:` as a policy-gated locator example (digest remains authoritative).
## Revised183 (2026-02-28)
- Integrated a least-authority **entropy request seam** for D-NONDET (no ambient RNG constructors; LLMs propose; validators execute; schemas/receipts are the stable surface):
  - Added **CH-ENTREQ v0** (`docs/30-architecture/entropy-request-schema-v0.md`): bounded, non-authoritative entropy request descriptor for `portal.entropy`; includes stable `req_id` for retry/dedupe correlation; never carries entropy bytes or bearer secrets.
  - Added ACP kind **`portal.entropy.request`** (ordered within `domain.id`; lane-gated by `cfg.params.lane.portal.entropy`) and wired it into commutativity predicates + serialization-boundary registry (keeps Hybrid + D-COMMUTE honest).
  - Updated D-NONDET decision note to explicitly name the ACP/portal seam (`portal.entropy.request` + CH-ENTREQ) as the preferred “no ambient nondet” path.
- Wiring + assurance/evidence:
  - Added **PO-ENTREQ-VALIDATE** and **PO-ACP-ENTROPY-REQUEST**; strengthened **I-NONDET-5**.
  - Registered **EVID-2026-196** (harness plan for lane-disabled rejects, ordered-stream witness enforcement, dedupe by req_id, and CH-ENTROPY emission/validation).
- Reference hygiene: added **REF-LINUX-GETRANDOM** to the bibliography for a primary RNG API baseline.

## Revised182 (2026-02-28)
- Tightened lane-gate *discoverability* on the stable product surface (prevents optional surfaces from drifting into “ambiently enabled” or “lane-gated but unnamed” posture):
  - Added a new CI drift gate `tools/check_acp_kind_lane_gates.py` (wired into `make lint`) that enforces: any lane-gated ACP kind (`portal.*`, `capshell.exec`, `fcell.*`) explicitly names its required `cfg.params.lane.*` kill switch key in the ACP kind registry Profiles cell, and the key exists in both `config-toggle-registry.md` and `profile-lane-defaults.md`.
  - Updated `acp-action-kind-registry.md` to make this requirement explicit in the per-kind metadata contract.
- Assurance + evidence wiring:
  - Strengthened **I-LANEGATE-1** and **PO-LANE-KILL** to include the explicit “ACP kind registry names required lane keys” contract.
  - Registered **EVID-2026-195**.

## Revised181 (2026-02-28)
- Entropy-reducing refactor: upgraded **CH-IOLEASE v0** (`docs/30-architecture/io-lease-schema-v0.md`) from an informal note into a standard schema surface (Encoding + conceptual data model + explicit bounds + fail-closed validation rules). This keeps device lease descriptors LLM-resilient and audit-friendly under D-IOLEASE and sealed-compat device mediation:
  - Explicitly reiterates non-authoritative posture (lease descriptors do not grant), no bearer secrets, and a `dma_window.kind="policy_ref"` option for profiles that forbid embedding raw IOVA addresses.
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_iolease_schema_formality.py` and wired it into `make lint`.
  - Enforces that CH-IOLEASE remains marked as a schema surface (no “informal” regression), retains Encoding/Data model/Validation rules sections, and stays wired to canonical PO/I anchors.
- Assurance + evidence wiring:
  - Added **I-IOLEASE-3** and **PO-IOLEASE-VALIDATE**.
  - Registered **EVID-2026-194**.

## Revised180 (2026-02-28)
- Reduced D-COMMUTE / Hybrid drift risk by pinning deterministic conflict-key derivation for the digest-valued `*_key` payload fields used by pinned hot-action and ACP seams (prevents “canonical tuple” ambiguity and keeps ordering scopes reviewable):
  - Added `docs/30-architecture/conflict-key-derivation-registry.md` (v0 seed): normative `ck_id(..)` helper and per-family tuple→digest derivation commitments for `mem.range`/`ipc.endpoint`/`view.slot`/`log.eventset`/`budget.*` (and cross-links for `domain.id`/`policy.param`).
  - Strengthened CH-CONFLICTKEY v0 derivation commitments (`docs/30-architecture/conflict-key-schema-v0.md`) to include these families (not just `policy.param` / `domain.id`) and to reference the derivation registry as the source of truth.
  - Tightened hot-action ordering scope prose (`hot-action-boundaries-v0.md`) so CH-ORDERTOK scoping is explicitly to `digest(CH-CONFLICTKEY v0)` and points to the derivation registry for the underlying `*_key` fields.
- Entropy-reducing refactor: unified CH-ORDERTOK family vocabulary with CH-CONFLICTKEY families to prevent shadow ordering vocabularies:
  - Updated `ordering-token-schema-v0.md` so `scope.family` uses the closed CH-CONFLICTKEY family allowlist pinned in `conflict-key-family-registry.md` (no “profile-defined enum” drift).
  - Updated the conflict-key family registry wiring requirements to explicitly cover CH-ORDERTOK.
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_conflictkey_derivation_registry.py` and wired it into `make lint`.
  - Enforces derivation-registry wiring (docs index + CH-CONFLICTKEY schema + hot-action boundaries) and rejects any `CH-ORDERTOK v0 (family \`...\`)` references that use unknown family tokens (prevents D-COMMUTE/Hybrid scoping drift).
- Assurance + evidence wiring:
  - Updated **I-CONFLICTKEY-2** and added **I-ORDERTOK-3**; updated **PO-CONFLICTKEY-DERIVE** and **PO-ORDERTOK-VALIDATE**.
  - Registered **EVID-2026-193**.
- Trajectory map update: refreshed the D-COMMUTE follow-up open question to reflect the new derivation registry; remaining follow-up is pinning canonical encodings for the profile-specific typed ids that feed `ck_id(..)`.

## Revised179 (2026-02-28)
- Tightened **policy/authority denial** evidence surfaces (no ambient “which policy?” drift) by introducing an explicit policy-handle schema surface and removing a stale, non-specified coupling point:
  - Added **CH-POLICYHANDLE v0** (`docs/30-architecture/policy-handle-schema-v0.md`): a digestable, non-authoritative handle naming veto-only policy semantics (evaluator + policy artifact digest). Supports profiles where policy is builtin/compiled (not shipped as a CH-POLICY bundle) while keeping CH-DENY policy denials transcript-visible and reviewable.
  - Updated policy/authority deny bindings to be explicit and schema-pinned: for `missing-approval` / `expired-approval` / `policy-deny`, CH-DENY now binds `reason.ref_digest = digest(CH-POLICY v0)` **or** `digest(CH-POLICYHANDLE v0)` (deny-code registry + CH-DENY producer rules + ACP validator semantics + D-POLICY note).
  - Entropy-reducing refactor: removed references to a non-specified `CH-CFG` `policy_bundle` field from CH-FADAPT receipts (v0/v1) and replaced with the explicit CH-POLICY/CH-POLICYHANDLE handle set (prevents a “shadow field” from becoming an ambient policy context).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_no_cfg_policy_bundle_ref.py` and wired it into `make lint`.
  - Forbids stale references to a non-specified `CH-CFG` `policy_bundle` field and vague “profile-defined policy handle” wording, keeping policy-handle semantics pinned to CH-POLICYHANDLE and preventing regression into ambiguous, prose-only policy contexts.
- Assurance + evidence wiring:
  - Added **I-POLICYHANDLE-1** and **PO-POLICYHANDLE-VALIDATE**; strengthened **PO-DENY-POLICY-BIND** and **I-DENY-5** to include CH-POLICYHANDLE.
  - Registered **EVID-2026-192**.

## Revised178 (2026-02-28)
- Entropy-reducing refactor: upgraded **CH-PLUMBMSG v0** (`docs/30-architecture/plumb-message-schema-v0.md`) from an informal note into a standard schema surface (Encoding + conceptual data model + explicit bounds + fail-closed validation rules), keeping D-PLUMB workflow intent envelopes LLM-resilient and audit-friendly.
  - Explicitly anchors `intent.kind` closure to `docs/30-architecture/intent-kind-registry.md` (no shadow enums) and reiterates non-authoritative posture (I-PLUMB-3).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_plumbmsg_schema_formality.py` and wired it into `make lint`.
  - Enforces that CH-PLUMBMSG stays marked as a schema surface (no “informal” regression), references the canonical intent-kind registry, and retains explicit fail-closed + validation anchors (prevents workflow plumbing drift into prose-only surfaces).
- Evidence wiring: registered **EVID-2026-191**.

## Revised177 (2026-02-28)
- Integrated an LLM-first, least-authority **network lease request seam** under D-NETLEASE (no ambient sockets; validators execute; schemas/receipts are the stable surface):
  - Added **CH-NETREQ v0** (`docs/30-architecture/network-request-schema-v0.md`): bounded, non-authoritative request descriptor for `portal.net` lease issuance; includes stable `req_id` for retry/dedupe correlation.
  - Added ACP kind **`portal.net.request`** (ordered within `domain.id`; profile-gated by `cfg.params.lane.portal.net`) so network leases can be requested as **LLM proposals** and executed via deterministic validators with transcript-visible outcomes.
- Hybrid + commutativity wiring (D-COMMUTE):
  - Updated the ACP kind registry and commutativity predicate registry to include `portal.net.request` (explicit predicate + normalized observation boundary).
  - Added serialization-boundary token `svc:portal.net` to the closed registry.
- Wiring + registries + evidence:
  - Updated the schema registry and docs index (`docs/README.md`) to link CH-NETREQ.
  - Updated D-NETLEASE in `decision-map.md` to mention the ACP kind and the request/lease split (CH-NETREQ → CH-NETLEASE).
  - Added **I-NETREQ-1**, **PO-NETREQ-VALIDATE**, and **PO-ACP-NET-REQUEST**; registered **EVID-2026-190**.

## Revised176 (2026-02-28)
- Tightened least-authority + sealed-kill-switch audit surfaces by making **policy/authority denials digest-bound** on the stable CH-DENY receipt surface (prevents “which policy?” from drifting into ambient/log-only explanations):
  - Updated `docs/30-architecture/deny-code-registry.md` to require `reason.ref_digest = digest(CH-POLICY v0)` bindings for `missing-approval`, `expired-approval`, and `policy-deny`.
  - Strengthened CH-DENY v0 producer rules (`docs/30-architecture/denial-receipt-schema-v0.md`) so these deny codes MUST set `reason.kind="policy"` and MUST bind `reason.ref_digest` to the pinned policy handle digest.
  - Updated ACP validator semantics (`docs/70-llm-control/acp-validator-semantics.md`) to emit these bindings on Reject paths and added an explicit “Policy/authority denials are digest-bound” section.
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_deny_policy_bindings.py` and wired it into `make lint`.
  - Enforces coherence across deny-code registry + CH-DENY producer rules + ACP semantics so policy-deny bindings cannot silently drift.
- Assurance + evidence wiring:
  - Added **I-DENY-5** and **PO-DENY-POLICY-BIND**; registered **EVID-2026-189**.

## Revised175 (2026-02-28)
- Tightened least-authority workflow intent posture by making “what is this run for?” **schema-pinned and profile-gated** (prevents intent drifting into ambient/prose-only channels while keeping A–D viable without forks):
  - Added **CH-EXECPACK v2** (`docs/30-architecture/capshell-exec-pack-schema-v2.md`): exec-pack now supports an optional `plumbmsg_digest = digest(CH-PLUMBMSG v0)` non-authoritative intent envelope (D-PLUMB) alongside the complete workflow context + `reqctx_digest = digest(CH-REQCTX v1)`.
  - Added `cfg.params.capshell.require_plumbmsg` (veto-only) and pinned A–D defaults in `profile-workflow-defaults.md` so strict profiles can require an explicit CH-PLUMBMSG envelope for `capshell.exec` without forks.
  - Added new deterministic deny token `plumbmsg-missing` to the closed deny-code registry for missing required intent envelopes (receipt-shaped; no ad-hoc strings).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_capshell_plumbmsg_req.py` and wired it into `make lint`.
  - Enforces coherence across cfg toggle registry + profile defaults + CH-EXECPACK v2 + ACP semantics/kind registry + deny-code vocabulary + assurance/evidence wiring (prevents silent regression to prose-only intent).
- Version/wiring updates:
  - Updated capshell/ACP wiring to treat CH-EXECPACK v2 as the normative exec-pack for `capshell.exec` (schema registry, decision map, ACP schema/semantics, CLI plumbing doc).
  - Updated the existing exec-pack reqctx drift gate and evidence entry (**EVID-2026-153**) to reference CH-EXECPACK v2.
- Assurance + evidence wiring:
  - Added **I-CAPSHELL-PLUMBMSG-1** and **PO-CAPSHELL-PLUMBMSG-REQ**; registered **EVID-2026-188**.

## Revised174 (2026-02-28)
- Tightened D-COMMUTE reject evidence so ordering failures stay **receipt-shaped** (no ambient/prose-only “ordering failed” explanations):
  - Updated `deny-code-registry.md` to require digest bindings for ordering denials:
    - `conflict-key-invalid` MUST bind `conflict_key_digest` (rejecting digest; for CH-ACP this is `meta.conflict_key_digest`).
    - `order-witness-missing` MUST bind `conflict_key_digest` (names the serialization domain even when `meta.order_digest` is absent).
    - `order-witness-invalid` MUST bind `order_digest` (and SHOULD bind `conflict_key_digest`).
  - Strengthened CH-DENY v0 producer rules to set `reason.kind="ordering"` and bind the relevant digest fields for these deny codes.
  - Updated ACP validator semantics to explicitly emit these bindings on `Reject(..)` paths (keeps Hybrid + commutativity audit surfaces stable).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_deny_ordering_bindings.py` and wired it into `make lint`.
  - Enforces coherence across deny-code registry, CH-DENY producer rules, and ACP semantics so ordering-deny bindings cannot silently drift.
- Assurance + evidence wiring:
  - Added **I-DENY-4** and **PO-DENY-ORDER-BIND**; registered **EVID-2026-187**.

## Revised173 (2026-02-28)
- Tightened lane kill-switch evidence to stay **explicit and reviewable** (prevents drift into ambiguous `lane-disabled` denials):
  - Strengthened CH-DENY v0 producer rules: for `deny_code == lane-disabled` and `deny_code == cfg-deny`, producers MUST bind `reason.kind="lane"` and MUST set `reason.ref_key=<cfg.params.* key>` naming the **registry-closed** gate/knob in `config-toggle-registry.md` (no ambient “which toggle fired?” state).
  - Updated ACP validator semantics to require the same `reason.ref_key` binding for lane/cfg-param gating rejections (stable receipt surface; LLM tooling can audit kill switches from transcripts).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_deny_lane_refkey.py` and wired it into `make lint`.
  - Enforces coherence across deny-code registry, CH-DENY schema, and ACP semantics so lane/cfg deny bindings cannot silently drift.
- Assurance + evidence wiring:
  - Strengthened **I-LANEGATE-1** and **PO-LANE-KILL** to treat `reason.ref_key` binding as part of lane-gate receipt visibility; registered **EVID-2026-186**.

## Revised172 (2026-02-28)
- Tightened least-authority workflow execution by making **explicit sponsorship** enforceable on the stable schema surface (no implicit budgets in automation):
  - Added `cfg.params.capshell.require_budget_lease` (veto-only). When true **and** `cfg.params.lane.metering=true`, `capshell.exec` requires the bound CH-REQCTX v1 to include at least one `budget_desc_digests` entry that resolves/validates as **CH-BUDGET v0** (D-BUDGET; I-BUDGET-1).
  - Added new deterministic denial token `budget-missing` to the closed deny-code registry for missing required budget leases (binds to the CH-REQCTX digest; no ambient sponsorship).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_capshell_budget_reqctx.py` and wired it into `make lint`.
  - Enforces closure + wiring across the cfg toggle registry, A–D workflow defaults matrix, ACP semantics/kind registry, deny-code vocabulary, and PO/I/EVID surfaces.
- Assurance + evidence wiring:
  - Added **I-CAPSHELL-BUDGET-1** and **PO-CAPSHELL-BUDGET-REQ**; registered **EVID-2026-185**.
- Wiring updates:
  - Updated `docs/30-architecture/decision-map.md` (D-CAPSHELL) to point at the new knob.
  - Updated `docs/70-llm-control/acp-validator-semantics.md` and `docs/70-llm-control/acp-action-kind-registry.md` to make the budget requirement explicit and receipt-shaped.
  - Updated `docs/00-meta/trajectory-map.md` with an open question on typed budget references in CH-REQCTX.

## Revised171 (2026-02-28)
- Tightened D-COMMUTE for the LLM-first action surface by pinning **per-kind commutation predicates** and **normalized observation boundaries** for swap-order tests:
  - Added `docs/70-llm-control/acp-commutativity-predicate-registry.md` (v0) as a stable diff surface for CH-ACP kinds.
  - Updated D-COMMUTE references to treat this as part of the commutativity evidence substrate (in addition to the ACP kind registry and hot-action surfaces).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_acp_commutativity_predicates.py` and wired it into `make lint`.
  - Enforces closure: every CH-ACP kind must have a predicate entry with explicit `Predicate:` and `Normalize:` anchors mentioning CH-ACPOUT + `conflict_key_digest` (prevents planner-unsafe “commutes” drift into prose).
- Assurance + evidence wiring:
  - Added **I-ACP-COMMUTE-1** and **PO-ACP-COMMUTE-PREDMAP**; registered **EVID-2026-184**.

## Revised170 (2026-02-28)
- Added a **profiled workflow hardening knob** for capshell execution context:
  - Introduced `cfg.params.capshell.minimal_context` (veto-only) to require a *minimal* `capshell.exec` context: empty CH-ENV, CH-CWD `kind="empty"`, CH-STDIO `(null, drop, drop)`, empty CH-FDSET, and exactly one CH-ARGV `role="exec"` selector (no ambient PATH).
  - Pinned non-authoritative A–D defaults in `docs/30-architecture/profile-workflow-defaults.md` (no forks).
- Denial + receipt hygiene (entropy-reducing refactor):
  - Added new deny code `cfg-deny` to the closed deny-code registry for cfg-param gates (bind `reason.ref_key = <cfg.params.* key>`).
  - Fixed CH-DENY v0 to include `reason.kind="reqctx"` in its closed enum, aligning the schema with existing `reqctx-mismatch` guidance and ACP semantics.
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_profile_workflow_defaults.py` and wired it into `make lint`.
  - Enforces that any `cfg.params.capshell.*` knob is registry-closed, has A–D defaults pinned, and is referenced from capshell/ACP control docs (prevents drift back into prose-only “strict profile” workflow rules).
- Assurance + evidence wiring:
  - Added **I-CAPSHELL-MINCTX-1** and **PO-CAPSHELL-MINCTX-ENF**; registered **EVID-2026-183**.

## Revised169 (2026-02-28)
- Made **retry/dedupe outcomes mechanically distinguishable** on the stable receipt surface:
  - Extended **CH-ACPOUT v0** with an optional closed `effect` field for `accept` outcomes: `applied` | `no_op` | `duplicate_suppressed`.
  - Tightened D-RETRYSAFE / ACP semantics to recommend `effect="duplicate_suppressed"` when a proposal is accepted but deduped (pre-effect suppression remains mandatory; no grant-by-id).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_acp_outcome_effect_status.py` and wired it into `make lint`.
  - Enforces that CH-ACPOUT effect-status anchors and `duplicate_suppressed` wiring remain present across ACP semantics, the ACP kind registry, and PO-RETRY-DEDUP.
- Assurance + evidence wiring:
  - Updated **I-RETRY-1** and **PO-RETRY-DEDUP** to explicitly bind dedupe visibility to CH-ACPOUT `effect`.
  - Registered **EVID-2026-182**.

## Revised168 (2026-02-28)
- Tightened the LLM-first action substrate by pinning **deterministic retry/dedupe semantics** (no duplicate effects under retries):
  - Added decision surface **D-RETRYSAFE** (schema-pinned idempotency keys for any kind that claims *at-least-once-safe*).
  - Updated ACP semantics docs to make dedupe obligations explicit and non-authoritative (no grant-by-id).
  - Updated the trajectory-map open question to treat CH-EFFCON `contract_id` as the canonical idempotency key for `capshell.exec` (output-normal-form remains the open follow-up).
- New CI drift gate (amnesia/drift guardrail):
  - Added `tools/check_retry_dedupe_wiring.py` and wired it into `make lint`.
  - Enforces that any ACP kind marked **at-least-once-safe** names an explicit stable id key token (e.g., CH-EFFCON `contract_id`, CH-JOBREQ `job_id`, CH-TIMEREQ `req_id`, CH-NOTIF.id), preventing “retry safe” prose drift.
- Assurance + evidence wiring:
  - Added **I-RETRY-1** and **PO-RETRY-DEDUP**; registered **EVID-2026-181**.
- Wiring updates:
  - Documented the new drift gate in `tools/README.md`, noted it in `README.md`, and updated `docs/70-llm-control/acp-validator-semantics.md` + `docs/70-llm-control/acp-action-kind-registry.md`.

## Revised167 (2026-02-28)
- New CI drift gate to prevent **context-pack drift** (LLM amnesia resistor):
  - Added `tools/check_context_pack_contract.py` and wired it into `make lint`.
  - The check generates a context pack into `out/_ci_context_pack.md` and enforces the contract: header revision/date matches the top CHANGELOG entry; required sections exist (non-negotiables, must-read set, profile matrix, open questions, commands); and all four profile rows remain present.
- Assurance + evidence wiring:
  - Added **I-CTXPACK-1** and **PO-CTXPACK-CONTRACT**; registered **EVID-2026-180**.
- Wiring updates:
  - Documented the new drift gate in `tools/README.md` and noted it in `README.md` repo checks.

## Revised166 (2026-02-28)
- New CI drift gate for the least-authority self-restriction surface (CH-PLEDGE token coherence):
  - Added `tools/check_pledge_token_mapping.py` and wired it into `make lint`.
  - Enforces that `docs/30-architecture/pledge-token-mapping.md` covers the closed CH-PLEDGE v0 token set declared in `docs/30-architecture/pledge-contract-schema-v0.md` exactly (no missing/extra/duplicate tokens), preventing “shadow promise tokens” from drifting into the archive.
- Assurance + evidence wiring:
  - Added **I-PLEDGE-4** and **PO-PLEDGE-MAP-CLOSE**; registered **EVID-2026-179**.
- Wiring updates:
  - Indexed CH-PLEDGE docs from `docs/README.md`, documented the drift gate in `tools/README.md`, and noted the new check in `README.md`.

## Revised165 (2026-02-28)
- Refactor: moved the closed ACP serialization-boundary token allowlist (`validator` / `svc:<name>` / `none`) out of `commutativity-and-interface-scalability.md` into a dedicated stable diff surface:
  - Added `docs/30-architecture/serialization-boundary-registry.md` (v0; closed).
  - Updated `docs/30-architecture/commutativity-and-interface-scalability.md` to reference the registry instead of embedding the table.
- CI drift gate update:
  - Updated `tools/check_acp_serialization_boundary_registry.py` to parse the allowlist from `serialization-boundary-registry.md`.
- Assurance + evidence wiring:
  - Updated **I-ACTMETA-1** and **PO-ACT-KINDMETA** to point at the new registry; registered **EVID-2026-178**.
- Wiring updates:
  - Linked the new registry from `README.md`, `docs/README.md`, `docs/30-architecture/decision-map.md`, and ACP kind registry notes.

## Revised164 (2026-02-28)
- New CI drift gate for privileged-surface discovery: IF-ID reference closure.
  - Added `tools/check_interface_registry_refs.py` and wired it into `make lint`.
  - Enforces that any `IF-...` token referenced in repo markdown (docs/RFCs/ADRs/README) must be present in `docs/30-architecture/interface-registry.md` (prevents typo’d/"shadow" interfaces).
- Assurance + evidence wiring:
  - Added **I-IFREF-1** and **PO-IFREF-CLOSE**; registered evidence hook **EVID-2026-177**.
- Wiring updates:
  - Noted the drift gate in `docs/30-architecture/interface-registry.md` and documented the tool in `tools/README.md`.

## Revised163 (2026-02-28)
- New CI drift gate to prevent “svc-name drift” in multicore/commutativity evidence surfaces:
  - Added a **closed serialization-boundary token registry** in `docs/30-architecture/commutativity-and-interface-scalability.md` (stable diff surface for `validator`/`svc:<name>` tokens used by ordered CH-ACP kinds).
  - Added `tools/check_acp_serialization_boundary_registry.py` and wired it into `make lint` to enforce allowlist closure for the ACP kind registry’s Serialization boundary column.
- Assurance + evidence wiring:
  - Strengthened **I-ACTMETA-1** and **PO-ACT-KINDMETA** to treat serialization-boundary tokens as registry-closed; registered evidence hook **EVID-2026-176**.
- Wiring updates:
  - Documented the new drift gate in `tools/README.md` and added a CI note in `docs/70-llm-control/acp-action-kind-registry.md`.

## Revised162 (2026-02-28)
- Integrated D-BGLEASE into the LLM-first, validator-executed surface (no ambient background/autostart APIs):
  - Added **CH-BGREQ v0** (`docs/30-architecture/background-request-schema-v0.md`), a bounded request descriptor (no capability material) for background/autostart grants.
  - Added ACP kind **`portal.background.request`** and wired it through ACP docs + validator semantics (ordered within `domain.id`; explicit serialization boundary `svc:portal.background`; policy-killable via `cfg.params.lane.portal.background`).
  - Updated RFC-0103 and decision-map D-BGLEASE to reflect the CH-BGREQ→portal→CH-BGLEASE flow and the ACP seam.
- Assurance + evidence wiring:
  - Added **I-BGREQ-1**, **PO-BGREQ-VALIDATE**, and **PO-ACP-BGLEASE-REQUEST**; registered evidence hook **EVID-2026-175**.
- Wiring updates:
  - Updated portal registry + pledge mapping + effect-contract allowlist to reference CH-BGREQ as the request descriptor; updated docs indexes (README + docs/README).

## Revised161 (2026-02-28)
- New CI drift gate to keep drift gates alive and discoverable (LLM-resilience / prevents silent lint degradation):
  - Added `tools/check_guardrail_wiring.py` and wired it into `make lint`.
  - Enforces that every `check_*.py` drift gate under `tools/` is invoked by `make lint`, exists on disk, and is referenced in `tools/README.md`.
- Assurance + evidence wiring:
  - Added **I-TOOLWIRE-1** and **PO-TOOLWIRE-CLOSE**; registered evidence hook **EVID-2026-174**.
- Wiring update:
  - Documented the new drift gate in `tools/README.md`.

## Revised160 (2026-02-28)
- New CI drift gate for the assurance substrate (prevents traceability drift under LLM edits):
  - Added `tools/check_assurance_token_refs.py` and wired it into `make lint`.
  - Enforces registry-closure for assurance IDs across repo markdown: A-* (assumptions), C-* (claims), I-* (invariants), PO-* (proof obligations). Undefined/typo'd assurance IDs (including in registries themselves) fail CI.
- Assurance + evidence wiring:
  - Added **I-ASSUREREF-1** and **PO-ASSUREREF-CLOSE**; registered evidence hook **EVID-2026-173**.
- Entropy-reducing refactor (caught by the new registry-closure gate):
  - De-duplicated **I-WASM-1** by renaming the "Closed import set" invariant to **I-WASM-4** and updating references (PO-WASM-IMPORTS, RFC-0052, AC-041, and related notes).
- Wiring update:
  - Documented the tool in `tools/README.md` and added the new check to `Makefile` `lint`.

## Revised159 (2026-02-28)
- Expanded schema reference closure (LLM-resilience for the schemas/validators/receipts product surface):
  - Added `tools/check_schema_token_refs.py` and wired it into `make lint`.
  - Rejects `docs/` mentions of versioned schema tokens of the form `CH-XYZ vN` unless the (CH-ID,version) pair exists in `docs/30-architecture/schema-registry.md` (catches prose/example typos beyond `digest(...)` references).
- Assurance + evidence wiring:
  - Added **I-SCHEMAREF-2** and extended **PO-SCHEMAREF-CLOSE** to cover both `digest(CH-XYZ vN)` and plain `CH-XYZ vN` references; registered evidence hook **EVID-2026-172**.
- Wiring update:
  - Noted the new drift gate in `docs/30-architecture/schema-registry.md` and documented the tool in `tools/README.md`.

## Revised158 (2026-02-28)
- New CI drift gate to keep the closed `portal.*` workflow authority taxonomy honest in *prose* docs:
  - Added `tools/check_portal_token_refs.py` and wired it into `make lint`.
  - Rejects `docs/` references to backticked `portal.*` tokens unless their root family exists in `docs/30-architecture/portal-family-registry.md` (prevents unreviewed portal seams / workflow authority drift).
- Assurance + evidence wiring:
  - Added **I-PORTALREF-1** and **PO-PORTALREF-CLOSE**; registered evidence hook **EVID-2026-171**.
- Wiring update:
  - Noted the new drift gate in `portal-family-registry.md` and documented the tool in `tools/README.md`.

## Revised157 (2026-02-28)
- New CI drift gate for profile-extension vocabulary: added `tools/check_feature_flag_refs.py` and wired it into `make lint`.
  - Rejects `docs/` references to backticked `ext.*` `cfg.feature_flags` values unless they exist in the closed set pinned in `docs/30-architecture/config-toggle-registry.md` (prevents typo’d/shadow feature flags).
- Assurance + evidence wiring:
  - Added **I-FLAGREF-1** and **PO-FLAGREF-CLOSE**; registered evidence hook **EVID-2026-170**.
- Wiring update:
  - Added the new drift gate to the config-toggle registry evidence seed list.

## Revised156 (2026-02-28)
- Integrated D-JOBS into the LLM-first ACP surface (no ambient cron/alarms):
  - Added ACP kind `portal.jobs.submit` (ordered within `domain.id`, serialization boundary `svc:portal.jobs`) that binds `jobreq_digest = digest(CH-JOBREQ v0)` and is policy-killable via `cfg.params.lane.portal.jobs`.
  - Updated ACP schema/examples and validator semantics to require canonical CH-JOBREQ validation and fail-closed lane gating before invoking the portal; outcomes are transcript-visible (CH-ACPOUT/CH-DENY) with explicit conflict_key/order digests.
- Assurance + evidence wiring:
  - Added **PO-ACP-JOBS-SUBMIT** and registered evidence hook **EVID-2026-169** (ACP/job portal harness plan).
- Wiring updates:
  - Updated RFC-0096, D-JOBS decision-map entry, CH-JOBREQ schema notes, and `docs/README.md` to reference the ACP seam.

## Revised155 (2026-02-28)
- Integrated D-TIMEPROOF into the LLM-first ACP surface (no ambient time assumptions):
  - Added CH-TIMEREQ v0 (`docs/30-architecture/timeproof-request-schema-v0.md`) as a bounded, endpoint-free request descriptor.
  - Added ACP kind `portal.clock.timeproof.sample` that binds `timereq_digest = digest(CH-TIMEREQ v0)` and yields CH-TIMEPROOF evidence; ordered within `domain.id` with explicit `svc:portal.clock` serialization boundary.
- Kept the seam policy-killable and profile-friendly (A–D; no forks):
  - Added lane kill switch `cfg.params.lane.timeproof` (in addition to `cfg.params.lane.portal.clock`) and pinned A–D defaults in `profile-lane-defaults.md`.
- Assurance + evidence wiring:
  - Added **I-TIMEREQ-1**, **PO-TIMEREQ-VALIDATE**, and **PO-ACP-TIMEPROOF-SAMPLE**; registered evidence seed **EVID-2026-168**.
- Discovery/anti-drift hardening:
  - Extended `tools/check_discovery.py` to require CH-TIMEPROOF/CH-TIMEREQ artifacts remain indexed from `docs/README.md`.

## Revised154 (2026-02-28)
- New stable diff surface for profile composition (no forks): added `docs/30-architecture/profile-feature-flag-defaults.md` to pin **non-authoritative** A–D defaults for the closed `cfg.feature_flags` set.
- New CI drift gate (LLM-resilience for profile posture): added `tools/check_profile_feature_flag_defaults.py` and wired it into `make lint`. It enforces matrix closure over the `cfg.feature_flags` closed set in `config-toggle-registry.md` (no silent omission/widening of default profile-extension posture).
- Wiring + assurance:
  - Linked the new matrix from `docs/README.md` and referenced it from `config-toggle-registry.md`.
  - Added **I-PROFFLAGDEFAULTS-1**, **PO-PROFFLAGDEFAULTS-VERIFY**, and evidence **EVID-2026-167**.

## Revised153 (2026-02-28)
- Entropy-reducing refactor: centralized the D-PLUMB workflow `intent.kind` vocabulary as a single stable diff surface:
  - Added `docs/30-architecture/intent-kind-registry.md` as the canonical closed taxonomy shared by CH-PLUMBMSG v0 and CH-ROUTE v0 (non-authoritative; unknown kinds reject).
  - Updated `plumb-message-schema-v0.md` and `route-rules-schema-v0.md` to reference the canonical registry (no shadow enum lists in schema docs).
  - Wired the registry into discovery/control points (`docs/README.md` and the D-PLUMB section of `decision-map.md`).
- New CI drift gate (LLM-resilience for workflow semantics):
  - Added `tools/check_intent_kind_registry.py` and wired it into `make lint`. It enforces that the canonical kind list is defined only in the registry and rejects any local `intent.kind` enum bullet lists near closed-enum declarations (prevents typo’d intents and “shadow vocabularies”).
- Assurance + evidence wiring:
  - Added **I-INTENTKIND-1** and **PO-INTENTKIND-CLOSE**.
  - Evidence: registered **EVID-2026-166**.

## Revised152 (2026-02-28)
- New CI drift gate to keep **decision references** mechanically closed and LLM-resilient:
  - Added `tools/check_decision_map_refs.py` and wired it into `make lint`. It enforces that any `D-*` identifier referenced in the `docs/` tree has a corresponding entry in `docs/30-architecture/decision-map.md` (prevents orphan decision IDs and keeps the decision→schemas→invariants→POs→evidence chain discoverable).
- Assurance + evidence wiring:
  - Added **I-DECISIONMAP-1** and **PO-DECISIONMAP-CLOSE**.
  - Evidence: registered **EVID-2026-165**.

## Revised151 (2026-02-28)
- Tightened sealed-compat killability with **granular Foreign Cell adapter lane gates** (no ambient interop growth):
  - Added per-adapter kill switches `cfg.params.lane.fcell.adapter.*` (v0 seed: `posix_open_via_doc_portal`, `posix_socket_via_net_portal`) so enabling the Foreign Cell lane does not implicitly enable specific adapter-mediated host workflows.
  - Updated D-FCELL control points to require **both** the adapter gate and the bound portal gate to be enabled (missing toggles fail closed): `foreign-cell-contract.md`, `foreign-cell-manifest-schema-v0.md`, `fcell-adapter-kind-registry.md`, `config-toggle-registry.md`, and `profile-lane-defaults.md`.
- Drift gate strengthening (LLM-resilience):
  - Extended `tools/check_fcell_adapter_registry.py` to require each adapter kind row has a corresponding `cfg.params.lane.fcell.adapter.<adapter_kind>` kill switch (in addition to portal lane kill switches), preventing silent compat interop widening.
- Assurance + evidence wiring:
  - Updated I-FADAPT-2 / I-FADAPT-3 and PO-FADAPT-EMIT / PO-FADAPT-KINDREG to reflect adapter-level lane gating.
  - Evidence: registered **EVID-2026-164**.

## Revised150 (2026-02-28)
- Entropy-reducing refactor: made the CH-CONFLICTKEY **family allowlist** a first-class stable diff surface.
  - Added `docs/30-architecture/conflict-key-family-registry.md` as the canonical closed family list and wired it into discovery/control points (docs index, D-COMMUTE decision map, and CH-CONFLICTKEY schema).
- New CI drift gate (LLM-resilience for D-COMMUTE/Hybrid):
  - Added `tools/check_conflictkey_family_registry.py` and wired it into `make lint`. It enforces schema↔registry closure and rejects any `family="..."` references across docs that use unknown family tokens (prevents typo'd family strings from silently drifting validators/evidence harnesses).
- Assurance + evidence wiring:
  - Updated **I-CONFLICTKEY-1** to point to the canonical family registry and extended **PO-CONFLICTKEY-VALIDATE** evidence.
  - Evidence: registered **EVID-2026-163**.

## Revised149 (2026-02-28)
- New CI drift gate to keep **evidence hooks** mechanically closed and LLM-resilient:
  - Added `tools/check_evidence_refs.py` and wired it into `make lint`. It enforces that any `EVID-YYYY-NNN` token referenced in repo markdown resolves to an entry in `docs/00-meta/evidence-index.md` and that evidence IDs are unique (prevents evidence-hook typos and orphaned references).
- Assurance wiring:
  - Added invariant **I-EVID-1** and proof obligation **PO-EVID-CLOSE** so evidence-token closure is an explicit part of the authority-substrate invariants/PO surface.
- Evidence: registered **EVID-2026-162**.

## Revised148 (2026-02-28)
- New CI drift gate to keep **Hybrid + D-COMMUTE** hot-path evidence mechanically honest:
  - Added `tools/check_hot_action_wiring.py` and wired it into `make lint`. It enforces that `hot-action-surface-v0.md` and `hot-action-boundaries-v0.md` name the same pinned family set, and that each family retains explicit conflict-key / ordering-token / replication-contract statements (prevents “hot action” taxonomy drift).
  - Updated `docs/30-architecture/hot-action-boundaries-v0.md` to name the tool as the enforcement surface.
- Evidence: registered **EVID-2026-161**.

## Revised147 (2026-02-28)
- Integrated the attention portal into the **LLM-first ACP surface** without introducing ambient notification APIs:
  - Added ACP kind `portal.attn.request` (profile-gated by `cfg.params.lane.portal.attn`) that binds `notif_digest = digest(CH-NOTIF v0)` and routes requests through the mediated `portal.attn.*` seam.
  - Pinned commutativity/ordering metadata in the ACP kind registry (ordered within `domain.id`; explicit `svc:portal.attn` serialization boundary) to keep Hybrid + D-COMMUTE honest.
- Assurance + evidence wiring:
  - Added **PO-ACP-ATTN-REQUEST** and registered evidence seed **EVID-2026-160** for lane-gate negative tests, CH-NOTIF digest binding, and ordered-witness enforcement.
- New guardrail (drift prevention):
  - Extended `tools/check_acp_kindmeta.py` to verify that any ACP kind starting with `portal.` corresponds to a portal family token in `portal-family-registry.md` and is explicitly lane-gated via `cfg.params.lane.portal.<family>` (keeps workflow seams policy-killable and prevents portal taxonomy drift inside ACP).
- Wiring:
  - Updated D-ATTN decision-map note and CH-NOTIF schema to reference the ACP invocation seam.




## Revised146 (2026-02-28)
- Integrated D-ATTN into the **portal taxonomy** as a first-class, policy-killable workflow seam (no ambient notification APIs):
  - Added the attention portal family `portal.attn.*` with CH-PLEDGE token `portal.attn` to `docs/30-architecture/portal-family-registry.md`.
  - Wired the new portal token through all closed-world control points (no forks):
    - CH-PLEDGE token set (`docs/30-architecture/pledge-contract-schema-v0.md`)
    - pledge token→effect mapping (`docs/30-architecture/pledge-token-mapping.md`)
    - Foreign Cell portal allowlist seed (`docs/30-architecture/foreign-cell-manifest-schema-v0.md`)
    - lane kill switch registry (`docs/30-architecture/config-toggle-registry.md`) + A–D defaults (`docs/30-architecture/profile-lane-defaults.md`)
    - CH-EFFCON effect kind + lane mapping + workflow descriptor allowlist table (`docs/30-architecture/effect-contract-schema-v0.md`)
- Tightened assurance/evidence around notifications as a schema+validator surface:
  - Added **PO-NOTIF-VALIDATE** and registered evidence seed **EVID-2026-159** for CH-NOTIF v0 validation + lane-gate negative tests.
  - Updated `docs/30-architecture/notification-request-schema-v0.md` to explicitly bind to `portal.attn.*` + `cfg.params.lane.portal.attn` and to spell out lane-disabled deny semantics.
- New amnesia-resistor guardrail:
  - Extended `tools/check_discovery.py` to require CH-NOTIF be indexed from `docs/README.md` when present (prevents D-ATTN from drifting into orphan docs).
- Wiring:
  - Updated `docs/README.md` (added portal-family registry + CH-NOTIF) and repo `README.md` pointers.

## Revised145 (2026-02-28)
- Strengthened archive amnesia-resistance around the **stable diff surfaces** by pinning bibliography + evidence hooks into the must-read loop:
  - Updated `docs/00-meta/llm-runbook.md` must-read set to include `docs/00-meta/bibliography.md` and `docs/00-meta/evidence-index.md`.
  - Extended `tools/check_discovery.py` to fail CI if those stable surfaces drop out of the must-read set.
- Discovery wiring:
  - Updated `docs/README.md` to reference `00-meta/evidence-index.md` and `30-architecture/multicore-architecture-options.md`.
  - Updated `tools/README.md` to list `check_discovery.py` and `gen_context_pack.py` as first-class guardrails.
- Wiring + evidence:
  - Registered evidence seed **EVID-2026-158**.

## Revised144 (2026-02-28)
- Strengthened denial semantics as a stable, schema-pinned product surface by adding a new CI drift gate:
  - Added `tools/check_deny_code_refs.py` and wired it into `make lint`. It scans repo markdown for lines that explicitly name a `deny_code` token (e.g., `deny_code = invalid-schema`, `deny_code: invalid-schema`, or `deny_code \`invalid-schema\``) and fails if the token is not present in `docs/30-architecture/deny-code-registry.md`.
  - Updated `deny-code-registry.md` notes to reference the new drift gate.
- Wiring + assurance + evidence:
  - Updated **PO-DENY-CODES** and **I-DENY-3** to reflect registry-closed deny-code references in docs/examples.
  - Registered evidence seed **EVID-2026-157** and documented the tool in `tools/README.md`.

## Revised143 (2026-02-28)
- Tightened **Hybrid + D-COMMUTE** scalability evidence by making serialization points mechanically explicit for ordered ACP kinds:
  - Refactor: extended the ACP kind registry table with a new `Serialization boundary` column. For any kind whose stance includes **ordered**, the boundary must be `validator` or `svc:<name>`; non-ordered kinds must use `none`.
  - Added `tools/check_acp_serialization_boundary.py` and wired it into `make lint` to prevent “ordered-but-nowhere” drift (LLM-amnesia resistor).
  - Updated the D-COMMUTE doc to reference the registry field as the audit surface for explicit serialization owners.
- Wiring + assurance + evidence:
  - Updated **I-ACTMETA-1** and **PO-ACT-KINDMETA** to cover serialization-boundary metadata.
  - Registered evidence seed **EVID-2026-156** and documented the tool in `tools/README.md`.

## Revised142 (2026-02-28)
- Strengthened archive **discovery surfaces** and LLM-resilience by adding a new CI drift gate that keeps bibliography references mechanically coherent:
  - Added `tools/check_bibliography_refs.py` and wired it into `make lint`. It scans repo markdown (docs/RFCs/ADRs/CHANGELOG) for `REF-*` tokens and fails if any referenced token is not defined in `docs/00-meta/bibliography.md` (or if the bibliography contains duplicate REF keys).
  - The guardrail also enforces that each bibliography REF entry line includes an explicit http(s) URL, keeping citations audit-friendly and avoiding “floating” refs.
- Refactor: deduplicated bibliography entries uncovered by the new gate (removed duplicate keys for **REF-RUMPKERNEL-ABC2015**, **REF-ARRAKIS-OSDI14**, and **REF-CAPNP-RPC**) and standardized the canonical Arrakis URL to the Usenix paper PDF.
- Wiring + assurance + evidence:
  - Added invariant **I-REF-1** and proof obligation **PO-REF-CLOSE**.
  - Registered evidence seed **EVID-2026-155** and documented the tool in `tools/README.md`.

## Revised141 (2026-02-28)
- Strengthened the **schemas/validators/receipts product surface** and LLM-resilience by adding a new CI drift gate that prevents schema/version typos from silently drifting the archive:
  - Added `tools/check_digest_schema_refs.py` and wired it into `make lint`. It scans docs for **versioned** schema digest references of the form `digest(CH-XYZ vN)` and fails if any reference does not resolve to an entry in `docs/30-architecture/schema-registry.md`.
  - Documented the guardrail in `docs/30-architecture/schema-registry.md` and `tools/README.md`.
- Wiring + assurance + evidence:
  - Added invariant **I-SCHEMAREF-1** and proof obligation **PO-SCHEMAREF-CLOSE**.
  - Registered evidence seed **EVID-2026-154**.

## Revised140 (2026-02-28)
- Tightened **no ambient authority in workflows** by making request-context correlation non-ambient at the capshell execution boundary:
  - Added **CH-EXECPACK v1** (`docs/30-architecture/capshell-exec-pack-schema-v1.md`): exec-pack now binds `reqctx_digest = digest(CH-REQCTX v1)` in addition to the complete workflow context digests (CH-EFFCON/ARGV/ENV/CWD/STDIO/FDSET).
  - Updated ACP/capshell control points to require `capshell.exec` use `exec_pack_digest = digest(CH-EXECPACK v1)` and to require `CH-ACP meta.reqctx_digest == CH-EXECPACK v1 reqctx_digest` (fail closed; recommended CH-DENY is `reqctx-mismatch`).
  - Refactored D-CAPSHELL decision-map wiring to explicitly include CH-EXECPACK v1 as the workflow completeness seal.
- New CI drift gate (LLM-amnesia resistor):
  - Added `tools/check_capshell_execpack_reqctx.py` and wired it into `make lint`. It fails if exec-pack v1 is missing/unregistered, if ACP/capshell semantics stop requiring reqctx coherence, or if the deny-code vocabulary drifts.
- Wiring + assurance + evidence:
  - Updated schema registry + docs index entries to prefer CH-EXECPACK v1 (v0 retained as legacy).
  - Added invariant **I-EXECPACK-2** and proof obligation **PO-CAPSHELL-REQCTX-BIND**.
  - Registered evidence seed **EVID-2026-153**.

## Revised139 (2026-02-28)
- Added a new CI drift gate to keep the schema registry a closed-world, stable diff surface:
  - Added `tools/check_schema_registry_complete.py` and wired it into `make lint`. It fails if any `*-schema-vN.md` spec file exists under `docs/30-architecture/` or `docs/70-llm-control/` but is missing from `docs/30-architecture/schema-registry.md` (prevents orphan schema specs and LLM drift).
  - Documented the guardrail in `tools/README.md` and noted it in `docs/30-architecture/schema-registry.md`.
- Evidence: registered **EVID-2026-152**.

## Revised138 (2026-02-28)
- Integrated **D-NONDET** into the canonical portal taxonomy to keep “no ambient nondeterminism” mechanically enforceable and drift-resistant:
  - Added `portal.clock` and `portal.entropy` as first-class portal families in `docs/30-architecture/portal-family-registry.md`; updated the CH-PLEDGE token set and the pledge token→effect mapping table accordingly (closed-world, fail-closed).
  - Updated **CH-EFFCON v0**: extended the closed effect-kind enum, lane-gate mapping, and the workflow descriptor allowlist so `capshell.exec` can bind **CH-CLOCK v0** / **CH-ENTROPY v0** descriptors only under declared `portal.clock` / `portal.entropy` effects (no ambient time/RNG).
  - Added explicit lane kill switches `cfg.params.lane.portal.clock` and `cfg.params.lane.portal.entropy` to the CH-CFG toggle registry and pinned A–D default guidance in the profile lane-defaults matrix (still veto-only; enabling never grants authority).
  - Updated CH-FCELL v0 portal-token seeds and the Foreign Cell contract to recognize `portal.clock`/`portal.entropy` issuance flows while keeping time/entropy as explicit resource handles (`resources.clocks` / `resources.entropy`) and preserving the sealed compat membrane.
  - Refactor: eliminated the one-off `portal.time` naming drift in RFC-0063 by renaming it to `portal.clock`.
- Assurance + evidence:
  - Updated **I-NONDET-1** and **PO-NONDET-NOAMBIENT** and registered **EVID-2026-151** (CI drift gates cover D-NONDET portal closure across portal registry/pledge/mapping/lane gates/effcon allowlist).

## Revised137 (2026-02-28)
- Tightened the **sealed POSIX/legacy Foreign Cell** membrane and the **LLM-first schemas/receipts surface** by adding an additive correlation hook for compat adapter receipts:
  - Added **CH-FADAPT v1** (`docs/30-architecture/fcell-adapter-receipt-schema-v1.md`): identical to v0 plus optional `reqctx_digest = digest(CH-REQCTX v1)` (non-authoritative; veto-only). This removes “implicit context” drift for profiles that want end-to-end correlation without introducing ambient authority.
  - Updated wiring surfaces to reference v0/v1 receipts (decision map D-FCELL, foreign cell contract, CH-FCELL manifest notes, schema registry, docs index).
- Strengthened CI drift gates (LLM-amnesia resistors):
  - Extended `tools/check_fcell_adapter_registry.py` to additionally enforce that if CH-FADAPT v1 exists it is registered, discoverable, and references both the adapter-kind registry and CH-REQCTX v1 (prevents orphan schema + correlation-hook drift).
- Assurance + evidence:
  - Added invariant **I-FADAPT-4** (reqctx propagation is non-authoritative/veto-only) and updated **PO-FADAPT-VALIDATE** to cover v0/v1.
  - Registered evidence seed **EVID-2026-150**.

## Revised136 (2026-02-28)
- Addressed the “no forks” profile viability mandate by pinning **non-authoritative A–D default guidance** for lane kill switches as a stable diff surface:
  - Added `docs/30-architecture/profile-lane-defaults.md` (profile default matrix for `cfg.params.lane.*`, including the complete `cfg.params.lane.portal.*` set).
  - Updated the CH-CFG toggle registry to reference the matrix for profile-dependent default guidance (without changing fail-closed lane semantics).
- New CI guardrail (LLM-amnesia resistor):
  - Added `tools/check_profile_lane_defaults.py` and wired it into `make lint`. It fails if the profile defaults matrix is not complete/closed over the `cfg.params.lane.*` key set pinned in `config-toggle-registry.md`, contains unknown keys, or uses values outside `{on,off}`.
- Wiring + assurance + evidence:
  - Added invariant **I-PROFDEFAULTS-1** and proof obligation **PO-PROFDEFAULTS-VERIFY**.
  - Registered evidence seed **EVID-2026-149** and updated discovery surfaces (`docs/README.md`, `tools/README.md`, decision map D-PLUMB note).

## Revised135 (2026-02-28)
- Added a new CI guardrail (LLM-amnesia resistor) to keep **no ambient authority** + **policy-killability** honest for CH-CFG: `tools/check_cfg_key_refs.py` fails `make lint` if any docs reference backticked `cfg.params.*` keys that are not present in the canonical closed set pinned in `docs/30-architecture/config-toggle-registry.md` (prevents “ambient toggles” / unreviewable lane gates).
- Wiring + assurance + evidence:
  - Wired the new check into `make lint` and documented it in `tools/README.md`.
  - Registered evidence seed **EVID-2026-148** and attached it to **PO-CFGTOGGLE-VERIFY**.
  - Updated CH-CFG toggle registry to cite the new evidence seed.

## Revised134 (2026-02-28)
- Tightened the **schemas/receipts are the product surface** + **LLMs propose; validators execute** pillars by making request contexts a stable, digest-only substrate in the ACP: CH-ACP proposals now MUST carry `meta.reqctx_digest = digest(CH-REQCTX v1)` (non-authoritative; veto-only).
  - Updated ACP control points to validate and echo `reqctx_digest` into CH-LOG v0 and CH-ACPOUT v0 (digest-only; redaction-safe), preventing ad-hoc correlation/idempotency drift and keeping replay/audit mechanically checkable.
  - Updated CH-ACPOUT v0 and the CH-LOG contract to include `reqctx_digest` as a first-class observability field (never authorization evidence).
- New CI guardrail (LLM-amnesia resistor):
  - Added `tools/check_acp_reqctx_wiring.py` and wired it into `make lint`. It fails if CH-ACP/ACP semantics stop requiring CH-REQCTX v1, if CH-LOG/CH-ACPOUT stop echoing it, or if wiring/assurance references drift.
- Wiring + assurance + evidence:
  - Updated schema registry + docs indexes for CH-REQCTX v1.
  - Added invariant **I-ACP-REQCTX-1** and proof obligation **PO-ACT-REQCTX**; registered evidence seed **EVID-2026-147**.
## Revised133 (2026-02-28)
- Tightened the **sealed POSIX/legacy Foreign Cell** membrane by closing an `adapter_kind` taxonomy drift seam:
  - Added `docs/30-architecture/fcell-adapter-kind-registry.md` (canonical closed adapter-kind set; binds each adapter to a CH-PLEDGE `portal.*` token, issued descriptor kinds, and lane kill switches).
  - Refactored CH-FCELL v0 seeds to point at the registry and removed the ambiguous `posix.clock_via_clock_handle` seed (time/entropy remain explicit resource handles via `resources.clocks` / `resources.entropy`, not adapter-mediated workflows in v0).
  - Updated CH-FADAPT v0 validation notes to require adapter kinds be members of the registry (fail closed).
- New CI guardrail (LLM-amnesia resistor):
  - Added `tools/check_fcell_adapter_registry.py` and wired it into `make lint`. It fails if CH-FCELL seed enums drift from the registry, CH-FADAPT stops referencing the registry, docs indexes omit the registry, or portal-token bindings lose their corresponding `cfg.params.lane.portal.*` kill switches.
- Assurance + evidence wiring:
  - Added invariant **I-FADAPT-3** and proof obligation **PO-FADAPT-KINDREG**.
  - Registered evidence seed **EVID-2026-146**.

## Revised132 (2026-02-28)
- Tightened the **schemas/receipts are the product surface** pillar by pinning a stable, digest-only outcome receipt for ACP decisions (prevents accept-path drift into ad-hoc strings):
  - Added **CH-ACPOUT v0**: `docs/30-architecture/acp-outcome-receipt-schema-v0.md` (non-authoritative; binds `action_digest` + kind; carries D-COMMUTE observability metadata and optionally references CH-DENY/CH-RECEIPT/other receipts by digest).
  - Wired CH-ACPOUT into ACP control points (`acp-action-schema-v0.md`, `acp-validator-semantics.md`) and D-COMMUTE guidance.
- New CI guardrail (LLM-amnesia resistor):
  - Added `tools/check_acp_outcome_wiring.py` and wired it into `make lint`. It fails if CH-ACPOUT is not registered in the schema registry, is not discoverable from docs indexes, or is not referenced from ACP + assurance control points.
- Assurance + evidence wiring:
  - Added invariant **I-ACPOUT-1** and proof obligation **PO-ACT-ACPOUT**.
  - Registered evidence seed **EVID-2026-145**.

## Revised131 (2026-02-28)
- New CI guardrail (LLM-amnesia resistor) to keep Hybrid + D-COMMUTE metadata stable and reviewable:
  - Added `tools/check_acp_kindmeta.py` and wired it into `make lint`. It treats `docs/70-llm-control/acp-action-kind-registry.md` as machine-checkable source-of-truth and fails if:
    - a kind row is missing an explicit conflict-key family,
    - a row references a non-existent CH-CONFLICTKEY family,
    - an ordered commutativity stance does not require a CH-ORDERTOK witness (or a non-ordered kind claims one),
    - the Profiles column drifts outside the closed A–D set, or
    - profile-gated kinds reference `cfg.params.lane.*` kill switches that are not present in the CH-CFG toggle registry.
- Wiring:
  - Documented the new guardrail in `tools/README.md` and linked it from the ACP kind registry.
  - Registered evidence seed **EVID-2026-144** for the new drift gate.

## Revised130 (2026-02-28)
- Tightened the **no ambient authority (esp. workflows)** pillar by making portal mediation **explicitly policy-killable** for *every* portal family (no partial/implicit enablement drift):
  - Expanded the CH-CFG lane gate surface to include a complete closed set of `cfg.params.lane.portal.*` kill switches (`portal.file`, `portal.uri`, `portal.print`, `portal.device`, `portal.location`, `portal.secret`, `portal.xfer`, `portal.jobs`, `portal.inhibit`), alongside the existing `portal.net`, `portal.capture`, `portal.background`, `portal.a11y`.
  - Updated **CH-EFFCON v0** lane-gate semantics: for any `portal.<family>` effect kind in `effects[*].kind`, runners MUST require `cfg.params.lane.portal.<family>` to be enabled; missing/unknown toggle values are treated as `false` (fail closed) and produce transcript-visible denials (PO-LANE-KILL).
  - Clarified **CH-FCELL v0** validation notes: any `interop.portals_allowed` entry also requires the corresponding portal lane kill switch to be enabled (missing toggles treated as disabled; fail closed).
- Strengthened the portal coherence drift gate (LLM-amnesia resistor):
  - `tools/check_portal_wiring.py` now enforces that the set of `cfg.params.lane.portal.*` kill switches is **complete** for the canonical `portal.*` token set (in addition to the existing cross-doc token coherence checks).
- Assurance + evidence wiring:
  - Added invariant **I-PORTAL-KILL-1** and updated **PO-LANE-KILL** to cover “missing toggle ⇒ disabled” and to reference the portal drift gate evidence.
  - Updated **EVID-2026-141** description to reflect the new completeness check.


## Revised129 (2026-02-28)
- Tightened the “no ambient authority (esp. workflows)” pillar by closing a schema-name drift seam in D-CAPSHELL:
  - Pinned a **workflow-bound descriptor allowlist** in **CH-EFFCON v0**: an explicit mapping from effect kinds → allowed `desc_schema` values for CH-ARGV/CH-ENV bindings (closed-world, effect-bound).
  - Updated **CH-ARGV v0** and **CH-ENV v0** to require `desc_schema` be justified by the bound CH-EFFCON `effects[*].kind` list (mismatches fail closed; recommended CH-DENY `effcon-violation`).
  - Updated ACP control points (kind registry + validator semantics) to make the rule deterministic and transcript-visible for `capshell.exec`.
- New CI-friendly drift gate (LLM-amnesia resistor):
  - Added `tools/check_workflow_descallow.py` and wired it into `make lint`. It treats CH-EFFCON as the source of truth and fails if:
    - any `portal.*` effect kind lacks a row in the mapping table,
    - any mapped `CH-* vN` token is missing from the schema registry,
    - or CH-ARGV/CH-ENV stop referencing the CH-EFFCON allowlist.
- Assurance + evidence wiring:
  - Added invariant **I-WDESC-1** and updated the CH-ARGV/CH-ENV validate/bind proof obligations to require effect-bound descriptor schema checking.
  - Registered evidence seed **EVID-2026-143** for the workflow descriptor allowlist drift gate.


## Revised128 (2026-02-28)
- Entropy-reducing coherence fix for Hybrid + D-COMMUTE (eliminates conflict-key derivation ambiguity at ACP seams):
  - Pinned **normative derivation commitments** in **CH-CONFLICTKEY v0** for the ACP-visible families `policy.param` and `domain.id` (no ambient param aliasing; avoid double-hashing digest-sized domain ids).
  - Updated the ACP kind registry to reference `ck_domain(..)` for `domain.id` keys and to spell `policy.param` payloads as exact `cfg.params.*` keys.
  - Removed a lingering `request_id`-based idempotency hint in `cfg.set_policy` metadata and aligned it with the already-pinned dedupe guidance (`CH-EFFCON contract_id` / explicit dedupe key).
- New CI-friendly drift gate (LLM-amnesia resistor):
  - `tools/lint_archive.py` now fails if CH-CONFLICTKEY loses the derivation commitments section for `policy.param` / `domain.id`, or if ACP kind metadata stops referencing the pinned derivation helper/shape.
- Assurance + evidence wiring:
  - Added invariant **I-CONFLICTKEY-2** and proof obligation **PO-CONFLICTKEY-DERIVE**; registered evidence seed **EVID-2026-142**.

## Revised127 (2026-02-27)
- Entropy-reducing refactor for sealed-compat denial vocabulary (prevents drift and improves LLM-resilience):
  - Clarified **CH-FADAPT v0** `result.reason` reuses the same **closed deny_code set** as CH-DENY (`docs/30-architecture/deny-code-registry.md`), eliminating a parallel uppercase reason-token set.
  - Updated assurance control points (invariants/POs/evidence) to require fail-closed validation of CH-FADAPT denial reasons against the deny-code registry.
- New CI-friendly drift gate:
  - `tools/lint_archive.py` now fails if CH-FADAPT denial reason tokens are non-canonical (not kebab-case) or not present in the deny-code registry, or if CH-FADAPT stops referencing the registry.

## Revised126 (2026-02-27)
- New drift guardrail (CI-friendly) to keep the **workflow/compat portal taxonomy closed and coherent** (LLM-amnesia resistor; sealed-compat honesty):
  - Added `tools/check_portal_wiring.py`, a tiny lint gate that treats `docs/30-architecture/portal-family-registry.md` as the canonical `portal.*` token set and fails if it drifts from:
    - CH-PLEDGE token list (`docs/30-architecture/pledge-contract-schema-v0.md`),
    - pledge token→effect mapping (`docs/30-architecture/pledge-token-mapping.md`),
    - Foreign Cell portal allowlist seeds (`docs/30-architecture/foreign-cell-manifest-schema-v0.md`),
    - and any `cfg.params.lane.portal.*` lane-gate keys.
  - Updated `make lint` to run the new guardrail, and documented the tool in `tools/README.md`.
- Evidence wiring:
  - Registered **EVID-2026-141** for the portal taxonomy coherence drift gate (supports PO-PLEDGE-ENFORCE + sealed-compat POs).

## Revised125 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by preventing omission-based ambient context in D-CAPSHELL:
  - Added **CH-EXECPACK v0** (`docs/30-architecture/capshell-exec-pack-schema-v0.md`) as a bounded, **non-authoritative** capshell execution pack that bundles the complete workflow execution context digests (**CH-EFFCON v0**, **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, **CH-FDSET v0**).
  - Wired `capshell.exec` to require `exec_pack_digest = digest(CH-EXECPACK v0)` (no ambient PATH/env/cwd/stdio/handle inheritance by omission; still profile-gated via `cfg.params.lane.capshell`).
  - Updated ACP kind registry, ACP validator semantics, and CLI plumbing guidance to treat the exec-pack digest as the stable workflow binding surface (schemas + validators + receipts).
- Entropy-reducing coherence fix:
  - Clarified `capshell.exec` retry safety guidance to use the bound CH-EFFCON `contract_id` (or another explicit dedupe key) for replay/duplicate suppression, rather than an undefined “request_id”.
- Assurance + evidence wiring:
  - Added invariant **I-EXECPACK-1** and proof obligations **PO-EXECPACK-VALIDATE** and **PO-CAPSHELL-EXECPACK-REQUIRE**; registered evidence seed **EVID-2026-140**.
  - Added deny-code **`execpack-missing`** (registry-backed) for deterministic `capshell.exec` omissions.
- New drift guardrail (CI-friendly):
  - `tools/lint_archive.py` now fails if CH-EXECPACK exists but isn’t indexed (docs/README + schema registry) or if ACP surfaces regress and stop requiring `exec_pack_digest` / `execpack-missing`.

## Revised124 (2026-02-27)
- Entropy-reducing coherence fix for Hybrid + D-COMMUTE (prevents conflict-key naming drift):
  - Aligned ACP kind metadata conflict-key families with the canonical CH-CONFLICTKEY allowlist (e.g., `policy.param`, `domain.id`, `view.slot`, `budget.issuer`, `cell.id`).
  - Expanded **CH-CONFLICTKEY v0** to include the families actually referenced by the current ACP/compat seams (`policy.param`, `domain.id`, `cell.id`, `cell.adapter`) while preserving the closed-world, fail-closed validation rule.
- New drift guardrail (CI-friendly):
  - `tools/lint_archive.py` now fails if any conflict-key `family="..."` referenced by the ACP kind registry, hot-action boundaries, or sealed-compat adapter receipts is missing from CH-CONFLICTKEY’s family allowlist (LLM-amnesia resistor).
- Evidence wiring:
  - Registered **EVID-2026-139** for the conflict-key family coherence drift gate.

## Revised123 (2026-02-27)
- Entropy-reducing workflow coherence fix (no ambient authority drift):
  - Updated `docs/60-engineering/cli-plumbing-tooling.md` to align its capshell integration guidance with the full D-CAPSHELL binding set: **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, and **CH-FDSET v0**.
  - Made the prohibition explicit: no ambient PATH resolution, no env/cwd/stdio inheritance, and no inherited handle/FD tables; all authority acquisition remains portalized and receipt/transcript-visible.
- New drift guardrail (CI-friendly):
  - `tools/lint_archive.py` now fails if the CLI plumbing doc’s capshell integration section stops mentioning the binding schemas that exist in the repo, or if it regresses on the explicit “no ambient PATH + require CH-ARGV role=\"exec\"” rule.

## Revised122 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by eliminating inherited handle/FD-table seams in D-CAPSHELL:
  - Added **CH-FDSET v0** (`docs/30-architecture/fdset-schema-v0.md`) as a bounded, **non-authoritative** extra descriptor binding set (slots >= 3) so workflow runners never inherit an ambient parent handle/FD table.
  - Wired `capshell.exec` semantics to require `fdset_digest = digest(CH-FDSET v0)` alongside `effcon_digest`, `argv_digest`, `env_digest`, `cwd_digest`, and `stdio_digest`.
  - Updated CH-STDIO/CH-ARGV docs to point to CH-FDSET as the explicit seam for extra handles beyond stdio.
- Assurance + evidence wiring:
  - Added invariants **I-FDSET-1** (fdset is non-authoritative) and **I-FDSET-2** (no ambient handle inheritance; fail closed and transcript-visible).
  - Added proof obligations **PO-FDSET-VALIDATE** and **PO-CAPSHELL-FDSET-BIND**; registered evidence seed **EVID-2026-138**.
  - Added deny-code **`fd-bind-failed`** (registry-backed) for deterministic fdset binding failures and ambient-extra-handle detection.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-FDSET wiring remains visible in ACP semantics/kind registry and that `fd-bind-failed` stays registry-backed.
  - `tools/check_discovery.py` now enforces CH-FDSET remains indexed from `docs/README.md` when present.



## Revised121 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by eliminating ambient executable resolution in D-CAPSHELL:
  - Updated **CH-ARGV v0** (`docs/30-architecture/argv-schema-v0.md`) to pin an explicit executable-binding rule: `capshell.exec` selects the executable **only** via a `desc` token with `role="exec"` (no ambient PATH resolution from `lit` tokens).
  - Updated ACP validator semantics (`docs/70-llm-control/acp-validator-semantics.md`) and kind registry (`docs/70-llm-control/acp-action-kind-registry.md`) to require and surface the rule.
- Assurance + evidence wiring:
  - Added invariant **I-ARGV-3** (no ambient executable resolution) and updated **PO-CAPSHELL-ARGV-BIND** to include the exec-binding requirement.
  - Updated evidence seed **EVID-2026-134** to include missing/ambiguous `role="exec"` negative cases.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now fails if CH-ARGV / ACP semantics regress and stop pinning “no ambient PATH” + `role="exec"` executable selection.

## Revised120 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by eliminating inherited stdio/TTY seams in D-CAPSHELL:
  - Added **CH-STDIO v0** (`docs/30-architecture/stdio-schema-v0.md`) as a bounded, **non-authoritative** stdio binding descriptor for `stdin/stdout/stderr` (explicit `null/drop` or docref digest bindings).
  - Wired `capshell.exec` semantics to require `stdio_digest = digest(CH-STDIO v0)` alongside `effcon_digest`, `argv_digest`, `env_digest`, and `cwd_digest`, so workflow runners never inherit ambient host stdio/TTY state.
- Entropy-reducing refactor:
  - Removed `stdin/stdout/stderr` roles from **CH-ARGV v0**; stdio binding is now exclusively modeled via **CH-STDIO v0** (prevents parallel, drifting stdio semantics).
- Assurance + evidence wiring:
  - Added invariants **I-STDIO-1** (stdio bindings are non-authoritative) and **I-STDIO-2** (no ambient stdio/TTY inheritance; unbindable bindings fail closed).
  - Added proof obligations **PO-STDIO-VALIDATE** and **PO-CAPSHELL-STDIO-BIND**; registered evidence seed **EVID-2026-137**.
  - Added deny-code **`stdio-bind-failed`** (registry-backed) for deterministic stdio binding failures.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-STDIO wiring remains visible in ACP semantics/kind registry and that `stdio-bind-failed` stays registry-backed.
  - `tools/check_discovery.py` now enforces CH-STDIO remains indexed from `docs/README.md` when present.

## Revised119 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by making child current working directory selection explicit and bindable in D-CAPSHELL:
  - Added **CH-CWD v0** (`docs/30-architecture/cwd-schema-v0.md`) as a bounded, **non-authoritative** working-directory selector (`empty` sandbox cwd or directory descriptor reference).
  - Wired `capshell.exec` semantics to require `cwd_digest = digest(CH-CWD v0)` alongside `effcon_digest`, `argv_digest`, and `env_digest`, so workflow runners never inherit ambient host cwd.
- Assurance + evidence wiring:
  - Added invariants **I-CWD-1** (cwd selector is non-authoritative) and **I-CWD-2** (no ambient cwd inheritance; empty cwd must not permit ambient traversal).
  - Added proof obligations **PO-CWD-VALIDATE** and **PO-CAPSHELL-CWD-BIND**; registered evidence seed **EVID-2026-136**.
  - Added deny-code **`cwd-bind-failed`** (registry-backed) for deterministic cwd binding failures.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-CWD wiring remains visible in ACP semantics/kind registry and that `cwd-bind-failed` stays registry-backed.
  - `tools/check_discovery.py` now enforces CH-CWD remains indexed from `docs/README.md` when present.

## Revised118 (2026-02-27)
- Tightened the “no ambient authority (esp. workflows)” pillar by making process environments explicit and bindable in D-CAPSHELL (no forks):
  - Added **CH-ENV v0** (`docs/30-architecture/env-schema-v0.md`) as a bounded, **non-authoritative** typed environment token list.
  - Wired `capshell.exec` semantics to require `env_digest = digest(CH-ENV v0)` alongside `effcon_digest` and `argv_digest`, so workflow runners can avoid inheriting ambient host environments and keep env binding receipt-shaped.
- Assurance + evidence wiring:
  - Added invariants **I-ENV-1** (env is non-authoritative) and **I-ENV-2** (no ambient acquisition via env binding).
  - Added proof obligations **PO-ENV-VALIDATE** and **PO-CAPSHELL-ENV-BIND**; registered evidence seed **EVID-2026-135**.
  - Added deny-code **`env-bind-failed`** (registry-backed) for deterministic env binding failures.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-ENV wiring stays visible in ACP semantics/kind registry and that `env-bind-failed` remains registry-backed.
  - `tools/check_discovery.py` now enforces CH-ENV remains indexed from `docs/README.md` when present.


## Revised117 (2026-02-27)
- Integrated a new workflow seam to reduce ambient authority in automation inputs (D-CAPSHELL) without forks:
  - Added **CH-ARGV v0** (`docs/30-architecture/argv-schema-v0.md`) as a bounded, **non-authoritative** typed argv token list that binds to already-held descriptor digests (no raw caps; no path/env as “permission grants”).
  - Wired `capshell.exec` to require `argv_digest = digest(CH-ARGV v0)` alongside `effcon_digest` so workflow execution remains schema/receipt-shaped and fail-closed.
- Assurance + evidence wiring:
  - Added invariants **I-ARGV-1** (argv is non-authoritative) and **I-ARGV-2** (no ambient acquisition via argv binding).
  - Added proof obligations **PO-ARGV-VALIDATE** and **PO-CAPSHELL-ARGV-BIND**; registered evidence seed **EVID-2026-134**.
  - Added deny-code **`argv-bind-failed`** (closed-world via deny-code registry) for deterministic binding failures.
- New drift guardrails (CI-friendly):
  - `tools/lint_archive.py` now enforces CH-ARGV wiring stays visible in ACP semantics/kind registry and that `argv-bind-failed` remains registry-backed.
  - `tools/check_discovery.py` now enforces CH-ARGV remains indexed from `docs/README.md` when present.

## Revised116 (2026-02-27)
- Refactor + coherence fix (pillar: multicore verification required; no single-core shipping):
  - Removed “multicore later / Phase 3” drift from core policy docs by aligning **mechanisms**, **unsafe-concurrency policy**, and **unsafe obligation notes** with D-CONC staged options (UP-only bring-up allowed; SMP big-lock baseline is the early verified posture).
  - Updated D-MEMMODEL to be an **SMP/Hybrid baseline** decision (no conditional “if SMP” phrasing), and tightened related phrasing in the abstract machine and threat-model abuse case AC-004.
- Assurance + evidence wiring:
  - Added **I-CONC-0** (multicore required for flagship; UP-only is non-claim) and **PO-CONC-MULTICORE** (C-CONC-1 evidence requires >=2-core execution); registered evidence seed **EVID-2026-133**.
- New drift guardrail (CI-friendly):
  - `tools/lint_archive.py` now includes a **multicore posture** lint that fails if canonical policy docs regress to “single-core default” or “multicore later” language, or if D-MEMMODEL becomes conditional again.
## Revised115 (2026-02-27)
- Reduced drift in fail-closed workflow/policy denials by centralizing denial semantics:
  - Added `docs/30-architecture/deny-code-registry.md` as the source of truth for the closed CH-DENY `deny_code` set (with recommended `reason.kind` bindings and required keys/digests).
  - Updated **CH-DENY v0** (`docs/30-architecture/denial-receipt-schema-v0.md`) to treat the registry as normative (validators reject unknown codes).
  - Updated ACP validator semantics to include an explicit “Deny codes used by ACP validators” list (subset of the registry) and to avoid nested inline-code drift.
- Wiring + assurance:
  - Added **I-DENY-3** (deny semantics centralized) and **PO-DENY-CODES**; registered evidence seed **EVID-2026-132**.
  - Updated D-EXPLAIN decision node to call out the deny-code registry as the closed-world source.
- New drift guardrails (CI-friendly):
  - `make lint` now validates deny-code registry completeness and that ACP semantics lists only registry-backed deny codes.
  - `tools/check_discovery.py` now enforces `deny-code-registry.md` remains indexed (and referenced from CH-DENY) when present.

## Revised114 (2026-02-27)
- Tightened D-RR replay/audit packaging so **fail-closed denials remain mechanically auditable** (and don't drift into ad-hoc strings in incident handoff):
  - Updated **CH-RRBUNDLE v0** (`docs/30-architecture/replay-bundle-schema-v0.md`) to add an optional `deny_stream` payload kind carrying CH-DENY records referenced by bundled CH-LOG entries via `deny_digest`.
  - Updated D-RR notes in the decision map to call out denial-receipt closure as an audit stability requirement (no silent gaps).
- Assurance + evidence wiring:
  - Added **I-RR-4** (bundle closure for denials) and **PO-RR-BUNDLE-CLOSURE**; registered evidence seed **EVID-2026-131**.
- New drift guardrail (CI-friendly): `make lint` now fails if CH-DENY exists but the replay-bundle schema doesn't mention the `deny_stream` closure seam.

## Revised113 (2026-02-27)
- Integrated a **structured denial receipt** seam so fail-closed rejections are mechanically auditable (and don’t drift into ad-hoc strings):
  - Added **CH-DENY v0** (`docs/30-architecture/denial-receipt-schema-v0.md`) as a bounded, **non-authoritative** validator-denial record with a closed `deny_code` enum.
  - Updated **CH-LOG v0** (`docs/30-architecture/transcript-contract.md`) to optionally bind `deny_digest = digest(CH-DENY v0)` for rejected actions.
  - Updated ACP validator semantics to emit CH-DENY for `Reject(..)` outcomes (especially lane/policy/effect-contract/ordering denials) and bind it from CH-LOG when present.
- Assurance + evidence wiring:
  - Updated **I-LOG-1** to cover rejected actions and CH-DENY binding.
  - Added invariants **I-DENY-1** (deny receipts are deterministic + non-authoritative) and **I-DENY-2** (lane/policy kills are receipt-visible).
  - Added proof obligation **PO-DENY-EMIT** and registered evidence seed **EVID-2026-130**.
- Sealed compat wiring tightened (no new ambient channels): Foreign Cell contract now explicitly calls for CH-DENY on lane-disabled and adapter-level rejects, keeping “killable by policy” auditable.
- New drift guardrails (CI-friendly):
  - `make lint` now requires CH-LOG to mention `deny_digest` when CH-DENY exists and sanity-checks the CH-DENY deny-code enum seed.
  - `tools/check_discovery.py` now enforces CH-DENY is indexed from `docs/README.md` when present.

## Revised112 (2026-02-27)
- Strengthened sealed POSIX/legacy compatibility so “interop only via portals/intents/receipts” is mechanically auditable (no ambient channels):
  - Added **CH-FADAPT v0** (`docs/30-architecture/fcell-adapter-receipt-schema-v0.md`) as a bounded, **non-authoritative** per-adapter receipt record that binds `portal_token` + issued descriptor digests (no bearer caps; no paths/env/implicit network).
  - Updated the Foreign Cell membrane contract and CH-FCELL manifest obligations to require per-op CH-FADAPT receipts for any adapter-mediated host effect (ALLOW/DENY), keeping the lane policy-killable and receipt-visible.
- Assurance + evidence wiring:
  - Added invariants **I-FADAPT-1** (non-authoritative + closed tokens) and **I-FADAPT-2** (interop is receipted; lane-kill yields deterministic DENY-only).
  - Added proof obligations **PO-FADAPT-VALIDATE** and **PO-FADAPT-EMIT**; registered evidence seed **EVID-2026-129**.
- New drift guardrail (CI-friendly): `tools/check_discovery.py` now enforces that CH-FADAPT stays indexed from `docs/README.md` and referenced from the Foreign Cell contract when present.

## Revised111 (2026-02-27)
- Entropy-reducing refactor: unified Foreign Cell (sealed compat) portal allowlists with the same **closed** `portal.*` token vocabulary used across portals and workflows:
  - Updated CH-FCELL v0 (`docs/30-architecture/foreign-cell-manifest-schema-v0.md`) so `interop.portals_allowed` is expressed in CH-PLEDGE `portal.*` tokens (mirrors `portal-family-registry.md`) rather than a parallel `portal_kind` taxonomy.
  - Rationale: sealed compat must not grow a drifting portal taxonomy; interop lanes stay reviewable and killable without introducing ambient channels.
- Assurance wiring tightened:
  - Updated **I-FCELL-1** to require portal lanes be validated against the closed CH-PLEDGE `portal.*` set.
  - Updated **PO-FCELL-VALIDATE** to include portal-token closure validation.
- New drift guardrail (CI-friendly):
  - `make lint` now rejects the deprecated CH-FCELL `portal_kind` taxonomy and checks any `portal.*` tokens referenced by CH-FCELL are valid CH-PLEDGE portal tokens.
  - Registered evidence seed **EVID-2026-128** for this sealed-compat drift gate.

## Revised110 (2026-02-27)
- Integrated a drift-resistant **config toggle closure** seam to keep kill switches and profile extensions explicit and reviewable:
  - Added `docs/30-architecture/config-toggle-registry.md` as the canonical registry for the closed set of CH-CFG `feature_flags` values and `cfg.params.lane.*` kill switches.
  - Tightened CH-CFG docs to require enforcement of toggle closure (unknown toggle names reject) and wired the same closure into profile and automation surfaces.
- Strengthened “policy-killable lanes” across workflow glue and sealed compat:
  - `capshell.exec`, `budget.mint`, and `fcell.*` kinds now explicitly reference the required lane gates (`cfg.params.lane.capshell`, `cfg.params.lane.metering`, `cfg.params.lane.fcell`).
  - CH-EFFCON now pins lane gates for profile-gated portal effects (`cfg.params.lane.portal.{net,capture,background,a11y}`), preserving no-ambient-authority workflows and fail-closed semantics.
- Assurance + evidence wiring:
  - New invariants **I-CFGTOGGLE-1** (toggle closure) and **I-LANEGATE-1** (lane gates are fail-closed + receipt-visible).
  - New proof obligations **PO-CFGTOGGLE-VERIFY** and **PO-LANE-KILL**; added evidence seed **EVID-2026-127**.
- New drift guardrails (CI-friendly):
  - `make lint` now checks that any `ext.*` feature flags and `cfg.params.*` lane-gate references in key docs are present in the toggle registry.
  - `tools/check_discovery.py` now enforces the toggle registry is indexed from `docs/README.md` when present.
- Wiring: updated `docs/README.md`, D-CAPSHELL and D-FCELL notes, and deployment profile documentation to use the registry as the canonical closure surface.

## Revised109 (2026-02-27)
- Integrated a high-leverage workflow seam to reduce ambient authority in “glue” automation (shell/CI/runbooks) without forks:
  - Added **CH-EFFCON v0** (`docs/30-architecture/effect-contract-schema-v0.md`) as a *veto-only* **effect contract** descriptor bound to a CH-WALLET core digest (no bearer secrets; no ambient paths/env as “permissions”).
  - Added optional runner surface **IF-CAPSHELL** and a corresponding CH-ACP action kind **`capshell.exec`** (ordered within a `domain_id`, commutative across disjoint domains) so **LLMs propose; deterministic validators execute**, and receipts/transcripts remain the stable product surface.
- Assurance + evidence wiring:
  - New invariants **I-EFFCON-1** (non-authoritative) and **I-EFFCON-2** (no bypass at effect boundaries).
  - New proof obligations **PO-EFFCON-VALIDATE** and **PO-CAPSHELL-ENF**; new evidence seed **EVID-2026-126** (contract enforcement + swap-order tests for disjoint domains).
- New drift guardrail: `tools/check_discovery.py` now enforces that CH-EFFCON stays indexed from `docs/README.md` when present (keeps workflow authority seams visible and reviewable).
- Wiring: registered CH-EFFCON in the schema registry, added IF-CAPSHELL to the interface registry, updated D-CAPSHELL notes, and updated ACP docs to reference effect-contract binding.

## Revised108 (2026-02-27)
- Integrated Hybrid + commutativity observability into the stable product surface (schemas + validators + receipts):
  - Extended **CH-LOG v0** (transcript contract) to optionally carry `conflict_key_digest = digest(CH-CONFLICTKEY v0)` and (for ordered actions) `order_digest = digest(CH-ORDERTOK v0)` as **non-authoritative** metadata.
  - Extended **CH-RECEIPT v0** (consent receipt) to optionally carry the same digests, with normative producer rules for CH-ACP actions (ordered kinds must emit `order_digest`; derived `conflict_key_digest` preferred).
  - Rationale: keeps D-COMMUTE honest by making conflict keys + ordering witnesses receipt-visible without relying on implicit log ordering or ambient state.
- Assurance wiring tightened:
  - Updated **I-LOG-1** and **I-EXPLAIN-2** to reflect conflict/order digest recording as non-authoritative observability when D-COMMUTE is in scope.
  - Added evidence seed **EVID-2026-125** for CH-LOG/CH-RECEIPT action-metadata field emission + redaction-safe export tests.
- New drift guardrail: `make lint` now fails if the CH-LOG and CH-RECEIPT schema docs omit the `conflict_key_digest` / `order_digest` field mentions (prevents silent regression of commutativity evidence surfaces).
- Wiring: updated schema-registry notes for CH-LOG/CH-RECEIPT and clarified ACP validator semantics to reference the log/receipt fields.

## Revised107 (2026-02-27)
- Integrated LLM-first + Hybrid/commutativity surface: added `docs/70-llm-control/acp-action-kind-registry.md` as the **closed-world** registry for CH-ACP kinds, pinning per-kind conflict key derivation, commutativity/ordering stance, retry safety, and profile gates (keeps A–D viable without forks).
  - Added two profiled, policy-killable Foreign Cell control kinds (`fcell.launch` / `fcell.kill`) so sealed compatibility is explicitly surfaced as schemas + validators + receipts rather than ad-hoc tooling.
- Assurance wiring for commutativity discipline at the validator boundary:
  - New invariant **I-ACTMETA-1** (action kind metadata is closed and enforced).
  - New proof obligation **PO-ACT-KINDMETA** (validator computes/records conflict keys; ordered kinds require CH-ORDERTOK + matching CH-CONFLICTKEY digests).
  - New evidence seed **EVID-2026-124** for a kind-metadata gate + negative tests.
- New drift guardrails (CI-friendly):
  - `make lint` now fails if the ACP kind registry is missing/malformed or if an **ordered** kind claims `none` for its ordering witness.
  - `tools/check_discovery.py` now enforces that the ACP kind registry is indexed from both `docs/README.md` and `docs/70-llm-control/README.md`.
- Research/refs: added **REF-KNOSSOS-JEPSEN** (linearizability checker) as a candidate tool for validating ordered serialization boundaries.
- Refactor: fixed numbering/order in `docs/00-meta/trajectory-map.md` non-negotiables list (keeps drift-control docs crisp).

## Revised106 (2026-02-27)
- LLM continuity: extended `tools/gen_context_pack.py` to include a compact **non-negotiables** reminder + **profile matrix** (shared substrate + the four product shapes), derived from `docs/00-meta/llm-runbook.md` and `docs/00-meta/trajectory-map.md`.
  - Goal: keep “no forks; profiles/compositions only” salient in continuation prompts and reduce drift-by-omission.
- New discovery guardrail: `tools/check_discovery.py` now fails if the trajectory map loses any of the four required profile headings (workstation, cloud substrate, embedded/separation, agent/automation).

## Revised105 (2026-02-27)
- Made conflict keys a first-class, schema’d artifact for Hybrid + commutativity:
  - Added CH-CONFLICTKEY v0 (`docs/30-architecture/conflict-key-schema-v0.md`) and registered it in the schema registry.
  - Tightened CH-ORDERTOK scope binding: `scope.key_digest = digest(CH-CONFLICTKEY v0)` (explicit scope-to-conflict-key linkage).
- Hardened ordered-action and commutativity wiring:
  - Updated CH-ACP v0 to require `meta.conflict_key_digest = digest(CH-CONFLICTKEY v0)` for ordered actions (alongside `meta.order_digest`).
  - Updated CH-KABI v0 metadata guidance to optionally carry `meta.conflict_key_digest` for observability and commutativity evidence.
  - Updated RFC-0119 to reflect conflict-key binding and ordered-action requirements.
- New drift guardrail: `make lint` now enforces that each pinned hot family in `hot-action-boundaries-v0.md` includes explicit `Conflict key:` and `Ordering token:` statements (in addition to non-commutative boundary + replication contract).
- Assurance wiring: added I-CONFLICTKEY-1, PO-CONFLICTKEY-VALIDATE, and evidence seed EVID-2026-123.

## Revised104 (2026-02-27)
- Made required ordering a first-class, schema’d artifact (Hybrid + commutativity hardening):
  - Added CH-ORDERTOK v0 (`docs/30-architecture/ordering-token-schema-v0.md`) as a non-authoritative ordering witness descriptor for non-commutative actions.
  - Added RFC-0119 (`rfcs/0119-ordering-streams-and-tokens.md`) to pin how ordered actions carry `order_digest` and how receipts make order visible.
- Tightened the pinned hot action boundary doc to always state `Ordering token:` (CH-ORDERTOK v0 or `none`) per hot family (prevents hidden global serialization).
- Assurance wiring: added invariants I-ORDERTOK-1..2 and proof obligation PO-ORDERTOK-VALIDATE; added EVID-2026-122 stub.
- New drift guardrail: `make lint` now fails if any pinned hot family section is missing an explicit `Ordering token:` statement.

## Revised103 (2026-02-27)
- New drift guardrail: `make lint` now checks that inline backticked repo paths (e.g., `docs/...`, `tools/...`) actually exist (prevents stale references from silently accumulating).
- Refactor: fixed RFC→ADR promotion rubric to link to the canonical [TCB inventory](docs/20-assurance/tcb.md) and [release profiles](docs/60-engineering/release-profiles.md) documents.
- Changelog hygiene: removed a backticked reference to a previously-deleted `__pycache__` directory so future path checks don’t false-alarm.

## Revised102 (2026-02-27)
- Pinned “sealed compatibility” as a first-class architecture seam (so POSIX/legacy support cannot reintroduce ambient authority):
  - Added `docs/30-architecture/foreign-cell-contract.md` defining the Foreign Cell membrane (portalized, fail-closed, policy-killable).
  - Added CH-FCELL v0 (`docs/30-architecture/foreign-cell-manifest-schema-v0.md`) as a bounded, non-authoritative manifest used for validation/receipts/drift-gates.
  - Added D-FCELL to the decision map (membrane contract) and clarified D-RUMPK as the runtime selection *inside* the cell.
- Assurance wiring: added invariant I-FCELL-1 and proof obligation PO-FCELL-VALIDATE.
- Wiring: added the Foreign Cell contract doc to the runbook must-read set and the docs index; registered CH-FCELL in the schema registry.

## Revised101 (2026-02-27)
- Tightened the Hybrid + commutativity integration by making cross-cluster replication assumptions explicit on the pinned hot action surface:
  - Updated `docs/30-architecture/hot-action-surface-v0.md` to record a default RC* replication class per hot family.
  - Updated `docs/30-architecture/hot-action-boundaries-v0.md` to require and document `Replication contract:` statements alongside non-commutative boundaries.
- New drift guardrail: `make lint` now fails if any pinned hot family is missing an explicit replication contract statement (prevents accidental “global state” drift in Hybrid).

## Revised100 (2026-02-27)
- Pinned cross-cluster replication/consistency contracts as an explicit Hybrid artifact seam:
  - Added `docs/30-architecture/replication-contracts-v0.md` (RC0..RC4 vocabulary) and CH-REPLCONTRACT v0 (`docs/30-architecture/replication-contract-schema-v0.md`).
  - Added ADR-0006 and D-REPL in the decision map; registered CH-REPLCONTRACT in the schema registry.
- Tightened assurance wiring for Hybrid cross-cluster metadata:
  - New invariant I-REPL-1 (replication is non-authoritative; no authority amplification from replicated metadata).
  - New proof obligations: PO-REPLCONTRACT-VALIDATE, PO-REPL-NOAMP, PO-REPL-MERGE, PO-REPL-ORDERED; added EVID-2026-121 stub.
- Threat model: added AC-092 (cross-cluster metadata divergence/split-brain) and linked mitigations to D-REPL + RC4 ordered-log semantics where needed.
- Wiring: updated multicore/commutativity docs, cluster-derivation follow-ups, docs index, and bibliography (added REF-CRDT-INRIA11).

## Revised99 (2026-02-27)
- Pinned Hybrid cluster derivation as a deterministic, auditable artifact surface:
  - Added `docs/30-architecture/cluster-derivation.md` and CH-CLUSTERMAP v0 (`docs/30-architecture/cluster-map-schema-v0.md`) for stable cluster partitions derived from CH-HWFACT (+ optional policy digest).
  - Updated ADR-0005 and multicore docs to treat cluster derivation as “done v0” and to focus remaining Hybrid follow-ups on cross-cluster replication/consistency contracts.
- Tightened the CH-HWFACT v0 `cpu_topology` payload with explicit bounded fields and canonicalization rules (supports D-MK/D-SKB).
- New drift guardrail: `make lint` now fails if any `*-schema-vN.md` doc is not registered in `docs/30-architecture/schema-registry.md`.

## Revised98 (2026-02-27)
- Added a conservative discovery-surface guardrail:
  - New tool `tools/check_discovery.py` ensures ADR/RFC indexes are complete and that the runbook must-read set stays discoverable from `docs/README.md`.
  - `make lint` now runs both the core archive lints and the discovery-surface checks (fails fast on drift).
- Updated runbook and docs wiring to reflect the new lint composition.

## Revised97 (2026-02-27)
- Committed the multicore direction as an explicit, permanent decision:
  - Added ADR-0005 adopting **Hybrid** multicore as the default direction and making **D-COMMUTE** a required spec/test discipline.
  - Updated D-MK and D-COMMUTE entries to reflect adopted status (and to keep SMP variants explicitly scoped to in-cluster profiles).
- Entropy-reducing refactor: removed duplicated commutativity sections and clarified the "current direction" in `docs/30-architecture/multicore-architecture-options.md`.
- Updated drift-resistant wiring: trajectory-map open questions now track Hybrid follow-ups (cluster derivation + replication contracts) instead of re-litigating the baseline.

## Revised96 (2026-02-27)
- Added LLM continuity guardrails to reduce archive amnesia:
  - Added `docs/00-meta/llm-runbook.md` (must-read set, non-negotiables, per-run outputs).
  - Added `tools/gen_context_pack.py` and `make context-pack` to generate `out/context_pack.md` for copy/paste-friendly continuation prompts.
- Updated discovery/wiring: `README.md`, `docs/README.md`, and `docs/00-meta/archive-policy.md`; added `out/` to `.gitignore`.

## Revised95 (2026-02-27)
- Refined the hot action surface into explicit **non-commutative sub-action boundaries** (so Hybrid + D-COMMUTE stays enforceable, not vibes):
  - Added `docs/30-architecture/hot-action-boundaries-v0.md` naming the minimal correctness-required serialization boundary (or explicit `none`) for each v0 hot family.
  - Updated `docs/30-architecture/hot-action-surface-v0.md` and D-COMMUTE doc wiring to require a boundary statement per hot family.
- Threaded boundary intent into the action IR docs:
  - Updated `docs/30-architecture/kabi-action-schema-v0.md` to make the IPC endpoint family explicit and to mark budget issuance as a profile-gated, ordered family.
  - Updated `docs/70-llm-control/acp-action-schema-v0.md` to include view attach/detach and budget mint as first-class proposed actions, and to require explicit ordering tokens for ordered actions.
- New drift guardrail:
  - Extended `tools/lint_archive.py` so `make lint` fails if the hot boundaries doc is missing or if a pinned hot family lacks an explicit boundary statement.

## Revised94 (2026-02-27)
- Made commutativity discipline concrete by pinning a **hot privileged action surface** and explicitly marking serialization points:
  - Added `docs/30-architecture/hot-action-surface-v0.md` (v0 seed set: mem.map/unmap, IPC endpoint ops, view attach/detach, transcript append, quota charge) with conflict keys, commutativity stance, and explicit serialization owners.
  - Added proof obligations for the hot surface and its declared serialization points: PO-HOT-MEMRANGE, PO-HOT-IPCORDER, PO-HOT-VIEWSLOT, PO-HOT-LOGCOMMUTE, PO-HOT-QUOTATOK.
  - Added evidence seed `EVID-2026-120` for a microbench + regression harness that measures/guards the declared serialization points.
- Tightened transcript semantics to avoid accidental global bottlenecks:
  - Clarified in `docs/30-architecture/transcript-contract.md` that transcript ingestion is a content-addressed event set; export order is derived canonically (append commutes).
- Wiring updates:
  - Updated D-COMMUTE references and MVP proof-slice wiring to point to the pinned hot surface v0 and the new evidence seed.

## Revised93 (2026-02-27)
- Added interface-first scalability as an explicit, testable discipline that composes with Hybrid multicore:
  - Added `docs/30-architecture/commutativity-and-interface-scalability.md` (D-COMMUTE) framing commutativity as a spec property and evidence target (REF-SCR-TOCS15).
  - Extended `docs/30-architecture/multicore-architecture-options.md` with an orthogonal commutativity lever section.
  - Updated `docs/30-architecture/decision-map.md` with D-COMMUTE and concrete PO hooks (PO-COMMUTE-SPEC, PO-COMMUTE-TEST).
  - Added `REF-SCR-TOCS15` to `docs/00-meta/bibliography.md` and wired evidence seed `EVID-2026-119`.

## Revised92 (2026-02-27)
- Wrote down a mile-high synthesis to prevent design drift:
  - Added `docs/00-meta/trajectory-map.md` capturing the four intended profile stacks (workstation, cloud substrate, embedded/separation, agent/automation) and the current non-negotiables (sealed compat; multicore verification; LLM-first workflows).
- Clarified the multicore option space and wired it into the decision surfaces:
  - Added `docs/30-architecture/multicore-architecture-options.md` (SMP big-lock vs sharded SMP vs multikernel vs hybrids; plus commutativity as an interface tool).
  - Updated the decision map’s D-CONC and D-MK entries to reflect the expanded option set and link to the new doc.
- Updated the verification plan to treat multicore as part of the MVP slice:
  - Refactored `docs/40-verification/minimum-viable-proof-slice.md` so the baseline includes an SMP profile (big-lock as a practical early anchor) rather than UP-only as the intended end state.
- Inspirations + refs:
  - Added compressed lessons and bibliography entries for Corey/Tornado/K42 and the scalable commutativity rule to ground multicore design choices in concrete precedents.

## Revised91 (2026-02-27)
- Added an “in-process confused deputy” guardrail seam (cheap now, painful later):
  - Added **RFC-0118** introducing **D-BRACKET**: privilege bracketing in user-space runtimes (borrowed-mode default; explicit scoped privileged blocks; veto-only).
  - Added **CH-CALLCHAIN v0** schema (bounded call-chain descriptor for audit + deny-only routing).
  - Added **CH-REQCTX v1** schema (optional call-chain digest hook) and updated D-REQCTX to recognize v0/v1.
  - Registered CH-CALLCHAIN and CH-REQCTX v1 in the schema registry and added **D-BRACKET** to the decision map.
- Threat model + assurance wiring:
  - Added abuse case **AC-091** (in-process confused deputy).
  - Added invariants **I-BRACKET-1..3** and **I-CALLCHAIN-1**; refined **I-REQCTX-3** to clarify contexts are non-authoritative for granting but may be used for veto-only narrowing/deny decisions; added **I-REQCTX-4**.
  - Added proof obligations **PO-CALLCHAIN-VALIDATE** and **PO-BRACKET-SCOPE**, and evidence seed **EVID-2026-118**.
- Meta-engineering + research threading:
  - Extended the sealing/learning playbook with an explicit D-BRACKET section.
  - Added a new bake-in item to RFC-0003 for veto-only privilege bracketing in plugin/helper ecosystems.
  - Added an OS lesson tying Confused Deputy + Java stack inspection to our D-BRACKET seam and expanded bibliography with the primary references.

## Revised90 (2026-02-27)
- Strengthened the workflow plumbing seam so CLI and GUI share a pinned, auditable substrate:
  - Added **RFC-0117** introducing **CH-PLUMBMSG v0**: a canonical, **non-authoritative** plumb message envelope for workflow intents (no raw capabilities).
  - Added **CH-PLUMBMSG v0** schema doc and registered it in the schema registry.
  - Refactored **RFC-0046** to explicitly use CH-PLUMBMSG and to document “plumb-first” CLI integration (no ambient paths; wallet-aware).
- Meta-engineering + safety rails:
  - Added **I-PLUMB-3** (plumb envelopes carry no raw capabilities; authority transfer is portalized and transcript-visible).
  - Added **PO-PLUMBMSG-VALIDATE** (total, bounded, closed-enum decoding for CH-PLUMBMSG).
  - Added **AC-090** (plumb injection/confused deputy) to keep the threat model honest.
- Added an engineering guide: `docs/60-engineering/cli-plumbing-tooling.md` (how to build safe `open/share/print` CLI verbs without reintroducing ambient authority).


## Revised89 (2026-02-27)
- Meta-engineering: made wallets usable as **stable drift-gate identifiers**:
  - Added decision node **D-WALLET** to track the wallet seam explicitly.
  - Tightened **CH-WALLET v0** with a normative `wallet_core_digest` normalization algorithm (drop volatile fields; deterministic sorting) so prompts/receipts/CI can key off a stable authority digest.
  - Added invariant **I-WALLET-3** and updated **PO-WALLET-VALIDATE** to cover the normalization requirement when used for gating.
  - Updated **RFC-0115** and **RFC-0116** to prefer `wallet_core_digest` over `digest(CH-WALLET)` for prompts and drift gates.
- Research/lessons: strengthened the **GNU Hurd translators** lesson and tied it to view-mutation semantics; added **REF-HURD-SETTRANS** and threaded it into RFC-0032 (views/namespaces) as an explicit precedent for attach/remove operations.
- Added an engineering playbook: `docs/60-engineering/authority-drift-gates.md` (how to turn authority widening into a deterministic CI failure).



## Revised88 (2026-02-27)
- Tightened the ecosystem adoption seam for least-privilege automation:
  - Added **RFC-0116** and **CH-WALLET v0**: a **non-authoritative capability wallet descriptor** for prompts, receipts, runbooks, and CI drift gates (no bearer secrets).
  - Wired discipline: new invariants **I-WALLET-1/I-WALLET-2**, new proof obligation **PO-WALLET-VALIDATE**, and schema registry entry for CH-WALLET.
  - Updated **RFC-0115** (D-CAPSHELL) to reference CH-WALLET and to position wallets as metadata + drift-gated contracts.
- Portal meta-engineering:
  - Refactored the **portal design playbook** to treat portals as **usage-control boundaries** (UCON lens) and to reference **CH-CAPDIFF + CH-RECEIPT** explicitly (fixing a placeholder CH-*).
  - Reinforced **view objects** as a name-binding protection boundary (Bisbey/Hollingworth lesson).
- Inspirations/research:
  - Added a compressed lesson on **sandboxing adoption reality** (mechanisms exist but adoption is low) and tied it to wrapper-first + learn-mode workflows.
- Bibliography additions: **REF-SANDBOX-ADOPTION-ARXIV24**, **REF-LEASH-CAPSICUM-2025**, **REF-UCON-ABC/REF-UCON-ABC-ACM**, **REF-BISBEY78**.

## Revised87 (2026-02-27)
- Added an ecosystem seam for keeping “glue code” capability-pure:
  - Added **RFC-0115** introducing **D-CAPSHELL**: capability-safe shell + automation components (wrapper-first + learn mode + explicit contracts).
  - Added **portal design playbook** (`docs/60-engineering/portal-design-playbook.md`) as an engineering checklist for portals as non-amplifying mediators.
  - Decision map updated to include D-CAPSHELL as an explicit node.



## Revised86 (2026-02-27)
- Added an ecosystem integrity seam for immutable artifacts:
  - Added **RFC-0114** introducing **D-VERITY**: optional **VerifiedBlob** handles backed by Merkle-tree verified reads (fs-verity/dm-verity lineage), with fail-closed behavior on integrity failure.
  - Added **CH-VBLOB v0** (verified blob descriptor) and registered it in the schema registry.
  - Updated decision map + core mechanisms narrative to include D-VERITY and to position verification as primarily user-space storage/pager policy (keep privileged core small).
  - Discipline wiring: new invariants **I-VERITY-1..3**, new proof obligations **PO-VBLOB-VALIDATE/PO-VERITY-ENF/PO-VERITY-BOUND**, and evidence seed **EVID-2026-117**.
  - Extended **RFC-0003** with a new bake-in item for D-VERITY and added a compressed inspiration lesson.
- Bibliography additions: **REF-LINUX-FSVERITY**, **REF-LINUX-DMVERITY**, **REF-ANDROID-DMVERITY**, **REF-ANDROID-AVB2-README**.



## Revised85 (2026-02-27)
- Added a “CPU-local fast paths without atomics everywhere” ecosystem seam:
  - Added **RFC-0113** introducing **D-RSEQ**: optional **restartable sequences** (Linux rseq lineage) so high-throughput runtimes can implement bounded per-CPU allocators/counters/queues with crisp abort-on-migrate semantics and a single commit point.
  - Updated decision map + core mechanisms narrative to position D-RSEQ as profile-gated (D-NONDET posture) and to clarify the determinism story for D-RR profiles (disable/virtualize/record).
  - Discipline wiring: new invariants **I-RSEQ-1..3**, new proof obligations **PO-RSEQ-BOUND/PO-RSEQ-NONDET**, and evidence seed **EVID-2026-116**.
  - Extended **RFC-0003** with a new bake-in item for D-RSEQ and added a compressed inspiration lesson.
- Bibliography additions: **REF-LINUX-RSEQ-DOC**, **REF-LINUX-RSEQ-MAN**, **REF-REDHAT-RSEQ-GLIBC**, **REF-LWN-RSEQ-GLIBC**.

## Revised84 (2026-02-27)
- Added a "read-mostly sharing without lock pain" ecosystem seam:
  - Added **RFC-0112** introducing **D-RCU**: optional **grace periods + deferred reclamation** (RCU/QSBR/EBR lineage) so components can publish new versions of shared state and safely reclaim old nodes after readers quiesce.
  - Updated decision map + core mechanisms narrative to include a bounded **GraceDomain** seam that composes with **D-UWAIT**/**D-WAITSET** for blocking waits and uses supervision (D-SUPV) as the explicit stall posture (no silent unbounded limbo).
  - Discipline wiring: new invariants **I-RCU-1..3**, new proof obligations **PO-RCU-BOUND/PO-RCU-NOORACLE**, and evidence seed **EVID-2026-115**.
  - Extended **RFC-0003** with a new bake-in item for D-RCU and added a compressed inspiration lesson.
- Bibliography additions: **REF-LINUX-RCU-WHATIS/REF-LINUX-RCU-CONCEPTS/REF-LINUX-RCU-CHECKLIST**, **REF-MCKENNEY-PERFBOOK**, **REF-HAZARD-POINTERS-MICHAEL**, **REF-FRASER-PRACTICAL-LOCK-FREEDOM**, **REF-HART-MEMRECL-IPDPS06**, **REF-LIBURCU**.

## Revised83 (2026-02-27)
- Added an ecosystem reliability seam for shared-memory synchronization:
  - Added **RFC-0111** introducing **D-ROBUSTLOCK**: optional **robust lock / owner-death** semantics so shared user-space locks don’t deadlock forever when an owner thread/process terminates while holding them.
  - Updated decision map + core mechanisms narrative to include a quota-bounded **RobustSet** registration seam that composes with **D-UWAIT**, supervision (D-SUPV), and deterministic replay (D-RR).
  - Discipline wiring: new invariants **I-ROBUST-1..3**, new proof obligations **PO-ROBUST-BOUND/PO-ROBUST-NOREUSE**, and evidence seed **EVID-2026-114**.
  - Inspirations/bibliography: added robust futex + WAIT_ABANDONED references and a compressed lesson mapping.

## Revised82 (2026-02-27)
- Added a “stop spinning / stop allocating events-per-lock” ecosystem seam:
  - Added **RFC-0110** introducing **D-UWAIT**: an optional **wait-on-address** (futex-like) primitive for efficient userspace mutex/condvar implementations (uncontended = userspace; contended = bounded kernel sleep/wake).
  - Updated decision map + core mechanisms narrative to treat wait-on-address as complementary to D-WAITSET (event loops) and to compose with D-REQCTX (timeout/cancel) without ambient time.
  - Discipline wiring: new invariants **I-UWAIT-1..3**, new proof obligations **PO-UWAIT-BOUND/PO-UWAIT-ATOMIC**, and evidence seed **EVID-2026-113**.
  - Extended **RFC-0003** with a new seed item for D-UWAIT and added a compressed lesson to `docs/90-inspirations/os-lessons.md`.
- Bibliography additions: **REF-MS-WAITONADDRESS/REF-MS-WAKEBYADDRESSSINGLE/REF-MS-WAITFUNCS**, **REF-LINUX-FUTEX2/REF-LINUX-FUTEX-PAPER**, **REF-FREEBSD-UMTX-OP**, **REF-FUCHSIA-FUTEX**.

## Revised81 (2026-02-27)
- Added a “post-mortem reliability” seam for incident workflows:
  - Added **RFC-0109** introducing **D-FLIGHTREC**: optional, bounded **flight recorder** retention rings for selected logs/traces/inspect state, with crash/watchdog/operator triggers that assemble CH-SNAPSHOT incident captures.
  - Added **CH-FLIGHTPOL v0** (retention + trigger policy artifact) and registered it in the schema registry.
  - Updated decision map + mechanisms narrative, and threaded D-FLIGHTREC into existing diagnostics/record-replay docs (RFC-0075, RFC-0013) and the ecosystem bake-in list (RFC-0003).
  - Discipline wiring: new invariants **I-FLIGHT-1..3**, new proof obligations **PO-FLIGHT-BOUND/PO-FLIGHT-ACCESS**, and evidence seed **EVID-2026-112**.
- Bibliography additions: **REF-SYSTEMD-JOURNALD**, **REF-LINUX-RAMOOPS**, **REF-LINUX-PSTORE**, **REF-ANDROID-NATIVE-CRASH**.

## Revised80 (2026-02-27)
- Added a “maintenance correctness” seam that is painful to retrofit later:
  - Added **RFC-0108** introducing **D-QUIESCE**: an optional, capability-gated **quiescence + drain/cancel protocol** for shutdown, restart swaps, and checkpoint capture.
  - Added **CH-QUIESCE v0** (bounded, non-authoritative maintenance intent/state descriptor) and registered it in the schema registry.
  - Updated decision map, core mechanisms narrative, and inspirations to treat quiesce/drain as a testable contract (not an ad-hoc signal).
  - Discipline wiring: new invariants **I-QUIESCE-1..3**, new proof obligations **PO-QUIESCE-STATE/PO-QUIESCE-GATE**, and evidence seed **EVID-2026-111**.
  - Extended **RFC-0003** with a new seed item for D-QUIESCE and updated the checkpoint/restore RFC to point at the minimal quiesce contract.
- Bibliography additions: **REF-SYSTEMD-SERVICE**, **REF-KUBE-LIFECYCLE-HOOKS**, **REF-ERLANG-RELEASE-HANDLING**, **REF-LINUX-CGROUP-FREEZER**.


## Revised79 (2026-02-27)
- Added a “throughput without bespoke fast paths” performance seam:
  - Added **RFC-0107** introducing **D-IOQ**: an optional **IoQueue** submission/completion ring object (io_uring / Windows I/O Rings shape) for batching I/O operations and harvesting completions efficiently.
  - Updated decision map, core mechanisms narrative, and inspirations: **D-IOQ** is now a first-class optional seam that composes with **D-WAITSET** and **D-IOBUF**.
  - Discipline wiring: new invariants **I-IOQ-1..3**, new proof obligations **PO-IOQ-BOUND/PO-IOQ-NOAMP**, and evidence seed **EVID-2026-110**.
  - Extended **RFC-0003** with a new seed item for D-IOQ.
- Bibliography additions: **REF-LINUX-IOURING-PDF/REF-LINUX-IOURING-ENTER/REF-LINUX-IOURING-MAN7**, **REF-WIN-IORING-OVERVIEW/REF-WIN-IORING-CREATE/REF-WIN-IORING-SUBMIT**.


## Revised78 (2026-02-27)
- Added a “hard-to-retrofit” event-loop scalability seam:
  - Added **RFC-0106** introducing **D-WAITSET**: object **signal bits** + an efficient **WaitSet** (epoll/kqueue/IOCP/Zircon ports–style) for waiting on many event sources without polling hacks.
  - Updated decision map and assurance registries: new invariants **I-WAITSET-1..3**, new proof obligations **PO-WAITSET-BOUND/PO-WAITSET-NOAMP**, and evidence seed **EVID-2026-109**.
  - Updated `docs/30-architecture/mechanisms.md` to call out WaitSets as an optional core mechanism seam; removed a duplicated “resource meters” section for clarity.
  - Extended **RFC-0003** with a new seed item for D-WAITSET and added a compressed lesson in `docs/90-inspirations/os-lessons.md`.
- Bibliography additions: **REF-ZIRCON-SIGNALS**, **REF-ZIRCON-OBJECT-WAIT-MANY**, **REF-ZIRCON-PORT-WAIT**, **REF-LINUX-EPOLL**, **REF-BSD-KQUEUE**, **REF-WIN-IOCP**.

## Revised77 (2026-02-27)
- Request-context seam added (avoid “timeout soup”; make cancellation/deadlines explainable):
  - Added **RFC-0105** introducing **D-REQCTX** and **CH-REQCTX v0** (bounded, non-authoritative request intent descriptor).
  - Added **CH-CAPRPC v1** as an optional correlation hook: CapRPC frames may carry `ctx_digest` (digest of CH-REQCTX) for transcript-friendly postmortems.
  - Updated **RFC-0026** (CapRPC) to call out request-context conventions and cancellation-as-default posture.
  - Updated decision map and assurance registries: new invariants **I-REQCTX-1..3**, new proof obligations **PO-REQCTX-VALIDATE/PO-REQCTX-ATTEN**, and evidence seed **EVID-2026-108**.
- Diagnostics inspiration tightened:
  - Added a compressed lesson for **Solaris Fault Management Architecture (FMA)** (typed error reports → diagnosis engines → response agents) and added it as prior art to **RFC-0087** triage.
  - Bibliography additions: **REF-SOLARIS-FMA-OVERVIEW**, **REF-SOLARIS-FMA-ADMIN**, plus request-context refs (**REF-GO-CONTEXT**, **REF-KOTLIN-CANCEL**, **REF-CAPNP-1.0-CANCEL**, **REF-VORPUS-TIMEOUTS**).

## Revised76 (2026-02-27)
- Added two “hard-to-retrofit” ecosystem seams:
  - **Constructor/factory components + confinement tests** (KeyKOS/EROS/Hydra lineage): tightened D-CONSTR narrative, added a compressed lesson, and added a matching RFC-0003 seed item pointing at RFC-0042.
  - **Interop-friendly networked object-capability transport** (CapTP/OCapN): added a compressed lesson and a matching RFC-0003 seed item emphasizing “no ambient network” and explicit introduction semantics.
- Meta-engineering:
  - `docs/30-architecture/mechanisms.md` now explicitly calls out constructors as an optional core mechanism seam.
  - Glossary expanded with **constructor/factory**, **confinement test**, and **sealer/unsealer** terminology.
- Bibliography: added **REF-KEYKOS-FACTORY** and **REF-HYDRA-CH6**.


## Revised75 (2026-02-27)
- Added three “operational primitives” lessons + corresponding feature seeds:
  - **Process containers / job objects** (Windows Job Objects + Linux cgroups + Fuchsia jobs) as a unified handle for limits + lifecycle cleanup (`docs/90-inspirations/os-lessons.md`, `rfcs/0003-ecosystem-features-to-bake-in.md`, `rfcs/0012-resource-meters-space-banks-and-budgets.md`, `rfcs/0017-supervision-trees-and-restart-policy.md`).
  - **Death-watch notifications** (Mach dead-name notification pattern) as a clean liveness signal for supervisors (`docs/90-inspirations/os-lessons.md`, `rfcs/0003-ecosystem-features-to-bake-in.md`, `rfcs/0017-supervision-trees-and-restart-policy.md`).
  - **Fast local RPC handles** (Solaris Doors) as a UX/perf target for local cap-RPC (`docs/90-inspirations/os-lessons.md`, `rfcs/0003-ecosystem-features-to-bake-in.md`).
- Added new REF entries: **REF-WIN-JOBOBJECTS**, **REF-MACH-REQUEST-NOTIFY**, **REF-SOLARIS-DOORS**.
- Repo hygiene: removed stray tools/__pycache__/ and empty temp file; added a small `.gitignore`.

## Revised74 (2026-02-27)
- Inspirations + “bake-in” seeds tightened with a few underused-but-relevant systems:
  - Added compressed lessons for **Amoeba** (capability directories + immutable storage), **Twizzler** (object-centric persistence), and **Multics** (rings + the complexity cautionary tale) in `docs/90-inspirations/os-lessons.md`.
  - Extended **RFC-0003** with two new candidate ecosystem features:
    - **38)** Immutable, content-addressed “time machine” storage as a standard service (Venti/Bullet line).
    - **39)** Persistent object graphs and cross-run sharing (Twizzler line).
  - Added new REF entries to the bibliography: **REF-AMOEBA-INTRO/REF-AMOEBA-CACM90/REF-AMOEBA-1990S**, **REF-TWIZZLER-ATC20/REF-TWIZZLER-TR17**, **REF-MULTICS-RINGS/REF-MULTICS-PROTMULT/REF-KARGER-2002**.
- Meta: changelog cleanup (removed an empty Revised70 header that had no associated notes).

## Revised73 (2026-02-26)
- Application secrets made explicit (tight, portalized, non-ambient):
  - Added **RFC-0104** introducing **D-APPSECRET**: application secret seeds are mediated by a secret portal (`portal.secret`) and emit bounded **CH-APPSECRET v0** descriptors.
  - Registered **CH-APPSECRET v0** (`docs/30-architecture/app-secret-descriptor-schema-v0.md`), updated the portal-family registry and CH-PLEDGE token mapping with `portal.secret`.
  - Discipline wiring: new invariants **I-APPSECRET-1..3**, new proof obligations **PO-APPSECRET-VALIDATE/PO-APPSECRET-ENF**, and new abuse case **AC-089** (secret-oracle/correlation/stealth rotation).
  - Evidence seed: **EVID-2026-107** (schema validator + secret-portal harness plan; no secret bytes in transcripts).

## Revised72 (2026-02-26)
- Background execution + login autostart authority made explicit (tight, portalized):
  - Added **RFC-0103** introducing **D-BGLEASE**: background execution and login autostart are mediated by a background portal (`portal.background`) that returns BackgroundLease handles and emits a bounded **CH-BGLEASE v0** descriptor.
  - Registered **CH-BGLEASE v0** (`docs/30-architecture/background-lease-schema-v0.md`), added the `portal.background.*` family to the portal registry, and extended CH-PLEDGE token set/mapping with `portal.background`.
  - Discipline wiring: new invariants **I-BGLEASE-1..3**, new proof obligations **PO-BGLEASE-VALIDATE/PO-BGLEASE-ENF**, and new abuse case **AC-088** (stealth persistence + battery drain via background/autostart).
  - Evidence seed: **EVID-2026-106** (schema validator + background-portal harness plan: deny-by-default; TTL/renew clamps; indicators/status; no implicit net).
  - Inspirations + refs: added a compressed background/autostart lesson and bibliography refs for XDG Background portal, Android background execution limits/FGS restrictions, and Apple background execution modes.


## Revised71 (2026-02-26)
- Power/idle “inhibit” authority made explicit (tight, portalized):
  - Added **RFC-0102** introducing **D-INHIBITLEASE**: session transition inhibition (idle/suspend/logout/shutdown) is mediated by an inhibit portal (`portal.inhibit`) that returns inhibition lease handles and emits a bounded **CH-INHIBITLEASE v0** descriptor.
  - Registered **CH-INHIBITLEASE v0** (`docs/30-architecture/inhibit-lease-schema-v0.md`), added the `portal.inhibit.*` family to the portal registry, and extended CH-PLEDGE token set/mapping with `portal.inhibit`.
  - Discipline wiring: new invariants **I-INHIBIT-1..3**, new proof obligations **PO-INHIBIT-VALIDATE/PO-INHIBIT-ENF**, and new abuse case **AC-087** (battery drain / transition DoS).
  - Evidence seed: **EVID-2026-105** (schema validator + portal harness plan: TTL/renew clamps; delay vs block; indicator/consent posture; no ambient inhibit APIs).
  - Inspirations + refs: added a compressed “inhibitor lock / wake lock” lesson and bibliography refs for XDG Inhibit portal + systemd inhibitor locks + Android wake locks.

- Location authority made explicit (tight, portalized):
  - Added **RFC-0101** introducing **D-LOCLEASE**: location access is mediated by a location portal (`portal.location`) that returns scoped location capabilities and emits a redaction-aware **CH-LOCLEASE v0** descriptor (no coordinates).
  - Registered **CH-LOCLEASE v0** (`docs/30-architecture/location-lease-schema-v0.md`) and added the `portal.location.*` family to the portal registry and CH-PLEDGE token set (`portal.location`).
  - Discipline wiring: new invariants **I-LOCLEASE-1..3**, new proof obligations **PO-LOCLEASE-VALIDATE/PO-LOCLEASE-ENF**, and new abuse case **AC-086** (covert tracking/background surveillance).
  - Evidence seed: **EVID-2026-104** (validator + portal harness: TTL/cadence clamps; background posture; export redaction; no implicit net authority).
  - Inspirations + refs: added a compressed location lesson (coarse vs precise, foreground vs background) and new bibliography refs for the XDG Location portal, Android location permissions/background guidance, Apple Precise Location toggle, and GeoClue D‑Bus API.
- Meta-engineering: archive lint now checks that `portal.*` tokens in CH-PLEDGE are covered by the portal-family registry (prevents silent portal/token drift).


## Revised69 (2026-02-26)
- D-ATTRFS query seam made explicit (tight, low-TCB):
  - Added **RFC-0100** standardizing **CH-ATTRQ v0**: a bounded, deterministic predicate format for attribute-indexed queries (“Find” / smart folders) that stays capability-scoped (view-scoped) and avoids a privileged DB/VM.
  - Registered **CH-ATTRQ v0** in the schema registry (`docs/30-architecture/attribute-query-schema-v0.md`) and updated D-ATTRFS decision-map notes to reference query predicates.
  - Discipline wiring: new invariant **I-ATTRQ-1**, new proof obligations **PO-ATTRQ-VALIDATE/PO-ATTRQ-BOUNDS**, and new abuse case **AC-085** (index/query leakage + query-as-DoS).
  - Evidence seed: **EVID-2026-103** (validator + bounded evaluation harness + no-cross-view-leak negative tests).
  - Bibliography: added **REF-PFSD-BFS** (Giampaolo’s BFS book PDF) and extended the BeOS/Haiku lesson refs.

## Revised68 (2026-02-26)
- Portal family hardening + pledge coherence (tight, meta-engineering):
  - Fixed a drift bug: **CH-PLEDGE v0** now explicitly includes the portal-family tokens already used by the archive, and the mapping table now matches the schema.
    - Added tokens: `portal.capture`, `portal.xfer`, `portal.jobs`, `portal.a11y`, plus `portal.uri`, `portal.print`, `portal.device`.
  - Added `docs/30-architecture/portal-family-registry.md` to keep `portal.*` families stable and reviewable (ties RFCs → portal families → CH-* descriptors → CH-PLEDGE tokens).
  - Meta-engineering: archive lint now checks **CH-PLEDGE token enum ↔ mapping-table consistency**, and the `TBD` placeholder check now matches word boundaries correctly.
  - Inspirations + refs: tightened the portals lesson to call out OpenURI/Print/USB as “boring glue” that benefits from the same mediation discipline; added bibliography refs **REF-XDG-PORTAL-OPENURI/PRINT/USB**.
  - Evidence seed: **EVID-2026-102** (token-set expansion + mapping consistency lint guard).

## Revised67 (2026-02-26)
- Accessibility/automation authority made explicit (tight, low-TCB):
  - Added **RFC-0099** introducing **D-UIAUT**: accessibility + automation as **portal-mediated, leased sessions** with rights separation (observe ≠ inject) and shell-driven indicators.
  - Added **CH-UIAUT v0** schema (`docs/30-architecture/ui-automation-lease-schema-v0.md`) and registered it in the schema registry.
  - Decision map: added **D-UIAUT** adjacent to D-UICAP; updated RFC-0080 to reference D-UIAUT and to treat a11y/automation as session-granted capabilities.
  - Discipline wiring: new invariants **I-UIAUT-1..3**, new proof obligations **PO-UIAUT-VALIDATE/PO-UIAUT-ENF**, new abuse case **AC-084**, and evidence seed **EVID-2026-101**.
  - Meta-engineering: expanded the pledge token mapping to include portal families `portal.capture`, `portal.xfer`, `portal.jobs`, and `portal.a11y` (keeps CH-PLEDGE reviewable as portals grow).
  - Bibliography: added focused references for Android AccessibilityService, Apple accessibility trust gating, and Windows UIAccess.

## Revised66 (2026-02-26)
- Recovery boot posture added (tight, low-TCB):
  - Added **RFC-0098** introducing **D-RECOVERY**: a dedicated, minimal **recovery environment** as a first-class boot target, with at least one physical-presence entry path (boot menu/button/SAS).
  - Standardized a lightweight binding convention: include a `recovery_root` deployment digest in CH-UPD/CH-BOOT `artifacts[]` so recovery is provenance-bound like any other trusted deployment.
  - Added assurance hooks: **I-RECOVERY-1**, **PO-RECOVERY-ENTRY**, **PO-RECOVERY-NOAMP**, with evidence seeds **EVID-2026-099/100** for recovery boot + trial-boot loop harnesses.
  - Decision map: added **D-RECOVERY** and linked it to D-ATOMICUPD/D-HEALTH without importing policy into IF-BOOT.
- Inspirations + refs: extended OS lessons and bibliography with WinRE, Android recovery partition, and systemd rescue/emergency targets (REF-WINRE, REF-ANDROID-PARTITIONS, REF-SYSTEMD-SPECIAL).

## Revised65 (2026-02-26)
- Hardware knowledge seam sharpened (tight, low-TCB):
  - Expanded **RFC-0018 (D-SKB)** to make **fact evolution** explicit: added **CH-HWEVENT v0** (bounded hardware event deltas with epoch+monotonic sequencing) so hotplug/link changes can be audited and replayed without kernel policy logic.
  - Registered **CH-HWEVENT v0** in the schema registry and added schema doc `docs/30-architecture/hardware-event-schema-v0.md`.
  - Tightened integration points:
    - RFC-0085 now records hotplug notifications as CH-HWEVENT (when D-SKB is enabled) and binds attach/detach logs to `{epoch,event_seq}`.
    - RFC-0083 now treats driver binding as a D-SKB informed user-space policy decision rather than ad-hoc probing.
  - Decision map: expanded D-SKB options/evidence/notes to include CH-HWEVENT epoching and D-DEVGUARD interaction.
  - Evidence seeds added: **EVID-2026-097/098** (CH-HWEVENT validator negatives; SKB named-query determinism harness).
- Inspirations + refs: strengthened the SKB lesson (declarative/constraint framing) and added bibliography entries **REF-DECLARATIVE-OS** and **REF-FUCHSIA-DRIVER-NODES**.

## Revised64 (2026-02-26)
- Rollback safety for **mutable data** made explicit (tight, low-TCB):
  - Added **RFC-0097** (data contracts + migration gates) to prevent “code rollback into unreadable state.”
  - Extended **CH-CFG v0** with optional `data_contracts` (bounded per-dataset reader/writer compatibility declarations used by update tooling).
  - Tightened D-ATOMICUPD discipline: new invariant **I-ATOMICUPD-4** (data rollback is explicit) and new proof obligation **PO-ATOMICUPD-DATA** (deterministic activation/rollback checks; snapshot-barrier enforcement).
  - Added evidence seed **EVID-2026-096** (compat-window + breaking-migration + snapshot-barrier harness; rollback fail-closed; restore succeeds; health-commit gating).
  - Integrated into docs: updated `configuration-pipeline.md` (turn NixOS-style footgun into a concrete seam), RFC-0051 (atomic updates caveat + pointer), the decision map D-ATOMICUPD entry, and RFC-0003’s snapshot/boot-environment seed to reference RFC-0097.

## Revised63 (2026-02-26)
- Trusted UI path upgrade (tight, low-TCB):
  - Expanded **RFC-0080** to pin concrete **secure UI mode** semantics (SAS enters a spoof-resistant “secure desktop” for login/high-risk consent) and to add an optional **secure input session** seam (lease + TTL) that suppresses non-authorized keyboard interception during sensitive entry.
  - Strengthened D-UICAP wiring: clarified I-UICAP-2 to treat focus-chain disclosure as sensitive metadata (capability-gated), and tightened PO-UICAP-FOCUS accordingly.
  - Added evidence seed **EVID-2026-095** for SAS + secure-input integration tests (secure desktop entry; secure-input TTL/expiry; non-authorized global tap suppression).
- Ecosystem “bake-in” list: added a dedicated RFC-0003 seed item for trusted-path entry + secure input sessions (SAS + secure keyboard entry).
- Inspirations + refs: added a compressed lesson and bibliography entries for Fuchsia focus-chain sensitivity, macOS Secure Event Input (TN2150), and IBM’s Secure Attention Key / trusted path posture.

## Revised62 (2026-02-26)
- Meta-engineering: fixed archive lint failures by:
  - registering **CH-PROV v0** in the schema registry and adding **ADV-APP** to the canonical adversary list,
  - replacing the sparse evidence register with a complete, tabled **EVID index** (stubs for every referenced EVID),
  - removing shorthand range notation (`EVID-…/…`, `EVID-…..…`) in RFCs/changelog so traceability is machine-checkable.
- Research + synthesis: added an Exokernel/Nemesis “application-level resource management” lesson (and bibliography entry) to strengthen the D-METER/D-PRESSURE/D-PAGER framing, and added a matching RFC-0003 seed item.
## Revised61 (2026-02-26)
- Background work hardening (tight, low-TCB):
  - Added **RFC-0096** introducing **D-JOBS** + **CH-JOBREQ v0**: a bounded job-request descriptor for portal-mediated, constraint-based background work (no ambient cron/alarms).
  - Added schema doc: `docs/30-architecture/job-request-schema-v0.md` and registered **CH-JOBREQ** in the schema registry.
  - Decision map: added **D-JOBS** seam and linked it to D-TCAP/D-PRESSURE/D-ACTIVATE integration points.
  - Discipline wiring: new invariants **I-JOB-1/I-JOB-2**, new proof obligations **PO-JOBREQ-VALIDATE/PO-JOBS-ENF**, new abuse case **AC-083**, and evidence seed **EVID-2026-094**.
- Inspirations + refs: added a compressed lesson and focused bibliography entries for Android JobScheduler/WorkManager, Apple BGTaskScheduler semantics (earliestBeginDate is advisory), and systemd.timer.

## Revised60 (2026-02-26)
- Media capture hardening (tight, low-TCB):
  - Added **RFC-0095** introducing **CH-CAPTURE v0**: a bounded capture-session descriptor for portal-mediated camera/microphone/screencast/remote-desktop workflows (no ambient capture; no media bytes in the descriptor).
  - Added schema doc: `docs/30-architecture/capture-session-schema-v0.md` and registered **CH-CAPTURE** in the schema registry.
  - Decision map: added **D-CAPTURE** seam and updated D-UICAP/D-PLUMB integration points (RFC-0080 + RFC-0046) to reference RFC-0095 + CH-CAPTURE.
  - Discipline wiring: new invariants **I-CAPTURE-1/I-CAPTURE-2**, new proof obligation **PO-CAPTURE-VALIDATE**, new abuse case **AC-082**, and evidence seed **EVID-2026-093**.
- Inspirations + refs: added a compressed lesson and focused bibliography entries for PipeWire access control/session-manager split and XDG portal camera/audio discussions.

## Revised59 (2026-02-26)
- Desktop workflow hardening (tight, low-TCB):
  - Added **RFC-0094** introducing **CH-XFER v0**: a bounded transfer descriptor for portal-mediated clipboard/drag-drop/share transfers (no ambient broadcast; no payload bytes in the descriptor).
  - Added schema doc: `docs/30-architecture/transfer-descriptor-schema-v0.md` and registered **CH-XFER** in the schema registry.
  - Updated D-PLUMB integration points: refined the decision map and updated RFC-0046’s clipboard/drag-drop section to reference RFC-0094 + CH-XFER.
  - Discipline wiring: new invariants **I-XFER-1/I-XFER-2**, new proof obligation **PO-XFER-VALIDATE**, new abuse case **AC-081**, and evidence seed **EVID-2026-092**.
- Bibliography hygiene: fixed stray/orphan bullets in Fuchsia/Genode entries; added focused refs for Wayland `wl_data_device`, XDG portal Clipboard docs, and Android clipboard security guidance.

## Revised58 (2026-02-26)
- Signature hygiene + adoption upgrade (tight, low-TCB):
  - Added **RFC-0093** introducing **D-SIGENV** + **CH-SIGENV v0**: a small, canonical signature envelope that signs *payload digests* with DSSE-style type binding (prevents type confusion and wrapper proliferation).
  - Added schema doc: `docs/30-architecture/signature-envelope-schema-v0.md` and registered **CH-SIGENV** in the schema registry.
  - Decision map: expanded **D-UPD-SIGN** options and added dedicated **D-SIGENV** and **D-KEYLESS** seams for keyless signing profiles.
  - Discipline wiring: new invariants **I-SIGENV-1/I-KEYLESS-1**, new proof obligations **PO-SIGENV-VALIDATE/PO-SIGENV-VERIFY/PO-KEYLESS-VERIFY**, new abuse case **AC-080**, and evidence seed **EVID-2026-091**.
  - Integrated into docs: tightened provenance/update schema notes to point at CH-SIGENV as the concrete “signed container” shape; updated `docs/60-engineering/supply-chain-repro.md`, `docs/60-engineering/update-repository-metadata-and-key-rotation.md`, `docs/90-inspirations/os-lessons.md`, and RFC-0003 with a new “bake-in” seed item.
- Bibliography: added focused references for DSSE, in-toto Statement v1, Sigstore bundle format, and Fulcio OIDC claim mapping.


## Revised57 (2026-02-26)
- Vulnerability-triage ergonomics upgrade (tight, low-TCB):
  - Added **RFC-0092** introducing **D-VEX** + **CH-VEX v0**: a bounded, digest-bound VEX exploitability statement artifact that can be attached to releases/boots and checked for **subject binding** (avoid VEX drift; reduce scanner noise without tribal allowlists).
  - Added schema doc: `docs/30-architecture/vex-schema-v0.md` and registered **CH-VEX** in the schema registry.
  - Decision map: updated **D-SBOM** to reference the concrete VEX seam and added **D-VEX** as a dedicated optional decision.
  - Discipline wiring: new invariants **I-VEX-1/I-VEX-2**, new proof obligations **PO-VEX-VALIDATE/PO-VEX-BIND**, new abuse case **AC-079**, and evidence seed **EVID-2026-090**.
  - Integrated into docs: updated `docs/60-engineering/supply-chain-repro.md`, `docs/90-inspirations/os-lessons.md`, and RFC-0003 with a new “bake-in” seed item.
- Bibliography: added focused references for OpenVEX versioning, CSAF/ISO advisory framing, and a real-world distro VEX feed (Ubuntu).


## Revised56 (2026-02-26)
- Supply-chain audit ergonomics upgrade (tight, low-TCB):
  - Added **RFC-0091** introducing **D-SBOM** + **CH-SBOM v0**: a bounded, digest-bound SBOM inventory artifact that can be attached to releases/boots and checked for **subject binding** (avoid SBOM drift).
  - Added schema doc: `docs/30-architecture/sbom-schema-v0.md` and registered **CH-SBOM** in the schema registry.
  - Decision map: added **D-SBOM** as an optional seam for SBOM artifacts + closure binding.
  - Discipline wiring: new invariants **I-SBOM-1/I-SBOM-2**, new proof obligations **PO-SBOM-VALIDATE/PO-SBOM-BIND**, new abuse case **AC-078**, and evidence seed **EVID-2026-089**.
  - Integrated into docs: updated `docs/60-engineering/supply-chain-repro.md`, `docs/90-inspirations/os-lessons.md`, and RFC-0003 with a new “bake-in” seed item.
- Bibliography: added focused primary references for NTIA/CISA SBOM minimum elements, SPDX specs, CycloneDX spec overview, and CISA/OpenVEX VEX guidance.

## Revised55 (2026-02-26)
- Time as *usable* security infrastructure (tight, low-TCB):
  - Added **RFC-0090** introducing **D-TIMEPROOF** + **CH-TIMEPROOF v0**: a user-space authenticated time bootstrap posture (Roughtime + optional NTS discipline) with a bounded, exportable time-proof receipt artifact.
  - Added schema doc: `docs/30-architecture/time-proof-schema-v0.md` and registered **CH-TIMEPROOF** in the schema registry.
  - Decision map: extended **D-TIME** options to include authenticated bootstrap, and added **D-TIMEPROOF** as a dedicated seam.
  - Discipline wiring: new invariants **I-TIMEPROOF-1/I-TIMEPROOF-2**, new proof obligations **PO-TIMEPROOF-VALIDATE/PO-TIMEPROOF-VERIFY/PO-TIMEPROOF-APPLY**, new abuse case **AC-077**, and evidence seed **EVID-2026-088**.
- Inspirations + refs: added a compressed lesson tying Roughtime/NTS into update freshness and audit workflows, and added focused bibliography entries for Roughtime protocol + IETF draft and RFC 8915 (NTS).

## Revised54 (2026-02-26)
- Desktop sandbox ergonomics upgrade (tight, non-bearer persistence):
  - Added **RFC-0089** introducing **CH-DOCREF v0**: a portal-managed durable “recent document” handle that can be re-opened into a scoped, path-free file capability without becoming a bearer token.
  - Added schema doc: `docs/30-architecture/document-handle-schema-v0.md` and registered **CH-DOCREF** in the schema registry.
  - Tightened RFC-0046’s “document-store ID” note into a concrete CH-* artifact and linked to RFC-0089 (handles/caps, not paths).
  - Discipline wiring: new invariants **I-DOCREF-1/I-DOCREF-2**, new proof obligations **PO-DOCREF-VALIDATE/PO-DOCREF-REOPEN**, new abuse case **AC-076**, and evidence seed **EVID-2026-087**.
  - Updated D-PLUMB entry in the decision map to explicitly call out CH-DOCREF as an optional adoption seam for “recent documents”.
- Inspirations + refs:
  - Updated `docs/90-inspirations/os-lessons.md` with a compressed lesson tying the XDG document portal and macOS security-scoped bookmark pitfalls into our portal/receipt discipline.
  - Updated bibliography with **REF-XDG-PORTAL-DOCUMENTS** and **REF-FLATPAK-SANDBOX-PERMS**.

## Revised53 (2026-02-26)
- Ecosystem ergonomics upgrade for “default isolation” adoption:
  - Documented and integrated the **zygote/template-spawner** pattern (Android/Chromium): warmed templates that fork/clone (or snapshot-restore) to make disposable sandboxes fast and memory-efficient.
  - Updated RFC-0050 (D-EPHEM) with a concrete warm-template section and safety posture (“template is tainted authority; immediate one-way narrowing”).
  - Tightened D-INITSNAP and D-CHKPT RFCs to explicitly support **templates-as-artifacts** (CH-INIT / CH-CKPT digests bound for audit).
  - Extended compressed OS lessons and RFC-0003 with the new “preforked template spawners” seed.
- Bibliography: added focused primary references for Android zygote docs, Android memory overview (zygote fork + shared pages), and Chromium’s zygote process doc.

## Revised52 (2026-02-26)
- Measured-boot made mechanically usable:
  - Added **RFC-0088** introducing **CH-MEASLOG v0**: a bounded, replayable **measured boot event log** artifact (PCR quotes are not interpretable without the event log).
  - Added schema doc: `docs/30-architecture/measured-boot-log-schema-v0.md` and registered **CH-MEASLOG** in the schema registry.
  - Tightened `docs/30-architecture/boot-manifest-schema-v0.md` to bind measurements explicitly via CH-MEASLOG digest references.
  - Discipline wiring: new invariant **I-MEASLOG-1**, new proof obligation **PO-MEASLOG-VALIDATE**, and evidence seed **EVID-2026-086**.
  - Inspirations + RFC-0003: added the measured-boot log posture as a “bake-in seam” and anchored it to TCG/systemd/IMA references.

## Revised51 (2026-02-26)
- Added **RFC-0087** introducing **D-TRIAGE** + **CH-TRIAGE v0**: a pinned, bounded on-device triage rule format that evaluates over CH-INSPECT and/or CH-CRASHCAP to emit bounded findings and advisory snapshot requests.
- Added schema doc: `docs/30-architecture/triage-rules-schema-v0.md` and registered **CH-TRIAGE** in the schema registry.
- Wired triage into the discipline layer:
  - new invariants **I-TRIAGE-1/I-TRIAGE-2**, new proof obligations **PO-TRIAGE-VALIDATE/PO-TRIAGE-EVAL**, new abuse case **AC-075**, and evidence seed **EVID-2026-085**.
- Integrated triage into observability docs:
  - updated `docs/60-engineering/diagnostics-stack.md` (triage workflow pattern)
  - updated RFC-0076 (clarified CH-OBSPOL stays non-programmable; triage is a separate advisory artifact)
- Inspirations + refs: added a compressed lesson about Fuchsia triage + rule-based alerting, and added focused references for Prometheus alerting rules and osquery query-pack configuration.

## Revised50 (2026-02-26)
- Debuggability ecosystem upgrade (tight, bounded, policy-scoped):
  - Added **RFC-0086** introducing **CH-CRASHCAP**: a failure-shaped **crash capsule** manifest that binds crash metadata + environment digests + module identity (build IDs) and references bounded evidence payloads (log/trace/inspect windows; optional minidump/core; optional replay bundle).
  - Added schema doc: `docs/30-architecture/crash-capsule-schema-v0.md`.
  - Updated `docs/60-engineering/diagnostics-stack.md` to position CH-CRASHCAP as the default crash-report artifact (small cousin of CH-SNAPSHOT).
- Prior art + symbolization posture:
  - Updated `docs/90-inspirations/os-lessons.md` with a compressed lesson tying **Crashpad/Breakpad**, **systemd-coredump**, **minidumps**, and **build-id/debuginfod** style symbol fetch into our artifact/policy seams.
  - Updated `docs/00-meta/bibliography.md` with focused references for Crashpad design, systemd-coredump, Microsoft minidump format docs, ELF/GNU ld build-ids, and debuginfod/elfutils debuginfod.
- Archive wiring:
  - Updated D-INSPECT entry in the decision map to mention **CH-CRASHCAP** alongside CH-SNAPSHOT, and updated RFC-0075 to cross-link crash capsules.
  - Updated RFC-0003 with a new ecosystem seed item for crash capsules + stable symbolization.

## Revised49 (2026-02-26)
- Ecosystem “ground-floor” upgrades (tight, low-TCB seams):
  - Added an adoption lesson and tooling seam for **declarative configuration + generations** (Nix/NixOS-style): treat privileged config (CH-CFG) as the compiled output of a deterministic “config compiler,” and make rollback/generations a first-class UX. Wired into RFC-0003 and `docs/60-engineering/configuration-pipeline.md`.
  - Tightened observability ergonomics with **correlation semantics** (ETW/OTel-inspired) without changing CH-TRACE v0: standardized `sem` tags for trace/span/correlation identifiers in CH-TPROBE and documented cross-artifact correlation expectations (traces ↔ inspect snapshots ↔ receipts).
- Archive wiring:
  - Updated `docs/90-inspirations/os-lessons.md` with two new compressed lessons:
    - **NixOS generations + declarative config** as a practical template for “config-as-artifact” and rollback UX.
    - **Windows ETW / Apple unified logging** as a precedent for privacy-aware logging and activity/correlation IDs.
  - Updated RFC-0077 (D-TPROBE) to define recommended `sem` tags (`trace_id`, `span_id`, `parent_span_id`, `corr_id`) and to bind the “correlate by ID” posture to policy/redaction.
  - Added **ADR-0004** to pin the stance that CH-CFG is a small signed artifact produced by deterministic tooling (module evaluation), with generations tracked outside the privileged core.
- Bibliography: added focused references for NixOS manual/generations, Nix profile rollback, Microsoft ETW activity/correlation docs, Apple OSLog privacy, OpenTelemetry trace identifiers, and W3C Trace Context.

## Revised48 (2026-02-26)
- Inspiration and “bake-in seams” tightening:
  - Extended `docs/90-inspirations/os-lessons.md` with two pragmatic adoption precedents:
    - **Capsicum Casper** “capability services” pattern (pre-open explicit service handles before capmode/seal), mapped to D-SEAL/D-CAPMODE.
    - **ZFS boot environments** (Solaris/FreeBSD) as a real-world confirmation of our **CH-BOOTSEL** “pending/tries/commit” state machine for atomic upgrades.
  - Added a small Redox “schemes” lesson to reinforce the value of namespace-shaped service endpoints without ambient discovery.
- RFC refinements:
  - RFC-0016 (D-SEAL): added a Casper-style section describing how compat layers can keep DNS/userdb/etc behind explicit service capabilities after sealing.
  - RFC-0051 (D-ATOMICUPD): added ZFS boot environment prior art to the boot-selector notes and references.
  - RFC-0037 (D-CHKPT): added ZFS send/receive as a “streamed checkpoint artifact” prior-art sanity check.
- Canonicalization / drift control:
  - Marked **RFC-0054** as **DEPRECATED** and **superseded by RFC-0069** (typed diffs via CH-CAPDIFF); updated `docs/00-meta/deprecations.md` and `rfcs/README.md` accordingly.
- Bibliography: added focused references for ZFS boot environments, ZFS send/receive streams, FreeBSD Capsicum/Casper, and Redox schemes.

## Revised47 (2026-02-26)
- Inspirations/refactor pass:
  - Repaired and extended `docs/90-inspirations/os-lessons.md` with the previously-mentioned but missing compressed lessons: **Singularity contracts** (mapped to D-CONTRACT), **OpenBSD W^X** (D-DYNCODE), **Barrelfish SKB** (D-SKB), and **Project Oberon** (simplicity discipline).
  - Added a new persistence UX lesson: **Plan 9 Fossil + Venti** snapshot trees and immutable archival storage, mapped to D-PERSIST/D-NS/D-INSPECT.
- Persistence RFC tightening: updated **RFC-0038** with a Fossil-style “snapshots as a browseable namespace” convention and added the relevant references.
- Bibliography expanded with new Plan 9 snapshot prior art: **REF-PLAN9-FOSSIL** and **REF-PLAN9-FOSSIL-MAN**.
- Repo hygiene: fixed the markdown table formatting in `rfcs/README.md` (removed blank lines that broke table rendering).

## Revised46 (2026-02-25)
- Added **RFC-0085 (D-DEVGUARD)**: an adoptable **deny-by-default** posture for hotplug peripherals (USB/Thunderbolt/PCIe hotplug) that makes device access an explicit, transcript-visible, **revocable** capability grant.
  - New schema: **CH-DEVGUARD v0** (`docs/30-architecture/device-guard-policy-schema-v0.md`) for deterministic device-authorization rules (USBGuard-like) and auditability.
  - Discipline wiring: new invariants **I-DEVGUARD-1/I-DEVGUARD-2**, new proof obligations **PO-DEVGUARD-DECIDE/PO-DEVGUARD-ATTACH**, new abuse case **AC-074**, and new evidence seed **EVID-2026-084**.
  - Updated the decision map (D-DEVGUARD), RFC-0003 feature list (new item 37), compressed OS lessons, and bibliography with concrete prior art (Qubes USB workflows, USBGuard, Thunderspy, Windows Kernel DMA protection, GoodUSB).

## Revised45 (2026-02-25)
- Fixed archive lint issues introduced in the previous pass:
  - RFC-0081: replaced a wildcard supervision proof-obligation reference with concrete **PO-SUPV-NOAMP** / **PO-SUPV-RLIMIT**.
  - RFC-0082: corrected an undefined provenance decision-node token to **D-PCP**.
  - RFC-0083: removed accidental ID tokenization by rephrasing the “visible in CH-LOG” note.
- Added **RFC-0084 (D-IOBUF)**: an optional, adoptable **copyless buffer** seam that keeps bounded-copy the default but enables explicit shared-region buffer handles when needed.
  - New schema: **CH-IOBUF v0** (`docs/30-architecture/io-buffer-schema-v0.md`) for redaction-safe, audit-friendly buffer descriptors.
  - Safety posture: **cross-trust implies immutable/snapshot** (IO-Lite-style immutability or Zircon-style COW snapshots), with contracted ring protocols for mutable streaming cases.
  - Discipline wiring: new invariant **I-IOBUF-2**, new proof obligation **PO-IOBUF-VALIDATE**, tightened **PO-IOBUF-OWNERSHIP**, new abuse case **AC-073**, and new evidence seed **EVID-2026-083**.
- Updated the decision map (D-IOBUF) and inspiration notes with concrete prior art: IO-Lite immutable buffers, Zircon VMO rights + COW children, and Xen grant tables.

## Revised44 (2026-02-25)
- Tightened **D-IFC** (RFC-0047) into an adoptable **IFC-lite** posture: start by labeling a few high-leverage **export sinks** (IF-OBS and portal-mediated exports), make **declassify/endorse** an explicit, transcript-visible authority boundary, and (optionally) represent **quarantine** as a secrecy tag so “clear quarantine” compiles down to declassification.
- Added an explicit declassification/endorsement hook to the discipline layer:
  - new invariant **I-IFC-3** (label lowering / integrity raising requires explicit authority and is transcript-visible)
  - new proof obligation **PO-IFC-DECLASS** (no unauthorized widening of flows; fail closed)
  - new evidence seed **EVID-2026-082** (model-vs-impl differential harness plan + quarantine-as-tag interop tests)
- Threat-model hygiene: added **AC-072** (label laundering / confused-declassifier) with concrete mitigations and evidence targets.
- Inspirations + prior art refactor: added a compressed DIFC lesson to `docs/90-inspirations/os-lessons.md` and upgraded the **IFC / labeled systems** bibliography section with concise “key/why/us” bullets (plus the foundational DIFC model paper).

## Revised43 (2026-02-25)
- Added **RFC-0083**: a tightened **driver-host + compatibility capsule** story that makes driver isolation operationally boring: native drivers run in restartable **driver host** processes (manager-owned lifecycles), and legacy donor stacks (rump/LKL/DDE-style) are treated as **compatibility runtimes** behind an explicit capability membrane.
- Updated **RFC-0036** (D-RUMPK): expanded the comparison space to include **LKL**, L4Re’s driver bring-up patterns, and user-space driver frameworks (Fuchsia DF / Windows UMDF), and linked RFC-0083 as the shared “compat capsule membrane” guidance.
- Updated the decision map’s **D-RUMPK** entry to reference RFC-0036 + RFC-0083 and to explicitly call out Linux-kernel-library style capsules as an alternative runtime.
- Added a new inspirations mapping: **Fuchsia/UMDF driver hosts** as a concrete precedent for D-DRVDOM + D-SUPV + D-ACTIVATE (drivers as restartable user-space services).
- Threat-model + evidence wiring:
  - new abuse case **AC-071** (compatibility capsule escape / ambient host effects)
  - new evidence seed **EVID-2026-081** (compat capsule harness: ambient-effect probes + hostile-input fuzz + restart containment)
- Bibliography expanded with a focused driver-host/compatibility spine: **Fuchsia driver framework**, **UMDF overview**, **LKL**, and **L4Re driver tutorial**.

## Revised42 (2026-02-25)
- Added **RFC-0082** (**D-WITNESS**): an optional, out-of-band **witnessed-checkpoint** seam for transparency logs that raises the bar against **split-view / equivocation** and “targeted invisibility” of releases, while keeping the kernel fully agnostic.
- Tightened **D-TLOG** (RFC-0029): clarified how CH-TLOG anchors can carry (or reference) witness bundles, and reframed witnesses as a profile-gated “audit-complete” predicate rather than a boot dependency.
- Wired witnessing into the discipline layer:
  - new invariant **I-TLOG-2** (split-view resistance when D-WITNESS is enabled)
  - new proof obligation **PO-TLOG-WITNESS**
  - evidence seed **EVID-2026-080** (witness verifier + negative tests)
  - new abuse case **AC-070** (split-view log attack / targeted transparency failure)
- Inspirations + bibliography: added Sigsum’s witness-threshold model, transparency.dev witness/armored-witness, and Go’s sumdb transparency-log design as concrete prior art, and corrected/updated the Tessera reference.

## Revised41 (2026-02-25)
- Added **RFC-0081** (**D-ACTIVATE**): an optional, user-space **activation/handoff** seam that makes crash-only restarts operationally usable: supervisor-owned **stable service handles** (socket-activation style) are passed into each instance at start, and an optional **per-component handle store** can preserve a bounded set of handles across restarts.
- Added **CH-ACTSET v0** (`docs/30-architecture/activation-set-schema-v0.md`) and registered it in the CH schema registry.
- Extended **CH-COMP v0** with an optional `activation` object (`stable_exports` + bounded `handle_store` policy) and tightened validator obligations accordingly.
- Wired the seam into the discipline layer:
  - invariants **I-ACTIVATE-1**, **I-ACTIVATE-2**
  - proof obligation **PO-ACTIVATE-HANDOFF**
  - evidence seed **EVID-2026-079**
  - new abuse case **AC-069** (handle-store misuse / seal bypass / wrong-instance restore)
- Inspirations + refs: added systemd socket activation + FD store, launchd socket activation, nginx “upgrade on the fly”, and Fuchsia Stop/Kill lifecycle semantics as concrete prior art.

## Revised40 (2026-02-25)
- Added **RFC-0080** (**D-UICAP**): an optional **capability-mediated UI compositor** contract that treats surfaces + input endpoints as object capabilities (no ambient global window IDs), routes input via an explicit focus chain, and pushes high-risk UI authority (screenshot/screencast/remote-control) behind portal workflows + leases.
- Hardened the trusted-gesture story: updated **RFC-0039** (D-VOLITION) with an optional **Secure Attention Sequence** concept (SAS) for spoof-resistant entry into secure-mode login/consent flows.
- Wired UI isolation into the archive’s discipline layer:
  - invariants **I-UICAP-1**, **I-UICAP-2**, **I-SAS-1**
  - proof obligations **PO-UICAP-FOCUS**, **PO-SAS-DELIVER**
  - evidence seed **EVID-2026-078** (compositor harness negative tests)
  - threat-model pressure test **AC-068** (UI spoofing / input snooping / screen scrape)
- Inspirations + bibliography: added a focused UI boundary section with Wayland model-of-operation, Fuchsia ViewRef, Windows SAS, and xdg-desktop-portal Screenshot as concrete prior art.

## Revised39 (2026-02-25)
- Added **RFC-0079**: a pragmatic **TUF-style update repository metadata** seam (**D-TUF**) for distributing CH-UPD + artifacts with survivable key compromise, metadata expiry, and freeze/rollback resistance — while keeping the privileged boot path agnostic.
- Added an operator-focused playbook: `docs/60-engineering/update-repository-metadata-and-key-rotation.md` (key hierarchy, thresholds, expiry windows, incident recovery drill).
- Tightened assurance wiring: added **I-TUF-1**, **PO-TUF-VERIFY**, and evidence seed **EVID-2026-077** for a prototype repo + rotation/compromise drill harness.
- Threat-model hygiene: resolved an abuse-case ID collision by renumbering “trace predicate abuse / filter-DoS” to **AC-066** and updating references; added **AC-067** for repository freeze / stale-metadata attacks.
- Inspirations/references: added a concise TUF/Uptane lesson and bibliographic spine (TUF spec + metadata roles + Uptane best practices + Sigstore Fulcio/keyless overview).


## Revised38 (2026-02-25)
- Tightened **D-SEAL / CH-PLEDGE** into an adoption-friendly workflow: clarified that `violation="deny"` acts as a **learn/complain mode** (deny+log) enabling token discovery without syscall-by-syscall allowlists; added a concrete engineering playbook (`docs/60-engineering/authority-bracketing-and-promise-learning.md`).
- Updated **RFC-0016** to include a dedicated “learning/audit mode” section and to explicitly connect execpromises-style spawn-time narrowing to our supervisor/launcher posture.
- Strengthened CH-PLEDGE semantics docs: added guidance that deny-mode violations SHOULD emit deterministic, redaction-safe records to support CI drift gates; updated the pledge token→effect mapping notes accordingly.
- Inspirations + references: expanded the OpenBSD pledge/unveil lesson with modern portability/usability evidence (SerenityOS reimplementation + Threadbox 2025 research) and added corresponding bibliography entries.
- Meta-hygiene: reordered the late evidence-index block so EVID-2026-069..076 are in numeric order and added **EVID-2026-076** for the pledge learn-mode harness.


## Revised37 (2026-02-25)
- Added **RFC-0078** (**D-TURNS**): an optional turn-based ("vat") service concurrency profile to prevent implicit reentrancy (no inbox pumping), improve reasoning tractability, and tighten the deterministic replay story without changing the kernel scheduler.
- Updated **RFC-0026** (D-CAPRPC): added explicit guidance on reentrancy hazards and how D-TURNS composes with oneway/pulses and promise pipelining; expanded the invariants/PO list accordingly.
- Wired D-TURNS into the archive’s discipline layer: added invariant **I-TURNS-1**, proof obligation **PO-TURNS-NOREENTR**, evidence seed **EVID-2026-075**, and a new threat-model abuse case **AC-064** (inbox-pumping RPC reentrancy).
- Updated inspirations and references: added an OS-lesson mapping for E/Spritely vats and expanded the bibliography with E manuals/FAQ + Spritely core/CapTP onboarding; updated the Robust Composition reference to a more stable source URL.


## Revised36 (2026-02-25)
- Strengthened the **D-PERSIST/D-CHKPT** story with tighter prior-art grounding: KeyKOS/EROS/CapROS checkpointed authority graphs + CapROS device-state caveats + modern TreeSLS (SOSP 2023) as an NVM-era “capability tree checkpoint” existence proof; threaded into OS lessons and RFC-0065/RFC-0037.
- Upgraded **D-CAPRPC** with an explicit, optional **promise-handle + pipelined send** profile (Cap’n Proto/E lineage), including new invariant/proof-obligation hooks (I-CAPRPC-3 / PO-CAPRPC-PIPELINE) and evidence seed EVID-2026-074.
- Bibliography expanded with focused refs for Cap’n Proto RPC/pipelining, KeyKOS OSR 1992 writeup, TreeSLS, CapROS persistence/device notes, and checkpoint-based update literature (KUP, L4 user-level checkpointing).

## Revised35 (2026-02-25)
- Added a new high-leverage composition lesson: **seL4 Microkit/capDL** as an existence proof that treating architecture as a static description compiled into a concrete time‑0 snapshot can keep runtime tiny and make initialization verifiable; threaded into OS lessons and D-INITSNAP guidance.
- Updated RFC-0009 (D-COMP): added an optional **CH-COMP → CH-INIT sysgen** posture (Microkit-style) to minimize runtime degrees of freedom in static/high-assurance profiles while preserving CH-COMP as the review artifact.
- Added `docs/60-engineering/system-generation-pipeline.md`: a tight description of the author→lint→sysgen→boot pipeline, TCB boundaries, and early evidence targets for ‘boot matches snapshot’.
- Bibliography additions: REF-MICROKIT-MANUAL / REF-MICROKIT-GITHUB / REF-MICROKIT-TUTORIAL.

## Revised34 (2026-02-25)
- Added a new microkernel “reality check” inspiration: **QNX Neutrino resource managers + pulses** (path-attached user-space servers + bounded async notifications); threaded into OS lessons, namespace/view semantics, and translator seams.
- Extended RFC-0026 (D-CAPRPC) with an optional **oneway/pulse** method profile (interface-marked) and crisp “enqueue vs error” semantics (no silent drop); added invariant **I-CAPRPC-2** and proof obligation **PO-CAPRPC-ONEWAY**.
- Tightened namespace/view docs (RFC-0032 + `docs/30-architecture/view-objects.md`) to explicitly treat **attach/mount/name registration** as an authorization surface that must be capability-gated, transcript-visible, and sealable.
- Meta-hygiene: fixed a duplicate **EVID-2026-070** entry in the evidence index (renumbered the health seam to **EVID-2026-072**) and added an evidence seed for CapRPC oneway tests (**EVID-2026-073**).
- Bibliography additions: REF-QNX-RESMGR / REF-QNX-RESMGR-ATTACH / REF-QNX-PULSES / REF-QNX-MSGSENDPULSE.

## Revised33 (2026-02-25)
- Added a new high-leverage “operator reality check” seed: **Genode depot/Sculpt** as a microkernel-native example of integrity-protected packages with on-target update + routine rollback; threaded into OS lessons, D-FPM/D-ATOMICUPD guidance, and supply-chain notes.
- Updated RFC-0033 (D-FPM): incorporated Genode’s depot posture to reinforce “closure as artifact” and rollback-by-default as an ecosystem goal (not just a build-system preference).
- Updated RFC-0009 (D-COMP): added an explicit mapping to Fuchsia’s manifest/routing semantics (`use`/`offer`/`expose`) to keep the lesson while keeping CH-COMP v0 flat and validator-driven.
- Updated RFC-0060 (D-CHERI) and target-platform notes: anchored the CHERI track to **CheriBSD** deployment realities, Cambridge status notes, and a 2026 security analysis to keep the profile evidence-driven.
- Bibliography additions: REF-FUCHSIA-COMP-MANIFESTS, REF-FUCHSIA-CAPABILITIES, REF-GENODE-PKG/SCULPT/UPDATE-ROLLBACK, REF-CHERIBSD/CHERIBSD-CAMBRIDGE/CHERI-ANALYSIS-2026.

## Revised32 (2026-02-25)
- Refactored `docs/90-inspirations/os-lessons.md` into a compressed, theme-grouped map of high-leverage OS lessons; added Qubes qrexec/templates/clipboard + Solaris SMF as concrete, ops-proven precedents.
- RFC hygiene: strengthened `rfcs/0000-template.md` with explicit TCB/`unsafe` delta + profile gating + compatibility + abuse-case sections.
- Updated RFC-0003: fixed heading numbering (`13b`), added **13c** on Qubes-style cross-domain services + policy-as-data, and threaded Qubes template/clipboard references into atomic updates and portal workflows.
- Updated RFC-0017 supervision to include Solaris SMF as an additional reference point for declarative manifests + restarters.
- Bibliography additions: added REF-QUBES-QREXEC / REF-QUBES-TEMPLATES / REF-QUBES-TEMPLATE-IMPL / REF-QUBES-CLIPBOARD / REF-QUBES-SPLITGPG and REF-SOLARIS-SMF-BP / REF-SOLARIS-SMF-CREATESVC.

## Revised31 (2026-02-25)
- Added **RFC-0077** (D-TPROBE): a pinned **tracepoint descriptor manifest** (**CH-TPROBE v0**) that binds CH-TRACE probe IDs to ordered **field names/types** plus **redaction classes** for safe tooling and predicates.
- Wired D-TPROBE into the decision map, tracing mechanisms, and diagnostics stack; updated CH-TRACE/CH-TPRED docs to reference CH-TPROBE as the authoritative field schema table.
- Added assurance hooks for trace schema safety: invariant **I-TPROBE-1**, proof obligations **PO-TPROBE-VALIDATE/PO-TPROBE-MATCH**, evidence seed **EVID-2026-070**, and threat-model abuse case **AC-063** (schema confusion / redaction bypass).
- Finished D-ENC doc hygiene: removed remaining “canonical JSON is the signed bytes” wording and standardized CH-CLOCK/CH-ENTROPY/CH-RR/CH-RRBUNDLE schema docs on **canonical CBOR** (JSON authoring only; ADR-0003).

## Revised30 (2026-02-25)
- Fixed accidental duplication/corruption in `docs/20-assurance/proof-obligation-registry.md`.
- Added **RFC-0076** (D-OBSPOL): a pinned **observation export policy** artifact (**CH-OBSPOL v0**) to make diagnostics export rules explicit, bounded, and auditable.
- Added **CH-OBSPOL v0** schema doc and registered it in the schema registry; updated IF-OBS + exit-surface ledger to reference the policy seam.
- Added decision nodes **D-OBS** and **D-OBSPOL** to the decision map; introduced invariant **I-OBSPOL-1** and proof obligation hooks for policy validation/application.
- Expanded bibliography with Fuchsia diagnostics/inspect, Android bugreport, Apple sysdiagnose, and Microsoft WER dump references.

## Revised29 (2026-02-25)
- Added **RFC-0075** (D-INSPECT): an Inspect-inspired structured diagnostics tree contract plus **support/incident snapshot bundles** (shareable triage artifacts distinct from replay bundles).
- Added **CH-INSPECT v0** (inspect snapshot) and **CH-SNAPSHOT v0** (diagnostic snapshot bundle manifest) schema docs; registered both in the schema registry.
- Added a new engineering note doc: `docs/60-engineering/inspect-and-snapshots.md`.
- Wired **D-INSPECT** into the decision map, mechanisms, and diagnostics stack mapping.


## Revised28 (2026-02-25)
- Added **RFC-0074** (D-HEALTH): explicit health predicates + capability-gated boot-success commit for spoof-resistant “trial boot → commit on health” semantics.
- Added **CH-HEALTH v0** (health predicate) and **CH-HEALTHREC v0** (health record) schema docs; registered both in the schema registry.
- Tightened CH-BOOTSEL semantics to allow `pending.policy.health_pred_digest` binding and to recommend emitting/binding CH-HEALTHREC on commit.
- Extended **CH-COMP v0** with optional `ready` metadata to support a minimal one-shot readiness barrier (ReadyToken) used by health evaluation and supervision.
- Wired new invariants/POs/EVID seeds and updated AC-059 to include D-HEALTH invariants.

## Revised27 (2026-02-25)
- Added **RFC-0073** (D-TPRED): a bounded trace-predicate contract (**CH-TPRED v0**) for safe prefiltering of CH-TRACE streams (no in-kernel scripting).
- Added **CH-TRACEPROC v1** (schema) to optionally reference CH-TPRED filters in trace-processor configuration; kept v0 for compatibility.
- Threaded D-TPRED through the decision map, mechanisms, and RFC-0015; clarified that early profiles can choose portal-only filtering with optional source-prefilter later.
- Minor doc hygiene: fixed a tracing section typo in mechanisms.md.

## Revised26 (2026-02-25)
- D-IDL/D-APIEVO refinement: clarified canonical `idl_digest` policy + stable method ordinal rules; added `docs/60-engineering/idl-digest-and-ordinal-policy.md`.
- Added **CH-ORD v0** (interface ordinal manifest) + RFC-0072 to pin method name↔id mappings and gate ordinal reuse/collisions.
- Clarified open-interface posture: for CH-IFACE.openness=`open`, it is often preferable to omit `idl_digest` so `iface_digest` stays stable as methods are added; pin evolving IDL revisions via CH-ORD.
- Updated CapRPC schema doc + RFCs (0011/0026/0071) and inspirations notes accordingly.


This archive is intentionally “living”. This file records *high-level* deltas between packaged revisions.


## revised25 (2026-02-25)
- Added **RFC-0071** (D-APIEVO): a concrete interface-evolution posture (closed vs open), explicit unknown-op behavior, and first-class adapter/translator components to avoid “silent fallback” confused-deputy hazards.
- Added **CH-IFACE v0** (interface descriptor) and registered it in the schema registry; refined **CH-CAPRPC** wording so `iface_digest` refers to a **CH-IFACE** digest (not a raw IDL blob), keeping on-wire identity aligned with policy-relevant pins.
- Standardized CapRPC forward-compat framework errors (`UNKNOWN_IFACE` / `UNKNOWN_METHOD`) and documented policy guidance for open vs closed interfaces.
- Added assurance hooks for evolution safety: invariant **I-APIEVO-1**, proof obligation **PO-APIEVO-NOGUESS**, and evidence seed **EVID-2026-068**.
- Added an engineering checklist for safe evolution: `docs/60-engineering/interface-evolution-workflow.md`, and expanded the bibliography with Fuchsia (open protocols / unknown interactions), Cap'n Proto, Protobuf, and COM interface-identity references.


## revised24 (2026-02-25)
- Added **CH-BOOTSEL v0** (boot selector state) as a pinned schema to support A/B-style *trial boot then commit* semantics (bounded tries + automatic fallback to last-known-good).
- Extended **RFC-0051** (atomic system updates) with a concrete boot-health commit handshake, plus new assurance hooks: invariant **I-ATOMICUPD-3** and proof obligations **PO-BOOTSEL-VALIDATE/PO-ATOMICUPD-COMMIT**.
- Threaded CH-BOOTSEL through IF-BOOT and CH-BOOT artifact roles (`boot_selector`) so selection/rollback decisions are auditable in transcripts and boot manifests.
- Added threat-model abuse case **AC-059** (boot-success marking bypass) and evidence seeds **EVID-2026-066, EVID-2026-067** for selector state-machine and negative-test plans.
- Refactored RFC-0051 field naming to align with CH-UPD (`target_root_digest`) and extended the bibliography with Android/ChromeOS/Fuchsia update references for future evidence-driven iteration.

## revised23 (2026-02-25)
- Closed D-ENC loose ends: standardized CH-ATTR + CH-HARDEN schemas on **canonical CBOR** as the normative signed bytes, with an explicit "JSON is authoring only" rule (JCS/RFC 8785) and deterministic transcode guidance.
- Added **ADR-0003** (D-ENC) and tightened `encoding-policy.md` + decision map D-ENC to record the canonical-bytes decision and prevent future hash/signature ambiguity.
- Added `docs/30-architecture/capability-rights-registry.md` (v0) to keep capability classes + rights bits explicit and UI-renderable (CH-CAPDIFF), including an early exec/execmod seam.
- Refactored **RFC-0059** to name the exec-authority capability (`VmExec`) and adopt a "two-key" execute gate (mapping authority + executable backing bytes), with concrete inspiration from Zircon/Fuchsia.
- Extended OS lessons + bibliography with Zircon/Fuchsia execute-gating references (`zx_vmar_map`, `zx_vmo_replace_as_executable`) and added RFC 8785 to canonicalization references.
- Hardened the meta-tooling: archive lint now fails on unresolved **TBD** placeholders in prose.

## revised22 (2026-02-25)
- Deepened the **deterministic replay** story into a concrete, ecosystem-ready "time travel debugging" target: expanded the rr lesson (OS lessons) and RFC-0013 with explicit user-space tooling goals (reverse execution, bisection/search-through-time, queryable traces) and aligned it with D-NONDET + D-CHKPT as optional accelerators.
- Extended the deterministic replay bibliography with practical and research references for "time-travel" workflows and concurrency determinism (Microsoft TTD, FReD, Pernosco dataflow, Kendo) to keep future scope expansions evidence-driven.
- Added `docs/60-engineering/diagnostics-stack.md` to clarify the artifact layering (CH-LOG vs CH-TRACE vs CH-RR vs CH-CKPT) and the safety rules for capture/export/minimization (explicit authority + redaction + boundedness).
- Extended CH-RRBUNDLE guidance to allow an optional `rr_index` payload as a non-authoritative acceleration structure for fast reverse queries/minimization without changing correctness semantics.
- Updated roadmap + decision map + glossary to reflect time-travel debugging as a first-class *ecosystem* goal layered over the replay boundary.


## revised21 (2026-02-25)
- Tightened the **compatibility-runtime story**: expanded D-RUMPK and **RFC-0036** with explicit comparisons to Drawbridge-style libOS/picoprocess compartments and gVisor-style userspace kernels, and clarified that any large ABI facade must stay outside the privileged core behind an explicit, fail-closed membrane.
- Added assurance hooks for compatibility runtimes: invariants **I-COMPAT-1/I-COMPAT-2** and proof obligations **PO-COMPAT-CLOSESET/PO-COMPAT-NOAMBIENT**.
- Extended **RFC-0003** with a **sealed appliance / unikernel-style deployment profile** seed (mapped to D-SEAL/D-FPM/D-BOOT) and a Drawbridge seed as an alternative future compatibility runtime.
- Updated inspirations + glossary to capture the key lessons and terminology (libOS, picoprocess, userspace kernel, unikernel).
- Added bibliography references: **REF-DRAWBRIDGE-ASPL11**, **REF-DRAWBRIDGE-POSIXPICO**, **REF-GVISOR-COST**, **REF-UNIKERNELS-ASPL13**, **REF-MIRAGE-PAPERS**.

## revised20 (2026-02-24)
- Added **RFC-0070**: Sealed secrets + vault service (D-VAULT): standardizes a user-space vault seam for credentials/opaque secrets with pinned policy (**CH-SECRETPOL**) and durable references (**CH-SECRETREF**) so CapStore persists *references*, not secret blobs, and high-risk releases can be consent/receipt- or attestation-gated without expanding the privileged core.
- Added schemas **CH-SECRETPOL v0** and **CH-SECRETREF v0** and registered them in the schema registry; extended mechanisms/roadmap/glossary with the vault seam.
- Extended threat model with abuse case **AC-058** and assurance hooks with invariants **I-VAULT-1/I-VAULT-2** and proof obligations **PO-SECRETPOL-ENF/PO-SECRETREF-PIN**.
- Added bibliography/lessons references for mainstream keychain/keystore patterns and Plan 9 secstore (Apple Keychain, Apple Platform Security keychain data protection, Android Keystore + key attestation, Plan 9 secstore).

## revised19 (2026-02-24)
- Added **RFC-0069**: Capability diffs for consent + receipts (CH-CAPDIFF, D-EXPLAIN): a typed, bounded “authority diff” object that the trusted UI can show and then bind into CH-VOL + CH-RECEIPT, reducing grant-creep/confused-deputy risk.
- Added schema **CH-CAPDIFF v0** (capability diff summary) and registered it in the schema registry; updated CH-RECEIPT to prefer CH-CAPDIFF digests.
- Strengthened assurance hooks for D-EXPLAIN: added abuse case **AC-057**, invariant **I-EXPLAIN-4**, and proof obligation **PO-CAPDIFF-REDACT**.
- Extended OS lessons + bibliography with concrete “powerbox/portal” references (xdg FileChooser, Sandstorm Powerbox, Plash powerbox) and secure UI design guidance (Yee 2002).

## revised18 (2026-02-24)
- Added **RFC-0068**: Wasm trace-processing pipelines (D-TRACEPROC): a user-space “programmable observability” seam that runs untrusted Wasm processors over CH-TRACE streams to produce bounded, redaction-safe aggregates without introducing an in-kernel scripting VM.
- Added schema **CH-TRACEPROC v0** (trace-processing request) and wired it into the schema registry.
- Threaded D-TRACEPROC through the decision map, mechanisms, OS lessons, roadmap, threat model (AC-056), invariants (I-TRACEPROC-1), and proof obligations (PO-TRACEPROC-SBX/PO-TRACEPROC-BOUNDS).

## revised17 (2026-02-24)
- Added **RFC-0067**: Capability crypto services + non-exportable key handles (D-CRYPTOSVC): standardizes “keys as capabilities” so long-lived secrets stay in a small user-space crypto provider (often the auth agent) and clients receive operation-only handles.
- Added schemas **CH-KEYPOL v0**, **CH-KEYREF v0**, and **CH-CRYPTOAUDIT v0**, wired into the schema registry for reviewable policy pins, durable key references (CapStore stores refs, not secrets), and redaction-safe crypto audit entries.
- Threaded D-CRYPTOSVC through the decision map, mechanisms, OS lessons, roadmap, invariants (I-CRYPTO-1/2), and proof obligations (PO-CRYPTOAUDIT-REDACT / PO-CRYPTOPOL-ENF); tightened AC-015 evidence targets to use pinned policy + audit payloads.

## revised16 (2026-02-24)
- Added **RFC-0066**: Capability leases + limited-use proxies (D-LEASE): standardizes time-/use-limited proxy capabilities as a user-space pattern for “temporary authority” at portals/gateways.
- Added **CH-CAPLEASE v0** schema and wired it into the schema registry for audit/receipt binding (no secrets, redaction-friendly).
- Threaded D-LEASE through decision map, capability semantics, mechanisms, roadmap, OS lessons, invariants (I-LEASE-1..3), proof obligations (PO-LEASE-VALIDATE/ENF/NOAMP), and threat model (AC-055).
- Refactored schema naming: **CH-LEASE v0 → CH-IOLEASE v0** for device/I/O leases to reduce ambiguity; recorded in deprecations and updated RFC-0045 + references.

## revised15 (2026-02-24)
- Added **RFC-0065**: Orthogonal persistence + capability store (D-PERSIST): an optional user-space CapStore with durable named roots, explicit durability authority, and rollback/resurrection defenses.
- Added **CH-CAPSTORE v0** schema and wired it into the schema registry.
- Threaded D-PERSIST through decision map, abstract machine, mechanisms, roadmap, threat model, abuse cases (AC-054), invariants (I-PERSIST-1..3), and proof obligations (PO-CAPSTORE-VALIDATE, PO-PERSIST-NOAMP, PO-PERSIST-ROLLBACK).
- Expanded bibliography and OS lessons with CapROS + orthogonal persistence references.

## revised14 (2026-02-24)
- Added **RFC-0064**: Confidential-computing profile (D-CC): an optional deployment extension that binds CC attestation evidence to our CH-BOOT/CH-PROV digests without importing CC protocols or policy into the privileged core.
- Tightened deployment-profile wording for CC mode (attest-only vs enforced isolation) and added decision-map cross-link for D-CC.
- Expanded assumptions and bibliography for CC/attestation with RATS (RFC 9334) and platform evidence references (SNP/TDX/CCA).
- Added a new abuse case **AC-053** covering CC attestation replay / wrong-state secret release failure modes.

## revised13 (2026-02-24)
- Added **RFC-0063**: Nondeterminism capabilities (Clock + Entropy handles) (D-NONDET): makes time/entropy explicit authority for replay, sandboxing, and timer hygiene.
- Added **CH-CLOCK v0** and **CH-ENTROPY v0** schemas; threaded the seam into D-RR and D-WASM where “no ambient time/entropy” was already required.
- Added **D-NONDET** to the decision map; added invariants/proof obligations (I-NONDET-1..4, PO-NONDET-NOAMBIENT, PO-CLOCK-VALIDATE, PO-ENTROPY-VALIDATE, PO-NONDET-RR) and a new abuse case AC-052.
- Extended OS lessons + bibliography with WASI clocks, OpenBSD getentropy/arc4random, and high-resolution timer policy/attack references.

## revised12 (2026-02-24)
- Added **RFC-0062**: Hardware memory tagging + hardening profiles (D-MEMTAG): an optional track that treats hardware tagging (e.g., Arm MTE) as a first-class hardening seam for unsafe/legacy compartments, pinned as data via **CH-HARDEN v0**.
- Added **CH-HARDEN v0** schema and threaded `harden_profile` artifact binding guidance into CH-BOOT; added invariants/proof obligations (I-HARDEN-1, I-MEMTAG-1, PO-HARDEN-BIND, PO-MEMTAG-ENF) and a new abuse case AC-051.
- Updated decision map, roadmap, OS lessons, and bibliography with MTE references (Android + Linux).

## revised11 (2026-02-24)
- Added **RFC-0061**: Bootstrappable toolchains + diverse double-compiling (D-BOOTSTRAP / D-DDC): treats toolchain trust as an explicit seam, binding bootstrap posture + optional DDC gates into provenance without expanding runtime TCB.
- Added **D-BOOTSTRAP** and **D-DDC** to the decision map, and threaded the seam into supply-chain guidance, OS lessons, and roadmap.
- Expanded supply-chain bibliography with references for “trusting trust”, DDC, and bootstrappable builds (Guix full-source bootstrap, stage0).

## revised10 (2026-02-24)
- Added **RFC-0060**: CHERI-ready compartmentalization profile (D-CHERI): an optional hardware-capability track for hardening unsafe/legacy compartments without entangling Phase‑1 bring-up.
- Added **D-CHERI** to the decision map, and threaded the track into target platform strategy, OS lessons, roadmap, and bibliography.
- Expanded CHERI bibliography: purecap vs hybrid definitions, Morello evaluation context, and CHERIoT (embedded).

## revised9 (2026-02-24)
- Added **RFC-0059**: sealed code spaces + dynamic code loading posture (D-DYNCODE): W^X default, capability-gated execmod, and profile-scoped exceptions.
- Added **D-DYNCODE** to the decision map and threaded the posture into mechanisms + threat model + roadmap.
- Extended OS lessons with: Singularity (contracts + manifest discipline), OpenBSD (W^X as default), Barrelfish (multikernel + SKB), Project Oberon (ruthless simplicity).
- Added bibliography refs for W^X and JIT attack surfaces (OpenBSD 3.3 W^X, OpenBSD kernel W^X talk, JITDefender, ACM “War on JITs”), plus Project Oberon.

## revised8 (2026-02-24)
- See prior revision notes in commit history or packaging metadata (if available).
