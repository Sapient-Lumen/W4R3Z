# Start here

Current revision: `rev0099` — verification-intake receipts, proof-drift guards, and metadata lineage audit.

Load these first:

1. `README.md`
2. `docs/README.md`
3. `docs/20-assurance/governance-verification-intake-receipt-v0.md`
4. `docs/30-architecture/verification-intake-proof-drift-guards-and-metadata-lineage-audit.md`
5. `docs/30-architecture/specimen-flow-96-verification-intake-proof-drift-guards-and-metadata-lineage-audit.md`

Rev0099's working rule: external proof intake can record verified, failed, absent, or conflicted proof; it is not remedy completion, quarantine clearance, export, repair, status update, action, or authority.

Latest pass surfaces:

- `docs/00-meta/research-synthesis-2026-05-26-pass-xcix.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-26-pass-xcix.md`
- `docs/30-architecture/specimen-flow-96-verification-intake-proof-drift-guards-and-metadata-lineage-audit.md`

## What changed in rev0099

Ward added verification-intake receipts downstream of remediation closure. The new receipt can record no-remediation recheck, verified external proof, failed external proof, absent proof, or conflicting proof while sustaining quarantine and source-replay requirements where needed. It cannot clear quarantine, complete remedy, execute rollback, export evidence, repair semantics, mutate status pointers, or grant authority.

## New in rev0099

- `schemas/governance-verification-intake-receipt.v0.json`
- `tools/check_governance_verification_intakes.py`
- `fixtures/governance-verification-intake/` with five positive and twenty-two negative fixtures
- `tools/check_metadata_lineage_integrity.py`
- `docs/00-meta/metadata-lineage-audit-refactor-2026-05-26-pass-xcix.md`

## What changed in rev0098

Ward added remediation-closure receipts downstream of rollback-remediation. The new receipt can confirm no-remediation/no-op closure, close rollback review while sustaining quarantine, acknowledge a remediation handoff while requiring external proof, or escalate unavailable-observation holds. It cannot execute rollback, complete remedy, clear quarantine, export evidence, repair semantics, mutate status pointers, or grant authority.

## New in rev0098

- `schemas/governance-remediation-closure-receipt.v0.json`
- `tools/check_governance_remediation_closures.py`
- `fixtures/governance-remediation-closure/` with five positive and twenty-one negative fixtures
- `tools/check_tool_runbook_integrity.py`
- `docs/00-meta/tool-runbook-audit-refactor-2026-05-26-pass-xcviii.md`

## What changed in rev0097

Ward added rollback-remediation receipts downstream of outcome observations. The new receipt can close no-remediation-needed for matched/no-op outcomes, hold unavailable observations, maintain quarantine for mismatches, open rollback review, or request a remediation handoff. It cannot execute rollback, repair, remedy, export, learning use, source mutation, or status-pointer mutation.

## New in rev0097

- `schemas/governance-rollback-remediation-receipt.v0.json`
- `tools/check_governance_rollback_remediations.py`
- `fixtures/governance-rollback-remediation/` with five positive and twenty negative fixtures
- `tools/check_schema_catalog_integrity.py`
- `docs/00-meta/schema-catalog-audit-refactor-2026-05-25-pass-xcvii.md`

## What changed in rev0096

Ward added outcome-observation receipts downstream of use-execution. The new receipt can confirm an observed public display/internal review, confirm a no-op hold, quarantine a mismatch with rollback-review-required, or hold when observation is unavailable. The pass also adds a fixture-catalog checker so the growing refusal harness cannot silently drift.

## New in rev0096

- `schemas/governance-outcome-observation-receipt.v0.json`
- `tools/check_governance_outcome_observations.py`
- `fixtures/governance-outcome-observation/` with five positive and twenty negative fixtures
- `tools/check_fixture_catalog_integrity.py`
- `docs/00-meta/fixture-catalog-audit-refactor-2026-05-25-pass-xcvi.md`

## What changed in rev0095

Ward now records post-gate use-execution receipts so a downstream display, internal review, hold, refusal, or quarantine is checked against the source reuse gate's purpose, effect, recipient, projection policy, and window.

Latest pass surfaces:

- `docs/00-meta/research-synthesis-2026-05-25-pass-xcv.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xcv.md`
- `docs/30-architecture/specimen-flow-92-use-executions-actual-effect-guards-and-doc-index-audit.md`

## New in rev0095

- `schemas/governance-use-execution-receipt.v0.json`
- `tools/check_governance_use_executions.py`
- `fixtures/governance-use-execution/` with five positive and twenty negative fixtures
- `tools/check_doc_index_integrity.py`
- `docs/00-meta/doc-index-audit-refactor-2026-05-25-pass-xcv.md`


## What changed in rev0094

Ward added reuse-gate receipts: a narrow, consequence-bound receipt that sits after receiver convergence and before any display, internal review, export, repair, remedy, action, or learning-loop reuse. The gate can allow only low-risk display/internal review, hold export for an evidence-release receipt, refuse high-consequence reuse, or quarantine receiver gaps. The checker registry was also refactored so schema ids and paths are audited.

## New in rev0094

- reuse-gate schema, checker, and fixtures;
- consequence-scope digests for requested reuse;
- explicit display/internal-review/hold/refuse/quarantine states;
- schema metadata in the governance checker registry;
- pass XCIV research, evaluation, threat model, architecture note, audit note, and specimen flow 91.

Read next: `research-synthesis-2026-05-25-pass-xciv.md`, `slopos-companions-evaluation-2026-05-25-pass-xciv.md`, and `specimen-flow-91-reuse-gates-consequence-binding-and-schema-audit.md`.

## What changed in rev0093

Ward now has a receiver-convergence layer. A single receiver can reconcile its notified consumers while another receiver lags, observes a divergent status-channel cut, duplicates an old observation, or forks. Rev0093 requires source reconciliation byte checks, receiver-set digests, overlap-consumer digests, status-channel cut digests, explicit lag/hold/quarantine states, and no-authority projection before multiple receivers can be treated as converged enough for replay. The pass also adds a registry-integrity checker so governance validators and fixture families cannot silently fall out of `make check`.

## New in rev0093

Read the latest research pass, evaluation pass, specimen, assurance doc, threat model, architecture note, and audit/refactor note first:

- `docs/00-meta/research-synthesis-2026-05-25-pass-xciii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xciii.md`
- `docs/30-architecture/specimen-flow-90-receiver-convergence-overlap-cuts-and-registry-integrity.md`
- `docs/20-assurance/governance-receiver-convergence-receipt-v0.md`
- `docs/10-threat-model/receiver-convergence-threat-model.md`
- `docs/30-architecture/receiver-convergence-overlap-cuts-and-registry-audit.md`
- `docs/00-meta/registry-integrity-audit-refactor-2026-05-25-pass-xciii.md`

## What changed in rev0092

Ward now has a signal-notification reconciliation layer. A notification can prove fanout and acknowledgments, but rev0092 requires per-consumer refresh observations and checked recertification references before any notified cache is treated as refreshed. Pending, dead-lettered, duplicate, and conflict-held consumers remain explicit gaps. This pass also audits/refactors the checker suite with a shared utility module and a registry-backed suite runner.

## New in rev0092

Read the latest research pass, evaluation pass, specimen, and audit/refactor note first:

- `docs/00-meta/research-synthesis-2026-05-25-pass-xcii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xcii.md`
- `docs/30-architecture/specimen-flow-89-signal-notification-reconciliation-refresh-proofs-and-checker-registry.md`
- `docs/20-assurance/governance-signal-notification-reconciliation-receipt-v0.md`
- `docs/10-threat-model/signal-notification-reconciliation-threat-model.md`
- `docs/30-architecture/signal-notification-reconciliation-refresh-proofs-and-checker-registry.md`
- `docs/00-meta/checker-suite-audit-refactor-2026-05-25-pass-xcii.md`

## What changed in rev0091

Ward now has a downstream signal-notification layer for proving fanout obligations after signal ingestion. A notification receipt binds the source signal-ingestion bytes, signal event key, affected consumer set digest, notification payload digest, delivery attempts, acknowledgments, retries, dead letters, stale-consumer quarantine, and no-authority fences. Notification is not recertification; acknowledgment is not refresh; dead-lettering is not delivery.

## New in rev0091

Read the latest research pass, evaluation pass, and specimen first:

- `docs/00-meta/research-synthesis-2026-05-25-pass-xci.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xci.md`
- `docs/30-architecture/specimen-flow-88-signal-notification-stale-consumer-acks-and-dead-letter-fences.md`
- `docs/20-assurance/governance-signal-notification-receipt-v0.md`
- `docs/10-threat-model/signal-notification-and-stale-consumer-threat-model.md`
- `docs/30-architecture/signal-notification-stale-consumer-acks-and-dead-letter-fences.md`

## What changed in rev0090

Ward now has a receiver-local signal-ingestion layer for refresh, revocation, status, projection, successor, branch, and quarantine signals. A signal is bound to source recertification bytes, source/id event key, subject/cache digests, duplicate window, watermark, conflict set, and follow-up requirement before it can request recertification or cache invalidation.

## New in rev0090

Read the latest research pass, evaluation pass, and specimen first:

- `docs/00-meta/research-synthesis-2026-05-25-pass-xc.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xc.md`
- `docs/30-architecture/specimen-flow-87-signal-ingestion-receiver-observations-and-race-guards.md`
- `docs/20-assurance/governance-signal-ingestion-receipt-v0.md`
- `docs/10-threat-model/signal-ingestion-and-receiver-observation-threat-model.md`
- `docs/30-architecture/signal-ingestion-receiver-observations-and-race-guards.md`

## What changed in rev0089

Ward now has a non-authority recertification layer for cached dispute-resolution receipts. A recovered head can be displayed only after source-resolution replay, cache-subject digest check, status/refresh-channel recheck, projection/owner/successor/branch/follow-up checks, and next-recheck scheduling; stale caches are invalidated, quarantined, downgraded to history, or held for recheck.

## New in rev0089

Read the latest research pass, evaluation pass, and specimen first:

- `docs/00-meta/research-synthesis-2026-05-24-pass-lxxxix.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-24-pass-lxxxix.md`
- `docs/30-architecture/specimen-flow-86-recertification-receipts-cache-invalidation-and-refresh-signals.md`
- `docs/20-assurance/governance-recertification-receipt-v0.md`
- `docs/10-threat-model/recertification-cache-invalidation-threat-model.md`
- `docs/30-architecture/recertification-receipts-cache-invalidation-and-refresh-signals.md`

## New in rev0088

- `schemas/governance-dispute-resolution-receipt.v0.json`
- `docs/20-assurance/governance-dispute-resolution-receipt-v0.md`
- `docs/30-architecture/dispute-resolution-current-head-recovery.md`
- `docs/10-threat-model/dispute-resolution-and-current-head-recovery-threat-model.md`
- `tools/check_governance_dispute_resolutions.py`
- four positive dispute-resolution fixtures and seventeen negative fixtures

## New in rev0087

- `ward.governance.chain-integrity-receipt.v0` records an ordered release/follow-up/transfer lineage without becoming authority.
- Canonical heads are current status/recheck pointers only.
- Forked branches publish `no_current_head` and hold reuse.
- Public fork projection remains bucketed/minimized.
- `tools/check_governance_chain_integrity.py` validates four positive and fourteen negative fixtures.

Latest pass surfaces: `research-synthesis-2026-05-23-pass-lxxxvii.md`, `slopos-companions-evaluation-2026-05-23-pass-lxxxvii.md`, and `specimen-flow-84-chain-integrity-dispute-forks-and-canonical-heads.md`.

## New in rev0086

- `schemas/governance-succession-transfer-receipt.v0.json` defines the succession/transfer receipt shape.
- `tools/check_governance_succession_transfers.py` rejects missing successor acceptance, old status channels left active, scope expansion, successor-as-authority, source digest drift, pending successor reuse, public steward-identity leakage, dropped forbidden effects, high-consequence transfer actions, predecessor continuing authority, unrotated status pointers, purpose drift, and missing no-authority labels.
- Four positive fixtures exercise public recipient-contact transfer, revoked-release status-channel rotation, restricted steward successor held for recheck, and projection-policy steward transfer after sealed-omission correction.
- Fourteen negative fixtures keep successor labels and status-channel changes from becoming hidden authority or mutable export state.

## What changed in rev0085

Ward now records the lifecycle of released governance evidence after the export leaves the cube boundary. A follow-up receipt can acknowledge, revoke, correct, quarantine, or refuse reuse of a released bundle without editing the original release receipt or granting new authority.

Latest pass surfaces: `research-synthesis-2026-05-22-pass-lxxxv.md`, `slopos-companions-evaluation-2026-05-22-pass-lxxxv.md`, and `specimen-flow-82-release-followups-recipient-acks-and-stale-bundle-quarantine.md`.

## New in rev0085

- `schemas/governance-evidence-release-followup-receipt.v0.json` defines the release follow-up receipt shape.
- `tools/check_governance_evidence_release_followups.py` rejects source digest drift, state mismatch, missing notice, acknowledgment-as-authority, expired-current laundering, missing status pointers, public leakage, dropped forbidden effects, high-consequence follow-up, channel mismatch, original-release mutation, and reuse-without-refresh.
- Five positive fixtures exercise recipient acknowledgment, expired-release revocation, sealed-omission correction, restricted-bundle quarantine, and held-recheck reuse refusal.
- Fourteen negative fixtures keep post-release lifecycle signals from becoming hidden authority or mutable export state.

## What changed in rev0084

Ward now has an evidence-release closure after search continuity. A governance export, restricted review bundle, audit snapshot, or held-recheck notice must bind source receipt digest, selection digest, query/projection basis, recipient class, purpose, retention horizon, refresh/revocation channel, field allowlist/denylist, sealed-omission disclosure, and no-authority watermark.

Latest pass surfaces: `research-synthesis-2026-05-22-pass-lxxxiv.md`, `slopos-companions-evaluation-2026-05-22-pass-lxxxiv.md`, and `specimen-flow-81-evidence-release-recipient-scope-and-export-guards.md`.

## New in rev0084

- `schemas/governance-evidence-release-receipt.v0.json` defines the evidence-release receipt shape.
- `tools/check_governance_evidence_release_receipts.py` rejects source digest drift, public sealed leaks, exact public hidden counts, missing recipient/purpose binding, weak-state upgrades, dropped forbidden effects, raw partner fragments in public release, missing no-authority labels, expired releases, and high-consequence release actions.
- Four positive fixtures exercise public owner-routing release, public sealed-omission release, restricted review bundle release, and held recheck notice release.
- Sixteen negative fixtures keep detached exports and review bundles from becoming hidden authority, existence oracles, or stale reusable permission slips.

## What changed in rev0083

Ward now has a search-continuity closure over paginated and long-running governance search. Page two must prove it still shares the same query, projection policy, owner-map epoch, and packet-compaction watermark; otherwise the receipt holds, recheckpoints, or starts a new search instead of silently continuing. Sealed omissions can be disclosed only through safe modes such as presence-only, bucketed range, or noisy count with budget evidence.

Latest pass surfaces: `research-synthesis-2026-05-22-pass-lxxxiii.md`, `slopos-companions-evaluation-2026-05-22-pass-lxxxiii.md`, and `specimen-flow-80-search-continuity-sealed-omissions-and-cursor-drift.md`.

## New in rev0083

- `schemas/governance-search-continuity-receipt.v0.json` defines the search-continuity receipt shape.
- `tools/check_governance_search_continuity_receipts.py` rejects cursor drift, query mutation, projection-policy drift, owner-map drift, compaction replay collapse, public exact sealed counts, sealed detail leakage, hidden omissions, noisy-count theater, raw authority counts, and high-consequence continuation effects.
- Five positive fixtures exercise same-snapshot page two, projection-policy hold, public bucketed sealed omission, restricted exact sealed review, and packet-compaction recheckpoint.
- Twelve negative fixtures keep pagination and sealed omissions from becoming hidden authority or existence oracles.

## What changed in rev0082

Ward now has a batch/search closure over governance decision consumer receipts. A search result or batch summary must keep member state, replay status, projection class, downgrade reasons, and forbidden-effect fences visible instead of collapsing route-only, current consequence-grade, restricted, and historical-only rows into one green result.

Latest pass surfaces: `research-synthesis-2026-05-22-pass-lxxxii.md`, `slopos-companions-evaluation-2026-05-22-pass-lxxxii.md`, and `specimen-flow-79-batch-search-receipts-mixed-state-and-projection-joins.md`.

## New in rev0082

- `schemas/governance-batch-search-receipt.v0.json` defines the batch/search receipt shape.
- `tools/check_governance_batch_search_receipts.py` rejects green-badge laundering, member-state upgrades, dropped forbidden-effect unions, public leakage of restricted members, missing gap disclosure, unbound cursors, raw authority counts, digest drift, and aggregate high-consequence effects.
- Four positive fixtures exercise mixed internal search, public owner-routing search, all-current batch summary, and restricted break-glass plus historical receipt batching.
- Twelve negative fixtures keep aggregation, search, pagination, and projection joins from turning consumer receipts into hidden authority.

## What changed in rev0081

Ward now has a consumer-side closure over governance decision events. A downstream cube must record a governance decision consumer receipt before an event can be rendered, retained, rechecked, attached, or preserved as history. The receipt keeps event digest parity, mirrors packet refs, preserves forbidden effects, prevents state upgrade, and records replay/compaction posture.

Latest pass surfaces: `research-synthesis-2026-05-22-pass-lxxxi.md`, `slopos-companions-evaluation-2026-05-22-pass-lxxxi.md`, and `specimen-flow-78-consumer-receipts-replay-diffs-and-compaction-guards.md`.

## New in rev0081

- `schemas/governance-decision-consumer-receipt.v0.json` defines the consumer receipt shape.
- `tools/check_governance_decision_consumers.py` rejects digest drift, weak-state promotion, dropped forbidden effects, unsafe compaction, packetless action, projection leaks, state upgrades, replay-diff mismatch, and missing no-authority labels.
- Five positive fixtures exercise Helm, Harbor, Schell, SlopOS, and historical downgrade after compaction.
- Ten negative fixtures keep event consumers from turning portable decision receipts into hidden authority.

## Rev0099 additions

Start with `docs/20-assurance/governance-verification-intake-receipt-v0.md`, then read `docs/30-architecture/verification-intake-proof-drift-guards-and-metadata-lineage-audit.md` and `docs/00-meta/metadata-lineage-audit-refactor-2026-05-26-pass-xcix.md`.
