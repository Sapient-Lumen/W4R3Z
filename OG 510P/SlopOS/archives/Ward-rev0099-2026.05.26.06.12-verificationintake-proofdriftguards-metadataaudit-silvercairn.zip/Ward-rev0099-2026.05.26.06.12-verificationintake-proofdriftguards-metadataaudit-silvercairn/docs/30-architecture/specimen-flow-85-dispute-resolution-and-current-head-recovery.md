# Specimen flow 85 — dispute resolution and current-head recovery

## Situation

A public owner-routing chain previously produced a `fork_detected_hold`: two status-channel branches claimed to be current. A restricted review chain previously produced `successor_pending_recheck`: the old steward was closed, but successor acceptance had not yet been proven. A sealed-omission public chain was minimized for history.

Consumers now need to know whether the chain is still held, whether a current status pointer has been safely recovered, or whether the result is historical-only.

## Bad collapse

The bad implementation rewrites the old chain-integrity receipt, selects the latest branch by timestamp, or renders a green “resolved” badge. It hides the losing branch, lets an old status channel keep working, leaks branch/conflict details publicly, or treats the recovered pointer as action authority.

This collapses dispute resolution, branch disposition, notification, currentness, projection, and authority.

## Ward residue

The flow introduces `ward.governance.dispute-resolution-receipt.v0`.

It records:

- source chain id, path, byte digest, and source chain digest;
- source chain observed state, release, recipient, purpose, source item, projection policy, fork state, and branch count;
- observed branch ids and branch-set digest;
- selected branch only when a current status head is recovered;
- branch disposition for every observed branch;
- resolver independence and conflict disclosure;
- successor acceptance/current-status recheck when recovering a head;
- old-channel invalidation and recipient notification;
- public branch minimization;
- no-authority watermark;
- forbidden-effect preservation.

## Safe paths

- A public status-channel fork becomes `current_head_recovered`, but reuse still requires refresh and source-packet replay.
- A restricted successor-pending chain becomes `current_head_recovered` only after successor acceptance and current recheck.
- A disputed public chain can remain `quarantine_sustained` with no current head.
- A sealed public chain can become `historical_resolution_recorded` without becoming current evidence.

## Rejected paths

Ward rejects source-chain digest drift, already-canonical source chains, missing source-chain digest, selected branches not observed, branch digest mismatch, losing-branch reuse, public sealed-branch leaks, exact public hidden counts, missing recipient notice, missing no-authority labels, high-consequence resolution effects, dropped forbidden fences, purpose drift, old-channel reuse, source-chain mutation, current-head recovery without successor acceptance, and quarantine states that publish a current head.

## Product line

Recovered current head:

> “Dispute resolved. Current status pointer recovered. Not authority. Refresh and replay the source packet before reuse.”

Sustained hold:

> “Dispute unresolved or quarantine sustained. No current head. Do not reuse this release.”
