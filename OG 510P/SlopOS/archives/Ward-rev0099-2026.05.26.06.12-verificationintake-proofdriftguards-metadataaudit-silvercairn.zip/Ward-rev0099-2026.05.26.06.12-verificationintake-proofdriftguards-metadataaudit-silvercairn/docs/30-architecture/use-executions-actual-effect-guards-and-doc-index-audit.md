# Use executions, actual-effect guards, and doc index audit

Rev0095 adds the first post-gate execution surface.

A reuse gate says whether a bounded request may be displayed, reviewed, held, or refused. That is still not enough. Ward also needs to record the concrete effect that followed the gate. Otherwise a downstream renderer, export path, or action bridge can say “the gate allowed reuse” while performing a different effect.

## Design split

Use-execution receipts have five safe outcomes:

1. **public display executed** — only a minimized public status surface rendered, refresh still required;
2. **internal review executed** — an internal review replay rendered, refresh still required;
3. **evidence release held** — no release occurred because a release receipt is required;
4. **high consequence refused** — no repair/remedy/action occurred because fresh authority is required;
5. **receiver gap quarantined** — no display occurred while receiver convergence remains incomplete.

## Why this is not a consumption grant

The receipt proves actual-effect containment. It does not make the gate stronger and it does not authorize future use. The source gate remains immutable, the source packet replay requirement remains visible, and status pointers cannot be updated by execution evidence.

## Audit/refactor

This pass adds `tools/check_doc_index_integrity.py`, which binds `docs/README.md`, `README.md`, and `START_HERE.md` back to `REVISION-RECEIPT.json` and `SURFACE-STATUS.json`. This catches stale “latest pass” documentation after the checker family grows.
