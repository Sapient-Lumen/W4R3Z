# Specimen flow 49 — calendar binding, timezone witness, and boundary drift alarm

Goal: keep Ward honest when one repeated trust question becomes a daily/weekly/monthly surface whose bucket membership depends on calendar family, time zone, or bucket origin.

## Scenario
A team promotes a recurring question over trust-significant events, such as “weekly count of provenance verdict narrowings” or “daily suspicious-custody alarms.” The same raw facts are later reviewed in three ways:
1. an internal UTC-bucketed operational chart;
2. a user-facing local-civil chart in `America/Los_Angeles`;
3. an audit rerun grouped by ISO week instead of Sunday-first week.

Without explicit calendrical residue, all three surfaces can borrow the same title while quietly changing which events belong to which bucket.

## Flow
1. Before promotion, Ward forces an explicit **calendar binding** for the recurring surface: bucket width, calendar family/week rule, and bucket origin/alignment.
2. If the surface groups in local civil time, Ward emits a **timezone witness** saying which time zone or civil-time assumption the bucketing used.
3. If the same recipe or query contract reruns under a different week-start rule, ISO/Gregorian boundary, time zone, or bucket origin, Ward raises a **boundary drift alarm** instead of flattening the change into ordinary fact drift.
4. If a DST transition makes a civil bucket contain an irregular amount of real elapsed time, Ward keeps the calendar binding and timezone witness visible rather than pretending all buckets were fixed-duration intervals.
5. If a maintained derivative is later promoted, the published surface still carries basis pin, calendar binding, timezone witness, and any boundary drift alarm that affected comparability.

## Nouns under pressure
- **calendar binding**
- **timezone witness**
- **boundary drift alarm**

## Separations preserved
- raw event time versus grouped calendar bucket;
- UTC/default bucket grid versus local-civil bucket grid;
- Sunday-first week versus ISO week;
- changed bucket semantics versus changed underlying facts.

## Why this earns space in Ward
Repeated trust questions are especially vulnerable to flattering labels like “daily” or “weekly.” If calendar semantics stay implicit, one pretty trend line can hide changed bucket membership, DST irregularity, or different week-year rules. Ward should therefore keep calendrical grouping visibly weaker than the raw facts and visibly weaker than the downstream decisions that consume the grouped result.

## Promotion note
Do not promote these nouns beyond guidance unless a later specimen shows the same recurring question surviving at least one UTC-vs-local regrouping, one week-rule change, and one DST or year-boundary review without hiding which bucket contract was in force.
