# Specimen flow 62 — interaction trail, render contract, and egress receipt

## Goal

Pressure-test the next careful datacube step for Ward: once a SlopOS-shaped trust answer is displayed, interacted with, and exported, Ward must keep gestures, renderer transforms, and detached artifacts from silently becoming stronger than the source answer capsule.

## Scenario

A Helm dashboard displays a SlopOS-facing partner-trust deterioration answer. The answer capsule is legitimate under a scope lens, state cut witness, quality witness, freshness envelope, and comparability passport. A human reviewer and an agent now interact with it:

- the reviewer changes the date parameter from “last 30 days” to “current quarter”;
- the reviewer filters to a partner class and clicks a high-deterioration bar;
- the chart renderer shows a top-10 list, hides an “other” bucket, and omits privacy-suppressed cells;
- the agent asks for “the affected partners and representative examples”;
- Helm offers a CSV export and a copied image for a review thread;
- a stale materialization warning arrives after the export is created.

Without pass LXV residue, the dashboard can accidentally turn parameter changes, drill-through, chart transforms, and exported artifacts into unreviewed authority.

## Walkthrough

1. **Ward identifies the source answer capsule.** It records capsule digest, scope lens, state cut witness, freshness envelope, quality witness, comparability passport, privacy posture, exemplar fences, and refusal receipts already attached to the displayed answer.

2. **Ward opens an interaction trail.** The trail names actor class (`human_reviewer`, `agent_assistant`, `helm_surface`), view binding, capability class, session/request boundary, source capsule, and whether the trail is consequence-grade, review-only, or diagnostic.

3. **The date parameter becomes a bounded query event.** “Current quarter” is resolved against a specific calendar/timezone/state cut. The interaction trail records the parameter binding, query digest, relative-date anchor, inherited scope, and whether the new result reused a materialization or required recompute.

4. **The filter does not widen authority.** The partner-class filter is allowed only over the already authorized population. If the filter would become a count/existence oracle over denied partners, Ward emits a refusal receipt instead of a more-specific count.

5. **The click/drill is checked before exemplars appear.** The high-deterioration bar click requests drill material. Ward requires exemplar fences and scope checks before returning row handles, traces, documents, or examples. If only aggregate evidence is safe, the drill is refused or downgraded to aggregate-only.

6. **The renderer produces a render contract.** The contract binds the source/recomputed answer to display transforms: top-10 limit, sort key, “other” bucket policy, suppressed-cell handling, current chart grain, axis labels, units, timezone/calendar, precision, warning copy, and renderer/runtime version if material.

7. **The chart title is downgraded if the render contract is weaker.** Helm may show “Top 10 deteriorating partners under current-quarter filter; other/suppressed cells omitted” rather than the stronger-looking “Partner trust deterioration”. The rendered chart cannot imply complete population coverage.

8. **The CSV export creates an egress receipt.** The receipt names source capsule, render contract, export format, row/cell limits, summarized-versus-underlying posture, included/omitted/redacted/suppressed classes, sensitivity/expiry, target class, and detached-from-live posture.

9. **The copied image creates a separate egress receipt.** The image receipt records that it is a static rendering of a render contract, not a live query handle; it carries freshness and invalidation caveats but no ability to drill.

10. **The agent cannot treat the export as live capability.** If the agent later asks “compare this CSV to today's answer,” Ward requires rehydration through current scope lens, state cut witness, query contract, and comparability passport. The stale CSV can be audit context, not current authority.

11. **The stale warning narrows detached artifacts.** The invalidation receipt attaches to the source answer and to known egress receipts when possible. The old CSV/image remain reviewable if policy allows, but they are no longer current/consequence-grade.

12. **Audit reads the trail without leaking denied cells.** A reviewer can inspect which filters, render transforms, refusals, exports, and warnings occurred. The trail itself redacts denied population existence and suppressed-cell details outside the reviewer's authority.

## Nouns pressure-tested

- **interaction trail** — compact transcript of consequential operations on an answer capsule, including filter/parameter/drill/sort/render/export/annotation/refusal events with authority and exposure posture.
- **render contract** — compact binding between answer capsule and displayed table/chart/card, naming transformations, limits, hidden/suppressed states, display semantics, and warning posture.
- **egress receipt** — compact record for a detached artifact such as CSV, spreadsheet, screenshot, copied table, embed, alert, report, or agent summary, naming scope, format, inclusion/omission/redaction, expiry, and detached-from-live posture.

## Why this preserves optionality

This specimen does not choose a dashboard framework, visualization grammar, BI product, notebook model, telemetry backend, trace schema, export format, DLP product, screenshot protocol, annotation standard, or agent memory stack. It can work with SlopOS D-ATTRFS/CH-ATTRQ view-scoped queries, Harbor restatements, Foundry basis cuts, Steward followthrough, Schell environment epochs, ViewFS resolve-once handles, and Helm review surfaces.

The promoted thing remains smaller than an interactive cube engine: displayed and exported answer handling whose authority is limited by interaction trails, render contracts, egress receipts, and the existing scope/state/refusal/comparability/explanation/reuse residues.

## Open pressure

- Should interaction trails be required for all sessions or only when filters, drills, exports, agents, or durable consequences are involved?
- Should render contracts be mandatory whenever visual transforms occur, or only when a rendered output leaves Helm or influences consequence?
- Should screenshots and copied text receive egress receipts, or is that too heavy unless the surface itself produced them?
- How can stale/invalidation notices reach detached artifacts without creating a global recall or tracking system?
- Can an egress receipt reveal truncation without leaking the existence of denied rows/cells?
- Should annotation anchors become their own noun, or remain part of interaction trail and review residue for now?
- Can a render contract safely expose renderer/runtime version without making Ward depend on a UI stack?
