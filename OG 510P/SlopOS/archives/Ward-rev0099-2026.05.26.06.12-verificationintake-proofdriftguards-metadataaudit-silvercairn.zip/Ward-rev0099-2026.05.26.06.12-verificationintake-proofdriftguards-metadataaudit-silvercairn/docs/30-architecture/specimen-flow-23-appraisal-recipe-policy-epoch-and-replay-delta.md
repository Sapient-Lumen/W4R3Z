# Specimen flow 23 — appraisal recipe, policy epoch, and replay delta

Goal: keep witness material, the interpretation recipe, the normalized result, and the local consequence visibly separate when the same evidence is re-evaluated later.

## Scenario
A receiver imports two trust-bearing bundles:
- a confidential-computing attestation package for a hosted workload;
- a provenance-bearing software release bundle for an updater.

In March, the local verifier stack uses one trust-root pack, one reference-value set, and one normalization rulebook.
The attestation package is appraised under **policy epoch E3** and yields a warning-tier result that is still acceptable for low-risk admission.
The provenance bundle is also acceptable for a narrow deployment lane.

In June, the local environment rotates one trust root, tightens one vulnerability rule, and updates the normalization/labelling guidance for how borderline runtime evidence should be classified.
An auditor or relying party replays the preserved witness material under **policy epoch E4**.
The same attestation package now yields a narrower result, and the provenance bundle falls out of the previously acceptable lane.

Ward must preserve all of the following without flattening them:
- the March witness material was really seen and appraised;
- the March result was produced under a specific recipe and trust root set;
- the June replay used a different recipe and therefore a different frame of reference;
- the June result can narrow current consequence without pretending the March result never existed.

## Proposed Ward objects
1. **appraisal recipe**
   - compact descriptor of the trust roots, comparison rules, normalization choices, and verification steps used to derive one result;
   - smaller than the witness bundle and smaller than the local action.

2. **label scheme handle**
   - stable pointer to the documented meaning behind normalized categories or tiers;
   - keeps one summary result from impersonating the full appraisal breakdown.

3. **policy epoch**
   - generation/version label for the appraisal recipe active when a local result was minted;
   - lets two results about the same witness material remain honestly non-identical.

4. **replay delta**
   - structured comparison between an earlier result and a later re-evaluation;
   - preserves the fact of historical appraisal while still showing what changed.

## Why this specimen matters
It pressure-tests whether Ward can stay honest when:
- the same raw evidence is re-read under a new trust-root pack or rule set;
- a normalized result tier is too small to explain the full meaning shift on its own;
- local policy evolution should narrow current consequence without rewriting history;
- and an auditor needs the frame of reference, not just the conclusion.

## Promotion rule
Do not promote `appraisal recipe`, `label scheme handle`, `policy epoch`, or `replay delta` unless they improve:
- one specimen where the same witness material is replayed under a changed recipe;
- one specimen where trust-root selection changes the normalized result or eligible consequence;
- one specimen where a summary tier is meaningfully weaker than the full appraisal breakdown;
- and one specimen where later replay narrows present consequence without erasing historical truth.
