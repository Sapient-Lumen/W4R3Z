# Specimen flow 78 — consumer receipts, replay diffs, and compaction guards

## Scenario

Ward has emitted governance decision events for the provider-risk quarantine example. Four consumers receive them:

1. Helm receives a public owner-hint event.
2. Harbor receives a recompute-budget/recheck event.
3. Schell receives a break-glass event that must be minimized and retained through a compacted stream.
4. SlopOS receives a CH-AREF attachment event.

Later, a cold Harbor-like consumer reads a compacted stream after event/supersession material has partially aged out.

## Good path

- Helm renders `routing_hint_only` and opens review; it does not export, repair, or approve.
- Harbor schedules a recheck only after packet/event replay remains current.
- Schell records a sealed-pointer retention receipt and declares tombstone/snapshot posture.
- SlopOS attaches CH-AREF identity while preserving `identity_not_trust`.
- The cold consumer downgrades a formerly consequence-grade event to `historical_receipt_only` when packet replay cannot be proven.

## Bad paths captured by fixtures

- event digest mismatch;
- owner hint promoted to export authority;
- forbidden-effect fences dropped during minimization;
- compacted stream without tombstone-retention check;
- compacted-away event treated as current;
- packet not replayed but consumer acts;
- public receipt leaks sealed evidence;
- consumer state upgrade;
- replay diff claims a different after-state;
- no-authority label removed.

## Residues under test

- governance decision consumer receipt;
- replay diff;
- compaction guard;
- forbidden-effect preservation;
- historical receipt downgrade.

## Non-promotion

This pass does not promote batch decision summaries. Batch is deferred until Ward can prove mixed states do not collapse into one green result.
