# Specimen flow 42 — query contract, metric card, and loss fence

## Goal
Show how one repeated analytic question can become easier to reuse and easier to explain **without** prematurely freezing the whole datacube into one semantic constitution or one lossy rollup-first posture.

## Flow
1. A team repeatedly asks the same trust question against a saved query recipe over an explicit basis pin.
2. Ward keeps the **saved query recipe** intact and weaker than any published surface.
3. Because the question repeats, Ward mints a small **query contract** that names the grain, allowed dimensions, measures, required headers, and caveats for that one question only.
4. Ward renders one human-facing **metric card** from that contract so the measure's meaning, grain, freshness/basis headers, and caveats are visible in UI and review surfaces.
5. A candidate accelerated derivative is considered, but before publication Ward states an explicit **loss fence** saying which raw, replayable, or high-cardinality questions that derivative can no longer answer honestly.
6. If the accelerated derivative is later promoted, it remains visibly `contracted`, `loss-fenced`, and weaker than the saved recipe and weaker than replayable raw truth.

## Why this specimen matters
- It proves Ward can standardize one repeated question without inventing a giant semantic empire.
- It keeps human-facing repeated measures smaller than source truth and smaller than full recipe semantics.
- It forces honesty when pre-aggregation or summarization drops queryability.

## Nouns under pressure
- **query contract**
- **metric card**
- **loss fence**

## What must stay separate
- saved query recipe versus query contract;
- query contract versus metric card;
- raw replayable truth versus lossy derivative;
- accelerated convenience versus final local consequence.

## Promotion check
Do not promote these nouns beyond guidance unless a later specimen shows the same repeated question surviving both exact replay and a loss-fenced accelerated derivative without hiding the difference.
