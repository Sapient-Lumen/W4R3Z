# Specimen flow 57 — axis capsule, layout aperture, and lineage facet

## Goal

Pressure-test one careful next step for Ward's embryonic datacube: let a recurring trust question earn compact answer residue without forcing a universal cube schema, storage engine, plan IR, or lineage stack.

## Scenario

A SlopOS surface asks a recurring trust question:

> Which partner trust surfaces are deteriorating across imported credentials, attestations, local appraisals, and spend consequences during the current policy epoch?

The same question may later be answered from a SlopOS D-ATTRFS snapshot query, a ViewFS manifest, a retained materialized summary, an Arrow-like batch handed to another tool, a Substrait-like plan receipt, or an Iceberg-like table snapshot. Ward should make the answer inspectable without deciding that any one of those is the cube.

## Flow

1. **Bounded query authority starts the flow.**  The question is resolved against a named SlopOS view/snapshot, not against an ambient global warehouse. The first return may be a handle set plus answer metadata, not a permanent fact.

2. **Axis capsule declares what one cell means.**  The promoted answer records the axes needed to identify cells: partner, credential family, appraisal lane, spend-consequence class, policy epoch, and time bucket. It also records base grain, measure family, unit/status/privacy/exactness attachments, and whether missing cells are unobserved, filtered, suppressed, filled, or true zero.

3. **Existing Ward residues remain attached, not replaced.**  Grain witness, fanout fence, aggregation law, exactness class, gap/fill posture, calendar binding, unit binding, privacy posture, resolution binding, tier witness, and hybrid seam can all attach to the axis capsule when relevant. The axis capsule is a sheath for earned residues, not a new superclass that erases them.

4. **Layout aperture keeps physical choices honest but subordinate.**  If the answer came from raw replay, a retained tier, a hidden partitioned table, a sparse array, a columnar export, or a materialized-plus-raw stitch, the layout aperture names the choice and any comparability/replay consequence. It does not let partition names, array tile choices, or export formats define the metric.

5. **Plan receipt stays optional.**  If an engine boundary needs a portable plan, the answer may reference a plan-shape receipt. The receipt is useful for replay and debugging, but Ward does not require Substrait, SQL, dataframe APIs, or any one language as the datacube's permanent grammar.

6. **Lineage facet captures enough to rerun or downgrade.**  The promoted answer records source cuts, input handles or snapshot IDs, derivation recipe, run/materialization identity when present, and promotion context. If a later policy epoch, source correction, or materialization bug appears, Ward can compare lineage facets instead of arguing from chart titles.

7. **Promotion remains gated.**  The answer cannot become a durable Ward fact unless the capsule, aperture, and facet survive replay, scope, privacy, layout, and lineage questions at the promotion gate.

## Nouns pressure-tested

- **axis capsule** — compact answer-shape residue naming axes, base grain, measure family, qualifiers, and absence posture.
- **layout aperture** — compact physical-layout residue naming material layout/tier/export choices that affected the returned answer without making them logical identity.
- **lineage facet** — compact provenance residue naming source cuts, recipe/run, and promotion context enough for rerun, diff, downgrade, or quarantine.

## Why this preserves optionality

This specimen keeps the useful parts of OLAP, dimensional modeling, RDF Data Cube, lakehouse table formats, portable relational plans, columnar interchange, lineage events, and sparse arrays without prematurely selecting any of them as Ward's datacube constitution.

The datacube can remain a set of earned answer residues first. Only repeated specimens should decide whether those residues later grow into first-class schemas, registries, engines, or SlopOS-native objects.

## Open pressure

- Can a SlopOS snapshot query return enough stable handles for an axis capsule without turning D-ATTRFS into a global index?
- When does layout aperture become mandatory: every exported answer, only materialized answers, or only comparability-changing answers?
- Should lineage facet point to a Ward-native receipt, a SlopOS diagnostic bundle, an OpenLineage-like event, or a smaller handle until the host design settles?
- Can axis capsule stay compact enough that ordinary Ward users can inspect it, while still preserving the details future reruns need?
