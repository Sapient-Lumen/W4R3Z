# Specimen flow 60 — delta anatomy, attribution rail, and exemplar fence

## Goal

Pressure-test the next careful datacube step for Ward: once a SlopOS-shaped comparison says a trust surface deteriorated, Ward must explain the movement without turning accounting decomposition, data diffs, cohort contrast, or examples into a causal story.

## Scenario

A Helm surface has just rendered the pass-LXII-style answer:

> Partner trust deterioration increased in the current policy epoch, with the OAuth-wallet credential family showing the largest movement.

The comparison carried a comparability passport. It was `bridged` for one credential-family label split, had one warning-level quality witness, and had two cells with explicit privacy/refusal mismatch.

A human now asks:

> Why did OAuth-wallet get worse?

Several things are true at the same time:

- the authorized SlopOS view narrowed the partner population;
- the metric card changed from raw failure count to deduped current-winner failure count;
- a label split moved some old OAuth-wallet observations into two new child members;
- late corrections added failures to the previous epoch after the old chart had already been shown;
- one partner feed had warning-level validation failures;
- two new-epoch cells were privacy-suppressed;
- a cohort contrast finds that one appraisal lane is overrepresented among worsened cells;
- three vivid drill-through examples exist, but one is redacted and none are proven representative;
- an LLM summary drafts: “The partner's new process caused the deterioration.”

Ward should not decide a root-cause engine. It should decide that the why-answer has its own residue.

## Flow

1. **The why request becomes a new answer capsule.** Ward records the source comparison capsule, consequence class, requester view, snapshot cut, and refusal posture. It does not reuse the rendered chart as authority.

2. **Ward checks the comparison passport first.** Any segment marked `bridge_required`, `incomparable`, `not_tested`, or quality-failed can contribute only to a constrained explanation. The why-answer cannot be stronger than the comparison it explains.

3. **Ward builds a delta anatomy.** The observed movement is decomposed into named buckets:
   - fact movement under same contract;
   - scope/population movement caused by the view narrowing;
   - metric-card movement from raw count to deduped current-winner count;
   - axis/member bridge movement from the label split;
   - late-correction movement from previous-epoch updates;
   - quality/refusal movement from the warning-level feed and withheld cells;
   - privacy/suppression movement from the two suppressed cells; and
   - residual unexplained movement.

4. **Each explanation fragment receives an attribution rail.** Ward allows:
   - “X percentage points are accounted for by denominator/scope movement” on an accounting rail;
   - “these source fields and transformations contributed to the output measure” on a lineage/where rail;
   - “these rows or cells differ between cuts” on a value-diff rail;
   - “this appraisal lane is overrepresented among worsened cells” on a cohort-contrast rail;
   - “these examples illustrate the pattern” on an exemplar rail; and
   - no “caused by” language unless a causal/counterfactual rail is explicitly satisfied.

5. **The LLM summary is downgraded.** “The partner's new process caused the deterioration” is rejected because the causal rail lacks intervention design, counterfactual basis, or approved causal model. The safe summary becomes: “The observed movement is partly accounted for by scope narrowing, metric-card drift, label bridging, late corrections, and quality/refusal changes; the remaining same-contract movement is concentrated in one appraisal lane, but causality is not established.”

6. **Exemplars are fenced before display.** Each drill-through example carries selection rule, source answer scope, redaction status, privacy posture, and representativeness posture. Helm may show “example, not representative” only if the requester has authority to see the exemplar handle and the cell-level fence permits it.

7. **Probe fixtures test the explanation recipe.** Ward keeps small static cases that exercise label split, denominator movement, dedupe, refusal, and late correction. If a fixture fails, the explanation recipe is quarantined even if the original numeric comparison still rendered.

8. **The residual bucket remains visible.** Ward does not force 100% attribution. Remaining movement can be named `residual_unexplained` and routed to followthrough, rather than being assigned to the most narratively satisfying cohort.

9. **Later evidence can strengthen the rail.** A reviewed experiment, counterfactual model, or external incident receipt may later upgrade a fragment to a causal rail, but that creates a new why-answer capsule rather than mutating the old explanation.

## Nouns pressure-tested

- **delta anatomy** — compact movement decomposition for changed answer capsules or compared cells, with residual preserved.
- **attribution rail** — compact explanation claim-strength lane with allowed verbs, evidence class, assumptions, uncertainty, and forbidden upgrades.
- **exemplar fence** — compact guard for drill-through examples, records, traces, or handles used to illuminate an aggregate.

## Why this preserves optionality

This specimen does not choose a causal framework, lineage ontology, data-diff tool, row drill API, observability backend, LLM summarizer, or explanation UI. It can work with SlopOS snapshots, CH-ATTRQ-style view-scoped queries, Harbor restatement receipts, ViewFS handles, Foundry basis changes, Steward reconciliation receipts, Schell environment epochs, and Helm badges.

The promoted thing remains smaller than “root cause”: a why-answer whose authority is limited by its comparison, decomposition, evidence rails, exemplar fences, and residual.

## Open pressure

- Should delta anatomies be mandatory only for trust-consequence explanations, or for every changed chart?
- Which movement classes deserve stable names versus pass-local prose?
- Can an LLM draft a delta anatomy if deterministic checks validate every bucket?
- Should exemplar fences be privacy-led, view-led, or result-led?
- Should Ward ever host causal rails, or only accept reviewed causal receipts from outside the datacube?
- What is the smallest fixture suite that can catch explanation bugs before a promoted why-answer is shown?
