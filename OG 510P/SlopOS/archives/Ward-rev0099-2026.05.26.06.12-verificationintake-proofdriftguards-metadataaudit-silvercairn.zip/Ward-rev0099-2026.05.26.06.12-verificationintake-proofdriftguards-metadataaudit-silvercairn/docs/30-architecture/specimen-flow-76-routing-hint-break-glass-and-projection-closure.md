# Specimen flow 76 — routing hint, break-glass, and projection closure

## Specimen question

Ward can now reject false governance authority. Can it also allow weak but useful governance states without letting them grow into hidden authority?

Two cases pressure the same seam:

1. A dashboard viewer sees a stale catalog owner label and only needs to route a review request.
2. A suspected false provider quarantine may harm a provider before normal governance lanes can assemble, so an incident commander needs sealed emergency access to raw partner fragments.

Can Ward allow the route and the sealed emergency review while still blocking export, remedy, action re-enable, privacy disclosure, and owner-label laundering?

## Existing material

- Governance handoff packet v0.
- Proof obligations PO-GOV-001 through PO-GOV-011.
- Datacube residue spine.
- Provider-risk quarantine valid fixture and ten rev0078 negative fixtures.

## New material

- `docs/20-assurance/governance-decision-state-matrix.md`
- `docs/30-architecture/routing-hint-and-break-glass-closures.md`
- `fixtures/governance-handoff/owner-hint-routing-only.valid.json`
- `fixtures/governance-handoff/break-glass-emergency-review-debt.valid.json`
- `fixtures/governance-handoff/negative/routing-hint-promoted-to-export.invalid.json`
- `fixtures/governance-handoff/negative/routing-hint-carries-sensitive-evidence.invalid.json`
- `fixtures/governance-handoff/negative/break-glass-no-expiry.invalid.json`
- `fixtures/governance-handoff/negative/public-projection-exposes-sealed-conflict.invalid.json`
- updated `tools/check_governance_handoff.py`

## Walkthrough A — owner hint routing

1. A dashboard viewer sees an owner hint attached to the provider-risk dashboard.
2. The stewardship charter behind the hint is stale, so it cannot support repair, export, action, remedy, privacy, or budget.
3. Ward emits `routing_hint_only` for `route_to_steward`.
4. The routing-hint mode proves read-only posture, non-sensitive evidence, and forbidden promotions.
5. Public and external views reveal only a safe label or redacted route.
6. Any attempt to promote the same owner hint into dashboard export approval fails.

## Walkthrough B — break-glass sealed review

1. A suspected false quarantine creates urgent provider-harm pressure.
2. A governance lane accepts an emergency handoff to an incident commander.
3. The charter and handoff grant only `emergency_raw_partner_fragment_access` under seal.
4. The break-glass packet records trigger, scope, expiry, allowed interim action, post-hoc review deadline, rollback plan, and review debt.
5. Public/external projections show only redacted hold/emergency receipt posture.
6. Export, remedy, action re-enable, and publication remain held until normal authority is rehydrated.

## Negative fixture pressure

The fixture set must fail when:

- routing hints become export approval;
- routing hints carry raw partner or sealed governance evidence;
- break-glass omits expiry;
- public projections expose sealed conflict or reviewer details.

## Promotion tests

A future governance decision event is not yet promoted. It must first prove that it can carry:

- state name;
- requested action;
- subject refs;
- proof summary;
- projection class;
- refusal/hold reason;
- sealed evidence pointer;
- expiry/review-debt state where relevant.

## Current posture

Promote routing-hint and break-glass closures as checker-enforced packet modes. Do not promote a standalone governance decision event yet.
