# Signal-notification reconciliation, refresh proofs, and checker registry

Rev0091 created the signal-notification receipt. Rev0092 closes the next hole: notification receipts could prove fanout and acknowledgment posture, but not consumer-local refresh.

## Receipt chain

```text
recertification receipt
  -> signal-ingestion receipt
    -> signal-notification receipt
      -> signal-notification reconciliation receipt
```

The reconciliation receipt is downstream-only. It cannot change the source signal, the source notification, the source recertification receipt, or the status pointer. It can only record which consumers supplied acceptable refresh evidence and which consumers remain unsafe.

## Refresh proof rule

A consumer is reconciled as refreshed only when the receipt includes a checked `consumer_recertification_ref` whose bytes validate and whose source release, recipient class, purpose, source item, projection policy, and cache-subject digest mirror the notification basis.

An acknowledgment digest can be carried as supporting delivery evidence. It never satisfies refresh by itself.

## Mixed outcomes

The receipt intentionally supports mixed states:

- all consumers refreshed;
- some refreshed, some quarantined;
- dead-lettered consumers still quarantined;
- duplicate notification suppressed with no refresh effect;
- conflict notification held with no selected winner.

This prevents the common UI and cache bug where a single green summary hides stale or unreconciled consumers.

## Checker-suite refactor

Pass XCII also audits the checker surface. The old suite contained a hardcoded Python list of checker scripts. That made it easy to add a checker and forget the suite. The pass adds:

- `tools/governance_common.py` for shared loading, digest, path, time, and fixture-runner utilities;
- `tools/governance_checker_registry.json` as an auditable list of receipt validators;
- a refactored `tools/check_governance_suite.py` that reads the registry, verifies checker and fixture paths, deduplicates entries, and then runs the validators.

This is still intentionally small. Ward is not turning the checker suite into a framework; it is making the current refusal harness auditable as the number of receipt families grows.

## External pressure

`EXT-RFC-8935` and `EXT-RFC-8936` keep delivery and local handling distinct. `EXT-OPENID-SSF-2025` keeps event exchange between transmitter and receiver separate from local policy decisions. `EXT-CLOUDEVENTS-SPEC-2026` pushes Ward to preserve event identity and duplicate posture rather than treating repeated delivery as new authority. Cloud dead-letter systems such as `EXT-GCP-PUBSUB-DEADLETTER-2026` and `EXT-AZURE-EVENTGRID-DELIVERY-RETRY-2026` reinforce the same pattern: delivery state is not consumer refresh.
