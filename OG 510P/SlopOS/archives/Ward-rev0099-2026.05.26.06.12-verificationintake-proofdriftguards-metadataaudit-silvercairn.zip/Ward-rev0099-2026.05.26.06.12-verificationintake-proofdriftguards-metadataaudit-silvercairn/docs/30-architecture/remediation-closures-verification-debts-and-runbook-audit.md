# Remediation closures, verification debts, and runbook audit

Pass XCVIII adds a bounded closure layer:

```text
reuse gate -> use execution -> outcome observation -> rollback-remediation -> remediation closure
```

The new receipt supports five safe closure postures:

- no-remediation-needed closure confirmed, refresh still required;
- no-op closure confirmed, refresh still required;
- rollback review closed, quarantine sustained, external proof still required;
- remediation handoff acknowledged, external proof still required;
- unavailable observation escalated and still held.

## Non-authority boundary

Remediation-closure receipts are append-only governance hygiene. They do not mutate rollback-remediation receipts, outcome observations, use executions, reuse gates, chain heads, status channels, or released evidence. They do not execute rollback, clear quarantine, complete remedies, repair semantics, release evidence, or grant action authority.

## Cross-cube seam

- **Helm** renders closure state, verification debt, and visible no-authority watermark.
- **Harbor** may consume handoff acknowledgment as a pending external-proof requirement, not as correction completion.
- **Schell** minimizes closure/public postmortem evidence and handles retention of verification debt.
- **ViewFS** carries lineage and trusted-path posture for closure packets.
- **SlopOS** attaches closure receipts to portal/CH-AREF/recheckpoint flows only as context; consequence gates still require source replay and appropriate receipts.

## Audit/refactor

The pass also adds `tools/check_tool_runbook_integrity.py`. The checker treats `tools/README.md` and the `make check` runbook as first-class maintainability surfaces. If the registry grows or audit tools change without the runbook reflecting them, the repository check fails.
