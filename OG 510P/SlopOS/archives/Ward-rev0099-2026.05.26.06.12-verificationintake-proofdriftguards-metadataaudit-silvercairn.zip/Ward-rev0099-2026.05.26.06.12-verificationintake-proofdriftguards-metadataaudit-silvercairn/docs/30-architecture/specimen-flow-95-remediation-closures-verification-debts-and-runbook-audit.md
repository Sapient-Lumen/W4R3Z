# Specimen flow 95 — remediation closures, verification debts, and runbook audit

## Scenario

A public governance status surface previously executed a display-only reuse. Outcome observation found that the actual effect drifted into evidence-bundle release, so rev0097 opened rollback review and requested remediation handoff while maintaining quarantine.

## New pass behavior

Rev0098 adds a remediation-closure receipt after the rollback-remediation receipt.

1. The closure receipt byte-checks the rollback-remediation receipt.
2. It mirrors the source remediation state, remediation id, target, recipient class, projection policy, review state, and review-handoff digest.
3. It records one bounded closure state:
   - review closed, quarantine sustained;
   - or handoff acknowledged, external proof required;
   - or no-remediation/no-op closure confirmed;
   - or unavailable observation escalated and still held.
4. It records verification debt and next recheck time.
5. It preserves no-authority labels and public projection minimization.
6. It refuses rollback execution, remedy completion, quarantine clearance, source mutation, status-pointer update, export, repair, learning use, and action authority.

## Why this matters

Without this layer, downstream consumers could see “review closed” or “handoff acknowledged” and display the incident as fixed. Ward now forces closure vocabulary to stay smaller than remedy proof.

## Audit note

The same pass audits the tools runbook. The checker registry, `tools/README.md`, and Makefile are now cross-checked so a new receipt validator cannot silently exist outside the human maintenance map.
