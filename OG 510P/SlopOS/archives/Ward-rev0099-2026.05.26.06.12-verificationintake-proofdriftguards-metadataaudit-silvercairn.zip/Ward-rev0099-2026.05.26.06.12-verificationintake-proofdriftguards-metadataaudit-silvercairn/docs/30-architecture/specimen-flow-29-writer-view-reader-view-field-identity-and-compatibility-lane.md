# Specimen flow 29 — writer view, reader view, field identity, and compatibility lane

Goal: keep authored meaning, consumer-local decoding meaning, stable field identity, and evolution policy visibly separate whenever Ward republishes or reuses trust residue across changing schemas.

## Scenario
A relying party publishes a trust cut `C111` for one subject. The exact bytes are authored under **writer view** `WV1`.
In `WV1`, field identity `F12` is labelled `purpose`, field identity `F18` is labelled `state_class`, and field identity `F33` does not exist yet.

Weeks later, a newer consumer uses **reader view** `RV2`.
In `RV2`, `F12` is now labelled `status_purpose`, `F18` still means the same classified state, and a new optional field identity `F33` named `coverage_scope` has been added with a default.
`RV2` also treats one field with explicit presence so that "absent" and "explicitly set to false" do not collapse.

When `RV2` reads cut `C111`, it does **not** pretend the older cut was authored under `RV2`.
Instead it records that `C111` was authored under `WV1` and read here through a specific **compatibility lane**: aliases map `purpose` to `status_purpose`, the missing `F33` gets the documented default, and any writer-only residue unknown to `RV2` is preserved or explicitly noted as dropped depending on the chosen lane.

Now imagine the inverse direction too.
A later cut `C118` is authored under `WV2` and includes `F33` plus one additional unknown field identity `F41`.
An older consumer still pinned to reader view `RV1` may be able to read `C118` only under a weaker compatibility lane.
It might ignore `F33`, preserve `F41` only in binary form, or lose both if someone converts through a text/JSON path.
Ward should not let all three stories collapse into the same fake claim that "the cut is compatible."

## What this specimen is trying to preserve
1. **writer view**
   - exact authored schema/shape bound to the published cut;
   - smaller than one universal registry or serializer choice.

2. **reader view**
   - consumer-local expected schema/shape used for decoding or projection;
   - smaller than one final local consequence.

3. **field identity**
   - stable identity of one fact independent of current labels or order;
   - smaller than one global ontology.

4. **compatibility lane**
   - explicit statement of how older/newer views interoperate here;
   - smaller than one permanent migration engine.

## Promotion test
Do not promote `writer view`, `reader view`, `field identity`, `compatibility lane`, `presence mode`, or `translation witness` unless they improve all of the following:
- one old-cut / new-reader specimen with aliases or defaults;
- one new-cut / old-reader specimen where unknown residue may survive, narrow, or be lost;
- one rename/reorder specimen where stable identity matters more than labels;
- one absent-versus-explicit-default specimen where presence mode changes consequence.
