# Specimen flow 80 — search continuity, sealed omissions, and cursor drift

## Situation

A SlopOS portal search lists governance decisions for a provider-risk dashboard. Page one is produced from valid batch/search receipts. It includes one route-only owner hint, one current consequence-grade recheck receipt, and one historical receipt. One restricted break-glass row is omitted from the public projection.

The user requests page two later. Between page one and page two:

- the owner-map epoch changes;
- the projection policy is tightened;
- one packet's compaction watermark advances;
- a sealed conflict remains hidden from the public surface.

## Bad collapse

The bad implementation says:

> “Page two loaded. 27 approved governance records.”

That sentence hides every Ward distinction:

- search result versus authority;
- page continuation versus new basis;
- visible row versus sealed omission;
- public count versus restricted evidence;
- current replay versus compacted/historical replay.

## Ward residues

The flow introduces `ward.governance.search-continuity-receipt.v0`.

It references:

- prior batch/search receipt digest;
- current batch/search receipt digest;
- query digest;
- projection-policy digest;
- owner-map epoch;
- packet-compaction watermark;
- sealed omission disclosure mode;
- drift response state.

## Safe positive path

If all basis fields are unchanged, the receipt may say:

- `continued_same_snapshot`;
- current/prior page digests match;
- no authority upgrade;
- public view has no sealed leakage;
- effects are limited to render/search-navigation/review-intake.

## Safe held path

If projection policy, owner map, or compaction changed, the receipt must say:

- `held_recheckpoint_required`, `new_receipt_issued`, or `new_search_required`;
- continuation not claimed;
- drift reason visible;
- sealed omission mode safe for the audience;
- no export/action/repair/remedy/learning effect.

## Sealed omission path

For public or external views, Ward permits:

- `presence_only`;
- `bucketed_range`;
- `dp_noisy_count` with privacy budget.

Ward rejects:

- exact count of hidden rows;
- per-subject hidden counts;
- reviewer/conflict/incident/private-org details;
- “complete result” language when omissions exist.

## Product line

The UI should say:

> “Some governance rows are hidden or held. This page cannot prove action authority. Recheck current packet state before acting.”

That is awkward but true.
