# Specimen flow 67 — threshold witness, action warrant, and consequence receipt

## Why this specimen exists

A SlopOS-facing datacube can answer a question correctly and still be too weak to act on. A month-over-month deterioration can be scoped, fresh, comparable, semantically anchored, privacy-reviewed, and quality-checked, but it may still be a transient spike, a degraded preview, an inhibited alert, a stale materialization, or a consequence outside the user's authority.

This specimen keeps actuation small and answer-local. It does not introduce a Ward alerting engine, workflow system, policy engine, feature flag framework, ACP extension, event bus, or incident-management product.

## Scenario

A reviewer asks:

> If the credential-provider risk family deterioration is persistent enough, notify the reviewer and propose a bounded ACP quarantine action for newly affected provider-family handles.

The source answer already carries:

- scope lens and state cut witness for the authorized SlopOS view;
- metric card, grain witness, window frame, calendar binding, and aggregation law;
- quality witness, freshness envelope, privacy/suppression posture, and uncertainty envelope;
- comparability passport, drift notice, concept anchors, crosswalk warrants, and hierarchy cut;
- projection curtain and render contract for a Helm review surface.

The dangerous shortcut is: “risk got worse, therefore page the reviewer and quarantine providers.” Ward refuses that shortcut. The answer may support a consequence only through a trigger condition, action permission, and receipt path.

## Candidate residues

### Threshold witness

A compact trigger-condition record for an answer-derived alert/recommendation/control-loop candidate.

Suggested fields:

- referenced answer capsule, cell set, metric card, axis capsule, and hierarchy cut;
- comparator and threshold or baseline;
- duration / persistence requirement;
- evaluation cadence and last evaluated cut;
- tolerance, hysteresis, stabilization window, cooldown, and anti-flap posture;
- no-data, stale, error, refusal, privacy suppression, and degraded-answer handling;
- pending/firing/resolved/withheld state;
- grouping key, inhibition key, dedupe key, and flood-limit posture;
- allowed labels/annotations/runbook handles for presentation.

A threshold witness is stronger than “value exceeded X” and smaller than an alerting engine.

### Action warrant

A compact permission-to-use record that says a named cube answer may support a named consequence class.

Suggested fields:

- consequence class: page, notify, open docket, recommend, propose ACP action, feature flag, throttle, scale, quarantine, or refuse;
- authorized actor/lane and human-review requirement;
- required answer residues: scope, freshness, quality, comparability, semantic bridge, privacy, uncertainty, projection, and correction posture;
- policy epoch, runbook/version, and acceptance floor;
- action template or digest boundary, without embedding raw authority;
- ACP/precondition posture when relevant;
- budget/payer posture and rate/cost caps;
- idempotency/conflict/dedupe key posture;
- cooldown, escalation, rollback, withdrawal, and revocation posture;
- expiry and rehydration requirements.

An action warrant is stronger than a dashboard button and smaller than a policy engine.

### Consequence receipt

A compact after-the-fact record for what happened because an answer crossed an action warrant.

Suggested fields:

- consequence id and event/envelope identity;
- referenced answer capsule, threshold witness, action warrant, and render/egress surfaces;
- actor, reviewer, agent, policy decision, run/workflow, or ACP outcome references;
- result state: proposed, accepted, rejected, error, applied, no-op, duplicate-suppressed, inhibited, silenced, withdrawn, expired, or fenced;
- effect/refusal notes and downstream receipt refs;
- notification/export/agent-summary refs when safe;
- budget spent / privacy/detail exposure / egress posture;
- repair, revocation, invalidation, rollback, or recompute followthrough;
- rehydration requirement before reuse.

A consequence receipt is stronger than a log line and smaller than a workflow engine.

## Flow

1. **Start with answer authority.** The source cube answer must already carry ordinary Ward datacube residues: scope, cuts, grain, metric, quality, freshness, privacy, uncertainty, comparability, semantics, rendering, and egress posture.

2. **Evaluate trigger separately.** The threshold witness states the comparator, baseline, duration, evaluation cadence, tolerance, stabilization, cooldown, and no-data/stale/error posture. A one-bucket spike can remain `pending`; a stale/no-data answer can become `withheld`; a degraded preview can become `review_only`.

3. **Apply grouping and inhibition before consequence.** Multiple provider families with the same root outage can group under one review item. A broader “attribute query stale” or “source unavailable” condition can inhibit derivative risk-family alerts. Privacy suppression can withhold specific members while preserving aggregate warning posture.

4. **Check action warrant.** The warrant says which consequences are allowed. A warning banner may be allowed; an urgent notification may require stronger freshness; an ACP quarantine proposal may require exact answer material, reviewer confirmation, policy epoch match, and budget/payer evidence.

5. **Bind the action proposal exactly.** If an ACP proposal is formed, it references canonical action bytes or digest, exact precondition witnesses, and the answer capsule digest. The proposal does not get to re-query “latest risk” at validation time.

6. **Record consequence receipt.** The result might be `notified`, `proposed`, `accepted`, `rejected`, `no_op`, `duplicate_suppressed`, `inhibited`, or `error`. CH-ACPOUT, CH-NOTIF, policy decision logs, event envelopes, or workflow records can be digest-referenced if they exist, but they do not become authorization evidence by themselves.

7. **Carry downstream decay.** Alerts, exported recommendations, copied tables, and agent summaries need rehydration before later action. If the source answer is invalidated, corrected, revocated, or semantically bridged differently, old consequence receipts may remain audit material while current action authority is fenced.

8. **Preserve non-action as a healthy outcome.** A threshold witness can withhold, an action warrant can deny, and a consequence receipt can record no-op/duplicate-suppressed/refused states without treating them as system failure.

## Healthy outputs

A healthy answer-to-action path can say:

- `pending`: threshold condition is active but has not persisted long enough;
- `firing_allowed`: trigger condition passed and the action warrant permits this consequence class;
- `withheld_no_data`: answer state is insufficient for alerting;
- `review_only`: approximate/degraded answer may open a docket but not automate;
- `inhibited`: broader or higher-priority condition suppresses duplicate consequence;
- `silenced`: matched an explicit temporary mute;
- `proposal_bound`: ACP/action proposal is tied to exact answer and precondition material;
- `no_op` or `duplicate_suppressed`: accepted path produced no new effect;
- `fenced_after_invalidation`: old recommendation remains audit material but cannot drive new consequence.

## Promotion gate

Promote threshold witness, action warrant, and consequence receipt only if they keep at least these seven cases honest:

1. transient spike that stays pending;
2. persistent breach that pages only after an actionability warrant;
3. stale/no-data/error answer that refuses or recomputes instead of alerting;
4. approximate/degraded answer that opens review only;
5. inhibited/grouped alert storm;
6. ACP proposal that accepts as no-op or duplicate-suppressed; and
7. old notification/export/agent summary fenced after answer invalidation.

The specimen passes only if the cube answer is weaker than its action warrant, and the consequence receipt is weaker than fresh authority to act again.
