# Specimen flow 79 — batch/search receipts, mixed state, and projection joins

## Scenario

A SlopOS portal asks Ward for a provider-risk governance search result.

The visible candidates include:

1. a Helm-rendered owner hint that can only route a review request;
2. a Harbor consumer receipt for a current consequence-grade recompute recheck;
3. a historical-only receipt preserved after compaction;
4. a restricted Schell break-glass receipt that can be summarized internally but not exposed publicly.

The product team wants a single summary badge and a count.

Ward refuses the green-badge collapse.

## Flow

1. Each member remains a separate governance decision consumer receipt.
2. The batch/search receipt references each member by ID, path, and SHA-256 digest.
3. Member state, replay status, projection view/class, downgrade reasons, and forbidden-effect fences are mirrored.
4. The aggregate result exposes state counts and replay-status counts.
5. The projection join uses least privilege and keeps projection classes distinct.
6. Public views omit restricted members and disclose omissions.
7. Search cursors bind to query and projection-filter digests.
8. Aggregate effects stay limited to safe review/navigation effects.

## Positive result

A valid internal search can say:

- one routing hint;
- one current consequence-grade receipt;
- one historical-only receipt;
- one member omitted or redacted by projection;
- no aggregate authority count;
- no action/export/remedy effect performed by the batch.

## Rejected result

Ward rejects a result that says:

- `3 allowed`;
- `all green`;
- `approved for export`;
- `current authority set`;
- public display of restricted break-glass material;
- continuation cursor that is not bound to the original query/projection digest;
- aggregate summary with missing forbidden-effect fences.

## Why this belongs in Ward

This is not a UI concern alone. The error is semantic: aggregation can change the apparent consequence of governance evidence.

Ward owns the refusal because Ward owns the distinction between evidence, route, review, authority, currentness, and consequence.

## New artifacts

- `docs/20-assurance/governance-batch-search-receipt-v0.md`
- `docs/10-threat-model/batch-search-replay-threat-model.md`
- `docs/30-architecture/batch-search-mixed-state-guards.md`
- `schemas/governance-batch-search-receipt.v0.json`
- `fixtures/governance-batch-search/*.valid.json`
- `fixtures/governance-batch-search/negative/*.invalid.json`
- `tools/check_governance_batch_search_receipts.py`
