# Specimen flow 44 — aggregation law, rollup passport, and merge state

## Goal
Show how one repeated analytic question can earn faster derived surfaces **without** pretending every metric inside that question rolls up like `SUM`.

## Flow
1. A team already has a saved query recipe and a query contract for one repeated trust question.
2. The same question yields three neighboring measures: an event count, a distinct principal count, and an end-of-period active-grant balance.
3. Before any promoted derivative is published, Ward forces an explicit **aggregation law** for each measure instead of letting the dashboard inherit one silent universal rollup rule.
4. The event count may be declared additive across some dropped dimensions; the distinct principal count is declared non-additive across regrouped category totals; the end-of-period balance is declared semiadditive across time.
5. Ward attaches a **rollup passport** saying which regroupings are safe, which need replay, and which require a carry-forward or time-selection rule.
6. If the team wants fast higher-level recomposition for a non-additive or stateful measure, Ward preserves a **merge state** distinct from the rendered value so later recomposition does not have to fake correctness from one naked number.
7. The promoted derivative remains aggregation-lawed, passported, and, when needed, merge-state-backed while staying weaker than the source recipe and weaker than final local consequence.

## Why this specimen matters
- It proves Ward can speed up recurring questions without flattening every measure into a fake additive cube fact.
- It keeps forbidden regroupings and time-rollup traps visible.
- It preserves the difference between a displayed number and the intermediate state required for safe recomposition.

## Nouns under pressure
- **aggregation law**
- **rollup passport**
- **merge state**

## What must stay separate
- additive event totals versus non-additive distinct totals;
- semiadditive balance snapshots versus ordinary counts;
- rollup passport versus the full query contract;
- rendered value versus mergeable intermediate state;
- accelerated derivative versus final local consequence.

## Promotion check
Do not promote these nouns beyond guidance unless a later specimen shows the same recurring question surviving additive, semiadditive, and non-additive pressure without hiding which regroupings are safe and which require replay or merge state.
