# Specimen flow 26 — completeness frontier, lateness budget, and retraction delta

Goal: keep intake completeness, early visibility, and later correction visibly separate whenever Ward projects a current trust answer from ongoing later-state feeds.

## Scenario
A relying party builds a per-subject trust projection from several later-state feeds: one issuer status feed, one watch stream for incident-style updates, and one local review lane.
The system needs to answer online checks quickly, so it emits an early per-subject answer once its intake has advanced past a chosen cut.
That first answer is useful, but the correction window is still open.

A delayed issuer event then arrives within the allowed correction window and changes the subject’s effective local posture.
The system records the late arrival, emits an explicit correction, and preserves both the earlier provisional answer and the retraction/amendment that followed.
Later, another even older event arrives after the correction budget has closed.
The archive may still keep the fact in history, but it does not silently rewrite the already-stabilized projection without an explicit replay or re-evaluation step.

## What this specimen is trying to preserve
1. **completeness frontier**
   - explicit claim about how far the relevant intake is believed complete enough;
   - smaller than objective truth and smaller than final local consequence.

2. **provisional view**
   - early projected answer emitted before the correction window has closed;
   - useful for fast checks, but weaker than a stabilized answer.

3. **lateness budget**
   - explicit interval during which late-arriving facts may still revise the projection;
   - smaller than retention, compaction, or full historical replay policy.

4. **retraction delta**
   - explicit correction that narrows, withdraws, or amends an earlier projected answer;
   - smaller than pretending the earlier answer never existed.

## What this specimen refuses to decide yet
- whether Ward’s long-term completeness frontier is global, per-feed, per-subject, or per-projection only;
- whether provisional views and retraction deltas are stored as first-class objects, sidecar metadata, or compact history entries;
- whether lateness budget belongs in Ward proper or in an adjacent history/observation cube;
- whether stabilization after budget expiry implies immutable finality or only “no more silent correction without replay.”

## Why this specimen matters
Trust systems fail quietly when the first available answer is treated as final by accident, or when late corrections rewrite history invisibly. Ward should learn to preserve “current enough,” “still open to correction,” and “explicitly amended” as different truths before it chooses one cube-wide projection doctrine.

## Promotion test for these nouns
Do not promote `completeness frontier`, `provisional view`, `lateness budget`, or `retraction delta` unless they improve:
- one fast-answer-before-closure specimen,
- one late-correction specimen,
- one budget-expiry specimen,
- and one replay/re-evaluation specimen where old projections must not be silently rewritten.
