# Trust consequences and spendable grants

Ward becomes useful only when it can turn appraisal into restrained consequences.

The cube should prefer:
- explicit narrow grants,
- visible review warrants,
- short-lived approvals,
- and attributable badges or receipts.

It should resist:
- global sticky “trusted” mode bits,
- replayable forever credentials masquerading as recent consent,
- and giant account/session folklore standing in for local policy.

A consequence should say:
- what appraisal produced it,
- what appraisal recipe or policy epoch produced it when that meaning could change over time,
- what it authorizes,
- for whom or for what holder,
- how it expires or is consumed,
- and what stronger review is still required.
