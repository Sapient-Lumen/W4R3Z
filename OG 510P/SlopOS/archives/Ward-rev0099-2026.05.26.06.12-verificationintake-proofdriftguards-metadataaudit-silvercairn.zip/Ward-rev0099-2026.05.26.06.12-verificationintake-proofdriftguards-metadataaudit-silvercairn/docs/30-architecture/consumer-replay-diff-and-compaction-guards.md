# Consumer replay diffs and compaction guards

Pass LXXX let sibling cubes carry one Ward decision state without copying the full packet. Pass LXXXI closes the next seam: **what did the consumer do with that state?**

A governance decision event answers: what did Ward decide about one actor/action under one packet?

A governance decision consumer receipt answers: how did a downstream surface preserve, weaken, retain, or safely refuse that event?

## Consumer chain

```text
governance handoff packet
  -> governance decision event
    -> consumer receipt
      -> rendered badge / minimized receipt / recheck schedule / CH-AREF attachment / historical replay diff
```

Every arrow is lossy. Ward therefore requires each lower layer to preserve enough information to avoid authority inflation.

## Replay diff

A replay diff is not a data diff. It is a force diff.

| Before | After | Meaning |
|---|---|---|
| `routing_hint_only` | `routing_hint_only` | consumer preserved weak route-only state |
| `consequence_grade` | `consequence_grade` | consumer rechecked event and packet, then performed only event-allowed effects |
| `consequence_grade` | `historical_receipt_only` | event bytes survived but current packet replay failed |
| `review_only` | `consequence_grade` | invalid upgrade unless a fresh packet produced a fresh decision event |

The replay diff must record whether packet and event digests were checked. Current replay without packet digest check is a false-currentness claim.

## Compaction hazard

Compacted streams are useful because they keep a latest value per key. That is dangerous for Ward because a latest survivor can look like a complete proof trail.

Ward treats compaction as a historical-risk surface:

- a survivor record is not proof that no older refusal, supersession, review debt, tombstone, or projection block existed;
- a missing tombstone is not proof that no deletion or supersession happened;
- a cold consumer that cannot complete a full scan inside tombstone retention must downgrade;
- a materialized latest-state table is not a packet replay.

## Safe consumer patterns

### Helm

Helm may display a public owner hint if the receipt preserves `routing_hint_only`, shows a no-authority label, and performs only render/open-review effects.

### Harbor

Harbor may schedule a recheck from a consequence-grade event when packet replay is current. It must not convert the recheck into correction implementation or export release.

### Schell

Schell may retain a minimized event and sealed pointers, but compaction mode must record tombstone-retention posture and materialized-state limits.

### SlopOS

SlopOS may attach event identity to CH-AREF-like material only while preserving `identity_not_trust`; the attachment cannot become a grant.

## Refusal rule

When in doubt, a consumer receipt should downgrade. Ward prefers a visible historical receipt over a polished but replay-unsafe badge, search result, transcript, or recheck ticket.
