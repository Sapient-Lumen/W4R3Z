# Governance handoff packet v0

A **governance handoff packet** is Ward's first executable spine around stewardship, delegation, escalation, currentness, conflict, budget, privacy, and agent boundary evidence.

It is not a new organization model. It is not an IAM policy. It is not a ticket. It is not an incident object. It is a compact packet that lets Ward say one of three useful things:

- this requested action is consequence-grade under current governance evidence;
- this material is useful only for review or routing;
- this request must be refused, rehydrated, escalated, or downgraded.

## Minimum packet sections

1. **subject** — cube, answer family, metric/axis/source/semantic bridge/export/action/remedy/learning subject, CH-AREF-like refs, and source cuts.
2. **requested actions** — actor, principal class, action, consequence class, deadline/urgency, and requested posture.
3. **stewardship charter** — active/stale/orphan/suspended state, permitted duties, excluded powers, currentness, successor/backstop, conflict/quorum posture, and projection class.
4. **delegation warrants** — active/expired/revoked/refused state, delegator, delegatee, granted and denied capabilities, scope, caveats, expiry, no-redelegation, revocation, and result receipt requirement.
5. **escalation handoffs** — trigger, from/to lane, evidence supplied/withheld, acceptance posture, authority requested/granted/denied/still missing, interim effects, deadline, closure, and unresolved gaps.
6. **agent boundary** — tool-call leash, allowed proposal/query/validation posture, no self-approval, no steward-of-record, and no escalation acceptance unless explicitly permitted.
7. **budget and payer** — recompute/export/action spend posture, payer authority, amount/rate/limit, and missing-budget refusal.
8. **privacy/projection** — allowed evidence detail, withheld evidence, public/internal/restricted/sealed/external views, and no-existence-oracle posture.
9. **proof obligations** — PO-GOV-001 through PO-GOV-011 with pass/fail/not-applicable reasons.
10. **evaluated actions** — per actor/action posture: allowed, review-only, routing-hint-only, needs-rehydration, refused, expired, unaccepted, conflict, budget-missing, privacy-blocked, or agent-boundary-violation.

## Required currentness envelope

Every charter, warrant, and handoff that supports an allowed action must carry:

- `effective_from`;
- `source_cut` or evidence cut;
- `last_rehydrated_at`;
- `review_by` or `expires_at`;
- `max_staleness_days` where appropriate;
- `status`;
- `successor_backstop` when relevant;
- `supersedes` / `superseded_by` when relevant;
- `rehydration_result` for fresh consequence-grade use.

Currentness is not an optional note. Succession is a data-quality event.

## Decision states

A packet should use these states rather than an untyped boolean.

- `consequence_grade`
- `review_only`
- `routing_hint_only`
- `needs_rehydration`
- `stale_governance`
- `authority_missing`
- `conflict_unresolved`
- `budget_missing`
- `privacy_projection_block`
- `expired_warrant`
- `handoff_unaccepted`
- `agent_boundary_violation`
- `refuse`

## Non-authority material

The packet may include owner hints, incident routes, ticket identifiers, group names, agent traces, and dashboard owners, but these stay non-authority unless converted through charter/warrant/handoff proof.

Examples of non-authority evidence:

- catalog owner label;
- dashboard owner label;
- CODEOWNERS-like reviewer map;
- on-call schedule;
- Slack assignment;
- ticket assignee;
- agent tool permission;
- successful query/tool execution;
- old answer cut with old steward;
- payer approval for a different action.

## Positive fixture target

The canonical fixture is a provider-risk quarantine repair where:

- business steward is stale;
- technical owner moved teams;
- successor/backstop permits a temporary analyst to inspect, draft repair, validate, and prepare recompute request;
- payer lane accepts recompute budget;
- dashboard export remains held;
- action re-enable remains review-only because the agent can propose but not approve;
- conflicts and projection limits are explicit;
- each allowed action has proof-obligation coverage.

## Negative fixture target

The first negative fixture set must reject catalog-owner approval, on-call-as-steward, expired delegation, ticket assignment as acceptance, agent tool access as stewardship, payer-semantic collapse, privacy break-glass without review debt, old owner map reuse, conflicted reviewer self-approval, and re-delegation creep.


## Pass LXXIX closure additions

The v0 packet now carries two weak-state closures without adding new top-level nouns.

### `routing_hint_mode`

Use this only when an owner/catalog/dashboard label is being shown as a route or review-intake hint. Required posture: enabled, read-only, non-sensitive, promotion-fenced, and projected through public/internal labels only.

### `break_glass` closure

When `break_glass.used` is true, the packet must carry trigger, scope, allowed interim actions, expiry, post-hoc review deadline, rollback plan, and recorded review debt. Break-glass supports only the named interim action and leaves export, remedy, action, and publication held.

### projection views

Public and external views must not reveal sealed conflict details, raw partner fragments, reviewer identities, private org maps, or incident details. This is checked even when the evaluated action is routing-only.


## Pass LXXX derived decision events

A packet may now be projected into one or more `ward.governance-decision-event.v0` records. Each event references exactly one evaluated action by actor/action/posture and binds the source packet by id plus SHA-256 digest. Events exist for Helm rendering, Schell minimization, Harbor recheck, and SlopOS CH-AREF attachment. They do not grant authority, replace packet proof, or expand the action scope.
