# Specimen flow 56 — resolution binding, tier witness, and hybrid seam

Goal: keep Ward honest when one repeated trust question is answered at several fidelities: raw for short horizons, downsampled for long horizons, and materialized-plus-raw for “fresh historical” views.

## Scenario
A team wants one recurring trust question around “high-risk authentication failures by partner and day”:
- the investigation lane wants raw replay over a bounded recent horizon;
- the long-range trend lane wants historical views that may come from retained summaries or downsampled blocks;
- the dashboard lane wants a renderer-safe point count, which may auto-roll up the display;
- the “fresh enough” lane wants materialized daily history plus the newest raw events;
- the chart title looks similar in every lane.

All of these answers can be useful, but Ward refuses to let them share one fake timeless meaning.

## Walkthrough
1. Ward keeps the saved query recipe pinned to one basis, one view binding, and one calendar binding, but any promoted range answer must also carry a **resolution binding**.
2. The recent investigation lane can require raw replay with a fine step. Ward keeps that answer distinct from any long-range retained summary instead of assuming “same recipe” means same fidelity.
3. The long-range trend lane may read from retained/downsampled history. Ward requires a **tier witness** saying whether the answer came from raw replay, retained summary, materialized derivative, display rollup, or another declared tier.
4. If the renderer auto-rolls the visible chart to respect a point budget, Ward keeps that display rollup smaller than the underlying query answer instead of letting the screenshot borrow raw authority.
5. If the “fresh enough” lane stitches materialized daily history with the newest raw events, Ward requires a **hybrid seam** showing where the stitch occurs and what freshness or eventual-consistency bargain it implies.
6. If a long-horizon rerun silently crosses from raw history into downsampled history because retention expired, Ward raises meaning drift instead of pretending only the time range changed.
7. If two dashboards use the same chart title but different steps, different source-resolution caps, or different hybrid-materialization posture, Ward refuses comparability-by-title and preserves the fidelity residue.

## Nouns pressure-tested here
1. **resolution binding**  
   - visible statement of the query step, source resolution, or other declared fidelity width the answer actually used;  
   - smaller than full query contract, smaller than basis pin, and smaller than final local consequence.

2. **tier witness**  
   - visible statement of whether the answer came from raw replay, retained/downsampled history, materialized derivative, display rollup, or another declared storage/serving tier;  
   - smaller than the whole storage architecture and smaller than the answer it helped shape.

3. **hybrid seam**  
   - visible statement of any stitch line where materialized history and fresher raw data, or two retained resolutions, were combined in one answer;  
   - smaller than the full maintenance plan and smaller than any final interpretation of freshness.

## What this specimen must keep separate
- raw replay versus retained or downsampled summary;
- source-tier selection versus renderer rollup;
- one homogeneous answer versus hybrid materialized-plus-raw stitch;
- changed fidelity versus changed facts.

## Promotion gate for these nouns
Do not promote these nouns beyond guidance unless a later specimen shows:
- one raw-only replay answer,
- one long-range retained or downsampled answer,
- one hybrid materialized-plus-raw answer,
- and one comparison surface
surviving the comparison without collapsing into one flattering recurring title.

## Why this matters
Repeated trust questions often live longer than raw retention, and dashboards routinely compress or stitch data to stay fast enough. Systems age badly when raw, downsampled, renderer-rolled, and hybrid answers all pose as the same timeless metric. Ward should therefore keep fidelity/tier residue visibly smaller than fact truth before any repeated answer gets promoted into trusted browse or decision support.
