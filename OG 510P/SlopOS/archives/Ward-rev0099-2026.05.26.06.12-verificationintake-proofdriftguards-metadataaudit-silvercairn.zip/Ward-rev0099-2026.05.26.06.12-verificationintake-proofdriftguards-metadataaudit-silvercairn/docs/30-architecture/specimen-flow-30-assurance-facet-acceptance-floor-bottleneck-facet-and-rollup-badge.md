# Specimen flow 30 — assurance facet, acceptance floor, bottleneck facet, and rollup badge

Goal: keep decomposed assurance visible whenever Ward carries enough information to tempt a local system into one fake scalar trust score.

## Scenario
A local operator wants to use one credentialed workflow for two actions on the same service:
1. **read status** for a managed system; and
2. **change configuration** on that system.

The current login is direct rather than federated.
The subscriber account was previously identity-proofed more strongly than the current authentication ceremony.
The current ceremony is a passkey-backed WebAuthn authentication.
The local environment also has device/appraisal residue from an attesting verifier.

Ward therefore receives a decomposed picture such as:
- identity proofing facet: sufficient for elevated operator identity;
- authentication facet: strong enough for normal operator login;
- federation facet: not claimed here because this is a direct flow;
- authenticator custody facets: `backupEligible` true, `backupState` true, `uvInitialized` true;
- device/appraisal facets: hardware healthy, instance identity healthy, executables weaker than desired for high-risk configuration changes.

The local policy does **not** want one scalar `trust_score = 82`.
Instead it has two **acceptance floors**:
- the read-status action accepts the current authentication facet plus direct-flow no-federation posture;
- the change-configuration action additionally requires the executables facet to clear a stronger local floor.

Ward therefore records:
1. an **assurance facet** bundle rather than one universal score;
2. an **acceptance floor** map keyed by local action/profile;
3. a **bottleneck facet** explaining that the high-risk action was constrained by the executables facet rather than by identity proofing, federation, or backup posture;
4. and, if the product team really wants one summary glyph for the UI, an optional **rollup badge** kept visibly weaker than both the facet bundle and the acceptance-floor map.

## Why this matters
- A high identity-proofing facet should not silently upgrade a weaker current authentication facet.
- A missing federation facet should remain **not claimed**, not silently converted into a default low or default high value.
- Backup/custody posture can matter for some consequences without becoming the sole measure of the current session.
- A single weaker appraisal facet can legitimately narrow only the higher-risk action while leaving the lower-risk action intact.

## Promotion pressure
Do not promote these nouns unless they survive at least:
- one direct-auth specimen with no federation facet claim;
- one federated specimen where IAL/AAL/FAL-style minimums diverge by action;
- one attestation/provenance specimen where a single weaker facet constrains only a subset of actions;
- and one specimen where the rollup badge is intentionally omitted while the facet bundle still drives correct local consequence.
