# Specimen flow 52 — bucket schema, boundary witness, and interpolation posture

Goal: keep Ward honest when one recurring trust question is shown as a distribution or percentile surface rather than as raw replayable rows.

A reviewer asks a recurring question: “How old is the spendable trust material we are relying on right now?”
One team wants a raw frozen result listing each currently spendable subject with `age_since_last_refresh`. Another wants a histogram-shaped derivative for quick browsing. A third wants a single p95 number on a dashboard.

Ward therefore records three separate residues rather than one vague distribution truth:
1. a **bucket schema** for any bucketed derivative, saying whether the grid is explicit, cumulative, exponential, or another declared family and what the relevant boundaries/resolution are;
2. a **boundary witness** saying whether bucket upper/lower bounds are inclusive/exclusive, how zero/underflow/overflow buckets behave, and whether the last bucket hides a meaningful tail;
3. an **interpolation posture** saying whether any percentile/tail answer is exact replay, bucket-interpolated, sketch-estimated, or unavailable.

## Walkthrough
1. Ward first freezes the raw answer as a basis-pinned snapshot result: one row per currently spendable subject with the exact age value and the join clock used to compute it.
2. A browsing derivative is then proposed with explicit boundaries at `1h`, `6h`, `1d`, `3d`, `7d`, and `30d`.
3. Ward records the **bucket schema** instead of letting the chart title imply a timeless “age distribution” truth.
4. Because values above `30d` still matter operationally, Ward records a **boundary witness** explaining that the final bucket is an overflow bucket rather than a precise closed interval.
5. A dashboard then asks for `p95 age_since_last_refresh` from the bucketed derivative. Ward records the **interpolation posture** as bucket-interpolated rather than exact replay.
6. Later, another team imports an exponential-histogram derivative with a different resolution and a downscaled tail view. Ward preserves that as a different bucket schema rather than pretending the new p95 is just a fresher run of the old question.

## Why this specimen matters
- A bucketed derivative is weaker than the raw frozen result that fed it.
- Overflow handling can materially change what “tail” means.
- A percentile derived from buckets is a different truth from an exact percentile replayed from raw rows.
- Downscale-friendly histogram families may be brilliant, but they are still a family choice, not one universal timeless meaning.

## Promotion check
Do not promote `bucket schema`, `boundary witness`, `interpolation posture`, or `perfect subsetting` unless they improve all of the following:
- one explicit-bucket specimen where the last bucket meaning matters;
- one imported/downscaled histogram specimen where family compatibility matters;
- one percentile specimen where interpolation is load-bearing;
- and one raw-replay comparison showing that the distribution derivative stayed smaller than the underlying frozen result.
