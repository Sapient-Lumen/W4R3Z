# Specimen flow 18 — status purpose, recency window, and external status issuer

Goal: keep typed later status meaning, bounded freshness, and status-governance split visibly separate.

## Scenario
A credential, proof, or earlier verification event was accepted before.
Later the receiver consults status material that may come from a separate status issuer or status provider.
The returned status might mean:
- refresh only,
- temporary suspension,
- irreversible revocation,
- or a message that informs local review without invalidating the original witness.

The receiver must decide how long that status is fresh enough to trust, whether the status authority is the original issuer or a distinct actor, and what local consequence follows without erasing historical truth.

## Proposed Ward objects
1. **status purpose**
   - typed meaning for later status;
   - stronger than one generic invalid bit and weaker than local spend/adopt consequence.

2. **recency window**
   - explicit horizon for how long fetched or carried status should influence current local consequence;
   - stronger than folklore freshness and weaker than timeless trust.

3. **external status issuer**
   - typed residue that says later status governance may differ from original issuance;
   - important when regulators, operators, or privacy-preserving status services participate without becoming the original witness authority.

4. **status coordinate**
   - locator for later status material, such as a list position or other smaller-than-meaning reference;
   - useful only if it remains clearly weaker than the status meaning and the local verdict.

## Why this specimen matters
It pressure-tests whether Ward can stay honest when:
- the same status channel serves refresh, suspension, revocation, and message-like updates;
- fetched status is only trustworthy inside a bounded freshness window;
- status may be issued or served by a different authority than the original witness;
- and some trustworthy short-lived material may intentionally have no revocation lane at all.

## Promotion rule
Do not promote `status purpose`, `recency window`, `external status issuer`, or `status coordinate` unless they improve:
- one reversible suspension specimen,
- one refresh-without-invalidation specimen,
- one external-status-authority specimen,
- and one short-lived/no-status specimen that proves Ward can stay truthful without universal live revocation.
