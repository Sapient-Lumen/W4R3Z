# Specimen flow 63 — uncertainty envelope, degradation receipt, and budget gate

## Goal

Pressure-test the next careful datacube step for Ward: when a SlopOS-facing trust answer cannot be served exactly under the current budgets, Ward must preserve what was requested, what was served, why it was weaker, what uncertainty it carries, and whether it can influence consequence.

## Scenario

A Helm review surface asks Ward for a consequence-grade SlopOS partner-trust comparison:

- exact distinct affected subjects by partner and week for the current quarter;
- p95 time-to-remediation by partner class;
- quality failures and validation details for the affected cohorts;
- representative examples for the largest deterioration cell;
- exportable table for a review queue;
- answer returned within an interactive latency budget.

The exact query would need a wider raw replay than the interactive budget allows. Some cells are privacy-shaped. The validation owner can see complete quality detail, but the reviewer can only see summary-level validation. The agent asks whether a fast approximate preview is good enough to start a promotion.

Without pass LXVI residue, Ward can accidentally let a sketch, sample, noisy count, summary-only validation result, or top-k truncation look like the exact consequence-grade answer originally requested.

## Walkthrough

1. **Ward identifies the requested answer capsule shape.** It records scope lens, state cut witness, query contract, metric card, axis capsule, comparability requirement, privacy posture, expected render/egress posture, and consequence class before considering shortcuts.

2. **Ward opens a budget gate.** The gate names requester view, actor class (`human_reviewer`, `agent_assistant`, `helm_surface`), requested answer shape, consequence class, and relevant budget lanes: interactive latency, raw-scan/resource, warehouse-cost, privacy loss, egress rows/cells, validation-detail exposure, and exemplar detail.

3. **The gate refuses hidden exact execution.** The exact raw replay would exceed the interactive resource/latency gate. Ward does not silently run a broader query, borrow an ambient payer, or widen authority. It records `exact_now_refused` with safe reason class `resource_latency_gate`.

4. **Ward evaluates safe degraded alternatives.** It considers a retained HLL/sketch distinct-count sidecar, a T-Digest/remediation-quantile sidecar, a sampled preview for one non-consequential overview, and an exact recompute docket for later review. Each alternative is checked against scope, privacy, quality, and comparability posture.

5. **Ward creates a degradation receipt for the preview.** The receipt says the requested answer was `exact_current_consequence_grade`, while the served answer is `review_only_sketch_and_summary_preview`. It names loss classes: `exact_to_sketch`, `exact_p95_to_quantile_estimate`, `complete_validation_to_summary`, `exemplar_detail_to_aggregate_only`, and `interactive_now_to_recompute_pending`.

6. **Ward attaches an uncertainty envelope.** The envelope composes existing residue: exactness class, estimator/sketch witnesses, sample witness if used, privacy noise/suppression posture, quality witness summary, freshness envelope, resolution/tier witness, nondeterminism/repeatability posture, and cells where no safe uncertainty detail may be revealed.

7. **The privacy-shaped cells remain non-oracular.** If a cell is suppressed or noisy, Ward reports a safe class such as `privacy_withheld_or_noisy` without revealing whether the true hidden count was just below threshold, above row limit, or absent.

8. **Validation detail is bounded by authority.** The reviewer sees summary-level quality witness and affected safe classes. The owner can inspect complete validation detail through a separate authorized view. The summary-only posture is part of the uncertainty envelope, not a missing check.

9. **The agent cannot promote the preview.** Ward marks the answer `review_only`. A promotion gate sees the degradation receipt and refuses consequence-grade promotion until exact recompute, accepted approximation policy, or a narrower consequence class is explicitly approved.

10. **A recompute docket is opened.** The docket says what exact repair is owed: raw replay under an explicit batch budget, renewed privacy accounting, quality witness rerun, comparability passport check, and replacement/confirmation of the preview.

11. **Helm renders with degradation visible.** The render contract shows `sketch preview`, `summary validation`, `privacy-shaped cells`, `exact recompute pending`, and `not consequence-grade`. It must not display the chart title as if it were the exact current-quarter partner trust answer.

12. **Export receives egress posture.** If the preview table leaves Helm, the egress receipt says it is a review-only degraded artifact with uncertainty envelope attached, not a live capability or exact answer.

13. **Later exact recompute reconciles the preview.** If the exact answer materially differs, Ward emits an invalidation receipt for the preview, updates comparability/degradation posture, and keeps the preview as reviewable historical material only when policy allows.

14. **Audit can reconstruct without leaking.** An authorized reviewer can see the requested-versus-served shape, gate outcome, degradation classes, uncertainty envelope, and recompute status. Denied cells, hidden cohorts, and suppressed exemplar counts remain protected.

## Nouns pressure-tested

- **budget gate** — compact answer-attempt admission residue naming relevant resource, latency, cost, privacy, egress, validation-detail, exemplar-detail, payer/sponsor, and capability-scope constraints plus outcome/refusal/degradation options.
- **degradation receipt** — compact record that the served answer is weaker or different from the requested answer, naming loss classes, trigger, affected safe scope, accepted/refused posture, and any recompute or rehydration path.
- **uncertainty envelope** — compact wrapper that composes exactness, estimator/sketch, sample, privacy, quality, freshness, tier, nondeterminism, and detail-exposure residue so rendered or exported answers cannot hide their strength class.

## Why this preserves optionality

This specimen does not choose a warehouse, OLAP engine, approximate-query processor, sketch library, differential-privacy system, budget scheduler, billing model, dashboard badge set, or statistical interval DSL. It can work with SlopOS bounded view-scoped queries, Harbor exactness and evidence grades, Foundry basis cuts, Steward recompute/followthrough, Schell runtime epochs, ViewFS stable handles, and Helm review queues.

The promoted thing remains smaller than an engine or budget system: answer-attempt hygiene whose authority is limited by budget gates, degradation receipts, uncertainty envelopes, and the existing exactness/sample/privacy/freshness/render/egress residues.

## Open pressure

- Should a budget gate be mandatory for all agent-initiated cube queries or only consequence-grade / expensive / privacy-shaped attempts?
- Should a degraded preview always open an exact recompute docket, or only when a reviewer requests promotion?
- Can an uncertainty envelope be compact enough for every cell, or should it often attach at measure/segment/render level?
- How can Ward compare two uncertainty envelopes when one is sketch-based and the other is noisy/private or sample-based?
- Should budget gates propose multiple degraded alternatives, or is that too much planner behavior for Ward?
- Can budget-exceeded or row-limit messaging stay useful without revealing denied population size?
- When can an approximate answer ever be consequence-grade, and what acceptance floor would that require?
