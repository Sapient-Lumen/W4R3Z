# Specimen flow 93 — outcome observations, rollback guards, and fixture catalog audit

## Scenario

A public Ward status chip was allowed by a reuse gate and recorded by a use-execution receipt as `public_minimized_display`. Later, the observing surface must prove whether that display actually occurred without leaking private receiver details or converting observation into authority.

## Flow

1. The outcome-observation receipt references the use-execution receipt by path and byte digest.
2. The receipt mirrors source execution state, execution id, expected effect, recipient class, projection policy, target, and actual-effect digest.
3. The observer records the observed effect, observed target, observed recipient class, observed projection policy, and observation window.
4. The observed-outcome digest binds the minimized observation sample.
5. If the observed effect matches the execution receipt, the receipt records a matched outcome and keeps refresh required.
6. If the observed effect diverges, the receipt records `observed_mismatch_quarantined_rollback_required` and requests rollback review without performing rollback.
7. If no reliable observation exists, the receipt records a hold and makes no match claim.

## Negative path

`tools/check_governance_outcome_observations.py` rejects fixtures where the observed effect drifts but is claimed matched, a mismatch lacks quarantine or rollback review, a public observation leaks sealed/private material, a no-observation state is rendered green, or the receipt mutates the source use-execution/status pointer.

## Fixture-catalog audit

The pass also adds a fixture-catalog checker so every registry-backed governance fixture family keeps the same positive/negative layout and schema identity discipline.
