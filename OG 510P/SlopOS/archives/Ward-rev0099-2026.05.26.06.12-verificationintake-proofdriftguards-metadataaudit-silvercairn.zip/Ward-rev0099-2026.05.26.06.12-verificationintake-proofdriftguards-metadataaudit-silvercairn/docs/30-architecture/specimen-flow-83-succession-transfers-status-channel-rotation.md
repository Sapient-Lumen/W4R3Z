# Specimen flow 83 — succession transfers and status-channel rotation

## Situation

A public Ward owner-routing release was acknowledged by a recipient. Later, the public contact channel moved. Separately, an expired release was revoked, a restricted review bundle was quarantined after projection-policy drift, and a public sealed-omission release was corrected.

Each chain now needs a current responsibility/status path.

## Bad collapse

The bad implementation updates the owner/contact label in place and lets old status URLs keep resolving. Some consumers see the old steward, others see the new one, and nobody can tell whether the successor accepted, refused, or is still pending.

This collapses transfer, authority, status, projection, and currentness.

## Ward residue

The flow introduces `ward.governance.succession-transfer-receipt.v0`.

It records:

- source release and latest follow-up references with byte digests;
- transfer kind and scope;
- predecessor notification and no-continuing-authority posture;
- successor acceptance or pending state;
- source release recipient, purpose, item digest, and projection policy;
- old status channel and new status pointer;
- public successor-identity minimization;
- forbidden-effect preservation;
- no-authority label.

## Safe paths

- A public recipient-contact transfer becomes `transfer_recorded` with refresh required.
- A revoked public release gets `rotation_recorded` status-only channel rotation.
- A restricted steward successor remains `successor_pending_recheck` until accepted.
- A projection-policy steward transfer becomes `transfer_recorded` without exposing private steward identities.

## Rejected paths

Ward rejects:

- missing successor acceptance time;
- old status channel left active;
- scope expansion;
- successor treated as authority;
- source release or follow-up digest mismatch;
- pending successor reuse;
- public private-steward leakage;
- dropped forbidden effects;
- high-consequence transfer actions;
- predecessor continuing authority;
- unrotated status pointer;
- purpose drift;
- missing no-authority label.

## Product line

A successor label is a routing/status fact, not authority:

> “Transfer recorded. Not authority. Refresh current status and replay the source packet before reuse.”
