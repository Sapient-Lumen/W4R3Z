# Signal ingestion, receiver observations, and race guards

Pass XC adds the layer after recertification: how Ward receives refresh/revocation/status signals without letting signal transport become governance authority.

## Position in the spine

```text
governance handoff packet
  -> governance decision event
    -> governance decision consumer receipt
      -> governance batch/search receipt
        -> governance search-continuity receipt
          -> governance evidence-release receipt
            -> governance evidence-release follow-up receipt
              -> governance succession/transfer receipt
                -> governance chain-integrity receipt
                  -> governance dispute-resolution receipt
                    -> governance recertification receipt
                      -> governance signal-ingestion receipt
```

A signal-ingestion receipt is a receiver-local observation. It may request recertification, publish a refresh signal, or hold a conflict. It cannot approve action, mutate the source recertification receipt, or prove that all consumers refreshed.

## Why this exists

Rev0089 lets Ward recertify or invalidate cached dispute-resolution evidence, but the trigger evidence was still too abstract. Real systems deliver signals through push, poll, batch, manual review, status lists, channel rotations, and detached exported bundles. Those transports duplicate, reorder, race, get acknowledged before local action, and can be observed by only one receiver.

The new receipt answers: “What exactly did this receiver see, which prior watermark and duplicate window were checked, what subject was bound, did the signal change basis, and what follow-up is required?”

## Race rules

- `source + id` / canonical event key identifies duplicates, not independent basis changes.
- Sequence or watermark regression cannot become current state.
- Conflicting signals produce `conflicting_signals_held`, not “latest wins.”
- Push acknowledgement is delivery evidence only.
- Poll order is delivery order only.
- A basis-changing signal requires recertification before cache reuse.
- A cache-invalidation signal can drive invalidation posture, but not action, export, remedy, repair, learning use, delegation, budget spend, or privacy waiver.

## Neighbor behavior

- **SlopOS** should treat signal ingestion as a trigger for recheckpoint/replay, not as a CH-AREF grant or portal permission.
- **ViewFS** should render accepted, duplicate, stale, conflicting, irrelevant, and rejected signal states distinctly.
- **Schell** should minimize public signal payloads while retaining event key, subject digest, source recertification digest, and high-watermark evidence.
- **Harbor** should not use a signal alone to update stale-surface messaging; it should wait for recertification or release follow-up state.
- **Helm** should display receiver observation and race-hold chips rather than green authority badges.
