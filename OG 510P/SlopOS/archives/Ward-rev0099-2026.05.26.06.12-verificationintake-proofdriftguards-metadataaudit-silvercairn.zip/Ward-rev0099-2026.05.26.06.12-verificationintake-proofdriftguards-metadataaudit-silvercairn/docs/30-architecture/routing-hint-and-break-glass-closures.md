# Routing-hint and break-glass closures

Pass LXXIX adds two closures to the governance handoff packet surface.

## Routing-hint closure

A routing hint is allowed only when it is deliberately weak.

Minimum fields:

- `routing_hint_mode.enabled = true`
- `read_only = true`
- `evidence_detail` is `public_label_only`, `internal_label_only`, or `redacted_route_only`
- `sensitive_evidence_carried = false`
- forbidden promotions include semantic repair, dashboard export, action re-enable, privacy waiver, and budget spend
- public/external projections do not expose sealed governance evidence

Safe actions:

- `route_to_steward`
- `surface_owner_hint`
- `open_review_hint`
- `suggest_contact`

A routing hint can say “ask this lane” or “this label may help you file a review.” It cannot say “this lane approved.”

## Break-glass closure

Break-glass is not a waiver. It is an expiring emergency state with review debt.

Minimum fields:

- `used = true`
- `trigger`
- `scope`
- `allowed_interim_actions`
- `expires_at`
- `post_hoc_review_by`
- `rollback_plan`
- `review_debt_recorded = true`
- `review_debt_ref`

Break-glass can support only the named interim action. It does not grant export, remedy, action re-enable, learning use, semantic repair approval, or privacy disclosure outside the sealed scope.

## Projection closure

Governance evidence may be more sensitive than the answer it governs. Public or external views must not disclose:

- sealed conflict details;
- raw partner fragments;
- reviewer identities;
- private org maps;
- incident details.

This lets Ward prove authority without turning governance evidence into an oracle over people, partners, incidents, or internal control structure.

## Checker posture

`tools/check_governance_handoff.py` now checks these closures across positive and negative fixtures. The goal is not a full policy engine. The goal is to make the next obvious false promotions fail in CI.
