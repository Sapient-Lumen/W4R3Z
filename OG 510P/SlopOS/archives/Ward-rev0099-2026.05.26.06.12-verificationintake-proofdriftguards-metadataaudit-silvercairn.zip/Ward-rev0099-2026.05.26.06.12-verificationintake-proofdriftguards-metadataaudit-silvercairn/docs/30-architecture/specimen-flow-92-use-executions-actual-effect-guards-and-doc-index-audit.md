# Specimen flow 92 — use executions, actual-effect guards, and doc index audit

## Scenario

A public Ward status chip is rendered after a reuse gate says `display_reuse_allowed_refresh_required`. The renderer wants to show a minimized “route only; not authority” badge.

## Flow

1. The renderer references the reuse-gate receipt by path and byte digest.
2. The use-execution receipt mirrors gate state, purpose, requested effect, recipient class, projection policy, and gate window.
3. The receipt records the actual effect: `public_minimized_display`.
4. The actual-effect digest binds the target, actor class, effect, recipient class, and projection policy.
5. The projection closure proves no receiver identity, status-channel detail, sealed gate payload, private org map, or raw partner fragment leaked.
6. The effect closure records no status-pointer mutation, no export, no repair, no remedy, no learning use, and no authority upgrade.

## Negative path

If the same gate is consumed by an export path, action bridge, semantic repair, stale receiver-gap render, or status-pointer writeback, `tools/check_governance_use_executions.py` rejects the fixture.

## Doc-index audit

The pass also adds a documentation-index checker so the latest receipt family, specimen, and current revision cannot be missing from the public map of the cube.
