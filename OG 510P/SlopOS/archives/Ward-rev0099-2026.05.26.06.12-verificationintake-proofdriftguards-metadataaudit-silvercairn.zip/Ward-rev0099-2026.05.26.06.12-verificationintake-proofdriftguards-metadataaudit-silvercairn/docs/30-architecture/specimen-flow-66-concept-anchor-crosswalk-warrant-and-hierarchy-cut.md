# Specimen flow 66 — concept anchor, crosswalk warrant, and hierarchy cut

## Why this specimen exists

A SlopOS-facing datacube can be perfectly scoped, fresh, validated, budgeted, and federated, then still mislead because an axis label changed. A provider family may be renamed. A risk bucket may split. A partner may supply a free-form tag that looks like a governed term. A glossary hierarchy may acquire a new parent. A rendered chart may show the same title even though the semantic membership behind one line changed.

This specimen keeps semantic drift small and answer-local. It does not introduce a Ward ontology, terminology server, universal concept graph, glossary product, or taxonomy engine.

## Scenario

A reviewer asks:

> For this SlopOS-authorized view, which credential-provider risk families deteriorated month-over-month, and which evidence families explain the movement?

The answer touches:

- a SlopOS CH-ATTR field whose display label changed from `browser_federation` to `fedcm_browser_mediation`;
- a Steward activation-cause family that split `setup_failure` into `setup_policy_denied` and `setup_user_abandoned`;
- a Harbor evidence summary with codes that are not the same thing as outcome buckets;
- a Foundry semantic spine label used by a companion dashboard;
- a partner free-form tag `delegated_login_setup`;
- a hierarchy where `federated credential setup` is an abstract rollup node, not a directly observed fact bucket;
- an old Helm export that still shows the earlier label.

A smooth month-over-month chart would be dangerous unless the answer can say which concepts stayed the same, which labels changed, which mappings were warranted, and which hierarchy membership cut was used.

## Candidate residues

### Concept anchor

A compact semantic identity card for a consequence-grade axis, member, status, code, term, bucket, or unit-like qualifier.

Suggested fields:

- `anchor_id` or source-local handle;
- source or vocabulary family;
- concept kind: axis, member, status, code, measure qualifier, unit-like concept, hierarchy node;
- owner/reviewer and governance status;
- definition handle or digest;
- version, effective interval, and state cut;
- label snapshots with locale/display posture;
- deprecation/supersession posture;
- selectable versus abstract posture;
- sensitivity, policy, or privacy tags;
- whether the anchor is authoritative, imported, derived, or review-only.

A concept anchor is stronger than a label and smaller than an ontology.

### Crosswalk warrant

A compact bridge record that says whether one concept/member/code/term/tag may stand in relation to another for this answer context.

Suggested fields:

- source anchor and target anchor;
- direction: source-to-target, target-to-source, bidirectional, comparison-only, display-only;
- relationship grade: exact, equivalent, close, broader, narrower, related, deprecated-to, split-from, merge-into, no-map, unknown;
- cardinality: one-to-one, one-to-many, many-to-one, many-to-many;
- split/merge loss notes and residual bucket handling;
- effective period and mapping cut;
- author/reviewer/evidence handle;
- confidence or review posture;
- affected cells, axes, comparisons, explanations, and exports;
- refusal posture when no safe bridge exists.

A crosswalk warrant is stronger than “same name” and smaller than a mapping engine.

### Hierarchy cut

A compact rollup/classification membership snapshot for one answer, comparison, render, or export.

Suggested fields:

- scheme/root and owner;
- hierarchy version/cut/effective interval;
- parent/child closure or rule reference;
- multiple-parent posture;
- abstract/selectable member posture;
- subtotal, all, unknown, unmapped, and other semantics;
- rollup law and aggregation constraints;
- excluded members and no-map members;
- whether the hierarchy is authoritative, imported, inferred, or review-only;
- privacy/suppression interaction for low-count or unmapped children.

A hierarchy cut is stronger than a visual tree and smaller than a taxonomy platform.

## Flow

1. **Open the ordinary answer authority.** Start with scope lens, state cut witness, metric card, axis capsule, grain witness, quality witness, freshness envelope, comparability passport, privacy/suppression posture, and federation/projection residue where relevant.

2. **Attach concept anchors to consequence-grade groupable things.** Every displayed provider family, risk family, evidence family, status bucket, or rollup node that can affect consequence receives a concept anchor or an explicit `anchor_missing` refusal/degradation state.

3. **Keep labels in the label lane.** `browser_federation`, `FedCM browser mediation`, localized captions, partner-friendly names, and exported column headings are label snapshots. They can be useful, but they do not decide identity by themselves.

4. **Require crosswalk warrants before bridge claims.** The old `browser_federation` member cannot be compared with `fedcm_browser_mediation` merely because the names look related. The Steward split from `setup_failure` into two new buckets needs one-to-many mapping posture and residual loss notes. The partner tag `delegated_login_setup` starts as review-only or close-match until warranted.

5. **Make no-map visible.** If Harbor code families do not map to Ward outcome buckets, the answer should expose `no_map`, `bridge_required`, or `review_only` posture rather than dropping the rows into `Other` or silently excluding them.

6. **Freeze hierarchy membership for the answer.** A hierarchy cut states whether `federated credential setup` is an abstract rollup node, which children were included, how multiple parents were handled, and what happened to unmapped children.

7. **Push semantic drift into comparison and explanation.** A comparability passport must account for crosswalk warrants. A delta anatomy must separate metric movement from semantic-bucket movement. An attribution rail must not say “risk worsened because FedCM failed” if the only movement is a category split.

8. **Carry semantic residue through rendering and egress.** A render contract can show friendly labels, but the egress receipt for a CSV, screenshot, or agent summary should retain the concept anchors, crosswalk warrants, hierarchy cut, and label snapshots needed to rehydrate or fence it later.

9. **Refuse when semantic authority would leak.** If revealing that an unmapped partner tag exists would leak a suppressed cohort or denied participant, the refusal receipt should state semantic bridge withheld rather than exposing the member in a chart.

10. **Do not rewrite old exports.** The old Helm export remains historically reviewable under its old label snapshot and hierarchy cut. It becomes current authority only if rehydrated through present scope, policy, concept anchors, crosswalk warrants, and comparability posture.

## Healthy outputs

A healthy answer can say:

- `same_anchor`: label changed, concept identity remained stable under this answer cut;
- `bridged`: mapping warranted with grade and effective period;
- `bridge_required`: data exists but semantic bridge is not strong enough for consequence;
- `split_or_merge`: historical restatement requires explicit loss/fanout posture;
- `hierarchy_cut_changed`: rollup membership changed since the compared answer;
- `no_map`: a code/member/tag exists but cannot be safely grouped;
- `semantic_refusal`: answering would overclaim meaning or leak hidden membership.

## Promotion gate

Promote concept anchor, crosswalk warrant, and hierarchy cut only if they keep at least these seven cases honest:

1. a pure label rename;
2. a bucket split;
3. a bucket merge;
4. a partner free-form tag;
5. an abstract hierarchy node;
6. a no-map privacy-sensitive member; and
7. an old export being reinterpreted after current labels changed.

The specimen passes only if the smooth chart is weaker than its semantic residues.
