# Specimen flow 41 — staged derivative, publish rail, and change witness

Goal: keep candidate maintained derivatives, explicit publication, and typed replacement diffs visibly separate whenever Ward revises a promoted trust exploration.

## Scenario
A trust team already has a repeatedly used saved exploration `Q7` with:
- basis pin `B10`,
- join clock `JC-policy-effective`,
- workload witness `W3`,
- and one active maintained derivative `D1` that powers an internal review board.

A schema cleanup and a better enrichment rule are proposed. The team wants the derivative to improve without quietly mutating the current board out from under reviewers.

## Desired flow
1. Ward keeps `Q7` as the saved recipe and leaves prior frozen result `S1` untouched.
2. A new candidate `D1-stage` is created as a **staged derivative**. It hydrates in the background using validation basis `B11` and the declared join clock `JC-policy-effective`.
3. Reviewers can inspect `D1-stage` before it is official.
4. Ward computes a **change witness** between active `D1` and `D1-stage`, showing which rows or grouped outputs were inserted, deleted, or updated and whether the movement came from recipe change, basis movement, or both.
5. Only after human review does Ward cross a **publish rail** that swaps the active maintained derivative from `D1` to `D2`.
6. Downstream consumers keep one stable name, but the archive preserves that `D1-stage` was merely candidate until the publish event.
7. If the candidate fails review, Ward abandons `D1-stage` without mutating `D1`, `S1`, or the historical audit trail.

## What Ward must keep distinct
1. **staged derivative**  
   - candidate maintained surface under hydration or review;  
   - may be queryable for validation;  
   - is still weaker than the active derivative.

2. **publish rail**  
   - explicit action that makes the candidate official;  
   - should be transcript-visible and reviewable;  
   - should not fire automatically just because hydration completed.

3. **change witness**  
   - typed inserted/deleted/updated diff between active and candidate outputs;  
   - smaller than the full derivative but stronger than a generic `updated` badge;  
   - useful both for review and for later audit.

## Questions this specimen pressures
- Does Ward need a first-class `staged derivative` noun, or is it just one internal implementation trick inside promotion bay?
- Should `change witness` stay a datacube-side review surface, or graduate into a durable archive artifact later?
- Can Ward keep publish explicit without overcommitting to one engine's native branch/swap semantics?

## Why this specimen matters
If Ward cannot survive this specimen without collapsing saved recipe, frozen result, staged candidate, active derivative, and typed diff into one magic current object, then the datacube is still deciding too much too early.
