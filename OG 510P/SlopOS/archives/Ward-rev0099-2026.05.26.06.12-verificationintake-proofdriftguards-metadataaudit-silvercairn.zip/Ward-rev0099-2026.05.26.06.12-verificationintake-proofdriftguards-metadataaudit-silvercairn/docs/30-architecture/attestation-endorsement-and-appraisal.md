# Attestation, endorsement, and appraisal

The attestation side of Ward should stay faithful to the RATS lesson:
evidence, endorsements, and appraisal are different roles in the trust story.

A healthy Ward flow looks like:
- receive evidence,
- gather endorsements or trust anchors,
- apply local appraisal policy,
- emit a local result,
- mint only the consequences justified by that result.

This is the right place to keep freshness and revocation visible as side inputs rather than hiding them inside one magical token.

Foundry may hand Ward runtime evidence. Harbor may hand Ward callback-derived artifacts.
Ward’s job is to explain how those become a verdict — or why they do not.

When Ward records a result that may matter later, it should ideally also preserve which appraisal recipe or policy epoch produced it. Otherwise later readers cannot tell whether a changed result reflects changed evidence, changed interpretation, or both.
