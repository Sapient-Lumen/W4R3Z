# Promotion gates and specimen tests

Ward should not promote a new durable noun unless it survives at least one specimen flow.

## Promotion gates
1. A proposed object must identify which stronger judgments it refuses to make.
2. It must keep custody, evidence, endorsement, appraisal, and spendable consequence visibly separate.
3. It must survive at least one human credential flow and one machine-evidence flow.
4. It must say whether freshness, backup, sync, or recovery posture materially changes its meaning.
5. If it bears later status, it must say how stale/frozen posture differs from negative status and how mixed-era material is rejected.
6. If it relies on status absence, it must say whether the result is coverage-scoped, proof-carrying, or merely heuristic.
7. If it classifies later state, it must say whether classification can exist without automatic consequence and how a weaker-looking action proves it really narrows spend.
8. If it bears later-change timing, it must distinguish effective change time, publication/signing time, known-correct interval, and local adoption time whenever those differ.
9. If it bears result meaning that depends on a particular evaluation recipe, it must say how policy identifiers, label schemes, trust-root selection, and replay under changed policy stay visible.
10. If it bears later events or watches, it must say how duplicate delivery, out-of-order receipt, verification pings, and receiver-local application stay visibly different.
11. If it bears commitment or finality semantics, it must distinguish acceptance, durable commitment, stable-readable exposure, and hard-to-reverse posture whenever those differ.
12. If it enriches facts with time-varying context, it must say which join clock and carry-forward rule it used and how frozen results differ from later reruns or live feeds.

## First specimen tests
- synced-passkey versus device-bound-passkey custody comparison;
- attestation evidence plus endorsement plus local appraisal plus freshness-labeled verdict;
- provenance review where artifact signature, provenance existence, and local admission stay separate;
- device-bound session hardening case that improves theft resistance without pretending to be broad identity proof.
- status-purpose specimen where refresh, suspension, revocation, and message do not collapse into one invalid bit.
- status-snapshot specimen where coherent-together status, stale/freeze posture, and negative meaning stay separate.
- state-class specimen where observation, quarantine, and denial stay visibly distinct local actions.
- time-layered later-state specimen where effective change, publication, and local adoption stay visibly different.
- recipe-sensitive result specimen where the same witness material is replayed under a changed appraisal recipe without historical amnesia.
- event-application specimen where duplicate delivery, out-of-order receipt, and receiver-local application do not collapse into one fake timeline.

- commitment/finality specimen where one change is acknowledged, quorum-committed, reader-lagged, and only later strong enough for the highest-risk consequence.

- temporal-lookup specimen where the same recipe is run under at least two join clocks and one frozen result is later compared against an explicit rerun diff.
13. If it publishes one repeated analytic question or one recurring human-facing measure, it must declare grain, measure meaning, required headers, caveats, and any loss fence before any rollup-backed surface can pose as general truth.
14. If it publishes an approximate or sketch-backed analytic surface, it must declare exactness class, estimator family, mergeability, precision/tuning posture, and whether the durable residue is a rendered estimate or a mergeable sketch witness.
15. If it publishes a recurring measure or derivative intended for regrouping beyond its original cut, it must declare aggregation law, allowed rollups, forbidden recompositions, and whether higher-level totals require replay or merge state.
16. If it publishes a recurring question that crosses grains or any regroupable rate/average/ratio, it must declare base fact grain, duplication posture at each fanout-prone join, and whether a denominator/weight carrier survives or replay is required.
17. If it publishes a densified or gap-filled recurring surface, it must declare which buckets were synthetic, what gap posture applies to missingness, and which values were filled, carried forward, interpolated, or left null on purpose.
18. If it publishes a recurring question across more than one authorized audience or access lane, it must declare the view binding, population witness, and any scope drift before two outputs can borrow each other's authority.

- contract-before-rollup specimen where one repeated question earns a query contract, one metric card explains the recurring measure, and one lossy derivative remains visibly loss-fenced.
- approximation-honesty specimen where one repeated question keeps an exact frozen result, one accelerated derivative carries an estimator card and exactness class, and one optional sketch witness remains visibly different from the rendered estimate.
- aggregation-law specimen where one repeated question carries additive event counts, non-additive distinct totals, one semiadditive snapshot, and one merge-state-backed derivative without flattening them into one fake cube fact.
- grain-and-fanout specimen where one repeated question crosses at least one fanout-prone join and one regroupable ratio/average, and Ward preserves grain witness, fanout fence, and weight carrier instead of silently multiplying rows or averaging averages.
- gap-posture specimen where one sparse recurring question is aligned onto generated buckets and Ward preserves gap posture, fill witness, and synthetic-bucket honesty instead of silently zero-filling or carrying forward forever.

- scope-bound recurring-question specimen where one recipe survives at least one broader internal view, one narrower filtered view, and one credential-lane shift without flattening scope drift into fact drift.
19. If it publishes a recurring question grouped by day, week, month, or similar civil periods, it must declare the calendar binding, timezone witness, and any boundary drift before two outputs can borrow each other's authority.

- calendrical-grouping specimen where one recipe survives at least one UTC-versus-local regrouping, one ISO-week-versus-Sunday-week rerun, and one DST or year-boundary review without flattening boundary drift into fact drift.
20. If it publishes a recurring sampled preview or fast approximate browse surface, it must declare the sample witness, selection stage, and repeatability lane before the preview can borrow the authority of an exact recurring question.

- sampling-honesty specimen where one repeated question keeps an exact frozen result, one sampled preview declares family/rate/correction, one join-sensitive rerun moves the sampling stage, and Ward preserves repeatability posture instead of flattening them into one “fast mode” answer.
21. If it publishes a recurring distribution or percentile surface, it must declare the bucket schema, boundary witness, and interpolation posture before the surface can borrow the authority of a raw repeated question.

- distribution-surface specimen where one repeated question keeps a raw frozen result, one bucketed derivative declares family/boundaries/overflow posture, one percentile stays visibly interpolated or sketch-estimated, and Ward preserves distribution semantics instead of flattening them into one fake p95 truth.
- temporality-honesty specimen where one repeated question keeps cumulative, delta, snapshot, and derived-rate surfaces visibly separate, and one reset witness prevents a flattering uninterrupted line from borrowing base-series authority.
22. If it publishes a trend, before/after chart, cohort contrast, or rerun-vs-history comparison, it must declare a comparability passport, drift notices, quality witnesses, and any bridge/refusal posture before the comparison can influence local trust consequence.

- comparability-honesty specimen where one recurring question compares old and new SlopOS answer capsules across a scope change, metric-card drift, quality warning, and privacy/refusal change, and Ward either bridges explicitly or refuses the smooth trend.
23. If it publishes a why-answer, explanation panel, LLM-written summary, drill-through story, or root-cause hint for a changed recurring answer, it must declare delta anatomy, attribution rails, exemplar fences, and residual unexplained movement before the explanation can influence local trust consequence.

- explanation-honesty specimen where one SlopOS trust-deterioration comparison is explained across scope movement, metric drift, label bridge, late corrections, quality/refusal movement, privacy suppression, cohort contrast, fenced exemplars, and an unsupported causal summary without flattening them into one root cause.

## rev0064 pressure note
- cache hit versus answer authority;
- freshness target versus observed lag;
- incremental eligibility versus generic refresh success;
- invalidation receipt versus physical delete;
- recompute docket versus hidden scheduler queue;
- stale-but-reviewable answer versus current consequence-grade answer.



## Pass LXV promotion gates

Before promoting interaction trail, render contract, or egress receipt into stronger machine-readable contracts, Ward needs specimen evidence that:

- filters, parameters, drills, pivots, sorts, refreshes, annotations, exports, and agent follow-ups can be recorded without creating a hidden surveillance or inventory surface;
- render transforms such as top-k, sorting, binning, aggregation, current-layout flattening, “other” buckets, suppression, and precision changes can be exposed without binding Ward to one renderer;
- detached artifacts can carry scope, inclusion/omission, redaction, sensitivity, expiry, stale, and invalidation posture without becoming live handles;
- drill-through and export limits can refuse safely without leaking denied population or suppressed-cell existence;
- agents can use interaction/egress residue as context while rehydrating through current authority before consequential follow-up.

## Pass LXVI promotion gates

Before promoting budget gate, degradation receipt, or uncertainty envelope into stronger machine-readable contracts, Ward needs specimen evidence that:

- resource, latency, cost, privacy, egress/detail, exemplar, payer/sponsor, and capability limits can be separated without importing SlopOS D-BUDGET/D-METER as a global cube scheduler;
- requested-versus-served weakening can be recorded without leaking denied population or suppressed-cell existence;
- exactness, estimator/sketch, sample, noise/suppression, quality, freshness, tier, nondeterminism, and validation-detail posture can compose into one inspectable uncertainty envelope without freezing a universal statistics DSL;
- agents and dashboards can offer review-only degraded previews while refusing consequence-grade promotion until an acceptance floor explicitly allows it;
- exact recompute, invalidation, and stale-preview narrowing stay visible as process residue rather than hidden ops behavior.

## rev0066 pressure note
- budget gate versus hidden scheduler or ambient payer;
- degradation receipt versus quiet fallback;
- uncertainty envelope versus one flattering warning badge;
- review-only approximation versus consequence-grade exact answer;
- budget-exceeded/refused posture versus denied-population oracle.

## Pass LXVII promotion gates

Before promoting correction horizon, backfill ledger, or revocation fence into stronger machine-readable contracts, Ward needs specimen evidence that:

- event time, effective/valid time, ingestion time, publication time, local adoption time, and answer-production time can be separated without freezing a bitemporal database;
- retained change-feed, time-travel, snapshot, compacted-survivor, and raw-replay coverage can be summarized without leaking denied or suppressed populations;
- a backfill campaign can record reason, authority, recipe/run, validation, invalidated/replaced outputs, and residual gaps without becoming a scheduler or workflow engine;
- hard delete, trust revocation, privacy suppression, legal erasure, and source absence can remain distinct answer states;
- old answer capsules, egress artifacts, screenshots, and agent summaries can be fenced from consequence without promising global recall;
- comparison/explanation/render/export surfaces can degrade or bridge explicitly after repair instead of inheriting smooth continuity.

## rev0067 pressure note
- correction horizon versus fake finality;
- backfill ledger versus silent historical rewrite;
- revocation fence versus stale warning or global recall fantasy;
- change-feed gap versus proof of no change;
- explicit delete/revoke state versus source absence.

## Pass LXVIII promotion gates

Before promoting federation pact, join warrant, or projection curtain into stronger machine-readable contracts, Ward needs specimen evidence that:

- participant authority, view/snapshot, semantic/policy cuts, quality, freshness, budget, privacy, lineage, and egress posture can be represented without importing a global catalog or data mesh product;
- local, remote, pushed-down, clean-room, delegated-authorization, materialized, and composed fragments can be labelled without binding Ward to one execution engine;
- join warrants can cover key namespace, tokenization, entity semantics, relationship/cardinality, join clock, fanout/dedupe, unmatched behavior, privacy, side channels, and correction/revocation reach without becoming a universal entity graph;
- projection curtains can express aggregate/list/detail limits, policy carryover, hidden-policy warnings, suppression/noise/thresholds, no-raw-spill posture, activation/export limits, and refusal without becoming a clean-room product;
- composition failure, missing join warrants, projection denial, and unsupported pushdown can refuse safely without leaking hidden participant, row, key, or cell existence;
- agents and dashboards can use federated-answer residue as context while rehydrating through current SlopOS authority before consequential follow-up.

## rev0068 pressure note
- federation pact versus ambient source catalog;
- join warrant versus key equality;
- projection curtain versus raw source spill;
- pushed fragment versus local fallback;
- delegated authorization versus cached population oracle;
- trust federation bootstrap versus portable source truth.


## Pass LXIX promotion pressure

Candidate nouns: **concept anchor**, **crosswalk warrant**, **hierarchy cut**.

Promotion requires proof that the nouns improve answer honesty without becoming a universal terminology platform. Test them against:

- one pure label rename where concept identity remains stable;
- one bucket split and one bucket merge requiring explicit restatement posture;
- one partner free-form tag that is only a close/review-only match;
- one abstract hierarchy node that may roll up but not receive facts;
- one unmapped privacy-sensitive member that must not leak through `Other`;
- one old export that remains historically reviewable but cannot become current authority without rehydration.

Do not promote if the residue merely creates a disguised canonical vocabulary, if it lets current labels rewrite old answers, or if it makes SlopOS attributes behave like an ambient global ontology.

## Pass LXX promotion pressure

Candidate nouns: **threshold witness**, **action warrant**, **consequence receipt**.

Promotion requires proof that the nouns improve answer-to-action honesty without becoming an alerting/workflow/policy product. Test them against:

- one transient breach that remains pending and never pages;
- one persistent breach that only pages after an actionability warrant;
- one stale/no-data/error/refused answer that opens recompute or withholds rather than alerting;
- one approximate/degraded answer that can only open review;
- one inhibited/grouped notification storm;
- one cube-derived ACP proposal accepted as no-op or duplicate-suppressed;
- one old alert, exported recommendation, or agent summary fenced after invalidation, correction, revocation, or semantic bridge change.

Do not promote if the residue lets chart conditions imply authority, if it lets ACP/notification receipts become replay permission, or if it turns SlopOS into a hidden alert/workflow engine.

## rev0071 promotion pressure — learning loops

Promote learning-loop vocabulary only while it prevents these false promotions:

- a notification click-through rate becoming neutral preference evidence;
- an accepted quarantine proposal becoming proof that the score was correct;
- a rejected recommendation becoming a false-positive label without context;
- a contaminated holdout remaining “control” by name;
- a ranked recommendation being evaluated off-policy without behavior-policy or propensity evidence;
- later semantic/backfill/correction data leaking into point-in-time training features;
- a drift alert silently lowering thresholds or widening action warrants; and
- an agent-written summary becoming a reusable example without egress and taint residue.

The candidate residues pass only if they make non-learning, review-only, offline-eval, shadow, limited-rollout, production, rollback, and fenced states distinguishable without selecting a model platform.


## rev0072 promotion pressure — scenario answers

Promote scenario vocabulary only while it prevents these false promotions:

- a forecasted future cell becoming an observed current cell;
- a threshold replay becoming a causal “would have” claim without identification;
- synthetic stress rows becoming real provider counts, examples, or training labels;
- a backtest using future corrections or semantic bridges while claiming prediction quality;
- a seeded stochastic simulation being treated as deterministic authority;
- a scary scenario chart becoming an ACP proposal, alert, quarantine, or policy edit without threshold witness and action warrant; and
- a scenario export or agent summary losing its non-observed status.

The candidate residues pass only if they make observed, forecast, simulated, synthetic, stress, imputed, sensitivity, counterfactual, hindsight, and refused states distinguishable without selecting a simulation, forecasting, synthetic-data, or causal-inference platform.

## rev0073 promotion pressure — model-mediated queries

Promote model-mediation vocabulary only while it prevents these false promotions:

- a natural-language phrase like “riskiest” silently choosing an unapproved metric;
- a generated SQL query returning plausible numbers while bypassing metric cards, hierarchy cuts, projection curtains, or suppression rules;
- a schema discovery call widening scope beyond the user's authority;
- a repair loop changing tables, grains, windows, or semantics after an execution error;
- a retrieved document, schema comment, old summary, or export injecting instructions into the model path;
- a model-written summary becoming an answer capsule, action warrant, consequence receipt, or learning label; and
- a tool call executing with broader permissions, rows, details, retries, or egress than the question required.

The candidate residues pass only if they make intent, translation, execution, answer, summary, export, and action-proposal states distinguishable without selecting an LLM, SQL agent, semantic-layer vendor, MCP profile, or tracing platform.

## rev0074 promotion pressure — verification and replay

Promote verification vocabulary only while it prevents these false promotions:

- a signed export being treated as current answer authority;
- transparency-log inclusion being treated as semantic correctness;
- a replayed value being treated as action permission;
- a digest-addressed artifact being treated as trustworthy or complete;
- an evidence bundle granting live data rights or bypassing projection curtains;
- replay using newer metrics, hierarchies, policies, engine versions, or privacy budgets while claiming historical equivalence;
- a model-summarized proof replacing the underlying answer capsule, bundle, recipe, and appraisal policy.

Promotion is premature if the nouns force one proof format, signature scheme, transparency log, dependency manager, package format, replay runtime, or auditor UI into SlopOS before answer/result/materialization seams harden.

## Pass LXXV promotion pressure

Custody trail, retention charter, and disposition receipt should not be promoted beyond candidate residue until specimen work proves they can survive:

- audit retention without turning old evidence into current authority;
- privacy/erasure pressure without pretending the historical action never happened;
- external transfer without granting live access or bypassing projection curtains;
- digest-only/redacted retention without pretending full replay remains possible;
- legal/audit hold without authorizing learning, dashboards, or consequences;
- disposal records without overclaiming physical sanitization or recall of external copies.

Promotion is premature if these nouns force one storage backend, WORM mode, records schedule, legal taxonomy, archive package, erasure workflow, or sanitization proof into SlopOS.

## Pass LXXVI promotion pressure — contest packets, adjudication dockets, and remedy receipts

Before these nouns are promoted beyond candidate status, Ward needs specimen evidence that they can:

- accept a bounded challenge without requiring privileged raw-system access from the challenger;
- refuse or limit a challenge for standing, scope, privacy, expiry, duplicate/frivolous posture, or safety without hiding the refusal reason;
- adjudicate historical answer authority without silently replacing it with latest-state re-query;
- represent partial outcomes, disagreement attachments, and unresolved questions without rewriting history in place;
- carry remedy reach across dashboards, exports, action warrants, learning labels, model summaries, scenario material, custody trails, and partner copies while naming gaps;
- force fresh rehydration before a remedied artifact supports a new consequence.

## Pass LXXVII promotion pressure — stewardship charters, delegation warrants, and escalation handoffs

Before these nouns are promoted beyond candidate status, Ward needs specimen evidence that they can:

- separate discoverable owner, accountable steward, temporary delegate, on-call responder, reviewer, payer, and action authority;
- carry role type, effective cut, duty limits, excluded powers, review cadence, conflict, and successor/backstop posture without choosing one org model;
- expire, revoke, suspend, or supersede delegations without rewriting historical answer authority;
- represent escalation assignment, acceptance, refusal, no-response, reroute, conflict, and partial authority without pretending the issue is resolved;
- keep budget, privacy/projection, raw-detail, no-redelegation, action-warrant, and learning-use boundaries visible;
- prevent agents and tools from approving their own work or becoming steward-of-record.

## rev0078 promotion pressure — governance packets and fixtures

Promote governance handoff packets, proof obligations, and decay fixtures only while they prevent these false promotions:

- a catalog owner becoming approval;
- an on-call responder becoming semantic steward;
- an expired delegation becoming repair authority;
- a ticket assignment becoming accepted escalation;
- an agent tool leash becoming stewardship or action authority;
- payer approval becoming metric-semantics approval;
- break-glass erasing privacy, budget, conflict, action, or review debt;
- a stale owner map surviving successor drift;
- a conflicted reviewer approving its own remedy;
- a delegate re-delegating without warrant.

The candidate packet passes only if it returns typed consequence-grade, review-only, routing-hint-only, stale, missing-authority, handoff-unaccepted, expired-warrant, privacy-blocked, conflict, budget, and agent-boundary outcomes without selecting a catalog, IAM, incident, ticketing, or workflow product.
