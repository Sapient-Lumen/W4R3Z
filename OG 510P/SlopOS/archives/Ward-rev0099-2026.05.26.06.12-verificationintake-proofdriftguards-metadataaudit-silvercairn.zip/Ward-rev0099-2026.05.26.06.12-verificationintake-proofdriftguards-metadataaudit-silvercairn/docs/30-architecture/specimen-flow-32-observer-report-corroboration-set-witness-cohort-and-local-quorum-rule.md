# Specimen flow 32 — observer report, corroboration set, witness cohort, and local quorum rule

Goal: keep Ward honest when one trust-relevant statement is accompanied by several receipts, cosignatures, or registrations that look like “quorum” but do not all mean the same thing.

## Scenario
A high-value local spend action depends on an imported software artifact and its trust bundle.
The bundle arriving at a relying system contains:
1. one issuer statement saying artifact `A` was built under policy `P`;
2. one transparency receipt from service `TS-public`;
3. one additional receipt from service `TS-enterprise`;
4. two witness cosignatures over a checkpoint gathered by the issuer’s release service; and
5. one monitor note produced later by an internal auditor.

At first glance, the relying system could flatten all of this into “verified by five sources”.
That would be a mistake.
One of the witness cosignatures and the enterprise receipt come from the same organizational trust cohort.
Another receipt refers to an earlier checkpoint than the cosigned checkpoint.
The local policy for this spend action requires **either**:
- one public transparency receipt plus one enterprise receipt over the same cut, **or**
- a checkpoint carrying cosignatures from at least two acceptable witness cohorts.

Ward should therefore record four distinct residues rather than one vague “threshold met” story:
1. an **observer report** for each actor-specific statement (issuer, transparency service, witness, monitor);
2. a **corroboration set** grouping only the receipts/cosignatures that refer to the same underlying cut;
3. a **witness cohort** note describing which corroborators are independent enough to count separately here;
4. a **local quorum rule** explaining why this relying system accepted, quarantined, or deferred the action.

In this specimen, the artifact is **not yet spendable** for the high-value action because the available corroboration does not satisfy the local quorum rule on one coherent cut.
The system may still allow a lower-risk observation-only path, but it must not pretend the stronger action already earned threshold truth.

## Why this matters
- One observer statement is weaker than grouped corroboration.
- Several receipts over different cuts should not be silently counted as one corroboration set.
- Raw signature count is weaker than independence/cohort knowledge.
- The rule that decides “enough here” is local policy residue, not issuer truth.
- Monitor notes help later accountability, but they are not identical to same-cut corroboration for the current action.

## Ward pressure
This specimen pressures Ward to keep corroboration material and action policy distinct while still leaving open whether later implementation uses appended receipts, threshold attestations, witness registries, or policy-side trust lists.
