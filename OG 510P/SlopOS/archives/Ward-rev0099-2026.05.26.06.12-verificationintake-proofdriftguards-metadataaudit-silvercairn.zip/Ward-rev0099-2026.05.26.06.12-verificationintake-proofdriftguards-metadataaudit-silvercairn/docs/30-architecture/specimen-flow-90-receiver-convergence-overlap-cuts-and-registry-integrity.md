# Specimen flow 90 — receiver convergence, overlap cuts, and registry integrity

## Situation

Two Ward receivers observe the same public owner-routing release and the same governance signal family. Receiver Alpha has reconciled its notified consumers. Receiver Beta is delayed behind a retry/dead-letter edge. Receiver Delta sees a different status-channel cut. A dashboard wants to show a single green “current” status.

## Ward move

Ward issues a receiver-convergence receipt instead of choosing a global winner.

The receipt binds:

- each source signal-notification reconciliation receipt by byte digest;
- every receiver by hashed receiver id and hashed status-channel id;
- each status-channel cut digest and watermark;
- the digest of the expected receiver set;
- the overlap digest of affected consumer sets;
- explicit observation states: reconciled, lagging/quarantined, divergent-held, duplicate-suppressed, or fork-quarantined.

## Safe outcome

If all required receivers are reconciled, Ward can publish `all_receivers_converged_refresh_required`. That still only means replay/refresh may proceed. It does not grant authority.

If one receiver lags, Ward publishes `partial_receiver_lag_quarantined`. If cuts diverge, Ward publishes `divergent_status_channel_cut_held`. If a branch forks, Ward publishes `receiver_fork_quarantined`.

## Refusal

Ward refuses to:

- treat receiver majority as authority;
- hide missing receivers;
- hide overlap-set differences;
- collapse divergent status-channel cuts;
- expose raw receiver ids or private status channels in public views;
- update global status pointers;
- approve action, repair, export, remedy, delegation, budget spend, or learning use.

## Audit seam

The pass also makes the checker registry self-auditing. The new registry-integrity checker catches unregistered governance checkers and unregistered fixture directories before `make check` can report a false sense of coverage.
