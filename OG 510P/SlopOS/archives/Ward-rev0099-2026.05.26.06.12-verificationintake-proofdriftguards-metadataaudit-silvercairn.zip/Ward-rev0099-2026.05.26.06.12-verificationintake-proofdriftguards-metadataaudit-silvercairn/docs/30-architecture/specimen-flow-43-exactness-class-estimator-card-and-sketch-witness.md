# Specimen flow 43 — exactness class, estimator card, and sketch witness

## Goal
Show how one repeated analytic question can earn sketch-backed or approximate acceleration **without** letting the result impersonate replayable exact truth.

## Flow
1. A team already has a saved query recipe and one exact frozen result for a repeated trust question.
2. Ward keeps that **saved query recipe** and exact frozen result intact and weaker than any final local consequence.
3. To reduce cost or latency, Ward evaluates one candidate approximate derivative powered by a named estimator family instead of silently replacing the exact path.
4. Ward labels the new surface with an explicit **exactness class** so humans and downstream systems can see that this is an estimate, not exact replay.
5. Ward attaches an **estimator card** naming the family, what it estimates, whether it is mergeable, what precision/tuning posture applies, and what caveats remain.
6. If the derivative stores mergeable sketch state, Ward preserves a **sketch witness** distinct from the rendered approximate number so later unions, intersections, refreshed estimates, or audit can reason over the state honestly.
7. If the approximate derivative is later promoted, it remains visibly `approximate`, `estimator-carded`, and, when applicable, `sketch-backed`, while staying weaker than the exact recipe and weaker than replayable raw truth.

## Why this specimen matters
- It proves Ward can accept useful estimates without flattening them into fake exactness.
- It keeps algorithm-family shifts, precision posture, and mergeability visible.
- It preserves the difference between a rendered estimate and durable mergeable sketch state.

## Nouns under pressure
- **exactness class**
- **estimator card**
- **sketch witness**

## What must stay separate
- exact replay versus approximate estimate;
- metric card versus estimator card;
- rendered approximate value versus mergeable sketch state;
- sketch-backed acceleration versus final local consequence.

## Promotion check
Do not promote these nouns beyond guidance unless a later specimen shows the same repeated question surviving both exact replay and sketch-backed acceleration without hiding which class of truth each surface belongs to.
