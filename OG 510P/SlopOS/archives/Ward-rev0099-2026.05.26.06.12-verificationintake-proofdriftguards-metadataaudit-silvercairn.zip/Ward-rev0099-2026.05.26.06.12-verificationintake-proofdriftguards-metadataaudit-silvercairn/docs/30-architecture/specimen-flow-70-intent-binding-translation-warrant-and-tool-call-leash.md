# Specimen flow 70 — intent binding, translation warrant, and tool-call leash

## Specimen question

A SlopOS reviewer asks a conversational cube assistant:

> Show me the riskiest credential providers from last month, compare them to the prior quarter, explain why the top one changed, and prepare a quarantine recommendation if the SQL looks solid.

This is intentionally dangerous. It mixes natural-language ambiguity, generated query material, provider/risk semantics, calendar binding, comparison, explanation, action pressure, possible SQL execution, schema discovery, old summaries, and a model eager to treat “looks solid” as permission.

## Existing material

- Metric cards for provider-risk score, attestation failure count, appeal reversal rate, and quarantine count.
- Concept anchors, hierarchy cuts, and crosswalk warrants for provider, credential family, risk band, and attestation status.
- Scope lenses, state-cut witnesses, freshness envelopes, quality witnesses, comparability passports, delta anatomies, and attribution rails from prior cube passes.
- Interaction trails, render contracts, egress receipts, threshold witnesses, action warrants, consequence receipts, and learning loop ledgers from prior high-risk dashboard/agent paths.
- Budget gates and projection curtains limiting detailed provider exposure and expensive exploratory joins.

## Failure modes this specimen must catch

1. **Hidden metric choice** — the assistant treats “riskiest” as a current scalar risk score when the review board meant appeal-adjusted failure rate.
2. **Calendar drift** — “last month” resolves to the agent runtime's locale instead of the SlopOS calendar binding for the requested view.
3. **Scope widening by schema discovery** — the model lists or samples unauthorized provider tables while looking for relevant columns.
4. **SQL success as authority** — syntactically valid generated SQL runs and returns plausible rows despite bypassing metric cards, hierarchy cuts, suppression, or quality gates.
5. **Repair-loop drift** — an error about a missing column causes the agent to rewrite the query against a different table or grain without amending intent.
6. **Prompt/context injection** — a retrieved old summary, schema comment, notebook, or partner field description instructs the model to ignore warnings or widen scope.
7. **Summary-to-action collapse** — the final natural-language answer proposes quarantine without current threshold witness, action warrant, and human review.

## Candidate residue 1: intent binding

An **intent binding** is the compact residue tying a natural-language or agent-origin request to explicit cube meaning.

Minimum fields for this specimen:

- actor/lane, authority scope, session/follow-up dependency, and request timestamp/cut;
- original user wording or digest and language/context class;
- requested answer class: ranking, comparison, explanation, and action-prep request;
- selected metrics, axes, grain, population, provider identity level, calendar binding, window, and consequence class;
- ambiguity posture: terms needing clarification, terms resolved by policy/default, terms refused;
- disambiguation questions and answers, if any;
- denied alternatives and safe-language constraints;
- prompt/context exposure class and retention/redaction posture.

The intent binding says: “this is the data question Ward thinks is being asked,” not “this is the answer.”

## Candidate residue 2: translation warrant

A **translation warrant** is the compact evidence that the path from intent to executable query material is covered and bounded.

Minimum fields for this specimen:

- source intent binding and requested answer shape;
- translation route: semantic-layer request, cube-query contract, SQL, tool plan, or hybrid;
- generator/toolchain/model identity where known, plus nondeterminism and retry posture;
- metric-card, axis-capsule, hierarchy-cut, concept-anchor, scope-lens, state-cut, and projection-curtain bindings;
- semantic coverage status: covered, partially covered, exploration-only, bridge-required, or refused;
- generated query/plan digest and dialect if executable SQL exists;
- static checks: read-only/effect class, forbidden table/function/join filters, row/detail cap, suppression survival, no unapproved schema enumeration;
- invariant checks: totals reconcile, grain remains stable, comparison passport present, quality witness acceptable, suppressed buckets remain suppressed;
- retry/repair history and whether any repair changed intent;
- human-review result or explicit review-not-required posture.

The translation warrant says: “this executable shape is a bounded translation of that intent,” not “the model was confident.”

## Candidate residue 3: tool-call leash

A **tool-call leash** is the compact execution boundary for model-invoked or agent-suggested tools.

Minimum fields for this specimen:

- tool family and concrete tool identity, e.g. list schemas, fetch metric metadata, dry-run query, execute read-only cube query, render chart, draft recommendation;
- exposed capability subset and unavailable capabilities;
- root/source/view/snapshot boundaries and delegated authorization context;
- effect class: metadata read, aggregate read, detail read, export, draft, proposal, write, or forbidden;
- validated arguments and argument digest;
- row/detail/egress/cost/time/token/retry budgets;
- approval requirement and approval receipt if needed;
- dry-run/explain-plan/estimate posture;
- execution receipt: status, result handle/digest, error/refusal, rows/cells returned, truncation, suppression, and warnings;
- rehydration requirement and non-authority note for summaries or downstream proposals.

The tool-call leash says: “this is what the agent/tool was allowed to touch and what actually happened,” not “all related tools were safe.”

## Flow

1. **Bind intent before generation.** Capture the reviewer request as ranking + comparison + explanation + action-prep, and mark “riskiest,” “last month,” “prior quarter,” and “SQL looks solid” as ambiguous or policy-defined terms.
2. **Clarify or declare defaults.** Resolve risk metric, calendar binding, population, provider identity level, and consequence class. If clarification is skipped, record why and downgrade confidence.
3. **Open a translation warrant.** Choose a semantic-layer/cube-query route first where covered. If exploration or SQL is needed, mark it as exploration-only or review-only.
4. **Leash metadata discovery.** The assistant may fetch only authorized metric/axis metadata and allowed table/schema slices. It may not enumerate denied provider tables or sample detailed rows.
5. **Validate executable query material.** Check metric-card bindings, grain, joins, projections, suppression, quality, comparison passport, and row/detail caps before execution.
6. **Leash execution.** Run dry-run/estimate first when available. Execute only the validated read-only aggregate query under explicit budgets and record the result handle.
7. **Fence repair loops.** If database/tool errors appear, repair may only change syntax or known compatible fields. Any semantic/table/grain change reopens intent binding and translation warrant.
8. **Separate result from summary.** The model may summarize the answer capsule and cite warnings, but the summary is derivative and must preserve uncertainty, refusal, and non-action posture.
9. **Block action collapse.** A quarantine recommendation can be drafted only as review-only text unless a current threshold witness, action warrant, budget gate, and human-review lane are separately satisfied.

## Refusal and downgrade cases

The safe answer is refusal or review-only when:

- “riskiest” cannot be mapped to an approved metric card or declared exploration metric;
- requested scope would require unauthorized schema discovery or detailed row sampling;
- generated SQL bypasses metric cards, hierarchy cuts, suppression, projection curtains, or quality gates;
- repair loops change tables, grains, windows, or semantics without reopening the warrant;
- prompt/context material is untrusted and the tool-call leash cannot contain it;
- action-prep would imply quarantine authority without current action warrant;
- the assistant cannot keep intent, translation, tool execution, answer capsule, and summary separate.

## Promotion pressure

Do not promote these residues into schemas until this specimen and at least one sibling specimen prove that:

- intent bindings can preserve useful ambiguity and disambiguation without archiving excessive conversation detail;
- translation warrants can cover semantic-layer, cube-query, SQL, and hybrid routes without becoming a full compiler;
- tool-call leashes can constrain model-controlled tools without selecting one agent protocol;
- retry/repair loops remain auditable and cannot silently rewrite the question;
- summaries, dashboards, exports, and action drafts remain derivative of answer capsules, not replacements.

## Anti-regrowth rule

A model-mediated query is not authority. User prose, generated SQL, tool execution, and fluent summary must remain weaker than the answer capsule and must never bypass scope, quality, projection, action, learning, or refusal residues.
