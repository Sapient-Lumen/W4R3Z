# Specimen flow 86 — recertification receipts, cache invalidation, and refresh signals

## Story

A public Ward release once had a forked status chain. A dispute-resolution receipt recovered a current status pointer and labeled it “not authority; refresh before reuse.” Helm cached that pointer for a dashboard chip. Later, the recipient refresh channel receives a status update: the recovered head is still current for display, but the cache must be rechecked weekly and replayed before any export or action.

In a parallel case, a cached public resolution misses a newer status-channel signal. Ward must invalidate the cache, notify stale consumers, and publish a refresh signal without editing the old dispute-resolution receipt.

## Residues in play

- source dispute-resolution receipt;
- cache subject digest;
- recertification cut time;
- next recheck due;
- status-channel recheck;
- recipient-refresh-channel recheck;
- projection-policy digest check;
- owner-map epoch check;
- successor-state check;
- branch-state check;
- stale-consumer notification;
- no-authority watermark.

## Happy path

1. Consumer presents a cached dispute-resolution receipt id and digest.
2. Ward replays the source dispute-resolution validator.
3. Ward recomputes the cache-subject digest.
4. Ward checks status channel, recipient refresh channel, projection policy, owner-map epoch, successor state, branch state, follow-up signals, and clock window.
5. If no newer signal is observed, Ward records `current_cache_recertified` with `refresh_required` reuse state.
6. If a newer signal, projection drift, successor drift, or branch drift is observed, Ward records invalidated/quarantined/historical/recheck state.
7. Public output reveals cache state only and carries “not authority.”

## Failure cases

- cache subject digest mismatch;
- source dispute-resolution digest mismatch;
- current cache claimed despite newer signal;
- status-channel recheck skipped;
- projection-policy drift hidden;
- next recheck already expired;
- cached status pointer treated as grant;
- invalidated cache not notifying stale consumers;
- public recertification leaking sealed branch evidence or exact hidden counts;
- purpose drift from display to export/action.

## Outcome

Ward can now tell downstream cubes: “Your cached resolution is current enough to display as a status pointer, stale and invalidated, quarantined, historical-only, or held for recheck.” None of those states authorizes consequence without source-packet replay.
