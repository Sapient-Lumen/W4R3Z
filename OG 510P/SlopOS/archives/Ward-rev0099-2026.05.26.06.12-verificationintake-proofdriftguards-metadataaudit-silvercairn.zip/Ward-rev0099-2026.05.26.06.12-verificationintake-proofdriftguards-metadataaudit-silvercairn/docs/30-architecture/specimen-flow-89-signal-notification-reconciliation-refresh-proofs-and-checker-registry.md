# Specimen flow 89 — signal-notification reconciliation, refresh proofs, and checker registry

## Scenario

A public owner-routing release was previously recertified as current-but-refresh-required. A revocation signal then arrived through the Ward status channel. Ward accepted the signal for cache invalidation, notified three downstream public cache consumers, and recorded delivery acknowledgments for all three.

A product dashboard wants to show the route again. The unsafe shortcut is:

> Everyone acknowledged the notification, so the public cache is safe.

Ward rejects that shortcut.

## Flow

1. `GRC-public-current-cache-recertified-2026-05-24` records a current cache that still requires refresh before reuse.
2. `GSI-accepted-revocation-signal-for-cache-invalidation-2026-05-25` accepts a revocation signal as receiver-local observation, not authority.
3. `GSN-all-consumers-notified-refresh-required-2026-05-25` records fanout and acknowledgment posture, not local consumer refresh.
4. `GSNR-all-consumers-recertified-refresh-required-2026-05-25` records that each affected consumer produced checked recertification evidence.
5. The public surface may now say the reconciliation finished, but it still labels the result as not authority and keeps refresh/replay requirements visible.

## Counterflow

If one consumer is pending retry or dead-lettered, the reconciliation receipt must say so. It may record a quarantine pointer and stale-consumer owner notice. It may not produce a green batch, update a status pointer, export raw evidence, or claim all consumers refreshed.

## Checker refactor specimen

The pass also changes how Ward runs its growing validation suite. A new checker registry lists each receipt family and its fixture directory. The suite now validates the registry before running checkers, so the suite itself becomes audit material.

## Specimen lesson

Notification is a fanout fact. Acknowledgment is a delivery fact. Reconciliation is a receiver-local accounting fact. Consumer recertification is the smallest proof of local refresh. None of these facts is action authority.
