# Specimen flow 74 — stewardship charter, delegation warrant, and escalation handoff

## Specimen question

A SlopOS provider-risk cube has a contested quarantine score. The prior business steward left the domain. The technical owner moved to another team. A temporary analyst is asked to repair a stale crosswalk and re-run a backfill. A dashboard owner wants the corrected chart re-exported. An agent proposes to re-enable the quarantine recommendation after the repair. The overnight on-call is paged because the action warrant is blocked and the appeal deadline is approaching.

Who, exactly, can approve the repair, spend the recompute budget, expose enough detail for review, re-export the corrected answer, and re-enable a consequence-grade recommendation?

This specimen intentionally collides ownership discovery, temporary delegation, agent/tool leashes, contest/remedy state, backfill/recompute, budget gates, privacy/projection, action warrants, and escalation timing.

## Existing material

- Answer capsule, scope lens, state-cut witness, metric/query contracts, concept anchor, crosswalk warrant, hierarchy cut, quality witness, freshness envelope, budget gate, projection curtain, and uncertainty envelope.
- Correction horizon, backfill ledger, invalidation receipt, recompute docket, revocation fence, contest packet, adjudication docket, and remedy receipt.
- Action warrant, threshold witness, consequence receipt, learning loop ledger, feedback taint fence, render contract, egress receipt, custody trail, retention charter, disposition receipt, intent binding, translation warrant, and tool-call leash.

## Failure modes this specimen must catch

1. **Catalog-owner-as-approval collapse** — a current catalog owner field is treated as permission to change the metric, approve a crosswalk bridge, or re-enable quarantine.
2. **On-call-as-steward collapse** — the paged responder is treated as accountable owner even though on-call coverage is only a response route.
3. **Delegation-as-permanence collapse** — a temporary analyst's repair permission becomes permanent metric/editor/export authority.
4. **Assignment-as-acceptance collapse** — a ticket, dashboard mention, or chat assignment is treated as accepted escalation.
5. **Agent-as-delegate collapse** — an LLM/tool runner with query rights proposes a repair and is treated as delegated to approve it.
6. **Owner-map-cut drift** — the old owner map, current org chart, and historical answer cut disagree, and Ward silently chooses whichever is convenient.
7. **Conflict laundering** — the reviewer who approved the original disputed crosswalk also approves the remedy without conflict posture.
8. **Budget authority drift** — the person who can approve semantic repair is treated as able to spend recompute/export budget.
9. **Re-delegation creep** — a delegate asks another person/tool to perform a higher-scope action without authority to re-delegate.
10. **Escalation-overreach collapse** — emergency escalation overrides privacy, projection, source-contract, or action-warrant gates without explicit break-glass residue.

## Candidate residue 1: stewardship charter

A **stewardship charter** is a scoped accountability and maintenance posture for a cube subject.

Minimum fields for this specimen:

- subject: cube domain, metric family, axis/member family, source fragment, semantic bridge, quality suite, dashboard/export family, action class, remedy class, or learning-use class;
- accountable parties and role types: technical owner, business owner, data steward, policy owner, payer/budget owner, reviewer lane, custodian, on-call lane, or successor/backstop;
- effective cut, lifecycle state, review cadence, expiration/revalidation posture, and supersession link;
- permitted duties: edit definition, approve crosswalk, approve backfill, approve export, approve remedy, approve learning use, open action warrant, or request budget;
- excluded powers: cannot view raw rows, cannot approve action, cannot spend budget, cannot re-delegate, cannot waive privacy, cannot waive contest hold, cannot erase custody evidence;
- conflict posture, independence requirements, dual-control / quorum posture, emergency override posture, and post-hoc review requirement;
- evidence pointers: catalog entries, policy versions, CODEOWNERS-like maps, org/group records, prior dockets, and source-contract references;
- orphan/stale/suspended state and successor/backstop lane.

A stewardship charter answers: “who is accountable for this subject, and for which duties?” It does not itself approve any specific change, export, action, or remedy.

## Candidate residue 2: delegation warrant

A **delegation warrant** is scoped evidence that one principal, lane, system, or agent may perform a named task.

Minimum fields for this specimen:

- delegator, delegatee, principal class, source stewardship charter, and proof/evidence pointer;
- granted capability: inspect, draft, query, repair crosswalk, run validation, open backfill, approve recompute, approve render/export, approve remedy notice, or prepare action-warrant packet;
- denied capabilities and must-not-cross boundaries: raw-row access, partner fragment access, privacy waiver, budget spend, action authorization, re-delegation, publication, or learning use;
- scope: view, source, metric, axis, cell/cohort, time/window, semantic cut, policy epoch, privacy/projection class, budget/payer, and consequence class;
- caveats: expiry, use count, office hours, incident id, contest id, reviewer lane, dual control, no self-approval, conflict, or break-glass flag;
- revocation posture, membrane/lease posture, revalidation requirements, audit/event/log pointer, and result receipt requirement;
- outcome: active, expired, revoked, refused, superseded, consumed, suspended, or not-used.

A delegation warrant answers: “what may this delegate do now?” It does not make the delegate the steward-of-record or authorize unrelated consequences.

## Candidate residue 3: escalation handoff

An **escalation handoff** is routing, acceptance, and authority-transfer residue for an issue that exceeds the current local lane.

Minimum fields for this specimen:

- issue subject: answer capsule, metric, crosswalk, backfill, export, action warrant, contest packet, remedy receipt, learning loop, privacy/projection block, or budget gate;
- trigger: timeout, unresolved conflict, missing owner, nearing deadline, high consequence, privacy block, failed validation, budget exhaustion, unavailable delegate, or emergency override;
- severity/urgency, from-lane, to-lane, recipient candidates, escalation policy version, and expected response window;
- evidence supplied, evidence withheld, missing evidence, projection limits, and CH-AREF/digest pointers;
- authority requested, authority granted, authority denied, and authority still missing;
- acceptance posture: accepted, refused, rerouted, no-response, partial, conflict-declared, needs-info, or emergency-only;
- interim effect: action hold, export hold, recompute hold, learning hold, dashboard warning, no change, break-glass with review debt, or privacy restriction;
- deadline, notices, communications channel, closure state, successor/backstop lane, and unresolved gaps.

An escalation handoff answers: “who was asked to take what lane, what authority did they accept, and what remains unresolved?” It does not prove that the issue was fixed.

## Walkthrough

1. The disputed quarantine-score remedy needs a crosswalk repair and backfill. Ward finds three conflicting governance hints: an old business steward in the historical answer cut, a current catalog owner, and an on-call responder.
2. Ward refuses to treat any one hint as approval. It requires a stewardship charter for the provider-risk metric family and semantic bridge subject.
3. The charter shows that semantic bridge approval needs a business steward plus technical steward, while recompute budget approval belongs to a payer lane and action re-enable requires a separate action warrant.
4. The business steward is vacant. The charter's successor/backstop lane allows temporary delegation only for inspection, proposed crosswalk repair, validation, and recompute request preparation.
5. Ward emits a delegation warrant for the analyst. It expires after the contest docket, forbids raw partner fragments, forbids re-delegation, and cannot approve action or publish exports.
6. Validation passes, but recompute budget and action re-enable remain blocked. An escalation handoff goes to the payer lane and action-governance lane with evidence pointers and privacy projection limits.
7. The payer lane accepts recompute budget authority. The action-governance lane accepts only review, declares a conflict on one reviewer, and keeps the quarantine recommendation held pending fresh threshold witness and action warrant.
8. A dashboard owner asks to re-export immediately. Ward refuses because the export duty is not in the analyst warrant and the escalation handoff has not granted publication authority.
9. After fresh rehydration, the corrected answer is rendered, old export is marked withdrawn/disputed, recompute and remedy receipts are updated, and any future quarantine action must pass the normal action-warrant path.

## Promotion tests

The three residues earn promotion only if they survive all of these tests:

- can separate discoverable owner, accountable steward, temporary delegate, on-call responder, reviewer, payer, and action authority;
- can preserve historical owner-map cuts while requiring current governance rehydration for fresh consequences;
- can expire, revoke, suspend, or supersede delegations without rewriting old answer history;
- can represent acceptance/refusal/no-response/partial escalation without treating assignment as resolution;
- can carry conflict, dual-control, privacy/projection, budget, and no-redelegation caveats;
- can keep an agent or tool runner as a bounded delegate rather than a steward-of-record;
- can route emergencies without letting break-glass erase post-hoc review and residue obligations.

## Open questions

- Which SlopOS surfaces should hold canonical stewardship charter fragments, if any, versus Ward answer-local copies?
- Should low-risk read-only dashboard answers need only owner hints rather than full stewardship charters?
- How much owner/delegation/escalation residue should be shown in Helm versus carried as hidden-but-checkable receipts?
- How do privacy, contest standing, and projection curtains limit who can see governance evidence?
- Can future Steward surfaces supply role taxonomy without making Ward dependent on one org model?

## Current posture

Promote these as candidate residues, not hardened schemas. The next pass should pressure-test operational decay: stale charters, owner-map invalidation, delegation expiry, no-response escalation, conflicting successors, and agent-proposed governance repair under SlopOS's design-phase authority discipline.
