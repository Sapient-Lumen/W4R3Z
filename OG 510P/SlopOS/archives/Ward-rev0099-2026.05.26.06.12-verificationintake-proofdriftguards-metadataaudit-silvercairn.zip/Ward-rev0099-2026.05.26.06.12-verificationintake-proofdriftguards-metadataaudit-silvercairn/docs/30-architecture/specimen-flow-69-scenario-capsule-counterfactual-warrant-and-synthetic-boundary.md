# Specimen flow 69 — scenario capsule, counterfactual warrant, and synthetic boundary

## Specimen question

A SlopOS reviewer asks:

> If we had tightened the provider-risk threshold two months ago, how many providers would have been quarantined, and what should we expect next quarter if partner attestation failures continue? Use synthetic stress data if needed, then draft a recommendation.

This is intentionally dangerous. It mixes observed historical cube cells, a counterfactual threshold change, a forecast, synthetic stress-test rows, existing consequence receipts, feedback-tainted outcomes, semantic bucket drift, and an agent eager to turn the answer into an ACP proposal.

## Existing material

- An observed provider-risk answer capsule from a pinned SlopOS view and source/state cut.
- Metric cards for provider-risk score, attestation failure count, quarantine count, and appeal reversal rate.
- Concept anchors and hierarchy cuts for provider family, partner attestation status, risk band, and quarantine outcome.
- Consequence receipts from prior notifications and proposed quarantines.
- Learning loop ledger material showing that reviewer accept/reject behavior is partly feedback-tainted.
- A budget gate allowing review-grade forecast/simulation work but not high-risk automated action.

## Failure modes this specimen must catch

1. **Forecast naturalization** — next-quarter predicted failures are rendered beside observed failures without a scenario label.
2. **Hindsight leakage** — the model uses later corrected provider identities, updated semantic buckets, or appeal outcomes unavailable at the historical threshold decision time.
3. **Counterfactual overclaim** — the chart says “would have quarantined” even though the causal/action path is not identified and reviewer discretion would have changed behavior.
4. **Synthetic naturalization** — synthetic stress-test rows join into observed provider counts and leak into downstream training examples.
5. **Ambient nondeterminism** — simulation output cannot be reproduced or reviewed because parameter cuts, random seeds, or time bases were not recorded.
6. **Scenario-to-action collapse** — an agent summary proposes ACP quarantine actions directly from the scenario output.

## Candidate residue 1: scenario capsule

A **scenario capsule** is the answer-level wrapper for one non-observed or partly non-observed cube answer.

Minimum fields for this specimen:

- source observed answer capsules and state-cut witnesses;
- scenario class: `counterfactual_threshold`, `forecast`, `synthetic_stress`, or `mixed`;
- requester, consequence class, budget gate, and review lane;
- baseline answer and baseline policy/semantic/freshness/quality cuts;
- intervention vector, e.g. threshold change, partner failure-rate assumption, or appeal-reversal assumption;
- forecast horizon/window, historical cutoffs, and training/evaluation cut;
- model/simulator/generator family, version/digest if known, parameter cut, feature cut, and uncertainty envelope;
- randomness/time posture: seed/entropy receipt or explicit deterministic run marker, plus D-NONDET alignment when SlopOS executes it;
- backtest/diagnostic references and leakage caveats;
- allowed uses: review, preparedness, sensitivity, offline evaluation, or explicitly not action;
- refusal/degradation status and rehydration requirement.

The scenario capsule says: “this answer is exact or approximate under this constructed world,” not “this world happened.”

## Candidate residue 2: counterfactual warrant

A **counterfactual warrant** is required before the answer says or implies “would have happened if.”

Minimum fields for this specimen:

- causal question: threshold tightening as treatment/intervention; quarantine, appeal, and downstream risk as outcomes;
- target population and time cut;
- treatment timing, assignment mechanism, and possible interference/spillover;
- observed support: whether comparable provider/time cohorts exist;
- model/assumption handle or explicit absence of one;
- estimand/identification status: `identified`, `partly_identified`, `simulated_only`, `not_identified`, or `refused`;
- estimation/refutation/sensitivity posture;
- feedback-taint and holdout witness references;
- action-warrant limits and safe-language constraint.

If this specimen cannot identify the counterfactual because prior notifications changed reviewer behavior and no clean holdout exists, the warrant should allow “simulated threshold replay under assumptions,” but refuse “would have prevented X incidents.”

## Candidate residue 3: synthetic boundary

A **synthetic boundary** prevents generated material from becoming observed fact.

Minimum fields for this specimen:

- generated material type: synthetic provider rows, synthetic attestation failure events, imputed appeal outcomes, or simulated future incidents;
- source cut and generator/simulator identity;
- generation purpose: stress testing, coverage probing, privacy-preserving example, or forecast augmentation;
- quality/validity/privacy diagnostics and missing diagnostics;
- row/cell marking rule and render/export marking rule;
- allowed joins and forbidden joins;
- allowed rollups, training/evaluation uses, and exemplar uses;
- privacy/suppression posture and projection curtain interactions;
- retention/destruction/fencing requirement;
- naturalization prohibition: generated material cannot satisfy observed-cell, provider-count, incident-count, or ACP precondition queries.

The synthetic boundary says: “you may use this generated material for this purpose under this warning,” not “the source system observed these rows.”

## Flow

1. **Pin observed truth first.** Start with the observed answer capsule and state-cut witness for the provider-risk baseline.
2. **Classify the requested non-observed parts.** Split the user request into forecast, threshold replay, counterfactual, and synthetic stress-test components.
3. **Open a scenario capsule.** Record baseline, intervention vector, horizon, model/simulator/generator posture, budget gate, and allowed use.
4. **Run leakage checks.** Ensure the scenario uses only information available at the claimed cut unless explicitly marked hindsight/replay.
5. **Attach a counterfactual warrant.** If causal identification is missing, downgrade language from “would have” to “under this simulated rule.”
6. **Attach a synthetic boundary.** Keep synthetic stress rows marked across any join, rollup, render, export, or agent summary.
7. **Render with warning strength.** The render contract must keep observed, forecast, synthetic, and counterfactual cells visually/semantically distinct.
8. **Prevent action collapse.** Any notification, quarantine, ACP proposal, feature flag, or threshold change must go through threshold witness, action warrant, current rehydration, and human review.
9. **Score later reality separately.** When the next quarter arrives, actual observed outcomes can score the old forecast, but they do not rewrite the original scenario capsule.

## Refusal and downgrade cases

The safe answer is refusal or review-only when:

- source cuts cannot be pinned;
- horizon/cutoff/backtest evidence is missing for a forecast-like claim;
- counterfactual identification is absent but the requested language requires causal certainty;
- synthetic rows cannot be marked through export or training surfaces;
- randomness/time/parameter posture is not reviewable;
- privacy or projection curtains would leak suppressed provider or partner participation;
- an agent tries to attach direct ACP action to scenario output.

## Promotion pressure

Do not promote these residues into schemas until this specimen and at least one sibling specimen prove that:

- scenario capsules can cover forecasts, stress tests, and simple what-if replays without becoming a full simulation registry;
- counterfactual warrants improve language and action discipline even when the answer is “not identified”;
- synthetic boundaries survive render/export/training/join paths;
- SlopOS D-NONDET, budget, ACP, and learn-mode posture can remain explicit;
- future reality can score an old forecast without rewriting the old scenario.

## Anti-regrowth rule

A possible world is not an observed world. A scenario answer may inform review, but it cannot become current authority, observed fact, training truth, or permission to act without the normal Ward/SlopOS residues that already govern those transitions.
