# Specimen flow 84 — chain integrity, dispute forks, and canonical heads

## Situation

A public Ward owner-routing release was acknowledged, then its recipient contact was transferred. A separate sealed-omission release was corrected, then projection-policy stewardship moved. A restricted review bundle was quarantined while a successor was pending.

Each path now has multiple valid receipts. A consumer needs to know which chain is current without mistaking the current head for authority.

## Bad collapse

The bad implementation fetches “the latest status object” and treats it as the whole truth. It may miss an older follow-up, follow an invalidated status URL, select the wrong branch after a successor dispute, or render a fork as a green current badge.

This collapses chain integrity, currentness, branch conflict, status routing, and action authority.

## Ward residue

The flow introduces `ward.governance.chain-integrity-receipt.v0`.

It records:

- ordered release/follow-up/transfer members;
- member ids, paths, byte digests, states, and observed times;
- source release, recipient, purpose, source item, and projection policy parity;
- a deterministic chain digest;
- old-status-channel closure;
- canonical head or fork hold;
- projection minimization;
- forbidden-effect preservation;
- no-authority label.

## Safe paths

- A public owner-routing chain becomes `canonical_head_recorded` with refresh required.
- A sealed-omission correction plus projection-policy transfer becomes `historical_minimized`.
- A restricted successor chain remains `successor_pending_recheck`.
- A conflicting status-channel branch becomes `fork_detected_hold` with no current head.

## Rejected paths

Ward rejects digest mismatch, missing chain digest, unchecked members, source-release mismatch, purpose drift, fork-as-canonical collapse, public branch leakage, missing no-authority labels, high-consequence effects, dropped forbidden effects, a non-transfer canonical head, old-channel reuse, noncanonical branch reuse, and nonmonotonic lineage.

## Product line

A current chain head is not a grant:

> “Chain integrity recorded. Not authority. Refresh current status and replay the source packet before reuse.”

A fork is a hard hold:

> “Fork detected. No current head. Do not reuse this release until a later chain-integrity receipt resolves the branch.”
