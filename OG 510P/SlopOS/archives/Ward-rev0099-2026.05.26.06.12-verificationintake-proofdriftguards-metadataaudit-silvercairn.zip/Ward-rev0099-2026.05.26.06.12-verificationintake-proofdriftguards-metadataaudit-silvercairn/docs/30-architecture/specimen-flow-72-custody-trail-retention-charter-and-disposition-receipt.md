# Specimen flow 72 — custody trail, retention charter, and disposition receipt

## Specimen question

An auditor asks SlopOS to retain the proof packet behind a provider-risk quarantine recommendation for seven years. A partner then requests erasure of one identity fragment used in the old answer. A reviewer forwards the signed exported chart to outside counsel, and a later internal dashboard asks whether the quarantine still stands.

This specimen intentionally collides audit retention, erasure pressure, evidence transfer, signed exports, replay limits, current authority, and downstream consequences.

## Existing material

- Answer capsule, scope lens, state-cut witness, metric/query contracts, concept anchors, crosswalk warrants, hierarchy cuts, quality witness, freshness envelope, uncertainty envelope, and refusal/degradation material.
- Verification bundle, replay recipe, and attestation envelope from pass LXXIV.
- Render contract and egress receipt for the signed exported chart.
- Threshold witness, action warrant, consequence receipt, correction horizon, backfill ledger, revocation fence, learning loop ledger, and feedback taint fence for downstream effects.
- Projection curtain and privacy/suppression fence for partner and identity-sensitive material.

## Failure modes this specimen must catch

1. **Retention-as-authority collapse** — a kept audit packet is treated as proof that the quarantine remains justified.
2. **Deletion-as-amnesia collapse** — removed or redacted material is treated as though the historical action never happened.
3. **Hold-as-permission collapse** — legal or audit hold is treated as permission to keep using sensitive material for dashboards, learning, or recommendations.
4. **Archive-as-capability collapse** — an auditor bundle contains locators or raw fragments that bypass current projection, consent, partner, or privacy gates.
5. **Custody break invisibility** — forwarded charts, counsel copies, redactions, re-signatures, and model summaries circulate without handling records.
6. **Fixity overclaim** — matching a digest is treated as proof of semantic correctness, currentness, or authorized retention.
7. **Disposition overclaim** — a disposal note claims deletion while old exports, derived aggregates, digest indexes, downstream caches, or agent memories remain.
8. **Replay after expiry** — a replay recipe quietly fetches missing retired inputs or substitutes newer policy/material while pretending the old bundle remained complete.

## Candidate residue 1: custody trail

A **custody trail** is a chronological handling trail for answer-adjacent evidence.

Minimum fields for this specimen:

- subject artifact or answer digest, artifact class, and provenance link;
- holder/actor/system, role, organization/boundary, and authority lane;
- event class: created, viewed, copied, exported, transferred, redacted, sealed, re-signed, verified, checked, disposed, held, or returned;
- event time, source cut if relevant, and transfer purpose;
- access class and projection/detail level before and after the event;
- fixity check result and digest/hash posture when bytes are involved;
- transformation summary: redaction, projection, compression, format conversion, signature wrapping, digest-only reduction, or summary generation;
- known gaps, untracked downstream copies, or outside-boundary notice requirements.

A custody trail answers: “how did this evidence move and change?” It does not answer: “is the old answer currently valid?”

## Candidate residue 2: retention charter

A **retention charter** is a compact lifecycle posture for one answer, bundle, export, sidecar, prompt, validation result, partner fragment, or evidence family.

Minimum fields for this specimen:

- retained subject(s) and excluded subject(s);
- retention purpose: audit, dispute, replay, regulatory, training-prohibited review, incident review, partner obligation, or local debugging;
- authority/policy owner and review cadence;
- designated reviewer/verifier class and allowed use;
- retention horizon, expiry event, and renewal/hold requirements;
- legal hold, audit hold, privacy erasure, partner-contract, projection, and minimization posture;
- detail posture: raw, redacted, aggregate-only, digest-only, locator-only, partner-held, unavailable, or not-retainable;
- replay impact: byte/value/tolerance/verdict/redacted-check-only/not-replayable;
- downstream artifacts covered or explicitly out of scope;
- refusal state when retention would over-expose data or conflict with current policy.

A retention charter answers: “why and how may this evidence remain?” It does not answer: “may this evidence still drive a consequence?”

## Candidate residue 3: disposition receipt

A **disposition receipt** is a compact record of an end-of-life or lifecycle-change action.

Minimum fields for this specimen:

- disposed/reduced/transferred/held subject(s), affected cells/artifacts, and digest references;
- disposition class: expired, deleted, redacted, digest-only reduced, sealed, transferred, returned, legal-hold extended, erasure-applied, cryptographic-erasure claimed, sanitization claimed, or disposal refused;
- actor, authority, policy reason, and reviewer if any;
- method class and evidence strength: self-declared, system log, fixity check, deletion marker, key destruction evidence, media sanitization evidence, partner acknowledgment, or not verifiable;
- residual material: tombstone, digest, revocation fence, egress receipt, aggregate, model summary, cache, external copy, or unknown;
- downstream notice/posture for counsel, partner, exported chart recipients, dashboards, learning ledgers, and action warrants;
- non-amnesia clause: the receipt narrows future use but does not erase the fact that a historical action occurred.

A disposition receipt answers: “what lifecycle action happened and what remains?” It does not prove every copy vanished.

## Walkthrough

1. The quarantine answer is rendered and exported with an egress receipt. Pass LXXIV creates a verification bundle, replay recipe, and attestation envelope.
2. The audit request opens a retention charter for the evidence family. The charter allows review and dispute, forbids learning/training reuse, and reduces raw partner fragments to digest/redacted posture unless a hold requires otherwise.
3. The reviewer forwards the signed chart to outside counsel. Ward appends a custody-trail event and a new egress/custody boundary entry rather than treating counsel's copy as part of the original bundle.
4. The partner erasure request hits one identity fragment. Ward does not rewrite the old answer in place. It compares retention charter, projection curtain, partner obligations, privacy posture, legal hold, and revocation fence.
5. Where allowed, Ward reduces retained material to digest-only or redacted-only and emits a disposition receipt. Where not allowed, Ward emits a disposal-refused or hold-extended receipt with reason and review horizon.
6. The old verification bundle becomes redacted-check-only or verdict-only replay, if raw inputs are no longer retained. The replay recipe records the weaker class.
7. The dashboard asks whether the quarantine still stands. Ward refuses to answer from the old retained export alone; it rehydrates current scope, source, semantic, quality, privacy, and action-warrant state.
8. If current authority differs, the old consequence receipt remains historically explainable, while current continuation requires a fresh threshold witness and action warrant.

## Promotion tests

The three residues earn promotion only if they survive all of these tests:

- can represent legal/audit hold without turning hold into use permission;
- can represent erasure/redaction without erasing historical accountability;
- can represent external transfer without granting external live capabilities;
- can represent digest-only or redacted retention without pretending full replay remains possible;
- can keep current authority weaker/stronger checks separate from old custody and retention state;
- can tell a reviewer what is missing, held, disposed, or externally uncontrolled.

## Open questions

- Should retention charters attach primarily to answer capsules, verification bundles, exported artifacts, source fragments, or evidence families?
- Should custody trails be retained as event streams, bundle sidecars, answer facets, or external review packets?
- What is the smallest disposition receipt that is useful without overclaiming physical deletion or external-copy recall?
- How should privacy-budget state, DP noise seeds, and model prompts be retained or disposed when they are necessary for replay but risky to preserve?
- Where should Ward stop and a future compliance/records-management companion begin?

## Non-decision

This specimen does not choose a legal regime, storage system, WORM mode, records schedule, erasure workflow, archive package, or sanitization process. It only keeps lifecycle evidence visible enough that old datacube artifacts cannot impersonate current truth, and disposal cannot impersonate total amnesia.
