# Specimen flow 25 — concurrency witness, merge recipe, and compaction horizon

Goal: keep concurrent later-state updates, the explicit rule that reconciles them, and the retention limits of a compacted latest-value view visibly separate.

## Scenario
A relying party keeps a later-state history for a credential or device trust subject.
Two regional services publish trust-relevant updates close together:
- one suspension-style update saying the subject should be narrowed because of new device-risk evidence;
- one recovery-style update saying the subject is usable again under a newer local review package.

The relying party receives both updates without a trustworthy total order.
It preserves both in history, then builds a compacted per-subject “current state” view for fast online checks.
Later, tombstones and superseded entries age out of the compacted projection.
A second receiver reading only the compacted view can restore the current survivor value, but cannot prove that older sibling states were absent, resolved the same way, or still recoverable.

## What this specimen is trying to preserve
1. **concurrency witness**
   - residue that two later-state artifacts are parallel or otherwise incomparable;
   - stronger than timestamp guessing and weaker than a whole conflict-resolution family.

2. **merge recipe**
   - explicit note describing how one local projection reduced concurrent siblings into one survivor state;
   - smaller than the source facts and smaller than final spend consequence.

3. **survivor view**
   - compacted/latest-value projection optimized for present lookup or restart;
   - useful, but smaller than complete history.

4. **compaction horizon**
   - visible boundary beyond which one survivor view no longer implies retained tombstones, complete sibling history, or strong negative inference.

## What this specimen refuses to decide yet
- whether Ward’s long-term later-state store is append-only, compacted, dual-lane, or projection-first;
- whether concurrency witnesses are durable objects, sidecar metadata, or per-view annotations only;
- whether merge recipes are standardized families, free-text policy handles, or local projection residue;
- whether compaction horizons belong in Ward proper or in an adjacent history/observation cube.

## Why this specimen matters
Trust systems fail quietly when “the latest value” is treated as if it were the whole history, and when concurrent updates are silently forced through last-write-wins folklore. Ward should resist both collapses before it chooses a storage or projection doctrine.

## Promotion test for these nouns
Do not promote `concurrency witness`, `merge recipe`, `survivor view`, or `compaction horizon` unless they improve:
- one concurrent-sibling specimen,
- one explicit local merge specimen,
- one compacted-latest-view specimen,
- and one late-reader specimen where tombstone/compaction limits matter.
