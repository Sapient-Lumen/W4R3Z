# Outcome observations, rollback guards, and fixture catalog audit

Rev0096 adds the first post-execution observation surface.

A reuse gate binds a requested use. A use-execution receipt records the consumer's actual attempted effect. That is still not enough: the observed system outcome can diverge from the recorded execution. Ward now records this as a separate, weaker-than-authority receipt.

## Design split

Outcome-observation receipts have five safe outcomes:

1. **public display matched** — a minimized public status surface was observed and refresh remains required;
2. **internal review matched** — an internal review replay was observed and refresh remains required;
3. **no-op hold confirmed** — a held/refused/no-execution path remained no-op;
4. **mismatch quarantined** — an unsafe effect was observed, quarantined, and marked rollback-review-required;
5. **observation unavailable** — no current-safe claim is made.

## Why this is not rollback authority

A mismatch may require rollback review, but the outcome-observation receipt does not itself perform rollback, remedy, repair, or status-pointer mutation. It is evidence for a later handoff/remedy packet, not a grant.

## Audit/refactor

This pass adds `tools/check_fixture_catalog_integrity.py`. The checker audits every registry-backed fixture family for direct positive fixtures, `negative/` invalid fixtures, slugged filenames, parseable JSON, schema parity with the checker registry, and schema parity. The purpose is to keep Ward's expanding refusal harness from developing hidden fixture-family drift.
