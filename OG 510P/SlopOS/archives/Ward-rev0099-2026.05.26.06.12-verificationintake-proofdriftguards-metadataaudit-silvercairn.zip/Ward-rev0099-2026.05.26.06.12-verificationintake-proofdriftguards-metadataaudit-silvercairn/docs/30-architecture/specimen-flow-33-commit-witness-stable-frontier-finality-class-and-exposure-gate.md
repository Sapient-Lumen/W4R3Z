# Specimen flow 33 — commit witness, stable frontier, finality class, and exposure gate

Goal: keep Ward honest when one trust-relevant change has been accepted or durably recorded somewhere, but different readers or policies still need stronger evidence before they should expose or spend through it.

## Scenario
A high-value local spend action depends on a policy rollback that narrows artifact `A` after a compromise finding.
The upstream durability story unfolds in four steps:
1. a coordinator accepts the rollback request and returns an acknowledgment token;
2. a replicated control plane records the rollback on a quorum and emits a commit receipt;
3. one downstream read surface still serves views only up to its current stable-read cut because another transaction touching the same policy family is unresolved;
4. later, a checkpoint/finality mechanism makes reversal materially harder, and only then does the local environment allow the strongest spend consequence to mint.

At first glance, the relying system could flatten all of this into “rollback succeeded”.
That would be a mistake.
The returned acknowledgment is weaker than the quorum-backed commit receipt.
The quorum-backed commit receipt is stronger than a mere request acceptance, but still weaker than the downstream reader’s **stable frontier** if the reader has not yet advanced past the relevant cut.
And even after the change becomes visible, the local policy for high-value spend requires a stronger **finality class** than “committed but rollback-possible”.

Ward should therefore record four distinct residues rather than one vague done bit:
1. a **commit witness** for the exact durability / consensus threshold crossed;
2. a **stable frontier** for the read surface that says how far durable truth is currently safe to expose there;
3. a **finality class** saying how hard the relevant cut is to reverse;
4. an **exposure gate** explaining why this local environment allowed observation, narrowed spend, or full spend at each stage.

In this specimen, the rollback is strong enough to drive a caution badge and a narrowed local action once the stable frontier passes the relevant cut, but **not yet strong enough for the strongest spend consequence** until the required finality class is satisfied.

## Why this matters
- Acknowledged, committed, visible-to-this-reader, and finalized are different truths.
- One consumer’s stable-read cut can lag behind a stronger upstream commitment without either side being dishonest.
- A stronger action may reasonably require a stronger finality class than a lower-risk observation path.
- Finality/reversal hardness belongs to local consequence only through an explicit gate, not by silent implication.
- A system that says only “done” hides both rollback risk and visibility lag.

## Ward pressure
This specimen pressures Ward to keep commitment/finality residue and local action policy distinct while still leaving open whether later implementation uses consensus receipts, transaction-status sidecars, reader-frontier markers, or checkpoint/finality witnesses.
