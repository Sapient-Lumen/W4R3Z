# Verification intake, proof-drift guards, and metadata lineage audit

Pass XCIX adds the next layer after remediation closure:

```text
reuse gate -> use execution -> outcome observation -> rollback-remediation -> remediation closure -> verification intake
```

The new receipt supports five safe postures:

- no-remediation closure rechecked; refresh still required;
- external remedy proof verified; quarantine sustained;
- external remedy proof failed; quarantine sustained;
- external proof absent; held/escalated;
- conflicting proof held; no winner selected.

## Non-authority boundary

Verification-intake receipts are append-only proof-intake records. They do not mutate remediation closures, rollback-remediation receipts, outcome observations, use executions, reuse gates, chain heads, status channels, or released evidence. They do not execute rollback, clear quarantine, complete remedies, repair semantics, release evidence, grant action authority, or update current status pointers.

## Cross-cube seam

- **Harbor** may produce implementation/recheck evidence that Ward records as external proof. Ward does not treat Harbor proof as authority to clear quarantine.
- **Helm** renders verified/failed/absent/conflicted proof with a visible no-authority watermark and quarantine posture.
- **Schell** minimizes public verification projections and retention of proof payloads.
- **ViewFS** can preserve source-closure and proof-intake lineage without making proof receipts trusted-path tokens.
- **SlopOS** attaches verification intake only as context for portal/recheckpoint/CH-AREF flows; consequence gates still replay the source packet and require their own authority.

## Audit/refactor

The pass also adds `tools/check_metadata_lineage_integrity.py`. The checker treats revision metadata as a living lineage surface. It verifies that top-level ledgers, context pack, surface status, manifest, README, START_HERE, latest docs, and outside-source references remain aligned with `REVISION-RECEIPT.json`.
