# Specimen flow 28 — published cut, moving alias, reader pin, and retention floor

Goal: keep immutable trust-relevant cuts, moving "current" aliases, stable reader pins, and physical retention promises visibly separate whenever Ward projects or republishes a current trust answer.

## Scenario
A relying party maintains a current local trust projection for a subject from several pieces of Ward residue.
Each recomputation emits a durable artifact containing the exact support braid, appraisal recipe, and resulting spend posture for that moment.
Ward calls that immutable artifact a **published cut**.

The operator also exposes a friendlier handle named `current-high-assurance` so downstream systems do not need to memorize exact cut identifiers.
That handle is a **moving alias**: on Monday it points at cut `C104`, and on Thursday—after newer evidence and a fresher policy epoch arrive—it advances to `C109`.
The Thursday move does **not** rewrite `C104`; it only changes what the alias names now.

One downstream auditor begins a review on Wednesday and needs reproducible results even if the alias later advances.
The auditor therefore records a **reader pin** to `C104` and performs all review work against that cut.
A different consumer may intentionally follow the alias and accept Thursday's `C109`, but the pinned reader must not be silently switched to the new cut just because the alias moved.

Later, storage cleanup runs.
Historical cuts older than the documented retention promise may be compacted or physically removed.
Ward therefore exposes a **retention floor** saying how long published cuts that may still be named by pins, audits, or rollback surfaces remain physically readable.
If `C104` falls below that floor and is removed, Ward must not pretend the alias trail or the historical name alone can still produce the old bytes.
At that point an old pin may still be historically meaningful, but it is no longer a promise of readable material.

## What this specimen is trying to preserve
1. **published cut**
   - immutable trust-relevant cut that can be addressed directly;
   - smaller than one universal table/log/queue substrate.

2. **moving alias**
   - named pointer that may advance without rewriting the cut it names;
   - smaller than final local consequence and smaller than one alias-management service.

3. **reader pin**
   - consumer-local fixation on one exact cut for stable evaluation or replay;
   - smaller than global history retention policy.

4. **retention floor**
   - explicit promise about how long historical cuts remain physically readable;
   - smaller than one universal GC or lifecycle protocol.

## Promotion pressure it creates
Do not promote these nouns further unless they survive at least:
- one specimen where a moving alias advances while a reader pin must stay stable;
- one specimen where historical addressability survives but readability does not;
- one specimen where several aliases legitimately point at the same published cut;
- one specimen where alias movement is reviewed/audited without pretending the underlying cut changed in place.
