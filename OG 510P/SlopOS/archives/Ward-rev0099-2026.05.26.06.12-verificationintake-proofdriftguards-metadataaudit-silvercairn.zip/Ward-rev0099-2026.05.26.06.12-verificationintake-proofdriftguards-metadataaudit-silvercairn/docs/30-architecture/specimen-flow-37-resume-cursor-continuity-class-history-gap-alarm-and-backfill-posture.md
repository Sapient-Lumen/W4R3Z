# Specimen flow 37 — resume cursor, continuity class, history gap alarm, and backfill posture

Goal: keep Ward honest when a trust-relevant changefeed appears resumable, but the source history may already have aged out and the only safe recovery path is an explicit bounded backfill plus a downgraded continuity claim.

## Scenario
A local high-risk approval monitor consumes trust changes about device grant `G` from an upstream source.
The sequence unfolds in seven steps:
1. the local monitor records a **resume cursor** `R1` after processing grant history through source cut `C1`;
2. the monitor goes offline for longer than usual while the source continues to emit changes, including a revocation of `G` and a later replacement grant `G2`;
3. when the monitor returns, the source says the saved cursor can no longer bridge the interval because the relevant history is outside the retained replay window or because the source lane is otherwise invalidated;
4. the local system raises a **history gap alarm** instead of silently jumping to `latest`, because it no longer knows whether the missing interval contained one or more trust-relevant state changes;
5. the local status for this intake lane is downgraded from continuous to a weaker **continuity class** such as `gap_detected` or `reset_required`;
6. recovery begins through an explicit **backfill posture**: the local system requests a bounded baseline rebuild or chunked replay, while still keeping live intake visibly separate from the repaired baseline path;
7. only after the backfill completes and the local appraiser decides the rebuilt cut is sufficient does the lane return to a stronger continuity class and allow the highest-risk consequence again.

At first glance, a product might flatten this into “stream resumed”.
That would be a mistake.
A resume cursor is weaker than continuity proof.
A continuity class is weaker than final trust consequence.
A gap alarm is stronger than silent auto-reset.
And backfill posture is different from ordinary forward intake.

Ward should therefore record four distinct residues rather than one vague health bit:
1. a **resume cursor** for the restart handle that was last believed usable;
2. a **continuity class** for how trustworthy the local history chain currently is;
3. a **history gap alarm** when one replay interval is no longer provably covered;
4. a **backfill posture** when bounded reconstruction is underway or required.

In this specimen, a UI may still show “connected”, but **the highest-risk consequence must not collapse cursor possession, replayability, continuity, and repaired baseline state into one badge**.

## Why this matters
- Saved offsets/tokens can outlive the retention window that made them meaningful.
- Silent reset to current head can erase the very evidence a high-risk decision needed.
- Baseline reconstruction is a different activity from forward intake and deserves explicit residue.
- A resumed lane can still have a weaker continuity class than before the interruption.
- Gap-aware systems are safer than systems that quietly substitute convenience for coverage.

## Ward pressure
This specimen pressures Ward to keep resume cursors, continuity classes, history gap alarms, and backfill postures distinct while still leaving open whether later implementation uses offsets, resume tokens, replication slots, checkpoint manifests, chunked snapshots, or some mixed carrier.
