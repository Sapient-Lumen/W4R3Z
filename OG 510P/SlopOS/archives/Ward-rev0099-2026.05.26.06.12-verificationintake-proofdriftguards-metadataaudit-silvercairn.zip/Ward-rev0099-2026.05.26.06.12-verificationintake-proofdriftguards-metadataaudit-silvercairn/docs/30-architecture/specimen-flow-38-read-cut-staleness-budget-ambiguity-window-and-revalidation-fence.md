# Specimen flow 38 — read cut, staleness budget, ambiguity window, and revalidation fence

Goal: keep Ward honest when a fast nearby answer is coherent enough for orientation, but not yet strong enough to justify the highest-risk consequence.

## Scenario
A local reviewer opens a high-risk approval surface for grant `G` from a regionally replicated trust store.
The sequence unfolds in seven steps:
1. the UI asks for the current posture of `G`, but the local appraiser explicitly allows a five-second **staleness budget** for browse-grade orientation so the answer can come from a nearby replica;
2. the underlying store chooses a historical **read cut** `C1` inside that budget and returns a coherent answer quickly;
3. shortly before or during that read, another replica learns a new suspension/update for `G`, but the system cannot yet safely guarantee whether that write belongs inside `C1` for every path because the relevant visibility still sits inside an **ambiguity window**;
4. the UI may still show “last observed acceptable at cut `C1`”, but it must keep the actual read cut and the staleness budget visible instead of pretending the answer was universal present truth;
5. the reviewer then requests a higher-risk action — mint a spendable approval consequence for `G`;
6. that action crosses a **revalidation fence**: Ward requires either a stronger current read, an exact read at a named cut, or an honest deferral/restart posture that waits until the ambiguity window is no longer relevant;
7. only the result that survives the revalidation fence may mint the higher-risk consequence, while the earlier browse-grade answer remains historically meaningful but visibly weaker.

At first glance, a product might flatten this into “the dashboard was green, so approve”.
That would be a mistake.
A read cut is weaker than ambient present truth.
A staleness budget is weaker than freshness certainty.
An ambiguity window is stronger than fake latest-state confidence.
And a revalidation fence is different from the initial browse-grade observation.

Ward should therefore record four distinct residues rather than one vague “looked current” bit:
1. a **read cut** for the exact historical view one answer reflects;
2. a **staleness budget** for how old the answer was allowed to be;
3. an **ambiguity window** when inclusion/exclusion of some near-time writes is not safely knowable yet;
4. a **revalidation fence** when a later stronger check is required before higher-risk consequence.

In this specimen, a UI may still show “usable for review”, but **the highest-risk consequence must not collapse read cut, stale-but-allowed view, unresolved ambiguity, and final re-check into one badge**.

## Why this matters
- Low-latency local answers often come from older safe cuts rather than from magical global present truth.
- Historical/coherent reads can be good enough for browse, triage, or ranking while still being too weak for spend.
- Distributed ambiguity windows are normal; pretending they do not exist creates false certainty.
- Waiting/retrying/rechecking can be the honest move when the action is stronger than the first observation.
- A visible revalidation fence makes later action policy clearer without forcing one global read protocol today.

## Ward pressure
This specimen pressures Ward to keep read cuts, staleness budgets, ambiguity windows, and revalidation fences distinct while still leaving open whether later implementation uses timestamp bounds, closed timestamps, explicit `AS OF` queries, deferrable reads, snapshot-plus-conflict fences, or some mixed carrier.
