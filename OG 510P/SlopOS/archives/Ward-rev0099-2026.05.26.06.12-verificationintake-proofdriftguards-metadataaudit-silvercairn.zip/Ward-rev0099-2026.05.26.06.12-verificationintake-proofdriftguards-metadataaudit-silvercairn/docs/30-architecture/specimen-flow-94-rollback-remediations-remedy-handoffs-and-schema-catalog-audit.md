# Specimen flow 94 — rollback remediations, remedy handoffs, and schema catalog audit

## Scenario

A public governance status surface was allowed only to show minimized routing context. Use execution recorded a public display. Outcome observation later sees an evidence-bundle release instead of the minimized display. Rev0096 quarantined the mismatch and required rollback review. Pass XCVII asks what Ward can safely do next.

## Flow

1. Load the source outcome-observation receipt by path and SHA-256.
2. Mirror the source outcome state, observation id, observed target, recipient class, projection policy, observed-outcome digest, and no-authority label.
3. Bind a remediation scope digest to the source observation, target, recipient, projection policy, requested remediation effect, and consequence class.
4. If the source matched or confirmed no-op, close no-remediation-needed while still requiring refresh/source replay.
5. If the source mismatched, maintain quarantine and either open rollback review or request a remediation handoff.
6. If observation was unavailable, hold without a green remediation claim.
7. Reject actual rollback, remedy, repair, export, learning use, status-pointer mutation, source mutation, and public sealed-evidence leakage.

## Fixtures

Positive fixtures cover:

- no-remediation-needed for a matched public display outcome;
- no-remediation-needed for a confirmed no-op hold;
- rollback review opened with quarantine maintained;
- remediation handoff requested with no action performed;
- unavailable observation held with no remediation claim.

Negative fixtures cover digest drift, unchecked or ghost source refs, target/recipient/projection drift, matched-source rollback overreach, mismatch without quarantine/review, rollback execution without authority, high-consequence planned effects, missing forbidden fences, public identity/sealed payload leaks, source mutation, status-pointer mutation, handoff-as-remedy laundering, and missing no-authority labels.

## Audit/refactor

`tools/check_schema_catalog_integrity.py` now audits all governance schema files against the checker registry. This prevents the cube from accumulating schema files that are not backed by fixture/checker registration.
