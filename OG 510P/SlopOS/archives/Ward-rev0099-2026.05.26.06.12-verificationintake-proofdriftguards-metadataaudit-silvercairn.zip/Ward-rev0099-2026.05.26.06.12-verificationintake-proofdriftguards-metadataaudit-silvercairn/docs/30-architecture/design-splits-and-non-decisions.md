# Design splits and non-decisions

## Splits Ward is freezing early
- custody object versus account binding;
- claim or evidence versus endorsement material;
- endorsement input versus local appraisal;
- appraisal result versus spendable consequence;
- recent success versus durable trust state.

## Non-decisions still open
- whether passkeys and non-web credentials should share one custody object shape;
- how much appraisal history should be retained as first-class archive state;
- whether spendable consequences need one shared expiration model or a family of them;
- how much of revocation and freshness checking lives inside Ward versus imported side services;
- whether multi-party endorsement sets deserve their own sub-registry now or later.

## Process non-decisions
- do not create a boundary-family map until at least three recurring seams have earned it;
- do not create a giant registry or schema family until at least two specimen tests need it;
- do not let a convenience integration define the cube’s permanent object model.

## rev0019 pressure note
- original witness material versus later incident streams;
- event statement versus remote command;
- watch ownership versus final local spend consequence.

## rev0021 pressure note
- status purpose versus generic invalidity;
- recency window versus fake live truth;
- external status authority versus original witness history.


## rev0022 pressure note
- coherent status snapshot versus one-off fetched status;
- stale/frozen status versus negative status meaning;
- aggregation/discovery surface versus per-subject status coordinate.


## rev0023 pressure note
- covered negative claim versus uncovered unknown;
- proof-carrying non-inclusion versus heuristic not-seen residue;
- local snapshot-plus-deltas versus live point lookup;
- plural accountability receipts versus one status/transparency authority.

## rev0024 pressure note
- state class versus automatic local consequence;
- action ladder versus one universal deny/allow rule;
- real narrowing versus decorative de-preference;
- status meaning versus one stapled/carried/live delivery path.

## rev0025 pressure note
- effective change time versus publication/signing time;
- known-correct interval versus local adoption cut;
- shared cause cohort versus one isolated later-state atom or one giant merged incident object;
- reason handle versus local action ladder.

## rev0026 pressure note
- witness material versus the appraisal recipe that interprets it;
- normalized result tier versus documented label scheme and breakdown;
- policy epoch versus one timeless verifier conclusion;
- replay delta versus historical amnesia.


## rev0027 pressure note
### Keep newly visible event/application splits visible
- delivery identity versus underlying cause identity;
- event/effective/publish time versus receipt order;
- local apply cursor versus transport acknowledgment or verification ping.


## rev0028 pressure note
- concurrent sibling facts versus one forced winner;
- merge recipe versus source history;
- survivor view versus complete history;
- compaction horizon versus strong negative inference.

## rev0030 pressure note
- monotone support accumulation versus closure-dependent negatives;
- closure gate versus completeness frontier, ordering window, or apply cursor;
- support braid versus one flattened reason string or one giant provenance engine;
- alternate derivation versus automatic whole-result collapse.

## rev0031 pressure note
- published cut versus moving alias;
- reader pin versus ambient reading from whatever “latest” means now;
- historical addressability versus retained readable bytes;
- alias movement versus in-place mutation of the cut itself.

## rev0032 pressure note
- writer view versus reader view;
- field identity versus label/order/alias accidents;
- compatibility lane versus fake timeless parseability;
- explicit presence versus collapsed absent/default folklore.


## rev0033 pressure note
- assurance facet versus one scalar trust score;
- acceptance floor versus observed facet value;
- bottleneck facet versus vague whole-result denial;
- rollup badge versus the facet bundle and policy that produced it.

## rev0036 pressure note
- request acceptance versus durable commitment;
- durable commitment versus stable-readable visibility on one surface;
- finality class versus one timeless done/settled claim;
- exposure gate versus the underlying commit/finality residue.


## rev0037 pressure note
- lease claim versus recipient-validated authority;
- fence token versus TTL/session confidence;
- stale-holder alarm versus fake exclusive-current-owner truth;
- cooperative handoff versus forced break.

## rev0042 pressure note
- basis pin versus ambient latest;
- cohort contrast versus one predeclared summary bucket family;
- promotion bay versus silent authority growth of a maintained derivative.


## rev0043 pressure note
- temporal lookup lane versus one vague latest-value join;
- join clock versus hidden default time axis;
- freeze rail versus silent live refresh;
- workload witness versus intuition-driven acceleration.

## rev0045 pressure note
- query contract versus saved query manifest;
- metric card versus the full contract and the full result;
- loss fence versus replayable raw truth;
- repeated question versus one giant semantic constitution.


## rev0046 pressure note
- exactness class versus one flattering fast-enough metric truth;
- estimator card versus hidden algorithm folklore;
- sketch witness versus one bare approximate number;
- approximate acceleration versus replayable exact truth.

## rev0047 pressure note
- aggregation law versus silent universal additivity;
- rollup passport versus dashboard folklore about what can be summed later;
- merge state versus one friendly rendered total.


## rev0048 pressure note
- grain witness versus one flattering row label after joins changed the real meaning;
- fanout fence versus convenience joins that silently multiply facts;
- weight carrier versus one naked percentage or average stripped of its denominator story.

## rev0049 pressure note
- observed bucket versus synthetic alignment bucket;
- explicit null or unknown versus synthetic zero;
- carried-forward value versus fresh observation;
- gap posture versus one silent chart-smoothing default.
- window frame versus one silent rolling/cumulative default.

## rev0050 pressure note
- trailing frame versus cumulative frame under one flattering chart title;
- anchor instant versus one ambient “latest” assumption;
- partial early window versus full mature window.

## rev0051 pressure note
- query recipe versus authorized view or scope lane;
- fact drift versus visibility/scope drift;
- row restriction versus field redaction;
- population witness versus one flattering dashboard title.

## rev0052 pressure note
- daily label versus explicit calendrical contract;
- UTC bucket versus local-civil bucket;
- boundary drift versus fact drift;
- pretty chart title versus declared week rule and bucket origin.

## rev0054 pressure note
- exact frozen result versus sampled preview;
- block or row sample versus one flattering generic “10% sample” label;
- sample-before-join versus sample-after-join;
- deterministic/key-stable rerun posture versus probabilistic rerun posture.

## rev0055 pressure note
- raw frozen population versus bucketed derivative;
- bucket schema versus one flattering “distribution” title;
- boundary witness versus hidden overflow/inclusivity semantics;
- interpolation posture versus one fake exact p95.

## rev0056 pressure note
- cumulative total versus interval delta;
- snapshot/current level versus odometer-like lane;
- reset-aware derivative versus naive post-aggregation slope;
- original temporality versus exported/converted temporality.


## rev0057 pressure note
- raw append row versus retry-collapsed winner;
- exact-key dedupe versus best-effort dedupe;
- current winner versus correction-bearing history;
- explicit delete/tombstone state versus silent present absence.

## rev0062 pressure note
- comparison capsule versus two naked answer tables;
- comparability passport versus same chart title;
- drift notice versus silent restatement;
- quality witness versus hidden pipeline log;
- bridge-required status versus fake smooth trend.
## rev0063 pressure note
- delta anatomy versus one polished root-cause paragraph;
- accounting movement versus causal movement;
- value diff versus explanation proof;
- cohort contrast versus causal inference;
- exemplar fence versus representative evidence;
- residual unexplained movement versus forced attribution.

## rev0064 non-decisions

- No materialized-view engine, streaming engine, OLAP index, cache, or scheduler is selected.
- No global dependency graph or invalidation protocol is selected.
- No cache-key, materialization-generation, or physical layout schema is frozen.
- No one freshness SLA is made universal across SlopOS datacube answers.
- No rule says incremental refresh is superior to full recompute for trust-bearing answers.
- No UI badge system for fresh/stale/invalid/recompute-pending states is frozen.



## Pass LXV non-decisions

- No chosen dashboard, BI product, chart grammar, notebook runtime, telemetry backend, export format, DLP system, annotation protocol, or agent memory stack.
- No decision that every UI gesture must be archived forever.
- No decision that every screenshot or copied table always receives a full egress receipt.
- No decision that render contracts are mandatory for trivial tables with no transforms or consequence.
- No decision that exported artifacts can be globally recalled; they can be narrowed, invalidated, or marked stale when known.
- No decision that annotations/comments can correct answer cells without a new answer/invalidation/recompute/review path.

## Pass LXVI non-decisions

- No approximate-query engine, sketch library, warehouse function set, online aggregation system, or statistical interval DSL is selected.
- No global budget scheduler, billing model, quota authority, payer lookup plane, or SlopOS D-BUDGET/D-METER embedding is selected.
- No one privacy accountant, privacy-loss vocabulary, or cross-query budget odometer is made universal.
- No rule says exact answers must always degrade instead of refusing.
- No UI badge, warning copy, chart uncertainty grammar, or color language is frozen.
- No decision says every degraded preview automatically opens exact recompute, or that every approximate answer is permanently review-only.

## Pass LXVII non-decisions

- No stream processor, CDC format, lakehouse table format, bitemporal database, audit-log backend, or data-version-control product is selected.
- No universal correction window, lateness budget, retention period, finality threshold, or backfill cadence is frozen.
- No rule says historical answer capsules are rewritten in place after repair.
- No rule says every old answer remains reviewable forever despite privacy, legal, or retention constraints.
- No global export recall mechanism, notification protocol, legal-erasure workflow, or UI badge grammar is selected.
- No decision says revocation, hard delete, privacy suppression, legal erasure, and ordinary absence are the same state.

## Pass LXVIII non-decisions

- No federated query engine, graph federation stack, clean-room product, semantic-layer product, data mesh catalog, policy-decision API, or trust-federation protocol is selected.
- No universal participant contract, capability discovery protocol, endpoint registry, entity graph, key-normalization scheme, or tokenization/hash method is frozen.
- No rule says pushed filters, delegated authorization decisions, clean-room aggregates, or federation trust chains become local source truth.
- No global projection/export/activation format, side-channel mitigation model, or collaborator notification protocol is selected.
- No decision says all cross-boundary answers must be impossible, or that all federated answers are stronger because more participants contributed.


## Pass LXIX non-decisions

- Ward does not choose RDF, SKOS, FHIR, QUDT, catalog glossary, semantic-layer, relational dimension, or JSON receipt as the required representation for semantic residue.
- Ward does not choose one SlopOS-wide controlled vocabulary, ontology governance group, concept registry, mapping service, or hierarchy engine.
- Ward does not decide whether every displayed member needs a concept anchor; consequence-grade, exported, cross-source, long-lived, and comparison-heavy axes are the current pressure points.
- Ward does not decide whether crosswalk warrants are manual, generated, negotiated, inferred, or imported; answer-local evidence and refusal posture matter first.
- Ward does not decide whether hierarchy cuts are tree-only, DAG/polyhierarchical, rule-based, or materialized closures.
- Ward does not decide that rename means same concept or changed concept by default; the concept anchor and label snapshot must say which case applies.

## Pass LXX non-decisions

- Ward does not choose an alerting product, incident tool, workflow engine, policy engine, feature-flag platform, event bus, autoscaler, notification portal, or ACP action family.
- Ward does not choose one threshold DSL, anomaly detector, SLO burn-rate model, escalation ladder, routing tree, silence model, or page severity taxonomy.
- Ward does not decide that every threshold breach pages a human, every stale answer opens recompute, every refusal opens an incident, or every recommendation becomes an ACP proposal.
- Ward does not decide that CH-ACPOUT, CH-NOTIF, CloudEvents, OPA decision logs, OpenFeature reasons, or workflow histories are the required representation for consequence receipts.
- Ward does not decide that every low-risk dashboard alert needs a full action warrant; consequence-grade, exported, agent-driven, ACP-adjacent, budgeted, and long-lived alerts are the current pressure points.
- Ward does not choose a global recall system for already-sent notifications, copied recommendations, exported alerts, or agent summaries; it only preserves fencing and rehydration posture when known.

## rev0070 pressure note
- threshold witness versus one bare breached cell;
- action warrant versus dashboard button or agent suggestion;
- consequence receipt versus replay authority;
- notification request versus current display-state truth;
- ACP outcome receipt versus authorization;
- control-loop dampening versus reactive thrash.

## rev0071 design splits and non-decisions

Learning-loop hygiene does not decide:

- whether Ward, SlopOS, Helm, or a future ML/experimentation companion owns full learning infrastructure;
- one feature store, model registry, experiment platform, bandit library, drift monitor, recommender, or agent-memory system;
- one holdout percentage, randomization unit, propensity estimator, reward function, retraining cadence, or rollout mode;
- one label ontology or maturity model for every consequence family;
- whether learning-loop ledgers attach to answer capsules, datasets, model versions, policy versions, action warrants, or all of the above;
- whether tainted feedback can ever be promoted for high-risk automation without human review.

The current decision is only to prevent circular proof while the datacube remains design-phase.


## rev0072 design splits and non-decisions

Scenario hygiene does not decide:

- whether Ward, SlopOS, Helm, Foundry, or a future simulation/forecast companion owns full scenario infrastructure;
- one forecasting package, simulator, synthetic generator, causal graph DSL, model registry, notebook runner, random-number API, or scenario catalog;
- one horizon vocabulary, backtest metric, calibration threshold, uncertainty interval, causal refuter suite, privacy metric, or synthetic-quality threshold;
- whether every scenario capsule attaches to answer capsules, model versions, datasets, dashboards, exports, action warrants, or all of the above;
- whether counterfactual warrants can ever be machine-enforced or remain review evidence;
- whether synthetic data can ever support production learning without human review and a fresh learning loop ledger.

The current decision is only to prevent possible-world answers from naturalizing into observed truth while the datacube remains design-phase.

## rev0073 design splits and non-decisions

Model-mediation hygiene does not decide:

- whether Ward, SlopOS, Helm, Foundry, or a future AI-assistant companion owns full natural-language query infrastructure;
- one LLM, SQL agent framework, MCP profile, semantic-layer product, prompt format, model registry, tracing backend, query validator, or human-review UI;
- one prompt/transcript retention policy, token budget, retry count, row cap, approval threshold, or query-complexity measure;
- whether every high-risk query must use a semantic layer, or whether raw text-to-SQL is always forbidden;
- whether intent bindings attach to chat turns, answer capsules, query contracts, tool calls, dashboards, exports, or all of the above;
- whether model-generated summaries can ever enter high-risk workflows without human review.

The current decision is only to prevent model mediation from laundering user prose into executable authority while the datacube remains design-phase.

## rev0074 explicit non-decisions

- No chosen signature suite, proof format, VC profile, attestation framework, transparency log, key system, or witness network.
- No chosen package format for verification bundles; RO-Crate-like, OCI-like, ZIP-like, SlopOS CH-AREF graph, VC presentation, and plain manifest shapes remain open.
- No chosen replay runtime, query engine, container format, notebook format, dependency manager, or deterministic build substrate.
- No guarantee that all answers are replayable, signed, logged, or byte-identical.
- No rule that evidence bundles may include raw rows, partner fragments, model prompts, schema samples, or full validation sidecars.
- No rule that historical replay or attestation can override current revocation, correction, freshness, privacy, projection, or action-warrant checks.

## rev0075 explicit non-decisions

- No records-management product, evidence vault, archive repository, object store, WORM mode, DLP system, legal-hold workflow, or sanitization process is selected.
- No global retention schedule, erasure policy, jurisdictional compliance mapping, designated-community model, or disposition-review UI is frozen.
- No rule says every answer, export, verification bundle, prompt, validation sidecar, partner fragment, or raw row must be retained or destroyed.
- No decision says retention beats erasure, erasure beats hold, or legal/audit/privacy pressure can be solved without local policy.
- No disposition receipt claims that all external screenshots, emails, caches, summaries, or downstream memories vanished unless separately evidenced.
- No claim says WORM, legal hold, archive transfer, digest match, or successful disposal makes an answer current, correct, authorized, or consequence-grade.

## rev0076 explicit non-decisions — contestability

- No appeals product, grievance UI, tribunal, independent-review provider, ticketing system, legal procedure, or staffing model is chosen.
- No global standing rule, burden of proof, deadline, escalation ladder, admissibility rule, fee/cost rule, or remedy taxonomy is frozen.
- No rule says every disputed answer freezes every related dashboard, aggregate, trend, learning loop, export, or action.
- No rule says every complaint invalidates the original answer, and no signature/replay/custody residue makes an answer unchallengeable.
- No downstream recall mechanism, partner-notice transport, compensation protocol, or deletion/erasure policy is implied by remedy receipts.
- No claim says explanation alone is a remedy, or that a remedy receipt proves total downstream repair unless reach is separately evidenced.

## rev0077 explicit non-decisions — stewardship and escalation

- No org chart, HR group registry, data catalog, CODEOWNERS mechanism, RACI matrix, ticket queue, incident tool, policy engine, authorization engine, or GRC product is selected.
- No global role taxonomy for technical owner, business owner, data steward, reviewer, payer, custodian, policy owner, on-call, auditor, or action authority is frozen.
- No rule says catalog owners, dashboard owners, CODEOWNERS-like reviewers, on-call responders, or assigned reviewers can approve metric edits, backfills, exports, remedies, learning uses, or actions by default.
- No rule says escalation equals acceptance, acceptance equals full authority, or handoff closure equals downstream repair.
- No permanent delegation chain is implied; delegation warrants may expire, be revoked, be refused, be consumed, or require rehydration.
- No claim says an LLM, SQL agent, tool runner, imported partner catalog, or dashboard widget can become steward-of-record.
