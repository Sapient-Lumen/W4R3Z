# Reuse gates, consequence binding, and schema registry audit

Rev0094 adds a narrow bridge between receiver convergence and downstream use.

Receiver convergence is still monitoring evidence. A reuse gate asks a smaller, harder question:

> For this request, this purpose, this consequence class, this effect, and this projection policy, may the converged evidence be reused at all?

## Design split

The gate has three safe outcomes:

1. **allow only display/internal review** — for low-consequence, no-authority views;
2. **hold** — when export, evidence release, receiver gaps, or refresh proof are missing;
3. **refuse** — when the requested consequence is semantic repair, remedy, action, delegation, budget spend, or learning use without fresh authority proof.

## Why this is not authorization

Ward is not becoming a PDP. The reuse gate records that a specific Ward evidence chain is not sufficient for a requested consequence, or is only safe for a constrained display/review surface. Any real action still belongs to the appropriate authority surface and sibling cube.

## Audit/refactor

The checker registry now carries schema identity as data. Registry integrity checks schema path and schema id alongside checker and fixture coverage. This keeps Ward's growing receipt family from becoming an implicit checker-only dialect.
