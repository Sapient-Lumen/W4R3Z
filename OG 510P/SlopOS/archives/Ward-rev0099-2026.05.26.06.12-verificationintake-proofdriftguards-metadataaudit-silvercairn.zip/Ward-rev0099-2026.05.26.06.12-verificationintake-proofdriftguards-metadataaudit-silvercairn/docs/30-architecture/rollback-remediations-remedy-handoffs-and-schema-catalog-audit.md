# Rollback remediations, remedy handoffs, and schema catalog audit

Pass XCVII adds a bounded post-observation layer:

```text
reuse gate -> use execution -> outcome observation -> rollback-remediation receipt
```

The new receipt captures what Ward may safely do after an observed outcome:

- close no-remediation-needed for matched low-consequence display/review observations;
- close no-remediation-needed for a confirmed no-op hold;
- maintain quarantine and open rollback review for mismatches;
- request a remediation handoff without claiming the remedy occurred;
- hold unavailable observations without green claims.

## Non-authority boundary

Rollback-remediation receipts are append-only governance hygiene. They do not mutate use-execution receipts, outcome-observation receipts, reuse gates, chain heads, status channels, or released evidence. They also do not execute rollback, perform repair, grant authority, publish raw evidence, or force downstream consumer action.

## Cross-cube seam

- **Helm** may render the remediation posture and visible no-authority watermark.
- **Harbor** may consume a handoff request as an input to correction/recheck work, but Harbor must still produce its own implementation/recheck receipts.
- **Schell** should decide retention, minimization, and sealed evidence posture for remediation evidence.
- **ViewFS** should carry provenance and trusted-path display boundaries for remediation packets.
- **SlopOS** should attach remediation posture to CH-AREF or portal flows only as non-authority context.

## Audit/refactor

The pass also adds `tools/check_schema_catalog_integrity.py`. Registry integrity already checks each registered schema entry; the new schema-catalog audit turns the directory itself into an audited surface. It fails when a governance schema exists without registry coverage, when the registry points at missing schema files, when schema constants drift, or when schema files are not parseable JSON object schemas.
