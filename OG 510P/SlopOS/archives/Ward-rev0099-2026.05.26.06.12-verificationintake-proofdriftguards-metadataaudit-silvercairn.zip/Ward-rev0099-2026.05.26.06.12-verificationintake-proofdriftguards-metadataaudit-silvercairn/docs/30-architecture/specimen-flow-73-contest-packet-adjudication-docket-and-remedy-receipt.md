# Specimen flow 73 — contest packet, adjudication docket, and remedy receipt

## Specimen question

A provider disputes a SlopOS provider-risk cube cell that contributed to a quarantine recommendation. The answer was rendered in a dashboard, exported to outside counsel, preserved in an audit bundle, fed into a learning-label queue, and later counted in a monthly appeal-reversal dashboard.

The provider claims the cell combined two entities after a stale crosswalk, used the wrong hierarchy cut, and reused a retained materialization after a correction horizon had already opened.

This specimen intentionally collides contest intake, answer authority, semantic drift, correction horizons, retained evidence, exported charts, action warrants, feedback taint, and current consequence authority.

## Existing material

- Answer capsule, scope lens, state-cut witness, metric/query contracts, concept anchor, crosswalk warrant, hierarchy cut, comparability passport, drift notice, quality witness, freshness envelope, and uncertainty envelope.
- Correction horizon, backfill ledger, revocation fence, freshness envelope, invalidation receipt, and recompute docket from prior correction/reuse work.
- Render contract, egress receipt, verification bundle, replay recipe, attestation envelope, custody trail, retention charter, and disposition receipts for the counsel export and audit bundle.
- Threshold witness, action warrant, consequence receipt, learning loop ledger, feedback taint fence, holdout witness, and model-mediated intent/translation/tool-call residues where applicable.

## Failure modes this specimen must catch

1. **Signature-as-finality collapse** — the exported signed chart is treated as unchallengeable because bytes and attestation check out.
2. **Complaint-as-invalidation collapse** — one disputed cell freezes every related dashboard, trend, aggregate, or action regardless of scope.
3. **Review-as-requery collapse** — the reviewer reruns against latest data and calls it adjudication of the historical answer.
4. **Form-gate collapse** — the provider cannot open a challenge because it lacks Ward's preferred evidence bundle or exact internal field names.
5. **Explanation-as-remedy collapse** — a plausible reason statement is issued, but the wrong crosswalk, old export, action warrant, and learning label remain unfenced.
6. **Remedy-overreach collapse** — a correction to one provider silently rewrites historical aggregates, trend denominators, and audit evidence without receipt.
7. **Remedy-underreach collapse** — the current dashboard is fixed, but old egress copies, training labels, model summaries, and consequence receipts still imply the old result.
8. **Standing leak** — the contest process exposes unrelated provider rows, partner fragments, or suppressed cells while trying to prove the challenger is affected.
9. **Appeal-metric laundering** — appeal reversal rate becomes a KPI without comparability, scope, quality, and privacy posture.

## Candidate residue 1: contest packet

A **contest packet** is a bounded challenge wrapper for one answer-adjacent subject.

Minimum fields for this specimen:

- challenged subject: answer capsule, cell, cohort, export, action warrant, consequence receipt, learning label, model summary, verification bundle, or scenario output;
- subject digest(s), rendered label(s), time/window, source cut, semantic cut, and egress/custody pointers when known;
- challenger identity/role, standing posture, representative/delegation posture, and privacy/projection limits;
- grounds: factual error, identity/dedupe error, semantic/crosswalk error, hierarchy/rollup error, stale materialization, quality failure, privacy/suppression issue, unsupported action, model-translation error, or remedy non-reach;
- requested remedy: explanation, amendment, correction, withdrawal, suppression, re-render, re-export, downstream notice, learning exclusion, action rollback, or dispute marker;
- submitted evidence, missing evidence, inaccessible evidence, and evidence the cube must not expose;
- admissibility status: accepted, partial, needs-info, refused-no-standing, refused-out-of-scope, frivolous/irrelevant, duplicate, expired, or unsafe-to-review;
- interim effect: no change, review-only marker, action hold, export warning, learning hold, recompute hold, or privacy restriction.

A contest packet answers: “what exactly is being challenged and what review may begin?” It does not decide the merits.

## Candidate residue 2: adjudication docket

An **adjudication docket** is the review-process residue for a contest packet.

Minimum fields for this specimen:

- docket id, linked contest packet(s), reviewer lane, reviewer/owner, independence/expertise posture, conflict posture, and escalation lane;
- procedure/rules snapshot, review standard, burden/evidence posture, deadlines, pause/extension reasons, and notice posture;
- issue framing: facts, identity, semantics, hierarchy, freshness, quality, privacy, action permission, learning use, or remedy reach;
- admitted evidence: answer capsule, state cuts, metric cards, crosswalk warrants, hierarchy cuts, logs, replay material, custody trail, external evidence, and witness statements;
- excluded/withheld evidence and reason: privacy, projection, partner boundary, expired retention, nondeterminism, unavailable source, or irrelevant scope;
- replay/check posture: byte/value/tolerance/verdict/redacted-only/not-replayable;
- interim orders: action hold, export warning, learning hold, custody hold, recompute request, backfill request, or no interim change;
- outcome: upheld, corrected, amended, attached-disagreement, withdrawn, partly upheld, not proven, refused, remanded, escalated, timed-out, settled, or unresolved;
- rationale summary, dissent/unresolved questions, appeal-next posture, and current-authority warning.

An adjudication docket answers: “how was the challenge reviewed and what was decided?” It does not make old material current or authorize future action by itself.

## Candidate residue 3: remedy receipt

A **remedy receipt** records what downstream effect a contest outcome attempted.

Minimum fields for this specimen:

- linked contest packet, adjudication docket, answer/action/export/learning subjects, and affected cells/cohorts/artifacts;
- remedy class: explanation-only, corrected, amended, dispute-attached, withdrawn, suppressed, re-rendered, re-exported, notice-sent, action-rolled-back, action-hold-lifted, learning-excluded, recompute-opened, backfill-opened, compensation/credit-opened, or refused-remedy;
- authority, actor, approval, time, policy cut, and scope of remedy;
- currentness impact: historical-only, current-answer-updated, current-action-requires-rehydration, future-use-fenced, or no-current-effect;
- derivative reach: dashboards, exports, verification bundles, custody trails, old emails, counsel packets, partner outputs, action warrants, consequence receipts, learning labels, model summaries, scenario capsules, and metrics;
- notices sent, notices pending, notices refused, and unreachable recipients;
- residual gaps and non-erasure clause: old action happened, old export existed, old evidence may be retained, old aggregate may remain historically explainable;
- rollback/fence requirements, comparability/drift updates, and review queue follow-through.

A remedy receipt answers: “what was changed or fenced, and what remains outside reach?” It does not prove every downstream copy changed.

## Walkthrough

1. The provider submits a challenge to the quarantine-score cell. Ward opens a contest packet with cell digest, rendered labels, state cut, crosswalk/hierarchy references, requested remedy, standing posture, and privacy limits.
2. The contest packet is accepted in part: identity/crosswalk, stale materialization, and action effect are in scope; unrelated partner rows and suppressed cohorts are out of scope.
3. Ward opens an adjudication docket. The reviewer lane is internal-first with possible independent escalation because the consequence was adverse and externally shared.
4. The docket admits the answer capsule, crosswalk warrant, hierarchy cut, freshness envelope, invalidation receipt, egress/custody records, and provider-submitted evidence. It excludes raw partner fragments not needed for standing or issue resolution.
5. Replay is redacted-check-only because retention/disposition reduced one source fragment. The docket records that limitation instead of pretending full historical replay succeeded.
6. The docket finds that one crosswalk split was effective before the answer's materialization reuse window and that the old answer should be amended and withdrawn from action-grade use.
7. Ward emits remedy receipts: current dashboard cell corrected, old chart marked disputed/withdrawn, counsel notified, action warrant reopened, learning label fenced, appeal-reversal metric flagged with comparability/drift notes, and old audit evidence retained with non-erasure limits.
8. A later dashboard asks whether the quarantine still stands. Ward refuses to answer from the remedy receipt alone and rehydrates current scope, source, semantic, quality, privacy, freshness, and action-warrant state.

## Promotion tests

The three residues earn promotion only if they survive all of these tests:

- can accept a bounded challenge without requiring privileged raw-system access from the challenger;
- can refuse/limit a challenge for standing, scope, privacy, expiry, or safety without hiding the refusal reason;
- can review historical answer authority without re-querying latest state and pretending it is historical adjudication;
- can record partial outcomes and unresolved disagreement without rewriting history in place;
- can reach dashboards, exports, action warrants, learning labels, model summaries, and partner/custody copies where possible while honestly naming gaps;
- can keep future action weaker than a fresh rehydrated answer, even after a remedy succeeds.

## Open questions

- Should contest packets attach primarily to answer capsules, individual cells, rendered artifacts, action warrants, or evidence families?
- When does a contest packet trigger automatic action hold, learning hold, or independent escalation?
- How should Ward represent challenger standing without leaking unrelated cohort membership or partner data?
- Should unresolved disagreement markers flow into every future disclosure, only consequence-grade disclosures, or only explicitly requested review packets?
- Where should Ward stop and a future grievance/adjudication/compliance companion begin?

## Non-decision

This specimen does not choose an appeals product, tribunal, legal rule, review deadline, burden of proof, notification transport, dispute UI, remedy protocol, or recall system. It only keeps challenge, review, and remedy evidence visible enough that signed SlopOS datacube answers cannot become unchallengeable, and remedies cannot impersonate total downstream repair.
