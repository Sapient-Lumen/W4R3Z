# Specimen flow 68 — learning loop ledger, holdout witness, and feedback taint fence

## Why this specimen exists

A SlopOS-facing datacube answer can now become an alert, recommendation, workflow input, feature flag, ACP proposal, notification, or control-loop candidate only through threshold witnesses, action warrants, and consequence receipts. The next danger is subtler: after those consequences change behavior, the resulting outcomes may be fed back into the cube, a recommender, an agent, or a policy tuner as if they were neutral observations.

This specimen keeps learning useful without making the cube into a hidden optimizer.

## Scenario

A reviewer asks:

> “Last week the provider-risk cube identified three credential-provider families with persistent deterioration. Helm notified reviewers and SlopOS proposed bounded quarantine actions. Some proposals were accepted, some were rejected, and risky events dropped. Can we use those outcomes to train the next provider-risk recommender and lower the notification threshold?”

The source answer already has prior Ward residues: scope lens, state-cut witness, metric card, grain/window/calendar/unit bindings, quality witness, freshness envelope, comparability passport, concept anchors, uncertainty envelope, threshold witness, action warrant, consequence receipt, interaction trail, render contract, egress receipt, correction horizon, and revocation fence posture.

## New residues

### Learning loop ledger

A compact record for a proposed or actual use of cube material in learning, evaluation, policy tuning, agent memory, recommendation ranking, or threshold adjustment.

Suggested fields:

- loop id and proposed use: training, evaluation, reward, ranking, threshold tuning, drift response, agent memory, policy review, or simulation;
- referenced answer capsules, threshold witnesses, action warrants, consequence receipts, interaction trails, egress receipts, and feedback taint fences;
- model/policy/agent surface and version, if any;
- feature candidates, label candidates, reward candidates, and objective/guardrail posture;
- training/evaluation cut, point-in-time feature cut, semantic/hierarchy cut, and privacy/detail posture;
- label maturity: provisional, observed, delayed, corrected, disputed, revoked, human-reviewed, or mature;
- drift/skew checks and quality witnesses;
- holdout/control/off-policy evidence, including missing-propensity refusal;
- budget/payer and privacy spend posture;
- promotion result: refused, review-only, accepted-for-offline-eval, accepted-for-shadow, accepted-for-limited-rollout, accepted-for-production, rolled back, or fenced;
- rehydration/rollback/expiry requirement.

A learning loop ledger is stronger than an analytics note and smaller than a model registry.

### Holdout witness

A compact record that a comparison lane, population, or reference path remained suitable for measuring intervention-shaped effects.

Suggested fields:

- witness id, population scope, eligibility, exclusion rules, and randomization/assignment unit;
- intended allocation and observed allocation;
- assignment, exposure, logging, and sample-ratio diagnostics;
- treatment/control/holdout surface, duration, and exposure cut;
- spillover/interference/contamination posture;
- guardrail metrics, no-data/refusal/suppression posture, and privacy budget;
- reference/current dataset cuts when used for drift or quality checks;
- outcome: clean, degraded, contaminated, invalid, or not_applicable;
- allowed consequence classes that may rely on the witness.

A holdout witness is stronger than “we had a control” and smaller than an experimentation platform.

### Feedback taint fence

A compact boundary around outcomes, labels, examples, clicks, reviewer choices, operator actions, agent summaries, and downstream metrics that may have been shaped by cube-mediated intervention.

Suggested fields:

- tainted artifact id and artifact class: label, outcome, click, approval, rejection, no-op, metric, example, feature, reward, note, summary, or export;
- source intervention: answer capsule, threshold witness, action warrant, consequence receipt, render/egress surface, or UI/ranking exposure;
- visibility/exposure posture: user saw, agent saw, reviewer saw, hidden/background, notification delivered, suppressed, or unknown;
- selection/censoring/missingness notes;
- label-delay and maturity posture;
- allowed uses: audit-only, review-only, offline-eval, off-policy-estimate, training-candidate, production-label, or forbidden;
- required holdout/counterfactual/debiasing evidence;
- privacy/detail/egress limits and revocation/correction followthrough.

A feedback taint fence is stronger than a warning and smaller than a data-governance platform.

## Flow

1. **Start from consequence receipts, not raw outcomes.** The reviewer accepted one quarantine proposal, rejected another, and did nothing on a third notification. These outcomes are linked to exact answer capsules, threshold witnesses, action warrants, and render/egress surfaces.

2. **Fence every exposed outcome.** Each approval, rejection, no-op, follow-up click, and later risky-event metric receives a feedback taint fence because reviewers and providers were exposed to notifications and quarantine proposals.

3. **Check label maturity.** A rejection is not automatically a false positive. It may reflect missing context, insufficient authority, bad timing, a privacy-suppressed cell, a reviewer workload issue, or an action-warrant mismatch. The learning loop ledger marks the label provisional until later review or ground-truth maturation.

4. **Search for a holdout witness.** If one provider-family cohort was not exposed to the notification/quarantine flow, the holdout witness records eligibility, allocation, exposure, SRM/assignment diagnostics, spillover, and privacy posture. If global UI changes reached everyone, the witness degrades or invalidates.

5. **Require point-in-time features.** Training data uses the attribute/query/view state that was available at the decision time. Later concept-anchor repair, hierarchy changes, backfills, or revocations become separate correction inputs rather than leaked future features.

6. **Preserve off-policy evidence.** If a recommender or ranking policy chose which provider-family warning to show, the learning loop ledger records behavior policy, exposure probabilities if known, candidate set, and missing-propensity refusal if unknown.

7. **Separate drift from permission.** A drift monitor can suggest that the feedback distribution changed, but it does not lower thresholds, widen action warrants, or approve a new model. The ledger can open review-only or shadow-eval posture.

8. **Record promotion result.** The loop may be refused, accepted for offline evaluation, accepted for shadow mode, or accepted for limited rollout. Production promotion requires fresh action warrants, budget gates, privacy checks, and rollback posture.

9. **Carry correction and revocation forward.** If old labels are backfilled, merged, privacy-fenced, or semantically rebridged, old learning-loop comparisons become invalid, bridge-required, or audit-only.

## Healthy outputs

A healthy learning path can say:

- `audit_only`: outcome is useful history but not training/evaluation material;
- `tainted_review_only`: feedback was intervention-shaped and lacks holdout/counterfactual evidence;
- `holdout_clean`: allocation/exposure diagnostics support effect measurement for the named scope;
- `holdout_contaminated`: UI, policy, or spillover changes invalidated the comparison lane;
- `missing_propensity`: ranked/bandit exposure cannot support off-policy evaluation;
- `label_provisional`: outcome has not matured enough for training;
- `offline_eval_allowed`: material may be used in bounded offline evaluation;
- `shadow_allowed`: model/policy can run without consequence;
- `production_denied`: learning report did not satisfy action-warrant/policy/budget gates;
- `fenced_after_correction`: old training or evaluation cut remains audit material only.

## Promotion gate

Promote learning loop ledger, holdout witness, and feedback taint fence only if they keep at least these cases honest:

1. notification click-through cannot become neutral preference evidence;
2. accepted quarantine cannot become proof of model correctness without label maturity;
3. rejected recommendation cannot become false-positive label without context;
4. a contaminated holdout is visibly degraded;
5. a ranked recommendation lacking exposure/propensity evidence refuses off-policy evaluation;
6. point-in-time feature leakage is detected before training;
7. a drift alert does not auto-retune thresholds or action warrants; and
8. corrected/revoked labels fence old model comparisons and training cuts.

The specimen passes only if learning material is weaker than its feedback taint fence and holdout witness, and any promotion is weaker than fresh action authority.
