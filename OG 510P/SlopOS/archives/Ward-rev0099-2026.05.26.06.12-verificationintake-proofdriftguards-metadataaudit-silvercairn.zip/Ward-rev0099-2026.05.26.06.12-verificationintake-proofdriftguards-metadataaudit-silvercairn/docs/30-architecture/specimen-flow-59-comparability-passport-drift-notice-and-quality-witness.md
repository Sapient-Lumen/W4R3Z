# Specimen flow 59 — comparability passport, drift notice, and quality witness

## Goal

Pressure-test the next careful datacube step for Ward: a SlopOS-shaped comparison must prove or refuse comparability before a before/after chart, trend, cohort contrast, or promotion decision can influence trust consequence.

## Scenario

A Helm surface asks a recurring Ward question over SlopOS evidence:

> Are partner trust surfaces deteriorating compared with the previous policy epoch, and which credential families or appraisal lanes got worse?

The tempting implementation is to fetch last epoch's answer, fetch this epoch's answer, join by partner and credential family, and render arrows. That is dangerous. Since the last epoch:

- one SlopOS view narrowed the authorized partner population;
- one credential-family label was split into two labels;
- one metric card changed from raw count to deduped current-winner count;
- one quality check failed at warning level for a partner feed;
- one materialized summary was rebuilt under a new policy epoch;
- one cell was privacy-suppressed in the new answer but not in the old answer.

Ward should not decide the final SlopOS cube engine. It should decide that the comparison is a first-class answer with its own residue.

## Flow

1. **The comparison starts as a question, not as a chart.** The request says which answer families or cuts are being compared and what consequence class the comparison might influence. It does not receive naked tables.

2. **Ward loads answer capsules from both sides.** Each side must carry at least a scope lens, state cut witness, axis capsule, lineage facet, refusal receipt posture, and any relevant unit/calendar/privacy/resolution/identity residues.

3. **Quality witnesses are collected before comparison.** Ward records the validation or contract subset used for each side: suite/contract ID, version, run/cut, result status, highest severity, coverage, tolerated failures, and affected cells/cohorts. A missing quality run is a quality witness with `not_run`, not invisible success.

4. **Drift notices are emitted for material differences.** Ward notices the view population narrowed, the credential-family axis split, the metric card switched dedupe posture, the policy epoch changed, the materialized summary generation changed, and refusal coverage changed. Each notice says whether the drift is compatible, bridge-required, bridged, breaking, restated, or unbridged.

5. **The comparability passport is created.** For the whole comparison and, if necessary, for individual measures or axis slices, Ward records:
   - checked scope equality or declared scope bridge;
   - checked schema/query/metric-card equality or bridge;
   - checked axis/grain/member mapping;
   - checked state cuts and materialization generation;
   - checked quality witness posture;
   - checked privacy/refusal coverage; and
   - final posture: `same_contract`, `bridged`, `bridge_required`, `incomparable`, or `not_tested`.

6. **The promotion gate refuses polished lies.** Helm may render only comparable or explicitly bridged segments as trend arrows. It must badge bridge-required segments, show warning/failed quality witnesses, and refuse or separate incomparable segments. A missing old cell, a privacy-suppressed new cell, and a scope-denied cell do not become zeros.

7. **Bridge receipts remain smaller than truth.** If a human or deterministic process maps the old credential-family label to the two new labels, the bridge receipt is attached. It does not erase the drift notice and does not claim the old answer originally used the new semantics.

8. **Later reruns can improve the passport.** If Ward later reruns old evidence under the new policy epoch or revalidates the old answer with the new quality suite, that creates a new answer capsule or bridge, not a silent mutation of the prior comparison.

## Nouns pressure-tested

- **comparability passport** — compact residue saying which answer capsules or cells are comparable, bridged, bridge-required, incomparable, or untested, and why.
- **drift notice** — compact residue naming semantic, scope, schema, source-contract, policy, quality, materialization, privacy, or refusal drift relevant to comparison.
- **quality witness** — compact validation/contract residue naming suite/contract subset, run/cut, severity, status, coverage, tolerated failures, and affected cells/cohorts.

## Why this preserves optionality

This specimen does not choose dbt, ODCS, Great Expectations, Iceberg, OpenLineage, Harbor's datacube vocabulary, or one SlopOS-native comparison API. It can work with CH-ATTRQ snapshots, SQL queries, semantic models, sparse arrays, columnar exports, materialized summaries, lineage events, or manually reviewed bridge receipts.

The promoted thing remains a comparison capsule whose authority comes from inspectable residues, not from chart polish.

## Open pressure

- Should comparability passports be mandatory for every trend/chart, or only for trust-consequence promotion?
- Should quality witnesses be generated by SlopOS, Ward, Harbor, or a future data-quality companion?
- What is the smallest bridge receipt that can justify a label split, metric formula change, or policy-epoch restatement?
- Should Helm suppress incomparable segments by default, or render them with explicit refusal badges?
- Can an LLM propose a comparison bridge, and if so which deterministic residues must validate it before promotion?
