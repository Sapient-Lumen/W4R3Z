# Specimen flow 91 — reuse gates, consequence binding, and schema registry audit

## Scenario

A public Ward surface has receiver-convergence evidence for an owner-routing status. A downstream surface wants to reuse it in five ways:

1. show a public minimized status badge;
2. replay it for internal review;
3. export an evidence bundle;
4. perform semantic repair;
5. display it while one receiver remains lagging.

## Flow

- The display request passes only as `display_reuse_allowed_refresh_required` and carries a no-authority watermark.
- The internal review request passes only as `internal_review_reuse_allowed`; it still requires source-packet replay before consequence.
- The export request becomes `evidence_release_required_hold` until a separate evidence-release receipt exists.
- The semantic repair request becomes `high_consequence_refused` until fresh handoff-packet and authority proof exist.
- The lagging receiver case becomes `receiver_gap_quarantine_hold`.

## What the specimen proves

Receiver convergence is not reusable authority. Reuse must be bound to purpose, consequence class, requested effect, projection policy, and cache subject. Safe display is not export. Export is not repair. Repair is not action authority. A receiver gap blocks reuse even when the requested effect looks low risk.

## Added executable surface

- `schemas/governance-reuse-gate-receipt.v0.json`
- `tools/check_governance_reuse_gates.py`
- `fixtures/governance-reuse-gate/`

The same pass refactors the checker registry so schema ids and schema paths are audited with checker scripts and fixture families.
