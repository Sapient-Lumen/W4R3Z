# Search continuity, sealed omissions, and cursor drift

Pass LXXXIII adds a narrow architecture rule:

> A cursor is a memory of a query basis, not proof that the next page still carries the same governance authority.

## Problem

Ward already has:

- governance handoff packets;
- decision events;
- consumer receipts;
- batch/search receipts.

The remaining weakness is temporal and cross-boundary. Search is often rendered as if the user is browsing a stable list. But governance evidence is alive: owner maps change, policies change, packet replay can degrade, and compaction can erase tombstone evidence needed for currentness.

The dangerous sentence is:

> “Load more.”

That sentence can smuggle a new governance basis into an old result set.

## Receipt position

`ward.governance.search-continuity-receipt.v0` sits above batch/search receipts:

```text
governance handoff packet
  -> governance decision event
    -> governance decision consumer receipt
      -> governance batch/search receipt
        -> governance search-continuity receipt
```

It is a projection/refusal receipt only. It cannot grant authority.

## Continuation basis

The receipt compares:

- query digest;
- request fingerprint;
- projection policy digest;
- owner-map epoch;
- packet-compaction watermark;
- prior batch/search receipt digest;
- cursor token binding and expiry.

Only unchanged basis can produce `continued_same_snapshot`.

Changed basis must produce one of:

- `held_recheckpoint_required`;
- `new_receipt_issued`;
- `new_search_required`.

## Sealed omissions

Ward should be honest that hidden rows exist without turning the count into an oracle.

Allowed broad-view disclosure modes:

- no sealed omission;
- presence-only;
- bucketed range;
- noisy count with explicit privacy budget.

Forbidden broad-view disclosure:

- exact sealed row count;
- per-subject hidden row counts;
- raw reviewer/conflict/incident/partner details;
- omission reason labels that identify the hidden row.

## Product consequence

Helm should render “continuation held; recheck required,” not “no more results.” SlopOS should treat a held cursor as a review/recheckpoint job, not as a failed search. Schell and ViewFS should preserve minimized sealed-omission evidence without exposing raw hidden facts. Harbor and Foundry should not consume page-two results for repair/export until current packet replay succeeds.

## No-authority label

Every search-continuity receipt must carry the same warning:

> This receipt preserves or refuses a search continuation. It does not approve repair, export, action, remedy, budget spend, model learning, or delegation.
