# Specimen flow 82 — release follow-ups, recipient acknowledgments, and stale-bundle quarantine

## Situation

A public Ward release exposed a bucketed governance-search summary with sealed omissions. A restricted review bundle was also sent to an internal board. Later:

- one public recipient acknowledges receipt;
- the public release expires;
- the sealed omission bucket changes;
- the restricted review projection policy is superseded;
- a partner tries to reuse a held-recheck notice as if it were a release.

## Bad collapse

The bad implementation treats the old exports as still valid because the JSON files still exist. It also treats acknowledgment as acceptance and edits the old release row in place.

This collapses history, currentness, recipient notice, revocation, correction, and authority.

## Ward residue

The flow introduces `ward.governance.evidence-release-followup-receipt.v0`.

It records:

- source release receipt id/path/digest;
- mirrored release state, expiry, recipient, purpose, item digest, and projection policy;
- trigger basis and drift class;
- recipient notice channel and acknowledgment state;
- status pointer and stale-artifact label;
- correction or omission delta posture;
- immutable-original flag;
- no-authority label;
- forbidden-effect preservation.

## Safe paths

- Recipient acknowledgment becomes `ack_recorded`, not approval.
- Expired public release becomes `revocation_issued` with status pointer.
- Changed sealed omission becomes `correction_issued` without exact public hidden counts.
- Superseded restricted review bundle becomes `stale_bundle_quarantined`.
- Reuse of a held-recheck notice becomes `reuse_refused`.

## Rejected paths

Ward rejects:

- source release digest mismatch;
- release-state mismatch;
- missing recipient binding;
- missing no-authority label;
- acknowledgment as authority;
- expired release marked current;
- revocation without status pointer;
- sensitive public correction;
- exact public hidden counts;
- dropped forbidden effects;
- high-consequence follow-up actions;
- channel mismatch;
- original release mutation;
- reuse without refresh.

## Product line

A release is not enough. A released Ward artifact should be read with its current follow-up state:

> “Evidence release. Not authority. Check follow-up status before reuse.”
