# Dispute resolution and current-head recovery

Pass LXXXVIII adds the seam after chain integrity: how a fork, pending successor, disputed head, or historical-minimized chain is resolved without rewriting history or manufacturing authority.

## Position in the spine

```text
governance handoff packet
  -> governance decision event
    -> governance decision consumer receipt
      -> governance batch/search receipt
        -> governance search-continuity receipt
          -> governance evidence-release receipt
            -> governance evidence-release follow-up receipt
              -> governance succession/transfer receipt
                -> governance chain-integrity receipt
                  -> governance dispute-resolution receipt
```

The dispute-resolution receipt is a recovery/hold receipt. It never edits the source chain-integrity receipt. It either recovers a current status pointer that still requires refresh and source-packet replay, or it sustains a no-current-head hold.

## Why this exists

A chain-integrity receipt can correctly report a fork or successor-pending state, but downstream systems still need a safe way to close the loop:

- a successor later accepts responsibility;
- a contested status channel is replaced;
- a branch is rejected as noncanonical;
- a public surface needs to say that a dispute exists without revealing sealed branch evidence;
- a historical chain should remain inspectable without becoming current;
- SlopOS needs to know whether a CH-AREF, portal, export, action, or tool path must hold, refresh, or replay.

Without a downstream resolution receipt, the tempting implementation is to mutate the old chain, select the latest branch by timestamp, or publish a “resolved” badge that hides rejected branches.

## Recovery rule

A recovered current head requires:

1. the source chain-integrity receipt bytes and source chain digest were checked;
2. the source chain validator replayed cleanly;
3. every observed branch has a disposition;
4. losing/noncanonical branches are not reusable;
5. resolver independence and conflict disclosure are recorded;
6. successor acceptance and current-status recheck are present;
7. old status channels are invalidated;
8. recipients/watchers are notified;
9. no source receipt is mutated;
10. the recovered head is labeled “not authority.”

## Hold rule

A sustained quarantine or recheck resolution publishes no current head. It can publish a status/update pointer that says “held,” but it cannot provide a status pointer that downstream systems treat as current evidence.

## Projection rule

Public resolution receipts can disclose a bucketed or presence-only dispute state. They must not disclose named private stewards, reviewer identities, conflict details, internal org maps, raw partner fragments, exact hidden branch counts, or sealed branch evidence.

## Neighbor behavior

- **ViewFS** should render recovered, held, and historical-only resolution states distinctly.
- **Schell** should retain source chain and resolution receipts separately and minimize public branch evidence.
- **Harbor** should refuse recompute or correction support from held or unrefreshed resolutions.
- **Helm** should show resolution status without creating an approval badge.
- **SlopOS** should require resolution refresh plus source-packet replay before CH-AREF, portal, export, tool, action, learning, or remedy use.
