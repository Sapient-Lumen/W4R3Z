# Specimen flow 65 — federation pact, join warrant, and projection curtain

## Goal

Pressure-test the next careful datacube step for Ward: a SlopOS-facing trust answer that combines several authority domains must not launder source authority, join permission, privacy release, delegated authorization, or external federation trust into one polished answer capsule.

## Scenario

Helm asks Ward for a consequence-adjacent answer:

> “Across our tenant and two partner collaboration surfaces, which credential providers show elevated risk after the latest revocation/backfill wave, and how does that compare with last month?”

The tempting implementation is to run a federated query across:

- SlopOS-local incident and login-posture facts;
- a partner clean-room-like collaboration exposing only aggregate overlap by hashed provider/subject keys;
- Harbor evidence summaries about signed revocation notices;
- Foundry semantic spines for provider family and credential class;
- a delegated authorization service that says which collaboration resources the requester may use;
- one materialized local summary from before the backfill in pass LXVII.

Without pass LXVIII residue, the system may accidentally join on convenient hashed keys, move filters out of the remote source when pushdown is unavailable, project dimensions a partner only allowed for joining, treat a trust federation chain as a source registry, and render a trend that reveals suppressed partner overlap.

## Walkthrough

1. **Ward starts with the requester and consequence.** It reads the scope lens, budget gate, requested answer shape, comparison posture, and whether this answer could influence trust consequence or only review.

2. **Each participant offers a federation pact.** The pact names participant identity, requester/view authority, source or endpoint handle, snapshot/cut, semantic/model version, policy epoch, freshness envelope, quality witness, correction horizon, allowed query fragments, projection rules, egress constraints, cost/privacy/detail budgets, and revocation/refusal channels.

3. **No source is imported as ambient inventory.** The OpenID Federation or FedCM-style material attached to one participant is treated as provider-local trust bootstrap or browser mediation. It can help identify the interaction boundary, but it does not become a portable source registry or durable account/provider truth.

4. **Ward labels execution fragments.** The plan proposal separates local scan, remote-service fragment, clean-room aggregate fragment, delegated authorization evaluation/search, materialized local summary reuse, and composed render. Each fragment carries whether filtering, aggregation, grouping, and suppression were enforced at source, at collaboration boundary, or locally.

5. **Pushdown is checked, not assumed.** One partner source cannot enforce a requested provider-family filter remotely. Ward either narrows the query to a permitted aggregate fragment, computes inside the protected collaboration boundary, or refuses. It does not pull raw rows locally to finish a filter that the projection curtain forbids.

6. **Join warrants are required before overlap.** Ward creates a warrant for each join seam: hashed subject key to local subject cohort, provider family to Foundry spine, Harbor notice to provider, and old materialized summary to repaired current answer. The warrant names key namespace, hash/salt/tokenization posture, relationship/cardinality, fanout fence, identity witness, join clock, unmatched handling, privacy thresholds, and policy reason.

7. **A key equality failure is not silently repaired.** One partner hashed key was minted under a different salt epoch. Ward records `join_warrant_missing` for that seam and emits a safe refusal for affected cells rather than trying a fuzzy provider-name join.

8. **Projection curtains decide output.** The partner allows joining on hashed subject and provider keys but permits only aggregate output by provider family and credential class above threshold. The curtain forbids projecting raw keys, partner row counts below threshold, exemplar handles, and activation lists. It permits noisy aggregate counts with suppression markers.

9. **Hidden policy posture is surfaced.** A Snowflake-style linked table has an underlying row policy that still applies but is not visible through the collaboration UI. Ward attaches `hidden_policy_carryover` to the projection curtain and refuses consequence-grade promotion until the provider communicates or mirrors the policy in the pact.

10. **Delegated authorization is scoped.** The AuthZEN-like PDP says the requester may run this specific collaboration analysis today. Ward records the decision context and expiry; it does not cache the search result as “all resources this requester can see” for future cube enumeration.

11. **The comparison stays fenced.** The previous-month materialized summary predates the backfill. Ward reads correction horizon, backfill ledger, revocation fences, freshness envelope, and comparability passport before rendering a month-over-month trend. Some cells become `bridge_required` or `not_comparable`.

12. **The answer capsule is assembled with residue.** It includes scope lens, state cut witness, federation pacts, join warrants, projection curtains, quality witnesses, budget/degradation posture, uncertainty envelope, comparability passport, drift notices, refusal receipts, and egress posture.

13. **Helm renders condition strips, not hidden source lore.** Helm may show `federated`, `remote fragment`, `join warranted`, `projection narrowed`, `clean-room aggregate`, `hidden policy warning`, `bridge required`, and `some cells refused`. It does not reveal denied partner existence, suppressed overlap size, raw join keys, or forbidden dimensions.

14. **Exports remain bounded.** A CSV export receives an egress receipt pointing to the projection curtains and refusing raw keys/exemplars. An agent summary must cite aggregate-only posture and rehydrate through current authority before any follow-up consequence.

15. **Future correction can propagate.** If the partner later revokes a projection or changes a join policy, Ward emits invalidation receipts, updates relevant federation pact state, fences stale exports where known, and opens a recompute docket without pretending the original collaboration never happened.

## Nouns pressure-tested

- **federation pact** — compact per-answer/per-attempt participant contract naming source authority, view/snapshot, semantic/model/policy cuts, allowed fragments, pushdown capabilities, freshness, quality, budgets, privacy, lineage, egress, and non-delegation posture.
- **join warrant** — compact evidence that a cross-boundary join is permitted and semantically meaningful, including key namespace, tokenization, relationship/cardinality, join clock, fanout/dedupe, unmatched handling, privacy thresholds, policy reason, side-channel posture, and correction/revocation reach.
- **projection curtain** — compact release boundary naming what may be exposed by participant and composed answer: fields, dimensions, measures, grains, aggregate/list/detail posture, policy carryover, thresholds/noise/suppression, no-raw-spill guarantees, activation/export limits, and refusal posture.

## Why this preserves optionality

This specimen does not choose Trino, SPARQL, GraphQL Federation, a clean-room product, an authorization API, a semantic layer, a data contract standard, a source registry, or a trust federation protocol. It can work with SlopOS snapshot handles, Harbor evidence grades, Foundry semantic spines, Steward followthrough, Schell execution epochs, ViewFS stable handles, and Helm review surfaces.

The promoted thing remains smaller than an engine: composition residue whose authority is bounded by federation pacts, join warrants, projection curtains, and the already-existing scope, state, freshness, quality, comparison, refusal, rendering, egress, uncertainty, correction, and revocation machinery.

## Open pressure

- Should federation pacts be generated per answer attempt, per participant, per source family, or per collaboration?
- What is the smallest safe machine-readable join warrant that covers key semantics, policy, fanout, temporal alignment, privacy, and side channels without becoming a universal entity graph?
- Should projection curtains live with source owners, Ward recipes, SlopOS policy, clean-room templates, or all of them with precedence rules?
- How should Ward report hidden underlying policies without revealing the shape of denied data?
- What fallback is safe when a connector cannot push a filter or aggregate to the source that was supposed to enforce it?
- Can delegated authorization search APIs be used for cube population discovery without becoming an oracle?
- How should correction horizons and revocation fences propagate when a partner changes a join or projection policy after exports already exist?
