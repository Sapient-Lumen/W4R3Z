# Specimen flow 51 — sample witness, selection stage, and repeatability lane

Goal: keep Ward honest when one repeated trust question gets a fast sampled preview before anyone has earned a replayable exact derivative.

## Scenario
A team keeps asking, “which subjects or issuers are responsible for the slowest appraisal and refresh paths this week?”

The raw history is now large enough that shells want a quick browse path before they pay for a full exact rerun. One engine offers block sampling. Another offers a deterministic keyed sample across joined tables. A third offers seeded probabilistic row sampling after the join result has already been formed.

Without explicit residue, all three surfaces can share the same chart title while quietly meaning different subsets of history.

## Flow
1. Before promotion, Ward allows a quick preview only if it emits a **sample witness** that says the family (for example block, row, reservoir, deterministic key-stable), the fraction/target size, and any extrapolation or correction rule.
2. Ward also requires a **selection stage** that says whether the sample was taken from base fact rows, one side of a join, or the joined result after filters.
3. Ward emits a **repeatability lane** that says whether reruns are expected to reproduce the same subset, depend on a fixed seed plus execution conditions, or vary probabilistically each run.
4. If one preview scales counts upward or otherwise extrapolates, Ward keeps that scaling rule in the sample witness instead of pretending the totals were directly observed.
5. If a later exact frozen rerun is produced, Ward keeps the exact result and the sampled preview visibly separate even if they share a query contract or human-facing title.
6. If a team later promotes a maintained derivative, the sampled preview still remains weaker than the frozen exact result unless a later specimen earns stronger promotion rights.

## Nouns under pressure
- **sample witness**
- **selection stage**
- **repeatability lane**

## Separations preserved
- exact frozen result versus sampled preview;
- block/cluster sample versus row-level sample;
- sample-before-join versus sample-after-join;
- deterministic or key-stable rerun posture versus probabilistic rerun posture;
- observed count versus extrapolated/corrected count.

## Why this earns space in Ward
Repeated trust questions often need a fast browse path long before they deserve a fully maintained derivative. Sampling can be a brilliant temporary teacher, but only if the result surface stays honest about what subset it saw and whether that subset can be reproduced later. Ward should therefore keep sample semantics visibly weaker than exact frozen truth and visibly weaker than any consequence-bearing interpretation layered on top.

## Promotion note
Do not promote these nouns beyond guidance unless a later specimen shows the same recurring question surviving at least one block-sampled preview, one key-stable sampled join, and one exact frozen comparison without hiding where the sample was taken or whether reruns reproduce the same subset.
