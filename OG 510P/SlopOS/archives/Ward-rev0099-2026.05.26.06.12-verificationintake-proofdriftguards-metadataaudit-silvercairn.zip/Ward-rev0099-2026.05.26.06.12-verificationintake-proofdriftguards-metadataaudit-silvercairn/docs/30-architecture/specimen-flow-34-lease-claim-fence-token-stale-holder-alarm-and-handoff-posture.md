# Specimen flow 34 — lease claim, fence token, stale-holder alarm, and handoff posture

Goal: keep Ward honest when temporary authority moves from one holder to another and delayed requests may outlive the old holder’s local belief that it still owns the lane.

## Scenario
A high-value local recovery/spend lane depends on a temporary review lease over artifact family `A`.
The sequence unfolds in four steps:
1. reviewer `R1` receives a **lease claim** saying it may approve or narrow actions on `A` for a bounded interval;
2. the authority service also issues **fence token** `42`, and the destination spend service will only honor requests carrying the newest acceptable token for that lane;
3. `R1` becomes partitioned or slow, the lease is reissued to reviewer `R2` with token `43`, and the local system raises a **stale-holder alarm** because requests from `R1` may still arrive looking superficially valid to `R1`;
4. the system first tries a cooperative release / warning path, but when `R1` does not relinquish in time the lane moves to a stronger **handoff posture** where token `42` is fenced out and only `43` can drive the highest-risk consequence.

At first glance, a product might flatten this into “review lease transferred”.
That would be a mistake.
The lease claim is weaker than the fence token.
The fence token is only useful because the destination actually checks it.
The stale-holder alarm is different again: it is the explicit residue that old requests may still be in flight or locally believed valid by the old holder.
And the handoff posture matters because graceful release, timeout grace, and forceful exclusion produce different operator expectations and different risk.

Ward should therefore record four distinct residues rather than one vague ownership bit:
1. a **lease claim** for the temporary authority lane and its bounded scope;
2. a **fence token** for the monotonic authority generation the destination will honor;
3. a **stale-holder alarm** explaining why old actions must now be treated skeptically;
4. a **handoff posture** explaining whether this was a graceful release, an expiry/grace transition, or a forced break.

In this specimen, observer surfaces may still show that `R1` once legitimately held the lane, but **the highest-risk consequence must follow the current fence token rather than the old holder’s self-belief**.

## Why this matters
- Lease ownership and recipient-side exclusion are different truths.
- Clock-based expiry can disagree across participants; stale holders are normal, not exotic.
- Delayed success from a superseded authority should not silently become current authority.
- Cooperative handoff and forced eviction have different operational and trust meanings.
- A system that says only “owner changed” hides stale-request risk and hides what actually made the new owner authoritative.

## Ward pressure
This specimen pressures Ward to keep temporary authority, monotonic fencing, stale-holder risk, and release style distinct while still leaving open whether later implementation uses capability generations, lease sidecars, replicated revision validators, or some mixed carrier.
