# Recertification receipts, cache invalidation, and refresh signals

Pass LXXXIX adds the seam after dispute resolution: how a recovered head, sustained quarantine, or historical-only resolution is rechecked after a downstream cache, browser surface, shell view, exported bundle, or CH-AREF attachment has stored it.

## Position in the spine

```text
governance handoff packet
  -> governance decision event
    -> governance decision consumer receipt
      -> governance batch/search receipt
        -> governance search-continuity receipt
          -> governance evidence-release receipt
            -> governance evidence-release follow-up receipt
              -> governance succession/transfer receipt
                -> governance chain-integrity receipt
                  -> governance dispute-resolution receipt
                    -> governance recertification receipt
```

The recertification receipt is a cache-currentness receipt. It never edits the source dispute-resolution receipt. It either rechecks a cached resolution as still current-but-refresh-required, invalidates it, sustains quarantine, downgrades it to historical-only, or holds for another recheck.

## Why this exists

A valid dispute-resolution receipt can become unsafe later:

- a newer follow-up, revocation, or quarantine arrives;
- a status channel rotates;
- a successor acceptance is withdrawn or superseded;
- a projection policy changes;
- an owner-map epoch advances;
- a branch state changes after the cached cut;
- a detached exported bundle keeps circulating after status changes;
- a SlopOS CH-AREF or portal attachment stores a recovered head and misses later refresh signals.

Without a recertification receipt, consumers are tempted to treat the last valid resolution they saw as durable authority.

## Current-cache rule

A cached resolution can be recertified only when:

1. the source dispute-resolution receipt bytes and digest are checked;
2. the source dispute-resolution validator replays cleanly;
3. the cache subject digest is recomputed;
4. the status channel is rechecked;
5. the recipient refresh channel is rechecked;
6. projection policy, owner-map epoch, successor state, branch state, and follow-up signals are checked;
7. no newer status signal is observed;
8. the next recheck is scheduled after the recertification cut;
9. the cache is labeled not authority;
10. reuse still requires refresh and source-packet replay.

## Invalidation rule

When any governing basis changes, the receipt records an invalidated stale cache, publishes a refresh signal, notifies stale consumers, and preserves a no-current-authority posture. Invalidating a cache does not mutate the source dispute-resolution receipt.

## Projection rule

Public recertification receipts reveal only status/cache state. They do not reveal sealed branch evidence, private stewards, recipient private contacts, conflicts, reviewer identities, internal org maps, raw partner fragments, or exact hidden branch counts.

## Neighbor behavior

- **ViewFS** should display recertified, invalidated, quarantined, historical-only, and recheck-required cache states distinctly.
- **Schell** should retain cache-subject digest and recertification cut while minimizing public status evidence.
- **Harbor** should refuse recompute, correction, or stale-surface support from cached resolutions that lack a current recertification receipt.
- **Helm** should show “cached resolution: refresh required” rather than an approval badge.
- **SlopOS** should require recertification plus source-packet replay before a cached resolution affects CH-AREF, portal, export, action, tool, learning, remedy, or budget flows.
