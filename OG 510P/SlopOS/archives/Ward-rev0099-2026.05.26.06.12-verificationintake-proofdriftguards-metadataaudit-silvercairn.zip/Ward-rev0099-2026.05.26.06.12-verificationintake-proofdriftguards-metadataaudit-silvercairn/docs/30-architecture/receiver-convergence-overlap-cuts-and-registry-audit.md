# Receiver convergence, overlap cuts, and registry audit

Rev0092 closed the gap between notification fanout and consumer-local refresh. Rev0093 closes the next gap: multiple Ward receivers can each hold valid reconciliation receipts while the wider system is still unsafe.

## Receipt chain

```text
recertification receipt
  -> signal-ingestion receipt
    -> signal-notification receipt
      -> signal-notification reconciliation receipt
        -> receiver-convergence receipt
```

The receiver-convergence receipt is downstream-only. It cannot mutate source reconciliations, choose a global winner, update a status pointer, or convert receiver quorum into authority.

## Convergence proof rule

A receiver is counted as converged only when its observation binds a checked signal-notification reconciliation receipt and mirrors the source release, purpose, recipient class, signal event key, subject digest, cache-subject digest, affected-consumer digest, expected-consumer count, and stale-consumer count.

A receiver set is counted as converged only when the `receiver_set_digest` matches the observed receiver identities/classes/status-channel ids and every required receiver is either reconciled or explicitly quarantined/held.

## Mixed outcomes

The receipt intentionally supports mixed states:

- all required receivers reconciled, but refresh/replay still required;
- one receiver lagging and quarantined;
- two receivers looking at different status-channel cuts, held without a winner;
- duplicate receiver observation suppressed with no fresh effect;
- receiver fork quarantined.

This prevents the common operations bug where the latest receiver or majority receiver looks safe and hides a stale or divergent receiver.

## Registry integrity refactor

Pass XCIII also audits the checker registry introduced in rev0092.

New pieces:

- `tools/check_governance_registry_integrity.py` verifies registry revision parity, unique ids/scripts, registered checker scripts, fixture directories, positive/negative fixture presence, and no unregistered governance fixture families.
- `tools/governance_common.py` now exposes `load_registry`, `fixture_counts`, and `governance_checker_scripts` so the suite and audit code share registry inventory logic.
- `tools/check_governance_suite.py` now uses `load_registry()` rather than parsing the registry ad hoc.

The refactor is intentionally small. Ward is not building a plugin framework. It is making the refusal harness self-auditing enough that a future receipt family cannot be added as files without joining the suite.

## External pressure

`EXT-OPENID-SSF-2025` and SET delivery specs (`EXT-RFC-8935`, `EXT-RFC-8936`) separate transmitter/receiver exchange, delivery, acknowledgment, and local processing. `EXT-CLOUDEVENTS-SPEC-2026` and `EXT-CLOUDEVENTS-SUBSCRIPTIONS-2026` pressure receiver identity, duplicate suppression, and subscription scope. `EXT-SCITT-ARCH-2026-LATEST` keeps plural receipt histories visible. `EXT-NIST-SP-800-137-2011` keeps continuous-monitoring cadence visible. Ward therefore records receiver convergence as non-authority monitoring evidence, not as a global grant.
