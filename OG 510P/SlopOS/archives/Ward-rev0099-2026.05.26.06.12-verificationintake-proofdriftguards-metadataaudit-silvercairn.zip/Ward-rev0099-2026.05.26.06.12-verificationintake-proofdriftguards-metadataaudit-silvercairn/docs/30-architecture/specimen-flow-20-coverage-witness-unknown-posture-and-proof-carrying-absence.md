# Specimen flow 20 — coverage witness, unknown posture, and proof-carrying absence

Goal: keep covered negative claims, uncovered unknowns, and proof-carrying absence visibly separate.

## Scenario
A credential, proof, or earlier verification event was accepted before.
Later a receiver wants to know whether fresh status should narrow current consequence.
It has some combination of:
- a locally cached status snapshot,
- one or more bounded deltas extending that snapshot,
- a per-subject status coordinate,
- an issuer participation / coverage statement,
- and optionally one or more transparency or publication receipts over the corpus it is using.

For one issuer, the local corpus says coverage exists and returns a proof-carrying negative result.
For another issuer, the corpus is fresh enough but explicitly does **not** cover that issuer/family.
For a third case, coverage exists but the receiver only has a heuristic miss rather than a real proof.
The receiver must decide what local consequence follows without pretending that uncovered or heuristic absence means “good”.

## Proposed Ward objects
1. **coverage witness**
   - small residue that says the current status corpus actually covers the relevant issuer / subject family / time cut;
   - stronger than a generic fetch success and weaker than any local spend/adopt consequence.

2. **unknown posture**
   - typed residue that says no trustworthy negative inference is available here because coverage, freshness, or service scope is insufficient;
   - stronger than silent retry logic and weaker than negative status meaning.

3. **proof-carrying absence**
   - explicit non-inclusion or covered-negative result stronger than “not found” in one cache or one query path;
   - useful only if it remains smaller than local verdict and keeps its coverage assumptions visible.

4. **delta train**
   - bounded snapshot-extension sequence that can move a local corpus forward without requiring a live oracle on every check;
   - valuable only if it remains transport residue rather than universal Ward truth.

## Why this specimen matters
It pressure-tests whether Ward can stay honest when:
- one corpus covers some issuers but not others;
- a “good” answer is only meaningful inside known coverage;
- absence may be proven, heuristic, or unknown;
- and a local replica plus deltas may be safer and more private than a live point lookup without becoming the only allowed future substrate.

## Promotion rule
Do not promote `coverage witness`, `unknown posture`, `proof-carrying absence`, or `delta train` unless they improve:
- one covered-negative specimen,
- one uncovered-unknown specimen,
- one proof-carrying non-inclusion specimen,
- and one local-snapshot-plus-delta specimen that proves Ward can stay truthful without a live oracle.
