# Specimen flow 21 — state class, action ladder, and delivery-path skepticism

Goal: keep classified later state, local consequence, and transport expectations visibly separate.

## Scenario
A credential, proof, session warrant, or earlier verification event was admitted before.
Later the receiver evaluates whether current consequence should stay the same, narrow, or stop.
It may learn later state through several different lanes:
- a locally replicated status corpus,
- a per-subject lookup,
- a carried or stapled status artifact,
- or an incident/watch stream.

Coverage is partial.
One subject lands in a covered negative class.
Another lands in an uncovered/unknown class.
A third looks negative but only through a lane whose delivery path is missing, deprecated, or no longer relied on.
Different local gates care differently: one gate is observe-only, one narrows high-risk spend, and one can hard deny.
The receiver must stay honest without pretending that classification automatically decides consequence or that one missing delivery path proves the subject clean or bad.

## Proposed Ward objects
1. **state class**
   - visible classification result smaller than any verdict or spend consequence;
   - should exist even when local policy chooses observation only.

2. **action ladder**
   - explicit local mapping from one or more state classes to actions such as observe, de-prefer, quarantine, narrow, or deny;
   - may differ by spend class, subject class, or local gate.

3. **effective-validity test**
   - explicit review question asking whether a weaker-looking action still permits substantially the same real consequence;
   - stronger than decorative policy prose and weaker than any claim that the ladder is formally proved.

4. **delivery-path skepticism**
   - residue that says status meaning is not guaranteed merely because one stapled, carried, or live lookup path exists or disappears;
   - useful only if it remains smaller than the classified state and smaller than the final local consequence.

## Why this specimen matters
It pressure-tests whether Ward can stay honest when:
- every evaluated subject should still receive a classification result;
- partial deployment makes `unknown` or `not found` common for a while;
- one local surface wants telemetry/observation while another wants quarantine or denial;
- and a softer-looking response may still be effectively equivalent to validity.

## Promotion rule
Do not promote `state class`, `action ladder`, `effective-validity test`, or `delivery-path skepticism` unless they improve:
- one observe-only rollout specimen,
- one multi-gate specimen where the same state class maps to different local actions,
- one effective-validity failure specimen where de-preference still behaves like acceptance,
- and one missing/deprecated carried-status specimen that proves Ward can stay truthful without worshipping one transport path.
