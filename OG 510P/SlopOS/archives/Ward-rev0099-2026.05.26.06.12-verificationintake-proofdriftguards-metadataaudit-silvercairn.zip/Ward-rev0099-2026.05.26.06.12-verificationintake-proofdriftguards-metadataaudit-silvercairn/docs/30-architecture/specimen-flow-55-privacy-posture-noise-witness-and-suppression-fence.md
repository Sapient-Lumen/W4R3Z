# Specimen flow 55 — privacy posture, noise witness, and suppression fence

Goal: keep Ward honest when one repeated trust question is published as an exact internal answer in one lane, a threshold-suppressed answer in another, and a noisy privacy-protected answer in a third.

## Scenario
A team wants one recurring trust question around “high-risk authentication subjects by partner and day”:
- the internal operator lane can replay the exact answer over sensitive subject-level history;
- a shared collaboration lane must not expose tiny partner/day cohorts;
- a publishable trend lane may use a privacy-protected aggregate with a declared protected entity and contribution bounds;
- the chart title looks similar in all three lanes.

All of these answers can be useful, but Ward refuses to let them share one fake timeless meaning.

## Walkthrough
1. Ward keeps the saved query recipe pinned to one basis, one authorized population, and one calendar binding, but any published answer that is privacy-shaped must also carry a **privacy posture**.
2. The internal lane may preserve the replayable exact answer. Ward keeps that answer distinct from any shared or publishable derivative instead of assuming privacy policy is just a rendering detail.
3. A collaboration lane adds threshold or output-constraint rules that can withhold small partner/day rows. Ward requires a **suppression fence** saying what may be withheld and whether withholding is silent or explicitly signaled.
4. A publishable trend lane adds a protected entity rule plus contribution bounds and a declared noise or privacy-budget family. Ward requires a **noise witness** so the release does not borrow the authority of replayable exact truth.
5. If the privacy-shaped lane omits one small cohort entirely, Ward refuses to equate that omission with zero subjects or with “no data arrived.”
6. If the exact lane and privacy-shaped lane use different protected-entity rules or contribution bounds, Ward raises meaning drift instead of pretending the chart title preserved comparability.
7. If a budgeted release family accumulates privacy cost across repeated runs, Ward keeps that budget residue attached rather than pretending each rerun is a free restatement of the same answer.

## Nouns pressure-tested here
1. **privacy posture**  
   - visible statement of whether the answer is exact-inside-scope, threshold-suppressed, differentially private, or another declared privacy-shaped truth class;  
   - smaller than full query contract, smaller than view binding, and smaller than final local consequence.

2. **noise witness**  
   - visible statement of the protected entity, contribution-bounding posture, and budget/noise family or other declared privacy mechanism residue behind the answer;  
   - smaller than the full privacy policy and smaller than the result it helped shape.

3. **suppression fence**  
   - visible statement of what rows, cells, cohorts, or small groups may be withheld and whether withholding is silent or explicit;  
   - smaller than full policy and smaller than any final interpretation of absence.

## What this specimen must keep separate
- exact replayable answer versus privacy-shaped release;
- threshold suppression versus noisy privacy protection;
- hidden policy-shaped omission versus observed zero or true absence;
- protected-entity and contribution-bound choices versus one generic metric label.

## Promotion gate for these nouns
Do not promote these nouns beyond guidance unless a later specimen shows:
- one exact internal answer,
- one threshold-suppressed collaboration answer,
- one noisy privacy-protected answer,
- and one comparison surface
surviving the comparison without collapsing into one flattering recurring title.

## Why this matters
Repeated trust questions often want broader visibility before they deserve broad raw-data access. Systems age badly when exact answers, thresholded answers, and differentially private answers all pose as the same timeless metric. Ward should therefore keep privacy-shaped publishability visibly smaller than replayable exact truth before any repeated answer gets promoted into trusted browse or decision support.
