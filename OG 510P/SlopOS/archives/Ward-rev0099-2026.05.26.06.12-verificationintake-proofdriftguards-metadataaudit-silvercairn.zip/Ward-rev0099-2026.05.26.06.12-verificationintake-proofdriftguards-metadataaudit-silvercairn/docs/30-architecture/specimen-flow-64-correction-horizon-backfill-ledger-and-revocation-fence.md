# Specimen flow 64 — correction horizon, backfill ledger, and revocation fence

## Goal

Pressure-test the next careful datacube step for Ward: a SlopOS-facing trust answer that was valid under one cut later receives late facts, an identity correction, a hard-delete/revocation state, and a partial backfill. Ward must preserve history without pretending the old answer is still current consequence-grade or silently rewriting old artifacts in place.

## Scenario

Helm displays a weekly partner-trust answer capsule from Ward:

- distinct affected subjects by partner and week;
- remediation latency percentiles;
- trust-consequence downgrade counts;
- a fenced exemplar list for the largest deterioration cell;
- a CSV exported to a review queue;
- a comparison against the previous quarter.

Three days later, SlopOS receives late events for one partner, a source connector starts reporting deletes explicitly rather than ignoring them, an identity repair merges duplicate subject keys, and a backfill campaign discovers that one historical partner label changed effective two weeks earlier. The old chart, its CSV, and an agent-written summary are still circulating.

Without pass LXVII residue, Ward can either silently rewrite the past or keep serving a polished answer that is no longer safe for consequence.

## Walkthrough

1. **Ward locates the old answer capsule.** It reads scope lens, state cut witness, freshness envelope, comparability passport, render contract, egress receipt, degradation/uncertainty posture if any, and the source/change-feed coverage known at production time.

2. **Ward checks the correction horizon.** The horizon says the affected weeks are ordinary-display-closed but still inside a repair horizon for late events, identity repairs, delete/revoke states, and policy changes. It names event time, effective time, ingestion time, publication time, local adoption time, answer-production time, and retained-change coverage.

3. **Late events do not automatically rewrite the answer.** Ward records that the late facts landed after the display close but before the correction horizon closed. It opens repair posture instead of mutating the old capsule in place.

4. **A backfill ledger is opened.** The ledger names reason classes: `late_event_repair`, `identity_merge`, `hard_delete_state_change`, and `dimension_effective_time_patch`. It records authority, requester/view, source ranges, change-feed versions, time-travel/snapshot availability, recipe/run identity, validation requirements, expected safe affected scope, budget gate, and anti-oracle disclosure posture.

5. **Ward finds a change coverage gap.** Delta-style CDF is available only after one retained version and one older section now requires raw replay or safe refusal. The ledger records `patchable_range` and `replay_required_range`; it does not claim that missing change rows mean no changes happened.

6. **Delete is treated as state.** The connector's new explicit delete records are not flattened into absence. Ward keeps source-hard-delete, trust-revocation, privacy suppression, legal erasure, and unavailable-under-view as separate safe state classes.

7. **Identity repair changes grain-sensitive measures.** The duplicate-subject merge changes distinct counts, exemplar fences, and p95 latency cohorts. Ward emits drift notices and invalidation receipts for affected answer cells, but reports affected scope only at safe granularity.

8. **The old answer receives a revocation fence.** The fence marks the answer capsule and its exported CSV/agent summary as `superseded_by_backfill_pending` for consequence. The old material remains reviewable only through authorized rehydration and only where retention/privacy policy allows.

9. **Materializations and comparisons are narrowed.** Freshness envelopes on reused/materialized answers are invalidated. Comparability passport for the old-versus-new trend moves to `bridge_required` until the backfill ledger closes and quality witnesses pass.

10. **A replacement answer is computed under explicit scope.** If raw replay and retained change coverage are enough, Ward creates a new answer capsule with a new state cut witness, quality witness, delta anatomy, and egress posture. If not enough, it narrows the answer and emits refusal receipts for unsafe cells/ranges.

11. **The backfill ledger closes with residual gaps.** The close record names replaced capsules, fenced exports, validation status, affected safe classes, unresolved ranges, and whether a comparison bridge was created, refused, or left pending.

12. **Helm renders revision without leaking.** Helm can show `revised answer available`, `old export fenced`, `bridge required`, and `some cells withheld`, but it cannot reveal hidden cohort sizes, denied row existence, or suppressed exemplar counts.

13. **Agents rehydrate before follow-up.** An agent that cites the old summary must re-query through current Ward/SlopOS authority. The old summary can be used as historical context, not current evidence for new consequence.

14. **Audit can reconstruct the story.** An authorized reviewer can inspect original answer, correction horizon, backfill ledger, invalidation receipts, revocation fences, replacement answer, and residual gaps. The system can say “this answer was legitimate under its old cut, then fenced under this repair” without historical amnesia.

## Nouns pressure-tested

- **correction horizon** — compact answer-history posture naming which cells/ranges/cuts remain open, closed, or repair-only for late data, identity correction, delete/revoke state, privacy/legal change, or backfill; it separates event/effective/ingest/publication/adoption/answer time and names retained-change coverage when known.
- **backfill ledger** — compact process residue for deliberate historical repair: reason, authority, affected safe scope, source/change/time-travel coverage, recipe/run, validation, budget/degradation posture, invalidated/replaced outputs, residual gaps, and close state.
- **revocation fence** — compact boundary preventing withdrawn, superseded, deleted, erased, privacy-fenced, stale-invalidated, or policy-narrowed answer material from being reused as current authority without rehydration.

## Why this preserves optionality

This specimen does not choose a stream processor, CDC format, lakehouse table format, bitemporal store, scheduler, legal workflow, export recall system, or UI badge grammar. It can work with SlopOS snapshot handles, Harbor exactness/evidence grades, Foundry basis cuts, Steward followthrough, Schell epochs, ViewFS stable handles, and Helm review surfaces.

The promoted thing remains smaller than an engine: repair and withdrawal residue whose authority is bounded by correction horizons, backfill ledgers, revocation fences, and the existing freshness/invalidation/recompute/comparability/render/egress/refusal machinery.

## Open pressure

- Should every answer capsule have a correction horizon, or only consequence-grade / recurring / exported / materialized answers?
- Should correction horizons be expressed in event time, effective time, source version, answer production time, or a bundle of all relevant cuts?
- When does ordinary lateness become a backfill ledger rather than normal recompute?
- How should Ward safely summarize affected scope without leaking denied or suppressed cells?
- Can a revocation fence travel with detached exports, or can it only be discovered on rehydration?
- When should an old fenced answer be hidden, kept reviewable, or destroyed under policy?
- What bridge evidence is enough to compare pre-backfill and post-backfill answers?
