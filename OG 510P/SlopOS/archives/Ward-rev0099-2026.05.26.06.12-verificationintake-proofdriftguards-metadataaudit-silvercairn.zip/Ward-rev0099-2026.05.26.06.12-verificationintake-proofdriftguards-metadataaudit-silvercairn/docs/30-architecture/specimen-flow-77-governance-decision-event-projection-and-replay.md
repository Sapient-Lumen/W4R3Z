# Specimen flow 77 — governance decision event projection and replay

## Specimen question

Rev0079 proved Ward can distinguish routing hints, break-glass review, and projection closure inside a governance handoff packet. Can Ward now emit compact decision events for sibling cubes without letting those events become hidden authority?

The pressure comes from four consumers:

1. Helm wants a visible badge and next safe action.
2. Schell wants a minimized retained receipt with expiry and sealed evidence pointers.
3. Harbor wants a recheck window after correction/recompute pressure.
4. SlopOS wants a CH-AREF-adjacent attachment that binds decision evidence to an artifact without treating digest identity as trust.

## Existing material

- `docs/30-architecture/governance-handoff-packet-v0.md`
- `docs/20-assurance/governance-proof-obligations.md`
- `docs/20-assurance/governance-decision-state-matrix.md`
- `docs/30-architecture/routing-hint-and-break-glass-closures.md`
- `tools/check_governance_handoff.py`

## New material

- `schemas/governance-decision-event.v0.json`
- `docs/20-assurance/governance-decision-event-v0.md`
- `docs/10-threat-model/decision-event-threat-model.md`
- `docs/30-architecture/decision-event-projection-and-replay.md`
- `fixtures/governance-decision-event/helm-owner-hint-render.valid.json`
- `fixtures/governance-decision-event/schell-break-glass-minimized.valid.json`
- `fixtures/governance-decision-event/harbor-recompute-recheck.valid.json`
- `fixtures/governance-decision-event/slopos-charef-attachment.valid.json`
- eight decision-event negative fixtures
- `tools/check_governance_decision_events.py`

## Walkthrough A — Helm rendering

1. The packet says an owner label can support only `routing_hint_only`.
2. The decision event references the packet digest and the `route_to_steward` evaluated action.
3. Helm renders a badge and review-intake affordance.
4. The event explicitly forbids export, repair, action, budget, remedy, privacy waiver, future-action reuse, and authority reuse without packet.

## Walkthrough B — Schell minimization

1. A sealed break-glass packet allows emergency raw partner fragment access only inside a short expiry window.
2. The decision event records the consequence-grade emergency review state, but carries only sealed CH-AREF-like pointers and retention/review-debt metadata.
3. Schell can retain a minimized receipt while sealing or later deleting the raw governance evidence.
4. Public/external projections remain non-sensitive.

## Walkthrough C — Harbor recheck

1. The packet allows a bounded recompute budget while export and action remain held.
2. The decision event records the allowed recompute-budget state and names the Harbor recheck deadline/window.
3. Harbor may schedule the recheck.
4. The event does not implement a correction and does not approve export/action.

## Walkthrough D — SlopOS CH-AREF attachment

1. The packet allows a temporary analyst to draft a crosswalk repair.
2. The decision event attaches to CH-AREF-like artifact refs.
3. SlopOS can bind the event to replayable artifact identity.
4. The event preserves the rule that a valid artifact reference proves identity, not trust, current authority, or permission.

## Negative fixture pressure

The new checker rejects:

- event without packet digest;
- mismatched packet digest;
- routing event promoted to export;
- public event leaking sealed evidence;
- event claiming consequence-grade while packet says authority missing;
- expired break-glass event treated as current;
- event with authority surface set to grant;
- event missing required forbidden-effect fences.

## Current posture

Promote governance decision event v0 as a **derived, packet-parity-checked projection**. Do not let it become an authority source, grant, policy object, approval token, or standalone audit-log substrate.
