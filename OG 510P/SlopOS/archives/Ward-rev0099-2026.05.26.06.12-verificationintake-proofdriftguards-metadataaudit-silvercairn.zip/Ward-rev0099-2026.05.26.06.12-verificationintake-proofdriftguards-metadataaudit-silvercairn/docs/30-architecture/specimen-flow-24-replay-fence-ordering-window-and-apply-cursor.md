# Specimen flow 24 — replay fence, ordering window, and apply cursor

Goal: keep delivery identity, shared-cause identity, receipt order, and receiver-local application visibly separate when later trust state arrives more than once or out of order.

## Scenario
A relying party subscribes to a later-state feed from a transmitter.
A single compromise response on the transmitter side produces two SETs that share one `txn` value:
- one session-revoked event,
- and one credential-change event.

Because of polling and retry behavior, the receiver first gets the credential-change event, then later the session-revoked event, and then receives the session-revoked event again after acknowledgement uncertainty.

The receiver also triggers a verification request on the stream and gets success that only means a verification event was or will be transmitted later.

## What this specimen is trying to preserve
1. **replay fence**
   - exact-delivery residue keyed to one delivered artifact or delivery handle;
   - stronger than best-effort duplicate tolerance and weaker than subject or cause identity;
   - lets the same delivered event be seen twice without silently double-applying a local consequence.

2. **ordering window**
   - explicit note that receipt order, event time, and issuance time are not one perfect total order;
   - lets Ward remain honest when it knows partial order but not a clean single sequence.

3. **apply cursor**
   - receiver-local marker for how far this exact receiver has actually incorporated later-state deliveries;
   - smaller than acknowledgement and smaller than final spend consequence.

4. **verification ping**
   - explicit stream/test request whose success is weaker than receiving the sought event;
   - keeps liveness checks from becoming fake evidence.

## What this specimen refuses to decide yet
- whether Ward’s long-term later-state substrate is push, poll, append-only log, local queue, or snapshot-plus-change feed;
- whether replay fences are durable objects, sidecar cache entries, or purely local ephemeral state;
- whether apply cursors are global, per-stream, per-subject, or per-view;
- whether verification pings belong in Ward proper or in an adjacent watch/observation cube.

## Why this specimen matters
Distributed trust systems fail quietly when “we received something”, “we acknowledged something”, “we applied something”, and “the thing happened before the other thing” are treated as the same sentence. Ward should resist that collapse before it chooses a transport or object family.

## Promotion test for these nouns
Do not promote `replay fence`, `ordering window`, `apply cursor`, or `verification ping` unless they improve:
- one duplicate-delivery specimen,
- one out-of-order-delivery specimen,
- one shared-cause multi-event specimen,
- and one liveness-check specimen where no real evidence has yet arrived.
