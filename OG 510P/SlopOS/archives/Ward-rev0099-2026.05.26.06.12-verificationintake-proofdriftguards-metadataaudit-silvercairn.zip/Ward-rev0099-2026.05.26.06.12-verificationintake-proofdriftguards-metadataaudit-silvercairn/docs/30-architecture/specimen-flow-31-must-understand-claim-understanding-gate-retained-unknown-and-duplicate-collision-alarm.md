# Specimen flow 31 — must-understand claim, understanding gate, retained unknown, and duplicate collision alarm

Goal: keep Ward honest whenever a trust-bearing envelope carries a mixture of safe-to-ignore residue, must-understand semantics, and format-translation risk.

## Scenario
A relying system ingests a signed trust envelope that bundles:
1. a durable subject binding;
2. an attestation/appraisal summary for a higher-risk action;
3. several UI/display hints; and
4. one new action-constraining claim introduced after some receivers were already deployed.

The new claim says the current result is valid only for a narrower action profile than older receivers expect.
A newer sender marks that claim as **must understand** inside the integrity-protected envelope.
An older receiver does not know the claim, but it *can* preserve unknown fields if it stays in the original binary/canonical format.
A bridge service then converts the envelope into a friendlier JSON-shaped intermediate form for audit indexing.
That bridge drops unknown fields and also flattens duplicate header entries according to a host parser default.

Ward should therefore record four distinct residues rather than one vague “verification passed” story:
1. a **must-understand claim** identifying the narrower action constraint that cannot be ignored;
2. an **understanding gate** that fails local consequence because this receiver/bridge stack cannot prove that claim was understood end to end;
3. a **retained unknown** note describing that an older binary-only path could have forwarded the claim without interpreting it, but the JSON bridge made that weaker still by erasing it;
4. a **duplicate collision alarm** because a semantically meaningful envelope/header field appeared twice and the stack must not silently turn parser behavior into trust meaning.

## Why this matters
- A signature over the envelope is not enough if critical semantics were ignored.
- Preserving an unknown field is weaker than understanding it, but stronger than erasing it.
- A bridge that drops unknowns is not neutral; it changes future compatibility and replay posture.
- Duplicate semantically meaningful fields are not harmless repetition when different parsers may choose different winners.
- Local deny/hold should come *after* the understanding gate, not replace it.

## Promotion pressure
Do not promote these nouns unless they survive at least:
- one X.509- or VC-like specimen where critical semantics must fail closed;
- one JOSE/COSE-style specimen with integrity-bound must-understand declarations;
- one bridge specimen where unknowns are preserved in one format and lost in another;
- and one specimen where duplicate parser behavior could otherwise create split-brain consequence.
