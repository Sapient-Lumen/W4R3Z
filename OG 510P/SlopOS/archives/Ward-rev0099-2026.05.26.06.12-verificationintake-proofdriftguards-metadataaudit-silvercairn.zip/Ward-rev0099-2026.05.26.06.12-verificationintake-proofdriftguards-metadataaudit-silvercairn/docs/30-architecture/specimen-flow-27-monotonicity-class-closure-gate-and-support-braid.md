# Specimen flow 27 — monotonicity class, closure gate, and support braid

Goal: keep safe accumulation, closure-dependent reasoning, and multi-support local consequence visibly separate whenever Ward projects a current trust answer from several support paths.

## Scenario
A relying party computes a local spend posture for a subject from three families of residue:
1. a currently acceptable key-history path;
2. a recent attestation/appraisal path;
3. an absence-shaped rule that says no conflicting later-state event has been seen for the subject inside the relevant watch lanes.

The first two families are positive support paths: new acceptable evidence can add support without invalidating earlier acceptable evidence.
The third family is not like that: “no conflicting event has been seen” may stop being true when later intake arrives, so it should not be treated as the same kind of truth.

Ward therefore records the result with an explicit `monotonicity class` for each support family and a separate `closure gate` for the absence-shaped rule.
Before the closure gate has been met, the local projection may still emit a narrowed or provisional answer, but it must not silently treat the absence-shaped rule as stable.

Later, one positive support path is withdrawn: the attestation path ages out or is superseded by a later negative appraisal.
The local result does **not** automatically collapse to zero, because the key-history path still supports a weaker spend posture.
Ward records a `support braid` that still shows the surviving derivation, and it emits an explicit note that the withdrawn derivation triggered a narrowed local consequence.
Only when the last acceptable derivation disappears—or when the closure gate for the absence-shaped rule is later crossed in the wrong direction—does the local result fully lose support.

## What this specimen is trying to preserve
1. **monotonicity class**
   - explicit note about whether one residue safely accumulates or may still require belief revision;
   - smaller than final local consequence and smaller than one universal consistency doctrine.

2. **closure gate**
   - visible point where absence-, threshold-, or count-shaped logic becomes strong enough to use;
   - smaller than completeness frontier, ordering window, or global finality.

3. **support braid**
   - compact linkage among the distinct support paths currently underwriting one local result;
   - smaller than full provenance history and smaller than final verdict.

4. **alternate derivation**
   - explicit residue that another acceptable support path still exists after one path is withdrawn;
   - smaller than pretending the withdrawn path never existed.

## What this specimen refuses to decide yet
- whether Ward stores support braids as first-class objects, compact sidecars, or embedded residue on projected answers;
- whether closure gates are global, per-watch-lane, per-subject, or per-result-family only;
- whether alternate derivation should be durable Ward vocabulary or an implementation-side inference made from support braid state;
- whether invalidation cascades should be fully logged or only summarized when local consequence changes.

## Why this specimen matters
Trust systems fail quietly when designers flatten “one more support arrived”, “nothing conflicting has arrived yet”, and “we can now safely rely on that absence-shaped fact” into one fake kind of truth.
They also fail when one lost support path is treated as if the whole result was never justified. Ward should learn both cautions before it chooses one universal belief-maintenance story.

## Promotion test for these nouns
Do not promote `monotonicity class`, `closure gate`, `support braid`, or `alternate derivation` unless they improve:
- one multi-support specimen,
- one support-loss-with-surviving-derivation specimen,
- one absence-shaped/threshold-shaped closure specimen,
- and one invalidation-cascade specimen where downstream consequence narrows because the last acceptable support path actually disappears.
