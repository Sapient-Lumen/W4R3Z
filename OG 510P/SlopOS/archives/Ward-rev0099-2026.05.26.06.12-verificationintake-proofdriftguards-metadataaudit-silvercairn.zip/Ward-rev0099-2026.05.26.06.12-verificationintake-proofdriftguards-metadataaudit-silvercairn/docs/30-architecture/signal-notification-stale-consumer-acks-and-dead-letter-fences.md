# Signal notification, stale-consumer acknowledgments, and dead-letter fences

Pass XCI adds the layer after signal ingestion: how Ward proves downstream consumers were notified, acknowledged, retried, dead-lettered, quarantined, or held after an incoming governance signal.

## Position in the spine

```text
governance handoff packet
  -> governance decision event
    -> governance decision consumer receipt
      -> governance batch/search receipt
        -> governance search-continuity receipt
          -> governance evidence-release receipt
            -> governance evidence-release follow-up receipt
              -> governance succession/transfer receipt
                -> governance chain-integrity receipt
                  -> governance dispute-resolution receipt
                    -> governance recertification receipt
                      -> governance signal-ingestion receipt
                        -> governance signal-notification receipt
```

A signal-notification receipt is a fanout and stale-consumer closure receipt. It may prove that a notification obligation was discharged or quarantined. It cannot prove local consumer refresh, approve action, mutate a status head, or upgrade an acknowledgment into authority.

## Why this exists

Rev0090 records what a receiver observed. That still leaves a dangerous gap: a signal may have been accepted for cache invalidation, but one downstream consumer may be offline, a webhook may be dead-lettered, a poll consumer may not have fetched the update, or a UI cache may acknowledge receipt without replaying its source packet.

The new receipt answers: "Who was required to hear about this signal, what exactly was sent, who acknowledged delivery, who still needs retry or manual review, and which cache subjects remain unsafe?"

## Neighbor behavior

- **SlopOS** should treat signal notification as recheckpoint pressure, not as CH-AREF permission or portal authority.
- **ViewFS** should render all-notified, partial, dead-lettered, duplicate-suppressed, and conflict-held states differently.
- **Schell** should minimize consumer identities and hidden counts while retaining consumer-set digests for audit.
- **Harbor** should not mark stale surfaces safe merely because a notification was delivered.
- **Helm** should display stale-consumer and dead-letter chips rather than green authority badges.
