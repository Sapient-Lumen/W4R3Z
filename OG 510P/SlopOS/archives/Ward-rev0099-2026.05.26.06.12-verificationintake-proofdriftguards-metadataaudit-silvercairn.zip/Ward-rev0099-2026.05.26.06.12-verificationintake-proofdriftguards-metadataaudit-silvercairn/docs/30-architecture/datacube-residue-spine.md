# Datacube residue spine

Ward now has many useful answer-adjacent residues. This spine keeps them from drifting into a pile of strong-sounding nouns. It records what each residue is allowed to imply, what it must not imply, and where the nearest owning cube or seam probably lives.

The spine is not a complete object model. It is a refusal map: a way to prevent one residue from impersonating another.

## Spine rules

1. A residue may support a consequence only through an explicit allowed edge.
2. A residue may be historically valid while being unusable for current action.
3. A residue may route review without authorizing repair, export, remedy, learning, or action.
4. A residue may prove evidence handling without proving answer truth.
5. A residue may prove answer truth without proving budget, privacy, or action authority.
6. Every residue that can leak people, partners, disputes, or incidents needs projection posture.
7. Forbidden implication edges are first-class design material, not comments.

## Residue classes

| residue | primary job | likely owner/seam | can support | must not imply |
|---|---|---|---|---|
| answer capsule | bounded answer claim | SlopOS/Ward seam | review, comparison, render, audit | action, export, learning, remedy, or governance authority |
| scope lens | population/view/scope boundary | SlopOS/Ward seam | answer interpretation, refusal, projection | source truth, owner authority, or budget authority |
| state-cut witness | exact state/version cut | Ward/SlopOS seam | replay/review of a historical answer | current truth without freshness/rehydration |
| metric card/query contract | semantic/query promise | SlopOS/Foundry/Ward seam | semantic coverage and query validation | approval to change semantics or spend budget |
| concept anchor | stable meaning identity | Foundry/Ward seam | semantic continuity and label drift handling | current hierarchy membership or crosswalk equivalence |
| crosswalk warrant | bounded mapping bridge | Foundry/Ward seam | comparison, restatement, join, bridge review | no-map erasure, privacy waiver, or action authority |
| hierarchy cut | rollup membership cut | Foundry/Ward seam | rollup replay/comparison | current taxonomy truth after drift |
| quality witness | source/answer quality evidence | Ward/SlopOS seam | degradation, review, refusal | semantic correctness, stewardship, or action approval |
| freshness envelope | currentness window | Ward/SlopOS seam | reuse, stale-but-reviewable posture | live truth or update authority |
| invalidation receipt | old authority narrowing | Ward/Harbor seam | fencing and recompute/remedy triggers | total downstream recall or new truth |
| recompute docket | recompute attempt posture | Ward/Helm/Harbor seam | review of repair/backfill route | authority to repair, budget approval, or publication |
| correction horizon | repair reach boundary | Harbor/Ward seam | repair scope, derivative reach | all derivatives fixed or old evidence erased |
| backfill ledger | deliberate historical repair | Harbor/Ward seam | repair campaign audit | scheduler authority or current action permission |
| revocation fence | withdrawn/narrowed use boundary | Harbor/Schell/Ward seam | refusal, degradation, stale warning | deletion, amnesia, or global recall |
| verification bundle | portable audit evidence | Ward/ViewFS/Schell seam | audit, challenge, replay input | current truth, privacy permission, or action authority |
| replay recipe | rerun/check method | Ward/Helm seam | replay class and reproducibility check | same result, current authority, or no-change proof |
| attestation envelope | signed/logged proof wrapper | Ward/ViewFS seam | issuer/proof/log evidence | semantic correctness, local policy, or action permission |
| custody trail | evidence handling history | Schell/Ward seam | chain-of-handling review | current answer truth or retention permission |
| retention charter | allowed evidence retention | Schell/Ward seam | lifecycle review and minimization | permission to keep using evidence for new decisions |
| disposition receipt | disposal/reduction record | Schell/Ward seam | lifecycle status and replay weakening | amnesia, source absence, or no residual copies |
| contest packet | challenge wrapper | Ward/Harbor/Helm seam | standing, grounds, requested remedy | adjudicated truth or automatic hold everywhere |
| adjudication docket | review process residue | Ward/Harbor seam | review completeness and outcome context | full downstream repair or future action authority |
| remedy receipt | downstream remedy record | Harbor/Ward seam | correction/remedy reach and gaps | all consumers repaired or learning/action safe |
| threshold witness | trigger evidence | Ward/Helm seam | pending/firing/withheld trigger state | notification/action authority |
| action warrant | consequence permission | Ward/SlopOS seam | explicit action support | answer truth, budget spend beyond scope, or learning use |
| consequence receipt | what happened downstream | Ward/Helm/Harbor seam | audit, rollback, taint detection | correctness of the triggering answer |
| learning loop ledger | learning/evaluation use authority | Steward/Ward seam | training/eval/policy-tuning review | neutral labels or observed truth |
| holdout witness | clean comparison support | Ward/Steward seam | intervention/effect review | causality by itself or action authority |
| feedback taint fence | intervention-shaped feedback mark | Ward/Steward seam | learning degradation/refusal | unusable forever or clean label proof |
| scenario capsule | forecast/simulation wrapper | Ward/Steward seam | non-observed scenario answer | observed truth or action permission |
| counterfactual warrant | would-have-happened claim support | Ward/Steward seam | causal/counterfactual posture | identified effect without assumptions/refutation |
| synthetic boundary | generated/imputed/simulated marker | Ward/Schell/Steward seam | allowed synthetic use | naturalized observed facts |
| intent binding | natural-language meaning capture | Ward/Helm seam | query/tool/request interpretation | semantic correctness or execution permission |
| translation warrant | generated query/tool coverage | Ward/Foundry/Helm seam | checked translation/execution input | answer truth or action approval |
| tool-call leash | tool execution boundary | Helm/Ward seam | effect caps and execution audit | stewardship, delegation, or approval |
| stewardship charter | scoped accountability and maintenance posture | Ward/Steward seam | who may be accountable for which duties | specific approval, budget spend, export, action, or remedy by itself |
| delegation warrant | scoped temporary authority | Ward/Helm/SlopOS seam | who may perform which task now | steward-of-record, re-delegation, unrelated consequences |
| escalation handoff | routing and acceptance residue | Ward/Helm/Steward seam | who accepted/refused which authority | resolution, repair, approval, or action by assignment alone |
| governance handoff packet | compiled proof over charter/warrant/handoff/currentness | Ward seam | consequence-grade/refusal/review-only decision | catalog, ticketing, IAM, or incident system replacement |

| governance evidence-release receipt | bounded release/hold/refusal record for projected governance evidence crossing a boundary | Ward/ViewFS/Schell seam | minimized evidence release, held recheck notice, audit/review intake | action authority, semantic repair, privacy waiver, remedy, budget spend, learning use, or future reuse |

## Forbidden implication edges

- `catalog_owner -> approval`
- `dashboard_owner -> export_authority`
- `code_owner -> metric_semantics_authority`
- `domain_owner -> privacy_waiver`
- `on_call -> semantic_steward`
- `ticket_assignee -> accepted_escalation`
- `page_sent -> handoff_accepted`
- `handoff_accepted -> repair_resolved`
- `agent_tool_access -> delegation_authority`
- `tool_call_leash -> stewardship_authority`
- `payer_authority -> metric_semantics_authority`
- `semantic_steward -> recompute_budget_authority`
- `valid_CH_AREF -> trustworthy_evidence`
- `signed_attestation -> current_authority`
- `replay_success -> action_permission`
- `retained_artifact -> allowed_reuse`
- `disposition_receipt -> global_amnesia`
- `contest_open -> remedy_granted`
- `remedy_receipt -> all_derivatives_fixed`
- `threshold_crossed -> action_authorized`
- `consequence_receipt -> answer_correct`
- `owner_hint -> consequence_grade`
- `evidence_release_receipt -> action_authority`
- `evidence_release_receipt -> privacy_waiver`
- `released_bundle -> current_packet_replay`
- `released_bundle -> complete_visible_universe`
- `export_log -> safe_governance_release`


## Low-risk owner-hint mode

Owner hints may be allowed only as routing hints when all of these are true:

- read-only use;
- low consequence;
- no export, no remedy, no learning use, no action, and no publication change;
- no raw row or partner fragment exposure;
- no private/conflict/incident governance evidence exposure;
- no stale materialization update;
- visibly labeled as non-authority;
- refused automatically if the viewer asks for approval, repair, recompute, export, learning, remedy, or action.

## Pass LXXXV addition — evidence-release follow-up receipt
`ward.governance.evidence-release-followup-receipt.v0` sits after evidence-release receipt in the residue spine. It can support acknowledgment, revocation, correction, stale-bundle quarantine, reuse refusal, and refresh/recheck notices. It must not imply action authority, export expansion, semantic repair, remedy, learning use, budget spend, privacy waiver, stewardship acceptance, or mutable correction of the original release.

## Pass LXXXVI addition — succession/transfer receipt
`ward.governance.succession-transfer-receipt.v0` sits after evidence-release follow-up receipt in the residue spine. It can support successor/contact/status-channel currentness checks, predecessor closure, successor acceptance or pending state, stale-channel refusal, and refresh-required routing. It must not imply action authority, export expansion, semantic repair, remedy, learning use, budget spend, privacy waiver, delegation, or replacement of the underlying governance handoff packet.

New forbidden implication edges:

- `successor_label -> authority_grant`
- `accepted_transfer -> semantic_repair_authority`
- `status_channel_rotation -> export_authority`
- `predecessor_contact -> continuing_authority_after_transfer`
- `old_status_url -> current_release_state`
- `transfer_receipt -> delegation_warrant`
- `pending_successor -> current_reuse`

## Pass LXXXVII addition — governance chain-integrity receipt

`ward.governance.chain-integrity-receipt.v0` sits after evidence-release, follow-up, and succession/transfer receipts. It is a lineage/currentness residue, not an authority residue.

It may say:

- these release/follow-up/transfer members were replayed in this order;
- these member byte digests produced this chain digest;
- source release, purpose, recipient, source item, and projection policy stayed in scope;
- this transfer is the current status head; or
- no current head exists because a fork/dispute is held.

It must never imply export, action, repair, remedy, budget spend, learning use, privacy waiver, delegation, or approval.

## Pass LXXXVIII addition — governance dispute-resolution receipt

`ward.governance.dispute-resolution-receipt.v0` sits after a chain-integrity receipt reports a fork, pending successor, disputed head, recheck state, or historical-minimized chain. It is a recovery/hold residue, not an authority residue.

It may say:

- this chain-integrity receipt was replayed by byte digest and source-chain digest;
- this branch set was observed and digested;
- these branches were selected, rejected, quarantined, pending, or historical-only;
- this recovered status pointer may be refreshed and replayed; or
- no current head exists and reuse remains held.

It must never imply export, action, repair, remedy, budget spend, learning use, privacy waiver, delegation, or approval. A resolved dispute is still weaker than a fresh governance packet for any consequence.

## Pass LXXXIX addition — governance recertification receipt

`ward.governance.recertification-receipt.v0` sits after a dispute-resolution receipt has been cached by a consumer, rendered into a UI, retained by a bundle, or attached to a SlopOS handle. It is a cache-currentness residue, not an authority residue.

It may say:

- this cached dispute-resolution receipt was replayed by byte digest;
- this cache subject digest still names the same release, recipient, purpose, source item, and projection policy;
- this status channel, recipient refresh channel, owner-map epoch, successor state, branch state, and follow-up-signal cut were checked;
- the cache is current only as a status pointer and still refresh-required;
- the cache is invalidated, quarantined, historical-only, or held for recheck.

It must never imply export, action, repair, remedy, budget spend, learning use, privacy waiver, delegation, approval, or consequence-grade reuse.

New forbidden implication edges:

- `cached_resolution -> current_authority`
- `recertified_cache -> action_permission`
- `recertified_cache -> export_permission`
- `status_pointer_rechecked -> source_packet_replayed`
- `refresh_signal_sent -> consumer_refreshed`
- `recipient_ack -> consequence_permission`
- `next_recheck_scheduled -> safe_until_any_use`
- `cache_current -> no_future_fork`


## Pass XC addition — governance signal-ingestion receipt

`ward.governance.signal-ingestion-receipt.v0` sits after recertification as receiver-observation hygiene. It records an incoming status/refresh/revocation/projection/successor/branch/quarantine signal, the receiver checks performed, duplicate/watermark/conflict state, and the follow-up required.

It may say:

- a new basis-changing signal was accepted for recertification;
- a duplicate signal was ignored;
- a stale signal was ignored;
- conflicting signals were held without a winner;
- an irrelevant or invalid signal was ignored/rejected.

It must never imply authority, consumer refresh, current head recovery, export, action, repair, remedy, budget spend, learning use, privacy waiver, delegation, or approval.

## Pass XCI residue-spine note

Governance signal-notification receipts are derived fanout/stale-consumer closure residues. They depend on signal-ingestion receipts and must not imply recertification, authority, refresh, export, repair, action, or status-head mutation.

## Pass XCII residue-spine note

`ward.governance.signal-notification-reconciliation-receipt.v0` sits after a signal-notification receipt and before any consumer may claim a stale cache was locally refreshed. It is a reconciliation/status residue, not an authority residue.

It may say:

- a source signal-notification receipt was replayed by byte digest;
- an affected-consumer set was mirrored exactly;
- specific consumers supplied checked recertification receipts;
- specific consumers remain pending, dead-lettered, duplicate-suppressed, or conflict-held;
- unreconciled consumers are quarantined and visible as gaps.

It must never imply action, export, repair, remedy, budget spend, learning use, privacy waiver, delegation, approval, current-head mutation, or source-notification mutation.

New forbidden implication edges:

- `notification_ack -> consumer_refresh`
- `signal_notification_receipt -> all_consumers_recertified`
- `partial_reconciliation -> complete_reconciliation`
- `dead_letter -> delivered_and_refreshed`
- `duplicate_notification -> new_refresh`
- `conflict_hold -> winner_selected`
- `reconciliation_receipt -> status_pointer_update`
- `consumer_recertification_ref -> action_authority`

## Pass XCIII residue — receiver-convergence receipt

Receiver-convergence receipts are monitoring/audit residues downstream of signal-notification reconciliation. They bind source reconciliation bytes, receiver-set digest, affected-consumer overlap digest, status-channel cut digests, receiver observation states, stale/quarantine/hold posture, and projection safety. They are forbidden from implying global authority, receiver quorum approval, status-pointer mutation, action/export/remedy/repair/learning use, or recertification by themselves.

## Use-execution receipt

A derived post-gate receipt that proves the actual display/review/hold/refusal/quarantine effect stayed inside a source reuse gate. It never grants authority or updates status pointers.

## Outcome-observation receipt

A derived post-execution receipt that proves a use-execution outcome was observed, held unavailable, confirmed no-op, or quarantined for rollback review. It never grants authority, performs rollback, or updates status pointers.

## Pass XCVII residue note — rollback-remediation receipt

A downstream post-observation receipt that records whether remediation is unnecessary, held, review-opened, or handed off after an outcome observation. It is not a rollback executor, not a remedy receipt, not a correction implementation, and not status-pointer authority. Its strongest safe claim is that Ward maintained the right containment posture after an observed outcome.

Forbidden implication edges:

- `outcome_observation_mismatch -> execute_rollback`
- `rollback_review_opened -> rollback_completed`
- `remediation_handoff_requested -> remedy_completed`
- `no_remediation_needed -> durable_current_trust`
- `rollback_remediation_receipt -> status_pointer_update`
