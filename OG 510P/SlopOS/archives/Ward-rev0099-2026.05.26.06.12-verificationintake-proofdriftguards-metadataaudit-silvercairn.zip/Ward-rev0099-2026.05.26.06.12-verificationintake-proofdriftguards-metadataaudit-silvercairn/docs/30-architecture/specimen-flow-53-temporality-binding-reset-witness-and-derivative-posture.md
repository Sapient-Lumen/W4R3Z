# Specimen flow 53 — temporality binding, reset witness, and derivative posture

Goal: keep Ward honest when one repeated trust question can be rendered as a cumulative total, an interval delta, a current snapshot, or a derived rate.

## Scenario
A team wants one recurring trust question around “attestation checks”:
- one review board wants **`attestation_checks_total`** for the running total since process start;
- another wants **checks during the last 5 minutes**;
- another wants **current active attestation sessions**;
- another wants **checks per second** for alerting.

All four answers are useful, but Ward refuses to let them share one fake timeless meaning.

## Walkthrough
1. Ward keeps the saved query recipe pinned to one basis and one authorized population, but each published numeric surface must also carry a **temporality binding**.
2. The running total is published as `cumulative` with a start/created time story attached to the lane.
3. The “last 5 minutes” answer is published as `delta-over-window`, not as a cosmetically renamed total.
4. The “current active sessions” answer is published as `snapshot`, not as a counter-shaped lane.
5. The alerting surface `checks_per_second` is published only as a derived surface with an explicit **derivative posture** saying whether it came from replayed event deltas, reset-adjusted cumulative counters, or another declared method.
6. A restart happens. The underlying cumulative lane resets. Ward records a **reset witness** saying whether the reset was cleanly detected and adjusted for, remains ambiguous, or makes the derivative unsafe for this interval.
7. If several worker-local counters are later summed, Ward keeps derivative work reset-aware at the per-series lane before flattening them into the promoted aggregate; otherwise the derivative posture degrades or the answer is withheld.
8. If a downstream export rewrites the same lane from delta into cumulative (or vice versa), Ward treats that as a distinct temporality binding and raises comparability caution rather than pretending the chart title preserved meaning.

## Nouns pressure-tested here
1. **temporality binding**  
   - visible statement of whether one recurring numeric surface is cumulative, delta, snapshot, or another declared temporal contract;  
   - smaller than query contract, smaller than exactness class, and smaller than final local consequence.

2. **reset witness**  
   - visible statement of whether resets/discontinuities were absent, detected and adjusted for, unresolved, or not applicable;  
   - smaller than continuity class, smaller than derivative result, and smaller than any restart/root-cause story.

3. **derivative posture**  
   - visible statement of whether a rate/increase/change answer was replayed from base deltas, derived from cumulative state, derived after aggregation with caveats, or withheld as unsafe;  
   - smaller than the base series itself and smaller than any decision that consumes it.

## What this specimen must keep separate
- cumulative total versus interval delta;
- snapshot/current level versus odometer-like total;
- reset-aware derivative versus naive post-aggregation slope;
- exported/converted temporality versus original lane meaning.

## Promotion gate for these nouns
Do not promote these nouns beyond guidance unless a later specimen shows:
- one cumulative/base lane,
- one delta/window lane,
- one snapshot lane,
- one reset event or discontinuity,
- and one derived-rate surface
surviving the comparison without collapsing into one flattering metric title.

## Why this matters
Repeated trust questions often start life as “just show me a rate” or “just graph the total.” Systems age badly when they forget that cumulative, delta, snapshot, and derived-rate outputs are different truths. Ward should therefore keep temporal contract and reset handling visible before any recurring numeric surface gets promoted into trusted browse or decision support.
