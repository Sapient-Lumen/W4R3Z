# Specimen flow 50 — unit binding, conversion witness, and display scale

Goal: keep Ward honest when one repeated numeric trust question becomes a recurring surface whose numbers can be expressed, normalized, or displayed in different units.

## Scenario
A team promotes two recurring trust questions:
1. “verification latency for attestation appraisal”; and
2. “share of narrowings among all verdict refreshes.”

One ingestion path reports latency in `ms`, another in `s`. One downstream chart wants to show the same values as human-friendly `ms`. Another product card wants the narrowing share as a displayed percentage even though the canonical source computation is a ratio from `0` to `1`.

Without explicit unit residue, all of these surfaces can borrow the same title while quietly changing the meaning of the number.

## Flow
1. Before promotion, Ward forces an explicit **unit binding** for each recurring surface, such as `seconds` for latency or `ratio` for the share surface.
2. If an input source arrives in a different but compatible unit, Ward emits a **conversion witness** that says exactly how values were normalized into the bound unit before publication.
3. If an input source arrives with an unknown, conflicting, or mixed unit, Ward does not silently merge it into the promoted surface; the candidate stays weaker than published truth until the unit ambiguity is resolved.
4. If a dashboard or shell wants to render `0.034 s` as `34 ms`, or `0.12` as `12%`, Ward keeps that rendering choice in a **display scale** lane that is visibly weaker than the bound unit and weaker than the conversion witness.
5. If a maintained derivative is later promoted, the published surface still carries basis pin, query contract, unit binding, any conversion witness that mattered, and the display scale when human rendering differs from canonical meaning.

## Nouns under pressure
- **unit binding**
- **conversion witness**
- **display scale**

## Separations preserved
- canonical unit contract versus source-unit residue;
- conversion/normalization versus display formatting;
- ratio versus percentage;
- raw stored value versus auto-scaled human-readable rendering.

## Why this earns space in Ward
Repeated trust questions are vulnerable to flattering labels like “latency,” “failure rate,” or “storage used.” If unit semantics stay implicit, one friendly number can hide milliseconds-versus-seconds drift, bytes-versus-kibibytes drift, or ratio-versus-percentage drift. Ward should therefore keep unit semantics visibly weaker than raw facts and visibly weaker than the downstream actions that consume the grouped result.

## Promotion note
Do not promote these nouns beyond guidance unless a later specimen shows the same recurring question surviving at least one source-unit conversion, one ratio-versus-percent rendering path, and one mixed-unit rejection or quarantine case without hiding which unit contract was in force.
