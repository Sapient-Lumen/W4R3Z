# Specimen flow 48 — view binding, population witness, and scope drift alarm

Goal: keep Ward honest when one repeated trust question becomes a published surface even though different viewers are not looking at the same authorized population.

## Scenario
A team keeps asking a recurring question across several audiences:

> “Show the daily count of credentials newly narrowed for review, by provider and environment.”

The first implementation looks tidy, but the semantics are slippery:
1. one internal team runs the recipe against a broad privileged view that includes all environments;
2. one partner-facing surface runs the same recipe through an authorized view that drops private fields and hides some rows;
3. one dashboard lane rides a narrower credential/policy path with user-specific filters;
4. a later rerun compares today's answer with yesterday's, but yesterday used a different scope lane.

## What Ward should preserve
1. Before any derivative is promoted, Ward forces an explicit **view binding** for the result: the authorized view, scoped lens, or other named access lane the recipe ran against.
2. The answer carries a **population witness** saying what rows/fields/population it actually covered.
3. If the same recipe or contract reruns under a different view binding, credential lane, or access policy, Ward emits a **scope drift alarm** instead of pretending the population stayed constant.
4. If a query contract, metric card, or maintained derivative is later published, the promoted surface still carries basis pin, view binding, population witness, and exactness class.
5. Rerun diff and change-witness stories must not compare outputs from different authorized populations without surfacing the scope drift first.

## Nouns under pressure
- **view binding**
- **population witness**
- **scope drift alarm**

## What must stay separate
- query recipe versus authorized scope;
- fact change versus visibility change;
- row restriction versus field redaction;
- a pretty recurring metric title versus the population that made it true.

## Promotion rule
Do not promote these nouns beyond guidance unless a later specimen shows the same recurring question surviving at least one broader internal view, one narrower filtered view, and one credential-lane shift without silently flattening scope drift into fact drift.
