# Specimen flow 45 — grain witness, fanout fence, and weight carrier

Goal: keep Ward honest when one repeated trust question crosses grains, multiplies rows under joins, and then tries to publish a percentage or average as if it were an ordinary additive fact.

## Scenario
A team keeps asking a recurring question across several weeks of trust activity:

> “What share of reviewed recovery-grade sign-ins, by organization and week, reached local spend within the allowed posture?”

To answer it, they combine:
1. sign-in events at **event grain**;
2. organization membership that may be **one subject to many org rows over time**;
3. posture snapshots at **subject × effective-time grain**;
4. spend outcomes at **consequence grain**.

The first attempt looks reasonable in a BI tool, but it silently joins event rows to multi-row membership/posture tables and then averages subgroup percentages to make a broader dashboard tile.

## What Ward should preserve
1. Before any derivative is promoted, Ward forces an explicit **grain witness** for each measure-bearing input: what one row means, which key keeps it unique, and what inner grouping makes the measure semantically valid.
2. The recipe records that sign-ins are counted at `signin_event_id`, spends at `consequence_id`, and any subject/org/posture enrichment is weaker context attached to those facts rather than new fact identity.
3. The moment one join can multiply sign-in rows, Ward requires a visible **fanout fence** that says whether the join is duplication-safe, deduped by a declared key, replay-only at the original grain, or forbidden for promoted use.
4. The ratio itself is not allowed to survive as one naked percentage if later regrouping matters. Ward keeps a **weight carrier** such as explicit numerator/denominator totals or equivalent weighting residue so a broader rollup does not devolve into an accidental average of averages.
5. If the team later wants a maintained derivative, the promoted surface still carries basis pin, join clock when relevant, grain witness, fanout posture, weight carrier posture, aggregation law, and exactness class.

## Nouns under pressure
- **grain witness**
- **fanout fence**
- **weight carrier**

## What must stay separate
- one measure-bearing fact row versus many joined result rows;
- duplication-safe joins versus convenience joins;
- one rendered subgroup rate versus the numerator/denominator or weight story needed for honest regrouping;
- query contract versus final local consequence.

## Promotion rule
Do not promote these nouns beyond guidance unless a later specimen shows the same recurring question surviving one fanout-prone join, one inner-grain-sensitive calculation, and one broader regrouping without hiding what one row meant or how the rate stayed honest.
