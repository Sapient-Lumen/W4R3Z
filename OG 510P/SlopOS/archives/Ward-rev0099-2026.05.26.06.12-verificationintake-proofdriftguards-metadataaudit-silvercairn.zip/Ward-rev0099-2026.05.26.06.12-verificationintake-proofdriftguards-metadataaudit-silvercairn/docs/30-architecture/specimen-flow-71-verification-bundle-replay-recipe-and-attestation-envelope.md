# Specimen flow 71 — verification bundle, replay recipe, and attestation envelope

## Specimen question

A risk-governance reviewer receives a signed exported chart from last week showing that a SlopOS datacube provider-risk answer crossed a quarantine threshold. The chart was later forwarded into an ACP proposal and summarized by a model. The reviewer asks:

> Prove this quarantine recommendation was justified, replay the answer if possible, and tell me whether the old signed export is still authoritative.

This specimen intentionally collides historical proof, current authority, replay, privacy, egress, model summaries, action warrants, and revocation.

## Existing material

- An answer capsule for provider-risk ranking.
- Metric cards, concept anchors, crosswalk warrants, hierarchy cuts, scope lens, state-cut witness, quality witness, freshness envelope, uncertainty envelope, comparability passport, delta anatomy, and attribution rail.
- Render contract and egress receipt for the exported chart.
- Intent binding, translation warrant, and tool-call leash for the model-mediated follow-up.
- Threshold witness, action warrant, consequence receipt, learning-loop ledger, and feedback-taint fence for the quarantine recommendation path.
- Correction horizon, backfill ledger, and revocation fence from later provider-identity and appeal-result updates.

## Failure modes this specimen must catch

1. **Signature-as-truth collapse** — the signed export is treated as proof that the answer is currently valid.
2. **Replay-as-authority collapse** — a successful historical replay is treated as permission to keep the quarantine active.
3. **Package-as-capability collapse** — the verification packet contains enough locators or raw fragments to bypass current projection, consent, partner, or privacy rules.
4. **Hidden dependency drift** — replay uses a newer metric card, hierarchy cut, model version, query engine, calendar, suppression threshold, or policy epoch while claiming to reproduce the old answer.
5. **Nondeterminism drift** — seed, sketch, approximate aggregation, DP noise, model-mediated SQL, or partner clean-room fragment changed but the replay class hides the distinction.
6. **Retired input drift** — source snapshots, validation sidecars, prompts, or partner fragments expired, so a value-identical replay is impossible.
7. **Attestation overclaim** — a logged/signed envelope proves only issuer/subject/predicate/inclusion, but downstream tools interpret it as freshness, semantic correctness, or action authority.

## Candidate residue 1: verification bundle

A **verification bundle** is a compact, possibly redacted packet of answer-adjacent evidence for review, challenge, audit, dispute, rehydration, or replay.

Minimum fields for this specimen:

- bundle id, creation time, producer, intended verifier class, retention/expiry posture;
- subject answer capsule digest and any exported artifact digests;
- included evidence list: state-cut witness, metric/query contracts, semantic cards, scope lens, privacy/projection fences, quality/freshness/uncertainty/refusal material, render/egress receipts, model-mediation residues, action/consequence residues, correction/revocation residues;
- evidence mode for each component: embedded, digest-only, locator, redacted, withheld, expired, partner-held, or unavailable;
- projection and privacy posture for the bundle itself;
- known gaps and verifier warnings;
- non-authority clause: bundle possession does not grant capability, live data access, action permission, or currentness.

A verification bundle answers: “what can a reviewer inspect?” It does not answer: “is the answer still true?”

## Candidate residue 2: replay recipe

A **replay recipe** is a compact recipe for rerunning, recomputing, or checking the answer under a named replay class.

Minimum fields for this specimen:

- source verification bundle and subject answer digest;
- replay class requested and possible: byte-identical, value-identical, tolerance-identical, verdict-identical, explanation-identical, redacted-check-only, or not-replayable;
- required source cuts, snapshots, materialization generations, retained states, privacy budget state, semantic/policy/metric versions, hierarchy/crosswalk cuts, and partner fragments;
- query/plan digest, generated-SQL/semantic-layer warrant reference, tool-call leash references, and engine/dialect/environment posture;
- dependency locks and build/run environment references where relevant;
- nondeterminism posture: seeds, sketches, approximate estimators, DP noise, model/version/sampling, time/entropy handles;
- invariants and tolerances: expected row/cell counts, suppressed-cell posture, confidence/tolerance bands, subtotal checks, policy/refusal expectations;
- cost/budget/authority preconditions and safe dry-run posture;
- invalidation, correction, and revocation behavior;
- result class and explanation if replay is refused or degraded.

A replay recipe says what it would mean to re-check the answer. It is allowed to say “only verdict replay is possible” or “not replayable after retention/correction.”

## Candidate residue 3: attestation envelope

An **attestation envelope** is a signed, logged, endorsed, witnessed, or otherwise externally checkable wrapper around a bundle, recipe, answer capsule, run, export, or verification result.

Minimum fields for this specimen:

- issuer, subject digest(s), predicate/profile, issuance time, expiry, key/proof/log posture;
- covered material: answer capsule, verification bundle, replay recipe, run result, export, consequence receipt, or reviewer verdict;
- claim strength: generated-by, reviewed-by, policy-checked, replayed-as, archived-as, export-produced, or dispute-resolved;
- proof mechanism: signature, transparency-log inclusion, witness set, local endorsement, or digest-only;
- verification policy hints and required local appraisal;
- redaction/privacy disclosure posture;
- revocation/supersession links and stale-if conditions;
- non-authority clause: envelope validity does not prove freshness, semantic correctness, policy permission, privacy permission, or action authority.

The attestation envelope makes claims about evidence; it does not replace the answer capsule.

## Happy path

1. Reviewer asks to verify the signed exported chart.
2. System verifies the attestation envelope enough to know issuer, subject digest, predicate/profile, and log/proof posture.
3. System opens the verification bundle and shows answer capsule, source cuts, metric/query/semantic contracts, quality/freshness/uncertainty/refusal material, render/egress receipts, action/consequence material, and known gaps.
4. System evaluates the replay recipe and determines the strongest possible replay class.
5. If value replay is possible, system runs a dry-run or replay under original cuts and compares invariant/tolerance results.
6. If only verdict replay is possible, system reports that historical quarantine eligibility can be checked against retained verdict material, but exact values cannot be reproduced.
7. System checks current correction/revocation/freshness material before answering whether the old export remains authoritative.
8. System separates outcomes:
   - historical answer was justified under cut X;
   - replay class was Y;
   - old export is / is not current authority;
   - downstream consequence must stand, be reviewed, be withdrawn, or remain disputed.

## Refusal and degradation cases

- **No bundle**: return an evidence-absence refusal, not a guess.
- **Bundle exists but lacks current authority**: allow historical audit, refuse current authority claim.
- **Replay inputs expired**: return non-replayable or redacted-check-only with the missing inputs named.
- **Privacy budget cannot be re-spent**: offer digest/invariant/verdict replay if allowed; refuse exact-row replay.
- **Attestation verifies but subject digest mismatches export**: reject the envelope for that artifact.
- **Transparency-log inclusion verifies but source cuts are stale**: keep anti-tamper and currentness separate.
- **Model summary was signed but answer capsule was not**: treat summary as derivative; require underlying answer/bundle evidence.

## Promotion test

Promote these nouns only if they continue to prevent at least four false inferences:

- signed means true;
- logged means current;
- replayed means authorized;
- packaged means complete;
- digest-addressed means trustworthy;
- historical answer means active consequence;
- verifier has bundle means verifier has data rights;
- model-summarized proof means the proof was checked.

If future SlopOS design introduces a native attestation or replay substrate, these residues should narrow into that substrate or retire. They should not become a second parallel proof universe.
