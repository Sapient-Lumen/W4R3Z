# Specimen flow 54 — identity witness, dedupe posture, and correction lineage

Goal: keep Ward honest when one repeated trust question can be answered from raw append facts, retry-collapsed rows, current winners after corrections, or delete-aware history.

## Scenario
A team wants one recurring trust question around "attestation decisions":
- the ingest lane records every observed decision event from several worker paths;
- retries can replay the same logical event more than once;
- later review can replace an earlier decision with a corrected one;
- an explicit withdrawal can later delete or tombstone a previously accepted row;
- one dashboard wants the **raw event history**, while another wants the **current decision per subject**.

All of these answers are useful, but Ward refuses to let them share one fake timeless meaning.

## Walkthrough
1. Ward keeps the saved query recipe pinned to one basis and one authorized population, but any result that collapses rows must also carry an **identity witness** saying what made several rows count as the same logical subject or retry family.
2. The raw append surface preserves every observed event, including transport retries and later corrective events.
3. A retry arrives with the same declared retry/identity rule. Ward may collapse it for one derived current surface, but the answer must carry a **dedupe posture** saying whether the collapse was exact-keyed, best-effort, background-compacted, on-read winner selection, or still unresolved.
4. A later correction arrives that changes the earlier decision. Ward may publish a current-winner surface, but that surface must carry a **correction lineage** saying whether the shown row descends from one original create, a replacement/update chain, a delete/tombstone chain, or another declared correction path.
5. A later explicit withdrawal arrives. Ward keeps raw history, current deduped head, and delete-aware history visibly distinct instead of letting “missing now” impersonate “never happened.”
6. If one engine only clears duplicates in the background, Ward keeps that surface weaker than raw append truth until the current read proves which winner logic actually ran.
7. If two teams compare “attestation decisions” while one chart shows raw append rows and the other shows current winners, Ward raises meaning drift instead of pretending the title alone preserved comparability.

## Nouns pressure-tested here
1. **identity witness**  
   - visible statement of the key/fingerprint/offset rule by which rows were treated as the same logical subject or retry family;  
   - smaller than full query contract, smaller than basis pin, and smaller than final local consequence.

2. **dedupe posture**  
   - visible statement of whether duplicates were preserved, filtered by an exact key, collapsed best-effort, collapsed by background compaction, collapsed on read, or intentionally unresolved;  
   - smaller than the raw append history and smaller than any final current-state decision that consumes it.

3. **correction lineage**  
   - visible statement of whether a current row derives from one original event, a replacement chain, a delete/tombstone chain, or another declared correction path;  
   - smaller than full event history and smaller than any action or consequence taken from the current winner.

## What this specimen must keep separate
- raw append event versus retry-collapsed row;
- exact-key dedupe versus best-effort dedupe;
- current winner versus full correction-bearing history;
- explicit delete/tombstone state versus silent present absence.

## Promotion gate for these nouns
Do not promote these nouns beyond guidance unless a later specimen shows:
- one raw append surface,
- one retry duplicate,
- one corrective replacement,
- one explicit delete/tombstone event,
- and one current-winner surface
surviving the comparison without collapsing into one flattering recurring title.

## Why this matters
Repeated trust questions often start life as "just show me the latest decision" or "just count the decisions." Systems age badly when they forget that retries, corrections, deletes, and current-winner projections are different truths. Ward should therefore keep identity rules and correction posture visible before any repeated answer gets promoted into trusted browse or decision support.
