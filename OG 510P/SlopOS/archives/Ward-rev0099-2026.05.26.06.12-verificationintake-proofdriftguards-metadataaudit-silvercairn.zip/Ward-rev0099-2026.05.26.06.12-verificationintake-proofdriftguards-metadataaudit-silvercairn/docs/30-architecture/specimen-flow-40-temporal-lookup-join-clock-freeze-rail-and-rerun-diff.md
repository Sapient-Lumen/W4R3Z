# Specimen flow 40 — temporal lookup lane, join clock, freeze rail, and rerun diff

Goal: keep Ward honest when one trust exploration needs time-varying context and later review without silently regrowing ambient latest or silent liveness.

## Scenario
A reviewer investigates approvals that happened around a key-roll and later policy change.
The sequence unfolds in nine steps:
1. the reviewer saves an explicit **basis pin** `B9` for the trust facts under review instead of asking against ambient latest;
2. they define one **temporal lookup lane** `TL1` that decorates each approval with the most recent relevant policy/status row **as of** one chosen clock;
3. they record the chosen **join clock** `J_effective` because event time, publication/signing time, and local adoption time do not all mean the same thing here;
4. the first run yields one explicit **result snapshot** `S1`, and the reviewer uses a **freeze rail** so the answer stays still while they inspect, annotate, and share it;
5. meanwhile, fresher rows arrive elsewhere, but the frozen result does not silently mutate into a new answer or a hidden live feed;
6. a second reviewer intentionally re-runs the exact same recipe against a newer basis `B10` with the same join clock, producing `S2`; a **rerun-diff rail** highlights which rows changed because the basis moved;
7. the team then re-runs the recipe once more with a different join clock `J_adopt`, producing `S3`; another explicit diff shows that the answer changed because the temporal semantics changed, not because the source facts were identical all along;
8. after repeated use, the team records a **workload witness** that this recipe is genuinely recurring and now worth acceleration or promotion;
9. only then does the team consider a maintained derivative, and even that promoted surface still carries lineage, freshness posture, basis/join-clock headers, and the standing warning that it remains weaker than evidence, appraisal, and spendable consequence.

At first glance, a product might flatten this into “the saved query always shows the latest annotated answer.”
That would be a mistake.
A basis pin is different from a join clock.
A frozen review result is different from a live feed.
A rerun diff is different from silent mutation.
And repeated use should produce workload evidence before the cube earns any hidden acceleration.

Ward should therefore record at least five distinct residues here:
1. a **temporal lookup lane** for the rule that attaches time-varying context;
2. a **join clock** for the exact time axis the lookup uses;
3. a **freeze rail** for one held-still result snapshot;
4. a **rerun-diff rail** for comparing later or differently-clocked runs;
5. a **workload witness** before promotion or precomputation.

## Why this matters
- Trust exploration often needs “what was the relevant posture at that moment?” rather than “what is the latest posture now?”
- Two honest analysts can reach different answers if one used event/effective time and the other used local adoption time; the cube should make that visible instead of pretending one was careless.
- Review-grade frozen results are valuable even when live monitoring also exists.
- Diffing a rerun is often the clearest way to explain whether drift came from new source facts, a moved basis, or a changed clock.
- Hidden acceleration is safest only after a visible workload witness says the shape really pays rent.

## Ward pressure
This specimen pressures Ward to keep temporal lookup lane, join clock, freeze rail, rerun-diff rail, and workload witness distinct while still leaving open whether implementation rides on one warehouse, one streaming planner, one time-travel table format, or a thinner federated query posture.
