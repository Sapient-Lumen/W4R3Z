# Specimen flow 61 — freshness envelope, invalidation receipt, and recompute docket

## Goal

Pressure-test the next careful datacube step for Ward: once a SlopOS-shaped trust answer has a materialized or cached form, Ward must decide whether reuse is legitimate without turning speed, schedule, or retained state into truth.

## Scenario

A Helm surface asks for the current partner-trust deterioration summary. A matching answer capsule exists from four hours ago. It was expensive to compute, and a maintained aggregate can render the same chart immediately.

Several things are true at the same time:

- the original answer was scoped to a CH-ATTRQ-style view and snapshot cut;
- the materialization was built under policy epoch `P42`, semantic model `M7`, quality suite `Q19`, and materialization generation `G14`;
- the source freshness target was one hour, but the slowest input is now three hours behind;
- one upstream source received late corrections that affect two previous buckets;
- a schema-compatible metric-card patch changed dedupe behavior for current-winner failures;
- an operator compacted old materialized segments and coarsened one retained tier;
- a privacy policy update suppresses one small cell that the old answer displayed;
- the incremental refresh path skipped one unsupported mutation and fell back to a full query for one dependency, but the dashboard cache still has the old rendered answer;
- the requester is authorized to see the old answer, but not to learn whether suppressed rows exist outside the current view.

Ward should not choose a cache, scheduler, materialized-view engine, or dependency graph. It should decide that reuse has its own residue.

## Flow

1. **The cache hit is treated as a proposal, not an answer.** Ward first identifies the candidate answer capsule, its scope lens, state cut witness, axis capsule, metric card, quality witness, privacy posture, resolution/tier/hybrid seam, and prior comparability/explanation residues.

2. **Ward builds a freshness envelope.** The envelope records authorized scope, source cuts, semantic/policy/materialization generations, target freshness, observed lag, stale-by class, allowed reuse class, and consequence threshold. It says whether the answer is `reusable`, `stale_but_reviewable`, `revalidate_before_use`, `invalidated`, or `refuse`.

3. **The source freshness miss narrows reuse.** The three-hour-late source breaches the one-hour target. The old answer may remain reviewable for audit, but it cannot become a current consequence-grade answer unless a policy explicitly allows over-lag reuse.

4. **Ward emits invalidation receipts.** Separate receipts record late corrections, metric-card patch, privacy suppression change, tier coarsening, and incremental-refresh fallback. Each receipt names affected cuts/cells/axes, invalidation class, detection time, action, and uncertainty. None of these receipts by itself chooses the recomputation engine.

5. **The metric patch triggers comparability pressure.** Even if a recompute succeeds, old and new answers may need a comparability passport or drift notice before a trend can be rendered. Reuse cannot silently bridge metric-card drift.

6. **The privacy change triggers refusal posture.** The old displayed cell cannot simply be served from cache if the current policy would suppress it. Ward records a refusal receipt for the current view and forbids cache reuse from becoming a privacy bypass.

7. **The compaction/tier change is not assumed harmless.** If coarsened retained tiers preserve the displayed result, the freshness envelope can say result-preserving under this query. If replay fidelity or drill-through changed, Ward marks comparison/explanation surfaces as affected.

8. **Ward opens a recompute docket.** The docket lists impacted answer capsules, required mode (`full_recompute` for one dependency, `recompare` for the trend, `reexplain` for any why-answer), priority, replay floor, blockers, budget, and completion/refusal posture.

9. **Helm receives a stricter display posture.** It may show “previous answer, stale and recompute pending” to an authorized requester, but it may not show the old answer as current, compare it as if bridged, explain it as if repaired, or reveal suppressed-cell existence.

10. **Repair produces a new answer capsule.** When recomputation completes, Ward creates a new answer capsule with new freshness envelope and state cut witness. The invalidated answer remains audit material only if retention and policy allow it.

## Nouns pressure-tested

- **freshness envelope** — compact reuse boundary for one answer capsule or materialization, naming target freshness, observed lag/cut age, source/semantic/policy/materialization cuts, allowed reuse class, and stale/refusal posture.
- **invalidation receipt** — compact evidence that a change affected an answer's reuse, comparison, explanation, or consequence posture, without becoming a global dependency graph.
- **recompute docket** — compact process residue for owed recalculation, repair, revalidation, re-comparison, re-explanation, or refusal.

## Why this preserves optionality

This specimen does not choose a materialized-view engine, cache key, scheduler, dependency graph, OLAP index, incremental-computation engine, table format, or UI badge system. It can work with SlopOS snapshots, D-ATTRFS/CH-ATTRQ query handles, Harbor restatement receipts, ViewFS materialized handles, Foundry basis generations, Steward reconciliation process state, Schell environment epochs, and Helm review surfaces.

The promoted thing remains smaller than a cube engine: answer reuse whose authority is limited by freshness envelopes, invalidation receipts, recompute dockets, and existing scope/state/refusal/comparability/explanation residue.

## Open pressure

- Should freshness envelopes be mandatory for every answer capsule or only for reused/materialized answers?
- Should invalidation receipts be append-only evidence, transient maintenance state, or both?
- Can recompute dockets be safely exposed without leaking denied population or suppressed cell existence?
- Which invalidation classes require full recompute versus incremental repair versus refusal?
- Should retention floors be recorded in state cut witnesses, freshness envelopes, recompute dockets, or a separate replay-floor noun?
- Can a stale answer participate in comparisons or explanations if every consumer sees the stale/recompute posture?
