# Specimen flow 88 — signal notification, stale-consumer acknowledgments, and dead-letter fences

## Scenario

A public owner-routing release was recertified as current but refresh-required. A revocation signal is then accepted by Ward's signal-ingestion lane. Three downstream consumers hold cached projections: Helm chips, Harbor stale-surface messaging, and ViewFS public owner-route display.

## Flow

1. Ward validates the source signal-ingestion receipt bytes and event key.
2. Ward computes the affected consumer set digest for the cache subject.
3. The notification payload is minimized and labeled "not authority."
4. Helm and Harbor acknowledge delivery.
5. ViewFS fails all retry attempts and is moved to a dead-letter quarantine.
6. Ward records that the cache subject cannot be reused until the missing consumer is recertified or the quarantine is resolved.

## Required refusal

Ward must refuse to treat any of the following as current authority:

- transport acknowledgement;
- consumer acknowledgment;
- a dead-letter pointer;
- a notification count;
- a duplicate notification;
- a conflict-hold notice;
- a partial fanout summary.

## Fixture pressure

Pass XCI adds positive fixtures for all-notified refresh, partial quarantine, duplicate suppression, dead-letter quarantine, and conflict-hold notification. Negative fixtures cover source digest drift, event-key mismatch, consumer-set drift, payload drift, sealed-payload leakage, ack-as-authority, ack-as-refresh, delivery-ack-as-refresh, partial-all-ack laundering, dead-letter-as-delivery, missing quarantine, duplicate promotion, conflict-winner selection, public consumer identity leakage, missing no-authority labels, high-consequence notification effects, dropped fences, status-pointer mutation, and notification-as-recertification.
