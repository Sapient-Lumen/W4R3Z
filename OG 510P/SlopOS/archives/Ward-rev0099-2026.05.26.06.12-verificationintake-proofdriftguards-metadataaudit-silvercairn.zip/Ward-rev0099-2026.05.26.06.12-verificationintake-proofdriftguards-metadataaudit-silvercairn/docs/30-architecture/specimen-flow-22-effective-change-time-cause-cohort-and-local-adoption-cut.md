# Specimen flow 22 — effective change time, cause cohort, and local adoption cut

Goal: keep underlying event time, publication time, grouped-cause residue, and receiver-local consequence visibly separate.

## Scenario
A roaming authenticator and an X.509 client certificate are both implicated in the same compromise story.
The identity provider emits two CAEP/RISC-style events with the same shared-cause handle:
- one later-state artifact says sessions should be revoked,
- another says a credential changed or was compromised.

Separately, a certificate-status responder and a replicated status corpus publish negative material for the affected certificate.
One artifact says the compromise was believed to have taken effect before the signed response was produced.
The response also carries a bounded interval for how long the responder claims the state answer is current enough.

A low-risk receiver sees the event stream quickly and moves to observe-only.
A higher-risk receiver does not change spend consequence until a later local refresh imports the matching status corpus cut.
Both receivers need to remember the same underlying cause without pretending that they adopted the change at the same time or that publication time equals effective compromise time.

## Proposed Ward objects
1. **effective change time**
   - the time the underlying trust-relevant fact is believed to have become true or dangerous;
   - may predate publication, signing, or local receipt.

2. **cause cohort**
   - compact linkage showing that several later-state artifacts stem from one underlying cause;
   - smaller than any final verdict and smaller than one giant merged incident object.

3. **local adoption cut**
   - the receiver-local point when a later-state artifact or coherent package started influencing consequence here;
   - may differ across local gates and across receivers.

4. **reason handle**
   - typed cause/explanation residue smaller than local policy;
   - useful for explanation, review, and analytics without pretending to determine action.

## Why this specimen matters
It pressure-tests whether Ward can stay honest when:
- the underlying harmful event may have begun before anyone published it;
- one signed artifact claims when the answer was known correct while another gives a different publication/signing time;
- several artifacts share one cause without needing to be flattened into one super-object;
- and two local gates adopt the same later-state package at different moments.

## Promotion rule
Do not promote `effective change time`, `cause cohort`, `local adoption cut`, or `reason handle` unless they improve:
- one specimen where effective invalidity or compromise predates publication,
- one specimen where several later-state artifacts share one underlying cause,
- one specimen where two gates adopt the same later-state package at different local times,
- and one specimen where reason/explanation remains visibly smaller than the action ladder.
