# Evidence release, recipient scope, and export guards

Pass LXXXIV adds the missing release seam after search continuity.

Ward can now prove that search results and page continuations are not authority. But a new failure appears the moment a user clicks:

> “Export.”

The exported artifact can outlive the UI, lose row-level state, drop sealed omissions, erase downgrade reasons, and get forwarded to a recipient who was never allowed to see the underlying governance evidence. That makes release a separate residue.

## Position in the spine

```text
governance handoff packet
  -> governance decision event
    -> governance decision consumer receipt
      -> governance batch/search receipt
        -> governance search-continuity receipt
          -> governance evidence-release receipt
```

The evidence-release receipt is downstream. It never grants authority upstream.

## Why not reuse an export log?

A generic export log says something left a system. Ward needs more:

- which source receipt was used;
- whether source digest and query/projection basis still match;
- which rows and fields were selected;
- which recipient class received it;
- which purpose bounds the release;
- what sealed omissions were disclosed or withheld;
- which fields were denied;
- what retention, refresh, and onward-use controls travel with it;
- whether the artifact visibly says it is not authority.

This is not provenance alone and not access control alone. It is **evidence-release hygiene**.

## Release modes

### Public redacted export

Allowed only when the payload is minimized, sensitive fields are denied, sealed evidence is not inlined, and omission disclosure is safe.

### Restricted review bundle

Allowed for internal review, privacy board, partner-restricted, or regulator/auditor lanes. It may carry more detail than public release, but still cannot grant action authority, privacy waiver, repair, remedy, or budget spend.

### Held recheck notice

Used when compaction, cursor drift, policy drift, or replay uncertainty makes release unsafe. The receipt may notify a recipient that release is held, but it must not ship current-authority language.

## Export guard rule

A release receipt may perform `export_minimized_projection` or `deliver_restricted_review_bundle` only when the receipt itself carries:

- source digest parity;
- selection digest;
- recipient and purpose binding;
- projection-policy digest;
- field allowlist and denylist;
- omission disclosure posture;
- no-authority watermark;
- refresh/revocation channel;
- forbidden-effect preservation.

If any one is missing, Ward should hold or refuse release.

## Public omission rule

For public/external release, hidden governance evidence is never disclosed as exact subject-level fact. Ward allows only:

- no sealed rows;
- presence-only;
- bucketed range;
- noisy count with budget proof.

This keeps release from becoming an existence oracle while still avoiding the lie that visible rows are complete.

## Product consequence

Helm should render released Ward artifacts as:

> “Evidence release. Not authority. Refresh before action.”

ViewFS should treat the artifact path as a trusted/minimized path, not as proof that downstream users may reuse it. Schell should track retention and forgetting posture for the receipt. Harbor and Foundry should reject released governance bundles as action/recompute evidence unless current packet replay succeeds separately.
