# Specimen flow 81 — evidence release, recipient scope, and export guards

## Situation

A SlopOS user has a Ward governance search page for provider-risk material. The page includes:

- a public route-only owner hint;
- a public result with sealed omissions represented by a bucket;
- a restricted break-glass/history review bundle;
- a held recheck notice after packet-compaction drift.

The user asks to export the visible governance evidence and send a restricted review bundle to an internal review board.

## Bad collapse

The bad implementation says:

> “Exported approved governance decisions.”

That sentence performs several hidden upgrades:

- public rows become complete rows;
- route-only hints become approvals;
- mixed current/historical receipts become one current state;
- sealed omissions become either leaked facts or false absence;
- the detached artifact loses retention, refresh, recipient, and purpose bounds;
- the export becomes reusable action evidence.

## Ward residues

The flow introduces `ward.governance.evidence-release-receipt.v0`.

It references exactly one source receipt by id/path/digest:

- a batch/search receipt; or
- a search-continuity receipt.

It records:

- release kind;
- recipient class;
- purpose;
- source query and projection-policy digests;
- selection digest;
- redaction/minimization posture;
- field allowlist and denylist;
- sealed-omission disclosure mode;
- retention horizon;
- refresh/revocation channel;
- no-authority watermark;
- forbidden-effect preservation.

## Safe positive paths

Public redacted release may say:

- `released_minimized`;
- route-only rows remain route-only;
- sealed rows are represented only by safe omission disclosure;
- sensitive fields are denied;
- no-authority watermark travels with the artifact.

Restricted review release may say:

- `released_restricted_review`;
- recipient and purpose are bounded;
- sealed material is pointer/minimized unless explicitly allowed by the review lane;
- current and historical receipt states remain visible.

Held release may say:

- `held_recheck_required`;
- source compaction or replay drift blocks release;
- partner or reviewer sees a notice, not an authority-bearing bundle.

## Rejected paths

Ward rejects:

- missing or mismatched source digest;
- query/projection-policy mismatch;
- public sealed evidence inline;
- exact public hidden-row counts;
- weak-state promotion to current authority;
- dropped forbidden effects;
- raw partner fragments in public release;
- missing no-authority label;
- expired release reused as current;
- high-consequence actions during release.

## Product line

The artifact should carry:

> “Ward evidence release. Not authority. Refresh before action.”

That label is not decoration. It is the guardrail that keeps an export from becoming a portable permission slip.
