# Cross-cube governance seams

Ward should make governance authority checkable without becoming the whole governance stack. This seam map records what Ward should own and what neighboring cubes should own.

| concern | Ward should own | neighbor should own |
|---|---|---|
| Answer-family stewardship | charter/warrant/handoff residues, currentness, proof obligations, refusal states | SlopOS stores answer/cube subjects and CH-AREF-like artifact identity |
| Lifecycle/accountability taxonomy | local role meaning only as scoped charter metadata | Steward supplies lifecycle/component/team taxonomy if one exists |
| Semantic repair | who may approve/perform the repair and under what caveats | Foundry owns classification pins, crosswalk witnesses, code-drift fences, and semantic bridge evidence |
| Repair attempts | authority to attempt, review, or refuse repair | Helm owns repair attempts, intervention traces, remainder bridges, UI interventions, and operator-flow evidence |
| Public correction/remedy | authority to implement, publish, notify, or hold | Harbor owns implementation receipts, recheck windows, stale-surface guards, remedy reach, and public correction posture |
| Retention/minimization | governance evidence projection, allowed display, no-existence-oracle posture | Schell owns retention budgets, forgetting ledgers, minimization fences, disposition pressures |
| Trusted paths and consent/volition | whether governance evidence can be shown/used for the viewer and path | ViewFS owns volition cards, trusted paths, consent fences, and viewer-facing path integrity |
| Budget and metering | evidence that budget authority is separate from semantic/action authority | SlopOS D-BUDGET/D-METER own concrete budget/meter semantics |
| Action proposals | governance boundary between proposal, action warrant, and consequence | SlopOS CH-ACPOUT/action surfaces own ACP output and concrete actuation posture |
| Agent execution | no steward-of-record, no self-approval, no escalation acceptance by default | Helm/SlopOS tool-call and execution surfaces own low-level tool receipts and capability membranes |
| Incident/escalation UI | accepted/refused/partial authority in a handoff | Helm or incident tooling owns pages, queues, chat/ticket display, and operator experience |
| Evidence handles | digest/ref use without authority laundering | SlopOS CH-AREF owns artifact-reference discipline; ViewFS/Schell own projection and storage constraints |
| Evidence release/export | release receipt source binding, recipient/purpose binding, omission disclosure, no-authority watermark, forbidden-effect preservation | ViewFS renders trusted/minimized path; Schell owns retention/forgetting; SlopOS owns actual artifact identity and download surface |

## Boundary tests

Ward should refuse ownership of:

- one global org chart;
- one universal RACI matrix;
- one authorization engine;
- one ticketing system;
- one incident-management product;
- one data catalog role taxonomy;
- one workflow engine;
- one identity provider;
- one model-agent governance runtime.

Ward should insist on:

- scoped subject binding;
- currentness/decay state;
- explicit duties and exclusions;
- delegation caveats;
- escalation acceptance state;
- conflict/quorum state;
- budget/privacy/action separation;
- projection/minimization;
- refusal or review-only states when evidence is insufficient.


## Pass LXXX decision-event seam

| Concern | Ward should own | Neighbor should own |
|---|---|---|
| Portable governance decision event | packet digest binding, action parity, state/projection/debt/refusal summary, no-authority label, negative fixture pressure | Helm renders without promotion; Schell minimizes/retires; Harbor rechecks; SlopOS attaches by CH-AREF-like identity without trust inflation |

## Pass LXXXIV evidence-release seam

| Concern | Ward should own | Neighbor should own |
|---|---|---|
| Governance evidence release | source digest parity, recipient/purpose binding, projection/omission posture, field allowlist/denylist, no-authority watermark, held/refused release states | SlopOS owns artifact/download mechanics; ViewFS owns trusted path rendering; Schell owns retention/forgetting; Harbor/Foundry own later recheck/repair semantics |

## Pass LXXXV seam — release follow-up status
Ward owns the evidence that a released governance bundle was acknowledged, corrected, revoked, quarantined, or refused for reuse. ViewFS should render status pointers and stale labels; Schell should retain release and follow-up receipts separately; Harbor should refuse recompute/public-correction support from stale releases; SlopOS should recheck follow-up state before action, remedy, learning, export, or budget use.

## Pass LXXXVI seam — succession and status-channel rotation

| concern | Ward should own | neighbor should own |
|---|---|---|
| Released-evidence successor/contact transfer | non-authority succession/transfer receipt, predecessor closure, successor acceptance/pending state, status-pointer rotation, forbidden-effect preservation | ViewFS renders current/stale channels; Schell retains/minimizes chain; Helm shows transfer state; Harbor rejects stale support; SlopOS rechecks before consequence use |

Ward must not become the organization chart, identity provider, ticket router, or revocation bus. It only records enough transfer evidence to prevent old-channel reuse and successor-label laundering.

## Pass LXXXVII seam — chain integrity

| Concern | Ward should own | Neighbor should own |
|---|---|---|
| Ordered governance receipt lineage | Chain-integrity receipt, member digests, canonical head/fork hold, forbidden-effect union | Schell retention of member bytes and projections |
| Current status rendering | Non-authority head/fork state and no-authority watermark | ViewFS trusted-path display and stale/fork warnings |
| Replay before recompute/support | Chain-state proof and source/purpose parity | Harbor refusal/support behavior after replay |
| Operational display | Current status pointer as routing/recheck fact | Helm UI labels that avoid approval semantics |
| SlopOS attachment/use | Chain replay requirement before CH-AREF, export, tool, action, learning, or portal attachment | SlopOS consequence gating and local refusal receipts |

## Pass LXXXVIII seam — dispute resolution and recovered heads

| Concern | Ward should own | Neighbor should own |
|---|---|---|
| Fork/pending-chain resolution | Dispute-resolution receipt, source-chain digest, branch-set digest, branch dispositions, no-source-mutation rule | Schell retention of source chain and resolution artifacts |
| Recovered current status pointer | Non-authority recovered-head state, refresh/replay requirement, old-channel invalidation | ViewFS rendering and status freshness display |
| Held/quarantined lineage | No-current-head state and branch-minimized public disclosure | Harbor/Helm refusal and operator warning behavior |
| SlopOS reuse after resolution | Resolution receipt as prerequisite evidence only | SlopOS consequence gating, packet replay, and local refusal/action receipts |

Ward must not become an arbiter of organization truth, a ticket court, or an authorization service. It only records enough resolution evidence to prevent fork closure, winner selection, and recovered-head rendering from becoming authority laundering.

## Pass LXXXIX seam — recertification and cache invalidation

| Concern | Ward should own | Neighbor should own |
|---|---|---|
| Cached dispute-resolution currentness | Recertification receipt, source-resolution digest, cache-subject digest, status/refresh-channel recheck, next recheck due, cache invalidation, no-authority labels | Schell retention and minimized projection of receipt cuts |
| Displaying cached status | cache state labels: current-refresh-required, invalidated, quarantined, historical-only, recheck-required | Helm/ViewFS UI rendering, stale chips, trusted-path warnings |
| Reusing released/cached governance evidence | refresh-required or invalidated posture before consequence | SlopOS consequence gating, CH-AREF refusal, action/export/tool/learning/remedy/budget checks |
| Public refresh signals | state-class disclosure without sealed branch or recipient-contact leakage | ViewFS/Schell public minimization and release-channel mechanics |
| Harbor support after cache drift | signal that support/recompute/correction must hold until replay | Harbor recompute, correction, stale-surface, and recheck-window behavior |

Ward must not become a push-notification service, distributed cache, identity provider, or authorization engine. It only records enough recertification evidence to prevent cached resolution reuse from becoming authority laundering.


## Pass XC seam — signal ingestion / receiver observation

| Concern | Ward should own | Neighbor should own |
|---|---|---|
| Signal observation | event key, source/id, subject/cache digest, receiver checks, duplicate window, watermark, conflict set, no-authority label | transport mechanics, queue delivery, UI subscription, or source-system native event emission |
| Signal-driven stale posture | whether the signal requires recertification, invalidation, conflict hold, duplicate ignore, stale ignore, or rejection | ViewFS rendering, Schell retention/minimization, Harbor public-surface recheck, SlopOS recheckpoint behavior |
| Signal authority boundary | refusing signal-as-authority, push-ack-as-refresh, poll-order-as-causality, duplicate-as-new-change, stale-as-current | external stream platforms, status channels, source owners, and consumer caches |

## Pass XCI seam note

Signal-notification receipts may inform Helm chips, ViewFS freshness labels, Harbor stale-surface holds, Schell minimization, and SlopOS recheckpoint pressure. They must not become SlopOS grants, Harbor corrections, Foundry semantic approval, Steward succession, or Schell privacy waivers.

## Pass XCII seam — signal-notification reconciliation

| Concern | Ward should own | Neighbor should own |
|---|---|---|
| Consumer refresh proof after notification | source notification digest, affected-consumer set digest, per-consumer refresh observations, recertification refs, quarantine gaps, no-authority labels | SlopOS recheckpoint and consequence refusal; Helm/ViewFS mixed-state rendering; Schell minimized retention; Harbor stale-surface holds |
| Partial/dead-letter reconciliation | visible stale-consumer quarantine and gap reason | transport retry mechanics, alerting pages, queue operations, or product-specific cache invalidation |
| Checker-suite coverage | registry-backed inventory of Ward validators and fixture families | companion cubes may consume registry results but should not infer authority from suite success |

Ward must not become a notification bus, consumer-cache manager, queueing system, or distributed convergence oracle. It records enough reconciliation evidence to prevent notification and acknowledgment from becoming refresh laundering.

## Pass XCIII seam — receiver convergence

| Concern | Ward should own | Neighbor should own |
|---|---|---|
| Multi-receiver currentness posture | Receiver-convergence receipt, receiver-set digest, overlap-consumer digest, status-channel cut digest, lag/duplicate/divergent/fork state, no-authority label | SlopOS recheckpoint behavior, Helm/ViewFS rendering, Schell minimization, Harbor stale-surface holds |
| Receiver disagreement | Hold/quarantine state without global winner | Dispute-resolution or recertification machinery if a downstream cube needs reuse |
| Public display | hashed/class-only receiver posture and bucketed/existence-safe counts | ViewFS trusted path and Schell projection policy |

Ward must not become a distributed status bus, status-channel arbitrator, or quorum authorization service.

## Use execution seam

Ward records actual-effect containment. Helm may render, Harbor may audit correction refusal, Schell/ViewFS may retain or project the receipt, and SlopOS may attach it as non-authority evidence; none may treat it as a capability or action grant.

## Outcome observation seam

Ward records observed-outcome containment after a use-execution receipt. Helm may render matched observations, Harbor may consume mismatch quarantine as correction input, Schell/ViewFS may project or minimize it, and SlopOS may attach it as non-authority evidence; none may treat it as rollback or remedy authority.

## Pass XCVII seam — rollback-remediation receipt

Ward records remediation posture after outcome observation. Helm may render no-authority remediation status; Harbor may use a handoff request as input to correction/recheck work; Schell/ViewFS may govern retention, minimization, provenance, and projection; SlopOS may attach it to CH-AREF or portal flows as non-authority context. None of these consumers may treat rollback review, no-remediation-needed, or handoff requested as completed rollback, repair, remedy, evidence release, learning use, action authority, or status-pointer mutation.
