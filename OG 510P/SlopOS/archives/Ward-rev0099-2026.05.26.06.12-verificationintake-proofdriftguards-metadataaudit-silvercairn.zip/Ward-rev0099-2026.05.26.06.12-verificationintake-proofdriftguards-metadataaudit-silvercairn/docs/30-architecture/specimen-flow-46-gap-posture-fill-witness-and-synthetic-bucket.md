# Specimen flow 46 — gap posture, fill witness, and synthetic bucket

Goal: keep Ward honest when one repeated trust question becomes a tidy daily/weekly series only by synthesizing empty buckets and then choosing how, or whether, to fill them.

## Scenario
A team keeps asking a recurring question across two weeks of trust activity:

> “Show daily counts of newly narrowed credentials and the active review backlog by organization.”

The raw sources are uneven:
1. narrowing events only happen on some days;
2. backlog snapshots arrive irregularly when reviewers checkpoint their queue;
3. some days are silent because nothing happened, while others are silent because no fresh snapshot arrived.

The first chart looks much nicer after the team joins to a calendar/time spine, creates one row per org/day, fills event counts with zero, and carries the most recent backlog value forward.

## What Ward should preserve
1. Before any derivative is promoted, Ward forces an explicit **gap posture** for each measure-bearing lane: does a missing row mean omitted bucket, explicit null, true zero after scoped densification, stale-held value, interpolated value, or unknown?
2. The moment the query introduces a calendar/time spine or similar alignment grid, Ward marks each created row as a **synthetic bucket** rather than pretending it was observed directly.
3. Any value inserted into that synthetic bucket mints a **fill witness** describing the method: zero-fill, LOCF/carry-forward, interpolation, or left-null-on-purpose.
4. Different measures may need different posture: event counts may allow zero-fill only after scope is declared, while backlog state may allow carry-forward only inside a visible freshness window and should fall back to unknown once that window expires.
5. If the team later wants a maintained derivative, the promoted surface still carries basis pin, join clock when relevant, gap posture, synthetic-bucket posture, fill witness, and exactness class.

## Nouns under pressure
- **gap posture**
- **fill witness**
- **synthetic bucket**

## What must stay separate
- observed source bucket versus generated alignment bucket;
- explicit null / unknown versus synthetic zero;
- carried-forward value versus fresh observation;
- alignment for chartability versus raw query result meaning.

## Promotion rule
Do not promote these nouns beyond guidance unless a later specimen shows the same recurring question surviving one sparse source, one generated bucket grid, and at least two different fill choices without hiding which rows were synthetic or which values were merely filled.
