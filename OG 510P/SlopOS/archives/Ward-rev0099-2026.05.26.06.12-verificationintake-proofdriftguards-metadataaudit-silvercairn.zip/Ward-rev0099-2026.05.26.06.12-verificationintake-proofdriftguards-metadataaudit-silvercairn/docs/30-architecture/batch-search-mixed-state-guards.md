# Batch/search mixed-state guards

Pass LXXXII adds the smallest guard Ward needs before governance decision receipts are useful in real products: mixed search and batch surfaces must preserve member weakness.

## Shape

The new object is `ward.governance.batch-search-receipt.v0`.

It references one or more `ward.governance.decision.consumer-receipt.v0` objects and records:

- request kind: `batch_evaluation` or `search_result`;
- member receipt refs and digests;
- member state/replay/projection mirrors;
- aggregate state counts;
- replay-status counts;
- projection join rules;
- search pagination and gap disclosure;
- aggregate effect closure;
- replay-boundary summary.

## Why not just reuse consumer receipts?

Consumer receipts prove one downstream interpretation. A search result proves a different thing: that **several interpretations were combined without collapsing their differences**.

That is a separate assurance problem. It is especially important for Helm search screens, SlopOS portals, Harbor recheck queues, Schell minimized views, and ViewFS/Foundry governance browsers.

## Least-privilege projection join

A projection join cannot be “show everything the strongest member can show.” It must be:

1. preserve every member projection class;
2. show the weakest actionable class;
3. redact sealed/restricted material when moving to broader views;
4. keep public rows from carrying private org maps, reviewer identities, incident details, and partner fragments;
5. disclose omitted rows and projection filters.

## Mixed-state rendering rule

A batch/search result may say:

> 1 route-only, 1 current consequence-grade, 1 historical-only.

It may not say:

> 3 allowed.

The first is a navigational summary. The second is authority laundering.

## Search count rule

Counts are scoped to the projection and replay basis.

Allowed:

- `visible_members_only`;
- `exact_after_projection_filter`;
- `not_applicable_batch`.

Forbidden:

- raw authority counts;
- complete “authorized set” counts when omissions exist;
- counts that hide replay failures or compaction downgrade.

## Cursor rule

A cursor is not authority either. If a search result provides a cursor, it must bind to the query digest and projection filter digest. A subsequent page with different query scope, projection class, subject, action, or resource basis is a new receipt, not a continuation.

## Relationship to AuthZEN and OpenFGA

AuthZEN's multiple-evaluation and search surfaces are useful pressure because they separate single evaluation, boxed multi-evaluation, and search results. Ward borrows the distinction but does not become a PDP/PEP protocol. OpenFGA's relationship queries are useful because they distinguish check/read/expand/list shapes and their limits. Ward borrows the caution: a list result is not a universal grant.

## Relationship to event systems

OPA decision logs, CloudEvents, OpenTelemetry-shaped trace context, and Kafka-style compaction all pressure Ward toward portable correlation fields. None of them make a batch/search result authoritative. Ward requires per-member digest checks, projection joins, and replay boundaries precisely because event and log systems can preserve correlation while losing current authority.
