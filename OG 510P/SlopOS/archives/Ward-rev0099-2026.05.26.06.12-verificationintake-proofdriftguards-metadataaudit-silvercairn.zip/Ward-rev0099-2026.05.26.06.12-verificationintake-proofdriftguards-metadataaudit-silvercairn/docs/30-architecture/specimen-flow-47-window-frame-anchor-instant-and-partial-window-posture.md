# Specimen flow 47 — window frame, anchor instant, and partial-window posture

Goal: keep Ward honest when one repeated trust question becomes a rolling or cumulative surface only because the query implicitly chooses a frame, an anchor time, and a rule for incomplete early windows.

## Scenario
A team keeps asking a recurring question across several organizations:

> “Show the trailing 7-day count of newly narrowed credentials, plus the cumulative month-to-date review backlog.”

The first implementation looks tidy, but the semantics are slippery:
1. the event side is sparse and bucketed daily;
2. one engine silently defaults an ordered window to a cumulative frame when the author forgets to write the frame clause;
3. a rerun one day later changes the trailing answer because the anchor instant moved;
4. the first six days of the chart have less than a full 7 days of history, yet the graph line visually suggests ordinary comparability.

## What Ward should preserve
1. Before any derivative is promoted, Ward forces an explicit **window frame** for each rolling/cumulative lane: trailing 7 days, month-to-date, all time so far, or another explicitly named frame.
2. The answer carries an explicit **anchor instant** saying which evaluation instant or bucket edge the frame is relative to.
3. Ward forces an explicit **partial-window posture** for early/truncated windows: emit partial with a badge, suppress until the frame is full, mark unknown, or use another visibly named rule.
4. If densification or fill choices were also involved, the promoted surface still carries gap posture, synthetic-bucket posture, and fill witness rather than pretending window semantics make those weaker choices disappear.
5. If the team later wants a maintained derivative, the promoted surface still carries basis pin, window frame, anchor instant, partial-window posture, and exactness class.

## Nouns under pressure
- **window frame**
- **anchor instant**
- **partial-window posture**

## What must stay separate
- snapshot fact versus windowed projection;
- trailing frame versus cumulative frame;
- evaluation anchor versus abstract label like “7-day rolling”;
- partial early window versus full mature window.

## Promotion rule
Do not promote these nouns beyond guidance unless a later specimen shows the same recurring question surviving at least one trailing window, one cumulative window, and one incomplete early edge without silently inheriting one engine default or hiding which answers were only partial-frame outputs.
