# Specimen flow 87 — signal ingestion, receiver observations, and race guards

## Story

A public owner-routing release was recertified as current-refresh-required. Hours later, Ward receives a revocation signal on the release status channel. Another receiver sees a duplicate refresh signal, and a third sees an older poll result after the high watermark has advanced. A fourth path observes two conflicting signals: one says the channel is current, another says the bundle is revoked.

Ward must record what each receiver observed without letting any signal become authority.

## Residues in play

- source recertification receipt;
- signal envelope;
- canonical event key;
- source/id pair;
- signal subject digest;
- cache-subject digest;
- envelope digest;
- high watermark;
- duplicate window;
- conflict set;
- payload classification;
- follow-up binding;
- no-authority projection label.

## Happy path

1. Receiver loads the source recertification receipt by id and byte digest.
2. Receiver binds the incoming signal to stream id, signal source, signal id, event key, subject, and cache-subject digest.
3. Receiver checks sender/channel authentication, signature or transport evidence, duplicate window, watermark, replay window, projection payload, and local policy.
4. If the signal is new and basis-changing, Ward records `signal_accepted_for_recertification`.
5. If the same source/id is seen again, Ward records `duplicate_signal_ignored`.
6. If the sequence is below the high watermark, Ward records `stale_signal_ignored`.
7. If signals conflict, Ward records `conflicting_signals_held` with no winner.
8. Public projection exposes signal state only and says not authority.

## Failure cases

- source recertification digest mismatch;
- signal subject digest mismatch;
- missing envelope digest check;
- unauthenticated sender;
- unregistered channel;
- duplicate signal treated as new change;
- stale watermark accepted as current;
- conflicting signal auto-winner;
- high-consequence action from signal receipt;
- public sealed-payload leak;
- purpose or recipient drift;
- push acknowledgement treated as consumer refresh.

## Outcome

Ward now has an executable receiver-observation layer between raw status signals and recertification. The signal can request recheck or invalidation, but it cannot itself change authority.
