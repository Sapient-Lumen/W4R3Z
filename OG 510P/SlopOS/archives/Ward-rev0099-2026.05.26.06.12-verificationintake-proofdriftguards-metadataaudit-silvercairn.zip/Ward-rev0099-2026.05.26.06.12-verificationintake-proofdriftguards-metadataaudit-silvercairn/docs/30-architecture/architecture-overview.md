# Architecture overview

Ward is built around layered trust artifacts.

1. **custody objects** — passkeys, keys, wallets, certificates, secret handles, or similar holders of trust-bearing capability;
2. **claims and evidence** — what authenticators, attesters, issuers, builders, or runtimes assert;
3. **endorsement inputs** — trust roots, reference values, policy inputs, freshness and revocation side material;
4. **local appraisal** — what the local environment concludes now;
5. **spendable consequences** — grants, badges, allow/deny outcomes, narrowed powers, or review warrants minted from appraisal.

Ward’s strength is keeping those five layers visible instead of flattening them into “auth succeeded”.

## rev0003 posture additions
- keep snapshot, callback, and provider success signals visibly weaker than durable local consequence;
- prefer one or two specimen artifacts before inventing family-wide registries;
- track downgrade and freshness as first-class modifiers instead of folding them into a success bit.

## rev0023 posture additions
- keep covered absence weaker than issued/valid truth;
- keep uncovered unknown weaker than negative status;
- prefer local replicated status plus bounded deltas over regrowing a mandatory live oracle.

## rev0024 posture additions
- keep classified later state weaker than any automatic spend consequence;
- prefer explicit local action ladders over one universal deny/allow reaction;
- distrust delivery-path coupling when a status transport starts masquerading as status meaning.

## rev0025 posture additions
- keep effective change time weaker than publication/signing time and weaker than final consequence;
- keep grouped-cause residue smaller than one giant incident object;
- keep local adoption cuts visible when different gates or receivers change consequence at different moments.

## rev0026 posture additions
- keep appraisal recipe weaker than witness material and weaker than local consequence;
- keep policy epoch visible when changing trust roots or rules can change result meaning;
- keep replay delta smaller than both the historical result and the current action.


## rev0027 posture additions
- keep replay fences smaller than cause cohorts, subject identity, and consequence;
- keep ordering windows visible when receipt order and event time diverge;
- keep apply cursors smaller than transport acknowledgement and smaller than final local action.


## rev0028 posture additions
- keep concurrency witnesses smaller than both replay fences and final consequence;
- keep merge recipes visible when one local projection reduces parallel source facts;
- keep survivor views and compaction horizons smaller than full history or proof-carrying absence.
- keep writer view weaker than reader view weaker than local consequence when schemas evolve;
- keep field identity stronger than labels/order, and compatibility lanes visible.


## rev0033 posture additions
- keep decomposed assurance facets smaller than any collapsed badge or summary tier;
- keep acceptance floors visible when different local actions need different minima;
- keep the bottleneck facet inspectable so one weaker axis does not become a vague global failure story.

## rev0036 posture additions
- keep commit witnesses smaller than local consequence and smaller than one generic success bit;
- keep stable frontiers visible when one read surface lags behind stronger upstream commitment;
- keep finality classes inspectable when reversal hardness materially changes what actions are safe;
- keep exposure gates local so one substrate threshold does not quietly choose every consequence.


## rev0037 posture additions
- keep lease claims smaller than recipient-validated authority and smaller than final local consequence;
- keep fence tokens visible when clock-based expiry or holder-local confidence can disagree with the destination;
- keep stale-holder alarms inspectable when delayed requests may still arrive after authority moved;
- keep handoff postures local so graceful release, grace delay, expiry, and forced break do not collapse into one vague revocation story.


## rev0038 posture additions
- keep desired state smaller than observed/applied reality and smaller than consequence;
- keep observed generation visible when conditions may still describe an older desired revision;
- keep condition sets smaller than full observed state or local verdict;
- keep teardown gates visible when deletion was requested but cleanup or handoff is not finished.

## rev0039 posture additions
- keep delete markers smaller than physical destruction and smaller than final local consequence;
- keep repair floors visible when a stale replica or lagging rebuild could still revive retired state;
- keep resurrection alarms inspectable instead of letting stale return paths masquerade as fresh truth;
- keep reclamation horizons separate from logical retirement, rollback history, or ordinary current-view absence.

## rev0042 posture additions
- keep basis pins smaller than ambient current truth and smaller than spendable consequence;
- keep cohort contrasts smaller than verdict, recipe, or policy itself;
- keep promoted maintained derivatives visibly weaker than evidence, appraisal recipe, and local consequence.


## rev0043 posture additions
- keep temporal lookup lanes smaller than basis pins and smaller than local consequence;
- keep join clocks visible when event/effective/publication/adoption time can attach different context;
- keep frozen result snapshots smaller than live feeds and smaller than later reruns;
- keep workload witnesses visible before hidden acceleration or maintained-derivative promotion.

## rev0047 posture additions
- keep aggregation laws visible when recurring measures stop behaving like plain sums;
- keep rollup passports smaller than query contracts and smaller than final local consequence;
- keep merge states inspectable when recomposition needs more than one displayed number.


## rev0048 posture additions
- keep grain witnesses visible when one recurring question depends on a specific base fact identity or inner grouping;
- keep fanout fences smaller than query convenience and smaller than promoted derivative authority;
- keep weight carriers inspectable when regroupable rates or averages need more than one rendered number.

## rev0049 posture additions
- keep gap postures visible when missingness, staleness, and true zero diverge;
- keep synthetic buckets smaller than observed source buckets and smaller than promoted derivative authority;
- keep fill witnesses inspectable when a value was carried forward, interpolated, zero-filled, or left null on purpose.

## rev0050 posture additions
- keep window frames visible when one repeated question could mean trailing, cumulative, or all-time-so-far answers;
- keep anchor instants smaller than ambient latest-state folklore and smaller than promoted derivative authority;
- keep partial-window posture inspectable when early buckets do not yet have full frame support.


## rev0051 posture additions
- keep view bindings visible when one repeated question can run over different authorized populations;
- keep population witnesses smaller than query contracts and smaller than promoted derivative authority;
- keep scope drift alarms inspectable when identical query bytes rerun under different view or credential lanes.

## rev0052 posture additions
- keep calendar bindings visible when one repeated question can mean UTC buckets, local civil buckets, ISO weeks, or shifted-origin periods;
- keep timezone witnesses smaller than query contracts and smaller than promoted derivative authority;
- keep boundary drift alarms inspectable when identical query bytes rerun under different calendrical contracts.

## rev0056 posture additions
- keep temporality bindings visible when one repeated question could mean cumulative total, interval delta, or current snapshot;
- keep reset witnesses smaller than continuity classes and smaller than the derived numeric surface that consumed them;
- keep derivative posture inspectable when a rendered rate or increase is weaker than direct replay of the base series.


## rev0057 posture additions
- keep identity witnesses visible when one repeated question collapses rows by a declared logical key or retry family;
- keep dedupe postures smaller than raw append history and smaller than promoted current-winner authority;
- keep correction lineage inspectable when deletes, replacements, or retries shaped the current answer.

## rev0062 posture additions
- keep comparability passports visible when two answer capsules become a trend, before/after chart, cohort contrast, or rerun-vs-history claim;
- keep drift notices inspectable when scope, schema, metric, policy, quality, materialization, privacy, or refusal posture changes;
- keep quality witnesses smaller than local trust consequence but close enough to promoted answer cells to prevent polished low-quality comparisons.
## rev0063 posture additions
- keep delta anatomies visible when a changed answer becomes a why-answer, so scope movement, metric movement, quality/refusal movement, privacy/suppression movement, late corrections, and residual unexplained movement do not collapse into one story;
- keep attribution rails inspectable when explanation fragments move between accounting, lineage, diff, cohort contrast, exemplar, and causal/counterfactual claim strength;
- keep exemplar fences smaller than drill-through authority and smaller than population truth, so vivid cases cannot impersonate representative cause.

## rev0064 posture additions
- keep freshness envelopes visible when reused or materialized answers would otherwise look current just because they are fast;
- keep invalidation receipts inspectable when source, policy, metric, quality, privacy, layout, retention, or refresh-mode changes narrow old answer authority;
- keep recompute dockets smaller than schedulers and stronger than hidden ops logs, so repair/refusal obligations remain part of datacube truth.



## Pass LXV datacube pressure

Ward now treats interaction, rendering, and egress as separate datacube authority surfaces. The new candidate residues are interaction trail, render contract, and egress receipt. They deliberately do not select a dashboard, visualization grammar, export format, telemetry backend, annotation protocol, or agent memory stack. They only make it harder for filters, drill-through, renderer transforms, screenshots, CSVs, embeds, alerts, and summaries to outgrow the source answer capsule.

## Pass LXVI datacube pressure

Ward now treats budgeted/degraded answers as separate datacube authority surfaces. The new candidate residues are budget gate, degradation receipt, and uncertainty envelope. They deliberately do not select an approximate-query engine, sketch library, budget scheduler, billing model, privacy-accounting framework, validation-detail policy, or warning grammar. They only make it harder for resource limits, latency targets, privacy loss, validation-detail withholding, sampling, sketches, nondeterminism, stale fallback, top-k truncation, and agent convenience to outgrow the requested answer capsule.

## rev0067 posture additions
- keep correction horizons visible when an answer can be revised by late facts, identity repair, delete/revoke state, privacy/legal change, or backfill;
- keep backfill ledgers inspectable when deliberate history repair affects answer capsules, materializations, comparisons, exports, or agent summaries;
- keep revocation fences smaller than global recall and stronger than a stale warning, so withdrawn or superseded answer material cannot keep consequence authority by inertia.

## Pass LXVII datacube pressure

Ward now treats correction, backfill, and revocation as separate datacube authority surfaces. The new candidate residues are correction horizon, backfill ledger, and revocation fence. They deliberately do not select a CDC engine, table format, temporal database, audit-log backend, export recall system, legal-erasure workflow, or universal finality rule. They only make it harder for late facts, history repair, explicit deletes, policy changes, and stale detached artifacts to outgrow the source answer capsule.

## rev0068 posture additions
- keep federation pacts visible when one answer crosses sources, tenants, clean-room collaborations, semantic owners, or delegated policy surfaces;
- keep join warrants smaller than a universal entity graph and stronger than key equality, so authority, tokenization, fanout, temporal alignment, privacy, and side-channel posture remain inspectable;
- keep projection curtains smaller than a data-sharing platform and stronger than a column list, so aggregate/list/detail release, policy carryover, suppression, activation, and export limits stay part of answer authority.

## Pass LXVIII datacube pressure

Ward now treats federated composition as a separate datacube authority surface. The new candidate residues are federation pact, join warrant, and projection curtain. They deliberately do not select a federated query engine, clean room, semantic layer, trust-federation protocol, PDP, data contract standard, or source catalog. They only make it harder for remote fragments, pushdown fallback, clean-room joins, delegated authorization, trust chains, and projection release decisions to outgrow the source answer capsule.


## rev0069 posture additions

- keep concept anchors visible when an axis/member/code/term/status bucket needs durable semantic identity beyond display labels;
- keep crosswalk warrants smaller than mapping engines but strong enough to explain rename, split, merge, broader/narrower, no-map, and partner-tag bridge posture;
- keep hierarchy cuts inspectable when rollups, abstract nodes, value-set expansions, or taxonomy membership shape a cube answer;
- keep SlopOS CH-ATTR/CH-ATTRQ bounded: semantic receipts may qualify answer capsules without turning the attribute layer into a global ontology or full-text semantic index.

## rev0070 posture additions

- keep threshold witnesses visible when an answer-derived alert, recommendation, or control loop depends on comparator, baseline, duration, tolerance, stabilization, no-data/error, and anti-flap posture;
- keep action warrants smaller than policy engines but strong enough to separate observed answer truth from permission to page, notify, recommend, propose ACP action, throttle, scale, quarantine, or refuse;
- keep consequence receipts inspectable when downstream alerts, notifications, workflow runs, flag decisions, ACP outcomes, no-ops, duplicate suppression, withdrawals, and fenced artifacts result from cube answers;
- keep SlopOS ACP/notification/budget separations intact: cube-derived residues may qualify proposals and receipts without becoming authorization, current display-state truth, or ambient payer context.

## Pass LXX datacube pressure

Ward now treats answer-to-action handoff as a separate datacube authority surface. The new candidate residues are threshold witness, action warrant, and consequence receipt. They deliberately do not select an alerting product, workflow engine, policy engine, feature-flag provider, event bus, autoscaler, notification stack, or SlopOS ACP extension. They only make it harder for breached cells, urgent-looking charts, dashboards, agents, and exported alerts to outgrow the source answer capsule.

## rev0071 posture additions
- keep learning loop ledgers visible when cube answers, consequence receipts, reviewer decisions, or agent summaries are proposed as training/evaluation/reward/policy material;
- keep holdout witnesses smaller than an experiment platform but stronger than a claimed control lane;
- keep feedback taint fences inspectable when outcomes were shaped by prior alerts, recommendations, rankings, quarantines, exports, UI exposure, or agent summaries;
- keep learning reports non-authoritative until ordinary review, budget, policy, and action-warrant gates accept them.


## rev0072 posture additions
- keep scenario capsules visible whenever forecasts, simulations, stress tests, synthetic data, imputations, sensitivities, or what-if answers enter the datacube surface;
- keep counterfactual warrants smaller than a causal platform but stronger than narrative contrast;
- keep synthetic boundaries attached to generated rows/cells/features/exemplars across joins, rollups, renders, exports, and learning loops;
- keep scenario outputs review-oriented until current authority, action warrants, learning-loop ledgers, and egress receipts explicitly accept downstream use.

## rev0073 posture additions
- keep intent bindings visible when a natural-language or agent-origin request would otherwise disappear behind generated query material;
- keep translation warrants smaller than query compilers but stronger than model confidence or SQL syntax success;
- keep tool-call leashes inspectable when model-controlled tools can query, sample, render, export, draft, or propose, so capability, arguments, budgets, approval, and execution result remain visible;
- keep model-written summaries derivative: they may explain answer capsules, but cannot become answer authority, action permission, learning labels, or proof that the query was safe.

## Pass LXXIII datacube pressure

Ward now treats model-mediated cube use as a separate datacube authority surface. The new candidate residues are intent binding, translation warrant, and tool-call leash. They deliberately do not select an LLM, SQL-agent framework, MCP profile, semantic-layer product, prompt format, validator, tracing backend, or review UI. They only make it harder for user prose, generated SQL, model-controlled tools, repair loops, and fluent summaries to outgrow the source answer capsule.

## rev0074 posture additions
- keep verification bundles as evidence packets, not authority, replay engines, or raw-data escape hatches;
- keep replay recipes explicit about replay class, locked inputs, nondeterminism, tolerances, budgets, and refusal/degradation behavior;
- keep attestation envelopes as claims over subjects with issuer/proof/log posture, not as truth, freshness, permission, or consequence authority;
- keep signed exports and model-summarized proofs derivative until current scope/state/freshness/revocation material is rehydrated.

## Pass LXXIV datacube pressure

Ward now treats portable verification as a separate datacube authority surface. The new candidate residues are verification bundle, replay recipe, and attestation envelope. They deliberately do not select a proof format, package format, transparency log, key system, replay runtime, dependency manager, notebook/container format, or verifier UI. They only make it harder for audits, signatures, replays, and evidence packets to outgrow the source answer capsule.

## Pass LXXV architecture pressure — lifecycle evidence without storage closure

Pass LXXV adds lifecycle residue around SlopOS-facing datacube evidence:

- **custody trail** keeps handling, transfer, projection, redaction, fixity, and boundary changes visible for answer-adjacent evidence;
- **retention charter** keeps purpose, authority, allowed use, detail level, hold/erasure/privacy pressure, and expiry near retained artifacts;
- **disposition receipt** records deletion, redaction, transfer, sealing, hold-extension, digest-only reduction, sanitization claim, or refused disposal without claiming total downstream amnesia.

This keeps verification bundles, replay recipes, exports, and consequences reviewable without choosing a storage backend, records-management system, WORM mode, legal taxonomy, or archive package.

## Pass LXXVI architecture pressure — contestable datacube answers

Pass LXXVI adds contestability as an answer-adjacent layer, not as a legal workflow. Ward now assumes a SlopOS datacube answer can be generated, exported, signed, retained, replayed, acted upon, learned from, and later contested; those states must remain separately inspectable.

The architectural split is:

- **contest packet** for bounded challenge intake and admissibility/refusal posture;
- **adjudication docket** for review procedure, evidence admission/exclusion, replay/check posture, conflicts, interim holds, outcome, and unresolved questions;
- **remedy receipt** for downstream effects, derivative reach, residual gaps, and currentness impact.

This keeps review and remedy visible without letting Ward become a tribunal, ticketing queue, compliance product, or global source of legal truth.

## Pass LXXVII architecture pressure — stewardship, delegation, and escalation

Ward now treats governance handoff as answer-adjacent residue rather than ambient org metadata:

- **stewardship charter** keeps accountability, duties, exclusions, review cadence, conflict, successor/backstop, and evidence pointers scoped to a cube subject;
- **delegation warrant** keeps temporary human/team/service/agent authority scoped, caveated, expiring, revocable, budgeted, and auditable;
- **escalation handoff** keeps routing, acceptance/refusal, evidence coverage, authority requested/granted/denied, interim state, deadline, and closure visible.

This layer sits beside answer authority, contestability, action, learning, and lifecycle residue. It should not own org charts, HR group membership, authorization engines, ticket queues, or incident systems. It only prevents owner labels, assignments, and pages from laundering themselves into datacube authority.

## rev0078 posture additions
- keep governance handoff packets smaller than catalogs, IAM engines, ticket systems, incident systems, or org charts;
- keep proof obligations visible so subject binding, duties/exclusions, currentness, caveats, acceptance, conflict, agent boundaries, emergency residue, rehydration, and projection cannot collapse into one owner label;
- keep negative fixtures close to promoted nouns so Ward can prove it rejects owner-label laundering, expired delegation, unaccepted handoffs, agent-as-steward collapse, budget/semantic confusion, stale successor state, and forbidden re-delegation.


## rev0084 posture additions
- keep evidence release smaller than authority release; recipient, purpose, projection, and field selection must travel with detached artifacts;
- keep public omission disclosure smaller than exact hidden fact so sealed rows do not become existence oracles;
- keep export logs weaker than release receipts unless source digest, selection digest, no-authority watermark, and forbidden-effect fences are preserved.


## Rev0094 reuse gates

Reuse-gate receipts sit after receiver convergence and before downstream use. They make reuse consequence-specific: low-risk display/internal review may be allowed with no-authority labels, export is held for evidence-release, high-consequence repair/action is refused without fresh packet replay, and receiver gaps quarantine reuse.
