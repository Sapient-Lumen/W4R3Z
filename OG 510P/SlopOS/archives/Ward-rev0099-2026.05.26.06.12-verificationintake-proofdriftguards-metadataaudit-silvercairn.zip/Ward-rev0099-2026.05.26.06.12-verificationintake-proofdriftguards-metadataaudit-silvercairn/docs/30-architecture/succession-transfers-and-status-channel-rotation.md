# Succession transfers and status-channel rotation

Pass LXXXVI adds the responsibility-transfer seam that appears after release and follow-up receipts.

## Position in the spine

```text
governance handoff packet
  -> governance decision event
    -> governance decision consumer receipt
      -> governance batch/search receipt
        -> governance search-continuity receipt
          -> governance evidence-release receipt
            -> governance evidence-release follow-up receipt
              -> governance succession/transfer receipt
```

The succession/transfer receipt is downstream and non-authority. It may update where current status is found and who is responsible for review contact, but it does not approve semantic repair, remedy, export, action, learning, privacy waiver, budget spend, or delegation.

## Why this exists

Released governance evidence becomes sticky. Follow-up receipts can revoke, correct, quarantine, or acknowledge a release, but they still depend on living status paths and responsible contacts. When those change, Ward needs a receipt that can say:

- the old channel is no longer current;
- the predecessor has no continuing authority;
- the successor accepted, refused, or is pending;
- the transfer did not widen scope or purpose;
- public views remain minimized;
- downstream consumers must refresh before reuse.

## Safe positive lanes

The v0 fixtures cover:

- public recipient-contact transfer after acknowledgment;
- status-channel rotation after revocation;
- restricted steward successor held for recheck after stale-bundle quarantine;
- projection-policy steward transfer after sealed-omission correction.

## Dangerous lanes

The negative fixtures reject old-channel reuse, hidden pending successors, public named-steward leakage, scope expansion, purpose drift, source digest mismatch, and transfer-as-authority.

## Neighbor behavior

ViewFS should surface current status and stale-channel warnings. Schell should retain the immutable chain and minimize public successor details. Harbor should refuse support from pending transfers. Helm should display transfer state rather than replacing the original owner. SlopOS should treat accepted transfer as a route to recheck, not as a grant.
