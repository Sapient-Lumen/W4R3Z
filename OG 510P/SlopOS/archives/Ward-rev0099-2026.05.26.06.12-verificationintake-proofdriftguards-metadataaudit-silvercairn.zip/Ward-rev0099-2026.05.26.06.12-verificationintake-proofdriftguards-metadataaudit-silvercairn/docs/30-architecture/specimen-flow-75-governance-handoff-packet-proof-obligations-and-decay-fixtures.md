# Specimen flow 75 — governance handoff packet, proof obligations, and decay fixtures

## Specimen question

A provider-risk quarantine answer needs semantic repair, recompute, remedy update, dashboard re-export, and possible action re-enable. The latest owner hints disagree. The prior business steward is stale. A technical owner changed teams. A temporary analyst has a narrow repair delegation. A payer lane accepts recompute budget. A dashboard owner wants publication. An agent proposes to re-enable the quarantine recommendation.

Can Ward prove which pieces are allowed, review-only, routing-only, stale, or refused without treating owner labels, pages, tickets, tools, or budget approval as global authority?

## Existing material

- Pass LXXVII stewardship charter, delegation warrant, and escalation handoff.
- Contest packet, adjudication docket, remedy receipt, correction horizon, backfill ledger, invalidation receipt, recompute docket, revocation fence.
- Action warrant, threshold witness, consequence receipt, learning loop ledger, feedback taint fence.
- Verification bundle, replay recipe, attestation envelope, custody trail, retention charter, disposition receipt.
- Intent binding, translation warrant, tool-call leash.

## New material

- `docs/30-architecture/datacube-residue-spine.md`
- `docs/20-assurance/governance-proof-obligations.md`
- `docs/10-threat-model/governance-handoff-threat-model.md`
- `docs/30-architecture/governance-handoff-packet-v0.md`
- `docs/30-architecture/cross-cube-governance-seams.md`
- `schemas/governance-handoff-packet.v0.json`
- `schemas/residue-spine.v0.json`
- `fixtures/governance-handoff/provider-risk-quarantine.valid.json`
- `fixtures/governance-handoff/negative/*.invalid.json`
- `tools/check_governance_handoff.py`

## Walkthrough

1. Ward receives a request to repair the stale provider-status crosswalk, recompute the provider-risk score, update remedy records, re-export a dashboard chart, and re-enable a quarantine recommendation.
2. It compiles a governance handoff packet bound to the exact answer family, metric, semantic bridge, contest packet, recompute docket, export family, and action class.
3. It reads the stewardship charter. The business steward lane is stale, but a backstop governance lane can issue temporary repair warrants. The charter permits semantic bridge review and repair initiation, but excludes raw-row exposure, export publication, privacy waiver, action approval, and budget spend.
4. It reads the delegation warrant. The temporary analyst may inspect projected evidence, draft the crosswalk repair, run validation, and prepare a recompute request. The analyst may not spend budget, publish exports, waive privacy, re-delegate, approve remedy, or re-enable action.
5. It reads escalation handoffs. The payer lane accepts recompute budget. The action-governance lane accepts review only and declares a reviewer conflict. The dashboard export lane has no accepted authority yet.
6. It reads the agent boundary. The agent may summarize validation results and propose an action-warrant packet, but may not approve its own recommendation or accept escalation.
7. It evaluates proof obligations PO-GOV-001 through PO-GOV-011.
8. It allows analyst repair draft and validation, allows payer-approved recompute budget, marks agent re-enable proposal review-only, keeps dashboard export held, and refuses action re-enable until fresh threshold witness, action warrant, conflict/quorum, and accepted governance authority exist.

## Negative fixture pressure

The fixture set must fail when any of these are allowed as consequence-grade:

- catalog owner approves metric edit;
- on-call responder re-enables quarantine;
- expired delegate runs backfill;
- ticket assignment accepts escalation;
- agent tool access becomes stewardship;
- payer changes metric semantics;
- break-glass waives privacy without review debt;
- old owner map survives after successor drift;
- conflicted reviewer approves own remedy;
- delegate re-delegates without warrant.

## Promotion tests

Governance handoff packet v0 earns further promotion only if it can keep these distinctions alive:

- owner hint versus chartered duty;
- chartered duty versus specific approval;
- delegated task versus steward-of-record;
- escalation assignment versus accepted authority;
- payer authority versus semantic authority;
- agent proposal versus action warrant;
- emergency override versus review debt;
- historical governance fact versus current rehydrated authority;
- authority proof versus governance evidence disclosure.

## Current posture

Promote the packet, proof obligations, schema, and fixtures as a **machine-checking scaffold**, not as a finished governance product. The next pressure should add more positive fixtures, integrate Foundry/Harbor/Helm/Schell/ViewFS sample artifacts, and decide whether low-risk owner-hint routing deserves a tiny formal fixture or should remain prose-only.
