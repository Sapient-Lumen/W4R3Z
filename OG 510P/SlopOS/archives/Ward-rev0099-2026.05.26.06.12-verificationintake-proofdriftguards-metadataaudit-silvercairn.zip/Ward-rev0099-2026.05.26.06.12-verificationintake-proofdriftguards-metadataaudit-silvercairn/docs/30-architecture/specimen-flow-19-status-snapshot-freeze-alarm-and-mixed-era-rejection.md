# Specimen flow 19 — status snapshot, freeze alarm, and mixed-era rejection

Goal: keep coherent status cuts, stale/freeze posture, and multi-lane discovery visibly separate.

## Scenario
A credential, proof, or earlier verification event was accepted before.
Later the receiver consults status material from one or more sources:
- a direct status coordinate,
- an issuer-published aggregation surface,
- a cached list from an earlier fetch,
- and optionally an append-only publication history.

Some of the fetched material is fresh enough, some is older, and some may not belong to the same time cut.
The receiver must decide whether it has one coherent current-enough snapshot, whether it only has stale residue, and what local consequence follows without pretending that stale, missing, or mixed-era status means "revoked".

## Proposed Ward objects
1. **status snapshot**
   - a coherent batch or time cut of later status material;
   - stronger than one fetched fragment and weaker than a local spend/adopt consequence.

2. **freeze alarm**
   - typed residue that says status material is too old, too unavailable, or no longer refreshable enough for the current gate;
   - stronger than silent retry logic and weaker than negative status meaning.

3. **aggregation surface**
   - issuer-published discovery of one or more relevant status lanes;
   - useful only if it remains smaller than any one lane's meaning and smaller than the final local verdict.

4. **consistency witness**
   - optional append-only or version witness that later publication extends earlier publication rather than rewriting it;
   - valuable when it remains accountability material rather than automatic approval.

## Why this specimen matters
It pressure-tests whether Ward can stay honest when:
- several status lanes exist for one underlying subject or witness bundle;
- clients have cached status that might still be valid but no longer current enough;
- later publication history proves detectability but not automatic safety;
- and fetch success, freshness, coherence, and negative meaning are all different truths.

## Promotion rule
Do not promote `status snapshot`, `freeze alarm`, `aggregation surface`, or `consistency witness` unless they improve:
- one multi-lane specimen where several status sources must compose coherently,
- one historical time-cut specimen,
- one stale/frozen specimen that proves Ward does not flatten freshness failure into revocation,
- and one append-only consistency specimen that proves publication history can stay smaller than local spend/adopt consequence.
