# Specimen flow 36 — delete marker, repair floor, resurrection alarm, and reclamation horizon

Goal: keep Ward honest when a trust-relevant grant looks deleted in the current view, older versions still exist, and stale rebuild paths could revive it unless negative evidence survives long enough.

## Scenario
A local high-risk approval grant `G` lets device `D` approve large transfers for account family `A`.
The sequence unfolds in six steps:
1. recovery workflow decides that `D` is no longer acceptable and writes a **delete marker** / logical tombstone for grant `G`; ordinary current-state reads now treat `G` as absent;
2. historical cuts and rollback-friendly history still retain the older bytes for `G`, because the system keeps prior generations for review and bounded recovery;
3. a lagging consumer rebuilding a compact current projection from the beginning must still observe the delete marker before that marker ages out, otherwise it can reconstruct a stale current view that still includes `G`;
4. one replica or offline cache that missed the delete marker can later reappear with the older bytes for `G`; unless the system kept enough repair coverage before purging old delete evidence, that stale state may look like newly current data;
5. only after the relevant replication / rebuild safety bar is met does the **repair floor** clear, and only later does the **reclamation horizon** arrive when the older bytes, metadata, or markers may be physically removed;
6. until both are satisfied, Ward should keep a **resurrection alarm** available: the grant may be absent from the default current read, but not yet strong enough to be treated as impossible-to-return.

At first glance, a product might flatten this into “grant deleted”.
That would be a mistake.
A delete marker is weaker than physical destruction.
A current default view is weaker than historical non-existence.
A retained rollback generation is different again.
And a post-retention stale replica can still matter if the system purges negative evidence before repair/build safety is satisfied.

Ward should therefore record four distinct residues rather than one vague deletion truth:
1. a **delete marker** for current-view logical retirement;
2. a **repair floor** for the minimum repair / propagation / rebuild-safety posture before stronger deletion claims;
3. a **resurrection alarm** for explicit risk that stale copies could make the retired thing look current again;
4. a **reclamation horizon** for when old bytes, metadata, or markers may be physically purged.

In this specimen, a UI may choose to show one row as “deleted”, but **the highest-risk consequence must not collapse logical retirement, retained history, repair debt, and physical reclamation into one badge**.

## Why this matters
- Default current reads often hide older retained versions without destroying them.
- Lagging rebuilds and stale replicas need negative markers to survive long enough.
- Repair/propagation safety is materially different from logical retirement.
- Physical reclamation is a separate policy moment with its own corruption and rollback costs.
- A system that says only “deleted” hides both resurrection risk and undelete / rollback reality.

## Ward pressure
This specimen pressures Ward to keep delete markers, repair floors, resurrection alarms, and reclamation horizons distinct while still leaving open whether later implementation uses versioned objects, compacted logs, tombstone sidecars, lifecycle rules, or some mixed carrier.
