# Chain integrity, dispute forks, and canonical heads

Pass LXXXVII adds the seam that appears after release, follow-up, and transfer receipts accumulate: which lineage is current, and what happens when two plausible downstream branches disagree?

## Position in the spine

```text
governance handoff packet
  -> governance decision event
    -> governance decision consumer receipt
      -> governance batch/search receipt
        -> governance search-continuity receipt
          -> governance evidence-release receipt
            -> governance evidence-release follow-up receipt
              -> governance succession/transfer receipt
                -> governance chain-integrity receipt
```

The chain-integrity receipt is a lineage receipt. It never manufactures authority. It records the ordered receipt chain, validates member bytes, checks that source release, recipient, purpose, source item, and projection policy did not drift, and either records a current status head or holds the chain because a fork exists.

## Why this exists

Ward now has enough post-release receipt types that consumers can become split-brained:

- one consumer sees a release and old follow-up but misses the transfer;
- another sees a transfer through an old status channel;
- a third sees a successor branch that was never accepted;
- a public surface receives a branch conflict and leaks named steward evidence;
- a batch/search surface compresses all branches into a single green “current” badge.

The chain-integrity receipt gives Ward a compact refusal machine for those cases.

## Canonical head rule

A canonical head must be the latest valid transfer member in the ordered chain. The head is current only for status/recheck routing. It cannot approve export, action, repair, remedy, budget spend, learning use, privacy waiver, or delegation.

A forked lineage must set `no_current_head` and `release_reuse_state: held_due_to_fork`. It may disclose a bucketed fork state, but not named private branch evidence in public views.

## Chain digest rule

The v0 chain digest is deterministic over ordered member ids and member byte digests. This makes the receipt cheap to compare, safe to project, and hostile to invisible member swaps.

This is intentionally smaller than a transparency log. Ward borrows the discipline of append-only and receipt-based systems without becoming the log, status issuer, or authorization server. `EXT-RFC-9162`, `EXT-SCITT-ARCH-2026-LATEST`, and `EXT-W3C-VC-DATA-INTEGRITY-1-1-2026` are load-bearing pressure for this restraint.

## Neighbor behavior

- **ViewFS** should show the chain head or fork hold without revealing sealed branch evidence.
- **Schell** should retain the immutable chain and minimize public fork details.
- **Harbor** should refuse recompute or correction support from forked chains.
- **Helm** should render current status pointers as routing facts, not approval.
- **SlopOS** should require chain replay before attaching governance evidence to CH-AREF, portal, tool, export, or action paths.
