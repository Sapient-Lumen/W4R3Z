# Decision event projection and replay closure

The pass LXXX decision-event work adds a narrow replay surface over governance handoff packets.

A governance handoff packet answers: **is this actor/action allowed, held, refused, or downgraded under current governance evidence?**

A governance decision event answers: **what compact, projected, replay-checkable fact can a sibling cube carry about that one evaluated action?**

## Projection hierarchy

1. **Packet** — full proof context; can support consequence-grade action when valid.
2. **Decision event** — digest-bound projection of one evaluated packet action; cannot grant authority by itself.
3. **Rendered badge / retained receipt / recheck ticket / CH-AREF attachment** — consumer-specific view; must preserve event weakness.
4. **Telemetry/correlation IDs** — search and debugging only; never governance proof.

## Replay recipe

To replay a decision event:

1. resolve `packet_ref.packet_path` or equivalent artifact reference;
2. verify `packet_ref.packet_sha256`;
3. re-run the governance handoff checker on the packet;
4. locate the referenced `actor` and `action` in `evaluated_actions`;
5. compare packet posture with event state;
6. check projection, expiry, review-debt, and consumer-profile fields;
7. downgrade the event if any of the above fails.

## Consumer closures

| Consumer | What it may do with the event | What it must not do |
|---|---|---|
| Helm | render the visible state, weakness, next safe route, and no-authority label | turn a badge into approval |
| Schell | retain a minimized receipt and sealed pointer with expiry/deletion policy | inline sensitive governance evidence into public/external views |
| Harbor | schedule or justify a recheck window | treat recheck as correction implementation |
| SlopOS | attach the event to a CH-AREF-like artifact/ref or transcript | treat digest identity as trust, authority, or currentness |

## Why not a generic audit log?

Ward is not promoting a general log substrate. The event has exactly one purpose: make one governance decision state portable without losing the packet-parity and projection checks that made the state safe.
