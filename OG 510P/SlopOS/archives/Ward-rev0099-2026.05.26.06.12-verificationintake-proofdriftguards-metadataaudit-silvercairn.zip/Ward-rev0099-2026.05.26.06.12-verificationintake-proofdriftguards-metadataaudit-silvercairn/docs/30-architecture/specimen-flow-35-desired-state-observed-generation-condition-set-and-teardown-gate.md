# Specimen flow 35 — desired state, observed generation, condition set, and teardown gate

Goal: keep Ward honest when a requested trust-policy change is stored immediately, compact status still describes an older generation, and deletion begins before cleanup is complete.

## Scenario
A local high-risk transfer policy is represented by a small trust object for account family `A`.
The sequence unfolds in five steps:
1. an operator edits the object so the **desired state** now requires an extra corroboration step for transfers above a threshold; the object generation advances to `12` immediately;
2. the reconciling component has not yet processed generation `12`, so the current **condition set** still shows `Ready=True` and `PolicyApplied=True`, but only with **observed generation** `11`;
3. a transfer request arrives during that gap; the local system must not pretend that “stored generation 12” means the new policy is already active, and must not pretend that “Ready=True” means the status definitely reflects generation `12`;
4. the operator then requests deletion of this policy object because a replacement policy family will take over; the API marks the object with a deletion timestamp, but a **teardown gate** remains because dependent grants, watches, or derived review handles still need cleanup;
5. only after the cleanup controller removes the gate can the object actually disappear. Until then, the object is neither ordinary current policy nor fully gone.

At first glance, a product might flatten this into “policy updated, then policy deleted”.
That would be a mistake.
The desired state is weaker than the observed/applied state.
The condition set is weaker again unless its observed generation tells us which desired revision it summarizes.
And deletion request is different yet again: terminating-with-cleanup-pending is not absence.

Ward should therefore record four distinct residues rather than one vague current-object truth:
1. a **desired state** for the requested local target;
2. an **observed generation** telling which desired revision the compact summary really covers;
3. a **condition set** for concise typed summary smaller than the full observed/appraised state;
4. a **teardown gate** explaining that cleanup is still in progress after deletion was requested.

In this specimen, a UI may choose to render one row, but **the highest-risk consequence must not collapse requested, observed, summarized, and terminating states into one badge**.

## Why this matters
- Requested truth and applied truth often diverge for a while.
- Compact condition summaries are easy to over-read unless they carry generation context.
- Some observed fields are direct acknowledgements while others lag because they describe running effects.
- Teardown-in-progress is operationally real and materially different from absence.
- A system that says only “current policy” or “deleted” hides reconciliation lag and hides cleanup debt.

## Ward pressure
This specimen pressures Ward to keep desired target, observed-generation coverage, compact summary conditions, and teardown-in-progress distinct while still leaving open whether later implementation uses spec/status objects, sidecars, paired request/result records, or some mixed carrier.
