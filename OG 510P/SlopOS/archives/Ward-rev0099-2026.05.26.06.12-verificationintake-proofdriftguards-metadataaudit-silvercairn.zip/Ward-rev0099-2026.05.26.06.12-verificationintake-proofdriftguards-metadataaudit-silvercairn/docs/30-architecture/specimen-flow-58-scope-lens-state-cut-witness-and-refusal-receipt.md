# Specimen flow 58 — scope lens, state cut witness, and refusal receipt

## Goal

Pressure-test the next careful datacube step for Ward: a SlopOS-shaped answer must preserve its authority scope, mutable state cuts, and cannot-answer/withheld material before it can become durable trust evidence.

## Scenario

A SlopOS surface asks a recurring trust question:

> Which partner trust surfaces are deteriorating this policy epoch, grouped by credential family, appraisal lane, and spend-consequence class, and why are any partners or cells missing?

The answer is supposed to help a human decide where to narrow spend or trigger review. That makes the failure mode dangerous: a plausible partial chart could cause real trust consequences. Ward should make the answer inspectable without deciding that SlopOS must use SQL, Substrait, MetricFlow, an array store, a lakehouse table, or a global cube registry.

## Flow

1. **The question starts inside an explicit SlopOS view.** The caller has a view capability, a CH-ATTRQ-like bounded query digest, and a declared namespace/schema digest. There is no ambient “search all trust things” endpoint and no count-only existence probe.

2. **Scope lens records authority before rows.** The answer capsule records the view or snapshot binding, namespace, schema digest, query digest, authorized population, result kind, and leakage posture. It also says which conveniences were refused: raw paths, hidden lineage joins, provider-global inventory, count-only probes, or cross-view expansion.

3. **Axis capsule records cell meaning.** The answer then records the cell axes: partner, credential family, appraisal lane, spend-consequence class, policy epoch, time bucket, and any subtotal/ALL levels. It distinguishes subtotal identity from ordinary null-valued members and keeps absence posture close to the cell.

4. **State cut witness freezes the moving world.** The answer records the mutable cuts that shaped this run: SlopOS snapshot ID or handle set, CH-ATTR schema digest, policy epoch, semantic model or metric-card version if used, materialization generation, redaction profile, source data cuts, calendar/timezone/unit bindings, fill/privacy/resolution/tier residues, and any retained aggregate-state family.

5. **Computation may produce answers and refusals.** Some cells return measures. Other cells produce refusal receipts: `authority_denied`, `schema_unsupported`, `unmodeled_dimension`, `privacy_suppressed`, `stale_materialization`, `budget_exhausted`, `cost_guardrail`, `lineage_hidden`, or `not_replayable`. A zero-refusal run still records `refusal_receipts: none_observed_under_scope` rather than leaving completeness implicit.

6. **Layout aperture and lineage facet remain attached.** If the answer came from a retained summary, sparse array, hidden-partitioned table, columnar export, or materialized-plus-raw stitch, the layout aperture names the consequence. The lineage facet names source cuts, recipe/run identity, and promotion context enough for rerun, diff, downgrade, or quarantine.

7. **Promotion gate checks failures before trust consequence.** Ward may promote the answer only if reviewers can inspect the scope lens, state cut witness, axis capsule, layout aperture when needed, lineage facet, and refusal receipts. A chart that has values but lost its refusals is rejected as a plausible partial answer.

## Nouns pressure-tested

- **scope lens** — compact authority residue naming view/snapshot, namespace, schema/query digest, authorized population, and leakage limits for one answer.
- **state cut witness** — compact mutable-cut residue naming the source snapshots, schema/semantic/policy/materialization/redaction cuts, and retained state family that made the answer.
- **refusal receipt** — compact cannot-answer or withheld-answer residue naming why a query, cohort, cell, or projection was denied, unsupported, stale, suppressed, over-budget, or unsafe.

## Why this preserves optionality

This specimen does not choose a SlopOS datacube engine. It can work if the future implementation uses view-scoped CH-ATTRQ queries, SQL grouping sets, MetricFlow-style semantic models, Substrait-style plan receipts, sparse arrays, Arrow-like exports, ViewFS manifests, or retained materialized summaries.

The promoted thing remains an earned answer capsule with inspectable scope/cut/refusal residue. Only repeated specimens should decide whether those residues become first-class schemas, facet families, or SlopOS-native objects.

## Open pressure

- Is scope lens mandatory on every Ward answer, or only when a query crosses a view, trust, privacy, export, or promotion boundary?
- Should state cut witness be one card or a bundle of existing residues such as policy epoch, basis pin, lineage facet, tier witness, and metric card?
- Do refusal receipts live at query, cohort, cell, or projection level by default?
- Can SlopOS expose any count-only datacube surface without turning hidden populations into an oracle?
- How should Helm show refused/suppressed/stale cells so humans do not mistake them for zeros or ordinary absence?
