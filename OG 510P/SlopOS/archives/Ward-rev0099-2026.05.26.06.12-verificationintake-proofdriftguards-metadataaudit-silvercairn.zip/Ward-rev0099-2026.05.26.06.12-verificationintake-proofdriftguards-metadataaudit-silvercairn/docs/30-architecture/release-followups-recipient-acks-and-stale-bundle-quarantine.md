# Release follow-ups, recipient acknowledgments, and stale-bundle quarantine

Pass LXXXV adds the missing post-release lifecycle seam.

An evidence-release receipt proves that one export or bundle was safe at release time. It does not prove the bundle remains safe forever. Ward therefore adds a downstream follow-up receipt.

## Position in the spine

```text
governance handoff packet
  -> governance decision event
    -> governance decision consumer receipt
      -> governance batch/search receipt
        -> governance search-continuity receipt
          -> governance evidence-release receipt
            -> governance evidence-release follow-up receipt
```

The follow-up is downstream and non-authority. It cannot grant new permissions and cannot repair the original release by mutation.

## Why a separate receipt?

Post-release changes are not the same as release-time projection:

- a recipient may acknowledge receipt without accepting authority;
- an artifact may expire;
- a sealed omission bucket may change;
- a projection policy may be superseded;
- an owner map or packet digest may drift;
- a downstream user may try to reuse a release without refresh;
- a restricted bundle may need quarantine.

If Ward edits the old receipt, auditability is lost. If Ward does nothing, stale artifacts become portable authority. The follow-up receipt keeps both truths visible: what was released then, and why it is now acknowledged, corrected, revoked, quarantined, or refused for reuse.

## Product consequence

Every released artifact should expose a refresh/status pointer. Consumers should resolve that pointer before action, export, remedy, learning, or budget use. Helm should render:

> “Released evidence. Follow-up state: revoked/corrected/quarantined/acknowledged. Not authority.”

ViewFS should treat a stale label as part of the trusted path, not as optional decoration. Schell should retain follow-up receipts separately from releases. Harbor and SlopOS should reject stale release bundles as current support.

## Non-goal

The follow-up receipt does not become a revocation protocol, messaging bus, legal notice engine, or authorization system. It records enough lifecycle evidence for Ward to refuse stale-bundle laundering.
