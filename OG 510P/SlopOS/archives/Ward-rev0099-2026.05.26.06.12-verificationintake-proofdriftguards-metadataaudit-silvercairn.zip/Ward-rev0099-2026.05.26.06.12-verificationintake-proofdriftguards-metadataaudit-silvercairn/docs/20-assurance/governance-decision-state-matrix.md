# Governance decision state matrix

This matrix records the minimum closure rules for Ward governance handoff packet outcomes.

It is deliberately smaller than an authorization model. It tells the checker and downstream renderers what a state may imply, what it must not imply, and which evidence must be present.

| State | May imply | Must not imply | Required closure |
|---|---|---|---|
| `routing_hint_only` | Safe read-only route, contact hint, steward discovery, review-intake affordance | repair, export, budget, remedy, privacy waiver, action, learning use, steward-of-record | routing-hint mode enabled; read-only; non-sensitive evidence; forbidden promotions; safe projection |
| `review_only` | material may be inspected, summarized, or prepared for human/governance review | approval, publication, action, remedy, acceptance of escalation | subject binding; review lane; projection class; no consequence-grade effects |
| `needs_rehydration` | old material may be useful if refreshed | current authority, current truth, current approval | stale/currentness reason; rehydration target; no spendable consequence |
| `authority_missing` | local evidence may be routed or queued | any consequence-grade act | named missing authority class; no allowed effect |
| `handoff_unaccepted` | escalation was sent or assigned | accepted authority or resolution | explicit acceptance missing/denied/stale |
| `expired_warrant` | prior delegation existed historically | present delegation | expiry/revocation/supersession reason |
| `privacy_projection_block` | action may be technically or semantically possible | disclosure or export | blocked projection reason and safe substitute view if any |
| `agent_boundary_violation` | agent had a tool, prompt, trace, or draft | steward, approver, escalation acceptor, action authority | leash evidence plus denied authority |
| `consequence_grade` | requested action is allowed under current packet evidence | broader action, future action, disclosure beyond projection, authority outside scope | subject binding; active charter/warrant/handoff; currentness; caveats; conflict/quorum; budget/privacy if relevant; projection proof |
| `refuse` | request should not proceed under current evidence | historical falsity of all inputs | refusal basis and safe next step if one exists |

## Closure rules

1. A state is not valid unless its weakness is visible.
2. A `routing_hint_only` state may use non-authority evidence as a basis; a `consequence_grade` state may not.
3. A break-glass basis must carry trigger, scope, expiry, allowed interim actions, post-hoc review, rollback, and review debt.
4. Public and external projections must not reveal sealed conflicts, reviewer identities, private org maps, incident details, or raw partner fragments.
5. A decision state should be small enough for Helm or SlopOS to render without copying the whole packet.

## Future pressure

A future governance decision event may reuse this matrix if at least three consumers need a portable state record. Until then, the matrix remains assurance guidance for fixtures and checkers.


## Pass LXXX event projection rule

A governance decision event may carry one matrix state only when it is digest-bound to a governance handoff packet and parity-checked against the packet's evaluated action. The event is a projection of the matrix state, not a new state source. If packet replay fails, the event downgrades to historical receipt or refusal context.
