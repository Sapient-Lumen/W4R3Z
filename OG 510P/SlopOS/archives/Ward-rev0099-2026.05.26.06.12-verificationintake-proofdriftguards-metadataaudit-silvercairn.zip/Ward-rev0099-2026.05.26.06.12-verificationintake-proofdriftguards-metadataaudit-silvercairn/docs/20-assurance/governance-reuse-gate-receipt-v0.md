# Governance reuse-gate receipt v0

Pass XCIV adds a reuse-gate receipt downstream of receiver convergence. It answers one question Ward could not answer in rev0093:

> Given a receiver-convergence result, what exact reuse is being requested, and is that reuse display-safe, review-safe, held for another receipt, or refused?

The receipt is deliberately not a grant, not a recertification, not an evidence-release receipt, not a handoff packet, and not a status-pointer update.

## Required binding

A reuse-gate receipt must bind:

- the referenced receiver-convergence receipt by path and byte digest;
- the source convergence state, recipient class, purpose, source release, signal key, subject digest, cache subject, receiver-set digest, overlap digest, and stale receiver count;
- the request id, requester class, requested purpose, consequence class, requested effect, recipient class, source release, cache subject, projection policy, and request window;
- a deterministic consequence-scope digest;
- refresh, evidence-release, packet-replay, and high-consequence fences;
- public projection safety and no-authority labeling;
- actual effects and forbidden effects.

## Valid states

- `display_reuse_allowed_refresh_required`
- `internal_review_reuse_allowed`
- `evidence_release_required_hold`
- `high_consequence_refused`
- `receiver_gap_quarantine_hold`
- `invalid_reuse_rejected`

## Required refusals

The checker rejects all of these collapses:

- source convergence digest drift;
- unchecked or missing source refs;
- purpose, recipient, release, signal, or cache-subject drift;
- convergence treated as authority;
- reuse gate treated as authority;
- export without an evidence-release receipt;
- high-consequence reuse without fresh packet replay;
- receiver gaps claimed as display-safe;
- dropped forbidden-effect fences;
- public receiver/status-channel leakage;
- missing no-authority labels;
- status-pointer mutation;
- unsupported or high-consequence actual effects;
- request-window inversion.

## Schema and checker

- Schema: `schemas/governance-reuse-gate-receipt.v0.json`
- Checker: `tools/check_governance_reuse_gates.py`
- Fixtures: `fixtures/governance-reuse-gate/`
