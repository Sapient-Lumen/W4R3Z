# Governance decision consumer receipt v0

A **governance decision consumer receipt** records how one downstream cube consumed one Ward governance decision event.

It exists because pass LXXX made decision events portable, and portability immediately creates a second laundering risk: a renderer, retention queue, recheck scheduler, CH-AREF attachment, search index, or agent transcript can preserve the event bytes while silently changing their force.

The receipt is explicitly not authority. It is a consumer-side accountability record saying: **I saw this event, I checked its digest and packet parity, I interpreted the state this weakly, I performed only these effects, I preserved these forbidden effects, and I know whether compaction/replay makes this historical.**

## Pressure from outside systems

OPA decision logs are useful because they carry enough query, input, bundle, and decision identity for audit and offline debugging (`EXT-OPA-DECISION-LOGS-2026`). CloudEvents makes event delivery and subscription portable (`EXT-CLOUDEVENTS-SPEC-2026`, `EXT-CLOUDEVENTS-SUBSCRIPTIONS-2026`). OpenTelemetry's event semantics say events should have stable names and structured attributes, while the 2026 span-event deprecation direction pushes standalone log-shaped events instead of ambiguous trace-only attachments (`EXT-OTEL-EVENT-SEMCONV-2026`, `EXT-OTEL-SPAN-EVENT-DEPRECATION-2026`). Compacted event streams can retain latest state while losing full history or tombstone context unless consumers respect retention windows and replay limits (`EXT-KAFKA-LOG-COMPACTION`, `EXT-CONFLUENT-KAFKA-LOG-COMPACTION-2026`).

Ward's response is narrower than any event platform: the consumer receipt proves a downstream interpretation did not widen one decision event.

## Required shape

Minimum fields:

- `schema = ward.governance-decision-consumer-receipt.v0`
- `receipt_name = ward.governance.decision.consumer-receipt.v0`
- `authority_surface = consumer_receipt_only`
- `consumer.cube`, `consumer.profile`, `consumer.operation`
- `event_ref.event_id`, `event_ref.event_path`, `event_ref.event_sha256`
- mirrored `packet_ref` from the event
- `replay_check.status`
- `state_interpretation.event_state`
- `state_interpretation.consumer_state`
- `state_interpretation.weakness_visible = true`
- `state_interpretation.non_authority_statement = true`
- `effect_closure.effects_performed`
- `effect_closure.effects_held`
- `effect_closure.forbidden_effects_preserved`
- `projection` safety flags
- `compaction_guard`

## Replay statuses

| Status | Meaning | Allowed posture |
|---|---|---|
| `replayed_current` | event digest and packet digest matched; event and packet checks ran | may perform effects allowed by the event, still scoped to the original packet action |
| `held_pending_packet` | event may be present but packet replay is unavailable or incomplete | no consequence effects; hold or route review |
| `downgraded_historical` | event is useful as history but not current authority | retain minimized receipt, render historical badge, record replay diff, or open review only |

## Consumer state rule

A consumer may keep the event state or downgrade it. It must never upgrade it.

Examples:

- `routing_hint_only` may remain `routing_hint_only` or become `review_only`; it may not become `consequence_grade`.
- `consequence_grade` may remain `consequence_grade` only after current replay; otherwise it downgrades to `historical_receipt_only`, `needs_rehydration`, `authority_missing`, or `review_only`.
- `historical_receipt_only` is not a decision-event state; it is a consumer receipt state for safe retention after replay loss.

## Effect closure

A receipt must name what the consumer did. This is intentionally mundane.

Allowed examples:

- Helm rendered an owner-hint badge and opened a review request.
- Harbor scheduled a recheck without implementing the correction.
- Schell retained a sealed-pointer summary and recorded review debt.
- SlopOS attached a CH-AREF pointer while preserving `identity_not_trust` semantics.

Forbidden examples:

- rendering a weak badge as approval;
- scheduling export from a routing hint;
- acting from an event when packet replay failed;
- dropping forbidden effects during minimization;
- treating a compacted survivor row as current authority.

## Compaction guard

If a decision-event stream is compacted, the receipt must show:

- source stream and consumer watermark;
- snapshot basis;
- whether tombstone retention was checked;
- delete/tombstone retention window;
- whether the event or supersession marker was compacted away;
- whether the materialized state is only historical.

A compacted-away event may not support current consequence. It may survive only as a historical receipt unless the packet and event can be replayed again from an authoritative source.

## Validator role

`tools/check_governance_decision_consumers.py` checks fixtures for:

- event digest and event-id parity;
- packet-ref mirroring;
- current replay requirements;
- state non-upgrade;
- weakness and non-authority labels;
- forbidden-effect preservation;
- projection leakage;
- compaction/tombstone guards;
- historical downgrade safety.
