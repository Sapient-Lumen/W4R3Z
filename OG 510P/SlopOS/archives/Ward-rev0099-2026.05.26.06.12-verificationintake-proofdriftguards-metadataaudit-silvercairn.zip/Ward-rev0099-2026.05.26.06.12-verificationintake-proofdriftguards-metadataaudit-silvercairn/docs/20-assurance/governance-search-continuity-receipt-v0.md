# Governance search continuity receipt v0

Pass LXXXIII adds a search-continuity receipt around paginated, long-running, or cross-boundary governance searches.

This receipt is **not** a search protocol and not a grant. It is a refusal harness for the moment where a user, agent, export job, or downstream cube says “continue page two” after enough time has passed for owner maps, projection policy, packet replay state, or compaction watermarks to change.

## Why this exists

The pass LXXXII batch/search receipt proved that one page or one batch can preserve member state. It did not yet prove that **page two** is still part of the same safe result set.

External pressure is sharp here:

- AuthZEN Search APIs warn that pagination is not an atomic snapshot; repeated or omitted entries can appear when the underlying data changes, and subsequent requests must keep entities and pagination parameters identical (`EXT-AUTHZEN-AUTHORIZATION-API-2026`).
- Kafka-style compacted logs can drop tombstones after retention windows, making late consumers miss deletion evidence and weakening current replay (`EXT-CONFLUENT-KAFKA-LOG-COMPACTION-2026`).
- NIST SP 800-226 pressures aggregate privacy claims: a noisy or minimized count is only meaningful when the surrounding query model, side-channel posture, access control, and privacy-loss accounting remain explicit (`EXT-NIST-SP-800-226-DP-2025`).
- CloudEvents trace/correlation material helps connect pages, but correlation is still not authority (`EXT-CLOUDEVENTS-DISTRIBUTED-TRACING-2026`).

## Non-authority invariant

A governance search-continuity receipt may:

- chain page receipts by digest;
- say a cursor still names the same search basis;
- require a recheckpoint when owner-map, projection-policy, or compaction state changed;
- disclose that sealed/restricted rows exist without revealing exact counts or sensitive details to broad audiences;
- preserve partial-result and gap semantics across pages.

It must not:

- let a cursor continue after semantic drift while pretending nothing changed;
- hide omitted sealed rows behind “complete” result language;
- disclose exact sealed counts in public/external views;
- turn a continuation event into export, action, repair, remedy, learning, or budget authority;
- use trace IDs, page tokens, or row counts as authority.

## Required checks

A valid v0 receipt proves these closure properties:

1. **Page digest closure** — current and prior page receipts resolve to valid governance batch/search receipts by path, ID, and SHA-256 digest.
2. **Cursor basis closure** — query digest, request fingerprint, projection policy digest, owner-map epoch, and packet-compaction watermark are named and compared.
3. **Same-snapshot closure** — a claimed continuation is allowed only when all basis fields remain unchanged, the prior digest is chained, and no drift is detected.
4. **Drift response closure** — when any basis changed, the receipt must hold, recheckpoint, or start a new search; it cannot claim a same continuation.
5. **Sealed omission closure** — sealed rows may be disclosed by absence, presence-only, bucketed range, or differentially-private/noisy count, never by exact public count or raw details.
6. **No existence-oracle closure** — public/external views must set an explicit existence-oracle guard, redact details, avoid per-subject breakdowns, and avoid sensitive reason classes.
7. **Completeness closure** — a result with projection/replay/sealed omissions cannot claim complete authority coverage.
8. **Effect closure** — continuation may render, request review, or retain a minimized receipt; all high-consequence effects remain forbidden.

## v0 continuity states

`drift_response.state` is deliberately small:

- `continued_same_snapshot` — safe same-basis continuation;
- `held_recheckpoint_required` — the result must stop until current page material is rechecked;
- `new_receipt_issued` — a drift-aware new receipt replaced the old continuation claim;
- `new_search_required` — drift is too large for a continuation.

## Sealed omission modes

`sealed_omissions.disclosure_mode` may be:

- `none` — no sealed omission known;
- `presence_only` — says restricted rows exist, without exact count or row detail;
- `bucketed_range` — gives coarse bounded ranges only when bucket size is large enough and no row detail leaks;
- `dp_noisy_count` — gives a noisy count only with privacy unit, privacy-budget reference, noise model, epsilon cap, composition window, and no exact-count fallback.

## Promotion rule

Do not promote this into a durable Ward noun until SlopOS can show a long-running search, Helm can render a held continuation without confusing users, Schell/ViewFS can minimize sealed omission disclosure, and Harbor/Foundry can treat cross-page drift as review debt rather than action authority.

## Fixtures

Positive fixtures:

- `fixtures/governance-search-continuity/same-snapshot-page-two.valid.json`
- `fixtures/governance-search-continuity/projection-policy-change-held.valid.json`
- `fixtures/governance-search-continuity/public-sealed-omission-bucket.valid.json`
- `fixtures/governance-search-continuity/internal-exact-sealed-review.valid.json`
- `fixtures/governance-search-continuity/packet-compaction-recheckpoint.valid.json`

Negative fixtures live under `fixtures/governance-search-continuity/negative/` and cover continuation after drift, exact public sealed counts, sealed detail leakage, query mutation, digest mismatch, hidden omissions, missing existence-oracle guards, DP claims without budget, authority-count collapse, and high-consequence continuation effects.
