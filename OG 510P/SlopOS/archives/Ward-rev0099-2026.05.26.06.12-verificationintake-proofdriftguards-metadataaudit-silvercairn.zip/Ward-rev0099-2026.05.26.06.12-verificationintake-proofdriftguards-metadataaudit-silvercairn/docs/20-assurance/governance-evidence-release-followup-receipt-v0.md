# Governance evidence-release follow-up receipt v0

`ward.governance.evidence-release-followup-receipt.v0` is a **non-authority lifecycle receipt** for one previously issued evidence-release receipt.

It answers:

> Has a released governance-evidence bundle been acknowledged, refreshed, corrected, revoked, quarantined, or refused for reuse without mutating the original release receipt?

It does not approve action, repair, remedy, learning use, budget spend, delegation, export expansion, or privacy waiver.

## Required posture

Every follow-up receipt must preserve eight checks:

1. **Release binding** — the source evidence-release receipt is referenced by id, path, and SHA-256 digest.
2. **Source-state mirroring** — decision state, expiry, recipient class, purpose, item digest, and projection-policy digest mirror the source release.
3. **Trigger basis** — expiry, drift, correction, misuse, recheck failure, or no-drift acknowledgment is explicit and timestamped.
4. **Recipient notice** — notification channel, recipient, purpose, and no-authority label are preserved.
5. **Acknowledgment state** — recipient acknowledgments are recorded without becoming acceptance of authority.
6. **Status pointer** — revocation, correction, quarantine, reuse refusal, and refresh notices carry a status pointer and stale-artifact label.
7. **Immutable original** — the original release receipt is not edited in place.
8. **Effect closure** — only safe lifecycle effects are allowed; source forbidden effects remain preserved.

## Positive states

- `ack_recorded` — the recipient acknowledged receipt; no authority was granted.
- `release_still_current` — a refresh check found no drift and the source release has not expired.
- `refresh_notice_issued` — a non-authority refresh notice was sent.
- `revocation_issued` — the released bundle is no longer usable as current evidence.
- `correction_issued` — the released bundle has a correction notice or replacement path.
- `stale_bundle_quarantined` — cached or forwarded copies should be quarantined pending replay.
- `reuse_refused` — a downstream request to reuse the release without refresh was refused.
- `followup_held_recheck_required` — follow-up cannot complete until replay/recheck succeeds.

## Checker scope

`tools/check_governance_evidence_release_followups.py` validates:

- referenced release digest and validity;
- mirrored source release state;
- trigger timing and drift class;
- recipient notice and acknowledgment posture;
- status pointers, stale labels, and correction deltas;
- public follow-up minimization;
- original-release immutability;
- forbidden-effect preservation and no high-consequence follow-up effects.

The checker is a refusal harness for post-release lifecycle failures. It is not an authorization engine.
