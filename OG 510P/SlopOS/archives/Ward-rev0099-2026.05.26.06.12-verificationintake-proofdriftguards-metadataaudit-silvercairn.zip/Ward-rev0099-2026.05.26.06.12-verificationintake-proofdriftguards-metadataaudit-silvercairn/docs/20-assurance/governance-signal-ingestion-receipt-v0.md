# Governance signal-ingestion receipt v0

A governance signal-ingestion receipt records how Ward observed and locally arbitrated one incoming status, refresh, revocation, quarantine, successor, branch, or projection-policy signal against a cached governance recertification receipt.

It is **not** a grant, not an approval, not a repaired status head, and not proof that every consumer refreshed.

## Required binding

A receipt must bind:

- the source recertification receipt id, byte digest, state, source release, recipient class, purpose, projection policy digest, and cache-subject digest;
- the signal envelope, including stream id, signal source, signal id, event key, delivery mode, delivery channel, sequence/watermark, subject, subject digest, and envelope digest;
- the receiver observation, including authentication, digest checks, duplicate-window check, watermark check, replay-window check, projection-payload check, and local policy application;
- the arbitration context, including prior event keys, accepted event keys, conflict set, duplicate relation, high watermark, and correlation scope;
- the payload classification and cache action requested;
- the follow-up binding that says whether recertification, cache invalidation, or conflict hold is required;
- projection safety and forbidden-effect closure.

## Valid states

- `signal_accepted_for_recertification`
- `duplicate_signal_ignored`
- `stale_signal_ignored`
- `conflicting_signals_held`
- `irrelevant_signal_ignored`
- `invalid_signal_rejected`

## Invariants

- Push acknowledgement is not consumer refresh.
- Poll delivery order is not causal order.
- Duplicate delivery is not a second basis change.
- A stale signal cannot revive an old head.
- Conflicting signals do not pick a winner without a later dispute/recheck receipt.
- Signal ingestion never mutates the source recertification receipt.
- A signal can request recertification or invalidation, but cannot grant authority.
- Public projection never reveals sealed payloads, private stewards, private contacts, exact hidden counts, reviewer identities, or raw partner fragments.
