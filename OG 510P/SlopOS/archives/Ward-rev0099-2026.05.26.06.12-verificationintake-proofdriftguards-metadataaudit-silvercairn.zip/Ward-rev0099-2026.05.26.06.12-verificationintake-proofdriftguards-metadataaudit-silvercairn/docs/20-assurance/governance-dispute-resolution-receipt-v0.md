# Governance dispute-resolution receipt v0

A governance dispute-resolution receipt records how Ward resolved, held, or minimized a previously disputed governance receipt chain.

It is downstream of the governance chain-integrity receipt. It is not a new release, not a new follow-up, not a new transfer, not a delegation warrant, not a status authority, and not an authorization grant.

## Required bindings

A v0 receipt binds:

- one source governance chain-integrity receipt by id, path, byte digest, source chain digest, observed state, source release, recipient, purpose, source item, projection policy, fork state, and branch count;
- one resolution scope: fork resolution, successor-acceptance resolution, quarantine sustainment, historical minimization, or recheck resolution;
- an observed branch set and deterministic branch-set digest;
- selected branch id only when a current status head is recovered;
- branch dispositions for every observed branch;
- resolver independence, conflict disclosure, current-status recheck, successor acceptance, old-channel invalidation, and no-source-mutation checks;
- notification evidence to affected recipients and old/new status channels;
- public/restricted projection safety;
- no-authority watermarking;
- forbidden-effect preservation.

## Decision states

Allowed v0 states are:

- `current_head_recovered`;
- `quarantine_sustained`;
- `successor_resolution_pending`;
- `historical_resolution_recorded`;
- `resolution_recheck_required`.

A recovered head is still only a status/recheck pointer. Reuse requires refresh and source-packet replay. A quarantine sustainment publishes no current head. A historical resolution is inspectable but not spendable.

## Forbidden collapses

The checker rejects:

- source chain digest mismatch;
- dispute-resolution over an already canonical source chain;
- missing source chain digest;
- selected branches outside the observed branch set;
- branch-set digest mismatch;
- losing-branch reuse;
- public sealed branch leakage or exact hidden branch counts;
- missing recipient notice;
- missing no-authority label;
- high-consequence effects;
- dropped forbidden-effect fences;
- purpose drift;
- old status channel reuse;
- source chain mutation;
- recovered current head without successor acceptance/current recheck;
- quarantine state that publishes a current head.

## Product line

Render a recovered head as:

> “Dispute resolved. Current status pointer recovered. Not authority. Refresh and replay the source packet before reuse.”

Render a sustained hold as:

> “Dispute unresolved or quarantine sustained. No current head. Do not reuse this release.”
