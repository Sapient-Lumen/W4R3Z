# Governance outcome-observation receipt v0

Pass XCVI adds an outcome-observation receipt downstream of use-execution receipts. It answers one question rev0095 intentionally left open:

> A gate said what could be used, and a use-execution receipt said what a consumer attempted. What was actually observed afterward, and did the observed outcome match the execution receipt?

The receipt is deliberately not authority, not a recertification, not an evidence-release receipt, not a rollback grant, and not a status-pointer update.

## Required binding

An outcome-observation receipt must bind:

- the referenced use-execution receipt by path and byte digest;
- the source execution state, execution id, actual effect, recipient class, projection policy, target, window, and actual-effect digest;
- the observer class, observation window, observed effect, observed target, observed recipient class, observed projection policy, and observed-outcome digest;
- whether the outcome matched, was unavailable, confirmed a no-op, or exposed a discrepancy;
- quarantine and rollback-review requirements for unsafe discrepancies;
- public projection and no-authority labels;
- forbidden-effect fences for observation-as-authority, hidden mismatch, unreviewed rollback, export, repair, remedy, learning use, and status-pointer mutation.

## Valid states

- `observed_public_display_matched_refresh_required`
- `observed_internal_review_matched_refresh_required`
- `observed_noop_hold_confirmed`
- `observed_mismatch_quarantined_rollback_required`
- `observation_unavailable_held_no_claim`
- `invalid_outcome_observation_rejected`

## Required refusals

The checker rejects these collapses:

- source use-execution digest drift or unchecked source references;
- observed effect, target, recipient, projection, or time-window drift;
- an unavailable observation claimed as matched;
- a mismatch that is not quarantined or does not require rollback review;
- public receiver identity, sealed payload, private org map, or raw partner leakage;
- missing no-authority labels;
- source receipt mutation or status-pointer mutation;
- high-consequence outcome effects;
- dropped forbidden-effect fences;
- treating observation success as authority, recertification, export permission, repair power, or remedy power.

## Schema and checker

- Schema: `schemas/governance-outcome-observation-receipt.v0.json`
- Checker: `tools/check_governance_outcome_observations.py`
- Fixtures: `fixtures/governance-outcome-observation/`
