# Governance batch/search receipt v0

Pass LXXXII adds a small batch/search receipt around governance decision consumer receipts.

This receipt is **not** a new authority source. It is a reconciliation surface for the dangerous moment when several already-consumed Ward governance decisions are shown together, filtered together, paginated together, summarized together, or attached to a batch review packet.

## Why this exists

Single-event receipts are relatively easy to keep honest. Batch and search surfaces are where Ward can lose its refusal discipline:

- a routing hint, a current consequence-grade receipt, and a historical-only receipt can be collapsed into one green count;
- a public search row can accidentally include restricted break-glass or sealed conflict material;
- pagination can hide that some rows were omitted because projection or replay failed;
- a search result can be misread as a complete authority set;
- a batch summary can preserve event IDs while dropping forbidden-effect fences.

External pressure is consistent with this split. AuthZEN names both multiple access evaluations and search APIs, and warns that search pagination may repeat or omit entries unless token scope remains identical (`EXT-AUTHZEN-AUTHORIZATION-API-2026`). OpenFGA's relationship-query surface similarly distinguishes check/read/expand/list-object shapes rather than treating a list as a grant (`EXT-OPENFGA-RELATIONSHIP-QUERIES-2026`). OPA decision logs remain audit/debug events rather than grants (`EXT-OPA-DECISION-LOGS-2026`). CloudEvents and tracing pressure give Ward useful correlation vocabulary but no authority semantics (`EXT-CLOUDEVENTS-SPEC-2026`, `EXT-CLOUDEVENTS-DISTRIBUTED-TRACING-2026`).

## Non-authority invariant

A governance batch/search receipt may:

- render multiple consumer receipts;
- open review requests;
- retain minimized batch summaries;
- record replay-diff summaries;
- preserve per-member state, projection class, forbidden effects, and replay posture.

It must not:

- create a new approval;
- transform a member receipt into a stronger state;
- claim an aggregate authority count;
- hide mixed states behind one green badge;
- perform high-consequence effects across a mixed or non-current set;
- make public projections of restricted or sealed member rows.

## Required checks

A valid v0 receipt has to prove these closure properties:

1. **Member digest closure**: every member references a valid governance decision consumer receipt by path, ID, and SHA-256 digest.
2. **Mirror closure**: member state, replay status, projection class, projection view, downgrade reasons, and forbidden-effect fences mirror the referenced consumer receipt.
3. **Mixed-state closure**: if member states differ, the aggregate result state is `mixed_visible` or `held_partial`; never `all_current_consequence_grade`.
4. **No single green badge**: `no_single_badge=true`, `mixed_state_visible=true`, and `no_authority_upgrade=true` are required even when all members are current.
5. **Forbidden-effect union closure**: the aggregate union exactly equals the member union; a batch cannot drop a forbidden effect because it is inconvenient to render.
6. **Projection join closure**: the join mode is `least_privilege_join`; projection classes are preserved and the weakest class remains visible.
7. **Public projection closure**: public/external views cannot include restricted member rows or inline sensitive evidence.
8. **Pagination/gap closure**: search results disclose projection/replay omissions and bind cursors to the query digest.
9. **Replay boundary closure**: aggregate currentness is not invented; the receipt names per-member currentness and compaction posture.
10. **Aggregate-effect closure**: aggregate effects remain in the safe batch set unless all members are current consequence-grade, and high-consequence effects are never performed by the aggregate.

## v0 states

`aggregation.result_state` is deliberately small:

- `mixed_visible` — members differ, and the difference is visible;
- `all_current_consequence_grade` — every member is current and consequence-grade, but effects remain per-member;
- `all_routing_hint_only` — every member is route-only;
- `historical_only` — no current authority remains;
- `held_partial` — the batch/search result is present but cannot be acted on because at least one member is held, stale, omitted, or unreplayed.

## Promotion rule

Do not promote this receipt into a durable Ward noun until at least one SlopOS, one Helm, one Harbor, one Schell/ViewFS, and one Foundry/Steward consumer can read it without making a mixed set look stronger than its weakest actionable member.

## Fixtures

Positive fixtures:

- `fixtures/governance-batch-search/mixed-governance-search-visible.valid.json`
- `fixtures/governance-batch-search/public-owner-routing-search.valid.json`
- `fixtures/governance-batch-search/current-consumer-batch-safe.valid.json`
- `fixtures/governance-batch-search/restricted-breakglass-and-history-mix.valid.json`

Negative fixtures live under `fixtures/governance-batch-search/negative/` and cover green-badge collapse, member-state upgrades, dropped forbidden effects, public restricted-member leakage, missing partial-result disclosure, unbound cursors, aggregate high-consequence effects, digest mismatch, hidden downgrade reasons, raw authority counts, projection-class collapse, and unchecked member digests.
