# Governance chain-integrity receipt v0

A governance chain-integrity receipt records one evaluated lineage of already-issued Ward governance receipts.

It is downstream of evidence-release receipts, evidence-release follow-up receipts, and succession/transfer receipts. It is not a new release, not a follow-up, not a transfer, not a delegation warrant, not a status authority, and not an authorization grant.

## Required bindings

A v0 receipt binds:

- one source release id, source item digest, recipient class, purpose, and projection-policy digest;
- an ordered list of release, follow-up, and transfer receipt members;
- each member's path, byte digest, role, observed state, observed time, source release, recipient, purpose, projection policy, source item digest, and forbidden-effect set;
- a deterministic ordered chain digest over member ids and member byte digests;
- member digest checks, dependency checks, source-release parity, purpose/recipient parity, projection-policy parity, and source-item parity;
- transfer latest-follow-up dependency order;
- old-status-channel invalidation posture;
- a canonical head or an explicit no-current-head fork hold;
- public/restricted projection safety;
- no-authority watermarking;
- forbidden-effect preservation.

## Decision states

Allowed v0 states are:

- `canonical_head_recorded`;
- `revoked_head_recorded`;
- `successor_pending_recheck`;
- `fork_detected_hold`;
- `disputed_head_quarantined`;
- `chain_recheck_required`;
- `historical_minimized`.

A canonical head is never authority. It only says which already-issued downstream receipt is the current status pointer for recheck. Forked or disputed chains must hold reuse until the branch conflict is resolved.

## Forbidden collapses

The checker rejects:

- byte-digest mismatch for any lineage member;
- missing deterministic chain digest;
- unchecked members;
- follow-up or transfer members bound to a different source release;
- hidden purpose/recipient/source-item drift;
- forked branches treated as canonical;
- public release of private branch or steward evidence;
- missing no-authority labels;
- high-consequence chain effects;
- dropped forbidden-effect fences;
- canonical heads that are not latest transfer members;
- old status channels left current;
- noncanonical branch reuse;
- nonmonotonic lineage ordering.

## Product line

Render a chain-integrity receipt as:

> “Chain integrity recorded. Not authority. Refresh current status and replay the source packet before reuse.”

For a forked chain, render:

> “Fork detected. No current head. Hold reuse until a new chain-integrity receipt resolves the branch.”
