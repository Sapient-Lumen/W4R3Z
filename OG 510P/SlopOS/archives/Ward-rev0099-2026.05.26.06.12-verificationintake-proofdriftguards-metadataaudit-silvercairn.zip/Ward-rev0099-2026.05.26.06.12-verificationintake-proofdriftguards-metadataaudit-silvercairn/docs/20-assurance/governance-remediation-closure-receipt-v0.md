# Governance remediation-closure receipt v0

Pass XCVIII adds a remediation-closure receipt downstream of rollback-remediation receipts. It answers one question rev0097 intentionally left open:

> The rollback/remediation path opened review, requested handoff, closed no-remediation-needed, or held unavailable observation. What closure state can Ward record without claiming rollback, remedy, repair, export, or authority?

## Required binding

A remediation-closure receipt must bind:

- the referenced rollback-remediation receipt by path and byte digest;
- the source remediation state, remediation id, source observation id, target, recipient class, projection policy, review state, review-handoff digest, remediation quarantine state, and no-authority label;
- the closure scope, requested closure effect, consequence class, time window, and scope digest;
- verification evidence and verification-evidence digest;
- planned safe effects and forbidden-effect fences;
- public projection minimization and no-authority watermark;
- explicit verification debt and next recheck timing.

## Valid states

- `no_remediation_closure_confirmed_refresh_required`
- `noop_closure_confirmed_refresh_required`
- `rollback_review_closed_quarantine_sustained`
- `remediation_handoff_acknowledged_external_proof_required`
- `unavailable_observation_escalated_still_held`
- `invalid_remediation_closure_rejected`

## Required refusals

The checker rejects:

- source rollback-remediation digest drift, unchecked source refs, ghost source paths, or mirror mismatch;
- target, recipient, projection, state, scope, or verification-evidence digest drift;
- review closure that clears quarantine;
- handoff acknowledgment treated as remedy completion;
- external remedy proof or rollback execution verified inside the closure receipt;
- source rollback-remediation, outcome-observation, or use-execution mutation;
- status-pointer mutation;
- public leakage of sealed outcome payloads, reviewer identity, status-channel internals, private org maps, or partner fragments;
- missing no-authority labels;
- high-consequence planned effects such as rollback, repair, remedy, export, learning use, budget spend, quarantine clearance, or action re-enable.

## Why closure remains small

The receipt can close the bookkeeping loop for review/no-op/handoff/unavailable states, but it does not say that the remedy occurred. External remedy proof should become a separate intake surface only after Ward can bind external implementation/recheck receipts without granting ambient authority.

## Schema and checker

- Schema: `schemas/governance-remediation-closure-receipt.v0.json`
- Checker: `tools/check_governance_remediation_closures.py`
- Fixtures: `fixtures/governance-remediation-closure/`
