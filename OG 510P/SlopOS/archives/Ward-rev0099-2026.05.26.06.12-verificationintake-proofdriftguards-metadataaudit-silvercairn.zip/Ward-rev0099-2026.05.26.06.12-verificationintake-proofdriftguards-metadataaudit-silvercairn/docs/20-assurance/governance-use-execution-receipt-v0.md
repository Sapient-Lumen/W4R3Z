# Governance use-execution receipt v0

Pass XCV adds a use-execution receipt downstream of reuse gates. It answers one question Ward could not answer in rev0094:

> A reuse gate allowed, held, or refused a bounded use. What actually happened at the consuming surface, and did that actual effect stay inside the gate?

The receipt is deliberately not authority, not a fresh handoff packet, not a recertification, not an evidence-release receipt, and not a status-pointer update.

## Required binding

A use-execution receipt must bind:

- the referenced reuse-gate receipt by path and byte digest;
- the source gate state, requested purpose, consequence class, effect, recipient class, projection policy, request window, and consequence-scope digest;
- the actual execution id, actor class, actual purpose, consequence class, effect, recipient class, projection policy, target, and execution window;
- an actual-effect digest;
- public projection and no-authority labels;
- whether execution was performed, held, refused, or quarantined;
- forbidden-effect fences for authority upgrade, export, repair, remedy, learning use, status-pointer mutation, and public leakage.

## Valid states

- `executed_public_display_refresh_required`
- `executed_internal_review_refresh_required`
- `held_no_execution_evidence_release_required`
- `refused_noop_high_consequence`
- `quarantined_no_execution_receiver_gap`
- `invalid_use_execution_rejected`

## Required refusals

The checker rejects these collapses:

- source gate digest drift or unchecked source references;
- actual purpose/effect/recipient/projection drift;
- use outside the source gate window;
- public receiver identity, sealed payload, or private org leakage;
- missing no-authority labels;
- status-pointer mutation;
- high-consequence actual effects;
- dropped forbidden-effect fences;
- executed holds, executed refusals, and executed receiver-gap quarantines;
- actual-effect digest mismatch.

## Schema and checker

- Schema: `schemas/governance-use-execution-receipt.v0.json`
- Checker: `tools/check_governance_use_executions.py`
- Fixtures: `fixtures/governance-use-execution/`
