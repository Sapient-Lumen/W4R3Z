# Governance decision event v0

A **governance decision event** is a small, portable, derived record of one evaluated action from a governance handoff packet.

It exists because downstream cubes need a compact thing to render, retain, recheck, attach, and correlate without copying the entire packet. It is explicitly not a grant, not a policy object, not a ticket, not an approval token, and not an authority source.

## Pressure from outside systems

OPA decision logs show the usefulness of event records that carry decision IDs, policy/query context, inputs, bundle metadata, and enough material for audit and offline debugging (`EXT-OPA-DECISION-LOGS-2026`). CloudEvents pressures Ward toward a source/type/id/subject/time envelope that can move between services without custom folklore (`EXT-CLOUDEVENTS-SPEC-2026`). OpenTelemetry's logs model and event semantics pressure Ward to keep event names stable, put structured details in attributes, and avoid treating a free-form body as semantic authority (`EXT-OTEL-LOGS-DATA-MODEL-2026`, `EXT-OTEL-EVENT-SEMCONV-2026`). AuthZEN reminds Ward that subject/action/resource/context decisions are request-scoped PDP/PEP coordination, not ambient cube authority (`EXT-AUTHZEN-AUTHORIZATION-API-2026`).

Ward's response is narrower: one decision event may summarize one packet action, but only packet proof can make an effect consequence-grade.

## Required event shape

Minimum fields:

- `schema = ward.governance-decision-event.v0`
- `event_name = ward.governance.decision.v0`
- `event_time`
- `authority_surface = derived_receipt_only`
- `packet_ref.packet_id`
- `packet_ref.packet_path`
- `packet_ref.packet_sha256`
- `evaluated_action_ref.actor`
- `evaluated_action_ref.action`
- `evaluated_action_ref.posture`
- `decision.state`
- `decision.basis`
- `decision.reason`
- `decision.proof_summary`
- `projection.view`
- `projection.projection_class`
- `projection.contains_sensitive_evidence`
- `projection.sealed_evidence_inline`
- `forbidden_effects`
- `consumer_profile`

Optional fields include CloudEvents/OpenTelemetry-shaped correlation, retention/minimization posture, Harbor recheck windows, SlopOS CH-AREF attachments, and OPA/AuthZEN-like request or decision IDs.

## Parity rules

A decision event is valid only if:

1. the referenced packet exists and its digest matches;
2. the referenced packet id matches `packet_ref.packet_id`;
3. the referenced actor/action exists in `evaluated_actions`;
4. `decision.state` and `evaluated_action_ref.posture` match the packet posture;
5. the event states `authority_surface = derived_receipt_only`;
6. consequence-grade events include the evaluated action in allowed effects and summarize all proof obligations;
7. public and external projections carry no sensitive governance evidence and no inline sealed material;
8. break-glass events occur before emergency expiry and carry review-debt posture;
9. required forbidden effects are present: broader-scope reuse, future-action reuse, unprojected disclosure, and authority reuse without packet;
10. consumer-specific fields are present when the profile claims Helm, Schell, Harbor, or SlopOS use.

## Consumer profiles

### Helm rendering

Helm may render a `routing_hint_only`, `review_only`, `authority_missing`, or `consequence_grade` badge, but the rendered copy must preserve weakness. An owner hint can become a contact affordance. It must not become export, remedy, privacy, budget, repair, or action authority.

### Schell minimization and expiry

Schell may retain the event as a minimized receipt while sealing or forgetting raw governance evidence. The event may carry CH-AREF-like sealed pointers, expiry, review debt, and projection class. It must not inline private org maps, reviewer identities, incident details, raw partner fragments, or sealed conflict material in a public/external view.

### Harbor recheck

Harbor may use the event to open or schedule a recheck window after correction, recompute, export hold, or public-surface repair. The event records what recheck is needed; it does not itself implement the correction.

### SlopOS CH-AREF attachment

SlopOS may attach a governance decision event to a content-addressed artifact reference. The CH-AREF relation proves identity and replay attachment, not trust. A valid digest pointer still does not imply semantic authority, currentness, or permission.

## Negative rule

If a decision event and a packet disagree, the packet wins and the event is invalid. If the packet is unavailable, stale, digest-mismatched, or redacted beyond parity, the event downgrades to a non-authoritative historical receipt.
