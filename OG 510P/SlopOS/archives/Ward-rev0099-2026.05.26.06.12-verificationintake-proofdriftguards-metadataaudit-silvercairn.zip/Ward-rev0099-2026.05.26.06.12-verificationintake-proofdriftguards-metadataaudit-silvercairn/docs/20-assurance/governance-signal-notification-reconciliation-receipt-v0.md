# Governance signal-notification reconciliation receipt v0

Pass XCII adds a reconciliation receipt downstream of signal-notification receipts. It answers one question Ward could not answer in rev0091:

> After a governance signal was notified to consumers, which consumers actually produced local refresh/recertification evidence, which remain quarantined, and which observations are still only delivery or acknowledgment facts?

The receipt is deliberately not a grant, not a status pointer, not a consumer refresh by itself, and not an authorization decision. It is a reconciliation record for the notification fanout produced in rev0091.

## Required binding

A reconciliation receipt must bind:

- the exact source signal-notification receipt bytes and digest;
- the source signal event key and subject digest;
- the source release, recipient class, purpose, and cache-subject digest;
- the affected-consumer set digest from the notification receipt;
- one refresh observation for every affected required consumer;
- any consumer recertification receipt bytes used as proof of local refresh;
- quarantine pointers for missing, pending, or dead-lettered consumers;
- conflict-hold pointers when no winner may be selected;
- a public projection that does not reveal consumer identities, sealed payloads, private contacts, or exact hidden counts.

## Valid states

- `all_consumers_recertified_refresh_required`
- `partial_recertification_quarantined`
- `dead_letter_reconciliation_quarantined`
- `duplicate_reconciliation_suppressed`
- `conflict_reconciliation_held`
- `invalid_reconciliation_rejected`

The states are about reconciliation posture only. They do not permit action, export, repair, learning use, remedy, delegation, or current-head mutation.

## Required refusals

The checker rejects all of these collapses:

- source notification digest drift;
- affected-consumer set drift;
- expected-consumer count inflation;
- notification-state mismatch;
- acknowledgment treated as refresh;
- delivery acknowledgment treated as consumer-local refresh;
- missing recertification receipts claimed as local refresh;
- recertification receipt digest or subject mismatch;
- dead-lettered consumers treated as reconciled;
- duplicate notifications promoted to fresh refresh;
- conflict holds selecting a winner;
- partial reconciliation claimed complete;
- public consumer identity leakage;
- sealed signal, notification, or recertification payload leakage;
- missing no-authority labels;
- status-pointer mutation or high-consequence effects.

## Why this is separate from notification

SET push and poll delivery distinguish delivery from recipient-local processing, and Shared Signals separates transmitter/receiver event exchange from local policy response. CloudEvents also treats source/id identity as event identity and duplicate posture rather than proof of downstream application. Ward therefore keeps notification, acknowledgment, reconciliation, and local recertification as separate residues. See `EXT-RFC-8935`, `EXT-RFC-8936`, `EXT-OPENID-SSF-2025`, and `EXT-CLOUDEVENTS-SPEC-2026`.

## Schema and checker

- Schema: `schemas/governance-signal-notification-reconciliation-receipt.v0.json`
- Checker: `tools/check_governance_signal_notification_reconciliations.py`
- Fixtures: `fixtures/governance-signal-notification-reconciliation/`
