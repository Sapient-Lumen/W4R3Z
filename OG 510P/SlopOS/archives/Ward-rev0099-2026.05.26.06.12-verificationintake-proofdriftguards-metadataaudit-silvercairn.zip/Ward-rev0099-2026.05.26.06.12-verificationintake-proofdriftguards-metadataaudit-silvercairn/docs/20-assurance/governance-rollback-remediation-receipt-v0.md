# Governance rollback-remediation receipt v0

Pass XCVII adds a rollback-remediation receipt downstream of outcome-observation receipts. It answers one question rev0096 intentionally left open:

> Ward observed that an execution matched, no-opped, was unavailable, or mismatched. What rollback, remediation, review, or handoff posture is now safe to record without mutating the observed history or granting remedy authority?

The receipt is deliberately not a rollback executor, not a remedy receipt, not a Harbor correction implementation, not a Helm intervention, not a status-pointer update, and not a substitute for a governance handoff packet.

## Required binding

A rollback-remediation receipt must bind:

- the referenced outcome-observation receipt by path and byte digest;
- the source outcome state, observation id, observed target, observed effect, recipient class, projection policy, observed-outcome digest, and no-authority label;
- the remediation scope, requested remediation effect, consequence class, time window, and scope digest;
- whether no remediation is needed, rollback review was opened, remediation handoff was requested, or the case is held because observation was unavailable;
- whether quarantine is maintained when the source observation mismatched;
- whether recipient notice was required and sent for mismatch review/handoff postures;
- forbidden-effect fences for rollback execution, remedy, repair, semantic repair, export, learning use, source mutation, status-pointer mutation, and authority laundering.

## Valid states

- `no_remediation_needed_match_refresh_required`
- `noop_hold_no_remediation_needed`
- `rollback_review_opened_quarantine_maintained`
- `remediation_handoff_requested_no_action`
- `observation_unavailable_hold_no_remediation`
- `invalid_rollback_remediation_rejected`

## Required refusals

The checker rejects these collapses:

- source outcome-observation digest drift, unchecked source refs, or ghost source paths;
- target, recipient, projection, state, or remediation-scope digest drift;
- matched observations that open rollback review anyway;
- mismatches that do not maintain quarantine or do not open review / request handoff;
- handoff requests treated as completed remedies;
- rollback execution without a separate authority receipt;
- source outcome/use-execution mutation or status-pointer mutation;
- public receiver identity, sealed outcome payload, raw partner, or private org leakage;
- missing no-authority labels;
- high-consequence planned effects such as repair, semantic repair, export, learning use, budget spend, or action re-enable.

## Why it is not a remedy receipt

A mismatch can require rollback review and can request a remedy handoff, but the receipt does not itself repair the answer, execute rollback, release evidence, or update current status. That split is intentional. Ward can say **a remedy path is necessary** while still refusing to say **this actor may remedy now**.

## Schema and checker

- Schema: `schemas/governance-rollback-remediation-receipt.v0.json`
- Checker: `tools/check_governance_rollback_remediations.py`
- Fixtures: `fixtures/governance-rollback-remediation/`
