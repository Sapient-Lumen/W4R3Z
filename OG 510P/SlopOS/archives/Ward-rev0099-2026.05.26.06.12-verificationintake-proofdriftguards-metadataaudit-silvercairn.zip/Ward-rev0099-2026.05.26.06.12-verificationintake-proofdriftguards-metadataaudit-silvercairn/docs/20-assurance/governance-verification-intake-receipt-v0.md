# Governance verification-intake receipt v0

Pass XCIX adds a verification-intake receipt downstream of remediation-closure receipts. It answers the seam rev0098 deliberately left open:

> A closure recorded that external proof was required, absent, or unnecessary. What later proof can Ward intake without pretending proof intake is authority, remedy completion, rollback, export, or quarantine clearance?

## Required binding

A verification-intake receipt binds:

- the referenced remediation-closure receipt by path and byte digest;
- the source closure state, closure id, source remediation id, target, recipient class, projection policy, closure-scope digest, closure-evidence digest, external-proof requirement, closure finality, quarantine posture, and no-authority label;
- the verification scope, proof source class, proof channel, proof subject digest, requested verification effect, consequence class, time window, and proof-scope digest;
- external proof evidence and verification-evidence digest;
- planned safe effects and forbidden-effect fences;
- public projection minimization and a no-authority watermark;
- verification debt and next recheck timing.

## Valid states

- `no_remediation_verification_rechecked_refresh_required`
- `external_remedy_proof_verified_quarantine_sustained`
- `external_remedy_proof_failed_quarantine_sustained`
- `external_proof_absent_escalated_still_held`
- `proof_conflict_held_quarantine_sustained`
- `invalid_verification_intake_rejected`

## Required refusals

The checker rejects source closure digest drift, unchecked/ghost source refs, target/recipient/projection drift, proof-scope digest drift, unchecked proof digests, audience/purpose/subject mismatch, verifier conflict omissions, proof evidence digest mismatch, verification-as-authority, verified proof clearing quarantine, status-pointer mutation, source-history mutation, high-consequence effects, public proof-payload leaks, missing no-authority labels, failed proof accepted, absent proof claiming validation, conflict auto-winners, and dropped forbidden-effect fences.

## Why proof intake remains small

A verified external proof may be important. It still does not grant Ward authority. It does not clear quarantine, update a status pointer, repair semantics, complete a remedy, release evidence, spend budget, or re-enable an action. It only records that a byte- and scope-bound proof was verified, failed, absent, or conflicted so later gates can replay the source packet.

## Schema and checker

- Schema: `schemas/governance-verification-intake-receipt.v0.json`
- Checker: `tools/check_governance_verification_intakes.py`
- Fixtures: `fixtures/governance-verification-intake/`
