# Governance evidence-release receipt v0

`ward.governance.evidence-release-receipt.v0` is a **non-authority release receipt** for one governance-evidence bundle, link, export, audit snapshot, or held-recheck notice.

It answers a narrower question than authorization:

> May this already-projected governance evidence be released to this recipient, for this purpose, from this source receipt, with this field allowlist and omission disclosure?

It does not approve dashboard export, semantic repair, action re-enable, remedy, budget spend, delegation, model learning, privacy waiver, or future reuse.

## Required posture

Every evidence-release receipt must preserve seven checks:

1. **Source binding** — exactly one batch/search or search-continuity receipt is referenced by id, path, and SHA-256 digest.
2. **Selection binding** — the chosen rows, fields, and omission summary are bound to the source query/projection basis.
3. **Recipient binding** — the release names the recipient class and keeps it separate from the requester.
4. **Purpose binding** — the released material is usable only for the named purpose.
5. **Projection/minimization** — the receipt lists field allowlist, field denylist, redaction profile, omission mode, and sensitive-evidence flags.
6. **Downstream controls** — retention, refresh/revocation channel, onward-use restrictions, and visible no-authority watermark travel with the bundle.
7. **Effect closure** — the only allowed effects are safe release/notice/receipt effects; all action, repair, remedy, learning, budget, privacy-waiver, delegation, and reuse effects remain forbidden.

## Positive states

- `released_minimized` — projected, audience-safe evidence was released with no authority grant.
- `released_restricted_review` — a restricted review bundle or pointer bundle was released to a bounded review lane.
- `held_recheck_required` — release was not completed; a recheck/replay notice was recorded.
- `release_refused` — release was refused and the refusal reason is visible.

## Broad-view omissions

Public or external release may disclose hidden governance evidence only as:

- none;
- presence-only;
- bucketed range;
- noisy/DP count with explicit privacy-budget evidence.

The v0 checker rejects exact public sealed counts, per-subject breakdowns, reviewer identities, named conflicts, incident details, private owner maps, and raw partner fragments.

## Checker scope

`tools/check_governance_evidence_release_receipts.py` validates:

- source digest parity and referenced-source validity;
- query/projection-policy mirroring;
- drift/result-state mirroring;
- public/restricted projection safety;
- sealed-omission disclosure;
- recipient, purpose, retention, refresh, and no-authority labels;
- payload field allowlist/denylist and state-preservation posture;
- forbidden-effect preservation and no high-consequence release effects.

The checker is not an authorization engine. It is a refusal harness for Ward's known evidence-release failures.
