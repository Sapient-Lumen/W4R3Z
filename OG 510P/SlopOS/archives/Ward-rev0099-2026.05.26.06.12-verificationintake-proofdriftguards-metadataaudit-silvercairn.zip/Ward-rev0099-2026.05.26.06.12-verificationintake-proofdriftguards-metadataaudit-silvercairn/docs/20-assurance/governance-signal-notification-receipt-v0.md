# Governance signal-notification receipt v0

A governance signal-notification receipt records Ward's downstream notification obligations after a governance signal-ingestion receipt has been accepted, ignored, held, or rejected.

It is **not** a recertification receipt, not proof that consumers refreshed, not evidence of local action, and not authority to update a status head. It says which consumers were expected, how delivery was attempted, which acknowledgments arrived, which caches remain unsafe, and which retries, dead letters, or quarantines are now owed.

## Required binding

A receipt must bind:

- the source signal-ingestion receipt id, byte digest, ingestion state, source recertification id, signal event key, subject digest, release, recipient, purpose, cache-subject digest, and requested cache action;
- the notification scope: plan id, reason, affected consumer set, consumer-set digest, expected required-consumer count, source signal event key, source signal subject digest, source release, recipient, purpose, and cache subject;
- the delivery plan: delivery mode, retry policy, dead-letter policy, attempt window, notification payload digest, payload subject digest, allowed channels, sealed-payload exclusion, and no-authority label;
- each consumer observation: hashed consumer id, channel, delivery state, attempt count, acknowledgment digest or retry/dead-letter pointer, and explicit refusal to treat acknowledgment as refresh or authority;
- the acknowledgment summary, stale-consumer closure, projection safety, effect closure, and notification decision.

## Valid states

- `all_consumers_notified_refresh_required`
- `partial_notification_quarantined`
- `duplicate_notification_suppressed`
- `dead_lettered_notification_quarantined`
- `conflict_notification_held`
- `invalid_notification_rejected`

## Invariants

- Notification is not recertification.
- Acknowledgment is not refresh.
- Dead-lettering is not delivery.
- A conflict-hold notice cannot pick a winner.
- A duplicate notification cannot become a new basis-changing signal.
- Missing, pending, or dead-lettered consumers keep the affected cache subject quarantined until consumer-local recertification/replay exists.
- Public projection may disclose state class, not private consumer identity, sealed payload, exact hidden counts, private steward, recipient contact, org map, or raw partner fragments.
