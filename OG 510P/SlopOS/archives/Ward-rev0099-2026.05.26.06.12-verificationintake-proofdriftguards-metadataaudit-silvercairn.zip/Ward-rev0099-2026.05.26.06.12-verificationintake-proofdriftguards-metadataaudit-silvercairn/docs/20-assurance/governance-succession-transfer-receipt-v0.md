# Governance succession/transfer receipt v0

A governance succession/transfer receipt records a responsibility or status-channel change over an already released Ward governance artifact.

It is downstream of an evidence-release receipt and, when available, the latest evidence-release follow-up receipt. It is not a delegation warrant, not a stewardship charter, not an authorization decision, and not a grant.

## Required bindings

A v0 receipt binds:

- source evidence-release receipt id/path/digest;
- optional latest follow-up receipt id/path/digest;
- source-chain digest and source-chain check posture;
- transfer kind and scope;
- recipient class and purpose from the source release;
- predecessor role, notification channel, termination reason, and no-continuing-authority flag;
- successor role, acceptance state, proof digest, scope parity, no-scope-expansion, no-authority-upgrade, and no-redelegation-without-warrant flags;
- source release id, source item digest, projection-policy digest, recipient, and purpose;
- old status channel, new status pointer, rotation/invalidation posture;
- projection-safety labels and public successor-identity mode;
- forbidden-effect preservation.

## Decision states

Allowed v0 states are:

- `transfer_recorded`;
- `rotation_recorded`;
- `successor_pending_recheck`;
- `transfer_refused`;
- `transfer_quarantined`;
- `transfer_held_review`.

A pending, dual-control-pending, held, or refused successor cannot make the release currently reusable. Accepted transfer records still do not create authority; they only keep the status and responsibility chain current enough for downstream recheck.

## Forbidden collapses

The checker rejects:

- treating successor acceptance as authority;
- leaving the predecessor with continuing authority;
- leaving an old status channel active after rotation;
- changing purpose or recipient without a new release;
- expanding scope during transfer;
- using pending successor state to reuse a release;
- leaking named/private stewardship evidence in a public transfer;
- dropping forbidden effects from the source release or latest follow-up;
- performing action, remedy, export, repair, budget, learning, privacy-waiver, or delegation effects.

## Product line

A Ward status URL is not forever. Consumers should render:

> “Succession/transfer receipt. Not authority. Old status channel invalidated; refresh current status before reuse.”
