# Governance recertification receipt v0

A governance recertification receipt records a bounded recheck of one cached governance dispute-resolution receipt.

It is downstream of the dispute-resolution receipt. It is not a new dispute resolution, not a release, not a follow-up, not a succession transfer, not an approval, and not an authorization grant.

## Required bindings

A v0 receipt binds:

- one source governance dispute-resolution receipt by id, path, byte digest, source resolution state, release id, recipient class, purpose, source item digest, projection policy digest, reuse state, status pointer, and current-head flag;
- one cache subject digest over the cached source resolution, release, recipient, purpose, source item, and projection policy;
- one recertification scope: scheduled recheck, status-channel recheck, recipient refresh, cache invalidation, historical revalidation, or projection-policy recheck;
- trigger evidence for status-channel, recipient-refresh channel, projection policy, owner-map epoch, successor state, branch state, follow-up signals, and clock window;
- cache posture: current-but-refresh-required, invalidated stale, quarantine sustained, historical only, or recheck required;
- public/restricted projection safety;
- no-authority watermarking;
- forbidden-effect preservation.

## Decision states

Allowed v0 states are:

- `current_cache_recertified`;
- `cached_resolution_invalidated`;
- `cache_quarantine_sustained`;
- `historical_cache_only`;
- `recertification_recheck_required`.

Even a recertified current cache remains refresh-required. Source-packet replay is required before export, action, repair, remedy, learning use, budget spend, delegation, or CH-AREF attachment.

## Forbidden collapses

The checker rejects:

- source dispute-resolution digest mismatch;
- cache-subject digest mismatch;
- missing source-resolution replay;
- missing status-channel or refresh-channel recheck;
- cached resolution treated as authority;
- current cache reusable without refresh;
- next recheck due at or before the recertification cut;
- newer signal ignored while claiming current cache;
- projection-policy drift claimed current;
- high-consequence effects;
- dropped forbidden-effect fences;
- missing no-authority label;
- public sealed-branch evidence or exact hidden counts;
- stale cache not invalidated;
- notification gaps after invalidation;
- source-resolution mutation;
- purpose drift;
- current cache without a status pointer.

## Product line

Render a recertified current cache as:

> “Cached resolution rechecked. Still current as a status pointer. Not authority. Refresh and replay before reuse.”

Render an invalidated cache as:

> “Cached resolution stale or changed. Invalidate local cache, refresh from status channel, and do not reuse until replay passes.”
