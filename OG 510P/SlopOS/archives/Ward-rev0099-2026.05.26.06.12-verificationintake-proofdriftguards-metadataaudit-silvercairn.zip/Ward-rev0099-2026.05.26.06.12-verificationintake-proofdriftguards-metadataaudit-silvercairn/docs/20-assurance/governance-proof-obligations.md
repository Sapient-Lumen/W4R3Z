# Governance proof obligations

This surface turns Ward's stewardship/delegation/escalation vocabulary into proof obligations. The obligations are intentionally small. They should be checked before a governance residue supports a SlopOS-facing metric edit, semantic bridge, backfill, recompute, export, remedy, learning use, action warrant, ACP-adjacent proposal, or emergency override.

A governance handoff packet may cite external evidence, but it must not make owner labels, routes, tickets, dashboards, or agents stronger than the obligations below allow.

## Obligation set

| id | obligation | pass condition | common refusal |
|---|---|---|---|
| PO-GOV-001 | Subject binding | Charter, warrant, handoff, and requested action are bound to the exact answer family, metric, axis, source fragment, semantic bridge, export, remedy, learning use, or action class. | subject too broad, stale cut, digest mismatch, “provider risk” used as ambient scope |
| PO-GOV-002 | Duty/exclusion proof | Requested action appears in permitted duties or granted capabilities and does not appear in excluded/denied powers. | owner can maintain but not export; delegate can repair but not publish; payer can spend but not change metric |
| PO-GOV-003 | Currentness proof | Charter/warrant/handoff is active, reviewed, not expired, not superseded, not stale, not orphaned, and not suspended for the as-of cut. | old owner map, unreviewed charter, expired temporary warrant, missing successor |
| PO-GOV-004 | Delegator authority proof | The delegator had authority to grant the exact capability, subject, budget, privacy/projection, and time scope. | delegate issued a higher-scope delegation; on-call created semantic authority; agent approved its own warrant |
| PO-GOV-005 | Delegation caveat proof | Expiry, revocation, no-redelegation, dual-control, conflict, privacy, budget, use-count, and result-receipt caveats are satisfied. | active-looking warrant missing no-redelegation, expired use count, or result receipt |
| PO-GOV-006 | Escalation acceptance proof | Handoff records whether authority was accepted, partially accepted, refused, rerouted, no-response, needs-info, conflict-declared, emergency-only, or closed. | ticket assignment treated as accepted authority; page treated as decision; no-response treated as approval |
| PO-GOV-007 | Conflict/quorum proof | Independence, conflict, dual-control, and quorum requirements are satisfied for the requested consequence. | conflicted reviewer approves own remedy; single approver where dual control is required |
| PO-GOV-008 | Agent boundary proof | Agent/tool runner is only drafting, querying, validating, or proposing under a leash and warrant; it is not steward-of-record, self-approver, or escalation accepter. | tool access treated as governance authority; ACP proposal treated as action warrant |
| PO-GOV-009 | Break-glass proof | Emergency authority names trigger, duration, scope, interim effect, reviewer, rollback, notices, and post-hoc review debt. | emergency route waives privacy/budget/action gates without residue |
| PO-GOV-010 | Rehydration proof | Before fresh change/export/action/learning/remedy use, old governance facts are checked against current owner map, policy epoch, privacy, budget, source contract, and action-warrant posture. | historical steward treated as current; old approval reused after semantic or policy drift |
| PO-GOV-011 | Projection/minimization proof | Governance evidence is projected to the viewer and consequence class without leaking hidden people, partners, conflicts, incidents, or suppressed populations. | authority proof becomes an org-chart leak or existence oracle |

## Outcome classes

A checker or reviewer should return one of these postures rather than a bare boolean.

- `consequence_grade` — all relevant obligations pass and the requested action is allowed under current scope.
- `review_only` — useful evidence exists but at least one action-support obligation is not satisfied.
- `routing_hint_only` — owner/contact/queue material may route low-risk review but cannot approve, repair, export, learn, remedy, or act.
- `needs_rehydration` — old material may be historically valid but cannot support current consequence until rechecked.
- `stale_governance` — charter, warrant, owner map, reviewer lane, or escalation policy is stale, orphaned, superseded, suspended, or expired.
- `authority_missing` — no scoped steward, delegate, or accepted escalation covers the requested action.
- `conflict_unresolved` — reviewer/delegate/steward conflict, independence, quorum, or self-approval problem is unresolved.
- `budget_missing` — recompute/export/action budget or payer authority is missing or out of scope.
- `privacy_projection_block` — evidence or requested action would exceed projection, privacy, source-contract, or minimization limits.
- `expired_warrant` — delegation existed but cannot be used at the as-of cut.
- `handoff_unaccepted` — escalation was assigned or sent but not accepted for the requested authority.
- `agent_boundary_violation` — model/tool lane attempts stewardship, self-approval, escalation acceptance, or action authorization.
- `refuse` — one or more obligations fail in a way that should not degrade silently.

## Promotion rule

A Ward governance residue does not graduate merely because the prose is useful. It graduates only when it has proof obligations, at least one positive fixture, multiple negative fixtures, cross-cube seam placement, downgrade/refusal behavior, and a currentness model.


## Pass LXXIX closure notes

- PO-GOV-003 currentness remains not-applicable for routing-hint-only states only when the packet explicitly forbids promotion and carries no sensitive evidence.
- PO-GOV-009 break-glass now requires trigger, scope, expiry, allowed interim actions, rollback plan, post-hoc review deadline, and review-debt receipt.
- PO-GOV-011 projection/minimization applies even to routing hints and refusals, not only consequence-grade actions.
