# Governance receiver-convergence receipt v0

Pass XCIII adds a receiver-convergence receipt downstream of signal-notification reconciliation receipts. It answers one question Ward could not answer in rev0092:

> When two or more Ward receivers observe overlapping consumers or status channels, have they actually converged, or is one receiver lagging, forked, duplicated, or looking at a divergent status-channel cut?

The receipt is deliberately not a grant, not a global current head, not a status pointer, not a quorum decision, and not a consumer recertification. It is a convergence/audit record over multiple receiver-local reconciliation receipts.

## Required binding

A receiver-convergence receipt must bind:

- every referenced signal-notification reconciliation receipt by path and byte digest;
- the source release, signal event key, subject digest, recipient class, purpose, and cache-subject digest;
- each receiver by hashed receiver id, receiver class, hashed status-channel id, status-channel cut digest, and watermark;
- the digest of the expected receiver set;
- the overlap digest of the affected consumer sets being compared;
- whether each receiver is reconciled, lagging/quarantined, divergent-held, duplicate-suppressed, or fork-quarantined;
- stale receiver counts without treating public exact counts as safe disclosure;
- projection controls for receiver identities, status channels, sealed signal payloads, and private org maps.

## Valid states

- `all_receivers_converged_refresh_required`
- `partial_receiver_lag_quarantined`
- `divergent_status_channel_cut_held`
- `duplicate_receiver_observation_suppressed`
- `receiver_fork_quarantined`
- `invalid_convergence_rejected`

The states are convergence posture only. Even when all required receivers converge, reuse still requires replay/refresh of the underlying packet chain; the receipt does not approve export, action, repair, remedy, delegation, learning use, or status-pointer mutation.

## Required refusals

The checker rejects all of these collapses:

- source reconciliation digest drift;
- receiver-set digest drift;
- overlap-digest drift;
- expected receiver count inflation;
- divergent status-channel cuts claimed as converged;
- partial receiver lag claimed complete;
- receiver quorum treated as authority;
- convergence treated as recertification;
- status-pointer mutation;
- public receiver identity leakage;
- public exact hidden counts;
- missing no-authority labels;
- dropped forbidden-effect fences;
- high-consequence convergence effects;
- duplicate receiver observations promoted to fresh effects;
- fork quarantine publishing a winner;
- source-scope purpose drift;
- unchecked source references;
- stale receivers without quarantine or hold pointers.

## Why this is separate from reconciliation

`EXT-RFC-8935` and `EXT-RFC-8936` keep SET delivery and local handling distinct. `EXT-OPENID-SSF-2025` separates transmitter/receiver event streams from local receiver decisions. `EXT-CLOUDEVENTS-SPEC-2026` treats source/id as event identity and duplicate posture. `EXT-NIST-SP-800-137-2011` pressures continuous monitoring rather than one-time authorization. Together they imply that one receiver's clean reconciliation is not global convergence.

## Schema and checker

- Schema: `schemas/governance-receiver-convergence-receipt.v0.json`
- Checker: `tools/check_governance_receiver_convergence.py`
- Fixtures: `fixtures/governance-receiver-convergence/`
