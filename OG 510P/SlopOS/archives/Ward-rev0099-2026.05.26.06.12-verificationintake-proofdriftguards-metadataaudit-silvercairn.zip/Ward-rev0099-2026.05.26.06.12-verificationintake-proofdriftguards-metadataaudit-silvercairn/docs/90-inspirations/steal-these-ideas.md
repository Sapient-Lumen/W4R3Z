# Steal these ideas

## From outside systems
- WebAuthn: scoped credentials, user consent, and separate backup-eligibility / backup-state facts.
- RATS: evidence, endorsements, appraisal, and results are different roles for a reason.
- TUF: threshold roots, delegations, and expiry keep ultimate trust away from one convenient online key.
- SLSA provenance: build claims are valuable witness material without becoming automatic approval.
- DBSC: session hardening deserves its own lane rather than quietly impersonating identity.
- SCITT: transparency receipts create accountability without promising honesty.
- Key Transparency: accountable key history and stability are useful trust inputs without becoming trust verdicts.
- Sigstore keyless signing: short-lived identity-backed witness flows can be convenient and strong without replacing local approval.

## From sibling cubes
- Harbor: callback or route success should remain weaker than durable spend.
- Helm: trust consequences should have inspectable user-facing surfaces.
- Schell: operational convenience channels often need explicit adoption.
- ViewFS: imported material and locally admitted material are different strengths.
- Foundry: runtime evidence remains smaller than local verdict.

## New steals for rev0008
1. **Stability card** — a compact witness about how steady an account→key relation has been.
2. **Receipt pack** — grouped transparency/provenance/verification receipts without fake completeness.
3. **Admission profile ladder** — different local profiles for public-facing acceptance and high-risk spend.
4. **History witness** — accountable history kept smaller than verdict.
5. **Spend profile** — a policy object that explains what must be true before consequence becomes spendable.
## New steals for rev0011
1. **Receipt skepticism** — verification receipts stay smaller than spend approval.
2. **History braid** — compact linkage among current binding, prior binding history, and watch pointers.
3. **Quarantine gate** — preserve earlier verification history while blocking present spend.
4. **Watch duty** — explicit ownership that someone must keep monitoring after first admission.
5. **Invalidity horizon** — the earliest point from which later compromise should change consequence.

## New steals for rev0013
1. **Receipt half-life** — how long a bundle may straightforwardly support spend before recheck is expected.
2. **History watch** — explicit ongoing monitoring duty after first admission.
3. **Quarantine braid** — linkage among earlier verification, later suspicion, and current narrowed consequence.
4. **Re-anchoring prompt** — a small card saying stronger witness material or fresher receipts are now required.
5. **Watch handoff** — make the owner of post-admission monitoring visible.


- **state watch** — explicit record of how much continuity the client still remembers.
- **auditor lag card** — how fresh the outside witness must remain.
- **successor root card** — continuity object for a new epoch that does not erase rollover risk.

## New steals for rev0014
- **receipt distrust notice** — later skepticism without historical erasure.
- **bundle half-life** — a visible age class for grouped verification material.
- **watch duty** — explicit ownership for later recheck and drift monitoring.
- **successor skepticism card** — continuity that remains weaker than final approval.
- **quarantine without amnesia** — narrow spend while preserving earlier truth.

## New steals for rev0015
- **state anchor** — a local continuity memory for what was last checked or accepted.
- **fork alarm** — a narrow warning that history or monitoring continuity is no longer comfortably linear.
- **successor audit** — explicit work required before a rolled-forward service can influence spend again.
- **witness carry-forward** — keep historical residue available without treating it as present approval.
- **continuity weaker than freshness** — a standing anti-regrowth rule.

## New steals for rev0016
- **status carrier** — grouped status material that stays smaller than final spend approval.
- **suspension rail** — reversible narrowing distinct from permanent invalidation.
- **refresh notice** — advisory status that says replace this without saying it was false.
- **status authority split** — explicit residue when status governance differs from issuance.
- **privacy-friendly staple** — holder-provided status that still leaves room for fresher local checks.

## New steals for rev0019
- **incident watch** — signed stream of later trust-relevant facts.
- **subject braid** — typed continuity across original bundles, status carriers, and later event streams.
- **local spend hold** — explicit local narrowing triggered by later incident facts.
- **watch lease** — visible ownership and freshness duty for an event stream.
- **fact smaller than command** — a standing anti-regrowth rule.

## New steals for rev0019
- **derived proof** — holder-generated proof smaller than the base witness.
- **unlinkability rail** — explicit note that repeated successful presentations need not be correlatable.
- **disclosure dial** — visible choice about how much of the base witness is revealed.
- **status braid** — continuity across base witness, derived proof, and later status/freshness checks.
- **proof smaller than custody** — a standing anti-regrowth rule.

## Pass XIX additions
- **root epoch** — durable label for trusted root lineage.
- **delegation freeze** — local hold for withdrawn delegated trust.
- **recovery lane** — explicit out-of-band path after threshold compromise.


## Pass XX additions
- **attenuation event** — signed status update that narrows or revisits local consequence.
- **receiver stance** — explicit local posture about what a continuous event may do here.
- **subject drift** — residue about ambiguity in subject mapping over time.
- **status receiver** — lane for accepted, queued, quarantined, or ignored trust-change signals.

## Pass XXI additions
- **status purpose** — typed later meaning instead of one generic invalid bit.
- **recency window** — visible freshness horizon for fetched or carried status.
- **external status issuer** — later status authority distinct from original issuance.
- **status coordinate** — smaller-than-meaning locator into later status material.
- **time-cut status check** — ask what status material was valid at a specific moment.
- **no-live-oracle-by-default** — a standing anti-regrowth rule.


## Pass XXII additions
- **freshness witness** — small artifact that says what status batch is current enough to trust.
- **coherent snapshot cut** — visible boundary saying several status fragments belonged together.
- **freeze alarm** — typed stale/unrefreshable posture distinct from negative status.
- **aggregation surface** — discovery lane for multiple relevant status sources.
- **consistency witness** — append-only proof that later publication extends earlier publication.
- **privacy-coarse freshness cadence** — avoid per-check freshness artifacts that become correlation beacons.


## Pass XXIII additions
- **coverage witness** — explicit statement that a status corpus really covers this issuer/family/time cut.
- **unknown posture** — typed residue for uncovered or insufficiently supported status.
- **proof-carrying absence** — non-inclusion stronger than “not found”.
- **issuer participation card** — compact clue that one issuer/family is inside or outside a replicated corpus.
- **delta train** — bounded sequence of updates extending a trusted snapshot.
- **plural receipt braid** — multiple accountability receipts that remain smaller than verdict.

## Pass XXIV additions
- **state class** — classification result smaller than verdict.
- **action ladder** — visible local response ladder for one classified state.
- **default non-action** — set state first, act only with explicit local policy.
- **effective-validity test** — catch “de-preferenced but still effectively valid” outcomes.
- **delivery-path skepticism** — status transport stays smaller than status meaning.
- **coverage floor** — explicit minimum coverage/confidence before hard-drop semantics.

## Pass XXV additions
- **effective change time** — when the trust-relevant fact likely became true, even if publication came later.
- **known-correct interval** — responder/publisher claim about how long one state answer is current enough.
- **cause cohort** — compact linkage across several later-state artifacts from one underlying cause.
- **local adoption cut** — when one receiver actually let a later-state package change consequence here.
- **reason handle** — typed explanation smaller than local policy or verdict.

## Pass XXVI additions
- **appraisal recipe** — keep the evaluation method smaller than the evidence and smaller than the action.
- **label scheme handle** — explicit pointer to the meaning behind normalized result labels.
- **policy epoch** — visible generation for one local interpretation frame.
- **replay delta** — compare new evaluation with old without historical amnesia.
- **frame-of-reference card** — grouped hint about verifier, recipe, and epoch.


## Pass XXVII additions
- **replay fence** — exact-delivery dedupe smaller than cause identity or local consequence.
- **ordering window** — visible uncertainty band when delivery order and event time disagree.
- **apply cursor** — receiver-local marker for what has really been incorporated.
- **verification ping** — liveness probe weaker than delivered evidence.
- **same-handle exact replay** — a standing anti-regrowth rule.


## Pass XXVIII additions
- **concurrency witness** — explicit residue that two updates are parallel rather than ordered.
- **merge recipe** — visible statement of how concurrent siblings were reduced.
- **survivor view** — compact current projection that stays smaller than source history.
- **compaction horizon** — explicit boundary where latest-view negatives get weaker.
- **no silent LWW** — a standing anti-regrowth rule.

## Pass XXIX additions
- **completeness frontier** — explicit claim about how far later-state intake is believed complete enough.
- **provisional view** — early answer that stays visibly open to correction.
- **lateness budget** — named grace period for late-arriving truth.
- **retraction delta** — explicit corrective diff smaller than a whole replacement history.
- **no fake final-by-default** — a standing anti-regrowth rule.

## Pass XXX additions
- **monotonicity class** — explicit clue about whether one residue safely accumulates or may still need belief revision.
- **closure gate** — visible point where absence-, count-, or threshold-shaped logic becomes trustworthy enough to use.
- **support braid** — compact linkage among the distinct support paths for one local result.
- **alternate derivation** — residue that another acceptable support path still exists after one path is withdrawn.
- **invalidation cascade** — explicit trail of secondary narrowing after support loss.
- **support smaller than verdict** — a standing anti-regrowth rule.

## Pass XXXI additions
- **published cut** — immutable addressable trust cut smaller than one universal substrate.
- **moving alias** — named pointer that may advance without rewriting the cut.
- **reader pin** — consumer-local fixation on one exact cut for stable replay or review.
- **retention floor** — explicit promise about how long old cuts remain physically readable.
- **alias trail** — compact history of where one moving alias used to point.
- **adjacent note** — commentary attached beside a cut without re-authoring the cut.

## Pass XXXII additions
- **writer view** — exact authored schema/shape bound to one cut.
- **reader view** — consumer-local expected schema or projection.
- **field identity** — stable identity for one fact independent of current label/order.
- **compatibility lane** — explicit policy for how older/newer views interoperate here.
- **presence mode** — visible distinction between absent, explicit default, and explicit set.
- **translation witness** — compact residue that one view was intentionally projected into another.
- **retired slot** — field or ordinal identity that must not be silently reused.
- **label weaker than identity** — a standing anti-regrowth rule.


## Pass XXXIII additions
- **assurance facet** — one independently meaningful trust/appraisal dimension.
- **acceptance floor** — minimum value or posture required for one local action.
- **bottleneck facet** — the facet that actually constrained or denied the current action.
- **rollup badge** — optional collapsed summary kept visibly weaker than the facet set.
- **facet waiver** — explicit local override for one facet floor.
- **not-claimed facet** — visible absence of a facet claim without a fake default.
- **no fake scalar by default** — a standing anti-regrowth rule.

## New in rev0034
- **must-understand claim** — field or claim whose semantics must be understood before local consequence can proceed.
- **understanding gate** — parser/appraiser checkpoint smaller than policy that decides whether processing can continue.
- **retained unknown** — unknown field preserved for forwarding/replay without being treated as understood.
- **duplicate collision alarm** — parse-level or envelope-level conflict that must not be normalized away silently.


## Pass XXXV additions
- **observer report** — one actor's statement that it saw, checked, or registered one trust-relevant thing.
- **corroboration set** — grouped receipts, cosignatures, or registrations over the same cut or claim.
- **witness cohort** — the independence class the corroborators belong to.
- **local quorum rule** — the local policy that decides what corroboration is enough for one action.
- **same-cut requirement** — rule that corroboration only counts together when it speaks about the same underlying cut.
- **quorum shortfall** — visible residue that some corroboration exists but not enough for this consequence.
- **count weaker than independence** — a standing anti-regrowth rule.

## Pass XXXVI additions
- **commit witness** — residue that one change crossed a specific durability or consensus threshold.
- **stable frontier** — exact read/view cut below which unresolved work is believed absent.
- **finality class** — typed reversal hardness smaller than consequence.
- **exposure gate** — local rule that says which commitment/finality class is enough here.
- **rollback budget** — compact clue about what reversal would cost.
- **apply lag note** — visible gap between durable acceptance and local applied visibility.
- **visibility weaker than commitment** — a standing anti-regrowth rule.


## Pass XXXVII additions
- **lease claim** — bounded temporary authority smaller than exclusion.
- **fence token** — monotonic generation checked by the recipient.
- **stale-holder alarm** — explicit residue that old authority may still act or still believe itself current.
- **handoff posture** — cooperative release, grace delay, expiry, or forced break kept visibly distinct.
- **authority epoch bump** — compact clue that a successor is now current.
- **recipient validator** — destination-side rule that actually makes fencing real.
- **no high-risk lease without fencing** — a standing anti-regrowth rule.


## Pass XXXVIII additions
- **desired state** — persisted requested target smaller than enacted reality.
- **observed generation** — exact desired revision a compact summary reflects.
- **condition set** — typed summary lane smaller than full observed state.
- **teardown gate** — cleanup barrier between deletion request and absence.
- **level-based target** — drive to latest desired without fake intermediate milestones.
- **allocation acknowledgement** — asynchronously confirmed result weaker than request intent.
- **terminating-not-gone** — a standing anti-regrowth rule.

## Pass XXXIX additions
- **delete marker** — current-view retirement smaller than destruction.
- **repair floor** — explicit replication / rebuild safety threshold before stronger deletion claims.
- **resurrection alarm** — visible warning that stale copies may still revive what looks gone.
- **reclamation horizon** — separate policy point for physical purge of bytes, metadata, or markers.
- **hidden-not-destroyed** — a standing anti-regrowth rule.


## Pass XL additions
- **resume cursor** — saved restart handle smaller than continuity proof.
- **continuity class** — explicit statement of whether local history is continuous, degraded, reset-required, or unknown.
- **history gap alarm** — visible residue that one replay interval may no longer be recoverable from the source.
- **backfill posture** — explicit note that bounded reconstruction is in progress or required.
- **continuity downgrade** — honest state change when a formerly resumable lane loses replay coverage.
- **cursor decay horizon** — reminder that saved positions can age out even when the abstraction sounds durable.
- **no silent reset after a gap** — a standing anti-regrowth rule.


## Pass XLI additions
- **read cut** — exact historical view one answer actually reflects.
- **staleness budget** — explicit freshness bargain instead of hidden latency trade-off.
- **ambiguity window** — visible interval where inclusion/exclusion is not safely knowable yet.
- **revalidation fence** — stronger check required before high-risk consequence.
- **deferral posture** — honest wait/restart instead of fake latest-state confidence.
- **stronger-than-browse** — a standing anti-regrowth rule.

## Pass XLII additions
- **basis pin** — exact factual cut/scope an exploration rides on.
- **cohort contrast** — contrast-first surfacing of surprising differences in one selected set.
- **saved query recipe** — durable analytic recipe that can run against a pinned or moved basis.
- **promotion bay** — explicit graduation lane from one-off query to maintained derivative.
- **basis drift alarm** — visible residue that a saved exploration is no longer running against the same basis.
- **derivative weaker than source** — a standing anti-regrowth rule.


## Pass XLIII additions
- **temporal lookup lane** — explicit point-in-time enrichment rule for time-varying context.
- **join clock** — inspectable statement of which time axis drove the lookup.
- **freeze rail** — hold one result snapshot still for review.
- **rerun-diff rail** — compare one recipe across bases or clocks without mutating history.
- **workload witness** — repeated-query evidence before acceleration or promotion.
- **recipe-not-result-not-live** — a standing anti-regrowth rule.

## Pass XLIV additions
- **staged derivative** — candidate maintained surface that can hydrate and be inspected before swap.
- **publish rail** — explicit move from staged candidate to active derivative.
- **change witness** — typed inserted/deleted/updated diff for one rerun or replacement.
- **validate-before-swap** — standing process rule for promoted derivative changes.
- **no silent derivative swap** — a standing anti-regrowth rule.

## Pass XLV additions
- **query contract** — small published promise for one repeated question: grain, measures, dimensions, headers, and caveats.
- **metric card** — compact human-facing statement of one measure's meaning and limits.
- **loss fence** — explicit boundary around what a lossy derivative cannot answer.
- **contract-before-rollup** — standing process rule for repeated questions.
- **no lossy default cube** — a standing anti-regrowth rule.

## Pass XLVI additions
- **exactness class** — visible statement of whether a surface is exact replay, exact derived, approximate, or otherwise weaker.
- **estimator card** — family/mergeability/precision/caveat surface for one approximate result family.
- **sketch witness** — optional durable residue for mergeable sketch-backed state.
- **algorithm-name honesty** — standing process rule for approximate surfaces.
- **approximate-not-replayable** — a standing anti-regrowth rule.

## Pass XLVII additions
- **aggregation law** — explicit statement of how one recurring measure may or may not re-aggregate.
- **rollup passport** — compact contract for safe regroupings, time-rollups, and forbidden projections.
- **merge state** — optional intermediate residue kept when a displayed value is not itself safely re-aggregatable.
- **no universal additivity by default** — a standing anti-regrowth rule.
- **rendered total weaker than recomposition state** — a standing anti-regrowth rule.


## Pass XLVIII additions
- **grain witness** — explicit base fact meaning, uniqueness anchor, and inner grouping for one recurring measure lane.
- **fanout fence** — visible duplication-risk barrier at one join seam.
- **weight carrier** — optional numerator/denominator or weighting residue for honest regrouping.
- **equal-weight versus event-weight honesty** — a standing anti-regrowth rule.
- **no average-of-averages by accident** — a standing anti-regrowth rule.

## Pass XLIX additions
- **gap posture** — explicit statement of what missingness means on one result surface.
- **fill witness** — explicit trace that one value was filled and by what method.
- **synthetic bucket** — generated alignment bucket for densification, display, or comparison.
- **no silent zero-fill** — a standing anti-regrowth rule.
- **alignment weaker than observation** — a standing anti-regrowth rule.

## Pass L additions
- **window frame** — explicit interval or accumulation rule for one rolling/cumulative surface.
- **anchor instant** — explicit evaluation point or bucket edge a windowed answer is relative to.
- **partial-window posture** — explicit rule for incomplete early or truncated windows.
- **no silent cumulative default** — a standing anti-regrowth rule.
- **frame weaker than fact** — a standing anti-regrowth rule.


## Pass LI additions
- **view binding** — explicit authorized slice or scope lane a recurring question ran against.
- **population witness** — compact statement of the rows/fields/population the answer actually covered.
- **scope drift alarm** — visible residue that the same recipe reran under a different authorized population.
- **no silent scope widening** — a standing anti-regrowth rule.
- **query text weaker than population** — a standing anti-regrowth rule.

## Pass LII additions
- **calendar binding** — explicit calendar family, week rule, bucket width, and origin/alignment for one recurring surface.
- **timezone witness** — compact statement of which time zone or civil-time assumption the result actually used.
- **boundary drift alarm** — visible residue that the same recipe reran under a different calendrical contract.
- **no silent week rule** — a standing anti-regrowth rule.
- **calendar semantics weaker than fact truth** — a standing anti-regrowth rule.


## Pass LIII additions
- **unit binding** — canonical unit contract for one promoted recurring surface.
- **conversion witness** — compact residue that says how source values were normalized before comparison or publication.
- **display scale** — explicit statement of what the human saw, kept weaker than the underlying bound unit.
- **no silent percent sign** — standing anti-regrowth rule.


## Pass LIV additions
- **sample witness** — compact residue describing sampling family, rate/target size, and any extrapolation or correction rule.
- **selection stage** — explicit note about whether the sample was taken before or after joins/filters.
- **repeatability lane** — explicit note about seed, deterministic key stability, and rerun expectations.
- **key-stable sample** — deterministic subset trick that preserves comparable populations across related tables.
- **fast preview is weaker than frozen truth** — a standing anti-regrowth rule.

## Pass LV additions
- **bucket schema** — declared distribution grid/family smaller than one full metric constitution.
- **boundary witness** — compact residue for inclusivity/exclusivity, zero bucket, and overflow handling.
- **interpolation posture** — visible note that a percentile came from bucket interpolation, sketch estimation, or exact replay.
- **perfect subsetting** — downscale-compatible histogram family that can lower resolution without inventing error.
- **tail answer weaker than raw population** — a standing anti-regrowth rule.

## Pass LVI additions
- **temporality binding** — declared temporal contract for one recurring numeric surface: cumulative, delta, snapshot, or another named family.
- **reset witness** — compact residue saying whether resets/discontinuities were absent, adjusted for, unresolved, or irrelevant.
- **derivative posture** — visible note that a rendered rate/increase/change came from replayed deltas, reset-adjusted cumulative state, or an unsafe path that was withheld.
- **derive-before-aggregate** — preserve reset detection before flattening many series together.
- **derived slope weaker than base series** — a standing anti-regrowth rule.


## Pass LVII additions
- **identity witness** — compact residue for the exact key, fingerprint, or offset rule that made several rows count as one logical subject or retry family.
- **dedupe posture** — explicit note that duplicates were preserved, filtered exactly, filtered best-effort, compacted in the background, or collapsed on read.
- **correction lineage** — visible note that a current row descends from an original event, replacement chain, or delete/tombstone chain.
- **explicit delete-as-state** — treat deletion as a typed correction event instead of letting rows merely vanish.
- **current winner weaker than raw history** — a standing anti-regrowth rule.

## Pass LVIII additions

- **privacy-unit badge** — compact reminder of who or what the release protects.
- **budget odometer** — visible accumulation of privacy spend across repeated releases.
- **suppression fence** — compact cue that hidden rows may reflect privacy policy instead of raw absence.
- **release-family card** — small surface distinguishing thresholded, noisy, and replayable-exact answers.
- **privacy-shaped weaker than replayable exact** — standing anti-regrowth rule.


## Pass LIX additions
- **resolution binding** — declared query step or source-resolution cap kept smaller than the full query contract.
- **tier witness** — compact residue saying whether the answer came from raw replay, retained summary, materialized derivative, or display rollup.
- **hybrid seam** — explicit note that one answer stitched materialized history with fresher raw data or crossed retained fidelities.
- **raw-only lane** — replay-grade opt-in that refuses downsampled history.
- **resolution weaker than fact truth** — a standing anti-regrowth rule.

## Pass LX additions

- **axis capsule** — small answer-shape card for axes, base grain, measure family, qualifiers, and absence posture.
- **layout aperture** — visible-but-narrow disclosure of storage, partition, retained tier, columnar export, or sparse/dense choices when they affect comparison or replay.
- **lineage facet** — compact provenance attachment for source cuts, recipe/run identity, and promotion context.
- **answer-shape before engine** — collect what a promoted answer means before choosing SlopOS's eventual cube storage or query stack.
- **hidden layout, visible consequence** — steal hidden partitioning's decoupling while refusing to hide semantic drift caused by layout/tier changes.
- **tiny interface with non-goals** — make every export or plan boundary explicit about what it does *not* decide.


## Pass LXI additions

- **scope lens** — compact authority card for view/snapshot, namespace, schema/query digest, authorized population, and leakage limits.
- **state cut witness** — compact mutable-cut card for source snapshots, semantic/model versions, policy epoch, materialization generation, redaction profile, and retained state family.
- **refusal receipt** — durable cannot-answer or withheld-answer card for denied, unsupported, stale, suppressed, over-budget, or unsafe cells/projections.
- **subtotal identity badge** — explicit cue that a row/cell is an ALL/subtotal rollup rather than ordinary null or missing data.
- **cannot-answer beats plausible-wrong** — a standing anti-regrowth rule for agents, semantic layers, dashboards, and LLM-assisted query drafting.
- **scope/state/refusal before promotion** — standing process rule for SlopOS datacube answers.

## Pass LXII additions

- **comparability passport** — compact residue saying whether compared answer capsules or cells are same-contract, bridged, bridge-required, incomparable, or untested.
- **drift notice** — compact cue that scope, schema, metric logic, source contract, policy epoch, quality gate, materialization, privacy, or refusal coverage changed in a comparison-relevant way.
- **quality witness** — compact validation/contract residue for suite or contract subset, version, run/cut, status, severity, coverage, and affected cells.
- **bridge-required status** — a first-class middle posture between comparable and impossible.
- **same title is weaker than comparable** — a standing anti-regrowth rule for trends, before/after charts, cohort contrasts, and agent-written summaries.
- **validation-result-as-residue** — steal the habit of treating data-quality outcomes as durable material attached to the answer they qualified.

## Pass LXIII additions

- **delta anatomy** — compact movement decomposition for a changed answer or comparison, with residual explicitly preserved.
- **attribution rail** — small claim-strength lane that constrains explanation verbs and evidence class.
- **exemplar fence** — guard around examples, rows, traces, handles, or documents used to illuminate an aggregate.
- **allowed-verbs discipline** — distinguish accounts-for, came-from, associated-with, illustrates, and caused-by.
- **explanation probe fixture** — small static case that proves the explanation recipe handles label splits, refusal cells, denominator movement, and late corrections.
- **why-answer weaker than causal proof** — a standing anti-regrowth rule for dashboards, agents, and LLM summaries.

## Pass LXIV additions

- **freshness envelope** — reuse boundary that keeps target lag, observed staleness, source cuts, and consequence class visible.
- **invalidation receipt** — small record that says what changed, which cells/cuts/axes were affected, and what action was taken.
- **recompute docket** — visible repair queue for stale or invalidated answer capsules.
- **incremental eligibility witness** — optional pressure to record why a delta refresh was safe rather than merely faster.
- **stale-but-reviewable posture** — old answers may remain audit material without being current truth.
- **cache hit weaker than answer authority** — a standing anti-regrowth rule.



## Pass LXV additions

- **interaction trail** — a bounded transcript of filter, parameter, drill, sort, render, export, annotation, agent, and refusal events on an answer capsule.
- **render contract** — visible binding between answer and displayed table/chart/card, including transforms, limits, warnings, and hidden/suppressed states.
- **egress receipt** — detached-artifact receipt for CSV, spreadsheet, screenshot, copied table, embed, alert, report, or agent summary.
- **render spec as evidence** — steal the idea that interaction parameters and transforms are declarative enough to inspect.
- **export weaker than live capability** — a CSV/image/share should decay unless rehydrated through current authority.
- **annotation anchor without correction authority** — comments can point precisely without rewriting the answer.

## Pass LXVI additions

- **budget gate** — compact answer-attempt admission residue for resource, latency, cost, privacy, egress, detail, exemplar, payer/sponsor, and capability constraints.
- **degradation receipt** — requested-versus-served weakening card for exact-to-sketch, exact-to-sample, current-to-stale, full-to-top-k, complete-to-summary, or exemplar-to-aggregate-only answers.
- **uncertainty envelope** — compact wrapper around answer strength that composes exactness, estimator, sample, privacy, quality, freshness, tier, nondeterminism, and detail-exposure residue.
- **named estimator family** — steal the habit of naming HLL, T-Digest, reservoir sample, adaptive sample, or unknown family instead of saying merely “fast”.
- **review-only preview** — useful approximate answer that cannot promote until an explicit gate accepts its uncertainty.
- **degraded weaker than requested** — a standing anti-regrowth rule for agents, dashboards, exports, and cached previews.

## Pass LXVII additions

- **correction horizon** — compact open/closed/repair-only posture for late facts, identity repair, delete/revoke states, privacy/legal changes, and retained-change coverage.
- **backfill ledger** — reviewable campaign residue for historical repair: reason, authority, source coverage, recipe/run, validation, invalidated outputs, replacement answers, and residual gaps.
- **revocation fence** — boundary preventing withdrawn, superseded, erased, deleted, or policy-fenced answer material from being reused as current authority without rehydration.
- **change coverage card** — steal the habit of naming retained change-feed/time-travel/snapshot range before claiming a delta is complete.
- **timeline action class** — borrow visible commit/clean/rollback/savepoint-style action states without importing one table format.
- **old answer weaker than rehydrated current authority** — a standing anti-regrowth rule for dashboards, exports, and agents.

## Pass LXVIII additions

- **federation pact** — compact participant/collaboration contract for source authority, allowed fragments, capability envelope, freshness, quality, budget, privacy, lineage, egress, and refusal.
- **join warrant** — compact permitted-and-meaningful-join residue, stronger than key equality and smaller than a universal entity graph.
- **projection curtain** — compact release boundary for fields, dimensions, measures, grains, aggregate/list/detail posture, hidden policy, suppression/noise, activation, and export limits.
- **remote fragment label** — preserve where enforcement actually happened: local, remote, pushed-down, clean-room, delegated PDP, materialized, or composed.
- **composition refusal** — steal federation composition failure as a first-class healthy state, not an error to paper over.
- **join column as policy** — clean-room join policies are a great reminder that keys can be allowed for linking but forbidden for projection.
- **trust chain non-regrowth** — federation bootstrap helps one interaction without becoming global source truth.


## Pass LXIX additions

- **concept anchor** — compact semantic identity card that keeps concept, owner, definition, version/effective cut, label snapshots, status, and selectable/abstract posture separate.
- **crosswalk warrant** — compact mapping evidence with direction, equivalence grade, cardinality, split/merge loss, effective period, reviewer, no-map/refusal, and affected cells.
- **hierarchy cut** — compact rollup membership snapshot for one answer, comparison, render, or export.
- **label snapshot lane** — steal the idea that display text is useful evidence but should not be the concept key.
- **value-set expansion receipt** — a controlled set or rule expansion should be frozen for the answer that used it.
- **no-map as evidence** — unmapped members can change denominators and privacy thresholds, so they deserve first-class posture.
- **tag/term/domain separation** — informal discovery labels, governed business terms, and ownership domains should not be interchangeable cube axes.
- **rename-with-history** — prefer continuity-preserving rename over delete, but still carry the old label and review trail.

## Pass LXX additions

- **threshold witness** — compact trigger-condition evidence for answer-derived alerts, recommendations, or control-loop candidates.
- **action warrant** — compact permission-to-use record saying which consequence class a cube answer may support and under which freshness, quality, semantic, policy, budget, review, rate, and rollback conditions.
- **consequence receipt** — compact after-the-fact record for proposed, accepted, rejected, applied, no-op, duplicate-suppressed, inhibited, silenced, withdrawn, fenced, or errored consequences.
- **trigger weaker than warrant** — a breached cell is a candidate, not authority.
- **pending/firing/resolved lane** — steal alert state without importing an alerting product.
- **control-loop dampening** — tolerance, stabilization, cooldown, rate caps, and direction disable should be named before cube answers act on systems.
- **decision reason field** — cached/stale/error/default/disabled-style reasons keep flags, recommendations, and automations from looking magical.
- **consequence receipt not replay authority** — audit records explain what happened; they do not authorize doing it again.

## Pass LXXI additions

- **learning loop ledger** — steal MLOps run/evaluation discipline without importing a model registry.
- **holdout witness** — steal holdout/control/SRM habits without importing an experimentation platform.
- **feedback taint fence** — steal data-lineage and intervention-lineage caution for labels, rewards, examples, and agent memory.
- **behavior-policy evidence** — off-policy evaluation is a useful warning: exposure probabilities and candidate sets matter.
- **label maturity lane** — clicks, approvals, no-ops, delayed outcomes, corrections, and disputes are different label strengths.
- **learn-mode as observational only** — SlopOS D-CAPSHELL gives a perfect anti-regrowth pattern: reports may teach humans without auto-widening authority.
- **drift monitor not retraining warrant** — a monitor can open a docket, not silently mutate thresholds, models, or policies.


## Pass LXXII additions
- **scenario capsule** — possible-world answer wrapper smaller than a scenario platform.
- **counterfactual warrant** — explicit evidence for “would have happened if” language.
- **synthetic boundary** — mark that generated/imputed/simulated material cannot naturalize into observed fact.
- **forecast cutoff card** — keep horizon, cutoff, training cut, and backtest posture near the chart.
- **seed receipt** — reproducibility residue that stays weaker than truth.
- **possible-world anti-regrowth** — a standing rule that scenario outputs can inform review but cannot authorize action by being vivid.

## Pass LXXIII additions
- Steal MCP's explicit tool and root vocabulary without adopting MCP as the SlopOS datacube runtime: exposed capabilities, visible invocations, human denial, and boundary changes are the useful scar.
- Steal SQL-agent repair-loop transparency without adopting one framework: schema discovery, generated query, checker, execution, error repair, and result synthesis should leave receipts.
- Steal semantic-layer fail-closed posture: when modeled metrics/axes cannot answer, the cube should say so rather than generate a polished wrong number.
- Steal enterprise text-to-SQL benchmark humility: large schemas, external knowledge, dialects, multi-step workflows, and ambiguity mean translation warrants and clarification are not optional.
- Steal prompt-injection paranoia as design discipline: retrieved context, schema comments, old summaries, notebooks, and exported artifacts are untrusted data unless a leash and projection boundary say otherwise.

## Pass LXXIV additions
- Steal SLSA's distinction between artifact, build definition, builder, parameters, dependencies, and consumer verification, but apply it to answer generation without making builds the cube model.
- Steal in-toto's step/material/product/command/environment/byproduct shape for answer derivations, query plans, validation runs, exports, and model-mediated tool paths.
- Steal Rekor's append-only/monitorable transparency-log posture while refusing to treat log inclusion as semantic correctness or current authority.
- Steal RO-Crate's human/machine-readable research-object metadata idea for compact evidence packets, without choosing it as the SlopOS package format.
- Steal ReproZip's hard-won lesson that hidden environments and dependencies wreck reproducibility, but avoid forcing every cube answer into a container or notebook.
- Steal Nix-style input locks as a habit: lock before replay, and keep updating locks separate from claiming the historical answer still stands.


## Pass LXXV additions
- **custody trail** — steal chain-of-custody chronology without making every datacube artifact courtroom evidence.
- **retention charter** — steal records-schedule explicitness without choosing a global compliance system.
- **disposition receipt** — steal disposition-review and sanitization humility without claiming total downstream erasure.
- **fixity weaker than authority** — BagIt/OCFL-style manifests are excellent evidence, but only for byte/package integrity.
- **hold weaker than use permission** — object-lock/legal-hold patterns prevent overwrite/delete; they do not authorize dashboards, learning, or actions.
- **digest-only survival** — preserve enough to verify accountability when raw detail should not survive.

## Pass LXXVI additions

- Steal the DSA split between clear reason material, public/machine-readable scrutiny, redaction of personal data, internal complaint handling, and out-of-court review lanes; do not import content-moderation law as Ward machinery.
- Steal CFPB-style reasonable-investigation humility: preferred forms and perfect evidence packets should not become easy ways to avoid review.
- Steal HIPAA-style disagreement travel: when amendment is denied or partial, the disagreement can remain attached to later disclosures without rewriting the underlying record as if the dispute vanished.
- Steal CMS-style automatic escalation triggers for adverse upheld/high-consequence results, but keep escalation rules local and consequence-specific.
- Steal EU AI Act explanation-right pressure while keeping explanation, contest, adjudication, remedy, and fresh action authority as separate residues.

## Pass LXXVII additions

- Steal Backstage's “make ownership discoverable” instinct, but pair it with Ward's answer-local authority checks so ownership metadata does not become approval.
- Steal CODEOWNERS' cut-bound, branch-local review map and its visible failure modes; treat owner maps as loadable artifacts with syntax/access/size/freshness hazards.
- Steal DataHub/OpenMetadata role vocabulary pressure while refusing to freeze one global taxonomy; technical owner, business owner, data steward, payer, reviewer, and on-call are different lanes.
- Steal OpenFGA's relationship/condition/context shape for delegation warrants without choosing an authorization engine.
- Steal incident-management escalation discipline: page/assign, accept, coordinate, communicate, and close are separate states.

## Pass LXXVIII additions
- **governance handoff packet** — compile steward, delegate, escalation, currentness, budget, privacy, conflict, and agent-boundary evidence into one consequence-specific decision surface.
- **proof obligation ladder** — subject binding, duty/exclusion, currentness, caveats, acceptance, conflict, agent boundary, break-glass, rehydration, and projection checks before authority can spend.
- **negative authority fixtures** — test the attractive wrong moves, not just the happy path.
- **routing hint only** — allow low-risk owner hints without letting them approve repair, export, remedy, learning, or action.
- **governance evidence minimization** — prove authority without turning internal people, conflicts, incidents, or partner details into a new disclosure surface.

## Pass LXXIX additions
- **routing-hint-only mode** — safe contact/route display that cannot promote into authority.
- **break-glass closure** — emergency access with trigger, scope, expiry, rollback, and review debt.
- **projection leak flags** — explicit booleans for sealed conflict, raw fragment, reviewer, org-map, and incident leakage.
- **decision-state matrix** — outcome states with must-not-imply columns for downstream UI and packet checks.
- **weak-state positive fixtures** — tests that prove narrowed work can happen without weakening refusal discipline.
## Pass LXXX additions

- Steal OPA's decision-log audit/debug instinct without stealing event-as-grant semantics.
- Steal CloudEvents/OpenTelemetry envelope discipline without treating correlation IDs or event names as proof.
- Steal AuthZEN's explicit subject/action/context decision tuple while keeping it request-scoped and non-ambient.


## Pass LXXXI additions

- Steal CloudEvents subscription vocabulary for producer/intermediary/consumer clarity without letting subscriptions imply acceptance or authority.
- Steal OpenTelemetry's log-shaped event discipline while keeping governance state in structured attributes, not prose bodies or trace folklore.
- Steal OPA's audit/debug posture for decisions but require consumer receipts before downstream effects.
- Steal Kafka compaction scars: latest survivor is not full history, and tombstone retention becomes a governance currentness boundary.
- Steal historical downgrade as a first-class safe outcome: old evidence can remain inspectable without remaining spendable.

## Pass LXXXII additions

- Steal AuthZEN's separation between single evaluation, boxed multiple evaluations, and search, but keep Ward batches as non-authority reconciliation surfaces.
- Steal OpenFGA's check/read/expand/list-object distinction as humility: a relationship query shape does not become a global approval badge.
- Steal OPA's decision-log audit posture while refusing to let a batch log become a grant set.
- Steal CloudEvents and trace-context portability for correlation, not authority.
- Steal Kafka compaction scars again: search materializations can preserve latest rows while losing enough history to force historical-only downgrade.
- Steal UI table honesty: mixed counts, per-row states, and explicit omissions beat one confident summary badge.


## Pass LXXXIII additions

- Steal AuthZEN's humility around non-atomic pagination, but add Ward-specific governance-basis drift checks.
- Steal Kafka compaction's tombstone-retention warning as a replay-currentness guard for long-running searches.
- Steal NIST differential-privacy evaluation pressure for sealed/noisy counts: budget, privacy unit, query model, and side-channel closure matter as much as the number.

## Pass LXXXIV additions

- Steal NIST Privacy Framework purpose/processing discipline, but make it executable for Ward release receipts rather than broad program prose.
- Steal DPV's recipient, purpose, processing, storage, and measure vocabulary as pressure for compact release fields without importing a full privacy ontology.
- Steal ODRL's travelling prohibitions and duties, while refusing to let a policy container become an authority grant.
- Steal OAuth RAR's structured-request instinct: `export=true` is too weak for governance evidence crossing a boundary.
- Steal AC-4 information-flow discipline: where evidence travels is a separate question from who can view a UI.

## Pass LXXXV additions
- Steal status-purpose separation from verifiable-credential status lists: current status can be represented outside the original artifact.
- Steal scoped revocation from token revocation endpoints: invalidation has a bounded subject and may have cascading implications that need explicit policy.
- Steal evented attenuation from continuous access evaluation: downstream parties need typed signals, not hidden edits.

## Pass LXXXVI additions
- Steal account-lifecycle discipline from access-control guidance: terminations and transfers are explicit control events, not comments on an owner map.
- Steal shared-signal verification posture: receivers need typed status changes they can check, not hidden pointer rewrites.
- Steal status-reference separation from verifiable-credential status lists, but use it for Ward release/follow-up chains instead of credentials.
- Steal revocation humility: invalidating one old channel is not the same as proving all downstream consumers refreshed.
- Steal catalog ownership discoverability while refusing successor-as-authority semantics.

## Pass LXXXVII additions

- Steal transparency-log inclusion/consistency discipline, but keep Ward chain receipts smaller than a log and weaker than authority.
- Steal SCITT's plural-transparency-service humility: divergent receipt histories are possible, and relying parties need explicit scenario-bound checks.
- Steal Shared Signals receiver posture: status updates travel between peers, but receivers still need local policy and replay.
- Steal VC status-purpose separation: a current status pointer is typed evidence, not a universal valid/revoked truth.
- Steal proof-chain integrity from Data Integrity work while refusing proof-success-as-action-permission.

## Pass LXXXVIII additions

- Steal SCITT's plural-history humility: resolving a branch requires scenario-bound evidence, not whichever receipt arrived last.
- Steal transparency-log immutability: append a resolution receipt instead of rewriting the old chain.
- Steal Shared Signals receiver posture: status updates and notices are necessary, but receivers still apply local policy.
- Steal VC status-purpose separation: recovered status is typed evidence, not a universal grant.
- Steal federation privacy pressure: status/identity-like facts should stay purpose-bound, audience-bound, and minimized.

## Pass LXXXIX additions

- Steal continuous monitoring cadence from security-control practice, but make Ward's cadence object a small receipt instead of a broad program document.
- Steal Shared Signals and CAEP receiver humility: a signal is input to local posture, not proof of local action.
- Steal SET delivery scars: duplicate, delayed, or reordered event delivery means the receiver must record its own cut and cache subject.
- Steal token-revocation lifecycle posture: post-issuance invalidation should be explicit and scoped, not hidden mutation.
- Steal cache-invalidation anxiety from distributed systems: a cached governance resolution is useful only with refresh evidence and a visible no-authority label.


## Pass XC additions

- Steal CloudEvents source/id discipline for duplicate detection, but keep it as receiver observation rather than authority.
- Steal SET push/poll humility: acknowledgement and delivery order are transport facts, not proof that downstream governance caches are refreshed.
- Steal continuous-monitoring cadence pressure from NIST, but require Ward-specific cache-subject and no-authority closure.

## Pass XCI additions

- Steal SET push/poll humility: transport acknowledgement proves delivery mechanics, not local governance refresh.
- Steal CloudEvents subscription separation: producers, subscribers, intermediaries, and fanout managers are distinct evidence roles.
- Steal dead-letter queues as a design smell: failure to notify must become explicit stale-consumer quarantine, not aggregate success.

## Pass XCII additions

- Steal SET delivery humility again: transmission success and recipient acknowledgment are not proof of downstream consumer state.
- Steal CloudEvents source/id uniqueness as duplicate discipline, but refuse to let duplicate delivery become fresh refresh.
- Steal cloud dead-letter queues as explicit negative evidence: failure to deliver must become quarantine, not aggregate success.
- Steal registry/catalog discipline for Ward's own checkers: a refusal harness needs an auditable inventory once it grows.

## Pass XCIII additions

Borrow the split between event delivery, receiver-local processing, duplicate identity, and continuous monitoring from Shared Signals, SET delivery, CloudEvents, SCITT, and NIST ISCM. Do not borrow the temptation to display distributed receiver agreement as approval.

## Pass XCIV additions

- Steal AuthZEN's request/decision boundary without importing a PDP into Ward.
- Steal XACML's visible decision-state humility: allow, hold, refuse, not-applicable, and indeterminate must not collapse.
- Steal OpenFGA's request-local context caution: basis evidence can be valid for one check and unsafe as ambient authority.

## Pass XCV additions

- Borrow the enforcement-obligation split from XACML, the activity/entity/agent separation from PROV, and event identity discipline from CloudEvents without turning Ward receipts into authorization decisions.

## Pass XCVI additions

- Borrow PROV's entity/activity/agent separation, but keep Ward outcome observations smaller than provenance graphs.
- Borrow NIST audit-record outcome explicitness, but refuse audit-success-as-authority.
- Borrow OpenTelemetry semantic consistency for event attributes, but keep telemetry weaker than governance proof.
- Borrow XACML's decision/enforcement split, then add an observation split after enforcement.


## Pass XCVII additions

- Steal incident-response recovery humility from NIST: response/recovery evidence should feed risk-management learning, not vanish into cleanup.
- Steal compensating-transaction caution from distributed systems: undo logic is application-specific, retryable only by design, and sometimes manual.
- Steal saga vocabulary only as pressure, not as authority; Ward consequences are not universally compensable.
- Steal schema-directory hygiene from build/test catalogs: a schema without registered fixtures and checkers is an unreviewed promise.

## Pass XCVIII additions

- Steal the SRE habit of factual, contextual, blameless postmortem records, but do not let a postmortem or closure artifact become Ward authority.
- Steal action-item tracking discipline, but keep written action items separate from implemented and verified improvements.
- Steal incident-response continuous-improvement pressure from NIST, but keep lessons learned separate from rollback, remedy, export, and status-pointer authority.

## Pass XCIX additions

Steal PROV-style consistency checking and SRE action-item follow-through, but keep proof intake separated from remedy completion and authority.
