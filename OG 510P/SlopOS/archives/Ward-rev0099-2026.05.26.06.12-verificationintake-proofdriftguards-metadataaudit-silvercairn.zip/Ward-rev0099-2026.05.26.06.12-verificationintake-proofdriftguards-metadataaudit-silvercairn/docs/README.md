# Docs map

Current revision: `rev0099` — verification-intake receipts, proof-drift guards, and metadata lineage audit.

- `00-meta/` keeps charter, roadmap, trajectory, bibliography, lessons, construction protocol, research synthesis, source registers, and audit/refactor notes.
- `10-threat-model/` carries threat models for promoted risk surfaces.
- `20-assurance/` carries proof-obligation and checker-facing assurance surfaces.
- `30-architecture/` carries seam docs, residue spine material, receipt architectures, and specimen flows.
- `90-inspirations/` harvests stealable moves from outside systems and adjacent companion cubes.

Latest additions in rev0099:
- `docs/00-meta/research-synthesis-2026-05-26-pass-xcix.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-26-pass-xcix.md`
- `docs/00-meta/metadata-lineage-audit-refactor-2026-05-26-pass-xcix.md`
- `docs/10-threat-model/verification-intake-threat-model.md`
- `docs/20-assurance/governance-verification-intake-receipt-v0.md`
- `docs/30-architecture/verification-intake-proof-drift-guards-and-metadata-lineage-audit.md`
- `docs/30-architecture/specimen-flow-96-verification-intake-proof-drift-guards-and-metadata-lineage-audit.md`

Latest research pass: `docs/00-meta/research-synthesis-2026-05-26-pass-xcix.md`.
Latest datacube evaluation: `docs/00-meta/slopos-companions-evaluation-2026-05-26-pass-xcix.md`.
Latest specimen: `docs/30-architecture/specimen-flow-96-verification-intake-proof-drift-guards-and-metadata-lineage-audit.md`.

## Historical latest-addition blocks

Latest additions in rev0098:
- `docs/00-meta/research-synthesis-2026-05-26-pass-xcviii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-26-pass-xcviii.md`
- `docs/00-meta/tool-runbook-audit-refactor-2026-05-26-pass-xcviii.md`
- `docs/10-threat-model/remediation-closure-threat-model.md`
- `docs/20-assurance/governance-remediation-closure-receipt-v0.md`
- `docs/30-architecture/remediation-closures-verification-debts-and-runbook-audit.md`
- `docs/30-architecture/specimen-flow-95-remediation-closures-verification-debts-and-runbook-audit.md`

Latest additions in rev0097:
- `docs/00-meta/research-synthesis-2026-05-25-pass-xcvii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xcvii.md`
- `docs/00-meta/schema-catalog-audit-refactor-2026-05-25-pass-xcvii.md`
- `docs/10-threat-model/rollback-remediation-threat-model.md`
- `docs/20-assurance/governance-rollback-remediation-receipt-v0.md`
- `docs/30-architecture/rollback-remediations-remedy-handoffs-and-schema-catalog-audit.md`
- `docs/30-architecture/specimen-flow-94-rollback-remediations-remedy-handoffs-and-schema-catalog-audit.md`

Latest additions in rev0096:
- `docs/00-meta/research-synthesis-2026-05-25-pass-xcvi.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xcvi.md`
- `docs/00-meta/fixture-catalog-audit-refactor-2026-05-25-pass-xcvi.md`
- `docs/10-threat-model/outcome-observation-threat-model.md`
- `docs/20-assurance/governance-outcome-observation-receipt-v0.md`
- `docs/30-architecture/outcome-observations-rollback-guards-and-fixture-catalog-audit.md`
- `docs/30-architecture/specimen-flow-93-outcome-observations-rollback-guards-and-fixture-catalog-audit.md`


Latest additions in rev0095:
- `docs/00-meta/research-synthesis-2026-05-25-pass-xcv.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xcv.md`
- `docs/00-meta/doc-index-audit-refactor-2026-05-25-pass-xcv.md`
- `docs/10-threat-model/use-execution-threat-model.md`
- `docs/20-assurance/governance-use-execution-receipt-v0.md`
- `docs/30-architecture/use-executions-actual-effect-guards-and-doc-index-audit.md`
- `docs/30-architecture/specimen-flow-92-use-executions-actual-effect-guards-and-doc-index-audit.md`


Latest additions in rev0094:
- `docs/00-meta/research-synthesis-2026-05-25-pass-xciv.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xciv.md`
- `docs/30-architecture/specimen-flow-91-reuse-gates-consequence-binding-and-schema-audit.md`
- `docs/20-assurance/governance-reuse-gate-receipt-v0.md`
- `docs/10-threat-model/reuse-gate-threat-model.md`
- `docs/30-architecture/reuse-gates-consequence-binding-and-schema-audit.md`
- `docs/00-meta/schema-registry-audit-refactor-2026-05-25-pass-xciv.md`

Latest additions in rev0093:
- `docs/00-meta/research-synthesis-2026-05-25-pass-xciii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xciii.md`
- `docs/30-architecture/specimen-flow-90-receiver-convergence-overlap-cuts-and-registry-integrity.md`
- `docs/20-assurance/governance-receiver-convergence-receipt-v0.md`
- `docs/10-threat-model/receiver-convergence-threat-model.md`
- `docs/30-architecture/receiver-convergence-overlap-cuts-and-registry-audit.md`
- `docs/00-meta/registry-integrity-audit-refactor-2026-05-25-pass-xciii.md`

Latest additions in rev0092:
- `docs/00-meta/research-synthesis-2026-05-25-pass-xcii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xcii.md`
- `docs/30-architecture/specimen-flow-89-signal-notification-reconciliation-refresh-proofs-and-checker-registry.md`
- `docs/20-assurance/governance-signal-notification-reconciliation-receipt-v0.md`
- `docs/10-threat-model/signal-notification-reconciliation-threat-model.md`
- `docs/30-architecture/signal-notification-reconciliation-refresh-proofs-and-checker-registry.md`
- `docs/00-meta/checker-suite-audit-refactor-2026-05-25-pass-xcii.md`

Latest additions in rev0090:
- `docs/00-meta/research-synthesis-2026-05-25-pass-xc.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xc.md`
- `docs/30-architecture/specimen-flow-87-signal-ingestion-receiver-observations-and-race-guards.md`
- `docs/20-assurance/governance-signal-ingestion-receipt-v0.md`
- `docs/10-threat-model/signal-ingestion-and-receiver-observation-threat-model.md`
- `docs/30-architecture/signal-ingestion-receiver-observations-and-race-guards.md`

Latest additions in rev0089:
- `docs/00-meta/research-synthesis-2026-05-24-pass-lxxxix.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-24-pass-lxxxix.md`
- `docs/30-architecture/specimen-flow-86-recertification-receipts-cache-invalidation-and-refresh-signals.md`
- `docs/20-assurance/governance-recertification-receipt-v0.md`
- `docs/10-threat-model/recertification-cache-invalidation-threat-model.md`
- `docs/30-architecture/recertification-receipts-cache-invalidation-and-refresh-signals.md`

Latest additions in rev0088:
- `docs/00-meta/research-synthesis-2026-05-23-pass-lxxxviii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-23-pass-lxxxviii.md`
- `docs/30-architecture/specimen-flow-85-dispute-resolution-and-current-head-recovery.md`
- `docs/20-assurance/governance-dispute-resolution-receipt-v0.md`
- `docs/10-threat-model/dispute-resolution-and-current-head-recovery-threat-model.md`
- `docs/30-architecture/dispute-resolution-current-head-recovery.md`

Latest additions in rev0087:
- `docs/00-meta/research-synthesis-2026-05-23-pass-lxxxvii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-23-pass-lxxxvii.md`
- `docs/30-architecture/specimen-flow-84-chain-integrity-dispute-forks-and-canonical-heads.md`
- `docs/20-assurance/governance-chain-integrity-receipt-v0.md`
- `docs/10-threat-model/chain-integrity-and-dispute-forks-threat-model.md`
- `docs/30-architecture/chain-integrity-dispute-forks-and-canonical-heads.md`

Latest additions in rev0086:
- `docs/00-meta/research-synthesis-2026-05-23-pass-lxxxvi.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-23-pass-lxxxvi.md`
- `docs/30-architecture/specimen-flow-83-succession-transfers-status-channel-rotation.md`
- `docs/20-assurance/governance-succession-transfer-receipt-v0.md`
- `docs/10-threat-model/succession-transfer-threat-model.md`
- `docs/30-architecture/succession-transfers-and-status-channel-rotation.md`

Latest additions in rev0085:
- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxv.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxv.md`
- `docs/30-architecture/specimen-flow-82-release-followups-recipient-acks-and-stale-bundle-quarantine.md`
- `docs/20-assurance/governance-evidence-release-followup-receipt-v0.md`
- `docs/10-threat-model/evidence-release-followup-threat-model.md`
- `docs/30-architecture/release-followups-recipient-acks-and-stale-bundle-quarantine.md`

Latest additions in rev0084:
- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxiv.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxiv.md`
- `docs/30-architecture/specimen-flow-81-evidence-release-recipient-scope-and-export-guards.md`
- `docs/20-assurance/governance-evidence-release-receipt-v0.md`
- `docs/10-threat-model/evidence-release-threat-model.md`
- `docs/30-architecture/evidence-release-recipient-scope-and-export-guards.md`

Latest additions in rev0083:
- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxiii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxiii.md`
- `docs/30-architecture/specimen-flow-80-search-continuity-sealed-omissions-and-cursor-drift.md`
- `docs/20-assurance/governance-search-continuity-receipt-v0.md`
- `docs/10-threat-model/search-continuity-and-sealed-omission-threat-model.md`
- `docs/30-architecture/search-continuity-sealed-omissions-and-cursor-drift.md`

Latest additions in rev0082:
- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxii.md`
- `docs/30-architecture/specimen-flow-79-batch-search-receipts-mixed-state-and-projection-joins.md`
- `docs/20-assurance/governance-batch-search-receipt-v0.md`
- `docs/10-threat-model/batch-search-replay-threat-model.md`
- `docs/30-architecture/batch-search-mixed-state-guards.md`

Latest additions in rev0081:
- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxi.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxi.md`
- `docs/30-architecture/specimen-flow-78-consumer-receipts-replay-diffs-and-compaction-guards.md`
- `docs/20-assurance/governance-decision-consumer-receipt-v0.md`
- `docs/10-threat-model/consumer-replay-threat-model.md`
- `docs/30-architecture/consumer-replay-diff-and-compaction-guards.md`

Latest additions in rev0080:
- `docs/00-meta/research-synthesis-2026-05-21-pass-lxxx.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-21-pass-lxxx.md`
- `docs/30-architecture/specimen-flow-77-governance-decision-event-projection-and-replay.md`
- `docs/20-assurance/governance-decision-event-v0.md`
- `docs/10-threat-model/decision-event-threat-model.md`
- `docs/30-architecture/decision-event-projection-and-replay.md`

Latest additions in rev0079:
- `docs/00-meta/research-synthesis-2026-05-21-pass-lxxix.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-21-pass-lxxix.md`
- `docs/30-architecture/specimen-flow-76-routing-hint-break-glass-and-projection-closure.md`
- `docs/20-assurance/governance-decision-state-matrix.md`
- `docs/30-architecture/routing-hint-and-break-glass-closures.md`

Latest additions in rev0078:
- `docs/00-meta/research-synthesis-2026-05-21-pass-lxxviii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-21-pass-lxxviii.md`
- `docs/30-architecture/specimen-flow-75-governance-handoff-packet-proof-obligations-and-decay-fixtures.md`
- `docs/10-threat-model/governance-handoff-threat-model.md`
- `docs/20-assurance/governance-proof-obligations.md`
- `docs/30-architecture/datacube-residue-spine.md`
- `docs/30-architecture/governance-handoff-packet-v0.md`
- `docs/30-architecture/cross-cube-governance-seams.md`

- Latest research pass: `docs/00-meta/research-synthesis-2026-05-25-pass-xc.md`.
- Latest datacube evaluation: `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xc.md`.
- Latest specimen: `docs/30-architecture/specimen-flow-87-signal-ingestion-receiver-observations-and-race-guards.md`.


## Pass LXXXIV evidence-release receipt surfaces

- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxiv.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxiv.md`
- `docs/30-architecture/specimen-flow-81-evidence-release-recipient-scope-and-export-guards.md`
- `docs/20-assurance/governance-evidence-release-receipt-v0.md`
- `docs/10-threat-model/evidence-release-threat-model.md`
- `docs/30-architecture/evidence-release-recipient-scope-and-export-guards.md`

## Pass LXXXIII search-continuity receipt surfaces

- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxiii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxiii.md`
- `docs/30-architecture/specimen-flow-80-search-continuity-sealed-omissions-and-cursor-drift.md`
- `docs/20-assurance/governance-search-continuity-receipt-v0.md`
- `docs/10-threat-model/search-continuity-and-sealed-omission-threat-model.md`
- `docs/30-architecture/search-continuity-sealed-omissions-and-cursor-drift.md`

## Pass LXXXII batch/search receipt surfaces

- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxii.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxii.md`
- `docs/30-architecture/specimen-flow-79-batch-search-receipts-mixed-state-and-projection-joins.md`
- `docs/20-assurance/governance-batch-search-receipt-v0.md`
- `docs/10-threat-model/batch-search-replay-threat-model.md`
- `docs/30-architecture/batch-search-mixed-state-guards.md`

## Pass LXXXI consumer receipt surfaces

- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxi.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxi.md`
- `docs/30-architecture/specimen-flow-78-consumer-receipts-replay-diffs-and-compaction-guards.md`
- `docs/20-assurance/governance-decision-consumer-receipt-v0.md`
- `docs/10-threat-model/consumer-replay-threat-model.md`
- `docs/30-architecture/consumer-replay-diff-and-compaction-guards.md`

## Pass LXXX decision-event surfaces

- `docs/00-meta/research-synthesis-2026-05-21-pass-lxxx.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-21-pass-lxxx.md`
- `docs/30-architecture/specimen-flow-77-governance-decision-event-projection-and-replay.md`
- `docs/20-assurance/governance-decision-event-v0.md`
- `docs/10-threat-model/decision-event-threat-model.md`
- `docs/30-architecture/decision-event-projection-and-replay.md`


## Pass LXXXV release follow-up receipt surfaces

- `docs/00-meta/research-synthesis-2026-05-22-pass-lxxxv.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-22-pass-lxxxv.md`
- `docs/30-architecture/specimen-flow-82-release-followups-recipient-acks-and-stale-bundle-quarantine.md`
- `docs/20-assurance/governance-evidence-release-followup-receipt-v0.md`
- `docs/10-threat-model/evidence-release-followup-threat-model.md`
- `docs/30-architecture/release-followups-recipient-acks-and-stale-bundle-quarantine.md`

## Pass LXXXVI succession/transfer receipt surfaces

- `docs/00-meta/research-synthesis-2026-05-23-pass-lxxxvi.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-23-pass-lxxxvi.md`
- `docs/30-architecture/specimen-flow-83-succession-transfers-status-channel-rotation.md`
- `docs/20-assurance/governance-succession-transfer-receipt-v0.md`
- `docs/10-threat-model/succession-transfer-threat-model.md`
- `docs/30-architecture/succession-transfers-and-status-channel-rotation.md`

## Latest pass — LXXXVII

- Research: `docs/00-meta/research-synthesis-2026-05-23-pass-lxxxviii.md`
- SlopOS/companions evaluation: `docs/00-meta/slopos-companions-evaluation-2026-05-23-pass-lxxxviii.md`
- Specimen: `docs/30-architecture/specimen-flow-85-dispute-resolution-and-current-head-recovery.md`
- Assurance: `docs/20-assurance/governance-chain-integrity-receipt-v0.md`
- Architecture: `docs/30-architecture/chain-integrity-dispute-forks-and-canonical-heads.md`
- Threat model: `docs/10-threat-model/chain-integrity-and-dispute-forks-threat-model.md`

## Pass LXXXVIII additions

- `docs/20-assurance/governance-dispute-resolution-receipt-v0.md`
- `docs/30-architecture/dispute-resolution-current-head-recovery.md`
- `docs/10-threat-model/dispute-resolution-and-current-head-recovery-threat-model.md`
- `docs/30-architecture/specimen-flow-85-dispute-resolution-and-current-head-recovery.md`

## Latest pass — rev0091 / pass XCI

- `docs/00-meta/research-synthesis-2026-05-25-pass-xci.md`
- `docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-xci.md`
- `docs/30-architecture/specimen-flow-88-signal-notification-stale-consumer-acks-and-dead-letter-fences.md`
- `docs/20-assurance/governance-signal-notification-receipt-v0.md`
- `docs/10-threat-model/signal-notification-and-stale-consumer-threat-model.md`
- `docs/30-architecture/signal-notification-stale-consumer-acks-and-dead-letter-fences.md`

