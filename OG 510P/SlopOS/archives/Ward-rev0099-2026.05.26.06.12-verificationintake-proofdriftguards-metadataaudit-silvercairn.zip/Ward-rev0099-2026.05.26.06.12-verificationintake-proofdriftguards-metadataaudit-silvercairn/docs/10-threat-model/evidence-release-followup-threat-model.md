# Evidence-release follow-up threat model

## Asset

A Ward evidence-release receipt and the artifacts derived from it: public projections, restricted review bundles, held-recheck notices, and audit snapshots.

## Core threat

A released bundle keeps circulating after its basis changed. The old artifact can then appear current, complete, safe, or authority-bearing even after expiry, correction, revocation, sealed-omission change, owner-map drift, or downstream misuse.

## Threats

- recipient acknowledgment treated as approval or stewardship acceptance;
- expired release marked current because no one checked the release horizon;
- correction performed by editing the original release receipt in place;
- revocation notice lacking a status pointer, leaving cached artifacts unverifiable;
- stale bundle forwarded without quarantine;
- public correction leaking sealed evidence or exact hidden counts;
- refresh notice widening recipient or purpose;
- dropped forbidden effects from the original release;
- status channel mismatch, so the recipient never receives the revocation/correction;
- downstream consumer reuses a held-recheck notice as a real release;
- follow-up event performs action, remedy, repair, learning, or budget effects;
- historical release erased, destroying auditability.

## Required refusal posture

Ward must refuse any follow-up that cannot bind the original release digest, mirror source state, preserve recipient/purpose/channel, carry a no-authority label, expose status pointer for status-bearing changes, and preserve all original forbidden effects.
