# Evidence-release threat model

## Assets

- governance handoff packets;
- decision events and consumer receipts;
- batch/search and search-continuity receipts;
- sealed omission facts;
- reviewer, conflict, incident, owner-map, partner, and raw-fragment evidence;
- released artifacts, bundles, links, and exported summaries.

## Adversary goals

- turn a public evidence export into approval authority;
- remove “not authority” labels from detached artifacts;
- infer sealed conflicts or private owner maps through exact omission counts;
- export mixed-state results as one current/green result;
- drop downgrade reasons or forbidden-effect fences;
- ship stale page-two results after cursor, owner-map, projection-policy, or compaction drift;
- release raw partner fragments under a public or partner-public label;
- reuse an old release after the source receipt expires, is superseded, or needs recheck;
- forward a restricted review bundle outside the recipient/purpose class;
- treat regulator/audit release as semantic repair, remedy, or privacy waiver.

## Controls

`ward.governance.evidence-release-receipt.v0` requires:

- source id/path/digest parity;
- source query/projection-policy mirroring;
- source result-state and drift-state mirroring;
- recipient and purpose binding;
- field allowlist plus sensitive field denylist;
- safe sealed-omission disclosure;
- visible no-authority watermark;
- retention limit and refresh/revocation channel;
- preservation of source forbidden effects.

## Non-goals

The receipt does not solve:

- full data-loss prevention;
- legal privilege determination;
- cryptographic packaging;
- end-user consent adjudication;
- authorization-policy evaluation;
- downstream enforcement after malicious forwarding.

Those belong to neighboring systems. Ward's job is to refuse release artifacts that would otherwise launder authority, leak governance evidence, or hide uncertainty.
