# Receiver-convergence threat model

## Boundary

This threat model begins after one or more signal-notification reconciliation receipts exist. The attacker wants a clean receiver, latest receiver, duplicate receiver, or receiver majority to make the wider Ward surface look current and safe while another receiver is lagging, forked, or observing a different status-channel cut.

## Threats

1. **Receiver quorum laundering** — two clean receivers outvote a stale or forked receiver and are displayed as authority.
2. **Latest receiver laundering** — the most recent receiver observation overwrites older divergent status-channel cuts.
3. **Overlap hiding** — a convergence result hides that receiver observations cover different affected-consumer sets.
4. **Receiver-set shrinkage** — expected receiver count drops a required receiver before calculating convergence.
5. **Divergent-cut collapse** — two valid observations over different status-channel cuts are summarized as converged.
6. **Duplicate receiver promotion** — a replayed receiver observation is treated as a fresh convergence proof.
7. **Fork winner injection** — a forked receiver branch selects a winner without dispute-resolution machinery.
8. **Projection leak** — public convergence leaks raw receiver ids, status-channel names, private org maps, sealed signal payloads, or exact hidden counts.
9. **Status-pointer mutation** — convergence updates the global status pointer even though it is only downstream monitoring evidence.
10. **Registry drift** — new checker or fixture families appear on disk but never join the suite.

## Controls added in pass XCIII

- Source reconciliation refs are byte-digest checked.
- Receiver set and overlap digests are recomputed.
- Every required receiver observation must point at a source reconciliation ref.
- Divergent cuts, lagging receivers, duplicate observations, and receiver forks have explicit non-current states.
- Public projections are hashed/class-only and carry no-authority labels.
- High-consequence effects, status-pointer mutations, and receiver-quorum authority are refused.
- Registry integrity is checked as part of the governance suite.

## Non-goals

Receiver-convergence receipts do not poll receivers, deliver notifications, resolve forks, mutate current heads, choose global winners, or authorize downstream actions. They record whether the currently observed receiver set is converged enough to proceed to replay/refresh, or whether unsafe receivers remain quarantined/held.
