# Outcome-observation threat model

Pass XCVI treats the observed result after a use-execution receipt as a separate attack surface.

## Threats

- a public display execution is followed by a hidden export or raw evidence release;
- an internal review replay leaks public receiver identities or sealed governance payloads;
- a no-execution hold is falsely reported as observed safe execution;
- a mismatch is logged but not quarantined;
- rollback language is used as authority to mutate a source gate, use-execution receipt, or status pointer;
- an unavailable observation is rendered as a green badge;
- observed effect, target, recipient class, projection policy, or observation window drifts;
- outcome telemetry is consumed as approval, recertification, export authority, repair authority, remedy authority, or learning-loop permission.

## Containment

Outcome-observation receipts bind observations to source use-execution bytes and make mismatch, unavailable, and no-op outcomes explicit. A valid receipt may confirm that an expected display or review occurred, confirm that a no-op hold stayed no-op, hold because observation is unavailable, or quarantine a mismatch and require rollback review. It cannot grant authority or update current status.
