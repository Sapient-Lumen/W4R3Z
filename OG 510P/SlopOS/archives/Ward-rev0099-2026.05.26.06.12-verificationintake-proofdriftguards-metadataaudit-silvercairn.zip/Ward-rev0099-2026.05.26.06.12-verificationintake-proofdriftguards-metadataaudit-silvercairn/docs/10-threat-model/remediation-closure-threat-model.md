# Remediation-closure threat model

Pass XCVIII treats closure as a dangerous word. Closure can mean recordkeeping closure, review closure, handoff acknowledgment, external remediation proof, quarantine clearance, public correction, or durable remedy. Ward must keep those meanings separate.

## Threats

- **Closure as remedy** — a closed review is displayed as a completed remedy.
- **Handoff acknowledgment as completion** — Harbor/Helm/SlopOS receipt of a handoff request is treated as proof that a correction happened.
- **No-remediation as durable trust** — matched/no-op closure is reused later without refresh or source replay.
- **Quarantine clearance by paperwork** — a closure receipt clears quarantine without separate external proof and authority.
- **External proof laundering** — an external proof exists but is not byte-bound, projected, or replayed; the closure receipt treats it as authoritative anyway.
- **Source-history mutation** — closure edits the rollback-remediation, outcome-observation, or use-execution receipt instead of appending a new receipt.
- **Status-pointer mutation** — closure updates a current status head or status channel directly.
- **Public closure leak** — public closure output reveals reviewer identity, private org maps, partner fragments, sealed outcome payloads, or private contact channels.
- **Blameful closure** — a closure/public postmortem blames individuals rather than preserving factual, bounded remediation evidence.
- **Action-item theater** — a closure records an action item but omits tracking, verification debt, or next recheck.

## Controls in v0

The remediation-closure receipt requires source rollback-remediation byte checks, source review-handoff digest mirrors, closure-scope digest, verification-evidence digest, no-authority labels, public projection minimization, explicit verification debt, and forbidden-effect fences for remedy, rollback, repair, export, learning use, status-pointer mutation, quarantine clearance, and authority laundering.

## Research pressure

NIST SP 800-61 Rev. 3 frames incident response and recovery as part of continuous risk-management improvement, not as a one-time closure event (`EXT-NIST-SP-800-61R3-2025`). Google SRE guidance makes postmortems useful only when they are factual, contextual, widely learnable, and tied to trackable action items (`EXT-GOOGLE-SRE-POSTMORTEM-WORKBOOK`). Google's action-item guidance pressures Ward to distinguish written action items from implemented improvements (`EXT-GOOGLE-POSTMORTEM-ACTION-ITEMS`).
