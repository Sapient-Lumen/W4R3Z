# Search continuity and sealed omission threat model

Pass LXXXIII models search continuity as a hostile boundary. The attacker does not need to forge a governance packet. They can wait for page two, alter the owner-map epoch, trigger compaction, change projection policy, or use public row counts to learn sealed governance facts.

## Assets

- governance handoff packets and decision events;
- decision consumer receipts;
- batch/search receipts;
- cursor tokens and page digests;
- owner-map epochs and stewardship currentness;
- projection-policy digests;
- packet compaction watermarks;
- sealed conflict, reviewer, incident, partner, and private org-map evidence.

## Threats

1. **Cursor drift laundering** — page two arrives after an owner-map or projection-policy change but is rendered as a same search.
2. **Compaction amnesia** — packet or event tombstones age out, but a continuation still claims current replay.
3. **Query mutation** — an agent changes subject, scope, filter, or consequence class while reusing a cursor.
4. **Exact sealed-count oracle** — a public or external view reveals the exact number of hidden governance rows.
5. **Reason-class oracle** — omission reasons reveal private org structure, reviewer identities, incident details, conflicts, or partner fragments.
6. **Complete-result lie** — a result with hidden, held, compacted, or projection-filtered rows claims complete coverage.
7. **Trace-as-authority collapse** — a CloudEvents/trace identifier is treated as proof that later pages share governance authority.
8. **DP theater** — a noisy count is claimed without privacy unit, budget, composition window, or exact-count fallback controls.
9. **Batch-to-export jump** — continuation receipts become convenient export/action approvals.

## Controls

Ward uses a search-continuity receipt with:

- page digest closure;
- cursor-basis comparison;
- drift response states;
- sealed omission disclosure modes;
- existence-oracle guard;
- completeness/gap closure;
- high-consequence effect refusal;
- digest-bound references back to batch/search receipts.

## Refusal posture

When in doubt, the receipt should choose `held_recheckpoint_required` or `new_search_required`. A held result is safer than a continued result that hides authority drift.
