# Signal-ingestion and receiver-observation threat model

Pass XC adds the threat model for incoming refresh, revocation, projection, successor, branch, and quarantine signals.

## Threats

- duplicate push delivery treated as a new revocation or new current-state proof;
- poll return order treated as causal order;
- transport acknowledgement treated as downstream consumer refresh;
- a stale signal with an old sequence number revives an old current head;
- an unauthenticated sender or unregistered stream drives cache invalidation;
- a signal subject is rebound to a different release, purpose, recipient, or cache subject;
- source/id collisions collapse unrelated signals;
- conflicting status and revocation signals are auto-resolved by “latest received”;
- public signal projection leaks sealed payload, private steward, recipient contact, conflict, or exact hidden-count material;
- cache invalidation signals trigger action, export, repair, remedy, or budget effects directly;
- a receiver-local signal log is treated as proof that every stale consumer refreshed.

## Controls added in pass XC

- source recertification byte-digest replay;
- subject and cache-subject digest binding;
- canonical event key and source/id pair checks;
- sender/channel authentication checks;
- duplicate-window and sequence/watermark checks;
- conflict hold state with no automatic winner;
- explicit follow-up binding for recertification or cache invalidation;
- no-authority projection labels;
- forbidden-effect fences for signal-as-authority, duplicate-as-new-change, stale-as-current, push-ack-as-refresh, and poll-order-as-causality failures.
