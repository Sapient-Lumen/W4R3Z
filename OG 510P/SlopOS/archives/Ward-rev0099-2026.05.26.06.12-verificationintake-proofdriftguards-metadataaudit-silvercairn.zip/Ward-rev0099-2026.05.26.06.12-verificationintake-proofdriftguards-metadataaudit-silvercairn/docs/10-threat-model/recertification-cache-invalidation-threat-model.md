# Recertification cache-invalidation threat model

## Scope

This threat model covers cached governance dispute-resolution receipts after they have been consumed by a downstream cube, UI, export bundle, or SlopOS attachment. The protected object is cache currentness, not the original governed answer.

## Threats

- **Cache-as-authority:** a previously valid dispute resolution is reused as approval, export permission, action authority, repair authority, or remedy authority.
- **Missed refresh signal:** a consumer keeps using a cached recovered head after a follow-up, revocation, quarantine, transfer, or fork update.
- **Status-channel replay:** an old status pointer is replayed after channel rotation.
- **Projection drift:** a cache survives after the projection policy or recipient class changed.
- **Owner-map drift:** a cache continues after owner-map epoch or steward/successor evidence changed.
- **Branch drift:** a resolved branch is superseded, quarantined, or historical-only after the cached cut.
- **Silent stale bundle:** a detached release bundle keeps circulating without visible invalidation.
- **Hidden invalidation:** a system invalidates privately but leaves public surfaces green.
- **Leakage during recertification:** public cache-status output reveals sealed branch details, internal reviewer identities, conflicts, private recipient contacts, org maps, or exact hidden counts.
- **Recertification-as-grant:** a recertified cache is treated as proof that downstream action may proceed without replaying the source packet.

## Controls

- source dispute-resolution id/path/byte digest checks;
- source dispute-resolution validator replay;
- deterministic cache-subject digest;
- status-channel and recipient-refresh-channel recheck;
- projection-policy, owner-map, successor-state, branch-state, follow-up-signal, and clock-window checks;
- explicit next-recheck due time;
- invalidated, quarantined, historical-only, and recheck-required states;
- stale-consumer notification;
- no-source-mutation invariant;
- public cache-state minimization;
- no-authority watermark;
- forbidden-effect union preservation.

## Residual risk

A v0 recertification receipt cannot prove that every external consumer has observed the refresh signal. Ward therefore treats acknowledgement as weaker than authority and keeps stale-bundle quarantine as a continuing lifecycle concern.
