# Verification-intake threat model

Pass XCIX treats external proof as a sharp edge. Proof can be useful, but it can also launder authority when a downstream cube says "Harbor fixed it" or "the verifier passed" without replaying scope, audience, projection, conflict, and quarantine state.

## Threats

- **Proof as authority** — external proof is displayed as approval to export, repair, learn, or act.
- **Proof as remedy completion** — a proof artifact is treated as completed remedy rather than proof that still needs local consequence gates.
- **Quarantine clearance by proof intake** — verified proof clears quarantine without a separate authority surface.
- **Proof drift** — proof subject, channel, audience, purpose, closure state, or projection policy changes after intake.
- **Verifier conflict omission** — a conflicted verifier accepts proof without recording independence checks.
- **Conflict auto-winner** — two incompatible proof artifacts arrive and Ward chooses one without a dispute path.
- **Absent proof theater** — a missing proof is recorded as a successful verification.
- **Public proof leak** — public status reveals private proof payload, issuer identity, status-channel internals, partner fragments, or org maps.
- **Source-history mutation** — verification edits the remediation closure instead of appending a new receipt.
- **Status-pointer mutation** — verification updates current status directly.

## Controls in v0

Verification-intake receipts require source remediation-closure byte checks, mirrored closure state, proof-scope digest, proof-evidence digest, audience/purpose/subject checks, verifier conflict checks, no-authority labels, projection minimization, explicit verification debt, and forbidden-effect fences for authority, remedy, rollback, repair, export, learning use, status-pointer update, and quarantine clearance.

## Research pressure

NIST SP 800-61 Rev. 3 keeps response, recovery, and improvement inside ongoing risk management rather than one-time closure (`EXT-NIST-SP-800-61R3-2025`). Google SRE postmortem practice pressures action items to have ownership and follow-through rather than becoming closure theater (`EXT-GOOGLE-SRE-POSTMORTEM-WORKBOOK`, `EXT-GOOGLE-POSTMORTEM-ACTION-ITEMS`). W3C PROV Constraints adds pressure for explicit consistency checking over provenance bundles (`EXT-W3C-PROV-CONSTRAINTS-2013`).
