# Batch/search replay threat model

Ward now has packet validation, decision events, consumer receipts, and consumer replay/compaction guards. The next realistic attack surface is **aggregation**: a UI, query API, report, batch job, or review queue that combines many consumer receipts and makes the set look simpler than it is.

## Assets

- member-level state (`routing_hint_only`, `consequence_grade`, `historical_receipt_only`, etc.);
- member-level replay status (`replayed_current`, `downgraded_historical`, `held_pending_packet`);
- projection class and view;
- forbidden-effect fences;
- packet/event/consumer receipt digests;
- downgrade reasons;
- pagination and omission facts;
- public/restricted/sealed projection boundaries.

## Threats

### T1: Green-badge laundering

A batch with one current decision, one owner hint, and one historical receipt renders as “3 allowed.” This hides weakness and makes the aggregate appear stronger than any member is permitted to be.

Required closure: `mixed_state_visible=true`, `no_single_badge=true`, state counts, replay-status counts, and per-member rows.

### T2: Authority-count inflation

A search result reports a total count of “authorized” resources even though some results are route-only, stale, omitted due to projection, or unavailable after compaction.

Required closure: no raw authority counts; count basis must be projection-safe and omission-aware.

### T3: Public projection leak

A public list result includes a restricted break-glass member, reviewer lane, sealed conflict, private org map, raw partner fragment, or incident detail.

Required closure: public/external projections cannot include restricted members and cannot inline sensitive evidence.

### T4: Forbidden-effect evaporation

A member forbids export/action/remedy/reuse, but the batch summary drops that fence because the aggregate renderer only knows one common field.

Required closure: aggregate forbidden-effect union must exactly match the member union.

### T5: Member-state upgrade

A routing-hint consumer receipt becomes consequence-grade because the batch renderer copies the strongest member state to every row.

Required closure: member mirrors are validated against referenced consumer receipts by digest.

### T6: Pagination drift

A second page is fetched with changed query scope or projection filter, causing rows to repeat, disappear, or widen without being visible.

Required closure: cursor must bind to query digest and projection filter digest; partial results and omission counts must be disclosed.

### T7: Historical replay laundering

A compacted-away or unreplayable historical receipt is included in a current batch and treated as live evidence.

Required closure: replay-status counts, minimum replay status, compaction posture, and downgrade reasons are preserved.

### T8: Aggregate high-consequence action

A mixed batch performs export, action re-enable, privacy waiver, remedy, budget spend, or semantic repair because at least one member was consequence-grade.

Required closure: aggregate effects stay within the safe batch set; high-consequence effects remain per-member and require current packet replay.

## Non-goals

This threat model does not define a search engine, PDP, catalog, query optimizer, pagination protocol, UI component, or event bus. It only constrains how Ward surfaces may summarize already-consumed governance decisions.
