# Consumer replay threat model

## Threat surface

Governance decision events are designed to travel. The threat is not only that an event is forged. The harder threat is that a real event is copied, retained, compacted, indexed, summarized, rendered, or attached in a way that changes its force.

## Threats

| Threat | Failure mode | Closure in rev0081 |
|---|---|---|
| Event digest drift | consumer references bytes different from the checked event | receipt carries `event_sha256`; checker recomputes it |
| State upgrade | weak event becomes strong consumer state | checker rejects consumer states stronger than event state |
| Forbidden-effect loss | minimization drops `export_without_packet` or similar fences | receipt must preserve all event forbidden effects |
| Packetless action | consumer acts from event bytes after packet replay failed | non-current replay allows only historical-safe effects |
| Compaction survivor illusion | latest survivor row poses as full audit/current authority | compacted streams require tombstone/snapshot/watermark posture |
| Tombstone disappearance | delete/supersession marker vanishes before cold consumer scan | compacted-away material must downgrade to historical receipt |
| Projection leak | public consumer view leaks sealed governance evidence | public/external receipts inherit projection leak checks |
| CH-AREF authority inflation | artifact identity attachment becomes semantic permission | SlopOS receipt preserves identity-not-trust semantics |
| Search/result laundering | index or dashboard returns an old event as current authority | replay status and materialized state must be visible |
| Agent transcript laundering | an assistant quotes a decision event as permission | consumer receipt must keep non-authority statement and replay status |

## Security posture

A valid consumer receipt proves only a bounded consumer behavior. It does not prove that all consumers behaved safely, that the event is current everywhere, or that a later packet would reach the same state.

## Design scar

Authority can be lost in a downstream copy. It must not be gained there.
