# Signal-notification reconciliation threat model

## Boundary

This threat model begins after a signal-ingestion receipt has been accepted and a signal-notification receipt has attempted fanout. The attacker wants a notification, acknowledgment, retry, duplicate, or dead-letter outcome to look like consumer-local refresh.

## Threats

1. **Acknowledgment laundering** — a delivery acknowledgment is treated as proof that the consumer replayed the source packet or invalidated its cache.
2. **Dead-letter laundering** — retry exhaustion or dead-letter routing is displayed as a successful fanout.
3. **Partial-complete laundering** — one or two refreshed consumers let a batch claim every consumer is safe.
4. **Consumer-set drift** — a reconciliation receipt silently uses a smaller affected-consumer set than the source notification.
5. **Digest substitution** — a consumer refresh is proven against a different notification, recertification receipt, cache subject, recipient class, or purpose.
6. **Duplicate promotion** — a duplicate notification is converted into a fresh refresh event.
7. **Conflict winner injection** — a conflict-hold notification is reconciled by choosing a winner without dispute resolution.
8. **Public identity leakage** — public reconciliation reveals raw consumer identities, private contacts, sealed signal payloads, or exact hidden counts.
9. **Status-pointer mutation** — reconciliation updates the current status pointer even though only recertification or later chain/dispute machinery may do that.
10. **Checker-suite drift** — as receipt validators multiply, hardcoded checker lists omit new validators and allow stale fixture families to escape `make check`.

## Controls added in pass XCII

- `source_signal_notification_ref` byte-digest binding.
- Exact affected-consumer set mirroring.
- One refresh observation per affected required consumer.
- Recertification receipt digest and cache-subject checking.
- Quarantine pointers for pending and dead-lettered consumers.
- Duplicate and conflict hold states that cannot become refresh.
- Public projection minimization and no-authority watermark checks.
- A checker registry and shared checker utility module so the suite can be audited as data instead of only as hardcoded Python.

## Non-goals

The reconciliation receipt does not deliver notifications, retry dead-letter queues, authorize consumers, mutate current heads, or prove eventual global convergence. It records receiver-local reconciliation evidence and the remaining unsafe cache surface.
