# Reuse-gate threat model

## Boundary

This threat model begins after a receiver-convergence receipt exists. The attacker wants a converged or partially converged monitoring result to become reusable permission for export, repair, remedy, learning use, budget spend, status-pointer mutation, or action.

## Threats

1. **Convergence-as-authority laundering** — a clean receiver-convergence result is treated as approval.
2. **Display-to-export promotion** — a public minimized status badge is reused as an evidence-release or dashboard-export basis.
3. **High-consequence shortcut** — semantic repair, remedy, delegation, or action re-enable skips fresh packet replay.
4. **Purpose drift** — a request bound to review routing is reused for export, learning, or action.
5. **Receiver-gap hiding** — partial or forked receiver state is ignored because one visible receiver looks clean.
6. **Cache-currentness laundering** — refresh-required basis is reused as if no recertification is needed.
7. **Projection-policy drift** — a display-safe policy is replaced by a broader projection without a new gate.
8. **Status-pointer mutation** — the reuse decision updates current head or status pointer.
9. **Public leakage** — public reuse exposes receiver ids, private status channels, sealed convergence payloads, or raw partner fragments.
10. **Registry/schema drift** — a checker family exists without a tracked schema identity.

## Controls added in pass XCIV

- Source receiver-convergence refs are byte-digest checked.
- Reuse requests mirror source purpose, release, signal, recipient, and cache subject.
- Consequence-scope digests bind the requested effect and projection policy.
- Export requests are held until an evidence-release receipt exists.
- High-consequence requests are refused until fresh handoff-packet replay and authority proof exist.
- Receiver gaps force quarantine/hold.
- Public projections require no-authority watermarks and no private receiver/status-channel disclosure.
- Registry integrity now audits schema ids and schema paths.

## Non-goals

Reuse-gate receipts do not authorize the underlying action. They are consequence-specific refusal/hold/display records. They do not replace handoff packets, evidence-release receipts, recertification receipts, or consumer-local enforcement.
