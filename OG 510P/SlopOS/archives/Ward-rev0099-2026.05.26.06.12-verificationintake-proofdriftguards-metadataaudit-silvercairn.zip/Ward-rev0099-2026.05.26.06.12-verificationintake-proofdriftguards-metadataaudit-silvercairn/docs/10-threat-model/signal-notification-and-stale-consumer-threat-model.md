# Signal-notification and stale-consumer threat model

Pass XCI adds the threat model for downstream notification obligations after signal ingestion.

## Threats

- push or poll delivery acknowledgement treated as consumer refresh;
- consumer acknowledgement treated as authority, recertification, or cache safety;
- dead-lettered notification treated as successful delivery;
- a missing consumer hidden behind an aggregate "notified" badge;
- duplicate notification promoted into a new basis-changing event;
- conflict notification selecting a winner without a dispute/recheck receipt;
- stale consumer caches reused after partial notification failure;
- notification payload leaks sealed signal payload, private consumer identity, private steward/contact, exact hidden counts, or raw partner fragments;
- a notification fanout mutates source signal-ingestion receipts or status pointers;
- notification delivery triggers action, export, repair, remedy, learning use, delegation, budget spend, or privacy waiver.

## Controls added in pass XCI

- source signal-ingestion byte-digest replay;
- signal event key and subject/cache-subject binding;
- affected-consumer set digest and required-consumer count;
- delivery-plan payload digest and no-authority label;
- per-consumer acknowledgment, retry, duplicate-suppression, conflict-hold, and dead-letter states;
- stale-consumer quarantine and no-reuse closure;
- public projection minimization for consumer identities and hidden counts;
- forbidden-effect fences for acknowledgment-as-refresh, notification-as-recertification, dead-letter-as-delivery, and missing-consumer hiding failures.
