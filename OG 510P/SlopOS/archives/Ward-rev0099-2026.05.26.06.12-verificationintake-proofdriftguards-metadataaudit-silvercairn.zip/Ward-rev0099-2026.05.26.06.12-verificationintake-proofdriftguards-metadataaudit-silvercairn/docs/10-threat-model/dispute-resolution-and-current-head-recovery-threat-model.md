# Dispute resolution and current-head recovery threat model

## Scope

This threat model covers the step after a governance chain-integrity receipt has reported a fork, pending successor, chain recheck, disputed head, or historical-minimized chain. The protected object is the resolution of that chain state, not the original governed answer.

## Threats

- **Winner laundering:** one branch is marked current without binding the full observed branch set.
- **Loser reuse:** a rejected or quarantined branch remains usable through an old status channel.
- **Silent fork closure:** a public surface says “resolved” while hiding that a branch was rejected, quarantined, or held.
- **Source-chain mutation:** a resolver edits the old chain-integrity receipt instead of issuing an immutable downstream receipt.
- **Digest evasion:** a resolver names a source chain without checking the bytes and source chain digest.
- **Purpose drift:** a resolution for “show review route” is reused for export, action, repair, remedy, learning use, budget spend, or delegation.
- **Successor theater:** a current head is recovered before successor acceptance and current-status recheck are present.
- **Sealed-branch leakage:** branch identities, conflicts, reviewer identities, private org maps, incidents, or partner fragments leak while explaining a public dispute.
- **Notification gap:** affected recipients, old status channels, or downstream watchers are not notified, so stale bundles keep circulating.
- **Resolution-as-authority:** a resolved current head is treated as approval rather than a recheck pointer.

## Controls

- source chain id/path/byte digest and source chain digest checks;
- source chain validator replay;
- observed branch-set digest;
- branch disposition for every observed branch;
- winner/loser/quarantine/historical-only distinctions;
- resolver independence and conflict disclosure;
- successor acceptance and current-status recheck for recovered heads;
- old-channel invalidation and recipient notification;
- no-source-mutation invariant;
- public branch minimization;
- no-authority watermark;
- forbidden-effect union preservation.

## Residual risk

A v0 resolution receipt still relies on downstream consumers checking for newer chain-integrity or dispute-resolution receipts. Ward should treat unrefreshed cached resolutions as stale rather than current.
