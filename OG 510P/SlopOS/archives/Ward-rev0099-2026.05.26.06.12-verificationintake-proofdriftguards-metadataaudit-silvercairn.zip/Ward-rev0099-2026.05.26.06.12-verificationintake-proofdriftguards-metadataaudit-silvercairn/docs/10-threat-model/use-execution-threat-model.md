# Use-execution threat model

Pass XCV treats execution after a reuse gate as a separate attack surface.

## Threats

- a display-only gate is consumed as export permission;
- an internal-review gate leaks public/private receiver or steward details;
- an evidence-release hold performs a release without a release receipt;
- a high-consequence refusal still triggers repair, remedy, action, or budget spend;
- a receiver-gap quarantine still renders a green public badge;
- actual effect, recipient, projection policy, or purpose drift after the gate;
- execution occurs outside the gate window;
- a consumer writes back to a status pointer or source convergence receipt;
- execution logs become authority evidence in a later replay.

## Containment

Use-execution receipts bind the actual effect to a source reuse-gate digest and make no-execution outcomes first-class. A valid receipt may show that a safe display happened, or that a hold/refusal/quarantine was respected. It cannot prove authority, export permission, repair power, or recertification.
