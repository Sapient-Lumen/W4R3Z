# Governance decision event threat model

Decision events are useful precisely because they are small. That also makes them dangerous: a small event can be copied, indexed, retained, rendered, exported, or fed to agents long after the packet evidence that constrained it has decayed.

## Threats

1. **event-as-grant laundering** — a downstream system treats a decision event as an approval token or portable authorization grant.
2. **packet detachment** — the event loses the digest-bound packet reference and survives as folklore.
3. **state inflation** — a routing, review, hold, refusal, expired, or authority-missing event is rendered as consequence-grade.
4. **projection leak** — a public/external event includes sealed conflicts, raw partner fragments, reviewer identities, private org maps, or incident details.
5. **break-glass replay** — an emergency event is replayed after expiry or outside the allowed interim action.
6. **proof elision** — the event says “allowed” while hiding failed or not-run proof obligations.
7. **consumer collapse** — Helm display, Schell retention, Harbor recheck, or SlopOS CH-AREF attachment is mistaken for the original packet authority.
8. **agent memory contamination** — an agent remembers the compact event as “permission granted” without the packet, expiry, or projection limits.
9. **search/index overexposure** — event attributes are optimized for observability and accidentally become sensitive-evidence indexes.
10. **correlation overclaim** — OPA/AuthZEN/trace/event IDs are treated as evidence of correctness rather than correlation.

## Controls added in pass LXXX

- every event must be digest-bound to a packet;
- event state must match the packet's evaluated action posture;
- every event must declare `authority_surface = derived_receipt_only`;
- consequence-grade event summaries must include proof-obligation parity;
- public/external projections must remain non-sensitive and must not inline sealed material;
- break-glass event time must be inside expiry and must carry review debt;
- Helm/Schell/Harbor/SlopOS consumer profiles have required closure fields;
- negative fixtures catch routing-to-export promotion, public sealed-evidence leaks, stale break-glass replay, digest mismatch, and event-as-grant collapse.

## Residual risk

A decision event is easier to copy than a packet. Ward therefore treats every event as a lossy projection unless the packet digest can still be resolved and validated.
