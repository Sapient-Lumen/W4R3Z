# Succession/transfer threat model

The succession/transfer seam appears after evidence has already left Ward and after follow-up status may already exist.

## Threats

- A stale recipient contact keeps receiving or serving status after responsibility moved.
- A predecessor keeps acting because an old status channel still resolves.
- A successor label is treated as authority to export, repair, remedy, spend, or act.
- A public transfer leaks named stewards, org maps, conflicts, reviewer identities, or incident details.
- A pending successor is shown as accepted.
- A refused transfer is hidden behind a generic “updated owner” badge.
- A status pointer is rotated without invalidating the old path.
- Purpose or recipient class changes during transfer without a new evidence-release receipt.
- Source release or latest follow-up digests are not checked before transfer.
- Forbidden effects preserved by the release/follow-up chain are dropped during transfer.
- Emergency successor hold becomes a permanent authority bypass.
- A downstream consumer caches the old status URL and misses revocation/correction/quarantine.

## Required closure

A safe receipt must prove source-chain binding, predecessor closure, successor binding, status-channel continuity, projection safety, forbidden-effect preservation, and no-authority posture.

## Non-goal

Ward does not become an HR system, identity provider, ticket router, revocation bus, or organizational chart. It records just enough transfer evidence to prevent stale channel and successor-label laundering.
