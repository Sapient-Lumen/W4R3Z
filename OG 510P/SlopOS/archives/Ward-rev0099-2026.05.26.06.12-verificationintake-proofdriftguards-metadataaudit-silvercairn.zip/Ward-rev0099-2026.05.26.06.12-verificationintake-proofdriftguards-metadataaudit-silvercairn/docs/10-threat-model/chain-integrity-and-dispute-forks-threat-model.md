# Chain integrity and dispute-fork threat model

## Scope

This threat model covers the post-release lineage after evidence-release, follow-up, and succession/transfer receipts exist. The protected object is the chain of Ward governance receipts, not the original governed answer.

## Threats

- **Member swap:** a release, follow-up, or transfer receipt is replaced while the chain label stays the same.
- **Digest skip:** a consumer trusts member ids without checking bytes.
- **Purpose drift:** a chain for “show review route” is reused for export, action, or remedy.
- **Source-release drift:** a follow-up or transfer from one release is attached to another.
- **Old-channel replay:** a stale status channel is treated as still current after transfer.
- **Head inflation:** the latest receipt is rendered as approval rather than status/recheck routing.
- **Fork laundering:** two competing successor/status branches are compressed into one canonical green head.
- **Public branch leakage:** named private stewards, reviewer identities, conflicts, or partner fragments are released while explaining a fork.
- **Forbidden-effect loss:** old release/follow-up/transfer prohibitions are dropped when a chain summary is created.
- **Nonmonotonic lineage:** receipts are reordered to hide the dependency that a transfer relied on a specific follow-up.

## Controls

- ordered member ids and byte digests;
- deterministic chain digest;
- member-level validator replay;
- release/follow-up/transfer dependency checks;
- source release, recipient, purpose, projection-policy, and source-item parity;
- transfer latest-follow-up dependency order;
- old-status-channel invalidation checks;
- fork-hold state with no current head;
- public projection minimization;
- no-authority watermarking;
- union preservation of forbidden effects.

## Residual risk

A v0 chain-integrity receipt still depends on the referenced receipt bytes being available. If a member disappears, Ward should downgrade to `chain_recheck_required` or `disputed_head_quarantined` rather than reconstructing authority from memory.
