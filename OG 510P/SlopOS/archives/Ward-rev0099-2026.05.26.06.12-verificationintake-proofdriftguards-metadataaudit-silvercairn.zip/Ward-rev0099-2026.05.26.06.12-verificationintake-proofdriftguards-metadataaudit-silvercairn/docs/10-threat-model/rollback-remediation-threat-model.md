# Rollback-remediation threat model

Pass XCVII treats rollback and remediation as a dangerous post-observation boundary. A bad outcome observation should create containment and review obligations, not ambient authority to rewrite state.

## Threats

- **Rollback by telemetry** — a monitor observes a mismatch and directly rolls back a public surface without a separate handoff packet.
- **Remedy by handoff request** — a request for Harbor/Helm/SlopOS remediation is treated as proof that remediation occurred.
- **Matched outcome overreach** — a successful display observation is reused to authorize export, repair, or action.
- **No-observation greenwash** — unavailable observation is displayed as no remediation needed.
- **Hidden mismatch** — a mismatch is recorded without quarantine, recipient notice, or rollback-review requirement.
- **Source mutation** — the remediation path edits the source use-execution or outcome-observation receipt rather than appending a new receipt.
- **Status-pointer repair** — remediation updates a current status head directly instead of producing review/replay evidence.
- **Public leak during remediation** — public remediation status exposes receiver identity, partner fragments, sealed outcome payloads, private org maps, or steward names.
- **Compensating action confusion** — compensating actions are treated as automatically safe or idempotent even when the relevant Ward consequence requires separate authority.
- **Remedy-loop escape** — a remediation receipt requests a handoff, then later consumers treat the request as a completed remedy and skip Harbor/Helm/SlopOS proof.

## Controls in v0

The rollback-remediation receipt requires source outcome byte checks, scope digests, no-authority labels, public projection minimization, maintained quarantine for mismatches, explicit review/handoff states, and forbidden-effect fences for rollback execution, remedy, repair, export, learning use, status-pointer mutation, and source mutation.

## Research pressure

NIST SP 800-61 Rev. 3 keeps response and recovery tied to risk-management feedback and lessons learned, rather than one-shot local cleanup (`EXT-NIST-SP-800-61R3-2025`). Azure's compensating transaction guidance warns that undo steps are application-specific, may fail, may require manual intervention, and should be idempotent when retried (`EXT-AZURE-COMPENSATING-TRANSACTION-2026`). The Saga pattern is useful pressure because compensating transactions undo prior steps, but Ward must avoid importing the assumption that every governance consequence has a safe automatic compensation path (`EXT-AZURE-SAGA-PATTERN-2026`).
