# Governance handoff threat model

Ward treats governance evidence as useful but dangerous. A stewardship charter, delegation warrant, escalation handoff, owner map, incident route, reviewer roster, budget approval, or agent leash can help a SlopOS-facing cube answer become maintainable, but the same evidence can also launder authority, expose private organization structure, or give an attacker a new oracle.

This threat model is deliberately narrower than a full authorization-engine, GRC, catalog, incident-response, or ticketing threat model. It covers the moment when governance residue is used to decide whether an answer family may be repaired, recomputed, exported, remedied, learned from, or turned into action.

## Protected assets

- answer-family authority: who may change a metric, semantic bridge, source fragment, dashboard/export family, remedy class, learning use, or action class;
- currentness: whether the named steward, delegate, reviewer, payer, policy lane, or escalation lane is still active for this exact subject and consequence;
- caveats: expiry, revocation, no-redelegation, conflict, dual-control, privacy/projection, budget/payer, and emergency-review limits;
- evidence pointers: CH-AREF-like artifact refs, policy epochs, owner-map cuts, CODEOWNERS-like files, catalog entries, group records, incident routes, dockets, receipts, and audit logs;
- private governance material: person/team identifiers, partner fragments, conflict declarations, legal/incident reasons, emergency overrides, and reviewer independence evidence.

## Adversaries and failure actors

- a well-meaning dashboard owner who treats ownership display as approval;
- a stale technical owner, business owner, or steward whose label still appears in old cuts;
- a temporary delegate whose scope creeps from repair into publication or action;
- an on-call responder who can route incidents but cannot approve semantic, privacy, budget, or action decisions;
- an agent or tool runner with query rights that writes fluent recommendations and tries to approve them;
- an attacker who manipulates owner maps, group membership, ticket assignment, or escalation state;
- an insider who uses emergency process to bypass privacy, conflict, budget, or dual-control gates;
- an over-broad audit/export surface that discloses who owns, contests, or escalates sensitive subjects.

## Threats Ward must catch

| threat | failure shape | Ward containment |
|---|---|---|
| Owner-label laundering | catalog owner, dashboard owner, code owner, domain owner, or group label is treated as current approval | require a scoped stewardship charter plus current rehydration before consequence-grade use |
| Stale successor state | old owner map, old CODEOWNERS-like file, renamed team, departed steward, or changed domain survives into a fresh repair | carry owner-map cut, review-by, successor/backstop, stale/orphan/suspended state, and rehydration result |
| Ticket assignment laundering | assigned ticket, chat mention, queue item, or page is treated as accepted authority | require escalation handoff acceptance posture: accepted, partial, refused, rerouted, no-response, needs-info, conflict-declared, emergency-only |
| On-call-as-steward collapse | responder with operational route becomes semantic steward, payer, policy owner, reviewer, or action approver | keep routing lanes separate from permitted duties and granted authority |
| Delegation creep | temporary repair access becomes ongoing edit, export, raw-row, budget, privacy-waiver, or action authority | require delegation warrant scope, expiry, denied capabilities, no-redelegation, revocation, and result receipt |
| Agent boundary collapse | model/tool access becomes stewardship, self-approval, escalation acceptance, or action warrant | require tool-call leash plus delegation warrant; agents may draft/query/validate/propose but not steward-of-record or approve own work |
| Budget/semantic confusion | semantic steward spends recompute/export budget, or payer changes metric semantics | separate permitted duties, budget/payer authority, and action/export authority |
| Privacy/projection override | urgent escalation widens row/detail visibility or exports sensitive governance evidence | require projection class, withheld evidence, minimization, no-existence-oracle posture, and explicit break-glass review debt |
| Conflict laundering | original approver, interested party, or conflicted reviewer approves the remedy or action re-enable | require conflict declaration, independence, dual-control/quorum, and self-approval prohibition |
| Re-delegation overreach | delegate passes a higher-scope task to a person/tool without authority | require parent warrant re-delegation permission and target warrant |
| Break-glass amnesia | emergency action proceeds with no duration, rollback, reviewer, notice, or post-hoc review | break-glass creates review debt; it does not erase ordinary residues |
| Governance evidence oracle | viewer learns hidden partner, team, incident, dispute, or suppressed cohort existence from governance metadata | project governance evidence by audience and consequence; prove authority without full disclosure |

## Projection classes for governance evidence

Ward should not show the same governance evidence to every reader.

1. **public label** — coarse phrase such as “governance review required” or “stewardship stale”; no person, partner, conflict, or incident identifiers.
2. **internal routing hint** — non-authority contact or queue pointer; safe only for low-risk routing and visibly non-approving.
3. **review-visible charter summary** — scoped duties, currentness, successor/backstop, and exclusions visible to authorized reviewers.
4. **restricted conflict/dual-control evidence** — reviewer identity, conflict posture, quorum, and independence proofs visible only to governance reviewers.
5. **sealed emergency or incident material** — break-glass triggers, incident details, legal/regulatory posture, and post-hoc review debt.
6. **redacted external remedy view** — enough to explain challenge/remedy posture without exposing internal rosters or hidden evidence.

## Invariants

- Ownership is not action authority.
- Escalation is not acceptance.
- Assignment is not resolution.
- Agent access is not stewardship.
- Budget authority is not semantic authority.
- Break-glass is review debt, not amnesia.
- Governance evidence is attack surface.
- A fresh consequence must rehydrate old governance facts before use.


## Pass LXXIX added threats

- **Routing-hint promotion:** a safe owner/contact hint is copied into an export, repair, or action approval path.
- **Sensitive routing leak:** a route card carries raw partner fragments, reviewer identities, incident details, or sealed conflict material.
- **Unbounded break-glass:** emergency access lacks expiry, rollback, or post-hoc review debt and becomes normal authority.
- **Projection oracle:** public/external governance views reveal that a specific incident, conflict, reviewer, org lane, or partner fragment exists.

Mitigation: enforce routing-hint mode, break-glass closure fields, and projection leak flags in fixtures and CI checks before any new governance state is trusted.
