# Research synthesis — pass LXXVIII

Pass LXXVIII takes the pass LXXVII governance nouns and makes them executable enough to refuse bad authority. The move is from **stewardship/delegation/escalation as useful prose** to **governance handoff packets with proof obligations and decay fixtures**.

The motivating failure mode is still owner-label laundering, but the sharper pass LXXVIII problem is this: a cube can now name stewardship charters, delegation warrants, and escalation handoffs while still failing to prove that any particular repair, recompute, export, remedy, learning use, or action is allowed.

## Source pressure carried forward

The same external pressure remains load-bearing. `EXT-NIST-AIRMF-GOVERN-2026` supports the idea that roles, responsibilities, accountability structures, and communication lines must be documented, but Ward should not confuse documented accountability with local consequence authority. `EXT-BACKSTAGE-CATALOG-OWNERSHIP-2026`, `EXT-BACKSTAGE-DESCRIPTOR-LIFECYCLE-2026`, `EXT-DATAHUB-DOMAIN-OWNERSHIP-2026`, `EXT-DATAHUB-OWNERSHIP-TYPES-2026`, and `EXT-OPENMETADATA-DATA-OWNERSHIP-2026` continue to pressure discoverable ownership while proving that ownership taxonomies are local and product-shaped.

`EXT-GITHUB-CODEOWNERS-2026` remains the best anti-lesson: owner maps are versioned inputs with failure and parsing states, not ambient approval. `EXT-OPENFGA-CONCEPTS-2026`, `EXT-OPENFGA-CONTEXTUAL-TUPLES-2026`, and `EXT-OPENFGA-CONDITIONS-2026` pressure Ward toward scoped relationship/caveat evidence without turning Ward into an authorization engine. `EXT-PAGERDUTY-ESCALATION-POLICIES-2026` and `EXT-ATLASSIAN-INCIDENT-ROLES-2026` pressure the split between routing, acceptance, role, and resolution.

## New synthesis

1. **The residue set needs a spine.** Ward now has many answer-adjacent residues. Without a residue spine, any one of them can overclaim another's job. The spine records can-support and must-not-imply edges.
2. **Governance handoff needs proof obligations.** A charter, warrant, or handoff is not enough unless subject binding, duties/exclusions, currentness, delegator authority, caveats, acceptance, conflict/quorum, agent boundary, break-glass, rehydration, and projection obligations pass.
3. **Currentness is executable, not decorative.** `effective_from`, `source_cut`, `last_rehydrated_at`, `review_by`, `expires_at`, `status`, and successor/backstop state must affect whether a fresh consequence is allowed.
4. **Refusal states are product.** `routing_hint_only`, `review_only`, `needs_rehydration`, `authority_missing`, `handoff_unaccepted`, `expired_warrant`, and `agent_boundary_violation` are as important as `consequence_grade`.
5. **Governance evidence is attack surface.** Proof must be possible without exposing every person, conflict, incident, partner, or hidden review fact to every viewer.
6. **Agents stay below stewardship.** A model or tool runner can draft, query, validate, or prepare packets under a leash and warrant; it cannot be steward-of-record, approve its own work, or accept its own escalation by default.
7. **Break-glass creates review debt.** Emergency authority may change interim effects, but it does not erase privacy, budget, conflict, correction, action, or remedy obligations.

## Resulting Ward move

Do not add a fourth governance noun. Instead, add a **governance handoff packet** that compiles the three LXXVII residues plus currentness, conflict, budget, privacy/projection, agent boundary, proof obligations, and evaluated actions.

Do not promote a governance residue unless it has:

- proof obligations;
- at least one positive fixture;
- multiple negative fixtures;
- cross-cube seam placement;
- downgrade/refusal behavior;
- a currentness model;
- projection/minimization posture.

## New machine-checking posture

Pass LXXVIII adds `tools/check_governance_handoff.py`. The checker is intentionally small. It validates the schema-shaped packet fixtures enough to reject the exact failures Ward has been naming:

- catalog owner used as approval;
- on-call responder used as steward;
- expired delegation used as authority;
- ticket assignment used as acceptance;
- agent tool access used as stewardship;
- payer authority used as semantic authority;
- privacy break-glass without review debt;
- stale owner-map reuse;
- conflicted self-approval;
- forbidden re-delegation.

## Speculative direction

Ward is becoming a small **trust residue compiler**. Given answer evidence, scope, custody, privacy, budget, governance, contest, repair, and action posture, Ward should emit a typed decision state rather than a yes/no owner answer.

The compiler should remain smaller than SlopOS, smaller than an authorization engine, and smaller than a governance workflow product. Its job is to make false authority impossible to hide.
