# Research synthesis — pass LXXX

## Focus

Pass LXXX asks whether Ward can promote a compact governance decision event without collapsing back into authority laundering.

## External pressure

- OPA decision logs demonstrate why decision events are useful for audit and offline debugging: they include policy/query context, inputs, bundle metadata, results, and a decision id (`EXT-OPA-DECISION-LOGS-2026`). Ward borrows the audit/debug shape but refuses to treat the event as a grant.
- CloudEvents pressures Ward toward interoperable envelope fields such as source, type, id, subject, and time (`EXT-CLOUDEVENTS-SPEC-2026`). Ward borrows the envelope but keeps routing destination and authority outside the event.
- OpenTelemetry logs and event semantics pressure Ward to use stable event names, structured attributes, severity, and limited body semantics (`EXT-OTEL-LOGS-DATA-MODEL-2026`, `EXT-OTEL-EVENT-SEMCONV-2026`). Ward borrows the named-event discipline but avoids stuffing proof semantics into free-form text.
- AuthZEN's Authorization API pressures Ward to keep subject/action/resource/context decision results request-scoped and PDP/PEP-local (`EXT-AUTHZEN-AUTHORIZATION-API-2026`). Ward borrows the explicit decision tuple idea while refusing portable approval or entitlement semantics.

## Synthesis

A decision event is the right next residue only if it is digest-bound to the packet, parity-checked against the evaluated action, projection-safe, and visibly non-authoritative. The useful event is not “Ward allowed this forever.” It is “under packet X digest Y, at time Z, action A had state S, with these holds/refusals/debts still visible.”

## Speculative rule

Governance logs should be compiled like receipts, not trusted like policy. The smaller the event, the more aggressively it must preserve weakness: packet digest, action binding, projection class, forbidden effects, expiry, review debt, and no-authority label.

## Resulting work

- added `schemas/governance-decision-event.v0.json`;
- added decision-event docs, threat model, and replay closure;
- added four valid consumer fixtures for Helm, Schell, Harbor, and SlopOS;
- added eight negative fixtures;
- added `tools/check_governance_decision_events.py` and wired it into `make check`.
