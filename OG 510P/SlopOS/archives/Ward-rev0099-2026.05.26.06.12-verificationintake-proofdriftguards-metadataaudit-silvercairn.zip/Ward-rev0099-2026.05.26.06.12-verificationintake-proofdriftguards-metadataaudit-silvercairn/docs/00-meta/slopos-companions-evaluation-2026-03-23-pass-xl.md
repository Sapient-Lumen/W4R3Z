# SlopOS / companions evaluation — pass XL

This pass keeps Ward embryonic while stealing one more useful habit from SlopOS and the sibling cubes: **resume handles, liveness hints, and continuity guarantees should not collapse into one fake progress truth.**

## What the current cubes still teach
- **SlopOS** is again the strongest nearby teacher because it repeatedly refuses to let imported session, progress, continuation, or witness material silently widen into a portable continuity plane. The resolved-history entries on MCP progress import, auth continuation export, browser-session export, and network-lease session resumption are all variations on the same caution: a token or resume hook is weaker than a reviewed continuity contract.
- **Harbor** and **Steward** pressure the same seam operationally: callback arrival, teardown acknowledgement, or lease expiry can look like continuity if you are careless, but the real question is always what cut of truth is still reconstructible and what local followthrough remains.
- **ViewFS** keeps history/readability honesty alive too: a named path into current material is weaker than a guarantee that prior addressable material is still reconstructible from source.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one mandatory changefeed substrate, one universal replay cursor, or one compulsory gap-repair controller into the cube.

## Current recommendation
Keep Ward open on whether these truths ultimately ride on offsets, resume tokens, logical slots, replay fences, checkpoint manifests, explicit backfill jobs, or some mixed shape.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **resume cursor** instead of pretending a saved position proves continuity;
2. **continuity class** instead of one fake green/red stream-health bit;
3. **history gap alarm** instead of silent fallback to reset/rebuild behavior;
4. **backfill posture** instead of collapsing live intake and bounded reconstruction into one lane;
5. **start-here revision-heading coherence** so the archive's front door cannot quietly keep describing the previous revision after a new package is cut.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep imported progress/resume handles smaller than durable continuity promises;
- keep reset/backfill work visibly separate from normal forward intake;
- keep gap detection stronger than silent auto-reset behavior; and
- fail the revision if `START_HERE.md` stops naming the packaged revision in its "What changed" / "New in" headings.

## Still-not-yet decisions
- Whether `resume cursor` belongs in durable Ward vocabulary, or remains intake/history-side residue until more replay specimens accumulate.
- Whether `continuity class` should become first-class Ward vocabulary, or remain observation/process guidance until more cross-source specimens exist.
- Whether `history gap alarm` belongs inside Ward, or remains an operational warning owned by adjacent cubes.
- Whether `backfill posture` is best treated as archive/process residue or a first-class Ward noun later.
