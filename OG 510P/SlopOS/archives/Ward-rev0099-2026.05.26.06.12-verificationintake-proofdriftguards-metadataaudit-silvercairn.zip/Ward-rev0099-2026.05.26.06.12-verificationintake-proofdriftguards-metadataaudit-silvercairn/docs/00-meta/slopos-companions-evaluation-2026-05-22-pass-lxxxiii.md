# SlopOS companions evaluation — 2026-05-22 pass LXXXIII

Pass LXXXIII evaluates search-continuity receipts against the companion set.

## SlopOS

SlopOS is the primary consumer. Portal search, resumed queries, ACP queues, artifact browsers, and long-running datacube filters can all request “next page” after state drift.

Required behavior: SlopOS must treat `held_recheckpoint_required` as a real result, not an error. A held cursor should produce review/replay work, not export/action authority.

## Helm

Helm renders the confusing state.

Required behavior: Helm should show “continuation held” or “new search required,” preserve row-level state, and avoid green result-set badges.

## Harbor

Harbor may run recheck/correction jobs from search results.

Required behavior: Harbor can schedule recheck from a continuity receipt, but recompute/export/remedy remains per-member and requires current packet replay.

## Schell

Schell pressure is privacy, retention, and minimization.

Required behavior: Schell should retain minimized sealed-omission evidence, not exact hidden counts or raw sealed details in broad views.

## ViewFS

ViewFS cares about trusted paths and volition/consent cards.

Required behavior: ViewFS can show that hidden governance rows exist under a protected path while refusing to reveal exact count or reason detail to unauthorized viewers.

## Foundry

Foundry can expose crosswalk/code-drift search results.

Required behavior: a Foundry search continuation must stop when classification-policy or crosswalk-owner epochs change; otherwise stale page-two rows can authorize semantic repair by accident.

## Steward

Steward coordinates retries and replay guards.

Required behavior: Steward may own the recheckpoint work queue, but the receipt's state remains non-authority and cannot become budget approval.

## Net evaluation

The search-continuity receipt is justified as a v0 executable guard. It should remain provisional until at least one export path and one ViewFS trusted-path card consume it without turning sealed omissions into either an oracle or a false absence claim.
