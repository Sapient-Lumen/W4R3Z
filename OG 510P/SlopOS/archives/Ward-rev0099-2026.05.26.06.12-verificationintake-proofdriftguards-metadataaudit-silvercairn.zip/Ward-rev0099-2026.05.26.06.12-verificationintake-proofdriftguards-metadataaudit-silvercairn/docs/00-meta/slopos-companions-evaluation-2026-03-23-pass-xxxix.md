# SlopOS / companions evaluation — pass XXXIX

This pass keeps Ward embryonic while stealing one more useful habit from SlopOS and the sibling cubes: **current hiding, historical retention, and physical cleanup should not collapse into one fake deletion truth.**

## What the current cubes still teach
- **SlopOS** is again the strongest nearby teacher because it repeatedly separates active selection from retained generations and separates semantic state from retention/GC policy. ADR-0004 is especially useful here: compiled configuration generations remain selectable for rollback while retention/GC stays outside the privileged core. Ward should steal that discipline, not the exact object taxonomy.
- **ViewFS** continues to pressure the same seam from the imported-material side: current projection, historical addressability, and actually reclaimed bytes are not one fact just because a default view hides older content.
- **Harbor** and **Steward** keep the operational deletion side honest: requested teardown, user-visible disappearance, and durable cleanup often happen at different times and under different authorities.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one universal delete/tombstone carrier, one mandatory GC controller, or one required replica-repair protocol into the cube.

## Current recommendation
Keep Ward open on whether these truths ultimately travel as versioned records, delete-marker sidecars, compacted feeds, rollback-friendly generations, or some mixed shape.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **delete marker** instead of pretending “not returned by the default read” means physically gone;
2. **repair floor** instead of trusting current-view deletion without enough propagation / rebuild safety;
3. **resurrection alarm** instead of silently re-accepting stale state or silently assuming it can never return;
4. **reclamation horizon** instead of flattening retirement, retention expiry, and physical cleanup;
5. **ledger revision coherence** so the archive cannot quietly package current docs while its top-level ledgers still claim an older revision.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep current-hidden state smaller than physically reclaimed state;
- keep rollback/history retention smaller than the default current read;
- keep repair/replication obligations visible before old negative markers are purged; and
- fail the revision if the archive’s ledgers drift behind the packaged revision label.

## Still-not-yet decisions
- Whether `delete marker` belongs in durable Ward vocabulary, or remains storage/history-side residue until more retirement/resurrection specimens accumulate.
- Whether `repair floor` should become first-class Ward vocabulary, or remain imported from replica-repair / rebuild safety stories until more specimens exist.
- Whether `resurrection alarm` belongs inside Ward, or remains an observation-side warning owned by adjacent cubes.
- Whether `reclamation horizon` is best treated as archive/process residue or a first-class Ward noun later.
