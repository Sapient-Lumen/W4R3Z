# Research synthesis — pass XXXIII

This pass keeps Ward cautious and learns one more thing from mature assurance systems: **assurance often arrives as several facets with independent acceptance floors, not one timeless score.**

## Outside lessons
1. **NIST SP 800-63-4 keeps assurance dimensions separate on purpose.**  
   NIST requires organizations to select assurance levels separately for identity proofing (IAL), authentication (AAL), and federation (FAL). It also says relying parties determine the minimum IAL, AAL, and FAL they will accept for a function and may vary functionality accordingly. Ward should steal the restraint: one trust-relevant answer can have several independent facet values and several independent floors instead of one scalar “trust level.”

2. **EAR keeps a breakdown even when it also offers a summary.**  
   The current EAR draft allows an overall `ear_status`, but it says that status must be no higher than the worst claim across the trustworthiness vector. It also keeps submodules and per-dimension vector values visible. Ward should steal that humility: a summary badge may be convenient, but it should stay visibly weaker than the facet breakdown that produced it.

3. **WebAuthn already exposes orthogonal credential/account state instead of one badge.**  
   WebAuthn Level 3 recommends that relying parties store several separate facts about a credential record, including `uvInitialized`, `backupEligible`, `backupState`, `signCount`, and optionally the attestation material. It also warns that the UV flag must not be relied upon as an authentication factor until the RP has established the needed trust relationship. Ward should learn the same lesson: one positive-looking flag or one successful ceremony should not swallow neighboring facets.

4. **SLSA’s track split is a good datacube instinct even where the details are still moving.**  
   Current SLSA track docs say tracks exist to measure different aspects separately, to recognize progress in one aspect without blocking on an unrelated one, and to let the specification evolve by adding tracks later. Because the current tracks page is still a draft, Ward should treat it as design pressure rather than settled product truth. Even so, the underlying idea is brilliant and worth stealing: avoid one forced scalar level when independent axes are the real story.

## Resulting Ward move
Do not decide yet whether Ward's long-term multi-axis story is tiered, boolean, ordinal, vector-valued, registry-backed, or policy-local only.

For now, preserve four separations and let later specimens force promotion:
- `assurance facet` versus one collapsed badge or tier;
- `acceptance floor` versus the observed/measured facet value;
- `bottleneck facet` versus a vague whole-result failure story;
- `rollup badge` versus the facet vector and the policy that produced it.

Keep nearby, but not yet promoted, a few smaller ideas:
- `facet waiver` for an explicit local exception to one floor;
- `not-claimed facet` for dimensions intentionally absent rather than assumed low;
- `facet bundle` for grouped but still decomposed local appraisal residue.

## Fresh ideas worth stealing
- **assurance facet** — one independently meaningful trust/appraisal dimension.
- **acceptance floor** — minimum value or posture required for one local action.
- **bottleneck facet** — the facet that actually constrained or denied the current action.
- **rollup badge** — optional collapsed summary kept visibly weaker than the facet set.
- **facet waiver** — explicit local override for one facet floor.
- **not-claimed facet** — visible absence of a facet claim without a fake default.
- **facet bundle** — grouped decomposed appraisal residue.
- **no fake scalar by default** — a standing anti-regrowth rule.
