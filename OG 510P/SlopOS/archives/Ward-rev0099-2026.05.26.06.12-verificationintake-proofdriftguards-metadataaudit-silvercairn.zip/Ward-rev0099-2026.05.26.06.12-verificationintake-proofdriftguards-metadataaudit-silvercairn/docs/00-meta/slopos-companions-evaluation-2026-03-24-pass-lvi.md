# SlopOS / companions evaluation — pass LVI

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **query/result meaning gets weaker when temporality and reset handling disappear behind one friendly metric title.**

## What the included cubes keep teaching
- **SlopOS** remains the strongest nearby teacher because D-ATTRFS and the request-state family keep saying the same disciplined thing: request identity, current live state, and durable saved artifacts are different truths. The datacube analogue is that cumulative source lanes, per-interval deltas, current snapshots, and derived rates should also stay visibly distinct rather than collapsing into “the metric.”
- **SlopOS** also helps through D-TIMEPROOF and its request-state split: a `req_id` is not portal-owned live sample truth. Ward should steal the same shape for recurring numeric surfaces: the fact that two outputs share a subject and a name does not mean they share the same temporal contract.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: manifest, snapshot result, live feed, and materialized collection are distinct. The datacube analogue is that base cumulative lane, interval delta lane, current gauge/snapshot lane, and rendered derivative should remain distinct even when a shell groups them together for humans.
- **Helm** keeps pressuring UI honesty. If a shell shows “requests/sec”, “attestations total”, and “current active sessions” side by side, the header should be able to say temporality binding + reset witness + derivative posture without forcing a giant semantic layer.

## What outside systems add to the datacube posture
- Prometheus adds the first discipline: counters are cumulative and monotonic except for resets, gauges are free to move both directions, and derivative functions should run before aggregation when reset detection matters. Ward should steal that as **temporality binding** plus **reset witness** honesty, not as a commitment to Prometheus (`EXT-PROMETHEUS-METRIC-TYPES-2026`, `EXT-PROMETHEUS-FUNCTIONS-2026`).
- OpenTelemetry adds the second discipline: delta and cumulative temporality are both first-class, monotonicity steers instrument choice, and cross-system conversion can accumulate, rename, or even drop streams when semantics do not line up. Ward should steal that as **temporality binding** plus **derivative posture** honesty, not as a commitment to OpenTelemetry (`EXT-OTEL-METRICS-DATA-MODEL-2026`, `EXT-OTEL-SUPPLEMENTARY-METRICS-2026`, `EXT-OTEL-PROM-COMPAT-2026`).
- OpenMetrics 2.0 adds the third discipline: cumulative histogram state can reset, and when it does the count/sum/buckets/start timestamp reset together. Ward should steal that as **reset witness** honesty, not as a commitment to one wire format (`EXT-OPENMETRICS-2-0-2026`).
- Datadog adds the blunt operational warning: changing metric type can make historical visualizations nonsensical. Ward should steal that as a **comparability warning** instinct, not as a commitment to one vendor’s app model (`EXT-DATADOG-METRIC-TYPES-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Any promoted recurring numeric surface should declare a temporality binding before it borrows the title of a raw repeated question.**
2. **Any promoted rate/increase/change answer should declare derivative posture so replayed base values, derived deltas, and reset-adjusted slopes cannot impersonate one another.**
3. **Any promoted cumulative or counter-like surface used for derivative work should declare a reset witness whenever reset handling materially affected interpretation.**
4. **Ward should not bless one universal exporter/backend temporality, one universal `_total` doctrine, or one cube-wide derivative grammar while SlopOS and its siblings are still discovering their own query/result/materialization seams.**
5. **If Ward later imports or exports recurring numeric surfaces across systems, it should treat temporality/type conversion as semantic drift until proven comparable.**

## Specific anti-lessons from the past
- Do **not** let cumulative totals, interval deltas, and current snapshots share one recurring title without a visible temporality contract.
- Do **not** let reset handling vanish into engine defaults when derivative/rate questions depend on it.
- Do **not** let post-aggregation derivative math borrow the authority of reset-aware per-series derivation.
- Do **not** assume cross-system conversion preserved meaning just because the metric name survived.
- Do **not** choose one cube-wide temporality constitution just because a few dashboard questions look attractive.

## What Ward should probably steal next
- a **temporality binding** attached to any promoted recurring numeric surface that might otherwise blur cumulative, delta, and snapshot truth;
- a **reset witness** attached to any promoted derivative surface that had to cross restarts, discontinuities, or created-time cuts;
- a **derivative posture** attached to any rate/increase/change answer that was weaker than direct replay of its base series;
- a standing rule that **derived slope is weaker than base series** until the reset and temporality story is inspectable.
