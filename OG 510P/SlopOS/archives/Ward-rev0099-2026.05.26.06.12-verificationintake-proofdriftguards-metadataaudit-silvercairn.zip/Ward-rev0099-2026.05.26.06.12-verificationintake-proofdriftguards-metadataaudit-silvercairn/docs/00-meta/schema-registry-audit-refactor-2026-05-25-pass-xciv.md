# Schema registry audit/refactor — pass XCIV

## Finding

Rev0093 made the checker suite registry-backed, but the registry still knew only checker scripts and fixture directories. That left a quieter drift path: a receipt family could have fixtures and a checker while its schema path or schema id drifted out of the registry vocabulary.

## Refactor

Pass XCIV extends `tools/governance_checker_registry.json` so fixture-backed entries carry:

- `schema_path`
- `schema_id`

`tools/check_governance_registry_integrity.py` now verifies:

- the schema file exists;
- the schema `$id`, when present, matches the registry `schema_id` or schema filename, while `properties.schema.const` matches the registry `schema_id`;
- the schema has a matching top-level `properties.schema.const`;
- fixture-backed validators still have positive and negative fixtures;
- governance checker scripts and fixture directories remain registered.

## Why it matters

Ward is now schema-heavy enough that the registry is a control surface, not just a convenience list. The schema audit keeps future receipt families from silently becoming checker-only conventions with untracked schema identities.
