# Research synthesis — pass LXXXVII

Pass LXXXVII pressure-tested Ward after evidence release, follow-up, and succession/transfer receipts. The new question was not whether a single receipt is valid, but whether a lineage of valid receipts can still become misleading when a consumer sees only one branch.

## External pressure

`EXT-RFC-9162` keeps pushing Ward toward append-only humility: inclusion and consistency proofs help detect history changes, but they do not decide local consequence. Ward borrows the idea of ordered proof material while keeping local authority separate.

`EXT-SCITT-ARCH-2026-LATEST` is stronger pressure for plural receipt services and divergent relying-party views. It suggests that one statement can have multiple transparency histories and that the relying party must decide which issuers/services matter for its scenario. Ward translates that into explicit chain scope and fork-hold state instead of pretending that “latest receipt wins.”

`EXT-OPENID-SSF-2025` and `EXT-OPENID-CAEP-2025` keep event transmitter/receiver and continuous update concepts visible. They support Ward's post-release status-update lane, but also warn that a signal or event is not itself local authority.

`EXT-VC-BITSTRING-STATUS-LIST` keeps status purpose and status-reference separation visible. Ward should keep release status, branch status, and current-use status typed rather than compressing them into one valid/revoked flag.

`EXT-W3C-VC-DATA-INTEGRITY-1-1-2026` pressures Ward to preserve proof-chain integrity without letting proof-chain success imply action permission.

## Finding

Ward needed a compact lineage receipt with four properties:

1. **ordered member binding** — release, follow-up, and transfer receipts appear in a deterministic order;
2. **byte-level member identity** — every member carries a path and digest checked against the actual bytes;
3. **scope parity** — release id, recipient, purpose, source item, and projection policy stay constant unless a new chain explicitly holds/rechecks;
4. **branch honesty** — a forked chain has no current head and cannot be reused as current evidence.

## Speculation

The chain-integrity receipt may become the portable status object that ViewFS, Schell, Harbor, Helm, and SlopOS all consume. It should remain non-authority. Its promotion test is not “can it tell us what is current?” but “can it force every consumer to replay the same member chain before acting?”

## Result

Pass LXXXVII adds:

- `schemas/governance-chain-integrity-receipt.v0.json`;
- `docs/20-assurance/governance-chain-integrity-receipt-v0.md`;
- `docs/30-architecture/chain-integrity-dispute-forks-and-canonical-heads.md`;
- `docs/10-threat-model/chain-integrity-and-dispute-forks-threat-model.md`;
- `tools/check_governance_chain_integrity.py`;
- four positive fixtures and fourteen negative fixtures;
- specimen flow 84.

The pass deliberately refuses to promote chain integrity into authorization. A canonical head is still only a status/recheck pointer.
