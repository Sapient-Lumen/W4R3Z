# Research synthesis — pass XXXIV

This pass keeps Ward cautious and learns one more thing from mature trust/message systems: **unknown, must-understand, and duplicate/conflicting fields are different processing postures, not one generic parsing problem.**

## Outside lessons
1. **X.509 kept a strict fail-closed lane for critical extensions.**  
   RFC 5280 says that if an extension containing unexpected values is marked critical, the implementation MUST reject the certificate or CRL containing the unrecognized extension. Ward should steal the design restraint: some extensions can safely be additional residue, but some must stop local consequence if they are not understood.

2. **JOSE separates safe-to-ignore headers from the `crit` lane.**  
   RFC 7515 says header parameter names inside the JOSE header must be unique. It also says unrecognized non-critical header parameters must be ignored, while parameters listed in `crit` must be understood and processed or the JWS is invalid. Ward should learn the same split: there is a real difference between pass-through residue and gating residue.

3. **COSE makes must-understand both protected and fatal when violated.**  
   RFC 9052 says the `crit` header parameter indicates which protected header parameters an application that is processing a message is required to understand. It must live in the protected bucket, and it is a fatal processing error if a `crit`-listed header parameter is not there. Ward should steal two ideas here: the must-understand lane should be explicit, and the marker for that lane should itself be integrity-bound.

4. **Protocol Buffers keeps unknown fields, but not every transform preserves them.**  
   The proto3 guide says unknown fields are preserved in binary parsing/serialization, but can be lost when serializing to JSON or copying field-by-field. Ward should learn the datacube consequence: retained-unknown residue is weaker than understood residue, and format transitions can silently erase future compatibility affordances.

5. **The ecosystem still gets must-understand wrong in practice.**  
   Recent Authlib and PyJWT advisories document acceptance of JWTs with unknown `crit` headers, violating RFC 7515 and enabling split-brain verification, policy bypass, replay, or privilege escalation. Ward should learn the hard lesson from the past: parse-level ambiguity and ignored critical semantics are not academic; they produce live trust failures.

## Resulting Ward move
Do not decide yet whether Ward’s long-term datacube shape uses a registry of critical fields, per-envelope processing profiles, schema-local annotations, or action-local allowlists.

For now, preserve four separations and let later specimens force promotion:
- `must-understand claim` versus ordinary retained residue;
- `understanding gate` versus local spend or deny policy;
- `retained unknown` versus actually interpreted fact;
- `duplicate collision alarm` versus ordinary repeated history or multi-source support.

Keep nearby, but not yet promoted, a few smaller ideas:
- `profile closure` for the exact set of critical/known claims expected in one lane;
- `integrity-bound critical marker` for must-understand declarations that cannot be stripped or moved without detection;
- `lossy bridge warning` for format transitions that may drop retained unknowns.

## Fresh ideas worth stealing
- **must-understand claim** — field or claim whose semantics must be understood before local consequence can proceed.
- **understanding gate** — parser/appraiser checkpoint smaller than policy that decides whether processing can continue.
- **retained unknown** — unknown field preserved for forwarding/replay without being treated as understood.
- **duplicate collision alarm** — parse-level or envelope-level conflict that must not be normalized away silently.
- **profile closure** — explicit statement of what this lane promises to understand.
- **integrity-bound critical marker** — criticality declaration carried inside the integrity-protected surface.
- **lossy bridge warning** — note that a format translation may erase retained unknowns.
- **no fake understanding** — standing anti-pattern rule for Ward surfaces.
