# SlopOS / companions evaluation — pass XXXII

This pass keeps Ward embryonic while stealing one more useful habit from the neighbors and from evolving data contracts: **bind exact authored meaning, keep stable identities separate from labels, and make compatibility policy visible instead of implicit.**

## What the current cubes still teach
- **SlopOS** already has the strongest nearby lesson for this pass in its schema-registry completeness checks, IDL digest/ordinal work, interface-evolution RFCs, and data-contract / migration-gate posture. It keeps exact identities reviewable and refuses to let casual renames or open-ended compatibility folklore quietly widen authority. Ward should steal the smaller analog: one trust cut may carry an exact writer view, while reader compatibility and projection stay visibly weaker and more local.
- **SlopOS** also treats many closed-world request surfaces as intentionally rejecting unknown fields or unknown operations. That is useful pressure for Ward too: "I decoded something" should stay weaker than "I decoded it under the right compatibility lane and preserved what I did not understand."
- **Foundry** and **ViewFS** keep reminding Ward that imported evidence and derived views are not the same object. That rhymes with writer-vs-reader pressure: a translated, projected, or upgraded view should not masquerade as the authored cut itself.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one universal wire format, one schema registry service, one alias mechanism, or one mandatory upcaster framework into the archive.

## Current recommendation
Keep Ward open on whether evolution meaning ultimately rides on field IDs, schema fingerprints, ordinals, explicit translation witnesses, sidecar recipes, or another carrier.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **writer view** instead of pretending a later reader's interpretation is the same as the authored cut;
2. **reader view** instead of treating all consumers as if they decode through one universal timeless schema;
3. **field identity** instead of trusting labels/order not to drift;
4. **compatibility lane** instead of hiding upgrade choreography inside parser folklore;
5. **revision-summary coherence lint** so the archive's own front-door surfaces cannot quietly disagree about the latest focus.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep authored view versus consumer view explicit;
- keep stable field identity separate from current labels and ordering;
- make compatibility posture visible when local consequence depends on it;
- and fail the revision if the summary/focus phrase drifts across receipt, roadmap, surface status, and context pack.

## Still-not-yet decisions
- Whether `writer view` and `reader view` belong in Ward proper or remain imported from wire/storage carriers until more specimens accumulate.
- Whether `field identity` should be durable Ward vocabulary or remain carrier-local.
- Whether `compatibility lane` deserves first-class archive residue or stays local translation policy.
- Whether Ward should ever standardize a translation-witness artifact, or only require that lossy projection and unknown-field loss stay visible.
