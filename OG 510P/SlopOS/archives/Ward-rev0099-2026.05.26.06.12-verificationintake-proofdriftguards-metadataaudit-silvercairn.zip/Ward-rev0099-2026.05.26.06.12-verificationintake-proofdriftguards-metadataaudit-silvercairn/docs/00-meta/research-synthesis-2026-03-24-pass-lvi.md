# Research synthesis — pass LVI

This pass keeps Ward decision-light and adds another datacube discipline: **temporality is part of meaning, and cumulative, delta, snapshot, and derived-rate surfaces should not masquerade as one timeless truth.**

## What the past says we must learn
1. **Counter versus gauge is a semantic split, not just a chart toggle.**  
   Prometheus says a counter is cumulative and monotonically increasing except for resets, while a gauge can arbitrarily go up and down. Ward should steal the constitutional lesson directly: a recurring trust question that is really “events accumulated so far” should not quietly share one metric title with a “current level” snapshot just because both happen to be numbers (`EXT-PROMETHEUS-METRIC-TYPES-2026`).

2. **Temporality changes what one point means.**  
   The OpenTelemetry metrics data model says delta streams and cumulative streams are both valid, but they carry different temporal context and different transformation costs; it explicitly calls out delta-to-cumulative conversion as a real transformation with state trade-offs (`EXT-OTEL-METRICS-DATA-MODEL-2026`). Ward should steal the humility: a point-in-time value from a delta lane is not the same truth as a point-in-time value from a cumulative lane.

3. **Monotonicity belongs in the contract.**  
   OpenTelemetry’s supplementary guidance says counters are for monotonically increasing deltas, while non-monotonic additive values belong on UpDownCounter-style surfaces (`EXT-OTEL-SUPPLEMENTARY-METRICS-2026`). Ward should steal that as a general rule: if a recurring series can reverse direction, the cube should not let it borrow the authority of an odometer-like lane.

4. **Reset handling is semantic, not implementation dust.**  
   Prometheus’s query docs say `rate()`, `irate()`, and `increase()` are for counters and that reset detection can be lost if aggregation happens before the derivative step; OpenMetrics 2.0 says histograms are cumulative over time but may reset, and when they do the count, sum, buckets, and start timestamp all reset together (`EXT-PROMETHEUS-FUNCTIONS-2026`, `EXT-OPENMETRICS-2-0-2026`). Ward should steal the discipline: if a derived surface depends on reset handling, the reset story belongs in the result meaning.

5. **Cross-system conversion can drop or rewrite meaning.**  
   OpenTelemetry’s Prometheus/OpenMetrics compatibility doc says monotonic sums with cumulative temporality become Prometheus counters, monotonic delta sums should be accumulated before becoming counters, and other combinations can be dropped (`EXT-OTEL-PROM-COMPAT-2026`). Ward should steal the warning: a recurring question can drift when exported or materialized through a different temporality/type family even if the name stays familiar.

6. **Type changes can make history nonsense.**  
   Datadog’s metric-type docs warn that changing a metric type can change behavior in existing visualizations and monitors, potentially rendering historical data nonsensical (`EXT-DATADOG-METRIC-TYPES-2026`). Ward should steal that blunt honesty: if temporality or metric family changes, comparability should be treated as suspect until proven otherwise.

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal metrics backend, one preferred temporality, one exporter family, or one default derivative policy for rates and increases.

For now, keep three more separations visible and let later specimens force promotion:
- **temporality binding** — visible statement of whether a recurring numeric surface is cumulative, delta, snapshot, or another declared temporal contract.
- **reset witness** — visible statement of whether resets/discontinuities were absent, detected and adjusted for, unresolved, or not applicable.
- **derivative posture** — visible statement of whether a rendered rate/increase/change answer was replayed directly, derived from cumulative state, derived from deltas, or withheld because the semantics were unsafe.

## Why these separations are worth stealing
- A **temporality binding** stops one flattering metric title from hiding the difference between “total so far,” “change during this interval,” and “current value.”
- A **reset witness** stops restart/discontinuity handling from disappearing into query-engine folklore.
- A **derivative posture** stops a computed slope or increase from borrowing the authority of a replayable base fact or raw snapshot.

## Brilliant ideas to steal now
- **created/start timestamp honesty** — resets become more interpretable when the timebase of the cumulative lane is explicit.
- **derive-before-aggregate for reset-sensitive counters** — preserve reset detection before flattening many series together.
- **temporality binding** — compact residue for cumulative versus delta versus snapshot semantics.
- **reset witness** — explicit reset/discontinuity note instead of one flattering uninterrupted line.
- **derivative posture** — visible note on whether a rate/increase/change came from safe derivative semantics or should be withheld.
- **derived slope weaker than base series** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward should ever bless one default temporality for promoted recurring surfaces.
- Whether reset witness belongs on every promoted cumulative surface or only on derivative/rate outputs.
- Whether derivative posture should become machine-readable before more specimens survive counter-reset and export-conversion pressure.
- Whether Ward eventually needs a separate noun for `created/start timestamp` or whether temporality binding plus reset witness is enough.
