# SlopOS / companions evaluation — pass XLIII

This pass keeps Ward embryonic while stealing another discipline from the current cube ecology: **saved query, frozen result, live mode, and promoted derivative should not collapse into one magical datacube object**.

## What the included cubes keep teaching
- **SlopOS** is still the most useful direct teacher for Ward's datacube posture. Its D-ATTRFS posture is exactly the kind of discipline Ward should copy while SlopOS itself is still in design: queries are **view-scoped**, **snapshot-first**, **handle-returning**; saved queries stay **shell-owned manifests**; live mode is **optional and bounded**. That is a better default than inventing a global trust-search daemon or an ambient dashboard truth plane on day one.
- **ViewFS** sharpens the same lesson. Its current split between **query manifest**, **result snapshot**, **live feed**, and later **materialized local collection** is one of the best adjacent ideas available for Ward right now. The freeze/thaw/rerun/diff behavior should be stolen long before any grand star schema is frozen.
- **Helm** pressures the presentation side: if Ward ever shows promoted trust derivatives in user-facing surfaces, it should expose `snapshot`, `live`, `frozen`, `stale`, or `re-run needed` honestly rather than burying them under one polished badge.
- **Foundry**, **Harbor**, and **Steward** keep the same humility alive from other angles: measurements, callbacks, previews, and follow-through signals can be valuable orientation surfaces without automatically becoming the authority layer for consequence.

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Every nontrivial exploration should carry both a basis pin and an explicit join clock when it enriches facts with time-varying context.**
2. **Every result should be freezeable without silently turning into a live subscription.**
3. **Live mode should be explicit, bounded, and pauseable, not the hidden default meaning of a saved query.**
4. **Rerun and diff should be first-class review surfaces before Ward commits to canonical dashboards.**
5. **Any acceleration, pre-aggregation, or maintained derivative should require a workload witness.**

## Specific anti-lessons from the past
- Do **not** let one saved recipe quietly become the current answer, the live watcher, and the promoted derivative all at once.
- Do **not** let temporal enrichment default to one hidden clock such as ingestion time or publication time.
- Do **not** let a frozen review result silently mutate just because fresh rows arrived elsewhere.
- Do **not** build hidden acceleration paths before repeated query evidence says what is worth accelerating.
- Do **not** let product polish erase whether a surface is `recipe`, `snapshot`, `live`, `diff`, or only `history`.

## What Ward should probably steal next
- headers that show **basis pin + join clock** together but do not confuse them;
- explicit **freeze / thaw / rerun / diff** rails for trust explorations;
- a visible **live-mode badge** that can admit `paused`, `overflow`, `stale`, or `rebuild required`;
- a lightweight **workload witness** record before promotion or precomputation;
- repo hygiene that keeps these moves discoverable while the cube still stays design-phase and decision-light.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, and receipt;
- register the new outside source that is directly shaping temporal-lookup vocabulary;
- and extend repo hygiene so the release manifest's `core_docs` must include the newest pass docs, not just any plausible set of top-level links.

## Still-not-yet decisions
- engine choice;
- storage/index strategy;
- one canonical dashboard layer;
- one universal temporal-join API;
- one global acceleration policy for all trust derivatives.
