# Research synthesis — pass LXXIX

Pass LXXIX continues the executable governance-handoff work by filling the two positive lanes rev0078 intentionally left open: **low-risk owner-hint routing** and **emergency break-glass with review debt**.

The new pressure is closure. Rev0078 could refuse false authority, but a refusal machine also needs to prove when a weaker posture is legitimate. A catalog owner hint can be useful if it stays read-only and non-sensitive. A break-glass act can be useful if it stays scoped, expiring, sealed, review-debt-bearing, and unable to publish, remedy, export, or re-enable action by itself.

## Source pressure carried forward

`EXT-NIST-AIRMF-GOVERN-2026` and `EXT-NIST-AI-RMF-GENAI-PROFILE-2024` keep pressing Ward toward roles, responsibilities, and risk-management actions without letting those governance structures become an all-purpose authority token. `EXT-OWASP-LLM06-EXCESSIVE-AGENCY-2025` and `EXT-OWASP-AGENTIC-AI-THREATS-2025` sharpen the agent boundary: when tools and autonomy expand, Ward must treat complete mediation, least privilege, and post-action review as governance facts rather than prose warnings. `EXT-OPENFGA-CONDITIONS-2026` continues to pressure time-bounded, caveated grants. `EXT-OTEL-EVENT-SEMCONV-2026` gives a useful analogy for decision traces: a governance decision should have a stable name, bounded attributes, and severity/posture fields rather than dumping an unstructured body of private evidence.

## New synthesis

1. **Routing hints are allowed only as non-authority product.** Owner hints may help a user find a steward, open a review request, or display a contact label. They must not carry sensitive governance evidence or promote themselves into repair, export, action, privacy, or budget authority.
2. **Break-glass is a closure packet, not a waiver.** Emergency access must declare trigger, scope, allowed interim actions, expiry, rollback, post-hoc review, and review-debt receipt. It narrows time and disclosure; it does not erase proof obligations.
3. **Projection must be checked even when authority is absent.** A routing-only posture can still leak sealed conflicts, org maps, reviewer identities, raw partner fragments, or incident details. Safe routing is partly a projection problem.
4. **Decision states need closure gates.** `routing_hint_only`, `review_only`, `consequence_grade`, and `refuse` are not merely labels. Each carries required evidence, forbidden promotions, and projection behavior.
5. **Positive fixtures matter.** Negative fixtures prove refusal; positive fixtures prove the cube can still work under narrowed authority. Ward now has one normal allowed fixture, one routing-only fixture, and one emergency fixture.

## Resulting Ward move

Add a routing-hint mode and break-glass closure checks to the existing governance handoff packet checker. Do not create new nouns yet. The pass adds positive and negative fixtures plus a decision-state matrix so future changes can see which fields must exist before a state may be emitted.

The key rule becomes:

> A weak governance state is valid only when its weakness is machine-visible.

## New machine-checking posture

Pass LXXIX extends `tools/check_governance_handoff.py` so that:

- routing-hint-only actions must be read-only, non-sensitive, and fenced from repair/export/action/privacy promotions;
- public and external projections must not reveal sealed conflict details, reviewer identities, private org maps, incident details, or raw partner fragments;
- break-glass use must include trigger, scope, expiry, allowed interim actions, post-hoc review deadline, rollback plan, and recorded review debt;
- break-glass can support sealed emergency review only when charter/handoff authority also exists;
- normal export, remedy, action, and semantic repair remain blocked by owner hints or emergency posture alone.

## Speculative direction

Ward should eventually emit a compact **governance decision event** for every packet evaluation. That event should look more like a semantic event than a narrative log: named event type, subject refs, requested action, posture, proof summary, projection class, severity, refusal reasons, and sealed evidence pointers. This would let Helm render the decision, Harbor recheck corrections, Schell minimize retention, and SlopOS attach authority state without copying the sensitive packet.

Do not implement that event yet. Pass LXXIX only creates the decision-state matrix and fixture pressure needed to tell whether such an event would earn its keep.
