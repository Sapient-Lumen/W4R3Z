# Research synthesis — 2026-05-22 pass LXXXI

## Focus

Pass LXXXI asks whether Ward's new governance decision event can survive downstream consumption without becoming ambient authority. The target seam is the consumer: renderers, retention systems, recheck schedulers, CH-AREF attachments, search indexes, transcripts, and materialized latest-state tables.

## Outside pressure

OPA decision logs carry policy-query events for auditing and offline debugging, including decision identifiers and bundle/query context (`EXT-OPA-DECISION-LOGS-2026`). Ward steals the auditability habit but refuses to make logs grants.

CloudEvents gives Ward a portable event vocabulary and subscription model (`EXT-CLOUDEVENTS-SPEC-2026`, `EXT-CLOUDEVENTS-SUBSCRIPTIONS-2026`). Portability is exactly the danger: once many consumers receive a decision event, each consumer can accidentally widen or stale-freeze it.

OpenTelemetry's standalone event semantic conventions and the 2026 span-event deprecation direction pressure Ward to keep event names, attributes, correlation, and logs clear (`EXT-OTEL-EVENT-SEMCONV-2026`, `EXT-OTEL-SPAN-EVENT-DEPRECATION-2026`). Ward keeps governance events structured and boring rather than burying state in a body string or trace decoration.

Kafka-style compaction and tombstone retention pressure Ward hardest (`EXT-KAFKA-LOG-COMPACTION`, `EXT-CONFLUENT-KAFKA-LOG-COMPACTION-2026`). A compacted topic can be excellent for latest-state reconstruction, but a latest state is not a complete governance proof trail. Tombstones, supersession markers, and review debt can disappear before a cold consumer reconstructs safe state.

## Decision

Promote a consumer-side receipt, not a new authority noun. The receipt is a checker-facing accountability object for one consumer's interpretation of one event.

## New rule

A downstream consumer may not perform a consequence effect unless:

1. the decision event digest matches;
2. the event itself validates;
3. the event's packet reference is mirrored;
4. the packet replay remains current when `replayed_current` is claimed;
5. the consumer state is not stronger than the event state;
6. forbidden effects are preserved;
7. projection safety is preserved;
8. compaction/tombstone hazards are declared when relevant.

## Rejected expansion

Ward should not yet add batch decision summaries, entitlement search result envelopes, or a generic event-log registry. The v0 consumer receipt is intentionally per-event because batch summaries are where mixed weak/strong states become easiest to launder.

## Result

Pass LXXXI adds `governance-decision-consumer-receipt.v0`, a checker, five valid fixtures, ten negative fixtures, a consumer replay threat model, and specimen flow 78.
