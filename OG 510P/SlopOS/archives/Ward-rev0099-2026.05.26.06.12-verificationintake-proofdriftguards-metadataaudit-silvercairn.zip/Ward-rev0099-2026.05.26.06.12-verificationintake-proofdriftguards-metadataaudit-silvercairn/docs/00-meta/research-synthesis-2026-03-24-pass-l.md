# Research synthesis — pass L

This pass keeps Ward decision-light and adds another datacube discipline: **a repeated question must declare its window semantics before any rolling, cumulative, or trailing answer can pose as an ordinary stable metric.**

## What the past says we must learn
1. **Omitting the window is already a decision.**  
   dbt's cumulative-metric docs say cumulative metrics measure data over a given window, and if no window parameter is passed the window is treated as **infinite**, accumulating over all time. Ward should steal the humility, not the stack: no repeated question should silently inherit “all time so far” just because the frame was omitted (`EXT-DBT-CUMULATIVE-2026`).

2. **Default frames are not neutral.**  
   BigQuery's window-function docs say that when `ORDER BY` is present but no frame clause is supplied, the default frame is `RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW`. The same page makes `ROWS` and `RANGE` distinct frame families. Ward should borrow the constitutional lesson: a moving window, a cumulative window, and a peer-based range window are different truths even when the chart title is identical (`EXT-BIGQUERY-WINDOW-FRAME-2026`).

3. **Frame family changes meaning.**  
   DuckDB documents `ROWS`, `GROUPS`, and `RANGE` framing as separate ways to define what counts as “in the window,” and it notes that `RANGE` requires a single ordering expression with subtraction semantics. Ward should steal the idea that frame shape belongs in the meaning, not in engine folklore (`EXT-DUCKDB-WINDOWS-2026`).

4. **Windowed questions are anchored in time, not free-floating.**  
   Prometheus's querying basics say range-vector selectors fetch samples back from the **current instant**, and PromQL instant queries versus range queries differ by evaluation timestamps. Its query-functions docs add that `delta(v range-vector)` extrapolates to cover the full selected time range. Ward should borrow the constitutional lesson: a trailing window answer needs an explicit anchor instant and should not pretend the anchor is obvious or immutable (`EXT-PROMETHEUS-RANGE-VECTORS-2026`, `EXT-PROMETHEUS-FUNCTIONS-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal rolling-window schema, one machine-readable frame grammar, one canonical anchor-clock field, or one universal partial-window rule.

For now, keep three more separations visible and let later specimens force promotion:
- **window frame** — visible statement of what interval or accumulation rule one row/result covers.
- **anchor instant** — visible statement of which evaluation instant or bucket edge the frame is relative to.
- **partial-window posture** — visible rule for what happens when the full frame is not yet available: emit partial, suppress, mark unknown, or use another explicitly named policy.

## Why these separations are worth stealing
- A `window frame` stops “7-day trailing”, “month-to-date”, and “all time so far” from borrowing each other's authority.
- An `anchor instant` keeps a rerun at a later time from silently masquerading as the same answer.
- A `partial-window posture` keeps early buckets and insufficient-history edges from pretending they are directly comparable with mature full-frame buckets.

## Brilliant ideas to steal now
- **window frame** — explicit frame/accumulation definition for one recurring surface.
- **anchor instant** — explicit evaluation point or bucket edge a rolling/cumulative answer is relative to.
- **partial-window posture** — explicit rule for early or truncated windows.
- **no silent cumulative default** — standing anti-regrowth rule.
- **frame weaker than fact** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward ever blesses one universal rolling-window grammar across all future surfaces.
- Whether `anchor instant` stays human-facing guidance or later becomes typed machine-readable metadata.
- Whether `partial-window posture` must be carried on every exploratory result or only on promoted derivatives.
- Whether some repeated questions should permanently remain snapshot-only rather than earning rolling/cumulative surfaces at all.
