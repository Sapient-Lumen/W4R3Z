# Research synthesis — pass LXXXVIII

Pass LXXXVIII pressure-tested Ward after chain-integrity receipts. The new question was not whether a fork can be detected, but whether a detected fork can be resolved without rewriting the chain, hiding the losing branch, or turning resolution into authority.

## External pressure

`EXT-SCITT-ARCH-2026-LATEST` keeps pressure on plural receipt histories. It supports Ward's assumption that multiple trustworthy-looking receipt paths can exist and that relying parties need scenario-bound resolution evidence rather than “latest wins.”

`EXT-RFC-9162` keeps append-only history visible. Ward borrows the humility that consistency/inclusion evidence is about history integrity, not local consequence authority.

`EXT-OPENID-SSF-2025` and `EXT-OPENID-CAEP-2025` keep receiver posture and continuous status updates visible. They pressure Ward to notify recipients and status watchers, but not to let notification become authority.

`EXT-VC-BITSTRING-STATUS-LIST` and `EXT-W3C-VC-DATA-INTEGRITY-1-1-2026` keep status-purpose and proof-chain separation visible. Ward translates this into separate chain-integrity and dispute-resolution receipts rather than mutating an earlier receipt.

`EXT-NIST-63-4-2025` keeps federation/assertion privacy pressure visible: status and identity-like facts should remain purpose-bound, audience-bound, and minimized instead of becoming public branch or organization-map disclosure.

## Finding

Ward needed a downstream resolution receipt with four properties:

1. **source-chain immutability** — the resolver checks the chain bytes and digest, then emits a new receipt instead of editing the old one;
2. **branch-set binding** — observed branches are named by digest and every branch gets a disposition;
3. **recovered-head humility** — a recovered current head is only a status/recheck pointer and still requires source-packet replay;
4. **projection-safe closure** — public resolution can show state class without revealing sealed branch details, named stewards, reviewer identities, conflicts, org maps, or exact hidden branch counts.

## Speculation

The dispute-resolution receipt may become the portable “current status recovered or still held” object consumed by ViewFS, Schell, Harbor, Helm, and SlopOS. It should remain downstream of chain integrity and weaker than authorization. Its promotion test is not “can it settle a dispute?” but “can it keep settlement, notification, branch disposition, and authority separate?”

## Result

Pass LXXXVIII adds:

- `schemas/governance-dispute-resolution-receipt.v0.json`;
- `docs/20-assurance/governance-dispute-resolution-receipt-v0.md`;
- `docs/30-architecture/dispute-resolution-current-head-recovery.md`;
- `docs/10-threat-model/dispute-resolution-and-current-head-recovery-threat-model.md`;
- `tools/check_governance_dispute_resolutions.py`;
- four positive fixtures and seventeen negative fixtures;
- specimen flow 85.

The pass deliberately refuses to promote dispute resolution into authority. Resolution can recover a current status pointer or sustain a hold; neither grants action, export, repair, remedy, budget, learning, privacy waiver, or delegation authority.
