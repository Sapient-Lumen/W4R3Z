# Research synthesis — pass LXXIII

Pass LXXII separated observed truth from forecasts, simulations, synthetic rows, and counterfactual worlds. Pass LXXIII follows the next failure mode: natural-language users and agents will ask the SlopOS datacube questions in ordinary language, route those questions through model-mediated planning, generate SQL or cube-query fragments, call tools, repair errors, and summarize results. That can be useful, but fluency is not authority. A beautiful question translation can still pick the wrong metric, over-broaden scope, leak a denied dimension, execute too much SQL, or turn a model's hidden ambiguity into a plausible number.

The restraint rule still holds. Ward should not choose an LLM, agent framework, prompt format, semantic-layer product, SQL dialect, tool protocol, workflow graph, tracing backend, query validator, or human-review UI as the SlopOS datacube constitution. SlopOS is still design-phase; its snapshot/view/handle discipline, D-BUDGET posture, D-NONDET posture, and ACP non-authority posture all argue against letting a language-model mediation layer become ambient authority. The right Ward move is to name small answer-adjacent residues that preserve **what was asked**, **how it was translated**, and **what was allowed to execute**.

## What the past says we must learn now

1. **Prompt text is not a security boundary.** NCSC's 2025 warning says current LLMs do not enforce a security boundary between instructions and data inside a prompt; treating a model response as though that boundary were robust is the prompt-injection mistake (`EXT-NCSC-PROMPT-INJECTION-2025`). OWASP's 2025 prompt-injection examples include direct, indirect, repository/RAG, multimodal, and payload-splitting cases (`EXT-OWASP-LLM01-PROMPT-INJECTION-2025`). Ward should therefore refuse any design where the prompt alone proves that a generated cube query is authorized, safe, or semantically correct.

2. **Agency must be minimized and mediated outside the model.** OWASP's Excessive Agency guidance separates excessive functionality, excessive permissions, and excessive autonomy, and recommends limiting extensions, limiting permissions, user approval for high-impact actions, and complete mediation in downstream systems (`EXT-OWASP-LLM06-EXCESSIVE-AGENCY-2025`). A SlopOS cube assistant should never be trusted because the model promised to be careful; the available functions, authority, scope, budgets, and approval gates must do the work.

3. **Tool protocols make model control explicit; Ward must make consequence boundaries explicit.** MCP's tools spec says tools are model-controlled and may let models query databases, call APIs, or perform computations; it recommends UI indicators, confirmation prompts, and human ability to deny tool invocations (`EXT-MCP-TOOLS-2025-11`). MCP roots provide useful workspace-boundary vocabulary, but the spec also keeps access-control responsibilities with the client/server implementation rather than magic context (`EXT-MCP-ROOTS-2025-11`). MCP sampling similarly keeps model access/selection/permission under the client, with human review of prompts and responses (`EXT-MCP-SAMPLING-2025-11`). Ward should steal the boundary shape: expose only small tools, show calls, carry approvals, and make a tool-call leash part of answer truth.

4. **SQL agents need scoped database permissions and review because generated SQL is executable.** LangChain's SQL-agent docs describe a loop that inspects tables/schemas, generates a query, checks it, executes it, repairs on errors, and returns an answer; the same docs warn that executing model-generated SQL has inherent risks and that database permissions should be narrowly scoped (`EXT-LANGCHAIN-SQL-AGENT-2026`). That loop is useful pressure, but Ward should not import the framework. It should preserve a translation warrant and execution leash whenever natural language becomes executable query material.

5. **Semantic layers and text-to-SQL fail differently.** dbt's 2026 benchmark update says LLMs can either write SQL directly or query through a structured ontology; it emphasizes that semantic-layer coverage can fail closed while text-to-SQL can return plausible wrong numbers (`EXT-DBT-SL-VS-TEXTSQL-2026`). This supports a Ward rule: the translation layer must expose whether the requested answer is covered by declared metric/axis/query contracts, not merely whether some SQL ran.

6. **Real enterprise text-to-SQL is long-context, multi-step, and metadata-heavy.** Spider 2.0 frames real-world enterprise text-to-SQL problems as involving large schemas, multiple dialects, long contexts, project metadata, and multi-query workflows (`EXT-SPIDER2-2025`). BIRD emphasizes SQL that is not only correct but efficient and often depends on external knowledge (`EXT-BIRD-SQL-2025`). BIRD-INTERACT adds multi-turn ambiguity handling, error recovery, user/knowledge interactions, and CRUD-spectrum pressure (`EXT-BIRD-INTERACT-2025`). Ward should assume natural-language cube mediation will require disambiguation, bounded metadata exposure, retry limits, and refusal—not one-shot magical query generation.

7. **Ambiguity is data, not an inconvenience.** When a user asks “top risky providers last month,” the model may need to resolve: risk metric, provider identity level, last-month calendar, suppression thresholds, current versus historical hierarchy, whether “top” means count or rate, and whether partner-only populations are allowed. A hidden model choice here is a design bug. The disambiguation trail belongs near the answer.

8. **Generated queries can be right for the wrong reason.** Execution success, non-empty result sets, and syntactic validity are weak evidence. A generated query needs semantic coverage, metric-card binding, scope-lens binding, axis/hierarchy/crosswalk binding, quality/freshness/uncertainty posture, and ideally a small set of invariant checks. This is stronger than a prompt and smaller than freezing a query compiler.

9. **Tool results and model summaries have different truth strengths.** A tool call can return an answer capsule; a model can summarize it; an agent can propose a next step. These are not the same residue. The model summary should not become the answer capsule, and the answer capsule should not become an action warrant.

10. **SlopOS design-phase humility matters most here.** The SlopOS datacube is not yet a settled query engine, materialization layer, semantic layer, or agent runtime. Ward should keep language-model mediation as a provisional shell around answer authority, preserving useful scars without committing SlopOS to one AI data-assistant stack.

## Resulting Ward move

Do **not** decide yet:

- one LLM, agent runtime, query planner, prompt format, query language, SQL dialect, validator, semantic-layer product, tracing backend, or tool protocol;
- one representation for prompts, hidden instructions, system messages, memories, schemas, samples, or retrieved context;
- one rule saying semantic-layer coverage is always required, or one rule saying text-to-SQL is always forbidden;
- one universal human-review UI, approval cadence, row limit, cost budget, retry count, or query complexity policy;
- one way for MCP, SQL agents, dashboards, notebooks, or SlopOS-native tools to expose capabilities;
- one guarantee that a model-generated explanation, repair loop, or final answer is ground truth.

Do add three small, reversible residues for model-mediated datacube hygiene:

- **intent binding** — compact residue tying a natural-language request or agent follow-up to a declared cube intent. It records actor/lane, original wording or digest, language/context class, session/follow-up dependency, unresolved terms, disambiguations asked and answered, selected metric/card/axis/grain/window/scope/authority/consequence class, denied alternatives, and safe-language/refusal posture. It is smaller than a conversation transcript and stronger than “the model understood.”
- **translation warrant** — compact evidence that a model-mediated translation from intent to cube query, semantic-layer request, SQL, tool plan, or answer-shape contract is covered, checked, and appropriately bounded. It records generator/toolchain identity, model/version if relevant, semantic coverage, metric/axis/query-contract bindings, candidate alternatives, static checks, invariant tests, policy/privacy/projection checks, expected result shape, refusal/degradation reasons, and human-review outcome if required. It is smaller than a query compiler and stronger than syntactic success.
- **tool-call leash** — compact execution boundary for model-invoked or agent-suggested tools. It records available tool family, exposed capability subset, root/source/scope boundaries, read/write/effect class, argument schema and validated arguments, row/detail/egress/cost/time budgets, approval requirement, dry-run/replay posture, retry/repair limits, result caps, execution receipt, and downstream non-authority posture. It is smaller than a full tool runtime and stronger than “the agent may call SQL.”

These residues sit beside earlier nouns. Intent bindings consume concept anchors, scope lenses, metric cards, query contracts, view bindings, budget gates, and refusal receipts. Translation warrants consume quality witnesses, comparability passports, hierarchy cuts, state-cut witnesses, query contracts, layout apertures, and projection curtains. Tool-call leashes consume budget gates, action warrants, egress receipts, interaction trails, correction horizons, federation pacts, and revocation fences.

## Brilliant ideas to steal now

- **Treat “cannot translate safely” as a successful answer.** A failed or refused translation can be more trustworthy than a plausible SQL result.
- **Separate intent, translation, execution, result, and summary.** These are different truth strengths and should not collapse into one chat turn.
- **Use semantic coverage as a capability map, not a religion.** Covered metric/axis requests can fail closed; uncovered exploration can be allowed only with stronger leashes and weaker consequence posture.
- **Make disambiguation first-class.** Ask, record, and reuse clarifications deliberately instead of letting hidden model defaults decide the query.
- **Leash tools by capability, not by prose.** Restrict exposed tools, identities, roots, row limits, cost budgets, writes, and egress at the boundary; do not rely on the agent promise.
- **Keep retries visible.** Query repair loops can improve results or drift away from the user intent; each retry should inherit or re-open the translation warrant.
- **Preserve prompt/context class without preserving everything.** Ward can retain digests, layer names, retrieved-source handles, and security class instead of turning every chat into a surveillance archive.
- **Run cheap invariants before trust.** Empty/non-empty, total reconciliation, grain checks, permission checks, metric-card consistency, no forbidden joins, and suppression survival are better promotion evidence than model confidence.
- **Make tool-call receipts boring.** Every call should know who/what requested it, what authority it used, what it touched, what it returned, and why the result is not itself permission to act.
- **Do not let summaries outrank capsules.** A fluent answer can cite or summarize an answer capsule, but cannot replace its scope lens, state cut, quality, uncertainty, refusal, and egress posture.

## Anti-lessons to keep out

- Do not treat an LLM's hidden chain, prompt, or self-critique as audit evidence.
- Do not let a generated SQL string bypass metric cards, scope lenses, join warrants, or projection curtains.
- Do not let “read-only database user” become the whole safety model; wide reads and detailed exports can still leak.
- Do not let an agent enumerate schemas, values, tools, roots, or denied populations beyond the question's authority scope.
- Do not turn every model-mediated query into a permanent transcript unless retention, privacy, and review purpose are explicit.
- Do not allow repair loops to silently change the question after database errors.
- Do not let sampled rows, schema examples, or retrieved metadata become exemplars without exemplar fences.
- Do not allow a natural-language answer to become a consequence receipt, action warrant, or learning label by fluency alone.

## Datacube construction impact

Pass LXXIII strengthens the construction protocol with a model-mediation step:

1. capture the natural-language or agent-origin request as an intent binding;
2. identify ambiguity before query generation;
3. bind intended metrics, axes, grain, scope, time, and consequence class to existing residues;
4. require a translation warrant before executable query or tool plan material can run;
5. leash every model-invoked tool and record its execution boundary;
6. distinguish tool result, answer capsule, model-written summary, and follow-up proposal;
7. refuse or downgrade if intent, translation, execution, or summary strength cannot be kept separate.

## Promotion stance

Promote **intent binding**, **translation warrant**, and **tool-call leash** only as candidate datacube residues, not schemas. They are valuable precisely because they defer the LLM/SQL/tool/protocol choices while forcing SlopOS-facing model mediation to carry evidence, limits, and refusal posture.
