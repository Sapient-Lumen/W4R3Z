# SlopOS companions evaluation — pass XC

Pass XC evaluated signal-ingestion receipts against SlopOS and the companion cubes.

## SlopOS

SlopOS should treat signal ingestion as a recheckpoint trigger. A signal may attach to CH-AREF as observation evidence, but CH-AREF, portal export, tool action, budget spend, learning use, remedy, repair, or privacy waiver still requires source-packet replay and a consequence-grade decision.

## ViewFS

ViewFS should distinguish accepted-for-recertification, duplicate ignored, stale ignored, conflict held, irrelevant ignored, and invalid rejected. A signal chip should never look like approval.

## Schell

Schell should retain envelope digest, event key, source recertification digest, subject digest, cache-subject digest, high watermark, and conflict state while minimizing public signal payloads and sealed branch details.

## Harbor

Harbor should not update stale-surface or public correction state from raw signals. It can subscribe to signal-ingestion receipts to request recertification, but it must wait for the downstream receipt chain before changing public posture.

## Helm

Helm should render race guards and receiver-observation state: duplicate, stale, conflict, accepted-for-recheck, rejected. It should avoid green “resolved” badges for signal delivery.

## Foundry and Steward

Foundry and Steward owner-map or lifecycle changes may arrive as signals, but Ward requires subject/cache binding and recertification before those signals affect governance state.

## Result

Signal ingestion remains v0 receiver-observation hygiene. It should not become a first-class status residue until stale-consumer observation, multi-receiver reconciliation, and end-to-end SlopOS recheckpoint behavior are proven.
