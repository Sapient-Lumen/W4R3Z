# SlopOS / companions evaluation — pass LXVI

Pass LXVI treats budgeted and degraded answer attempts as trust-bearing datacube events. Pass LXV said interaction/render/export handling needs residue. Pass LXVI says approximation, partial computation, privacy noise, validation-detail withholding, and resource/latency/cost limits must not quietly become equal to the requested exact answer.

## What the included cubes keep teaching

- **SlopOS** remains the anchor. D-ATTRFS / CH-ATTRQ keeps attribute queries view-scoped, snapshot-first, handle-returning, and bounded. D-BUDGET / D-METER keeps payer authority explicit and non-ambient. A Ward budget gate should preserve both lessons: answer work may be gated or refused without creating a hidden current-payer context, and any degraded answer stays tied to the authorized view/snapshot rather than becoming an ambient fast query lane.
- **Harbor** already has datacube exactness semantics, evidence grades, contract tiers, and measurement semantics. Ward should steal Harbor's exactness-class / sketch-witness / error-band posture, but apply it to trust consequences: approximate or partial evidence may be review-useful while still too weak for promotion.
- **Foundry** keeps basis, pinned cuts, candidate/active generation, and restore duties visible. A degradation receipt should name when the answer moved from requested basis to retained tier, sketch sidecar, sampled preview, or summary-only derivative instead of pretending basis continuity survived.
- **Steward** keeps process, reconciliation, cause conditions, and followthrough visible. When a budget gate returns review-only approximation, Steward-like followthrough becomes a recompute docket, repair task, or explicit refusal rather than an ops note.
- **Schell** keeps basis cards, activation receipts, and environment epochs separate. Estimator/runtime/library choices can appear in uncertainty envelopes when material without turning Schell environment detail into Ward's cube engine.
- **ViewFS** keeps stable handles distinct from live aliases and source resurfacing. A degraded answer should not retarget the original exact handle; it should mint its own answer capsule/degradation receipt or remain a preview artifact.
- **Helm** is where users will feel the temptation. Helm will want quick answers, approximate previews, review queues, stale fences, summaries, and condition strips. Ward should give Helm visible `review-only approximation`, `degraded fallback`, `budget-refused`, `privacy-noisy`, `summary-only quality`, and `exact recompute pending` postures instead of one green-looking chart.

## What this means for the SlopOS datacube

A SlopOS-facing budgeted/degraded answer should require at least:

1. **Budget gate before fallback.** The answer attempt should know which class of budget constrained it: resource, latency, cost, privacy loss, egress rows/cells, validation detail, exemplar detail, or capability scope.
2. **Requested versus served shape.** The degradation receipt should say what the user/agent requested and what Ward actually served: exact answer, sketch estimate, sample preview, coarse tier, stale fallback, top-k truncation, summary-only validation, aggregate-only drill, or refusal.
3. **Uncertainty composed, not flattened.** The uncertainty envelope should reference exactness class, estimator/sketch/sample witness, noise/suppression posture, freshness/tier posture, quality witness, and nondeterminism/seed/order posture where relevant.
4. **Safe refusal beats hidden degradation.** If the degraded answer would leak hidden population, denied cells, suppressed cohorts, or false precision, Ward should emit refusal receipts instead of a pleasing approximation.
5. **Review-only by default.** A degraded or approximate answer should be review-grade until a promotion gate explicitly says the uncertainty envelope and consequence class are compatible.
6. **Exact recompute as process, not promise.** If exactness is owed later, a recompute docket should say so. The preview should not imply that exact repair is already complete.
7. **No budget oracle.** A budget exceeded, privacy threshold hit, row limit reached, or detail suppression event must be reported without revealing the size or existence of denied material outside the requester authority.

## Companion-specific steals

- From **SlopOS**: explicit payer/budget authority and bounded, fail-closed query surfaces.
- From **Harbor**: exactness classes, sketch witness, error-band note, evidence grade, and contract tier separation.
- From **Foundry**: basis/pinned-cut honesty when a degraded answer switches to retained summary, sketch, or sample basis.
- From **Steward**: recompute/repair/followthrough state for approximations that are only temporary review aids.
- From **Schell**: environment/runtime epochs as optional uncertainty contributors, not engine constitution.
- From **ViewFS**: a degraded preview should be a distinct handle/artifact, never a silent mutation of the exact answer handle.
- From **Helm**: condition-strip language for review-only, degraded, stale, exact-recompute-pending, budget-refused, and promotion-blocked states.

## Anti-lessons to preserve

- Do **not** let a fast approximate answer inherit exact consequence grade.
- Do **not** collapse compute budget, privacy loss, egress/detail caps, and capability scope into one generic budget bit.
- Do **not** let a top-k/truncated/summary-only answer title imply full-population coverage.
- Do **not** treat a sketch point estimate as if the retained sketch, merge law, and error posture no longer matter.
- Do **not** let nondeterministic estimator output become comparable across runs without repeatability or comparability residue.
- Do **not** reveal hidden population existence through budget-exceeded, suppression, or row-limit messages.
- Do **not** let agents silently choose weaker fallbacks for stronger questions.
- Do **not** let a degraded preview stay consequential after an exact recompute or invalidation changes the answer.

## What Ward should probably steal next

- a **budget gate** for answer-attempt admission, refusal, and safe fallback boundaries;
- a **degradation receipt** for requested-versus-served answer weakening;
- an **uncertainty envelope** that composes exactness, estimator, sample, privacy, quality, tier, freshness, and nondeterminism residue;
- a standing **degraded answer weaker than requested answer** rule;
- a small fixture suite for exact-too-expensive, sketch preview, sample preview, noisy private count, top-k truncation, validation-summary-only, exemplar-detail-denied, and exact-recompute-later cases.
