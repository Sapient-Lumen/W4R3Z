# SlopOS / companions evaluation — pass XXII

This pass re-checks Ward against SlopOS plus the sibling cubes and keeps the datacube embryonic on purpose.

## What the current cubes still teach
- **SlopOS** keeps family discovery, same-revision maintenance, and machine-checked drift gates explicit. Ward should steal the *discipline*, not the weight: when an outside source becomes design-shaping, the source register, bibliography, synthesis, and manifests should move together in the same revision.
- **ViewFS** repeatedly distinguishes stable references from current live state and warns that live updates can stay advisory. Ward should therefore resist treating fetched status as timeless truth.
- **Steward** keeps countdown posture and followthrough visible. Ward should likewise keep stale/freeze posture typed instead of flattening it into silent retry logic.
- **Harbor** keeps detour success smaller than local adoption. Ward should likewise keep status discovery, fetch success, and current local spend consequence visibly separate.
- **Foundry** keeps provider-native runtime facts smaller than local approval. Ward should likewise keep issuer-published status and publication history smaller than local verdict.

## Current recommendation
Keep Ward open on transport and packaging.

The next wise move is still a specimen, not a schema family:
1. **coherent status cut** versus one-off fetch convenience,
2. **freeze posture** versus negative status meaning,
3. **aggregation/discovery surface** versus per-subject status coordinate,
4. **append-only publication history** versus local spend/adopt consequence.

Do **not** decide yet whether Ward's long-term status ecology prefers:
- direct lookups,
- compressed lists,
- event streams,
- append-only publication logs,
- or a mixed design.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should not import heavy closed-family machinery yet.
The smaller steal is enough for now:
- keep load-bearing outside sources explicit,
- update their discovery surfaces in the same revision when they become design-shaping,
- and make one tiny drift gate verify that the source register does not point at bibliography ghosts.

## Still-not-yet decisions
- Whether `status snapshot` belongs in Ward proper or remains fetch-layer detail.
- Whether `freeze alarm` deserves first-class archive vocabulary or remains a typed failure/result inside specimen flows.
- Whether `aggregation surface` is Ward truth or issuer-side wire convenience.
- Whether append-only `consistency witness` belongs in Ward, a sibling cube, or only in imported evidence packs.
