# Research synthesis — pass LXIV

Pass LXIII made why-answers safer by keeping explanation weaker than accounting, evidence, exemplars, and causal proof. Pass LXIV turns to a quieter operational failure: once a cube answer is expensive to compute, everyone wants to reuse it. In a trust-bearing SlopOS datacube, reuse is not an implementation detail. A cached answer, maintained aggregate, refreshable materialization, star-tree, continuous aggregate, or downsampled tier can silently become a second authority system unless the answer carries its own reuse evidence.

The restraint rule still holds. Ward should not choose a materialized-view product, scheduler, dependency graph, cache invalidator, refresh cadence, OLAP index, or incremental-computation engine while SlopOS remains in design. The healthy move is to name the smallest residues that tell a reader when one answer may be reused, when it was invalidated, and what recomputation obligation remains.

## What the past says we must learn now

1. **Freshness is an SLA-shaped claim, not ambient truth.** dbt source freshness snapshots compare source recency with defined freshness expectations (`EXT-DBT-SOURCE-FRESHNESS-2026`). Ward should steal the explicit freshness contract, but avoid making a scheduler or UI into the source of authority.

2. **Target lag is not exact currentness.** Snowflake dynamic tables expose target lag, downstream refresh, and auto/incremental/full refresh modes (`EXT-SNOWFLAKE-DYNAMIC-TABLE-REFRESH-2026`). The lesson is that a declared freshness target and the actual reuse posture are different residues.

3. **Incremental refresh is conditional.** BigQuery materialized views can use incremental updates only under specific change patterns, and fall back to the original query when those constraints are not met (`EXT-BIGQUERY-MV-INCREMENTAL-2026`). Databricks likewise publishes semantics and requirements for incremental refresh while still promising equivalence to the batch result (`EXT-DATABRICKS-MV-INCREMENTAL-2026`). Ward should not let “incremental” become a trust label unless the conditions are visible.

4. **Refresh strategy is part of meaning once answers are reused.** ClickHouse distinguishes incremental materialized views from refreshable materialized views, with different freshness and cost tradeoffs (`EXT-CLICKHOUSE-MV-TYPES-2026`). A SlopOS-facing answer should expose whether it came from live recompute, retained state, incremental maintenance, scheduled refresh, or hybrid stitch.

5. **Self-correction is healthier than silent replacement.** Materialize describes materialized view replacement and output drift through self-correcting/differential machinery (`EXT-MATERIALIZE-SELF-CORRECTING-2026`), and Feldera's docs foreground DBSP as an incremental view-maintenance engine (`EXT-FELDERA-DBSP-2026`). Ward should steal the delta/correction posture while refusing to bless one engine.

6. **Physical cleanup is not logical invalidation.** Iceberg maintenance warns that orphan-file removal and snapshot expiration need retention discipline (`EXT-ICEBERG-MAINTENANCE-2026`). Ward should keep logical answer invalidation, reader replay floors, and physical reclamation as separate states.

7. **Compaction and layout rewrite can be semantic-adjacent.** Druid compaction rewrites segments and can change granularity, dimensions, or ordering while trying not to alter query results except intentionally (`EXT-DRUID-COMPACTION-2026`). Ward should require layout/materialization changes to declare whether they are result-preserving, fidelity-changing, or comparison-relevant.

8. **Pre-aggregation is brilliant for known workloads and dangerous as a constitution.** Pinot star-trees give fast, bounded aggregation for known group-by patterns but are not appropriate for arbitrary high-cardinality/ad-hoc questions (`EXT-PINOT-STAR-TREE-2026`). Ward should steal workload-shaped acceleration only behind layout apertures and freshness envelopes.

9. **Hybrid answers need a seam.** Real-time aggregate systems can stitch materialized old state with recent raw data (`EXT-TIGERDATA-REALTIME-AGG-2026`). Ward already has hybrid seams; pass LXIV adds that the seam must also say whether the materialized side was fresh enough to reuse and whether the raw side can repair it.

10. **The old cache failure is authority laundering.** Teams routinely treat “the dashboard loaded quickly” as proof that the answer is current, complete, comparable, and safe to explain. SlopOS's D-ATTRFS / CH-ATTRQ posture says the opposite: view-scoped, snapshot-first, handle-returning answers should not acquire ambient latest-state authority through background refresh.

## Resulting Ward move

Do **not** decide yet:

- one materialized-view engine, streaming engine, OLAP index, or refresh scheduler;
- one dependency graph or invalidation propagation protocol;
- one cache key shape, storage tier, or physical layout;
- one global freshness SLA;
- one rule that incremental refresh is always preferable to full recompute;
- one truth-maintenance calculus for all answer capsules;
- one UI badge for “fresh”, “stale”, “invalid”, or “recomputed”.

Do add three small, reversible residues for answer reuse:

- **freshness envelope** — compact reuse boundary for one answer capsule or materialization. It names scope, source cuts, semantic/policy/materialization generation, freshness target, observed lag or cut age, allowed reuse class, stale-by posture, and what must be rechecked before consequence. It is smaller than a scheduler and weaker than current truth.
- **invalidation receipt** — compact evidence that an upstream change, policy shift, schema drift, quality failure, materialization rebuild, privacy change, retention event, or layout rewrite affected an answer. It names trigger, affected cuts/cells/axes, invalidation class, detection time, action taken, and residual uncertainty. It is smaller than a dependency graph.
- **recompute docket** — compact queue/obligation record for recalculating, repairing, rebridging, revalidating, re-comparing, or re-explaining impacted answers. It names priority, required mode, dependencies, budget, replay floor, blockers, and completion/refusal posture. It is smaller than an orchestrator.

These residues sit beside previous pass nouns. A freshness envelope constrains scope lenses, state cut witnesses, resolution/tier/hybrid seams, quality witnesses, comparability passports, and explanation capsules. An invalidation receipt can force a new drift notice, refusal receipt, comparability passport, delta anatomy, or recompute docket. A recompute docket turns invalidation into process without pretending the answer has already been repaired.

## Brilliant ideas to steal now

- **Reuse as a claim, not a cache hit** — every reused answer should say what made reuse legitimate.
- **Observed lag separate from target lag** — desired freshness, measured staleness, and promotion consequence are different layers.
- **Incremental eligibility witness** — when an engine says it can incrementally refresh, Ward should capture the condition that made that safe.
- **Invalidation weaker than delete** — an invalidated answer may remain reviewable evidence while no longer being consequence-grade.
- **Repair queue as public residue** — “needs recompute” is a state worth seeing, not an ops log footnote.
- **Retention floor before cleanup** — physical reclamation should not erase the material needed to re-audit a promoted answer.
- **Layout rewrite humility** — compaction, star-trees, hidden projections, and pre-aggregations are speed/lifecycle moves until they change replayability or comparability.
- **Freshness can refuse** — stale, over-lag, invalidated, under-repaired, or missing-retention answers should emit refusal posture rather than stale truth.

## Still-not-yet decisions

- Whether freshness envelopes attach to every answer capsule, only materialized answers, or only trust-consequence answers.
- Whether invalidation receipts are produced by SlopOS, Ward, Harbor, Steward, or a future maintenance companion.
- Whether recompute dockets are declarative records, executable plans, or tickets handed to a scheduler outside Ward.
- Whether incremental eligibility deserves a separate noun or lives inside freshness envelope/invalidation receipt.
- Whether retention/replay floors belong to state cut witnesses, freshness envelopes, recompute dockets, or all three.
- Whether a stale-but-reviewable answer can still be compared, explained, or shown with a warning.
- Whether answer reuse is machine-checkable before SlopOS has settled query handles, materialization generations, and snapshot naming.

## Process note

Pass LXIV does not add a materialization engine. It adds language for refusing materialization authority laundering. The next healthy move is to run these residues against a SlopOS trust dashboard where a cached answer exists, upstream policy/source/materialization state changed, and a human still wants the answer rendered immediately. If Ward cannot say why reuse is allowed, what invalidated it, and what recomputation remains, the answer should be stale/refused rather than fast and misleading.
