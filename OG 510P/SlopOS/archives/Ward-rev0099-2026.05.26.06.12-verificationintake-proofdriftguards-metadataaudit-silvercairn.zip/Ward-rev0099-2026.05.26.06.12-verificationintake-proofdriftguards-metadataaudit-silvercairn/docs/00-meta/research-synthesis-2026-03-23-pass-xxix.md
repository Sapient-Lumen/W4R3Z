# Research synthesis — pass XXIX

This pass keeps Ward cautious and learns one more thing from stream processors and incrementally maintained views: **event occurrence, completeness estimate, provisional visibility, and later correction are different truths.**

## Outside lessons
1. **A useful first answer is not the same thing as a complete answer.**  
   Beam treats the watermark as a notion of input completeness, not omniscience. It explicitly separates early firings, on-time firings, and late firings, and allowed lateness controls how long late arrivals may still change a window before state is garbage-collected. Ward should steal the humility: one local answer may be useful before the system is confident that relevant later-state intake is complete.

2. **Completeness frontiers are explicit claims, and they are only as strong as the intake model behind them.**  
   Flink says `Watermark(t)` means the stream is *probably* complete through time `t`. It also says designers can choose quicker but less complete answers, or wait longer and get stronger completeness, or emit fast answers and later corrections. Ward should steal that explicitness: “current enough” should become a visible claim rather than a hidden vibe.

3. **Window closure needs an explicit budget, not a magical forever-open or forever-closed default.**  
   Kafka Streams says window grace is the period during which out-of-order events may still revise a result, and records arriving after that grace are late and dropped for that window. Kafka’s recent guidance went even further: it removed the easy implicit 24-hour default and forced developers to choose an explicit grace period or an explicit no-grace posture. Ward should steal the process lesson as much as the technical one: if a result may still change, say for how long.

4. **Corrections are often best modeled as deltas, not invisible rewrites.**  
   Materialize describes incremental view maintenance as streams of `(data, time, diff)` tuples, and its self-correction work treats output drift and view-definition replacement through one correction mechanism rather than pretending old output was never emitted. Ward should steal the honesty: late trust facts should be able to retract or revise an earlier projected answer without erasing the archive’s memory that the earlier answer once existed.

## Resulting Ward move
Do not decide yet whether Ward’s long-term later-state cube is stream-first, watch-first, changelog-first, compacted-view-first, or replay-on-demand.

For now, preserve four separations and let later specimens force promotion:
- `completeness frontier` versus effective change time, publication time, or apply cursor;
- `provisional view` versus survivor view or final local consequence;
- `lateness budget` versus retention or compaction horizon;
- `retraction delta` versus full replacement state or whole-history replay.

## Fresh ideas worth stealing
- **completeness frontier** — explicit claim about how far relevant intake is believed complete enough for one result family.
- **provisional view** — early answer emitted before the correction window has closed.
- **lateness budget** — visible window in which late-arriving facts may still revise a result.
- **retraction delta** — explicit correction that narrows, withdraws, or amends an earlier projected answer.
- **no fake final-by-default** — a standing anti-regrowth rule.
