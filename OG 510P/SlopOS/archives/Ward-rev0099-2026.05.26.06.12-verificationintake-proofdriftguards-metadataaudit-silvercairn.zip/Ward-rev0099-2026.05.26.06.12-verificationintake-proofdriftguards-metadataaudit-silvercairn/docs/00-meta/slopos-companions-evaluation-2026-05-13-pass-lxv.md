# SlopOS / companions evaluation — pass LXV

Pass LXV treats interaction, rendering, and egress as trust-bearing datacube events. Pass LXIV said answer reuse needs freshness and invalidation residue. Pass LXV says a dashboard gesture, drill-through, chart transform, export, screenshot, embed, alert, or agent summary must not silently become a new authority surface.

## What the included cubes keep teaching

- **SlopOS** remains the anchor. D-ATTRFS / CH-ATTRQ already says queries are view-scoped, snapshot-first, handle-returning, bounded, and saved-query persistence stays shell-owned. An interaction trail should preserve that posture: every filter, parameter, drill, and agent follow-up stays bound to explicit view/query/render/egress material rather than becoming hidden session state.
- **Harbor** is the strongest pressure for egress receipts. Harbor's temporal witnesses, lineage guards, restatement habits, and contract subsets imply that exported/reported artifacts may need later narrowing, restatement, or invalidation without pretending the old artifact never existed.
- **Foundry** keeps basis, candidate, active generation, pinned cut, and restore duty distinct. Render contracts should identify which basis/cut/generation the displayed table or chart used, instead of letting current UI state substitute for basis evidence.
- **Steward** keeps bootstrap, reconciliation, cause condition, followthrough, and process state visible. Interaction trails and egress receipts create followthrough obligations when a misleading export, stale screenshot, hidden bucket, or unsafe drill-through needs review.
- **Schell** keeps basis cards, activation receipts, and environment epochs separate. Renderer version, agent environment, notebook/runtime, or visualization-library epoch may be relevant to a render contract without becoming the datacube engine.
- **ViewFS** is the warning for stable handles versus live aliases. A shared chart, copied table, or CSV must not retarget itself to a live alias. It should resolve once to a source capsule/render contract/egress receipt and then decay or be reissued.
- **Helm** is where the UX harm appears. Helm will want filters, click-through, exports, screenshots, alert summaries, and agent-generated explanations. Ward should give Helm stricter surfaces: interaction trail available, render contract visible, egress receipt required, drill refused, export truncated, stale detached artifact, or rehydrate-required.

## What this means for the SlopOS datacube

A SlopOS-facing interactive/rendered/exported answer should require at least:

1. **An interaction trail for consequential handling.** User gestures, agent follow-ups, drill paths, filters, parameter changes, refresh attempts, annotations, exports, and refusals should leave a bounded trail tied to the requester view and source answer capsule.
2. **Renderer transforms named as meaning.** The render contract should expose top-k, sorting, grouping, binning, time unit conversion, current-layout flattening, “other” buckets, missing/suppressed/denied cells, precision, scale, timezone, and row/cell limits when they can change interpretation.
3. **Exports treated as new artifacts.** Every CSV, spreadsheet, image, copied table, alert, embedded chart, or agent summary should get an egress receipt naming included/omitted/redacted material, scope, format, sensitivity, expiry, and detached-from-live posture.
4. **No hidden count/existence oracle.** Drill-through refusal, export truncation, suppression messaging, and “more rows exist” notices must not leak denied cells or hidden population outside the authorized view.
5. **Agents rehydrate through authority.** An agent may remember an egress receipt or interaction trail, but it should not use a stale CSV, screenshot, or chat summary as if it were a live capability. Consequential follow-up should re-enter through scope lens, state cut witness, and query contract.
6. **Annotations do not patch answers.** Human or machine comments may target cells/ranges/charts/capsules, but correction still requires a new answer, invalidation receipt, recompute docket, or review process.
7. **Detached artifacts can be narrowed later.** A stale or invalidated export may remain reviewable evidence while losing current/consequence grade. The egress receipt should make that narrowing explainable.

## Companion-specific steals

- From **Harbor**: restatement and lineage-change receipts as invalidation hooks for exported artifacts.
- From **Foundry**: basis pins and active-generation discipline inside render contracts.
- From **Steward**: misleading-export / unsafe-drill followthrough as visible process state.
- From **Schell**: environment epochs and activation receipts for renderer/agent/runtime seams when relevant.
- From **ViewFS**: resolve-once semantics for shared/exported artifacts; no live alias retargeting.
- From **Helm**: consequence-aware interaction affordances and export badges that do not hide refusal or truncation.

## Anti-lessons to preserve

- Do **not** let a filter widget become an unlogged query rewrite.
- Do **not** let a chart title imply the rendered chart preserves all answer residue.
- Do **not** let top-k, sort, bins, “other”, hidden rows, or current-layout flattening hide inside renderer folklore.
- Do **not** let drill-through reveal exemplar material without exemplar fences and authority scope.
- Do **not** let a CSV, screenshot, alert, embed, or copied table become a live query handle.
- Do **not** let agent conversation memory substitute for view-scoped rehydration.
- Do **not** let suppression/truncation messages leak hidden population or denied cell existence.
- Do **not** let annotations, comments, or review flags silently rewrite answer cells.

## What Ward should probably steal next

- an **interaction trail** beside consequential filter/drill/export/agent handling;
- a **render contract** beside any table/chart/card whose rendering decisions can alter interpretation;
- an **egress receipt** for detached artifacts and shared outputs;
- a standing **rendered/exported artifact weaker than source answer** rule;
- a small fixture suite for filter-trail, top-k hidden bucket, drill refusal, export truncation, screenshot decay, stale-agent-summary, and annotation-not-correction cases.
