# Research synthesis — pass XL

This pass adds one more design-pressure seam without freezing Ward into a specific queue, log, controller, snapshotter, or CDC carrier: **a resume cursor, a continuity class, a history gap alarm, and a backfill posture are different truths**.

## What the outside systems say
1. **Resume handles are useful, but they are not continuity guarantees.**  
   MongoDB change streams let clients resume from resume tokens and even distinguish `resumeAfter` from `startAfter`, but they also say the oplog must still contain enough history to locate the referenced operation or timestamp. Ward should steal that humility. A saved cursor is weaker than proof that the missed interval is still recoverable.

2. **History-retention failure deserves a named posture, not a silent reset.**  
   PostgreSQL now exposes replication-slot states like `reserved`, `unreserved`, and `lost`, plus explicit invalidation reasons such as `wal_removed` and `idle_timeout`. Kafka consumer docs likewise state that the current offset may no longer exist on the server and make the next move (`earliest`, `latest`, `by_duration`, or `none`) an explicit policy choice. Ward should steal both lessons: a continuity break is not just another resume.

3. **Backfill/rebuild and live intake can coexist, but only if the system says so honestly.**  
   Debezium's incremental snapshots are especially good pressure here. The docs make three separate facts explicit: the source log may not contain full historical truth, an initial or incremental snapshot may be needed to establish baseline state, and a resumable chunked backfill may run alongside live streaming without pretending the whole lane was one uninterrupted stream. Ward should steal that discipline.

4. **Retention budgets still bound whether a full “current” reconstruction is even safe.**  
   Kafka's tombstone-retention docs already taught Ward that a compacted current view needs enough marker-retention for readers to finish a full scan. This pass sharpens the same lesson for intake history: a cursor or offset is weaker than the source's willingness and ability to replay the intervening segment.

## Resulting Ward move
Do **not** decide yet whether Ward should literally standardize one cursor envelope, one replay protocol, one gap-proof family, one reset verb, or one baseline-materialization mechanism.

For now, preserve four separations and let later specimens force promotion:
- `resume cursor` versus proof that the missing interval is still recoverable;
- `continuity class` versus fake yes/no “stream healthy” language;
- `history gap alarm` versus silent fallback to `latest`, `earliest`, or “good enough” replay;
- `backfill posture` versus pretending baseline repair and live intake are the same activity.

Keep nearby, but not yet promoted, a few smaller ideas:
- `continuity downgrade` for when a once-resumable lane becomes reset/backfill-only;
- `cursor decay horizon` for the point after which old resume handles are no longer trustworthy;
- `reset reason handle` for why local history continuity was broken; and
- `live-plus-backfill braid` for systems that truthfully expose both ongoing intake and bounded reconstruction together.

## Fresh ideas worth stealing
- **resume cursor** — restart handle smaller than continuity proof.
- **continuity class** — explicit statement of whether local history is continuous, resumable-with-window, reset-required, or unknown.
- **history gap alarm** — visible residue that one interval may no longer be replayable from the original source.
- **backfill posture** — explicit note that baseline reconstruction or bounded replay is in progress or required.
- **cursor decay horizon** — local reminder that saved positions can age out even when the abstraction sounds durable.
