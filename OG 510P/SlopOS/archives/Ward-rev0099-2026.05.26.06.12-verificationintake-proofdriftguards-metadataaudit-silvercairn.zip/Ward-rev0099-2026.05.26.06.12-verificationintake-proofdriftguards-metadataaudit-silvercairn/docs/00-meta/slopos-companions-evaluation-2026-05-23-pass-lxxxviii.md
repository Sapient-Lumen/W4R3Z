# SlopOS companions evaluation — pass LXXXVIII

## Question

Can Ward resolve a forked or pending governance lineage without letting resolution become action/export authority or leaking sealed branch evidence?

## SlopOS seam

SlopOS can see Ward governance evidence through portal rendering, CH-AREF attachment, action proposals, export packages, tool calls, resume/recheckpoint paths, and cached status pointers. After pass LXXXVII, SlopOS can demand chain integrity, but it still needs a way to handle a later resolution.

The dangerous SlopOS failure modes are:

- choosing whichever status pointer arrived last;
- caching a fork hold and missing the resolution;
- caching a recovered head and missing a later quarantine;
- treating resolution as permission to export, act, repair, remedy, learn, or spend;
- showing public users the exact number or identity of sealed branches;
- replaying an old status channel after resolution.

## Pass LXXXVIII answer

Ward now introduces a governance dispute-resolution receipt that lets SlopOS demand:

- source chain id/path/byte digest and source chain digest;
- source chain validator replay;
- observed branch-set digest;
- disposition for every observed branch;
- selected branch only when a current head is recovered;
- successor acceptance and current-status recheck before recovered-head state;
- old-channel invalidation and recipient notification;
- no source-chain mutation;
- projection-safe branch disclosure;
- no-authority labels and forbidden-effect preservation.

## Companion pressure

- **ViewFS** should show recovered, held, pending, and historical-only resolution states distinctly.
- **Schell** should retain source chains and resolution receipts separately and minimize public branch detail.
- **Harbor** should refuse recompute/correction support from held or unrefreshed resolutions.
- **Helm** should render resolution state as operator information, not approval.
- **Foundry** should not treat resolved ownership/status as classification or crosswalk authority.
- **Steward** should not let successor labels or component ownership replace resolution evidence.
- **SlopOS** should require a fresh dispute-resolution receipt plus source-packet replay before CH-AREF, portal, export, tool, action, remedy, learning, or budget use.

## Remaining risk

Resolution receipts still need consumer-side refresh discipline. The next seam is likely cached-resolution invalidation: a downstream cube can cache a valid recovered head, then miss a later fork, quarantine, or status-channel withdrawal.
