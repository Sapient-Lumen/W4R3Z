# Research synthesis — pass XLII

This pass adds another design-pressure seam without freezing Ward into one warehouse, one metric layer, one dashboard constitution, or one omniscient current-state cube: **basis pin, cohort contrast, and promotion bay are different truths**.

## What the past says we must learn
1. **Pinned basis beats ambient “latest”.**  
   Datomic is still one of the cleanest teachers here. A database value carries an explicit basis `:t`, and the API also exposes `:as-of`, `:since`, and `:history` views. That is the right pressure for Ward: follow-up questions should be able to point at the exact factual cut they are about instead of inheriting whatever “latest” means a moment later.

2. **The same question should survive filtered or scoped views.**  
   Datomic's filters are even more useful than they first appear: one set of queries can run unchanged against differently filtered database values. Ward should steal that spirit. A saved trust exploration should be able to run against a basis-pinned scope, a redacted scope, or a narrower cohort without rewriting the whole object model first.

3. **Exploration wants rich events and high-cardinality contrast before pre-baked rollups.**  
   Honeycomb's event model, BubbleUp outlier analysis, and emphasis on Top-K/HAVING over high-cardinality dimensions are an excellent reminder that the first healthy move is often not “pick the dashboard dimensions now.” The first healthy move is to keep fact shape rich enough that the surprising difference can reveal itself.

4. **Maintained derivatives are powerful, but they are still derivatives.**  
   Materialize is a sharp teacher here from two angles. Its operational-consistency posture keeps materialized views “always up to date” relative to inputs, and its replacement materialized views preserve downstream dependencies while diffs flow through the dependent graph. That is a brilliant pattern to steal carefully: once a derived Ward surface proves repeatedly useful, we should be able to promote it without pretending it became source truth.

5. **Versioned references and retention policy are separate from one mutable current surface.**  
   Iceberg's snapshots, tags, and branches reinforce a crucial point: named references can have independent retention and readers only see a snapshot until they refresh. Ward should therefore treat a saved analytic basis as an explicit pinned thing, not as a pretty name for “whatever the cube says today.”

6. **Precomputation is workload-shaped, not constitution-shaped.**  
   ClickHouse projections and Pinot star-tree indexes are great, but only under known query patterns and with real limits. ClickHouse explicitly says projections should be deployed sparingly and documents several limitations; Pinot's star-tree index exists to accelerate known aggregation/group-by workloads on chosen columns. Ward should steal the lesson, not the eagerness: pre-aggregation belongs after repeated query evidence, not before.

## Resulting Ward move
Do **not** decide yet whether Ward's eventual datacube should be one semantic layer, one OLAP engine, one lakehouse table format, one stream processor, or one purpose-built trust store.

For now, keep three separations visible and let later specimens force promotion:
- **basis pin** — the exact factual cut/scope a follow-up exploration is anchored to;
- **cohort contrast** — a way to ask “what stands out here versus background?” without predeclaring the winning dimensions;
- **promotion bay** — an explicit promotion step where a repeatedly useful saved query/derivative becomes a maintained surface with owner, freshness posture, and lineage.

## Why these separations are worth stealing
- A `basis pin` keeps replay, review, and disagreement honest.
- A `cohort contrast` lets Ward discover which facets matter before it hardens summary vocabulary too early.
- A `promotion bay` lets Ward graduate from exploratory query to maintained derivative **without** silently letting the derivative impersonate evidence, appraisal recipe, or local consequence.

## Brilliant ideas to steal now
- **basis pin** — exact query basis smaller than ambient latest.
- **saved query recipe** — a durable query recipe that can be re-run against a pinned or moved basis.
- **cohort contrast** — contrast-first surfacing of what is unusual about one selected set.
- **basis drift alarm** — visible notice that a saved exploration is now running against a different basis than before.
- **promotion bay** — a named place where derived surfaces earn owners, refresh posture, and lineage before becoming team-facing.
- **derivative weaker than source** — a standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward wants one global cube at all, or a thinner family of queryable trust surfaces.
- Whether basis pins should be first-class durable Ward nouns, or remain datacube/query-side residue until more specimens accumulate.
- Whether cohort contrast belongs inside Ward, or remains an adjacent analytic capability layered over Ward facts.
- Whether promotion bays should become durable Ward vocabulary, or remain repo/process guidance until several promoted derivatives survive pressure.
