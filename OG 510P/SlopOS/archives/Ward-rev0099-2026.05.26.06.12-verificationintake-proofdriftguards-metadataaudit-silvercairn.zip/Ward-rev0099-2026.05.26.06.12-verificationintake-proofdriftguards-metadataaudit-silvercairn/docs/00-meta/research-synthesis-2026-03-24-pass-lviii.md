# Research synthesis — pass LVIII

This pass keeps Ward decision-light and adds another datacube discipline: **privacy-shaped answers are their own truth class, and thresholded, suppressed, or differentially private results should not masquerade as replayable exact truth or ordinary approximation.**

## What the past says we must learn
1. **Protected entity definition belongs in the contract.**  
   BigQuery’s differential privacy docs say a valid differentially private query must define exactly one **privacy unit column**, and that a privacy unit is the entity being protected. Ward should steal the lesson directly: once a repeated question is privacy-shaped, the protected entity is part of the answer’s meaning rather than hidden setup (`EXT-BIGQUERY-DIFFERENTIAL-PRIVACY-2026`).

2. **Differential privacy is not just “approximate analytics but noisier.”**  
   BigQuery’s differentially private aggregate docs say the results can change on each run and that smaller aggregations might be removed. Snowflake’s differential privacy overview says differential privacy quantifies the trade-off between privacy and utility and protects against differencing and amplification attacks. Ward should steal the constitutional lesson: a privacy-protected answer deserves its own honesty surface rather than borrowing the authority of exact or merely approximate replay (`EXT-BIGQUERY-DP-FUNCTIONS-2026`, `EXT-SNOWFLAKE-DIFF-PRIVACY-2026`).

3. **Suppression is real loss even when the UI stays quiet.**  
   AWS Clean Rooms documents that output constraints can require at least a minimum distinct-identifier count for a row to appear, and the query output does **not** indicate that results were removed because of the output constraint. Ward should steal the warning: missing rows can be a privacy policy effect rather than observational absence (`EXT-AWS-CLEANROOMS-ANALYSIS-RULES-2026`).

4. **Privacy budgets and noise settings are semantic residue, not merely operator knobs.**  
   AWS Clean Rooms differential privacy policy configuration makes privacy budget, budget refresh, and noise added per query explicit, and it lets providers view usage logs for how much privacy budget was consumed. Ward should steal the idea that privacy-shaped answers need inspectable budget lineage rather than one magical “safe answer” badge (`EXT-AWS-CLEANROOMS-DP-POLICY-2026`).

5. **Contribution bounding changes the question before noise is added.**  
   BigQuery’s docs require contribution bounds or implicit clamping, and AWS Clean Rooms documents user contribution limits plus min/max bounds for noisy aggregates. OpenDP’s measurement docs make the same deeper point in a more formal register: a privacy measurement has an input metric, an output measure, and a privacy relation, and threshold/noise mechanisms trade computational efficiency against a looser privacy map when the noise granularity changes. Ward should steal the discipline that bounded participation and release mechanism belong in the answer’s residue (`EXT-BIGQUERY-DIFFERENTIAL-PRIVACY-2026`, `EXT-AWS-CLEANROOMS-DP-POLICY-2026`, `EXT-OPENDP-MEASUREMENTS-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal differential-privacy stack, one threshold-suppression engine, one privacy-budget odometer, or one collaboration-safe publication contract.

For now, keep three more separations visible and let later specimens force promotion:
- **privacy posture** — visible statement of whether the answer is exact-inside-scope, threshold-suppressed, differentially private, or another declared privacy-shaped truth class.
- **noise witness** — visible statement of the protected entity, contribution bounds, and budget/noise family or other declared privacy mechanism residue behind the answer.
- **suppression fence** — visible statement of what small groups, cells, rows, or result fragments may be withheld and whether withholding is signaled or silent.

## Why these separations are worth stealing
- A **privacy posture** stops “safe to share” from silently becoming “same answer, just with permissions.”
- A **noise witness** stops one noisy or budgeted release from borrowing the authority of replayable exact truth.
- A **suppression fence** stops hidden row removal from impersonating observational absence or zero.

## Brilliant ideas to steal now
- **privacy-unit badge** — compact display of what entity is being protected.
- **budget odometer** — visible residue that privacy cost accumulates across releases instead of resetting by narrative convenience.
- **silent-suppression warning** — compact cue that a blank or missing row may be policy-shaped rather than data-shaped.
- **release-family card** — one small surface for threshold-only, DP-with-bounds, or other declared privacy family.
- **privacy-shaped weaker than replayable exact** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward should require privacy posture only when a result crosses operator or collaborator boundaries, or on every repeated question backed by sensitive entities.
- Whether noise witness should be mandatory on every differentially private answer or only when the answer becomes a promoted recurring surface.
- Whether suppression fence should describe only row/cell suppression or also privacy-driven withholding of whole charts or cohorts.
- Whether Ward should later distinguish threshold suppression from full differential-privacy releases as separate promoted truth classes.
