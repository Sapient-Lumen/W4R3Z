# SlopOS / companions evaluation — pass LVII

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **query/result meaning gets weaker when identity, dedupe quality, and correction lineage disappear behind one friendly current-state surface.**

## What the included cubes keep teaching
- **SlopOS** remains the strongest nearby teacher because D-ATTRFS already says query should be view-scoped, snapshot-first, and handle-returning, with saved queries staying shell-owned manifests. The datacube analogue is that a saved query recipe can stay perfectly pinned and still need an explicit answer about whether rows were raw append facts, retry-collapsed winners, or delete-aware corrected state.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: manifest, frozen hit set, live feed, materialized collection, and durable receipt are different truths. The datacube analogue is that raw append history, current deduped winner, correction chain, and deletion-aware current head should also stay visibly distinct.
- **Steward** and **Foundry** keep pressuring Ward toward honest aftermath objects: smaller borrowed utility, explicit consequence envelopes, and no silent adoption. The datacube analogue is that a background-compacted “current row” should stay visibly weaker than the underlying correction-bearing history that made it possible.

## What outside systems add to the datacube posture
- BigQuery adds the first discipline: retry collapse through `insertId` is **best-effort** and not recommended for stronger semantics. Ward should steal that as **dedupe posture** honesty, not as a commitment to BigQuery (`EXT-BIGQUERY-INSERTALL-2026`).
- ClickHouse adds the second discipline: duplicate cleanup during background merges is helpful but not equivalent to exact no-duplicates truth. Ward should steal that as **winner-on-read is weaker than raw history** honesty, not as a commitment to one table engine (`EXT-CLICKHOUSE-REPLACINGMERGETREE-2026`).
- Debezium adds the third discipline: change streams can preserve create/update/delete/read operation type, before/after state, and source ordering metadata. Ward should steal that as **correction lineage** honesty, not as a commitment to Kafka or CDC plumbing (`EXT-DEBEZIUM-POSTGRES-2026`).
- dbt snapshots add the fourth discipline: history over a `unique_key` plus explicit delete handling (`hard_deletes: new_record`) is a real modeling choice, not an afterthought. Ward should steal that as **identity witness** plus **explicit delete-as-state** honesty, not as a commitment to dbt (`EXT-DBT-SNAPSHOTS-2026`, `EXT-DBT-HARD-DELETES-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Any promoted recurring surface that collapses rows should declare an identity witness before it borrows the title of raw fact.**
2. **Any current-state or current-winner derivative should declare dedupe posture so exact raw append history, best-effort retry collapse, background compaction, and on-read replacement cannot impersonate one another.**
3. **Any promoted surface that absorbed updates or deletes should preserve correction lineage or explicitly admit that only the present winner is shown.**
4. **Ward should not bless one universal event id, one global upsert engine, one tombstone retention floor, or one mandatory correction-history substrate while SlopOS and its siblings are still settling their own query/result/materialization seams.**
5. **If Ward later imports current-state surfaces from different systems, it should treat identity-rule drift and dedupe-quality drift as semantic drift until proven comparable.**

## Specific anti-lessons from the past
- Do **not** let row equality or storage coincidence masquerade as semantic identity.
- Do **not** let best-effort retry collapse borrow the authority of exact ingest truth.
- Do **not** let background compaction hide the existence of still-readable duplicates.
- Do **not** let delete handling vanish into absence when explicit delete state or tombstones mattered to the result.
- Do **not** compare raw append counts and deduped current counts under one flattering recurring title.

## What Ward should probably steal next
- an **identity witness** attached to any promoted surface that groups or collapses rows by a declared logical key;
- a **dedupe posture** attached to any promoted current-state or current-winner surface that is weaker than raw append history;
- a **correction lineage** attached to any promoted delete/update-aware surface that has lived through replacement, tombstone, or explicit delete state;
- a standing rule that **current winner is weaker than raw history** until the identity and correction story stays inspectable.
