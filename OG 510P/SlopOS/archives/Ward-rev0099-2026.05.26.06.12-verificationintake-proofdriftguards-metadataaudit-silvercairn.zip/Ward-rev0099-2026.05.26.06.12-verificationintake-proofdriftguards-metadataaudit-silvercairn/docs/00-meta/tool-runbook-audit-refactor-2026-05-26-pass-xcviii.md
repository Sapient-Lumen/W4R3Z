# Tool runbook audit/refactor — pass XCVIII

Rev0098 adds `tools/check_tool_runbook_integrity.py`.

## Problem

The governance checker suite is now large enough that the human runbook can lag the machine registry. A future receipt family could be fully wired into the registry but absent from `tools/README.md`, or a new audit checker could be added to the Makefile without being explained. That is not a semantic trust failure, but it is an operational maintainability failure.

## Refactor

The new audit checks:

- every script listed in `tools/governance_checker_registry.json` appears in `tools/README.md`;
- required maintenance/audit tools appear in `tools/README.md`;
- required audit tools are present on disk;
- the `make check` target invokes the core audit/runbook tools and the governance suite;
- `tools/README.md` does not contain duplicate tool bullets.

## Boundary

This is an index/runbook audit only. It does not prove that a checker is semantically complete. It only fails silent documentation drift so maintainers can find the validator surfaces they are depending on.
