# Research synthesis — pass XLIV

This pass keeps Ward decision-light and adds another datacube discipline: **staged derivative, publish rail, and change witness are different truths**.

## What the past says we must learn
1. **A candidate derivative should be buildable and inspectable before it becomes current.**  
   Iceberg's WAP workflow is the cleanest teacher here: writes can land on an audit branch, and `publish_changes` later promotes a staged WAP ID into current table state without pretending the staged work was already live. Ward should steal the posture, not the machinery. A repeatedly useful trust derivative should be allowed to exist as a **staged derivative** before it becomes the current maintained surface (`EXT-ICEBERG-WAP-2026`).

2. **Replacing a maintained derivative should preserve downstream consumers without pretending the replacement is already official.**  
   Materialize now supports replacement materialized views that hydrate in the background, can be queried to validate results before replacement, and can then replace the target in place without recreating dependent objects. That is a strong reminder that “candidate,” “validated,” and “published” are not the same state (`EXT-MATERIALIZE-REPLACEMENT-MV-2026`).

3. **A rerun diff is healthier when it carries typed change evidence.**  
   Delta Lake's change data feed records row-level change events with metadata that says whether a row was inserted, deleted, or updated, and it explicitly calls out audit-trail use. Ward should steal the honesty. When a promoted trust derivative changes, a reviewer should be able to inspect a **change witness**, not just a shiny new table and a vague “refreshed” badge (`EXT-DELTA-CDF-2026`).

4. **Named refs still matter even when promotion gets fancier.**  
   Iceberg snapshot references keep immutable snapshots separate from mutable branches and tags with their own retention policy. Ward should not let publish-time convenience erase the earlier lesson that exact bases and named references are still smaller and truer than ambient currentness (`EXT-ICEBERG-SNAPSHOT-REFS-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward's eventual datacube rides on one warehouse, one stream processor, one lakehouse format, one semantic layer, or a thinner family of trust-query surfaces.

For now, keep three more separations visible and let later specimens force promotion:
- **staged derivative** — a candidate maintained surface that is hydrating or under review but not yet official;
- **publish rail** — an explicit apply/swap step that promotes one staged derivative into the active maintained surface;
- **change witness** — typed inserted/deleted/updated difference evidence between two result versions or maintained derivatives.

## Why these separations are worth stealing
- A `staged derivative` prevents one hot edit from silently rewriting team-facing truth.
- A `publish rail` makes promotion a deliberate reviewable action instead of an ambient side effect of hydration finishing.
- A `change witness` keeps review focused on what actually changed rather than on a vague replacement story.

## Brilliant ideas to steal now
- **staged derivative** — candidate maintained surface that can hydrate and be inspected before swap.
- **publish rail** — explicit move from staged candidate to active derivative.
- **change witness** — typed inserted/deleted/updated diff for one rerun or replacement.
- **validate-before-swap** — a standing process rule.
- **no silent derivative swap** — a standing anti-regrowth rule.

## Still-not-yet decisions
- Whether `staged derivative` belongs inside Ward proper or remains datacube-side guidance until more promoted surfaces exist.
- Whether `publish rail` is just one part of promotion bay or deserves durable independent vocabulary later.
- Whether `change witness` should stay a review/product surface or eventually become a typed archive artifact family.
- Whether these moves are best served by one engine's native features or by thinner Ward-owned receipts over several substrates.
