# Research synthesis — pass LXI

This pass goes deeper on the SlopOS-shaped datacube question by treating **authority scope and answer failure as first-class datacube material**. Pass LX asked what a promoted answer cell means. Pass LXI asks a more dangerous question: what exactly was this answer *allowed* to see, which mutable cuts did it depend on, and how should Ward preserve the fact that a tempting answer was not produced?

The goal is still restraint. Ward should not choose a global cube engine, saved-query service, semantic-layer monopoly, table format, array store, or lineage stack while SlopOS remains in design. The healthy move is to add small residues that let future answers say: this was my scope, these were my cuts, and these are the reasons I refused or withheld parts of the answer.

## What the past says we must learn now

1. **A cube query can become an authority oracle if scope is not part of the answer.** SlopOS D-ATTRFS already guards against ambient search: CH-ATTRQ is bounded, schema-shaped, view-scoped, snapshot-first, and handle-returning. Ward's datacube should mirror that by requiring a **scope lens** before any promoted answer borrows authority from a SlopOS view. A count-only, existence-only, or cross-view query can leak more than a normal handle-returning answer.

2. **Semantic layers are useful because they fail differently than text-to-SQL.** MetricFlow/dbt-style semantic models separate entities, dimensions, measures, and metrics; this is useful because supported questions can compile deterministically, while unsupported questions can fail instead of producing a plausible wrong number (`EXT-DBT-SEMANTIC-MODELS-2026`, `EXT-DBT-METRICFLOW-2026`). The 2026 dbt benchmark is load-bearing for one lesson, not for its exact numbers: where accuracy matters, a covered semantic layer should return either a governed answer or an explicit cannot-answer state, not a creative SQL guess (`EXT-DBT-SEMANTIC-LAYER-AI-BENCH-2026`).

3. **`CUBE` and `ROLLUP` create super-aggregate identity that must not be confused with ordinary nulls.** DuckDB and ClickHouse both expose modern grouping-set / rollup / cube surfaces; ClickHouse and DuckDB also expose grouping indicators so subtotal rows can be distinguished from ordinary grouped values (`EXT-DUCKDB-GROUPING-SETS-2026`, `EXT-CLICKHOUSE-GROUPING-SETS-2026`). Ward should steal the lesson: an “ALL” cell, unknown cell, suppressed cell, missing cell, and null-valued dimension member need different residue.

4. **Aggregate state is not the displayed answer.** ClickHouse's `AggregateFunction` / merge-state posture is a useful reminder that retained intermediate state can be recomposed while a displayed scalar may not be safely regrouped (`EXT-CLICKHOUSE-AGGREGATEFUNCTION-2026`). Ward already has merge-state language; LXI adds that a **state cut witness** must say which state family and generation produced an answer before that answer influences trust.

5. **Labeled arrays teach alignment, but labels are not enough.** Xarray's dataset model uses named dimensions, coordinates, variables, and attributes for metadata-aware operations (`EXT-XARRAY-DATA-STRUCTURES-2026`). That is a good shape to steal for human-inspectable axes, but Ward should not pretend aligned labels prove identical authority scope, policy epoch, fill rule, or lineage.

6. **Sparse coordinates make absence explicit.** TileDB-style dimensions define coordinates in sparse arrays and empty sparse cells are not materialized (`EXT-TILEDB-DIMENSIONS-2026`). Ward should carry that lesson forward: if a cell is empty because the query was not allowed to see it, because privacy policy suppressed it, because no observation existed, or because a sparse store never materialized it, the refusal/absence reason must survive.

7. **Interchange needs security posture, not only speed.** Arrow's 2026 security model frames the columnar format, C Data Interface, and IPC as building blocks that need expectations for untrusted sources (`EXT-ARROW-SECURITY-MODEL-2026`). Ward should steal this for exported answer batches: a fast columnar crossing is not an admission of trusted meaning unless the scope lens, state cut witness, and lineage facet survive the crossing.

8. **The failure mode we should fear is the polished partial answer.** Old OLAP, spreadsheets, dashboards, and now LLM-assisted analytics all make it easy to render something attractive. Ward's datacube should treat incomplete authority, unsupported dimensions, stale cuts, privacy suppression, budget exhaustion, and cost guardrails as answer material rather than side-channel logs.

## Resulting Ward move

Do **not** decide yet:

- one global saved-query inventory;
- one semantic-layer authority above SlopOS views;
- one count/existence API for cube questions;
- one meaning for null, missing, ALL, suppressed, filtered, or refused cells;
- one retained aggregate-state representation;
- one canonical snapshot protocol for every future datacube answer;
- one LLM/text-to-SQL route for uncovered questions.

Do add three small, reversible residues for promoted datacube answers:

- **scope lens** — compact authority residue naming the SlopOS view/snapshot, namespace, schema/query digest, capability scope, authorized population, and any count/existence/leakage limits that bound the answer. It is smaller than an access-control system and smaller than a semantic layer.
- **state cut witness** — compact mutable-cut residue naming the source snapshots, policy epoch, semantic/model version, materialization generation, redaction profile, layout/tier, calendar/unit/fill/privacy posture, and other cuts that made the answer what it is. It is smaller than a global snapshot protocol.
- **refusal receipt** — compact cannot-answer or withheld-answer residue naming unsupported query shape, schema mismatch, denied authority, hidden population, stale state, privacy suppression, cost/budget exhaustion, or unmodeled dimension/measure reasons. It is smaller than an exception system and stronger than an empty chart.

These residues do not replace axis capsule, layout aperture, or lineage facet. They sit in front of and beside them: scope lens answers “what were you allowed to see?”, state cut witness answers “which moving world did you freeze?”, lineage facet answers “how did this come to be?”, and refusal receipt answers “what did you not answer and why?”

## Brilliant ideas to steal now

- **Cannot-answer as a product surface** — semantic layers and guarded query systems teach that a refusal can be safer than a plausible number.
- **Scope-as-data** — carry the authorized view/population with the answer, not just in execution logs.
- **Subtotal identity badges** — steal `GROUPING`/grouping-id style cues so `ALL`/subtotal cells cannot be mistaken for null or unknown members.
- **State before scalar** — retained aggregate state, sketches, or materialized summaries can be stronger recomposition material than a rendered scalar; say which state cut was used.
- **Coordinate labels plus cut labels** — labeled dimensions are useful, but only when joined with policy epoch, query scope, time/calendar, fill, unit, privacy, and lineage cuts.
- **Refusal ledger in the answer capsule** — every promoted answer should be able to show whether there were zero refusals or which parts were refused/withheld.
- **Export quarantine** — a columnar batch or view manifest should arrive with its scope/state/refusal residues intact, otherwise Ward should appraise it as an imported fact rather than native truth.

## Still-not-yet decisions

- Whether scope lens becomes mandatory on every datacube answer or only on answers that cross a trust, view, privacy, or promotion boundary.
- Whether state cut witness should be one card, a bundle of existing residues, or a named facet set.
- Whether refusal receipts are cell-level, cohort-level, query-level, or all three.
- Whether SlopOS should ever expose a count-only datacube surface, and if so which anti-oracle proofs it must carry.
- Whether a future Ward semantic layer should compile to CH-ATTRQ, SQL, Substrait, array slicing, object-manifest traversal, or a mixed plan graph.
- Whether LLM-generated datacube proposals should be allowed only as draft query cards until a scope lens and refusal receipt have been computed by deterministic machinery.

## Process note

Pass LXI adds refusal and cut discipline before adding schema. The next healthy move is to run these residues against a SlopOS view-scoped snapshot query that returns both answer cells and explicit cannot-answer material. If that specimen stays small, the datacube can grow by earned residues rather than by a premature cube constitution.
