# Research synthesis — 2026-05-22 pass LXXXIV

Pass LXXXIV studies the seam after search continuity: evidence release.

## External pressure

NIST Privacy Framework 1.1 pressure is broad but useful: privacy risk management must account for how data processing is governed, communicated, and controlled (`EXT-NIST-PRIVACY-FRAMEWORK-1-1-2026`). Ward should treat governance evidence release as a processing event with purpose, retention, and audience posture, not just a download.

W3C DPV sharpens vocabulary pressure. DPV represents purposes, processing operations, recipients, storage, technical and organizational measures, legal bases, and statuses (`EXT-W3C-DPV-2026`). Ward should not import DPV wholesale, but the shape supports a minimal recipient/purpose/processing/retention record for release receipts.

ODRL provides a useful but dangerous analogy: permissions, prohibitions, and duties can be attached to assets (`EXT-W3C-ODRL-MODEL-2-2`). Ward borrows the idea of travelling prohibitions and obligations, while refusing to let a release receipt become a rights-management grant.

OAuth Rich Authorization Requests show why flat scopes are not enough for high-consequence operations: structured authorization details can carry fine-grained resource/action context (`EXT-IETF-RFC-9396-RAR`). Ward similarly needs structured recipient, purpose, projection, and selection context for evidence release, rather than a single `export=true` flag.

NIST SP 800-53 AC-4 pressure is the information-flow lesson: controlling where information travels is different from simply knowing who can access it (`EXT-NIST-SP-800-53-REV5`). Ward's release receipt is therefore an information-flow guard over governance evidence, not a general identity or role check.

## Synthesis

Ward should add a **governance evidence-release receipt** downstream of search-continuity receipts.

The receipt must bind:

- source receipt id/path/digest;
- source query digest and projection-policy digest;
- selected rows/fields;
- recipient class;
- release purpose;
- redaction and minimization posture;
- sealed-omission disclosure mode;
- retention and refresh/revocation channel;
- no-authority watermark;
- forbidden-effect preservation.

## Design choice

The pass keeps release separate from authorization. A release receipt can prove that a projected evidence artifact was safely released or held. It cannot make the artifact usable for action, repair, export approval, privacy waiver, remedy, budget spend, delegation, or learning use.

## Fixture pressure

The checker validates four positive fixtures and sixteen negative fixtures. The strongest failures are:

- missing or mismatched source digest;
- public inline sealed evidence;
- exact public sealed counts;
- unbound recipient or missing purpose;
- query/projection-policy mismatch;
- weak-state upgrade to current authority;
- dropped forbidden effects;
- raw partner fragments in public release;
- missing no-authority watermark;
- high-consequence action performed during release;
- expired release treated as current;
- sealed omissions hidden.

## Remaining open pressure

Ward still needs future pressure around:

- cryptographic packaging or artifact signatures for released bundles;
- ViewFS trusted-path cards for released evidence;
- Schell retention/forgetting receipts for exported artifacts;
- recipient-side consumer receipts for partner/auditor handling;
- revocation notices for releases already downloaded or forwarded.
