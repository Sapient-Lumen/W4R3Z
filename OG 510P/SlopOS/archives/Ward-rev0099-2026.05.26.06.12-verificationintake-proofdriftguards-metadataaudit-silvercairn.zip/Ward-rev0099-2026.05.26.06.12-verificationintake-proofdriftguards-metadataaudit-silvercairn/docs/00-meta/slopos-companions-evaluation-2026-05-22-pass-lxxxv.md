# SlopOS companions evaluation — pass LXXXV

Pass LXXXV asks whether Ward's evidence-release chain can survive after it leaves the cube boundary.

## What changed

Ward now has `ward.governance.evidence-release-followup-receipt.v0`, a non-authority receipt over one prior evidence-release receipt. It can record:

- recipient acknowledgement;
- expiry or revocation;
- correction notice;
- stale-bundle quarantine;
- reuse refusal;
- refresh or recheck notice.

## Neighbor pressure

- **Schell** should retain the immutable release and the follow-up receipt separately, then apply retention/disposition to each.
- **ViewFS** should render status pointers and stale labels on trusted paths, not silently serve cached bundles.
- **Helm** should show “released, then revoked/corrected/quarantined” instead of overwriting the original release row.
- **Harbor** should refuse recompute/public-correction evidence that depends on a release with unresolved follow-up state.
- **SlopOS** should require follow-up recheck before using released governance evidence as supporting material for action, remedy, learning, budget, or export.

## Specimen outcome

The pass adds five positive fixtures and fourteen negative fixtures. The checker rejects source digest mismatch, release-state mismatch, missing recipient notice, missing no-authority label, acknowledgment-as-authority, expired-release-currentness, revocation without status pointer, public sensitive correction, exact hidden counts, dropped forbidden effects, high-consequence follow-up, channel mismatch, original-release mutation, and reuse-without-refresh.
