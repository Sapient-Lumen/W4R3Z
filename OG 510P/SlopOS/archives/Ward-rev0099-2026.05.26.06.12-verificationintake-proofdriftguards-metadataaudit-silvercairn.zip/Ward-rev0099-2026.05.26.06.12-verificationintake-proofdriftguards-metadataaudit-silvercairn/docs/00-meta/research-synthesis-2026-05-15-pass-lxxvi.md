# Research synthesis — pass LXXVI

Pass LXXV made the lifecycle of evidence visible: retained, transferred, reduced, or disposed artifacts no longer silently become current authority or total amnesia. Pass LXXVI follows the next human/system boundary: what happens when an affected party, reviewer, partner, regulator, model steward, or downstream operator says that a cube answer or its consequence is wrong?

The trap is familiar. A signed answer can become hard to challenge because it looks official. A review UI can become a rubber stamp because the evidence packet is opaque. A correction can be applied to the current dashboard while old exports, learning labels, action receipts, and partner copies keep circulating. A disputed cell can be over-frozen, blocking safe use of unrelated material. A reason statement can become a remedy even though no correction, withdrawal, notice, or downstream fence happened.

The new posture: Ward should let SlopOS datacube answers be contested, reviewed, and remedied without turning Ward into a court system, ticket tracker, compliance workflow, or global truth tribunal. Contestability is answer-adjacent residue. It improves accountability, but it does not by itself prove the challenger is right, the original answer is false, or the remedy has fully reached every derivative.

## What the past says we must learn now

1. **Reason-giving is the front door to challenge, not the end of challenge.** The DSA's statement-of-reasons system requires online platforms to provide clear and specific reasons for moderation restrictions and to submit statements of reasons to a public machine-readable database, while removing personal data from published entries (`EXT-EC-DSA-TRANSPARENCY-DB-2025`). Ward should steal the split between reason material, public scrutiny, and privacy filtering without importing a content-moderation database.

2. **An appeal lane needs independence, expertise, accessibility, and scope limits.** The European Commission's DSA dispute-settlement page says users can contest platform decisions through internal complaint handling and certified out-of-court bodies; certified bodies must be impartial/independent, have expertise, support accessible online submissions, operate under clear/fair public rules, and report on outcomes and resolution time (`EXT-EC-DSA-ODS-2026`). Ward should steal the attributes of a review lane, not the platform-law procedure.

3. **Dispute intake should not be defeated by preferred forms.** CFPB Circular 2022-07 states that consumer reporting agencies and furnishers must reasonably investigate eligible disputes even without their preferred format, intake forms, or documents (`EXT-CFPB-REASONABLE-INVESTIGATION-2022`). Ward should not let a cube challenge fail merely because the challenger lacks raw system logs or a perfect packet shape.

4. **Dispute scope needs admissibility and exceptions.** Regulation V's direct-dispute rule identifies categories of information furnishers must investigate and also names exceptions (`EXT-CFPB-DIRECT-DISPUTES-2026`). Ward should carry challenge scope, admissibility, and refusal grounds explicitly instead of treating every complaint as either fully accepted or ignored.

5. **Correction can coexist with disagreement documentation.** HHS's HIPAA correction guidance says people have a stake in health-information accuracy, can seek amendment while records are maintained, and if a request is denied can continue to dispute accuracy and have disagreement documented with later disclosures (`EXT-HHS-HIPAA-CORRECTION-2008`). Ward should steal the idea that an unresolved dispute can travel with later uses without pretending the record was changed.

6. **Independent review can be automatic after an adverse upheld decision.** CMS states that when a Medicare Advantage plan upholds an adverse organization determination, it must automatically submit the case file and decision to a Part C Independent Review Entity (`EXT-CMS-PART-C-IRE-2026`). Ward should steal automatic escalation triggers for high-consequence, adverse, or unresolved cube outcomes, not Medicare's domain-specific appeal ladder.

7. **Explanation rights are narrower than global transparency but still valuable.** The EU AI Act gives affected persons subject to certain high-risk AI-based decisions the right to clear and meaningful explanations of the AI system's role and main elements of the decision (`EXT-EU-AI-ACT-2024`). Ward should treat explanation, contest, adjudication, and remedy as different residues; none should swallow the others.

8. **Dispute outcome metrics are themselves cube material.** Appeal reversal rates, average time to resolve, upheld/overturned/withdrawn outcomes, and missing-evidence rates can become datacube metrics. They need the same cube hygiene: scope lenses, comparability passports, drift notices, quality witnesses, and privacy projection.

9. **Remedy reach is the hard part.** Correcting an answer cell is often easy compared with reaching old charts, emails, exports, verification bundles, action warrants, learning labels, model summaries, external counsel packets, partner clean-room outputs, and custody trails.

10. **A dispute is not a pause-all-world command.** Some contested material should be held, some marked disputed, some withdrawn from action, some still usable for unrelated aggregates, and some refused for lack of standing or scope. The cube needs intermediate states.

## Resulting Ward move

Do **not** decide yet:

- one complaint system, appeals UI, tribunal, case-management product, legal procedure, notification channel, or human-review staffing model;
- one global deadline, standing rule, evidence-admissibility rule, burden of proof, severity taxonomy, or escalation ladder;
- one universal remedy protocol, recall mechanism, compensation model, audit report, or downstream-notice transport;
- one rule that every contested answer freezes all related dashboards, or that every dispute automatically invalidates the original answer;
- one claim that a signed answer, replayable answer, retained evidence packet, or public reason statement is unchallengeable.

Do add three small, reversible residues:

- **contest packet** — a bounded challenge wrapper for one answer capsule, cell, export, action, consequence, learning label, model-mediated summary, scenario, or verification bundle. It names challenger/standing posture, challenged subject, grounds, requested remedy, submitted evidence, missing evidence, admissibility/refusal posture, privacy/projection limits, and interim effect. It answers “what exactly is being challenged and why?”
- **adjudication docket** — a review-process residue naming reviewer lane, independence/expertise posture, procedure/rules, evidence admitted/excluded, issue framing, standards applied, timeline, interim holds, conflicts, result, and unresolved questions. It answers “how was the challenge reviewed?” not “is this old answer current?”
- **remedy receipt** — a downstream-effect receipt for uphold, correct, amend, attach disagreement, withdraw, suppress, re-render, re-export, re-notify, rollback, compensate, fence, learn-exclude, or refuse-remedy outcomes. It records affected artifacts/cells/consequences, reach, residual gaps, notices, currentness impact, and non-erasure limits. It answers “what was done, where did it reach, and what remains?”

## Why these names and not stronger machinery

- “Contest packet” keeps challenge intake portable and bounded without inventing a tribunal.
- “Adjudication docket” gives reviewers a process/evidence spine without deciding whether review is human, delegated, independent, internal, regulator-facing, or automated-assist.
- “Remedy receipt” keeps fix/withdraw/notify/fence actions visible without pretending every downstream copy or learned label was recalled.

## Hygiene rule for SlopOS

A contested SlopOS datacube artifact is never stronger than the weakest of:

- the original answer capsule, scope lens, state-cut witness, and verification/lifecycle residues;
- the contest packet's standing, subject, grounds, and admissibility posture;
- the adjudication docket's review lane, evidence coverage, conflict, and outcome posture;
- the remedy receipt's reach across current cells, old exports, action warrants, learning labels, model summaries, scenario material, custody trails, and partner copies;
- the revocation, correction, privacy, projection, and retention fences still in force; and
- current rehydration when a downstream actor wants to use the old or remedied material for a fresh consequence.

## Specimen pressure that should come next

A provider disputes a SlopOS quarantine-score cell that drove a recommendation, was exported to counsel, entered a learning-label queue, and later appeared in an appeal-reversal dashboard. The answer path should not be: trust the old signature, throw away the old history, or freeze every related metric. It should be: open a contest packet, build an adjudication docket with bounded evidence and reviewer scope, emit remedy receipts for correction/withdrawal/disagreement/notice decisions, fence derivative artifacts whose reach is incomplete, and rehydrate current authority before any continuing action.
