# Research synthesis — pass XXXV

This pass keeps Ward cautious and learns one more thing from mature transparency/update/trust systems: **one observer report, one corroboration set, and one local quorum rule are different truths.**

## Outside lessons
1. **TUF separates one signature from a trusted threshold.**  
   The current TUF specification says all roles can use one or more keys and require a threshold of signatures before metadata is trusted. It also says a single-key configuration is possible but insecure. Ward should steal the restraint: “signed” and “trusted enough here” are different claims.

2. **SCITT keeps one statement and multiple independent receipts separate.**  
   The current SCITT architecture draft says the same Signed Statement may be independently registered in multiple Transparency Services, producing multiple, independent Receipts. Ward should learn that one issuer statement and plural corroborating registrations are neighboring but non-identical facts.

3. **Sigsum makes acceptance depend on enough witness cosignatures, not only on one log signature.**  
   Sigsum’s design says an end-user should only accept distributed data if the tree head is from a known log with enough valid cosignatures, and it says the difficulty of bypassing public logging depends on controlling enough independent witnesses. Ward should steal two ideas: raw count is smaller than independence, and acceptance thresholds belong to the local trust policy.

4. **Merkle Tree Certificates keeps relying-party requirements explicit.**  
   The current Merkle Tree Certificates draft says relying parties are configured with trusted cosigners, and the CA requests sufficient checkpoint cosignatures to meet relying party requirements. It also keeps monitors visible. Ward should learn that plural corroboration still needs a local rule about *which* corroborators count and *how many* are enough.

## Resulting Ward move
Do not decide yet whether Ward’s long-term datacube should speak in witness registries, notary bundles, quorum certificates, committee proofs, or policy-side trust lists.

For now, preserve four separations and let later specimens force promotion:
- `observer report` versus a fused “everyone agrees” blob;
- `corroboration set` versus one raw signature or receipt;
- `witness cohort` versus a naked count of signatures;
- `local quorum rule` versus the corroboration material itself.

Keep nearby, but not yet promoted, a few smaller ideas:
- `same-cut requirement` for corroboration that only counts together when it refers to the same underlying cut/checkpoint/subtree;
- `quorum shortfall` for “real corroboration exists, but not enough for this action here”;
- `monitor visibility` for the fact that thresholds are stronger when third parties can still inspect what was certified;
- `count weaker than independence` as a standing anti-regrowth rule.

## Fresh ideas worth stealing
- **observer report** — one actor’s statement that it saw, checked, or registered one trust-relevant thing.
- **corroboration set** — grouped receipts/cosignatures/registrations over the same cut or claim.
- **witness cohort** — the independence class or trust grouping the corroborators belong to.
- **local quorum rule** — the local policy that says what corroboration is enough for one action.
- **same-cut requirement** — rule that corroboration only counts together when it speaks about the same underlying cut.
- **quorum shortfall** — visible residue that some corroboration exists but not enough for this consequence.
- **monitor visibility** — reminder that corroboration without auditability can still be brittle.
- **count weaker than independence** — a standing anti-regrowth rule.
