# Research synthesis — pass LII

This pass keeps Ward decision-light and adds another datacube discipline: **calendar semantics are part of result meaning, not just display formatting.**

## What the past says we must learn
1. **Civil truncation is not neutral.**  
   BigQuery's `TIMESTAMP_TRUNC` docs say truncation to `MINUTE` or `HOUR` works by determining the civil time in the specified or default time zone and warn that the result is **non-intuitive near daylight savings transitions that aren't hour-aligned**. Ward should steal the constitutional lesson: if a recurring trust surface is grouped in local civil time, the bucket rule belongs to the truth contract rather than hidden engine folklore (`EXT-BIGQUERY-TIMESTAMP-FUNCTIONS-2026`).

2. **“Week” is not one thing.**  
   BigQuery's date docs distinguish `WEEK` (Sunday-first, with dates before the first Sunday in week 0), `WEEK(<WEEKDAY>)`, `ISOWEEK` (Monday-first), and `ISOYEAR`. Ward should steal the humility: a weekly trust question can change meaning when the calendar family or week-start rule changes, even if the query title stays the same (`EXT-BIGQUERY-DATE-FUNCTIONS-2026`).

3. **Bucket grids are anchored, not universal.**  
   DuckDB's `time_bucket` docs say the grid is anchored at default origins that differ by bucket width and can instead be anchored by an explicit `origin` or `timezone`. Druid's `TIME_FLOOR` and `TIME_CEIL` docs likewise expose explicit `origin` and `timezone` parameters. Ward should borrow the discipline: bucket origin/alignment belongs in the contract when a promoted recurring question depends on it (`EXT-DUCKDB-TIMESTAMPTZ-2026`, `EXT-DRUID-SQL-SCALAR-TIME-2026`).

4. **Local-calendar buckets can have irregular real duration.**  
   Tiger Data's `time_bucket` docs say buckets align to midnight in UTC by default, can be realigned to midnight in a chosen time zone, and warn that daylight-savings shifts can make the amount of data in a bucket irregular. Ward should steal that as an honesty rule: a civil bucket is sometimes not a fixed-duration interval, so regrouped comparisons need the calendar semantics attached (`EXT-TIGERDATA-TIME-BUCKET-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal time zone, one default week-start rule, one canonical ISO-versus-Gregorian calendar policy, or one mandatory time spine.

For now, keep three more separations visible and let later specimens force promotion:
- **calendar binding** — explicit calendar family, week-start rule, bucket width, and bucket origin/alignment for one recurring surface.
- **timezone witness** — visible statement of which time zone or civil-time assumption the result actually used.
- **boundary drift alarm** — visible residue that the same recipe or contract reran under a different calendar binding or crossed a boundary where bucket membership changed materially.

## Why these separations are worth stealing
- A `calendar binding` stops one friendly “daily” or “weekly” title from borrowing authority across incompatible bucket rules.
- A `timezone witness` keeps UTC, local civil time, and viewer-local rendering from silently impersonating each other.
- A `boundary drift alarm` keeps fact drift distinct from bucket-rule drift when the same events fall into different days, weeks, or months after a calendar change.

## Brilliant ideas to steal now
- **calendar binding** — explicit calendrical contract for promoted recurring questions.
- **timezone witness** — compact statement of the civil-time assumption actually used.
- **boundary drift alarm** — visible warning when bucket membership changed because the calendrical contract moved.
- **no silent week rule** — standing anti-regrowth rule.
- **calendar semantics weaker than fact truth** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward ever blesses one default time zone for cross-team surfaces or keeps every recurring question explicitly bound.
- Whether `calendar binding` should always carry ISO-versus-Gregorian distinctions or only when week/year boundaries matter.
- Whether `boundary drift alarm` is only a header/review concern or later becomes typed durable residue.
- Whether some repeated questions should permanently stay event-time/raw-cut only rather than earning civil-calendar grouping at all.
