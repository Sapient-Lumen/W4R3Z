# Research synthesis — pass XXXI

This pass keeps Ward cautious and learns one more thing from versioned data systems and source-control-like history engines: **immutable published cuts, moving aliases, reader pins, and retention promises are different truths.**

## Outside lessons
1. **Human-friendly “latest” names should move without pretending the underlying cut moved in place.**  
   Git keeps immutable content-addressed history and then uses refs and symbolic refs as named pointers. A ref names an interesting point in history; a symbolic ref such as `HEAD` points at another ref rather than impersonating the underlying object. Ward should steal that restraint: one friendly handle that means “current here” should stay visibly weaker than the durable cut it currently names.

2. **Alias movement deserves its own visible trail.**  
   Git reflogs record when the tips of branches and other refs moved, including older values such as `HEAD@{2}` or `master@{one.week.ago}`. Ward should steal the idea without freezing the carrier: if a later local result moves a named pointer, the move itself is residue worth keeping smaller than the cut and smaller than the final consequence.

3. **Pinned reads and moving aliases are different contracts.**  
   Iceberg snapshot references separate mutable branches from tags and from concrete snapshot IDs. Readers can read from a branch/tag by name, while fast-forwarding and replacing references remain explicit operations. Delta Lake makes the same pressure visible differently: jobs that need stable answers should pin to a specific version, because a “latest” read can change between invocations. Ward should steal the humility: a consumer pin deserves its own noun instead of being hidden inside a moving alias.

4. **Historical readability is governed by retention, not by nostalgia.**  
   Iceberg retention policies determine which snapshots and refs survive expiration. Delta time travel requires both log and data retention, and `VACUUM`/retention settings bound how far back reads remain available. lakeFS pushes the same lesson harder: old commits may still exist even after underlying objects have been garbage-collected, which yields `410 Gone` instead of magical resurrection. Ward should steal the sharper consequence: historical addressability and historical readability are not the same thing.

5. **Annotations can remain adjacent instead of mutating the base cut.**  
   Git notes show a brilliant smaller move even if Ward should not standardize it yet: attach commentary to an object without rewriting the object. Ward should keep that nearby as a future implementation trick for local remarks, appraisals, or handoff hints that should not re-author the trusted cut itself.

## Resulting Ward move
Do not decide yet whether Ward’s long-term cut/alias/pin surface is git-shaped, snapshot-table-shaped, log-offset-shaped, digest-shaped, or some other carrier.

For now, preserve four separations and let later specimens force promotion:
- `published cut` versus a moving “latest/current/preferred” handle;
- `moving alias` versus one immutable cut identifier;
- `reader pin` versus ambient reading from whatever the alias names now;
- `retention floor` versus naive assumptions that historical names remain physically readable forever.

## Fresh ideas worth stealing
- **published cut** — immutable trust-relevant cut addressable without asking what “latest” means today.
- **moving alias** — named pointer that may advance while staying weaker than the cut it names.
- **reader pin** — consumer-local fixation on one specific cut for stable evaluation or replay.
- **retention floor** — explicit promise about how long pinned or historical cuts remain physically readable.
- **alias trail** — compact history of where a moving alias used to point.
- **adjacent note** — commentary attached beside a cut without rewriting the cut.
- **latest weaker than pinned** — a standing anti-regrowth rule.
