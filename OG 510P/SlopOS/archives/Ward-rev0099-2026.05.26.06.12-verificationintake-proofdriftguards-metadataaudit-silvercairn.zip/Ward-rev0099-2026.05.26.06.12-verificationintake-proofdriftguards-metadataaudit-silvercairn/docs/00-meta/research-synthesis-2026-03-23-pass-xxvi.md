# Research synthesis — pass XXVI

This pass keeps Ward cautious and learns one more thing from attestation, provenance, and policy-driven verification systems: **evidence, the interpretation recipe, the normalized appraisal result, and the local consequence are different truths, and replay under a new recipe should not erase history.**

## Outside lessons
1. **RATS keeps two different appraisal policies explicit.**  
   RFC 9334 defines an **Appraisal Policy for Evidence** used by the Verifier and a separate **Appraisal Policy for Attestation Results** used by the Relying Party. Ward should therefore resist any design that treats “verification policy” as one ambient invisible thing.

2. **EAR makes the frame of reference part of the result.**  
   The current EAR draft says a verifier should publicly and permanently document its labelling scheme, carries appraisal-policy identifiers, and warns that relying only on the overall status loses quality compared with keeping the trustworthiness breakdown. Ward should steal that humility: a normalized result is only honest when the recipe behind it stays reconstructible.

3. **SLSA says provenance is incomplete without an interpretation method.**  
   The SLSA guidance explicitly says that when you create provenance, you must supply users a method for interpreting what you created. Ward should keep this lesson close: witness material alone is weaker than it first appears.

4. **in-toto treats the verification recipe as a real artifact.**  
   in-toto layouts name authorized functionaries, material/product rules, and inspections that run commands during verification. Ward should therefore preserve the idea that trust meaning can depend on a concrete evaluation recipe rather than on prose memory.

5. **Sigstore policy surfaces make trust roots and local policy explicit.**  
   Sigstore’s policy-controller validates signatures and attestations, applies multiple policies, supports custom trust roots, and resolves tags so the admitted image is the one actually run. Ward should learn from that: the same witness material can legitimately yield different local results when the trust root set, policy stack, or subject-resolution rule changes.

## Resulting Ward move
Do not decide yet whether Ward’s long-term appraisal recipe is embedded in a result object, carried next to it, or only referenced by identifier.

For now, preserve four separations and let later specimens force promotion:
- `appraisal recipe` versus the raw evidence or witness bundle;
- `label scheme handle` and result breakdown versus one summary status tier;
- `policy epoch` versus the local action taken from a result;
- `replay delta` versus historical erasure or “the old result was never real”.

## Fresh ideas worth stealing
- **appraisal recipe** — compact descriptor of trust roots, comparison rules, normalization, and verification steps used for one result.
- **label scheme handle** — stable pointer to the documented meaning behind normalized result labels.
- **policy epoch** — version/generation of the recipe in force when a result was minted.
- **replay delta** — structured residue describing how a later re-evaluation differs from an earlier one.
- **frame-of-reference card** — grouped hint about verifier identity, recipe, and active policy epoch without pretending to be final consequence.
