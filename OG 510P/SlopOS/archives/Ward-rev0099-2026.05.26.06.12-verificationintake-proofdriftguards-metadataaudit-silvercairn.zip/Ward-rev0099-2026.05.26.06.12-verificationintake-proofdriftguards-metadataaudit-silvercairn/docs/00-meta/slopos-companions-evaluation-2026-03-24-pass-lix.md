# SlopOS / companions evaluation — pass LIX

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **resolution and tier belong to result meaning, so raw, retained-summary, hybrid, and display-rollup answers should not share one flattering recurring title by default.**

## What the included cubes keep teaching
- **SlopOS** remains the strongest nearby teacher because D-ATTRFS keeps query view-scoped, snapshot-first, and handle-returning. The datacube analogue is that a saved query recipe can stay the same while the returned answer crosses from raw replay into a retained summary or hybrid serving lane. Ward should keep that change visible instead of pretending snapshot-first means fidelity-first.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: handle set, preview surface, frozen manifest, and durable receipt are different truths. The datacube analogue is that raw result, downsampled retained surface, and hybrid materialized-plus-raw answer should likewise stay visibly distinct.
- **Steward** and **Foundry** keep pressuring Ward toward honest seam markers rather than giant flattening objects. The datacube analogue is that resolution/tier shift should show up as compact residue instead of silently changing what one recurring chart title means.

## What outside systems add to the datacube posture
- Prometheus adds the first discipline: range queries explicitly carry `step`, which means returned points are already a resolution-shaped derivative rather than ambient raw history. Ward should steal that as **resolution binding** honesty, not as a commitment to Prometheus (`EXT-PROMETHEUS-QUERY-API-2026`).
- Datadog adds the second discipline: graphs auto-roll up to respect a point limit, defaulting to `avg`, and `.rollup()` can explicitly choose another interval and aggregation. Ward should steal that as **display rollup is weaker than raw replay** honesty, not as a commitment to Datadog (`EXT-DATADOG-ROLLUP-2026`).
- Thanos adds the third discipline: source resolution can be forced to raw or selected from downsampled tiers, and long-term retention/downsampling policy determines which fidelities still exist. Ward should steal that as **tier witness** discipline, not as a commitment to Thanos (`EXT-THANOS-QUERY-2026`, `EXT-THANOS-COMPACTOR-2026`).
- Tiger Data adds the fourth discipline: continuous aggregates can outlive raw data, and real-time aggregates explicitly stitch materialized history with fresher raw data while remaining eventually consistent for some historical changes. Ward should steal that as **hybrid seam** honesty, not as a commitment to Timescale/Tiger Data (`EXT-TIGERDATA-RETENTION-CAGG-2026`, `EXT-TIGERDATA-REALTIME-AGG-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Any promoted recurring range answer should declare resolution binding before it borrows the title of the underlying repeated question.**
2. **Any promoted answer that may come from raw, downsampled, materialized, or display-rollup lanes should declare tier witness so replay-grade and browse-grade truths stay visibly different.**
3. **Any promoted answer that stitches materialized history with fresher raw data, or combines different retained fidelities, should declare a hybrid seam instead of posing as one homogeneous source.**
4. **Ward should not bless one universal downsampling engine, one raw-retention ladder, one hybrid-materialization policy, or one display-rollup doctrine while SlopOS and its siblings are still settling their own query/result/materialization seams.**
5. **If Ward later imports answers from different systems, it should treat step drift, source-resolution drift, tier drift, and hybrid-stitch drift as semantic drift until proven comparable.**

## Specific anti-lessons from the past
- Do **not** let raw and downsampled answers share one recurring title without visible fidelity residue.
- Do **not** let renderer-imposed rollups impersonate replayable source truth.
- Do **not** let hybrid materialized-plus-raw answers masquerade as one homogeneous source.
- Do **not** let retention policy quietly decide whether replay is still possible without surfacing that boundary.
- Do **not** compare retained summaries and raw reruns as though only time range changed.

## What Ward should probably steal next
- a **resolution binding** attached to any promoted range answer that depends on query step, source-resolution cap, or another declared fidelity width;
- a **tier witness** attached to any promoted answer that comes from raw replay, retained summary, materialized derivative, display rollup, or another declared serving tier;
- a **hybrid seam** attached to any promoted answer that stitches materialized history with fresher raw data or crosses retained-resolution tiers;
- a standing rule that **resolution-shaped or tier-shaped answers are weaker than raw replay unless the fidelity residue stays inspectable**.
