# SlopOS / companions evaluation — pass LV

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **distribution surfaces can be very useful, but their bucket family and percentile derivation must stay visible.**

## What the included cubes keep teaching
- **SlopOS** remains the strongest nearby teacher because D-ATTRFS keeps query bytes modest and explicit: view-scoped, snapshot-first, handle-returning, and shell-owned when persistence appears. Ward should steal the next lesson in the same spirit: if SlopOS later offers recurring distribution-style browse surfaces, the bucket family and percentile derivation should live in the recipe/result contract rather than in one ambient chart default.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: query manifest, snapshot result, live feed, and materialized local collection are distinct. The datacube analogue is that raw population, bucketed derivative, and interpolated percentile should also remain distinct even when they share a title.
- **Helm** keeps pressuring UI honesty. If a shell shows “p95 attestation age” or “tail of stale local receipts,” the header should be able to say basis pin + exactness class + bucket schema + boundary witness + interpolation posture without forcing a giant semantic layer.
- **Steward** keeps teaching that local consequence is narrower than remote operation folklore. The datacube analogue is that a percentile or histogram can help humans explore and compare, but should stay weaker than any replayable exact frozen result for spend-grade truth.

## What outside systems add to the datacube posture
- Prometheus adds the first discipline: bucket boundaries shape the error you buy, histograms aggregate while summaries do not always do so safely, and histogram quantiles are interpolated within buckets. Ward should steal that as **bucket schema** plus **interpolation posture** honesty, not as a commitment to Prometheus (`EXT-PROMETHEUS-HISTOGRAMS-2026`).
- OpenTelemetry adds the second discipline: histogram bucket inclusivity is explicit, ExponentialHistogram scale controls resolution, and perfect subsetting lets consumers downscale without introducing error. Ward should steal that as **boundary witness** plus optional **perfect subsetting** posture, not as a commitment to OpenTelemetry (`EXT-OTEL-METRICS-DATA-MODEL-2026`).
- Prometheus native histograms add the third discipline: custom buckets have upper-inclusive boundaries, the first bucket starts from `-Inf`, and values above the final boundary go into an explicit overflow bucket. Ward should steal that as **overflow posture** honesty, not as a commitment to one histogram wire format (`EXT-PROMETHEUS-NATIVE-HISTOGRAMS-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Any promoted recurring distribution surface should declare a bucket schema before it borrows the title of a raw repeated question.**
2. **Any promoted percentile or tail answer should declare its interpolation posture so exact replay, bucket interpolation, and sketch estimation cannot impersonate one another.**
3. **Any promoted histogram-style derivative should declare a boundary witness so overflow, zero-bucket, and inclusivity semantics remain inspectable.**
4. **Ward should not bless one universal explicit-bucket grid, one exponential-histogram family, or one percentile publication grammar while SlopOS and its siblings are still discovering their own query/result/materialization seams.**
5. **If Ward later adopts downscale-friendly distribution derivatives, it should prefer explicit perfect-subsetting claims over hand-wavy “compatible enough” folklore.**

## Specific anti-lessons from the past
- Do **not** let two p95 numbers share one title when their bucket schema changed.
- Do **not** let overflow buckets quietly hide the tail of the distribution.
- Do **not** let cumulative/upper-inclusive bucket semantics disappear into renderer defaults.
- Do **not** let bucket-interpolated percentiles pose as exact replayable percentiles.
- Do **not** choose one cube-wide histogram/percentile constitution just because a few recurring distribution questions look attractive.

## What Ward should probably steal next
- a **bucket schema** attached to any promoted distribution surface that starts influencing decisions;
- a **boundary witness** attached to any bucketed derivative whose overflow or inclusivity semantics matter;
- an **interpolation posture** attached to any percentile or tail answer that is not exact replay;
- and maybe, later, **perfect subsetting** where downscaling without extra error really buys something.
