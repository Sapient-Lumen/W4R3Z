# SlopOS / companions evaluation — pass LI

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **a repeated trust question should not be treated as the same surface when its authorized population changes.**

## What the included cubes keep teaching
- **SlopOS** is still the strongest nearby teacher because D-ATTRFS keeps querying modest: query mode runs against an explicit **authorized view**, results are **handles already reachable through that view**, querying stays **snapshot-first**, and saved queries remain **shell-owned manifests**. Ward should copy the constitutional lesson: the query bytes are not the whole meaning; the view binding matters too.
- **ViewFS** sharpens the neighboring seam Ward needs: a query manifest is a recipe, evaluation is scoped to a concrete view/lens, and snapshot-first results remain smaller than any ambient live global search story. The datacube analogue is that a recurring question should carry a visible scope lane rather than pretending one query text names one universal population.
- **Steward** keeps teaching that shell state and live authority should stay explicit and host-scoped. The analogous datacube lesson is that a result should remain visibly bound to the scope and authority lane that produced it.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows one team-facing metric card or dashboard tile, the shell should be able to say which authorized population that number actually covers before anyone compares it with another team's number.

## What outside systems add to the datacube posture
- BigQuery authorized views teach the first discipline: a query result can be intentionally shared without exposing the underlying source data, and the view can hide columns. Ward should steal that as **view binding** honesty, not as a commitment to BigQuery (`EXT-BIGQUERY-AUTHORIZED-VIEWS-2026`).
- BigQuery row-level security adds the second discipline: authorized views, row-level policies, and separate tables are different security/performance/convenience choices. Ward should steal that as **population witness** and **scope drift** discipline, not as a commitment to one RLS stack (`EXT-BIGQUERY-RLS-INTRO-2026`).
- Looker adds the third discipline: `access_filter` is user-specific and Explore-specific. Ward should steal that as **surface-local scope binding** rather than ambient workbook folklore (`EXT-LOOKER-ACCESS-FILTER-2026`).
- dbt adds the fourth discipline: semantic-layer requests ride credentials, and the access policies tied to those credentials are respected for every request. Ward should steal that as **credential-lane scope honesty**, not as a commitment to dbt's APIs or hosting posture (`EXT-DBT-SL-PERMISSIONS-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Every promoted recurring question should declare a view binding or equivalent authorized scope lane before it earns dashboard authority.**
2. **Every published answer should be able to emit a population witness that says what rows/fields/population it actually covered.**
3. **A rerun under a different authorized view, credential lane, or access policy should raise a scope drift alarm instead of pretending facts changed and scope stayed constant.**
4. **Ward should not let a query contract or metric card silently outrank the scope that made the answer visible.**
5. **Ward should not bless one giant row-security or visibility constitution while SlopOS and its siblings are still discovering their shell-owned manifest, view binding, and snapshot/live seams.**

## Specific anti-lessons from the past
- Do **not** treat query text alone as the whole meaning of a published recurring question.
- Do **not** compare numbers across teams or views as if different authorized populations were just cosmetic filters.
- Do **not** let a broader credential lane silently widen a promoted derivative without a visible drift header.
- Do **not** assume field redaction and row restriction are the same thing.
- Do **not** choose one universal access-control DSL, view schema, or sharing constitution just because a few recurring questions are emerging.

## What Ward should probably steal next
- a **view binding** attached to any recurring surface that starts influencing decisions;
- a **population witness** that can say whether rows, fields, or both were filtered by the scope lane;
- a **scope drift alarm** whenever the same recipe reruns under a different authorized slice or credential lane;
- UI headers that can say **basis pin + view binding + population witness + exactness class** together when relevant;
- hygiene that refuses to let new scope/security sources drift out of the bibliography, source register, queue, front door, or manifest.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new authorized-view, row-security, and access-scope sources that are now directly shaping datacube posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- refresh the ledgers/context surfaces so the new scope-bound question shows up in the open-question and pressure queue;
- rerun the repo hygiene checks after the source-register and front-door refresh.

## Still-not-yet decisions
- engine choice;
- one canonical row-level-security grammar;
- one mandatory machine-readable view-binding schema;
- one rule about whether field-redacted and row-restricted populations must use separate witness fields;
- one policy saying every future metric card must already be globally shareable across differently scoped audiences.
