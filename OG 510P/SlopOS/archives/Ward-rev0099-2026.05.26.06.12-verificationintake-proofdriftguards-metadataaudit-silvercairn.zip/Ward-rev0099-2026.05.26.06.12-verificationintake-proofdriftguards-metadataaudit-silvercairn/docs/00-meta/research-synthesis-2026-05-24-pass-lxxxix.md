# Research synthesis — pass LXXXIX

Pass LXXXIX focused on the problem Ward left open after dispute resolution: cached recovered heads can remain locally useful after their source resolution has become stale, superseded, quarantined, or projection-incompatible.

## External pressure

- `EXT-NIST-SP-800-53-REV5` keeps continuous monitoring and information-flow discipline separate from a one-time authorization story. Ward borrows the cadence pressure, not the whole control catalog.
- `EXT-OPENID-SSF-2025` and `EXT-OPENID-CAEP-2025` reinforce transmitter/receiver humility: a signal updates receiver posture, but the receiver still applies local policy and cannot pretend notification equals authority.
- `EXT-RFC-8417`, `EXT-RFC-8935`, and `EXT-RFC-8936` keep event identity, duplicate delivery, push acknowledgement, poll order, and receiver-local application separate. Ward turns that into cache-subject digest, status-channel recheck, recipient-refresh recheck, and stale-consumer notification.
- `EXT-RFC-7009` keeps revocation scoped and post-issuance. Ward translates that into invalidated cached resolutions, refresh signals, and no-source-mutation posture.

## Design conclusion

Do not mutate dispute-resolution receipts. Add a downstream recertification receipt that asks: “Is this cached resolution still current enough to display as a status pointer, or must it be invalidated, quarantined, downgraded to history, or rechecked?”

The answer is still non-authority. Even a recertified current cache requires source-packet replay before any consequence.

## New executable pressure

The pass adds five positive fixtures and nineteen negative fixtures around cached current heads, invalidation after status signals, restricted successor recertification, historical-only cache posture, quarantine sustainment, digest drift, missed signals, public leakage, purpose drift, missing next-recheck windows, and forbidden-effect preservation.
