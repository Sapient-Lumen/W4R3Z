# Research synthesis — pass XXXVIII

This pass adds one more design-pressure seam without freezing Ward into a specific queue, table, controller, or log shape: **what was asked for**, **what the reconciler has actually observed**, **what compact conditions summarize right now**, and **what is marked for teardown but not gone yet** are different truths.

## What the outside systems say
1. **Kubernetes keeps desired state and current state separate on purpose.**  
   The API conventions say `spec` is the complete desired state, `status` summarizes the current state, and the system works to bring status into line with the most recent spec over time. The same conventions explicitly say the behavior is **level-based rather than edge-based**, so the system is not required to “touch base” at every intermediate desired value. Ward should steal that humility: a later local result should not pretend that every requested intermediate step was ever real here.

2. **Status needs its own authority lane and its own stale-check clue.**  
   Kubernetes says writes to `status` must go through a `/status` subresource and that `spec` and `status` usually deserve distinct authorization scopes. The same conventions define `observedGeneration` and warn that a condition can be out of date with respect to the current instance when its observed generation trails the object generation. Ward should steal two ideas: status authorship is its own lane, and compact status summaries need a visible clue about which desired revision they actually reflect.

3. **Condition sets are summaries, not the whole truth.**  
   The API conventions say conditions are a standard higher-level summary mechanism, should be treated as a map keyed by `type`, may be `True` / `False` / `Unknown`, and should complement rather than replace more detailed status. Ward should steal the restraint: compact condition cards are useful, but they stay smaller than the full observed state and smaller than local consequence.

4. **Even “observed generation” can be nuanced.**  
   Current Kubernetes Pod docs go further: some status fields correspond to the current generation, while others reflect the previous sync loop because they are indirect results of running the old spec. Ward should steal that subtlety too. “Observed generation N” is not one magic freshness badge for every field unless the cube preserves which surfaces are direct acknowledgements and which are lagging runtime effects.

5. **Deletion requested is not deletion complete.**  
   Kubernetes finalizers make this explicit: a delete request sets `metadata.deletionTimestamp`, the API returns `202 Accepted`, and the object remains in a terminating state until finalizers are removed. Ward should steal that shape wholesale. A teardown request, a teardown-in-progress marker, and actual absence are not the same truth.

6. **Asynchronous allocation/results belong on the observed side unless they are synchronously confirmed.**  
   The API conventions are blunt that user-supplied allocated values in `spec` are often unsafe unless they can be validated synchronously; many asynchronously determined results are safer in `status` or even a different type. Ward should steal the habit without overcommitting the datacube: do not let requested/desired fields impersonate confirmed allocation, attachment, or effect.

## Resulting Ward move
Do **not** decide yet whether Ward should literally adopt a Kubernetes-like `spec`/`status` split, a request/result pair, a plan/observation pair, or separate sidecar objects.

For now, preserve four separations and let later specimens force promotion:
- `desired state` versus the false comfort of “already applied”;
- `observed generation` versus a stale compact summary;
- `condition set` versus the full observed state or local verdict;
- `teardown gate` versus simple deletion/absence.

Keep nearby, but not yet promoted, a few smaller ideas:
- `level-based target` for “drive to latest desired, skip fake intermediate history”;
- `status authority lane` for who is allowed to summarize observed reality;
- `allocation acknowledgement` for asynchronously confirmed results that should not live in request fields; and
- `terminating-not-gone` as a standing anti-regrowth rule.

## Fresh ideas worth stealing
- **desired state** — persisted requested target smaller than current reality.
- **observed generation** — which desired revision a compact observed summary actually reflects.
- **condition set** — concise, typed summary lane smaller than full status and smaller than verdict.
- **teardown gate** — explicit in-progress cleanup barrier between deletion request and absence.
- **level-based target** — latest desired state without fake intermediate milestones.
- **status authority lane** — separate writer/auth scope for observed summaries.
- **allocation acknowledgement** — asynchronously confirmed allocation/result kept weaker than request intent.
- **terminating-not-gone** — a standing anti-regrowth rule.
