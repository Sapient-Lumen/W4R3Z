# SlopOS and companion evaluation — pass LXXII

Pass LXXII evaluates Ward's emerging datacube posture against scenario pressure: forecast, simulation, synthetic data, stress test, imputation, and counterfactual answers. The key question is not “which scenario engine should SlopOS use?” The question is whether a SlopOS-facing answer can remain honest when a user asks for a world that is useful but not observed.

## SlopOS fit

SlopOS is still design-phase, which is exactly why Ward should avoid picking a scenario substrate. The included SlopOS snapshot already contains several adjacent lessons:

- **D-CAPSHELL learn-mode is observational only.** Learn-mode reports cannot auto-widen authority or rewrite contracts. Scenario capsules should inherit that spirit: a scenario may report, suggest, or prepare review, but it does not edit policy, lower thresholds, or authorize action by existing.
- **D-NONDET rejects ambient time/entropy.** Forecasts and simulations frequently depend on time, seeds, stochastic samples, and random scenario perturbations. Ward should route those through scenario capsule metadata rather than assuming host clocks or random state are harmless.
- **CH-ACPOUT is non-authoritative.** A scenario that says “would have accepted/rejected” is not an ACP outcome receipt and must not be replayed as one. A counterfactual warrant can help review, but current ACP authority still needs live validation.
- **Budget/payer posture is explicit.** Large simulation or synthetic generation jobs should be budget-gated and sponsor-scoped, not smuggled into ordinary query refresh.
- **Snapshot/view discipline matters.** A scenario must name the observed cut it perturbs. It must not call itself a SlopOS answer if it quietly mixes current source state, backfilled corrections, model parameters, and generated rows.

## Companion pressure

- **Helm** will be tempted to render scenario charts, forecast confidence bands, what-if sliders, and agent summaries. Pass LXXII says Helm can display them only through render contracts and egress receipts that keep scenario class visible.
- **Foundry** pushes semantic spines, serving lanes, and pinned cuts. Scenario capsules should pin concept anchors and hierarchy cuts before generating synthetic members or forecasting over semantic buckets.
- **Harbor** pushes temporal witnesses, contract subsets, and lineage guards. It is the strongest reminder that a scenario answer must say which time axis is observed, forecasted, effective, learned, or merely assumed.
- **Steward** pushes cause/condition and bootstrap reconciliation pressure. Counterfactual warrants should not smuggle cause into Ward when the evidence only supports condition, eligibility, or replay comparison.
- **Schell** pushes basis cards, activation receipts, and environment epochs. Scenario runs around rollout, activation, and environment change need an explicit baseline and activation cut, not current environment folklore.
- **ViewFS** pushes preview/export/display alias risks. Synthetic or forecast exports are new artifacts; ViewFS-like surfaces should not naturalize generated rows through copy, save, folder placement, or familiar names.

## What Ward should absorb

1. **Scenario class belongs near answer authority.** A scenario answer can be exact with respect to its model and still non-observed with respect to the world.
2. **Backtesting belongs near the forecast, not in an appendix.** Cutoff, horizon, metric, leakage caveat, calibration, and scored historical runs must be answer residue when consequence is possible.
3. **Counterfactuals need warrants.** If a user asks “what would have happened,” Ward needs an explicit identified/simulated/refused posture.
4. **Synthetic boundaries travel.** Generated rows, synthetic exemplars, imputed labels, and simulated incidents must keep marks through join, rollup, export, training, and review.
5. **Scenario-to-action remains gated.** A scenario can create a review task or recompute docket, but a threshold witness and action warrant are still required before notification, quarantine, ACP proposal, feature flag, or workflow execution.

## What Ward should not absorb yet

- No SlopOS-wide scenario store, model registry, simulation DSL, causal graph format, synthetic data generator, or random-number API.
- No default confidence interval, backtest metric, privacy threshold, calibration test, or causal-identification schema.
- No rule that forecasts, synthetic stress tests, or counterfactual estimates can become action warrants by score alone.
- No global rule that scenario material can or cannot be used for learning. Learning-loop ledgers and feedback taint fences decide that later.
- No universal UI grammar for forecast bands, synthetic rows, or counterfactual badges.

## Evaluation verdict

Promote **scenario capsule**, **counterfactual warrant**, and **synthetic boundary** only as candidate datacube residues, not as stable schemas. They improve Ward because they preserve a high-value design-phase distinction: the cube may answer questions about possible worlds without allowing possible worlds to become observed authority.

## Immediate review checklist

Before a SlopOS-facing scenario answer is allowed into any consequence-grade path, verify that:

- the observed answer capsule and source/state cuts are named;
- forecast horizon/cutoff/backtest posture is present for prediction-like claims;
- a counterfactual warrant exists or the causal claim is refused/downgraded;
- synthetic/generated/imputed rows or cells carry a synthetic boundary;
- randomness/time/parameter choices are recorded enough for review;
- render/export/agent surfaces preserve scenario class;
- action warrants and learning loop ledgers remain separate from the scenario output.
