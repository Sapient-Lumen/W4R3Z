# SlopOS / companions evaluation — pass LVIII

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **query/result meaning gets weaker when privacy-shaped releases borrow the authority of replayable exact results.**

## What the included cubes keep teaching
- **SlopOS** remains the strongest nearby teacher because D-ATTRFS already says query should be view-scoped, snapshot-first, and handle-returning, with saved queries staying shell-owned manifests. The datacube analogue is that one saved query recipe can legitimately have several publishable result classes: exact in one internal view, thresholded in one collaboration view, and noisy in another. The privacy difference is therefore not just auth plumbing; it is part of result meaning.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: manifest, frozen hit set, live feed, materialized collection, and durable receipt are different truths. The datacube analogue is that exact result, privacy-shaped release, and suppressed/noisy publishable surface should also stay visibly distinct.
- **Steward** and **Foundry** keep pressuring Ward toward honest aftermath objects. The datacube analogue is that a privacy-safe surface should stay visibly smaller than the raw or internally replayable answer it borrowed from.

## What outside systems add to the datacube posture
- BigQuery adds the first discipline: differentially private queries require a **privacy unit column**, and the DP aggregate docs explicitly show that smaller aggregations might be removed and repeated runs can change. Ward should steal that as **protected-entity and non-replay** honesty, not as a commitment to BigQuery (`EXT-BIGQUERY-DIFFERENTIAL-PRIVACY-2026`, `EXT-BIGQUERY-DP-FUNCTIONS-2026`).
- AWS Clean Rooms adds the second discipline: output-constraint suppression can remove rows without the output explicitly indicating that removal, and the DP policy makes privacy budget and noise-per-query explicit with usage logs. Ward should steal that as **suppression fence** plus **budget residue** honesty, not as a commitment to Clean Rooms (`EXT-AWS-CLEANROOMS-ANALYSIS-RULES-2026`, `EXT-AWS-CLEANROOMS-DP-POLICY-2026`).
- Snowflake adds the third discipline: differential privacy is explicitly framed as protection against targeted re-identification attacks with a managed privacy/utility tradeoff. Ward should steal that as **privacy-shaped truth class** honesty, not as a commitment to one warehouse (`EXT-SNOWFLAKE-DIFF-PRIVACY-2026`).
- OpenDP adds the fourth discipline: mechanisms are formal measurements with an input metric, an output measure, and a privacy relation, and threshold/noise settings materially shape that relation. Ward should steal that as **noise witness** discipline, not as a commitment to one library (`EXT-OPENDP-MEASUREMENTS-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Any promoted recurring surface that is privacy-shaped should declare privacy posture before it borrows the title of the underlying repeated question.**
2. **Any promoted privacy-shaped surface should declare noise witness so the protected entity, contribution-bounding posture, and budget/noise family remain inspectable.**
3. **Any promoted surface that may withhold rows, cells, or small groups should declare a suppression fence instead of letting omission impersonate observation or zero.**
4. **Ward should not bless one universal privacy budget engine, one threshold floor, one collaborator-safe publication DSL, or one mandatory DP stack while SlopOS and its siblings are still settling their own query/result/materialization seams.**
5. **If Ward later imports privacy-shaped answers from different systems, it should treat privacy-unit drift, budget drift, and suppression-policy drift as semantic drift until proven comparable.**

## Specific anti-lessons from the past
- Do **not** let “safe to share” borrow the authority of replayable exact truth.
- Do **not** let hidden suppression impersonate observational absence or zero.
- Do **not** let privacy-unit choice disappear behind a generic metric title.
- Do **not** let budget consumption or per-query noise disappear behind one permanent-looking dashboard cell.
- Do **not** compare exact, thresholded, and differentially private answers under one flattering recurring title.

## What Ward should probably steal next
- a **privacy posture** attached to any promoted surface that is exact-inside-scope, thresholded, differentially private, or another declared privacy-shaped class;
- a **noise witness** attached to any promoted privacy-shaped release that depends on protected-entity definition, contribution bounding, or budget/noise configuration;
- a **suppression fence** attached to any promoted release that may hide rows/cells/cohorts for privacy reasons;
- a standing rule that **privacy-shaped publishability is weaker than replayable exact truth** until the privacy residue stays inspectable.
