# Research synthesis — pass XC

Pass XC focused on the gap left after recertification: incoming status, refresh, revocation, quarantine, projection, branch, and successor signals can race, duplicate, reorder, or be acknowledged before any local consumer refresh.

## External pressure

- `EXT-OPENID-SSF-2025` and `EXT-OPENID-CAEP-2025` keep transmitter/receiver/event posture separate from local policy application. Ward borrows the receiver-local humility, not the identity-domain event taxonomy.
- `EXT-RFC-8417`, `EXT-RFC-8935`, and `EXT-RFC-8936` pressure Ward to treat SET identity, duplicate delivery, push acknowledgement, poll ordering, and receiver acknowledgement as delivery facts rather than governance authority.
- `EXT-CLOUDEVENTS-SPEC-2026` reinforces stable event envelope identity through source/id/subject/type/time fields. Ward borrows source/id duplicate discipline for canonical signal keys.
- `EXT-NIST-SP-800-53-REV5` and `EXT-NIST-SP-800-137-2011` keep continuous monitoring and information-flow posture separate from a one-time authorization result.

## Design conclusion

Add a receiver-local governance signal-ingestion receipt. It binds the source recertification receipt, signal envelope, subject digest, cache-subject digest, delivery channel, event key, watermark, duplicate window, conflict set, payload classification, and follow-up requirement.

Signal ingestion is not recertification. It is the thing that says whether recertification, cache invalidation, conflict hold, duplicate ignore, stale ignore, or rejection is required.

## New executable pressure

The pass adds five positive fixtures and eighteen negative fixtures around accepted revocation, duplicate refresh, stale watermark, conflicting signals, projection-policy change, digest drift, sender/channel failure, source/subject mismatch, duplicate-as-new-change, stale-as-current, conflict auto-resolution, public leakage, missing labels, dropped forbidden effects, and push-ack/poll-order laundering.
