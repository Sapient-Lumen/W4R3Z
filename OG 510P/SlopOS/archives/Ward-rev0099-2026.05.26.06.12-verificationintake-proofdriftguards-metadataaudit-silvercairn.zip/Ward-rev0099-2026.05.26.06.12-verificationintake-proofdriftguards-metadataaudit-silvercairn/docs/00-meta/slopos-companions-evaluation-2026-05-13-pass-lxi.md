# SlopOS / companions evaluation — pass LXI

Pass LXI treats SlopOS's datacube as a future consequence of several still-designing seams rather than as an object that already exists. Ward's contribution is to keep the seams legible: view authority, query shape, mutable cuts, materialization state, lineage, and refusal reasons must not be collapsed into a polished answer.

## What the included cubes keep teaching

- **SlopOS** is the anchor. Its D-ATTRFS posture already says the dangerous thing clearly: attribute queries are view-scoped, snapshot-first, handle-returning, bounded, and not a global inventory/search oracle. A Ward datacube answer should therefore begin with a **scope lens** and should preserve a **refusal receipt** when a question would require an ungranted view, a count-only side channel, a hidden lineage join, or an unsupported query expansion.
- **ViewFS** keeps handles and presentation apart. A returned handle set, a preview, a manifest, an exported batch, and a durable promoted answer are different strengths of fact. Ward should require scope/state/refusal residue to travel with any ViewFS-shaped answer export.
- **Harbor** keeps imported boundary facts from becoming native authority. External semantic-layer answers, BI dashboard numbers, and partner warehouse extracts should enter Ward as imported claims until their scope lens and state cut witness are locally appraised.
- **Foundry** keeps substrate realization optional. Scope lens and state cut witness let Ward evaluate relational, array, object-manifest, columnar, and log-derived realizations without blessing one storage engine as the datacube.
- **Schell** keeps commands, receipts, and effects separated. Ward should steal refusal receipts for query execution: unsupported, over-budget, denied, stale, or non-deterministic plan outcomes should be durable answer material, not shell stderr lost after a dashboard refresh.
- **Steward** keeps lifecycle state separate from the activated thing. A materialized cube summary has created/refreshed/promoted/expired lifecycle facts; the state cut witness should name them without pretending lifecycle freshness is measure truth.
- **Helm** keeps UI displays from replacing object truth. A chart needs visible refusal and scope cues; “blank” must not be the only user-visible representation of denied, suppressed, unmodeled, stale, or absent cells.

## What outside systems add to the datacube posture

- MetricFlow/dbt add the governed-answer lesson: a semantic layer can define entities, dimensions, measures, and metrics, and compile metric requests into SQL, but its strongest trust lesson for Ward is typed coverage and explicit failure for uncovered questions (`EXT-DBT-SEMANTIC-MODELS-2026`, `EXT-DBT-METRICFLOW-2026`, `EXT-DBT-SEMANTIC-LAYER-AI-BENCH-2026`).
- DuckDB and ClickHouse add the subtotal-identity lesson: grouping sets, rollups, and cubes need a way to distinguish super-aggregate rows from ordinary null-like members (`EXT-DUCKDB-GROUPING-SETS-2026`, `EXT-CLICKHOUSE-GROUPING-SETS-2026`).
- ClickHouse aggregate-state docs add the retained-state lesson: mergeable state can be valuable and must be named separately from the scalar it eventually displays (`EXT-CLICKHOUSE-AGGREGATEFUNCTION-2026`).
- Xarray adds the labeled-coordinate lesson: dimensions, coordinates, data variables, and attributes are a helpful human/modeling split, but they do not carry authority or state cuts by themselves (`EXT-XARRAY-DATA-STRUCTURES-2026`).
- TileDB adds the sparse-coordinate lesson: empty sparse cells are not materialized, so absence posture must not be guessed after the fact (`EXT-TILEDB-DIMENSIONS-2026`).
- Arrow's security model adds the export-boundary lesson: fast columnar interchange is a crossing surface that still needs validation and trust posture, especially for untrusted sources (`EXT-ARROW-SECURITY-MODEL-2026`).

## Recommended datacube posture for Ward right now

1. **Require answer authority before answer shape.** A scope lens should precede durable promotion whenever a query crosses SlopOS views, imported data, privacy surfaces, or external exports.
2. **Treat mutable cuts as part of meaning.** A state cut witness should capture which snapshots, schema digests, semantic versions, materialization generations, redaction profiles, and policy epochs made the answer possible.
3. **Make refusal visible.** A refusal receipt should travel with the answer, even when it simply says no refusal occurred. This keeps later readers from confusing “complete” with “the chart rendered.”
4. **Keep refusal smaller than policy.** Refusal receipts should say why an answer was not produced; they should not become the policy engine or auth subsystem.
5. **Do not open a count oracle.** SlopOS's handle-returning posture is a clue: application-visible count/existence cube queries need special skepticism because they can leak hidden populations.
6. **Do not rescue uncovered questions with creative SQL.** LLMs may propose drafts, but Ward should not promote an answer unless deterministic machinery produced the scope lens, state cut witness, axis capsule, lineage facet, and refusal receipt.

## Specific anti-lessons from the past

- Do **not** let a semantic layer become an ambient global truth oracle outside the view that authorized the question.
- Do **not** let a subtotal cell, an ordinary null member, a sparse empty cell, a hidden/suppressed cell, and a denied cell share one representation.
- Do **not** treat “no rows returned” as evidence of absence unless the scope lens and refusal receipt say so.
- Do **not** let LLM-generated SQL fill gaps in governed query coverage when the right outcome is an explicit cannot-answer receipt.
- Do **not** promote a materialized scalar after discarding the state generation, metric spec, source snapshots, redaction policy, or materialization freshness that made it.
- Do **not** trust an exported Arrow-like batch, ViewFS manifest, or partner cube output more than the residues it carries.

## What Ward should probably steal next

- a **scope lens** for any promoted answer whose authority boundary, view, population, or count/existence leakage posture may matter later;
- a **state cut witness** for any answer whose schema, semantic model, policy epoch, source snapshot, materialization generation, redaction profile, or retained state might drift;
- a **refusal receipt** for any unsupported, denied, suppressed, stale, over-budget, unmodeled, or withheld part of a datacube answer;
- a standing **cannot-answer beats plausible-wrong** rule for SlopOS-facing analytics and agent workflows.
