# SlopOS / companions evaluation — pass XXIV

This pass keeps Ward embryonic while stealing one more good habit from the neighbors: **make recurring seams discoverable and machine-checked, but keep the mechanism lighter than the archive's maturity.**

## What the current cubes still teach
- **SlopOS** keeps classification and consequence visibly separate across many surfaces: claims, receipts, denials, policy handles, and final effect are not allowed to collapse into one ambient success bit. Ward should steal that discipline for later-state handling: `state class` should stay smaller than any local spend/adopt consequence.
- **SlopOS** also earns its family indexes only after repeated pressure, then keeps them discoverable and same-revision maintained. Ward now has enough recurring specimen pressure to justify one tiny family map for specimen flows, but still not a giant schema or registry system.
- **Harbor** keeps successful detours and callbacks weaker than durable local adoption. Ward should apply the same smell test to later-state action ladders: a policy label that still leads to substantially the same real consequence is not honest narrowing.
- **Steward** keeps followthrough and freshness decay explicit. Ward should similarly keep observe-only posture, quarantine posture, and hard denial visibly different instead of pretending one later-state class always forces one action.
- **ViewFS** keeps apply ladders and delta truth explicit. Ward should therefore preserve the difference between classified state, local action ladder, and the real spend semantics of that action.

## Current recommendation
Keep Ward open on transport and proof substrate.

The next wise move is still a specimen, plus one tiny hygiene upgrade:
1. **state class** instead of status-to-action collapse,
2. **action ladder** instead of one universal reaction,
3. **effective-validity test** instead of decorative de-preference,
4. **delivery-path skepticism** instead of stapled/live transport worship,
5. **specimen-flow index + lint gate** instead of thin family drift.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should still avoid heavyweight family machinery.
The smaller steal is enough for now:
- add one lightweight `specimen-flow-index.md`,
- keep every `specimen-flow-*.md` listed there in the same revision,
- and make the hygiene checker fail if the specimen family drifts out of discoverability.

## Still-not-yet decisions
- Whether `state class` deserves first-class Ward vocabulary or remains typed local evaluation residue.
- Whether `action ladder` belongs in Ward proper or only in neighboring policy/adoption surfaces.
- Whether `effective-validity test` should become a promotion gate, a review question, or merely a standing anti-pattern check.
- Whether `delivery-path skepticism` belongs in Ward or should stay imported from status/transparency transports.
- Whether `coverage floor` is Ward truth or only local gate policy.
