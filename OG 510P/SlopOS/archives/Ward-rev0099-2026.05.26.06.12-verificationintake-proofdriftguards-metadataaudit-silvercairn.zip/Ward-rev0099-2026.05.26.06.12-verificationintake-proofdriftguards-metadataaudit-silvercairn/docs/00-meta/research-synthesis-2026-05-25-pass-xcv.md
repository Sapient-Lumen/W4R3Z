# Research synthesis — pass XCV

This pass pressure-tests the post-gate execution seam.

## Sources pressed into the design

- `EXT-OASIS-XACML-3-0-2013` keeps policy decisions and enforcement obligations separate. Ward borrows the caution: a gate result must not be treated as completed enforcement.
- `EXT-W3C-PROV-DM-2013` keeps activity, entity, derivation, and association visible. Ward uses that pressure to model use execution as an activity bound to a source gate, not a mutation of the source gate.
- `EXT-CLOUDEVENTS-SPEC-2026` keeps event identity and context explicit. Ward uses that pressure for source-gate identity and duplicate-safe actual-effect recording.
- `EXT-OTEL-EVENT-SEMCONV-2026` keeps instrumentation vocabulary separate from business meaning. Ward uses that pressure to avoid treating execution telemetry as authority.

## Design consequence

A use-execution receipt records actual effect containment. It is allowed to prove that display or review happened safely, or that no execution happened because the gate held/refused/quarantined. It is not allowed to approve export, repair, remedy, action, learning use, budget spend, or status-pointer updates.
