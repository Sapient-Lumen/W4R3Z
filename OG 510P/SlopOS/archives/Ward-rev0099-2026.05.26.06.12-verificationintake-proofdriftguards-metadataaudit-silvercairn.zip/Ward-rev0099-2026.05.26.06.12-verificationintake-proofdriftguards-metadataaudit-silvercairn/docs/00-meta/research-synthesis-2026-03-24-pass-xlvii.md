# Research synthesis — pass XLVII

This pass keeps Ward decision-light and adds another datacube discipline: **a recurring measure needs an explicit aggregation law before any promoted derivative or dashboard rollup can pose as general truth**.

## What the past says we must learn
1. **Additivity is not the default.**  
   Cube's measure-additivity docs are unusually candid: additivity is the property that determines whether a value calculated at one dimensional grain can be re-aggregated to a coarser one, and only some measure types qualify. Ward should steal the habit, not the product model: every promoted analytic surface should carry an **aggregation law** instead of inheriting a silent “sum it later” assumption (`EXT-CUBE-ADDITIVITY-2026`).

2. **Distinct totals and balance snapshots do not share one rollup story.**  
   Microsoft's DAX docs make the non-additive lesson concrete by showing that distinct-count totals are not the sum of category totals, while Analysis Services' semiadditive docs make the complementary lesson explicit: balance/snapshot facts often aggregate across some dimensions but not uniformly across time. Ward should therefore attach a **rollup passport** to any recurring measure surface that says where the result can safely roll up and where it cannot (`EXT-DAX-DISTINCTCOUNT-2026`, `EXT-SSAS-SEMIADDITIVE-2025`).

3. **Some higher-level totals require mergeable state, not one rendered number.**  
   ClickHouse's `AggregateFunction` docs spell out the key implementation truth: some aggregates can be kept as intermediate state and later recombined with `-Merge`. Ward should steal the lighter constitutional lesson: if a promoted derivative must support safe recomposition beyond one displayed value, it may need an explicit **merge state** residue instead of only a final rendered total (`EXT-CLICKHOUSE-AGGREGATEFUNCTION-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal measure taxonomy, one semantic compiler, one pre-aggregation engine, or one mandatory machine-readable metric contract.

For now, keep three more separations visible and let later specimens force promotion:
- **aggregation law** — visible statement that one measure is additive, semiadditive, non-additive, merge-state-backed, replay-only, or otherwise unsafe to re-roll without extra structure.
- **rollup passport** — compact statement of the dimensions, grains, windows, and dropped-context moves that are allowed, forbidden, or caveated for one recurring measure surface.
- **merge state** — optional durable residue holding the intermediate state needed for safe recomposition when a final displayed value is not itself safely re-aggregatable.

## Why these separations are worth stealing
- An `aggregation law` stops dashboards and derived tables from pretending every metric behaves like `SUM`.
- A `rollup passport` keeps “safe to regroup”, “safe to sum over time”, and “safe only with the original recipe” from collapsing into one cheerful metric label.
- A `merge state` preserves the difference between “I can show you this number” and “I can safely recombine the underlying aggregate state into another exact-or-supported higher-level result.”

## Brilliant ideas to steal now
- **aggregation law** — explicit rollup behavior for one recurring measure.
- **rollup passport** — compact contract for allowed regrouping, time-rollup, and caveated projections.
- **merge state** — optional intermediate-state residue when displayed values are not safely re-aggregatable.
- **no universal additivity by default** — standing anti-regrowth rule.
- **rendered total weaker than recomposition state** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward ever blesses one fixed taxonomy for additive / semiadditive / non-additive / merge-state-backed measures.
- Whether `rollup passport` stays human-facing guidance or later becomes a typed artifact.
- Whether `merge state` is only for promoted derivatives or also for some frozen review bundles.
- Whether some recurring measures should permanently remain replay-only instead of ever gaining a passported derivative.
