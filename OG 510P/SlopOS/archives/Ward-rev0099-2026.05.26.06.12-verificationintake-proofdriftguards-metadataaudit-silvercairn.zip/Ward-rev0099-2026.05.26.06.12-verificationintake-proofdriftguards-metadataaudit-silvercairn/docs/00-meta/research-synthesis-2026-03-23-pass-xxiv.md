# Research synthesis — pass XXIV

This pass keeps Ward narrow and learns one more thing from deployed validation systems: **classification is not consequence, and a careful design should set state broadly, apply action locally, and prove that “softer” action really narrows the real outcome.**

## Outside lessons
1. **RPKI separates evaluation from policy on purpose.**  
   RFC 8481 says all routes should have their validation state set and that policy MUST NOT be applied without operator configuration. Ward should therefore keep `state class` visibly smaller than any spendable consequence, even when the status engine feels decisive.

2. **RPKI also treats rollout posture as a local ladder, not one universal action.**  
   RFC 7115 says origin validation marks routes `Valid`, `NotFound`, or `Invalid`, and how that state is used should be specified by the operator's local policy. It further suggests relative preference during early deployment because coverage will be incomplete for a long time. Ward should therefore preserve an explicit `action ladder` instead of pretending one later-state answer forces one universal consequence.

3. **A weaker-looking action can still be effectively equivalent to full acceptance.**  
   RFC 7115 warns that merely de-preferencing `Invalid` announcements is often equivalent to treating them as fully valid because longest-match forwarding still wins. Ward should steal an `effective-validity test`: any local narrowing must be checked against the real consequence path, not only against a policy label.

4. **Mandatory delivery-path coupling has a bad operational history.**  
   Let's Encrypt says OCSP Must-Staple failed to get wide browser support and that popular web servers implement OCSP Stapling in ways that create serious downtime risks. Ward should therefore avoid binding durable trust meaning to one carried, stapled, or live delivery path too early.

5. **The ecosystem is already moving away from one mandatory status transport.**  
   CA/Browser Forum Ballot SC063v4 made OCSP optional for publicly trusted CAs, required CRLs, and allowed short-lived certificates that need neither revocation pointers nor revocation service. Ward should therefore resist baking one universal later-status transport into the datacube while the surrounding ecosystem is still plural.

## Resulting Ward move
Do not decide yet whether Ward's long-term status ecology prefers lists, point lookups, carried responses, event watches, transparency-backed queries, or local corpora.

For now, preserve four separations and let later specimens force promotion:
- `state class` versus any automatic local consequence;
- `action ladder` versus one fixed universal deny/allow rule;
- real narrowing versus cosmetically weaker-but-still-effective validity;
- status meaning versus one fragile delivery path.

## Fresh ideas worth stealing
- **state class** — visible classification smaller than verdict or spend.
- **action ladder** — explicit local mapping from classified state to observe, narrow, quarantine, or deny.
- **default non-action** — classification can exist without implicit consequence until local policy says otherwise.
- **effective-validity test** — check whether a softer penalty still spends almost like valid.
- **delivery-path skepticism** — a carried/stapled/live transport remains weaker than the meaning it tries to convey.
- **coverage floor** — minimum coverage/confidence required before a local ladder may hard-drop.
