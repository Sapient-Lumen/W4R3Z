# SlopOS / companions evaluation — pass XXXIV

This pass keeps Ward embryonic while stealing one more useful habit from SlopOS and from mature message-security systems: **be explicit about what must be understood, what may be tolerated as unknown, and what must fail closed when duplicated or misplaced.**

## What the current cubes still teach
- **SlopOS** already has the strongest nearby lesson in RFC-0071 and its validator-heavy families: explicit interface identity, explicit unknown-op behavior, deterministic refusal for closed interfaces, and adapters instead of silent fallback. Ward should steal the smaller analog: keep a narrow must-understand lane and make unknown behavior explicit instead of folkloric.
- **SlopOS** also repeatedly uses total validators, closed enums, and fail-closed treatment of malformed or unknown critical variants. That is a valuable archive hygiene lesson for Ward’s datacube too: the receiver should not pretend it understood a stronger claim than it actually processed.
- **Foundry** and **ViewFS** still remind Ward that bridge formats and derived views can be weaker than source truth. That pressure matters here as well: retained unknowns are already weaker than understood claims, and lossy bridges can weaken them again.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one universal field registry, one parser contract, one crit-bit schema, or one global compatibility rule into the archive.

## Current recommendation
Keep Ward open on whether must-understand posture ultimately rides on schema annotations, envelope-local declarations, profile manifests, or action-local allowlists.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **must-understand claim** instead of one blob of “all claims are equal”;
2. **understanding gate** instead of hiding parse/appraisal prerequisites inside verifier folklore;
3. **retained unknown** instead of silently converting preserved-but-unread material into understood truth;
4. **duplicate collision alarm** instead of normalizing duplicate semantically meaningful fields away;
5. **release-manifest core-doc existence lint** so the archive’s declared front-door set cannot drift into dead links.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep closed/flexible handling explicit;
- keep fail-closed treatment for critical semantics explicit;
- keep bridge-loss pressure visible when unknowns are only retained transitively;
- and fail the revision if a `core_docs` path in `RELEASE-MANIFEST.json` does not actually exist.

## Still-not-yet decisions
- Whether `must-understand claim` belongs in durable Ward vocabulary or remains envelope-local / transport-local until more specimens accumulate.
- Whether `understanding gate` should stay a parse/appraisal seam only, or become a more general promotion gate noun inside Ward.
- Whether `retained unknown` deserves first-class archive residue, or whether it should remain a compatibility-sidecar idea until more bridge specimens exist.
- Whether `duplicate collision alarm` should stay parse-level, or become part of a larger anti-ambiguity family later.
