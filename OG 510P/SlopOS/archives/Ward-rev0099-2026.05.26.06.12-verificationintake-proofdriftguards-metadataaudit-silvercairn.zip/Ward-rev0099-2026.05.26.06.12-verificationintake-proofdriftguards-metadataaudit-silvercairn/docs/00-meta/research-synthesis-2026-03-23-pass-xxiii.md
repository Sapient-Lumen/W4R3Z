# Research synthesis — pass XXIII

This pass keeps Ward narrow and learns one more thing from status, transparency, and revocation systems: **covered absence, uncovered unknown, and negative status are different truths, and a trustworthy local answer should say which one it has instead of painting them all green.**

## Outside lessons
1. **OCSP's `good` status is weaker than people remember.**  
   RFC 6960 says `good` means at minimum that no certificate with the requested serial number currently within its validity interval is revoked, but it does **not** necessarily mean that the certificate was ever issued or that the response time is within the certificate's validity interval. Ward should therefore never let a positive later-status check impersonate original issuance truth or present validity.

2. **OCSP's `unknown` result is healthier than fake certainty.**  
   RFC 6960 says `unknown` means the responder does not know the certificate being requested, allowing the client to try another status source. Ward should therefore preserve an explicit `unknown posture` rather than quietly treating coverage gaps or unserved issuers as if they were clean status.

3. **CRLite separates freshness, coverage, and negative result.**  
   Mozilla's CRLite design reduces local checking to three questions: is the local filter fresh enough, is the issuer included, and if so does the filter indicate revocation. Ward should steal that split: a negative answer only means much when the corpus proves it actually covers the relevant issuer/time cut.

4. **CRLite's production rollout strengthens the case against live-oracle regrowth.**  
   Mozilla says Firefox stores a compact local revocation encoding, updates it every 12 hours, ships roughly a 4 MB snapshot every 45 days plus delta updates averaging about 300 kB/day, enabled CRLite for desktop users starting in Firefox 137, and plans to disable OCSP for domain-validated certificates in Firefox 142. Ward should therefore keep `snapshot + delta` pressure alive without deciding that every future Ward status family must be list-shaped.

5. **Key Transparency shows that absence can be proof-carrying.**  
   The current Key Transparency protocol draft defines `inclusion`, `nonInclusionLeaf`, and `nonInclusionParent` proof results. Ward should steal the lesson that “not found” can be cryptographically stronger than “I didn't see it”, while still treating the whole substrate as imported accountability material rather than automatic verdict.

6. **SCITT keeps plural receipts possible.**  
   The current SCITT architecture draft allows one Signed Statement to be registered with multiple Transparency Services, producing multiple receipts. Ward should therefore resist making one publication service or one receipt lane look like the whole truth; plural accountability can stay smaller than local approval.

## Resulting Ward move
Do not decide yet whether Ward needs durable first-class nouns for `coverage witness`, `unknown posture`, `proof-carrying absence`, `issuer participation card`, `delta train`, or `plural receipt braid`.

For now, preserve four separations and let specimens decide later:
- covered negative claim versus uncovered unknown;
- proof-carrying non-inclusion versus heuristic “not seen” residue;
- locally replicated snapshot-plus-deltas versus live point lookups;
- plural accountability receipts versus one status or transparency authority.

## Fresh ideas worth stealing
- **coverage witness** — small artifact that says this status corpus actually covers the relevant issuer/subject class/time cut.
- **unknown posture** — explicit residue that says no trustworthy negative inference is available here yet.
- **proof-carrying absence** — non-inclusion result stronger than a cache miss or empty search.
- **issuer participation card** — compact statement that a status corpus does or does not include one issuer/family.
- **delta train** — bounded sequence of updates extending an older snapshot without requiring a live oracle on every check.
- **plural receipt braid** — multiple accountability receipts that stay smaller than any final local verdict.
