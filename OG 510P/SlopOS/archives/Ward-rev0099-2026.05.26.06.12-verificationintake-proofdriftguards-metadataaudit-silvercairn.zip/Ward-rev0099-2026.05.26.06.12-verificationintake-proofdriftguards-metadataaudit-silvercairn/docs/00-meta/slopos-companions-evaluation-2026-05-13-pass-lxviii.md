# SlopOS and companion evaluation — pass LXVIII

Pass LXVIII asks whether Ward's datacube can compose answers across boundaries without turning federation into a laundering machine. This is directly relevant to SlopOS because the SlopOS snapshot is full of import/export boundaries, provider-local-only interpretations, explicit budget/payer posture, snapshot-first bounded queries, and closed companion discovery surfaces. A cube that ignores those habits would become the place where all carefully pinned boundaries quietly dissolve.

## SlopOS pressure

SlopOS already teaches several constraints Ward should preserve:

1. **Boundary-local meanings do not become portable truth.** The recent FedCM and OpenID Federation import boundaries pin browser federation and federation trust bootstrap as provider-local compatibility/mediation material, not portable current-user, account, approval, policy, or trust-root truth. Ward should treat datacube federation the same way: a participant's trust chain, resolver output, clean-room template, or policy-decision response informs one answer attempt but does not become a global source registry.

2. **Queries are snapshot-first and handle-returning where SlopOS is already careful.** CH-ATTRQ's posture is capability-scoped, typed when schema is present, bounded, snapshot-first, and handle-returning. Ward's federation pact should inherit that style: no live inventory, no hidden saved-query plane, no implicit cross-view expansion, and no raw-source substitution through lineage joins.

3. **Budget/payer authority is explicit.** D-BUDGET/D-METER pressure from earlier passes remains relevant: federated query fragments, clean-room intersections, delegated authorization searches, and remote pushdown all consume resource/cost/privacy/detail budgets under specific authority. A federation pact should name those gates instead of assuming a central cube pays.

4. **Closed family indexes are hygiene, not product surfaces.** SlopOS's boundary-index contract is a strong process pattern: companion families need explicit membership and same-revision maintenance. Ward should steal the hygiene for federated participants and source families, but not import a new global catalog yet.

## Companion-specific evaluation

- **Harbor** should keep evidence-grade and custody posture from being upgraded just because another participant joined the cube. A federation pact can name Harbor evidence cuts, but a join warrant cannot convert evidence into outcome truth.
- **Foundry** can contribute semantic spines, pinned cuts, and generation labels. Ward should use them as participant contract material, not as a universal semantic graph for all sources.
- **Steward** is a natural home for followthrough on residual gaps, composition refusals, and collaborator-specific repair tasks. A failed federation pact should open a followthrough item, not a hidden retry loop.
- **Schell** can contribute environment epoch and execution posture for where one remote fragment ran. Ward should not turn that into a mandatory runtime substrate.
- **ViewFS** reminds Ward that stable handles, aliases, and rehydration matter. A projection curtain can expose a handle or aggregate, but it should not smuggle the source file, folder, or raw lineage path.
- **Helm** needs visible condition strips: remote fragment, clean-room projected, join warranted, projection narrowed, hidden policy warning, composition refused, rehydrate-before-use. Helm should render those without inheriting cube authority.
- **SlopOS itself** remains the authority boundary, not the datacube. Ward composes answer residues; SlopOS still owns capability, policy, budget, and execution boundaries.

## Lessons that must survive

1. **Federation is an answer attempt, not a source of truth.** More participants do not make the answer stronger unless their scope, semantic, quality, policy, and projection residues compose.
2. **Remote execution needs a label.** Local, remote, pushed-down, clean-room, delegated-PDP, cached, and materialized fragments are different evidence postures.
3. **Join permission is not just key equality.** A join key may be meaningful but forbidden, permitted but privacy-shaped, or allowed only for aggregate intersection.
4. **Projection can be stronger than join.** A source may allow joining on a key but forbid projecting it, or allow aggregate output but not list output.
5. **Hidden policies are still real.** If underlying source policies still apply but are not visible through the collaboration surface, Ward should carry a warning or refuse consequence-grade promotion.
6. **Federated refusal must be safe.** `participant_denied`, `join_warrant_missing`, `projection_blocked`, and `composition_failed` must not leak hidden participant, row, key, or cohort existence.
7. **Source contracts are multi-part.** Schema compatibility is not enough; quality, roles, SLA, support, policy, pricing/cost, and infrastructure cuts can all affect answer authority.
8. **Agents are especially dangerous here.** An agent may ask “just join these two sources.” Ward should force the agent through federation pacts, join warrants, projection curtains, and refusal receipts before anything consequential leaves the cube.

## Anti-lessons to preserve

- Do **not** let a federated query title imply source contracts composed successfully.
- Do **not** let an external federation trust chain become a portable Ward source registry.
- Do **not** let a delegated authorization decision become a cached population inventory.
- Do **not** let a join key equality check bypass identity witness, fanout fence, join clock, policy, privacy, and projection posture.
- Do **not** let clean-room aggregate output be treated as replayable raw data.
- Do **not** let a remote endpoint's “unsupported pushdown” silently move filtering or aggregation to a less protected location.
- Do **not** let hidden source-table policies or policy carryover failures become dashboard surprises.
- Do **not** let composition refusal reveal the existence of denied participants or suppressed cohorts.

## What Ward should probably steal next

- a **federation pact** for bounded participant/authority/capability contracts;
- a **join warrant** for permitted and semantically meaningful cross-boundary joins;
- a **projection curtain** for safe output/release limits at each participant and composed-answer boundary;
- a standing **remote fragment label** so execution location and enforcement responsibility remain inspectable;
- a small fixture suite for pushed filter, pushed aggregate, unsupported pushdown fallback, clean-room intersection, hidden policy warning, allowed join/no projection, projection allowed/no activation, delegated PDP search refusal, and safe composition failure.
