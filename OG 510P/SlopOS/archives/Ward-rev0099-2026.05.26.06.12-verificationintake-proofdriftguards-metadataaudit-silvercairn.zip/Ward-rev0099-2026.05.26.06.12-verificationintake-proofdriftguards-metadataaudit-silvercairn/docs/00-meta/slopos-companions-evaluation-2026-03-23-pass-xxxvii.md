# SlopOS / companions evaluation — pass XXXVII

This pass keeps Ward embryonic while stealing one more useful habit from SlopOS and the sibling cubes: **separate temporary authority, monotonic fencing, stale-holder risk, and handoff style instead of collapsing them into one lock/owner truth.**

## What the current cubes still teach
- **SlopOS** is the clearest teacher for this pass. Its capability semantics already keep `gen_at_issue` and generation-bump revocation visible, its multiple lease posture surfaces avoid turning every hint into a durable grant, and its descriptor-vs-live-state boundaries keep historical lease bytes smaller than current authority. Ward should steal the restraint, not the whole machinery.
- **Harbor** and **Steward** keep pressuring the same seam from the operator/browser side: time-bounded presence, leased attention, and remote teardown all want honest local consequences without pretending that “still looks live to me” is enough.
- **Helm** remains a neighboring reminder that acceptance and settlement differ; this pass adds the authority-side sibling lesson that holding or once-holding a lease is weaker than presenting a current fence token where the destination actually checks it.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one lease API, one epoch-carrier, one lock-manager substrate, or one mandatory recipient protocol into the datacube.

## Current recommendation
Keep Ward open on whether temporary authority and fencing ultimately travel as capability generations, lease descriptors plus recipient-side validators, replicated-object revisions, operation-side compare-and-swap conditions, or some mixed shape.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **lease claim** instead of pretending time-bounded ownership is already exclusion;
2. **fence token** instead of relying on one holder’s local clock or confidence;
3. **stale-holder alarm** instead of letting superseded requests masquerade as current authority;
4. **handoff posture** instead of flattening cooperative release and forced break;
5. **release-manifest highlight coherence** so the packaged archive cannot quietly advertise one focus while roadmap/context/receipt surfaces say another.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep lease descriptors and live authority separate;
- keep epoch/generation validation stronger than holder-local TTL confidence;
- keep cooperative handoff weaker than forced exclusion; and
- fail the revision if `RELEASE-MANIFEST.json` advertises highlights different from the shared current focus.

## Still-not-yet decisions
- Whether `lease claim` belongs in durable Ward vocabulary or remains temporary-authority residue owned by adjacent coordination cubes.
- Whether `fence token` should become first-class Ward vocabulary, or remain imported substrate residue until more specimens accumulate.
- Whether `stale-holder alarm` belongs inside Ward, or remains a consequence-side warning produced by sibling cubes.
- Whether `handoff posture` is best treated as a local policy-side render of other residue, or a first-class Ward noun later.
