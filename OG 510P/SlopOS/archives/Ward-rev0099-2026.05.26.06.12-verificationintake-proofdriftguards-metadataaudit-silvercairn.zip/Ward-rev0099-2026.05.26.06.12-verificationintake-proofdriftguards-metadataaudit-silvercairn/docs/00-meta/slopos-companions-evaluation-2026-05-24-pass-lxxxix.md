# SlopOS companions evaluation — pass LXXXIX

Pass LXXXIX evaluated Ward's recertification receipt against SlopOS and the companion cubes.

## SlopOS

SlopOS should treat a recertified cache as a status pointer only. CH-AREF attachment, portal use, action support, export, learning-loop use, repair, remedy, and budget effects still require source-packet replay and consequence-grade checks.

## Harbor

Harbor should require a current recertification receipt before using a cached dispute resolution to support recompute, stale-surface messaging, correction status, or public recheck windows. Invalidated and quarantine-sustained cache states should hold.

## Helm

Helm should render cache state as a visible freshness/replay chip, not as approval. The safe label is “cached resolution: refresh required,” not “resolved.”

## Schell

Schell should minimize public recertification evidence while retaining cache-subject digest, source-resolution digest, cut time, next recheck due, and stale-bundle quarantine state.

## ViewFS

ViewFS should keep recertified, invalidated, quarantine-sustained, historical-only, and recheck-required states visibly distinct. Detached artifacts should show refresh/invalidation posture when their source status changes.

## Foundry and Steward

Foundry owner-map/crosswalk drift and Steward lifecycle/successor drift can invalidate a cached Ward resolution without making Foundry or Steward the authority to repair. Ward should record the changed basis and require replay.

## Result

Recertification remains v0 lifecycle hygiene. It should not be promoted into a first-class authority residue until SlopOS and the companions prove cached-resolution invalidation, refresh-signal propagation, stale-bundle quarantine, and consequence-gating semantics end to end.
