# SlopOS companions evaluation — 2026-05-22 pass LXXXIV

Pass LXXXIV evaluates evidence-release receipts against the companion set.

## SlopOS

SlopOS is the main release initiator. Portal downloads, queue exports, artifact attachments, and ACP handoffs can all detach Ward evidence from its live UI.

Required behavior: SlopOS must require an evidence-release receipt before governance evidence leaves the current trusted path. A released bundle is not action authority and must keep its no-authority label.

## ViewFS

ViewFS is the trusted-path consumer.

Required behavior: ViewFS should render release receipts as bounded evidence artifacts with recipient/purpose labels, retention horizon, refresh channel, and sealed-omission posture. It must not treat the artifact as proof that all hidden governance rows are absent.

## Schell

Schell owns retention, minimization, and forgetting pressure.

Required behavior: Schell should consume the release receipt's retention horizon, field allowlist/denylist, and refresh/revocation channel. Forgetting a source receipt should create release-review debt rather than silently leaving detached artifacts authoritative.

## Helm

Helm renders release consequences.

Required behavior: Helm should label released artifacts as “not authority; refresh before action,” show held-recheck notices as first-class results, and refuse green export badges for mixed-state evidence.

## Harbor

Harbor may receive released evidence during correction or recheck flows.

Required behavior: Harbor can use a release receipt for intake context, but recompute, correction implementation, and public remedy still require current packet replay and Harbor's own proof obligations.

## Foundry

Foundry may export classification/crosswalk governance evidence.

Required behavior: Foundry should preserve mapping grade, split/merge posture, no-map states, and code-drift warnings in release payloads instead of exporting only the apparent label.

## Steward

Steward may schedule release rechecks and partner notifications.

Required behavior: Steward can route held-recheck notices and refresh tasks. It cannot convert partner acknowledgment or notification delivery into acceptance of governance authority.

## Net evaluation

The evidence-release receipt is justified as a v0 executable guard. It should stay provisional until released artifacts are consumed through ViewFS trusted-path cards and Schell retention receipts without losing no-authority, omission, and refresh semantics.
