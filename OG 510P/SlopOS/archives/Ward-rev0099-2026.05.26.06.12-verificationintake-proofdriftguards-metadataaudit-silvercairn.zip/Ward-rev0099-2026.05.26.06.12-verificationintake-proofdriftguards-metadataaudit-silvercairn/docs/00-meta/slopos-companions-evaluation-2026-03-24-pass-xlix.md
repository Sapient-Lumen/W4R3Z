# SlopOS / companions evaluation — pass XLIX

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **a repeated trust question should not be promoted until Ward can say whether missing buckets were omitted, synthesized, zero-filled, carried forward, or left explicitly unknown.**

## What the included cubes keep teaching
- **SlopOS** is still the strongest nearby teacher because RFC-0100 keeps querying modest: **view-scoped**, **snapshot-first**, **handle-returning**, with saved queries remaining **shell-owned manifests** and live mode **optional and bounded**. That posture reinforces the new lesson: densification convenience should stay smaller than result meaning, and result meaning should stay smaller than a promoted derivative.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: **query manifest**, **result snapshot**, **live feed**, **materialized local collection**, and **current bind** are distinct. This revision adds one more split inside the result itself: a gap-aligned bucket may itself be synthetic, and the value inside it may carry a weaker fill witness.
- **Steward** keeps teaching that remembered structure is weaker than current liveness. The analogous datacube lesson is that a carried-forward or stale-held number is weaker than fresh observation even when it makes a chart look calmer.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows a continuous trend line or tidy daily table, the shell should be able to say whether a row was observed, synthesized, zero-filled, or carried forward.

## What outside systems add to the datacube posture
- dbt's current metrics guidance makes the first anti-lesson explicit: `join_to_timespine` and `fill_nulls_with` are separate moves. Ward should borrow that as **synthetic bucket** plus **fill witness**, not as a commitment to dbt's exact metric compiler (`EXT-DBT-FILL-NULLS-2026`).
- BigQuery's `GAP_FILL` docs add the second anti-lesson: the default method is `NULL`, and `locf` / `linear` are explicit method choices. Ward should borrow that as **gap posture** and **fill witness**, not as a decision to adopt one time-series SQL family while SlopOS is still moving (`EXT-BIGQUERY-GAP-FILL-2026`).
- Tiger Data / Timescale adds the third lesson: generating contiguous buckets is already separate from assigning values to them. Ward should borrow that as **synthetic bucket** posture for repeated questions that need alignment or chartability (`EXT-TIGERDATA-GAPFILL-2026`).
- Prometheus adds the fourth lesson: lookback, staleness, and disappearance are already semantic moves, not innocent rendering details. Ward should borrow that as **gap posture** discipline, not as a commitment to Prometheus semantics across every future surface (`EXT-PROMETHEUS-STALENESS-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Every promoted densified question must declare a gap posture before it earns dashboard authority.**
2. **Every generated bucket should stay visibly weaker than an observed bucket.**
3. **Every carried-forward, interpolated, or zero-filled value that matters should mint a fill witness or remain query-local ephemeral state.**
4. **Ward should not let one tidy chart or table quietly erase the difference between sparse raw observation and synthetic alignment.**
5. **Ward should not bless one universal timespine or gap-fill constitution while SlopOS and its siblings are still actively discovering their shell, manifest, and result seams.**

## Specific anti-lessons from the past
- Do **not** let “no row” silently become “zero” without an explicit decision.
- Do **not** let a carried-forward value borrow the authority of fresh observation forever.
- Do **not** let a synthetic alignment bucket masquerade as a source bucket.
- Do **not** confuse chart continuity with truth continuity.
- Do **not** pick one giant gap-fill grammar or time-spine constitution just because a few repeated questions are emerging.

## What Ward should probably steal next
- a **gap posture** attached to any recurring trend surface that starts influencing decisions;
- a **fill witness** that stays smaller than both the query contract and the final local consequence;
- a **synthetic bucket** marker for aligned/densified rows that were created rather than observed;
- UI headers that can say **basis pin + join clock + gap posture + synthetic-bucket posture + fill witness + exactness class** together when relevant;
- hygiene that refuses to let new gap/fill sources drift out of the bibliography, source register, queue, front door, or manifest.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new gap/fill sources that are now directly shaping datacube posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- rerun the repo hygiene checks after the ledger and front-door refresh.

## Still-not-yet decisions
- engine choice;
- one canonical time spine or densification substrate;
- one mandatory machine-readable gap/fill schema;
- one default fill method for future repeated questions;
- one rule that every future metric card must already know whether sparse omission or synthetic alignment is globally preferred.
