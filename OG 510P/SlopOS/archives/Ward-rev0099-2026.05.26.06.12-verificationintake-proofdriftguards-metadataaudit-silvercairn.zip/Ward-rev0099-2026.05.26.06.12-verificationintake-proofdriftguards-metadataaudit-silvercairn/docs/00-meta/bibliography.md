- **EXT-NIST-63-4-2025** — NIST SP 800-63-4 Digital Identity Guidelines — https://pages.nist.gov/800-63-4/sp800-63.html
- **EXT-SLSA-TRACKS-2026** — SLSA tracks (working draft) — https://slsa.dev/spec/draft/tracks
# Bibliography

- **EXT-WEBAUTHN-3** — W3C Web Authentication: Level 3 — https://www.w3.org/TR/webauthn-3/
- **EXT-RFC-9334** — IETF RFC 9334, RATS Architecture — https://www.rfc-editor.org/rfc/rfc9334.html
- **EXT-RFC-9711** — IETF RFC 9711, The Entity Attestation Token (EAT) — https://www.rfc-editor.org/rfc/rfc9711.html
- **EXT-TUF-DOCS** — TUF roles and metadata — https://theupdateframework.io/docs/metadata/
- **EXT-TUF-SPEC-2026** — The Update Framework specification — https://theupdateframework.github.io/specification/latest/
- **EXT-SLSA-PROVENANCE** — SLSA Build Provenance — https://slsa.dev/spec/draft/build-provenance
- **EXT-DBSC** — W3C Device Bound Session Credentials — https://www.w3.org/TR/dbsc/
- **EXT-FIDO-PASSKEYS** — FIDO Alliance, Passkeys — https://fidoalliance.org/passkeys/
- **EXT-FIDO-DPCS** — FIDO Alliance, Device-bound passkeys overview — https://passkeycentral.org/introduction-to-passkeys/passkey-types
- **EXT-NIST-SYNCABLE** — NIST syncable authenticators guidance — https://pages.nist.gov/800-63-4/sp800-63b/syncable/
- **EXT-NIST-63B-SUP1** — NIST SP 800-63B Supplement 1 — https://csrc.nist.gov/pubs/sp/800/63/b/sup/final
- **EXT-SLSA-PROVENANCE-APPROVED** — SLSA provenance overview — https://slsa.dev/provenance
- **EXT-SLSA-PROVENANCE-SPEC** — SLSA provenance spec — https://slsa.dev/spec/v1.0/provenance
- **EXT-DBSC-CHROME** — Chrome DBSC overview — https://developer.chrome.com/docs/web-platform/device-bound-session-credentials
- **EXT-OAUTH-CROSS-DEVICE-2025** — IETF draft, Cross-Device Flows: Security Best Current Practice — https://datatracker.ietf.org/doc/draft-ietf-oauth-cross-device-security/
- **EXT-WEBAUTHN-3-2026** — W3C WebAuthn Level 3 — https://www.w3.org/TR/webauthn-3/
- **EXT-FIDO-PASSKEYS-2025** — FIDO Alliance, Passkeys — https://fidoalliance.org/passkeys/
- **EXT-DBSC-2025** — Chrome Developers, Device Bound Session Credentials — https://developer.chrome.com/docs/web-platform/device-bound-session-credentials
- **EXT-SLSA-V1** — SLSA Provenance v1.0 — https://slsa.dev/spec/v1.0/provenance
- **EXT-TUF-ROLES-2025** — TUF roles and metadata — https://theupdateframework.io/docs/metadata/
- **EXT-TUF-SPEC-LATEST-2026** — The Update Framework specification — https://theupdateframework.github.io/specification/latest/
- **EXT-SLSA-PROVENANCE-V1** — SLSA provenance v1.0 — https://slsa.dev/spec/v1.0/provenance

- **EXT-SCITT-ARCH-2026** — IETF SCITT architecture draft — https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
- **EXT-KEYTRANSPARENCY** — Google Key Transparency — https://github.com/google/keytransparency
- **EXT-SIGSTORE-KEYLESS** — Sigstore keyless signing overview — https://docs.sigstore.dev/cosign/signing/overview/

- **EXT-SIGSTORE-BUNDLE** — Sigstore bundle format — https://docs.sigstore.dev/about/bundle/
- **EXT-REKOR-EVENT-STREAM** — Sigstore Rekor event stream — https://docs.sigstore.dev/logging/event_stream/
- **EXT-KEYTRANS-WG** — IETF KEYTRANS working group goals — https://datatracker.ietf.org/wg/keytrans/about/
- **EXT-KEYTRANS-ARCH-2026** — IETF KEYTRANS architecture draft — https://datatracker.ietf.org/doc/draft-ietf-keytrans-architecture/

- **EXT-SCITT-SCRAPI-2026** — IETF SCITT Reference APIs draft — https://datatracker.ietf.org/doc/draft-ietf-scitt-scrapi/

- **EXT-SCITT-RECEIPTS-CCF-2026** — IETF SCITT receipts CCF profile draft — https://datatracker.ietf.org/doc/draft-ietf-scitt-receipts-ccf-profile/

- **EXT-SIGSTORE-BUNDLE-2025** — Sigstore bundle format — https://docs.sigstore.dev/about/bundle/

- **EXT-KEYTRANS-PROTOCOL-2026** — IETF Key Transparency Protocol draft — https://ietf-wg-keytrans.github.io/draft-protocol/draft-ietf-keytrans-protocol.html
- **EXT-SCITT-ARCH-2026-LATEST** — IETF SCITT architecture draft (latest) — https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
- **EXT-SIGSTORE-SECURITY** — Sigstore security model — https://docs.sigstore.dev/about/security/

- **EXT-VC-BITSTRING-STATUS-LIST** — W3C Bitstring Status List v1.0 — https://www.w3.org/TR/vc-bitstring-status-list/
- **EXT-VC-DATA-MODEL-2-0** — W3C Verifiable Credentials Data Model v2.0 — https://www.w3.org/TR/vc-data-model-2.0/
- **EXT-VC-DATA-INTEGRITY** — W3C Verifiable Credential Data Integrity 1.0 — https://www.w3.org/TR/vc-data-integrity/
- **EXT-VC-DI-BBS** — W3C Data Integrity BBS Cryptosuites v1.0 — https://www.w3.org/TR/vc-di-bbs/
- **EXT-OPENID-SSF-2025** — OpenID Shared Signals Framework 1.0 — https://openid.net/specs/openid-sharedsignals-framework-1_0.html
- **EXT-OPENID-CAEP-2025** — OpenID Continuous Access Evaluation Profile 1.0 — https://openid.net/specs/openid-caep-1_0-final.html
- **EXT-OPENID-RISC-2025** — OpenID RISC Profile Specification 1.0 — https://openid.net/specs/openid-risc-1_0-final.html
- **EXT-RFC-7009** — IETF RFC 7009, OAuth 2.0 Token Revocation — https://www.rfc-editor.org/rfc/rfc7009.html
- **EXT-RFC-7662** — IETF RFC 7662, OAuth 2.0 Token Introspection — https://www.rfc-editor.org/rfc/rfc7662.html
- **EXT-RFC-8417** — IETF RFC 8417, Security Event Token (SET) — https://www.rfc-editor.org/rfc/rfc8417.html
- **EXT-RFC-8935** — IETF RFC 8935, Push-Based SET Delivery Using HTTP — https://www.rfc-editor.org/rfc/rfc8935.html
- **EXT-RFC-8936** — IETF RFC 8936, Poll-Based SET Delivery Using HTTP — https://www.rfc-editor.org/rfc/rfc8936.html
- **EXT-RFC-9162** — IETF RFC 9162, Certificate Transparency Version 2.0 — https://www.rfc-editor.org/rfc/rfc9162.html
- **EXT-RFC-9493** — IETF RFC 9493, Subject Identifiers for Security Event Tokens — https://www.rfc-editor.org/rfc/rfc9493.html
- **EXT-RFC-9608** — IETF RFC 9608, No Revocation Available for X.509 Public Key Certificates — https://www.rfc-editor.org/rfc/rfc9608.html
- **EXT-OAUTH-TSL-2026** — IETF OAuth Token Status List draft-19 — https://datatracker.ietf.org/doc/draft-ietf-oauth-status-list/

- **EXT-RFC-5280** — IETF RFC 5280, PKIX Certificate and CRL Profile — https://www.rfc-editor.org/rfc/rfc5280.html
- **EXT-RFC-6960** — IETF RFC 6960, Online Certificate Status Protocol (OCSP) — https://www.rfc-editor.org/rfc/rfc6960.html
- **EXT-CRLITE-DESIGN-2020** — Mozilla Security Blog, The End-to-End Design of CRLite — https://blog.mozilla.org/security/2020/01/09/crlite-part-2-end-to-end-design/
- **EXT-CRLITE-FIREFOX-2025** — Mozilla Hacks, CRLite: Fast, private, and comprehensive certificate revocation checking in Firefox — https://hacks.mozilla.org/2025/08/crlite-fast-private-and-comprehensive-certificate-revocation-checking-in-firefox/
- **EXT-REKOR-OVERVIEW** — Sigstore Rekor overview — https://docs.sigstore.dev/logging/overview/

- **EXT-RFC-8481** — IETF RFC 8481, Clarifications to BGP Origin Validation Based on Resource Public Key Infrastructure (RPKI) — https://www.rfc-editor.org/rfc/rfc8481.html
- **EXT-RFC-7115** — IETF RFC 7115, Origin Validation Operation Based on the Resource Public Key Infrastructure (RPKI) — https://www.rfc-editor.org/rfc/rfc7115.html
- **EXT-CABF-SC063V4** — CA/Browser Forum Ballot SC063v4, Make OCSP Optional, Require CRLs, and Incentivize Automation — https://cabforum.org/2023/07/14/ballot-sc063v4-make-ocsp-optional-require-crls-and-incentivize-automation/
- **EXT-LE-OCSP-2025** — Let's Encrypt, Ending OCSP Support in 2025 — https://letsencrypt.org/2024/12/05/ending-ocsp
- **EXT-EAR-2026** — IETF draft-ietf-rats-ear-03, EAT Attestation Results — https://datatracker.ietf.org/doc/draft-ietf-rats-ear/03/
- **EXT-SLSA-GET-STARTED** — SLSA get started guidance — https://slsa.dev/how-to/get-started
- **EXT-IN-TOTO-GETTING-STARTED** — in-toto getting started — https://in-toto.io/docs/getting-started/
- **EXT-SIGSTORE-POLICY-CONTROLLER** — Sigstore policy-controller overview — https://docs.sigstore.dev/policy-controller/overview/

- **EXT-DYNAMO-SOSP-2007** — DeCandia et al., *Dynamo: Amazon's Highly Available Key-value Store* — https://www.allthingsdistributed.com/files/amazon-dynamo-sosp2007.pdf
- **EXT-RIAK-CONFLICT-RESOLUTION** — Riak KV conflict resolution docs — https://docs.riak.com/riak/kv/latest/developing/usage/conflict-resolution/index.html
- **EXT-RIAK-CAUSAL-CONTEXT** — Riak KV causal context / dotted version vectors — https://docs.riak.com/riak/kv/latest/learn/concepts/causal-context/index.html
- **EXT-KAFKA-LOG-COMPACTION** — Apache Kafka design docs: log compaction — https://kafka.apache.org/42/design/design/
- **EXT-KAFKA-BROKER-CONFIGS-2026** — Apache Kafka broker configs (`log.cleaner.delete.retention.ms`) — https://kafka.apache.org/42/configuration/broker-configs/
- **EXT-BEAM-PROGRAMMING-GUIDE-2026** — Apache Beam Programming Guide — https://beam.apache.org/documentation/programming-guide/
- **EXT-FLINK-STREAMING-ANALYTICS-2026** — Apache Flink Streaming Analytics docs — https://nightlies.apache.org/flink/flink-docs-stable/docs/learn-flink/streaming_analytics/
- **EXT-KAFKA-STREAMS-CORE-CONCEPTS-2026** — Apache Kafka Streams Core Concepts — https://kafka.apache.org/42/streams/core-concepts/
- **EXT-KAFKA-STREAMS-UPGRADE-2026** — Apache Kafka Streams Upgrade Guide — https://kafka.apache.org/42/streams/upgrade-guide/
- **EXT-MATERIALIZE-SELF-CORRECTING-2026** — Materialize, Self-Correcting Materialized Views — https://materialize.com/blog/self-correcting-materialized-views/

- **EXT-CALM-2019** — Hellerstein and Alvaro, *Keeping CALM: When Distributed Consistency is Easy* — https://arxiv.org/pdf/1901.01930
- **EXT-BLOOM-CALM-2011** — Alvaro et al., *Consistency Analysis in Bloom: a CALM and Collected Approach* — https://www.cidrdb.org/cidr2011/Papers/CIDR11_Paper35.pdf
- **EXT-PROVENANCE-SEMIRINGS-2007** — Green et al., *Provenance Semirings* — https://web.cs.ucdavis.edu/~green/papers/pods07.pdf
- **EXT-TRUTH-MAINTENANCE-1990** — McAllester, *Truth Maintenance* — https://cdn.aaai.org/AAAI/1990/AAAI90-164.pdf
- **EXT-MATERIALIZE-ARRANGEMENTS-2026** — Materialize documentation, Arrangements — https://materialize.com/docs/get-started/arrangements/
- **EXT-DIFFERENTIAL-ARRANGEMENTS** — Differential Dataflow documentation, Arrangements — https://timelydataflow.github.io/differential-dataflow/chapter_5/chapter_5.html

- **EXT-GIT-SYMBOLIC-REF-2026** — Git symbolic-ref documentation — https://git-scm.com/docs/git-symbolic-ref
- **EXT-GIT-REFLOG-2026** — Git reflog documentation — https://git-scm.com/docs/git-reflog
- **EXT-ICEBERG-SNAPSHOT-REFS-2026** — Apache Iceberg specification, snapshot references — https://iceberg.apache.org/spec/
- **EXT-ICEBERG-BRANCHING-2026** — Apache Iceberg branching and tagging docs — https://iceberg.apache.org/docs/latest/branching/
- **EXT-DELTA-TIME-TRAVEL-2026** — Delta Lake batch reads and writes / time travel — https://docs.delta.io/delta-batch/
- **EXT-LAKEFS-GC-2026** — lakeFS garbage collection docs — https://docs.lakefs.io/v1.79/howto/garbage-collection/gc/
- **EXT-AVRO-SPEC-2026** — Apache Avro specification — https://avro.apache.org/docs/1.11.1/specification/
- **EXT-ICEBERG-EVOLUTION-2026** — Apache Iceberg schema evolution docs — https://iceberg.apache.org/docs/1.7.1/evolution/
- **EXT-ICEBERG-SCHEMA-SPEC-2026** — Apache Iceberg specification, field IDs and column projection — https://iceberg.apache.org/spec/
- **EXT-PROTOBUF-PROTO3-2026** — Protocol Buffers language guide (proto3) — https://protobuf.dev/programming-guides/proto3/
- **EXT-PROTOBUF-FIELD-PRESENCE-2026** — Protocol Buffers field presence application note — https://protobuf.dev/programming-guides/field_presence/
- **EXT-CONFLUENT-SCHEMA-EVOLUTION-2026** — Confluent Schema Registry evolution and compatibility docs — https://docs.confluent.io/platform/current/schema-registry/fundamentals/schema-evolution.html
- **EXT-RFC-7515** — RFC 7515, JSON Web Signature (JWS) — https://datatracker.ietf.org/doc/html/rfc7515
- **EXT-RFC-9052** — RFC 9052, CBOR Object Signing and Encryption (COSE): Structures and Process — https://datatracker.ietf.org/doc/html/rfc9052
- **EXT-AUTHLIB-CRIT-2025** — GitHub advisory, Authlib accepts unknown `crit` headers — https://github.com/authlib/authlib/security/advisories/GHSA-9ggr-2464-2j32
- **EXT-PYJWT-CRIT-2026** — GitHub advisory, PyJWT accepts unknown `crit` headers — https://github.com/advisories/GHSA-752w-5fwx-jx9f

- **EXT-SIGSUM-DESIGN-2026** — Sigsum design notes (witness cosigning and monitoring) — https://git.sigsum.org/sigsum/tree/doc/design.md
- **EXT-MERKLE-TREE-CERTS-2026** — IETF Merkle Tree Certificates draft-02 — https://www.ietf.org/archive/id/draft-ietf-plants-merkle-tree-certs-02.html
- **EXT-RAFT-2014** — Ongaro and Ousterhout, *In Search of an Understandable Consensus Algorithm (Raft)* — https://raft.github.io/raft.pdf
- **EXT-KAFKA-PRODUCER-CONFIGS-2026** — Apache Kafka producer configs — https://kafka.apache.org/41/configuration/producer-configs/
- **EXT-KAFKA-CONSUMER-CONFIGS-2026** — Apache Kafka consumer configs — https://kafka.apache.org/22/configuration/consumer-configs/
- **EXT-MONGODB-WRITE-CONCERN-2026** — MongoDB write concern docs — https://www.mongodb.com/docs/manual/reference/write-concern/
- **EXT-MONGODB-READ-CONCERN-MAJORITY-2026** — MongoDB read concern `"majority"` docs — https://www.mongodb.com/docs/manual/reference/read-concern-majority/
- **EXT-ETHEREUM-POS-2026** — Ethereum.org proof-of-stake docs — https://ethereum.org/developers/docs/consensus-mechanisms/pos/

- **EXT-CHUBBY-OSDI-2006** — Burrows, *The Chubby lock service for loosely-coupled distributed systems* — https://research.google.com/archive/chubby-osdi06.pdf
- **EXT-ZOOKEEPER-RECIPES** — Apache ZooKeeper Recipes and Solutions — https://zookeeper.apache.org/doc/r3.4.14/recipes.html
- **EXT-ETCD-LOCKING-2025** — etcd, notes on the usage of lock and lease — https://etcd.io/docs/v3.5/learning/why/
- **EXT-KAFKA-PROTOCOL-2026** — Apache Kafka protocol/error semantics — https://kafka.apache.org/protocol/

- **EXT-K8S-API-CONVENTIONS-2026** — Kubernetes API conventions — https://github.com/kubernetes/community/blob/main/contributors/devel/sig-architecture/api-conventions.md
- **EXT-K8S-FINALIZERS-2026** — Kubernetes Finalizers docs — https://kubernetes.io/docs/concepts/overview/working-with-objects/finalizers/
- **EXT-K8S-PODS-2026** — Kubernetes Pods docs — https://kubernetes.io/docs/concepts/workloads/pods/
- **EXT-CASSANDRA-TOMBSTONES-2026** — Apache Cassandra Documentation, Tombstones — https://cassandra.apache.org/doc/latest/cassandra/managing/operating/compaction/tombstones.html
- **EXT-S3-DELETE-MARKERS-2026** — Amazon S3 User Guide, Working with delete markers — https://docs.aws.amazon.com/AmazonS3/latest/userguide/DeleteMarker.html
- **EXT-S3-MANAGING-DELETE-MARKERS-2026** — Amazon S3 User Guide, Managing delete markers — https://docs.aws.amazon.com/AmazonS3/latest/userguide/ManagingDelMarkers.html
- **EXT-ICEBERG-MAINTENANCE-2026** — Apache Iceberg Documentation, Maintenance — https://iceberg.apache.org/docs/latest/maintenance/
- **EXT-MONGODB-CHANGE-STREAMS-2026** — MongoDB Database Manual, Change Streams — https://www.mongodb.com/docs/manual/changestreams/
- **EXT-POSTGRES-REPLICATION-SLOTS-2026** — PostgreSQL documentation, `pg_replication_slots` — https://www.postgresql.org/docs/current/view-pg-replication-slots.html
- **EXT-DEBEZIUM-MYSQL-2026** — Debezium MySQL connector docs — https://debezium.io/documentation/reference/stable/connectors/mysql.html
- **EXT-DEBEZIUM-DB2-2026** — Debezium Db2 connector docs — https://debezium.io/documentation/reference/stable/connectors/db2.html

- **EXT-SPANNER-TIMESTAMP-BOUNDS-2026** — Cloud Spanner documentation, Timestamp bounds — https://docs.cloud.google.com/spanner/docs/timestamp-bounds
- **EXT-SPANNER-TRUETIME-2026** — Cloud Spanner documentation, TrueTime and external consistency — https://docs.cloud.google.com/spanner/docs/true-time-external-consistency
- **EXT-COCKROACH-FOLLOWER-READS-2026** — CockroachDB documentation, Follower Reads — https://www.cockroachlabs.com/docs/stable/follower-reads
- **EXT-YUGABYTE-READ-RESTART-2026** — YugabyteDB documentation, Read Restart error — https://docs.yugabyte.com/stable/architecture/transactions/read-restart-error/
- **EXT-FOUNDATIONDB-DEVELOPER-GUIDE-2026** — FoundationDB documentation, Developer Guide (snapshot reads and conflict ranges) — https://apple.github.io/foundationdb/developer-guide.html
- **EXT-DATOMIC-CLIENT-API-2026** — Datomic client API documentation — https://docs.datomic.com/client-api/datomic.client.api.html
- **EXT-DATOMIC-FILTERS-2026** — Datomic database filters documentation — https://docs.datomic.com/reference/filters.html
- **EXT-HONEYCOMB-EVENTS-2026** — Honeycomb docs, Events, Metrics, and Logs — https://docs.honeycomb.io/get-started/basics/observability/concepts/events-metrics-logs
- **EXT-HONEYCOMB-BUBBLEUP-2026** — Honeycomb docs, Investigate Application Data / BubbleUp — https://docs.honeycomb.io/investigate/debug/application-data-in-honeycomb
- **EXT-HONEYCOMB-BUILD-QUERY-2026** — Honeycomb docs, Build a Query — https://docs.honeycomb.io/investigate/query/build
- **EXT-MATERIALIZE-RELEASES-2026** — Materialize release notes (replacement materialized views) — https://materialize.com/docs/releases/
- **EXT-MATERIALIZE-OP-CONSISTENCY-2026** — Materialize blog, Consistency and Operational Confidence — https://materialize.com/blog/operational-consistency/
- **EXT-CLICKHOUSE-PROJECTIONS-2026** — ClickHouse docs, Projections — https://clickhouse.com/docs/data-modeling/projections
- **EXT-PINOT-STAR-TREE-2026** — Apache Pinot docs, Star-Tree Index — https://docs.pinot.apache.org/indexing/star-tree-index

- **EXT-DUCKDB-ASOF-JOIN-2026** — DuckDB documentation, AsOf Join — https://duckdb.org/docs/stable/guides/sql_features/asof_join
- **EXT-ICEBERG-WAP-2026** — Apache Iceberg Spark writes / WAP branch docs — https://iceberg.apache.org/docs/1.8.0/spark-writes/
- **EXT-MATERIALIZE-REPLACEMENT-MV-2026** — Materialize docs, CREATE MATERIALIZED VIEW / replacement materialized views — https://materialize.com/docs/sql/create-materialized-view/
- **EXT-DELTA-CDF-2026** — Delta Lake change data feed — https://docs.delta.io/delta-change-data-feed/
- **EXT-DBT-SEMANTIC-ARCH-2026** — dbt Semantic Layer architecture — https://docs.getdbt.com/docs/use-dbt-semantic-layer/sl-architecture
- **EXT-DRUID-ROLLUP-2026** — Apache Druid documentation, data rollup — https://druid.apache.org/docs/latest/ingestion/rollup/

- **EXT-BIGQUERY-APPROX-AGG-2026** — BigQuery documentation, Approximate aggregate functions — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/approximate_aggregate_functions
- **EXT-DUCKDB-APPROX-AGG-2026** — DuckDB documentation, Approximate aggregates — https://duckdb.org/docs/stable/sql/functions/aggregates.html
- **EXT-DRUID-DATASKETCHES-2026** — Apache Druid documentation, DataSketches extension — https://druid.apache.org/docs/latest/development/extensions-core/datasketches-extension/
- **EXT-DATASKETCHES-THETA-2026** — Apache DataSketches documentation, Theta Sketch Framework — https://datasketches.apache.org/docs/Theta/ThetaSketches.html

- **EXT-CUBE-ADDITIVITY-2026** — Cube documentation, Concepts / Measure additivity — https://cube.dev/docs/product/data-modeling/concepts
- **EXT-DAX-DISTINCTCOUNT-2026** — Microsoft Learn, `DISTINCTCOUNT` function (DAX) — https://learn.microsoft.com/en-us/dax/distinctcount-function-dax
- **EXT-SSAS-SEMIADDITIVE-2025** — Microsoft Learn, Define Semiadditive Behavior — https://learn.microsoft.com/en-us/analysis-services/multidimensional-models/define-semiadditive-behavior?view=sql-analysis-services-2025
- **EXT-CLICKHOUSE-AGGREGATEFUNCTION-2026** — ClickHouse docs, `AggregateFunction` Type — https://clickhouse.com/docs/sql-reference/data-types/aggregatefunction

- **EXT-LOOKER-SYMMETRIC-AGG-2026** — Looker documentation, Understanding symmetric aggregates — https://docs.cloud.google.com/looker/docs/best-practices/understanding-symmetric-aggregates
- **EXT-DBT-METRICFLOW-JOINS-2026** — dbt Developer Hub, Joins — https://docs.getdbt.com/docs/build/join-logic
- **EXT-CUBE-MULTI-STAGE-2026** — Cube documentation, Multi-stage calculations — https://cube.dev/docs/product/data-modeling/concepts/multi-stage-calculations
- **EXT-DBT-RATIO-METRICS-2026** — dbt Developer Hub, Ratio metrics — https://docs.getdbt.com/docs/build/ratio
- **EXT-DUCKDB-WEIGHTED-AVG-2026** — DuckDB documentation, Aggregate functions / weighted_avg — https://duckdb.org/docs/stable/sql/functions/aggregates
- **EXT-CLICKHOUSE-AVGWEIGHTED-2026** — ClickHouse documentation, avgWeighted — https://clickhouse.com/docs/sql-reference/aggregate-functions/reference/avgweighted

- **EXT-DBT-FILL-NULLS-2026** — dbt Developer Hub, Fill null values for metrics — https://docs.getdbt.com/docs/build/fill-nulls-advanced
- **EXT-BIGQUERY-GAP-FILL-2026** — BigQuery documentation, Work with time series data — https://docs.cloud.google.com/bigquery/docs/working-with-time-series
- **EXT-TIGERDATA-GAPFILL-2026** — Tiger Data documentation, Time bucket gapfill — https://www.tigerdata.com/docs/use-timescale/latest/hyperfunctions/gapfilling-interpolation/time-bucket-gapfill
- **EXT-PROMETHEUS-STALENESS-2026** — Prometheus documentation, Querying basics — https://prometheus.io/docs/prometheus/latest/querying/basics/

- **EXT-DBT-CUMULATIVE-2026** — dbt Developer Hub, Cumulative metrics — https://docs.getdbt.com/docs/build/cumulative
- **EXT-BIGQUERY-WINDOW-FRAME-2026** — Google Cloud BigQuery docs, Window function calls — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/window-function-calls
- **EXT-DUCKDB-WINDOWS-2026** — DuckDB docs, Window Functions — https://duckdb.org/docs/stable/sql/functions/window_functions
- **EXT-PROMETHEUS-RANGE-VECTORS-2026** — Prometheus docs, Querying basics — https://prometheus.io/docs/prometheus/latest/querying/basics/
- **EXT-PROMETHEUS-FUNCTIONS-2026** — Prometheus docs, Query functions — https://prometheus.io/docs/prometheus/latest/querying/functions/

- **EXT-BIGQUERY-AUTHORIZED-VIEWS-2026** — BigQuery documentation, Create an authorized view — https://docs.cloud.google.com/bigquery/docs/create-authorized-views
- **EXT-BIGQUERY-RLS-INTRO-2026** — BigQuery documentation, Introduction to row-level security — https://docs.cloud.google.com/bigquery/docs/row-level-security-intro
- **EXT-LOOKER-ACCESS-FILTER-2026** — Looker documentation, `access_filter` parameter — https://docs.cloud.google.com/looker/docs/reference/param-explore-access-filter
- **EXT-DBT-SL-PERMISSIONS-2026** — dbt Developer Hub, Semantic Layer FAQs / permissions and access — https://docs.getdbt.com/docs/use-dbt-semantic-layer/sl-faqs
- **EXT-BIGQUERY-TIMESTAMP-FUNCTIONS-2026** — Google Cloud BigQuery docs, Timestamp functions — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/timestamp_functions
- **EXT-BIGQUERY-DATE-FUNCTIONS-2026** — Google Cloud BigQuery docs, Date functions — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/date_functions
- **EXT-TIGERDATA-TIME-BUCKET-2026** — Tiger Data documentation, `time_bucket()` — https://www.tigerdata.com/docs/api/latest/hyperfunctions/time_bucket
- **EXT-DUCKDB-TIMESTAMPTZ-2026** — DuckDB documentation, Timestamp with Time Zone Functions — https://duckdb.org/docs/stable/sql/functions/timestamptz
- **EXT-DRUID-SQL-SCALAR-TIME-2026** — Apache Druid documentation, SQL scalar date/time functions — https://druid.apache.org/docs/latest/querying/sql-scalar/

- **EXT-OTEL-METRICS-DATA-MODEL-2026** — OpenTelemetry specification, Metrics Data Model — https://opentelemetry.io/docs/specs/otel/metrics/data-model/
- **EXT-OTEL-METRICS-CONCEPTS-2026** — OpenTelemetry docs, Metrics concepts — https://opentelemetry.io/docs/concepts/signals/metrics/
- **EXT-PROMETHEUS-WRITING-EXPORTERS-2026** — Prometheus docs, Writing exporters — https://prometheus.io/docs/instrumenting/writing_exporters/
- **EXT-GRAFANA-STANDARD-OPTIONS-2026** — Grafana docs, Configure standard options — https://grafana.com/docs/grafana/latest/visualizations/panels-visualizations/configure-standard-options/

- **EXT-BIGQUERY-TABLESAMPLE-2026** — BigQuery documentation, Table sampling — https://docs.cloud.google.com/bigquery/docs/table-sampling
- **EXT-DUCKDB-SAMPLES-2026** — DuckDB documentation, Samples — https://duckdb.org/docs/stable/sql/samples
- **EXT-CLICKHOUSE-SAMPLE-2026** — ClickHouse documentation, SAMPLE clause — https://clickhouse.com/docs/sql-reference/statements/select/sample

- **EXT-PROMETHEUS-HISTOGRAMS-2026** — Prometheus docs, Histograms and summaries — https://prometheus.io/docs/practices/histograms/
- **EXT-PROMETHEUS-NATIVE-HISTOGRAMS-2026** — Prometheus docs, Native Histograms — https://prometheus.io/docs/specs/native_histograms/

- **EXT-PROMETHEUS-METRIC-TYPES-2026** — Prometheus docs, Metric types — https://prometheus.io/docs/concepts/metric_types/
- **EXT-OTEL-SUPPLEMENTARY-METRICS-2026** — OpenTelemetry specification, Supplementary guidelines for metrics — https://opentelemetry.io/docs/specs/otel/metrics/supplementary-guidelines/
- **EXT-OTEL-PROM-COMPAT-2026** — OpenTelemetry specification, Prometheus and OpenMetrics compatibility — https://opentelemetry.io/docs/specs/otel/compatibility/prometheus_and_openmetrics/
- **EXT-OPENMETRICS-2-0-2026** — Prometheus docs, OpenMetrics 2.0 — https://prometheus.io/docs/specs/om/open_metrics_spec_2_0/
- **EXT-DATADOG-METRIC-TYPES-2026** — Datadog docs, Metrics Types — https://docs.datadoghq.com/metrics/types/

- **EXT-BIGQUERY-INSERTALL-2026** — BigQuery REST reference, `tabledata.insertAll` — https://docs.cloud.google.com/bigquery/docs/reference/rest/v2/tabledata/insertAll
- **EXT-CLICKHOUSE-REPLACINGMERGETREE-2026** — ClickHouse docs, ReplacingMergeTree table engine — https://clickhouse.com/docs/engines/table-engines/mergetree-family/replacingmergetree
- **EXT-DEBEZIUM-POSTGRES-2026** — Debezium docs, PostgreSQL connector — https://debezium.io/documentation/reference/stable/connectors/postgresql.html
- **EXT-DBT-SNAPSHOTS-2026** — dbt Developer Hub, Add snapshots to your DAG — https://docs.getdbt.com/docs/build/snapshots
- **EXT-DBT-HARD-DELETES-2026** — dbt Developer Hub, `hard_deletes` — https://docs.getdbt.com/reference/resource-configs/hard-deletes



- **EXT-BIGQUERY-DIFFERENTIAL-PRIVACY-2026** — BigQuery documentation, Use differential privacy — https://docs.cloud.google.com/bigquery/docs/differential-privacy
- **EXT-BIGQUERY-DP-FUNCTIONS-2026** — BigQuery documentation, Differentially private aggregate functions — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/aggregate-dp-functions
- **EXT-AWS-CLEANROOMS-ANALYSIS-RULES-2026** — AWS Clean Rooms User Guide, Analysis rules in AWS Clean Rooms — https://docs.aws.amazon.com/clean-rooms/latest/userguide/analysis-rules.html
- **EXT-AWS-CLEANROOMS-DP-POLICY-2026** — AWS Clean Rooms User Guide, Configuring differential privacy policy — https://docs.aws.amazon.com/clean-rooms/latest/userguide/configure-differential-privacy.html
- **EXT-SNOWFLAKE-DIFF-PRIVACY-2026** — Snowflake Documentation, Differential privacy in Snowflake — https://docs.snowflake.com/en/user-guide/diff-privacy/differential-privacy-overview
- **EXT-OPENDP-MEASUREMENTS-2026** — OpenDP documentation, `opendp.measurements` module — https://docs.opendp.org/en/stable/api/python/opendp.measurements.html

- **EXT-PROMETHEUS-QUERY-API-2026** — Prometheus documentation, HTTP API / range queries — https://prometheus.io/docs/prometheus/latest/querying/api/
- **EXT-THANOS-QUERY-2026** — Thanos documentation, Querier / Query — https://thanos.io/tip/components/query.md/
- **EXT-THANOS-COMPACTOR-2026** — Thanos documentation, Compactor / downsampling and retention — https://thanos.io/tip/components/compact.md/
- **EXT-DATADOG-ROLLUP-2026** — Datadog documentation, Rollup — https://docs.datadoghq.com/dashboards/functions/rollup/
- **EXT-TIGERDATA-RETENTION-CAGG-2026** — Tiger Data documentation, data retention with continuous aggregates — https://www.tigerdata.com/docs/use-timescale/latest/data-retention/data-retention-with-continuous-aggregates
- **EXT-TIGERDATA-REALTIME-AGG-2026** — Tiger Data documentation, real-time aggregates — https://www.tigerdata.com/docs/use-timescale/latest/continuous-aggregates/real-time-aggregates
- **EXT-DATACUBE-GRAY-1997** — Gray et al., Data Cube: A Relational Aggregation Operator Generalizing Group-By, Cross-Tab, and Sub-Totals — https://arxiv.org/abs/cs/0701155
- **EXT-KIMBALL-GRAIN-2003** — Kimball Group, Grain — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/grain/
- **EXT-W3C-RDF-DATACUBE-2014** — W3C RDF Data Cube Vocabulary — https://www.w3.org/TR/vocab-data-cube/
- **EXT-ICEBERG-HIDDEN-PARTITIONING-2026** — Apache Iceberg docs, Partitioning and hidden partitioning — https://iceberg.apache.org/docs/latest/partitioning/
- **EXT-SUBSTRAIT-PRINCIPLES-2026** — Substrait Technology Principles — https://substrait.io/spec/technology_principles/
- **EXT-SUBSTRAIT-RELATIONS-2026** — Substrait Relations Basics — https://substrait.io/relations/basics/
- **EXT-OPENLINEAGE-OBJECT-MODEL-2026** — OpenLineage Object Model — https://openlineage.io/docs/spec/object-model/
- **EXT-ARROW-COLUMNAR-2026** — Apache Arrow Columnar Format — https://arrow.apache.org/docs/format/Columnar.html
- **EXT-ARROW-C-DATA-2026** — Apache Arrow C Data Interface — https://arrow.apache.org/docs/format/CDataInterface.html
- **EXT-TILEDB-ARRAY-MODEL-2026** — TileDB introduction, array data model and dense/sparse arrays — https://tiledb-inc-tiledb.readthedocs-hosted.com/en/1.6.3/introduction.html

- **EXT-DBT-SEMANTIC-MODELS-2026** — dbt Developer Hub, Semantic models — https://docs.getdbt.com/docs/build/semantic-models
- **EXT-DBT-METRICFLOW-2026** — dbt Developer Hub, About MetricFlow — https://docs.getdbt.com/docs/build/about-metricflow
- **EXT-DBT-SEMANTIC-LAYER-AI-BENCH-2026** — dbt Developer Blog, Semantic Layer vs. Text-to-SQL: 2026 Benchmark Update — https://docs.getdbt.com/blog/semantic-layer-vs-text-to-sql-2026
- **EXT-DUCKDB-GROUPING-SETS-2026** — DuckDB documentation, GROUPING SETS / ROLLUP / CUBE — https://duckdb.org/docs/current/sql/query_syntax/grouping_sets.html
- **EXT-CLICKHOUSE-GROUPING-SETS-2026** — ClickHouse documentation, GROUPING function and grouping sets — https://clickhouse.com/docs/sql-reference/aggregate-functions/grouping_function
- **EXT-XARRAY-DATA-STRUCTURES-2026** — Xarray documentation, Data structures — https://docs.xarray.dev/en/latest/user-guide/data-structures.html
- **EXT-TILEDB-DIMENSIONS-2026** — TileDB Academy, Dimensions — https://cloud.tiledb.com/academy/structure/arrays/foundation/key-concepts/storage/dimensions/
- **EXT-ARROW-SECURITY-MODEL-2026** — Apache Arrow blog, Introducing a Security Model for Arrow — https://arrow.apache.org/blog/2026/02/09/arrow-security-model/
- **EXT-DBT-MODEL-CONTRACTS-2026** — dbt Developer Hub, Model contracts — https://docs.getdbt.com/docs/mesh/govern/model-contracts
- **EXT-DBT-MODEL-VERSIONS-2026** — dbt Developer Hub, Model versions — https://docs.getdbt.com/docs/mesh/govern/model-versions
- **EXT-ODCS-3-1-2026** — Open Data Contract Standard v3.1.0 definition — https://bitol-io.github.io/open-data-contract-standard/v3.1.0/
- **EXT-GX-CHECKPOINT-ACTIONS-2026** — Great Expectations docs, Create a Checkpoint with Actions — https://docs.greatexpectations.io/docs/core/trigger_actions_based_on_results/create_a_checkpoint_with_actions/
- **EXT-KIMBALL-TYPE2-SCD-2008** — Kimball Group, Type 2: Add New Row — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/type-2/
- **EXT-OPENLINEAGE-FACETS-2026** — OpenLineage docs, Facets & Extensibility — https://openlineage.io/docs/spec/facets/
- **EXT-W3C-PROV-DM-2013** — W3C, PROV-DM: The PROV Data Model — https://www.w3.org/TR/prov-dm/
- **EXT-CHENEY-PROVENANCE-SURVEY-2009** — Cheney et al., Provenance in Databases: Why, How, and Where — https://dl.acm.org/doi/10.1561/1900000006
- **EXT-OPENLINEAGE-COLUMN-LINEAGE-2026** — OpenLineage, Column Level Lineage Dataset Facet — https://openlineage.io/docs/spec/facets/dataset-facets/column_lineage_facet
- **EXT-DBT-UNIT-TESTS-2026** — dbt Developer Hub, Unit tests — https://docs.getdbt.com/docs/build/unit-tests
- **EXT-HONEYCOMB-OUTLIERS-BUBBLEUP-2026** — Honeycomb Docs, Identify Outliers / BubbleUp — https://docs.honeycomb.io/investigate/analyze/identify-outliers
- **EXT-OTEL-EXEMPLARS-2026** — OpenTelemetry docs, Using exemplars — https://opentelemetry.io/docs/languages/dotnet/metrics/exemplars/
- **EXT-DATAFOLD-DATA-DIFF-2026** — Datafold docs, What's a Data Diff? — https://docs.datafold.com/data-diff/what-is-data-diff
- **EXT-RELADIFF-TECH-2026** — Reladiff documentation, Technical explanation — https://reladiff.readthedocs.io/en/latest/technical-explanation.html
- **EXT-CAUSALIMPACT-2015** — Brodersen et al., Inferring causal impact using Bayesian structural time-series models — https://arxiv.org/abs/1506.00356

- **EXT-DBT-SOURCE-FRESHNESS-2026** — dbt Developer Hub, Source freshness — https://docs.getdbt.com/docs/deploy/source-freshness
- **EXT-SNOWFLAKE-DYNAMIC-TABLE-REFRESH-2026** — Snowflake Documentation, Understanding dynamic table initialization and refresh — https://docs.snowflake.com/en/user-guide/dynamic-tables-refresh
- **EXT-BIGQUERY-MV-INCREMENTAL-2026** — Google Cloud BigQuery docs, Use materialized views / incremental updates — https://docs.cloud.google.com/bigquery/docs/materialized-views-use
- **EXT-FELDERA-DBSP-2026** — Feldera Documentation, Feldera, DBSP and incremental view maintenance — https://docs.feldera.com/sql/intro/
- **EXT-DATABRICKS-MV-INCREMENTAL-2026** — Databricks documentation, Incremental refresh for materialized views — https://docs.databricks.com/aws/en/optimizations/incremental-refresh
- **EXT-CLICKHOUSE-MV-TYPES-2026** — ClickHouse Docs, Use materialized views — https://clickhouse.com/docs/best-practices/use-materialized-views
- **EXT-DRUID-COMPACTION-2026** — Apache Druid documentation, Compaction — https://druid.apache.org/docs/latest/data-management/compaction/


- **EXT-OTEL-TRACES-2026** — OpenTelemetry docs, Traces — https://opentelemetry.io/docs/concepts/signals/traces/
- **EXT-OTEL-LOGS-DATA-MODEL-2026** — OpenTelemetry specification, Logs Data Model — https://opentelemetry.io/docs/specs/otel/logs/data-model/
- **EXT-VEGA-LITE-PARAMETERS-2026** — Vega-Lite documentation, Dynamic Behaviors with Parameters — https://vega.github.io/vega-lite/docs/parameter.html
- **EXT-VEGA-LITE-TRANSFORMS-2026** — Vega-Lite documentation, Transformation — https://vega.github.io/vega-lite/docs/transform.html
- **EXT-METABASE-QUESTIONS-2026** — Metabase documentation, Questions — https://www.metabase.com/docs/latest/questions/introduction
- **EXT-METABASE-DASHBOARD-FILTERS-2026** — Metabase documentation, Dashboard filters and parameters — https://www.metabase.com/docs/latest/dashboards/filters
- **EXT-POWERBI-EXPORT-DATA-2026** — Microsoft Learn, Export data from a Power BI visualization — https://learn.microsoft.com/en-us/power-bi/visuals/power-bi-visualization-export-data
- **EXT-W3C-TABULAR-DATA-MODEL-2015** — W3C, Model for Tabular Data and Metadata on the Web — https://www.w3.org/TR/tabular-data-model/
- **EXT-W3C-WEB-ANNOTATION-2017** — W3C, Web Annotation Data Model — https://www.w3.org/TR/annotation-model/
- **EXT-DATASKETCHES-HLL-2026** — Apache DataSketches documentation, HLL Sketches — https://datasketches.apache.org/docs/HLL/HllSketches.html
- **EXT-DATASKETCHES-THETA-CI-2026** — Apache DataSketches documentation, Theta Sketch Confidence Intervals — https://datasketches.apache.org/docs/Theta/ThetaConfidenceIntervals.html
- **EXT-CLICKHOUSE-TDIGEST-2026** — ClickHouse docs, quantileTDigest aggregate function — https://clickhouse.com/docs/sql-reference/aggregate-functions/reference/quantiletdigest
- **EXT-CLICKHOUSE-UNIQ-2026** — ClickHouse docs, uniq aggregate function — https://clickhouse.com/docs/sql-reference/aggregate-functions/reference/uniq
- **EXT-OPENDP-TYPICAL-WORKFLOW-2026** — OpenDP documentation, Typical Workflow — https://docs.opendp.org/en/stable/getting-started/typical-workflow.html
- **EXT-GX-RESULT-FORMAT-2026** — Great Expectations docs, Choose a result format — https://docs.greatexpectations.io/docs/core/trigger_actions_based_on_results/choose_a_result_format/

- **EXT-BIGQUERY-TIME-TRAVEL-2026** — BigQuery documentation, Data retention with time travel and fail-safe — https://docs.cloud.google.com/bigquery/docs/time-travel
- **EXT-HUDI-TIMELINE-2026** — Apache Hudi documentation, Concepts / Timeline — https://hudi.apache.org/docs/concepts/
- **EXT-SNOWFLAKE-TIME-TRAVEL-2026** — Snowflake documentation, Understanding & using Time Travel — https://docs.snowflake.com/en/user-guide/data-time-travel
- **EXT-SQLSERVER-TEMPORAL-TABLES-2025** — Microsoft Learn, Temporal tables / system-versioned temporal tables — https://learn.microsoft.com/en-us/sql/relational-databases/tables/temporal-tables?view=sql-server-ver17

- **EXT-TRINO-PUSHDOWN-2026** — Trino documentation, Pushdown — https://trino.io/docs/current/optimizer/pushdown.html
- **EXT-SPARQL-FEDERATED-QUERY-2013** — W3C Recommendation, SPARQL 1.1 Federated Query — https://www.w3.org/TR/sparql11-federated-query/
- **EXT-APOLLO-FEDERATION-COMPOSITION-2026** — Apollo GraphQL documentation, Federation composition rules — https://www.apollographql.com/docs/graphos/schema-design/federated-schemas/reference/composition-rules
- **EXT-AWS-CLEANROOMS-AGGREGATION-RULE-2026** — AWS Clean Rooms User Guide, Aggregation analysis rule — https://docs.aws.amazon.com/clean-rooms/latest/userguide/analysis-rules-aggregation.html
- **EXT-SNOWFLAKE-CLEANROOM-POLICIES-2026** — Snowflake Documentation, Understanding Snowflake Data Clean Room policies — https://docs.snowflake.com/en/user-guide/cleanrooms/v1/policies
- **EXT-OPENID-FEDERATION-1-0-2026** — OpenID Foundation, OpenID Federation 1.0 — https://openid.net/specs/openid-federation-1_0.html
- **EXT-AUTHZEN-AUTHORIZATION-API-2026** — OpenID Foundation, Authorization API 1.0 — https://openid.net/specs/authorization-api-1_0.html
- **EXT-W3C-SKOS-2009** — W3C, SKOS Simple Knowledge Organization System Reference — https://www.w3.org/TR/skos-reference/
- **EXT-HL7-FHIR-VALUESET-2026** — HL7 FHIR, ValueSet resource — https://hl7.org/fhir/valueset.html
- **EXT-HL7-FHIR-CONCEPTMAP-2026** — HL7 FHIR, ConceptMap resource — https://hl7.org/fhir/conceptmap.html
- **EXT-HL7-FHIR-CONCEPTMAP-DEFINITIONS-2026** — HL7 FHIR, ConceptMap detailed definitions — https://hl7.org/fhir/conceptmap-definitions.html
- **EXT-QUDT-UNITS-2026** — QUDT, Unit vocabulary documentation — https://www.qudt.org/doc/DOC_VOCAB-UNITS.html
- **EXT-DATAHUB-BUSINESS-GLOSSARY-2026** — DataHub, Business Glossary guide and entity docs — https://docs.datahub.com/docs/generated/metamodel/entities/glossaryterm
- **EXT-DATAHUB-DOMAINS-2026** — DataHub, Domains overview and tags/terms/domains distinction — https://docs.datahub.com/docs/domains
- **EXT-OPENMETADATA-GLOSSARY-BEST-PRACTICES-2026** — OpenMetadata, Best Practices for Glossary — https://docs.open-metadata.org/v1.12.x/how-to-guides/data-governance/glossary/best-practices
- **EXT-OPENMETADATA-GLOSSARY-TERMS-2026** — OpenMetadata, What is a Glossary Term — https://docs.open-metadata.org/v1.11.x/how-to-guides/data-governance/glossary/glossary-term

- **EXT-PROMETHEUS-ALERTING-RULES-2026** — Prometheus documentation, Alerting rules — https://prometheus.io/docs/prometheus/latest/configuration/alerting_rules/
- **EXT-PROMETHEUS-ALERTMANAGER-2026** — Prometheus documentation, Alertmanager — https://prometheus.io/docs/alerting/latest/alertmanager/
- **EXT-GOOGLE-SRE-MONITORING-2026** — Google SRE Book, Monitoring Distributed Systems — https://sre.google/sre-book/monitoring-distributed-systems/
- **EXT-K8S-HPA-BEHAVIOR-2026** — Kubernetes documentation, Horizontal Pod Autoscaling — https://kubernetes.io/docs/concepts/workloads/autoscaling/horizontal-pod-autoscale/
- **EXT-CLOUDEVENTS-SPEC-2026** — CloudEvents specification — https://github.com/cloudevents/spec/blob/main/cloudevents/spec.md
- **EXT-OPENFEATURE-PROVIDER-2026** — OpenFeature specification, Providers — https://openfeature.dev/specification/sections/providers/
- **EXT-OPA-DECISION-LOGS-2026** — Open Policy Agent documentation, Decision Logs — https://www.openpolicyagent.org/docs/management-decision-logs

- **EXT-GOOGLE-RULES-ML-2025** — Google for Developers, Rules of Machine Learning — https://developers.google.com/machine-learning/guides/rules-of-ml
- **EXT-TFX-DATA-VALIDATION-2024** — TensorFlow TFX API docs, `tfdv.validate_statistics` — https://www.tensorflow.org/tfx/data_validation/api_docs/python/tfdv/validate_statistics
- **EXT-FEAST-POINT-IN-TIME-2026** — Feast documentation, Use Cases / point-in-time correctness — https://docs.feast.dev/getting-started/use-cases
- **EXT-OBP-OPE-2026** — Open Bandit Pipeline documentation, logged bandit feedback and off-policy evaluation — https://zr-obp.readthedocs.io/en/latest/
- **EXT-MICROSOFT-SRM-2020** — Microsoft Research, Diagnosing Sample Ratio Mismatch in A/B Testing — https://www.microsoft.com/en-us/research/articles/diagnosing-sample-ratio-mismatch-in-a-b-testing/
- **EXT-STATSIG-HOLDOUTS-2026** — Statsig documentation, Holdouts — https://docs.statsig.com/experiments/holdouts-introduction
- **EXT-EVIDENTLY-DRIFT-2026** — Evidently documentation, Data drift explainer — https://docs.evidentlyai.com/metrics/explainer_drift
- **EXT-DATABRICKS-LAKEHOUSE-MONITORING-2026** — Databricks documentation, Monitor data and AI assets with Lakehouse Monitoring — https://docs.databricks.com/sap/en/lakehouse-monitoring

- **EXT-SKLEARN-DATA-LEAKAGE-2026** — scikit-learn documentation, Common pitfalls and recommended practices / Data leakage — https://scikit-learn.org/stable/common_pitfalls.html
- **EXT-SKLEARN-TIMESERIESSPLIT-2026** — scikit-learn documentation, TimeSeriesSplit — https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html
- **EXT-PROPHET-DIAGNOSTICS-2026** — Prophet documentation, Diagnostics / cross validation — https://facebook.github.io/prophet/docs/diagnostics.html
- **EXT-DOWHY-CAUSAL-EFFECTS-2026** — PyWhy DoWhy documentation, Estimating Causal Effects — https://www.pywhy.org/dowhy/v0.14/user_guide/causal_tasks/estimating_causal_effects/index.html
- **EXT-DOWHY-REFUTERS-2026** — PyWhy DoWhy documentation, Refuting causal estimates — https://www.pywhy.org/dowhy/main/user_guide/refuting_causal_estimates/index.html
- **EXT-NUMPY-SEEDSEQUENCE-2026** — NumPy documentation, `numpy.random.SeedSequence` — https://numpy.org/doc/2.4/reference/random/bit_generators/generated/numpy.random.SeedSequence.html
- **EXT-SDV-DIAGNOSTIC-2026** — Synthetic Data Vault documentation, Diagnostic report — https://docs.sdv.dev/sdv/single-table-data/evaluation/diagnostic
- **EXT-SDMETRICS-QUALITY-2026** — SDMetrics documentation, Quality Report — https://docs.sdv.dev/sdmetrics/data-metrics/quality/quality-report
- **EXT-SDMETRICS-PRIVACY-2026** — SDMetrics documentation, Privacy metrics — https://docs.sdv.dev/sdmetrics/data-metrics/privacy
- **EXT-NIST-SDNIST-2022** — NIST, SDNist Synthetic Data Report Tool — https://www.nist.gov/services-resources/software/sdnist-synthetic-data-report-tool

- **EXT-NCSC-PROMPT-INJECTION-2025** — UK National Cyber Security Centre, “Prompt injection is not SQL injection (it may be worse)” — https://www.ncsc.gov.uk/blog-post/prompt-injection-is-not-sql-injection
- **EXT-OWASP-LLM01-PROMPT-INJECTION-2025** — OWASP GenAI Security Project, LLM01:2025 Prompt Injection — https://genai.owasp.org/llmrisk/llm01-prompt-injection/
- **EXT-OWASP-LLM06-EXCESSIVE-AGENCY-2025** — OWASP GenAI Security Project, LLM06:2025 Excessive Agency — https://genai.owasp.org/llmrisk/llm062025-excessive-agency/
- **EXT-MCP-TOOLS-2025-11** — Model Context Protocol specification 2025-11-25, Tools — https://modelcontextprotocol.io/specification/2025-11-25/server/tools
- **EXT-MCP-ROOTS-2025-11** — Model Context Protocol specification 2025-11-25, Roots — https://modelcontextprotocol.io/specification/2025-11-25/client/roots
- **EXT-MCP-SAMPLING-2025-11** — Model Context Protocol specification 2025-11-25, Sampling — https://modelcontextprotocol.io/specification/2025-11-25/client/sampling
- **EXT-LANGCHAIN-SQL-AGENT-2026** — LangChain documentation, Build a SQL agent — https://docs.langchain.com/oss/python/langchain/sql-agent
- **EXT-DBT-SL-VS-TEXTSQL-2026** — dbt Developer Blog, Semantic Layer vs. Text-to-SQL: 2026 Benchmark Update — https://docs.getdbt.com/blog/semantic-layer-vs-text-to-sql-2026
- **EXT-SPIDER2-2025** — Spider 2.0, Evaluating Language Models on Real-World Enterprise Text-to-SQL Workflows — https://spider2-sql.github.io/
- **EXT-BIRD-SQL-2025** — BIRD SQL benchmark — https://bird-bench.github.io/
- **EXT-BIRD-INTERACT-2025** — Huo et al., BIRD-INTERACT: Re-imagining Text-to-SQL Evaluation for Large Language Models via Lens of Dynamic Interactions — https://arxiv.org/abs/2510.05318

- **EXT-IN-TOTO-LINK-ATTESTATION-2026** — in-toto Attestation Framework, Link predicate — https://github.com/in-toto/attestation/blob/main/spec/predicates/link.md
- **EXT-ROCRATE-1-2-2025** — RO-Crate Metadata Specification 1.2, Metadata of the RO-Crate — https://www.researchobject.org/ro-crate/specification/1.2/metadata.html
- **EXT-W3C-VC-DATA-INTEGRITY-1-1-2026** — W3C, Verifiable Credential Data Integrity 1.1 — https://www.w3.org/TR/vc-data-integrity-1.1/
- **EXT-REPROZIP-ABOUT-2026** — ReproZip, About ReproZip — https://www.reprozip.org/about.html
- **EXT-NIX-FLAKE-LOCK-2026** — Nix Reference Manual, `nix flake lock` — https://nix.dev/manual/nix/2.18/command-ref/new-cli/nix3-flake-lock

- **EXT-NARA-RECORDS-SCHEDULE-2021** — U.S. National Archives, NARA Records Schedule — https://www.archives.gov/about/records-schedule
- **EXT-NIST-CHAIN-CUSTODY-GLOSSARY-2026** — NIST CSRC Glossary, Chain of Custody — https://csrc.nist.gov/glossary/term/chain_of_custody
- **EXT-LOC-BAGIT-2019** — Library of Congress, BagIt at the Library of Congress — https://blogs.loc.gov/thesignal/2019/04/bagit-at-the-library-of-congress/
- **EXT-OCFL-1-1-2022** — Oxford Common File Layout Specification 1.1 — https://ocfl.io/1.1.0/spec/
- **EXT-PREMIS-3-0** — Library of Congress, PREMIS Data Dictionary for Preservation Metadata, Version 3.0 — https://www.loc.gov/standards/premis/v3/
- **EXT-AWS-S3-OBJECT-LOCK-2026** — AWS S3 User Guide, Locking objects with Object Lock — https://docs.aws.amazon.com/AmazonS3/latest/userguide/object-lock.html
- **EXT-MICROSOFT-PURVIEW-DISPOSITION-2025** — Microsoft Learn, Disposition of content in Microsoft Purview — https://learn.microsoft.com/en-us/purview/disposition
- **EXT-EURLEX-GDPR-2016** — EUR-Lex, Regulation (EU) 2016/679 General Data Protection Regulation — https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng
- **EXT-NIST-800-88R2-2025** — NIST SP 800-88 Rev. 2, Guidelines for Media Sanitization — https://csrc.nist.gov/pubs/sp/800/88/r2/final
- **EXT-CCSDS-OAIS-3-2024** — CCSDS Publications, OAIS Reference Model, Issue 3 listing — https://ccsds.org/publications/allpubs/
- **EXT-EC-DSA-TRANSPARENCY-DB-2025** — European Commission, DSA Transparency Database: Questions and Answers — https://digital-strategy.ec.europa.eu/en/faqs/dsa-transparency-database-questions-and-answers
- **EXT-EC-DSA-ODS-2026** — European Commission, Out-of-court dispute settlement bodies under the Digital Services Act (DSA) — https://digital-strategy.ec.europa.eu/en/policies/dsa-out-court-dispute-settlement
- **EXT-CFPB-REASONABLE-INVESTIGATION-2022** — Consumer Financial Protection Bureau, Circular 2022-07: Reasonable investigation of consumer reporting disputes — https://www.consumerfinance.gov/compliance/circulars/consumer-financial-protection-circular-2022-07-reasonable-investigation-of-consumer-reporting-disputes/
- **EXT-CFPB-DIRECT-DISPUTES-2026** — Consumer Financial Protection Bureau, Regulation V § 1022.43 Direct disputes — https://www.consumerfinance.gov/rules-policy/regulations/1022/43
- **EXT-HHS-HIPAA-CORRECTION-2008** — HHS, Health Information Technology and HIPAA — Correction — https://www.hhs.gov/sites/default/files/ocr/privacy/hipaa/understanding/special/healthit/correction.pdf
- **EXT-CMS-PART-C-IRE-2026** — CMS, Reconsideration by Part C Independent Review Entity (IRE) — https://www.cms.gov/medicare/appeals-grievances/managed-care/review-part-c-independent-entitiy
- **EXT-EU-AI-ACT-2024** — EUR-Lex, Regulation (EU) 2024/1689 laying down harmonised rules on artificial intelligence — https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=OJ:L_202401689

- **EXT-NIST-AIRMF-GOVERN-2026** — NIST AI Resource Center, AI RMF Playbook / Govern — https://airc.nist.gov/airmf-resources/playbook/govern/
- **EXT-BACKSTAGE-CATALOG-OWNERSHIP-2026** — Backstage Software Catalog, ownership and metadata overview — https://backstage.io/docs/features/software-catalog/
- **EXT-BACKSTAGE-DESCRIPTOR-LIFECYCLE-2026** — Backstage Software Catalog, descriptor format for type/lifecycle/owner — https://backstage.io/docs/features/software-catalog/descriptor-format/
- **EXT-GITHUB-CODEOWNERS-2026** — GitHub Docs, About code owners — https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners
- **EXT-DATAHUB-DOMAIN-OWNERSHIP-2026** — DataHub, Domain entity ownership — https://docs.datahub.com/docs/generated/metamodel/entities/domain
- **EXT-DATAHUB-OWNERSHIP-TYPES-2026** — DataHub, OwnershipType entity — https://docs.datahub.com/docs/generated/metamodel/entities/ownershiptype
- **EXT-OPENMETADATA-DATA-OWNERSHIP-2026** — OpenMetadata, Assign or change data ownership — https://docs.open-metadata.org/v1.12.x/how-to-guides/guide-for-data-users/data-ownership
- **EXT-OPENFGA-CONCEPTS-2026** — OpenFGA documentation, Concepts — https://openfga.dev/docs/concepts
- **EXT-OPENFGA-CONTEXTUAL-TUPLES-2026** — OpenFGA documentation, Contextual tuples — https://openfga.dev/docs/interacting/contextual-tuples
- **EXT-OPENFGA-CONDITIONS-2026** — OpenFGA documentation, Conditions — https://openfga.dev/docs/modeling/conditions
- **EXT-PAGERDUTY-ESCALATION-POLICIES-2026** — PagerDuty Support, Escalation Policy Basics — https://support.pagerduty.com/main/docs/escalation-policies
- **EXT-ATLASSIAN-INCIDENT-ROLES-2026** — Atlassian, Understanding incident response roles and responsibilities — https://www.atlassian.com/incident-management/incident-response/roles-responsibilities
- **EXT-OWASP-AGENTIC-AI-THREATS-2025** — OWASP GenAI Security Project, Agentic AI — Threats and Mitigations — https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/
- **EXT-NIST-AI-RMF-GENAI-PROFILE-2024** — NIST AI Risk Management Framework page, NIST-AI-600-1 Generative AI Profile release note — https://www.nist.gov/itl/ai-risk-management-framework
- **EXT-OTEL-EVENT-SEMCONV-2026** — OpenTelemetry Semantic Conventions, General event semantics — https://opentelemetry.io/docs/specs/semconv/general/events/
- **EXT-CLOUDEVENTS-SUBSCRIPTIONS-2026** — CloudEvents subscription specification — https://github.com/cloudevents/spec/blob/main/subscriptions/spec.md
- **EXT-OTEL-SPAN-EVENT-DEPRECATION-2026** — OpenTelemetry Blog, Deprecating Span Events API — https://opentelemetry.io/blog/2026/deprecating-span-events/
- **EXT-CONFLUENT-KAFKA-LOG-COMPACTION-2026** — Confluent Documentation, Kafka Log Compaction — https://docs.confluent.io/kafka/design/log_compaction.html
- **EXT-OPENFGA-RELATIONSHIP-QUERIES-2026** — OpenFGA documentation, Relationship Queries: Check, Read, Expand, ListObjects and ListUsers — https://openfga.dev/docs/interacting/relationship-queries
- **EXT-CLOUDEVENTS-DISTRIBUTED-TRACING-2026** — CloudEvents specification, Distributed Tracing Extension — https://github.com/cloudevents/spec/blob/main/cloudevents/extensions/distributed-tracing.md
- **EXT-NIST-SP-800-226-DP-2025** — NIST SP 800-226, Guidelines for Evaluating Differential Privacy Guarantees — https://csrc.nist.gov/pubs/sp/800/226/final
- **EXT-NIST-PRIVACY-FRAMEWORK-1-1-2026** — NIST, Privacy Framework and Privacy Framework 1.1 materials — https://www.nist.gov/privacy-framework
- **EXT-W3C-DPV-2026** — W3C / DPVCG, Data Privacy Vocabulary — https://w3id.org/dpv/
- **EXT-W3C-ODRL-MODEL-2-2** — W3C Recommendation, ODRL Information Model 2.2 — https://www.w3.org/TR/odrl-model/
- **EXT-IETF-RFC-9396-RAR** — IETF RFC 9396, OAuth 2.0 Rich Authorization Requests — https://datatracker.ietf.org/doc/html/rfc9396
- **EXT-NIST-SP-800-53-REV5** — NIST SP 800-53 Rev. 5, Security and Privacy Controls for Information Systems and Organizations — https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final

- **EXT-NIST-SP-800-137-2011** — NIST SP 800-137, Information Security Continuous Monitoring for Federal Information Systems and Organizations — https://csrc.nist.gov/pubs/sp/800/137/final


- **EXT-GCP-PUBSUB-DEADLETTER-2026** — Google Cloud Pub/Sub documentation, Dead-letter topics — https://docs.cloud.google.com/pubsub/docs/dead-letter-topics
- **EXT-AZURE-EVENTGRID-DELIVERY-RETRY-2026** — Microsoft Learn, Azure Event Grid message delivery and retry — https://learn.microsoft.com/en-us/azure/event-grid/delivery-and-retry

- **EXT-AUTHZEN-AUTHORIZATION-API-2025** — OpenID Foundation, AuthZEN Authorization API 1.0 draft 04 — https://openid.net/specs/authorization-api-1_0-04.html

- **EXT-OASIS-XACML-3-0-2013** — OASIS, eXtensible Access Control Markup Language (XACML) Version 3.0 Core Specification — https://docs.oasis-open.org/xacml/3.0/xacml-3.0-core-spec-os-en.html

- **EXT-NIST-SP-800-61R3-2025** — NIST SP 800-61 Rev. 3, Incident Response Recommendations and Considerations for Cybersecurity Risk Management — https://csrc.nist.gov/pubs/sp/800/61/r3/final

- **EXT-AZURE-COMPENSATING-TRANSACTION-2026** — Microsoft Azure Architecture Center, Compensating Transaction pattern — https://learn.microsoft.com/en-us/azure/architecture/patterns/compensating-transaction

- **EXT-AZURE-SAGA-PATTERN-2026** — Microsoft Azure Architecture Center, Saga distributed transaction pattern — https://learn.microsoft.com/en-us/azure/architecture/patterns/saga

- **EXT-GOOGLE-SRE-POSTMORTEM-WORKBOOK** — Google SRE Workbook, Postmortem Practices for Incident Management — https://sre.google/workbook/postmortem-culture/
- **EXT-GOOGLE-POSTMORTEM-ACTION-ITEMS** — Google Research, Postmortem Action Items: Plan the Work and Work the Plan — https://research.google/pubs/postmortem-action-items-plan-the-work-and-work-the-plan/

- **EXT-W3C-PROV-CONSTRAINTS-2013** — W3C PROV Constraints specification. Pressure: provenance bundles need explicit consistency checks before comparison or reuse.
- **EXT-DORA-METRICS-2026** — DORA software delivery performance metrics guide. Pressure: recovery/improvement metrics are aggregate signals, not proof that one disputed remedy is complete.
