# Research synthesis — pass LXXI

Pass LXX made answer-to-action hygiene explicit: a SlopOS-facing cube answer may inform alerts, recommendations, workflow inputs, feature flags, ACP proposals, notifications, or control loops only through threshold witnesses, action warrants, and consequence receipts. Pass LXXI follows the next failure mode: once those consequences happen, their aftermath can become training data, evaluation data, reward data, optimization data, product analytics, agent memory, or policy-learning material. At that point the cube is no longer merely observing a world; it may be observing a world that the cube itself helped perturb.

The restraint rule still holds. Ward should not choose a model registry, feature store, experiment platform, bandit library, recommender stack, agent-memory store, human-feedback tool, drift monitor, holdout framework, or objective-function DSL as the SlopOS datacube constitution. SlopOS is still design-phase, and its own D-CAPSHELL learn-mode posture already warns that “learning” must remain observational and non-authoritative unless a separate explicit edit/review path promotes it. The right Ward move is to name answer-level residues that keep **observation**, **intervention**, **feedback**, **evaluation**, and **learning promotion** separate.

## What the past says we must learn now

1. **Training-serving skew is not a footnote.** Google's ML guidance separates launching and iterating from skew evaluation and warns practitioners to measure training/serving skew (`EXT-GOOGLE-RULES-ML-2025`). TensorFlow Data Validation's `validate_statistics` has explicit `previous_statistics` and `serving_statistics` channels for drift and skew detection (`EXT-TFX-DATA-VALIDATION-2024`). Ward should steal the posture: a cube-derived feature, label, or metric used in learning needs a visible production/training cut, not a vague “same metric” claim.

2. **Point-in-time correctness is a leakage fence.** Feast frames recommendation and risk-scorecard feature use around historical retrieval and point-in-time correctness to avoid data leakage (`EXT-FEAST-POINT-IN-TIME-2026`). Ward should carry the same lesson into the cube: labels, features, actions, and evaluations need the information state available at the time, not after correction, quarantine, or later semantic repair made the answer look obvious.

3. **Counterfactual learning needs logged policy evidence.** Open Bandit Pipeline exists specifically for logged bandit feedback and off-policy evaluation, including behavior-policy/propensity information (`EXT-OBP-OPE-2026`). Ward should not let “users clicked after we recommended X” become evidence that X was best unless the exposure policy, propensity/exploration posture, and candidate set are recorded.

4. **Experiments can look valid while the sample is broken.** Microsoft Research treats Sample Ratio Mismatch as a required pre-analysis check because disproportionate experiment data can reverse conclusions, and missing users are often the users most affected by a change (`EXT-MICROSOFT-SRM-2020`). Ward should steal the SRM habit for any cube answer used to tune actions, agents, recommendations, or policy thresholds.

5. **Holdouts are a way to measure cumulative intervention, not a product checkbox.** Statsig's holdout docs describe holding back a balanced control group from a set of features to measure aggregate impact (`EXT-STATSIG-HOLDOUTS-2026`). Ward should not require one experiment product, but it should preserve the idea that some population must remain clean enough to tell intervention-shaped metrics from ambient trend.

6. **Drift monitoring needs reference/current cuts.** Evidently's drift docs compare current and reference datasets, while Databricks Lakehouse Monitoring attaches monitors to tables or inference logs, computes quality/performance metrics over time, and can use a baseline table for drift (`EXT-EVIDENTLY-DRIFT-2026`, `EXT-DATABRICKS-LAKEHOUSE-MONITORING-2026`). Ward should steal the cut discipline and resist turning drift alerts into automatic retraining or threshold edits.

7. **Learning reports are not authority.** The included SlopOS D-CAPSHELL learn-mode posture says reports are non-authoritative suggestions, no relaxed enforcement path exists, and tooling must not auto-edit, auto-approve, or auto-rerun. This is directly relevant to Ward: a cube learning loop can produce review material without becoming a hidden policy synthesis service.

8. **Receipts and logs are not fresh labels.** Prior Ward passes already separated consequence receipts, interaction trails, egress receipts, correction horizons, revocation fences, semantic cuts, and quality witnesses. Pass LXXI adds the missing warning: those residues can be inputs to learning, but they are not neutral observations unless their intervention lineage and label maturity are preserved.

## Resulting Ward move

Do **not** decide yet:

- one feature store, model registry, experiment platform, bandit library, recommender service, MLOps monitor, agent-memory substrate, or evaluation harness;
- one objective function, reward model, label ontology, counterfactual estimator, exploration scheme, randomization unit, holdout percentage, or retraining cadence;
- one rule that every drift alert retrains, every successful recommendation becomes a positive label, every human acceptance becomes ground truth, every no-op means success, or every rejection means failure;
- one SlopOS-wide policy-learning, auto-widening, auto-thresholding, or “learn from denied actions” service;
- one durable universal event log that can replay all learning decisions without current authority.

Do add three small, reversible residues for datacube learning-loop hygiene:

- **learning loop ledger** — compact residue for a proposed or actual learning/evaluation use of cube material. It names the source answer capsules, action/consequence receipts, feature/label/reward candidates, model/policy/agent surface, training/evaluation cut, label maturity, point-in-time feature posture, drift/skew checks, off-policy/experiment evidence, human review lane, promotion decision, rollback/fence requirements, and current non-authoritative status. It is smaller than an MLOps platform and stronger than “we used analytics to improve it.”
- **holdout witness** — compact residue that a population, cohort, assignment, or clean reference path remained suitable for measuring intervention-shaped effects. It names randomization or assignment unit, intended/observed allocation, eligibility/exposure rules, SRM/assignment diagnostics, overlap/interference/spillover notes, duration, exclusion reasons, guardrail metrics, privacy/suppression posture, and whether the witness is clean, degraded, or invalid. It is smaller than an experiment engine and stronger than “control group.”
- **feedback taint fence** — compact boundary around outcomes, labels, clicks, reviewer choices, operator actions, agent summaries, or downstream metrics that may have been shaped by a cube answer, alert, recommendation, ranking, quarantine, export, or UI change. It records intervention source, exposure surface, user/agent/operator visibility, action-warrant/consequence linkage, label-delay/maturity, selection bias, censoring/missingness, privacy/detail limits, allowed uses, and decontamination or holdout requirements. It is smaller than a data-governance platform and stronger than a warning icon.

These residues sit beside earlier nouns. Learning loop ledgers consume answer capsules, scope lenses, state-cut witnesses, quality witnesses, freshness envelopes, uncertainty envelopes, action warrants, consequence receipts, interaction trails, egress receipts, correction horizons, and concept anchors. Holdout witnesses consume population witnesses, sample witnesses, comparability passports, quality witnesses, privacy/noise residue, and budget gates. Feedback taint fences feed refusal receipts, degradation receipts, backfill ledgers, revocation fences, and future retraining/evaluation promotion gates.

## Brilliant ideas to steal now

- **Intervention-shaped data is not neutral data.** Once a cube answer changes a display, alert, workflow, quarantine, or recommendation, downstream behavior is tainted evidence until proven otherwise.
- **Label maturity matters.** Clicks, reviewer approvals, quarantines, no-ops, later corrections, customer outcomes, and policy decisions mature on different clocks.
- **Point-in-time features before impressive accuracy.** A model that uses facts unavailable at decision time is a flattering artifact, not a safe learning loop.
- **SRM before effect.** Allocation and logging diagnostics should run before interpreting the lift, drift, or reward.
- **Holdout as witness, not product choice.** Preserve a clean enough counterfactual lane without selecting an experimentation vendor.
- **Propensity/exposure as first-class.** Ranked recommendations, throttles, or quarantines create biased observation; off-policy evaluation needs behavior-policy evidence.
- **No hidden threshold tuning.** A drift monitor or successful alert cannot quietly rewrite thresholds or action warrants.
- **Agent memory must decay.** Agent summaries and reviewer notes may become examples only through egress receipts, exemplar fences, and feedback taint fences.
- **Negative examples need context.** A rejected recommendation may mean the answer was wrong, the action warrant was too broad, the timing was bad, the reviewer lacked context, or the interface was confusing.
- **Learning reports weaker than edits.** A suggested feature, label, threshold, or policy patch stays non-authoritative until a normal review/edit/promotion path accepts it.

## Candidate specimen pressure

Use a SlopOS reviewer question such as: “A provider-risk cube answer generated notifications and a bounded quarantine proposal last week. Can the resulting accept/reject/no-op outcomes train the next provider-risk recommender and retune the alert threshold?” The answer must preserve the original intervention and consequence receipts, fence feedback shaped by the notification/quarantine UI, identify any holdout/control witness, detect assignment/logging skew, separate mature labels from provisional outcomes, and refuse automatic retuning when counterfactual or point-in-time evidence is missing.

## Still-not-yet decisions

- Whether learning loop ledgers live under Ward, a future ML/experimentation companion, a SlopOS observation lane, or a Helm review-product surface.
- Whether holdout witnesses should be keyed to users, handles, provider families, workspaces, requests, documents, devices, tenants, or action scopes.
- Whether feedback taint fences should attach to cells, rows, examples, features, labels, whole answer capsules, or exported artifacts.
- What minimum evidence upgrades a tainted outcome into usable training/evaluation material for a specific consequence class.
- What forms of exploration are allowed when privacy, safety, budget, or user trust makes randomization inappropriate.
- How to expose learning-loop health to humans without turning it into a noisy experiment dashboard too early.
