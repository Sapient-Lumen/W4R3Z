# Research synthesis — pass XLV

This pass keeps Ward decision-light and adds another datacube discipline: **a repeated question may deserve a small published query contract before it deserves any lossy rollup, and any lossy derivative needs an explicit loss fence**.

## What the past says we must learn
1. **A semantic contract can be smaller than a giant semantic layer.**  
   dbt's Semantic Layer architecture keeps one useful idea separate from any single serving engine: teams can centrally define semantic models and metrics with YAML specifications, and the layer can query them through explicit interfaces rather than by letting every downstream chart reinvent meaning. Ward should steal the posture, not the stack. The healthy move is a small **query contract** for one repeatedly useful trust question, not a giant mandatory universal semantic model on day one (`EXT-DBT-SEMANTIC-ARCH-2026`).

2. **Pre-aggregation is a real trade, not a free optimization.**  
   Druid's rollup docs are refreshingly blunt: rollup is ingestion-time summarization/pre-aggregation, it can dramatically cut storage and row counts, and the trade-off is that you lose the ability to query individual events. Druid also says to disable rollup if you need row-level results or need `GROUP BY` / `WHERE` on any column, and suggests multiple tables when needs conflict. Ward should steal the honesty. Any accelerated trust derivative that becomes lossy should carry an explicit **loss fence** rather than quietly masquerading as raw replayable truth (`EXT-DRUID-ROLLUP-2026`).

3. **High-cardinality discovery still comes before narrow published metrics.**  
   Honeycomb remains the right warning against freezing the cube too early: contrast-first exploration over rich event shape is often where the real pressure-bearing dimensions appear. That means Ward should not jump straight from saved query manifests to a full metric constitution. A repeated question can earn a **metric card** or query contract, while the broader cube stays open to richer contrast-first investigation (`EXT-HONEYCOMB-BUBBLEUP-2026`, `EXT-HONEYCOMB-EVENTS-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward's eventual datacube rides on one warehouse, one semantic layer, one OLAP engine, one stream processor, or a thinner query-family posture.

For now, keep three more separations visible and let later specimens force promotion:
- **query contract** — a small published promise for one repeated analytic question: named measures/dimensions, grain, required headers, and caveats; smaller than a giant semantic layer and smaller than raw evidence/appraisal.
- **metric card** — the compact human-facing statement of one measure's meaning, grain, headers, and warnings; smaller than the query contract itself.
- **loss fence** — explicit statement of which raw or high-cardinality questions a lossy derivative can no longer answer honestly.

## Why these separations are worth stealing
- A `query contract` lets Ward standardize one repeated question without prematurely freezing the whole cube.
- A `metric card` helps humans consume one repeated measure without mistaking it for source truth.
- A `loss fence` keeps acceleration honest when pre-aggregation or lossy summarization becomes tempting.

## Brilliant ideas to steal now
- **query contract** — small published promise for one repeated question, not one giant semantic constitution.
- **metric card** — compact meaning/grain/caveat surface for one measure.
- **loss fence** — explicit boundary around what a lossy derivative cannot answer.
- **contract-before-rollup** — a standing process rule.
- **no lossy default cube** — a standing anti-regrowth rule.

## Still-not-yet decisions
- Whether `query contract` belongs inside Ward proper or remains datacube-side guidance until more repeated questions exist.
- Whether `metric card` is just one human-facing rendering of a query contract or deserves durable independent vocabulary later.
- Whether `loss fence` should stay a review/product surface or eventually become a typed archive artifact family.
- Whether a future semantic layer exists at all, and if so whether it stays smaller than the saved-query-manifest family SlopOS and ViewFS already pressure us toward.
