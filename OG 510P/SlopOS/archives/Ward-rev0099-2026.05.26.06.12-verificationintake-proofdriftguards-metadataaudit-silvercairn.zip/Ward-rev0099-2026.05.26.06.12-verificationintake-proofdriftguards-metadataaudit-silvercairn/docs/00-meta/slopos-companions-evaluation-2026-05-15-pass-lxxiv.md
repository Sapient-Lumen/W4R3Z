# SlopOS and companion evaluation — pass LXXIV

Pass LXXIV evaluates Ward's SlopOS datacube posture after adding verification bundles, replay recipes, and attestation envelopes. The target is not a packaging standard. The target is a durable distinction between **evidence that can be checked** and **authority that remains current**.

## SlopOS fit

The included SlopOS snapshot already contains strong nearby pressure:

- **CH-AREF** names content-addressed artifact references where digest is authoritative and locator is a hint. Ward should borrow this for verification-bundle components, but not assume a digest proves trust or currentness.
- **CH-DERIV** records build recipe plus input/output digests as a compact seam, explicitly not a complete build language. Ward's replay recipe should follow that restraint: enough to audit/replay/check, not a universal computation engine.
- **D-NONDET / D-RR** keeps ambient time/entropy from sneaking into replay. Ward's replay recipe should record nondeterminism posture, seed/source cuts, and whether byte-identical, value-identical, tolerance-identical, or verdict-identical replay is possible.
- **CH-ACPOUT** remains non-authoritative. A signed or logged datacube verification artifact cannot become action permission or downstream completion truth.
- **Artifact-resolution posture** treats locators as workflow seams. Ward verification bundles should not fetch arbitrary URLs, schema samples, notebooks, or partner artifacts without authority, projection, and budget checks.
- **Receipt replication boundaries** reinforce that immutable evidence can replicate without becoming local authority. That is exactly the attestation-envelope lesson.

The fit is excellent as long as Ward stays at the residue level: verification bundle, replay recipe, and attestation envelope are portable *interpretation aids*, not SlopOS substrate primitives yet.

## Companion pressure

- **Harbor** gives temporal pressure: verification bundles must preserve source cuts, read cuts, join clocks, correction horizons, and revocation fences. Historical correctness under one cut is not current correctness.
- **Foundry** gives semantic-spine pressure: replay recipes must bind to metric cards, concept anchors, hierarchy cuts, and crosswalk warrants, not raw column names alone.
- **Steward** gives consequence pressure: attestation envelopes cannot turn historical justifications into durable permission to act; action warrants and consequence receipts still rule.
- **Schell** gives environment pressure: replay recipes must name basis cards, environment epochs, activation receipts, and dependency locks when runtime differences matter.
- **ViewFS** gives artifact pressure: exported charts, notebooks, signed bundles, saved prompts, and validation sidecars are file-like objects whose provenance, redaction, and stale status must remain visible.
- **Helm** gives review-surface pressure: human reviewers need a compact “verify / replay / dispute / currentness” presentation rather than a pile of logs.

## What Ward should absorb

1. **Evidence packaging must be bounded.** A verification bundle can carry digests, references, redacted materials, policies, validation summaries, replay hints, and missing-piece declarations without carrying raw rows or live capabilities.
2. **Replay class must be explicit.** Byte-identical, value-identical, tolerance-identical, verdict-identical, explanation-identical, and non-replayable are materially different outcomes.
3. **Attestations are claims with issuers, subjects, predicates, proofs, and verifier policy.** They are not ambient truth and do not override source authority, policy, privacy, freshness, or revocation.
4. **Transparency logs support anti-tamper and monitoring, not semantic correctness.** A logged exported answer can still be stale, suppressed, incomparable, over-budget, or semantically invalid.
5. **Verification creates egress.** Bundles, recipes, signatures, and logs expose metadata. They need projection curtains, egress receipts, revocation fences, and privacy/noise posture.
6. **Replay should fail closed.** If inputs expired, policy changed, privacy budgets cannot be re-spent, source cuts were compacted, or partner fragments are unavailable, the recipe should return a clear class of non-replayability rather than a fabricated rerun.

## What Ward should not absorb yet

- No SlopOS-wide proof format, signature suite, transparency log, key system, replay runtime, dependency manager, notebook/container format, or research-object package.
- No requirement that every answer be signed or globally logged.
- No guarantee that historical replay implies current authority.
- No hidden raw-row inclusion just to make auditors happy.
- No universal retention promise for inputs, models, prompts, partner fragments, or validation sidecars.
- No implication that verification bundles can satisfy capability checks, authorization checks, or action warrants.

## Evaluation verdict

Promote **verification bundle**, **replay recipe**, and **attestation envelope** as candidate datacube residues only. They improve Ward because they let SlopOS-facing datacube answers be checked, disputed, and archived without collapsing evidence packaging into answer truth, replay capability, or action authority.

## Immediate review checklist

Before a SlopOS-facing datacube answer can be treated as audit-ready:

- the verification bundle must identify the answer capsule, state cuts, metric/query/semantic contracts, privacy/projection fences, and missing evidence;
- the replay recipe must declare replay class, inputs, environment/dependency locks, nondeterminism posture, tolerance/invariant checks, and invalidation/revocation behavior;
- the attestation envelope must declare issuer, subject digest, predicate/profile, proof/log posture, expiry/revocation posture, and local-verifier policy expectations;
- exports, screenshots, model summaries, and action/consequence receipts must remain separate residues;
- currentness must be rehydrated from live authority and revocation/correction material, not inferred from old signatures or old bundles.
