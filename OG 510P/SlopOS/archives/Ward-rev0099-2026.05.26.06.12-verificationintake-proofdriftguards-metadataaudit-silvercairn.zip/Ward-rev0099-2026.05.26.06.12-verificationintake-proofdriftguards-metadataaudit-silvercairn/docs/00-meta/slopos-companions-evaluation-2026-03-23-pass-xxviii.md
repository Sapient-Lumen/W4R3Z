# SlopOS / companions evaluation — pass XXVIII

This pass keeps Ward embryonic while stealing one more useful habit from the neighbors: **make non-commutativity explicit and keep compiled/latest views visibly smaller than their source history.**

## What the current cubes still teach
- **SlopOS** already says privileged action families should prefer commutative specs when possible and should name the minimal serialization boundary when they are not. Ward should steal the smaller principle: if two later-state updates are incomparable, preserve that fact first and delay any universal merge story.
- **SlopOS** also treats configuration as compiled output with generations tracked outside the privileged core. Ward should steal the analogous lesson that a compacted or merged “current” view is a derived artifact, not the authoritative whole trust history.
- **Steward** remains a good reminder that cursors and followthrough state are small continuity aids, not a universal truth engine. Ward should keep merge outputs and survivor views equally humble.
- **Harbor** still warns that callback/delivery success is weaker than durable local effect. Ward should now add the parallel warning that one latest-value projection is weaker than full historical truth.

## Current recommendation
Keep Ward open on whether concurrent-sibling handling lives inline on result objects, beside a watch/history lane, or in a separate projection/compaction sidecar.

The next wise move is one specimen plus one tiny hygiene upgrade:
1. **concurrency witness** instead of timestamp folklore,
2. **merge recipe** instead of silent last-write-wins,
3. **compaction horizon** instead of pretending one latest view keeps all historical negatives,
4. **survivor view** instead of flattening derived projections into source truth,
5. **docs-front-door drift check** instead of letting `docs/README.md` lag behind the latest revision.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should still avoid freezing one durable concurrency algebra, one CRDT family, or one mandatory compaction regime into the repo.
The smaller steal is enough for now:
- keep `REVISION-RECEIPT.json` honest about which new research/evaluation/specimen surfaces landed this revision,
- make the hygiene checker verify that both `README.md` and `docs/README.md` actually point at those newest pass/specimen surfaces,
- and fail the revision if the archive’s front doors drift behind the current cut.

## Still-not-yet decisions
- Whether `concurrency witness` belongs in Ward proper or stays imported from event/history substrates.
- Whether `merge recipe` should be first-class Ward residue or remain local projection tooling.
- Whether `survivor view` deserves durable vocabulary or remains an implementation-side projection label.
- Whether `compaction horizon` belongs in Ward or in an adjacent history/observation cube.
- Whether Ward should ever standardize one causality carrier, or only insist that timestamps alone are not enough.
