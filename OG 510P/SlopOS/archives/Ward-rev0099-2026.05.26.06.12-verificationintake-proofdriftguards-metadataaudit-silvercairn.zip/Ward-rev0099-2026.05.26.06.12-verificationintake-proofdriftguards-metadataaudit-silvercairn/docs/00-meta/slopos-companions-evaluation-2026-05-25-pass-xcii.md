# SlopOS / companion evaluation — 2026-05-25 — pass XCII

## SlopOS pressure

SlopOS cares because notification acknowledgment is an attractive false positive. A recheckpoint, resume, portal handoff, or capability handle may see a successful notification fanout and treat it as cache-safe. Ward now forces a stronger question:

> Which downstream consumers actually produced local recertification receipts, and which remain quarantined?

The answer can feed SlopOS as a recheckpoint precondition, but not as action authority.

## Helm

Helm can render a reconciliation badge only as a mixed-state surface. It should not collapse `partial_recertification_quarantined` into a green status. A dead-lettered consumer should render as quarantine or review debt, not as delivery success.

## Schell

Schell can retain minimized reconciliation receipts while forgetting sealed notification payloads and raw consumer identities. Public views should show hashed/class-only consumers and bucketed/presence-only counts.

## Harbor

Harbor correction and recompute flows can require `all_consumers_recertified_refresh_required` before a public stale-surface guard is lifted. Partial reconciliation should keep stale bundles quarantined.

## Foundry

Foundry crosswalk/classification outputs should treat reconciliation as downstream hygiene. A classification pin or crosswalk witness must not be updated merely because a notification was acknowledged.

## ViewFS

ViewFS can expose reconciliation receipts as trusted-path annotations, but only as no-authority projections. It should not reveal sealed payloads, private contacts, or raw consumer identities to public readers.

## Steward

Steward can use reconciliation receipts to route followthrough. The receipt may identify stale-consumer closure work, but it cannot create a new delegation warrant or accept an escalation.

## Refactor evaluation

The checker registry helps all companions because it makes Ward's refusal harness inspectable. A consumer can now see which receipt validators exist without reading a hardcoded Python list.
