# SlopOS / companions evaluation — pass LII

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **a repeated trust question should not be treated as the same daily/weekly/monthly surface when its calendar semantics changed.**

## What the included cubes keep teaching
- **SlopOS** is still the strongest nearby teacher because D-ATTRFS keeps querying modest: query mode runs against an explicit authorized view, results are handles already reachable through that view, querying stays snapshot-first, and saved queries remain shell-owned manifests. Ward should copy the constitutional lesson again: recipe bytes are weaker than the execution frame, and calendrical grouping belongs in that frame whenever a recipe graduates into a recurring surface.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: query manifest, result snapshot, live feed, materialized local collection, and current bind are distinct. The datacube analogue here is that calendar grouping should remain another visible layer rather than disappearing into ambient UI defaults.
- **Steward** keeps teaching that local authority and host-scoped execution matter. The datacube analogue is that day/week/month grouping should remain explicitly host/surface-bound instead of being silently viewer-shaped.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows a weekly card or monthly trend, the shell should be able to say which calendar and time zone that title actually meant before two teams compare the numbers.

## What outside systems add to the datacube posture
- BigQuery adds the first discipline: `TIMESTAMP_TRUNC` uses civil time in the chosen time zone and can behave non-intuitively near DST transitions. Ward should steal that as **timezone witness** honesty, not as a commitment to BigQuery (`EXT-BIGQUERY-TIMESTAMP-FUNCTIONS-2026`).
- BigQuery adds the second discipline too: `WEEK`, `WEEK(<WEEKDAY>)`, `ISOWEEK`, and `ISOYEAR` are meaningfully different. Ward should steal that as **calendar binding** honesty, not as a commitment to one SQL dialect (`EXT-BIGQUERY-DATE-FUNCTIONS-2026`).
- Tiger Data / Timescale adds the third discipline: bucket alignment defaults to midnight UTC, can be realigned to a chosen time zone, and DST shifts can make bucketed duration irregular. Ward should steal that as **boundary drift** and **civil-bucket irregularity** discipline, not as a commitment to Timescale (`EXT-TIGERDATA-TIME-BUCKET-2026`).
- DuckDB and Druid add the fourth discipline: bucket origin is an explicit parameter, not a hidden universal. Ward should steal that as **calendar binding includes origin/alignment** posture, not as a commitment to either engine (`EXT-DUCKDB-TIMESTAMPTZ-2026`, `EXT-DRUID-SQL-SCALAR-TIME-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Every promoted recurring question grouped by day/week/month should declare a calendar binding before it earns dashboard authority.**
2. **Every published answer with local civil semantics should be able to emit a timezone witness.**
3. **A rerun under a different week rule, time zone, ISO/Gregorian boundary, or bucket origin should raise a boundary drift alarm instead of pretending facts changed and semantics stayed constant.**
4. **Ward should not let a query contract or metric card silently outrank the calendar binding that made the answer.**
5. **Ward should not bless one giant time-zone/calendar constitution while SlopOS and its siblings are still discovering their own view binding, snapshot/live, and shell-owned manifest seams.**

## Specific anti-lessons from the past
- Do **not** treat “daily” or “weekly” as self-explanatory labels.
- Do **not** compare UTC-bucketed and local-civil-bucketed answers as if the difference were cosmetic formatting.
- Do **not** let DST or ISO-year boundary effects hide behind a smooth chart title.
- Do **not** assume bucket origin/alignment is harmless implementation detail.
- Do **not** choose one universal calendar grammar, viewer-localization rule, or time-spine policy just because a few recurring questions are emerging.

## What Ward should probably steal next
- a **calendar binding** attached to any recurring surface that starts influencing decisions;
- a **timezone witness** that can say which civil-time assumption the answer actually used;
- a **boundary drift alarm** whenever the same recipe reruns under a different week rule, time zone, or bucket origin;
- UI headers that can say **basis pin + calendar binding + timezone witness + boundary drift alarm + exactness class** together when relevant;
- hygiene that refuses to let new calendrical sources drift out of the bibliography, source register, queue, front door, or manifest.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new calendar/time-bucketing sources now directly shaping datacube posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- refresh the ledgers/context surfaces so the new calendrical question shows up in the open-question and pressure queue;
- rerun the repo hygiene checks after the source-register and front-door refresh.

## Still-not-yet decisions
- engine choice;
- one canonical calendar grammar shared across all companion cubes;
- one default time zone for every recurring surface;
- one rule saying every promoted question must use civil time instead of UTC or vice versa;
- one policy saying viewer-local rendering may rewrite bucket membership after publication.
