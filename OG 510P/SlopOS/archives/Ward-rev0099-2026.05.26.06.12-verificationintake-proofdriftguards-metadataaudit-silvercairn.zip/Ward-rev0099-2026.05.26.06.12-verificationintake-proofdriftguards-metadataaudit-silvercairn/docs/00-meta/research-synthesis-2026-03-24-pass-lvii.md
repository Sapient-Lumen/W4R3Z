# Research synthesis — pass LVII

This pass keeps Ward decision-light and adds another datacube discipline: **identity and correction posture are part of meaning, and retries, updates, deletes, and current-winner projections should not masquerade as one timeless raw fact.**

## What the past says we must learn
1. **Best-effort dedupe is weaker than exact ingest truth.**  
   BigQuery’s legacy streaming API says `insertId` is only for **best-effort** deduplication and is not recommended for stronger insertion semantics. Ward should steal the constitutional lesson directly: a result that depends on retry collapse should say so instead of borrowing the authority of an exact append history (`EXT-BIGQUERY-INSERTALL-2026`).

2. **Background compaction is not the same as duplicate absence.**  
   ClickHouse says `ReplacingMergeTree` deduplication occurs only during background merges at unknown times and does **not guarantee the absence of duplicates**. Ward should steal the warning: “current winner” and “raw observed rows” are different truths even when one engine makes the winner convenient (`EXT-CLICKHOUSE-REPLACINGMERGETREE-2026`).

3. **Correction lineage should stay inspectable.**  
   Debezium’s PostgreSQL connector emits change events with `op` codes like create, update, delete, and read; it also includes `before`/`after` state plus source ordering metadata such as LSN and snapshot markers. Ward should steal the discipline: once a current row has lived through retries or corrections, the path from original event to current state should remain explicitly weaker than “raw fact” (`EXT-DEBEZIUM-POSTGRES-2026`).

4. **Deletes can be explicit state instead of disappearance.**  
   dbt snapshots require a `unique_key`, create new rows when tracked values change, and with `hard_deletes: new_record` can represent deletion as an explicit new record rather than a silent gap. Ward should steal that as a general habit: delete handling is a semantic choice that belongs in the result posture (`EXT-DBT-SNAPSHOTS-2026`, `EXT-DBT-HARD-DELETES-2026`).

5. **Identity rules belong in the contract.**  
   Once a system relies on a key, fingerprint, request token, composite natural key, or source-position rule to collapse rows, the answer inherits that choice. Ward should therefore keep the identity rule visible rather than pretending row equality or storage coincidence settled it for free (`EXT-DBT-SNAPSHOTS-2026`, `EXT-DEBEZIUM-POSTGRES-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal event-id scheme, one global upsert/delete engine, one tombstone retention policy, or one correction-history substrate.

For now, keep three more separations visible and let later specimens force promotion:
- **identity witness** — visible statement of the key/fingerprint/offset rule by which rows were treated as the same logical subject or retry family.
- **dedupe posture** — visible statement of whether duplicates were preserved, filtered by an exact key, collapsed best-effort, collapsed by background compaction, collapsed on read, or intentionally unresolved.
- **correction lineage** — visible statement of whether a current row derives from one original event, a replacement chain, a delete/tombstone chain, or another declared correction path.

## Why these separations are worth stealing
- An **identity witness** stops “same-looking row” from silently becoming “same logical fact.”
- A **dedupe posture** stops current projections from borrowing the authority of raw append history.
- A **correction lineage** stops delete/update/retry handling from disappearing behind one flattering present-state number.

## Brilliant ideas to steal now
- **retry key smaller than row identity** — do not force transport retry equivalence to become the universal subject key.
- **explicit delete-as-state** — let deletion become a typed correction event instead of a silent vanishing row.
- **winner-on-read weaker than raw history** — standing anti-regrowth rule.
- **history-with-current-head badges** — compact UI pattern for “here is the current winner, here is the correction chain behind it.”
- **dedupe posture** — explicit residue for exact, best-effort, background, on-read, or unresolved duplicate handling.

## Still-not-yet decisions
- Whether Ward eventually needs a separate noun for transport retry keys versus semantic row identity.
- Whether correction lineage should be mandatory on every promoted current projection or only when retries/updates/deletes are known to exist.
- Whether Ward should ever bless one default delete/tombstone retention story for promoted derivatives.
- Whether exact append history and current-winner projections should later get separate default browse surfaces.
