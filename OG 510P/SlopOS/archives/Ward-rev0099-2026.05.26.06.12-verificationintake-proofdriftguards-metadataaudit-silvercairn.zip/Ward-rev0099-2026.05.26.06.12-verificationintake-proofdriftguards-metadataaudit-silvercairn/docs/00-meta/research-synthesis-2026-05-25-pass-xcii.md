# Research synthesis — 2026-05-25 — pass XCII

## Research pressure

Pass XCII revisits the delivery stack behind rev0090 and rev0091. The important lesson is not new transport syntax; it is the repeated separation between delivery, acknowledgment, event identity, local policy handling, and downstream state.

- `EXT-RFC-8935` defines push delivery where a recipient indicates successful or failed transmission. That is not the same thing as consumer-local replay, cache invalidation, or renewed authority.
- `EXT-RFC-8936` defines poll delivery and delivery assurance subject to recipient need. Poll availability and acknowledgment still do not prove every downstream cache or projection refreshed.
- `EXT-OPENID-SSF-2025` frames transmitter/receiver event sharing between cooperating peers. Ward should copy the receiver-local posture while refusing to let incoming or forwarded signals become commands.
- `EXT-CLOUDEVENTS-SPEC-2026` treats source/id identity as event identity. Ward uses this to preserve duplicate posture instead of promoting duplicate notification into new refresh.
- `EXT-GCP-PUBSUB-DEADLETTER-2026` and `EXT-AZURE-EVENTGRID-DELIVERY-RETRY-2026` reinforce that retry exhaustion, drops, dead-lettering, and endpoint failure are explicit delivery states, not consumer-local reconciliation.

## Design result

The pass adds `governance-signal-notification-reconciliation-receipt.v0` as a downstream receipt from signal-notification receipts.

The receipt exists because notification fanout can succeed while consumer-local recertification fails, lags, duplicates, dead-letters, or enters conflict hold. Ward now records that gap explicitly instead of allowing a notification receipt to stand in for refresh.

## Audit/refactor result

The checker suite had become an operational risk. Thirteen checkers were listed inside `check_governance_suite.py`; adding the fourteenth would be easy to forget in a future pass. Rev0092 adds an auditable checker registry and a shared utility module:

- `tools/governance_checker_registry.json`
- `tools/governance_common.py`
- refactored `tools/check_governance_suite.py`

The refactor is intentionally modest. Existing checkers still run as they did before, but the suite now checks registry IDs, script paths, fixture directories, and duplicate entries before executing validators.

## Speculative pressure

The next likely seam is aggregate reconciliation across multiple Ward receivers or status channels. Rev0092 reconciles one notification receipt. It does not yet prove convergence when two receivers notify overlapping consumers from different channel cuts, nor does it arbitrate between receiver-local reconciliation receipts. That should become the next pass before promoting signal-notification reconciliation as a durable first-class residue.
