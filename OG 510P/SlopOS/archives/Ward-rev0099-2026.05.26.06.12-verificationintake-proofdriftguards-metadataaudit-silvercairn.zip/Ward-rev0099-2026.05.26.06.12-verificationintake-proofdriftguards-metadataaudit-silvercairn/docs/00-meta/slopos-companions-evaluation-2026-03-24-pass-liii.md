# SlopOS / companions evaluation — pass LIII

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **a repeated numeric trust question should not pretend its unit semantics are obvious.**

## What the included cubes keep teaching
- **SlopOS** is still the strongest nearby teacher because D-ATTRFS keeps querying modest: query mode runs against an explicit authorized view, results are handles already reachable through that view, querying stays snapshot-first, and saved queries remain shell-owned manifests. Ward should copy the constitutional lesson again: if query meaning already depends on view/snapshot binding, numeric result meaning also deserves explicit unit binding when a recipe graduates into a recurring surface.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: query manifest, result snapshot, live feed, materialized local collection, and current bind are distinct. The datacube analogue here is that canonical unit, normalization step, and rendered display should remain distinct layers rather than silently collapsing into one pretty card.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows a trust latency card, a failure-rate badge, or a storage-usage trend, the shell should be able to say what unit the result actually means before teams compare screenshots.
- **Steward** keeps teaching that host-local execution and local consequence matter. The datacube analogue is that auto-scaled or localized display should stay visibly weaker than the canonical number a local shell or promotion surface is actually publishing.

## What outside systems add to the datacube posture
- OpenTelemetry adds the first discipline: unit is part of metric identity, and disagreeing units may require explicit conversion to avoid semantic errors. Ward should steal that as **unit binding** and **conversion witness** honesty, not as a commitment to an observability stack (`EXT-OTEL-METRICS-DATA-MODEL-2026`).
- OpenTelemetry also adds the source-edge discipline: instruments are defined with name, kind, unit, and description. Ward should steal that as “catch unit ambiguity early,” not as a commitment to one telemetry API (`EXT-OTEL-METRICS-CONCEPTS-2026`).
- Prometheus adds the second discipline: publish base units, keep metric-name/unit agreement honest, expose ratios rather than percentages, and do not mix incompatible units under one metric. Ward should steal that as **canonical-unit-before-dashboard** posture, not as a commitment to Prometheus (`EXT-PROMETHEUS-WRITING-EXPORTERS-2026`).
- Grafana adds the third discipline: the unit setting changes display rather than underlying data, and display may auto-scale for readability. Ward should steal that as **display scale is weaker than data truth**, not as a commitment to Grafana (`EXT-GRAFANA-STANDARD-OPTIONS-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Every promoted recurring numeric question should declare a unit binding before it earns dashboard authority.**
2. **Any cross-source or cross-derivative normalization should emit a conversion witness instead of hiding conversion inside folklore.**
3. **Any rendered `%`, `ms`, `MB`, or auto-scaled human-readable label should stay visibly weaker than the canonical unit binding through a display scale.**
4. **If a source arrives with a conflicting or unknown unit, Ward should reject or quarantine the merge rather than pretending formatting can save semantics.**
5. **Ward should not bless one giant universal conversion constitution while SlopOS and its siblings are still discovering their own view binding, snapshot/live, and shell-owned manifest seams.**

## Specific anti-lessons from the past
- Do **not** treat a naked number as self-explanatory once it becomes a repeated question.
- Do **not** let `%` and ratio, or `ms` and `s`, quietly impersonate each other.
- Do **not** let a display-layer unit chooser masquerade as a data-layer conversion rule.
- Do **not** aggregate mixed-unit values just because the UI title looks singular.
- Do **not** choose one universal unit/currency/display constitution just because a few recurring questions are emerging.

## What Ward should probably steal next
- a **unit binding** attached to any recurring numeric surface that starts influencing decisions;
- a **conversion witness** that can say how raw source units were normalized before publication;
- a **display scale** that can say what the human actually saw without inflating the display choice into canonical truth;
- UI headers that can say **basis pin + query contract + unit binding + conversion witness + display scale + exactness class** together when relevant;
- hygiene that refuses to let new unit-related teachers drift out of the bibliography, source register, queue, front door, or manifest.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new unit/formatting sources now directly shaping datacube posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- refresh the ledgers/context surfaces so the unit-normalization question shows up in the open-question and pressure queue;
- rerun the repo hygiene checks after the source-register and front-door refresh.

## Still-not-yet decisions
- engine choice;
- one canonical unit registry shared across all companion cubes;
- one universal ratio-versus-percent rule for every future surface beyond the ones that earn promotion;
- one default currency/exchange-rate posture for finance-shaped metrics;
- one policy saying every display must mirror the canonical unit rather than allowing weaker human-readable scaling.
