# SlopOS companions evaluation — 2026-05-22 pass LXXXII

Pass LXXXII evaluates the new batch/search receipt against the companion set.

## SlopOS

SlopOS is the main consumer. Portal search, ACP queues, CH-AREF attachment views, artifact browsers, and resumed/truncated query surfaces can all display many Ward decisions at once.

Required behavior: SlopOS must show mixed state and replay boundaries. A result set containing a routing hint and a current consequence-grade receipt must not become a global action/export authority.

## Helm

Helm benefits immediately because rendering is where green-badge collapse usually happens.

Required behavior: Helm should render state counts, row-level labels, and no-authority markers instead of one badge. Public Helm views must not include restricted members.

## Harbor

Harbor queues may batch rechecks and corrections.

Required behavior: Harbor may use the batch receipt to schedule review/navigation work, but recompute/export/remedy actions remain per-member and require current packet replay.

## Schell

Schell pressure is minimization. Batch/search receipts must not reveal sealed break-glass details, reviewer identities, private org maps, or raw partner fragments while proving that such material exists behind a restricted projection class.

Required behavior: Schell can retain minimized summaries and sealed pointers, not public raw details.

## ViewFS

ViewFS cares about trusted paths and consent/volition cards.

Required behavior: a ViewFS trusted-path card should be able to say “mixed-state governance result; inspect per-row authority” without implying all members are actionable.

## Foundry

Foundry may expose classification pins, crosswalk witnesses, and code-drift fences through search surfaces.

Required behavior: a Foundry classification search cannot claim that all returned items have identical semantic repair authority; member-level crosswalk authority and drift state must survive aggregation.

## Steward

Steward may coordinate retries, replay guards, and pushback budgets over many governance decisions.

Required behavior: batch scheduling can group work, but budget/authority remains bound to the member packet and consumer receipt.

## Net evaluation

The batch/search receipt is justified as a v0 executable guard. It is still not a promoted durable Ward noun because cross-page reconciliation, sealed count handling, and long-running query snapshots are unresolved.
