# SlopOS / companions evaluation — pass LXII

Pass LXII treats the future SlopOS datacube as a place where comparison can accidentally become a new authority surface. A chart that says “worse than last epoch” is not just two answers placed side by side; it is a claim that the two answer capsules share enough scope, semantics, quality, and mutable cuts to support the comparison.

## What the included cubes keep teaching

- **SlopOS** remains the anchor. D-ATTRFS already says queries are view-scoped, snapshot-first, handle-returning, bounded, and not a count/existence oracle. Ward's new pressure is that a comparison between two SlopOS answer capsules must not widen authority by aligning hidden populations, silently dropping refused cells, or treating changed CH-ATTR/CH-ATTRQ schema digests as a harmless implementation detail.
- **Harbor** is the closest datacube sibling for this pass. Its datacube design principles, change-history lanes, contract tiers, time axes, aggregation semantics, and restatement receipts all point to one rule: comparison needs a lane and contract story, not just row values. Ward should borrow the posture but keep Ward-specific nouns focused on trust-bearing comparison.
- **ViewFS** reminds Ward that handles, previews, manifests, exported batches, and durable answer capsules differ in strength. A ViewFS export can be comparison material only if its scope/state/refusal/quality residues survive the export boundary.
- **Foundry** keeps basis, candidate generation, active generation, restore duty, and foreign handles separate. Ward should not compare trust answers across Foundry-shaped basis changes unless the comparability passport says which basis changed and whether a bridge exists.
- **Steward** keeps activation, bootstrap, reconciliation, and followthrough receipts from collapsing into “done.” Ward should apply the same caution to datacube comparisons: a reconciled current state is not automatically comparable with a pre-reconciliation answer.
- **Schell** keeps basis cards, activation receipts, environment epochs, and operator-visible secret/material posture distinct. Ward should not let an operations chart compare across environment epoch changes without a drift notice.
- **Helm** is where the harm becomes visible. It must be able to show “comparable,” “bridged,” “incomparable,” “quality-gated,” and “refused” without turning them all into ordinary missing/gray cells.

## What this means for the SlopOS datacube

A SlopOS-facing answer comparison should require at least:

1. **Two or more answer capsules, not two naked tables.** Each side needs scope lens, state cut witness, axis capsule, lineage facet, refusal receipt posture, and any relevant privacy/resolution/calendar/unit/identity residues.
2. **A comparability passport before a trend.** The passport should state which equalities were checked: view/scope, schema/query digest, metric/query card, axes/grain, policy epoch, quality witness, materialization generation, redaction profile, and refusal coverage.
3. **Drift notices for every material change.** Schema evolution, metric formula change, policy epoch change, quality threshold change, bridge mapping, and changed source contract are not renderer trivia.
4. **Quality witnesses near the answer, not only near the pipeline.** A result that built successfully but failed a high-severity validation gate should not influence trust consequence without visible qualification.
5. **Bridge-required is a first-class state.** When a label, dimension member, metric formula, or policy epoch changes, Ward can allow a bridge, but the bridge must itself become residue.
6. **Incomparability can be the right answer.** Refusing to draw a before/after arrow may be the most truthful outcome.

## Companion-specific steals

- From **Harbor**: restatement receipts, change-history lane cards, contract-tier cards, and time-axis cards — but use them as pressure, not imports.
- From **Foundry**: basis/candidate/active distinctions for detecting when a comparison crosses realization generations.
- From **Steward**: reconciliation receipts as a reminder that “caught up” and “same semantics” are different truths.
- From **Schell**: activation/environment epochs as drift material, especially for operator-facing trust charts.
- From **ViewFS**: export-manifest humility; exported bytes need residues before they can serve as native comparison truth.
- From **Helm**: visible badges and refusal affordances for humans, especially when a chart segment is bridged or incomparable.

## Anti-lessons to preserve

- Do **not** let “same query text” imply same population, model, quality, or authority.
- Do **not** let “schema-compatible” imply “quality-compatible” or “semantically comparable.”
- Do **not** silently restate history under new policy or metric logic.
- Do **not** hide failed validation, warning-level validation, or unrun validation in build logs.
- Do **not** turn an unbridged scope or policy drift into a smooth trend line.
- Do **not** let LLM narration explain away incomparability; deterministic residue must earn comparison.

## What Ward should probably steal next

- a **comparability passport** for any promoted before/after, trend, cohort contrast, or rerun-vs-history chart;
- a **drift notice** whenever a comparison crosses changed scope, semantics, source contract, quality threshold, schema identity, policy epoch, or materialization generation;
- a **quality witness** whenever a validation or contract subset shaped the trustworthiness of answer cells;
- a standing **same title is weaker than comparable** rule for dashboards, agents, and promotion gates.
