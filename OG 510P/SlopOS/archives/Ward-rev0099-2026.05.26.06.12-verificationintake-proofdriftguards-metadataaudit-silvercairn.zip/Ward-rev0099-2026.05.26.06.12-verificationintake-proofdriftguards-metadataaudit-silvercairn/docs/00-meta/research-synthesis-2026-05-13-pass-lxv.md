# Research synthesis — pass LXV

Pass LXIV made reuse visible: a fast, cached, materialized, or incrementally maintained answer is not authority unless its freshness envelope, invalidation receipt, and recompute docket survive inspection. Pass LXV moves one layer outward. Once an answer capsule exists, people and agents touch it: filter it, parameterize it, drill through it, sort it, render it, screenshot it, embed it, export it, quote it, and ask follow-up questions against it. Those operations can silently become a second cube.

The restraint rule still holds. Ward should not choose a dashboard product, visualization grammar, notebook stack, telemetry backend, export format, annotation protocol, or agent transcript schema while SlopOS remains in design. The healthy move is to name the smallest residues that keep interaction, rendering, and egress weaker than answer authority.

## What the past says we must learn now

1. **Interaction is a query surface.** Vega-Lite parameters explicitly map user input such as clicks, drags, sliders, and dropdowns into data queries and encoding/filter behavior (`EXT-VEGA-LITE-PARAMETERS-2026`). Metabase dashboard filters and parameters likewise change what data is displayed or how it is displayed (`EXT-METABASE-DASHBOARD-FILTERS-2026`). Ward should treat dashboard gestures and agent follow-ups as bounded query acts, not harmless UI state.

2. **Render transforms are semantic, not paint.** Vega-Lite view specs and transform docs make filtering, binning, time-unit conversion, aggregation, sorting, stacking, windowing, and pivoting part of the visualization specification (`EXT-VEGA-LITE-TRANSFORMS-2026`). If a renderer bins a timestamp, hides an “other” bucket, changes sort order, truncates top-k rows, or flattens a hierarchy, the rendered answer has a different contract than the source answer capsule.

3. **Saved analytical objects often mix query, result, and visualization.** Metabase describes a question as a query, its results, and its visualization (`EXT-METABASE-QUESTIONS-2026`). That is brilliant product ergonomics and dangerous constitutional language. Ward should steal the convenience while keeping query contract, answer capsule, render contract, and egress receipt separable.

4. **Export is not a neutral copy.** Power BI distinguishes current-layout, summarized, and underlying export, notes that filters and aggregates affect exported data, and documents row/cell/file-size limits, permission controls, row-level-security effects, omitted-data messages, and local datetime-format changes (`EXT-POWERBI-EXPORT-DATA-2026`). Ward should assume every export/share/screenshot is a new artifact with its own egress receipt.

5. **Tabular exchange needs metadata, not just bytes.** W3C CSV on the Web defines a tabular data model and metadata usable for validation, display, and conversion (`EXT-W3C-TABULAR-DATA-MODEL-2015`). Ward should steal the idea that detached tabular outputs deserve explicit metadata, but avoid declaring CSVW, Arrow, Parquet, or any format as the SlopOS cube constitution.

6. **Operational trace patterns are useful but insufficient.** OpenTelemetry traces model operations through spans, and its logs data model aims at a common understanding of log records that can be mapped between formats (`EXT-OTEL-TRACES-2026`, `EXT-OTEL-LOGS-DATA-MODEL-2026`). Ward should steal correlation and loss/accounting discipline, but an interaction trail is not merely telemetry; it is answer authority residue subject to view, privacy, and refusal rules.

7. **Annotations need anchors and humility.** W3C Web Annotation models bodies and targets, including links to data points and machine-created annotations, without prescribing one transport (`EXT-W3C-WEB-ANNOTATION-2017`). Ward should steal anchorable comments/exceptions on cube cells or rendered regions, but annotations must not rewrite answer cells or smuggle new authority.

8. **The old dashboard failure is context evaporation.** A screenshot, alert email, CSV, copied table, embedded chart, or agent-written summary often outlives the scope lens, state cut witness, privacy posture, quality witness, comparability passport, freshness envelope, and refusal receipts that made the source answer safe. SlopOS's D-ATTRFS / CH-ATTRQ posture says the opposite: view-scoped, snapshot-first, handle-returning answers should not gain ambient portability through visual polish.

## Resulting Ward move

Do **not** decide yet:

- one visualization grammar, dashboard system, chart specification, or notebook protocol;
- one interaction transcript schema, telemetry backend, or audit-log store;
- one export format, sharing service, screenshot format, or embed token system;
- one renderer warning vocabulary, badge set, palette, or interaction affordance;
- one global rule that drill-through, export, or share is always allowed when base answer is allowed;
- one way for agents to maintain conversational context across cube follow-ups;
- one ontology for annotations, comments, flags, or review notes.

Do add three small, reversible residues for answer handling:

- **interaction trail** — compact transcript of user/agent/tool operations on an answer capsule: open, filter, parameter change, drill, pivot, sort, top-k, refresh, render change, export/share, annotation, and refused operation. It names actor class, authority scope, input bindings, query/render/egress digests, inherited state cut, exposure class, and refusal/withholding reasons. It is smaller than a telemetry system and stronger than an ephemeral UI session.
- **render contract** — compact binding between an answer capsule and a presented table/chart/card: transformations, filters, bins, aggregation, sort/limit/top-k, hidden/other buckets, suppressed/denied/missing states, scale/unit/timezone/calendar/display precision, row/cell limits, warning posture, and renderer/version if material. It is smaller than a UI toolkit and weaker than the source answer capsule.
- **egress receipt** — compact record for an answer artifact that leaves the live cube surface: CSV, spreadsheet, image, copied table, alert, embedded chart, report, message, or agent summary. It names source capsule, render contract, scope lens, redaction/suppression, rows/cells included or omitted, format, sensitivity/expiry, share target class, detached-from-live posture, and invalidation/retraction hooks. It is smaller than DLP and weaker than a live query handle.

These residues sit beside previous pass nouns. An interaction trail uses scope lenses, state cut witnesses, query contracts, refusal receipts, comparability passports, exemplar fences, freshness envelopes, invalidation receipts, and recompute dockets. A render contract constrains explanation, comparison, and privacy posture. An egress receipt makes detached artifacts reviewable without pretending they are live authority.

## Brilliant ideas to steal now

- **Grammar of interaction** — clicks, drags, filters, parameters, and agent prompts are not invisible; they are small query events with bindings.
- **Render spec as evidence** — binning, sorting, filtering, current-layout export, stack/aggregate decisions, and top-k truncation should be inspectable next to the chart.
- **Questions as ergonomic bundles, not constitutions** — save query/result/viz together for humans, but keep their residues separable for Ward.
- **Export rows/cells/limits as first-class evidence** — every egress artifact should know if it is summarized, underlying, current-layout, truncated, redacted, suppressed, filtered, or stale.
- **Metadata sidecar before format loyalty** — detached tables should carry enough metadata for validation/display/conversion without freezing CSVW, Arrow, Parquet, or one exchange stack.
- **Trace-like correlation without telemetry authority** — interaction trails can borrow span/log correlation while refusing to become a hidden analytics surveillance channel.
- **Anchored annotations** — comments and review notes should target cells, axes, ranges, capsules, or rendered regions, but should never silently patch answer meaning.
- **Detached artifacts decay** — screenshots, CSVs, alerts, embeds, and agent summaries should carry freshness/invalidation posture or lose consequence-grade standing.

## Still-not-yet decisions

- Whether interaction trails are mandatory for all cube sessions, only consequence-grade sessions, or only agent/drill/export sessions.
- Whether render contracts attach to every rendered surface or only when transformations/limits/suppression occur.
- Whether egress receipts are required for screenshots and copied text, or only for programmatic export/share/embed artifacts.
- Whether annotations deserve a separate noun or live inside interaction trail / render contract / review residue.
- Whether renderer warnings should be machine-checkable badges, human copy, or both.
- Whether an exported artifact can later receive an invalidation notice without creating a global recall system.
- Whether an agent may use an egress artifact as context for a follow-up, or must rehydrate through a live view-bound query.
- Whether live dashboards need periodic interaction-trail checkpoints to avoid infinite transcript growth.

## Process note

Pass LXV does not add a dashboard framework. It adds language for refusing interaction, renderer, and export authority laundering. The next healthy move is to run these residues against a Helm dashboard where a human filters a trust answer, an agent drills into a suspicious cell, the renderer hides an “other” bucket and suppressed cells, and a CSV/screenshot leaves the live surface. If Ward cannot say which interactions happened, what the renderer changed, and what detached artifact was actually exported, the artifact should be review-only or refused rather than consequence-grade evidence.
