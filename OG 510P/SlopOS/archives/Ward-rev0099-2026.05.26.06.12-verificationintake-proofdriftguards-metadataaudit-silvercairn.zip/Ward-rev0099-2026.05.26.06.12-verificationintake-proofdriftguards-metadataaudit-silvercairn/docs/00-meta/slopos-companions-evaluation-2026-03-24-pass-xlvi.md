# SlopOS / companions evaluation — pass XLVI

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **approximate answers can be useful, but only if Ward makes their exactness posture impossible to confuse with replayable exact truth**.

## What the included cubes keep teaching
- **SlopOS** is still the most useful direct teacher because D-ATTRFS keeps querying modest: **view-scoped**, **snapshot-first**, **handle-returning**, with saved queries remaining **shell-owned manifests** and live mode **optional and bounded**. That means Ward should stay suspicious of any approximate layer that quietly grows into an ambient semantic oracle while SlopOS itself is still design-phase.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: **query manifest**, **result snapshot**, **live feed**, **materialized local collection**, and **current bind** are distinct. Ward can now borrow one more distinction above that seam: an approximate derivative should advertise its **exactness class**, and if it is sketch-backed it should keep that residue distinct from a plain rendered result.
- **Steward** keeps teaching that remembered structure is weaker than current liveness. That is the right humility for approximate analytics too: a remembered estimate, cached sketch, or stale approximate card should never impersonate current exact truth.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows approximate trust surfaces in human-facing UI, the UI should be able to say `exact`, `exact-derived`, `approximate`, `sketch-backed`, or `not replayable` instead of collapsing everything into one flattering metric badge.

## What outside systems add to the datacube posture
- BigQuery's approximate aggregate docs make the first anti-lesson explicit: approximate aggregation introduces statistical uncertainty, and BigQuery separates simple approximate functions from sketch-specific functions where precision can be specified. Ward should borrow the separation as an **exactness class** and an **estimator card**, not as a commitment to BigQuery's exact API split (`EXT-BIGQUERY-APPROX-AGG-2026`).
- DuckDB's approximate aggregate docs make a second anti-lesson explicit by naming the estimator families directly. Ward should borrow that honesty so a future approximate trust surface does not hide algorithm swaps under one stable-looking metric label (`EXT-DUCKDB-APPROX-AGG-2026`).
- Druid plus Apache DataSketches add the important positive lesson: sketches are mergeable streaming algorithms, can be stored as additive metrics, and in the Theta family can return sketches from set operations rather than only final numbers. Ward should borrow that as optional **sketch witness** posture, not as a mandate to pick one sketch family already (`EXT-DRUID-DATASKETCHES-2026`, `EXT-DATASKETCHES-THETA-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Approximate answers must declare an exactness class instead of borrowing the authority of exact replay.**
2. **Any approximate or sketch-backed recurring surface should carry an estimator card naming family, mergeability, precision/tuning posture, and caveats.**
3. **Rendered estimates and mergeable sketch state should remain visibly different classes.**
4. **Approximate acceleration should stay weaker than saved recipe, weaker than frozen exact result, and weaker than final local consequence.**
5. **Ward should not bless one universal sketch family while SlopOS and its siblings are still actively finding the right analytic seams.**

## Specific anti-lessons from the past
- Do **not** let approximate answers sit in the same truth class as replayable exact results.
- Do **not** hide algorithm-family changes behind a stable metric title.
- Do **not** flatten one mergeable sketch artifact into one naked approximate number if later set algebra or recomposition matters.
- Do **not** choose HLL/KLL/theta/t-digest as Ward's constitution this early.
- Do **not** let a sketch-backed derivative masquerade as a complete raw-history substitute.

## What Ward should probably steal next
- an **exactness class** state distinct from query contract, metric card, and frozen result;
- an **estimator card** that makes algorithm family and error posture legible without requiring a giant semantic layer;
- a **sketch witness** lane for promoted approximate derivatives that keep mergeable state;
- UI headers that can say **basis pin + join clock + exactness class + loss posture** together when relevant;
- hygiene that refuses to let new approximation-driving sources drift out of the register, queue, front door, or manifest.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new approximation/sketch sources that are now directly shaping datacube posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- rerun the repo hygiene checks after the ledger and front-door refresh.

## Still-not-yet decisions
- engine choice;
- one universal exactness taxonomy;
- one canonical sketch family;
- one mandatory sketch-witness format;
- one rule that every future metric card must be approximate-aware from day one.
