# Research synthesis — pass XXX

This pass keeps Ward cautious and learns one more thing from distributed logic, provenance, and belief-maintenance systems: **monotone accumulation, closure-dependent negatives, and multi-support derivations are different truths.**

## Outside lessons
1. **Some truths can safely accumulate; others require an explicit closure point before they are trustworthy.**  
   The CALM theorem says monotonic programs can have a consistent coordination-free distributed implementation, while non-monotonic programs “change their mind” in the face of new information and therefore require coordination. Ward should steal the small design consequence: a trust cube should not quietly treat “nothing bad has arrived yet” as the same kind of truth as “one more support has arrived.”

2. **Non-monotonic pressure should be isolated at named gates instead of smeared across the whole design.**  
   Bloom’s CALM work turned monotonicity into a practical analysis technique and explicitly suggested that anomalies can be handled either by introducing coordination at the relevant points or by tracking inconsistency/taint as it propagates. Ward should steal that habit: keep closure-dependent rules visible instead of letting them become ambient behavior.

3. **One result may have several derivations, and losing one derivation is not the same as losing the result.**  
   Provenance semirings treat output tuples as carrying “how-provenance,” not just contributing inputs. The provenance of one result can record several distinct derivations, and coefficients can count the degree of ambiguity / number of derivations. Ward should steal the humility: if one support path disappears, a local consequence should narrow only if no acceptable alternate derivation remains.

4. **Belief maintenance deserves its own smaller lane.**  
   Classic truth-maintenance work framed the core idea as an independent module for maintaining beliefs, and emphasized monotonic systems as the solid foundation on which other reasoning can be built. Ward should steal that shape, not the whole apparatus: belief revision is smaller than custody, smaller than evidence, and smaller than final spend consequence, but it still deserves its own visible residue.

5. **Shared support state is cheaper and safer when it is indexed once instead of recomputed everywhere.**  
   Materialize and differential dataflow both make the same implementation-side suggestion: represent updates as `(data, time, diff)` and share indexed arrangements across overlapping queries rather than rebuilding the same support index repeatedly. Ward should not standardize that implementation now, but it is a brilliant idea worth keeping nearby if several future projections need the same support history.

## Resulting Ward move
Do not decide yet whether Ward’s long-term derivation/belief-maintenance surface is provenance-polynomial-shaped, dependency-graph-shaped, count-shaped, or just compact residue on specific projections.

For now, preserve four separations and let later specimens force promotion:
- `monotonicity class` versus freshness, completeness frontier, or final local consequence;
- `closure gate` versus ordering window, apply cursor, or lateness budget;
- `support braid` versus one flattened “reason” string or one giant provenance graph;
- `alternate derivation` versus silent full retraction when one support path disappears.

## Fresh ideas worth stealing
- **monotonicity class** — explicit note about whether a residue safely accumulates or may still require mind-changing.
- **closure gate** — visible point where absence-, threshold-, or count-shaped logic becomes strong enough to use.
- **support braid** — compact linkage among the distinct support paths currently underwriting one local result.
- **alternate derivation** — residue that another acceptable support path still exists after one path is withdrawn.
- **invalidation cascade** — explicit propagation trail when a withdrawn support forces secondary narrowing.
- **support smaller than verdict** — a standing anti-regrowth rule.
