# SlopOS / companions evaluation — pass XXXI

This pass keeps Ward embryonic while stealing one more useful habit from the neighbors and from versioned data systems: **keep exact cuts smaller than moving selectors, make stable-reader pins explicit, and keep retention/GC policy separate from naming.**

## What the current cubes still teach
- **SlopOS** already has the strongest nearby lesson for this pass in ADR-0004 and the boot/init surfaces: exact compiled artifacts and digests stay visible, generation selection stays outside the privileged core, and retention/GC remains explicit user-space policy. Ward should steal the smaller analog: name exact trust cuts first, then let any “current” alias remain visibly weaker and easier to move.
- **SlopOS** also treats generation-change signals as observational rather than authority-bearing. That is a perfect warning for Ward too: an alias move or generation change is evidence about selection/history, not automatic permission to spend or trust.
- **SlopOS** keeps rollback normal instead of exceptional. Ward should mirror that habit by making `reader pin` a first-class pressure surface rather than treating stable historical evaluation as an exotic debug mode.
- **ViewFS** and **Foundry** still remind Ward that imported history can remain addressable while practical readability and consequence depend on additional local policy. That pressure rhymes with retention floors: do not promise historical readability unless the archive really keeps the bytes.

## Current recommendation
Keep Ward open on whether cut identity lives as snapshot IDs, digests, commit-like hashes, log coordinates, or some other carrier.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **published cut** instead of treating “latest” as if it were immutable truth;
2. **moving alias** instead of one silent overwrite of the current answer;
3. **reader pin** instead of ambient reading from whatever the alias points at when evaluation happens;
4. **retention floor** instead of fake confidence that historical names imply retained readable bytes;
5. **archive-identity coherence lint** so folder name, manifest, receipt, and revision summary cannot quietly drift apart.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should still avoid freezing one universal snapshot table, one ref namespace, one GC algorithm, or one pin/lease protocol into the archive.
The smaller steal is enough for now:
- keep exact-cut identity distinct from moving aliases;
- require historical readability claims to name a retention floor;
- and fail the revision if archive identity surfaces disagree about which revision/codename this archive actually is.

## Still-not-yet decisions
- Whether `published cut` belongs in Ward proper or remains archive/process guidance until more specimens accumulate.
- Whether `moving alias` should be durable Ward vocabulary or remain an implementation choice of adjacent history/projection tooling.
- Whether `reader pin` belongs in Ward or in an adjacent observation/history cube.
- Whether `retention floor` should be first-class trust residue or remain implementation/ops posture attached to historical reads.
- Whether Ward should ever standardize one alias-history carrier, or only insist that alias movement be inspectable and weaker than the cut itself.
