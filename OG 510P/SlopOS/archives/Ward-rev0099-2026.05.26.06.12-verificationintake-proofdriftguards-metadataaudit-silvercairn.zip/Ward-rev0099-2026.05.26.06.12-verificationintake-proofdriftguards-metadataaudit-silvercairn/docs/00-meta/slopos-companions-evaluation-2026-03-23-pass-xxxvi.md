# SlopOS / companions evaluation — pass XXXVI

This pass keeps Ward embryonic while stealing one more useful habit from SlopOS and the sibling cubes: **separate acceptance, durable commitment, stable-readable visibility, and hard-to-reverse finality instead of collapsing them into one green after-state.**

## What the current cubes still teach
- **SlopOS** keeps teaching the right design temperament: exact boundary language, explicit local-policy ownership, and drift gates that stop one imported success signal from regrowing into a universal truth. Ward should steal the small analog here: do not let one acknowledgment, one replication state, and one final consequence masquerade as the same object.
- **Helm** is the clearest nearby teacher for this pass. Its new settlement-witness / commit-card pressure says an action can be accepted, locally durable, quorum durable, replicated, or receiver-visible without those being the same truth. Ward should steal the truth-shape, not the shell rendering.
- **Schell** and **Steward** keep pressuring Ward not to confuse receiver-local adoption or teardown success with durable shared truth. That fits this pass directly: one downstream consumer may still lag even after a stronger upstream commit witness exists.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one witness carrier, one consensus proof family, one settlement registry, or one queue/log/table substrate into the datacube.

## Current recommendation
Keep Ward open on whether commitment/finality truth ultimately travels as consensus receipts, replicated-log metadata, transaction-side read frontiers, checkpoint witnesses, or some mixed shape.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **commit witness** instead of pretending a returned success already means durable truth;
2. **stable frontier** instead of letting “latest seen anywhere” masquerade as safe reader-visible truth;
3. **finality class** instead of promising one timeless durability level;
4. **exposure gate** instead of letting the substrate choose when high-risk local consequence becomes spendable;
5. **current-revision-first changelog lint** so the archive’s changelog front door cannot silently lag behind the packaged revision.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep acknowledgment weaker than commitment;
- keep commitment weaker than stable reader visibility when one receiver can still lag;
- keep finality class visible when reversal cost changes materially; and
- fail the revision if `CHANGELOG.md` does not put the current revision first.

## Still-not-yet decisions
- Whether `commit witness` belongs in durable Ward vocabulary or remains imported durability/consensus residue until more specimens accumulate.
- Whether `stable frontier` belongs inside Ward, or in an adjacent observation/history cube that owns exact read cuts.
- Whether `finality class` should stay smaller than spendable consequence, or eventually become part of Ward’s durable trust-result family.
- Whether `exposure gate` is best treated as a local policy-side render of other residue, or a first-class Ward noun later.
