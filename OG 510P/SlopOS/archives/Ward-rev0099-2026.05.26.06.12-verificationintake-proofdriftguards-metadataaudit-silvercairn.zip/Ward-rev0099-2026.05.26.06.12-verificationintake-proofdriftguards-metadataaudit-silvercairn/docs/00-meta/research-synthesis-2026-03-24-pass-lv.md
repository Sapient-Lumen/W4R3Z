# Research synthesis — pass LV

This pass keeps Ward decision-light and adds another datacube discipline: **distribution surfaces have their own semantics, and bucket grids plus percentile derivation should not masquerade as one timeless truth.**

## What the past says we must learn
1. **Bucket layout controls the error you buy.**  
   Prometheus says that with histograms you control error in the dimension of the observed value via the bucket layout, while summaries control error in the quantile dimension. The same Prometheus guidance also says to choose histograms if you need to aggregate across instances. Ward should steal the constitutional lesson: a recurring p95 or tail surface is inseparable from the bucket schema or summary/sketch family that produced it (`EXT-PROMETHEUS-HISTOGRAMS-2026`).

2. **Bucket interpolation is a real semantic move, not just chart polish.**  
   Prometheus explicitly shows histogram quantiles being linearly interpolated within a bucket and warns that different distributions can make the interpolated percentile look much better or much worse than the true value. Ward should steal the humility: when a recurring percentile comes from bucket interpolation, that derivation belongs in the result meaning rather than ambient folklore (`EXT-PROMETHEUS-HISTOGRAMS-2026`).

3. **Boundary semantics matter.**  
   The OpenTelemetry metrics data model says explicit histogram upper bounds are inclusive and lower bounds are exclusive, and it warns that changing inclusivity/exclusivity is itself a source of worst-case histogram error. Ward should steal that directly: one bucket grid is not fully specified until the boundary semantics are declared (`EXT-OTEL-METRICS-DATA-MODEL-2026`).

4. **Exponential histograms bring one brilliant idea: perfect subsetting.**  
   OpenTelemetry describes ExponentialHistogram bucket boundaries with a scale parameter and says a higher-resolution histogram can map exactly into lower-resolution ones without introducing error. Ward should absolutely steal the idea while refusing the premature engine decision: if a future distribution surface needs downscaling or merge-friendly compression, the family should say whether it has perfect-subsetting behavior (`EXT-OTEL-METRICS-DATA-MODEL-2026`).

5. **Overflow and zero handling are part of meaning.**  
   Prometheus’s native histogram spec says custom bucket values are upper-inclusive, that the first bucket starts at `-Inf`, and that values above the last custom boundary go into an overflow bucket with `+Inf`. Ward should steal that honesty: “p99 over the last bucket” and “everything above the last bound” are different truths, and the overflow posture should not hide inside the rendering code (`EXT-PROMETHEUS-NATIVE-HISTOGRAMS-2026`).

6. **Not every quantile surface is safely mergeable.**  
   OpenTelemetry marks Summary as a legacy type and says summary points cannot always be merged meaningfully. Ward should steal the warning: a percentile answer may be distribution-shaped but still not behave like a recomposable cube fact (`EXT-OTEL-METRICS-DATA-MODEL-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal explicit-bucket layout, one exponential-histogram family, one summary/sketch percentile carrier, or one percentile publication contract for all recurring questions.

For now, keep three more separations visible and let later specimens force promotion:
- **bucket schema** — visible statement of the distribution grid or family behind a recurring distribution surface.
- **boundary witness** — visible statement of inclusivity/exclusivity, zero/underflow/overflow handling, and any other bucket-boundary semantics that affect interpretation.
- **interpolation posture** — visible statement of whether a percentile/tail answer is exact, bucket-interpolated, sketch-estimated, or unavailable.

## Why these separations are worth stealing
- A **bucket schema** stops two distribution surfaces with different grids from sharing one metric title as if they were identical.
- A **boundary witness** stops cumulative buckets, upper-inclusive buckets, and overflow buckets from disappearing into “implementation detail” language.
- An **interpolation posture** stops a linearly interpolated percentile from borrowing the authority of an exact replayable percentile.

## Brilliant ideas to steal now
- **perfect subsetting** — a histogram family that can lower resolution without inventing new error.
- **overflow posture** — explicit statement of what happens above the last bucket boundary instead of pretending the tail vanished.
- **boundary witness** — compact residue for inclusivity/exclusivity and special buckets.
- **interpolation posture** — visible note on whether the percentile is exact, bucket-interpolated, or sketch-estimated.
- **distribution surface weaker than raw population** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward should ever bless one universal histogram family across engines.
- Whether overflow posture belongs in every promoted distribution surface or only when the last bucket is materially load-bearing.
- Whether exact percentile replay, bucket-interpolated percentile, and sketch-estimated percentile should become first-class truth classes or remain smaller result-local residue.
- Whether a future query contract for distribution questions needs machine-readable boundary semantics or only human-facing receipts at first.
