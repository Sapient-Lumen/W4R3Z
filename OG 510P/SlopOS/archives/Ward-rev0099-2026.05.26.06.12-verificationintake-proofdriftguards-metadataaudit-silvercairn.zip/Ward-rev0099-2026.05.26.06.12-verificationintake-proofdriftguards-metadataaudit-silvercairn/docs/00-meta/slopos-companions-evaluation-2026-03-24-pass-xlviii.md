# SlopOS / companions evaluation — pass XLVIII

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **a repeated trust question should not be promoted until Ward can say what one row means, where joins may multiply it, and what denominator/weight must survive if the result is later regrouped.**

## What the included cubes keep teaching
- **SlopOS** is still the strongest nearby teacher because RFC-0100 keeps querying modest: **view-scoped**, **snapshot-first**, **handle-returning**, with saved queries remaining **shell-owned manifests** and live mode **optional and bounded**. That posture reinforces the new lesson nicely: query convenience should stay smaller than result meaning, and result meaning should stay smaller than a promoted derivative.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: **query manifest**, **result snapshot**, **live feed**, **materialized local collection**, and **current bind** are distinct. This revision adds one more split inside the result itself: the answer also needs a visible **grain witness**, and cross-grain joins need a **fanout fence** before one dashboard tile can inherit the social authority of “the metric.”
- **Steward** keeps teaching that remembered structure is weaker than current liveness. The analogous datacube lesson is that one cached ratio or average is weaker than the denominator/weight state needed to recompute it honestly later.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows rates, averages, or ratios in a human-facing shell, the UI should be able to say what the base grain was and whether the result still carries the denominator/weight story or only a rendered number.

## What outside systems add to the datacube posture
- Looker’s symmetric-aggregates docs make the first anti-lesson explicit: one-to-many joins can make a previously correct aggregate wrong, and safe recovery depends on a unique primary key plus the right join relationship. Ward should borrow that as a **grain witness** and **fanout fence**, not as a commitment to Looker’s whole modeling stack (`EXT-LOOKER-SYMMETRIC-AGG-2026`).
- dbt’s MetricFlow join docs add the second anti-lesson: join logic should know when to avoid **fan-out** or **chasm** joins instead of treating every linked table as equally harmless. Ward should borrow that as visible join hygiene, not as a decision to freeze one universal entity graph while SlopOS is still moving (`EXT-DBT-METRICFLOW-JOINS-2026`).
- Cube’s multi-stage calculations docs add the third lesson: some repeated questions only stay meaningful because they compute an inner measure at one specific grain and only then aggregate it outward. Ward should borrow that as **grain witness** posture for repeated questions that would otherwise drift into average-of-averages mistakes (`EXT-CUBE-MULTI-STAGE-2026`).
- dbt ratio metrics plus DuckDB/ClickHouse weighted-average functions add the denominator lesson: rates and averages need explicit numerator/denominator or weight posture when they are meant to survive regrouping. Ward should borrow that as optional **weight carrier** posture, not as a commitment to one warehouse engine or one metric compiler (`EXT-DBT-RATIO-METRICS-2026`, `EXT-DUCKDB-WEIGHTED-AVG-2026`, `EXT-CLICKHOUSE-AVGWEIGHTED-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Every promoted recurring question must declare a grain witness for each measure-bearing input before it earns dashboard authority.**
2. **Every join that can multiply measure rows must cross a fanout fence that says whether the result is duplication-safe, deduped, replay-only, or simply forbidden.**
3. **Every promoted rate/average/ratio that may need honest regrouping should keep a weight carrier or stay explicitly replay-only.**
4. **Ward should not let one subgroup percentage or average quietly masquerade as a safe higher-level total after the denominator/weight story has been discarded.**
5. **Ward should not bless one universal semantic constitution while SlopOS and its siblings are still actively discovering their shell, manifest, and result seams.**

## Specific anti-lessons from the past
- Do **not** let one-to-many joins silently multiply trusted facts.
- Do **not** let a repeated question change meaning because the inner grain changed but the label stayed the same.
- Do **not** average averages or regroup percentages after throwing away the denominator/weight story.
- Do **not** confuse join convenience with duplication-safe truth.
- Do **not** pick one giant entity graph or semantic compiler just because a few repeated questions are emerging.

## What Ward should probably steal next
- a **grain witness** attached to any recurring measure surface that starts influencing decisions;
- a **fanout fence** that stays smaller than both the query contract and the final local consequence;
- optional **weight carrier** residue for promoted rates, averages, and ratios that need honest regrouping;
- UI headers that can say **basis pin + join clock + grain witness + fanout posture + weight carrier + aggregation law + exactness class** together when relevant;
- hygiene that refuses to let new grain/fanout/weight sources drift out of the bibliography, source register, queue, front door, or manifest.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new grain/fanout/weight sources that are now directly shaping datacube posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- rerun the repo hygiene checks after the ledger and front-door refresh.

## Still-not-yet decisions
- engine choice;
- one canonical entity graph;
- one mandatory machine-readable grain/fanout schema;
- one default denominator/weight-carrier encoding;
- one rule that every future metric card must already know its full join graph from day one.
