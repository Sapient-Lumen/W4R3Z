# SlopOS / companions evaluation — pass XXIII

This pass re-checks Ward against SlopOS plus the sibling cubes and keeps the datacube embryonic on purpose.

## What the current cubes still teach
- **SlopOS** already keeps provenance-coverage policy local and machine-checks that discovery and same-revision maintenance stay honest. Ward should steal the *discipline*: status carriers may point at evidence or coordinates, but they should not silently choose the verifier's coverage policy or smuggle bibliography drift into the archive.
- **SlopOS** also keeps certificate-status and collateral-status evaluation as explicit local evidence plus explicit local policy, not as an ambient fetch entitlement. Ward should likewise resist turning every status-bearing trust object into a portable live-oracle promise.
- **ViewFS** keeps delta truth and apply ladders explicit. Ward should therefore preserve the difference between one calm snapshot, one bounded delta sequence, and one heuristic “latest-looking” fetch.
- **Harbor** continues to keep detour success smaller than local adoption. Ward should likewise keep issuer coverage, proof-carrying absence, and final local spend consequence visibly separate.
- **Steward** keeps freshness decay and followthrough honest. Ward should likewise keep `unknown posture` explicit when coverage, freshness, or service reachability is not strong enough to support a real negative inference.

## Current recommendation
Keep Ward open on transport, packaging, and proof substrate.

The next wise move is still a specimen, not a schema family:
1. **coverage witness** versus generic negative status,
2. **unknown posture** versus false green,
3. **proof-carrying absence** versus heuristic not-seen,
4. **snapshot-plus-deltas** versus live point lookup.

Do **not** decide yet whether Ward's long-term status ecology prefers:
- compressed status corpora,
- point lookups,
- transparency-backed queries,
- event streams,
- plural receipts,
- or a mixed design.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should still avoid heavyweight closed-family machinery.
The smaller steal is enough for now:
- keep load-bearing outside sources explicit,
- update register/bibliography/research surfaces in the same revision when new sources become design-shaping,
- and make one tiny drift gate verify that the revision receipt's `outside_sources` list cannot point at bibliography ghosts.

## Still-not-yet decisions
- Whether `coverage witness` belongs in Ward proper or remains fetch/corpus eligibility residue.
- Whether `unknown posture` deserves first-class archive vocabulary or remains typed local gate residue.
- Whether `proof-carrying absence` belongs in Ward or only in imported transparency/status substrates.
- Whether `delta train` is Ward truth or just one transport convenience that should stay small.
- Whether plural transparency receipts belong in Ward, a sibling cube, or only in imported evidence packs.
