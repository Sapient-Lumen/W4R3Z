# SlopOS companion evaluation — pass XCVII

## What changed

Ward now has rollback-remediation receipts downstream of outcome observations. This creates a safe seam for mismatch handling without making rollback/remediation an ambient action permission.

## Companion pressure

- **SlopOS** should treat rollback-remediation receipts as non-authority annotations on CH-AREF / portal / resume flows. They may say “review opened” or “handoff requested,” not “safe to act.”
- **Harbor** can consume remediation handoff requests as pressure to produce correction/recheck receipts. Ward does not replace Harbor implementation receipts.
- **Helm** can render remediation posture, quarantine, recipient-notice state, and no-authority labels. Helm should not render a handoff request as a completed fix.
- **Schell** should govern retention/minimization of remediation evidence, especially public projection of mismatch and quarantine state.
- **ViewFS** should ensure remediation packets carry provenance/trusted-path constraints without exposing sealed outcome payloads.
- **Foundry** can use rollback-remediation posture to identify semantic crosswalk/codedrift reviews, but it must not treat Ward remediation posture as classification authority.
- **Steward** may use the handoff request as followthrough pressure; it must not treat review-opened as delegated repair power.

## Remaining seam

The next likely seam is **remediation outcome verification**: if Harbor, Helm, or SlopOS later claims a remedy/rollback/recheck was performed, Ward will need a follow-up receipt proving that the remediation outcome is bound to the original rollback-remediation receipt and still carries no-authority / source-replay / projection fences.
