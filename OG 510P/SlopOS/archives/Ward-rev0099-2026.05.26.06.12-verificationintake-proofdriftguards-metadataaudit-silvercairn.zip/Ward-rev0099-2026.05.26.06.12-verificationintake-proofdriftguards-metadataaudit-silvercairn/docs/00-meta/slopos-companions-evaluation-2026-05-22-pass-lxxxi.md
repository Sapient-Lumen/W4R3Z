# SlopOS companions evaluation — 2026-05-22 pass LXXXI

## Evaluation frame

SlopOS and the companion cubes can consume Ward governance decision events only if they preserve the weakness and replay posture of the original packet decision. Pass LXXXI tests the first consumer-side receipt layer.

## Companion seams

| Consumer | Safe use | Required receipt closure |
|---|---|---|
| Helm | render badge, next safe route, owner-hint affordance | state non-upgrade; weakness visible; no-authority statement; public projection safe |
| Harbor | schedule correction/recompute recheck | packet replay current; recheck is not implementation; forbidden effects preserved |
| Schell | retain minimized decision summary and sealed pointers | retention/minimization plus compaction/tombstone guard; no sensitive inline public view |
| SlopOS | attach event identity to CH-AREF-like artifact/ref | `identity_not_trust`; digest attachment is not permission/currentness/semantic authority |
| ViewFS | future artifact browser can show historical receipt | must not turn old event into trusted-path authority without replay |
| Steward | future lifecycle queue can track orphan/stale governance | assignment and scheduling remain weaker than acceptance/authority |
| Foundry | future classification/crosswalk review can see event history | event history does not approve semantic repair without fresh packet |

## What changed from pass LXXX

Pass LXXX checked that the event itself did not become a grant. Pass LXXXI checks that the consumer did not turn the event into a grant later.

## SlopOS-specific lesson

A CH-AREF attachment can prove byte identity and relation to a transcript/artifact. It still cannot prove trust, current governance, export permission, action permission, or semantic correctness. SlopOS should treat a Ward consumer receipt as a visible replay status and no-authority label, not as a portal-wide approval token.

## Open pressure

Batch/search/entitlement results remain intentionally open. A search index returning 50 governance events should not compress them into a single green badge unless every member's packet replay, projection class, and forbidden-effect set survives aggregation. That needs a future batch-summary fixture family.
