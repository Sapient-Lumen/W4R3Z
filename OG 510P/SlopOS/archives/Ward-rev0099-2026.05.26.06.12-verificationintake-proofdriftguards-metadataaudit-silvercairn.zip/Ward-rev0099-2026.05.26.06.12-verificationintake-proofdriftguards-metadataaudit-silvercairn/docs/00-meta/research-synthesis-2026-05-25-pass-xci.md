# Research synthesis — pass XCI

Pass XCI focused on the gap after signal ingestion: accepted refresh/revocation/conflict signals still need downstream fanout discipline. A receiver-local signal observation does not prove every cache, UI, export bundle, search index, or companion cube heard, acknowledged, replayed, or recertified the change.

## External pressure

- `EXT-OPENID-SSF-2025`, `EXT-RFC-8935`, and `EXT-RFC-8936` keep event transmission, delivery acknowledgement, poll state, and receiver-local handling separate. Ward borrows this separation so push/poll delivery cannot become consumer refresh.
- `EXT-CLOUDEVENTS-SUBSCRIPTIONS-2026` keeps producers, subscriptions, subscribers, and delivery intermediaries distinct enough that Ward should record notification fanout rather than assuming one receiver observation reaches every consumer.
- `EXT-GCP-PUBSUB-DEADLETTER-2026` and `EXT-AZURE-EVENTGRID-DELIVERY-RETRY-2026` pressure Ward to treat retries, dead-letter routing, dropped events, and endpoint failures as first-class delivery outcomes rather than invisible implementation details.
- `EXT-NIST-SP-800-53-REV5` and `EXT-NIST-SP-800-137-2011` keep continuous monitoring and information-flow discipline in view: stale consumers are a control state, not a messaging nuisance.

## Design conclusion

Add a governance signal-notification receipt. It binds the source signal-ingestion receipt, source event key, subject digest, cache-subject digest, affected consumer set, delivery payload digest, retry/dead-letter policy, per-consumer observations, acknowledgment limits, stale-consumer closure, and projection-safety posture.

Notification is not recertification. Acknowledgment is not refresh. Dead-lettering is not delivery. Partial fanout means quarantine, not green status.

## New executable pressure

The pass adds five positive fixtures and twenty negative fixtures around all-notified refresh, partial quarantine, duplicate suppression, dead-letter quarantine, conflict hold, source digest drift, event-key mismatch, consumer-set drift, payload drift, sealed leakage, ack-as-authority, ack-as-refresh, delivery-ack laundering, dead-letter-as-delivery, missing quarantine, duplicate promotion, conflict auto-winner, identity leakage, missing labels, high-consequence effects, status-pointer mutation, and notification-as-recertification.
