# Research synthesis — pass XXXVII

This pass keeps Ward cautious and learns one more thing from mature lease/lock and authority-handoff systems: **lease ownership, monotonic fencing, stale-holder risk, and release/handoff posture are different truths.**

## Outside lessons
1. **Chubby separates “I hold the lock” from “the recipient should still honor my request.”**  
   The Chubby paper says a lock holder may request a **sequencer** that carries the lock name, mode, and generation number, and that recipient servers should reject requests if the sequencer is no longer valid. It also adds **lock-delay** as a weaker fallback when recipients do not understand sequencers. Ward should steal the humility: a time-bounded or session-bounded ownership claim is weaker than a recipient-validated generation token, and weaker still than a local consequence.

2. **etcd says lease TTL alone is not mutual exclusion.**  
   etcd’s docs explicitly warn that server and client clocks may disagree, so the server may revoke a lease while the client still believes it owns it. The docs then say mutual exclusion comes from **revision / lease validation** in `Put` / `Txn`, not from the lease by itself, and that external resources need their own validation mechanism. Ward should steal the restraint: “lease still looks live from here” is not enough when high-risk local action depends on excluding stale holders.

3. **Kafka keeps stale-writer fencing explicit.**  
   Kafka’s protocol says `INVALID_PRODUCER_EPOCH` means an operation came from an old epoch and `TRANSACTION_COORDINATOR_FENCED` means the coordinator is no longer current. It also keeps duplicate and out-of-order sequence failures distinct. Ward should steal the pressure: stale authority, duplicate replay, and ordering failure are neighboring but non-identical facts.

4. **ZooKeeper keeps cooperative release and forced break separate.**  
   ZooKeeper’s lock recipes use ephemeral sequential nodes and predecessor watches to avoid herd effects. Its revocable shared locks require the holder to **consent** to release after seeing an `unlock` marker, while a forceful break is an extra posture outside that polite path. Ward should steal the distinction: graceful handoff and forced eviction should not collapse into one vague revocation story.

## Resulting Ward move
Do not decide yet whether Ward’s long-term datacube should carry these truths as lease descriptors, epoch receipts, capability generations, compare-and-swap sidecars, or local policy-only residue.

For now, preserve four separations and let later specimens force promotion:
- `lease claim` versus one fake exclusive-authority bit;
- `fence token` versus a mere TTL/session/lock-owner belief;
- `stale-holder alarm` versus silent reuse of apparently successful but superseded authority;
- `handoff posture` versus one collapsed release/revoke word.

Keep nearby, but not yet promoted, a few smaller ideas:
- `grace delay` for the imperfect safety interval after failure or disconnect;
- `authority epoch bump` for visible transfer to a successor holder;
- `recipient validator` for the destination-side rule that actually rejects stale authority; and
- `cooperative release weaker than forced break` as a standing anti-regrowth rule.

## Fresh ideas worth stealing
- **lease claim** — time-bounded or session-bounded claim that one holder currently has temporary authority.
- **fence token** — monotonic token or generation checked by the recipient to reject stale holders.
- **stale-holder alarm** — explicit residue that an apparently successful holder may already be superseded elsewhere.
- **handoff posture** — visible distinction among cooperative release, grace delay, timeout expiry, and forced break.
- **authority epoch bump** — compact residue that a successor authority generation is now current.
- **recipient validator** — the destination-side condition that actually turns fencing into exclusion.
- **cooperative release weaker than forced break** — a standing anti-regrowth rule.
