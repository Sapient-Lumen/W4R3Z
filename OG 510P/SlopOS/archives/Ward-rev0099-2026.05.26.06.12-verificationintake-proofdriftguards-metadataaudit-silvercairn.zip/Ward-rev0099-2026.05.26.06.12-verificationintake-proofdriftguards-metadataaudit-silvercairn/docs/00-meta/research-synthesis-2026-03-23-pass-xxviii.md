# Research synthesis — pass XXVIII

This pass keeps Ward cautious and learns one more thing from distributed stores and compacted logs: **concurrent later-state updates, the merge rule that reduces them, and the retention horizon of a latest-value projection are different truths.**

## Outside lessons
1. **Old distributed systems already learned that multiple versions are not an edge case.**  
   Dynamo says applications must explicitly acknowledge the possibility of multiple versions of the same data “in order to never lose any updates,” uses vector clocks to capture causality, and returns parallel branches when it cannot syntactically reconcile them. Ward should steal the restraint: concurrent later-state facts should stay visible instead of being silently flattened into one fake winner.

2. **Causal context is stronger than timestamp folklore, and better conflict metadata shrinks duplicate blowups.**  
   Riak says eventual conflicts are unavoidable, that causal context should be used when updating mutable objects, and that failing to do so can cause sibling explosion. Its dotted version vectors identify the specific event that introduced each update and let duplicate sibling values be removed, keeping sibling count proportional to real concurrency. Ward should therefore keep concurrency residue and dedupe smaller than subject identity or final consequence.

3. **A compacted “current state” view is valuable, but it is not a full trust history.**  
   Kafka says log compaction retains at least the last known value for each key so consumers can restore final state without retaining the complete log of all changes. Kafka also says delete tombstones are themselves cleaned out after a period of time, and the broker config makes explicit that a consumer starting from offset 0 must finish within `delete.retention.ms` to ensure a valid final snapshot. Ward should steal that honesty: a latest-value projection is useful, but after compaction and tombstone expiry it can no longer impersonate complete historical truth.

## Resulting Ward move
Do not decide yet whether Ward’s long-term later-state substrate is append-only history, compacted latest view, plural projections, sidecar concurrency cache, or something else.

For now, preserve four separations and let later specimens force promotion:
- `concurrency witness` versus replay fence or ordering window;
- `merge recipe` versus the source facts it reconciles;
- `survivor view` versus complete history;
- `compaction horizon` versus covered absence or proof-carrying absence.

## Fresh ideas worth stealing
- **concurrency witness** — compact residue that two updates are parallel/incomparable rather than ordered replacement.
- **merge recipe** — explicit statement of how concurrent siblings were reduced.
- **survivor view** — latest-value projection kept visibly smaller than history.
- **compaction horizon** — visible bound after which negative inference from one compacted view weakens.
- **no silent LWW** — a standing anti-regrowth rule.
