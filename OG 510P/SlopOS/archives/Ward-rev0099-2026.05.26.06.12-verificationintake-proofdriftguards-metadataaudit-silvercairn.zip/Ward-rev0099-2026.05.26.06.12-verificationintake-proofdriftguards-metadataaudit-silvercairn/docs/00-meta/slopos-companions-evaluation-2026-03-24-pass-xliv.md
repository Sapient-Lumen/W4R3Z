# SlopOS / companions evaluation — pass XLIV

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **promoted trust derivatives should stage, validate, and publish explicitly instead of mutating in place**.

## What the included cubes keep teaching
- **SlopOS** is still the most useful direct teacher because it keeps querying modest: D-ATTRFS stays **view-scoped**, **snapshot-first**, **handle-returning**, with saved queries remaining **shell-owned manifests** and live mode **optional and bounded**. That means Ward still has no excuse to invent one giant ambient current-state datacube while SlopOS itself is still design-phase.
- **ViewFS** keeps sharpening the exact neighboring split Ward needs: **query manifest**, **result snapshot**, **live feed**, and later **materialized local collection** are distinct. The next healthy steal is to add one more seam above that split: when a materialized derivative changes, the candidate should be stageable and its diff inspectable before the official surface moves.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows a promoted trust derivative in human-facing surfaces, the UI should be able to say `staged`, `validating`, `ready to publish`, `published`, or `diff requires review` instead of burying everything under `updated`.
- **Foundry**, **Harbor**, and **Steward** keep the same humility alive from adjacent angles: measurements, previews, callbacks, and follow-through signals can be useful without automatically becoming the authority layer.

## What outside systems add to the datacube posture
- Iceberg's WAP writes and explicit `publish_changes` show a healthy **stage then publish** path (`EXT-ICEBERG-WAP-2026`).
- Materialize's replacement materialized views show that a candidate derivative can **hydrate in the background** and be **validated before replacement** while downstream dependencies stay intact (`EXT-MATERIALIZE-REPLACEMENT-MV-2026`).
- Delta Lake's change data feed shows that replacement/re-run review is much healthier when the system can surface a typed **change witness** instead of one opaque refresh event (`EXT-DELTA-CDF-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Any promoted derivative revision should begin as a staged derivative, not as an in-place silent mutation.**
2. **Every staged derivative should be reviewable under an explicit basis pin and join clock before publish.**
3. **Promotion should use a publish rail, not “hydration finished” as a hidden swap trigger.**
4. **Every publish should carry a change witness that explains what rows or grouped outcomes changed.**
5. **Recipe, frozen result, live feed, staged derivative, and active derivative should remain visibly different classes.**

## Specific anti-lessons from the past
- Do **not** let one promoted derivative rewrite itself without a visible review step.
- Do **not** let diff collapse into a pretty badge with no inserted/deleted/updated account.
- Do **not** let “candidate ready” masquerade as “officially published”.
- Do **not** let the same saved recipe silently become active derivative, live watcher, and canonical dashboard all at once.
- Do **not** choose one engine's staging/publish mechanism as Ward's constitution this early.

## What Ward should probably steal next
- a **staged derivative** state distinct from recipe, snapshot, and live feed;
- a **publish rail** that keeps the swap explicit and reviewable;
- a **change witness** surface that can say inserted / deleted / updated rather than only “changed”;
- status headers that show **basis pin + join clock + derivative state** together;
- hygiene that refuses to let a new datacube-driving source live only in prose without being registered.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new outside sources that are now directly shaping promotion posture;
- make the hygiene checker reject latest-pass source refs that are missing from the load-bearing source register;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index.

## Still-not-yet decisions
- engine choice;
- storage/index strategy;
- one canonical dashboard layer;
- one universal derivative-promotion API;
- one mandatory change-witness schema for every future result family.
