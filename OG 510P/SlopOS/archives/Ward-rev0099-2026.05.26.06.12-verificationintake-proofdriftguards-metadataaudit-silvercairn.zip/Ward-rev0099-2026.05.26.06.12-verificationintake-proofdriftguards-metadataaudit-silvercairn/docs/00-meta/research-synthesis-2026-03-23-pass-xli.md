# Research synthesis — pass XLI

This pass adds one more design-pressure seam without freezing Ward into one global clock service, one snapshot API, one follower-read contract, or one “latest” oracle: **a read cut, a staleness budget, an ambiguity window, and a revalidation fence are different truths**.

## What the outside systems say
1. **A read should be explicit about which cut of history it is actually showing.**  
   Spanner makes this especially crisp. A strong read means “latest data”, bounded staleness lets the system pick the newest timestamp within a user-supplied age bound, and exact staleness means the application asked for one exact historical cut. It also keeps an `earliest_version_time`, which reminds Ward that “readable as-of” depends on retention, not just API shape.

2. **Cheap nearby reads usually come from an older safe frontier, not from magic present truth.**  
   CockroachDB follower reads are an excellent pressure source here. A range’s closed timestamp means no new writes can later appear at or below that timestamp, and follower reads only work when the chosen historical `AS OF SYSTEM TIME` value is old enough to sit behind that closed frontier. Ward should steal that humility instead of pretending every low-latency answer is ambiently current.

3. **Clock ambiguity and distributed reads deserve named posture, not silent guessing.**  
   YugabyteDB’s read-restart behavior makes the hidden danger explicit: there is an ambiguity interval in which the system cannot safely decide whether one version should belong to the read snapshot, so it raises a restart rather than lie. Its `SERIALIZABLE READ ONLY DEFERRABLE` posture is also a brilliant small idea: sometimes the honest move is to wait out uncertainty before reading.

4. **Relaxed reads still need an invariant fence before they drive irreversible consequence.**  
   FoundationDB’s snapshot-read guidance is the sharpest reminder here. Snapshot reads reduce conflicts, but they also relax isolation, so the docs tell you to add explicit conflict ranges or narrower strict reads around the actual invariant you care about. Ward should steal that pattern directly: fast orientation can be weaker than the final re-check that authorizes spend.

## Resulting Ward move
Do **not** decide yet whether Ward should standardize one timestamp envelope, one read-consistency registry, one cross-region time service, or one universal `as_of` API.

For now, preserve four separations and let later specimens force promotion:
- `read cut` versus vague “current enough” language;
- `staleness budget` versus hidden latency/freshness trade-offs;
- `ambiguity window` versus fake certainty during skew / unresolved visibility intervals;
- `revalidation fence` versus pretending the first cheap read was already strong enough for high-risk consequence.

Keep nearby, but not yet promoted, a few smaller ideas:
- `deferral posture` for reads that honestly wait instead of guessing;
- `locality bargain` for when the system intentionally trades freshness for nearby service;
- `stronger-than-browse` for the moment a local action crosses from orientation into consequence; and
- `read-proof note` for compact residue describing why one exact cut was believed safe to use.

## Fresh ideas worth stealing
- **read cut** — exact historical cut that one answer actually reflects.
- **staleness budget** — explicit maximum age the reader was willing to tolerate for this answer.
- **ambiguity window** — interval in which inclusion/exclusion is not safely knowable yet.
- **revalidation fence** — explicit stronger check crossed before minting higher-risk consequence.
- **deferral posture** — visible choice to wait/restart rather than pretend the present is already safe to read.
