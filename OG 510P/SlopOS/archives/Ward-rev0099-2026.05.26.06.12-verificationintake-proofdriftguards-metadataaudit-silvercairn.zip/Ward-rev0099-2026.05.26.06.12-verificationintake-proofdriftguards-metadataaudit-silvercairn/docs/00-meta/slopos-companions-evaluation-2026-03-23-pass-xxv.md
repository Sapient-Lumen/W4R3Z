# SlopOS / companions evaluation — pass XXV

This pass keeps Ward embryonic while stealing one more good habit from the neighbors: **separate “these outside sources matter” from “these mutable sources need active review soon.”**

## What the current cubes still teach
- **SlopOS** already separates source importance from source refresh discipline with a head/lock/review split. Ward should steal the *principle* but keep the implementation lighter: the cube is still too young for byte locks, but it is old enough for a small source-review queue tied to the load-bearing source register.
- **SlopOS** also keeps timing and publication seams explicit in many architecture surfaces instead of letting “current state” float around as prose. Ward should apply the same discipline to later-state evaluation: effective change, publication/signing, and local adoption are different moments.
- **Steward** keeps followthrough and activation posture visible. Ward should learn the analogous truth that one receiver may adopt a later-state package at a different local cut than another without rewriting the underlying event.
- **Schell** keeps outcome and operator-facing explanation smaller than final effect. Ward should similarly keep reason handles, user/admin explanations, and initiating-entity hints smaller than action ladders or spend consequence.

## Current recommendation
Keep Ward open on universal transport and proof substrate.

The next wise move is still one specimen plus one tiny hygiene upgrade:
1. **effective change time** instead of “publication time equals truth time”,
2. **cause cohort** instead of either isolated event atoms or one giant merged incident object,
3. **local adoption cut** instead of pretending every receiver changes consequence at the same moment,
4. **reason handle** instead of turning explanation strings into local policy,
5. **source-review queue** instead of relying on memory for moving or newly finalized pressure sources.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should still avoid external-source locks and generated review machinery.
The smaller steal is enough for now:
- add one lightweight `source-review-queue.md`,
- keep it aligned with the load-bearing source register in the same revision,
- and make the hygiene checker fail if moving/recent/living load-bearing sources disappear from the queue.

## Still-not-yet decisions
- Whether `effective change time` deserves first-class Ward vocabulary or remains imported timing residue.
- Whether `known-correct interval` belongs in Ward proper or stays smaller than responder/publisher substrates.
- Whether `cause cohort` should become a durable Ward family or remain an imported grouping handle.
- Whether `local adoption cut` belongs in Ward or in neighboring policy/adoption surfaces.
- Whether `reason handle` should be durable Ward vocabulary or merely imported explanatory residue.
