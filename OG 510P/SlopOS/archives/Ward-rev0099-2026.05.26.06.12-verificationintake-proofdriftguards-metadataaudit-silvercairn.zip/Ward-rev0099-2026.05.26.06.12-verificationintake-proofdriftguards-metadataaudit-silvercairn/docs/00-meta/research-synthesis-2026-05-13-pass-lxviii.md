# Research synthesis — pass LXVIII

Pass LXVII made history repair and withdrawal visible: old answer capsules, materializations, exports, screenshots, and agent summaries can be corrected, backfilled, fenced, or made review-only without either rewriting the past or pretending stale material is still consequence-grade. Pass LXVIII follows the next failure mode: a SlopOS-facing datacube answer may cross multiple sources, tenants, collaborators, semantic owners, policy engines, or clean-room boundaries. Federation can make a polished answer look unified while laundering authority, identity, join permission, projection rules, side-channel risk, and semantic mismatches.

The restraint rule still holds. Ward should not choose a federated SQL engine, graph federation stack, clean-room product, policy-decision API, data mesh governance system, data contract standard, semantic-layer product, or trust-federation protocol as the datacube constitution. SlopOS is still in design phase. The right move is to name small residues that let a future datacube compose answers across boundaries without pretending the composition boundary disappeared.

## What the past says we must learn now

1. **Federation is not unification.** SPARQL 1.1 Federated Query uses `SERVICE` to direct part of a query to a particular remote endpoint, then returns and combines results with the rest of the query (`EXT-SPARQL-FEDERATED-QUERY-2013`). The lesson for Ward is not RDF-specific. A remote fragment remains a boundary-labeled contribution, not a row that magically became local truth.

2. **Pushdown is connector-specific, not ambient.** Trino's pushdown docs say predicates, aggregations, and other operations may be passed to the underlying source, but support is specific to each connector and relevant database or storage system (`EXT-TRINO-PUSHDOWN-2026`). A SlopOS datacube should not say “the source enforced this filter/join/aggregation” unless the answer carries the relevant capability and execution posture.

3. **Composition needs failure modes, not just happy routing.** Apollo Federation composition rules make subgraph compatibility explicit; shared fields need compatible types/arguments, and a combined schema can fail composition when locally valid pieces cannot resolve consistently (`EXT-APOLLO-FEDERATION-COMPOSITION-2026`). Ward should steal the refusal posture: if cube participants cannot compose under one safe contract, the result should be `composition_refused`, `projection_narrowed`, or `join_warrant_missing`, not a best-effort dashboard.

4. **Clean rooms turn joins and projections into policy surfaces.** AWS Clean Rooms aggregation rules can constrain aggregate functions, grouping columns, query controls, result controls, and whether the configured table must be joined to the querying member's table so the analysis runs on an intersection (`EXT-AWS-CLEANROOMS-AGGREGATION-RULE-2026`). Snowflake clean room policies make join columns, projected columns, activation columns, hidden source-table policies, and policy propagation explicit (`EXT-SNOWFLAKE-CLEANROOM-POLICIES-2026`). Ward should steal the idea that joins and projections are not mere plan operators; they are authority-bearing release decisions.

5. **Row-level sharing can leak through timing and can lose policy on rewrite.** BigQuery's row-level security guidance distinguishes authorized views, row-level policies, and separate tables, and explicitly notes query-duration side-channel concerns and situations where row access policies are removed by replacement or write-truncate operations (`EXT-BIGQUERY-RLS-INTRO-2026`). A projection curtain needs side-channel and policy-carryover posture, not just “RLS applied.”

6. **Contracts have more sections than schema.** ODCS v3.1.0 divides contract material into schema, references, quality, support, pricing, team, roles, service-level agreement, infrastructure, and custom sections (`EXT-ODCS-3-1-2026`). Ward should not collapse a source contract into one schema hash. Federation needs separate role, SLA, quality, support, pricing/cost, and infrastructure claims when they affect answer authority.

7. **Semantic layers help only if access and joins stay bounded.** dbt's semantic architecture and permissions posture are useful because centrally defined metrics, models, and permissions can make repeated questions consistent (`EXT-DBT-SEMANTIC-ARCH-2026`, `EXT-DBT-SL-PERMISSIONS-2026`). They do not eliminate the need for scope lenses, grain witnesses, fanout fences, quality witnesses, and refusal receipts when a request crosses owners or authority boundaries.

8. **Trust federation is bootstrap, not portable truth.** OpenID Federation 1.0 says it concerns how entities in a federation get to know about each other and explicitly separates that from broader trust earned through performance, certification, or transparent operations (`EXT-OPENID-FEDERATION-1-0-2026`). This aligns with SlopOS's import-boundary habit: a trust chain, Trust Mark, or metadata policy may inform one interaction, but it should not become global cube authority or a universal source registry.

9. **Delegated authorization is still request-shaped.** The AuthZEN Authorization API separates PDP and PEP roles and exposes evaluation/search surfaces for subject, resource, action, context, and decisions while leaving PDP internals out of scope (`EXT-AUTHZEN-AUTHORIZATION-API-2026`). Ward should treat delegated authorization as one bounded decision input with freshness and scope, not as a permanent permission cache for every subsequent cube operation.

## Resulting Ward move

Do **not** decide yet:

- one federated query engine, graph router, semantic-layer product, query planner, catalog, or clean-room platform;
- one universal participant contract, endpoint description, capability discovery protocol, or source registry;
- one global entity graph, one key-normalization system, one hash/tokenization method, or one join policy language;
- one data mesh governance stack, data contract format, SLA grammar, or ownership registry;
- one policy-decision API, trust-federation protocol, PDP/PEP binding, or cached-permission model;
- one projection/export format, activation path, privacy clean-room rule, or side-channel mitigation model;
- one rule that a federated answer is always weaker than local answers or always stronger because more sources contributed;
- one UI grammar for “remote fragment,” “policy-shaped projection,” “join allowed,” “join refused,” or “composed from participants.”

Do add three small, reversible residues for federated cube composition:

- **federation pact** — compact per-answer/per-attempt contract naming participants, authorities, views, snapshots, endpoint/source handles, semantic/model versions, policy epochs, allowed query fragments, pushdown/capability envelope, budgets, freshness, quality, lineage, privacy, egress, and non-delegation posture. It is smaller than a federation engine or data mesh governance layer.
- **join warrant** — compact evidence that a cross-boundary join/link is both permitted and meaningful: key namespace, normalization/tokenization/hash posture, entity semantics, relationship/cardinality, join clock, fanout/dedupe protection, unmatched/null behavior, privacy/suppression thresholds, clean-room or policy requirements, side-channel posture, and revocation/correction reach.
- **projection curtain** — compact boundary around what each participant may expose and what the composed answer may release: allowed fields, dimensions, measures, grains, aggregate/list/detail posture, row/column policy carryover, hidden-policy warnings, threshold/noise/suppression, no-raw-spill guarantees, activation/export limits, and refusal posture.

These residues sit beside earlier nouns. A federation pact can include scope lenses, state cut witnesses, freshness envelopes, quality witnesses, budget gates, and correction horizons for each participant. A join warrant should reuse grain witness, fanout fence, identity witness, join clock, privacy posture, and comparability passport when relevant. A projection curtain should feed render contracts, egress receipts, refusal receipts, degradation receipts, revocation fences, and uncertainty envelopes.

## Brilliant ideas to steal now

- **Remote fragment label.** Preserve which part of an answer was evaluated remotely, locally, in a clean room, or in a delegated policy surface.
- **Capability envelope.** Connector pushdown is a capability claim with source/version/cut, not a blanket engine feature.
- **Composition refusal.** Federation should have explicit `cannot_compose` and `bridge_required` states when participant contracts do not line up.
- **Join columns as policy.** Clean-room join policies are a good pressure source: the allowed join key is release authority, not just a physical column.
- **Projection as release.** Column projection, aggregation, activation, and list output deserve release posture independent of the source table.
- **Hidden policy warning.** Source-table policies can keep applying even when not visible through a collaboration UI; Ward should require policy-carryover and hidden-policy posture.
- **Separate table as stronger isolation.** When totals or row existence must stay secret, physically separate or separately authorized surfaces may be safer than flexible policies.
- **PDP/PEP humility.** Delegated authorization answers should be request-scoped, versioned, and revalidated, not cached as ambient cube permission.
- **Trust chain non-regrowth.** Federation metadata and trust chains should help route one interaction, not become a global app/source/trust registry.
- **Contract subsets.** Schema, quality, roles, SLA, support, cost, and infrastructure can drift independently; federation pacts should not collapse them.

## Still-not-yet decisions

- Whether every federated answer needs a federation pact or only cross-authority, cross-tenant, clean-room, external-source, or consequence-grade answers.
- Whether join warrants attach to key pairs, relationship classes, answer capsules, query fragments, clean-room collaborations, or projection curtains.
- Whether projection curtains are authored by source owners, SlopOS policy, clean-room templates, Ward recipes, or all of them with precedence rules.
- Whether a federated answer can be materialized, and if so whether each participant's correction horizon and revocation fence must travel into the materialization.
- Whether participant capability discovery should be pull-time, published contract, cached metadata, or human-reviewed registry.
- How to safely summarize composition failure without leaking denied endpoint, row, key, or participant existence.
- Whether clean-room-style aggregation thresholds should be a privacy posture, a projection curtain property, or both.
- Whether a delegated authorization search result can ever be used to enumerate possible cube populations without becoming an oracle.

## Process note

Pass LXVIII does not add a federated query engine, clean room, semantic layer, PDP, catalog, trust registry, or data mesh. It adds composition hygiene so SlopOS-facing datacube answers can cross boundaries without losing authority labels, join permission, projection release posture, policy carryover, side-channel warnings, or refusal. The next healthy move is to run these residues against a specimen where a partner overlap answer crosses SlopOS, Harbor, Foundry, and a clean-room-like collaboration boundary while preserving no-hidden-inventory discipline.
