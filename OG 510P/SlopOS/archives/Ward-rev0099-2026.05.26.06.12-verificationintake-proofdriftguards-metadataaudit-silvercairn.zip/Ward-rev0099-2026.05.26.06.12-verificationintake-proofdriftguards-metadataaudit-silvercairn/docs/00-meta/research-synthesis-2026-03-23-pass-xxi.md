# Research synthesis — pass XXI

This pass keeps Ward narrow and learns one more thing from mature trust-update systems: **status meaning and status freshness need their own truthful surfaces, and not every trustworthy artifact should inherit the same revocation story**.

## Outside lessons
1. **W3C's Bitstring Status List keeps status meaning typed instead of collapsing everything into one invalid bit.**  
   The same mechanism explicitly distinguishes `refresh`, `revocation`, `suspension`, and `message`, and says `refresh` does not invalidate the credential while `suspension` is reversible. Ward should steal the idea that status purpose is first-class and that local consequence should not flatten all later change into "revoked".

2. **VC Data Model 2.0 keeps local evaluation with the verifier.**  
   The verifier is expected to evaluate `credentialStatus` according to the status type definition and the verifier's own criteria. Ward should therefore keep status publication separate from local appraisal even when the outside status surface looks highly structured.

3. **OAuth token introspection is a warning that "current status" is expensive truth.**  
   RFC 7662 makes the active state server-defined and warns that caching creates a stale window in which a revoked token can still be used. Ward should therefore keep a visible `recency window` rather than pretending any fetched status is timeless or perfectly live.

4. **OAuth token revocation is a warning against over-reading teardown responses.**  
   RFC 7009 allows revocation of one token to invalidate related tokens and the underlying authorization grant, and success can still be expressed with semantics that do not cleanly map to durable local truth. Ward should preserve scope of effect and resist turning remote teardown success into a portable final verdict.

5. **X.509 is now explicit that short-lived and long-lived material deserve different status stories.**  
   RFC 9608 says short-lived certificates may sensibly publish no revocation information because the validity period is shorter than the time needed to detect, report, and distribute revocation information, while long-lived signing material still benefits from revocation history. Ward should not force every witness or credential family into one universal status mechanism.

6. **The current OAuth Token Status List draft harvests several good implementation instincts without yet earning promotion into Ward truth.**  
   It keeps status list freshness bounded with `iat`, `exp`, and `ttl`; it separates Issuer, Status Issuer, and Status Provider roles; it recommends preventing double allocation of `(uri, idx)`; and it allows time-cut retrieval for historical checks. Ward should collect those ideas, but not yet decide that list-shaped status is its permanent substrate.

## Resulting Ward move
Do not decide yet whether the durable nouns are `status purpose`, `recency window`, `external status issuer`, and `status coordinate`, or whether one or more later compress behind a calmer status family.

For now, keep them alive as specimen nouns and demand that they improve:
- one reversible suspension specimen,
- one refresh-without-invalidation specimen,
- one external-status-authority specimen,
- and one short-lived/no-status specimen that proves Ward can stay truthful without requiring a universal revocation lane.

## Fresh ideas worth stealing
- **status purpose** — typed later meaning such as refresh, suspension, revocation, or message.
- **recency window** — explicit horizon for how long fetched status may safely influence local consequence.
- **external status issuer** — separate authority that governs later status without replacing original witness history.
- **status coordinate** — a locator for later status that remains smaller than the status meaning itself.
- **time-cut status check** — ability to ask what status material was valid for a specific historical moment.
- **no-live-oracle-by-default** — a standing anti-regrowth rule: stale but explicit status is often healthier than fake perfect liveness.
