# Research synthesis — pass LXXVII

Pass LXXVII studies a boundary that shows up after contestability and remedy: **who is actually allowed to maintain, delegate, escalate, or repair a SlopOS-facing cube answer family?** This is governance pressure, but Ward should not harden into an org chart, GRC product, RACI table, or ticketing system.

The sharp failure mode is **owner-label laundering**. A dashboard says “provider risk owner,” a catalog says “business owner,” a Slack rotation says “on-call,” an agent says “I have tool access,” and a remedy docket says “reviewer assigned.” None of those facts alone proves current authority to change a metric, approve a backfill, weaken a projection curtain, re-enable a quarantine recommendation, or accept a contested remedy.

## Source pressure

`EXT-NIST-AIRMF-GOVERN-2026` is useful because NIST's AI RMF Govern function frames roles, responsibilities, accountability structures, and lines of communication as something that must be documented and clear. The datacube lesson is not “adopt an AI governance framework”; it is that accountability is an answer-adjacent cut, not an ambient property of a person or team name.

`EXT-BACKSTAGE-CATALOG-OWNERSHIP-2026` and `EXT-BACKSTAGE-DESCRIPTOR-LIFECYCLE-2026` pressure Ward toward catalog-style discoverability without making catalog ownership sufficient authority. Backstage's catalog keeps ownership and metadata discoverable, and its descriptor docs warn that organizations should establish proper taxonomies for lifecycle and type values because tools can behave differently based on them. For Ward, owner and lifecycle labels need cut, taxonomy, and use-class posture.

`EXT-GITHUB-CODEOWNERS-2026` is a surprisingly good anti-lesson. CODEOWNERS can request reviewers and, with branch protection, require approval. But ownership is branch-specific, depends on the base branch, can fail if the file is too large or syntax/user access is invalid, and one owner approval may suffice when multiple owners are listed. The datacube lesson is: owner maps are versioned inputs with failure states, not universal veto/approval truth.

`EXT-DATAHUB-DOMAIN-OWNERSHIP-2026`, `EXT-DATAHUB-OWNERSHIP-TYPES-2026`, and `EXT-OPENMETADATA-DATA-OWNERSHIP-2026` reinforce separation between asset owner, domain owner, technical owner, business owner, data steward, and custom ownership type. They are valuable as vocabulary pressure, but Ward should not adopt any one catalog's role taxonomy or propagation rule.

`EXT-OPENFGA-CONCEPTS-2026`, `EXT-OPENFGA-CONTEXTUAL-TUPLES-2026`, and `EXT-OPENFGA-CONDITIONS-2026` pressure delegation warrants: checks depend on a model plus relationship tuples; contextual tuples can be request-scoped and ephemeral; conditions can express time, IP, quota, or resource-attribute restrictions. The datacube should steal the idea of scoped relationship evidence, not choose OpenFGA as its authorization engine.

`EXT-PAGERDUTY-ESCALATION-POLICIES-2026` and `EXT-ATLASSIAN-INCIDENT-ROLES-2026` pressure escalation handoffs. Escalation policies route when responders do not respond; incident roles distinguish incident manager, technical lead, communications, support, and subject-matter experts. Ward should separate “paged,” “assigned,” “accepted,” “empowered,” “reviewed,” and “resolved.”

## Lessons we must carry forward

1. **Ownership is not action authority.** Catalog ownership, code ownership, domain ownership, and on-call ownership are discoverability and routing facts until a scoped warrant says which consequence they can approve.
2. **Delegation must expire or it becomes ambient authority.** Temporary analyst access, agent tool access, steward override, and emergency review must name scope, capability, duration, caveats, revocation posture, and re-delegation limits.
3. **Escalation is not acceptance.** A handoff that pages another lane, opens a ticket, or assigns a reviewer does not mean that lane accepted responsibility, received adequate evidence, or has authority to decide.
4. **Role taxonomies are local.** Technical owner, business owner, data steward, on-call engineer, incident manager, reviewer, approver, payer, and policy owner are not interchangeable.
5. **Succession is a data-quality event.** When a steward leaves, a domain changes, a team is renamed, a CODEOWNERS-like map fails to load, or an escalation schedule expires, cube answers that depend on that governance path need visible weakening.
6. **Emergency authority must leave residue.** Break-glass, expedited remedy, quarantine override, or urgent re-enablement can exist, but it must carry trigger, authority, duration, reviewer, conflict, rollback, and post-hoc review obligations.
7. **Agents can be delegates, not owners.** A model or tool runner may hold a leash or delegation warrant for a narrow task, but it should not become steward-of-record or silently accept escalations.
8. **Governance metrics are also cube answers.** Orphaned metrics, stale steward charters, delegation expiry rates, handoff acceptance latency, and conflict override rates need the same scope, comparability, privacy, and quality hygiene as any other metric.

## Resulting Ward move

Do **not** decide yet:

- one org model, RACI matrix, data-catalog product, code-owner mechanism, authorization engine, incident platform, ticketing system, or stewardship workflow;
- one role taxonomy for technical owner, business owner, data steward, reviewer, on-call, policy owner, payer, custodian, auditor, or escalation lane;
- one global rule that owner labels approve changes, on-call schedules resolve disputes, or assigned reviewers accept liability;
- one mandatory human-review process for every low-risk cube answer; or
- one permanent delegation chain that can survive policy, semantic, privacy, or source-contract drift.

Do add three small, reversible residues:

- **stewardship charter** — scoped accountability/maintenance posture for an answer family, metric, axis, source fragment, policy seam, export family, or consequence class. It names accountable parties, role types, permitted duties, excluded powers, effective cut, review cadence, conflict posture, backstop/successor lane, and evidence pointers.
- **delegation warrant** — evidence that a principal, system, agent, reviewer, team, or temporary lane may perform a named cube-maintenance/review/action-support task under bounded scope, time, capability, budget, privacy/projection, re-delegation, revocation, and audit conditions.
- **escalation handoff** — routing/acceptance residue for issues that exceed a local steward, delegate, or reviewer: trigger, severity, from/to lanes, evidence supplied, authority requested/granted/denied, acceptance/refusal, interim state, deadline, notices, and closure posture.

## Hygiene rule for SlopOS

A stewarded SlopOS datacube artifact is never stronger than the weakest of:

- its answer capsule, scope lens, state-cut witness, semantic, freshness, quality, privacy, uncertainty, correction, action, contest, remedy, and lifecycle residues;
- the stewardship charter's effective scope, role taxonomy, duty limits, review cadence, conflict posture, and successor/backstop state;
- the delegation warrant's capability subset, caveats, expiry, revocation, budget/payer, projection, and re-delegation posture;
- the escalation handoff's accepted lane, supplied evidence, authority requested/granted/denied, deadline, and closure state; and
- current rehydration when a human, tool, or agent wants to use governance residue to change, repair, publish, export, learn from, or act on a cube answer.

## Specimen pressure that should come next

A provider-risk metric's business steward is out, the technical owner has changed teams, a temporary analyst receives delegated authority to repair a stale crosswalk, an agent proposes to re-enable a quarantine recommendation, and a contest remedy is pending. Ward should not answer “who can approve this?” from a catalog owner field, on-call schedule, old CODEOWNERS-like map, or chat assignment alone. It should require a stewardship charter, a delegation warrant, and an escalation handoff before any governance fact can become current action-support authority.
