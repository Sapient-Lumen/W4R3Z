# SlopOS + companion evaluation — pass LXX

Pass LXX evaluates the actuation layer after pass LXIX's semantic-drift pass. The candidate residues are **threshold witness**, **action warrant**, and **consequence receipt**.

## SlopOS pressure

SlopOS is still in design phase, so Ward should not ask it to freeze a datacube alerting subsystem, workflow engine, or action surface now. The stronger lesson from the current SlopOS snapshot is separation:

- CH-ACP outcomes are non-authoritative receipts. A cube-derived proposal may point at CH-ACPOUT later, but CH-ACPOUT does not prove authorization, downstream completion, or current provider state.
- ACP preconditions are veto-only exact witness gates. A threshold witness can be a precondition input only if exact local witness material is already in scope; it must not become an ambient query language or hidden “latest cube value” lookup.
- CH-NOTIF request identity does not prove current notification presentation state. A consequence receipt can say a notification request was formed or accepted, but it should not claim the user saw it unless a future explicit SlopOS surface provides that truth.
- D-BUDGET/D-METER keep payer authority explicit and non-ambient. Action warrants should carry budget/payer posture for expensive recompute, notification storms, agent follow-up, or ACP proposals without importing SlopOS budgets as a global cube scheduler.
- CH-ATTR/CH-ATTRQ stay view-scoped, bounded, snapshot-first, and handle-returning. A threshold witness should bind a specific answer/cut rather than re-querying an ambient attribute universe during action validation.

## Companion readings

### Foundry

Foundry's semantic-spine and runtime-evidence posture is useful but should not become automatic consequence. A Foundry-labeled deterioration can support an answer capsule, but a threshold witness and action warrant must decide whether it is persistent, actionable, and authorized.

### Harbor

Harbor evidence summaries are especially tempting as alert material. Ward should keep evidence-code movement, missing witnesses, and temporal confidence as threshold inputs, not direct pages. A Harbor-backed action should say whether the evidence is direct, derived, late, withheld, or review-only.

### Steward

Steward activation and followthrough surfaces remind Ward that actions have lifecycle state. A consequence receipt should distinguish proposed, accepted, applied, no-op, duplicate-suppressed, rejected, withdrawn, and followthrough-pending rather than one generic “triggered” bit.

### Schell

Schell basis-card pressure reinforces exact reviewed basis. A cube-derived action proposal should pin the answer capsule, threshold witness, policy epoch, and reviewed action template; it should not let prose runbooks or mutable dashboards become action authority.

### ViewFS

ViewFS teaches that handles and displayed paths are not authority. An alert row, exported table, or notification link should rehydrate through current scope and handle authority before drill-through or action, especially after invalidation or revocation.

### Helm

Helm is where action pressure becomes concrete: banners, review queues, alert chips, command buttons, and copied screenshots can make a cube answer feel actionable. Render contracts and egress receipts should carry threshold/action/consequence residue so UI affordances do not outrun authority.

### SlopOS as boundary keeper

SlopOS should remain the authority boundary, not the actuation catch-all. Ward can attach actionability residue to answer capsules and detached artifacts, but CH-ACP, CH-NOTIF, CH-BUDGET, capability, policy, and view scoping still determine what may be proposed, shown, spent, and applied.

## Lessons that must survive promotion

- A threshold breach is weaker than a firing alert, and a firing alert is weaker than permission to act.
- Alert routing, grouping, inhibition, silencing, and flood limits are part of consequence safety, not merely delivery polish.
- An ACP outcome receipt is audit evidence, not approval inventory or future replay authority.
- Notification request identity is not display-state truth.
- A stale/no-data/error/degraded answer should not create a more confident action than the answer itself.
- Cube-derived feature flags, rollouts, throttles, or quarantines need reason, rollback, rate, and revalidation posture.
- Old alerts and recommendations can require withdrawal or fencing after correction, invalidation, revocation, or semantic drift.

## Promotion probes

Before making the new residues stronger than candidate nouns, pressure-test:

1. one persistent risk deterioration that enters pending before firing;
2. one inhibited/duplicated notification storm during a broader outage;
3. one stale or no-data answer that opens recompute rather than alerting;
4. one approximate answer that only creates a review docket;
5. one cube-derived ACP proposal accepted as `no_op` or `duplicate_suppressed`;
6. one notification whose request receipt exists but current presentation state is unknown; and
7. one old alert/exported recommendation fenced after a backfill or semantic bridge change.
