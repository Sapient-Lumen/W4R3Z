# Lessons we must learn

Ward should begin by learning from mistakes that old identity, attestation, and trust systems keep making.

## 1) Possession is not the same as trust
A key, token, certificate, or attestation blob can be real and still not justify the consequence someone wants. Ward must therefore keep custody, evidence, endorsements, local appraisal, and spendable consequence distinct.

## 2) Convenience credentials change the custody story
Passkeys are excellent, but synced passkeys and device-bound credentials do not have the same recovery, portability, or administrative control story. Ward should not flatten them into one “credential object” too early.

## 3) Evidence is not endorsement; endorsement is not verdict
RATS exists partly because prior systems kept muddling who says what and who decides what. Ward should preserve those roles even when the final UX wants a single green badge.

## 4) Provenance presence is not the end of verification
Supply-chain ecosystems repeatedly show that signed metadata and provenance are useful inputs, not self-justifying approval. Ward must keep “provenance exists”, “metadata verified”, and “locally acceptable to use” as different facts.

## 5) Recovery and backup are first-class trust facts
Systems often hide recovery posture until after an incident. Ward should do the opposite: recovery method, sync fabric, device binding, and administrative escape hatches all belong in the custody story.

## 6) Session-binding is not the same as identity or consent
Mechanisms that harden sessions against theft are valuable, but they are not identical to login, identity proof, or broad user intent. Ward should learn from them without letting them swallow the whole cube.

## 7) Backup eligibility and backup state are different facts
WebAuthn’s BE/BS distinction is a superb warning: “could be backed up” and “has been backed up” are not interchangeable. Ward should steal that habit for custody facets more broadly.

## 8) Threshold roles beat one omnipotent signing key
TUF’s role split and threshold signatures are a reminder that trust roots and update/provenance ecosystems get healthier when no single metadata key silently becomes the whole system.

## 9) Freshness is not one universal clock
Challenge-bound attestation freshness, revocation freshness, account-binding age, and supply-chain recency are different time stories. Ward should resist any attempt to collapse them into one generic “fresh” bit.

## rev0005 additions
- Backup eligibility and current backup state are different facts; Ward should never compress them into a vague “synced” bit.
- Threshold roles, metadata expiry, and provenance inputs are strong reminders that trust roots and trust material age differently.
- Session theft resistance is not identity proof; session-binding deserves its own lane and its own warrants.

## rev0007 additions
- Cross-device approval is dangerous because a legitimate credential presentation can still authorize the wrong claimant or session.
- Session theft resistance deserves an explicit lane and a typed warrant instead of being quietly merged into login or identity.
- Recovery posture should be inspectable before spend, not discovered only after an incident.
- Threshold roots and delegations stay valuable because they keep ultimate trust away from online or overly-convenient keys.
- Provenance is a witness about how an artifact was produced; it should not silently become local approval or safe-to-spend status.
- Local admission and spend deserve their own inspectable gate even after evidence, endorsements, provenance, or sessions verify cleanly.

## rev0008 additions
- Transparency receipts and public key history are excellent accountability tools, but logged or stable is still weaker than locally approved to spend.
- Public-facing acceptance posture and high-risk spend posture may need different rules; one global credential policy is often a product smell.
- Keyless identity/provenance systems are most useful when they shrink long-lived signing burden without letting short-lived witness material impersonate final trust.
## rev0011 additions
- Grouped verification receipts are valuable precisely because they remain grouped verification material rather than becoming automatic approval.
- Accountable key/binding history should stay available as witness material without flattening into a final verdict.
- Later quarantine should narrow or block present spend without erasing the reality of earlier successful verification.

## rev0013 additions
- Receipt material can remain historically valid while becoming operationally weaker; Ward should not force a false choice between timeless trust and total erasure.
- Bundled verification residue is healthier when it keeps timestamps, log evidence, and key/binding context grouped but still smaller than local spend.
- Long-lived trust requires explicit watch duty; otherwise every system quietly assumes someone else is monitoring compromise, drift, and invalidation.


- Trust systems fail quietly when client state loss is treated as irrelevant.
- Successor logs or networks can preserve continuity and still deserve fresh skepticism.

## rev0014 additions
- Receipt material can stay historically meaningful while becoming operationally too weak to spend through safely.
- Bundle age, service compromise, and auditor lag are different reasons for later skepticism and should stay visibly distinct.
- Trust systems stay healthier when someone explicitly owns later watch duty instead of assuming the log or verifier solved everything forever.

## rev0015 additions
- Trust systems lose important detection power when client continuity state is treated as disposable.
- Successor logs or services may preserve useful history and still require fresh auditing before local spend.
- Historical witness material can remain meaningful even when current approval is quarantined.

## rev0016 additions
- Status is not one universal invalid bit; suspension, refresh, revocation, and message semantics should stay visibly different.
- The authority that changes status can legitimately differ from the authority that issued the original witness material.
- Holder-provided status improves privacy but still leaves room for local freshness skepticism and watch duty.

## rev0019 additions
- Later trust change often arrives as signed statements of fact about a subject, not as a replacement for the original witness.
- Event delivery posture matters; owning a watch stream is different from receiving a one-off status carrier.
- Remote incidents can justify local narrowing without becoming remote commands.

## rev0019 additions
- A holder can prove less than they know; Ward should preserve source witness, derived proof, and local verdict as different strengths of fact.
- Unlinkable derived proofs are a reminder that later successful verification may intentionally resist correlation with the original credential presentation.
- Privacy-preserving status is still its own layer; selective disclosure should not swallow freshness, suspension, or watch duty.

## Pass XIX addition
- Do not flatten routine key rotation, delegation withdrawal, and severe root compromise into one status shape. Recovery severity matters.

## Pass XX additions
- Trust changes arrive over time; local attenuation needs its own truthful lane.
- Session revocation, credential change, device compliance change, and risk change are neighboring but non-identical events.
- A signed event can be genuine while still mapping ambiguously to local subject state.
- The receiver’s local stance should stay visible instead of masquerading as the transmitter’s will.

## Pass XXI additions
- Status semantics deserve more than one invalid bit; refresh, suspension, message, and revocation are neighboring but non-identical facts.
- Current-state oracles always have a freshness story, and cached status can stay wrong long enough to matter.
- Remote teardown success is weaker than durable local truth, especially when one action can cascade across related grants or tokens.
- Short-lived trust material and long-lived signing material may need different status models instead of one universal revocation doctrine.


## Pass XXII additions
- Current-enough status and coherent-together status are different truths; do not quietly synthesize one from the other.
- Stale, unreachable, or frozen status should usually narrow consequence without pretending to say "revoked".
- Publication history and append-only proofs improve detectability, not automatic local safety.
- Freshness artifacts can become tracking beacons if they are overly personalized or too fine-grained.


## Pass XXIII additions
- A positive status answer can mean only “not known revoked here now”; do not let it impersonate issuance, current validity, or general goodness.
- Coverage and freshness are prerequisites for interpreting a negative result; uncovered status should stay visibly unknown.
- Proof-carrying non-inclusion is materially stronger than a cache miss or empty search result.
- Local replicated corpora plus bounded deltas can beat privacy-leaking live oracles without becoming universal truth.
- Multiple transparency receipts widen accountability, not final local approval.

## Pass XXIV additions
- A system that classifies later state should not silently choose consequence; local action policy remains a different truth.
- Partial deployment and incomplete coverage are normal for a long time; observe-only and quarantine ladders can be healthier than fake universal hard fail.
- A softer-looking penalty can still behave like acceptance in practice; trust systems need an effective-validity smell test.
- Delivery-path coupling is brittle; carried, stapled, or live status transport should stay smaller than meaning.
- One ecosystem transport becoming optional or disappearing is a reminder not to freeze one universal later-status channel too early.

## Pass XXV additions
- Effective invalidity or compromise time can predate publication or processing time; do not let “we heard it now” impersonate “it became true now”.
- Known-correct interval, signing/publication time, and receiver-local adoption time are different truths and should stay visibly different when later state matters.
- Several later-state artifacts can legitimately share one underlying cause without requiring either total isolation or one giant merged incident object.
- Reason codes and user/admin explanations are useful, but they are smaller than local action policy.

## Pass XXVI additions
- Evidence without an interpretation recipe is weaker than it first appears; trust systems need a visible frame of reference.
- The same witness material can legitimately yield different normalized results under different trust roots, appraisal policies, or labeling schemes.
- Re-evaluation should narrow present consequence honestly without pretending earlier appraisal never happened.
- One summary status tier is often too lossy when the breakdown and labeling scheme materially affect meaning.

## Pass XXVII additions
- Delivery identity, cause identity, and subject identity are different facts; a duplicate delivery should not silently become a second local action.
- Timestamps are useful clues, but event time, issuance time, and receipt order do not guarantee a total order in distributed trust systems.
- Delivery acknowledgement, stream verification, and local application are three different strengths of truth and should stay visibly separate.


## Pass XXVIII additions
- Concurrent trust updates are normal; fake last-write-wins hides both uncertainty and risk.
- Causal context is stronger than timestamp folklore when later-state updates arrive in parallel.
- A latest-value or compacted projection is useful for restart and present lookup, but weaker than full trust history.
- Tombstone and retention horizons matter; after compaction, “not visible here” may be weaker than true absence.

## Pass XXIX additions
- Fast answer, complete answer, and closed-for-correction answer are different truths.
- Completeness estimates should be explicit and humble; a frontier/watermark is a claim, not omniscience.
- Late evidence needs a named correction budget rather than hidden forever-open or forever-closed behavior.
- Corrections should be explicit deltas/retractions when possible, not silent historical rewrite.

## Pass XXX additions
- Monotone accumulation and closure-dependent negatives are different trust stories; Ward should not let “no bad fact seen yet” masquerade as the same kind of truth as “one more support arrived.”
- One lost support path is not automatically full result collapse when another acceptable derivation still stands.
- Belief maintenance is smaller than custody, evidence, and spend consequence, but it still deserves explicit residue when support is revised.

## Pass XXXII additions
- Schema evolution is not one timeless object truth; authored view and consumer view should stay separately inspectable.
- Stable field identity is safer than trusting names or positions not to drift.
- Unknown fields, retired slots, and explicit presence deserve respect; transcoding can silently destroy them.
- Compatibility mode is a policy choice with upgrade choreography, not an intrinsic property of one artifact.


## Pass XXXIII additions
- Independent assurance axes should stay independent; identity proofing, current authentication, federation posture, and device/appraisal posture do not naturally collapse into one scalar truth.
- Local minimums matter as much as measured facets; a system can legitimately accept one action and reject another from the same session without contradiction.
- A summary badge is useful only when it stays visibly weaker than the facet bundle and the policy floor map that produced it.


## Pass XXXIV additions
- Must-understand semantics and safe-to-ignore residue are different processing postures.
- Preserved-but-unknown material is weaker than understood semantics, but stronger than erased residue.
- Duplicate semantically meaningful fields should not be silently normalized into trust meaning.


## Pass XXXV additions
- One observer report is weaker than a corroboration set.
- Same-cut coherence and witness independence matter more than raw signature count.
- Local quorum rules should stay visibly separate from the corroboration material they evaluate.

## Pass XXXVI additions
- Acknowledged, committed, stable-to-read, and hard-to-reverse are different truths.
- One reader can honestly lag behind a stronger upstream commitment; visibility should not masquerade as commitment or vice versa.
- Finality is often a local action threshold as much as a substrate fact; different actions can reasonably require different reversal hardness.


## Pass XXXVII additions
- Lease expiry is weaker than stale-holder exclusion; clocks disagree and delayed requests keep happening.
- Recipient-side fencing is often the real safety boundary; sender-side confidence is not enough for high-risk authority.
- Cooperative release and forced break are different postures and should not be flattened into one polite revocation story.
- Historical lease bytes or once-valid ownership should remain smaller than current authority.


## Pass XXXVIII additions
- Requested or authored policy is weaker than reconciled/applied truth; Ward should preserve that gap instead of inventing fake immediate enactment.
- Compact summary conditions need visible generation context or they will quietly masquerade as current truth.
- Deletion requested, terminating with cleanup pending, and actual absence are different truths.
- Level-based reconciliation can legitimately skip intermediate desired states; Ward should not backfill fake edge history from the latest request and latest summary alone.
- Asynchronously confirmed allocations or attachments should stay weaker than request intent.

## Pass XXXIX additions
- Current-view deletion and physical disappearance are different truths; a delete marker may hide older retained versions without destroying them.
- Negative markers need their own repair/reader horizon; purge them too early and stale replicas or lagging rebuilds can make dead state look live again.
- Retention/GC policy is a separate truth from logical retirement; rollback-friendly history and present absence can coexist honestly.
- “Deleted” should stay visibly weaker than “impossible to resurrect.”

## Pass XL additions
- A saved cursor or offset is weaker than proof that the missing interval is still replayable.
- Gap detection should be explicit and action-shaping; silent reset-to-head or reset-to-earliest hides lost coverage.
- Backfill/baseline repair is a different posture from normal forward intake and deserves visible residue.
- Continuity can legitimately downgrade even while connectivity returns.


## Pass XLI additions
- A coherent read is weaker than a current read; the exact cut matters.
- Low-latency or nearby reads usually imply a freshness bargain, and that bargain should stay visible.
- Distributed ambiguity windows deserve honest defer/restart posture instead of fake certainty.
- The read that informs orientation can be weaker than the re-check that authorizes spend.

## Pass XLII additions
- The same trust question should be able to run against an explicit pinned basis, not only against ambient latest.
- High-cardinality fact shape often teaches more than a prematurely flattened dashboard grammar.
- Contrast-first exploration can surface the real pressure-bearing dimensions before Ward freezes summary nouns.
- A maintained derivative can be extremely useful and still remain weaker than source truth.
- Pre-aggregation should follow repeated workload evidence, not lead it.


## Pass XLIII additions
- Point-in-time enrichment is not one innocent join; the chosen lookup clock materially shapes meaning.
- A pinned basis is still smaller than the temporal semantics used to attach changing context to that basis.
- Saved recipe, frozen result, live feed, and rerun diff are different truths and should not silently collapse.
- Acceleration should follow repeated workload evidence, not architectural enthusiasm.

## Pass XLIV additions
- A staged candidate is weaker than a published maintained derivative, even if both satisfy the same outward query contract.
- Hydrated and validated are different truths; finishing computation should not silently become publication.
- A typed change witness is healthier than one opaque refresh story when a promoted derivative changes.
- Preserving downstream dependencies is useful, but it should not erase the difference between candidate and official output.

## Pass XLV additions
- A repeated question can deserve a small published contract before Ward deserves one giant semantic layer.
- Human-facing recurring measures need explicit grain, header, and caveat honesty; a pretty metric title is not enough.
- Lossy rollup is useful only when the loss is named; fast answers should not masquerade as replayable raw truth.
- Contract-before-rollup is healthier than default-on pre-aggregation.

## Pass XLVI additions
- Approximate answers are useful only when they stay visibly weaker than replayable exact truth.
- Algorithm family is part of meaning; HLL, t-digest, KLL, theta, and reservoir-style estimates are not interchangeable folklore.
- Mergeable sketch state is different from one rendered approximate number and deserves separate residue when it matters.
- Approximation hygiene is healthier than picking one universal sketch constitution too early.

## Pass XLVII additions
- Repeated metrics do not naturally share one aggregation law; additive counts, distinct totals, and balance snapshots are different truth stories.
- A displayed total is often weaker than the intermediate state needed for safe recomposition.
- Safe regrouping deserves an explicit contract; “the dashboard can probably sum this later” is not a trustworthy doctrine.


## Pass XLVIII additions
- A repeated question can stay semantically fragile even after the measure name feels stable; if one join multiplies facts, the answer may already be lying.
- The meaning of a rate or average often depends on a surviving denominator or weight story; a naked rendered percentage is weaker than the residue needed to regroup it honestly.
- Convenience joins, subgroup averages, and pretty dashboards are all dangerous when they hide base grain and duplication posture.

## Pass XLIX additions
- Missing bucket, explicit null, stale-held value, true zero, and interpolated value are different truths and should not flatten into one pretty chart line.
- Densification and filling are separate operations; a generated alignment bucket is already weaker than directly observed source data.
- Carry-forward can be useful, but it is weaker than fresh observation and should eventually fall back to visible unknown/stale posture when its freshness bargain expires.
- Synthetic alignment is healthy only when the cube says it synthesized something.

## Pass L additions
- Omitted window clauses are not neutral; many systems quietly mean “all time so far” or another nontrivial default.
- Frame family is part of meaning; trailing rows, peer groups, logical ranges, and cumulative windows are different truths.
- A rolling answer is anchored to a specific evaluation instant or bucket edge, not to one timeless label.
- Early or truncated windows deserve explicit posture instead of borrowing the comparability of full mature windows.


## Pass LI additions
- Query text alone is weaker than the authorized population it ran against.
- The same recipe under a different view, row policy, or credential lane is meaning drift, not just admin plumbing.
- Field redaction and row restriction are different truth-shaping moves and should not silently collapse.
- Cross-team comparison is unhealthy when scope drift is hidden behind one shared metric title.

## Pass LII additions
- “Daily” and “weekly” are not neutral labels; calendar family, week start, time zone, and bucket origin can all change meaning.
- Civil-time grouping is weaker than raw event time and can behave non-intuitively near DST boundaries.
- UTC buckets, local-civil buckets, ISO weeks, and shifted-origin buckets should not silently borrow each other's authority.
- Bucket-rule drift is different from fact drift and deserves its own visible warning.

## Pass LIII additions
- Unit semantics are part of result meaning; a naked number is weaker than it looks once it becomes recurring.
- Canonical unit, source-unit conversion, and rendered display are different truths and should stay visibly separate.
- Ratios and percentages should not silently impersonate each other.
- Mixed-unit aggregation is usually a lie unless Ward can prove the normalization path explicitly.


## Pass LIV additions
- Fast previews are useful, but a sampled subset is a different truth class than a replayable exact result.
- Sampling method and placement in the plan matter; block, row, keyed, pre-join, and post-join samples are not interchangeable.
- Repeatability is part of meaning; a deterministic subset and a probabilistically varying preview should not share authority by title alone.

## Pass LV additions
- Distribution summaries are weaker than raw events, and their bucket grid or family is part of meaning.
- Bucket-boundary semantics matter; inclusive versus exclusive bounds, zero buckets, and overflow buckets should not hide behind one friendly label.
- A percentile derived by bucket interpolation is a different truth from an exact percentile or a sketch-estimated percentile.
- Perfect subsetting and downscaling are brilliant ideas, but Ward should steal them as optional posture rather than blessing one histogram family too early.

## Pass LVI additions
- Temporality is part of result meaning; cumulative totals, interval deltas, current snapshots, and derived rates should not silently borrow each other's titles.
- Reset handling is semantic, not renderer dust; a rate or increase that crossed restarts deserves explicit residue.
- Cross-system conversion can drop, accumulate, or rename meaning; exporter/backend compatibility is weaker than stable metric truth.
- A derived slope is weaker than its base series unless the temporality and reset story stays inspectable.


## Pass LVII additions
- Row identity is not storage coincidence; once a cube collapses rows by key, fingerprint, or retry token, that identity rule becomes part of meaning.
- Best-effort dedupe and background duplicate cleanup are weaker truths than exact append history.
- Deletes and replacements should not silently disappear into current-state surfaces when explicit correction history mattered.
- A current winner is weaker than the correction-bearing history that produced it.

## Pass LVIII additions

- Exact, threshold-suppressed, and differentially private answers are different truths.
- Protected-entity choice and contribution bounds belong to result meaning, not just policy plumbing.
- Privacy-shaped omission can be policy-shaped loss rather than observational absence or zero.
- Budget consumption and per-release noise settings are residue that should survive promotion.


## Pass LIX additions
- Resolution is part of result meaning; raw, fine-step, coarse-step, and downsampled answers should not silently borrow each other's titles.
- Storage or serving tier is semantic residue, not hidden ops plumbing, once raw replay and retained summaries no longer coincide.
- Hybrid materialized-plus-raw answers are useful, but weaker than one homogeneous replay unless the stitch seam stays inspectable.
- Retention ladders can silently change what is still replayable; tier drift is different from fact drift.

## Pass LX additions

- The first datacube duty is to say what one promoted answer cell means before deciding the engine, storage layout, plan language, or lineage stack.
- Grain, axes, measures, qualifiers, and absence posture are different responsibilities; dashboard titles are not enough.
- Physical layout can optimize and evolve, but when it changes replayability or comparability it needs visible residue rather than silent authority.
- Portable plans and columnar exports are useful boundary artifacts, not the constitution of Ward's datacube.
- Lineage should attach early enough to enable rerun, diff, downgrade, and quarantine, while remaining smaller than a workflow engine.


## Pass LXI additions

- Authority scope is part of answer meaning; a datacube answer without its view/snapshot boundary can become a hidden oracle.
- Cannot-answer is safer than plausible-wrong when a query is unsupported, denied, stale, over-budget, or outside the modeled semantic surface.
- Subtotal, null, zero, sparse-empty, suppressed, and refused cells need distinct residue.
- Mutable cuts such as schema digest, policy epoch, semantic model version, materialization generation, and redaction profile belong near promoted answers.
- Export speed and columnar shape do not substitute for scope, state, lineage, and refusal posture.

## Pass LXII additions

- Comparison is an answer with its own authority; two answer capsules do not automatically form a valid trend.
- Same title, same query text, or schema compatibility is weaker than demonstrated comparability across scope, metric, policy, quality, materialization, and refusal posture.
- Data-quality and contract validation results belong near promoted answer cells, not only in pipeline logs.
- Safe evolution can still be comparison-relevant drift; bridge-required is healthier than silent restatement.
- A current label or dimension member should not relabel historical facts unless an explicit bridge says what changed.

## Pass LXIII additions

- A why-answer is a trust-bearing answer, not harmless narration.
- Accounting movement, lineage/diff evidence, cohort contrast, exemplars, and causal claims need separate rails.
- Row-level differences and vivid examples are evidence, not root-cause proof.
- Residual unexplained movement is healthier than forced full attribution.
- LLM explanations must not upgrade “associated with” or “accounted for by” into “caused by” without counterfactual evidence.

## Pass LXIV additions

- A cache hit is an answer proposal, not answer authority.
- Freshness targets, observed lag, source recency, and consequence-grade currentness are different truths.
- Incremental refresh is conditional; eligibility and fallback posture belong near reused answers.
- Invalidation should narrow reuse without erasing reviewable evidence when retention/policy allow review.
- Recompute obligations should be visible process residue, not hidden scheduler folklore.
- Physical cleanup, compaction, and layout rewrite must not silently delete replay floors or change comparison/explanation authority.



## Pass LXV additions

- Dashboard gestures and agent follow-ups are query acts, not harmless UI state.
- Render transforms are semantic; filters, bins, sort order, top-k limits, “other” buckets, and current-layout flattening can change answer meaning.
- A saved question can be good product ergonomics while still being too compressed for Ward's trust constitution.
- Exports, screenshots, copied tables, embeds, alerts, and agent summaries are detached artifacts that need egress posture.
- Interaction trails must not become hidden surveillance logs or denied-population oracles.
- An annotation can target an answer or rendered region, but it should not silently correct answer truth.

## Pass LXVI additions

- Approximation is not just acceleration; it changes answer strength and should carry estimator-family, merge, precision, and uncertainty posture.
- Compute/resource/cost budgets, privacy-loss budgets, egress/detail limits, and authority scope are different gates and should not collapse into one vague budget bit.
- Requested answer shape and served answer shape must remain visible when exact answers degrade into sketch, sample, noisy, stale, top-k, summary-only, or aggregate-only previews.
- Nondeterminism, seed/order dependence, distributed merge posture, and validation-detail withholding belong near the answer when they affect interpretation.
- A degraded answer should start review-only unless a promotion gate explicitly accepts its uncertainty envelope for the named consequence.

## Pass LXVII additions

- “Final enough to render” is weaker than “closed against correction.” Late facts, identity repair, and policy changes need a visible correction horizon.
- A change-feed gap is not proof of no change; retained deltas, raw replay, time travel, and refusal are different repair postures.
- Hard delete, trust revocation, privacy suppression, legal erasure, and source absence are different states and should not collapse into one missing row.
- Backfills are trust-bearing process events: reason, authority, coverage, validation, outputs touched, and residual gaps belong near answer authority.
- Old exports, screenshots, copied tables, and agent summaries should become fenced historical material unless rehydrated through current authority.

## Pass LXVIII additions

- Federation is not unification; remote fragments, clean-room fragments, delegated policy decisions, and local scans need labels.
- Pushdown is a capability claim with source/version/cut, not a blanket promise from the engine.
- Join permission is not key equality; key namespace, tokenization, fanout, temporal alignment, privacy, side-channel, and policy posture belong near the join.
- Projection is release authority; allowed join columns, output columns, aggregate/list/detail posture, activation, and export may all differ.
- Trust federation, browser federation, and delegated authorization are request-shaped inputs, not portable source registries or cached population inventories.
- Safe composition failure is better than a best-effort answer that leaks denied participants or suppressed overlap.


## Pass LXIX additions

- Labels are not concepts; current display text must not become the durable identity of a consequence-grade cube cell.
- Value-set, glossary, tag, or hierarchy membership is a cut; later expansion changes must not silently restate old answers.
- Mapping grade matters: exact, close, broader, narrower, split, merge, related, no-map, and review-only are different answer strengths.
- Partner free-form tags should start weaker than governed terms, even when their names look familiar.
- Rename-not-delete preserves continuity only when the old label snapshot and concept anchor remain inspectable.
- Abstract hierarchy nodes, selectable members, subtotal rows, unknowns, no-map members, and `Other` buckets need distinct posture.
- An unmapped or withheld semantic bridge can be privacy-relevant evidence and must not leak through friendly grouping.

## Pass LXX additions

- A threshold breach is weaker than a firing alert, and a firing alert is weaker than permission to act.
- Alert routing, grouping, inhibition, silencing, dedupe, and flood limits are part of consequence safety, not merely delivery polish.
- Cube-derived action proposals need exact answer/precondition material; they must not re-query ambient latest state at validation time.
- Notification request or ACP outcome receipts are audit material, not proof of current presentation state, downstream completion, or future replay authority.
- Stale, no-data, error, refused, suppressed, or degraded answers should refuse, withhold, or open review rather than firing a stronger consequence.
- No-op, duplicate-suppressed, inhibited, silenced, and withdrawn outcomes are healthy consequence states when they prevent duplicate or stale effects.

## Pass LXXI additions

- **learning loop ledger** — compact record for proposed or actual use of cube answers, consequences, outcomes, labels, features, rewards, or agent memory in learning/evaluation/policy tuning.
- **holdout witness** — compact evidence that a cohort, assignment, or reference lane remains clean enough to measure intervention-shaped effects.
- **feedback taint fence** — compact boundary around labels, outcomes, clicks, reviewer decisions, metrics, examples, exports, or summaries shaped by prior cube-mediated intervention.
- **intervention-shaped data is not neutral** — downstream behavior after recommendations, alerts, rankings, quarantines, and UI changes needs taint residue before learning use.
- **point-in-time before accuracy** — impressive model performance is suspect if features, labels, or semantic cuts were unavailable at decision time.
- **SRM before effect** — allocation/logging diagnostics must precede effect interpretation.
- **learning report weaker than policy edit** — suggested thresholds, features, labels, or warrants stay non-authoritative until ordinary review/promote paths accept them.


## Pass LXXII additions
- Forecast, simulation, synthetic, stress-test, imputed, and counterfactual answers are not observed answers.
- Forecast-like answers need cutoffs, horizons, backtests, leakage posture, and uncertainty before they can be persuasive.
- Causal language needs an explicit counterfactual warrant; contrast plus narrative is not identification.
- Seeds and reproducibility receipts make stochastic output reviewable, not true.
- Synthetic data can carry privacy, quality, utility, and validity risk; generated rows must not naturalize into observed facts.
- Scenario outputs may open review, but action, learning, export, and policy changes still need their own Ward/SlopOS residues.

## Pass LXXIII additions
- Natural-language fluency is not datacube authority; preserve user/agent intent, translation, execution, result, and summary as different truth strengths.
- Prompt injection is not solved by better prompt wording; keep query/tool boundaries outside the model through authorization, scope, budgets, validators, and approval gates.
- Generated SQL can be syntactically valid and semantically wrong; metric cards, scope lenses, projection curtains, quality witnesses, and invariant checks must sit between prose and execution.
- Tool-call visibility is not enough unless each call is leashed by capability subset, validated arguments, effect class, budgets, retry limits, and execution receipts.
- Refusing to translate or execute an ambiguous request can be the correct high-trust datacube answer.

## Pass LXXIV additions
- A signed, logged, or packaged answer is not automatically current, correct, comparable, policy-allowed, or consequence-grade.
- Verification material must distinguish evidence packaging, replay possibility, cryptographic/logged claims, and current local appraisal.
- Replay needs explicit classes; byte-identical replay, value replay, tolerance replay, verdict replay, and non-replayable are different truths.
- Bundles are egress artifacts; they can leak metadata, old prompts, raw rows, partner fragments, policy cuts, and privacy state unless projection and redaction remain attached.
- A digest identifies material; it does not make that material trustworthy, authorized, fresh, or complete.


## Pass LXXV additions
- Retained evidence is not current authority; it must be rehydrated through scope, state, semantic, privacy, quality, and action gates before reuse.
- Custody gaps are evidence gaps: exports, forwarded charts, outside counsel packets, redactions, and re-signatures should leave handling residue.
- Retention, legal hold, privacy erasure, audit need, and minimization are different pressures; none should silently erase the others.
- Disposition is not always deletion: expiry, redaction, digest-only reduction, transfer, sealing, key destruction, sanitization, and refused disposal have different truth strengths.
- Fixity proves byte identity, not correctness, currentness, completeness, authorization, or safe disclosure.

## Pass LXXVI additions

- **Signed evidence still needs a challenge path.** A digest, attestation, replay recipe, or custody trail can make an old answer easier to inspect; none of them should make it unchallengeable.
- **Reason statements are not remedies.** Reasons help a challenger frame a dispute, but correction, withdrawal, disagreement attachment, downstream notice, learning exclusion, and action rollback need separate receipts.
- **Dispute intake should tolerate imperfect packets.** Ward should accept bounded, privacy-safe challenges without requiring the challenger to know internal field names or possess raw system logs.
- **Review must preserve the historical question.** Re-querying latest data may be useful, but it is not the same thing as adjudicating whether an old answer was valid under its original cuts.
- **Remedy reach is finite.** A corrected dashboard cell does not prove old exports, partner copies, counsel packets, learning labels, model summaries, or consequence receipts were reached.

## Pass LXXVII additions

- **Owner labels are routing hints until scoped.** Catalog, code-owner, domain-owner, and on-call systems are valuable discovery surfaces, but consequence-grade cube change needs a stewardship charter and current rehydration.
- **Delegation must be caveated and perishable.** Temporary repair authority, reviewer authority, and agent/tool authority need scope, expiry, revocation, budget, projection, and no-redelegation posture.
- **Escalation is not resolution.** A page, ticket, mention, or assignment only starts a handoff; Ward must record acceptance, refusal, partial acceptance, missing evidence, authority still absent, and closure state.
- **Governance drift is data drift.** Stale owners, team renames, orphaned metrics, expired charters, and failed owner-map loads can weaken cube answers just like stale sources or semantic drift.

## Pass LXXVIII additions
- Governance handoff prose is not enough; Ward needs packet-shaped proof obligations that can refuse false authority.
- Subject binding, duty/exclusion, currentness, delegator authority, caveats, acceptance, conflict/quorum, agent boundary, break-glass, rehydration, and projection/minimization are separate proof obligations.
- Owner hints are useful only as routing hints unless a current charter, warrant, or accepted handoff makes the requested consequence explicit.
- Governance evidence is attack surface; authority proof should not leak every steward, conflict, incident, partner, or reviewer detail.
- Negative fixtures matter: a cube that cannot reject owner-label laundering, expired delegation, ticket-assignment-as-acceptance, and agent-as-steward collapse has not earned stronger governance nouns.

## Pass LXXIX additions
- A weak governance state is valid only when its weakness is machine-visible.
- Owner hints can be useful product without becoming approval when routing-only, read-only, non-sensitive, and promotion-fenced.
- Break-glass creates an expiring sealed closure with review debt; it is not a privacy, export, remedy, or action waiver.
- Public governance projection must be checked even when no consequence-grade action is allowed.
- Positive fixtures are as important as negative fixtures because refusal-only cubes cannot support safe narrowed work.
## Pass LXXX additions

- A compact decision event is safest when it is boring: packet digest, action parity, projection class, forbidden effects, expiry/review debt, and a no-authority label.
- Event portability is not authority portability; copied governance events should downgrade whenever packet replay fails.


## Pass LXXXI additions

- A consumer cannot make a decision event stronger; it can only preserve or downgrade the event state.
- Replaying event bytes is weaker than replaying the packet that made the decision consequence-grade.
- Forbidden-effect fences must survive projection, retention, indexing, summaries, and CH-AREF attachments.
- Compacted latest-state rows are dangerous governance evidence unless tombstone retention, snapshot basis, and consumer watermarks are visible.
- Historical receipt is a healthy downgrade when current packet replay fails.

## Pass LXXXII additions

- A batch/search result is not stronger than its weakest relevant member.
- Mixed state must be visible as state counts and per-member rows; a single green badge is authority laundering.
- Search counts are projection/replay artifacts, not raw authority counts.
- Cursors must bind to query and projection-filter digests; changed scope creates a new receipt or a hold.
- Forbidden-effect fences must survive aggregation exactly; dropped fences are semantic corruption.
- Public search projection must not become an existence oracle for sealed conflicts, reviewer lanes, private org maps, incidents, or partner fragments.


## Pass LXXXIII additions

- A cursor is a query-basis memory, not a proof that page two shares current governance authority.
- Hidden governance rows must be disclosed, if at all, through audience-safe omission modes rather than exact public counts.
- Noisy counts need privacy-unit, budget, composition, and fallback closure before Ward should treat them as more than theater.

## Pass LXXXIV additions

- Evidence release is not authority release; a downloaded or forwarded bundle must keep recipient, purpose, projection, retention, refresh, and no-authority semantics attached.
- Public omission honesty must not become an existence oracle; disclose hidden governance rows only through audience-safe modes.
- Field denylist is part of the proof, not a UI choice: private owner maps, reviewer identities, incident details, named conflicts, and raw partner fragments are governance evidence leaks.
- A held recheck notice is a successful safety outcome when cursor drift, compaction, or source replay makes export unsafe.
- Export logs are too weak unless they preserve source digest, selection digest, state/downgrade posture, and forbidden-effect fences.

## Pass LXXXV additions
- A release artifact is not self-currenting; every long-lived evidence release needs a follow-up/status lane.
- Recipient acknowledgment is not approval, acceptance of stewardship, or action authority.
- Revocation/correction/quarantine must not mutate the original release receipt; immutable history and current status are separate truths.

## Pass LXXXVI additions
- Successor labels are routing/status facts, not authority grants.
- Status channels are living pointers; old channels must be invalidated, downgraded, or visibly stale after transfer.
- Predecessor closure and successor acceptance are separate checks; one ending does not prove the other accepted.
- Pending succession should hold or require refresh, not let stale releases keep circulating.
- Public transfer evidence should expose role/status pointer, not private people, org maps, incidents, conflicts, or reviewer identities.

## Pass LXXXVII additions

- Individually valid receipts can still form an unsafe chain when consumers see different cuts, branches, or status channels.
- A canonical head is a recheck/status pointer, not approval, export permission, action authority, or repair authority.
- Forks should produce a visible hold with no current head; treating one branch as green without proof is authority laundering.
- Chain summaries must preserve the union of forbidden effects from all members.
- Public branch disclosure should reveal state class, not private stewards, reviewer identities, conflicts, incidents, or partner fragments.

## Pass LXXXVIII additions

- Resolving a governance fork must be an immutable downstream receipt, not an edit to the old chain.
- A recovered current head is only a status/recheck pointer; it still requires refresh and source-packet replay before any consequence.
- Every observed branch needs a disposition, including rejected, quarantined, pending, and historical-only branches.
- Public dispute closure must not reveal sealed branch details, private stewards, reviewer identities, conflicts, org maps, partner fragments, or exact hidden branch counts.
- Notifying recipients is not authority; it is a currentness and stale-bundle containment duty.

## Pass LXXXIX additions

- Valid when cached is not current enough for later use.
- A recovered head needs recertification, but recertification is still weaker than source-packet replay.
- Cache-subject digest, status-channel recheck, refresh-channel recheck, and next-recheck due belong near every cached governance resolution.
- A refresh signal sent is not proof that every receiver refreshed.
- Public cache-state output should reveal state class, not sealed branch details, private contacts, reviewer identities, conflicts, org maps, partner fragments, or exact hidden counts.


## Pass XC additions

- Signal delivery is not authority. Source/id keys, duplicate windows, watermarks, and receiver-local policy must be checked before any refresh signal can influence a cached governance state.
- Push acknowledgement is not consumer refresh; poll order is not causal order; conflicting signals must hold without a silent latest-wins rule.

## Pass XCI additions

- Notification is not recertification; a fanout receipt records obligation state, not consumer-local refresh.
- Acknowledgment is not authority; consumer acks must stay smaller than source-packet replay and consequence gates.
- Dead-lettering is not delivery; dead-lettered consumers keep affected cache subjects quarantined until review or recertification closes the gap.

## Pass XCII additions

- Notification fanout is not consumer-local refresh; a reconciliation receipt must bind recertification evidence per affected consumer.
- Acknowledgments are useful delivery evidence, but they stay smaller than recertification, replay, and consequence gates.
- Dead-letter and pending retry states are stale-consumer facts, not successful delivery or safe cache reuse.
- Duplicate notification should normally suppress work, not mint a new refresh fact.
- The checker suite is itself a governance surface; hardcoded validator lists become drift risk once receipt families multiply.

## Pass XCIII additions

One clean receiver is not global convergence. A majority of receivers is not authority. Receiver convergence must preserve lagging receivers, divergent status-channel cuts, duplicate observations, fork holds, and overlap-set differences as first-class refusal evidence.

## Pass XCIV additions

- Receiver convergence is not a reuse grant; every downstream use must bind purpose, consequence class, requested effect, projection policy, cache subject, and source bytes.
- Display-safe reuse and export-safe reuse are different states, not severity levels of one green badge.
- Schema identity is now part of checker hygiene, not a doc-only convention.

## Pass XCV additions

- Use execution is a separate trust seam: a gate result can be correct while the consuming surface performs the wrong effect. Actual effects need their own digest, projection guard, no-authority label, and no-execution states.

## Pass XCVI additions

- Execution evidence is not observed-outcome evidence; a consumer can perform or report one effect while the system exhibits another.
- Mismatch quarantine is a safety state, not rollback authority. Rollback and remedy need their own handoff/remedy proof.
- Unavailable observation must hold without a green claim.
- Fixture layout is part of the refusal harness; validator families need auditable positive/negative shape.


## Pass XCVII additions

- Rollback review is not rollback. A remediation handoff request is not a completed remedy.
- A mismatch can require quarantine and notice without granting repair, export, learning use, status-pointer mutation, or action authority.
- Matched and no-op observations still need refresh/source replay; no-remediation-needed is a bounded closure, not durable trust.
- Schema files are governance surfaces once validators and fixtures depend on them; unaudited schema growth is drift risk.

## Pass XCVIII additions

- Closure is not remedy. Review closure, handoff acknowledgment, no-remediation closure, and unavailable-observation escalation must stay smaller than rollback execution, quarantine clearance, public correction, and durable trust.
- External remedy proof needs its own intake/refusal surface; a closure receipt may record verification debt, not complete the proof chain.
- Human runbooks are governance surfaces once they tell maintainers which refusal harnesses exist. Registry-backed tools still need human discoverability checks.

## Pass XCIX additions

External proof is not authority. Verified proof can still require quarantine, refresh, projection, and source replay.
