# SlopOS / companions evaluation — pass XXX

This pass keeps Ward embryonic while stealing one more useful habit from the neighbors: **make monotonic accumulation cheap, make non-monotonic gates visible, and keep support state smaller than consequence.**

## What the current cubes still teach
- **SlopOS** already has the strongest nearby lesson for this pass: interface-first commutativity discipline. It prefers commutative common-case operations and names the minimal serialization boundary when order really matters. Ward should steal the smaller analog: keep monotone trust residue cheap and local, and name the exact `closure gate` when a result depends on absence, counting, threshold satisfaction, or “no conflicting event has arrived yet.”
- **SlopOS** also keeps ordering evidence small. Its ordering-token posture is a witness seam, not a generic sequencing service. Ward should steal the analogous restraint here too: `closure gate` should be a narrow witness that non-monotonic reasoning is now allowed, not a universal workflow engine.
- **SlopOS** keeps compiled/current artifacts visibly smaller than the source logic that produced them. Ward should mirror that habit by keeping `support braid` smaller than complete provenance history and smaller than final spend consequence.
- **Harbor** and **Steward** remain useful reminders that quick success and visible continuity aids are weaker than durable local effect. Ward should now add the sibling reminder that one vanished support is weaker than total invalidity if a second derivation still stands.

## Current recommendation
Keep Ward open on whether support state lives as inline residue on result objects, beside a projection/watch lane, or in a separate belief-maintenance adjunct.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **monotonicity class** instead of smearing safe accumulation and closure-dependent logic together;
2. **closure gate** instead of ambient “probably complete enough” folklore;
3. **support braid** instead of one flattened reason string;
4. **alternate derivation** instead of automatic whole-result collapse;
5. **a small noun-promotion rubric** so attractive new words must earn permanence through specimen pressure rather than style.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should still avoid freezing one universal provenance engine, one dependency-graph substrate, one support-counter algorithm, or one global closure protocol into the archive.
The smaller steal is enough for now:
- add a tiny noun-promotion rubric inspired by SlopOS’s promotion discipline;
- keep the latest research/evaluation/specimen surfaces wired into the front door;
- and fail the revision if `START_HERE.md` stops naming the latest evaluation pass as well as the latest research/specimen pass.

## Still-not-yet decisions
- Whether `monotonicity class` belongs in Ward proper or remains design-time guidance until more specimens accumulate.
- Whether `closure gate` is durable Ward vocabulary or belongs in an adjacent projection/observation cube.
- Whether `support braid` should be first-class archive residue or remain compact provenance sidecar data.
- Whether `alternate derivation` deserves durable vocabulary or stays an implementation-side inference.
- Whether Ward should ever standardize one belief-maintenance carrier, or only insist that support loss and result loss are not the same thing.
