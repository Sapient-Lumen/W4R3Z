# Research synthesis — pass LXIX

Pass LXVIII made federation visible: a polished SlopOS-facing cube answer must not launder remote fragments, clean-room rules, delegated policy decisions, or projection permissions into one local-looking truth. Pass LXIX follows the next failure mode: even inside a permitted answer, the **names** of things move. Labels, codes, categories, glossary terms, taxonomy nodes, unit strings, provider risk families, policy names, and partner tags can rename, split, merge, broaden, narrow, deprecate, or drift while dashboards keep drawing the same axis.

The restraint rule still holds. Ward should not choose RDF, SKOS, OWL, FHIR terminologies, QUDT, a business glossary, a semantic-layer product, a canonical vocabulary registry, a universal concept graph, or a SlopOS-wide ontology as the datacube constitution. SlopOS remains in design phase, and even its current attribute/query surfaces are deliberately bounded. The right move is to name answer-level residues that preserve semantic identity and mapping evidence without freezing the whole vocabulary universe.

## What the past says we must learn now

1. **Labels are not concepts.** SKOS says concepts can have URI identity, lexical labels, notations, notes, hierarchical links, associative links, collections, schemes, and mappings to other schemes (`EXT-W3C-SKOS-2009`). Ward should steal the distinction, not the whole RDF stack: a current label on a cube axis is display residue, not durable concept identity.

2. **A value set expansion is a cut, not timeless truth.** FHIR ValueSet distinguishes intensional composition from expansion and frames a value set as a selectable set of codes drawn from code systems (`EXT-HL7-FHIR-VALUESET-2026`). A SlopOS datacube bucket derived from a value set, tag set, provider-family list, or glossary slice needs an expansion/cut witness; otherwise an old answer can be silently restated through today's membership.

3. **Mappings require grade, direction, and context.** FHIR ConceptMap treats relationships between source and target concepts as contextual and graded, with applicability metadata such as use context and effective periods in the definitions (`EXT-HL7-FHIR-CONCEPTMAP-2026`, `EXT-HL7-FHIR-CONCEPTMAP-DEFINITIONS-2026`). Ward should not flatten `exact`, `equivalent`, `wider`, `narrower`, `related`, `unmatched`, and `no-map` into one bridge bit.

4. **Unit strings are too weak for repeated answers.** QUDT provides a vocabulary of units (`EXT-QUDT-UNITS-2026`). Ward already has unit binding and conversion witnesses; pass LXIX extends the lesson to semantic units and qualifiers: display strings like “days,” “risk,” “recovered,” or “provider family” are not enough when regrouping or comparison has consequence.

5. **Dimension changes need history, not overwrite folklore.** Kimball Type 2 slowly changing dimensions preserve new dimension rows with effective datetime fields rather than overwriting prior reality (`EXT-KIMBALL-TYPE2-SCD-2008`). Ward should treat a renamed, split, merged, or reclassified member as dimension-history pressure, even when a future SlopOS implementation does not resemble a star schema.

6. **Business vocabulary is owned and mutable.** DataHub glossary material models terms, groups, owners, relationships, and Git-managed glossary-as-code workflows (`EXT-DATAHUB-BUSINESS-GLOSSARY-2026`). Its Domains docs distinguish informal tags, governed glossary terms, and top-level domains (`EXT-DATAHUB-DOMAINS-2026`). Ward should steal the separation: partner tags, local labels, controlled terms, and ownership domains should not collapse into one axis authority.

7. **Rename is safer than delete, but still changes evidence.** OpenMetadata best practices recommend renaming glossary terms rather than deleting them when names are wrong, and its glossary-term docs treat terms as preferred terminology for concepts with synonyms, child terms, related terms, references, reviewers, status, and assets (`EXT-OPENMETADATA-GLOSSARY-BEST-PRACTICES-2026`, `EXT-OPENMETADATA-GLOSSARY-TERMS-2026`). Ward should not treat rename as semantic no-op; it should preserve label snapshots and review posture.

8. **Companion pressure already says identity and labels split.** Foundry's identity-anchor / label-snapshot / axis-budget pressure is a useful sibling echo, but Ward should not import Foundry's nouns wholesale. Ward needs cube-answer residues: concept anchors, crosswalk warrants, and hierarchy cuts that can compose with existing Ward answer capsules.

## Resulting Ward move

Do **not** decide yet:

- one universal SlopOS ontology, controlled vocabulary, concept registry, glossary tool, code-system protocol, terminology server, or semantic-layer product;
- whether concept material is represented as RDF/SKOS, FHIR, JSON Schema, relational dimensions, Arrow metadata, catalog facets, or plain receipts;
- one global alias graph, canonical member ID scheme, unit vocabulary, locale/display policy, synonym strategy, or taxonomy governance body;
- one hierarchy language for all rollups, including trees, DAGs, collections, polyhierarchies, rule-based value sets, or materialized closures;
- one equivalence-grade vocabulary or automatic mapping algorithm for every source and partner tag;
- one rule that current labels should always restate old answers, or that old labels should always be frozen forever;
- one UI grammar for concept identity, renamed members, split buckets, unmapped cells, broader/narrower rollups, or abstract-only hierarchy nodes.

Do add three small, reversible residues for semantic drift:

- **concept anchor** — compact semantic identity card for a groupable axis, member, status, measure qualifier, code, term, unit-like concept, or semantic bucket. It names source/vocabulary family, concept identifier or handle, owner/reviewer, definition handle or digest, version/cut/effective interval, label snapshots, status/deprecation posture, locale/display posture, selectable-vs-abstract posture, and sensitivity/policy flags. It is smaller than an ontology and stronger than a label.
- **crosswalk warrant** — compact evidence that a source concept/member/code/term/tag can be bridged to a target concept for a named answer context. It names source and target anchors, direction, equivalence grade, cardinality, split/merge posture, loss notes, confidence, author/reviewer, effective period, evidence, no-map/unmapped/refusal state, and affected cells. It is smaller than a mapping engine and stronger than “same name.”
- **hierarchy cut** — compact rollup/classification membership snapshot for one answer or comparison. It names scheme/root, version/cut/effective interval, parent/child closure, multiple-parent posture, abstract/selectable nodes, subtotal/all/unknown semantics, rollup law, excluded/unmapped members, and whether the closure is authoritative, inferred, imported, or review-only. It is smaller than a taxonomy platform and stronger than a visual tree.

These residues sit beside earlier nouns. Concept anchors feed axis capsules, metric cards, scope lenses, render contracts, and egress receipts. Crosswalk warrants feed comparability passports, drift notices, delta anatomies, federation pacts, join warrants, and refusal receipts. Hierarchy cuts feed aggregation laws, rollup passports, privacy/suppression fences, and projection curtains.

## Brilliant ideas to steal now

- **Concept identity before label.** Current display text should never be the only durable key for a consequence-grade cube cell.
- **Label snapshot lane.** Preserve label text, language/locale, source, and time cut separately from concept identity.
- **Value-set expansion receipt.** When a category is generated by a rule or controlled list, preserve the expansion/cut that created the membership.
- **Equivalence grade.** A mapping can be exact, close, broader, narrower, related, review-only, one-way, deprecated, or refused.
- **Split/merge posture.** A category split or merge is not a rename; affected historical cells need explicit bridge choices.
- **No-map as first-class.** Unmapped members should be represented as evidence, not dropped into “Other” without a witness.
- **Abstract versus selectable nodes.** A hierarchy can contain nodes that organize meaning but should not receive direct facts.
- **Tag/term/domain separation.** Informal tags, governed terms, and ownership domains have different authority and should not be interchangeable cube axes.
- **Rename-not-delete with receipt.** Preserve the old label and a review trail even when a concept keeps identity.
- **Locale/display humility.** Display names can be translated, shortened, redacted, or made UI-friendly without becoming semantic identity.

## Candidate specimen pressure

Use a SlopOS reviewer question such as: “Which credential-provider risk families deteriorated month-over-month for this authorized view, and which evidence families explain the movement?” The source materials include local CH-ATTR fields, a design-phase SlopOS provider-family label, a Harbor evidence code summary, a Foundry semantic spine label, a Steward activation-cause split, one partner free-form tag, and an old exported Helm table. The answer should refuse a smooth trend unless concept anchors, crosswalk warrants, and hierarchy cuts can explain which labels, codes, buckets, and rollups were comparable under the requested state cut.

## Still-not-yet decisions

- Whether every axis/member needs a concept anchor or only consequence-grade axes, cross-source mappings, exported artifacts, and long-lived dashboards.
- Whether concept anchors should live in Ward answer capsules, SlopOS CH-ATTR metadata, Foundry semantic spines, Harbor evidence summaries, Steward activation epochs, a catalog, or multiple places with references.
- Whether crosswalk warrants are authored manually, generated from controlled vocabularies, inferred from lineage, negotiated at federation boundaries, or all of the above.
- Whether hierarchy cuts should be tree-only at first or allow DAG/polyhierarchy membership from the beginning.
- How much of concept/mapping/hierarchy residue belongs in compact UI badges versus inspectable receipts.
- Which semantic changes are merely drift notices and which must invalidate, recompute, fence, or refuse old answers.
