# Research synthesis — pass LI

This pass keeps Ward decision-light and adds another datacube discipline: **the same query text is not the same meaning when it runs against a different authorized population.**

## What the past says we must learn
1. **A view can be part of the truth contract, not just a convenience wrapper.**  
   BigQuery's authorized-view docs say authorized views let you share query results with particular users and groups **without giving them access to the underlying source data**, and that the view's SQL can exclude columns and fields from the results. Ward should steal the constitutional lesson: a promoted recurring question is weaker if it names only the query recipe and hides the authorized view or row/field slice that made the answer possible (`EXT-BIGQUERY-AUTHORIZED-VIEWS-2026`).

2. **Security mechanism changes are meaning changes, not just admin plumbing.**  
   BigQuery's row-level-security overview says authorized views, row-level access policies, and separate tables provide different mixes of security, performance, and convenience, and recommends different choices for different use cases. Ward should borrow the humility: if the same question is rerun under a new row-access lane or a more isolated table, that is not automatically “the same answer, just with permissions changed” (`EXT-BIGQUERY-RLS-INTRO-2026`).

3. **Per-surface scope must be explicit.**  
   Looker's `access_filter` docs say `access_filter` applies **user-specific data restrictions** and is **specific to a single Explore**. Ward should steal the design pressure: one repeated question may need a scope declaration attached to the exact published surface rather than inherited from ambient workspace folklore (`EXT-LOOKER-ACCESS-FILTER-2026`).

4. **Credentials are part of scope.**  
   dbt's Semantic Layer FAQ says service tokens are mapped to underlying data-platform credentials, that those credentials control physical access to raw data, and that physical access policies tied to those credentials are respected for every request. Ward should borrow the discipline: identical query bytes can still differ materially if they rode different credential or policy lanes (`EXT-DBT-SL-PERMISSIONS-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal row-level-security grammar, one ACL DSL, one view-object schema, or one credential-policy registry.

For now, keep three more separations visible and let later specimens force promotion:
- **view binding** — explicit authorized slice, dataset view, or scoped lens the recipe ran against.
- **population witness** — visible statement of which rows/fields/population the answer actually covered.
- **scope drift alarm** — visible residue that the same recipe or contract reran under a different view binding, credential lane, or policy envelope.

## Why these separations are worth stealing
- A `view binding` stops one pretty metric title from borrowing authority across broader and narrower populations.
- A `population witness` keeps a result from hiding whether rows, fields, or both were filtered away by security or sharing posture.
- A `scope drift alarm` keeps fact changes distinct from visibility changes when a later rerun sees more or less than the earlier one did.

## Brilliant ideas to steal now
- **view binding** — explicit authorized scope object for one recurring question.
- **population witness** — compact statement of what population the answer really covers.
- **scope drift alarm** — visible warning when the same recipe moved to a different authorized slice.
- **no silent scope widening** — standing anti-regrowth rule.
- **query text weaker than population** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward ever needs one machine-readable scope schema shared across all companion cubes.
- Whether `population witness` should be mandatory on every exploratory result or only on promoted recurring surfaces.
- Whether `scope drift alarm` is only a review/header concern or later becomes typed durable residue.
- Whether some repeated questions should permanently remain private view-scoped recipes rather than earning a published cross-team contract at all.
