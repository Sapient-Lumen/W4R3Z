# Research synthesis — pass XCIII — receiver convergence and registry audit

Pass XCIII extends Ward from one-receiver reconciliation to multi-receiver convergence.

## External pressure

`EXT-OPENID-SSF-2025` frames event exchange between transmitters and receivers as a stream relationship, which pressures Ward not to treat any single receiver's local observation as global truth. `EXT-RFC-8935` and `EXT-RFC-8936` reinforce the same split for push and poll delivery: delivery and acknowledgement are transport facts, not receiver-local refresh or global convergence.

`EXT-CLOUDEVENTS-SPEC-2026` keeps event identity and duplicate detection visible through source/id style identity, while `EXT-CLOUDEVENTS-SUBSCRIPTIONS-2026` keeps subscriptions, filters, and sinks separate from the meaning consumers attach to events.

`EXT-SCITT-ARCH-2026-LATEST` keeps plural receipt histories and registration-policy evidence visible. This pressures Ward to bind receiver observations by receipt bytes and cut digests rather than trust whichever status channel produced the latest or most convenient answer.

`EXT-NIST-SP-800-137-2011` adds continuous-monitoring pressure: currentness is not a one-time event. Receiver convergence needs cadence, recheck, and stale-receiver quarantine.

## Ward consequence

Ward adds `ward.governance.receiver-convergence-receipt.v0` as a non-authority monitoring/audit receipt. It can say:

- all required receivers converged, but replay/refresh remains required;
- a receiver is lagging and quarantined;
- status-channel cuts diverge and no winner may be selected;
- a duplicate observation was suppressed;
- a receiver fork remains quarantined.

It cannot grant authority, update a status pointer, choose a global winner, approve an action/export/remedy, or treat receiver quorum as current truth.

## Audit/refactor consequence

The checker registry introduced in rev0092 is now checked by `tools/check_governance_registry_integrity.py`. That checker verifies registry revision parity, unique ids/scripts, checker file coverage, fixture directory coverage, and positive/negative fixture presence. The suite and audit code share registry helpers from `tools/governance_common.py`.
