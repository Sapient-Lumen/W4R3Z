# SlopOS / companions evaluation — pass XXI

This pass re-checks Ward against the uploaded cube ecology and still argues for a small, distinct trust cube.

## What the current cubes still teach
- **SlopOS** keeps import boundaries, proof cuts, and same-revision family maintenance explicit. Ward should steal the habit of marking a few load-bearing outside sources and reviewing them intentionally rather than letting mutable heads silently steer promotions.
- **Helm** reminds us that "signed out", "needs refresh", and "blocked from high-risk action" are neighboring user-facing states, not one universal trust fact.
- **Harbor** keeps crossing and outcome separate; Ward should remember that fetching status material or receiving an event is weaker than deciding what it means locally.
- **ViewFS** keeps stable identity and current reachability distinct; Ward should likewise separate original witness identity from later status lookup or list position.
- **Steward** keeps followthrough, retry windows, and current countdown posture typed; Ward should likewise make recency windows visible instead of pretending currentness is free.
- **Foundry** keeps provider-native runtime facts smaller than local approval; Ward should likewise keep issuer-published status smaller than local spend/adopt consequence.

## Current recommendation
Keep the new Ward nouns provisional.

The smallest wise move now is to preserve three separations and keep the transport choice open:
1. **status purpose** versus generic invalidity,
2. **recency window** versus fake live truth,
3. **status authority** versus original issuance history.

Do **not** decide yet whether Ward's long-term continuous-status substrate is:
- push events,
- pull streams,
- compressed status lists,
- direct point lookups,
- or some mixed ecology.

## Hygiene/process consequence
Because SlopOS is still in design phase too, the right thing to steal is not heavyweight closure.
It is lightweight maintenance discipline:
- keep a short register of load-bearing outside sources,
- re-check moving specs before promoting durable nouns,
- and prefer same-revision cleanup whenever a new outside pressure becomes design-shaping.

## Still-not-yet decisions
- Whether `status coordinate` belongs in Ward proper or remains wire-level detail.
- Whether `external status issuer` stays a first-class Ward noun or later compresses behind existing status-authority-split language.
- Whether time-cut status queries deserve durable archive vocabulary or remain an implementation trick.
- Whether short-lived/no-status posture belongs in Ward as a first-class family or merely as a specimen test that keeps universal revocation folklore away.
