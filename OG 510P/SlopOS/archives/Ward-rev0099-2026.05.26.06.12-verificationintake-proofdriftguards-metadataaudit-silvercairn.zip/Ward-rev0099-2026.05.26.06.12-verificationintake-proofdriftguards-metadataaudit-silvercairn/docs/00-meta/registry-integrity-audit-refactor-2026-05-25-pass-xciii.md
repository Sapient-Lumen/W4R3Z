# Registry integrity audit/refactor — pass XCIII

## Audit finding

Rev0092 moved the governance checker suite from a hardcoded list into `tools/governance_checker_registry.json`, but the registry itself was not yet audited by an executable checker. That meant a future contributor could add a checker or fixture family on disk without registering it, or update the revision without noticing registry drift.

## Refactor

Pass XCIII adds:

- `tools/check_governance_registry_integrity.py`
- `load_registry()` in `tools/governance_common.py`
- `fixture_counts()` in `tools/governance_common.py`
- `governance_checker_scripts()` in `tools/governance_common.py`
- a small suite update so `check_governance_suite.py` uses the shared registry loader

## New checks

The registry-integrity checker verifies:

- registry revision matches `REVISION-RECEIPT.json`;
- registry ids and scripts are unique;
- every governance checker script is registered;
- every governance fixture directory is registered;
- every fixture-backed checker has at least one positive fixture and one negative fixture;
- registry-integrity itself is in the suite but does not pretend to be fixture-backed.

## Deliberate limits

The checker does not execute nested schema validation, infer semantic coverage, or enforce naming taxonomy across all old checker files. It only closes the highest-risk registry drift seam while keeping the suite small enough to run inside Ward's current embryo constraints.
