# SlopOS / companions evaluation — pass LXIII

Pass LXIII treats explanation as a separate trust-bearing datacube answer. Pass LXII said a comparison needs a comparability passport before a trend. Pass LXIII says the explanation of that trend needs a delta anatomy, attribution rail, and exemplar fence before it can influence trust consequence.

## What the included cubes keep teaching

- **SlopOS** remains the anchor. D-ATTRFS / CH-ATTRQ posture already leans view-scoped, snapshot-first, handle-returning, bounded, and non-oracular. A “why did this cell move?” query must not widen the view, follow ambient latest state, or turn refused cells into implied existence evidence.
- **Harbor** is the strongest sibling pressure for delta anatomy. Harbor's change-history lanes, temporal witnesses, contract subsets, lineage guards, and restatement habits suggest that answer movement needs accounting categories before it becomes a story.
- **ViewFS** is the warning for exemplar fences. A drill-through row, file, preview, or exported batch is a different authority surface from the aggregate cell. Ward should require handle/scope/redaction/representativeness posture before examples are shown behind a cube answer.
- **Foundry** keeps basis, candidate, active generation, restore duty, and foreign handles distinct. A trust trend can move because the basis generation changed, not because the observed population got worse. The delta anatomy should keep basis movement separate from behavioral movement.
- **Steward** keeps bootstrap, reconciliation, cause condition, followthrough, and process state visible. Ward should treat reconciliation as an administrative/accounting explanation unless stronger evidence earns causal language.
- **Schell** keeps basis cards, activation receipts, and environment epochs distinct. If an explanation crosses activation or environment epoch changes, Ward needs a rail that says whether the movement is config/environment accounting, source evidence, or causal inference.
- **Helm** is where the harm becomes visible. Helm will be tempted to render “why” panels and LLM summaries. Ward should give Helm badges and refusals: accounting, diff, contrast, exemplar, causal-not-earned, and residual-unexplained.

## What this means for the SlopOS datacube

A SlopOS-facing why-answer should require at least:

1. **A comparison capsule as input.** Do not explain a trend until the compared answers already have comparability passports, drift notices, quality witnesses, state cuts, and refusal posture.
2. **A delta anatomy before narrative.** Separate fact movement, scope/population movement, metric-card movement, axis/member bridge movement, quality/refusal movement, privacy/suppression movement, materialization/tier movement, late-correction movement, and residual unexplained movement.
3. **An attribution rail per claim.** Each sentence in the explanation should know whether it is accounting, lineage/where, derivation/how, value diff, cohort contrast, exemplar/drill-through, or causal/counterfactual.
4. **Exemplar fences for drill-through.** Examples need selection rule, view scope, redaction, privacy/suppression posture, and a clear “not representative unless proven” caveat.
5. **Residual stays visible.** A why-answer may be partly unaccounted for; that residual should remain a visible bucket, not a rhetorical gap filled by an LLM.
6. **Causal language is opt-in and high friction.** “Caused” requires a stronger rail with explicit design/counterfactual assumptions. Most SlopOS datacube explanations should say “accounted for by,” “associated with,” “from these inputs,” or “unexplained.”

## Companion-specific steals

- From **Harbor**: restatement receipts and change-history lanes as source pressure for delta anatomy.
- From **ViewFS**: handle/export humility for examples and drill-through material.
- From **Foundry**: basis-generation separation so explanation does not confuse substrate change with subject behavior.
- From **Steward**: process-stage accounting without causal overclaim.
- From **Schell**: environment epochs and activation receipts as explicit explanation categories.
- From **Helm**: visible badges, caveats, and refusal affordances for why-panels.

## Anti-lessons to preserve

- Do **not** let an answer capsule's lineage facet become a full causal story.
- Do **not** let a data diff become root-cause proof.
- Do **not** let a high-cardinality cohort contrast become causal language by dashboard habit.
- Do **not** let one vivid exemplar stand in for a cell, cohort, or population.
- Do **not** let refused/suppressed cells disappear from the explanation denominator.
- Do **not** let LLM narration upgrade “associated with” into “caused by.”
- Do **not** hide residual unexplained movement just because the human asked for a crisp why.

## What Ward should probably steal next

- a **delta anatomy** beside any explanation of a changed cube answer;
- an **attribution rail** for each explanation fragment so allowed verbs and claim strength stay visible;
- an **exemplar fence** for any drill-through example used to orient a human;
- a standing **why-answer weaker than causal proof** rule for dashboards, agents, and promotion gates;
- a small suite of **explanation probe fixtures** before any explanation residue becomes machine-readable contract.
