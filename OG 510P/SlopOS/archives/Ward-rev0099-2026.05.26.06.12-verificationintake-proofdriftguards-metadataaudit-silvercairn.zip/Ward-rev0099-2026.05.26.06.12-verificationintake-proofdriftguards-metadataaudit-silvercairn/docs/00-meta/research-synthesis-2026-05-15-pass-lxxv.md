# Research synthesis — pass LXXV

Pass LXXIV made verification material portable: bundles, replay recipes, and attestation envelopes can help a reviewer challenge an answer. Pass LXXV follows the next failure mode: once evidence can travel, someone has to decide who may hold it, how long it remains readable, when it must be preserved, when it must be minimized, and what it means to dispose of it.

The trap is familiar. An archive can start to look like current authority. A retention hold can start to look like permission to keep using an old answer. A deletion can start to look like amnesia even when digests, tombstones, notices, legal obligations, or downstream exports remain. A WORM store can start to look like truth instead of merely an anti-tamper control. A signed verification bundle can keep circulating after the authority, privacy, source, semantic, or consequence boundary that justified it has expired.

The new posture: Ward should let SlopOS datacube evidence have a visible lifecycle without choosing a records-management product, legal taxonomy, archival repository, WORM store, or sanitization regime. Lifecycle residue is answer-adjacent evidence, not a storage engine and not current answer authority.

## What the past says we must learn now

1. **Disposition is a managed act, not a background timeout.** NARA records schedules are mandatory disposition instructions that say how operational records are maintained and what happens when they are no longer needed, including permanent versus temporary retention (`EXT-NARA-RECORDS-SCHEDULE-2021`). Ward should steal the idea of explicit lifecycle authority, not NARA's domain-specific schedule vocabulary.

2. **Custody is chronological handling evidence.** NIST defines chain of custody as tracking the movement of evidence through collection, safeguarding, and analysis by recording each handler, collection or transfer time, and transfer purpose (`EXT-NIST-CHAIN-CUSTODY-GLOSSARY-2026`). Ward should not pretend a bundle digest is enough when a consequential export moved through dashboards, email, auditors, agents, or partner tools.

3. **Fixity is useful but narrow.** BagIt distinguishes payload from tag metadata and uses manifests of filenames and checksums for transfer/storage fixity (`EXT-LOC-BAGIT-2019`). OCFL's preservation-oriented layout emphasizes structured, transparent, predictable storage for long-term repository management (`EXT-OCFL-1-1-2022`). Ward should steal fixity checks and boring package readability, but not treat matching bytes as fresh, authorized, semantically correct, or privacy-safe.

4. **Preservation metadata is multi-entity, not one blob.** PREMIS organizes preservation metadata around objects, events, rights, and agents (`EXT-PREMIS-3-0`). OAIS pressure says an archive has accepted responsibility to preserve information and make it available for a designated community (`EXT-CCSDS-OAIS-3-2024`). Ward should separate answer object, custody events, rights/policy posture, agents, designated verifier class, and preservation intent.

5. **Legal hold and retention are different controls.** S3 Object Lock documentation distinguishes retention periods from legal holds; a legal hold prevents overwrite/delete and has no fixed duration, remaining until removed (`EXT-AWS-S3-OBJECT-LOCK-2026`). Ward should steal the split: a hold can block disposal without making old answer material current or consequence-grade.

6. **Disposition review is part of the lifecycle.** Microsoft Purview's disposition surface manages reviews and metadata for items marked as records that are automatically deleted at the end of retention (`EXT-MICROSOFT-PURVIEW-DISPOSITION-2025`). Ward should make review/approval/refusal visible when bundles, exports, prompts, validation sidecars, or partner fragments hit a retention boundary.

7. **Erasure and retention can collide.** GDPR Article 17 gives data subjects a right to obtain erasure of personal data without undue delay under named grounds (`EXT-EURLEX-GDPR-2016`). Ward should not try to become a legal engine, but it must keep privacy erasure, legal hold, audit retention, and historical proof as distinct pressures so one cannot quietly override the others.

8. **Deletion is not the same as sanitization.** NIST SP 800-88 Rev. 2 frames media sanitization as rendering access to target data infeasible for a given level of effort and provides program guidance based on sensitivity (`EXT-NIST-800-88R2-2025`). Ward should distinguish logical deletion, redaction, cryptographic erasure, media sanitization, external-recipient notice, and digest-only retention.

9. **Keep less, prove enough.** The datacube should prefer proof-minimizing lifecycle material: retained digests, event receipts, redacted bundles, aggregate-only witnesses, projection curtains, and revocation/disposition receipts can sometimes satisfy review needs without retaining raw rows, partner fragments, prompts, or exemplars.

10. **Archives are audiences, not oracles.** An archival package can help a designated community understand and verify old material, but it should not answer current source authority, current privacy posture, current semantic mapping, or current action permission by itself.

## Resulting Ward move

Do **not** decide yet:

- one storage backend, object-lock mode, WORM system, evidence vault, records-management product, legal-hold workflow, DLP product, archive repository, preservation package, or sanitization process;
- one global retention period, disposal schedule, erasure rule, legal taxonomy, audit class, designated-community model, or jurisdiction policy;
- one format for custody logs, disposition certificates, manifest files, fixity checks, chain-of-custody signatures, transfer records, or downstream notices;
- one rule that every answer, export, verification bundle, model prompt, validation sidecar, partner fragment, or raw row must be retained forever or destroyed at once;
- one claim that WORM, hold, backup, archive, hash, or disposal proof equals current authority.

Do add three small, reversible residues:

- **custody trail** — a chronological handling trail for answer capsules, verification bundles, exports, replay materials, sidecars, model-mediated summaries, and derived evidence. It names holders, transfers, purposes, access class, fixity checks, transformations, projection/redaction changes, and gaps. It answers “who or what handled this evidence?” not “is this answer true?”
- **retention charter** — an answer-local or artifact-local lifecycle posture naming why material is retained, for whom, for how long, under which hold/erasure/audit/privacy pressures, at what projection/detail level, and with which review gates. It can say digest-only, redacted-only, aggregate-only, partner-held, expired, legal-hold, or not-retainable.
- **disposition receipt** — a compact receipt for deletion, expiry, redaction, transfer, sealing, hold-extension, cryptographic erasure, sanitization claim, digest-only reduction, or refused disposal. It records what happened, authority, method class, evidence strength, residual material, downstream notice posture, and non-amnesia limits.

## Why these names and not stronger machinery

- “Custody trail” borrows chain-of-custody discipline without claiming every cube artifact is court evidence.
- “Retention charter” keeps lifecycle intent near the answer without freezing a global compliance schedule.
- “Disposition receipt” acknowledges that end-of-life actions are consequential events, while staying weaker than proof that every downstream copy vanished.

## Hygiene rule for SlopOS

A retained SlopOS datacube artifact is never stronger than the weakest of:

- current scope lens and state-cut witness;
- verification bundle and attestation envelope limits;
- projection, privacy, revocation, and refusal fences;
- custody trail continuity;
- retention charter authority and review gates;
- disposition receipt method/evidence strength; and
- local policy deciding whether historical material can support current review, dispute, learning, or action.

## Specimen pressure that should come next

An auditor asks SlopOS to keep the evidence behind a quarantine recommendation for seven years, while a partner requests erasure of one underlying identity fragment and a reviewer forwards the signed chart to an outside counsel. The answer path should not be: keep everything forever or delete everything immediately. It should be: attach a retention charter, record a custody trail, reduce or fence sensitive material where allowed, emit disposition receipts for removals/transfers/seals, and keep any old export weaker than current rehydration and action-warrant checks.
