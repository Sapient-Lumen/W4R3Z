# Research synthesis — pass XCIV: reuse gates, consequence binding, and schema registry audit

## Question

Rev0093 made receiver convergence explicit, but convergence was still only monitoring evidence. Pass XCIV asks what must happen when a downstream surface wants to reuse a converged receiver observation for a concrete display, review, release, repair, remedy, action, or learning-loop purpose.

## External pressure

- `EXT-AUTHZEN-AUTHORIZATION-API-2025` keeps evaluation requests bound to subject, action, resource, context, and a PDP/PEP split. Ward borrows the request/decision split but refuses to become a general authorization server.
- `EXT-OASIS-XACML-3-0-2013` keeps Permit, Deny, NotApplicable, and Indeterminate visibly different. Ward uses that pressure to distinguish allowed display, held-for-receipt, refused high-consequence reuse, and quarantine holds.
- `EXT-OPENFGA-CONTEXTUAL-TUPLES-2026` keeps request-local context local to a check. Ward treats receiver convergence as request-local basis evidence, not as reusable ambient authority.
- `EXT-NIST-SP-800-53-REV5` continues to pressure least-privilege and information-flow controls; a low-risk status display should not imply evidence export, repair authority, or action permission.

## Result

Pass XCIV adds a governance reuse-gate receipt downstream of receiver convergence. It binds one reuse request to one source convergence receipt, one purpose, one consequence class, one requested effect, one projection policy, and one consequence-scope digest.

The gate can produce only narrow states:

- `display_reuse_allowed_refresh_required`
- `internal_review_reuse_allowed`
- `evidence_release_required_hold`
- `high_consequence_refused`
- `receiver_gap_quarantine_hold`
- `invalid_reuse_rejected`

The receipt is deliberately not authority. It records whether the requested reuse is display/review-safe, held for another receipt, or refused. Export still needs an evidence-release receipt. Repair, remedy, delegation, budget spend, learning use, and action still need fresh packet replay and the appropriate upstream authority packet.

## Speculation

The next durable family may be a **consequence-use ticket** that crosses from Ward into Helm, Harbor, or SlopOS, but only if the reuse gate survives more mixed receiver and projection cases. For now, reuse-gate receipts should stay inside Ward as refusal harnesses.
