# Research synthesis — pass XXXIX

This pass adds one more design-pressure seam without freezing Ward into a specific queue, table, controller, ledger, or object-store shape: **logically deleted**, **hidden from the current view**, **physically reclaimed**, and **impossible to resurrect** are different truths.

## What the outside systems say
1. **Cassandra treats deletion as replicated state, not immediate disappearance.**  
   Cassandra treats a deletion as an insertion of a time-stamped tombstone, keeps that tombstone through a grace period, and lets queries ignore older values while the tombstone survives. The same docs warn that if a replica misses the tombstone and stays down beyond the grace period, the old value can come back as a “zombie.” Ward should steal the humility: a current negative answer may still depend on repair coverage and marker retention.

2. **A compacted current view needs enough delete-marker retention to rebuild safely.**  
   Kafka’s compacted-log settings make this explicit: tombstone retention is not just storage trivia, it bounds how long a reader beginning from offset zero has to finish if it wants a valid final snapshot. Ward should steal that lesson too. A delete marker has a reader-horizon story, not just a write story.

3. **Current-view deletion can coexist with fully retained older versions.**  
   Amazon S3 versioning makes the distinction extremely concrete. A simple `DELETE` creates a delete marker that makes the object behave as deleted for ordinary reads, but the older versions remain. Removing the delete marker can revive the older version as current again. Ward should steal the separation: hidden-from-default-view is weaker than physically gone.

4. **Retention and physical reclamation deserve their own lane.**  
   Iceberg says snapshots accumulate until expiration removes them from metadata, and data files are not deleted until they are no longer referenced by a snapshot that could still serve time travel or rollback. It separately documents metadata cleanup and orphan-file deletion with retention warnings. Ward should steal that discipline: reclamation policy is not the same thing as logical retirement, and “safe to GC” is a separate truth worth preserving.

## Resulting Ward move
Do **not** decide yet whether Ward should literally adopt tombstones, versioned delete markers, lifecycle policies, retention jobs, or replica-repair ledgers.

For now, preserve four separations and let later specimens force promotion:
- `delete marker` versus simple absence;
- `repair floor` versus overconfident current-view deletion;
- `resurrection alarm` versus fake certainty that old state cannot return;
- `reclamation horizon` versus logical retirement or current invisibility.

Keep nearby, but not yet promoted, a few smaller ideas:
- `hidden-not-destroyed` for “ordinary reads say gone while older bytes still exist”;
- `undelete path` for deliberate reversal of a marker-backed delete;
- `marker retention budget` for how long one negative marker must survive so lagging readers can rebuild safely; and
- `repair-before-purge` as a standing anti-regrowth rule.

## Fresh ideas worth stealing
- **delete marker** — explicit current-view negative residue smaller than physical destruction.
- **repair floor** — minimum propagation/repair confidence required before a negative marker earns stronger local trust.
- **resurrection alarm** — explicit warning that stale replicas, lagging rebuilds, or old retained versions may still reintroduce the thing that looked gone.
- **reclamation horizon** — point after which old bytes, old metadata, or negative markers may be physically removed.
- **hidden-not-destroyed** — a standing anti-regrowth rule.
