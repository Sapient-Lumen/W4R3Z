# SlopOS and companion evaluation — pass LXXVI

Pass LXXVI evaluates Ward's SlopOS datacube posture after adding contest packets, adjudication dockets, and remedy receipts. The target is not legal automation. The target is a durable distinction between **an answer that was generated**, **an answer that was challenged**, **a challenge that was reviewed**, **a remedy that was attempted**, and **current authority for future use**.

## SlopOS fit

The included SlopOS snapshot already contains nearby pressure that makes contestability especially important:

- **CH-AREF** digest discipline is valuable for pointing a contest packet at exact answer/export/evidence material, but digest identity must not make the answer unchallengeable.
- **Artifact-resolution posture** keeps locator dereference explicit. A contest packet may reference bundles, exports, sidecars, or replay material, but review should not ambiently fetch stale or unauthorized fragments.
- **CH-ACPOUT** and ACP-adjacent surfaces are non-authority by default. A remedy receipt for an action proposal should not become proof that a downstream action was authorized, completed, or recalled.
- **D-RR / D-NONDET / CH-DERIV** keep replay and derivative material narrow. Adjudication dockets should record replay class and nondeterminism limits rather than pretending review can reproduce every historical state.
- **D-QUAR** gives a natural high-consequence specimen: a quarantine recommendation may be disputed, upheld, softened, withdrawn, or left historically explainable while current action requires fresh authority.
- **D-LLM / D-POWERBOX / tool-call seams** matter because model-mediated summaries and agent-proposed remedies are tempting to treat as review outcomes. They should remain evidence or drafts until an adjudication docket and remedy receipt say otherwise.
- **Archive policy** already prefers cite-rather-than-copy. Contest packets should name evidence and missing evidence without forcing raw-row hoarding or expanding projection beyond the challenged issue.

## Companion pressure

- **Harbor** should care about appeal/dispute timing and temporal authority: complaint intake time, decision time, effective remedy time, and downstream notice time are different cuts.
- **Foundry** should care about derivation and build material: a contested answer may require source recipe, model/metric version, query contract, and build/run witness without making Foundry the tribunal.
- **Steward** should care about policy/ownership: standing, reviewer authority, independence, conflicts, and remedy permission are governance facts.
- **Schell** should care about semantic bases: a dispute may be about concept mapping, hierarchy membership, identity match, unit conversion, or label drift rather than raw facts.
- **ViewFS** should care about view/export persistence: old dashboards, screenshots, CSVs, notebooks, and foldered evidence need dispute/remedy markers without implying global recall.
- **Helm** should care about review UI: reviewers need compact contest/adjudication/remedy surfaces, not an undifferentiated pile of logs, prompts, charts, and policy snippets.

## Residue boundaries

Promote **contest packet**, **adjudication docket**, and **remedy receipt** as candidate datacube residues only. They improve Ward because they let SlopOS-facing cube answers be challenged and corrected without collapsing challenge intake into proof, review into truth, or remedy into total downstream recall.

They must remain separate from:

- answer capsule, scope lens, state-cut witness, metric/query contract, and semantic residues;
- verification bundle, replay recipe, attestation envelope, custody trail, retention charter, and disposition receipt;
- action warrant, consequence receipt, correction horizon, backfill ledger, and revocation fence;
- learning loop ledger, feedback taint fence, scenario capsule, synthetic boundary, intent binding, translation warrant, and tool-call leash.

## What this pass rejects

- No global appeal workflow, tribunal, case-management product, service-level deadline, or regulator process is chosen.
- No assumption that every dispute suspends every related answer, dashboard, action, or export.
- No assumption that a denied dispute erases disagreement evidence.
- No assumption that a successful remedy reaches all prior recipients, caches, learning labels, model summaries, or partner copies.
- No assumption that an AI or LLM-written explanation is sufficient adjudication.

## Current promotion posture

Before a SlopOS-facing datacube contest can be considered healthy:

- the contest packet must identify challenger/standing posture, challenged subject, grounds, requested remedy, submitted and missing evidence, admissibility/refusal posture, privacy/projection limits, and interim effect;
- the adjudication docket must name reviewer lane, independence/expertise/conflict posture, evidence admitted/excluded, issue framing, standards applied, timeline, outcome, and unresolved questions;
- the remedy receipt must name affected cells/artifacts/consequences, outcome class, downstream reach, notices, residual gaps, rollback/fence/learning impacts, and currentness limits;
- old exports, verification bundles, retained artifacts, and model summaries must be marked or fenced when the remedy cannot reach them;
- future action must rehydrate current authority rather than reuse either the original answer or the remedy receipt as permission.
