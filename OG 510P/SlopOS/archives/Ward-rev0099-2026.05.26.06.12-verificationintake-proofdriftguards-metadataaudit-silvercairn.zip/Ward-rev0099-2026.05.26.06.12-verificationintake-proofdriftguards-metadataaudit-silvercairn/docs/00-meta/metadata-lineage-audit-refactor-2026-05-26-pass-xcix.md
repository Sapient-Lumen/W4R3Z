# Metadata lineage audit/refactor — pass XCIX

Rev0099 adds `tools/check_metadata_lineage_integrity.py`.

## Problem

Ward's semantic checker suite is now strong, but the cube's self-description can still drift across revision receipt, surface status, release manifest, top-level ledgers, context pack, README, and START_HERE. That is a maintainability failure: a future pass could be valid but hard to load or audit because the latest pointers disagree.

## Refactor

The new audit checks:

- top-level ledgers and context pack use the same revision as `REVISION-RECEIPT.json`;
- `SURFACE-STATUS.json`, `RELEASE-MANIFEST.json`, README, and START_HERE agree with the revision summary;
- latest research/evaluation/specimen docs in surface status are listed in revision hygiene additions;
- context pack carries the latest docs and latest outside source refs;
- living ledgers have unique ids.

## Boundary

This checker is metadata lineage hygiene only. It does not prove that any governance checker is semantically complete, and it does not replace repo hygiene, doc index, fixture catalog, schema catalog, tool runbook, registry, or governance receipt validators.
