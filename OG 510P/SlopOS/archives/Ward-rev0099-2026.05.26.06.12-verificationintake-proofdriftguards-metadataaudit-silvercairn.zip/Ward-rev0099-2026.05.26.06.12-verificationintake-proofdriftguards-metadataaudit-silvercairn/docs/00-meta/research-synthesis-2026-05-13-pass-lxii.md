# Research synthesis — pass LXII

This pass goes deeper on the SlopOS-shaped datacube question by treating **comparison itself as a trust-bearing answer**. Pass LXI made scope, mutable cuts, and refusal material first-class. Pass LXII asks what happens when a human, agent, dashboard, or promotion gate tries to compare two answer capsules across changed policy, changed schema, changed metric logic, changed source contracts, changed validation results, or changed SlopOS view authority.

The restraint rule remains unchanged: Ward should not choose a global compatibility calculus, model registry, data-contract product, quality framework, lakehouse format, or dashboard semantics while SlopOS is still in design. The healthy move is to add small residues that let future answers say: these two outputs are comparable, comparable only through a named bridge, not comparable, or not yet tested.

## What the past says we must learn now

1. **Same title is not stable meaning.** dbt's model-versioning docs frame versioning as an API-stability problem: producers need to change logic and structure, while consumers need warning and stability (`EXT-DBT-MODEL-VERSIONS-2026`). Ward should steal the lesson but keep it smaller: a recurring answer needs a comparability residue before a trend line can treat old and new points as the same question.

2. **Shape contracts and content quality are different evidence.** dbt model contracts define the shape of a returned dataset and can fail builds when logic or input data do not conform; dbt explicitly distinguishes those contracts from data tests, which validate content after the model is built and may have thresholds or stored failing records (`EXT-DBT-MODEL-CONTRACTS-2026`). Ward should not let a schema-compatible answer claim quality-compatible truth.

3. **A data contract is wider than columns.** ODCS v3.1.0 organizes a data contract across fundamentals, schema, references, data quality, support, pricing, team, roles, SLA, infrastructure, and custom sections (`EXT-ODCS-3-1-2026`). Ward should steal the breadth without importing the whole standard: a promoted datacube answer may need a tiny quality/contract witness, not just a schema digest.

4. **Evolution can be safe without being invisible.** Iceberg supports schema, partition, and sort-order evolution without rewriting table data, and its correctness posture relies on independent changes and stable field identity rather than column-position folklore (`EXT-ICEBERG-EVOLUTION-2026`). Ward should treat that as an anti-lesson against overclaiming: even safe evolution deserves a drift notice when comparison or replay depends on it.

5. **Historical dimensions should not be overwritten into amnesia.** Kimball Type 2 slowly changing dimensions add new rows, surrogate keys, effective dates, expiration dates, and current-row indicators when a dimension member changes (`EXT-KIMBALL-TYPE2-SCD-2008`). Ward should steal the temporal humility: a current credential family label, partner class, or appraisal lane must not silently relabel old facts unless a bridge says it did.

6. **Validation results are answer material, not backstage logs.** Great Expectations checkpoints run validation definitions and then trigger actions based on Validation Results; actions can update Data Docs or notify on severity, and result format can preserve more or less detail (`EXT-GX-CHECKPOINT-ACTIONS-2026`). Ward should keep a compact quality witness beside promoted answers whenever validation gates shaped whether the answer can influence trust.

7. **Facets beat monoliths during design.** OpenLineage facets are atomic metadata pieces attached to jobs, runs, and datasets, with custom facets using distinct prefixes and immutable schema URLs (`EXT-OPENLINEAGE-FACETS-2026`). Ward should steal the extension posture: comparability, drift, and quality can begin as small facets/residues rather than forcing a universal lineage or contract ontology.

8. **The old OLAP failure is flattering continuity.** Dashboards, data marts, semantic layers, and LLM-assisted analysis all make a smoothed comparison look authoritative. SlopOS's view-scoped, snapshot-first, handle-returning posture makes this more important, not less: comparing two answers can leak hidden population drift or import stale trust when the chart hides scope, quality, and semantic drift.

## Resulting Ward move

Do **not** decide yet:

- one universal semantic-versioning rule for answer families;
- one compatibility lattice for every metric, axis, contract, policy, or view change;
- one data-contract standard or quality framework;
- one schema registry, table format, lineage stack, or model registry;
- one bridge language for restating old answers under new semantics;
- one rule for whether quality failures with warnings still permit local trust consequence;
- one UI grammar for showing incomparable points, bridged points, or restated history.

Do add three small, reversible residues for comparisons:

- **comparability passport** — compact residue on a proposed comparison, series, trend, cohort contrast, or before/after chart saying whether the compared answer capsules are `same_contract`, `bridge_required`, `bridged`, `incomparable`, or `not_tested`, and which equality checks passed or failed. It is smaller than a proof of semantic equivalence.
- **drift notice** — compact residue naming what changed between answer cuts: scope, axis, metric formula, schema field identity, policy epoch, quality suite, materialization generation, privacy profile, calendar/unit binding, or source contract. It is smaller than a migration plan and stronger than a changelog footnote.
- **quality witness** — compact validation/contract residue naming the suite or contract subset checked, its version, run/cut, pass/fail/severity posture, coverage, tolerated failures, and affected cells/cohorts. It is smaller than a data quality platform and weaker than local trust consequence.

These residues sit above earlier Ward datacube residue rather than replacing it. A comparability passport consumes scope lenses, state cut witnesses, axis capsules, metric/query cards, unit/calendar/privacy/resolution residues, lineage facets, refusal receipts, and quality witnesses. It does not make those residues obsolete.

## Brilliant ideas to steal now

- **Comparison as its own query** — do not render a trend until the comparison has passed an explicit compatibility check.
- **Bridge-required status** — there is a middle state between comparable and impossible: a bridge can restate, map, or rebaseline, but the chart must say so.
- **Quality gates in the capsule** — validation results should travel with the answer they qualified, not live only in build logs.
- **Type-2 humility for dimensions** — current labels can change while old facts stay historically anchored.
- **Safe evolution with visible drift** — schema/partition evolution can be operationally safe and still comparison-relevant.
- **Facet-shaped growth** — start with tiny custom residues before deciding whether Ward needs a formal contract registry or lineage ontology.
- **Incomparability as a safe output** — a refused comparison can be the correct answer when scope, quality, policy, or semantic drift is unbridged.

## Still-not-yet decisions

- Whether comparability passports attach to whole answer capsules, individual measures, cells, series segments, or all of those.
- Whether a drift notice should be emitted by the query planner, materialization process, lineage collector, promotion gate, or human review.
- Whether quality witnesses are mandatory only at promotion boundaries or on every SlopOS datacube answer.
- Whether bridges should be executable restatement recipes, human-reviewed notes, or pointers to companion-cube receipts.
- Whether Helm should hide, gray, annotate, split, or refuse charts when some segments are incomparable.
- Whether SlopOS should expose a native comparison primitive or require Ward/Helm to compare answer capsules outside the query engine.

## Process note

Pass LXII does not add a compatibility engine. It adds pressure-tested language for the moment a datacube answer becomes a comparison. The next healthy move is to run these residues against a SlopOS trust-deterioration chart where one partner population, one metric contract, and one data-quality gate changed between epochs. If the chart cannot carry comparability, drift, and quality residue, Ward should refuse the comparison instead of polishing it.
