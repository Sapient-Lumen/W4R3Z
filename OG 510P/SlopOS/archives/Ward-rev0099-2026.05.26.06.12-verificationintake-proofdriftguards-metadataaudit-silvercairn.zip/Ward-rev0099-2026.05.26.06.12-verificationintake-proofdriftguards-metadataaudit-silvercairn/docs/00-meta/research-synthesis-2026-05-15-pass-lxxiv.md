# Research synthesis — pass LXXIV

Pass LXXIII fenced natural-language questions, generated SQL, semantic-layer calls, and model-controlled tools. Pass LXXIV follows the next handoff: after a cube answer exists, people will want to **verify**, **replay**, **archive**, **sign**, **share**, **audit**, and **dispute** it. That desire is healthy, but it contains a familiar trap. A well-packaged evidence artifact can start to look like the current answer; a signed claim can start to look like truth; a replay recipe can start to look deterministic even when source cuts, policies, privacy budgets, model versions, and external dependencies moved.

The new posture: Ward should let SlopOS package enough material to re-check an answer without making the package an engine, a warehouse, a global notebook format, a new trust root, or a portable authorization token. Verification is a structured **challenge to an answer**, not a resurrection of authority.

## What the past says we must learn now

1. **Provenance helps consumers verify expectations; it is not the same thing as correctness.** SLSA provenance describes how artifacts were produced so consumers can verify they were built according to expectations and so others can rebuild if desired; the model treats provenance as an attestation that a build platform produced artifacts by executing a build definition (`EXT-SLSA-PROVENANCE-V1`). Ward should steal the shape, not the domain. A SlopOS answer can expose how it was produced, but the consumer still needs an appraisal policy and current authority cuts.

2. **Steps, materials, commands, products, and byproducts belong in the record.** The in-toto link attestation model records one supply-chain step: subject/products, materials/inputs, step name, optional command, environment, and byproducts (`EXT-IN-TOTO-LINK-ATTESTATION-2026`; broader verification-recipe pressure also appears in `EXT-IN-TOTO-GETTING-STARTED`). For Ward, this says a cube replay should capture query material, state cuts, metric cards, policy gates, validation byproducts, refusal/degradation receipts, and render/export byproducts as different materials, not as one vague “dashboard was generated.”

3. **Transparency logs give inclusion and consistency, not semantic truth.** Rekor is built on a verifiable data structure; auditors can monitor consistency so entries remain append-only, and verifiers can monitor identities (`EXT-REKOR-OVERVIEW`). That is a useful anti-tamper pattern for attestation envelopes or exported-answer receipts, but a log entry cannot prove a cube result is fresh, comparable, policy-allowed, or semantically correct.

4. **Machine-verifiable credentials separate issuer, holder, verifier, proof, and claim.** W3C Verifiable Credentials 2.0 provides a model for cryptographically secure, privacy-respecting, machine-verifiable credentials (`EXT-VC-DATA-MODEL-2-0`), and Data Integrity work describes cryptographic mechanisms for authenticity and integrity of verifiable credentials or similar constrained documents (`EXT-VC-DATA-INTEGRITY`; `EXT-W3C-VC-DATA-INTEGRITY-1-1-2026`). Ward should borrow the split between claim, proof, issuer, presentation, and verifier appraisal; it should not turn cube answers into universal credentials by default.

5. **Research packaging is not just zip files; metadata matters.** RO-Crate describes a research object using JSON-LD metadata and distinguishes the crate dataset, data entities, and contextual entities that provide provenance (`EXT-ROCRATE-1-2-2025`). Ward should steal the idea of a small, readable, linked evidence package, but keep SlopOS-specific authority/refusal/privacy semantics outside any generic research-object packaging rule.

6. **Reproducibility is hard because environments and dependencies are hidden.** ReproZip automatically traces system calls to identify files that should be included, then packages experiments for reproduction across chroot, VM, Docker, or plugin unpackers; its motivation explicitly calls out hidden OS configuration and dependency hell (`EXT-REPROZIP-ABOUT-2026`). SlopOS cube replay has the same danger: even when SQL text and inputs are known, hidden environment, extension versions, nondeterminism, data-retention windows, and privacy budget state can break replay.

7. **Pinned dependency locks are useful but not magic.** Nix's flake lock command records locks for flake inputs, and supports updating them separately from a build (`EXT-NIX-FLAKE-LOCK-2026`). Ward should steal the “lock inputs separately from running the computation” instinct. It should not require Nix, nor claim that dependency locks freeze source data, policy cuts, privacy state, or remote partner answers.

8. **Reproducible-build culture teaches reproducibility versus repeatability versus validity.** Rebuilding the same bytes, replaying the same query, and reaching the same governance verdict are three different success classes. For datacubes, Ward needs replay classes: byte-identical replay, value-identical replay, tolerance-identical replay, verdict-identical replay, explanation-identical replay, and non-replayable/retired.

9. **Disputes need bounded packets.** If a reviewer disputes an alert derived from a cube answer, Ward should not require live access to every source system or raw row. It should package: answer capsule digest, state-cut witness, metric/query contracts, projection curtain, quality/freshness/uncertainty envelopes, tool-call leashes, render/egress receipts, action/consequence receipts, and a replay recipe. That packet may support audit without granting authority to rerun everything.

10. **Privacy and revocation do not disappear because verification wants detail.** A verification bundle can be exact, redacted, sampled, noisy, salted, thresholded, or digest-only. It must carry projection and revocation fences, not weaken them. Exporting proof material can create a new egress artifact.

## Resulting Ward move

Do **not** decide yet:

- one proof format, signature suite, credential format, attestation framework, transparency log, notebook format, container format, data-package format, dependency manager, or replay runtime;
- one rule that every answer must be signed, every bundle logged, every replay deterministic, or every exported result fully reproducible;
- one global hash algorithm, canonicalization format, provenance vocabulary, key management system, witness network, or retention period;
- one debug bundle shape that always includes raw rows, SQL, model prompts, schema samples, partner fragments, or full validation results;
- one product UI for disputes, audits, regenerated answers, or signed exports.

Do add three small, reversible residues:

- **verification bundle** — a compact, portable, possibly redacted packet of answer-adjacent evidence for review, challenge, audit, rehydration, or dispute. It references answer capsules, state cuts, metric/query/semantic cards, source cuts, quality/freshness/uncertainty/refusal material, privacy/projection boundaries, render/export/action/learning/scenario/model-mediated residues, and known missing pieces. It is an evidence packet, not a live capability or a claim of current authority.
- **replay recipe** — a compact recipe for rerunning, recomputing, or checking an answer under a named replay class. It records inputs, locked dependencies, query/plan digest, environment posture, nondeterminism handling, allowed tolerances, expected invariants, privacy/projection substitutions, budget requirements, and invalidation/revocation behavior. It can say “not replayable” without embarrassment.
- **attestation envelope** — a compact signed/logged/endorsed claim wrapper around a bundle, recipe, answer capsule, run, export, or verification result. It records issuer, subject digest, predicate/profile, proof/log/inclusion posture, verifier policy hints, expiry/revocation links, privacy disclosure posture, and non-authority limits. It does not make the underlying answer true.

## Why these names and not stronger machinery

- “Verification bundle” keeps evidence near the answer without deciding between RO-Crate, ZIP, OCI artifact, BagIt, W3C VC presentation, signed JSON, or SlopOS CH-AREF graph.
- “Replay recipe” says rerun/check semantics are separate from evidence packaging. A bundle can be reviewable without being replayable; a replay can be verdict-identical without being byte-identical.
- “Attestation envelope” keeps cryptographic/logged claims around answers distinct from answer authority, currentness, and policy permission.

## Hygiene rule for SlopOS

A SlopOS datacube answer may be easier to trust when it ships with verification material, but it is never stronger than the weakest of:

- scope lens and state-cut witness;
- query/metric/semantic contracts;
- quality/freshness/uncertainty/refusal material;
- privacy/projection/revocation fences;
- replay recipe class and current retained inputs;
- attestation envelope issuer/log/proof validity; and
- local verifier/appraisal policy.

The package must never become a portable permission slip, a replay attack, or a way to bypass current redaction.

## Specimen pressure that should come next

A reviewer receives a signed exported chart and asks, “prove this quarantine recommendation was justified.” The answer path should not be: trust the signature. It should be: verify the attestation envelope, inspect the verification bundle, run or decline the replay recipe, compare the replay class against the action warrant and consequence receipt, check current revocation fences, and clearly say whether the historical answer was justified under its cut, whether it remains current, and whether any downstream consequence still stands.
