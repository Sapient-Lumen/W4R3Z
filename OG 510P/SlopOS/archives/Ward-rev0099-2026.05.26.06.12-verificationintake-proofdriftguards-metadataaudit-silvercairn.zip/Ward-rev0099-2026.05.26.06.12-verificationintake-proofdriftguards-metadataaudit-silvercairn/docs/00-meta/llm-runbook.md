# LLM runbook

- Re-read charter, trajectory, roadmap, and current architecture docs before making changes.
- Strengthen distinctions first.
- Avoid silently importing sibling or outside terminology as settled product truth.
- Update ledgers when a change alters assumptions, open questions, or outside pressure.
- Re-check the load-bearing source register before promoting new durable nouns or leaning on moving external specs.
- If a load-bearing outside source changes the design pressure, update the source register, bibliography, and the relevant synthesis/specimen surfaces in the same revision.
- Keep the specimen-flow index current once the specimen family has earned one.
