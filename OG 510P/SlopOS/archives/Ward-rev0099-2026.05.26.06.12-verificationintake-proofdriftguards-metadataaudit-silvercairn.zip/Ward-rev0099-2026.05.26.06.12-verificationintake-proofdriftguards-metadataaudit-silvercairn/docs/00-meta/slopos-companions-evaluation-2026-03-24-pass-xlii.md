# SlopOS / companions evaluation — pass XLII

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology: **explicit bases, bounded projections, and derivative honesty are healthier than one prematurely canonical datacube.**

## What the included cubes keep teaching
- **SlopOS** still points in the best direction for Ward's datacube posture, even while SlopOS itself remains design-phase. The recurring lesson is not “build a giant control-plane warehouse.” The recurring lesson is “keep projections bounded, explicit, and weaker than source authority.” Ward should steal that discipline directly.
- **Helm** usefully pressures the derivative side of the problem. Saved views, decks, and materialization bays are good ideas when they remain visibly derivative. Ward should steal the promotion move, not the temptation to let presentation/layout become constitution.
- **ViewFS** keeps reminding the archive that basis/readability/retention are separate truths. That is healthy pressure for any Ward datacube worth building.
- **Steward**, **Harbor**, and **Foundry** reinforce a similar operational point: asynchronous observation, callbacks, previews, and foreign-ground measurements often produce valuable derivative truth, but they do not automatically become the authoritative layer for consequence.

## Recommended datacube posture for Ward right now
Freeze only a few laws and leave the rest open:
1. **Every nontrivial exploration should be able to name or pin its basis.**
2. **High-cardinality trust facts should stay explorable before Ward freezes one dashboard grammar.**
3. **Promoted maintained derivatives must carry owner, freshness posture, and lineage.**
4. **Promoted derivatives stay weaker than evidence, appraisal recipe, and spendable consequence.**

## Specific anti-lessons from the past
- Do **not** start by choosing the final star schema and then trying to force every trust question through it.
- Do **not** let “current dashboard answer” erase basis, retention, ambiguity, or replay differences.
- Do **not** confuse a maintained derivative with source truth just because it is fast and useful.
- Do **not** make one dashboard/deck layout the datacube's constitution.
- Do **not** build pre-aggregation or hidden acceleration paths before repeated workload evidence says where they pay off.

## What Ward should probably steal next
- a **basis-pinned saved exploration** surface;
- a **contrast-first exploration** path over rich fact/event shapes;
- an explicit **promotion bay** for graduating saved views into maintained derivatives;
- lightweight **lineage + freshness + owner** headers on promoted derivatives;
- repo hygiene that keeps these moves honest before the cube's object model hardens.

## Hygiene/process consequence
The small but real process steal for this revision is:
- keep the latest research/evaluation/specimen surfaces wired through the front door;
- keep bibliography/load-bearing/review surfaces current when new outside ideas become important enough to shape nouns;
- and make the hygiene script catch bibliography-ghost references if the newest pass docs start citing external refs that the bibliography does not actually register.

## Still-not-yet decisions
- engine choice;
- storage/index strategy;
- one canonical metric layer;
- one canonical dashboard/deck layer;
- one global promotion policy for all derived trust surfaces.
