# SlopOS / companions evaluation — pass LIV

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **quick sampled answers are useful, but their subset semantics must stay visible.**

## What the included cubes keep teaching
- **SlopOS** remains the strongest nearby teacher because D-ATTRFS keeps query meaning scoped and modest: query mode runs against an explicit authorized view, result entries are handles already reachable through that view, querying stays snapshot-first, and saved queries remain shell-owned manifests. Ward should steal the next lesson in the same spirit: if SlopOS later offers a “fast preview” or “cheap approximate browse” mode for recurring questions, the sample choice should live in the manifest/result contract rather than in one ambient “fast mode” toggle.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: query manifest, snapshot result, live feed, and materialized local collection are distinct. The datacube analogue is that exact frozen result, sampled preview, and maintained derivative should also remain distinct, especially when they can share a title.
- **Helm** keeps pressuring UI honesty. If a shell shows “top slow verification cohorts” or “most common narrowings” from a sample-backed preview, the header should be able to say basis pin + exactness class + sample witness + selection stage + repeatability lane without forcing a giant semantic layer.
- **Steward** keeps teaching that local consequence is narrower than remote operation folklore. The datacube analogue is that a sampled preview can help humans browse and compare, but should stay weaker than any replayable or spend-grade consequence-bearing truth surface.

## What outside systems add to the datacube posture
- BigQuery adds the first discipline: `TABLESAMPLE SYSTEM` is block-based, results can differ across runs, partitioning/clustering can bias the sample, and combining block sampling with `rand()` is a legitimate cost/quality trade. Ward should steal that as **sample witness** honesty, not as a commitment to BigQuery (`EXT-BIGQUERY-TABLESAMPLE-2026`).
- DuckDB adds the second discipline: sampling family matters, seeding has execution caveats, and `TABLESAMPLE` versus `USING SAMPLE` changes whether sampling happens before or after a join. Ward should steal that as **selection stage** and **repeatability lane** honesty, not as a commitment to DuckDB (`EXT-DUCKDB-SAMPLES-2026`).
- ClickHouse adds the third discipline: deterministic sampling keys can keep related tables on the same subset, while sampled totals may need explicit correction factors. Ward should steal that as **key-stable sample** plus visible extrapolation/correction posture, not as a commitment to ClickHouse (`EXT-CLICKHOUSE-SAMPLE-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Any recurring sampled preview should declare a sample witness before it borrows the title of an exact recurring question.**
2. **Any recurring sampled preview should declare its selection stage so pre-join and post-join samples cannot impersonate one another.**
3. **Any recurring sampled preview should declare a repeatability lane so deterministic-key samples, fixed-seed samples, and probabilistic reruns stay visibly different.**
4. **If a sampled result is extrapolated, scaled, or corrected, that correction rule should travel with the sample witness instead of hiding in dashboard code or folklore.**
5. **Ward should not bless one universal sample family, one mandatory seed policy, or one sample-to-exact promotion ladder while SlopOS and its siblings are still discovering their own query/result/materialization seams.**

## Specific anti-lessons from the past
- Do **not** let “preview” imply a stable subset if the engine can pick different rows each run.
- Do **not** let block sampling masquerade as row-level randomness.
- Do **not** let sample-before-join and sample-after-join share a title without residue.
- Do **not** let corrected/extrapolated counts pose as raw observed counts.
- Do **not** choose one cube-wide sampling constitution just because a few recurring browse questions want faster answers.

## What Ward should probably steal next
- a **sample witness** attached to any recurring sampled preview that starts influencing decisions;
- a **selection stage** that can say where in the plan the sample was taken;
- a **repeatability lane** that can say whether reruns are deterministic, seeded-but-conditional, or non-repeatable;
- the **key-stable sample** trick when one sampled preview must preserve comparable subsets across joined or paired tables;
- front-door/hygiene wiring that refuses to let new sampling teachers drift out of the bibliography, source register, queue, front door, or manifest.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new sampling sources now directly shaping datacube posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- refresh the ledgers/context surfaces so sample-backed preview semantics show up in the open-question and pressure queues;
- tighten the hygiene checker so revision receipts cannot silently accumulate duplicate outside-source refs while these fast-preview research passes pile up.

## Still-not-yet decisions
- engine choice;
- one universal preview/exploration service for all companion cubes;
- one mandatory extrapolation policy for sampled counts and totals;
- one seed/determinism policy for all repeated questions;
- whether sampled previews should ever graduate directly into maintained derivatives without an exact frozen comparison rail.
