# Research synthesis — pass XLVI

This pass keeps Ward decision-light and adds another datacube discipline: **approximation should be explicit, inspectable, and visibly weaker than replayable exact truth**.

## What the past says we must learn
1. **Approximate results are a different truth class from exact replay.**  
   BigQuery's approximate aggregate functions are explicit that they produce approximate results instead of exact ones, introduce statistical uncertainty, and are appropriate when exact linear-memory aggregation is impractical. The same docs also separate those built-ins from sketch-specific functions where users can choose precision. Ward should steal the separation, not the product shape: an approximate answer should declare an **exactness class** instead of borrowing the social authority of exact replay (`EXT-BIGQUERY-APPROX-AGG-2026`).

2. **Algorithm family materially shapes meaning.**  
   DuckDB does something healthy by naming the actual estimator family used by each approximate aggregate: HyperLogLog for approximate distinct counts, T-Digest for approximate quantiles, Filtered Space-Saving for approximate top-k, and reservoir sampling for a sampling-based quantile. Ward should steal that honesty. A fast approximate trust surface should carry an **estimator card** naming the family, what it estimates, and which trade it bought (`EXT-DUCKDB-APPROX-AGG-2026`).

3. **Mergeable sketch state is not just a pretty number.**  
   Druid's DataSketches extension describes sketches as approximate streaming mergeable algorithms that can be stored as additive metrics, and Apache DataSketches emphasizes that Theta set operators return sketches as a result rather than only a number. Ward should therefore keep an optional **sketch witness** lane visible when an approximate derivative is powered by mergeable sketch state instead of only a final rendered estimate (`EXT-DRUID-DATASKETCHES-2026`, `EXT-DATASKETCHES-THETA-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward's future approximations use one built-in estimator family, one sketches library, one precision policy, or one binary witness format.

For now, keep three more separations visible and let later specimens force promotion:
- **exactness class** — visible statement that one answer is exact replay, exact derived, approximate/sketch-backed, or otherwise weaker than exact replay.
- **estimator card** — compact explanation of estimator family, mergeability, tunables/precision posture, and known caveats for one approximate surface.
- **sketch witness** — optional durable residue that the approximate surface was backed by mergeable sketch state rather than only an opaque number.

## Why these separations are worth stealing
- An `exactness class` stops approximate answers from quietly inheriting the authority of exact replayable truth.
- An `estimator card` keeps algorithm swaps, precision shifts, and family differences visible instead of folklore.
- A `sketch witness` preserves the difference between “I rendered one approximate number” and “I hold mergeable approximate state that can support later unions, intersections, or refreshed estimates.”

## Brilliant ideas to steal now
- **exactness class** — visible truth label for exact replay versus approximate or weaker classes.
- **estimator card** — family/mergeability/precision/caveat surface for one approximate answer family.
- **sketch witness** — optional durable residue for mergeable sketch-backed state.
- **algorithm-name honesty** — standing process rule: do not hide HLL/KLL/theta/t-digest style differences behind one vague metric label.
- **approximate-not-replayable** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward ever standardizes one universal exactness-class taxonomy or keeps only a smaller result-local label set.
- Whether `estimator card` is purely human-facing or later grows a typed archive artifact form.
- Whether `sketch witness` should remain optional residue or become mandatory for some promoted derivative classes.
- Which sketch families, if any, are ever blessed for first-class use in Ward proper.
