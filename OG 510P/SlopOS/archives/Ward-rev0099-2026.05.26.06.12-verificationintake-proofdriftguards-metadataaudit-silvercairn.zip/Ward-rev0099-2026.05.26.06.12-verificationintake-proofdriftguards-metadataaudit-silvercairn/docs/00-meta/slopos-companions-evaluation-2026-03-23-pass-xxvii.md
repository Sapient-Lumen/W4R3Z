# SlopOS / companions evaluation — pass XXVII

This pass keeps Ward embryonic while stealing one more useful habit from the neighbors: **treat replay and ordering as small scoped seams, not as excuses to invent a universal control bus.**

## What the current cubes still teach
- **SlopOS** already freezes the healthy rule that the same request id means exact replay/dedupe of the same canonical request, not a mutable upsert under one old handle. Ward should steal the lighter principle: if a later-state delivery handle is reused, default to replay-fence semantics before inventing edit/replace meaning.
- **SlopOS** also keeps ordering tokens scope-bound and owner-minted instead of quietly standardizing a portable sequencer. Ward should learn the analogous move that an `apply cursor` or later-state ordering witness must stay receiver-local and view-local until multiple specimens prove more is needed.
- **Steward** already treats observation cursors as tiny continuity aids, not as a whole-world ordering algebra. Ward should steal that restraint for later-state application cursors and verification pings.
- **Harbor** remains a good reminder that transport success is weaker than durable local effect. Ward should keep event receipt, acknowledgement, application, and spend consequence similarly separate.

## Current recommendation
Keep Ward open on whether dedupe/apply state lives inline on local result objects, beside a watch/stream, or in a separate continuity sidecar.

The next wise move is one specimen plus one tiny hygiene upgrade:
1. **replay fence** instead of “we probably already handled that”,
2. **ordering window** instead of one fake total timeline,
3. **apply cursor** instead of conflating receipt with local incorporation,
4. **verification ping** instead of treating liveness checks as evidence delivery,
5. **latest-pass pointer drift check** instead of letting README entry surfaces quietly point at stale passes.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should still avoid building a portable sequencer, queue contract, or event-sourcing gospel into the repo.
The smaller steal is enough for now:
- keep `REVISION-RECEIPT.json` honest about which new research/evaluation/specimen surfaces landed this revision,
- make the hygiene checker verify that `README.md` actually points at those newest pass/specimen surfaces,
- and fail the revision if the front door of the archive drifts behind the current cut.

## Still-not-yet decisions
- Whether `replay fence` belongs in Ward proper or stays an imported event-lane residue.
- Whether `ordering window` should be first-class Ward vocabulary or remain explanatory text attached to result histories.
- Whether `apply cursor` belongs in Ward or in an adjacent observation/watch cube.
- Whether `verification ping` deserves durable vocabulary or remains a helper interaction on stream/watch surfaces.
- Whether delivery-identity handles should stay transport-local even when several transport families coexist.
