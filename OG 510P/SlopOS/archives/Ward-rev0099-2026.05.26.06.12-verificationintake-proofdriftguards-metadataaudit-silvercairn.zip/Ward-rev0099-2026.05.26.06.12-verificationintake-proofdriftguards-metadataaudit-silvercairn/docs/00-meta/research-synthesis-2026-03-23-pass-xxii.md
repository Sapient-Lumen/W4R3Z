# Research synthesis — pass XXII

This pass keeps Ward narrow and learns one more thing from mature update and transparency systems: **fresh-enough status, coherent-together status, and negative status are different truths, and clients should not synthesize a fake trustworthy present from fragments that never coexisted.**

## Outside lessons
1. **TUF separates freshness from coherence.**  
   The timestamp role tells clients what latest snapshot to trust, while the snapshot role tells clients which metadata versions belong together. Ward should steal the split: a "freshness witness" is not the same thing as a coherent status batch.

2. **TUF treats freeze, rollback, and fast-forward as their own failure classes.**  
   Expired metadata is a freeze alarm, older-than-trusted metadata is rollback suspicion, and impossibly advanced metadata can indicate fast-forward compromise. Ward should therefore avoid treating stale or incoherent status as just another revocation result.

3. **The current OAuth Token Status List draft makes historical checks explicit.**  
   A relying party can request a status list using a `time=<timestamp>` query, and it must reject the response unless the returned token was valid for that requested time. Ward should keep "historical time cut" pressure alive without yet deciding whether it belongs in Ward proper or in a smaller fetch layer.

4. **The current OAuth Token Status List draft also introduces an optional aggregation surface.**  
   An issuer can publish a list of one or more status-list URIs so relying parties can prefetch and cache relevant lanes for offline checking. Ward should steal the idea that discovery of relevant status lanes is a distinct truth surface, smaller than any one lane's status meaning.

5. **Certificate Transparency gives detectability and append-only consistency, not instant safety.**  
   CT logs provide inclusion and consistency proofs and signed tree heads, but they do not prevent misissuance. Ward should therefore treat publication history and consistency witnesses as accountability material, not as automatic local approval.

6. **Certificate Transparency also warns that freshness surfaces can become tracking surfaces.**  
   RFC 9162 says logs must not produce signed tree heads more frequently than declared, because a new STH per query could mark individual clients. Ward should remember that personalized or per-check freshness artifacts can quietly become correlation beacons.

## Resulting Ward move
Do not decide yet whether Ward needs durable first-class nouns for `status snapshot`, `freeze alarm`, `aggregation surface`, or `consistency witness`.

For now, preserve four separations and let specimens decide later:
- coherent-together status versus one-off fetched status;
- stale/frozen status posture versus negative status meaning;
- issuer-published aggregation/discovery versus one credential's status coordinate;
- append-only publication history versus current local spend/adopt consequence.

## Fresh ideas worth stealing
- **freshness witness** — small artifact that says what coherent status batch is current enough to trust.
- **coherent snapshot cut** — explicit statement that several status fragments belonged together at one time cut.
- **freeze alarm** — stale-or-unrefreshable posture that narrows consequence without pretending to say "revoked".
- **aggregation surface** — issuer-published discovery lane for multiple relevant status sources.
- **consistency witness** — append-only proof that a later publication extends an earlier one rather than rewriting it.
- **privacy-coarse freshness cadence** — refresh surfaces that avoid becoming per-client tracking beacons.
