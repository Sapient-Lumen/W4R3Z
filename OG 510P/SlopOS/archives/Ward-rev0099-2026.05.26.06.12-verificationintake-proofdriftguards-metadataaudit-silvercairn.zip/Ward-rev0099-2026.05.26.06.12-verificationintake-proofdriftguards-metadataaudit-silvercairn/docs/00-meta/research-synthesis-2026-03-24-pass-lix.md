# Research synthesis — pass LIX

This pass keeps Ward decision-light and adds another datacube discipline: **resolution and storage/materialization tier are part of meaning, and raw, downsampled, hybrid, or display-rollup answers should not masquerade as one timeless recurring truth.**

## What the past says we must learn
1. **Query resolution is part of the question, not harmless display dust.**  
   Prometheus range queries require a `step` parameter, explicitly naming the query-resolution width for the returned matrix. Datadog likewise documents that graphing enforces a point cap and automatically rolls up points over time intervals, defaulting to `avg` unless a custom rollup is specified. Ward should steal the lesson directly: once a question becomes recurring, the answer's resolution belongs in the contract instead of hiding behind renderer defaults (`EXT-PROMETHEUS-QUERY-API-2026`, `EXT-DATADOG-ROLLUP-2026`).

2. **Auto-selected source resolution can change the truth class even when the query text stays the same.**  
   Thanos documents `max_source_resolution` with choices of `auto`, `0` (raw only), `5m`, and `1h`, and says auto-downsampling can select source resolution based on the query when the parameter is not specified. Ward should steal the warning: a repeated question can silently cross from raw replay into downsampled history unless the chosen source-resolution lane stays visible (`EXT-THANOS-QUERY-2026`).

3. **Downsampling and retention interact, and the wrong retention ladder can erase the intended bridge.**  
   Thanos compactor says raw metrics older than 40 hours are downsampled to 5 minutes and 5-minute data older than 10 days is downsampled to 1 hour. The same docs warn that if retention at each resolution is lower than the minimum age for the next downsampling pass, data can be deleted before downsampling completes. Ward should steal the anti-lesson: retention tiering is not merely an operations knob because it changes what replay is still possible (`EXT-THANOS-COMPACTOR-2026`).

4. **Summaries surviving after raw deletion are a different truth class from raw replay.**  
   Tiger Data says you can combine retention policies with continuous aggregates so that old raw data can be deleted while summarized history remains, but it warns that refreshing over deleted raw windows can also delete the aggregate data. Ward should steal the discipline that raw replay, retained summary, and summary-after-raw-expiry are distinct result classes (`EXT-TIGERDATA-RETENTION-CAGG-2026`).

5. **Hybrid materialized-plus-raw answers deserve their own residue.**  
   Tiger Data says real-time aggregates combine materialized buckets with the most recent raw data, are disabled by default from TimescaleDB v2.13 onward, and are eventually consistent for newly inserted historical data. Ward should steal the constitutional lesson that a hybrid answer is neither “just raw” nor “just materialized”; the seam must stay inspectable (`EXT-TIGERDATA-REALTIME-AGG-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal downsampling engine, one retained-resolution ladder, one hybrid-materialization policy, or one display-resolution doctrine.

For now, keep three more separations visible and let later specimens force promotion:
- **resolution binding** — visible statement of the query step, source resolution, or other declared fidelity width the answer actually used.
- **tier witness** — visible statement of whether the answer came from raw replay, a retained/downsampled tier, a materialized derivative, a display rollup, or another declared storage/serving tier.
- **hybrid seam** — visible statement of any stitch line where materialized history and fresher raw data, or two retained resolutions, were combined in one answer.

## Why these separations are worth stealing
- A **resolution binding** stops one wide-step chart from borrowing the authority of a raw or fine-step rerun.
- A **tier witness** stops retained summaries or renderer rollups from posing as the same truth class as raw replay.
- A **hybrid seam** stops “materialized plus latest raw” from masquerading as a single homogeneous source.

## Brilliant ideas to steal now
- **raw-only lane** — explicit opt-in for replay-grade questions that must refuse downsampled history.
- **source-resolution badge** — compact display of `raw`, `5m`, `1h`, or another declared fidelity class.
- **tier handoff marker** — visible note that a long-range answer crossed from one retained tier into another.
- **hybrid seam card** — one small surface showing where materialized history stops and raw freshness begins.
- **resolution weaker than fact truth** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward should require resolution binding on every recurring range answer or only on promoted surfaces where renderer/engine defaults can drift meaningfully.
- Whether tier witness should distinguish storage tier, serving tier, and renderer rollup separately, or only when those differences change comparability.
- Whether hybrid seam should be mandatory only for materialized-plus-raw stitches, or also for queries that combine raw and downsampled historical blocks.
- Whether Ward should later standardize a machine-readable “raw floor” or retained-fidelity ladder once enough specimens show the same drift patterns.
