# Research synthesis — pass LIII

This pass keeps Ward decision-light and adds another datacube discipline: **unit semantics are part of result meaning, not just chart decoration.**

## What the past says we must learn
1. **Unit is identifying, not decorative.**  
   OpenTelemetry's metrics data model treats a metric stream's `unit` as an identifying property, and its producer guidance says disagreeing-but-similar units such as `ms` and `s` may be converted to avoid semantic errors, otherwise the implementation should inform the user of a semantic error. Ward should steal the constitutional lesson: unit mismatch is meaning drift first and convenience second (`EXT-OTEL-METRICS-DATA-MODEL-2026`).

2. **Base units are healthier than friendly mixed units.**  
   Prometheus's exporter guidance says metrics must use base units such as seconds and bytes, leave human-readability conversion to graphing tools, keep the metric name's unit consistent with the values, and expose ratios rather than percentages. Ward should steal the humility: a recurring trust surface should decide whether its canonical truth is seconds, bytes, or ratio before it earns dashboard authority (`EXT-PROMETHEUS-WRITING-EXPORTERS-2026`).

3. **One metric should not mix incompatible units.**  
   Prometheus also says all values within a metric should almost always have the same unit, because mixed-unit series break downstream aggregation and human interpretation. Ward should borrow that as a datacube warning: one promoted surface should not let milliseconds, seconds, bytes, and kibibytes silently cohabit under one friendly title (`EXT-PROMETHEUS-WRITING-EXPORTERS-2026`).

4. **Display formatting is a weaker layer than data truth.**  
   Grafana's standard-options docs say panel unit settings do not change the data, only how the visualization displays it; the same docs also expose custom SI-unit/source-scale handling and automatic scaling for readability. Ward should steal the separation, not the product: displayed `ms`, displayed `%`, or displayed `MB` can be a viewer convenience that remains weaker than the canonical unit contract underneath (`EXT-GRAFANA-STANDARD-OPTIONS-2026`).

5. **Unit choice begins at the instrument or source edge.**  
   OpenTelemetry's metrics concepts page says a metric instrument is defined by name, kind, unit, and description, with the unit chosen by the developer or semantic conventions. Ward should steal the process lesson: if a future trust surface starts life with ambiguous units, the ambiguity should be caught close to ingestion or contract definition rather than buried under later dashboards (`EXT-OTEL-METRICS-CONCEPTS-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal conversion registry, one global currency/financial normalization story, or one canonical display format for every shell.

For now, keep three more separations visible and let later specimens force promotion:
- **unit binding** — explicit statement of the canonical unit family and exact unit one recurring surface claims to speak.
- **conversion witness** — visible statement of any source-unit to canonical-unit conversion or normalization that was applied.
- **display scale** — explicit reminder that the shown unit/abbreviation/percentage formatting may be a rendering layer weaker than the canonical bound unit.

## Why these separations are worth stealing
- A **unit binding** stops one metric title from borrowing authority across `ms`/`s`, `bytes`/`KiB`, or `ratio`/`percent` folklore.
- A **conversion witness** keeps normalization work inspectable instead of hiding it inside one magical metric definition.
- A **display scale** keeps pretty rendering, auto-scaling, and percent signs from impersonating the underlying unit contract.

## Brilliant ideas to steal now
- **unit binding** — the canonical unit contract for one promoted recurring surface.
- **conversion witness** — compact residue that says how source values were normalized before comparison or publication.
- **display scale** — explicit statement of what the user was shown, kept weaker than the underlying bound unit.
- **no silent percent sign** — standing anti-regrowth rule.
- **display is weaker than data** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward should ever bless one universal unit registry beyond the promoted surface that needs it.
- Whether currencies, exchange-rate time cuts, or fiscal normalization should later become a sibling lane instead of living under the generic unit discipline.
- Whether `display scale` should remain presentation residue only or later become a typed contract field on published surfaces.
- Whether some repeated questions should permanently stay raw-number-plus-unit surfaces rather than earning auto-scaled display aliases at all.
