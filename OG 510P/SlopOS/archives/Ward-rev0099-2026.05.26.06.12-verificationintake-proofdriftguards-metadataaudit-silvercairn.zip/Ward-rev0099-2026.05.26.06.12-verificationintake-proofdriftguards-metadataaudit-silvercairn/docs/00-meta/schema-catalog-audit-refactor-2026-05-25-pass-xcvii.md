# Schema catalog audit/refactor — pass XCVII

## Problem

By rev0096, Ward had many governance schema files plus a registry-backed checker suite. Registry integrity checked registered entries, and fixture-catalog integrity checked fixture layout. The remaining maintenance gap was the schema directory itself: a future pass could add a schema file but forget to register the checker/fixture family.

## Change

Added `tools/check_schema_catalog_integrity.py` and wired it into `make check`.

The checker verifies:

- every `schemas/governance-*.v0.json` file is represented in `tools/governance_checker_registry.json`;
- every registered schema path exists;
- schemas are parseable JSON object schemas using draft 2020-12;
- `required` includes `schema`;
- `properties.schema.const` matches the registry `schema_id`;
- schema ids are unique;
- registered fixture directories exist.

## Refactor value

The governance suite now has three complementary maintenance guards:

- registry integrity: checks the declared checker/schema/fixture map;
- fixture catalog integrity: checks positive/negative fixture-family layout and schema parity;
- schema catalog integrity: checks that the schema directory cannot grow unaudited surfaces.
