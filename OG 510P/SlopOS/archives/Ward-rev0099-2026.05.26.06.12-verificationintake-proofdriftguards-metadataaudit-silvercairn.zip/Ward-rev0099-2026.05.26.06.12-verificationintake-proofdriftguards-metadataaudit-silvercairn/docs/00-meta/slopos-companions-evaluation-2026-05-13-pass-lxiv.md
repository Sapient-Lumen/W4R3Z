# SlopOS / companions evaluation — pass LXIV

Pass LXIV treats answer reuse as a trust-bearing datacube event. Pass LXIII said explanation must not outgrow evidence. Pass LXIV says materialization, caching, refresh, compaction, pre-aggregation, and incremental maintenance must not outgrow authority.

## What the included cubes keep teaching

- **SlopOS** remains the anchor. D-ATTRFS / CH-ATTRQ already says view-scoped, snapshot-first, handle-returning, bounded, and saved-query persistence stays shell-owned. That posture argues against a background cube cache becoming an ambient latest-state oracle. A freshness envelope should bind reuse to one explicit view/snapshot/cut, not to “the current dashboard”.
- **Harbor** is the strongest pressure for invalidation receipts. Harbor's temporal witnesses, contract subsets, lineage guards, restatement habits, and change-history lanes imply that upstream change can narrow old conclusions without deleting their evidentiary value.
- **Foundry** keeps basis, candidate, active generation, pinned cut, and restore duty distinct. Ward should not call a materialized result “fresh” if the basis generation changed, even when the physical cache still serves quickly.
- **Steward** keeps bootstrap, reconciliation, cause condition, followthrough, and process state visible. A recompute docket is Steward-shaped pressure: “repair is required” is not the same as “repair completed”.
- **Schell** keeps basis cards, activation receipts, and environment epochs separate. If an environment epoch changes, old materializations may remain reviewable but lose consequence-grade reuse unless their freshness envelope says otherwise.
- **ViewFS** is the warning for stable handles versus live aliases. SlopOS's safe-open materialization boundary resolves once and hands a request-local stable input; Ward should steal that exact pattern for cube answers: no retarget-on-change hidden behind a reused handle.
- **Helm** is where the UX harm appears. Helm will want to display stale/fast answers with a badge. Ward should give it stricter labels: reusable, stale-but-reviewable, invalidated, recompute-pending, refused, or repaired-under-new-cut.

## What this means for the SlopOS datacube

A SlopOS-facing reused answer should require at least:

1. **A freshness envelope before reuse.** The answer must say which scope lens, state cut witness, materialization generation, quality posture, redaction profile, and freshness target make reuse legitimate.
2. **Observed lag and target lag separated.** A target is not proof. Ward should keep desired freshness, observed cut age, source freshness, and consequence-grade threshold distinct.
3. **Incremental eligibility named.** If the answer came from incremental refresh, the answer should say why the change pattern was eligible, whether a fallback/full-recompute occurred, and which unsupported mutations would invalidate it.
4. **An invalidation receipt for every material change.** Upstream schema/semantic/policy/source/quality/privacy/materialization/layout/retention changes should produce visible receipts, even if the action is “reuse still allowed”.
5. **A recompute docket when repair is owed.** A stale or invalidated answer should not disappear into operations. It should leave a bounded docket: impacted answers, needed mode, replay floor, blockers, priority, and completion/refusal posture.
6. **No hidden count/existence oracle.** Freshness checks, invalidation probes, and recompute queues must not leak whether denied rows, cells, or handles exist outside the requester view.
7. **Reviewability survives invalidation when allowed.** Invalidated does not always mean deleted. Old answers may remain audit material while being barred from new consequence.

## Companion-specific steals

- From **Harbor**: restatement and lineage-change receipts as invalidation triggers.
- From **Foundry**: active-generation and pinned-cut discipline for freshness envelopes.
- From **Steward**: recompute/repair work as visible process state rather than invisible ops.
- From **Schell**: environment epochs as invalidation boundaries.
- From **ViewFS**: resolve-once materialization and no live retargeting.
- From **Helm**: consequence-aware stale/refused/recompute-pending badges.

## Anti-lessons to preserve

- Do **not** let a cache hit imply currentness.
- Do **not** let an incremental refresh mode imply correctness without eligibility evidence.
- Do **not** let compaction, hidden projections, star-trees, or downsampled tiers become the logical contract.
- Do **not** let physical cleanup erase replay/audit floors for promoted answers.
- Do **not** let stale answers silently feed comparisons, explanations, or trust consequence.
- Do **not** let recomputation queues leak denied population or cell existence.
- Do **not** let “fallback to base query” hide that the materialized path failed its reuse bargain.

## What Ward should probably steal next

- a **freshness envelope** beside any reused or materialized answer;
- an **invalidation receipt** for changes that affect reuse, comparison, explanation, or consequence;
- a **recompute docket** for stale/invalidated answers that owe repair or refusal;
- a standing **cache hit weaker than answer authority** rule;
- a small fixture suite for incremental-eligibility, stale-but-reviewable, retention-floor, and hidden-oracle cases.
