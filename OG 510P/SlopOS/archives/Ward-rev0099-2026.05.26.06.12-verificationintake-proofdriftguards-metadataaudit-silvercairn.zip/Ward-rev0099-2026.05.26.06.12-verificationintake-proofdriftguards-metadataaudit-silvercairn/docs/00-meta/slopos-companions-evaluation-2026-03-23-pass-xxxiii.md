# SlopOS / companions evaluation — pass XXXIII

This pass keeps Ward embryonic while stealing one more useful habit from SlopOS and from mature assurance systems: **keep decomposed assurance visible, and keep local minimums separate from observed facet values.**

## What the current cubes still teach
- **SlopOS** already has the strongest nearby lesson for this pass in its assurance claims, claim registry, invariant registry, proof-obligation registry, and posture-heavy boundary families. It repeatedly decomposes security meaning into scoped claims and obligations instead of promising one giant timeless score. Ward should steal the smaller analog: preserve a few typed assurance facets and keep any rollup weaker than the facet set.
- **SlopOS** also keeps exact witness gates and fail-closed posture explicit. That matches the new Ward pressure well: an action should test the exact minimum facets it needs rather than consume one scalar “good enough” verdict.
- **Foundry** and **ViewFS** still remind Ward that derived local views are weaker than source evidence. That is helpful here too: a rolled-up badge can be operationally useful, but it should remain visibly downstream of the facet bundle and the local floor map.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one universal assurance taxonomy, one numeric scoring model, one registry service, or one summary-tier ladder into the archive.

## Current recommendation
Keep Ward open on whether multi-axis appraisal ultimately rides on named facets, vectors, tracks, booleans, tiers, or some smaller imported shape.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **assurance facet** instead of one universal trust score;
2. **acceptance floor** instead of hiding minimums inside app policy folklore;
3. **bottleneck facet** instead of one vague deny reason;
4. **rollup badge** only as optional residue smaller than the facet set and smaller than policy;
5. **manifest file-count coherence lint** so the archive's own packaged shape stays inspectable.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep decomposed assurance visible;
- keep local acceptance floors explicit;
- keep the constraining/bottleneck facet inspectable;
- and fail the revision if the release manifest's `file_count` drifts from what is actually on disk.

## Still-not-yet decisions
- Whether `assurance facet` belongs in durable Ward vocabulary or remains imported from adjacent auth/attestation/provenance substrates until more specimens accumulate.
- Whether `acceptance floor` should live inside Ward or remain strictly local policy residue.
- Whether `bottleneck facet` deserves first-class archive residue, or whether a more general explanation family should eventually absorb it.
- Whether Ward should ever standardize a `rollup badge`, or merely require that any collapsed summary stay visibly weaker than the facet set that produced it.
