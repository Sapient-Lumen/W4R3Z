# Research synthesis — pass LXVI

Pass LXV made answer handling visible: filters, drills, render transforms, exports, screenshots, alerts, and agent summaries should not outgrow their source answer capsules. Pass LXVI turns inward again to a pressure that will keep recurring once SlopOS has users: the exact answer may be too expensive, too slow, too private, too detailed, or too unsupported to serve now. The unhealthy outcome is a polite approximate/degraded answer that looks just as strong as the requested answer.

The restraint rule still holds. Ward should not choose a query engine, sketch library, warehouse function, scheduler, pricing system, privacy-accounting framework, or dashboard warning grammar. It should name the smallest residues that keep budgeted, approximate, noisy, sampled, partial, and degraded answers weaker than replayable exact answers.

## What the past says we must learn now

1. **Approximation is not merely acceleration.** BigQuery's approximate aggregate documentation explicitly says approximate functions can use less memory and time, but produce approximate results and introduce statistical uncertainty (`EXT-BIGQUERY-APPROX-AGG-2026`). DuckDB names the estimator family in its approximate aggregate list: HyperLogLog for approximate distinct counts, T-Digest for approximate quantiles, Filtered Space-Saving for approximate top-k, and reservoir sampling for reservoir quantiles (`EXT-DUCKDB-APPROX-AGG-2026`). Ward should steal the visible estimator-family habit and refuse the hidden fast-count habit.

2. **Sketch choices carry merge, precision, and memory meaning.** DataSketches HLL exposes different HLL target types with compression and union-performance tradeoffs (`EXT-DATASKETCHES-HLL-2026`). Theta sketches expose set-expression posture and confidence intervals rather than one naked approximate scalar (`EXT-DATASKETCHES-THETA-2026`, `EXT-DATASKETCHES-THETA-CI-2026`). Druid's DataSketches extension reinforces that sketch-backed cardinality, quantile, and tuple summaries are separate retained objects with distinct set/merge behavior (`EXT-DRUID-DATASKETCHES-2026`). Ward should steal retained sketch identity and merge posture, not freeze any sketch family.

3. **Nondeterminism is answer residue.** ClickHouse documents that `quantileTDigest` computes approximate quantiles with memory use shaped by `log(n)`, and that the result depends on query order and is nondeterministic (`EXT-CLICKHOUSE-TDIGEST-2026`). ClickHouse `uniq` is an approximate distinct-count function using adaptive sampling (`EXT-CLICKHOUSE-UNIQ-2026`). If an engine, sample, seed, execution order, or distributed merge can change the estimate, Ward should attach that to the answer instead of hiding it in engine folklore.

4. **Privacy budget is not compute budget, but both can force answer narrowing.** BigQuery's differential privacy docs frame differential privacy as balancing privacy and statistical utility (`EXT-BIGQUERY-DIFFERENTIAL-PRIVACY-2026`). OpenDP's typical workflow starts by identifying the unit of privacy and then setting privacy loss parameters (`EXT-OPENDP-TYPICAL-WORKFLOW-2026`). A SlopOS datacube should not collapse privacy spend, query cost, latency, egress/detail budget, and capability authority into one generic `budget` field.

5. **Validation detail has its own exposure budget.** Great Expectations result formats range from boolean-only through complete detail, and the docs call out excluding excess validation-result data in published Data Docs (`EXT-GX-RESULT-FORMAT-2026`). This is useful pressure for Ward: a quality witness may be complete for a pipeline owner and summary-only for a dashboard reviewer. Detail withheld for exposure reasons is not the same as data missing or check not run.

6. **The old AQP failure is overconfident polish.** Online aggregation, sampling previews, approximate query processing, warehouse-native sketches, and interactive dashboards all share a temptation: show a number early and let users forget it is an estimate. Ward already has exactness classes, estimator cards, sketch witnesses, sample witnesses, privacy/noise residue, quality witnesses, freshness envelopes, and render contracts. Pass LXVI does not replace them; it adds a wrapper so their combined uncertainty and degradation are visible at the promoted answer boundary.

7. **SlopOS makes budget authority non-ambient.** The included SlopOS snapshot already keeps D-BUDGET / D-METER payer authority explicit and rejects hidden current-payer fallback or silent callee sponsorship. Ward's datacube should mirror the lesson at answer level: a budget gate is not a global scheduler or billing system, but an answer attempt should know which budget classes constrained it and whether they caused refusal or degradation.

## Resulting Ward move

Do **not** decide yet:

- one sketch family, estimator library, statistical error DSL, or approximate-query processor;
- one cost model, quota system, budget lease shape, scheduler, or query-admission engine;
- one privacy-accounting framework or universal privacy-loss vocabulary;
- one rule that exact queries always degrade instead of refusing;
- one UI badge, chart interval grammar, color system, or warning copy for uncertainty;
- one engine-specific mapping for seeds, merge order, distributed execution, partial results, or progressive refresh;
- one universal threshold for when a degraded answer can influence consequence;
- one way to bill, sponsor, or meter agent-initiated cube work.

Do add three small, reversible residues for budgeted and degraded answer attempts:

- **budget gate** — compact admission/evaluation residue for one answer attempt. It names requester view, consequence class, requested answer shape, relevant resource/latency/cost/privacy/egress/detail/exemplar budgets, payer or sponsor posture when applicable, gate outcome, refusal/degradation options, and anti-oracle posture. It is smaller than D-BUDGET/D-METER, a scheduler, or a billing system.
- **degradation receipt** — compact record that the served answer differs from the requested answer. It names requested versus served shape, triggering budget gate or safety rule, loss class, accepted/refused/repair posture, affected cells/axes/segments when safe to reveal, and whether a recompute docket or rehydration path exists. It is smaller than a fallback engine and stronger than a hidden warning log.
- **uncertainty envelope** — compact wrapper around answer or cell strength when exactness, sampling, sketching, privacy noise, suppression, quality warnings, partial coverage, freshness, tiering, nondeterminism, or validation-detail withholding affect interpretation. It composes existing residues without becoming a universal statistical language.

These residues sit beside previous pass nouns. A budget gate may produce refusal receipts, degradation receipts, freshness envelopes, recompute dockets, or egress receipts. A degradation receipt should reference exactness classes, estimator/sketch/sample/privacy/tier/render/quality residues instead of inventing a second truth. An uncertainty envelope should constrain render contracts and agent summaries so a clean chart cannot hide a mixed exact/sketch/noisy/sample answer.

## Brilliant ideas to steal now

- **Named estimator families** — borrow the habit of saying HyperLogLog, T-Digest, reservoir sample, or adaptive sample when known, even while refusing to hard-code one implementation.
- **Retained sketch as object, not just point estimate** — sketches can support unions, intersections, or merges, but only inside their declared family and precision posture.
- **Approximate confidence language with provenance** — confidence/error bands should say whether they are algorithmic, empirical, configured, rank-based, relative, or absent.
- **Budget classes, not one budget blob** — latency, CPU/IO, cost, privacy loss, egress rows/cells, exemplar detail, and validation-detail exposure can narrow answers for different reasons.
- **Degrade-with-receipt, not degrade-by-surprise** — exact-to-sketch, exact-to-sample, fine-to-coarse, current-to-stale, full-to-top-k, detail-to-summary, and private-to-noisy/suppressed all need visible loss classes.
- **Detail-level contracts** — quality, validation, and explanation detail may be boolean-only, summary, or complete depending on authority, not just system capability.
- **Progressive answer humility** — early/partial/progressive answers should decay or be replaced by an exact recompute, not silently harden as final truth.
- **Anti-oracle budgeting** — refusing because a budget or privacy threshold was exceeded must not leak denied population size, hidden cell existence, or suppressed exemplar count.

## Still-not-yet decisions

- Whether every answer attempt needs a budget gate, or only agent, expensive, privacy-shaped, detail-bearing, or consequence-grade attempts.
- Whether degradation receipts are mandatory for all preview/sample/approximate answers or only when the user requested stronger semantics.
- Whether uncertainty envelopes should attach at whole-answer, cell, segment, measure, or render-contract granularity.
- How to compare uncertainty envelopes across different estimator families or privacy mechanisms.
- Whether a budget gate may return multiple safe degraded alternatives or exactly one recommended fallback.
- Whether exact recompute is owed automatically after a degraded preview, or only when a recompute docket is opened.
- Whether uncertainty bands should be machine-checkable, human-readable, or both.
- How long partial/progressive answers remain reviewable after a final/exact answer arrives.

## Process note

Pass LXVI does not add an approximate analytics engine. It adds a refusal/degradation hygiene layer for when exactness, cost, latency, privacy, quality, or detail budgets collide. The next healthy move is to run these residues against a Helm review where an agent asks for a consequence-grade exact comparison, the exact query exceeds a resource/latency gate, a sketch-backed preview is safe for review but not promotion, a private cohort suppresses detail, and a later exact recompute changes the story. If Ward cannot say what was requested, what was served, why it was weaker, what uncertainty it carried, and what budget gate caused the narrowing, the answer should remain review-only or refused.
