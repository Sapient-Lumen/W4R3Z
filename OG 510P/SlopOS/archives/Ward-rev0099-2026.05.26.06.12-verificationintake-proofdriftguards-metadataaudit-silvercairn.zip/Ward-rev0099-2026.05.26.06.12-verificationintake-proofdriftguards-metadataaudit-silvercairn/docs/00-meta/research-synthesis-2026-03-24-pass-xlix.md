# Research synthesis — pass XLIX

This pass keeps Ward decision-light and adds another datacube discipline: **a repeated question must declare how it treats gaps before a densified answer can pose as raw observed truth.**

## What the past says we must learn
1. **Densification and numeric filling are different operations.**  
   dbt now documents `join_to_timespine` and `fill_nulls_with` together. Its example only gets a value for the missing day after a time spine join creates daily coverage, and only then can nulls be filled. Ward should steal that two-step humility: a contiguous aligned output is already a different artifact than raw observation, and the later fill choice deserves its own residue (`EXT-DBT-FILL-NULLS-2026`).

2. **Gap filling needs an explicit method, and the default still means something.**  
   BigQuery's `GAP_FILL` docs say that if no gap-filling method is specified, the default is `NULL`; they separately expose `locf` and `linear` methods. Ward should borrow the constitutional lesson: a missing bucket, an explicit null bucket, a carried-forward bucket, and an interpolated bucket are different truths (`EXT-BIGQUERY-GAP-FILL-2026`).

3. **Creating empty buckets is weaker than filling them.**  
   Tiger Data / Timescale says `time_bucket_gapfill` creates a contiguous set of time buckets **but does not fill the rows with data**; LOCF or interpolation are separate follow-on choices. Ward should therefore keep the generated bucket distinct from whatever value later occupies it (`EXT-TIGERDATA-GAPFILL-2026`).

4. **Missing and stale are not zero.**  
   Prometheus documents that queries use a lookback window, that series are marked stale when they stop appearing, and that stale series then disappear from query results. Ward should steal the caution, not the stack: absence, staleness, and zero should not silently collapse just because a dashboard wants a continuous line (`EXT-PROMETHEUS-STALENESS-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal time spine, one default gap-fill method, one machine-readable fill schema, or one canonical distinction among empty, null, stale, and unknown across every future surface.

For now, keep three more separations visible and let later specimens force promotion:
- **gap posture** — visible statement of what a missing bucket/series means here: omitted, null, stale, zero-filled, carried-forward, interpolated, or still unknown.
- **fill witness** — visible residue that one result used a particular fill method and therefore is weaker than direct observation.
- **synthetic bucket** — generated alignment bucket created for analysis or display, weaker than an observed source bucket.

## Why these separations are worth stealing
- A `gap posture` stops “no row”, “unknown”, “stale”, and “true zero” from borrowing each other's social authority.
- A `fill witness` keeps a carried-forward or zero-filled value from masquerading as directly observed fact.
- A `synthetic bucket` lets Ward align, compare, and chart recurring questions without pretending every visible row came from the source untouched.

## Brilliant ideas to steal now
- **gap posture** — explicit statement of what missingness means on one result surface.
- **fill witness** — explicit trace that one answer was filled and by what method.
- **synthetic bucket** — generated bucket for alignment, densification, or display.
- **no silent zero-fill** — standing anti-regrowth rule.
- **alignment weaker than observation** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward ever blesses one universal time spine or bucket-alignment substrate.
- Whether `gap posture` stays human-facing guidance or later becomes typed machine-readable metadata.
- Whether `fill witness` is mandatory only for promoted derivatives or also for frozen review bundles.
- Whether some repeated questions should permanently remain sparse/omissive instead of ever earning synthetic buckets.
