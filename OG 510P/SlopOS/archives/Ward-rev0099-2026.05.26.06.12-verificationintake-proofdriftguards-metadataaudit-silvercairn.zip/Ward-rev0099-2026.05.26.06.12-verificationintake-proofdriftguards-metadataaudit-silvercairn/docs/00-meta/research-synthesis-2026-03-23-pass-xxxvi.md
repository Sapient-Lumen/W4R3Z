# Research synthesis — pass XXXVI

This pass keeps Ward cautious and learns one more thing from mature replicated/consensus and durable-read systems: **acknowledged, committed, stable-to-read, and hard-to-reverse are different truths.**

## Outside lessons
1. **Raft keeps append, commit, and apply visibly different.**  
   The Raft paper says the leader first appends and replicates a new entry, then treats it as committed only when it is safe by the protocol’s rules, and only then applies it locally. It also shows that a log entry can be replicated on a majority and still not count as committed in the stronger sense after leader changes. Ward should steal the restraint: “seen on enough peers” and “safe local consequence now” are different claims.

2. **Kafka keeps producer acknowledgment strength and stable-read visibility separate.**  
   Apache Kafka’s producer configs say `acks=0`, `acks=1`, and `acks=all` mean materially different durability classes. Its consumer docs say `read_committed` only exposes data up to the last stable offset (LSO), withholding later offsets while transactions remain unresolved. Ward should steal two ideas: one write can be acknowledged before it is safe for one read surface to expose, and one visible frontier is smaller than full log end.

3. **MongoDB keeps majority acknowledgment, committed reads, and immediate reader visibility separate.**  
   MongoDB’s docs say write concern and journaling posture matter independently, and that starting in MongoDB 8.0 a `{ w: "majority" }` write is acknowledged after a majority durably writes the oplog entry even though secondaries may still apply the change later. Its `"majority"` read concern then returns data from the majority-commit view rather than “whatever one node most recently saw”. Ward should learn that one change can be durably acknowledged before all receivers or replicas have applied it.

4. **Ethereum keeps justified and finalized checkpoints separate.**  
   Ethereum’s proof-of-stake docs say one checkpoint first becomes justified and only later finalized, and that finalized blocks become economically hard to revert. Ward should steal the restraint: “strong enough to continue” and “expensive to reverse” are different strengths of truth.

## Resulting Ward move
Do not decide yet whether Ward’s long-term datacube should carry these truths as log metadata, receipt sidecars, settlement bundles, replication witnesses, or local policy-side projections.

For now, preserve four separations and let later specimens force promotion:
- `commit witness` versus a vague success/accepted bit;
- `stable frontier` versus full append/head/high-water truth;
- `finality class` versus one timeless durability promise;
- `exposure gate` versus the underlying durability/finality evidence itself.

Keep nearby, but not yet promoted, a few smaller ideas:
- `rollback budget` for how much coordination, time, or slashable stake reversal would cost;
- `apply lag note` for the gap between durable acknowledgment and one receiver’s applied state;
- `current-term commit rule` as a reminder that some protocols need stronger conditions than “majority replicated”; and
- `visibility weaker than commitment` as a standing anti-regrowth rule.

## Fresh ideas worth stealing
- **commit witness** — residue that one change crossed a specific durability or consensus threshold.
- **stable frontier** — the latest cut below which this read/view believes unresolved writes or transactions are no longer hiding.
- **finality class** — typed reversal hardness, such as rollback-possible, quorum-committed, or economically-finalized.
- **exposure gate** — local rule deciding which commitment/finality class is strong enough for one action.
- **rollback budget** — compact clue about what reversal would require.
- **apply lag note** — visible gap between durable acceptance and applied visibility at one reader or replica.
- **visibility weaker than commitment** — a standing anti-regrowth rule.
