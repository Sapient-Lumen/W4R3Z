# SlopOS + companion evaluation — pass LXIX

Pass LXIX evaluates the semantic-drift layer against SlopOS and the companion archives after pass LXVIII's federation pass. The candidate residues are **concept anchor**, **crosswalk warrant**, and **hierarchy cut**.

## SlopOS pressure

SlopOS is still in design phase, so Ward should not ask it to freeze a universal concept registry now. The stronger lesson from the current SlopOS snapshot is restraint:

- D-ATTRFS is view-scoped, snapshot-first, and handle-returning. That posture supports answer-level semantic receipts, not an ambient global ontology or search index.
- CH-ATTR keys are declared, typed, optionally indexed, and visibility-scoped. They are useful metadata pressure but not a complete semantic universe.
- CH-ATTRQ stays bounded and closed-family. Ward should not smuggle full-text ranking, plugin semantics, or unconstrained tag expansion into cube grouping.
- SlopOS already keeps derived semantic attributes quarantined from source attributes. Concept anchors and crosswalk warrants should follow that habit: a derived mapping can qualify an answer without rewriting source facts.
- Because SlopOS is young, provider families, boundary names, risk labels, attribute namespaces, and partner surfaces will likely rename or split. Ward should make that survivable rather than demand early naming finality.

## Companion readings

### Foundry

Foundry remains the closest sibling pressure for this pass. Its identity-anchor / label-snapshot / axis-budget language reminds Ward to split durable identity from display text and UI axis capacity. Ward should translate that into cube-answer residue rather than copying Foundry's nouns: a concept anchor identifies the semantic member; a crosswalk warrant bridges members; a hierarchy cut freezes rollup membership for the answer.

### Harbor

Harbor's evidence and temporal witness posture is a warning that evidence-code terms are not automatically outcome classifications. A Harbor evidence summary can support a Ward concept anchor or crosswalk warrant, but it should not silently become a datacube axis without mapping grade, effective period, and no-map posture.

### Steward

Steward's activation/cause/condition surfaces are likely to create bucket splits and merges. A new activation-cause split should not retroactively rewrite old Ward trend cells unless a crosswalk warrant and comparability passport state how the bridge works.

### Schell

Schell's basis and expansion pressure reinforces value-set expansion hygiene. A hierarchy or code set should carry the cut used for one answer; otherwise later basis changes can change old membership invisibly.

### ViewFS

ViewFS handle and presentation pressure says user-visible labels and folder-like organization are helpful but weak. Ward should not let a display path, alias, or exported column name become semantic identity without a concept anchor.

### Helm

Helm is where the mistakes become visible. Tables, charts, strips, review queues, and screenshots can keep the old label while the concept behind it changes. Render contracts and egress receipts should carry label snapshots, concept anchors, and hierarchy cuts when exported artifacts can influence later consequence.

### SlopOS as boundary keeper

SlopOS should remain the authority boundary, not the semantic catch-all. Ward can attach semantic residues to answer capsules, but query handles, attributes, view scoping, privacy gates, and snapshot cuts still determine what may be asked and shown.

## Lessons that must survive promotion

- A same-looking label is not proof of same concept.
- A renamed term is not always a changed concept, but the old label still belongs in the answer history.
- A split or merge is never just a label change.
- A partner free-form tag should start weaker than a governed term.
- A value-set or hierarchy expansion is a time-cut artifact.
- An unmapped code/member is evidence; dropping it can bias denominators, rollups, privacy thresholds, and explanation panels.
- Current taxonomy membership should not automatically restate old exports.

## Promotion probes

Before making the new residues stronger than candidate nouns, pressure-test:

1. one pure label rename with same concept identity;
2. one bucket split requiring explicit historical restatement choice;
3. one bucket merge with residual loss notes;
4. one partner free-form tag mapped to a governed term only as `close_match`;
5. one abstract hierarchy node that may roll up but not receive facts directly;
6. one unmapped privacy-sensitive cell that must not leak as “Other”; and
7. one old export that may be reviewed historically but cannot be reused as current authority without rehydration.
