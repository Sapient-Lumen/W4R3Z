# SlopOS companions evaluation — pass XCI

Pass XCI evaluates Ward's new signal-notification receipt against SlopOS and the companion cubes.

## SlopOS

SlopOS should consume a signal-notification receipt only as recheckpoint pressure. It should not turn a delivered notification, acknowledgment, dead-letter pointer, or aggregate fanout result into a CH-AREF grant, portal permission, action trigger, export allowance, or resume token.

## Helm

Helm gets a sharper rendering contract: all-notified, partial, dead-lettered, duplicate-suppressed, and conflict-held notification states should produce distinct chips. No chip should use green authority language until the consumer-local recertification or source-packet replay exists.

## Harbor

Harbor should not update public stale-surface text merely because a revocation notice was acknowledged. It may show that notification was received, but stale messaging remains held until the relevant recertification/follow-up receipt exists.

## Schell

Schell should minimize consumer identities and exact hidden counts in public notification summaries while preserving consumer-set digest, payload digest, and stale-consumer quarantine evidence in restricted audit views.

## ViewFS

ViewFS should treat dead-lettered or pending notification states as unsafe UI currentness. A projection can say "refresh notice pending/quarantined" without exposing sealed signal payloads or private consumer contacts.

## Foundry and Steward

Foundry and Steward should not import notification fanout as semantic approval, repair authority, or stewardship succession. The receipt is operational lifecycle evidence only.
