# SlopOS / companions evaluation — pass LXVII

Pass LXVII treats history repair and answer withdrawal as trust-bearing datacube events. Pass LXVI said weakened answers need budget/degradation/uncertainty residue. Pass LXVII says even strong answers can lose current authority when late events, corrected identity, delete/revoke states, policy changes, change-feed retention, or backfill campaigns revise the answer's basis.

## What the included cubes keep teaching

- **SlopOS** remains the anchor. D-ATTRFS / CH-ATTRQ keeps attribute queries view-scoped, snapshot-first, handle-returning, and bounded. D-BUDGET / D-METER keeps payer authority explicit. Its broader snapshot/namespace posture also teaches that a snapshot is a cut with scope, not a universal history oracle. Ward's correction horizon should therefore bind to SlopOS answer cuts and handles, not to ambient `latest`.
- **Harbor** already cares about exactness, evidence grades, contract subsets, and lineage guards. Ward should borrow its habit of making evidence strength explicit, but use correction horizons and revocation fences when previously strong evidence is later superseded or withdrawn.
- **Foundry** keeps basis, pinned cuts, candidate/active generations, and restore duties visible. A backfill ledger should look like a deliberate change of basis, not a hidden mutation of the answer that old consumers accidentally inherit.
- **Steward** keeps process, reconciliation, cause conditions, and followthrough visible. Backfills are process claims: reason, authority, run, validation, residual gap, and followthrough should stay visible instead of disappearing into an ops dashboard.
- **Schell** keeps activation receipts and environment epochs separate. A correction produced by a new runtime/library/epoch can carry that as optional evidence without making Ward choose one execution substrate.
- **ViewFS** keeps stable handles distinct from live aliases and resurfacing. A revocation fence should not mutate a stable old handle into new truth; it should mark whether old material can be rehydrated, compared, exported, or used for consequence.
- **Helm** is the pressure surface. Users will see old charts, exported CSVs, review comments, screenshots, and agent summaries after a backfill or revocation. Helm needs `revised`, `fenced`, `backfill-pending`, `comparison-bridge-required`, and `rehydrate-before-use` posture rather than one red/green stale badge.

## What this means for the SlopOS datacube

A SlopOS-facing corrected or withdrawn answer should require at least:

1. **Correction horizon before finality.** The answer capsule should say whether its time range and cells are still open to late data, identity repair, policy revision, delete/revoke state, or backfill.
2. **Backfill ledger before historical rewrite.** Deliberate repair should be a reviewable campaign with reason, authority, source cuts, recipe, affected safe scope, validation, outputs touched, and residual gaps.
3. **Revocation fence before reuse.** A stale, withdrawn, superseded, privacy-fenced, or legally constrained answer/export should require rehydration through current authority before it can influence new consequence.
4. **Change coverage named.** If change feed, snapshot, time-travel, compacted log, or raw replay coverage is incomplete, Ward should expose the gap safely and either full-replay, narrow the claim, or refuse.
5. **Effective-time and learned-time kept apart.** A fact may have been effective last week, learned today, published tomorrow, and locally adopted later. Smooth charts should not collapse these.
6. **No backfill oracle.** A correction notice must not reveal hidden cell existence, suppressed cohort size, denied row count, or private exemplar presence outside the requester view.
7. **Comparison repair.** Old-vs-new charts after a backfill need comparability passport, drift notices, quality witnesses, and often a bridge-required posture.
8. **Exports decay.** CSVs, screenshots, copied tables, and agent summaries become detached artifacts; correction/fence notices should point to egress receipts where possible without promising global recall.

## Companion-specific steals

- From **SlopOS**: snapshot/handle discipline, explicit budget/authority, fail-closed bounded query surfaces.
- From **Harbor**: evidence-grade humility when once-good evidence becomes superseded or outside current consequence grade.
- From **Foundry**: pinned-cut and generation posture for backfill/rebasis work.
- From **Steward**: followthrough/reconciliation language for repair campaigns and residual gaps.
- From **Schell**: environment epoch as optional correction evidence, not the datacube constitution.
- From **ViewFS**: stable handles remain historical references; live aliases and rehydration decide present use.
- From **Helm**: review-facing condition strips for revised, withdrawn, backfill-running, bridge-required, and rehydrate-before-use states.

## Anti-lessons to preserve

- Do **not** let “final dashboard” mean immune to late facts or explicit repair.
- Do **not** silently rewrite old answer capsules in place after a backfill.
- Do **not** let a change-feed gap masquerade as proof that nothing changed.
- Do **not** treat hard delete, privacy suppression, legal erasure, credential revocation, and absence from source as the same state.
- Do **not** let a compacted survivor view claim full correction lineage.
- Do **not** let a revocation/fence notice leak denied row or cell existence.
- Do **not** promise export recall; require egress receipts, warnings, and rehydration instead.
- Do **not** make one retention/finality window universal across every SlopOS trust answer.

## What Ward should probably steal next

- a **correction horizon** for open/closed/repair-only answer ranges;
- a **backfill ledger** for deliberate historical repair campaigns;
- a **revocation fence** for withdrawn, superseded, deleted, erased, or policy-fenced answer material;
- a standing **old answer weaker than rehydrated current authority** rule;
- a small fixture suite for late-event correction, identity backfill, hard-delete-as-state, change-feed gap, compaction survivor rebuild, fenced export, and comparison after repair.
