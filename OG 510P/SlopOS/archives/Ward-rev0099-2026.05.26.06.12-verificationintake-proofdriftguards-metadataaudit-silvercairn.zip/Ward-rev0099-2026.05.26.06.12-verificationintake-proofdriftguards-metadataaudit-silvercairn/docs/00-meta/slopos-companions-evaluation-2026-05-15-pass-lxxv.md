# SlopOS and companion evaluation — pass LXXV

Pass LXXV evaluates Ward's SlopOS datacube posture after adding custody trails, retention charters, and disposition receipts. The target is not compliance automation. The target is a durable distinction between **evidence that is held**, **evidence that is allowed to remain**, **evidence that has been reduced or disposed**, and **authority that remains current**.

## SlopOS fit

The included SlopOS snapshot already contains strong nearby pressure:

- **CH-AREF** says the digest is authoritative while locators are hints. Ward should borrow digest-bound artifact identity for custody trail entries and disposition residuals, but not let digest match become current answer authority.
- **Artifact-resolution posture** says dereferencing locators is an explicit workflow seam, not ambient privileged fetch. That maps directly to custody transfer: old bundles and sidecars should not be auto-fetched from stale locators during audit or replay.
- **Archive policy** says cite rather than copy and keeps heavyweight evidence out of the design archive. Ward's datacube lifecycle posture should prefer proof-minimizing references, redactions, and digest-only residues over raw-row hoarding.
- **D-NONDET / D-RR / CH-DERIV** already make replay and derivation explicit enough to show that missing retention is a first-class replay limit, not a bug to hide.
- **CH-ACPOUT** remains non-authoritative. A retained consequence receipt, signed export, or auditor copy cannot become permission to keep acting.
- **Receipt replication boundaries** reinforce that replicated evidence can survive without becoming local authority.

The fit is strong if Ward stays small: custody trail, retention charter, and disposition receipt are answer/evidence lifecycle residues, not SlopOS-wide records management primitives yet.

## Companion pressure

- **Harbor** gives temporal pressure: retention and disposition must respect read cuts, correction horizons, revocation fences, and old/new authority splits.
- **Foundry** gives semantic pressure: retained material must keep concept anchors, hierarchy cuts, and crosswalk warrants or it will mislead future reviewers.
- **Steward** gives consequence pressure: retained evidence of an old action is not an action warrant and cannot silently renew consequences.
- **Schell** gives environment pressure: custody and retention need environment/basis cards when replayability depends on captured runtime or dependency state.
- **ViewFS** gives artifact pressure: files, folders, copies, screenshots, sidecars, and exports need stale/disposed/retained status without hiding location ambiguity.
- **Helm** gives review pressure: reviewers need a compact lifecycle panel: held by whom, under what charter, what was disposed, what remains, and whether current authority must be rehydrated.

## What Ward should absorb

1. **Evidence lifecycle deserves first-class residue.** Verification bundles, exported charts, model summaries, validation reports, and action receipts can outlive the source answer. Their lifecycle must be visible.
2. **Retention scope must be narrower than answer truth.** Keep scope, purpose, designated verifier class, projection/detail level, hold status, erasure pressure, and expiry separate.
3. **Custody discontinuities matter.** If a chart was exported, emailed, copied into a review packet, redacted, re-signed, or handed to counsel, those are handling events with different projection and authority consequences.
4. **Disposition is not always deletion.** Expiry, redaction, digest-only reduction, transfer, sealing, cryptographic erasure, physical sanitization, legal hold, and refused disposal are different outcomes.
5. **Old evidence can remain historically useful while losing current force.** A retained bundle may show why an action was taken under a past cut; it may not justify continuing that action after correction, revocation, or policy change.
6. **Minimize retained sensitive detail.** Retain enough to verify process and explain limits, not enough to bypass projection curtains, privacy suppressions, partner boundaries, or erasure requirements.

## What Ward should not absorb yet

- No global retention schedule, legal-hold system, records taxonomy, object-store/WORM mode, evidence-vault product, DLP tool, archive repository, or sanitization framework.
- No claim that every datacube answer must be retained, exportable, auditable, replayable, or legally discoverable forever.
- No guarantee that disposition receipts prove all external copies, screenshots, emails, or downstream model memories vanished.
- No rule that audit retention beats privacy erasure, or that privacy erasure beats legal hold, without local policy.
- No universal “right answer” for retaining prompts, generated SQL, raw rows, partner fragments, validation sidecars, exemplars, or noisy/DP materials.

## Evaluation verdict

Promote **custody trail**, **retention charter**, and **disposition receipt** as candidate datacube residues only. They improve Ward because they let SlopOS-facing cube evidence survive audit, dispute, erasure, transfer, and expiry pressure without collapsing evidence custody into current authority or turning Ward into a compliance engine.

## Immediate review checklist

Before a SlopOS-facing datacube artifact can be treated as lifecycle-safe:

- the custody trail must name holders, transfer purposes, access/projection classes, fixity checks, transformations, and gaps;
- the retention charter must name purpose, authority, designated verifier/reviewer class, retention horizon, legal/erasure/privacy/audit pressures, detail level, and review gates;
- the disposition receipt must name scope, method class, actor/authority, time, evidence strength, residual material, downstream notice posture, and non-amnesia limits;
- verification bundles, replay recipes, attestation envelopes, render/egress receipts, action/consequence receipts, and learning/scenario/model residues must remain separate;
- currentness must be rehydrated from live authority, not inferred from old retention, old custody, old WORM status, or old disposal records.
