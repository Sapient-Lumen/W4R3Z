# Fixture catalog audit/refactor — pass XCVI

Rev0096 adds `tools/check_fixture_catalog_integrity.py`.

## Why

Ward now has many governance receipt families. The registry confirms scripts and schemas, but the fixture directories themselves can still drift: invalid fixtures can be placed at the wrong level, filenames can stop being slugged, schema ids can drift from registry entries, or a family can lose its positive/negative shape.

## What the checker enforces

For every fixture-backed registry entry, the checker verifies:

- the fixture directory exists;
- direct positive fixtures use `*.valid.json`;
- invalid fixtures live under `negative/*.invalid.json`;
- filenames are lowercase slugs;
- fixture JSON parses;
- direct positive/negative fixtures carry the schema id registered for that family.

## What it deliberately does not enforce

The checker does not require globally unique receipt ids because many negative fixtures intentionally clone a valid receipt and mutate one field. It also permits support fixtures in explicit non-negative subdirectories, such as search-continuity page fixtures, because those are input specimens rather than the family under direct validation.
