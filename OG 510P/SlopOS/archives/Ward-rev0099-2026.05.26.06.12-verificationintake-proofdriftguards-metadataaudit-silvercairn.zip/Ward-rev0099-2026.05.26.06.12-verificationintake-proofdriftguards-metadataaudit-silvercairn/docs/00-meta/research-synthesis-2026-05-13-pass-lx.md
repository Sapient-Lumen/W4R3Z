# Research synthesis — pass LX

This pass keeps Ward embryonic. The goal is not to crown a universal cube engine, semantic layer, table format, array store, or plan language. The goal is to learn from old data-cube scars and current systems while keeping SlopOS's design-phase reality in view: query authority, view scope, handles, snapshots, storage, and rendered answers are still being shaped.

The resulting posture is deliberately small: describe the shape and accountability of a promoted answer before deciding how every future answer must be stored or computed.

## What the past says we must learn

1. **The original data-cube idea is an aggregation lattice, not a product constitution.**  Gray et al. made the cube valuable by generalizing `GROUP BY`, cross-tabs, roll-ups, drill-down, and subtotal families. Ward should steal the lattice intuition without assuming that the first durable SlopOS datacube is a materialized OLAP cube (`EXT-DATACUBE-GRAY-1997`).

2. **Grain is a binding promise, not a comment.**  Kimball's old lesson still bites hardest: declare the grain before choosing facts and dimensions, and do not mix grains in the same fact surface. Ward already has grain witnesses; pass LX reframes them as part of a smaller **axis capsule** instead of a universal warehouse schema (`EXT-KIMBALL-GRAIN-2003`).

3. **Dimensions, measures, attributes, observations, and slices are different jobs.**  W3C's RDF Data Cube vocabulary keeps observations organized by dimensions, measures as observed phenomena, attributes as qualifiers such as units/status, and slices as useful subsets. Ward should steal that separation without importing RDF, SDMX, or a web-publication mandate (`EXT-W3C-RDF-DATACUBE-2014`).

4. **Physical layout must not become logical meaning by accident.**  Iceberg's hidden partitioning and partition evolution are the right anti-lesson: a query should not need to know that one table is physically laid out by `event_time_day` while another older cut used `event_time_month`. Ward's datacube needs a **layout aperture**: a small, explicit place to say which storage/layout choice affected the answer, while keeping layout outside the answer's identity (`EXT-ICEBERG-HIDDEN-PARTITIONING-2026`).

5. **Portable plans are valuable only if they stay severable.**  Substrait is attractive because it names relational operations and cross-language plan semantics without requiring one producer, one consumer, or one engine. Ward should steal the idea of a plan receipt or plan-shape witness, not commit SlopOS to Substrait or to relational algebra as the only future answer grammar (`EXT-SUBSTRAIT-PRINCIPLES-2026`, `EXT-SUBSTRAIT-RELATIONS-2026`).

6. **Interchange surfaces need explicit non-goals.**  Arrow is a strong teacher because its columnar format and C Data Interface are precise about sharing memory and schema/array data, while also staying out of higher-level coordination, storage persistence, and mutation semantics. Ward should steal the tiny-interface discipline: if an answer crosses a process or engine boundary, say what crossed, but do not mistake the transport surface for the cube constitution (`EXT-ARROW-COLUMNAR-2026`, `EXT-ARROW-C-DATA-2026`).

7. **Lineage can be facet-sized instead of scheduler-sized.**  OpenLineage's model of jobs, datasets, runs, events, and extensible facets is a useful shape. Ward should steal **lineage facet** as a compact answer attachment: enough to rerun, diff, or downgrade trust, not enough to force one orchestration stack (`EXT-OPENLINEAGE-OBJECT-MODEL-2026`).

8. **Sparse absence is not the same thing as zero.**  Array systems such as TileDB keep dense and sparse cells visibly different. Ward should keep emptiness posture close to the answer shape: unobserved, filtered out, suppressed, filled, and zero should not collapse into one tidy cell (`EXT-TILEDB-ARRAY-MODEL-2026`).

## Resulting Ward move

Do **not** decide yet:
- one canonical cube schema;
- one storage engine or table/array format;
- one universal query language or plan IR;
- one materialization ladder;
- one sparse/dense/zero-fill rule;
- one lineage/orchestration stack;
- one semantic-layer authority above SlopOS views.

Do keep three small, reversible residues available for promoted answers:

- **axis capsule** — compact answer-shape residue naming the axes that identify cells, the base grain, the measure family, attached qualifiers such as unit/status/privacy/exactness, and the sparse/dense/absence posture. It is smaller than a global datacube schema.
- **layout aperture** — compact layout residue naming any physical layout, partition, sort, columnar transport, retained tier, or sparse/dense representation that materially shaped the returned answer. It is smaller than a storage architecture.
- **lineage facet** — compact provenance residue naming enough source cuts, plan/run identifiers, derivation recipe, and promotion context to rerun, diff, or downgrade the answer. It is smaller than a workflow engine.

## Brilliant ideas to steal now

- **Data-structure definition without data-architecture constitution** — W3C-style component separation can help describe an answer without deciding the backing engine.
- **Hidden layout, visible consequence** — Iceberg-style hidden partitioning is healthy, but if a layout/tier choice changes comparability, the answer needs a layout aperture.
- **Plan receipt, not plan monarchy** — Substrait-style plan semantics are useful at boundaries; the plan receipt should be optional and severable from Ward's core noun set.
- **Tiny interchange interfaces with non-goals** — Arrow's discipline is a model for any Ward export: describe crossing shape precisely and refuse to absorb unrelated responsibilities.
- **Facet-sized lineage** — OpenLineage's facet extensibility is a good pattern for Ward answer provenance, provided the facet does not become an orchestration dependency.
- **Sparse absence witness** — TileDB's dense/sparse distinction echoes Ward's existing gap, fill, privacy, and suppression work: absence posture belongs in the answer, not in the chart legend alone.
- **Axis capsule before cube registry** — promote answer-shape facts after repeated specimens, not because one attractive schema exists.

## Still-not-yet decisions

- Whether an axis capsule becomes a first-class Ward object or remains a specimen/promotion checklist.
- Whether layout aperture should be required for every materialized answer or only when layout/tier choices affect comparability, replayability, or authority.
- Whether lineage facet should reference a native Ward receipt, an OpenLineage-like event, a SlopOS diagnostic bundle, or a smaller local handle.
- Whether Ward should later grow a canonical measure-card schema, or keep importing measure semantics from view-scoped SlopOS query surfaces.
- Whether arrays, relational tables, logs, object manifests, or columnar batches should be treated as coequal sources or normalized into one canonical internal shape.

## Process note

Pass LX intentionally adds language, not lock-in. The next healthy move is to pressure-test these nouns against SlopOS D-ATTRFS snapshot queries, ViewFS handle/manifest surfaces, Harbor boundary facts, Schell command receipts, Steward lifecycle receipts, and Foundry off-native realization before any registry or schema hardens.
