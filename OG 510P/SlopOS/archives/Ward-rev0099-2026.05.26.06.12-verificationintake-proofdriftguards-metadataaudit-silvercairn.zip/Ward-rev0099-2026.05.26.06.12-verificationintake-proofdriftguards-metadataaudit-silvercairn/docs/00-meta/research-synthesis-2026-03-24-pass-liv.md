# Research synthesis — pass LIV

This pass keeps Ward decision-light and adds another datacube discipline: **sampling semantics are part of result meaning, not just a speed knob.**

## What the past says we must learn
1. **Block sampling is not row sampling, and it can be biased.**  
   BigQuery's `TABLESAMPLE SYSTEM` docs say sampling works by randomly selecting a percentage of data blocks and reading all rows in those blocks. The docs also say results can differ on each run, that smaller tables can collapse to a single block, and that partitioned or clustered tables tend to produce more biased samples than non-partitioned, non-clustered tables. Ward should steal the constitutional lesson: a sampled preview needs to say whether it was block-shaped, not let a “10% sample” title impersonate row-level randomness (`EXT-BIGQUERY-TABLESAMPLE-2026`).

2. **Two-stage sampling is a real design option, not a hidden implementation detail.**  
   BigQuery also documents combining `TABLESAMPLE SYSTEM` with `WHERE rand() < K` to trade cost against more row-like randomness. Ward should steal the humility: one fast recurring preview may be “cheap block sample plus row filter,” and that selection story belongs in the result meaning rather than ambient folklore (`EXT-BIGQUERY-TABLESAMPLE-2026`).

3. **Sampling stage changes the answer.**  
   DuckDB's sampling docs say `TABLESAMPLE` samples directly from a named table while `USING SAMPLE` after the full `FROM` clause samples the entire join result instead. Ward should steal that as a durable datacube law: “sample before join” and “sample after join” are different questions, not equivalent implementation plans (`EXT-DUCKDB-SAMPLES-2026`).

4. **Sampling family changes repeatability and variance.**  
   DuckDB exposes `reservoir`, `bernoulli`, and `system` sampling, says percentage samples are probabilistic unless a seed is specified, and warns that even a fixed seed only guarantees the same sample when multithreading is disabled. It also says `system` sampling operates on vectors and has much higher variance for small datasets. Ward should steal the honesty, not the engine: a sample-backed surface should say what family it used and whether reruns are expected to reproduce the same subset (`EXT-DUCKDB-SAMPLES-2026`).

5. **Deterministic sampling keys are a brilliant join-preserving trick.**  
   ClickHouse's `SAMPLE` docs say sampling is deterministic, works consistently across tables that share the same sampling key, and therefore lets samples participate in joins and subqueries without each table choosing a different hidden slice. Ward should absolutely steal this idea: if a future promoted preview depends on a consistent sampled population across tables, that should be explicit selection posture rather than luck (`EXT-CLICKHOUSE-SAMPLE-2026`).

6. **Approximate totals need visible correction rules.**  
   ClickHouse also says aggregate values are not corrected automatically under `SAMPLE k`, shows manual multiplication for counts, and offers `_sample_factor` for `SAMPLE n`. Ward should steal that as a warning: once a surface starts extrapolating from sampled rows, the correction rule becomes part of meaning, not a display trick (`EXT-CLICKHOUSE-SAMPLE-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal sample family, one mandatory fixed-seed rule, one cross-engine preview layer, or one extrapolation policy for all recurring questions.

For now, keep three more separations visible and let later specimens force promotion:
- **sample witness** — explicit statement of the sampling family, rate/target size, and any extrapolation or correction rule.
- **selection stage** — visible statement of whether sampling happened on base rows, one side of a join, the joined result, or some other reduced population.
- **repeatability lane** — visible statement of whether reruns are expected to reproduce the same subset, differ probabilistically, or remain key-stable only under certain execution conditions.

## Why these separations are worth stealing
- A **sample witness** stops a fast preview from impersonating a replayable exact frozen result.
- A **selection stage** stops “same query, different placement of sampling” from masquerading as one stable semantic contract.
- A **repeatability lane** stops seeded, deterministic-key, and non-repeatable previews from borrowing each other's authority.

## Brilliant ideas to steal now
- **key-stable sample** — deterministic subset selection keyed so related tables can be sampled compatibly.
- **block-plus-row sampling** — cheap coarse sample with optional row-level refinement when full scans are too expensive.
- **sample witness** — compact residue describing family, fraction/target, and correction rule.
- **selection stage** — explicit note about whether sampling happened before or after joins and filters.
- **repeatability lane** — explicit note about seed, determinism, and rerun expectations.
- **fast preview is weaker than frozen truth** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward should ever bless one universal sampling family across engines.
- Whether a deterministic sampled preview deserves its own named truth class distinct from exactness class and sketch class.
- Whether extrapolation from sampled counts should ever be publishable without a stronger correction witness than the initial specimen needs.
- Whether sample witnesses belong on all quick previews or only on promoted recurring surfaces.
