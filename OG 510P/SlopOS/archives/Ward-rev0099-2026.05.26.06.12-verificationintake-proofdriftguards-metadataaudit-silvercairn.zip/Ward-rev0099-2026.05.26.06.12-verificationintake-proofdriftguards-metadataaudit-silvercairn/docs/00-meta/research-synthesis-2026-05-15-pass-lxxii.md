# Research synthesis — pass LXXII

Pass LXXI separated learning, feedback, holdouts, and taint. Pass LXXII follows the next failure mode: once a SlopOS-facing cube can answer observed questions, users and agents will ask it to forecast, simulate, synthesize, stress, and answer counterfactual questions. Those are valuable, but they are not the same truth as an observed answer capsule. A scenario answer can be brilliant and still be conditional, generated, or not identified.

The restraint rule still holds. Ward should not choose a forecasting library, simulation engine, causal graph language, synthetic-data generator, model registry, notebook format, scenario store, random-number API, uncertainty grammar, dashboard product, or experiment platform as the SlopOS datacube constitution. SlopOS is still design-phase, and its D-CAPSHELL/D-NONDET posture already warns that host time, entropy, and learned suggestions must not become ambient authority. The right Ward move is to name answer-level residues that keep **observed**, **forecast**, **simulated**, **synthetic**, and **counterfactual** material separate.

## What the past says we must learn now

1. **Forecasts are cutoff/horizon claims, not future observations.** Prophet's diagnostics frame cross-validation around historical cutoffs, training periods, forecast horizons, and predictions compared with actual values (`EXT-PROPHET-DIAGNOSTICS-2026`). scikit-learn's `TimeSeriesSplit` exists because ordinary cross-validation can train on future data and evaluate on past data, which is inappropriate for time-ordered data (`EXT-SKLEARN-TIMESERIESSPLIT-2026`). Ward should steal the posture: a forecast-like cube answer needs a horizon, cutoff set, training cut, and backtest posture before anyone reads it as evidence.

2. **Leakage turns impressive accuracy into a flattering artifact.** scikit-learn's common-pitfalls docs define data leakage as using information unavailable at prediction time when building the model, creating overly optimistic performance estimates (`EXT-SKLEARN-DATA-LEAKAGE-2026`). Ward already learned point-in-time lessons in pass LXXI; pass LXXII extends them to scenario runs, forecasts, synthetic data, and what-if comparisons.

3. **Causal counterfactuals require assumptions and refutation, not just contrast.** DoWhy's current effect-estimation workflow separates modeling assumptions, identification, estimation, and robustness/refutation checks (`EXT-DOWHY-CAUSAL-EFFECTS-2026`). Its refutation docs are explicit that observational causal analyses cannot be proved correct, but can be challenged through robustness tests (`EXT-DOWHY-REFUTERS-2026`). Ward should not let “if we had changed X, Y would have happened” appear unless the counterfactual warrant names whether the claim is identified, merely simulated, or refused.

4. **Randomness is reproducibility material, not ambient truth.** NumPy's `SeedSequence` documentation treats entropy mixing and spawning as reproducibility and independence machinery for bit generators (`EXT-NUMPY-SEEDSEQUENCE-2026`). SlopOS's D-NONDET posture similarly refuses ambient clock/RNG inheritance. Ward should steal the idea without choosing NumPy: scenario runs with stochastic elements need seed/randomness receipts and nondeterminism posture, but a seed does not make a scenario true.

5. **Synthetic data needs validity, quality, and privacy evidence.** SDV's diagnostic report checks format and validity for synthetic data (`EXT-SDV-DIAGNOSTIC-2026`), while SDMetrics quality reports compare statistical similarity between real and synthetic datasets (`EXT-SDMETRICS-QUALITY-2026`). SDMetrics privacy docs emphasize that privacy metrics are based on patterns across real and synthetic data and must be judged for the project (`EXT-SDMETRICS-PRIVACY-2026`). NIST's SDNist report tool evaluates utility and privacy of synthetic datasets and produces summary reports over those metrics (`EXT-NIST-SDNIST-2022`). Ward should not treat “synthetic” as privacy-clean, production-valid, or observation-equivalent by default.

6. **Synthetic buckets were the seed; synthetic worlds are the escalation.** Earlier Ward passes already separated synthetic buckets, fill witnesses, interpolation posture, degradation receipts, and feedback taint. The new risk is larger: generated rows, simulated futures, counterfactual cohorts, synthetic exemplars, imputed labels, and stress-test worlds can all be useful while remaining non-observed.

7. **Scenario output is often rhetorically stronger than evidence.** Forecast charts, “saved money if” cards, synthetic row examples, and simulated incidents can feel concrete. Ward must therefore preserve the weaker truth class in render contracts, egress receipts, agent summaries, threshold witnesses, and action warrants.

8. **SlopOS design-phase humility matters most here.** Because SlopOS's own query, model, simulation, observation, and ACP seams are not frozen, Ward should avoid choosing a universal scenario substrate. It should preserve scenario honesty as answer residue until repeated specimens prove what belongs in SlopOS proper versus Helm, Foundry, Harbor, or a future ML/simulation companion.

## Resulting Ward move

Do **not** decide yet:

- one forecasting package, simulator, synthetic data generator, causal-inference library, uncertainty renderer, random-number substrate, notebook engine, or scenario catalog;
- one notion of “scenario,” “baseline,” “intervention,” “forecast,” “stress test,” “digital twin,” “synthetic row,” or “counterfactual” across SlopOS;
- one backtest metric, horizon vocabulary, calibration test, uncertainty interval, refutation suite, privacy metric, or synthetic-data quality threshold;
- one rule that a successful backtest permits action, that a causal estimate authorizes policy, that synthetic rows can train models, or that simulated incidents can become observed incidents;
- one global recall or correction protocol for scenario screenshots, exported forecasts, agent-written what-if summaries, or synthetic exemplars.

Do add three small, reversible residues for datacube scenario hygiene:

- **scenario capsule** — compact residue for one forecast, simulation, stress test, synthetic augmentation, imputation, what-if, sensitivity, or counterfactual answer. It names the observed source cuts, scenario class, assumption set, intervention vector, horizon/window, baseline, model/simulator/generator identity, parameter cut, seed/randomness/nondeterminism posture, backtest or diagnostic evidence, uncertainty envelope, allowed-use class, refusal/degradation posture, and non-observed status. It is smaller than a simulation platform and stronger than a chart subtitle.
- **counterfactual warrant** — compact evidence that a “would have happened if” claim is allowed, identified, merely simulated, or refused. It names treatment/intervention, target population, outcome, causal assumptions or graph handle, estimand/identification status, estimator/method posture, observed support, refutation/sensitivity checks, interference/spillover notes, unmeasured-confounding caveats, action-warrant limits, and review posture. It is smaller than a causal DSL and stronger than a narrative contrast.
- **synthetic boundary** — compact boundary around generated, imputed, simulated, forecasted, sampled, cloned, stress-test, or synthetic rows/cells/features/exemplars. It records generation method, source cut, privacy/quality/validity diagnostics, allowed joins/rollups/training/evaluation/export uses, label visibility, row/cell marking, naturalization prohibition, and destruction/retention/refusal posture. It is smaller than a synthetic-data governance platform and stronger than “test data.”

These residues sit beside earlier nouns. Scenario capsules consume answer capsules, state-cut witnesses, freshness envelopes, uncertainty envelopes, budget gates, learning loop ledgers, holdout witnesses, render contracts, egress receipts, correction horizons, concept anchors, and federation pacts. Counterfactual warrants consume delta anatomies, attribution rails, action warrants, holdout witnesses, feedback taint fences, and quality witnesses. Synthetic boundaries feed privacy posture, exemplar fences, degradation receipts, projection curtains, learning loop ledgers, and revocation fences.

## Brilliant ideas to steal now

- **Scenario is a truth class.** Every what-if answer should say whether it is observed, forecast, simulated, synthetic, counterfactual, stress, imputed, sensitivity, or mixed.
- **Cutoff beats vibes.** Forecast-like answers need training cuts, cutoffs, horizons, and backtest posture.
- **No leakage heroics.** A scenario that uses post-decision corrections or future semantic bridges must be labeled as hindsight, not predictive evidence.
- **Refutation is not proof, but absence of refutation is worse.** Counterfactual claims need assumptions and failed/blocked refuters visible before they support consequence.
- **Seeds are receipts, not authority.** Reproducible stochastic output is still generated output.
- **Synthetic is not privacy-clean by name.** Validity, quality, utility, and privacy reports travel with generated material.
- **No naturalization of generated rows.** Synthetic/simulated/forecasted cells may be useful, but they must not become observed fact by crossing a dashboard, export, join, or training boundary.
- **Stress tests are review material.** Extreme synthetic scenarios can tune preparedness, but they are not incident counts.
- **Forecast errors deserve lineage.** Old forecasts should remain reviewable with their cutoff and horizon, not rewritten when reality arrives.
- **Action still needs a warrant.** A scary scenario capsule can open review, not directly page, quarantine, retrain, or rewrite policy.

## Candidate specimen pressure

Use a SlopOS reviewer question such as: “If we had tightened provider-risk thresholds two months ago, how many providers would have been quarantined, and what should we expect next quarter if partner attestation failures continue?” The specimen should include an observed historical answer, a what-if threshold counterfactual, a forecasted future window, synthetic stress-test rows, a partially contaminated holdout, and an eager agent summary that tries to propose ACP actions.

The right answer should preserve at least five separations:

1. observed historical cells versus simulated/counterfactual/synthetic cells;
2. forecast horizon evidence versus current source authority;
3. counterfactual identification versus narrative explanation;
4. stochastic reproducibility versus truth;
5. review-only scenario material versus consequence-grade action warrant.

## Open questions kept open

- Whether scenario capsules live in Ward, Helm, SlopOS, Foundry, or a future simulation/forecast companion.
- Whether counterfactual warrants should ever become machine-checkable enough to block/allow action, or remain review evidence.
- Whether synthetic boundaries attach to rows, cells, features, answer capsules, exported files, or all of the above.
- Which scenarios can be cached/materialized, and whether scenario reruns deserve their own invalidation receipts.
- How much of a scenario's model/generator internals can be exposed without leaking private source data, policy, or partner participation.
- Whether old scenario capsules should be corrected, superseded, or left as historically reviewable promises that later reality can score.

## Added pass LXXII surfaces

- `docs/00-meta/slopos-companions-evaluation-2026-05-15-pass-lxxii.md`
- `docs/30-architecture/specimen-flow-69-scenario-capsule-counterfactual-warrant-and-synthetic-boundary.md`
