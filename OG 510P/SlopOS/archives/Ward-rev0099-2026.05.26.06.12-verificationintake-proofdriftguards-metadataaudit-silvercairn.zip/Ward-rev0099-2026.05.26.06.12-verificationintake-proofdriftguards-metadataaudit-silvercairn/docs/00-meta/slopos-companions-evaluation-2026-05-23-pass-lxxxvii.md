# SlopOS companions evaluation — pass LXXXVII

## Question

Can Ward represent a current governance lineage after release, follow-up, and transfer receipts without letting “current head” become action authority?

## SlopOS seam

SlopOS can attach governance evidence to portal, CH-AREF, tool, export, action, and resume/recheckpoint paths. Those paths can easily observe different receipt subsets:

- a portal may show an old release;
- a CH-AREF attachment may include a follow-up but not a later transfer;
- a tool may see a rotated status pointer through an old channel;
- a resume path may replay a compacted or forked subset;
- an export path may flatten a disputed branch into a single current badge.

## Pass LXXXVII answer

Ward now introduces a chain-integrity receipt that lets SlopOS demand:

- ordered release/follow-up/transfer lineage;
- byte digests for every member;
- member validator replay;
- source release parity;
- recipient/purpose/source-item/projection-policy parity;
- transfer dependency on the cited latest follow-up;
- old status channel invalidation;
- canonical head or explicit fork hold;
- no-authority labels and forbidden-effect preservation.

## Companion pressure

- **ViewFS** should render `canonical_head_recorded`, `successor_pending_recheck`, and `fork_detected_hold` distinctly.
- **Schell** should preserve the member chain and minimize public fork evidence.
- **Harbor** should refuse to use forked or successor-pending chains as recompute/correction support.
- **Helm** should display current status pointers without promoting them to approval.
- **Foundry** should treat concept/crosswalk authority as absent until chain replay succeeds.
- **Steward** should not let component ownership override chain status.
- **SlopOS** should not attach released governance evidence to CH-AREF, export, action, learning, portal, or tool paths unless the chain-integrity receipt is current and non-forked for that purpose.

## Remaining risk

Chain integrity still depends on available member bytes. The next seam is likely consumer-side chain caching: a downstream cube can cache a valid chain, then miss a later fork or status-channel rotation.
