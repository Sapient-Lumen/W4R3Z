# Doc-index audit/refactor — pass XCV

## Finding

The governance checker suite was well indexed after rev0094, but the human-facing documentation map still relied on manual edits. As Ward accumulates receipt families, a stale docs map can mislead a reader or LLM into loading the wrong latest specimen or omitting the current pass.

## Refactor

Added `tools/check_doc_index_integrity.py` and wired it into `make check`.

The checker verifies:

- current revision appears in `docs/README.md`, `README.md`, and `START_HERE.md`;
- current summary appears in `README.md` and `START_HERE.md`;
- latest markdown files listed in `REVISION-RECEIPT.json` appear in `docs/README.md`;
- latest surfaces from `SURFACE-STATUS.json` are present in `docs/README.md`;
- latest specimen is present in both `docs/README.md` and `docs/30-architecture/specimen-flow-index.md`.

This is intentionally not a style checker. It is a drift guard for the public map of the cube.
