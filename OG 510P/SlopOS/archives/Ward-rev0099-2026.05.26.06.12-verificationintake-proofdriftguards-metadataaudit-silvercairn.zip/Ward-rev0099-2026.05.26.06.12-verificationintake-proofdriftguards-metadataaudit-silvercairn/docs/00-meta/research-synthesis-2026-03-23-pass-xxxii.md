# Research synthesis — pass XXXII

This pass keeps Ward cautious and learns one more thing from schema-evolution systems: **writer meaning, reader meaning, field identity, and compatibility posture are different truths.**

## Outside lessons
1. **Writer and reader views are separate contracts, not one timeless object truth.**  
   Avro says the original writer's schema must travel with the data, and schema resolution explicitly distinguishes the writer's schema from the reader's schema. When records evolve, writer-only fields may be ignored, reader-only fields may be filled from defaults, aliases may rewrite names for reading, and documentation text is not part of parse meaning. Ward should steal the restraint: one published cut may have one exact writer view even when later readers decode it through a different local view.

2. **Stable field identity matters more than labels or order.**  
   Iceberg says schema evolution should be free of side effects, uses unique IDs to track each field, and requires projection by field id because names and order may change after a file is written. It also warns that name-based tracking can accidentally un-delete reused names and position-based tracking can shift meaning when fields move. Ward should steal that humility: field identity should stay smaller than label text, display order, or one temporary alias map.

3. **Unknown and absent are not the same thing, and some transcodings destroy that difference.**  
   Proto3 preserves unknown fields in binary form, says deleted field numbers should be reserved so they are not reused later, and distinguishes implicit from explicit presence, recommending `optional` for proto3 basic types. It also warns that JSON/text transformations can lose unknown fields. Ward should therefore keep unknown residue, absent-vs-explicit-default pressure, and retired-slot hygiene visible instead of pretending every decode produced a complete timeless shape.

4. **Compatibility is a chosen lane, not an intrinsic property of one artifact.**  
   Schema Registry versions schemas per subject and makes backward, forward, full, and transitive compatibility explicit policy choices. Upgrade order depends on which compatibility type was chosen. Ward should steal that lesson too: if one local result depends on a compatibility contract or translation policy, that lane should be visible rather than smuggled in as invisible parser folklore.

## Resulting Ward move
Do not decide yet whether Ward's long-term evolution story is Avro-like, Proto-like, Iceberg-like, registry-backed, sidecar-translated, inline-versioned, or something else.

For now, preserve four separations and let later specimens force promotion:
- `writer view` versus the exact bytes/cut that were authored;
- `reader view` versus the local schema or interpretation expected by one consumer;
- `field identity` versus label/order/alias accidents;
- `compatibility lane` versus one fake universal "it just parses" story.

Keep nearby, but not yet promoted, a few smaller ideas:
- `presence mode` for absent versus explicit-set pressure;
- `translation witness` for evidence that one view was intentionally projected into another;
- `retired slot` for field/ordinal identities that must not be silently reused.

## Fresh ideas worth stealing
- **writer view** — exact authored schema/shape bound to one cut.
- **reader view** — consumer-local expected schema/shape used for decoding or projection.
- **field identity** — stable identity for one fact independent of current label or order.
- **compatibility lane** — explicit policy for how newer/older views may interoperate here.
- **presence mode** — visible distinction between absent, explicit default, and explicit set.
- **translation witness** — compact residue that one view was intentionally projected into another.
- **retired slot** — field or ordinal identity that must not be silently reused.
- **label weaker than identity** — a standing anti-regrowth rule.
