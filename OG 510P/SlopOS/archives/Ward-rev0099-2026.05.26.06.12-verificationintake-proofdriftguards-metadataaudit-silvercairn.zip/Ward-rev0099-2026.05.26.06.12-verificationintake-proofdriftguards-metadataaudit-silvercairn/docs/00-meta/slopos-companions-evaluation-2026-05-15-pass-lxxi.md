# SlopOS companion evaluation — pass LXXI

Pass LXXI evaluates Ward's datacube against SlopOS and the included companion cubes with one question: when cube answers cause consequences, can their aftermath be collected for learning without creating circular proof, hidden policy widening, or self-fulfilling metrics?

## SlopOS pressure

SlopOS is still design-phase, so the datacube should avoid binding to one ML platform, feature store, experiment engine, recommender, agent memory, or retraining scheduler. The safe pressure from the included SlopOS snapshot is narrower and stronger:

- **D-CAPSHELL learn-mode posture** is the clearest direct warning. It keeps learn mode observational only, no relaxed enforcement path, no auto-edit, no auto-approve, no auto-rerun, stage-local suggestions, and no ambient policy memory. Ward should steal this posture for cube learning: a learning loop ledger can recommend review, but it cannot widen authority or mutate thresholds by being present.
- **D-EXPLAIN posture** keeps CH-CAPDIFF/CH-RECEIPT bounded, digest-first, action-bound, and non-authoritative. Ward should treat reviewer explanations, acceptances, denials, and “why this action” summaries as feedback material only after a feedback taint fence records their intervention lineage and redaction posture.
- **CH-ATTRQ** is snapshot-first and handle-returning in v0. That helps Ward refuse hidden “latest feature” retrieval during training or evaluation; a learning loop must pin query/view/snapshot cuts and not silently use future attribute state.
- **CH-FLIGHTPOL** shows bounded observation streams and retention caps. Ward should not require a global training/event lake; learning loops can digest-reference bounded retained evidence and say when capture was incomplete.
- **CH-HEALTHREC** and other SlopOS receipts emphasize non-authoritative health/evidence records. Ward should mirror that: a model monitor, drift check, or evaluation report is evidence, not permission to deploy or retune.
- **CH-FADAPT v1** carries request-context correlation while remaining non-authoritative. Ward can use similar correlation discipline to link answer, action, exposure, feedback, and learning attempt without turning correlation into authority.
- **D-BUDGET/D-METER** already reject ambient current payer and force explicit spend authority. Learning loops should carry budget/payer posture for data collection, evaluation, privacy spend, and retraining rather than hiding them in background optimization.
- **CH-ACPOUT / ACP preconditions** remain exact, veto-only, and non-authoritative in the adjacent SlopOS surfaces. A consequence receipt may become an example, but it cannot authorize replay or train a policy that bypasses those exact preconditions.

## Companion pressure

- **Helm** pushes user-facing review, dashboards, workbenches, and exported artifacts. Its pressure on Ward is that reviewer choices and agent summaries are interface-shaped. They need feedback taint fences before becoming labels.
- **Foundry** pushes semantic spines, serving lanes, and pinned cuts. Its pressure is that feature/label definitions need semantic and serving-lane cuts, not just current field names.
- **Steward** pushes reconciliation and split/merge posture. Its pressure is that labels may be repaired or reclassified later; learning datasets need label maturity and correction horizon linkage.
- **Harbor** pushes temporal witnesses and evidence-code caution. Its pressure is that “known at the time” and “later discovered” must remain separate in training and evaluation cuts.
- **ViewFS** pushes display aliases, folder ghosts, and result surfaces. Its pressure is that what a user saw or clicked may be projection-shaped, not source truth.
- **Schell** pushes activation receipts and environment epochs. Its pressure is that rollout cohorts, activation states, and environment changes can shape feedback and must be visible in holdout witnesses.

## Ward boundary for this pass

Ward should own the learning-loop hygiene residue only while it remains about trust meaning of datacube answers: answer material, action consequences, feedback taint, holdout evidence, label maturity, and promotion/refusal posture. Ward should not own training infrastructure, model cards, model registry, optimizer loops, feature serving, human-review UI, or experimentation product design.

## Tests this pass should keep honest

1. A cube answer triggers a notification; the later click-through rate is not treated as neutral preference evidence.
2. A quarantine recommendation reduces risky events; the reduction is not attributed to model correctness without a holdout witness or counterfactual posture.
3. A reviewer rejects a recommendation; the rejection is not blindly labeled “false positive” without context and label maturity.
4. An agent summary is copied into an evaluation dataset; the egress receipt and feedback taint fence follow it.
5. A threshold is retuned after a drift alert; the learning loop ledger records the evidence and refuses auto-mutation without review.
6. A backfill repairs old labels; affected training/evaluation cuts are fenced and old model comparisons become bridge-required or invalid.
7. A clean holdout becomes contaminated by a global UI change; the holdout witness degrades rather than silently remaining valid.
8. A bandit-like recommendation wants to use observed outcomes; missing propensity/exposure evidence causes refusal or review-only posture.

## Evaluation outcome

Promote **learning loop ledger**, **holdout witness**, and **feedback taint fence** as candidate residues for the next Ward revision. They fit the existing datacube posture because they preserve optionality, add refusal surfaces, and keep SlopOS's observational/non-authoritative learn-mode lesson intact.
