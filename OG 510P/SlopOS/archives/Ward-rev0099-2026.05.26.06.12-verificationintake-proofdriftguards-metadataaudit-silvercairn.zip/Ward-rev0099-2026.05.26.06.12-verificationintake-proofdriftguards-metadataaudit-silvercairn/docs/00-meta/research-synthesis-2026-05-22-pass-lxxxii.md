# Research synthesis — 2026-05-22 pass LXXXII

Pass LXXXII studies a narrow question: once Ward has governance handoff packets, decision events, and consumer receipts, what breaks when a downstream surface returns **many** of them at once?

## External pressure

AuthZEN is the most direct pressure. Its Authorization API separates single access evaluation, multiple evaluations, and search APIs. The multiple-evaluation request treats the entries as distinct requests, and its search section describes paginated discovery of permitted subjects/resources/actions. It also warns that pagination is not necessarily an atomic snapshot and that a follow-up page must keep request entities and pagination parameters identical (`EXT-AUTHZEN-AUTHORIZATION-API-2026`).

OpenFGA's relationship-query docs add a second pressure: check, read, expand, list objects, and list users are different query shapes with different limits. ListObjects returns objects of a given type for which a user has a relationship; that is a useful access-aware list, not a universal authority certificate (`EXT-OPENFGA-RELATIONSHIP-QUERIES-2026`).

OPA decision logs remain useful for correlation and audit/debug. They include decision identifiers, inputs, queried policy, bundle metadata, and result-like material, but their purpose remains logging and offline diagnosis, not granting action authority (`EXT-OPA-DECISION-LOGS-2026`).

CloudEvents and its distributed tracing extension pressure Ward toward source/type/id/subject/time and trace context fields, but they also reinforce that event correlation and trace propagation are operational affordances, not governance authority (`EXT-CLOUDEVENTS-SPEC-2026`, `EXT-CLOUDEVENTS-DISTRIBUTED-TRACING-2026`).

Kafka-style compaction remains relevant because batch/search results often come from materialized views. A compacted stream can preserve a latest view while losing enough history to make old governance decisions historical-only (`EXT-CONFLUENT-KAFKA-LOG-COMPACTION-2026`).

## Synthesis

Ward should not add a general search protocol. It should add a **batch/search receipt** that proves aggregation did not change meaning.

The receipt is intentionally weaker than a grant. It asks:

- did each member still validate as a consumer receipt?
- did member state, replay status, projection class, downgrade reasons, and forbidden effects survive aggregation?
- did the aggregate expose mixed state rather than hiding it?
- did search pagination disclose omissions and bind cursors to query/projection basis?
- did the aggregate avoid high-consequence effects?

## Design choice

The pass treats `ward.governance.batch-search-receipt.v0` as a projection/reconciliation receipt, not a first-class authority noun.

The key rule is:

> A batch/search result is never stronger than its weakest relevant member, and it must not hide which member is weak.

## Fixture pressure

The new checker validates four positive fixtures and twelve negative fixtures. The strongest negative tests are:

- mixed state rendered as a green badge;
- route-only member upgraded to consequence-grade;
- forbidden-effect union dropped;
- public projection of restricted break-glass member;
- partial search result without gap disclosure;
- cursor not bound to query digest;
- aggregate high-consequence effect;
- raw authority count claim.

## Remaining open pressure

Ward still needs future pressure around:

- cross-page reconciliation over long-running queries;
- batched packet replay rather than batched consumer-receipt replay;
- sealed count disclosure without existence-oracle leaks;
- differential privacy/noisy counts for governance search;
- whether a ViewFS trusted-path card should show batch mixed-state posture directly.
