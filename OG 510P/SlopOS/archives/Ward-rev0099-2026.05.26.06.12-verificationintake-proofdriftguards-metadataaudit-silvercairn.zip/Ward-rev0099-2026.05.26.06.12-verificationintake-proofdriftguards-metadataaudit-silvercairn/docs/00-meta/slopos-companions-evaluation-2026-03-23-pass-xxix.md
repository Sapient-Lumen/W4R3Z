# SlopOS / companions evaluation — pass XXIX

This pass keeps Ward embryonic while stealing one more useful habit from the neighbors: **make “current enough” explicit, and make correction paths visible instead of silent.**

## What the current cubes still teach
- **SlopOS** already does the important discipline move of pinning exact postures instead of letting convenient ambient behavior masquerade as design. Its ordering-token posture keeps one small witness seam visible and refuses to silently grow a general sequencing service. Ward should steal the analogous restraint: a completeness frontier is a small claim about intake progress, not a hidden promise that the world is closed.
- **SlopOS** also keeps compiled/current artifacts visibly smaller than the source logic that produced them. The config-as-compiled-artifact ADR is the right reminder for Ward that a projected “current trust answer” may be provisional or derived without being the whole history.
- **Steward** remains a useful warning that continuity aids are smaller than durable truth. Ward should keep provisional views and correction deltas equally humble.
- **Harbor** still reminds the ecology that quick callback/delivery success is weaker than durable local effect. Ward should now add the parallel warning that an early answer is weaker than a frontier-backed answer whose correction window has actually closed.

## Current recommendation
Keep Ward open on whether frontier/correction semantics live inline on result objects, beside a watch/history lane, or in a separate projection sidecar.

The next wise move is one specimen plus one tiny hygiene upgrade:
1. **completeness frontier** instead of ambient “we probably saw enough”; 
2. **lateness budget** instead of hidden forever-open or forever-closed correction policy; 
3. **provisional view** instead of fake final-by-default; 
4. **retraction delta** instead of silent historical rewrite; 
5. **unique-ID lint** so repeated passes cannot quietly duplicate question/pressure identities.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should still avoid freezing one watermark algorithm, one versioned-store requirement, one correction engine, or one universal “finality frontier” object into the repo.
The smaller steal is enough for now:
- keep `REVISION-RECEIPT.json` honest about which new pass/specimen surfaces landed this revision,
- keep the load-bearing source register and review queue honest about the new living sources,
- and fail the revision if question/pressure ledgers reuse IDs instead of preserving archive identity.

## Still-not-yet decisions
- Whether `completeness frontier` belongs in Ward proper or in an adjacent history/observation cube.
- Whether `lateness budget` should be durable Ward vocabulary or remain projection-local policy.
- Whether `provisional view` deserves durable vocabulary or stays a label on specific result families.
- Whether `retraction delta` should be first-class archive residue or remain an implementation-side correction idiom.
- Whether Ward should ever standardize one frontier carrier, or only insist that “current enough” must be explicit.
