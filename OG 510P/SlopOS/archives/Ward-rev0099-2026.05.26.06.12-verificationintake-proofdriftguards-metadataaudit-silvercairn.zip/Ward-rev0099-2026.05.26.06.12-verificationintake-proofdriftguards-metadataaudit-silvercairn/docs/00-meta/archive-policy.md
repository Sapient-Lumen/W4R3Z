# Archive policy

- Prefer editing existing files over spawning near-duplicates.
- Keep one canonical document per concept family whenever possible.
- Ledgers should carry open uncertainty; prose should not pretend unsettled areas are decided.
- Outside systems are cited as pressure sources, not as templates to clone.
- When outside pressure becomes load-bearing for a new specimen noun, update the load-bearing source register in the same revision.
- When a moving or recently finalized outside source shapes a new durable noun, keep the source review queue aligned in the same revision.
