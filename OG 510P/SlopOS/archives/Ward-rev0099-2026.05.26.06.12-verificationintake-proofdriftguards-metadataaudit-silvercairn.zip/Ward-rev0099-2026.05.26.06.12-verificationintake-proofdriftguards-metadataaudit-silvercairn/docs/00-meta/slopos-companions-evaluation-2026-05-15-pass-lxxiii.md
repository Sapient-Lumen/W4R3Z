# SlopOS and companion evaluation — pass LXXIII

Pass LXXIII evaluates Ward's emerging datacube posture against model-mediated query pressure: natural-language questions, generated SQL, agent tool calls, semantic-layer requests, repair loops, and model-written summaries. The key question is not “which AI data assistant should SlopOS use?” The question is whether a SlopOS-facing answer can remain honest when the path from user words to query execution is partly model-mediated.

## SlopOS fit

SlopOS is still design-phase, which is exactly why Ward should avoid selecting a language-model runtime, query compiler, SQL validator, tool protocol, or semantic-layer product. The included SlopOS snapshot already contains adjacent lessons:

- **Snapshot/view discipline beats ambient database access.** Intent bindings should name the view/scope cut before a model sees schema, examples, or tools.
- **D-CAPSHELL learn-mode is observational only.** A model-mediated assistant can propose, summarize, or ask for clarification, but it cannot learn new authority or widen contracts from a successful chat turn.
- **D-NONDET rejects ambient time/entropy.** Model sampling, retry order, retrieved context, schema samples, and prompt construction are nondeterministic enough to deserve translation-warrant evidence when consequential.
- **D-BUDGET/D-METER keep cost/payer authority explicit.** Tool-call leashes should carry cost, row, time, egress, and detail budgets; an agent should not discover expensive or sensitive data by wandering.
- **CH-ACPOUT remains non-authoritative.** A model-written recommendation or generated query result cannot become an ACP outcome, action warrant, policy edit, or notification request by appearing in a chat.

## Companion pressure

- **Helm** will want conversational dashboards, filter follow-ups, “explain this chart” prompts, and agent summaries. Pass LXXIII says Helm can show these only when intent, translation, and tool execution are visibly weaker than the answer capsule and current authority can be rehydrated.
- **Foundry** provides semantic-spine pressure. Translation warrants should bind to semantic cards, metric cards, concept anchors, and hierarchy cuts instead of letting raw column names impersonate business meaning.
- **Harbor** provides lineage/time pressure. Intent bindings and translation warrants must preserve which time axis and source cut were asked for, not merely the one a generated query found easiest.
- **Steward** provides cause/condition caution. Natural-language “why” and “should we” questions must not let model summaries smuggle causal or action authority without attribution rails, counterfactual warrants, and action warrants.
- **Schell** provides environment/activation pressure. A model-mediated answer about activation or rollout must bind to the relevant basis card and environment epoch; schema examples from the wrong environment are not harmless.
- **ViewFS** provides context/exposure pressure. Retrieved files, examples, exports, screenshots, and saved prompts can become indirect prompt-injection or egress surfaces; tool-call leashes and egress receipts should keep them smaller than live authority.

## What Ward should absorb

1. **Intent is a residue.** A natural-language question should not disappear after SQL is generated; it should be bound to explicit metric/axis/scope/time/consequence choices and unresolved ambiguity.
2. **Translation is a warrant, not a vibe.** Generated SQL, semantic-layer calls, and tool plans need evidence of semantic coverage, policy scope, projection, static checks, invariant tests, and downgrade/refusal posture.
3. **Execution is leashed.** Model-controlled tools need capability subsets, validated arguments, budgets, result caps, approvals, retry limits, and receipts.
4. **Model summaries are derivatives.** A model-written explanation may be useful, but it cannot replace answer capsules, render contracts, egress receipts, action warrants, or learning-loop ledgers.
5. **Clarification is cheaper than repair.** For ambiguous SlopOS data questions, asking a bounded clarification is healthier than generating SQL that looks decisive.

## What Ward should not absorb yet

- No SlopOS-wide LLM, SQL agent, MCP profile, prompt format, model registry, tracing system, query validator, semantic-layer vendor, or NL-query UI.
- No rule that all natural-language queries must use semantic-layer coverage, and no rule that raw text-to-SQL is always allowed.
- No universal prompt-retention or transcript-retention policy.
- No default row cap, token cap, retry count, approval threshold, or query-complexity model.
- No guarantee that a model-generated explanation can ever be enough for high-risk action without ordinary Ward/SlopOS residues.

## Evaluation verdict

Promote **intent binding**, **translation warrant**, and **tool-call leash** only as candidate datacube residues. They improve Ward because they keep model mediation from becoming a hidden bridge between user prose and authority-bearing cube answers while preserving SlopOS's design-phase optionality.

## Immediate review checklist

Before a SlopOS-facing model-mediated answer is allowed into any consequence-grade path, verify that:

- an intent binding records the user/agent request, follow-up context, ambiguity posture, selected metric/axis/scope/time/grain, and consequence class;
- a translation warrant binds generated query material to metric cards, query contracts, semantic coverage, policy/privacy/projection checks, and expected answer shape;
- every model-invoked tool call has a tool-call leash with capability subset, arguments, budgets, effect class, approval posture, and execution receipt;
- retry/repair loops do not change the question without a new or amended intent binding;
- summaries, explanations, charts, exports, alerts, and ACP proposals rehydrate through current answer authority rather than inheriting chat fluency;
- refusal remains acceptable when the request cannot be safely translated, bounded, or executed.
