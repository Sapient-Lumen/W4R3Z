# SlopOS / companions evaluation — pass L

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **a repeated trust question should not be promoted until Ward can say what frame it used, what instant it was anchored to, and how it treated incomplete early windows.**

## What the included cubes keep teaching
- **SlopOS** is still the strongest nearby teacher because D-ATTRFS keeps querying modest: **view-scoped**, **snapshot-first**, **handle-returning**, with saved queries remaining **shell-owned manifests** and live mode **optional and bounded**. That posture reinforces the new lesson: rolling/cumulative convenience should stay smaller than result meaning, and result meaning should stay smaller than a promoted derivative.
- **ViewFS** sharpens the neighboring seam Ward needs: a **query manifest is a recipe**, not a live directory handle, evaluating against a view yields a **snapshot-first** result set, and a smart folder must not silently flip from snapshot to live mode. The datacube analogue is that window frame and anchor instant belong to the recipe/result contract, not to ambient latest-state folklore.
- **Steward** keeps teaching that remembered structure is weaker than current liveness. The analogous datacube lesson is that a running total or trailing window remains weaker than raw replayable facts unless the frame and anchor are visible.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows a “7-day rolling” line, “month-to-date” badge, or “all-time cumulative” counter, the shell should be able to say exactly what frame, anchor, and partial-window rule shaped it.

## What outside systems add to the datacube posture
- dbt's cumulative-metric docs make the first anti-lesson explicit: if no window is passed, the cumulative window is treated as infinite. Ward should borrow that as **window frame** honesty, not as a commitment to one semantic layer (`EXT-DBT-CUMULATIVE-2026`).
- BigQuery's window-function docs add the second anti-lesson: default frames are real semantics, and `ROWS` versus `RANGE` are different frame families. Ward should borrow that as **window frame** discipline, not as a decision to adopt one SQL engine while SlopOS is still moving (`EXT-BIGQUERY-WINDOW-FRAME-2026`).
- DuckDB adds the third lesson: `ROWS`, `GROUPS`, and `RANGE` frame different neighborhoods around the current row. Ward should borrow that as **frame-family honesty** for repeated questions (`EXT-DUCKDB-WINDOWS-2026`).
- Prometheus adds the fourth lesson: a range selector is explicitly relative to the current instant, and range functions can extrapolate over the full selected interval. Ward should borrow that as **anchor instant** and **partial-window posture** discipline, not as a commitment to PromQL semantics everywhere (`EXT-PROMETHEUS-RANGE-VECTORS-2026`, `EXT-PROMETHEUS-FUNCTIONS-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Every promoted rolling/cumulative question must declare a window frame before it earns dashboard authority.**
2. **Every windowed answer must say what instant or bucket edge it is anchored to.**
3. **Every early or incomplete window must declare a partial-window posture instead of borrowing comparability from mature full windows.**
4. **Ward should not let one pretty “7-day” or “to-date” label quietly erase the difference among moving, cumulative, peer-based, and snapshot-only semantics.**
5. **Ward should not bless one giant rolling-window constitution while SlopOS and its siblings are still actively discovering their shell, manifest, result, and live-feed seams.**

## Specific anti-lessons from the past
- Do **not** let omitted frame clauses silently choose all-time cumulative semantics.
- Do **not** let a rerun at a later instant masquerade as the same windowed answer.
- Do **not** let partial early windows pretend they are directly comparable with full mature windows.
- Do **not** confuse a chart label like “7-day rolling” with an adequately specified truth contract.
- Do **not** pick one universal rolling-window grammar or semantic-layer constitution just because a few repeated questions are emerging.

## What Ward should probably steal next
- a **window frame** attached to any recurring rolling/cumulative surface that starts influencing decisions;
- an **anchor instant** that stays smaller than both the query contract and the final local consequence;
- a **partial-window posture** for early-edge/truncated frames;
- UI headers that can say **basis pin + window frame + anchor instant + partial-window posture + exactness class** together when relevant;
- hygiene that refuses to let new framing/window sources drift out of the bibliography, source register, queue, front door, or manifest.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new window/frame sources that are now directly shaping datacube posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- tighten the repo hygiene check so the latest pass docs must also remain in the release manifest's `core_docs` list;
- rerun the repo hygiene checks after the ledger and front-door refresh.

## Still-not-yet decisions
- engine choice;
- one canonical rolling-window grammar;
- one mandatory machine-readable frame schema;
- one default anchor-clock field for all future surfaces;
- one rule that every future metric card must already know whether partial early windows should emit, suppress, or stay unknown.
