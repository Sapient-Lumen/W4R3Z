# Checker-suite audit and refactor — pass XCII

## Finding

By rev0091, Ward had thirteen governance receipt checkers. The suite still used a hardcoded list inside `tools/check_governance_suite.py`.

That was acceptable while there were a few validators, but it became a drift risk. The failure mode is simple: a future pass adds a schema, fixtures, and checker, but forgets to append the script to the suite. `make check` would then pass while the new receipt family was untested.

## Refactor

Pass XCII adds:

- `tools/governance_common.py` for shared path, digest, stable JSON digest, ISO time parsing, referenced-receipt validation, and fixture-runner utilities.
- `tools/governance_checker_registry.json` for an auditable checker inventory.
- A refactored `tools/check_governance_suite.py` that reads the registry, verifies checker scripts and fixture directories exist, rejects duplicate checker IDs/scripts, and then runs every checker.

## Scope control

The refactor deliberately does not rewrite every historical checker. That would create more risk than it removes. The new reconciliation checker uses the common utilities, and the suite registry provides the immediate drift guard. Future passes can migrate older checkers opportunistically.

## New invariant

A new receipt family is incomplete unless it appears in the checker registry and the registry-backed suite passes.
