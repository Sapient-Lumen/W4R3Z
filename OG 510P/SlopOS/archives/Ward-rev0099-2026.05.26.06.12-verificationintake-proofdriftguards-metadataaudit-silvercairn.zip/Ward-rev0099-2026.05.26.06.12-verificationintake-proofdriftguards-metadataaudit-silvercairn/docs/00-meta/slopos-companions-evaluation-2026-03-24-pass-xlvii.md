# SlopOS / companions evaluation — pass XLVII

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **recurring measures need explicit rollup law, because the same repeated question can contain additive counts, semiadditive snapshots, and non-additive distincts at once**.

## What the included cubes keep teaching
- **SlopOS** is still the most useful direct teacher because RFC-0100 keeps querying modest: **view-scoped**, **snapshot-first**, **handle-returning**, with saved queries remaining **shell-owned manifests** and live mode **optional and bounded**. That posture is a warning against turning Ward's early datacube into an ambient semantic oracle before the surrounding system has even finished deciding what its shells and manifests own.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: **query manifest**, **result snapshot**, **live feed**, **materialized local collection**, and **current bind** are distinct. This revision adds one more split above that seam: a recurring measure surface needs its own **aggregation law**, and some derived totals may need **merge state** instead of only a displayed number.
- **Steward** keeps teaching that remembered structure is weaker than current liveness. That same humility should apply to precomputed metrics: a cached daily total, distinct-count tile, or balance snapshot should not automatically inherit wider rollup rights than its own computation really supports.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows recurring measures in human-facing UI, the UI should be able to say whether a surface is additive, semiadditive, non-additive, or merge-state-backed rather than letting every friendly chart masquerade as the same kind of truth.

## What outside systems add to the datacube posture
- Cube's additivity docs make the first anti-lesson explicit: additivity is about whether a measure already computed at one grain can be further aggregated to another, and many useful measure types are non-additive. Ward should borrow that as an **aggregation law**, not as a commitment to Cube's whole modeling stack (`EXT-CUBE-ADDITIVITY-2026`).
- Microsoft's DAX docs make the second anti-lesson concrete by showing that distinct-count totals are not additive, while Analysis Services reminds us that snapshot/balance measures are often **semiadditive** across time. Ward should borrow that as a **rollup passport** that says what regroupings are safe for one surface and what regroupings require replay or special carry rules (`EXT-DAX-DISTINCTCOUNT-2026`, `EXT-SSAS-SEMIADDITIVE-2025`).
- ClickHouse adds the positive implementation lesson: some aggregates can be persisted as intermediate state and recombined later with `-Merge`. Ward should borrow that as optional **merge state** posture, not as a premature commitment to one storage engine or one aggregate-state encoding (`EXT-CLICKHOUSE-AGGREGATEFUNCTION-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **Every promoted recurring measure must declare an aggregation law before it earns dashboard authority.**
2. **Every regroupable derivative should carry a rollup passport saying which dimensions, grains, windows, and dropped-context moves are allowed, caveated, or forbidden.**
3. **If higher-level recomposition needs intermediate state, keep merge state distinct from the rendered value.**
4. **Ward should not assume distinct totals, end-of-period balances, event counts, and sketch-backed estimates are all the same kind of cube fact.**
5. **Ward should not bless one universal measure taxonomy while SlopOS and its siblings are still actively discovering the right query and shell seams.**

## Specific anti-lessons from the past
- Do **not** let every repeated metric quietly inherit `SUM`-shaped social authority.
- Do **not** collapse distinct totals, balance snapshots, and event counts into one rollup doctrine.
- Do **not** discard mergeable intermediate state if later recomposition still matters.
- Do **not** pick one giant semantic constitution just because a few recurring questions are emerging.
- Do **not** let one friendly chart title hide forbidden regroupings or time-rollup traps.

## What Ward should probably steal next
- an **aggregation law** attached to any recurring measure surface that starts influencing decisions;
- a **rollup passport** that stays smaller than both the query contract and the final local consequence;
- optional **merge state** residue for promoted derivatives that need safe recomposition;
- UI headers that can say **basis pin + join clock + aggregation law + exactness class + loss posture** together when relevant;
- hygiene that refuses to let new rollup-law sources drift out of the bibliography, source register, queue, front door, or manifest.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new additivity / semiadditivity / merge-state sources that are now directly shaping datacube posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- rerun the repo hygiene checks after the ledger and front-door refresh.

## Still-not-yet decisions
- engine choice;
- one canonical measure taxonomy;
- one mandatory machine-readable passport shape;
- one default merge-state encoding;
- one rule that every future metric card must already know its full rollup passport from day one.
