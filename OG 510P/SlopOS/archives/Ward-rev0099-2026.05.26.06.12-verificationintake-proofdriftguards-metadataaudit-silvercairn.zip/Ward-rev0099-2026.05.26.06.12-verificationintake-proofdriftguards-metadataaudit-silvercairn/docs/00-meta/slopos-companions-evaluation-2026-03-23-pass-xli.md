# SlopOS / companions evaluation — pass XLI

This pass keeps Ward embryonic while stealing one more useful habit from SlopOS and the sibling cubes: **reader-local “now”, latency-friendly observations, and high-risk action readiness should not collapse into one fake current-state truth**.

## What the current cubes still teach
- **SlopOS** is again the strongest nearby teacher because it repeatedly refuses to let imported status/freshness artifacts silently widen into ambient substrate truth. The attestation freshness boundary, collateral-status boundary, and many of the reviewed posture/boundary families are all pressure in the same direction: imported evidence can be fresh-enough for one purpose and still weaker than durable local consequence.
- **Harbor** and **Steward** pressure the same seam operationally: callback timing, teardown acknowledgement, or discovery arrival can be good-enough for orientation while still weaker than the exact check needed before the highest-risk action.
- **ViewFS** keeps a related history/readability lesson alive: an addressable current view is smaller than a stable cut, and a stable cut is smaller than ambient “latest”.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one mandatory global clock contract, one universal follower-read interface, one blessed staleness policy, or one universal revalidation controller into the cube.

## Current recommendation
Keep Ward open on whether these truths ultimately ride on timestamp bounds, closed timestamps, snapshot options, explicit read-restart APIs, deferrable transactions, or some mixed shape.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **read cut** instead of vague “this was current when we looked” language;
2. **staleness budget** instead of hidden latency/freshness bargains;
3. **ambiguity window** instead of fake certainty when visibility is not settled;
4. **revalidation fence** instead of letting an orientation read mint the highest-risk consequence;
5. **revision-supersedes coherence** so `REVISION-RECEIPT.json` cannot quietly point past the actual immediately prior packaged revision;
6. **latest-pass lesson/inspiration heading coherence** so the archive cannot add a new pass without also folding its anti-lessons and stealable ideas into the standing front-door harvests.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep imported freshness/readability posture smaller than local action authority;
- keep browse-grade or orientation-grade reads visibly weaker than spend-grade checks;
- keep ambiguity or skew windows stronger than fake “close enough” currentness; and
- fail the revision if the receipt’s `supersedes` pointer and the latest pass headings drift behind the packaged archive.

## Still-not-yet decisions
- Whether `read cut` belongs in durable Ward vocabulary, or remains query-side residue until more read-time specimens accumulate.
- Whether `staleness budget` should become first-class Ward vocabulary, or remain operational/appraisal guidance.
- Whether `ambiguity window` belongs inside Ward, or remains imported observation residue from underlying storage/read substrates.
- Whether `revalidation fence` is best treated as a first-class Ward noun, or as local spend/appraisal discipline until more specimens accumulate.
