# SlopOS / companions evaluation — pass XXXV

This pass keeps Ward embryonic while stealing one more useful habit from SlopOS and from mature threshold/transparency systems: **separate one observation, grouped corroboration, and the local rule that decides whether grouped corroboration is enough.**

## What the current cubes still teach
- **SlopOS** keeps teaching the right design temperament: exact witness surfaces, explicit policy profiles, and generated artifacts that stay smaller than the local decision they influence. Ward should steal the smaller analog here: do not collapse one witness note, one corroboration bundle, and one local acceptance rule into a single boolean.
- **SlopOS** also repeatedly prefers explicit closure points and explicit validator-owned meaning over ambient folklore. That matches the outside threshold lesson: “enough signatures” is not self-describing without the relying party’s rule.
- **Foundry** and **ViewFS** still pressure Ward not to let derived bundles erase provenance about where corroboration came from. A bundle that hides whether receipts came from one cohort or several can overstate independence.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one witness registry, one quorum algebra, one required committee size, or one universal corroboration carrier into the archive.

## Current recommendation
Keep Ward open on whether corroboration will ultimately travel as appended receipts, sidecar bundles, threshold attestations, policy-side trust lists, or some mixed shape.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **observer report** instead of pretending one witness already means corroborated truth;
2. **corroboration set** instead of flattening plural receipts into one yes/no bit;
3. **witness cohort** instead of trusting raw signature count to stand in for independence;
4. **local quorum rule** instead of letting issuer-side packaging quietly choose local consequence;
5. **current-revision changelog lint** so the archive cannot package a revision without naming it in `CHANGELOG.md`.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep witness material and acceptance rules visibly separate;
- keep independence/cohort posture visible instead of assuming count tells the whole story;
- keep monitorability/auditability nearby instead of pretending threshold signatures solve everything alone; and
- fail the revision if `CHANGELOG.md` does not contain an entry for the current revision.

## Still-not-yet decisions
- Whether `witness cohort` belongs in durable Ward vocabulary or remains receipt/transport-local until more plural-receipt specimens accumulate.
- Whether `local quorum rule` should stay appraiser-local policy residue, or become part of Ward’s durable trust-result family later.
- Whether `same-cut requirement` deserves first-class archive residue, or remains specimen-local guidance until more mixed-cut examples exist.
- Whether Ward should ever carry a collapsed “quorum badge”, or force local consumers to keep corroboration material and quorum policy visibly separate.
