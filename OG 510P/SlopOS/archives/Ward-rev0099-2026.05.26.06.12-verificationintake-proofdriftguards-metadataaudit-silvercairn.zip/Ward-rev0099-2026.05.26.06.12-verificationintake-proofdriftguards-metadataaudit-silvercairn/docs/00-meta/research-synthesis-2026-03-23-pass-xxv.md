# Research synthesis — pass XXV

This pass keeps Ward cautious and learns one more thing from older and newer status/event systems: **effective change time, publication/signing time, known-correct interval, and local adoption time are different truths, and one underlying cause can legitimately emit several later-state artifacts without becoming one giant object.**

## Outside lessons
1. **Reason and effective invalidity are not the same thing as publication.**  
   RFC 5280 says CRL issuers are strongly encouraged to include meaningful `reasonCode` values and `invalidityDate` when available, and that the invalidity date may be earlier than the revocation date in the CRL entry. Ward should therefore resist treating “we learned it now” as equal to “it became trust-relevant now”.

2. **OCSP explicitly separates four different times.**  
   RFC 6960 distinguishes `thisUpdate`, `nextUpdate`, `producedAt`, and `revocationTime`. Ward should steal that humility: when later state affects consequence, we often need to know when the responder says the fact was correct, when the artifact was signed, when the underlying negative state began, and when the local system actually adopted the artifact.

3. **Positive/negative/unknown semantics still do not collapse timing.**  
   RFC 6960 also keeps `good`, `revoked`, and `unknown` asymmetric. Even after a state class is chosen, Ward should preserve the timeline of how that class was reached rather than compressing it into one timeless verdict.

4. **Modern event systems preserve shared cause across several artifacts.**  
   OpenID Shared Signals Framework says the `txn` claim may be reused across different SETs to indicate they originated from the same underlying cause or reason. Ward should therefore allow a small `cause cohort` idea instead of forcing every later-state artifact to stand alone or forcing all related artifacts into one giant blob.

5. **CAEP keeps event occurrence, initiator, and explanations separate from token issuance.**  
   CAEP examples use `event_timestamp`, `initiating_entity`, and `reason_admin` / `reason_user`, while the surrounding SET still has its own `iat`. Ward should steal that split: the time of the underlying fact, the time the signed artifact was minted, and the human/admin explanation are all useful without becoming the local action.

## Resulting Ward move
Do not decide yet whether Ward's long-term later-state substrate is event streams, status corpora, point lookups, or carried artifacts.

For now, preserve four separations and let later specimens force promotion:
- `effective change time` versus publication/signing time;
- `known-correct interval` versus local adoption time;
- `cause cohort` versus one isolated later-state artifact;
- `reason handle` versus the local action ladder or final consequence.

## Fresh ideas worth stealing
- **effective change time** — when the underlying trust-relevant fact is believed to have become true or dangerous.
- **known-correct interval** — the period for which a responder or publisher claims a state answer was current enough.
- **cause cohort** — compact grouping across several later-state artifacts that stem from one underlying event.
- **local adoption cut** — the local point where this receiver actually incorporated a later-state package into consequence.
- **reason handle** — typed cause/explanation smaller than action, verdict, or spend consequence.
