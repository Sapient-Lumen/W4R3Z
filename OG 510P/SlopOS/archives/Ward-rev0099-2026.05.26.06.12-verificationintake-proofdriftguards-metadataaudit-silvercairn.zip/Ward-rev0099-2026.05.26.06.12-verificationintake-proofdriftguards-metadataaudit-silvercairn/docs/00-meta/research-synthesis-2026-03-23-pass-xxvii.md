# Research synthesis — pass XXVII

This pass keeps Ward cautious and learns one more thing from Security Event Token and Shared Signals systems: **delivery identity, event/cause identity, ordering clues, and receiver-local application are different truths.**

## Outside lessons
1. **SETs already carry a delivery identity that is smaller than the underlying cause.**  
   RFC 8417 requires every SET to carry a `jti` that is unique within an event feed and says receivers may use it to track whether a specific SET has already been received. The same RFC also warns that timestamps such as `iat` do not by themselves guarantee order in distributed systems. Ward should therefore keep replay resistance and ordering humility visible instead of pretending one timestamp or one subject mapping solves both.

2. **Poll delivery assumes duplicates and leaves return order flexible.**  
   RFC 8936 says a poll response may include both first-time SETs and SETs being retransmitted because they remain unacknowledged. It also says the transmitter chooses which SETs to return first, and recipients should accept repeat SETs and acknowledge them even when they believe they already have. Ward should steal that realism: duplicate delivery is normal, and delivery order is weaker than causal truth.

3. **Acknowledgement and local action are different layers.**  
   RFC 8936 says recipients should acknowledge receipt before taking local actions when possible, and RFC 8935 says a successful push delivery is acknowledged with HTTP 202 yet the transmitter may still be unsure whether delivery was durably recorded if the network or recorder failed at the wrong moment. Ward should therefore keep transport acknowledgement, local incorporation, and spend consequence separate.

4. **SSF keeps shared cause and stream verification smaller than final truth.**  
   SSF says the `txn` claim should be unique to the underlying cause and may be reused across different SETs that came from the same cause. It also says a successful Verification Endpoint call only means the transmitter has transmitted a verification event or will do so later. Ward should therefore keep cause grouping and liveness probes smaller than actual delivered evidence.

## Resulting Ward move
Do not decide yet whether Ward’s long-term later-state substrate is webhook, poll stream, local queue, append-only log, or snapshot-plus-change feed.

For now, preserve four separations and let later specimens force promotion:
- `replay fence` versus subject identity or cause cohort;
- `ordering window` versus effective-change/publication time and receipt order;
- `apply cursor` versus transport acknowledgement or final consequence;
- `verification ping` versus proof that relevant later-state evidence actually arrived.

## Fresh ideas worth stealing
- **replay fence** — exact-delivery dedupe residue keyed to one delivered artifact.
- **ordering window** — compact statement that current order knowledge is partial, not total.
- **apply cursor** — receiver-local marker for what has truly been incorporated.
- **verification ping** — explicit liveness/test request weaker than fresh evidence.
- **same-handle exact replay** — same delivery handle should mean replay/dedupe, not mutable upsert.
