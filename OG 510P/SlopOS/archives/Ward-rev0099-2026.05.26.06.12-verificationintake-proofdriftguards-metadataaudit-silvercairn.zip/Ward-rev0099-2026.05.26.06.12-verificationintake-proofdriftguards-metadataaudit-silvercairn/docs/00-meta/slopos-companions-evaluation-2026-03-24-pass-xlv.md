# SlopOS / companions evaluation — pass XLV

This pass keeps Ward embryonic while stealing one more useful discipline from the current cube ecology plus outside teachers: **publish a small query contract only after a question repeats, and put an explicit loss fence around any lossy derivative instead of letting rollup become the cube's hidden constitution**.

## What the included cubes keep teaching
- **SlopOS** is still the most useful direct teacher because D-ATTRFS keeps querying modest: **view-scoped**, **snapshot-first**, **handle-returning**, with saved queries remaining **shell-owned manifests** and live mode **optional and bounded**. That keeps pushing Ward away from a giant ambient semantic layer while SlopOS itself is still design-phase.
- **ViewFS** keeps sharpening the neighboring seam Ward needs: **query manifest**, **result snapshot**, **live feed**, **materialized local collection**, and **current bind** are distinct. Ward can borrow one more step above that seam: a repeated question may earn a small published **query contract**, but only if it stays visibly smaller than the underlying query manifest and visibly weaker than source truth.
- **Steward** keeps teaching that remembered structure is weaker than current liveness. That is exactly the right humility for a **metric card**: it should tell a human what one recurring measure means without impersonating the live substrate or the raw evidence behind it.
- **Helm** keeps pressuring presentation honesty. If Ward ever shows a query contract or one lossy derivative in human-facing surfaces, the UI should be able to say `contracted`, `rollup-backed`, `loss-fenced`, or `raw replay unavailable` instead of burying everything under one `metric` badge.

## What outside systems add to the datacube posture
- dbt's Semantic Layer architecture shows the value of centrally defined semantic models and metrics queried through explicit interfaces; Ward should borrow the modest part of that idea as a **query contract** for one repeated question rather than as an immediate giant semantic constitution (`EXT-DBT-SEMANTIC-ARCH-2026`).
- Druid's rollup docs show the anti-lesson clearly: rollup is lossy summarization, you lose individual-event queryability, and conflicting needs may deserve multiple tables. Ward should borrow the explicit trade disclosure as a **loss fence**, not the default-on rollup posture (`EXT-DRUID-ROLLUP-2026`).
- Honeycomb still argues for high-cardinality exploration before predeclared summary buckets, which means Ward should let repeated questions earn narrow published contracts one by one instead of choosing the cube's final metric grammar too early (`EXT-HONEYCOMB-BUBBLEUP-2026`, `EXT-HONEYCOMB-EVENTS-2026`).

## Recommended datacube posture for Ward right now
Freeze only a few laws and keep the rest open:
1. **A repeated saved query may earn a published query contract before it earns a lossy rollup.**
2. **Every query contract should declare its grain, measure meaning, basis/join-clock headers when relevant, and weaker-than-source posture.**
3. **Human-facing recurring measures should travel with a metric card, not a vague dashboard title.**
4. **Any lossy derivative should carry a loss fence that says what questions it cannot answer honestly anymore.**
5. **Saved recipe, query contract, metric card, frozen result, live feed, staged derivative, active derivative, and lossy rollup should remain visibly different classes.**

## Specific anti-lessons from the past
- Do **not** let a repeated question force a giant semantic layer before the question family is real.
- Do **not** let rollup/pre-aggregation become the default cube constitution just because it is cheap or fast.
- Do **not** let one metric title hide grain, headers, null/default posture, or lost queryability.
- Do **not** let a lossy derivative masquerade as raw replayable truth.
- Do **not** choose one engine's semantic/rollup machinery as Ward's constitution this early.

## What Ward should probably steal next
- a **query contract** state distinct from saved recipe and metric card;
- a **metric card** that makes one recurring measure legible without implying full semantic closure;
- a **loss fence** that makes pre-aggregation or summarization costs explicit;
- headers that show **basis pin + join clock + contract state + loss posture** together when relevant;
- hygiene that refuses to let new datacube-driving sources or latest pass docs drift out of the archive inventory/front door.

## Hygiene/process consequence
The process steal for this revision is deliberately small but useful:
- register the new outside sources that are now directly shaping contract/rollup posture;
- keep the newest research/evaluation/specimen surfaces wired through README, start-here, docs map, manifest, receipt, and archive index;
- rerun the repo hygiene checks after the ledger and front-door refresh.

## Still-not-yet decisions
- engine choice;
- storage/index strategy;
- one universal semantic layer;
- one canonical rollup/pre-aggregation family;
- one mandatory metric-contract schema for every future result family.
