# Research synthesis — pass XLIII

This pass keeps Ward decision-light and adds one more datacube discipline: **temporal lookup lane, join clock, and freeze/rerun-diff rails are different truths**.

## What the past says we must learn
1. **Point-in-time enrichment is a specific operation, not a vague “latest” join.**  
   DuckDB's AsOf Join docs are useful here because they state the problem plainly: time-series data is not perfectly aligned, cause and effect can be delayed, and one common use case is finding the value of a varying property at a specific point in time. Ward should steal the lesson directly. If one approval, attestation, or consequence event gets decorated with “latest policy,” “latest issuer posture,” or “latest risk label,” the cube must say **latest as of which clock**.

2. **A basis pin is still smaller than a join clock.**  
   Pass XLII already taught Ward to pin the factual cut. This pass adds the next caution: a pinned basis still does **not** say whether temporal lookup uses event time, effective-change time, publication/signing time, or local adoption time. Those choices can yield different but still honest answers, so the chosen clock has to stay separately inspectable.

3. **Saved recipe, frozen result, and live feed are not the same object.**  
   SlopOS already points in the right direction with D-ATTRFS: queries are view-scoped, snapshot-first, and handle-returning; saved queries remain shell-owned manifests; live mode is optional and bounded. ViewFS sharpens the same separation into query manifest, result snapshot, and live feed. Ward should steal that split directly for trust exploration surfaces instead of silently regrowing “one saved query that is somehow also the current truth.”

4. **Acceleration and promotion need workload evidence.**  
   ClickHouse projections and Pinot star-tree indexes still teach the same humility: precomputation belongs where known query patterns justify it, not where architecture fashion predicts it. Ward should therefore require a visible **workload witness** before adding hidden acceleration, pre-aggregation, or a maintained derivative that looks more official than it really is.

5. **Re-run and diff are product surfaces, not debugging leftovers.**  
   Once a trust result is frozen for review, later re-runs against a newer basis or a different join clock should produce an explicit diff instead of silently mutating the prior answer. That keeps review, disagreement, and follow-through honest.

## Resulting Ward move
Do **not** decide yet whether Ward's eventual datacube rides on one warehouse, one streaming planner, one lakehouse format, one semantic layer, or a thinner family of trust-query surfaces.

For now, keep five separations visible and let later specimens force promotion:
- **temporal lookup lane** — the explicit rule for attaching time-varying context to one fact;
- **join clock** — the exact timeline the temporal lookup uses;
- **freeze rail** — an explicit way to hold one reviewable result snapshot still;
- **rerun-diff rail** — an explicit way to compare the same recipe across bases or clocks;
- **workload witness** — concrete repeated-use evidence before acceleration or promotion.

## Why these separations are worth stealing
- A `temporal lookup lane` prevents “latest” from masquerading as timeless truth.
- A `join clock` keeps event-time, effective-time, publication-time, and local-adoption-time disagreements inspectable instead of hidden inside a join.
- A `freeze rail` lets a reviewer inspect one answer without silent live drift.
- A `rerun-diff rail` makes correction and disagreement explicit instead of mutating history.
- A `workload witness` makes promotion and acceleration earned rather than architectural folklore.

## Brilliant ideas to steal now
- **temporal lookup lane** — explicit point-in-time enrichment instead of hidden latest-value join.
- **join clock** — inspectable statement of which time axis the lookup used.
- **freeze rail** — one-click freeze of the current result for review, notes, or sharing.
- **rerun-diff rail** — explicit compare surface for “same recipe, newer basis/clock”.
- **workload witness** — concrete repeated-query evidence before adding precomputation or a maintained derivative.
- **recipe-not-result-not-live** — a standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward needs one universal temporal-lookup primitive or several narrower lookup lanes.
- Whether join clocks should become first-class Ward nouns, or remain datacube/query-side guidance until more specimens accumulate.
- Whether freeze/rerun-diff rails belong inside Ward proper or stay in a neighboring query shell.
- Whether workload witnesses should remain process guidance or become durable promotion policy.
