# SlopOS / companions evaluation — pass XXXVIII

This pass keeps Ward embryonic while stealing one more useful habit from SlopOS and the sibling cubes: **separate requested posture, reconciler-observed state, compact summary conditions, and teardown-in-progress residue instead of collapsing them into one fake current object truth.**

## What the current cubes still teach
- **SlopOS** is again the strongest nearby teacher, not because it already has a single “datacube object” to copy, but because it repeatedly keeps *shape*, *meaning pin*, and *current posture* in different files and families. Its posture docs, boundary docs, schema docs, and evidence hooks make it harder to smuggle current truth into one overloaded noun. Ward should steal that discipline, not the exact file taxonomy.
- **Foundry** and **ViewFS** keep pressuring the same seam from adjacent angles: imported facts, derived results, and live/current interpretation are not one object just because a UI wants one row.
- **Harbor** and **Steward** keep the teardown side honest: remote teardown request, local narrowing, and actual disappearance are usually different truths and deserve different surfaces.
- Because **SlopOS is still in design phase too**, Ward should still avoid freezing one universal object shape such as literal `spec/status`, one mandatory condition taxonomy, one universal reconciler loop, or one generic finalizer contract into the cube.

## Current recommendation
Keep Ward open on whether these truths ultimately travel as one object with subresources, paired request/result objects, separate sidecars, or some mixed shape.

The next wise move is one specimen plus one tiny process/hygiene improvement:
1. **desired state** instead of pretending requested policy is already enacted;
2. **observed generation** instead of trusting conditions without knowing which desired revision they describe;
3. **condition set** instead of one giant overloaded status blob;
4. **teardown gate** instead of flattening delete-request, terminating, and absent;
5. **front-door revision label coherence** so README / START_HERE / docs map cannot quietly describe the wrong revision while still linking the newest files.

## Hygiene/process consequence
The small SlopOS-style steal is enough for now:
- keep authored/requested surfaces smaller than observed/appraised surfaces;
- keep compact conditions smaller than the full observed state;
- keep teardown-in-progress smaller than absence; and
- fail the revision if front-door docs drift on which revision they claim to summarize.

## Still-not-yet decisions
- Whether `desired state` belongs in durable Ward vocabulary, or remains generic controller-side residue until more request/result specimens accumulate.
- Whether `observed generation` should become first-class Ward vocabulary, or remain imported reconciler residue until more stale-summary specimens accumulate.
- Whether `condition set` belongs inside Ward, or remains a smaller summary lane owned by adjacent cubes.
- Whether `teardown gate` is best treated as local policy/process residue or a first-class Ward noun later.
