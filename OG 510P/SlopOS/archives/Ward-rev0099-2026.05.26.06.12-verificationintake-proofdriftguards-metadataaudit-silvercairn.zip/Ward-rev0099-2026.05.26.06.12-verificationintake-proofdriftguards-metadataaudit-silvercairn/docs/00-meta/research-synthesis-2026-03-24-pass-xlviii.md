# Research synthesis — pass XLVIII

This pass keeps Ward decision-light and adds another datacube discipline: **a repeated question needs explicit grain and duplication honesty before any promoted derivative or dashboard can pretend it knows what one row means.**

## What the past says we must learn
1. **Joins can silently multiply facts.**  
   Looker’s symmetric-aggregates docs are unusually blunt: a one-to-many join can make a previously correct aggregate wrong, and safe recovery depends on a unique primary key plus the correct join relationship. Ward should steal the habit, not the product: every promoted surface needs an explicit **grain witness** saying what one fact row means and what identity keeps it from being counted twice (`EXT-LOOKER-SYMMETRIC-AGG-2026`).

2. **Join graphs need anti-fanout posture, not just pretty syntax.**  
   dbt’s MetricFlow join docs say joins are built from entities and that the system chooses join types to avoid fan-out or chasm joins. Ward should borrow the constitutional lesson: a repeated question that crosses grains needs a visible **fanout fence** instead of trusting convenience joins or dashboard folklore (`EXT-DBT-METRICFLOW-JOINS-2026`).

3. **Some measures have a base grain that must survive regrouping.**  
   Cube’s multi-stage calculations docs say some calculations use inner and outer aggregation stages, with the inner stage computing a base measure at a specific granularity and the outer stage aggregating those results. Their average-of-per-customer-averages example is the perfect warning: changing the inner grain changes the meaning of the answer. Ward should therefore keep a **grain witness** visible whenever a measure’s meaning depends on one inner grouping choice (`EXT-CUBE-MULTI-STAGE-2026`).

4. **Rates and averages need their denominator or weight story to survive.**  
   dbt’s ratio metrics explicitly require a numerator metric and a denominator metric, and DuckDB/ClickHouse both expose weighted-average functions instead of pretending every average can be re-rolled from one displayed number. Ward should steal the lighter law: if a promoted surface may need honest regrouping later, it may need an explicit **weight carrier** rather than one naked percentage or average (`EXT-DBT-RATIO-METRICS-2026`, `EXT-DUCKDB-WEIGHTED-AVG-2026`, `EXT-CLICKHOUSE-AVGWEIGHTED-2026`).

## Resulting Ward move
Do **not** decide yet whether Ward eventually standardizes one universal semantic graph, one mandatory entity-typing system, one auto-deduping join planner, or one canonical machine-readable metric compiler.

For now, keep three more separations visible and let later specimens force promotion:
- **grain witness** — visible statement of what one measure-bearing row means, which identity keeps it unique, and what inner grouping made the measure meaningful.
- **fanout fence** — explicit barrier that says where a join can multiply rows, what duplication protection exists, and when replay at another grain is required.
- **weight carrier** — optional durable residue that preserves denominator/weight state needed for honest regrouping of rates, averages, and ratios.

## Why these separations are worth stealing
- A `grain witness` stops a promoted derivative from quietly changing meaning when one join or inner grouping changes.
- A `fanout fence` keeps “same facts, more dimensions” from collapsing into “same truth, more rows.”
- A `weight carrier` preserves the difference between “I can show you a percentage here” and “I can safely recompute a broader percentage later without averaging averages.”

## Brilliant ideas to steal now
- **grain witness** — explicit base fact meaning and uniqueness anchor for one measure-bearing lane.
- **fanout fence** — visible statement of duplication risk and protection at one join seam.
- **weight carrier** — optional numerator/denominator or weighting residue for honest regrouping.
- **equal-weight versus event-weight honesty** — standing anti-regrowth rule.
- **no average-of-averages by accident** — standing anti-regrowth rule.

## Still-not-yet decisions
- Whether Ward ever blesses one universal join-entity graph.
- Whether `grain witness` stays human-facing guidance or later becomes typed machine-readable metadata.
- Whether `weight carrier` is mandatory only for promoted derivatives or also for some frozen review bundles.
- Whether some repeated questions should permanently remain replay-only instead of ever earning a weight-carrying derivative.
