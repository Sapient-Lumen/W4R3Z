# Research synthesis — 2026-05-22 pass LXXXIII

Pass LXXXIII studies the next unresolved pressure from pass LXXXII: cross-page and long-running governance search.

## External pressure

AuthZEN is the direct pagination pressure. Its Search APIs return sets of authorized entities rather than single decisions, warn that pagination does not guarantee an atomic snapshot, and require the entities and pagination parameters to stay identical across paginated requests (`EXT-AUTHZEN-AUTHORIZATION-API-2026`). Ward should inherit the caution but be stricter: even identical query parameters are not enough when the governance basis behind the query changes.

Kafka-style log compaction sharpens the replay problem. Confluent's compaction docs explain that delete/tombstone markers are retained only long enough for consumers to complete a full scan; late consumers may miss them after the retention bound (`EXT-CONFLUENT-KAFKA-LOG-COMPACTION-2026`). Ward should treat advanced compaction watermarks as a reason to downgrade or hold search continuation.

NIST SP 800-226 adds privacy pressure. It frames differential privacy as a mathematical framework for quantifying privacy loss and identifies many surrounding hazards in real systems (`EXT-NIST-SP-800-226-DP-2025`). Ward should not claim “DP count” merely because it adds noise. It needs privacy unit, budget reference, noise model, composition window, and exact-count fallback closure.

CloudEvents distributed tracing remains useful for correlation across pages and systems, but trace context is only context; it cannot prove authorization, stewardship, projection safety, or current replay (`EXT-CLOUDEVENTS-DISTRIBUTED-TRACING-2026`).

## Synthesis

Ward should add a **search-continuity receipt** rather than expanding the batch/search receipt.

The reason is authority hygiene: a batch/search receipt says one result set was aggregated safely. A search-continuity receipt says whether the next page is still safely connected to the prior page.

The minimum basis is:

- query digest;
- request fingerprint;
- prior page digest;
- projection-policy digest;
- owner-map epoch;
- packet-compaction watermark;
- cursor binding and expiry.

## Design choice

The new receipt has three conservative rules:

1. Same-snapshot continuation is allowed only when every basis field remains unchanged.
2. Any basis drift produces hold, recheckpoint, new receipt, or new search; never silent continuation.
3. Sealed omissions can be disclosed only through audience-safe modes: none, presence-only, bucketed range, or DP/noisy count with budget evidence.

## Fixture pressure

The checker validates five positive fixtures and twelve negative fixtures. The strongest negative tests are:

- cursor continues after owner-map drift;
- query scope changes while reusing a cursor;
- projection policy changes but continuation is still claimed;
- packet compaction watermark advances while current replay is claimed;
- public exact sealed count;
- public sealed detail leakage;
- hidden omissions with complete-result language;
- noisy count without privacy budget;
- high-consequence effect from a continuation receipt.

## Remaining open pressure

Ward still needs future pressure around:

- joining search-continuity receipts with export receipts;
- whether sealed-count ranges should be standardized across cubes;
- how ViewFS should render presence-only sealed rows without making users overtrust or undertrust the visible set;
- whether SlopOS should mint a generic “continuation held” UI primitive for paginated datacube surfaces.
