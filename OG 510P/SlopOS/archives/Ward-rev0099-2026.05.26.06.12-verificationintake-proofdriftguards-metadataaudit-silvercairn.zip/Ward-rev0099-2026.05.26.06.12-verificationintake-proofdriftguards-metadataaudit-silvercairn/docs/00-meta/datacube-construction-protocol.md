# Datacube construction protocol

This is a process surface, not a schema. It exists to keep Ward's embryonic SlopOS datacube work from hardening too early or regrowing into an ambient analytics platform.

## Standing posture

Ward should collect small, testable residues for repeated trust questions before choosing a global cube shape. A future SlopOS datacube may involve relational plans, array coordinates, object manifests, columnar exports, materialized summaries, semantic models, lineage events, or several of those. None of them is the constitution yet.

## Every datacube pass should separate

1. **Question** — the human or machine question being repeated.
2. **Authority scope** — the view, snapshot, handle set, policy epoch, and population the question was allowed to see.
3. **Answer shape** — axes, grain, measures, qualifiers, units, absence posture, subtotal identity, and aggregation law.
4. **Mutable cuts** — schema versions, semantic model versions, metric cards, source snapshots, materialization generations, redaction profiles, layout/tier choices, and retained state families.
5. **Computation boundary** — query contract, plan receipt, engine/export boundary, or intentionally-uncommitted recipe.
6. **Lineage** — source cuts, recipe/run identity, promotion context, and downgrade/rerun hooks.
7. **Refusal and withholding** — unsupported, denied, suppressed, stale, over-budget, unmodeled, or unsafe portions of the answer.
8. **Comparison posture** — when this answer is compared with another answer, the comparability passport, drift notices, quality witnesses, and bridge/refusal posture that make the comparison honest.
9. **Promotion decision** — whether the answer can influence durable trust consequence, and under which caveats.
10. **Non-decisions preserved** — what the pass deliberately did not freeze.

## Promotion stop signs

Reject or quarantine a datacube answer when:

- it lacks a clear view/scope binding;
- it can act as a hidden count or existence oracle;
- one cell's grain or axes are ambiguous;
- subtotal, null, zero, empty, suppressed, denied, and missing states collapse;
- materialization freshness or retained-state generation is missing;
- privacy, fill, sampling, resolution, calendar, unit, or identity residues were discarded;
- a plan/export/columnar batch is treated as stronger than the residues it carries;
- refusals are hidden in logs instead of attached to the answer;
- a before/after chart, trend, or cohort contrast lacks a comparability passport when scope, metric, policy, quality, materialization, privacy, or refusal posture may have drifted;
- an LLM-proposed query or comparison has not been grounded by deterministic scope/cut/refusal/comparability machinery.

## Revision hygiene checklist

For each datacube pass:

- add a research synthesis and a SlopOS/companions evaluation;
- add exactly one specimen unless there is a clear reason to split;
- keep new nouns smaller than schema, storage, policy, or engine commitments;
- update lessons, inspiration harvest, source register, review queue, ledgers, roadmap, front doors, manifest, receipt, and archive index;
- run `make check` before packaging;
- preserve explicit “not yet” decisions in the text.

## Anti-regrowth rule

A datacube answer is not more authoritative because it is faster, prettier, more complete-looking, more portable, or easier for an agent to request. It is more authoritative only when its scope, shape, state cuts, lineage, and refusal posture survive inspection.


## Comparison hygiene extension

A datacube comparison is not a free consequence of having two answer capsules. Before Ward lets an answer pair become a trend, before/after chart, cohort contrast, or rerun-vs-history claim, the comparison must either carry a **comparability passport** or refuse the comparison.

The minimum comparison review is:

1. identify the compared answer capsules and consequence class;
2. inspect scope lenses, state cut witnesses, axis capsules, metric/query cards, lineage facets, refusal receipts, and any privacy/resolution/calendar/unit residues;
3. attach quality witnesses or explicit `not_run` quality posture;
4. emit drift notices for material changes;
5. decide whether the comparison is same-contract, bridged, bridge-required, incomparable, or not-tested;
6. preserve any bridge receipt without rewriting the older answer's original meaning.

A smooth chart is never allowed to be stronger than its comparability passport.

## Explanation hygiene extension

A datacube explanation is a new answer, not a footnote on a chart. Before Ward lets a changed answer become a why-panel, LLM summary, root-cause hint, drill-through narrative, or promotion rationale, the explanation must either carry constrained explanation residue or refuse the why-story.

The minimum explanation review is:

1. identify the comparison capsule, its comparability passport, and its consequence class;
2. build a **delta anatomy** that separates fact movement, scope/population movement, metric logic movement, axis/member bridge movement, quality/refusal movement, privacy/suppression movement, materialization/tier movement, late-correction movement, and residual unexplained movement where relevant;
3. attach an **attribution rail** to each explanation fragment, distinguishing accounting, lineage/where, derivation/how, value diff, cohort contrast, exemplar/drill-through, and causal/counterfactual claims;
4. require **exemplar fences** before showing examples, traces, rows, documents, or handles behind an aggregate cell;
5. preserve residual unexplained movement instead of forcing full attribution;
6. prohibit causal verbs unless a causal/counterfactual rail has explicit evidence and assumptions.

A smooth why-story is never allowed to be stronger than its weakest attribution rail.

## Reuse and materialization hygiene extension

A datacube answer is not promoted again merely because a cache, materialized view, retained aggregate, star-tree, projection, compaction product, or downsampled tier can serve it quickly. Reuse is a fresh claim about authority.

The minimum reuse review is:

1. identify the candidate answer capsule, requester view, consequence class, and original state cut witness;
2. attach a **freshness envelope** naming target freshness, observed lag/cut age, source/semantic/policy/materialization generations, allowed reuse class, and stale/refusal posture;
3. inspect invalidation triggers from source updates, late corrections, schema or metric-card changes, policy/redaction updates, quality failures, materialization rebuilds, layout rewrites, retention changes, and refresh-mode fallback;
4. emit an **invalidation receipt** for any material change, even when reuse remains allowed;
5. open a **recompute docket** when repair, full recompute, revalidation, re-comparison, re-explanation, or refusal is owed;
6. ensure freshness/invalidation/recompute probes do not leak denied row, handle, or cell existence outside the authorized view;
7. preserve old answers as reviewable evidence only when retention and policy allow, and never let stale review material become current consequence by cache reuse.

A fast answer is never allowed to be stronger than its freshness envelope.



## Interaction, rendering, and egress hygiene extension

A datacube answer is not promoted again merely because a dashboard can filter it, a renderer can make it persuasive, an agent can drill into it, or an export can carry it elsewhere. Interaction and egress are fresh claims about authority.

The minimum interaction/render/egress review is:

1. identify the source answer capsule, requester view, consequence class, and existing scope/state/refusal/comparability/explanation/reuse residues;
2. open an **interaction trail** for consequential filters, parameter changes, drills, pivots, sorts, top-k requests, refresh attempts, render changes, annotations, agent follow-ups, exports, shares, embeds, alerts, and refusals;
3. attach a **render contract** when display transforms, top-k/limit/sort, grouping/binning, current-layout flattening, “other” buckets, missing/suppressed/denied states, precision, scales, timezone/calendar, or warning copy can change interpretation;
4. require exemplar fences and refusal receipts before drill-through reveals row, trace, handle, document, or example material;
5. create an **egress receipt** for detached artifacts such as CSV, spreadsheet, copied table, screenshot, report, alert, embedded chart, or agent summary;
6. ensure interaction, truncation, drill refusal, export limits, and stale/invalidation messages do not leak denied population or suppressed cell existence;
7. require rehydration through current authority before a stale export, screenshot, or agent summary influences new consequence.

A rendered or exported artifact is never allowed to be stronger than its render contract and egress receipt.

## Budget, uncertainty, and degradation hygiene extension

A datacube answer is not promoted merely because the system can produce a cheaper, faster, noisier, sampled, sketch-backed, summary-only, top-k, stale, or otherwise degraded result. Degradation is a fresh claim about answer strength.

The minimum budget/degradation review is:

1. identify the requested answer capsule, requester view, consequence class, and expected exactness/detail posture;
2. open a **budget gate** when resource, latency, cost, privacy loss, egress rows/cells, validation-detail, exemplar-detail, payer/sponsor, or capability-scope limits may constrain the answer;
3. refuse rather than degrade when fallback would leak denied population, hidden cells, suppressed cohorts, or false precision;
4. create a **degradation receipt** whenever the served answer differs from the requested answer through exact-to-sketch, exact-to-sample, fine-to-coarse, current-to-stale, full-to-top-k, detail-to-summary, exemplar-to-aggregate-only, private-to-noisy/suppressed, or similar weakening;
5. attach an **uncertainty envelope** that composes exactness, estimator/sketch, sample, privacy, quality, freshness, tier, nondeterminism, repeatability, and detail-exposure residue instead of flattening those into one friendly warning;
6. mark degraded answers review-only unless an explicit promotion gate accepts that uncertainty envelope for the named consequence class;
7. open a recompute docket when exact repair or confirmation is owed, and prevent stale previews from remaining consequential after a stronger rerun or invalidation changes the story.

A degraded answer is never allowed to be stronger than its budget gate, degradation receipt, and uncertainty envelope.

## Correction, backfill, and revocation hygiene extension

A datacube answer is not forever-current merely because it was once exact, rendered, exported, or cited by an agent. History repair is a fresh claim about answer authority.

The minimum correction/backfill/revocation review is:

1. identify the old answer capsule, requester view, consequence class, state cut witness, freshness envelope, render contract, egress receipt, and any comparison/explanation/reuse/degradation residue;
2. attach a **correction horizon** naming whether relevant cells, ranges, source cuts, and egress artifacts are open, closed, or repair-only for late data, identity repair, delete/revoke state, privacy/legal change, or backfill;
3. separate event time, effective/valid time, ingestion time, publication time, local adoption time, and answer-production time when any of them can change interpretation;
4. open a **backfill ledger** for deliberate historical repair, naming reason, authority, safe affected scope, source/change/time-travel coverage, recipe/run identity, validation, budget/degradation posture, invalidated/replaced outputs, and residual gaps;
5. emit invalidation receipts, drift notices, comparability changes, delta anatomies, and recompute dockets as needed rather than silently rewriting old capsules;
6. attach a **revocation fence** to withdrawn, superseded, deleted, erased, privacy-fenced, or policy-narrowed answer material and require rehydration before future consequence;
7. ensure correction notices, affected-scope summaries, and fence reasons do not leak denied rows, hidden cells, suppressed cohorts, or private exemplar existence.

An old answer is never allowed to be stronger than its correction horizon, backfill ledger, and revocation fence.

## Federation, join, and projection hygiene extension

A datacube answer is not promoted merely because several sources, participants, semantic owners, clean-room surfaces, or delegated policy engines can be queried together. Federation is a fresh claim about authority composition.

The minimum federation review is:

1. identify every participant/source/policy surface and the requested consequence class;
2. attach a **federation pact** for each participant or collaboration boundary, naming authority, view/snapshot, semantic/policy/model cuts, allowed fragments, pushdown/capability posture, budgets, freshness, quality, privacy, egress, and refusal channels;
3. label local, remote, pushed-down, clean-room, delegated-authorization, materialized, and composed fragments separately;
4. require a **join warrant** before any cross-boundary link, intersection, or enrichment, including key namespace, tokenization, entity semantics, relationship/cardinality, join clock, fanout/dedupe, unmatched behavior, privacy thresholds, side-channel posture, and revocation/correction reach;
5. require a **projection curtain** before any participant contribution or composed output leaves its boundary, including allowed fields/dimensions/measures/grain, aggregate/list/detail posture, policy carryover, thresholds/noise/suppression, no-raw-spill posture, activation/export limits, and refusal;
6. refuse rather than silently pull raw rows, move filters locally, or widen projection when a remote source cannot enforce the fragment it was supposed to enforce;
7. ensure composition failures and join/projection refusals do not leak denied participant, row, key, or suppressed-cell existence;
8. rehydrate delegated authorization, federation trust, and clean-room policy posture before consequential reuse, comparison, export, or agent follow-up.

A federated answer is never allowed to be stronger than its weakest federation pact, join warrant, or projection curtain.


## Semantic identity, crosswalk, and hierarchy hygiene extension

A datacube answer is not promoted merely because two labels, codes, tags, glossary terms, or hierarchy nodes look the same or have the same current display text. Semantic identity is a fresh claim about meaning under a cut.

The minimum semantic-drift review is:

1. identify every consequence-grade axis, member, status, code, term, bucket, rollup, and unit-like qualifier whose meaning affects the answer;
2. attach a **concept anchor** or an explicit missing-anchor refusal/degradation posture, keeping concept identity separate from label snapshots;
3. require a **crosswalk warrant** before comparing, restating, joining, or explaining across renamed, split, merged, broader, narrower, partner-supplied, or imported concepts;
4. attach a **hierarchy cut** before rollups, subtotals, abstract nodes, value-set expansions, or taxonomy-driven buckets become consequential;
5. preserve no-map, bridge-required, review-only, broader/narrower, split/merge, and unmapped states instead of hiding them in `Other`;
6. carry semantic residue through comparability passports, delta anatomies, render contracts, egress receipts, correction horizons, and revocation fences;
7. refuse or downgrade when semantic bridge evidence would overclaim meaning or leak denied/suppressed membership.

A same-looking axis label is never allowed to be stronger than its concept anchor, crosswalk warrant, and hierarchy cut.


## Action, alert, and consequence hygiene extension

A datacube answer is not promoted into an alert, recommendation, workflow input, feature-flag decision, ACP proposal, notification, or control-loop act merely because a value crossed a threshold. Actuation is a fresh authority claim.

The minimum answer-to-action review is:

1. identify the exact answer capsule/cells, state cut, metric card, grain/window/calendar semantics, quality/freshness/privacy/uncertainty/semantic/comparability residues that support the candidate trigger;
2. attach a **threshold witness** or an explicit missing-trigger refusal, naming comparator, baseline/threshold, duration, cadence, tolerance, stabilization, no-data/stale/error/refusal posture, grouping/inhibition/silence/dedupe posture, and pending/firing/resolved/withheld state;
3. require an **action warrant** before any consequence-grade page, notification, recommendation, feature flag, workflow, ACP proposal, scale/throttle/quarantine action, or exported alert can be treated as authorized;
4. keep human-review lane, policy epoch, acceptance floor, budget/payer posture, idempotency/conflict key, rate cap, cooldown, rollback/withdrawal posture, and rehydration requirement near the warrant;
5. record a **consequence receipt** for what actually happened, including no-op, duplicate-suppressed, inhibited, silenced, rejected, errored, withdrawn, or fenced outcomes;
6. keep CH-ACPOUT, CH-NOTIF, policy decisions, event envelopes, and workflow logs as digest-referenced audit evidence rather than authorization or current-state truth;
7. fence old alerts, exports, recommendations, and agent summaries after invalidation, correction, revocation, privacy suppression, semantic bridge change, or action-warrant expiry.

A crossed threshold is never allowed to be stronger than its threshold witness, action warrant, and consequence receipt.

## Learning loop, holdout, and feedback-taint hygiene extension

A datacube answer is not promoted into training data, evaluation data, reward signal, model feature, agent memory, threshold-tuning evidence, or policy-learning material merely because its aftermath was observed. Learning is a fresh authority and evidence claim.

The minimum learning-loop review is:

1. identify the exact source answer capsules, action warrants, consequence receipts, render/egress surfaces, interaction trails, and correction/revocation posture that shaped the observed feedback;
2. attach a **feedback taint fence** to outcomes, labels, clicks, reviewer choices, operator actions, agent summaries, or metrics that may have been affected by cube-mediated display, alert, recommendation, quarantine, ranking, or workflow exposure;
3. require a **holdout witness** or explicit missing-counterfactual refusal before using intervention-shaped differences as effect evidence;
4. require point-in-time feature and label cuts so later repairs, hierarchy changes, semantic bridges, backfills, or privacy releases do not leak into past training/evaluation claims;
5. open a **learning loop ledger** before any training, evaluation, reward, ranking, threshold, policy, or agent-memory use, naming objective/guardrail, label maturity, drift/skew checks, off-policy/experiment evidence, budget/privacy posture, and promotion result;
6. refuse or mark review-only when assignment/logging skew, missing propensities, contaminated holdouts, immature labels, privacy suppression, or correction/revocation gaps would overclaim learning value;
7. keep learning reports non-authoritative until a normal review/edit/promotion path creates fresh action warrants, budgets, rollout boundaries, and rollback/fence requirements.

A learning artifact is never allowed to be stronger than its learning loop ledger, holdout witness, and feedback taint fence.


## Scenario, counterfactual, and synthetic hygiene extension

A datacube answer is not promoted into observed truth merely because a forecast, simulation, synthetic generator, what-if replay, stress test, or counterfactual model can produce a persuasive result. Scenario work is a fresh truth-class claim.

The minimum scenario review is:

1. identify the observed source answer capsules, state cuts, semantic cuts, freshness/quality/privacy/uncertainty residues, and requested consequence class;
2. attach a **scenario capsule** before rendering or exporting any forecast, simulation, stress test, synthetic augmentation, imputation, sensitivity, or what-if answer;
3. name the scenario class, baseline, assumption set, intervention vector, horizon/window, model/simulator/generator identity, parameter cut, training/evaluation cut, and nondeterminism/seed posture;
4. require a **counterfactual warrant** before language implies “would have happened if,” including treatment, outcome, target population, assumptions, identification/refutation posture, feedback taint, holdout evidence, and safe-language limits;
5. attach a **synthetic boundary** to generated, imputed, simulated, forecasted, sampled, cloned, stress-test, or synthetic rows/cells/features/exemplars, including diagnostics, privacy/quality posture, marking, allowed uses, and naturalization prohibition;
6. refuse or mark review-only when leakage, unpinned cuts, missing backtest/refutation evidence, unreviewable randomness, privacy/projection risk, or missing synthetic markings would overclaim scenario strength;
7. require current rehydration, threshold witnesses, action warrants, learning loop ledgers, and egress receipts before scenario material can influence action, learning, export, or policy tuning.

A possible-world answer is never allowed to be stronger than its scenario capsule, counterfactual warrant, and synthetic boundary.

## Model-mediation, translation, and tool-call hygiene extension

A datacube answer is not promoted merely because a model translated a natural-language request into executable query material, repaired an error, called a tool, and produced a fluent summary. Model mediation is a fresh authority and execution-boundary claim.

The minimum model-mediated query review is:

1. attach an **intent binding** before query generation or tool execution, naming actor/lane, original request/digest, follow-up context, ambiguity, selected metric/axis/grain/window/scope/consequence class, denied alternatives, and refusal posture;
2. require disambiguation or explicit policy/default resolution for consequence-grade terms such as “risk,” “top,” “last month,” “current,” “same provider,” “why,” and “recommend”;
3. attach a **translation warrant** before generated SQL, semantic-layer calls, cube-query contracts, or tool plans execute, naming semantic coverage, metric/card/axis/query-contract bindings, projection/privacy/policy checks, invariant tests, expected answer shape, and review result;
4. attach a **tool-call leash** to every model-invoked or agent-suggested tool, naming capability subset, root/source/view boundaries, effect class, validated arguments, budgets, approval, dry-run/retry posture, execution receipt, and result caps;
5. keep tool result, answer capsule, model-written summary, chart, export, draft recommendation, and ACP/action proposal as different residues;
6. refuse or mark review-only when prompt/context injection risk, schema discovery scope, generated-query drift, repair-loop drift, missing invariants, or unbounded tool permissions would overclaim authority;
7. require current rehydration, render/egress receipts, action warrants, learning-loop ledgers, and revocation/correction checks before model-mediated outputs can influence action, export, learning, or policy tuning.

A model-mediated answer is never allowed to be stronger than its intent binding, translation warrant, and tool-call leash.

## Verification, replay, and attestation hygiene extension

A datacube answer is not promoted merely because an evidence packet was packaged, a run was replayed, a claim was signed, or an entry appeared in a transparency log. Verification material helps reviewers challenge an answer; it does not resurrect current authority.

The minimum verification review is:

1. attach a **verification bundle** when an answer, export, action, dispute, or model summary needs audit material, and declare which evidence is embedded, digest-only, located, redacted, withheld, expired, partner-held, or unavailable;
2. attach a **replay recipe** before any rerun/recompute/check claim, and declare replay class: byte-identical, value-identical, tolerance-identical, verdict-identical, explanation-identical, redacted-check-only, or not-replayable;
3. attach an **attestation envelope** when a bundle, recipe, answer, run, export, or verification result is signed, logged, endorsed, witnessed, or otherwise externally checkable;
4. keep issuer/proof/log validity separate from freshness, semantic correctness, policy permission, privacy permission, source authority, and action authority;
5. treat verification packaging as a new egress surface with projection curtains, egress receipts, revocation fences, and privacy/noise posture;
6. rehydrate current authority through current scope/state/freshness/correction/revocation material rather than old signatures or old replay success;
7. refuse or downgrade replay when inputs expired, source cuts were compacted, privacy budgets cannot be re-spent, partner fragments are unavailable, or nondeterminism cannot be pinned.

A signed or replayed answer is never allowed to be stronger than its verification bundle, replay recipe, attestation envelope, and current local appraisal policy.

## Lifecycle custody, retention, and disposition hygiene extension

A datacube answer is not promoted merely because its evidence was retained, archived, locked, forwarded, or disposed. Evidence lifecycle is a fresh claim about handling and allowed future use.

The minimum lifecycle review is:

1. identify every answer capsule, verification bundle, export, replay material, validation sidecar, prompt, exemplar, partner fragment, action receipt, and model summary whose lifecycle matters;
2. attach a **custody trail** when evidence crosses holders, tools, organizations, projections, redactions, signatures, or storage boundaries;
3. require a **retention charter** before keeping sensitive or consequence-grade material beyond ordinary answer/session use, naming purpose, authority, reviewer class, detail level, hold/erasure/privacy pressure, expiry, and allowed use;
4. require a **disposition receipt** when material expires, is deleted, redacted, transferred, sealed, reduced to digest-only, placed under hold, or cannot be disposed;
5. keep logical deletion, revocation, privacy erasure, cryptographic erasure, media sanitization, archive transfer, and legal hold as different lifecycle states;
6. degrade replay recipes, verification bundles, egress receipts, learning ledgers, and action warrants when retained material is reduced or disposed;
7. refuse to use old retained artifacts for current decisions unless current scope, source, semantic, quality, privacy, projection, and action authority are rehydrated.

A retained or disposed artifact is never allowed to be stronger than its custody trail, retention charter, and disposition receipt.

## Contest, adjudication, and remedy hygiene extension

A datacube answer is not promoted into finality merely because it was signed, retained, replayed, exported, explained, or previously acted upon. Contestability is a fresh authority and process claim.

The minimum contestability review is:

1. attach a **contest packet** to the exact answer capsule, cell, rendered artifact, export, action warrant, consequence receipt, learning label, model summary, scenario output, or verification bundle being challenged;
2. name challenger/representative posture, standing, challenged subject, grounds, requested remedy, submitted evidence, missing/inaccessible evidence, privacy/projection limits, and any interim effect;
3. refuse or limit challenges explicitly when standing, scope, privacy, expiry, duplicate/frivolous posture, safety, or partner-boundary rules prevent review, while recording the refusal reason;
4. open an **adjudication docket** before treating review as complete, naming reviewer lane, independence/expertise/conflict posture, procedure/rules snapshot, admitted/excluded evidence, replay/check posture, interim holds, outcome, rationale, unresolved questions, and appeal-next posture;
5. distinguish historical adjudication from fresh re-query: a reviewer may inspect old cuts, replay material, redacted checks, and current rehydration, but must not silently replace the historical question with latest-state truth;
6. emit a **remedy receipt** for explanation-only, correction, amendment, disagreement attachment, withdrawal, suppression, re-render, re-export, notice, rollback, action hold, learning exclusion, recompute/backfill, compensation/credit opening, or refused-remedy outcomes;
7. name derivative reach and residual gaps across dashboards, exports, verification bundles, custody trails, old emails, counsel packets, partner outputs, action warrants, consequence receipts, learning labels, model summaries, scenario capsules, and appeal metrics;
8. require current rehydration before any contested or remedied material can support a fresh consequence.

A contested or remedied artifact is never allowed to be stronger than its contest packet, adjudication docket, remedy receipt, and current rehydration path.

## Stewardship, delegation, and escalation hygiene extension

A datacube answer is not promoted into a change, repair, export, remedy, learning use, or action merely because an owner label, on-call schedule, ticket assignment, catalog entry, code-owner rule, or agent tool permission exists. Governance is a fresh authority claim.

The minimum governance handoff review is:

1. identify every answer family, metric, axis, semantic bridge, source fragment, quality suite, dashboard/export family, remedy class, learning use, or action class whose maintenance authority affects the requested consequence;
2. attach a **stewardship charter** or explicit orphan/stale/no-current-steward posture, naming accountable parties, role types, permitted duties, excluded powers, effective cut, review cadence, conflict posture, successor/backstop lane, and evidence pointers;
3. require a **delegation warrant** before a human, team, service, agent, tool runner, reviewer, or temporary lane performs a maintenance/review/recompute/export/remedy/action-support task on behalf of a steward;
4. keep delegation caveats close to execution: scope, expiry, use count, budget/payer, privacy/projection, raw-detail limits, re-delegation prohibition, revocation/membrane posture, and result-receipt requirement;
5. emit an **escalation handoff** when a local lane cannot decide, when an owner is stale/missing, when a deadline or high consequence triggers escalation, or when conflict/privacy/budget/action gates exceed the current delegate;
6. distinguish assigned, paged, accepted, refused, rerouted, no-response, partial, conflict-declared, emergency-only, and closed states;
7. refuse or mark review-only when owner maps are stale, delegations are expired, escalation evidence is insufficient, conflicts are unresolved, budget authority is missing, or an agent is trying to approve its own work;
8. require current rehydration before governance residue authorizes metric edits, semantic bridges, backfills, exports, remedies, learning uses, action warrants, or ACP-adjacent proposals.

An owner label is never allowed to be stronger than its stewardship charter, delegation warrant, and escalation handoff.

## Governance packet, proof-obligation, and decay-fixture extension

A datacube answer is not promoted into current governance authority merely because stewardship, delegation, or escalation vocabulary appears in nearby prose. Governance residue must compile into a packet that can pass or refuse the exact requested consequence.

The minimum governance-packet review is:

1. bind the packet to exact answer-family, metric, axis, source fragment, semantic bridge, export family, remedy class, learning use, action class, and artifact refs;
2. carry currentness envelopes for charters, warrants, and handoffs: source cut, effective cut, last rehydration, review-by/expiry, status, successor/backstop, and supersession posture;
3. evaluate PO-GOV-001 through PO-GOV-011 before allowing any repair, recompute, export, remedy, learning, action, or emergency override;
4. label owner hints, catalog labels, code-owner maps, on-call routes, ticket assignments, and agent tool permissions as non-authority unless converted through a current charter, warrant, or accepted handoff;
5. return typed refusal/degradation states such as `routing_hint_only`, `review_only`, `needs_rehydration`, `authority_missing`, `handoff_unaccepted`, `expired_warrant`, `privacy_projection_block`, or `agent_boundary_violation` instead of a bare boolean;
6. project governance evidence by audience so proving authority does not leak internal people, conflicts, incidents, partner fragments, or sealed emergency details;
7. maintain positive and negative fixtures before promoting stronger governance vocabulary.

A governance handoff packet is never allowed to be stronger than its proof obligations, currentness envelope, fixture coverage, and projection/minimization posture.


## Pass LXXIX construction rule: weak-state closures

When a pass introduces a weak governance state, add both a positive fixture and a promotion-failure fixture. The weak state must declare what it may do, what it must not imply, and what projection class it can safely expose. Routing hints and break-glass states are the current examples.


## Pass LXXXI consumer-receipt hygiene

When a Ward governance decision event crosses into another cube, require a consumer receipt before treating the event as rendered, retained, scheduled, attached, indexed, or summarized. The receipt must bind the event digest, mirror the packet reference, preserve forbidden effects, make weakness visible, carry a no-authority statement, and record replay/compaction posture. A consumer may downgrade a state when packet replay is unavailable; it may not upgrade a state without a fresh Ward packet and fresh decision event.

## Pass LXXXII batch/search aggregation hygiene

When a pass introduces a search result, batch summary, queue view, entitlement-like list, or portal table over governance decision consumer receipts, require a batch/search receipt before treating the aggregate as rendered, retained, paginated, or summarized.

The receipt must:

1. reference each member consumer receipt by ID, path, and digest;
2. mirror state, replay status, projection class, projection view, downgrade reasons, and forbidden-effect fences per member;
3. expose state counts and replay-status counts rather than a single green badge;
4. preserve the exact union of forbidden effects;
5. use least-privilege projection joins and disclose public/restricted omissions;
6. bind search cursors to query and projection-filter digests;
7. refuse raw authority counts and high-consequence aggregate effects;
8. record compaction and minimum replay-status boundaries.

A batch/search receipt is never allowed to be stronger than its weakest relevant member and never creates authority by counting, grouping, filtering, or paginating evidence.


## Search-continuity and sealed-omission hygiene

Before a datacube promotes paginated governance search, require:

- a query digest and request fingerprint for every page;
- prior/current page receipt digests;
- projection-policy digest comparison;
- owner-map epoch comparison;
- packet-compaction watermark comparison;
- explicit drift response when any basis changes;
- sealed-omission mode suitable for the audience;
- no exact public hidden counts, per-subject hidden counts, or sealed reason leaks;
- no export, action, repair, remedy, learning, delegation, or budget effects from a continuation receipt alone.

## Evidence-release hygiene

Before a datacube releases governance evidence outside the current trusted path, require a governance evidence-release receipt.

The receipt must:

1. reference exactly one batch/search or search-continuity receipt by ID, path, and digest;
2. mirror source query digest, projection-policy digest, operation, result state, and drift state;
3. bind release to a recipient class and named purpose;
4. bind selection by digest and list field allowlist plus sensitive field denylist;
5. disclose sealed omissions only through audience-safe modes;
6. carry retention horizon, refresh/revocation channel, onward-use restrictions, and no-authority watermark;
7. preserve source forbidden-effect fences;
8. refuse high-consequence effects such as action re-enable, semantic repair, remedy, budget spend, privacy waiver, learning use, or delegation.

A released evidence bundle is never allowed to be stronger than its source receipt, projection policy, recipient/purpose binding, and refresh/revocation posture.

## Pass LXXXV release follow-up hygiene
When a datacube exports or releases governance evidence, it must also define how released artifacts are acknowledged, corrected, revoked, quarantined, or refused for reuse. Follow-up receipts must bind the original release digest, preserve recipient and purpose, carry a status pointer, avoid public leakage, keep no-authority labels visible, and never mutate the original release in place.

## Pass LXXXVI succession/transfer hygiene
When a released governance artifact, follow-up status, responsible contact, projection-policy steward, custody operator, or status channel changes hands, require a governance succession/transfer receipt before treating the chain as current.

The receipt must:

1. bind the source release receipt and latest follow-up receipt by id, path, and byte digest;
2. mirror recipient class, purpose, projection-policy digest, source item digest, and latest follow-up state;
3. close predecessor authority with notification, end time, and no-continuing-authority posture;
4. record successor acceptance, refusal, pending, dual-control-pending, or held-recheck state;
5. rotate or invalidate old status channels when required;
6. preserve no-authority labels and forbidden-effect fences;
7. minimize public successor identity and sealed organizational evidence;
8. refuse release reuse while the successor is pending, refused, held, or unverified.

A successor label is never stronger than the source release, latest follow-up, predecessor closure, successor acceptance, and status-channel continuity checks.

## Pass LXXXVII construction rule — chain integrity before current-use

When a cube exports, renders, attaches, or reuses a Ward governance evidence release after follow-ups or transfers exist, it must not select “latest receipt” by timestamp or URL alone.

Require a chain-integrity receipt when:

- release, follow-up, and transfer receipts are all relevant;
- a status channel was rotated;
- a successor is pending or disputed;
- two consumers observed different current heads;
- a public surface wants to disclose a branch/fork state;
- a SlopOS action/export/tool/CH-AREF path wants to reuse previously released governance evidence.

A chain-integrity receipt must bind ordered member ids and byte digests, replay member validators, preserve source release/purpose/recipient/source-item/projection-policy parity, union forbidden effects, and either publish a canonical status head or explicitly hold reuse because no current head exists.

## Pass LXXXVIII construction rule — dispute resolution after chain integrity

When a chain-integrity receipt reports a fork, disputed head, pending successor, chain recheck, or historical-minimized state, do not mutate the chain-integrity receipt and do not choose a current head by timestamp.

Require a governance dispute-resolution receipt when:

- a forked chain is closed or held;
- a successor-pending chain becomes accepted or remains pending;
- an old status channel is withdrawn after a branch dispute;
- a public surface wants to say a dispute was resolved or sustained;
- a SlopOS action/export/tool/CH-AREF path wants to reuse a previously held release;
- a historical-only chain needs a portable non-spendable resolution.

A dispute-resolution receipt must bind the source chain id/path/byte digest and source chain digest, replay the source-chain validator, bind the observed branch set, record a disposition for every branch, preserve no-authority labels and forbidden effects, notify affected recipients/status channels, and either recover a status pointer that still requires refresh/replay or sustain a no-current-head hold.

## Pass LXXXIX construction rule — recertification before cached-resolution reuse

When a cube caches, renders, exports, attaches, or reuses a Ward governance dispute-resolution receipt after its first consumption, it must not treat “valid when cached” as current.

Require a governance recertification receipt when:

- a recovered current head was cached by Helm, ViewFS, Harbor, Schell, or SlopOS;
- a detached export or CH-AREF attachment points at an old dispute-resolution receipt;
- a status channel, recipient refresh channel, projection policy, owner-map epoch, successor state, branch state, or follow-up signal may have changed;
- a public surface wants to show that a cached resolution remains current;
- a consumer wants to proceed after a stale-bundle warning;
- a cached resolution is being used near export, action, repair, remedy, learning, budget, delegation, or portal behavior.

A recertification receipt must bind the source dispute-resolution id/path/byte digest, replay its validator, compute a cache-subject digest, recheck status and refresh channels, check projection/owner/successor/branch/follow-up/clock evidence, set a next recheck due time, preserve no-authority labels and forbidden effects, and either mark the cache current-refresh-required, invalidated, quarantined, historical-only, or recheck-required.

A recertified cache is still weaker than source-packet replay.


## Pass XC construction rule — signal ingestion before signal-driven recertification

When a cube receives a refresh, revocation, projection-policy, successor, branch, quarantine, or status signal that could affect a cached governance resolution, do not treat transport delivery as state change.

Require a governance signal-ingestion receipt when:

- a status/refresh channel delivers a signal for a cached Ward release or dispute resolution;
- push delivery is acknowledged but consumer refresh is not proven;
- poll results arrive out of order or below a known watermark;
- duplicate source/id events recur;
- two status signals conflict;
- a public surface wants to explain that a bundle is revoked, stale, current-for-display, or held;
- a SlopOS CH-AREF, portal, export, action, tool, learning, remedy, or budget path wants to react to a signal.

A signal-ingestion receipt must bind the source recertification id/path/byte digest, signal envelope, source/id event key, subject digest, cache-subject digest, receiver observation, duplicate window, watermark, conflict set, payload classification, follow-up requirement, projection safety, and forbidden-effect fences.

A signal can request recertification or cache invalidation, but cannot itself grant authority, prove every consumer refreshed, mutate the source recertification receipt, or authorize consequence.

## Pass XCI construction note

Signal-notification receipts should remain downstream lifecycle hygiene until multi-receiver reconciliation proves they deserve promotion. Add consumer-set digests, delivery payload digests, retry/dead-letter states, and no-authority labels before any notification fanout can be interpreted by SlopOS or companion cubes.

## Pass XCIII construction rule — receiver convergence before multi-receiver reuse

When more than one Ward receiver can affect a cached governance status, do not let the latest receiver, cleanest receiver, or receiver majority become global truth. Require a governance receiver-convergence receipt when a SlopOS recheckpoint, Helm/ViewFS render, Harbor stale-surface decision, Schell projection, or public status surface wants to rely on multiple receiver observations. The receipt must bind source reconciliation bytes, receiver-set digest, overlap-consumer digest, status-channel cut digest, receiver observation state, projection safety, and forbidden-effect fences. Convergence remains non-authority and still requires replay/refresh before consequence.



## Reuse-gate hygiene — added in rev0094

Before downstream surfaces reuse receiver-convergence evidence, bind the source bytes, purpose, consequence class, requested effect, projection policy, cache subject, and request window. Display reuse must not imply export, repair, remedy, learning use, budget spend, delegation, or action.

## Pass XCVII construction note

When adding a governance receipt family, update all three machine-maintenance layers together:

1. register checker, fixture family, schema path, and schema id in `tools/governance_checker_registry.json`;
2. add positive and negative fixture directories with schema parity;
3. ensure `tools/check_schema_catalog_integrity.py` sees the schema file as registered.

Rollback/remediation nouns may only be promoted after they can prove both sides of the seam: no-remediation-needed must stay smaller than durable trust, and remediation handoff requested must stay smaller than remedy completed.

## Pass XCVIII construction rule — closure is smaller than remedy

When a rollback-remediation receipt closes review, confirms no-remediation-needed, acknowledges a handoff, or escalates unavailable observation, do not treat that closure as proof that a remedy occurred.

Require a governance remediation-closure receipt when:

- rollback review is closed but quarantine remains active;
- a remediation handoff request is acknowledged by Harbor, Helm, SlopOS, or another consumer;
- no-remediation-needed or no-op closure is displayed downstream;
- an unavailable observation hold is escalated;
- a public surface wants to show closure status after a mismatch;
- a SlopOS CH-AREF, portal, export, action, remedy, learning, budget, or tool path wants to reuse closure status.

A remediation-closure receipt must bind the source rollback-remediation id/path/byte digest, mirror source remediation and review state, compute a closure-scope digest, record verification evidence and verification debt, preserve no-authority labels and public projection minimization, and forbid rollback execution, remedy completion, quarantine clearance, source mutation, status-pointer mutation, export, repair, learning use, and authority.

A closure can end bookkeeping for a bounded review state. It cannot clear quarantine or prove external remediation without a separate proof-intake surface.

## Rev0099 construction note

Verification proofs must be recorded as non-authority receipts downstream of closure; do not let proof intake clear quarantine or complete remedy.
