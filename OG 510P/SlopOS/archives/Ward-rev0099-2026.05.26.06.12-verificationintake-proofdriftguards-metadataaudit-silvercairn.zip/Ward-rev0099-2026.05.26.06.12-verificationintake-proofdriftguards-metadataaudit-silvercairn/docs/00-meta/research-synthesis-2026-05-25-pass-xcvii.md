# Research synthesis — pass XCVII

## Focus

Pass XCVII tests the post-observation rollback/remediation seam. Rev0096 could say whether an execution's observed result matched, no-opped, was unavailable, or mismatched. The missing closure was what Ward can safely record next without pretending that observation equals remedy authority.

## Findings

1. **Incident response recovery is not just cleanup.** NIST SP 800-61 Rev. 3 connects incident response to preparation, detection, response, recovery, lessons learned, and risk-management feedback. Ward should therefore record rollback/remediation posture as reviewable evidence and learning pressure, not as an invisible local fix (`EXT-NIST-SP-800-61R3-2025`).
2. **Compensation is not universally safe.** Azure's compensating transaction pattern explicitly warns that compensation logic is application specific, may fail, often needs progress tracking/resume, should be idempotent when retried, and may require manual intervention. Ward's governance consequences are even less safely auto-reversible, so v0 records review/handoff posture and refuses rollback execution (`EXT-AZURE-COMPENSATING-TRANSACTION-2026`).
3. **Saga pressure helps but must be contained.** Saga patterns show why undo logic exists in distributed systems, but they also tempt a design to treat every failed step as automatically compensable. Ward instead says a mismatch can open review or request handoff; it cannot execute repair, remedy, export, learning use, or action re-enable (`EXT-AZURE-SAGA-PATTERN-2026`).
4. **Events and provenance remain correlation, not authority.** CloudEvents source/id identity and W3C PROV activity/entity/agent separation are useful for tracing remediation evidence, but neither should collapse into authority to mutate source receipts or status heads (`EXT-CLOUDEVENTS-SPEC-2026`, `EXT-W3C-PROV-DM-2013`).

## Design consequence

Add `ward.governance-rollback-remediation-receipt.v0` as a non-authority receipt downstream of outcome observations. It may close no-remediation-needed, hold, maintain quarantine, open rollback review, or request a remediation handoff. It cannot execute rollback, perform remedy, mutate sources, update status pointers, export evidence, or grant authority.

## Audit/refactor consequence

Add a schema-catalog audit so schema files cannot silently exist outside the checker registry. This complements registry integrity and fixture-catalog integrity: registry checks the declared checker map, fixture catalog checks example layout, and schema catalog checks the schema directory itself.
