# Research synthesis — pass LXVII

Pass LXVI made weakened answers visible: resource-constrained, approximate, sampled, noisy, stale, summary-only, or otherwise degraded answers must not impersonate the exact answer requested. Pass LXVII follows the next failure mode: even an exact answer may later become historically revised, withdrawn, superseded, or fenced from consequence because late facts, corrected identity, backfills, hard deletes, revocations, erasure duties, retention windows, or change-feed gaps change what can safely be claimed.

The restraint rule still holds. Ward should not choose a warehouse table format, stream processor, change-data-capture system, bitemporal database, audit-log backend, data-version-control product, legal-erasure workflow, or global finality doctrine. The datacube is still in SlopOS design phase, so the right move is to name small residues that let a future cube revise history without either rewriting the past or treating yesterday's answer as forever-current.

## What the past says we must learn now

1. **Watermarks are progress claims, not omniscience.** Flink's event-time model treats watermarks as declarations that, by that point in the stream, events up to a timestamp should have arrived, while its late-data guidance still acknowledges allowed lateness and side paths for events that arrive after a window appears ready (`EXT-FLINK-STREAMING-ANALYTICS-2026`). Ward should steal the humility: a cube answer can be closed for ordinary display while still admitting a correction horizon.

2. **Change feeds have birth dates and retention horizons.** Delta Lake change data feed records row changes for updates, deletes, and merges after the feed is enabled, and its change data follows table retention/VACUUM behavior (`EXT-DELTA-CDF-2026`). A SlopOS datacube should not say “we have the delta” unless it can name the start version, end version, and retained-change horizon; older or vacuumed history may require full replay, a backfill ledger, or refusal.

3. **Snapshot history is a window, not a moral guarantee.** Iceberg treats writes/updates/deletes/upserts/compaction as new snapshots while retaining older metadata until snapshot expiration and maintenance remove no-longer-needed history (`EXT-ICEBERG-MAINTENANCE-2026`). BigQuery time travel keeps changed/deleted data queryable only inside a configurable window and has a non-queryable fail-safe period afterward (`EXT-BIGQUERY-TIME-TRAVEL-2026`). Snowflake likewise separates Time Travel from later Fail-safe recovery (`EXT-SNOWFLAKE-TIME-TRAVEL-2026`). Ward should keep replayability, emergency recoverability, and ordinary answer authority separate.

4. **Hard deletes are design choices, not one absence truth.** dbt's `hard_deletes` config can ignore source deletions, invalidate rows, or create new deleted-state records with metadata (`EXT-DBT-HARD-DELETES-2026`). dbt snapshot/SCD surfaces also remind Ward that validity windows and natural-key history need explicit non-overlap/identity discipline (`EXT-DBT-SNAPSHOTS-2026`). A SlopOS answer should distinguish “row absent from current source,” “explicit delete state,” “revoked for future consequence,” and “not revealable under policy.”

5. **Compacted survivor state is useful but weaker than complete history.** Kafka log compaction can retain the latest value for each key and tombstones, but tombstone retention bounds how long consumers have to rebuild a valid snapshot from the beginning (`EXT-KAFKA-LOG-COMPACTION`). Ward already knew this in earlier state/compaction passes; LXVII applies it to cube answers: if a derivative was rebuilt from a compacted survivor view, it should not claim full correction provenance.

6. **Maintenance actions deserve timeline identity.** Hudi's table timeline names actions such as commits, cleans, delta commits, compactions, rollbacks, and savepoints, and gives instants states like requested, inflight, and completed (`EXT-HUDI-TIMELINE-2026`). Ward should steal the idea of visible action classes and states for backfill/recompute/correction campaigns without importing Hudi as a substrate.

7. **Valid time and system time are different truths.** System-versioned temporal-table practice keeps full history for point-in-time analysis, while bitemporal modeling distinguishes when facts are valid in the world from when the system recorded them (`EXT-SQLSERVER-TEMPORAL-TABLES-2025`). For trust answers, effective change time, event time, ingestion time, publication time, local adoption time, and answer-production time should not collapse.

8. **Lifecycle facets are useful only if they stay small.** OpenLineage's facets include dataset lifecycle state changes and dataset versions, e.g. Iceberg snapshot IDs (`EXT-OPENLINEAGE-FACETS-2026`). Ward should steal facet-shaped growth for correction evidence while resisting the temptation to call a lineage event enough to make an old cube answer current or invalidated.

## Resulting Ward move

Do **not** decide yet:

- one bitemporal database, table format, CDC system, lakehouse version-control product, or stream engine;
- one representation for event time, valid time, transaction time, publication time, local adoption time, and answer time;
- one universal lateness window, correction SLA, backfill schedule, or finality rule;
- one legal erasure / revocation / deletion workflow or one global recall mechanism for exports;
- one rule that all historical answers are rewritten in place after correction;
- one rule that all old answers remain forever reviewable despite policy, privacy, or retention limits;
- one plan language for computing backfills or proving affected cells;
- one UI grammar for “revised,” “withdrawn,” “fenced,” “superseded,” or “safe to compare.”

Do add three small, reversible residues for history repair and withdrawal:

- **correction horizon** — compact posture saying which prior answer cuts, cells, axes, windows, or source versions remain open to late facts, amended identity, changed validity periods, delete/revoke states, privacy/legal changes, or recompute. It names the relevant time families, retention/change-feed coverage, ordinary-close versus repair-only posture, and whether consequences must revalidate.
- **backfill ledger** — compact campaign record for deliberate historical repair. It names reason, authority, affected safe scope, source/change-feed/time-travel coverage, recipe/run identity, validation/quality gates, budget/degradation posture, outputs invalidated or replaced, and residual gaps. It is smaller than a scheduler or workflow engine but stronger than an ops note.
- **revocation fence** — compact boundary that prevents a withdrawn, deleted, erased, superseded, invalidated, or policy-fenced answer/cell/export/exemplar from being treated as current authority. It names safe reason class, propagation targets, egress/export posture, rehydration requirement, and non-oracle disclosure limits.

These residues sit beside earlier nouns. A correction horizon may constrain freshness envelopes, comparability passports, delta anatomies, render contracts, egress receipts, budget gates, and recompute dockets. A backfill ledger may emit invalidation receipts and replacement answer capsules. A revocation fence may produce refusal receipts for drill-through, export, or agent reuse without claiming that the underlying facts never existed.

## Brilliant ideas to steal now

- **Closed-for-now, open-for-correction.** A window can be display-closed while still within late-arrival or policy-revision reach.
- **Change feed with stated coverage.** Delta-style version ranges and retention behavior are excellent pressure for “patchable from here, replay needed before there.”
- **Timeline action classes.** Commits, compactions, rollbacks, cleans, savepoints, backfills, repairs, and fences deserve typed process residue when they affect answer authority.
- **Explicit deleted state.** dbt's `new_record`-style deleted rows are a good anti-lesson against silent disappearance; sometimes deletion itself is the fact that downstream users need.
- **Tombstone/rebuild bounds.** Compacted survivor views are useful only if tombstone retention and rebuild horizon are visible.
- **Replayability versus recoverability.** Time-travel, snapshot, and fail-safe windows remind Ward that recoverable-by-operator is weaker than queryable-by-answer-capsule.
- **Bitemporal humility.** Correction of what was true then and discovery of that correction now are different movements.
- **Facet-shaped correction evidence.** Lifecycle/version facets can be attached without forcing one global lineage database.

## Still-not-yet decisions

- Whether every answer capsule needs a correction horizon or only repeated, consequential, materialized, exported, or comparison-prone answers.
- Whether correction horizons attach to whole answers, axes, cells, source cuts, materialization generations, or egress artifacts.
- Whether backfill ledgers are opened for all late data or only for deliberate historical repair beyond ordinary lateness.
- Whether revocation fences should be durable public notices, private authority checks, or both.
- How long old fenced answers remain reviewable once privacy/legal or retention rules change.
- Whether a backfill ledger can safely report affected row/cell counts without leaking suppressed or denied populations.
- How to compare old and new answers when one side is outside the retained change-feed or time-travel window.
- Whether there should be a “history repaired, comparison bridge required” posture distinct from stale, invalid, and withdrawn.

## Process note

Pass LXVII does not add a temporal database, CDC pipeline, table-format doctrine, or global recall layer. It adds correction/withdrawal hygiene so SlopOS-facing datacube answers can survive late facts and backfills without historical amnesia or consequence-grade stale truth. The next healthy move is to run these residues against a specimen where a previously exported trust answer is corrected, partially backfilled, and fenced from future reuse while old evidence remains reviewable only through current authority.
