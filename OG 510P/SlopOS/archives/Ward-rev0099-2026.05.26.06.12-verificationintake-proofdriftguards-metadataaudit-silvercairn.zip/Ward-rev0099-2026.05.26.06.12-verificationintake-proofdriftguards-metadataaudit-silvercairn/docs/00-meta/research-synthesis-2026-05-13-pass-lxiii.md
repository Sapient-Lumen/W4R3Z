# Research synthesis — pass LXIII

Pass LXII made comparison a first-class answer. Pass LXIII goes one layer deeper: after a comparison says **something changed**, everyone asks **why**. In a trust-bearing SlopOS datacube, the why-answer is more dangerous than the number. A polished explanation can smuggle causality, widen observation scope, cherry-pick sensitive examples, or erase residual uncertainty even when the underlying comparison was honest.

The restraint rule remains unchanged. Ward should not choose a causal-inference framework, root-cause engine, anomaly detector, lineage product, drill-through API, or explanation UI while SlopOS is still in design. The healthy move is to add tiny residues that force explanations to say what kind of explanation they are allowed to be.

## What the past says we must learn now

1. **Provenance is structured, but not self-explanatory.** W3C PROV gives domain-agnostic provenance concepts and extensibility points for entities, activities, and agents (`EXT-W3C-PROV-DM-2013`). Ward should steal the typed shape, not the whole web-provenance stack: a datacube explanation should say what entity/result, activity/query, and agent/reviewer/run are being discussed.

2. **Why, where, and how provenance are different questions.** The database-provenance survey distinguishes why-, how-, and where-provenance and ties them to confidence computation, view maintenance, debugging, and annotation propagation (`EXT-CHENEY-PROVENANCE-SURVEY-2009`). Ward should not answer “why did the trust score move?” with only “which table did this column come from?”

3. **Derivations are not a single thread.** Provenance semirings show that relational results can carry multiple derivations and support richer how-provenance (`EXT-PROVENANCE-SEMIRINGS-2007`). Ward's explanation posture should preserve residual and alternate-support buckets instead of flattening every change into one decisive source.

4. **Column lineage is useful, but too narrow for trust explanation.** OpenLineage's column-level lineage facet records fine-grained dependencies and transformation types for output columns (`EXT-OPENLINEAGE-COLUMN-LINEAGE-2026`). Ward should steal the idea of transformation-shaped influence, while keeping row membership, scope, refusal, privacy, and metric semantics outside a mere column lineage story.

5. **Data diffs prove differences, not causes.** Datafold frames data diffing as value-level comparison between tables to identify critical changes (`EXT-DATAFOLD-DATA-DIFF-2026`), and Reladiff uses segment checksums and recursive subdivision to find differing rows efficiently (`EXT-RELADIFF-TECH-2026`). Ward should steal diff artifacts as evidence, but never let “row changed” become “this caused the trust outcome.”

6. **Observability contrast is powerful and easy to over-read.** Honeycomb's BubbleUp-style outlier workflow compares a selected region with the baseline to surface distinguishing dimensions (`EXT-HONEYCOMB-OUTLIERS-BUBBLEUP-2026`). Ward should steal contrast-first discovery, but label it as cohort contrast unless stronger evidence earns a causal rail.

7. **Exemplars are bridges, not proof.** OpenTelemetry exemplars link aggregated metrics to individual measurements/traces and are useful for exploring outliers (`EXT-OTEL-EXEMPLARS-2026`). Ward should steal exemplar links, but wrap them in privacy, scope, and representativeness fences so a vivid case cannot impersonate the whole cell.

8. **Static probes catch explanation bugs before production truth is touched.** dbt unit tests validate SQL modeling logic on small static inputs before materializing production models (`EXT-DBT-UNIT-TESTS-2026`). Ward should steal the fixture habit: explanation decompositions deserve small known-case probes, especially around label splits, refusal cells, dedupe, and denominator movement.

9. **Causal claims require counterfactual discipline.** The CausalImpact paper frames causal impact in terms of estimating the counterfactual response that would have occurred without an intervention and explicitly discusses strengths and limitations when randomised experiments are unavailable (`EXT-CAUSALIMPACT-2015`). Ward should make causal language a high-friction rail, not a default chart narration style.

10. **The old dashboard failure is confident storytelling.** Once a trend exists, users, dashboards, and agents tend to demand a crisp answer. SlopOS's scope/snapshot/handle discipline means the honest result may be: “the observed delta is partly accounted for by scope narrowing, partly by metric drift, partly by refused cells, and partly unexplained.” That is a better answer than a false root cause.

## Resulting Ward move

Do **not** decide yet:

- one universal root-cause, anomaly, attribution, or causal-inference engine;
- one data-diff or row-drill mechanism;
- one PROV/OpenLineage/observability schema for all explanation residue;
- one UI grammar for why-panels, drilldowns, or examples;
- one policy for when a human or LLM may propose a causal story;
- one rule for how much raw evidence can be exposed behind a cell;
- one global confidence score for explanation quality.

Do add three small, reversible residues for changed datacube answers:

- **delta anatomy** — compact decomposition of an observed change into named movement classes such as fact movement, population/scope movement, metric logic movement, axis/member bridge movement, quality/refusal movement, privacy/suppression movement, materialization/tier movement, late-correction movement, and residual unexplained movement. It is smaller than a data-diff product and weaker than a causal claim.
- **attribution rail** — compact claim-strength lane for an explanation fragment: accounting decomposition, where/lineage, how/derivation, value diff, cohort contrast, exemplar/drill-through, or causal/counterfactual. It names allowed verbs, assumptions, method, evidence, uncertainty, and forbidden upgrades. It is smaller than a causality framework.
- **exemplar fence** — compact guard around any example record, trace, handle, row, or drill-through case used to illuminate an aggregate. It names selection rule, scope, redaction, privacy threshold, representativeness posture, and no-cherry-pick caveat. It is smaller than a drilldown API and stronger than a screenshot.

These residues sit after comparison. A delta anatomy consumes comparability passports, drift notices, quality witnesses, scope lenses, state cut witnesses, axis capsules, metric/query cards, refusal receipts, and lineage facets. An attribution rail constrains what the explanation is allowed to say. An exemplar fence constrains what evidence may be shown.

## Brilliant ideas to steal now

- **Why as its own answer capsule** — a why-answer has scope, cuts, lineage, refusal, and comparison posture just like a numeric answer.
- **Residual bucket as truth** — unexplained movement is not embarrassment; it is a useful refusal against overclaiming.
- **Allowed-verbs discipline** — “accounts for,” “is associated with,” “came from,” and “caused” should live on different rails.
- **Exemplar without representativeness** — examples can help orientation while explicitly refusing to be representative.
- **Probe fixtures for explanations** — tiny static cases should prove that label splits, denominator changes, refused cells, and late corrections decompose correctly.
- **Diff artifact weaker than root cause** — row-level differences are evidence for movement, not a causal story.
- **Contrast-first discovery with brakes** — borrow high-cardinality contrast to find candidate dimensions, then keep the claim observational until stronger evidence exists.
- **Counterfactual friction** — causal claims need intervention/counterfactual evidence, not merely a changed chart.

## Still-not-yet decisions

- Whether delta anatomies attach to whole comparisons, measures, cells, cohorts, axis members, or all of those.
- Whether attribution rails should be machine-enforced enums, human review checklists, or both.
- Whether exemplar fences should be generated by SlopOS, Ward, Helm, ViewFS, or a future drill-through companion.
- Whether LLM-generated explanations may draft attribution rails, and what deterministic checks must validate them.
- Whether causal rails should exist in Ward at all or remain an external reviewed-analysis artifact.
- Whether examples should be stored, linked by handle, generated on demand, or forbidden for some trust surfaces.
- Whether explanation probes belong in the datacube construction protocol, a future test suite, or companion-specific CI.

## Process note

Pass LXIII does not add root-cause analysis. It adds language for refusing premature root-cause analysis. The next healthy move is to run these residues against a SlopOS trust-deterioration comparison where a chart worsens and a human asks why. If Ward cannot separate accounting movement, diff evidence, cohort contrast, exemplars, and causal claims, it should refuse the why-story rather than narrate a polished lie.
