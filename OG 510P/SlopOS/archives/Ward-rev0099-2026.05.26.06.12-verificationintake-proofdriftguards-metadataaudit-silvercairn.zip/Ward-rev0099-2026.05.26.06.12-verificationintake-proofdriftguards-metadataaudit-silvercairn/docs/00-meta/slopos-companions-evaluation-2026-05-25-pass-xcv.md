# SlopOS companions evaluation — pass XCV

## SlopOS

SlopOS should treat a Ward use-execution receipt as a replayable fact about a bounded display/review/hold/refusal/quarantine, not as a capability handle, CH-AREF grant, or recheckpoint approval.

## Helm

Helm can use the positive public-display fixture as a rendering contract: show a minimized status chip with a no-authority label and do not update canonical status pointers from the execution receipt.

## Harbor

Harbor can use the refusal fixtures to keep correction/recompute paths from turning a reuse gate into repair authority.

## Schell and ViewFS

Schell and ViewFS should inspect projection-safety fields before retaining or showing use-execution records. Public records must not leak sealed source payloads, private org maps, or receiver identities.

## Steward and Foundry

Steward and Foundry should not treat execution evidence as stewardship acceptance or crosswalk repair approval. They may consume it only as an audit trace that a gate was respected.
