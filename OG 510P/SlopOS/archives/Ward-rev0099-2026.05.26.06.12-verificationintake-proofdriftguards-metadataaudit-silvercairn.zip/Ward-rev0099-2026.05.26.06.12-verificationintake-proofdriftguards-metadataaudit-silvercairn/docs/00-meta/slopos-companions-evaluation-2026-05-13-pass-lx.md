# SlopOS / companions evaluation — pass LX

This pass treats SlopOS as still in design. That matters. Ward should not pretend the SlopOS datacube already has stable storage, query, materialization, or export boundaries. The safest contribution Ward can make right now is to collect small, separable answer residues that help future SlopOS surfaces stay honest.

## What the included cubes keep teaching

- **SlopOS** remains the strongest nearby teacher. Its D-ATTRFS posture keeps attribute query view-scoped, snapshot-first, and handle-returning; CH-ATTRQ stays bounded and small rather than becoming an ambient global analytics authority. Ward should mirror that restraint: a datacube answer should be rooted in a view/snapshot and return handles or answer capsules before it claims universal truth.
- **ViewFS** keeps the capability-native lesson sharp: object handles, previews, manifests, portals, and receipts are not interchangeable. Ward's datacube analogue is that answer cells, exported batches, materialized summaries, and durable promoted facts must not collapse behind one title.
- **Harbor** warns that boundary facts can be useful without becoming native authority. Ward should treat external cube outputs, semantic-layer answers, and warehouse summaries as imported facts needing appraisal residue.
- **Foundry** warns against choosing a host substrate too early. Ward should allow relational, array, object-manifest, columnar, and lineage-backed realizations to compete behind a small public answer shape.
- **Schell** keeps command intent, effect lanes, and receipts visible. Ward should steal a query/plan receipt pattern for recurring questions without turning every query into a shell command.
- **Steward** keeps lifecycle readiness and activation receipt language separate from the thing activated. Ward should apply the same split to datacube materializations: created, refreshed, promoted, retained, downsampled, and expired are lifecycle facts, not measure truth.
- **Helm** reminds Ward not to confuse UI display with object truth. A rendered dashboard, inspector, or chart is a surface over an answer capsule, not the datacube itself.

## What outside systems add to the datacube posture

- Gray et al. add the lattice lesson: cube value comes from controlled aggregation and subtotal families, but the first Ward move should not be a mandatory OLAP engine (`EXT-DATACUBE-GRAY-1997`).
- Kimball adds the grain lesson: if Ward cannot say what one answer row/cell means, it has no business promoting the metric (`EXT-KIMBALL-GRAIN-2003`).
- W3C Data Cube adds a clean conceptual split among dimensions, measures, attributes, observations, and slices; Ward can borrow that split without borrowing RDF or SDMX (`EXT-W3C-RDF-DATACUBE-2014`).
- Iceberg adds the layout lesson: physical partitioning can evolve and be hidden from logical queries, but layout still needs to surface when it changes answer comparability or replayability (`EXT-ICEBERG-HIDDEN-PARTITIONING-2026`).
- Substrait adds the plan-portability lesson: a plan can be a boundary artifact without making one execution stack the only future (`EXT-SUBSTRAIT-PRINCIPLES-2026`, `EXT-SUBSTRAIT-RELATIONS-2026`).
- Arrow adds the interchange lesson: a precise columnar crossing format is useful exactly because its non-goals are clear (`EXT-ARROW-COLUMNAR-2026`, `EXT-ARROW-C-DATA-2026`).
- OpenLineage adds the facet lesson: provenance should be attached in a compact, extensible way, not smeared into every metric field (`EXT-OPENLINEAGE-OBJECT-MODEL-2026`).
- TileDB adds the sparse/dense lesson: absence, zero, and filled values need distinct posture in a cube-shaped surface (`EXT-TILEDB-ARRAY-MODEL-2026`).

## Recommended datacube posture for Ward right now

1. **Root answer identity in a view/snapshot before global analytics.** A SlopOS-shaped datacube should start from bounded view authority, not an omniscient warehouse namespace.
2. **Promote answer capsules before universal schemas.** An axis capsule says enough to compare, rerun, and inspect a promoted answer without freezing the future storage model.
3. **Keep layout visible but non-constitutional.** A layout aperture lets physical choices matter when they matter, without letting partitioning, downsampling, array tiling, or columnar export become logical truth by accident.
4. **Attach lineage as a facet.** A lineage facet gives Ward enough provenance to rerun, diff, downgrade, or quarantine an answer while leaving SlopOS free to choose its later diagnostic, receipt, or orchestration mechanics.
5. **Prefer reversible descriptors over registries.** While SlopOS is design-phase, Ward should add specimen-backed descriptors and promotion questions, not a broad registry of dimensions/measures/materializations.

## Specific anti-lessons from the past

- Do **not** choose one cube product shape because old OLAP vocabulary is familiar.
- Do **not** let dashboard titles stand in for grain, axes, units, privacy posture, exactness, or suppression state.
- Do **not** let partitions, sort orders, downsampled tiers, or array tiling leak into query meaning silently.
- Do **not** let a portable plan become an engine mandate.
- Do **not** confuse an Arrow-like export, a table snapshot, a ViewFS manifest, or a SlopOS handle set with the promoted answer's meaning.
- Do **not** store lineage in prose after the fact; attach a facet early enough that reruns and downgrades can see it.

## What Ward should probably steal next

- an **axis capsule** for any promoted answer whose cell identity, grain, measure, qualifiers, or absence posture may matter later;
- a **layout aperture** for any answer whose storage, partition, tier, export, or sparse/dense representation affects replay or comparison;
- a **lineage facet** for any answer that might later be rerun, compared, promoted, downgraded, or used as evidence by another cube;
- a standing **answer-shape-before-engine** rule so the SlopOS datacube can mature without premature substrate commitment.
