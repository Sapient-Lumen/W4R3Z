# Research synthesis — pass LXX

Pass LXIX made semantic drift visible: a polished SlopOS-facing cube answer must not let current labels, codes, tags, mappings, or hierarchy membership rewrite historical meaning. Pass LXX follows the next failure mode: once an answer looks credible, it can become an **alert**, a **recommendation**, an **ACP proposal**, a **workflow trigger**, a **feature flag input**, a **notification**, or an **operator instruction**. That handoff is dangerous because a cube answer can be true, scoped, fresh, comparable, semantically anchored, and still not be authorized to cause a consequence.

The restraint rule still holds. Ward should not choose an alerting product, workflow engine, policy engine, feature-flag provider, autoscaler, incident-management tool, notification stack, or SlopOS ACP extension as the datacube constitution. SlopOS is still in design phase, and its current action/notification/budget surfaces are intentionally bounded. The right move is to name answer-level residues that keep **observed answer**, **trigger condition**, **permission to act**, and **recorded consequence** separate.

## What the past says we must learn now

1. **Alert state is not just a boolean.** Prometheus alerting rules distinguish the expression, the optional `for` duration before firing, the pending/firing state behavior, `keep_firing_for`, labels, and annotations (`EXT-PROMETHEUS-ALERTING-RULES-2026`). Ward should steal the state-machine humility: a breached cube cell is weaker than a firing, persisted, routed, and annotated alert.

2. **Notification routing has its own noise-control semantics.** Alertmanager handles grouping, deduplication, routing, silencing, inhibition, high availability, and alert limits (`EXT-PROMETHEUS-ALERTMANAGER-2026`). Ward should not let one cube threshold directly page humans or agents without carrying grouping, inhibition, silence, and flood-limit posture.

3. **A good page is urgent, actionable, user-visible, and worth human intelligence.** The Google SRE monitoring chapter asks whether an alert detects an urgent/actionable/user-visible condition, whether it can be ignored, whether users are negatively affected, whether action is possible, and whether duplicate pages exist (`EXT-GOOGLE-SRE-MONITORING-2026`). Ward should make alert/consequence worthiness a warrant, not a side effect of chart polish.

4. **Control loops need dampening and rate limits.** Kubernetes HPA is an explicit control loop over observed metrics, with configurable scaling policies, stabilization windows, tolerance thresholds, and even direction-specific disabling (`EXT-K8S-HPA-BEHAVIOR-2026`). Ward should steal the idea that metric movement can feed action only through stated tolerances, hysteresis/stabilization, rate caps, and safe directionality.

5. **Event envelopes need identity and context.** CloudEvents standardizes event context such as source, type, id, subject, time, and extension attributes (`EXT-CLOUDEVENTS-SPEC-2026`). Ward should not turn a cube-triggered event into a naked payload; downstream consumers need identity, source/scope, subject, and extension material sufficient to rehydrate the answer boundary.

6. **Runtime flag decisions need reasons and error/stale posture.** OpenFeature providers are expected to return values and may populate variant, reason, metadata, and error fields; its reason examples include cached, disabled, stale, and error (`EXT-OPENFEATURE-PROVIDER-2026`). Ward should steal the reason-field habit for any cube-shaped feature gate, rollout input, or UI behavior switch.

7. **Policy decisions need audit logs and decision IDs.** OPA decision logs contain events describing policy queries, including queried policy, input, bundle metadata, result, and a decision ID (`EXT-OPA-DECISION-LOGS-2026`). Ward should steal the decision-log shape without importing OPA: if a cube answer supports a decision, that decision should have a receipt that points back to policy/input/result and the answer authority it consumed.

8. **SlopOS already warns against action laundering.** CH-ACPOUT in the included SlopOS snapshot is explicitly non-authoritative, redaction-safe, and bound to exact `action_digest`, `reqctx_digest`, outcome, optional effect, and receipt refs. ACP preconditions are veto-only exact witness gates; notification request state is not current presentation truth; D-BUDGET rejects ambient current payer. Ward should preserve those separations when cube answers feed proposed actions.

## Resulting Ward move

Do **not** decide yet:

- one alerting/incident-management system, workflow engine, policy engine, feature-flag provider, event bus, autoscaler, notification portal, or ACP action family;
- one trigger language, threshold DSL, anomaly detector, rule scheduler, routing tree, silence model, escalation ladder, or pager vocabulary;
- one event envelope, telemetry backend, dashboard-alert binding, notification format, or runbook schema;
- one rule that every threshold breach pages a human, every degradation opens a task, every stale answer triggers recompute, or every refused answer becomes an incident;
- one SlopOS-wide mechanism for turning datacube answers into CH-ACP, CH-NOTIF, CH-BUDGET, or policy-evaluation material;
- one durable decision registry or global action replay log for all cube-derived consequences.

Do add three small, reversible residues for datacube actuation hygiene:

- **threshold witness** — compact trigger-condition evidence for an answer-derived alert/recommendation/control-loop candidate. It names the answer capsule/cell, metric/grain/window, comparator, threshold or baseline, duration, tolerance, hysteresis/stabilization, no-data/error/refusal posture, suppression/noise/privacy interactions, evaluation cadence, pending/firing/resolved state, and anti-flap/anti-flood posture. It is smaller than an alerting engine and stronger than “value exceeded X.”
- **action warrant** — compact permission-to-use residue saying that a named cube answer may support a named consequence class: page, notify, open docket, recommend, propose ACP action, change flag, throttle, scale, quarantine, or refuse. It names the authorized actor/lane, scope lens, policy epoch, acceptance floor, required freshness/quality/comparability/semantic evidence, human-review lane, budget/payer posture, idempotency/conflict posture, rate caps, cooldowns, rollback/withdrawal posture, and action template/digest boundary. It is smaller than a policy engine and stronger than a dashboard link.
- **consequence receipt** — compact after-the-fact residue for what happened because the answer crossed an action warrant: proposal, alert, notification, page, flag decision, workflow run, ACP outcome, no-op, duplicate suppression, denial, rollback, or followthrough. It names answer capsule, threshold witness, action warrant, policy/decision/run identifiers, actor/reviewer, result/effect, egress/notification refs, downstream receipt refs, expiry/rehydration requirement, and repair/revocation followthrough. It is smaller than a workflow engine and stronger than a log line.

These residues sit beside earlier nouns. Threshold witnesses consume metric cards, window/frame anchors, quality witnesses, uncertainty envelopes, freshness envelopes, concept anchors, comparability passports, and refusal receipts. Action warrants consume scope lenses, state-cut witnesses, budget gates, projection curtains, privacy fences, and SlopOS authority surfaces. Consequence receipts feed interaction trails, egress receipts, correction horizons, revocation fences, recompute dockets, and future audit/explanation passes.

## Brilliant ideas to steal now

- **Trigger is weaker than warrant.** A breached threshold is a candidate, not permission to act.
- **Pending/firing/resolved posture.** Trigger state should preserve duration, `for`, keep-firing, no-data, and anti-flap behavior.
- **Noise-control as authority.** Grouping, inhibition, silencing, routing, dedupe, and flood limits are not presentation details when humans or agents act on alerts.
- **Actionability floor.** Before a page/recommendation/proposal can promote, it should say who can act, how urgently, and whether automation is safe.
- **Control-loop dampening.** Borrow tolerance, stabilization windows, rate caps, cooldowns, direction disable, and rollback posture before cube answers can control systems.
- **Reason field for decisions.** Cached/stale/error/default/disabled/split/target-match style reasons help keep feature flags and recommendations from looking magical.
- **Event envelope plus answer capsule.** A cube-triggered event should carry enough source/type/id/subject/time/context to rehydrate answer authority without embedding raw data.
- **Decision log not authorization.** Policy and ACP outcome logs are audit material; they do not become authority to rerun or widen the action.
- **No-op and duplicate-suppressed are healthy outcomes.** Repeated recommendations and retries should be visible without forcing duplicate effects.
- **Withdraw/fence stale consequences.** If answer authority is invalidated later, downstream pages, recommendations, flags, exported alerts, and ACP proposals need narrowing or rehydration posture.

## Candidate specimen pressure

Use a SlopOS reviewer question such as: “If the credential-provider risk family deterioration is persistent enough, notify the reviewer and propose a bounded ACP quarantine action for newly affected provider-family handles.” The source answer is scoped, fresh, comparable, semantically anchored, and privacy-reviewed. The specimen should still refuse automatic consequence until the threshold witness shows persistence/tolerance/no-data posture, the action warrant says this consequence class is authorized, and the consequence receipt records whether the notification/proposal was accepted, rejected, no-op, duplicate-suppressed, or withdrawn.

## Still-not-yet decisions

- Whether threshold witnesses live inside answer capsules, materialization metadata, dashboard alert configs, SlopOS notification requests, or separate Ward receipts.
- Whether action warrants are authored by policy, human review, runbooks, SlopOS ACP manifests, feature-flag configs, or a future control-plane surface.
- Whether consequence receipts should reference CH-ACPOUT, CH-NOTIF, CloudEvents, OpenTelemetry events, workflow runs, policy decisions, or local log entries directly or through digest sidecars.
- Whether every low-risk notification needs a full action warrant, or only consequential pages/actions/agent proposals/exported alerts do.
- Whether anomaly detection, forecasts, seasonality baselines, SLO burn rates, or business thresholds deserve later specialized residues.
- Whether a future Ward actionability rubric should become machine-checkable, or remain review checklist language until more specimens exist.

## Promotion probes

Before making the new residues stronger than candidate nouns, pressure-test:

1. one threshold breach that remains pending and must not page;
2. one firing alert inhibited by a broader outage or privacy/suppression state;
3. one no-data/error/stale answer that must refuse instead of firing;
4. one noisy/approximate degraded answer that can only create a review-only recommendation;
5. one feature-flag or rollout decision with `cached`, `stale`, or `default` reason posture;
6. one ACP proposal accepted but `no_op` or `duplicate_suppressed` under exact digest/idempotency rules; and
7. one old alert/export/agent summary withdrawn or fenced after answer invalidation.
