# Trajectory map

## Current thesis

Ward should begin as a **small, high-signal companion cube** whose main job is to metabolize a missing class of cross-pressure before it can leak confusion into the rest of the ecology.

## Non-negotiables
1. Ward owns a distinct pressure class and should not merely duplicate a sibling cube.
2. The cube may converse with sibling companions, but its public text stays clean of the sealed primary.
3. Early documents should freeze separations and non-decisions, not pretend a giant implementation stack already exists.
4. Outside examples are teachers, not templates.

## Immediate direction
- tighten the object model,
- keep the strongest distinctions visible,
- export compact artifacts that neighboring cubes could plausibly consume later,
- and grow only the subfamilies that survive repeated pressure.
- keep “current enough” explicit instead of ambient,
- preserve correction windows and explicit amendments before inventing one global finality story.
- keep browse-grade reads and spend-grade rechecks visibly different before inventing ambient current truth.
- keep pinned analytic basis explicit instead of regrowing ambient latest;
- keep temporal lookup lanes and join clocks explicit instead of hiding them inside “latest” joins;
- prefer contrast-first exploration over premature canonical dashboard dimensions;
- make freeze/rerun-diff review rails explicit before inventing silent liveness;
- let repeatedly useful derived views earn promotion with lineage and freshness only after a workload witness says the shape really pays rent.
- stage derivative changes behind an explicit publish rail instead of silently swapping the team-facing surface;
- require a typed change witness before calling one promoted derivative revision “safe enough” to publish.
- let repeated questions earn small published query contracts before inventing one giant semantic constitution;
- require explicit loss fences before any lossy derivative can pose as replayable source truth;
- let human-facing recurring measures travel with metric cards instead of vague dashboard names.

- make approximate truth visibly weaker than replayable exact truth;
- require estimator-family honesty before any sketch-backed acceleration can pose as a stable metric.

- require recurring metrics to declare aggregation law before promoted derivatives inherit dashboard authority;
- keep rollup passports visible when some regroupings are safe and others require replay or carry rules;
- preserve merge states when recomposition needs more than one rendered number.
- make measure-bearing base grain explicit before joins and dashboards can multiply rows;
- keep fanout fences visible when a convenience join is not duplication-safe;
- keep denominator/weight residue when a promoted rate or average might later be regrouped honestly.

- keep sparse observation visibly different from synthetic alignment buckets;
- make gap posture explicit before “no row” can become “zero” or “stale-held”;
- keep fill witnesses visible whenever carried-forward, interpolated, or zero-filled values matter.

- keep authorized view/scope binding explicit instead of pretending one query text names one universal population;
- separate fact drift from scope drift before promoted recurring questions become cross-team folklore.
- keep sampled previews visibly weaker than exact frozen results before inventing one ambient fast-answer authority;
- declare sampling family, selection stage, and rerun repeatability before two previews borrow each other's title.

- keep identity rules explicit instead of pretending row equality or storage coincidence settled semantics for free;
- keep dedupe quality visible before current-winner projections borrow the authority of raw append history;
- preserve correction lineage whenever deletes, replacements, or retries materially shaped the current answer.
- keep query resolution explicit instead of letting one recurring chart title float across fine-step and coarse-step answers;
- keep raw, retained-summary, and display-rollup tiers visibly distinct before browse-grade charts borrow replay-grade authority;
- mark any materialized-plus-raw stitch as a hybrid seam instead of pretending one homogeneous source.
- keep budgeted and degraded answers visibly weaker than requested exact answers before inventing one ambient approximate-query or cost-control plane;
- preserve requested-versus-served shape and uncertainty envelopes so agents cannot quietly promote fast previews into trust consequences.
- keep correction/backfill/fence posture visible so late repairs and withdrawn exports cannot silently rewrite old truth or remain current authority.
