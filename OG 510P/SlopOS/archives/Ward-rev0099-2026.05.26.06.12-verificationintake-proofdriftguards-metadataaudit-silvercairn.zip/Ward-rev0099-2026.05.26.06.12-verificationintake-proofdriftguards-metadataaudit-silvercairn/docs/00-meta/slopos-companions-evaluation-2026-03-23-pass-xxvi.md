# SlopOS / companions evaluation — pass XXVI

This pass keeps Ward embryonic while stealing one more useful habit from the neighbors: **make the interpretation frame explicit enough that later readers can tell which meaning pins produced a result.**

## What the current cubes still teach
- **SlopOS** already uses profile-claim and posture matrices to stop meaning drift. Ward should steal the lighter principle: when a result depends on a specific trust-root set, normalization rule, or appraisal recipe, keep that frame visible instead of leaving it in maintainer memory.
- **SlopOS** also treats compiled config generations as real artifacts rather than background vibes. Ward should learn the analogous move that a trust-result may need a visible `policy epoch` or recipe generation.
- **Foundry** keeps environment/config seams explicit and resists letting imported runtime facts masquerade as settled substrate truth. Ward should do the same when a verifier policy or trust root pack changes between one appraisal and the next.
- **Helm** keeps user-facing review smaller than the underlying state machinery. Ward should similarly keep `label scheme handle` and `replay delta` explanatory and inspectable without pretending they are the local consequence themselves.

## Current recommendation
Keep Ward open on whether recipe information lives inline, adjacent, or by reference.

The next wise move is one specimen plus one tiny hygiene upgrade:
1. **appraisal recipe** instead of invisible verifier folklore,
2. **policy epoch** instead of “current policy” as a handwave,
3. **replay delta** instead of rewriting history after re-evaluation,
4. **label scheme handle** instead of one summary tier pretending to say everything,
5. **current-focus drift check** instead of letting roadmap/context surfaces quietly disagree.

## Hygiene/process consequence
Because SlopOS is still in design phase too, Ward should still avoid heavyweight generation systems or locked external artifacts.
The smaller steal is enough for now:
- keep one explicit current-focus string in the roadmap,
- make the hygiene checker compare it against `SURFACE-STATUS.json` and `context-pack.json`,
- and fail the revision if those meta surfaces drift apart.

## Still-not-yet decisions
- Whether `appraisal recipe` deserves first-class Ward vocabulary or remains imported verifier config.
- Whether `label scheme handle` belongs in Ward proper or stays an explanatory sidecar on normalized results.
- Whether `policy epoch` should be durable Ward residue or simply a field carried by specific result families.
- Whether `replay delta` belongs in Ward or in an adjacent audit/history surface.
- Whether raw evidence retention for replay belongs in Ward or only in imported witness bundles.
