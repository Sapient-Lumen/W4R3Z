# Contributing

Keep additions small and typed.
Prefer strengthening one existing distinction over inventing a new umbrella abstraction.
New documents should usually justify themselves as a decision surface, a registry, a specimen proof cut, or a hygiene/process surface.
Before adding a new permanent noun, ask whether it can survive at least one specimen test without borrowing hidden truth from a sibling cube.
If an outside source becomes design-shaping enough to pressure a specimen noun or promotion gate, add it to the load-bearing source register in the same revision.
If a load-bearing source register row is added or changed, keep bibliography and research surfaces aligned in the same revision.
If a new specimen flow is added, update `docs/30-architecture/specimen-flow-index.md` in the same revision.
