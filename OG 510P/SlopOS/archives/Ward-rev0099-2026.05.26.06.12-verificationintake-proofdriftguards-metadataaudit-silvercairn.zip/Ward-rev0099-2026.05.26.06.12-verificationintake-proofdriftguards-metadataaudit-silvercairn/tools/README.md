# Tools

This embryo ships with deliberately small checkers. They are refusal harnesses, not authorization engines.

Run `make check` to execute repo hygiene, documentation audits, fixture/schema/runbook audits, and the registry-backed governance suite.

## Governance receipt validators

- `check_governance_handoff.py` validates governance handoff packets and refuses owner-label laundering, expired delegation, handoff non-acceptance, agent boundary collapse, and budget/semantic confusion.
- `check_governance_decision_events.py` validates derived governance decision events against packet digests, action parity, projection limits, expiry/debt, and consumer-profile closure.
- `check_governance_decision_consumers.py` validates downstream consumer receipts so decision events cannot be rendered, retained, rechecked, attached, or compacted into stronger hidden authority.
- `check_governance_batch_search_receipts.py` validates batch/search receipts so mixed member states, replay statuses, projection classes, downgrade reasons, and forbidden-effect fences cannot collapse into one green badge.
- `check_governance_search_continuity_receipts.py` validates search-continuity receipts so cursor continuation, sealed omissions, projection-policy drift, owner-map drift, and compaction changes cannot become hidden authority.
- `check_governance_evidence_release_receipts.py` validates evidence-release receipts so bundles, restricted packets, and held-recheck notices cannot leak sealed evidence, drop no-authority labels, or lose recipient/purpose binding.
- `check_governance_evidence_release_followups.py` validates release follow-up receipts so acknowledgments, revocations, corrections, stale-bundle quarantine, and reuse refusals cannot mutate releases or become authority.
- `check_governance_succession_transfers.py` validates succession/transfer receipts so successor labels, contact changes, projection-policy steward changes, and status-channel rotations cannot leave old channels active or become authority.
- `check_governance_chain_integrity.py` validates chain-integrity receipts so release/follow-up/transfer lineages cannot suffer member swaps, hidden forks, old-channel replay, public branch leakage, or canonical-head collapse.
- `check_governance_dispute_resolutions.py` validates dispute-resolution receipts so forked, pending, quarantined, or historical chains cannot be resolved by mutating history, hiding branches, or treating recovered heads as authority.
- `check_governance_recertifications.py` validates recertification receipts so cached dispute resolutions cannot ignore later signals, stale status channels, projection drift, cache-subject mismatch, or reuse requirements.
- `check_governance_signal_ingestions.py` validates signal-ingestion receipts so refresh/revocation/status signals cannot become authority, duplicates cannot become new changes, and conflicts cannot auto-pick winners.
- `check_governance_signal_notifications.py` validates signal-notification receipts, affected-consumer set digests, delivery/ack/retry/dead-letter states, stale-consumer quarantine, projection minimization, and no-authority fences.
- `check_governance_signal_notification_reconciliations.py` validates signal-notification reconciliation receipts so acknowledgments, partial fanout, duplicate notices, conflicts, and dead letters cannot become consumer refresh or authority.
- `check_governance_receiver_convergence.py` validates receiver-convergence receipts so clean, lagging, duplicate, divergent-cut, and forked receivers cannot collapse into receiver quorum or global authority.
- `check_governance_reuse_gates.py` validates reuse-gate receipts so receiver convergence cannot become reusable authority for export, repair, remedy, learning use, or action.
- `check_governance_use_executions.py` validates use-execution receipts so a reuse gate cannot be consumed as export, repair, remedy, action, status-pointer mutation, or hidden authority.
- `check_governance_outcome_observations.py` validates outcome-observation receipts so observed effects after a use-execution receipt cannot be laundered into authority, recertification, export, rollback, repair, remedy, or status-pointer mutation.
- `check_governance_rollback_remediations.py` validates rollback-remediation receipts so matched/no-op/unavailable/mismatched outcome observations cannot be laundered into rollback, remedy, repair, export, learning use, source mutation, status-pointer mutation, or authority.
- `check_governance_remediation_closures.py` validates remediation-closure receipts so review closure, handoff acknowledgment, no-remediation closure, or unavailable-observation escalation cannot become remedy, rollback, quarantine clearance, export, or authority.
- `check_governance_verification_intakes.py` validates verification-intake receipts so external proof can be verified, failed, absent, or conflicted without becoming remedy completion, quarantine clearance, export, repair, status-pointer mutation, or authority.

## Registry and audit/refactor tools

- `check_repo_hygiene.py` verifies required surfaces, archive index integrity, manifest drift, source register/queue references, latest-pass pointers, and revision identity.
- `check_doc_index_integrity.py` audits the human-facing docs map against the latest revision receipt and surface status.
- `check_fixture_catalog_integrity.py` audits every registry-backed fixture family for positive/negative layout, slugged filenames, schema parity, receipt ids, and authority-surface labels.
- `check_schema_catalog_integrity.py` audits all governance schema files against the checker registry.
- `check_tool_runbook_integrity.py` audits this tools runbook, the Makefile check target, and registry script coverage so new validators cannot be undocumented.
- `check_metadata_lineage_integrity.py` audits revision metadata, top-level ledgers, context pack, manifest, README, and latest-surface pointers against the current revision receipt.
- `check_governance_registry_integrity.py` audits the checker registry, registered governance checker scripts, schema ids/schema paths, and fixture-backed receipt families.
- `check_governance_suite.py` runs the governance receipt validators from `governance_checker_registry.json` in one Python process.
- `governance_common.py` contains shared digest, path, referenced-receipt, registry, and fixture-runner helpers.
- `governance_checker_registry.json` is the auditable inventory consumed by `check_governance_suite.py` and several catalog audits.

Keep automation tiny until the object model settles. A checker may reject known Ward failure modes without pretending to be a complete policy engine.
