#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

from governance_common import ROOT, load_checker, load_registry

def main() -> int:
    registry = load_registry()
    failures: list[str] = []
    entries = registry.get("entries") or []
    seen_ids: set[str] = set()
    seen_scripts: set[str] = set()
    for idx, entry in enumerate(entries):
        checker_id = entry.get("id")
        script = entry.get("script")
        fixture_dir = entry.get("fixture_dir")
        if not checker_id or checker_id in seen_ids:
            failures.append(f"registry entry {idx} has missing/duplicate id: {checker_id}")
            continue
        seen_ids.add(checker_id)
        if not script or script in seen_scripts:
            failures.append(f"registry entry {checker_id} has missing/duplicate script: {script}")
            continue
        seen_scripts.add(script)
        script_path = ROOT / "tools" / script
        if not script_path.exists():
            failures.append(f"registry entry {checker_id} script missing: {script}")
            continue
        if fixture_dir and not (ROOT / fixture_dir).exists():
            failures.append(f"registry entry {checker_id} fixture_dir missing: {fixture_dir}")
            continue
        module = load_checker(script_path, f"ward_suite_checker_{idx}_{script_path.stem}")
        rc = module.main()
        if rc != 0:
            failures.append(script)
    if failures:
        print("Governance suite failed:")
        for rel in failures:
            print(" -", rel)
        return 1
    print(f"Governance suite passed ({len(entries)} checkers from registry).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
