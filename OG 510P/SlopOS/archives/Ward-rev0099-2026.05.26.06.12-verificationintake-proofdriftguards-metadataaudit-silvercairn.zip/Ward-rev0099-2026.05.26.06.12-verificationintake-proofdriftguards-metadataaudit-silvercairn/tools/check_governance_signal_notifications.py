#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
NOTIFICATION_DIR = ROOT / "fixtures" / "governance-signal-notification"
SCHEMA = "ward.governance-signal-notification-receipt.v0"
RECEIPT_NAME = "ward.governance.signal-notification-receipt.v0"
AUTHORITY_SURFACE = "signal_notification_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}

VALID_STATES = {
    "all_consumers_notified_refresh_required",
    "partial_notification_quarantined",
    "duplicate_notification_suppressed",
    "dead_lettered_notification_quarantined",
    "conflict_notification_held",
    "invalid_notification_rejected",
}
VALID_DELIVERY_STATES = {
    "delivered_acknowledged",
    "pending_retry",
    "dead_lettered_quarantined",
    "duplicate_suppressed",
    "conflict_hold_notified",
    "not_required_noop",
    "rejected_invalid",
}
SAFE_EFFECTS = {
    "record_signal_notification_receipt",
    "record_consumer_set_digest",
    "record_delivery_attempt",
    "record_acknowledgment",
    "record_retry_state",
    "record_dead_letter_state",
    "publish_notification",
    "suppress_duplicate_notification",
    "quarantine_stale_consumers",
    "request_consumer_recertification",
    "hold_notification_conflict",
    "notify_review_lane",
    "mark_notification_noop",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "budget_spend",
    "delegate",
    "export_raw_evidence",
    "force_consumer_action",
    "grant_authority",
    "learning_use",
    "privacy_waiver",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "reuse_as_authority",
    "semantic_repair",
    "status_signal_as_action",
    "treat_ack_as_refresh",
    "update_current_head_without_replay",
}
REQUIRED_FORBIDDEN = {
    "acknowledgment_as_authority",
    "action_without_packet",
    "authority_reuse_without_packet",
    "budget_spend",
    "cache_as_authority",
    "cached_head_reuse_without_refresh",
    "conflicting_signal_auto_winner",
    "dead_letter_as_delivery",
    "delegate_without_warrant",
    "delivery_ack_as_consumer_refresh",
    "duplicate_delivery_as_new_change",
    "event_log_as_grant",
    "export_without_receipt",
    "future_action",
    "learning_use",
    "missing_consumer_hidden",
    "notification_as_recertification",
    "notification_scope_expansion",
    "poll_delivery_as_order_proof",
    "privacy_waiver_without_packet",
    "push_ack_as_consumer_refresh",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "resolution_as_authority",
    "reuse_without_refresh",
    "sealed_branch_disclosure",
    "signal_as_authority",
    "stale_consumer_reuse",
    "stale_signal_as_current",
    "status_channel_replay_as_authority",
    "status_pointer_as_grant",
    "status_signal_as_action",
    "unprojected_disclosure",
}


def load_checker(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load checker {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

signal_checker = load_checker(ROOT / "tools" / "check_governance_signal_ingestions.py", "ward_signal_checker_for_notification")


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stable_digest(obj: Any) -> str:
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def parse_time(value: str | None, field: str) -> datetime:
    if not value:
        raise ValueError(f"{field} missing")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} is not ISO-8601 parseable: {value}") from exc


def require(cond: bool, msg: str, errors: list[str]) -> None:
    if not cond:
        errors.append(msg)


def resolve_source_signal(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    if ref.get("receipt_sha256_checked") is not True:
        errors.append("source_signal_ingestion_ref.receipt_sha256_checked must be true")
    rel = ref.get("receipt_path")
    if not rel:
        errors.append("source_signal_ingestion_ref.receipt_path missing")
        return None
    path = (ROOT / rel).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append(f"source signal-ingestion path escapes repository root: {rel}")
        return None
    if not path.exists():
        errors.append(f"source signal-ingestion path missing on disk: {rel}")
        return None
    actual_sha = sha256(path)
    if ref.get("receipt_sha256") != actual_sha:
        errors.append("source_signal_ingestion_ref.receipt_sha256 mismatch")
    obj = load_json(path)
    if obj.get("schema") != "ward.governance-signal-ingestion-receipt.v0":
        errors.append("source_signal_ingestion_ref must point at a governance-signal-ingestion receipt")
    if ref.get("receipt_id") != obj.get("receipt_id"):
        errors.append("source_signal_ingestion_ref.receipt_id does not match referenced receipt")
    source_errors = signal_checker.validate_receipt(obj, path)
    if source_errors:
        errors.append("referenced source signal-ingestion receipt is invalid: " + "; ".join(source_errors))
    sref = obj.get("source_recertification_ref") or {}
    env = obj.get("signal_envelope") or {}
    cls = obj.get("signal_payload_classification") or {}
    follow = obj.get("followup_binding") or {}
    decision = obj.get("ingestion_decision") or {}
    mirrors = {
        "signal_ingestion_state": decision.get("state"),
        "source_recertification_id": sref.get("receipt_id"),
        "source_release_id": sref.get("source_release_id"),
        "recipient_class": sref.get("recipient_class"),
        "purpose": sref.get("purpose"),
        "source_item_digest": sref.get("source_item_digest"),
        "projection_policy_digest": sref.get("projection_policy_digest"),
        "cache_subject_digest": sref.get("cache_subject_digest"),
        "signal_event_key": env.get("canonical_event_key"),
        "signal_subject_digest": env.get("subject_digest"),
        "cache_action_requested": cls.get("cache_action_requested"),
        "target_recertification_kind": follow.get("target_recertification_kind"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_signal_ingestion_ref.{field} does not mirror source signal-ingestion receipt")
    return obj


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be signal_notification_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def scope_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    scope = receipt.get("notification_scope") or {}
    ref = receipt.get("source_signal_ingestion_ref") or {}
    for field in ["notification_plan_id", "notification_reason", "recipient_class", "purpose", "source_release_id", "source_signal_event_key", "source_signal_subject_digest", "cache_subject_digest"]:
        if not scope.get(field):
            errors.append(f"notification_scope.{field} missing")
    mirrors = {
        "recipient_class": ref.get("recipient_class"),
        "purpose": ref.get("purpose"),
        "source_release_id": ref.get("source_release_id"),
        "source_signal_event_key": ref.get("signal_event_key"),
        "source_signal_subject_digest": ref.get("signal_subject_digest"),
        "cache_subject_digest": ref.get("cache_subject_digest"),
    }
    for field, expected in mirrors.items():
        if scope.get(field) != expected:
            errors.append(f"notification_scope.{field} must mirror source_signal_ingestion_ref")
    consumers = scope.get("affected_consumers")
    if not isinstance(consumers, list):
        errors.append("notification_scope.affected_consumers must be a list")
        consumers = []
    if scope.get("affected_consumer_set_digest") != stable_digest(consumers):
        errors.append("notification_scope.affected_consumer_set_digest does not match affected_consumers")
    required = [c for c in consumers if c.get("required") is True]
    if scope.get("expected_consumer_count") != len(required):
        errors.append("notification_scope.expected_consumer_count must equal required affected consumers")
    seen = [c.get("consumer_id_hash") for c in consumers]
    if len(seen) != len(set(seen)):
        errors.append("notification_scope.affected_consumers contains duplicate consumer_id_hash values")
    for c in consumers:
        if not c.get("consumer_id_hash") or not c.get("consumer_class"):
            errors.append("each affected consumer needs consumer_id_hash and consumer_class")
        if c.get("projection_class") == "public_raw":
            errors.append("affected consumer projection_class must not be public_raw")


def delivery_plan_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    plan = receipt.get("delivery_plan") or {}
    ref = receipt.get("source_signal_ingestion_ref") or {}
    if plan.get("delivery_mode") not in {"push", "poll", "batch", "manual_review", "status_channel"}:
        errors.append("delivery_plan.delivery_mode invalid or missing")
    if not isinstance(plan.get("max_attempts"), int) or plan.get("max_attempts") < 0:
        errors.append("delivery_plan.max_attempts must be a non-negative integer")
    if not plan.get("retry_policy"):
        errors.append("delivery_plan.retry_policy missing")
    if plan.get("dead_letter_policy") not in {"quarantine", "manual_review", "not_applicable"}:
        errors.append("delivery_plan.dead_letter_policy invalid or missing")
    if plan.get("sealed_payload_inline") is not False:
        errors.append("delivery_plan.sealed_payload_inline must be false")
    if plan.get("no_authority_label_in_payload") is not True:
        errors.append("delivery_plan.no_authority_label_in_payload must be true")
    if plan.get("payload_subject_digest") != ref.get("signal_subject_digest"):
        errors.append("delivery_plan.payload_subject_digest must mirror source signal subject digest")
    payload = plan.get("notification_payload_without_digest")
    if not isinstance(payload, dict):
        errors.append("delivery_plan.notification_payload_without_digest missing or not object")
        payload = {}
    if plan.get("notification_payload_digest") != stable_digest(payload):
        errors.append("delivery_plan.notification_payload_digest does not match notification_payload_without_digest")
    if "not authority" not in str(plan.get("payload_label", "")).lower():
        errors.append("delivery_plan.payload_label must say not authority")


def observations_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    scope = receipt.get("notification_scope") or {}
    observations = receipt.get("consumer_observations")
    if not isinstance(observations, list):
        errors.append("consumer_observations must be a list")
        observations = []
    consumer_ids = {c.get("consumer_id_hash") for c in scope.get("affected_consumers") or []}
    observed_ids = [o.get("consumer_id_hash") for o in observations]
    if any(i not in consumer_ids for i in observed_ids):
        errors.append("consumer_observations contains consumer outside affected_consumer set")
    if len(observed_ids) != len(set(observed_ids)):
        errors.append("consumer_observations contains duplicate consumer_id_hash values")
    for obs in observations:
        state = obs.get("delivery_state")
        if state not in VALID_DELIVERY_STATES:
            errors.append("consumer_observations.delivery_state invalid or missing")
        if not obs.get("delivery_channel"):
            errors.append("consumer_observations.delivery_channel missing")
        if not isinstance(obs.get("attempt_count"), int) or obs.get("attempt_count") < 0:
            errors.append("consumer_observations.attempt_count must be a non-negative integer")
        if obs.get("ack_as_authority") is not False:
            errors.append("consumer_observations.ack_as_authority must be false")
        if obs.get("ack_as_refresh") is not False:
            errors.append("consumer_observations.ack_as_refresh must be false")
        if obs.get("delivery_ack_as_consumer_refresh") is not False:
            errors.append("consumer_observations.delivery_ack_as_consumer_refresh must be false")
        if state == "delivered_acknowledged":
            if not obs.get("ack_digest"):
                errors.append("delivered_acknowledged observation requires ack_digest")
            try:
                parse_time(obs.get("acknowledged_time"), "consumer_observations.acknowledged_time")
            except ValueError as exc:
                errors.append(str(exc))
        if state == "dead_lettered_quarantined" and not obs.get("dead_letter_pointer"):
            errors.append("dead_lettered_quarantined observation requires dead_letter_pointer")
        if state == "pending_retry" and not obs.get("next_retry_due"):
            errors.append("pending_retry observation requires next_retry_due")
        if state == "duplicate_suppressed" and obs.get("attempt_count") != 0:
            errors.append("duplicate_suppressed observation must have attempt_count 0")


def counts(receipt: dict[str, Any]) -> dict[str, int]:
    obs = receipt.get("consumer_observations") or []
    return {
        "ack": sum(1 for o in obs if o.get("delivery_state") == "delivered_acknowledged"),
        "pending": sum(1 for o in obs if o.get("delivery_state") == "pending_retry"),
        "dead": sum(1 for o in obs if o.get("delivery_state") == "dead_lettered_quarantined"),
        "dup": sum(1 for o in obs if o.get("delivery_state") == "duplicate_suppressed"),
        "conflict": sum(1 for o in obs if o.get("delivery_state") == "conflict_hold_notified"),
        "invalid": sum(1 for o in obs if o.get("delivery_state") == "rejected_invalid"),
        "noop": sum(1 for o in obs if o.get("delivery_state") == "not_required_noop"),
    }


def summary_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    summary = receipt.get("acknowledgment_summary") or {}
    scope = receipt.get("notification_scope") or {}
    state = (receipt.get("notification_decision") or {}).get("state")
    c = counts(receipt)
    expected = scope.get("expected_consumer_count")
    mirrors = {
        "expected_consumer_count": expected,
        "acknowledged_count": c["ack"],
        "pending_retry_count": c["pending"],
        "dead_lettered_count": c["dead"],
        "duplicate_suppressed_count": c["dup"],
    }
    for field, val in mirrors.items():
        if summary.get(field) != val:
            errors.append(f"acknowledgment_summary.{field} does not match observations/scope")
    stale = c["pending"] + c["dead"]
    if state in {"partial_notification_quarantined", "dead_lettered_notification_quarantined"}:
        if summary.get("stale_consumers_remaining") != stale or stale <= 0:
            errors.append(f"{state} requires positive stale_consumers_remaining matching pending/dead-letter counts")
    elif state == "all_consumers_notified_refresh_required":
        if summary.get("stale_consumers_remaining") != 0:
            errors.append("all_consumers_notified_refresh_required requires no stale consumers remaining")
    if summary.get("ack_as_authority") is not False:
        errors.append("acknowledgment_summary.ack_as_authority must be false")
    if summary.get("ack_as_refresh") is not False:
        errors.append("acknowledgment_summary.ack_as_refresh must be false")
    if summary.get("delivery_ack_as_consumer_refresh") is not False:
        errors.append("acknowledgment_summary.delivery_ack_as_consumer_refresh must be false")
    if summary.get("dead_letter_is_delivery") is not False:
        errors.append("acknowledgment_summary.dead_letter_is_delivery must be false")
    if summary.get("exact_counts_public") is not False:
        errors.append("acknowledgment_summary.exact_counts_public must be false")
    if summary.get("counts_bucketed_or_internal") is not True:
        errors.append("acknowledgment_summary.counts_bucketed_or_internal must be true")


def closure_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    closure = receipt.get("stale_consumer_closure") or {}
    ref = receipt.get("source_signal_ingestion_ref") or {}
    state = (receipt.get("notification_decision") or {}).get("state")
    c = counts(receipt)
    if closure.get("blocked_cache_subject_digest") != ref.get("cache_subject_digest"):
        errors.append("stale_consumer_closure.blocked_cache_subject_digest must mirror source cache subject")
    if closure.get("source_signal_mutated") is not False:
        errors.append("stale_consumer_closure.source_signal_mutated must be false")
    if closure.get("status_pointer_update_allowed") is not False:
        errors.append("stale_consumer_closure.status_pointer_update_allowed must be false")
    if closure.get("notification_can_grant_authority") is not False:
        errors.append("stale_consumer_closure.notification_can_grant_authority must be false")
    if state in {"all_consumers_notified_refresh_required", "partial_notification_quarantined", "dead_lettered_notification_quarantined", "conflict_notification_held"}:
        if closure.get("no_reuse_until_recertified") is not True:
            errors.append(f"{state} requires no_reuse_until_recertified")
        if closure.get("requires_consumer_recertification") is not True:
            errors.append(f"{state} requires consumer recertification")
    if state == "partial_notification_quarantined":
        if closure.get("missing_consumer_quarantine") is not True:
            errors.append("partial_notification_quarantined requires missing_consumer_quarantine")
    if state == "dead_lettered_notification_quarantined":
        if c["dead"] <= 0:
            errors.append("dead_lettered_notification_quarantined requires a dead-lettered consumer")
        if closure.get("dead_letter_requires_manual_review") is not True:
            errors.append("dead_lettered_notification_quarantined requires manual review")
        if closure.get("missing_consumer_quarantine") is not True:
            errors.append("dead_lettered_notification_quarantined requires missing_consumer_quarantine")
    if state == "duplicate_notification_suppressed":
        if closure.get("no_reuse_until_recertified") is not False:
            errors.append("duplicate_notification_suppressed should not create a new reuse hold")
        if closure.get("requires_consumer_recertification") is not False:
            errors.append("duplicate_notification_suppressed should not require consumer recertification")


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_signal_ingestion_ref") or {}
    p = receipt.get("projection_safety") or {}
    public = ref.get("recipient_class") in PUBLIC_RECIPIENTS or p.get("projection_class") == "public_minimized"
    if p.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(p.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    for field in [
        "sealed_signal_payload_inline",
        "sealed_notification_payload_inline",
        "reveals_private_org_map",
        "reveals_raw_partner_fragments",
        "reveals_reviewer_identities",
        "reveals_named_private_stewards",
        "reveals_recipient_private_contact",
        "reveals_consumer_identity_public",
    ]:
        if p.get(field) is not False:
            errors.append(f"projection_safety.{field} must be false")
    if public:
        if p.get("no_exact_hidden_counts_public") is not True:
            errors.append("public signal-notification receipt must not reveal exact hidden counts")
        if p.get("bucketed_or_presence_only_disclosure") is not True:
            errors.append("public signal-notification receipt requires bucketed or presence-only disclosure")
        if p.get("hashed_or_class_only_consumers") is not True:
            errors.append("public signal-notification receipt requires hashed-or-class-only consumers")


def effects_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    effects = receipt.get("effect_closure") or {}
    performed = set(effects.get("effects_performed") or [])
    preserved = set(effects.get("forbidden_effects_preserved") or [])
    if effects.get("safe_signal_notification_effects_only") is not True:
        errors.append("effect_closure.safe_signal_notification_effects_only must be true")
    if effects.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if effects.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")
    extra = performed - SAFE_EFFECTS
    if extra:
        errors.append("effect_closure has non-signal-notification effects: " + ", ".join(sorted(extra)))
    high = performed & HIGH_CONSEQUENCE_EFFECTS
    if high:
        errors.append("effect_closure performs high consequence effects: " + ", ".join(sorted(high)))
    missing = REQUIRED_FORBIDDEN - preserved
    if missing:
        errors.append("effect_closure missing required forbidden effects: " + ", ".join(sorted(missing)))


def decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    d = receipt.get("notification_decision") or {}
    state = d.get("state")
    source_state = (receipt.get("source_signal_ingestion_ref") or {}).get("signal_ingestion_state")
    summary = receipt.get("acknowledgment_summary") or {}
    c = counts(receipt)
    if state not in VALID_STATES:
        errors.append("notification_decision.state invalid or missing")
    if not d.get("reason_codes"):
        errors.append("notification_decision.reason_codes missing")
    if d.get("no_authority_granted") is not True:
        errors.append("notification_decision.no_authority_granted must be true")
    if d.get("source_signal_mutated") is not False:
        errors.append("notification_decision.source_signal_mutated must be false")
    if d.get("notification_as_recertification") is not False:
        errors.append("notification_decision.notification_as_recertification must be false")
    expected_cache = {
        "all_consumers_notified_refresh_required": "recheck_required",
        "partial_notification_quarantined": "quarantine_required",
        "duplicate_notification_suppressed": "unchanged_duplicate",
        "dead_lettered_notification_quarantined": "quarantine_required",
        "conflict_notification_held": "held_due_to_conflict",
        "invalid_notification_rejected": "rejected",
    }
    if state in expected_cache and d.get("cache_reuse_state") != expected_cache[state]:
        errors.append(f"{state} requires cache_reuse_state {expected_cache[state]}")
    if state == "all_consumers_notified_refresh_required":
        if source_state != "signal_accepted_for_recertification":
            errors.append("all_consumers_notified_refresh_required requires accepted source signal")
        if summary.get("all_required_consumers_acknowledged") is not True:
            errors.append("all_consumers_notified_refresh_required requires all_required_consumers_acknowledged")
        if c["pending"] or c["dead"]:
            errors.append("all_consumers_notified_refresh_required cannot have pending/dead-letter consumers")
    if state == "partial_notification_quarantined":
        if source_state != "signal_accepted_for_recertification":
            errors.append("partial_notification_quarantined requires accepted source signal")
        if c["pending"] <= 0:
            errors.append("partial_notification_quarantined requires pending_retry consumer")
        if summary.get("all_required_consumers_acknowledged") is not False:
            errors.append("partial_notification_quarantined must not claim all acknowledged")
    if state == "dead_lettered_notification_quarantined":
        if source_state != "signal_accepted_for_recertification":
            errors.append("dead_lettered_notification_quarantined requires accepted source signal")
        if c["dead"] <= 0:
            errors.append("dead_lettered_notification_quarantined requires dead_lettered consumer")
    if state == "duplicate_notification_suppressed":
        if source_state != "duplicate_signal_ignored":
            errors.append("duplicate_notification_suppressed requires duplicate source signal")
        if c["dup"] <= 0:
            errors.append("duplicate_notification_suppressed requires duplicate_suppressed observation")
    if state == "conflict_notification_held":
        if source_state != "conflicting_signals_held":
            errors.append("conflict_notification_held requires conflicting source signal")
        if c["conflict"] <= 0:
            errors.append("conflict_notification_held requires conflict_hold_notified observation")
        if d.get("winner_selected") is not False:
            errors.append("conflict_notification_held must not select a winner")
    if state == "invalid_notification_rejected":
        if c["invalid"] <= 0:
            errors.append("invalid_notification_rejected requires rejected_invalid observation")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    source = resolve_source_signal(receipt.get("source_signal_ingestion_ref") or {}, errors)
    scope_ok(receipt, source, errors)
    delivery_plan_ok(receipt, errors)
    observations_ok(receipt, errors)
    summary_ok(receipt, errors)
    closure_ok(receipt, errors)
    projection_ok(receipt, errors)
    effects_ok(receipt, errors)
    decision_ok(receipt, errors)
    return errors


def main() -> int:
    valid_paths = sorted(NOTIFICATION_DIR.glob("*.valid.json"))
    invalid_paths = sorted((NOTIFICATION_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance signal-notification fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance signal-notification fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance signal-notification check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance signal-notification check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
