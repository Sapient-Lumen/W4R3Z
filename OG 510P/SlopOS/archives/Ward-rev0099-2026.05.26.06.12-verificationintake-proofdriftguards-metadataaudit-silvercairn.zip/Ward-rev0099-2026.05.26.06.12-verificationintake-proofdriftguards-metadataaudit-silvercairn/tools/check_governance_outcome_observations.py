#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Any
import sys

from governance_common import (
    ROOT,
    parse_time,
    require,
    run_fixture_checker,
    stable_digest,
    validate_ref,
)

OUTCOME_DIR = ROOT / "fixtures" / "governance-outcome-observation"
SCHEMA = "ward.governance-outcome-observation-receipt.v0"
RECEIPT_NAME = "ward.governance.outcome-observation-receipt.v0"
AUTHORITY_SURFACE = "outcome_observation_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}

VALID_STATES = {
    "observed_public_display_matched_refresh_required",
    "observed_internal_review_matched_refresh_required",
    "observed_noop_hold_confirmed",
    "observed_mismatch_quarantined_rollback_required",
    "observation_unavailable_held_no_claim",
    "invalid_outcome_observation_rejected",
}
SAFE_OBSERVATION_EFFECTS = {
    "record_outcome_observation_receipt",
    "record_source_use_execution_ref",
    "record_observed_outcome_digest",
    "publish_no_authority_outcome_status",
    "confirm_public_display_observed",
    "confirm_internal_review_observed",
    "confirm_noop_hold_observed",
    "hold_without_observation_claim",
    "quarantine_observed_mismatch",
    "request_rollback_review",
    "request_remedy_handoff_packet",
    "request_reuse_gate_replay",
    "request_recertification_refresh",
    "notify_mismatch_followup_required",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "approve_export",
    "budget_spend",
    "delegate",
    "evidence_bundle_release",
    "export_raw_evidence",
    "force_consumer_action",
    "grant_authority",
    "learning_use",
    "merge_divergent_status_channels",
    "privacy_waiver",
    "promote_global_current_head",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "rollback_without_review",
    "semantic_repair",
    "status_pointer_update",
    "update_current_head",
    "update_status_pointer",
}
REQUIRED_FORBIDDEN = {
    "action_without_packet",
    "actual_effect_drift",
    "authority_from_observation",
    "budget_spend",
    "display_reuse_as_export_authority",
    "evidence_release_without_release_receipt",
    "execution_outcome_as_authority",
    "export_without_receipt",
    "future_action",
    "global_status_pointer_update",
    "high_consequence_without_handoff_packet",
    "learning_use",
    "mismatch_without_quarantine",
    "no_observation_claimed_current",
    "observation_as_approval",
    "observation_as_recertification",
    "observation_window_bypass",
    "privacy_waiver_without_packet",
    "recipient_projection_drift",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "rollback_without_review",
    "sealed_branch_disclosure",
    "semantic_repair_without_warrant",
    "source_use_execution_mutation",
    "status_pointer_as_grant",
    "unprojected_disclosure",
    "use_execution_as_authority",
}


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be outcome_observation_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def resolve_source_use_execution(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    source = validate_ref(
        ref,
        label="source_use_execution_ref",
        expected_schema="ward.governance-use-execution-receipt.v0",
        checker_script="check_governance_use_executions.py",
        checker_module_name="ward_use_execution_checker_for_outcome_observation",
        errors=errors,
    )
    if not source:
        return None
    req = source.get("execution_request") or {}
    decision = source.get("execution_decision") or {}
    binding = source.get("execution_binding") or {}
    projection = source.get("projection_safety") or {}
    mirrors = {
        "execution_state": decision.get("state"),
        "execution_performed": decision.get("execution_performed"),
        "execution_held": decision.get("execution_held"),
        "execution_refused": decision.get("execution_refused"),
        "execution_quarantined": decision.get("execution_quarantined"),
        "execution_id": req.get("execution_id"),
        "actual_effect": req.get("actual_effect"),
        "actual_purpose": req.get("actual_purpose"),
        "actual_consequence_class": req.get("actual_consequence_class"),
        "recipient_class": req.get("recipient_class"),
        "projection_policy_id": req.get("projection_policy_id"),
        "execution_target": req.get("execution_target"),
        "executed_at": req.get("executed_at"),
        "execution_window_end": req.get("execution_window_end"),
        "actual_effect_digest": binding.get("actual_effect_digest"),
        "no_authority_label_present": projection.get("no_authority_label_present"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_use_execution_ref.{field} does not mirror referenced use-execution receipt")
    if decision.get("no_authority_granted") is not True:
        errors.append("referenced use-execution receipt must grant no authority")
    if decision.get("status_pointer_update_allowed") is not False:
        errors.append("referenced use-execution receipt must not allow status-pointer update")
    return source


def observation_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    ref = receipt.get("source_use_execution_ref") or {}
    obs = receipt.get("outcome_observation") or {}
    comp = receipt.get("outcome_comparison") or {}
    decision = receipt.get("outcome_decision") or {}
    for field in [
        "observation_id", "expected_execution_id", "observer_class", "observed_at",
        "observation_window_end", "observed_target", "observed_effect", "observed_recipient_class",
        "observed_projection_policy_id", "observed_outcome_state", "observation_available",
        "observed_outcome_digest",
    ]:
        if obs.get(field) in (None, ""):
            errors.append(f"outcome_observation.{field} missing")
    try:
        observed_at = parse_time(obs.get("observed_at"), "outcome_observation.observed_at")
        window_end = parse_time(obs.get("observation_window_end"), "outcome_observation.observation_window_end")
        source_window_end = parse_time(ref.get("execution_window_end"), "source_use_execution_ref.execution_window_end")
        if window_end < observed_at:
            errors.append("outcome_observation.observation_window_end must not precede observed_at")
        if observed_at > window_end:
            errors.append("outcome_observation.observed_at must be within observation window")
        if observed_at < parse_time(ref.get("executed_at"), "source_use_execution_ref.executed_at"):
            errors.append("outcome_observation.observed_at must not precede source execution time")
        # Observation can happen after execution_window_end, but the receipt must keep it as observation only.
        if source_window_end and not comp.get("post_execution_observation_only"):
            errors.append("outcome_comparison.post_execution_observation_only must be true")
    except ValueError as exc:
        errors.append(str(exc))
    if obs.get("expected_execution_id") != ref.get("execution_id"):
        errors.append("outcome_observation.expected_execution_id must mirror source execution id")
    if obs.get("observation_available") is True and obs.get("observed_execution_id") != ref.get("execution_id"):
        errors.append("outcome_observation.observed_execution_id must mirror source execution id when observation is available")
    if obs.get("observation_available") is False and obs.get("observed_execution_id") not in (None, ""):
        errors.append("unavailable observations must not claim an observed execution id")
    for field in [
        "source_use_execution_digest_checked", "execution_id_matches_source", "outcome_within_observation_window",
        "post_execution_observation_only", "no_authority_label_required", "public_projection_checked",
    ]:
        if comp.get(field) is not True:
            errors.append(f"outcome_comparison.{field} must be true")
    if comp.get("source_use_execution_digest_checked") is not True:
        errors.append("outcome_comparison.source_use_execution_digest_checked must be true")
    if obs.get("observation_available") is True:
        expected_digest = stable_digest({
            "observation_id": obs.get("observation_id"),
            "execution_id": obs.get("observed_execution_id"),
            "observer_class": obs.get("observer_class"),
            "observed_effect": obs.get("observed_effect"),
            "observed_target": obs.get("observed_target"),
            "observed_recipient_class": obs.get("observed_recipient_class"),
            "observed_projection_policy_id": obs.get("observed_projection_policy_id"),
            "observed_outcome_state": obs.get("observed_outcome_state"),
            "observation_available": True,
        })
    else:
        expected_digest = stable_digest({
            "observation_id": obs.get("observation_id"),
            "expected_execution_id": obs.get("expected_execution_id"),
            "observer_class": obs.get("observer_class"),
            "observed_outcome_state": obs.get("observed_outcome_state"),
            "observation_available": False,
        })
    if obs.get("observed_outcome_digest") != expected_digest:
        errors.append("outcome_observation.observed_outcome_digest does not match observed outcome")


def projection_and_closure_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    obs = receipt.get("outcome_observation") or {}
    projection = receipt.get("projection_safety") or {}
    closure = receipt.get("outcome_closure") or {}
    if projection.get("projection_policy_id") != obs.get("observed_projection_policy_id"):
        errors.append("projection_safety.projection_policy_id must mirror outcome_observation")
    if projection.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(projection.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    if obs.get("observed_recipient_class") in PUBLIC_RECIPIENTS:
        for field in [
            "reveals_receiver_identity_public", "reveals_status_channel_private",
            "reveals_named_private_stewards", "reveals_private_org_map",
            "reveals_raw_partner_fragments", "reveals_recipient_private_contact",
            "sealed_execution_payload_inline", "sealed_source_payload_inline", "observed_private_payload_inline",
        ]:
            if projection.get(field) is not False:
                errors.append(f"projection_safety.{field} must be false for public recipients")
        if projection.get("hashed_or_class_only_subjects") is not True:
            errors.append("projection_safety.hashed_or_class_only_subjects must be true for public recipients")
    expected_bool = {
        "source_use_execution_mutated": False,
        "source_reuse_gate_mutated": False,
        "source_status_pointer_mutated": False,
        "outcome_observation_can_grant_authority": False,
        "use_execution_can_grant_authority": False,
        "rollback_can_grant_authority": False,
        "status_pointer_update_allowed": False,
        "scope_expansion_allowed": False,
        "requires_no_authority_label": True,
        "requires_source_use_execution_ref": True,
        "requires_observed_outcome_digest": True,
        "source_packet_replay_still_required": True,
        "safe_observation_effects_only": True,
        "no_authority_upgrade": True,
        "no_high_consequence_outcome_effects": True,
    }
    for field, expected in expected_bool.items():
        if closure.get(field) is not expected:
            errors.append(f"outcome_closure.{field} must be {expected}")
    actual = set(closure.get("observed_effects") or [])
    forbidden = set(closure.get("forbidden_effects") or [])
    if not actual:
        errors.append("outcome_closure.observed_effects missing")
    unsupported = sorted(actual - SAFE_OBSERVATION_EFFECTS)
    if unsupported:
        errors.append("outcome_closure.observed_effects contains unsupported effects: " + ", ".join(unsupported))
    high = sorted(actual & HIGH_CONSEQUENCE_EFFECTS)
    if high:
        errors.append("outcome_closure.observed_effects contains high-consequence effects: " + ", ".join(high))
    missing = sorted(REQUIRED_FORBIDDEN - forbidden)
    if missing:
        errors.append("outcome_closure.forbidden_effects missing required fences: " + ", ".join(missing[:8]))


def decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_use_execution_ref") or {}
    obs = receipt.get("outcome_observation") or {}
    comp = receipt.get("outcome_comparison") or {}
    closure = receipt.get("outcome_closure") or {}
    decision = receipt.get("outcome_decision") or {}
    state = decision.get("state")
    observed_effects = set(closure.get("observed_effects") or [])
    if state not in VALID_STATES:
        errors.append("outcome_decision.state invalid")
    for field, expected in {
        "no_authority_granted": True,
        "refresh_still_required": True,
        "status_pointer_update_allowed": False,
        "scope_expansion_allowed": False,
    }.items():
        if decision.get(field) is not expected:
            errors.append(f"outcome_decision.{field} must be {expected}")
    if "not_authority" not in (decision.get("reason_codes") or []):
        errors.append("outcome_decision.reason_codes must include not_authority")
    discrepancy = comp.get("discrepancy_detected") is True
    if state == "observed_public_display_matched_refresh_required":
        if ref.get("execution_state") != "executed_public_display_refresh_required":
            errors.append("public display outcome requires public display use-execution source")
        if obs.get("observed_effect") != ref.get("actual_effect") or obs.get("observed_effect") != "public_minimized_display":
            errors.append("public display outcome must observe public_minimized_display")
        if obs.get("observed_target") != ref.get("execution_target"):
            errors.append("public display outcome target must match source execution target")
        if obs.get("observed_recipient_class") != ref.get("recipient_class"):
            errors.append("public display outcome recipient must match source")
        if obs.get("observed_projection_policy_id") != ref.get("projection_policy_id"):
            errors.append("public display outcome projection policy must match source")
        if discrepancy or decision.get("observation_matched") is not True or decision.get("observation_quarantined") is not False or decision.get("rollback_required") is not False:
            errors.append("public display matched outcome must not carry discrepancy/quarantine/rollback")
        if "confirm_public_display_observed" not in observed_effects:
            errors.append("public display outcome must confirm observed public display")
    if state == "observed_internal_review_matched_refresh_required":
        if ref.get("execution_state") != "executed_internal_review_refresh_required":
            errors.append("internal review outcome requires internal review use-execution source")
        if obs.get("observed_effect") != ref.get("actual_effect") or obs.get("observed_effect") != "internal_review_replay":
            errors.append("internal review outcome must observe internal_review_replay")
        if obs.get("observed_target") != ref.get("execution_target"):
            errors.append("internal review outcome target must match source execution target")
        if discrepancy or decision.get("observation_matched") is not True or decision.get("rollback_required") is not False:
            errors.append("internal review matched outcome must not carry discrepancy/rollback")
        if "confirm_internal_review_observed" not in observed_effects:
            errors.append("internal review outcome must confirm internal review observation")
    if state == "observed_noop_hold_confirmed":
        if ref.get("execution_performed") is not False:
            errors.append("noop hold confirmation requires a no-execution source use-execution receipt")
        if obs.get("observed_effect") != "no_execution_observed":
            errors.append("noop hold confirmation must observe no_execution_observed")
        if comp.get("observed_noop_matches_source_no_execution") is not True:
            errors.append("noop hold confirmation must set observed_noop_matches_source_no_execution")
        if discrepancy or decision.get("observation_matched") is not True or decision.get("rollback_required") is not False:
            errors.append("noop hold confirmation must match without rollback")
        if "confirm_noop_hold_observed" not in observed_effects:
            errors.append("noop hold confirmation must record confirm_noop_hold_observed")
    if state == "observed_mismatch_quarantined_rollback_required":
        if obs.get("observation_available") is not True:
            errors.append("mismatch quarantine requires an available observation")
        if not discrepancy:
            errors.append("mismatch quarantine requires discrepancy_detected true")
        for field in ["unsafe_discrepancy_quarantined", "rollback_required_for_discrepancy"]:
            if comp.get(field) is not True:
                errors.append(f"outcome_comparison.{field} must be true for mismatch quarantine")
        if decision.get("observation_quarantined") is not True or decision.get("rollback_required") is not True:
            errors.append("mismatch quarantine decision must quarantine and require rollback review")
        if decision.get("observation_matched") is not False:
            errors.append("mismatch quarantine cannot claim observation matched")
        if "quarantine_observed_mismatch" not in observed_effects or "request_rollback_review" not in observed_effects:
            errors.append("mismatch quarantine must record quarantine and rollback-review effects")
    if state == "observation_unavailable_held_no_claim":
        if obs.get("observation_available") is not False:
            errors.append("unavailable observation state requires observation_available false")
        if comp.get("no_observation_claimed_as_match") is not True:
            errors.append("unavailable observation must explicitly avoid match claim")
        if decision.get("observation_held") is not True or decision.get("observation_matched") is not False or decision.get("rollback_required") is not False:
            errors.append("unavailable observation must hold without match or rollback claim")
        if "hold_without_observation_claim" not in observed_effects:
            errors.append("unavailable observation must record hold_without_observation_claim")
    # Cross-state consistency.
    if decision.get("observation_matched") is True and not discrepancy and state in {"observed_public_display_matched_refresh_required", "observed_internal_review_matched_refresh_required"}:
        for obs_field, ref_field in [
            ("observed_effect", "actual_effect"),
            ("observed_target", "execution_target"),
            ("observed_recipient_class", "recipient_class"),
            ("observed_projection_policy_id", "projection_policy_id"),
        ]:
            if obs.get(obs_field) != ref.get(ref_field):
                errors.append(f"matched observation {obs_field} must mirror source {ref_field}")
    if decision.get("observation_matched") is True and discrepancy:
        errors.append("observation cannot be matched when discrepancy_detected is true")
    if discrepancy and decision.get("observation_quarantined") is not True:
        errors.append("detected discrepancies must quarantine")
    if discrepancy and decision.get("rollback_required") is not True:
        errors.append("detected discrepancies must require rollback review")
    if obs.get("observation_available") is False and decision.get("observation_matched") is True:
        errors.append("unavailable observations cannot be matched")
    if decision.get("remedy_required") is True and decision.get("rollback_required") is not True:
        errors.append("remedy_required requires rollback_required in v0")
    if ref.get("execution_performed") is False and obs.get("observed_effect") not in {"no_execution_observed", "observation_unavailable"} and not discrepancy:
        errors.append("no-execution sources require noop/unavailable observation unless discrepancy is quarantined")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    ref = receipt.get("source_use_execution_ref")
    source = None
    if not isinstance(ref, dict):
        errors.append("source_use_execution_ref must be an object")
    else:
        source = resolve_source_use_execution(ref, errors)
    observation_ok(receipt, source, errors)
    projection_and_closure_ok(receipt, errors)
    decision_ok(receipt, errors)
    return errors


def main() -> int:
    return run_fixture_checker(
        fixture_dir=OUTCOME_DIR,
        valid_glob="*.valid.json",
        invalid_glob="*.invalid.json",
        validate_receipt=validate_receipt,
        label="Governance outcome-observation receipt",
    )


if __name__ == "__main__":
    sys.exit(main())
