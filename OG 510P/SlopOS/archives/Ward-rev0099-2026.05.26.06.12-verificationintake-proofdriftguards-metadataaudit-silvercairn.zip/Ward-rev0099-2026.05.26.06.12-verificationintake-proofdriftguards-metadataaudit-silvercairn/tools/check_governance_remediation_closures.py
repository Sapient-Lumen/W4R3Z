#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Any
import sys

from governance_common import (
    ROOT,
    parse_time,
    require,
    run_fixture_checker,
    stable_digest,
    validate_ref,
)

CLOSURE_DIR = ROOT / "fixtures" / "governance-remediation-closure"
SCHEMA = "ward.governance-remediation-closure-receipt.v0"
RECEIPT_NAME = "ward.governance.remediation-closure-receipt.v0"
AUTHORITY_SURFACE = "remediation_closure_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}

VALID_STATES = {
    "no_remediation_closure_confirmed_refresh_required",
    "noop_closure_confirmed_refresh_required",
    "rollback_review_closed_quarantine_sustained",
    "remediation_handoff_acknowledged_external_proof_required",
    "unavailable_observation_escalated_still_held",
    "invalid_remediation_closure_rejected",
}

SAFE_CLOSURE_EFFECTS = {
    "record_remediation_closure_receipt",
    "record_source_rollback_remediation_ref",
    "record_closure_scope_digest",
    "publish_no_authority_closure_status",
    "close_no_remediation_needed",
    "close_noop_no_remediation_needed",
    "maintain_remediation_quarantine",
    "record_review_closed_no_action",
    "record_handoff_acknowledgment",
    "request_external_remedy_proof",
    "escalate_observation_unavailable",
    "hold_pending_observation",
    "notify_affected_consumer_followup",
    "request_source_packet_replay",
    "request_use_execution_replay",
    "request_harbor_recheck",
    "record_verification_debt",
}

HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "approve_export",
    "budget_spend",
    "clear_quarantine",
    "close_quarantine_without_proof",
    "delegate",
    "evidence_bundle_release",
    "execute_remediation",
    "execute_rollback",
    "export_raw_evidence",
    "force_consumer_action",
    "grant_authority",
    "learning_use",
    "mark_remedy_complete",
    "merge_divergent_status_channels",
    "mutate_source_outcome_observation",
    "mutate_source_remediation",
    "mutate_source_use_execution",
    "privacy_waiver",
    "promote_global_current_head",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "rollback_without_review",
    "semantic_repair",
    "status_pointer_update",
    "unseal_private_evidence",
    "update_current_head",
    "update_status_pointer",
}

REQUIRED_FORBIDDEN = {
    "authority_from_closure",
    "budget_spend",
    "closure_as_authority",
    "closure_as_remedy",
    "evidence_release_without_release_receipt",
    "export_without_receipt",
    "external_proof_as_authority",
    "grant_authority",
    "handoff_ack_as_remedy",
    "high_consequence_without_handoff_packet",
    "learning_use",
    "no_remediation_as_reuse_authority",
    "observation_unavailable_as_closed",
    "privacy_waiver_without_packet",
    "public_private_identity_leak",
    "quarantine_cleared_without_proof",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remediation_closure_as_authority",
    "remedy_without_handoff_packet",
    "repair",
    "review_closed_as_rollback",
    "rollback_without_separate_authority",
    "scope_expansion",
    "sealed_payload_disclosure",
    "semantic_repair_without_warrant",
    "source_outcome_mutation",
    "source_remediation_mutation",
    "source_use_execution_mutation",
    "status_pointer_update",
    "unprojected_disclosure",
}

SOURCE_STATE_TO_DECISION = {
    "no_remediation_needed_match_refresh_required": "no_remediation_closure_confirmed_refresh_required",
    "noop_hold_no_remediation_needed": "noop_closure_confirmed_refresh_required",
    "rollback_review_opened_quarantine_maintained": "rollback_review_closed_quarantine_sustained",
    "remediation_handoff_requested_no_action": "remediation_handoff_acknowledged_external_proof_required",
    "observation_unavailable_hold_no_remediation": "unavailable_observation_escalated_still_held",
}

MISMATCH_SOURCE_STATES = {
    "rollback_review_opened_quarantine_maintained",
    "remediation_handoff_requested_no_action",
}


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be remediation_closure_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def resolve_source_remediation(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    source = validate_ref(
        ref,
        label="source_rollback_remediation_ref",
        expected_schema="ward.governance-rollback-remediation-receipt.v0",
        checker_script="check_governance_rollback_remediations.py",
        checker_module_name="ward_rollback_remediation_checker_for_remediation_closure",
        errors=errors,
    )
    if not source:
        return None
    scope = source.get("remediation_scope") or {}
    review = source.get("review_handoff") or {}
    decision = source.get("remediation_decision") or {}
    projection = source.get("projection_safety") or {}
    mirrors = {
        "remediation_state": decision.get("state"),
        "remediation_id": scope.get("remediation_id"),
        "source_observation_id": scope.get("source_observation_id"),
        "target": scope.get("target"),
        "recipient_class": scope.get("recipient_class"),
        "projection_policy_id": scope.get("projection_policy_id"),
        "requested_remediation_effect": scope.get("requested_remediation_effect"),
        "remediation_scope_digest": scope.get("remediation_scope_digest"),
        "review_state": review.get("review_state"),
        "review_handoff_digest": review.get("review_handoff_digest"),
        "remediation_quarantined": decision.get("remediation_quarantined"),
        "rollback_review_required": decision.get("rollback_review_required"),
        "remediation_held": decision.get("remediation_held"),
        "remediation_action_performed": decision.get("remediation_action_performed"),
        "no_authority_label_present": projection.get("no_authority_label_present"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_rollback_remediation_ref.{field} does not mirror referenced rollback-remediation receipt")
    if decision.get("no_authority_granted") is not True:
        errors.append("referenced rollback-remediation receipt must grant no authority")
    if decision.get("status_pointer_update_allowed") is not False:
        errors.append("referenced rollback-remediation receipt must not allow status-pointer update")
    if decision.get("remediation_action_performed") is not False:
        errors.append("referenced rollback-remediation receipt must not perform remediation action")
    return source


def closure_scope_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_rollback_remediation_ref") or {}
    scope = receipt.get("closure_scope") or {}
    required_fields = [
        "closure_id", "source_remediation_id", "target", "recipient_class", "projection_policy_id",
        "requested_closure_effect", "closure_consequence_class", "closure_window_start",
        "closure_window_end", "separate_authority_required", "closure_scope_digest",
    ]
    for field in required_fields:
        if scope.get(field) in (None, ""):
            errors.append(f"closure_scope.{field} missing")
    if scope.get("source_remediation_id") != ref.get("remediation_id"):
        errors.append("closure_scope.source_remediation_id must mirror source remediation id")
    if scope.get("target") != ref.get("target"):
        errors.append("closure_scope.target must mirror source target")
    if scope.get("recipient_class") != ref.get("recipient_class"):
        errors.append("closure_scope.recipient_class must mirror source recipient class")
    if scope.get("projection_policy_id") != ref.get("projection_policy_id"):
        errors.append("closure_scope.projection_policy_id must mirror source projection policy")
    if scope.get("separate_authority_required") is not True:
        errors.append("closure_scope.separate_authority_required must be true")
    try:
        start = parse_time(scope.get("closure_window_start"), "closure_scope.closure_window_start")
        end = parse_time(scope.get("closure_window_end"), "closure_scope.closure_window_end")
        if end <= start:
            errors.append("closure_scope.closure_window_end must be after closure_window_start")
    except ValueError as exc:
        errors.append(str(exc))
    expected_digest = stable_digest({
        "closure_id": scope.get("closure_id"),
        "source_rollback_remediation_receipt_id": ref.get("receipt_id"),
        "source_remediation_id": scope.get("source_remediation_id"),
        "source_remediation_state": ref.get("remediation_state"),
        "target": scope.get("target"),
        "recipient_class": scope.get("recipient_class"),
        "projection_policy_id": scope.get("projection_policy_id"),
        "requested_closure_effect": scope.get("requested_closure_effect"),
        "closure_consequence_class": scope.get("closure_consequence_class"),
    })
    if scope.get("closure_scope_digest") != expected_digest:
        errors.append("closure_scope.closure_scope_digest does not match closure binding")


def verification_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_rollback_remediation_ref") or {}
    scope = receipt.get("closure_scope") or {}
    verification = receipt.get("verification_evidence") or {}
    for field, expected in {
        "source_rollback_remediation_digest_checked": True,
        "source_remediation_state_matches": True,
        "source_review_handoff_digest_checked": True,
        "external_remedy_proof_verified": False,
        "rollback_execution_verified": False,
        "quarantine_clearance_proof_present": False,
        "reviewer_conflict_checked": True,
        "verification_debt_recorded": True,
    }.items():
        if verification.get(field) is not expected:
            errors.append(f"verification_evidence.{field} must be {expected}")
    if verification.get("closure_evidence_kind") not in {
        "none_needed",
        "noop_confirmed",
        "review_closed_no_action",
        "handoff_acknowledged",
        "escalation_recorded",
    }:
        errors.append("verification_evidence.closure_evidence_kind invalid")
    try:
        parse_time(verification.get("next_recheck_by"), "verification_evidence.next_recheck_by")
    except ValueError as exc:
        errors.append(str(exc))
    expected_digest = stable_digest({
        "closure_id": scope.get("closure_id"),
        "source_remediation_state": ref.get("remediation_state"),
        "closure_evidence_kind": verification.get("closure_evidence_kind"),
        "external_remedy_proof_present": verification.get("external_remedy_proof_present"),
        "external_remedy_proof_verified": verification.get("external_remedy_proof_verified"),
        "rollback_execution_verified": verification.get("rollback_execution_verified"),
        "quarantine_clearance_proof_present": verification.get("quarantine_clearance_proof_present"),
    })
    if verification.get("closure_evidence_digest") != expected_digest:
        errors.append("verification_evidence.closure_evidence_digest does not match verification binding")


def closure_controls_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    controls = receipt.get("closure_controls") or {}
    expected_controls = {
        "source_rollback_remediation_mutated": False,
        "source_outcome_observation_mutated": False,
        "source_use_execution_mutated": False,
        "source_status_pointer_mutated": False,
        "closure_can_grant_authority": False,
        "closure_can_execute_rollback": False,
        "closure_can_complete_remedy": False,
        "closure_can_clear_quarantine_without_proof": False,
        "status_pointer_update_allowed": False,
        "scope_expansion_allowed": False,
        "requires_no_authority_label": True,
        "requires_source_rollback_remediation_ref": True,
        "requires_closure_scope_digest": True,
        "source_packet_replay_still_required": True,
        "refresh_still_required": True,
        "safe_closure_effects_only": True,
        "no_authority_upgrade": True,
        "no_high_consequence_closure_effects": True,
        "closure_debt_recorded": True,
    }
    for field, expected in expected_controls.items():
        if controls.get(field) is not expected:
            errors.append(f"closure_controls.{field} must be {expected}")
    planned = set(controls.get("planned_effects") or [])
    forbidden = set(controls.get("forbidden_effects") or [])
    unknown_planned = sorted(planned - SAFE_CLOSURE_EFFECTS)
    if unknown_planned:
        errors.append("closure_controls.planned_effects contains non-safe effects: " + ", ".join(unknown_planned))
    high = sorted(planned & HIGH_CONSEQUENCE_EFFECTS)
    if high:
        errors.append("closure_controls.planned_effects contains high-consequence effects: " + ", ".join(high))
    missing = sorted(REQUIRED_FORBIDDEN - forbidden)
    if missing:
        errors.append("closure_controls.forbidden_effects missing required fences: " + ", ".join(missing))
    if sorted(HIGH_CONSEQUENCE_EFFECTS - forbidden):
        missing_high = sorted(HIGH_CONSEQUENCE_EFFECTS - forbidden)
        errors.append("closure_controls.forbidden_effects must include high-consequence fences: " + ", ".join(missing_high))


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    scope = receipt.get("closure_scope") or {}
    projection = receipt.get("projection_safety") or {}
    if projection.get("projection_policy_id") != scope.get("projection_policy_id"):
        errors.append("projection_safety.projection_policy_id must mirror closure_scope")
    if projection.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(projection.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    if scope.get("recipient_class") in PUBLIC_RECIPIENTS:
        for field in [
            "reveals_receiver_identity_public", "reveals_status_channel_private",
            "reveals_named_private_stewards", "reveals_private_org_map",
            "reveals_raw_partner_fragments", "reveals_recipient_private_contact",
            "sealed_outcome_payload_inline", "sealed_execution_payload_inline",
            "remediation_private_payload_inline", "closure_private_payload_inline",
        ]:
            if projection.get(field) is not False:
                errors.append(f"projection_safety.{field} must be false for public recipients")
        if projection.get("hashed_or_class_only_subjects") is not True:
            errors.append("projection_safety.hashed_or_class_only_subjects must be true for public recipients")


def decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_rollback_remediation_ref") or {}
    scope = receipt.get("closure_scope") or {}
    verification = receipt.get("verification_evidence") or {}
    controls = receipt.get("closure_controls") or {}
    decision = receipt.get("closure_decision") or {}
    state = decision.get("state")
    source_state = ref.get("remediation_state")
    effects = set(controls.get("planned_effects") or [])
    if state not in VALID_STATES:
        errors.append("closure_decision.state invalid")
    for field, expected in {
        "no_authority_granted": True,
        "refresh_still_required": True,
        "source_packet_replay_still_required": True,
        "status_pointer_update_allowed": False,
        "scope_expansion_allowed": False,
        "rollback_executed": False,
        "remedy_executed": False,
        "compensating_action_performed": False,
        "source_history_mutated": False,
    }.items():
        if decision.get(field) is not expected:
            errors.append(f"closure_decision.{field} must be {expected}")
    if "not_authority" not in (decision.get("reason_codes") or []):
        errors.append("closure_decision.reason_codes must include not_authority")
    expected_state = SOURCE_STATE_TO_DECISION.get(source_state)
    if expected_state and state != expected_state:
        errors.append("closure_decision.state does not match referenced rollback-remediation state")
    if source_state in MISMATCH_SOURCE_STATES:
        if decision.get("remediation_quarantine_maintained") is not True:
            errors.append("mismatch remediation closures must maintain quarantine")
        if "maintain_remediation_quarantine" not in effects:
            errors.append("mismatch remediation closures must plan maintain_remediation_quarantine")
        if decision.get("recipient_notice_required") is not True or decision.get("recipient_notice_sent") is not True:
            errors.append("mismatch remediation closures must require and send recipient notice")
    if state == "no_remediation_closure_confirmed_refresh_required":
        if scope.get("requested_closure_effect") != "confirm_no_remediation_closure":
            errors.append("no-remediation closure requires confirm_no_remediation_closure")
        if verification.get("closure_evidence_kind") != "none_needed":
            errors.append("no-remediation closure requires none_needed evidence")
        if decision.get("remediation_quarantine_maintained") is not False or decision.get("external_proof_required") is not False:
            errors.append("no-remediation closure cannot maintain quarantine or require external proof")
        if "close_no_remediation_needed" not in effects:
            errors.append("no-remediation closure must close no-remediation-needed")
    if state == "noop_closure_confirmed_refresh_required":
        if scope.get("requested_closure_effect") != "confirm_noop_closure":
            errors.append("noop closure requires confirm_noop_closure")
        if verification.get("closure_evidence_kind") != "noop_confirmed":
            errors.append("noop closure requires noop_confirmed evidence")
        if decision.get("remediation_quarantine_maintained") is not False or decision.get("external_proof_required") is not False:
            errors.append("noop closure cannot maintain quarantine or require external proof")
        if "close_noop_no_remediation_needed" not in effects:
            errors.append("noop closure must close noop no-remediation-needed")
    if state == "rollback_review_closed_quarantine_sustained":
        if scope.get("requested_closure_effect") != "close_review_no_action_keep_quarantine":
            errors.append("rollback review closure requires close_review_no_action_keep_quarantine")
        if verification.get("closure_evidence_kind") != "review_closed_no_action":
            errors.append("rollback review closure requires review_closed_no_action evidence")
        if decision.get("review_closed") is not True or decision.get("external_proof_required") is not True:
            errors.append("rollback review closure must close review and keep external proof required")
        if not {"record_review_closed_no_action", "maintain_remediation_quarantine", "record_verification_debt"}.issubset(effects):
            errors.append("rollback review closure must record review closure, quarantine, and verification debt")
    if state == "remediation_handoff_acknowledged_external_proof_required":
        if scope.get("requested_closure_effect") != "acknowledge_handoff_request":
            errors.append("handoff closure requires acknowledge_handoff_request")
        if verification.get("closure_evidence_kind") != "handoff_acknowledged":
            errors.append("handoff closure requires handoff_acknowledged evidence")
        if decision.get("handoff_acknowledged") is not True or decision.get("external_proof_required") is not True:
            errors.append("handoff closure must acknowledge handoff and require external proof")
        if not {"record_handoff_acknowledgment", "request_external_remedy_proof", "maintain_remediation_quarantine"}.issubset(effects):
            errors.append("handoff closure must record ack, request external proof, and maintain quarantine")
    if state == "unavailable_observation_escalated_still_held":
        if scope.get("requested_closure_effect") != "escalate_unavailable_observation_hold":
            errors.append("unavailable closure requires escalate_unavailable_observation_hold")
        if verification.get("closure_evidence_kind") != "escalation_recorded":
            errors.append("unavailable closure requires escalation_recorded evidence")
        if decision.get("observation_hold_escalated") is not True or decision.get("external_proof_required") is not False:
            errors.append("unavailable closure must escalate observation hold without external remedy proof")
        if not {"hold_pending_observation", "escalate_observation_unavailable", "record_verification_debt"}.issubset(effects):
            errors.append("unavailable closure must hold pending observation, escalate, and record debt")
    if decision.get("closure_finality") not in {"bounded_refresh_required", "pending_external_proof", "held_pending_observation"}:
        errors.append("closure_decision.closure_finality invalid")
    if state in {"rollback_review_closed_quarantine_sustained", "remediation_handoff_acknowledged_external_proof_required"}:
        if decision.get("closure_finality") != "pending_external_proof":
            errors.append("mismatch closures must be pending_external_proof")
    if state in {"no_remediation_closure_confirmed_refresh_required", "noop_closure_confirmed_refresh_required"}:
        if decision.get("closure_finality") != "bounded_refresh_required":
            errors.append("benign closures must be bounded_refresh_required")
    if state == "unavailable_observation_escalated_still_held":
        if decision.get("closure_finality") != "held_pending_observation":
            errors.append("unavailable closure must be held_pending_observation")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    ref = receipt.get("source_rollback_remediation_ref")
    if not isinstance(ref, dict):
        errors.append("source_rollback_remediation_ref must be an object")
    else:
        resolve_source_remediation(ref, errors)
    closure_scope_ok(receipt, errors)
    verification_ok(receipt, errors)
    closure_controls_ok(receipt, errors)
    projection_ok(receipt, errors)
    decision_ok(receipt, errors)
    return errors


def main() -> int:
    return run_fixture_checker(
        fixture_dir=CLOSURE_DIR,
        valid_glob="*.valid.json",
        invalid_glob="*.invalid.json",
        validate_receipt=validate_receipt,
        label="Governance remediation-closure receipt",
    )


if __name__ == "__main__":
    sys.exit(main())
