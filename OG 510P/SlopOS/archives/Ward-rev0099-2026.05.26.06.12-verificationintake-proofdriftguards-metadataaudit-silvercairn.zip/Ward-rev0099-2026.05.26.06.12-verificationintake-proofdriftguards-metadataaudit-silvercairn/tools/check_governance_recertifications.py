#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
RECERT_DIR = ROOT / "fixtures" / "governance-recertification"
SCHEMA = "ward.governance-recertification-receipt.v0"
RECEIPT_NAME = "ward.governance.recertification-receipt.v0"
AUTHORITY_SURFACE = "recertification_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}
VALID_STATES = {
    "current_cache_recertified",
    "cached_resolution_invalidated",
    "cache_quarantine_sustained",
    "historical_cache_only",
    "recertification_recheck_required",
}
VALID_CACHE_STATES = {
    "recertified_current_refresh_required",
    "invalidated_stale",
    "quarantine_sustained",
    "historical_only",
    "recheck_required",
}
SAFE_EFFECTS = {
    "record_recertification_receipt",
    "record_cache_key_digest",
    "publish_refresh_signal",
    "invalidate_cached_resolution",
    "notify_recipients",
    "update_status_pointer",
    "sustain_quarantine",
    "retain_historical_only",
    "request_recheck",
    "record_no_current_head",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "budget_spend",
    "delegate",
    "export_raw_evidence",
    "grant_authority",
    "learning_use",
    "privacy_waiver",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "reuse_as_authority",
    "semantic_repair",
}
REQUIRED_FORBIDDEN = {
    "action_without_packet",
    "authority_reuse_without_packet",
    "budget_spend",
    "cache_as_authority",
    "cached_head_reuse_without_refresh",
    "cached_resolution_as_authority",
    "delegate_without_warrant",
    "export_without_receipt",
    "future_action",
    "learning_use",
    "old_status_channel_reuse",
    "privacy_waiver_without_packet",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "resolution_as_authority",
    "reuse_without_refresh",
    "sealed_branch_disclosure",
    "stale_cached_resolution_reuse",
    "status_channel_replay_as_authority",
    "status_pointer_as_grant",
    "unprojected_disclosure",
}


def load_checker(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load checker {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

resolution_checker = load_checker(ROOT / "tools" / "check_governance_dispute_resolutions.py", "ward_dispute_checker_for_recertification")


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stable_digest(obj: Any) -> str:
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def parse_time(value: str | None, field: str) -> datetime:
    if not value:
        raise ValueError(f"{field} missing")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} is not ISO-8601 parseable: {value}") from exc


def require(cond: bool, msg: str, errors: list[str]) -> None:
    if not cond:
        errors.append(msg)


def resolve_source_resolution(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    if ref.get("receipt_sha256_checked") is not True:
        errors.append("source_resolution_ref.receipt_sha256_checked must be true")
    rel = ref.get("receipt_path")
    if not rel:
        errors.append("source_resolution_ref.receipt_path missing")
        return None
    path = (ROOT / rel).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append(f"source resolution path escapes repository root: {rel}")
        return None
    if not path.exists():
        errors.append(f"source resolution path missing on disk: {rel}")
        return None
    actual_sha = sha256(path)
    if ref.get("receipt_sha256") != actual_sha:
        errors.append("source_resolution_ref.receipt_sha256 mismatch")
    obj = load_json(path)
    if obj.get("schema") != "ward.governance-dispute-resolution-receipt.v0":
        errors.append("source_resolution_ref must point at a governance-dispute-resolution receipt")
    if ref.get("receipt_id") != obj.get("receipt_id"):
        errors.append("source_resolution_ref.receipt_id does not match referenced receipt")
    source_errors = resolution_checker.validate_receipt(obj, path)
    if source_errors:
        errors.append("referenced source resolution is invalid: " + "; ".join(source_errors))
    scope = obj.get("resolution_scope") or {}
    decision = obj.get("resolution_decision") or {}
    head = obj.get("recovered_head") or {}
    mirrors = {
        "source_resolution_state": decision.get("state"),
        "source_release_id": scope.get("source_release_id"),
        "recipient_class": scope.get("recipient_class"),
        "purpose": scope.get("purpose"),
        "source_item_digest": scope.get("source_item_digest"),
        "projection_policy_digest": scope.get("projection_policy_digest"),
        "source_reuse_state": decision.get("release_reuse_state"),
        "source_status_pointer": head.get("status_pointer"),
        "source_current_head_published": head.get("current_head_published"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_resolution_ref.{field} does not mirror source resolution")
    return obj


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be recertification_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def scope_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    scope = receipt.get("recertification_scope") or {}
    if source is not None:
        source_scope = source.get("resolution_scope") or {}
        for field in ["source_release_id", "recipient_class", "purpose", "source_item_digest", "projection_policy_digest"]:
            if scope.get(field) != source_scope.get(field):
                errors.append(f"recertification_scope.{field} must mirror source resolution")
    if scope.get("recertification_kind") not in {"scheduled_recheck", "status_channel_recheck", "recipient_refresh", "cache_invalidation", "historical_revalidation", "projection_policy_recheck"}:
        errors.append("recertification_scope.recertification_kind invalid or missing")
    try:
        cut = parse_time(scope.get("recertification_cut_time"), "recertification_scope.recertification_cut_time")
        due = parse_time(scope.get("next_recheck_due"), "recertification_scope.next_recheck_due")
        if due <= cut:
            errors.append("recertification_scope.next_recheck_due must be after recertification_cut_time")
    except ValueError as exc:
        errors.append(str(exc))
    if not scope.get("recertifier_profile"):
        errors.append("recertification_scope.recertifier_profile missing")


def cache_binding_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    binding = receipt.get("cache_binding") or {}
    ref = receipt.get("source_resolution_ref") or {}
    subject = binding.get("cache_subject")
    if not isinstance(subject, dict):
        errors.append("cache_binding.cache_subject missing or not object")
        subject = {}
    expected_digest = stable_digest(subject)
    if binding.get("cache_subject_digest") != expected_digest:
        errors.append("cache_binding.cache_subject_digest does not match cache_subject")
    if binding.get("cached_resolution_id") != ref.get("receipt_id"):
        errors.append("cache_binding.cached_resolution_id must match source_resolution_ref.receipt_id")
    if binding.get("cached_receipt_sha256") != ref.get("receipt_sha256"):
        errors.append("cache_binding.cached_receipt_sha256 must match source_resolution_ref.receipt_sha256")
    for field in ["source_release_id", "recipient_class", "purpose", "source_item_digest", "projection_policy_digest"]:
        if subject.get(field) != ref.get(field):
            errors.append(f"cache_binding.cache_subject.{field} must mirror source_resolution_ref")
    if subject.get("source_resolution_id") != ref.get("receipt_id"):
        errors.append("cache_binding.cache_subject.source_resolution_id must mirror source_resolution_ref.receipt_id")
    if binding.get("cached_status_pointer") != ref.get("source_status_pointer"):
        errors.append("cache_binding.cached_status_pointer must mirror source status pointer")
    if binding.get("cached_state") != ref.get("source_resolution_state"):
        errors.append("cache_binding.cached_state must mirror source resolution state")


def triggers_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    trig = receipt.get("trigger_evidence") or {}
    decision = receipt.get("recertification_decision") or {}
    binding = receipt.get("cache_binding") or {}
    if trig.get("cache_subject_digest_checked") is not True:
        errors.append("trigger_evidence.cache_subject_digest_checked must be true")
    if trig.get("cache_subject_digest") != binding.get("cache_subject_digest"):
        errors.append("trigger_evidence.cache_subject_digest must match cache binding")
    required_true = [
        "source_resolution_replayed",
        "source_resolution_digest_checked",
        "status_channel_checked",
        "latest_status_pointer_checked",
        "recipient_notice_channel_checked",
        "projection_policy_digest_checked",
        "owner_map_epoch_checked",
        "successor_state_checked",
        "branch_state_checked",
        "followup_signal_checked",
        "clock_window_checked",
    ]
    for field in required_true:
        if trig.get(field) is not True:
            errors.append(f"trigger_evidence.{field} must be true")
    if not trig.get("recheck_reason_codes"):
        errors.append("trigger_evidence.recheck_reason_codes missing")
    if decision.get("state") == "current_cache_recertified":
        if trig.get("no_newer_signal_observed") is not True:
            errors.append("current_cache_recertified requires no_newer_signal_observed true")
        if trig.get("projection_policy_changed") is not False:
            errors.append("current_cache_recertified requires projection_policy_changed false")
        if trig.get("status_channel_changed") is not False:
            errors.append("current_cache_recertified requires status_channel_changed false")
    else:
        if trig.get("stale_or_changed_basis_declared") is not True:
            errors.append("non-current recertification requires stale_or_changed_basis_declared true")


def procedure_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    proc = receipt.get("recertification_procedure") or {}
    posture = receipt.get("cache_posture") or {}
    decision = receipt.get("recertification_decision") or {}
    required_true = [
        "source_resolution_replayed",
        "source_resolution_digest_checked",
        "cache_key_bound",
        "status_channel_rechecked",
        "recipient_refresh_channel_rechecked",
        "projection_policy_checked",
        "owner_map_epoch_checked",
        "successor_state_checked",
        "branch_state_checked",
        "replay_before_reuse_required",
        "no_source_mutation",
        "no_authority_upgrade",
    ]
    for field in required_true:
        if proc.get(field) is not True:
            errors.append(f"recertification_procedure.{field} must be true")
    if not proc.get("reason_codes"):
        errors.append("recertification_procedure.reason_codes missing")
    state = decision.get("state")
    if state == "current_cache_recertified":
        if proc.get("next_recheck_scheduled") is not True:
            errors.append("current_cache_recertified requires next_recheck_scheduled")
        if proc.get("old_cache_invalidated") is not False:
            errors.append("current_cache_recertified must not mark old_cache_invalidated true")
    else:
        if proc.get("stale_consumers_notified") is not True:
            errors.append("non-current recertification requires stale_consumers_notified")
        if proc.get("old_cache_invalidated") is not True:
            errors.append("non-current recertification requires old_cache_invalidated")


def cache_posture_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    posture = receipt.get("cache_posture") or {}
    decision = receipt.get("recertification_decision") or {}
    ref = receipt.get("source_resolution_ref") or {}
    cache_state = posture.get("cache_state")
    if cache_state not in VALID_CACHE_STATES:
        errors.append("cache_posture.cache_state invalid or missing")
    if posture.get("cached_resolution_reusable_without_refresh") is not False:
        errors.append("cache_posture.cached_resolution_reusable_without_refresh must be false")
    if posture.get("source_packet_replay_required") is not True:
        errors.append("cache_posture.source_packet_replay_required must be true")
    if posture.get("cache_as_authority") is not False:
        errors.append("cache_posture.cache_as_authority must be false")
    if posture.get("status_pointer_as_authority") is not False:
        errors.append("cache_posture.status_pointer_as_authority must be false")
    state = decision.get("state")
    if state == "current_cache_recertified":
        if cache_state != "recertified_current_refresh_required":
            errors.append("current_cache_recertified requires recertified_current_refresh_required cache_state")
        if posture.get("current_head_visible") is not True:
            errors.append("current_cache_recertified requires current_head_visible true")
        if not posture.get("cached_status_pointer"):
            errors.append("current_cache_recertified requires cached_status_pointer")
        if posture.get("cached_status_pointer") != ref.get("source_status_pointer"):
            errors.append("current cache status pointer must match source")
        if posture.get("old_cached_entry_invalidated") is not False:
            errors.append("current_cache_recertified must keep old_cached_entry_invalidated false")
    else:
        if posture.get("current_head_visible") is not False:
            errors.append("non-current recertification must set current_head_visible false")
        if posture.get("cached_status_pointer") not in (None, ""):
            errors.append("non-current recertification must not expose cached_status_pointer")
        if posture.get("old_cached_entry_invalidated") is not True:
            errors.append("non-current recertification must invalidate old cached entry")
    expected = {
        "cached_resolution_invalidated": "invalidated_stale",
        "cache_quarantine_sustained": "quarantine_sustained",
        "historical_cache_only": "historical_only",
        "recertification_recheck_required": "recheck_required",
    }
    if state in expected and cache_state != expected[state]:
        errors.append(f"{state} requires cache_state {expected[state]}")


def notification_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    note = receipt.get("notification_status") or {}
    decision = receipt.get("recertification_decision") or {}
    if note.get("status_channel_updated") is not True:
        errors.append("notification_status.status_channel_updated must be true")
    if note.get("notification_digests_checked") is not True:
        errors.append("notification_status.notification_digests_checked must be true")
    if note.get("recipient_ack_required_for_authority") is not False:
        errors.append("notification_status.recipient_ack_required_for_authority must be false")
    if not note.get("notice_modes"):
        errors.append("notification_status.notice_modes missing")
    if decision.get("state") != "current_cache_recertified":
        if note.get("stale_consumers_notified") is not True:
            errors.append("non-current recertification must notify stale consumers")
        if note.get("refresh_signal_published") is not True:
            errors.append("non-current recertification must publish refresh signal")


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    scope = receipt.get("recertification_scope") or {}
    proj = receipt.get("projection_safety") or {}
    public = scope.get("recipient_class") in PUBLIC_RECIPIENTS or proj.get("projection_class") == "public_minimized"
    if proj.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(proj.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    for field in [
        "sealed_branch_evidence_inline",
        "reveals_private_org_map",
        "reveals_raw_partner_fragments",
        "reveals_reviewer_identities",
        "reveals_named_private_stewards",
        "reveals_conflict_details_public",
        "reveals_recipient_private_contact",
    ]:
        if proj.get(field) is not False:
            errors.append(f"projection_safety.{field} must be false")
    if public:
        if proj.get("no_exact_hidden_branch_counts_public") is not True:
            errors.append("public recertification must not reveal exact hidden branch counts")
        if proj.get("status_or_cache_state_only") is not True:
            errors.append("public recertification must expose only status/cache state")
        if proj.get("bucketed_or_presence_only_disclosure") is not True:
            errors.append("public recertification requires bucketed or presence-only disclosure")


def effects_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    effects = receipt.get("effect_closure") or {}
    performed = set(effects.get("effects_performed") or [])
    preserved = set(effects.get("forbidden_effects_preserved") or [])
    if effects.get("safe_recertification_effects_only") is not True:
        errors.append("effect_closure.safe_recertification_effects_only must be true")
    if effects.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if effects.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")
    extra = performed - SAFE_EFFECTS
    if extra:
        errors.append("effect_closure has non-recertification effects: " + ", ".join(sorted(extra)))
    high = performed & HIGH_CONSEQUENCE_EFFECTS
    if high:
        errors.append("effect_closure performs high consequence effects: " + ", ".join(sorted(high)))
    missing = REQUIRED_FORBIDDEN - preserved
    if missing:
        errors.append("effect_closure missing required forbidden effects: " + ", ".join(sorted(missing)))


def decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    decision = receipt.get("recertification_decision") or {}
    posture = receipt.get("cache_posture") or {}
    state = decision.get("state")
    if state not in VALID_STATES:
        errors.append("recertification_decision.state invalid or missing")
    if not decision.get("reason_codes"):
        errors.append("recertification_decision.reason_codes missing")
    if decision.get("no_authority_granted") is not True:
        errors.append("recertification_decision.no_authority_granted must be true")
    if decision.get("source_resolution_mutated") is not False:
        errors.append("recertification_decision.source_resolution_mutated must be false")
    if decision.get("cached_resolution_reuse_state") not in {"refresh_required", "invalidated", "held_due_to_quarantine", "historical_only", "recheck_required"}:
        errors.append("recertification_decision.cached_resolution_reuse_state invalid or missing")
    expected_reuse = {
        "current_cache_recertified": "refresh_required",
        "cached_resolution_invalidated": "invalidated",
        "cache_quarantine_sustained": "held_due_to_quarantine",
        "historical_cache_only": "historical_only",
        "recertification_recheck_required": "recheck_required",
    }
    if state in expected_reuse and decision.get("cached_resolution_reuse_state") != expected_reuse[state]:
        errors.append(f"{state} requires cached_resolution_reuse_state {expected_reuse[state]}")
    if state != "current_cache_recertified" and posture.get("current_head_visible") is True:
        errors.append("only current_cache_recertified may expose a current head")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    source = resolve_source_resolution(receipt.get("source_resolution_ref") or {}, errors)
    scope_ok(receipt, source, errors)
    cache_binding_ok(receipt, source, errors)
    triggers_ok(receipt, errors)
    procedure_ok(receipt, errors)
    cache_posture_ok(receipt, errors)
    notification_ok(receipt, errors)
    projection_ok(receipt, errors)
    effects_ok(receipt, errors)
    decision_ok(receipt, errors)
    return errors


def main() -> int:
    valid_paths = sorted(RECERT_DIR.glob("*.valid.json"))
    invalid_paths = sorted((RECERT_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance recertification fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance recertification fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance recertification check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance recertification check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
