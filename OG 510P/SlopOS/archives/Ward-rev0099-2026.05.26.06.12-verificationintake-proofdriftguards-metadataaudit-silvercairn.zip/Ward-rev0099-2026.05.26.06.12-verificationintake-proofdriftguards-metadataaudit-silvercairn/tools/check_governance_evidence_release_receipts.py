#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
RELEASE_DIR = ROOT / "fixtures" / "governance-evidence-release"

PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}
RESTRICTED_RECIPIENTS = {"internal_reviewer", "partner_restricted", "regulator_auditor", "privacy_board"}
PUBLIC_VIEWS = {"public", "external", "partner_public", "public_redacted"}
SAFE_RELEASE_EFFECTS = {
    "export_minimized_projection",
    "deliver_redacted_bundle",
    "deliver_restricted_review_bundle",
    "publish_presence_only_summary",
    "publish_bucketed_omission_summary",
    "record_release_receipt",
    "hold_release_for_recheck",
    "request_recheck",
    "retain_minimized_release_receipt",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "approve_dashboard_export",
    "raw_partner_fragment_export",
    "raw_partner_fragment_access",
    "publish_raw_partner_fragments",
    "waive_privacy",
    "action_reenable",
    "remedy",
    "semantic_repair",
    "budget_spend",
    "delegate",
    "approve",
    "learning_use",
}
SENSITIVE_FLAGS = {
    "reveals_private_org_map",
    "reveals_raw_partner_fragments",
    "reveals_reviewer_identities",
    "reveals_incident_details",
    "reveals_named_conflicts",
}
SENSITIVE_FIELDS = {
    "raw_partner_fragments",
    "reviewer_identities",
    "private_org_map",
    "sealed_conflict_details",
    "incident_details",
    "named_conflicts",
}
WEAK_STATES = {
    "all_routing_hint_only",
    "routing_hint_only",
    "mixed_visible",
    "held_partial",
    "historical_only",
    "historical_receipt_only",
    "review_only",
    "needs_rehydration",
    "authority_missing",
    "privacy_projection_block",
    "refuse",
}
STRONG_STATES = {"consequence_grade", "all_current_consequence_grade", "released_as_current_authority"}


def load_checker(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load checker {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

search_checker = load_checker(ROOT / "tools" / "check_governance_search_continuity_receipts.py", "ward_search_continuity_checker")
batch_checker = load_checker(ROOT / "tools" / "check_governance_batch_search_receipts.py", "ward_batch_search_checker")


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_time(value: str | None, field: str) -> datetime:
    if not value:
        raise ValueError(f"{field} missing")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} is not ISO-8601 parseable: {value}") from exc


def require(cond: bool, msg: str, errors: list[str]) -> None:
    if not cond:
        errors.append(msg)


def resolve_ref(ref: dict[str, Any], errors: list[str], label: str) -> tuple[dict[str, Any] | None, Path | None]:
    if not isinstance(ref, dict):
        errors.append(f"{label} must be an object")
        return None, None
    path_value = ref.get("receipt_path")
    if not path_value:
        errors.append(f"{label}.receipt_path missing")
        return None, None
    path = (ROOT / path_value).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append(f"{label}.receipt_path escapes repository root")
        return None, None
    if not path.exists():
        errors.append(f"{label}.receipt_path missing on disk: {path_value}")
        return None, None
    actual = sha256(path)
    if ref.get("receipt_sha256") != actual:
        errors.append(f"{label}.receipt_sha256 does not match receipt bytes")
    obj = load_json(path)
    if ref.get("receipt_id") != obj.get("receipt_id"):
        errors.append(f"{label}.receipt_id does not match referenced receipt")
    return obj, path


def extract_source(receipt: dict[str, Any], errors: list[str]) -> dict[str, Any]:
    refs = receipt.get("source_receipts") or {}
    search_ref = refs.get("search_continuity_receipt_ref")
    batch_ref = refs.get("batch_search_receipt_ref")
    if bool(search_ref) == bool(batch_ref):
        errors.append("exactly one source receipt ref is required")
        return {}
    if search_ref:
        src, path = resolve_ref(search_ref, errors, "search_continuity_receipt_ref")
        if not src or not path:
            return {}
        src_errors = search_checker.validate_receipt(src, path)
        if src_errors:
            errors.append("referenced search-continuity receipt is invalid: " + "; ".join(src_errors))
        return {
            "kind": "search_continuity",
            "receipt": src,
            "query_digest": (src.get("request") or {}).get("query_digest"),
            "operation": (src.get("request") or {}).get("operation"),
            "projection_policy_digest": (src.get("request") or {}).get("projection_policy_digest"),
            "projection_view": (src.get("projection_safety") or {}).get("view"),
            "sealed_rows_present": (src.get("sealed_omissions") or {}).get("sealed_rows_present"),
            "sealed_disclosure_mode": (src.get("sealed_omissions") or {}).get("disclosure_mode"),
            "drift_state": (src.get("drift_response") or {}).get("state"),
            "result_state": (src.get("state_summary") or {}).get("current_batch_result_state"),
            "forbidden_effects": set((src.get("effect_closure") or {}).get("forbidden_effects_preserved") or []),
        }
    src, path = resolve_ref(batch_ref, errors, "batch_search_receipt_ref")
    if not src or not path:
        return {}
    src_errors = batch_checker.validate_receipt(src, path)
    if src_errors:
        errors.append("referenced batch/search receipt is invalid: " + "; ".join(src_errors))
    return {
        "kind": "batch_search",
        "receipt": src,
        "query_digest": (src.get("request") or {}).get("query_digest"),
        "operation": (src.get("request") or {}).get("operation"),
        "projection_policy_digest": (src.get("search_pagination") or {}).get("projection_filter_digest"),
        "projection_view": (src.get("projection") or {}).get("view"),
        "sealed_rows_present": False,
        "sealed_disclosure_mode": "none",
        "drift_state": "not_search_continuation",
        "result_state": (src.get("aggregation") or {}).get("result_state"),
        "forbidden_effects": set((src.get("effect_closure") or {}).get("forbidden_effects_preserved_union") or []),
    }


def request_ok(receipt: dict[str, Any], errors: list[str]) -> datetime | None:
    req = receipt.get("release_request") or {}
    require(req.get("release_kind") in {"public_redacted_export", "partner_restricted_bundle", "internal_review_bundle", "regulator_audit_snapshot", "held_recheck_notice"}, "release_request.release_kind invalid or missing", errors)
    require(req.get("recipient_class") in PUBLIC_RECIPIENTS | RESTRICTED_RECIPIENTS, "release_request.recipient_class invalid or missing", errors)
    for field in ["request_id", "requester", "purpose", "projection_view", "projection_policy_digest", "source_query_digest", "selection_digest"]:
        require(bool(req.get(field)), f"release_request.{field} missing", errors)
    try:
        return parse_time(req.get("expires_at"), "release_request.expires_at")
    except ValueError as exc:
        errors.append(str(exc))
        return None


def source_binding_ok(receipt: dict[str, Any], source: dict[str, Any], errors: list[str]) -> None:
    binding = receipt.get("source_binding") or {}
    req = receipt.get("release_request") or {}
    for field in ["source_digest_checked", "selection_bound_to_source", "query_digest_matches", "projection_policy_matches", "no_authority_upgrade"]:
        if binding.get(field) is not True:
            errors.append(f"source_binding.{field} must be true")
    if source:
        if req.get("source_query_digest") != source.get("query_digest"):
            errors.append("release_request.source_query_digest does not match source receipt")
        if req.get("projection_policy_digest") != source.get("projection_policy_digest"):
            errors.append("release_request.projection_policy_digest does not match source receipt")
        if binding.get("source_result_state") != source.get("result_state"):
            errors.append("source_binding.source_result_state does not mirror source")
        if binding.get("source_operation") != source.get("operation"):
            errors.append("source_binding.source_operation does not mirror source")
        if binding.get("drift_state") != source.get("drift_state"):
            errors.append("source_binding.drift_state does not mirror source")
    if binding.get("release_scope") not in {"projected_rows_only", "sealed_omission_summary_only", "restricted_pointer_bundle", "held_recheck_notice_only"}:
        errors.append("source_binding.release_scope invalid or missing")


def projection_ok(receipt: dict[str, Any], source: dict[str, Any], errors: list[str]) -> None:
    req = receipt.get("release_request") or {}
    projection = receipt.get("projection_release") or {}
    recipient = req.get("recipient_class")
    view = projection.get("view")
    if view != req.get("projection_view"):
        errors.append("projection_release.view does not match release_request.projection_view")
    if projection.get("minimization_applied") is not True:
        errors.append("projection_release.minimization_applied must be true")
    if projection.get("omission_basis_visible") is not True:
        errors.append("projection_release.omission_basis_visible must be true")
    if projection.get("details_redacted") is not True and (recipient in PUBLIC_RECIPIENTS or view in PUBLIC_VIEWS):
        errors.append("public/external evidence release must redact details")
    if recipient in PUBLIC_RECIPIENTS or view in PUBLIC_VIEWS:
        if projection.get("contains_sensitive_evidence") is not False:
            errors.append("public/external evidence release contains sensitive evidence")
        if projection.get("sealed_evidence_inline") is not False:
            errors.append("public/external evidence release inlines sealed evidence")
        for flag in SENSITIVE_FLAGS:
            if projection.get(flag) is True:
                errors.append(f"public/external evidence release leaks {flag}")
        if projection.get("no_exact_sealed_counts_for_public") is not True:
            errors.append("public/external evidence release requires no_exact_sealed_counts_for_public=true")
        if projection.get("no_per_subject_breakdowns") is not True:
            errors.append("public/external evidence release requires no_per_subject_breakdowns=true")
    if source.get("sealed_rows_present") is True:
        if projection.get("sealed_omissions_disclosed") is not True:
            errors.append("release hides source sealed omissions")
        mode = projection.get("omission_disclosure_mode")
        if mode not in {"presence_only", "bucketed_range", "dp_noisy_count"}:
            errors.append("sealed source requires presence_only, bucketed_range, or dp_noisy_count disclosure")
        if recipient in PUBLIC_RECIPIENTS and mode == "exact_count":
            errors.append("public/external evidence release cannot disclose exact sealed counts")
        if projection.get("existence_oracle_guard") is not True:
            errors.append("sealed omission release requires existence_oracle_guard=true")
    elif projection.get("omission_disclosure_mode") not in {"none", "presence_only", "bucketed_range", "dp_noisy_count"}:
        errors.append("projection_release.omission_disclosure_mode invalid")


def recipient_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    controls = receipt.get("recipient_controls") or {}
    for field in ["recipient_bound", "purpose_bound", "no_action_authority_label_present"]:
        if controls.get(field) is not True:
            errors.append(f"recipient_controls.{field} must be true")
    for field in ["recipient_class", "watermark_label", "revocation_or_refresh_channel"]:
        if not controls.get(field):
            errors.append(f"recipient_controls.{field} missing")
    if controls.get("recipient_class") != (receipt.get("release_request") or {}).get("recipient_class"):
        errors.append("recipient_controls.recipient_class does not match release_request.recipient_class")
    if not controls.get("onward_use_restrictions"):
        errors.append("recipient_controls.onward_use_restrictions missing")
    try:
        parse_time(controls.get("retention_until"), "recipient_controls.retention_until")
    except ValueError as exc:
        errors.append(str(exc))
    label = str(controls.get("watermark_label") or "").lower()
    if "not authority" not in label and "no authority" not in label:
        errors.append("watermark_label must visibly say the release is not authority")


def payload_ok(receipt: dict[str, Any], source: dict[str, Any], errors: list[str]) -> None:
    manifest = receipt.get("payload_manifest") or {}
    decision = receipt.get("release_decision") or {}
    released = decision.get("state") in {"released_minimized", "released_restricted_review"}
    if released and not isinstance(manifest.get("item_count"), int):
        errors.append("payload_manifest.item_count must be an integer for released bundles")
    if released and manifest.get("item_count", 0) <= 0:
        errors.append("released bundle must contain at least one projected item")
    for field in ["artifact_type", "item_digest"]:
        if not manifest.get(field):
            errors.append(f"payload_manifest.{field} missing")
    if not isinstance(manifest.get("field_allowlist"), list) or not manifest.get("field_allowlist"):
        errors.append("payload_manifest.field_allowlist missing or empty")
    deny = set(manifest.get("field_denylist") or [])
    req = receipt.get("release_request") or {}
    if req.get("recipient_class") in PUBLIC_RECIPIENTS and not SENSITIVE_FIELDS <= deny:
        errors.append("public/external payload field_denylist must include all sensitive field classes")
    for field in ["member_states_preserved", "downgrade_reasons_visible", "forbidden_effects_preserved"]:
        if manifest.get(field) is not True:
            errors.append(f"payload_manifest.{field} must be true")
    src_state = source.get("result_state")
    payload_state = manifest.get("payload_result_state")
    if src_state in WEAK_STATES and payload_state in STRONG_STATES:
        errors.append("payload_manifest upgrades weak/mixed source state into current authority")


def effects_ok(receipt: dict[str, Any], source: dict[str, Any], errors: list[str]) -> None:
    closure = receipt.get("effect_closure") or {}
    effects = set(closure.get("effects_performed") or [])
    if closure.get("safe_release_effects_only") is not True:
        errors.append("effect_closure.safe_release_effects_only must be true")
    if closure.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if closure.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")
    high = effects & HIGH_CONSEQUENCE_EFFECTS
    if high:
        errors.append("evidence release performs high-consequence effects: " + ", ".join(sorted(high)))
    unsafe = effects - SAFE_RELEASE_EFFECTS
    if unsafe:
        errors.append("evidence release performs unsupported effects: " + ", ".join(sorted(unsafe)))
    preserved = set(closure.get("forbidden_effects_preserved") or [])
    missing = source.get("forbidden_effects", set()) - preserved
    if missing:
        errors.append("effect_closure drops source forbidden effects: " + ", ".join(sorted(missing)))


def decision_ok(receipt: dict[str, Any], expires_at: datetime | None, errors: list[str]) -> None:
    decision = receipt.get("release_decision") or {}
    state = decision.get("state")
    if state not in {"released_minimized", "released_restricted_review", "held_recheck_required", "release_refused"}:
        errors.append("release_decision.state invalid or missing")
    if not decision.get("reason_codes"):
        errors.append("release_decision.reason_codes missing")
    if decision.get("no_authority_granted") is not True:
        errors.append("release_decision.no_authority_granted must be true")
    if expires_at:
        try:
            receipt_time = parse_time(receipt.get("receipt_time"), "receipt_time")
            if state in {"released_minimized", "released_restricted_review"} and expires_at <= receipt_time:
                errors.append("released evidence receipt is already expired")
        except ValueError as exc:
            errors.append(str(exc))


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    require(receipt.get("schema") == "ward.governance-evidence-release-receipt.v0", "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == "ward.governance.evidence-release-receipt.v0", "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == "evidence_release_receipt_only", "authority_surface must be evidence_release_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))

    source = extract_source(receipt, errors)
    expires_at = request_ok(receipt, errors)
    source_binding_ok(receipt, source, errors)
    projection_ok(receipt, source, errors)
    recipient_ok(receipt, errors)
    payload_ok(receipt, source, errors)
    effects_ok(receipt, source, errors)
    decision_ok(receipt, expires_at, errors)
    return errors


def main() -> int:
    valid_paths = sorted(RELEASE_DIR.glob("*.valid.json"))
    invalid_paths = sorted((RELEASE_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance evidence-release fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance evidence-release fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance evidence-release receipt check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance evidence-release receipt check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
