#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    errors: list[str] = []
    registry = load_json(ROOT / "tools" / "governance_checker_registry.json")
    entries = [e for e in registry.get("entries", []) if e.get("schema_path")]
    registry_paths = {e["schema_path"]: e for e in entries}
    schema_files = sorted((ROOT / "schemas").glob("governance-*.v0.json"))
    schema_rels = {str(p.relative_to(ROOT)) for p in schema_files}

    missing_from_registry = sorted(schema_rels - set(registry_paths))
    if missing_from_registry:
        errors.append("schema files missing from governance checker registry: " + ", ".join(missing_from_registry))
    registry_ghosts = sorted(set(registry_paths) - schema_rels)
    if registry_ghosts:
        errors.append("registry schema_path entries missing on disk: " + ", ".join(registry_ghosts))

    consts: list[str] = []
    ids: list[str] = []
    for rel in sorted(schema_rels):
        path = ROOT / rel
        try:
            schema = load_json(path)
        except Exception as exc:
            errors.append(f"{rel}: schema is not parseable JSON: {exc}")
            continue
        const = (((schema.get("properties") or {}).get("schema") or {}).get("const"))
        sid = schema.get("$id")
        title = schema.get("title")
        if schema.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
            errors.append(f"{rel}: $schema must be draft 2020-12")
        if schema.get("type") != "object":
            errors.append(f"{rel}: top-level type must be object")
        if not isinstance(schema.get("required"), list) or "schema" not in schema.get("required", []):
            errors.append(f"{rel}: required must include schema")
        if const is None:
            errors.append(f"{rel}: properties.schema.const missing")
        else:
            consts.append(const)
        if not sid:
            errors.append(f"{rel}: $id missing")
        else:
            ids.append(sid)
        if not title or "Ward" not in str(title):
            errors.append(f"{rel}: title missing Ward marker")
        entry = registry_paths.get(rel)
        if entry:
            if entry.get("schema_id") != const:
                errors.append(f"{rel}: registry schema_id does not match properties.schema.const")
            if sid != const and not str(sid).endswith(Path(rel).name):
                errors.append(f"{rel}: $id must match properties.schema.const or schema filename")
            fixture_dir = entry.get("fixture_dir")
            if fixture_dir and not (ROOT / fixture_dir).exists():
                errors.append(f"{rel}: registered fixture_dir missing: {fixture_dir}")
    for label, values in [("schema const", consts), ("schema $id", ids)]:
        seen = set()
        dupes = sorted({v for v in values if v in seen or seen.add(v)})
        if dupes:
            errors.append(f"duplicate {label} values: " + ", ".join(dupes))
    if errors:
        print("Schema catalog integrity check failed.")
        for err in errors:
            print(" -", err)
        return 1
    print(f"Schema catalog integrity check passed ({len(schema_files)} governance schemas audited).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
