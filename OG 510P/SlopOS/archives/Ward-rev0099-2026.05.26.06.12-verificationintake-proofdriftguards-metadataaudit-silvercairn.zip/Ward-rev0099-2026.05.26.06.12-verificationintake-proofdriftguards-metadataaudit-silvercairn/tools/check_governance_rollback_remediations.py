#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Any
import sys

from governance_common import (
    ROOT,
    parse_time,
    require,
    run_fixture_checker,
    stable_digest,
    validate_ref,
)

REMEDIATION_DIR = ROOT / "fixtures" / "governance-rollback-remediation"
SCHEMA = "ward.governance-rollback-remediation-receipt.v0"
RECEIPT_NAME = "ward.governance.rollback-remediation-receipt.v0"
AUTHORITY_SURFACE = "rollback_remediation_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}

VALID_STATES = {
    "no_remediation_needed_match_refresh_required",
    "noop_hold_no_remediation_needed",
    "rollback_review_opened_quarantine_maintained",
    "remediation_handoff_requested_no_action",
    "observation_unavailable_hold_no_remediation",
    "invalid_rollback_remediation_rejected",
}

SAFE_REMEDIATION_EFFECTS = {
    "record_rollback_remediation_receipt",
    "record_source_outcome_observation_ref",
    "record_remediation_scope_digest",
    "publish_no_authority_remediation_status",
    "close_no_remediation_needed",
    "maintain_outcome_quarantine",
    "open_rollback_review",
    "request_remedy_handoff_packet",
    "request_harbor_recheck",
    "notify_affected_consumer_followup",
    "hold_pending_observation",
    "request_use_execution_replay",
    "request_source_packet_replay",
}

HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "approve_export",
    "budget_spend",
    "delegate",
    "evidence_bundle_release",
    "execute_rollback",
    "export_raw_evidence",
    "force_consumer_action",
    "grant_authority",
    "learning_use",
    "merge_divergent_status_channels",
    "mutate_source_outcome_observation",
    "mutate_source_use_execution",
    "privacy_waiver",
    "promote_global_current_head",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "rollback_without_review",
    "semantic_repair",
    "status_pointer_update",
    "unseal_private_evidence",
    "update_current_head",
    "update_status_pointer",
}

REQUIRED_FORBIDDEN = {
    "authority_from_remediation",
    "budget_spend",
    "display_reuse_as_remedy_authority",
    "evidence_release_without_release_receipt",
    "export_without_receipt",
    "grant_authority",
    "handoff_request_as_remedy",
    "hidden_mismatch",
    "high_consequence_without_handoff_packet",
    "learning_use",
    "no_observation_as_remedy",
    "observation_match_as_remedy",
    "privacy_waiver_without_packet",
    "public_private_identity_leak",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remediation_as_authority",
    "remedy_without_handoff_packet",
    "repair",
    "rollback_review_as_rollback",
    "rollback_without_separate_authority",
    "scope_expansion",
    "sealed_payload_disclosure",
    "semantic_repair_without_warrant",
    "source_outcome_mutation",
    "source_use_execution_mutation",
    "status_pointer_update",
    "unprojected_disclosure",
}

MISMATCH_STATES = {"observed_mismatch_quarantined_rollback_required"}
MATCHED_STATES = {"observed_public_display_matched_refresh_required", "observed_internal_review_matched_refresh_required"}
NOOP_STATES = {"observed_noop_hold_confirmed"}
UNAVAILABLE_STATES = {"observation_unavailable_held_no_claim"}


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be rollback_remediation_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def resolve_source_outcome(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    source = validate_ref(
        ref,
        label="source_outcome_observation_ref",
        expected_schema="ward.governance-outcome-observation-receipt.v0",
        checker_script="check_governance_outcome_observations.py",
        checker_module_name="ward_outcome_observation_checker_for_rollback_remediation",
        errors=errors,
    )
    if not source:
        return None
    obs = source.get("outcome_observation") or {}
    decision = source.get("outcome_decision") or {}
    projection = source.get("projection_safety") or {}
    mirrors = {
        "outcome_state": decision.get("state"),
        "observation_id": obs.get("observation_id"),
        "observation_matched": decision.get("observation_matched"),
        "observation_held": decision.get("observation_held"),
        "observation_quarantined": decision.get("observation_quarantined"),
        "rollback_required": decision.get("rollback_required"),
        "remedy_required": decision.get("remedy_required"),
        "refresh_still_required": decision.get("refresh_still_required"),
        "observed_effect": obs.get("observed_effect"),
        "observed_target": obs.get("observed_target"),
        "observed_recipient_class": obs.get("observed_recipient_class"),
        "observed_projection_policy_id": obs.get("observed_projection_policy_id"),
        "observed_outcome_digest": obs.get("observed_outcome_digest"),
        "no_authority_label_present": projection.get("no_authority_label_present"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_outcome_observation_ref.{field} does not mirror referenced outcome-observation receipt")
    if decision.get("no_authority_granted") is not True:
        errors.append("referenced outcome-observation receipt must grant no authority")
    if decision.get("status_pointer_update_allowed") is not False:
        errors.append("referenced outcome-observation receipt must not allow status-pointer update")
    return source


def remediation_scope_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_outcome_observation_ref") or {}
    scope = receipt.get("remediation_scope") or {}
    required_fields = [
        "remediation_id", "source_observation_id", "target", "recipient_class", "projection_policy_id",
        "requested_remediation_effect", "remediation_consequence_class", "remediation_window_start",
        "remediation_window_end", "separate_authority_required", "remediation_scope_digest",
    ]
    for field in required_fields:
        if scope.get(field) in (None, ""):
            errors.append(f"remediation_scope.{field} missing")
    if scope.get("source_observation_id") != ref.get("observation_id"):
        errors.append("remediation_scope.source_observation_id must mirror source outcome observation id")
    if scope.get("target") != ref.get("observed_target"):
        errors.append("remediation_scope.target must mirror source observed target")
    if scope.get("recipient_class") != ref.get("observed_recipient_class"):
        errors.append("remediation_scope.recipient_class must mirror source observed recipient class")
    if scope.get("projection_policy_id") != ref.get("observed_projection_policy_id"):
        errors.append("remediation_scope.projection_policy_id must mirror source observed projection policy")
    if scope.get("separate_authority_required") is not True:
        errors.append("remediation_scope.separate_authority_required must be true")
    try:
        start = parse_time(scope.get("remediation_window_start"), "remediation_scope.remediation_window_start")
        end = parse_time(scope.get("remediation_window_end"), "remediation_scope.remediation_window_end")
        if end <= start:
            errors.append("remediation_scope.remediation_window_end must be after remediation_window_start")
    except ValueError as exc:
        errors.append(str(exc))
    expected_digest = stable_digest({
        "remediation_id": scope.get("remediation_id"),
        "source_outcome_observation_receipt_id": ref.get("receipt_id"),
        "source_observation_id": scope.get("source_observation_id"),
        "source_observed_outcome_digest": ref.get("observed_outcome_digest"),
        "target": scope.get("target"),
        "recipient_class": scope.get("recipient_class"),
        "projection_policy_id": scope.get("projection_policy_id"),
        "requested_remediation_effect": scope.get("requested_remediation_effect"),
        "remediation_consequence_class": scope.get("remediation_consequence_class"),
    })
    if scope.get("remediation_scope_digest") != expected_digest:
        errors.append("remediation_scope.remediation_scope_digest does not match scope binding")


def remediation_plan_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    plan = receipt.get("remediation_plan") or {}
    closure = receipt.get("remediation_closure") or {}
    expected_plan_bool = {
        "source_outcome_digest_checked": True,
        "source_outcome_state_matches": True,
        "compensating_action_executed": False,
        "source_outcome_observation_mutated": False,
        "source_use_execution_mutated": False,
        "status_pointer_update_allowed": False,
        "rollback_without_separate_authority_allowed": False,
        "remedy_without_handoff_allowed": False,
        "safe_remediation_effects_only": True,
        "no_authority_label_required": True,
    }
    for field, expected in expected_plan_bool.items():
        if plan.get(field) is not expected:
            errors.append(f"remediation_plan.{field} must be {expected}")
    if plan.get("quarantine_maintained_when_required") is not True and (receipt.get("source_outcome_observation_ref") or {}).get("outcome_state") in MISMATCH_STATES:
        errors.append("remediation_plan.quarantine_maintained_when_required must be true for mismatches")
    actual = set(plan.get("planned_effects") or [])
    forbidden = set(plan.get("forbidden_effects") or [])
    if not actual:
        errors.append("remediation_plan.planned_effects missing")
    unsupported = sorted(actual - SAFE_REMEDIATION_EFFECTS)
    if unsupported:
        errors.append("remediation_plan.planned_effects contains unsupported effects: " + ", ".join(unsupported))
    high = sorted(actual & HIGH_CONSEQUENCE_EFFECTS)
    if high:
        errors.append("remediation_plan.planned_effects contains high-consequence effects: " + ", ".join(high))
    missing = sorted(REQUIRED_FORBIDDEN - forbidden)
    if missing:
        errors.append("remediation_plan.forbidden_effects missing required fences: " + ", ".join(missing[:8]))
    expected_closure_bool = {
        "source_outcome_observation_mutated": False,
        "source_use_execution_mutated": False,
        "source_reuse_gate_mutated": False,
        "source_status_pointer_mutated": False,
        "rollback_remediation_can_grant_authority": False,
        "rollback_review_can_execute_rollback": False,
        "remedy_handoff_request_can_remedy": False,
        "status_pointer_update_allowed": False,
        "scope_expansion_allowed": False,
        "requires_no_authority_label": True,
        "requires_source_outcome_observation_ref": True,
        "requires_remediation_scope_digest": True,
        "source_packet_replay_still_required": True,
        "safe_remediation_effects_only": True,
        "no_authority_upgrade": True,
        "no_high_consequence_remediation_effects": True,
    }
    for field, expected in expected_closure_bool.items():
        if closure.get(field) is not expected:
            errors.append(f"remediation_closure.{field} must be {expected}")


def review_handoff_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    scope = receipt.get("remediation_scope") or {}
    review = receipt.get("review_handoff") or {}
    required_fields = [
        "review_state", "review_opened", "review_owner_class", "review_by", "recipient_notice_required",
        "recipient_notice_sent", "handoff_packet_required", "handoff_packet_present", "rollback_execution_authorized",
        "review_handoff_digest",
    ]
    for field in required_fields:
        if review.get(field) in (None, ""):
            errors.append(f"review_handoff.{field} missing")
    try:
        parse_time(review.get("review_by"), "review_handoff.review_by")
    except ValueError as exc:
        errors.append(str(exc))
    if review.get("rollback_execution_authorized") is not False:
        errors.append("review_handoff.rollback_execution_authorized must be false in v0")
    if review.get("handoff_packet_present") is not False:
        errors.append("review_handoff.handoff_packet_present must be false in v0 fixtures; handoff is requested, not embedded")
    expected_digest = stable_digest({
        "remediation_id": scope.get("remediation_id"),
        "review_state": review.get("review_state"),
        "review_owner_class": review.get("review_owner_class"),
        "recipient_notice_required": review.get("recipient_notice_required"),
        "handoff_packet_required": review.get("handoff_packet_required"),
        "rollback_execution_authorized": review.get("rollback_execution_authorized"),
    })
    if review.get("review_handoff_digest") != expected_digest:
        errors.append("review_handoff.review_handoff_digest does not match handoff binding")


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    scope = receipt.get("remediation_scope") or {}
    projection = receipt.get("projection_safety") or {}
    if projection.get("projection_policy_id") != scope.get("projection_policy_id"):
        errors.append("projection_safety.projection_policy_id must mirror remediation_scope")
    if projection.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(projection.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    if scope.get("recipient_class") in PUBLIC_RECIPIENTS:
        for field in [
            "reveals_receiver_identity_public", "reveals_status_channel_private",
            "reveals_named_private_stewards", "reveals_private_org_map",
            "reveals_raw_partner_fragments", "reveals_recipient_private_contact",
            "sealed_outcome_payload_inline", "sealed_execution_payload_inline", "remediation_private_payload_inline",
        ]:
            if projection.get(field) is not False:
                errors.append(f"projection_safety.{field} must be false for public recipients")
        if projection.get("hashed_or_class_only_subjects") is not True:
            errors.append("projection_safety.hashed_or_class_only_subjects must be true for public recipients")


def decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_outcome_observation_ref") or {}
    scope = receipt.get("remediation_scope") or {}
    plan = receipt.get("remediation_plan") or {}
    review = receipt.get("review_handoff") or {}
    decision = receipt.get("remediation_decision") or {}
    state = decision.get("state")
    effects = set(plan.get("planned_effects") or [])
    if state not in VALID_STATES:
        errors.append("remediation_decision.state invalid")
    for field, expected in {
        "no_authority_granted": True,
        "refresh_still_required": True,
        "source_packet_replay_still_required": True,
        "status_pointer_update_allowed": False,
        "scope_expansion_allowed": False,
        "remediation_action_performed": False,
    }.items():
        if decision.get(field) is not expected:
            errors.append(f"remediation_decision.{field} must be {expected}")
    if "not_authority" not in (decision.get("reason_codes") or []):
        errors.append("remediation_decision.reason_codes must include not_authority")
    source_state = ref.get("outcome_state")
    if state == "no_remediation_needed_match_refresh_required":
        if source_state not in MATCHED_STATES:
            errors.append("no-remediation matched state requires matched source outcome")
        if scope.get("requested_remediation_effect") != "none_needed":
            errors.append("no-remediation matched state requires requested_remediation_effect none_needed")
        if review.get("review_state") != "not_needed" or review.get("review_opened") is not False:
            errors.append("no-remediation matched state must not open review")
        if decision.get("rollback_review_required") is not False or decision.get("remediation_quarantined") is not False:
            errors.append("no-remediation matched state cannot require rollback or quarantine")
        if "close_no_remediation_needed" not in effects:
            errors.append("no-remediation matched state must close no remediation needed")
    if state == "noop_hold_no_remediation_needed":
        if source_state not in NOOP_STATES:
            errors.append("noop no-remediation state requires noop source outcome")
        if scope.get("requested_remediation_effect") != "none_needed":
            errors.append("noop no-remediation state requires requested_remediation_effect none_needed")
        if review.get("review_state") != "not_needed" or decision.get("rollback_review_required") is not False:
            errors.append("noop no-remediation state must not open rollback review")
        if "close_no_remediation_needed" not in effects:
            errors.append("noop no-remediation state must close no remediation needed")
    if state == "rollback_review_opened_quarantine_maintained":
        if source_state not in MISMATCH_STATES or ref.get("rollback_required") is not True:
            errors.append("rollback-review state requires mismatched source with rollback_required")
        if scope.get("requested_remediation_effect") != "open_rollback_review":
            errors.append("rollback-review state requires requested_remediation_effect open_rollback_review")
        if review.get("review_state") != "opened" or review.get("review_opened") is not True:
            errors.append("rollback-review state must open review")
        if review.get("recipient_notice_required") is not True or review.get("recipient_notice_sent") is not True:
            errors.append("rollback-review state must require and send recipient notice")
        if decision.get("rollback_review_required") is not True or decision.get("remediation_quarantined") is not True:
            errors.append("rollback-review state must require review and quarantine")
        if not {"maintain_outcome_quarantine", "open_rollback_review"}.issubset(effects):
            errors.append("rollback-review state must maintain quarantine and open review")
    if state == "remediation_handoff_requested_no_action":
        if source_state not in MISMATCH_STATES or ref.get("rollback_required") is not True:
            errors.append("handoff-request state requires mismatched source with rollback_required")
        if scope.get("requested_remediation_effect") != "emit_remediation_handoff_request":
            errors.append("handoff-request state requires emit_remediation_handoff_request")
        if review.get("review_state") != "handoff_requested" or review.get("handoff_packet_required") is not True:
            errors.append("handoff-request state must require handoff packet")
        if decision.get("rollback_review_required") is not True or decision.get("remediation_quarantined") is not True:
            errors.append("handoff-request state must require review and keep quarantine")
        if not {"request_remedy_handoff_packet", "request_harbor_recheck", "maintain_outcome_quarantine"}.issubset(effects):
            errors.append("handoff-request state must request handoff, Harbor recheck, and maintain quarantine")
    if state == "observation_unavailable_hold_no_remediation":
        if source_state not in UNAVAILABLE_STATES:
            errors.append("unavailable remediation hold requires unavailable source outcome")
        if scope.get("requested_remediation_effect") != "hold_pending_observation":
            errors.append("unavailable remediation hold requires hold_pending_observation")
        if review.get("review_state") != "held_no_observation" or decision.get("remediation_held") is not True:
            errors.append("unavailable remediation hold must set held state")
        if decision.get("rollback_review_required") is not False or decision.get("remediation_quarantined") is not False:
            errors.append("unavailable remediation hold cannot require rollback or quarantine as if mismatch was observed")
        if "hold_pending_observation" not in effects:
            errors.append("unavailable remediation hold must record hold_pending_observation")
    if source_state in MISMATCH_STATES:
        if plan.get("quarantine_maintained_when_required") is not True:
            errors.append("mismatched sources must maintain quarantine")
        if state not in {"rollback_review_opened_quarantine_maintained", "remediation_handoff_requested_no_action"}:
            errors.append("mismatched sources require rollback review or handoff request state")
    if source_state in MATCHED_STATES and state != "no_remediation_needed_match_refresh_required":
        errors.append("matched sources must stay in no-remediation-needed state in v0")
    if source_state in NOOP_STATES and state != "noop_hold_no_remediation_needed":
        errors.append("noop sources must stay in noop no-remediation state in v0")
    if source_state in UNAVAILABLE_STATES and state != "observation_unavailable_hold_no_remediation":
        errors.append("unavailable sources must stay in hold-no-remediation state in v0")
    if decision.get("rollback_executed") is True or decision.get("remedy_executed") is True:
        errors.append("rollback/remedy execution is not allowed in rollback-remediation v0")
    if decision.get("rollback_review_required") is True and review.get("review_opened") is not True and review.get("review_state") != "handoff_requested":
        errors.append("rollback_review_required requires opened review or handoff request")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    ref = receipt.get("source_outcome_observation_ref")
    if not isinstance(ref, dict):
        errors.append("source_outcome_observation_ref must be an object")
    else:
        resolve_source_outcome(ref, errors)
    remediation_scope_ok(receipt, errors)
    remediation_plan_ok(receipt, errors)
    review_handoff_ok(receipt, errors)
    projection_ok(receipt, errors)
    decision_ok(receipt, errors)
    return errors


def main() -> int:
    return run_fixture_checker(
        fixture_dir=REMEDIATION_DIR,
        valid_glob="*.valid.json",
        invalid_glob="*.invalid.json",
        validate_receipt=validate_receipt,
        label="Governance rollback-remediation receipt",
    )


if __name__ == "__main__":
    sys.exit(main())
