#!/usr/bin/env python3
"""Ward governance decision event fixture checker.

This checker intentionally does not implement a general event log or authorization
engine. It verifies the pass LXXX rule: a decision event is a derived projection
of one governance handoff packet action, not a portable grant.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
EVENT_DIR = ROOT / "fixtures" / "governance-decision-event"
PACKET_CHECKER = ROOT / "tools" / "check_governance_handoff.py"
PROOF_IDS = [f"PO-GOV-{i:03d}" for i in range(1, 12)]
CONSEQUENCE_STATES = {"consequence_grade", "allowed"}
PUBLIC_VIEWS = {"public", "external"}
REQUIRED_FORBIDDEN = {
    "broader_scope",
    "future_action",
    "unprojected_disclosure",
    "authority_reuse_without_packet",
    "export_without_packet",
    "action_without_packet",
    "remedy_without_packet",
    "privacy_waiver_without_packet",
}
SENSITIVE_FLAGS = {
    "reveals_sealed_conflict_details",
    "reveals_raw_partner_fragments",
    "reveals_reviewer_identities",
    "reveals_private_org_map",
    "reveals_incident_details",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "approve_dashboard_export",
    "reenable_action",
    "approve_remedy",
    "waive_privacy",
    "publish_raw_partner_fragments",
    "raw_partner_fragment_access",
}

spec = importlib.util.spec_from_file_location("ward_packet_checker", PACKET_CHECKER)
packet_checker = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(packet_checker)
validate_packet = packet_checker.validate_packet
parse_time = packet_checker.parse_time


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text())
    except Exception as exc:  # pragma: no cover
        raise ValueError(f"{path}: cannot parse JSON: {exc}") from exc


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def resolve_packet(event: dict[str, Any], errors: list[str]) -> tuple[dict[str, Any] | None, Path | None]:
    ref = event.get("packet_ref") or {}
    packet_path_value = ref.get("packet_path")
    require(bool(ref.get("packet_id")), "packet_ref.packet_id missing", errors)
    require(bool(packet_path_value), "packet_ref.packet_path missing", errors)
    require(bool(ref.get("packet_sha256")), "packet_ref.packet_sha256 missing", errors)
    if not packet_path_value:
        return None, None
    packet_path = (ROOT / packet_path_value).resolve()
    try:
        packet_path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append("packet_ref.packet_path escapes repository root")
        return None, None
    if not packet_path.exists():
        errors.append(f"packet_ref.packet_path missing on disk: {packet_path_value}")
        return None, None
    actual_digest = sha256(packet_path)
    if ref.get("packet_sha256") != actual_digest:
        errors.append("packet_ref.packet_sha256 does not match packet bytes")
    packet = load_json(packet_path)
    if ref.get("packet_id") != packet.get("packet_id"):
        errors.append("packet_ref.packet_id does not match packet packet_id")
    packet_errors = validate_packet(packet, packet_path)
    if packet_errors:
        errors.append("referenced governance handoff packet is not valid: " + "; ".join(packet_errors))
    return packet, packet_path


def find_action(packet: dict[str, Any], actor: str, action: str) -> dict[str, Any] | None:
    for evaluated in packet.get("evaluated_actions", []):
        if evaluated.get("actor") == actor and evaluated.get("action") == action:
            return evaluated
    return None


def projection_ok(event: dict[str, Any], errors: list[str]) -> None:
    projection = event.get("projection") or {}
    view = projection.get("view")
    if projection.get("sealed_evidence_refs"):
        for ref in projection.get("sealed_evidence_refs") or []:
            if not str(ref).startswith("CH-AREF:"):
                errors.append("sealed_evidence_refs must be CH-AREF-like pointers")
    if view in PUBLIC_VIEWS:
        if projection.get("contains_sensitive_evidence") is True:
            errors.append("public/external projection contains sensitive evidence")
        if projection.get("sealed_evidence_inline") is True:
            errors.append("public/external projection inlines sealed evidence")
        for flag in SENSITIVE_FLAGS:
            if projection.get(flag) is True:
                errors.append(f"public/external projection leaks {flag}")


def break_glass_event_ok(event: dict[str, Any], packet: dict[str, Any], action: str, errors: list[str]) -> None:
    bg = packet.get("break_glass") or {}
    if not bg.get("used"):
        return
    if action not in set(bg.get("allowed_interim_actions") or []):
        return
    try:
        event_time = parse_time(event.get("event_time"), "event_time")
        expires_at = parse_time(bg.get("expires_at"), "packet.break_glass.expires_at")
    except ValueError as exc:
        errors.append(str(exc))
        return
    if event_time > expires_at:
        errors.append("break-glass decision event occurs after packet break_glass expiry")
    retention = event.get("retention") or {}
    projection = event.get("projection") or {}
    if not retention.get("review_debt_ref") and not any("review-debt" in ref for ref in projection.get("sealed_evidence_refs") or []):
        errors.append("break-glass decision event missing review debt reference")


def consumer_profile_ok(event: dict[str, Any], errors: list[str]) -> None:
    profile = event.get("consumer_profile")
    state = (event.get("decision") or {}).get("state")
    if profile == "helm.render":
        render = event.get("helm_render") or {}
        if render.get("display_state") != state:
            errors.append("Helm render display_state must match decision.state")
        if render.get("badge_must_include_no_authority_label") is not True:
            errors.append("Helm render must include no-authority label")
    elif profile == "schell.retention_minimized":
        retention = event.get("retention") or {}
        if not retention.get("expires_at"):
            errors.append("Schell minimized event missing retention.expires_at")
        if retention.get("minimization") not in {"sealed_pointer_only", "summary_only", "digest_only"}:
            errors.append("Schell minimized event missing acceptable minimization posture")
        if not retention.get("forgetting_or_sealing_policy"):
            errors.append("Schell minimized event missing forgetting_or_sealing_policy")
    elif profile == "harbor.recheck":
        recheck = event.get("recheck") or {}
        for field in ["recheck_kind", "deadline", "stale_surface_guard", "implementation_receipt_expected"]:
            if not recheck.get(field):
                errors.append(f"Harbor recheck event missing recheck.{field}")
    elif profile == "slopos.ch_aref_attachment":
        attachments = event.get("attachments") or {}
        if attachments.get("aref_semantics") != "identity_not_trust":
            errors.append("SlopOS CH-AREF attachment must declare identity_not_trust")
        refs = attachments.get("ch_aref_refs") or []
        if not refs:
            errors.append("SlopOS CH-AREF attachment missing ch_aref_refs")
        for ref in refs:
            if not str(ref).startswith("CH-AREF:"):
                errors.append("SlopOS attachment refs must be CH-AREF-like")
    else:
        errors.append(f"unknown consumer_profile: {profile}")


def validate_event(event: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    require(event.get("schema") == "ward.governance-decision-event.v0", "wrong or missing schema", errors)
    require(event.get("event_name") == "ward.governance.decision.v0", "wrong or missing event_name", errors)
    require(event.get("authority_surface") == "derived_receipt_only", "decision event authority_surface must be derived_receipt_only", errors)
    try:
        parse_time(event.get("event_time"), "event_time")
    except ValueError as exc:
        errors.append(str(exc))

    packet, _ = resolve_packet(event, errors)
    action_ref = event.get("evaluated_action_ref") or {}
    actor = action_ref.get("actor")
    action = action_ref.get("action")
    posture = action_ref.get("posture")
    require(bool(actor), "evaluated_action_ref.actor missing", errors)
    require(bool(action), "evaluated_action_ref.action missing", errors)
    require(bool(posture), "evaluated_action_ref.posture missing", errors)

    if packet and actor and action:
        packet_action = find_action(packet, actor, action)
        if not packet_action:
            errors.append(f"packet has no evaluated action for {actor}:{action}")
        else:
            packet_posture = packet_action.get("posture")
            if posture != packet_posture:
                errors.append("evaluated_action_ref.posture does not match packet posture")
            decision = event.get("decision") or {}
            if decision.get("state") != packet_posture:
                errors.append("decision.state does not match packet posture")
            allowed_effects = set(decision.get("allowed_effects") or [])
            if packet_posture in CONSEQUENCE_STATES and action not in allowed_effects:
                errors.append("consequence-grade event does not include evaluated action in allowed_effects")
            if packet_posture not in CONSEQUENCE_STATES and allowed_effects & HIGH_CONSEQUENCE_EFFECTS:
                errors.append("weak-state event includes high-consequence allowed_effects")
            proof_summary = decision.get("proof_summary") or {}
            if packet_posture in CONSEQUENCE_STATES:
                if proof_summary.get("status") != "all_required_pass_or_na":
                    errors.append("consequence-grade event missing all_required_pass_or_na proof summary")
                missing = [po for po in PROOF_IDS if po not in set(proof_summary.get("included_ids") or [])]
                if missing:
                    errors.append("consequence-grade event proof_summary missing IDs: " + ", ".join(missing))
                packet_proofs = packet.get("proof_obligations") or {}
                failed = [po for po, status in packet_proofs.items() if str(status).startswith("fail")]
                if failed:
                    errors.append("consequence-grade event references packet with failed proofs: " + ", ".join(sorted(failed)))
            break_glass_event_ok(event, packet, action, errors)

    forbidden = set(event.get("forbidden_effects") or [])
    missing_forbidden = sorted(REQUIRED_FORBIDDEN - forbidden)
    if missing_forbidden:
        errors.append("decision event missing forbidden_effect fences: " + ", ".join(missing_forbidden))

    projection_ok(event, errors)
    consumer_profile_ok(event, errors)
    return errors


def main() -> int:
    valid_paths = sorted(EVENT_DIR.glob("*.valid.json"))
    invalid_paths = sorted((EVENT_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance decision event fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance decision event fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_event(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_event(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance decision event fixture check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance decision event check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
