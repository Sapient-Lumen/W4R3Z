#!/usr/bin/env python3
"""Ward governance batch/search receipt fixture checker.

Pass LXXXII hardens the aggregation seam after governance decision events and
consumer receipts. A batch or search result may correlate many consumer
receipts, but it must not hide member state, replay status, forbidden effects,
projection class, or downgrade reasons behind one green badge or authority
count.
"""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
BATCH_DIR = ROOT / "fixtures" / "governance-batch-search"
CONSUMER_CHECKER = ROOT / "tools" / "check_governance_decision_consumers.py"

spec = importlib.util.spec_from_file_location("ward_consumer_checker", CONSUMER_CHECKER)
consumer_checker = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(consumer_checker)
validate_consumer_receipt = consumer_checker.validate_receipt
parse_time = consumer_checker.parse_time

HIGH_CONSEQUENCE_EFFECTS = {
    "approve_dashboard_export",
    "reenable_action",
    "approve_remedy",
    "waive_privacy",
    "publish_raw_partner_fragments",
    "raw_partner_fragment_access",
    "emergency_raw_partner_fragment_access",
    "approve_recompute_budget",
    "semantic_repair",
    "spend_budget",
}
SAFE_BATCH_EFFECTS = {
    "render_search_rows",
    "open_review_request",
    "retain_minimized_batch_summary",
    "record_batch_summary",
    "record_replay_diff",
}
PUBLIC_VIEWS = {"public", "external"}
RESTRICTED_MEMBER_VIEWS = {"restricted_internal", "sealed", "private"}
SENSITIVE_FLAGS = {
    "reveals_sealed_conflict_details",
    "reveals_raw_partner_fragments",
    "reveals_reviewer_identities",
    "reveals_private_org_map",
    "reveals_incident_details",
}
ALLOWED_RESULT_STATES = {
    "mixed_visible",
    "all_current_consequence_grade",
    "all_routing_hint_only",
    "historical_only",
    "held_partial",
}
WEAK_OR_NONCURRENT_STATES = {
    "routing_hint_only",
    "review_only",
    "needs_rehydration",
    "authority_missing",
    "handoff_unaccepted",
    "expired_warrant",
    "privacy_projection_block",
    "agent_boundary_violation",
    "refuse",
    "historical_receipt_only",
}


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text())
    except Exception as exc:  # pragma: no cover
        raise ValueError(f"{path}: cannot parse JSON: {exc}") from exc


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def resolve_consumer(member: dict[str, Any], errors: list[str]) -> tuple[dict[str, Any] | None, Path | None]:
    ref = member.get("consumer_receipt_ref") or {}
    path_value = ref.get("receipt_path")
    require(bool(ref.get("receipt_id")), "member consumer_receipt_ref.receipt_id missing", errors)
    require(bool(path_value), "member consumer_receipt_ref.receipt_path missing", errors)
    require(bool(ref.get("receipt_sha256")), "member consumer_receipt_ref.receipt_sha256 missing", errors)
    if not path_value:
        return None, None
    path = (ROOT / path_value).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append("member consumer_receipt_ref.receipt_path escapes repository root")
        return None, None
    if not path.exists():
        errors.append(f"member consumer_receipt_ref.receipt_path missing on disk: {path_value}")
        return None, None
    actual_digest = sha256(path)
    if ref.get("receipt_sha256") != actual_digest:
        errors.append("member consumer_receipt_ref.receipt_sha256 does not match receipt bytes")
    receipt = load_json(path)
    if ref.get("receipt_id") != receipt.get("receipt_id"):
        errors.append("member consumer_receipt_ref.receipt_id does not match consumer receipt_id")
    receipt_errors = validate_consumer_receipt(receipt, path)
    if receipt_errors:
        errors.append("referenced consumer receipt is not valid: " + "; ".join(receipt_errors))
    return receipt, path


def count_map(values: list[str]) -> dict[str, int]:
    return dict(sorted(Counter(values).items()))


def validate_member_mirror(member: dict[str, Any], consumer: dict[str, Any], errors: list[str]) -> None:
    state = consumer.get("state_interpretation") or {}
    replay = consumer.get("replay_check") or {}
    projection = consumer.get("projection") or {}
    closure = consumer.get("effect_closure") or {}
    if member.get("state") != state.get("consumer_state"):
        errors.append(f"member {member.get('member_id')} state does not mirror consumer_state")
    if member.get("replay_status") != replay.get("status"):
        errors.append(f"member {member.get('member_id')} replay_status does not mirror replay_check.status")
    if member.get("projection_view") != projection.get("view"):
        errors.append(f"member {member.get('member_id')} projection_view does not mirror consumer projection.view")
    if member.get("projection_class") != projection.get("projection_class"):
        errors.append(f"member {member.get('member_id')} projection_class does not mirror consumer projection_class")
    expected_forbidden = set(closure.get("forbidden_effects_preserved") or [])
    actual_forbidden = set(member.get("forbidden_effects_preserved") or [])
    if expected_forbidden != actual_forbidden:
        errors.append(f"member {member.get('member_id')} forbidden_effects_preserved does not mirror consumer receipt")
    expected_reasons = set(replay.get("downgrade_reasons") or [])
    actual_reasons = set(member.get("downgrade_reasons") or [])
    if expected_reasons != actual_reasons:
        errors.append(f"member {member.get('member_id')} downgrade_reasons do not mirror consumer receipt")


def projection_ok(receipt: dict[str, Any], members: list[dict[str, Any]], errors: list[str]) -> None:
    projection = receipt.get("projection") or {}
    view = projection.get("view")
    if view in PUBLIC_VIEWS:
        if projection.get("contains_sensitive_evidence") is True:
            errors.append("public/external batch receipt contains sensitive evidence")
        if projection.get("sealed_evidence_inline") is True:
            errors.append("public/external batch receipt inlines sealed evidence")
        for flag in SENSITIVE_FLAGS:
            if projection.get(flag) is True:
                errors.append(f"public/external batch receipt leaks {flag}")
        for member in members:
            if member.get("included_in_projection") and member.get("projection_view") in RESTRICTED_MEMBER_VIEWS:
                errors.append("public/external batch projection includes restricted member row")


def search_pagination_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    request = receipt.get("request") or {}
    pagination = receipt.get("search_pagination") or {}
    if request.get("kind") == "search_result":
        for field in ["result_count_basis", "returned_count", "partial_results_disclosed", "cursor_binds_query_digest", "projection_filter_digest"]:
            if field not in pagination:
                errors.append(f"search_pagination.{field} missing for search_result")
        omitted = (pagination.get("omitted_due_to_projection_count") or 0) + (pagination.get("omitted_due_to_replay_count") or 0)
        if omitted > 0 and pagination.get("partial_results_disclosed") is not True:
            errors.append("search result omits members without partial_results_disclosed=true")
        if pagination.get("next_cursor") and pagination.get("cursor_binds_query_digest") is not True:
            errors.append("search result next_cursor is not bound to query digest")
        if pagination.get("result_count_basis") == "raw_authority_count":
            errors.append("search result claims a raw authority count instead of a projection-safe count")
    if (receipt.get("aggregation") or {}).get("authority_count_claimed") is True:
        errors.append("batch/search receipt claims an aggregate authority count")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    require(receipt.get("schema") == "ward.governance-batch-search-receipt.v0", "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == "ward.governance.batch-search-receipt.v0", "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == "batch_search_receipt_only", "authority_surface must be batch_search_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))

    request = receipt.get("request") or {}
    require(request.get("kind") in {"batch_evaluation", "search_result"}, "request.kind invalid or missing", errors)
    for field in ["request_id", "operation", "query_digest"]:
        require(bool(request.get(field)), f"request.{field} missing", errors)

    members = receipt.get("members") or []
    require(isinstance(members, list) and bool(members), "members must be a non-empty list", errors)
    member_ids = [member.get("member_id") for member in members]
    if len(member_ids) != len(set(member_ids)):
        errors.append("members contain duplicate member_id values")

    consumer_receipts: list[dict[str, Any]] = []
    for member in members:
        consumer, _ = resolve_consumer(member, errors)
        if consumer:
            consumer_receipts.append(consumer)
            validate_member_mirror(member, consumer, errors)

    states = [m.get("state") for m in members if m.get("state")]
    replay_statuses = [m.get("replay_status") for m in members if m.get("replay_status")]
    aggregation = receipt.get("aggregation") or {}
    require(aggregation.get("result_state") in ALLOWED_RESULT_STATES, "aggregation.result_state invalid or missing", errors)
    if aggregation.get("member_count") != len(members):
        errors.append("aggregation.member_count does not match members length")
    if aggregation.get("state_counts") != count_map(states):
        errors.append("aggregation.state_counts does not match member states")
    if aggregation.get("replay_status_counts") != count_map(replay_statuses):
        errors.append("aggregation.replay_status_counts does not match member replay_status values")
    if aggregation.get("mixed_state_visible") is not True:
        errors.append("aggregation.mixed_state_visible must be true")
    if aggregation.get("no_single_badge") is not True:
        errors.append("aggregation.no_single_badge must be true")
    if aggregation.get("no_authority_upgrade") is not True:
        errors.append("aggregation.no_authority_upgrade must be true")
    summary_badge = str(aggregation.get("summary_badge") or "").lower()
    if any(token in summary_badge for token in ["all allowed", "green", "approved for all", "authority granted"]):
        errors.append("aggregation.summary_badge hides state with authority/green language")
    if len(set(states)) > 1 and aggregation.get("result_state") not in {"mixed_visible", "held_partial"}:
        errors.append("mixed member states require result_state=mixed_visible or held_partial")
    if states and set(states) == {"consequence_grade"} and set(replay_statuses) == {"replayed_current"}:
        if aggregation.get("result_state") != "all_current_consequence_grade":
            errors.append("all current consequence-grade batch must say all_current_consequence_grade")
    if states and set(states) == {"routing_hint_only"}:
        if aggregation.get("result_state") != "all_routing_hint_only":
            errors.append("all routing-hint batch must say all_routing_hint_only")

    reconciliation = receipt.get("reconciliation") or {}
    for field in ["states_preserved_per_member", "replay_status_preserved_per_member", "forbidden_effects_union_preserved", "downgrade_reasons_preserved", "member_effects_not_hidden"]:
        if reconciliation.get(field) is not True:
            errors.append(f"reconciliation.{field} must be true")
    if any(status != "replayed_current" for status in replay_statuses) and reconciliation.get("downgrade_reasons_preserved") is not True:
        errors.append("non-current members require downgrade_reasons_preserved=true")

    projection_join = receipt.get("projection_join") or {}
    if projection_join.get("mode") != "least_privilege_join":
        errors.append("projection_join.mode must be least_privilege_join")
    for field in ["classes_preserved", "weakest_class_visible", "sealed_members_redacted"]:
        if projection_join.get(field) is not True:
            errors.append(f"projection_join.{field} must be true")
    projection_classes = set(projection_join.get("projection_classes") or [])
    member_projection_classes = {m.get("projection_class") for m in members if m.get("projection_class")}
    if projection_classes != member_projection_classes:
        errors.append("projection_join.projection_classes does not equal member projection classes")

    effect_closure = receipt.get("effect_closure") or {}
    aggregate_effects = set(effect_closure.get("aggregate_effects_performed") or [])
    forbidden_union_actual = set().union(*(set(m.get("forbidden_effects_preserved") or []) for m in members)) if members else set()
    forbidden_union_declared = set(effect_closure.get("forbidden_effects_preserved_union") or [])
    if forbidden_union_declared != forbidden_union_actual:
        errors.append("effect_closure.forbidden_effects_preserved_union does not match member union")
    weak_or_noncurrent = any((state in WEAK_OR_NONCURRENT_STATES) or (status != "replayed_current") for state, status in zip(states, replay_statuses))
    if weak_or_noncurrent and (aggregate_effects & HIGH_CONSEQUENCE_EFFECTS):
        errors.append("weak/non-current batch member cannot support high-consequence aggregate effects")
    unsafe_aggregate = aggregate_effects - SAFE_BATCH_EFFECTS
    if unsafe_aggregate and not (set(states) == {"consequence_grade"} and set(replay_statuses) == {"replayed_current"}):
        errors.append("mixed or non-current batch performed effects outside the safe batch set: " + ", ".join(sorted(unsafe_aggregate)))
    if aggregate_effects & HIGH_CONSEQUENCE_EFFECTS:
        errors.append("aggregate effects must not contain high-consequence effects; keep them per-member")

    projection_ok(receipt, members, errors)
    search_pagination_ok(receipt, errors)

    replay_boundaries = receipt.get("replay_boundaries") or {}
    for field in ["all_member_digests_checked", "all_packet_refs_preserved"]:
        if replay_boundaries.get(field) is not True:
            errors.append(f"replay_boundaries.{field} must be true")
    if replay_boundaries.get("minimum_replay_status") not in set(replay_statuses):
        errors.append("replay_boundaries.minimum_replay_status must be one of the member replay statuses")
    actual_any_compacted = any((consumer.get("compaction_guard") or {}).get("event_compacted_away") is True for consumer in consumer_receipts)
    if replay_boundaries.get("any_compacted_away") != actual_any_compacted:
        errors.append("replay_boundaries.any_compacted_away does not match member compaction guards")
    if not replay_boundaries.get("watermark_basis"):
        errors.append("replay_boundaries.watermark_basis missing")
    return errors


def main() -> int:
    valid_paths = sorted(BATCH_DIR.glob("*.valid.json"))
    invalid_paths = sorted((BATCH_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance batch/search fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance batch/search fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance batch/search receipt check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance batch/search receipt check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
