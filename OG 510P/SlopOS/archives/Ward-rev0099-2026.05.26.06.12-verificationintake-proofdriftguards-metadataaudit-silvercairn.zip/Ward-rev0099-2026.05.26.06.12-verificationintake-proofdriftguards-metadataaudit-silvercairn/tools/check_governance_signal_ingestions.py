#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
SIGNAL_DIR = ROOT / "fixtures" / "governance-signal-ingestion"
SCHEMA = "ward.governance-signal-ingestion-receipt.v0"
RECEIPT_NAME = "ward.governance.signal-ingestion-receipt.v0"
AUTHORITY_SURFACE = "signal_ingestion_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}
VALID_STATES = {
    "signal_accepted_for_recertification",
    "duplicate_signal_ignored",
    "stale_signal_ignored",
    "conflicting_signals_held",
    "irrelevant_signal_ignored",
    "invalid_signal_rejected",
}
VALID_PAYLOAD_CLASSES = {
    "revocation",
    "refresh_required",
    "status_update",
    "projection_policy_change",
    "successor_change",
    "branch_update",
    "quarantine",
    "duplicate",
    "stale",
    "conflict",
    "irrelevant",
    "invalid",
}
VALID_CACHE_ACTIONS = {
    "invalidate_cache",
    "recheck_required",
    "sustain_quarantine",
    "current_refresh_signal",
    "no_action_duplicate",
    "hold_for_arbitration",
    "ignore_stale",
    "ignore_irrelevant",
    "reject_invalid",
}
SAFE_EFFECTS = {
    "record_signal_ingestion_receipt",
    "record_envelope_digest",
    "record_receiver_observation",
    "record_duplicate_observation",
    "record_high_watermark",
    "request_recertification",
    "publish_refresh_signal",
    "publish_cache_invalidation_signal",
    "hold_signal_conflict",
    "ignore_duplicate_signal",
    "ignore_stale_signal",
    "reject_invalid_signal",
    "update_signal_watermark",
    "notify_stale_consumers",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "budget_spend",
    "delegate",
    "export_raw_evidence",
    "grant_authority",
    "learning_use",
    "privacy_waiver",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "reuse_as_authority",
    "semantic_repair",
    "status_signal_as_action",
    "update_current_head_without_replay",
}
REQUIRED_FORBIDDEN = {
    "action_without_packet",
    "authority_reuse_without_packet",
    "budget_spend",
    "cache_as_authority",
    "cached_head_reuse_without_refresh",
    "conflicting_signal_auto_winner",
    "delegate_without_warrant",
    "duplicate_delivery_as_new_change",
    "event_log_as_grant",
    "export_without_receipt",
    "future_action",
    "learning_use",
    "poll_delivery_as_order_proof",
    "privacy_waiver_without_packet",
    "push_ack_as_consumer_refresh",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "resolution_as_authority",
    "reuse_without_refresh",
    "sealed_branch_disclosure",
    "signal_as_authority",
    "stale_signal_as_current",
    "status_channel_replay_as_authority",
    "status_pointer_as_grant",
    "status_signal_as_action",
    "unprojected_disclosure",
}


def load_checker(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load checker {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

recert_checker = load_checker(ROOT / "tools" / "check_governance_recertifications.py", "ward_recert_checker_for_signal_ingestion")


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stable_digest(obj: Any) -> str:
    payload = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def parse_time(value: str | None, field: str) -> datetime:
    if not value:
        raise ValueError(f"{field} missing")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} is not ISO-8601 parseable: {value}") from exc


def require(cond: bool, msg: str, errors: list[str]) -> None:
    if not cond:
        errors.append(msg)


def resolve_source_recertification(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    if ref.get("receipt_sha256_checked") is not True:
        errors.append("source_recertification_ref.receipt_sha256_checked must be true")
    rel = ref.get("receipt_path")
    if not rel:
        errors.append("source_recertification_ref.receipt_path missing")
        return None
    path = (ROOT / rel).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append(f"source recertification path escapes repository root: {rel}")
        return None
    if not path.exists():
        errors.append(f"source recertification path missing on disk: {rel}")
        return None
    actual_sha = sha256(path)
    if ref.get("receipt_sha256") != actual_sha:
        errors.append("source_recertification_ref.receipt_sha256 mismatch")
    obj = load_json(path)
    if obj.get("schema") != "ward.governance-recertification-receipt.v0":
        errors.append("source_recertification_ref must point at a governance-recertification receipt")
    if ref.get("receipt_id") != obj.get("receipt_id"):
        errors.append("source_recertification_ref.receipt_id does not match referenced receipt")
    source_errors = recert_checker.validate_receipt(obj, path)
    if source_errors:
        errors.append("referenced source recertification is invalid: " + "; ".join(source_errors))
    scope = obj.get("recertification_scope") or {}
    binding = obj.get("cache_binding") or {}
    posture = obj.get("cache_posture") or {}
    decision = obj.get("recertification_decision") or {}
    mirrors = {
        "source_recertification_state": decision.get("state"),
        "source_release_id": scope.get("source_release_id"),
        "recipient_class": scope.get("recipient_class"),
        "purpose": scope.get("purpose"),
        "source_item_digest": scope.get("source_item_digest"),
        "projection_policy_digest": scope.get("projection_policy_digest"),
        "cache_subject_digest": binding.get("cache_subject_digest"),
        "cached_resolution_id": binding.get("cached_resolution_id"),
        "cached_state": binding.get("cached_state"),
        "cache_state": posture.get("cache_state"),
        "cached_status_pointer": posture.get("cached_status_pointer"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_recertification_ref.{field} does not mirror source recertification")
    return obj


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be signal_ingestion_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def envelope_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    env = receipt.get("signal_envelope") or {}
    ref = receipt.get("source_recertification_ref") or {}
    for field in ["stream_id", "signal_source", "signal_id", "signal_type", "signal_schema_version", "delivery_mode", "delivery_channel"]:
        if not env.get(field):
            errors.append(f"signal_envelope.{field} missing")
    expected_key = f"{env.get('stream_id')}:{env.get('signal_source')}:{env.get('signal_id')}"
    if env.get("canonical_event_key") != expected_key:
        errors.append("signal_envelope.canonical_event_key must be stream_id:signal_source:signal_id")
    expected_pair = f"{env.get('signal_source')}#{env.get('signal_id')}"
    if env.get("source_id_pair") != expected_pair:
        errors.append("signal_envelope.source_id_pair must be signal_source#signal_id")
    if env.get("delivery_mode") not in {"push", "poll", "batch", "manual_review"}:
        errors.append("signal_envelope.delivery_mode invalid or missing")
    try:
        st = parse_time(env.get("signal_time"), "signal_envelope.signal_time")
        rt = parse_time(env.get("received_time"), "signal_envelope.received_time")
        if rt < st:
            errors.append("signal_envelope.received_time must not precede signal_time")
    except ValueError as exc:
        errors.append(str(exc))
    subject = env.get("subject")
    if not isinstance(subject, dict):
        errors.append("signal_envelope.subject missing or not object")
        subject = {}
    if env.get("subject_digest") != stable_digest(subject):
        errors.append("signal_envelope.subject_digest does not match subject")
    envelope_wo = env.get("envelope_without_digest")
    if not isinstance(envelope_wo, dict):
        errors.append("signal_envelope.envelope_without_digest missing or not object")
        envelope_wo = {}
    if env.get("envelope_digest") != stable_digest(envelope_wo):
        errors.append("signal_envelope.envelope_digest does not match envelope_without_digest")
    for field in ["source_release_id", "recipient_class", "purpose", "source_item_digest", "projection_policy_digest", "cache_subject_digest"]:
        if subject.get(field) != ref.get(field):
            errors.append(f"signal_envelope.subject.{field} must mirror source_recertification_ref")
    if subject.get("source_recertification_id") != ref.get("receipt_id"):
        errors.append("signal_envelope.subject.source_recertification_id must mirror source_recertification_ref.receipt_id")


def receiver_observation_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    obs = receipt.get("receiver_observation") or {}
    env = receipt.get("signal_envelope") or {}
    required_true = [
        "channel_bound",
        "stream_registered",
        "sender_authenticated",
        "signature_or_transport_checked",
        "envelope_digest_checked",
        "subject_digest_checked",
        "source_cache_subject_digest_checked",
        "duplicate_window_checked",
        "sequence_or_watermark_checked",
        "clock_skew_checked",
        "replay_window_checked",
        "projection_payload_checked",
        "receiver_policy_applied",
        "local_consequence_policy_applied",
    ]
    for field in required_true:
        if obs.get(field) is not True:
            errors.append(f"receiver_observation.{field} must be true")
    if obs.get("push_ack_treated_as_consumer_refresh") is not False:
        errors.append("receiver_observation.push_ack_treated_as_consumer_refresh must be false")
    if obs.get("poll_order_treated_as_causal_order") is not False:
        errors.append("receiver_observation.poll_order_treated_as_causal_order must be false")
    if obs.get("delivery_ack_treated_as_authority") is not False:
        errors.append("receiver_observation.delivery_ack_treated_as_authority must be false")
    if obs.get("observed_event_key") != env.get("canonical_event_key"):
        errors.append("receiver_observation.observed_event_key must match signal_envelope.canonical_event_key")
    try:
        parse_time(obs.get("observed_cut_time"), "receiver_observation.observed_cut_time")
    except ValueError as exc:
        errors.append(str(exc))


def arbitration_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    arb = receipt.get("arbitration_context") or {}
    env = receipt.get("signal_envelope") or {}
    decision = receipt.get("ingestion_decision") or {}
    classification = receipt.get("signal_payload_classification") or {}
    state = decision.get("state")
    seq = env.get("event_sequence")
    high = arb.get("known_high_watermark")
    if not isinstance(seq, int):
        errors.append("signal_envelope.event_sequence must be an integer")
        seq = None
    if not isinstance(high, int):
        errors.append("arbitration_context.known_high_watermark must be an integer")
        high = None
    prior = set(arb.get("prior_event_keys") or [])
    accepted = set(arb.get("accepted_event_keys") or [])
    conflicts = set(arb.get("conflicts_with_signal_ids") or [])
    if arb.get("correlation_scope") != "source-recertification-cache-subject":
        errors.append("arbitration_context.correlation_scope must be source-recertification-cache-subject")
    if arb.get("subject_digest") != env.get("subject_digest"):
        errors.append("arbitration_context.subject_digest must match signal envelope")
    if arb.get("source_recertification_id") != (receipt.get("source_recertification_ref") or {}).get("receipt_id"):
        errors.append("arbitration_context.source_recertification_id must mirror source ref")
    if state == "signal_accepted_for_recertification":
        if env.get("canonical_event_key") in prior:
            errors.append("accepted signal must not already be in prior_event_keys")
        if conflicts:
            errors.append("accepted signal must not have unresolved conflicts")
        if seq is not None and high is not None and seq <= high:
            errors.append("accepted signal event_sequence must advance known_high_watermark")
        if env.get("canonical_event_key") not in accepted:
            errors.append("accepted signal must be listed in accepted_event_keys")
    elif state == "duplicate_signal_ignored":
        if env.get("canonical_event_key") not in prior:
            errors.append("duplicate_signal_ignored requires canonical_event_key in prior_event_keys")
        if arb.get("duplicate_of") != env.get("canonical_event_key"):
            errors.append("duplicate_signal_ignored requires duplicate_of equal canonical_event_key")
        if classification.get("basis_changed") is not False:
            errors.append("duplicate_signal_ignored must not change basis")
    elif state == "stale_signal_ignored":
        if seq is not None and high is not None and seq > high:
            errors.append("stale_signal_ignored requires event_sequence at or below known_high_watermark")
        if classification.get("basis_changed") is not False:
            errors.append("stale_signal_ignored must not change basis")
    elif state == "conflicting_signals_held":
        if not conflicts:
            errors.append("conflicting_signals_held requires conflicts_with_signal_ids")
        if arb.get("winner_selected") is not False:
            errors.append("conflicting_signals_held must not select a winner")
    elif state == "irrelevant_signal_ignored":
        if classification.get("basis_changed") is not False:
            errors.append("irrelevant_signal_ignored must not change basis")
    elif state == "invalid_signal_rejected":
        if classification.get("payload_class") != "invalid":
            errors.append("invalid_signal_rejected requires payload_class invalid")


def classification_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    c = receipt.get("signal_payload_classification") or {}
    d = receipt.get("ingestion_decision") or {}
    state = d.get("state")
    payload_class = c.get("payload_class")
    action = c.get("cache_action_requested")
    if payload_class not in VALID_PAYLOAD_CLASSES:
        errors.append("signal_payload_classification.payload_class invalid or missing")
    if action not in VALID_CACHE_ACTIONS:
        errors.append("signal_payload_classification.cache_action_requested invalid or missing")
    if c.get("sealed_payload_inline") is not False:
        errors.append("signal_payload_classification.sealed_payload_inline must be false")
    if c.get("exact_hidden_counts_inline") is not False:
        errors.append("signal_payload_classification.exact_hidden_counts_inline must be false")
    if c.get("payload_digest_checked") is not True:
        errors.append("signal_payload_classification.payload_digest_checked must be true")
    if c.get("payload_schema_checked") is not True:
        errors.append("signal_payload_classification.payload_schema_checked must be true")
    if c.get("payload_subject_matches_envelope") is not True:
        errors.append("signal_payload_classification.payload_subject_matches_envelope must be true")
    if state == "signal_accepted_for_recertification":
        if c.get("basis_changed") is not True:
            errors.append("accepted signal requires basis_changed true")
        if action not in {"invalidate_cache", "recheck_required", "sustain_quarantine", "current_refresh_signal"}:
            errors.append("accepted signal requires a basis-changing cache action")
    if state == "duplicate_signal_ignored" and action != "no_action_duplicate":
        errors.append("duplicate_signal_ignored requires no_action_duplicate")
    if state == "stale_signal_ignored" and action != "ignore_stale":
        errors.append("stale_signal_ignored requires ignore_stale")
    if state == "conflicting_signals_held" and action != "hold_for_arbitration":
        errors.append("conflicting_signals_held requires hold_for_arbitration")
    if state == "irrelevant_signal_ignored" and action != "ignore_irrelevant":
        errors.append("irrelevant_signal_ignored requires ignore_irrelevant")
    if state == "invalid_signal_rejected" and action != "reject_invalid":
        errors.append("invalid_signal_rejected requires reject_invalid")


def followup_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    f = receipt.get("followup_binding") or {}
    state = (receipt.get("ingestion_decision") or {}).get("state")
    c = receipt.get("signal_payload_classification") or {}
    if f.get("source_recertification_mutated") is not False:
        errors.append("followup_binding.source_recertification_mutated must be false")
    if f.get("signal_can_grant_authority") is not False:
        errors.append("followup_binding.signal_can_grant_authority must be false")
    if f.get("source_packet_replay_before_consequence") is not True:
        errors.append("followup_binding.source_packet_replay_before_consequence must be true")
    if f.get("status_pointer_update_allowed") is not False:
        errors.append("followup_binding.status_pointer_update_allowed must be false")
    if state == "signal_accepted_for_recertification":
        if f.get("recertification_required") is not True:
            errors.append("accepted signal requires recertification_required")
        if not f.get("target_recertification_kind"):
            errors.append("accepted signal requires target_recertification_kind")
        if c.get("cache_action_requested") == "invalidate_cache" and f.get("can_drive_cache_invalidation") is not True:
            errors.append("invalidate_cache signal must be allowed to drive cache invalidation")
        if c.get("cache_action_requested") != "invalidate_cache" and f.get("can_drive_cache_invalidation") is True:
            errors.append("only invalidate_cache signals may drive cache invalidation")
    elif state in {"duplicate_signal_ignored", "stale_signal_ignored", "irrelevant_signal_ignored", "invalid_signal_rejected"}:
        if f.get("recertification_required") is not False:
            errors.append(f"{state} must not require recertification")
        if f.get("can_drive_cache_invalidation") is not False:
            errors.append(f"{state} must not drive cache invalidation")
    elif state == "conflicting_signals_held":
        if f.get("recertification_required") is not True:
            errors.append("conflicting_signals_held requires recertification/recheck")
        if f.get("can_drive_cache_invalidation") is not False:
            errors.append("conflicting_signals_held must not drive cache invalidation before resolution")
        if f.get("followup_receipt_required") is not True:
            errors.append("conflicting_signals_held requires followup receipt")


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_recertification_ref") or {}
    p = receipt.get("projection_safety") or {}
    public = ref.get("recipient_class") in PUBLIC_RECIPIENTS or p.get("projection_class") == "public_minimized"
    if p.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(p.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    for field in [
        "sealed_signal_payload_inline",
        "sealed_branch_evidence_inline",
        "reveals_private_org_map",
        "reveals_raw_partner_fragments",
        "reveals_reviewer_identities",
        "reveals_named_private_stewards",
        "reveals_conflict_details_public",
        "reveals_recipient_private_contact",
    ]:
        if p.get(field) is not False:
            errors.append(f"projection_safety.{field} must be false")
    if public:
        if p.get("no_exact_hidden_counts_public") is not True:
            errors.append("public signal-ingestion receipt must not reveal exact hidden counts")
        if p.get("bucketed_or_presence_only_disclosure") is not True:
            errors.append("public signal-ingestion receipt requires bucketed or presence-only disclosure")
        if p.get("status_or_signal_state_only") is not True:
            errors.append("public signal-ingestion receipt must expose only status/signal state")


def effects_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    effects = receipt.get("effect_closure") or {}
    performed = set(effects.get("effects_performed") or [])
    preserved = set(effects.get("forbidden_effects_preserved") or [])
    if effects.get("safe_signal_ingestion_effects_only") is not True:
        errors.append("effect_closure.safe_signal_ingestion_effects_only must be true")
    if effects.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if effects.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")
    extra = performed - SAFE_EFFECTS
    if extra:
        errors.append("effect_closure has non-signal-ingestion effects: " + ", ".join(sorted(extra)))
    high = performed & HIGH_CONSEQUENCE_EFFECTS
    if high:
        errors.append("effect_closure performs high consequence effects: " + ", ".join(sorted(high)))
    missing = REQUIRED_FORBIDDEN - preserved
    if missing:
        errors.append("effect_closure missing required forbidden effects: " + ", ".join(sorted(missing)))


def decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    d = receipt.get("ingestion_decision") or {}
    state = d.get("state")
    if state not in VALID_STATES:
        errors.append("ingestion_decision.state invalid or missing")
    if not d.get("reason_codes"):
        errors.append("ingestion_decision.reason_codes missing")
    if d.get("no_authority_granted") is not True:
        errors.append("ingestion_decision.no_authority_granted must be true")
    if d.get("source_recertification_mutated") is not False:
        errors.append("ingestion_decision.source_recertification_mutated must be false")
    if d.get("receiver_ack_as_authority") is not False:
        errors.append("ingestion_decision.receiver_ack_as_authority must be false")
    expected = {
        "signal_accepted_for_recertification": "recheck_required",
        "duplicate_signal_ignored": "unchanged_duplicate",
        "stale_signal_ignored": "unchanged_stale",
        "conflicting_signals_held": "held_due_to_conflict",
        "irrelevant_signal_ignored": "unchanged_irrelevant",
        "invalid_signal_rejected": "rejected",
    }
    if state in expected and d.get("cache_reuse_state") != expected[state]:
        errors.append(f"{state} requires cache_reuse_state {expected[state]}")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    source = resolve_source_recertification(receipt.get("source_recertification_ref") or {}, errors)
    envelope_ok(receipt, source, errors)
    receiver_observation_ok(receipt, errors)
    arbitration_ok(receipt, errors)
    classification_ok(receipt, errors)
    followup_ok(receipt, errors)
    projection_ok(receipt, errors)
    effects_ok(receipt, errors)
    decision_ok(receipt, errors)
    return errors


def main() -> int:
    valid_paths = sorted(SIGNAL_DIR.glob("*.valid.json"))
    invalid_paths = sorted((SIGNAL_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance signal-ingestion fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance signal-ingestion fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance signal-ingestion check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance signal-ingestion check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
