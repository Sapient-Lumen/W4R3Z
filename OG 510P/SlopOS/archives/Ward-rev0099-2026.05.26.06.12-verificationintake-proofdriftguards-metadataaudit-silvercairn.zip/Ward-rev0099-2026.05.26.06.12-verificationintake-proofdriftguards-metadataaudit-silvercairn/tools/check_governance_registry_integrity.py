#!/usr/bin/env python3
from __future__ import annotations

import sys
from collections import Counter
from pathlib import Path
from typing import Any

from governance_common import ROOT, fixture_counts, governance_checker_scripts, load_json, load_registry


def validate_registry(registry: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    receipt = load_json(ROOT / "REVISION-RECEIPT.json")
    if registry.get("registry_name") != "ward.governance.checker-registry.v0":
        errors.append("registry_name must be ward.governance.checker-registry.v0")
    if registry.get("revision") != receipt.get("revision"):
        errors.append("registry revision must match REVISION-RECEIPT revision")
    entries = registry.get("entries") or []
    if not isinstance(entries, list) or not entries:
        errors.append("registry entries must be a non-empty list")
        return errors
    ids = [e.get("id") for e in entries]
    scripts = [e.get("script") for e in entries]
    for field, values in [("id", ids), ("script", scripts)]:
        for value, count in Counter(values).items():
            if not value or count > 1:
                errors.append(f"registry {field} missing or duplicate: {value}")
    registry_scripts = {s for s in scripts if s}
    expected_scripts = set(governance_checker_scripts())
    missing = sorted(expected_scripts - registry_scripts)
    if missing:
        errors.append("governance checker scripts missing from registry: " + ", ".join(missing))
    extra = sorted(registry_scripts - expected_scripts - {"check_governance_registry_integrity.py"})
    if extra:
        errors.append("registry points at unexpected governance scripts: " + ", ".join(extra))
    for entry in entries:
        checker_id = entry.get("id")
        script = entry.get("script")
        receipt_label = entry.get("receipt")
        script_path = ROOT / "tools" / str(script)
        if not script or not script_path.exists():
            errors.append(f"{checker_id}: script missing on disk: {script}")
        if not receipt_label:
            errors.append(f"{checker_id}: receipt label missing")
        fixture_dir = entry.get("fixture_dir")
        if script == "check_governance_registry_integrity.py":
            if fixture_dir:
                errors.append("registry-integrity entry must not claim a fixture_dir")
            if entry.get("schema_path") or entry.get("schema_id"):
                errors.append("registry-integrity entry must not claim schema_path/schema_id")
            continue
        if not fixture_dir:
            errors.append(f"{checker_id}: fixture_dir missing")
            continue
        schema_path = entry.get("schema_path")
        schema_id = entry.get("schema_id")
        if not schema_path or not schema_id:
            errors.append(f"{checker_id}: schema_path and schema_id required for fixture-backed validators")
        else:
            schema_file = ROOT / str(schema_path)
            if not schema_file.exists():
                errors.append(f"{checker_id}: schema_path missing on disk: {schema_path}")
            else:
                try:
                    schema = load_json(schema_file)
                    schema_dollar_id = schema.get("$id")
                    if schema_dollar_id is not None and schema_dollar_id != schema_id and not str(schema_dollar_id).endswith(Path(str(schema_path)).name):
                        errors.append(f"{checker_id}: schema $id does not match registry schema_id or schema filename")
                    schema_const = (((schema.get("properties") or {}).get("schema") or {}).get("const"))
                    if schema_const != schema_id:
                        errors.append(f"{checker_id}: schema properties.schema.const does not match registry schema_id")
                except Exception as exc:
                    errors.append(f"{checker_id}: schema could not be read: {exc}")
        fixture_path = ROOT / fixture_dir
        if not fixture_path.exists():
            errors.append(f"{checker_id}: fixture_dir missing on disk: {fixture_dir}")
            continue
        valid, negative = fixture_counts(fixture_path)
        if valid < 1 or negative < 1:
            errors.append(f"{checker_id}: fixture_dir must contain positive and negative fixtures")
        if not (fixture_path / "negative").exists():
            errors.append(f"{checker_id}: fixture_dir missing negative/ directory")
    fixture_dirs = {
        str(p.relative_to(ROOT))
        for p in (ROOT / "fixtures").glob("governance-*")
        if p.is_dir()
    }
    registry_fixture_dirs = {e.get("fixture_dir") for e in entries if e.get("fixture_dir")}
    unregistered_dirs = sorted(fixture_dirs - registry_fixture_dirs)
    if unregistered_dirs:
        errors.append("governance fixture dirs missing from registry: " + ", ".join(unregistered_dirs))
    return errors


def main() -> int:
    errors = validate_registry(load_registry())
    if errors:
        print("Governance registry integrity check failed.")
        for err in errors:
            print(" -", err)
        return 1
    entries = load_registry().get("entries") or []
    fixture_entries = [e for e in entries if e.get("fixture_dir")]
    print(f"Governance registry integrity check passed ({len(entries)} entries, {len(fixture_entries)} fixture-backed validators, schema ids audited).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
