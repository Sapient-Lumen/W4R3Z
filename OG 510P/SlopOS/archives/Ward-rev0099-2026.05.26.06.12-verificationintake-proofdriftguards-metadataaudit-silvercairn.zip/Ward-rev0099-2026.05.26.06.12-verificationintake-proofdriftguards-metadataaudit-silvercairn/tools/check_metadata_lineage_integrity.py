#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEDGERS = [
    "QUESTION-REGISTRY.json",
    "ASSUMPTION-LEDGER.json",
    "FOREIGN-PRESSURE-LEDGER.json",
    "FOLLOWTHROUGH-QUEUE.json",
    "IRREVERSIBLE-DECISION-LEDGER.json",
    "context-pack.json",
]


def load_json(rel: str):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def main() -> int:
    errors: list[str] = []
    receipt = load_json("REVISION-RECEIPT.json")
    status = load_json("SURFACE-STATUS.json")
    manifest = load_json("RELEASE-MANIFEST.json")
    revision = receipt.get("revision")
    summary = receipt.get("summary")
    codename = receipt.get("codename")
    for rel in LEDGERS:
        obj = load_json(rel)
        if obj.get("revision") != revision:
            errors.append(f"{rel} revision must match REVISION-RECEIPT")
    if status.get("revision") != revision:
        errors.append("SURFACE-STATUS revision must match REVISION-RECEIPT")
    if status.get("latest_focus") != summary:
        errors.append("SURFACE-STATUS latest_focus must match REVISION-RECEIPT summary")
    if manifest.get("revision") != revision or manifest.get("codename") != codename:
        errors.append("RELEASE-MANIFEST identity must match REVISION-RECEIPT")
    if manifest.get("highlights") != summary:
        errors.append("RELEASE-MANIFEST highlights must match REVISION-RECEIPT summary")
    latest_surfaces = status.get("latest_surfaces") or {}
    latest_docs = {p for p in receipt.get("hygiene_additions", []) if isinstance(p, str) and p.endswith(".md")}
    for rel in latest_docs:
        if not (ROOT / rel).exists():
            errors.append(f"latest hygiene doc missing on disk: {rel}")
    for key in ["research_synthesis", "slopos_evaluation", "specimen"]:
        rel = latest_surfaces.get(key)
        if not rel:
            errors.append(f"SURFACE-STATUS latest_surfaces missing {key}")
        elif rel not in latest_docs:
            errors.append(f"SURFACE-STATUS {key} must be listed in REVISION-RECEIPT hygiene_additions")
    context = load_json("context-pack.json")
    required_refs = set(receipt.get("outside_sources") or [])
    context_refs = set(context.get("load_bearing_sources") or [])
    missing_context_refs = sorted(required_refs - context_refs)
    if missing_context_refs:
        errors.append("context-pack missing latest outside sources: " + ", ".join(missing_context_refs[:10]))
    context_docs = set(context.get("latest_docs") or [])
    if latest_docs and not latest_docs.issubset(context_docs):
        errors.append("context-pack latest_docs missing latest revision docs")
    # IDs should remain unique and slug-like in living ledgers.
    for rel, key in [("QUESTION-REGISTRY.json", "questions"), ("FOLLOWTHROUGH-QUEUE.json", "items"), ("ASSUMPTION-LEDGER.json", "assumptions"), ("FOREIGN-PRESSURE-LEDGER.json", "entries"), ("IRREVERSIBLE-DECISION-LEDGER.json", "decisions")]:
        obj = load_json(rel)
        ids = [item.get("id") for item in obj.get(key, [])]
        dupes = sorted({i for i in ids if i and ids.count(i) > 1})
        if dupes:
            errors.append(f"{rel} duplicate ids: " + ", ".join(dupes))
        if any(not i for i in ids):
            errors.append(f"{rel} contains rows without id")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    start = (ROOT / "START_HERE.md").read_text(encoding="utf-8")
    if revision not in readme or revision not in start:
        errors.append("README.md and START_HERE.md must mention current revision")
    if summary not in readme or summary not in start:
        errors.append("README.md and START_HERE.md must mention current revision summary")
    if errors:
        print("Metadata lineage integrity check failed.")
        for err in errors:
            print(" -", err)
        return 1
    print(f"Metadata lineage integrity check passed for {revision} ({len(LEDGERS)} ledgers plus context checked).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
