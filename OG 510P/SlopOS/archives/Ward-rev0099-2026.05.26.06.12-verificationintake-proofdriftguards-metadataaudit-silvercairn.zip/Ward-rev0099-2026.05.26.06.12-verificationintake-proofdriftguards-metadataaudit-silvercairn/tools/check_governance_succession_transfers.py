#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
TRANSFER_DIR = ROOT / "fixtures" / "governance-succession-transfer"

PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}
TRANSFER_KINDS = {
    "recipient_contact_transfer",
    "status_channel_rotation",
    "steward_successor_record",
    "projection_policy_steward_transfer",
    "custody_operator_transfer",
    "emergency_successor_hold",
}
ACCEPTANCE_STATES = {"accepted", "pending", "refused", "held_recheck", "dual_control_pending"}
TRANSFER_STATES = {
    "transfer_recorded",
    "rotation_recorded",
    "successor_pending_recheck",
    "transfer_refused",
    "transfer_quarantined",
    "transfer_held_review",
}
KIND_TO_STATES = {
    "recipient_contact_transfer": {"transfer_recorded", "successor_pending_recheck", "transfer_refused"},
    "status_channel_rotation": {"rotation_recorded", "transfer_quarantined", "transfer_held_review"},
    "steward_successor_record": {"transfer_recorded", "successor_pending_recheck", "transfer_refused"},
    "projection_policy_steward_transfer": {"transfer_recorded", "successor_pending_recheck", "transfer_quarantined"},
    "custody_operator_transfer": {"transfer_recorded", "successor_pending_recheck", "transfer_held_review"},
    "emergency_successor_hold": {"successor_pending_recheck", "transfer_held_review", "transfer_quarantined"},
}
ACCEPTANCE_TO_ALLOWED_STATES = {
    "accepted": {"transfer_recorded", "rotation_recorded"},
    "pending": {"successor_pending_recheck", "transfer_held_review"},
    "dual_control_pending": {"successor_pending_recheck", "transfer_held_review"},
    "held_recheck": {"successor_pending_recheck", "transfer_held_review", "transfer_quarantined"},
    "refused": {"transfer_refused", "transfer_quarantined"},
}
SAFE_TRANSFER_EFFECTS = {
    "record_successor_binding",
    "record_pending_successor",
    "rotate_status_channel",
    "invalidate_old_status_channel",
    "notify_predecessor",
    "notify_successor",
    "notify_recipient",
    "publish_status_pointer_update",
    "request_recheck",
    "hold_release_reuse",
    "retain_minimized_transfer_receipt",
    "quarantine_stale_bundle",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "approve_dashboard_export",
    "raw_partner_fragment_export",
    "raw_partner_fragment_access",
    "publish_raw_partner_fragments",
    "waive_privacy",
    "action_reenable",
    "remedy",
    "semantic_repair",
    "budget_spend",
    "delegate",
    "approve",
    "learning_use",
    "reuse_as_authority",
    "grant_authority",
    "change_metric_semantics",
}
REQUIRED_FORBIDDEN = {
    "ack_as_authority",
    "action_reenable",
    "action_without_packet",
    "authority_reuse_without_packet",
    "broader_scope",
    "budget_spend",
    "delegate_without_warrant",
    "export",
    "export_without_packet",
    "future_action",
    "learning_use",
    "old_channel_reuse",
    "privacy_waiver_without_packet",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy",
    "remedy_without_packet",
    "repair",
    "reuse_without_refresh",
    "stale_bundle_reuse",
    "successor_as_authority",
    "unprojected_disclosure",
}


def load_checker(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load checker {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

release_checker = load_checker(ROOT / "tools" / "check_governance_evidence_release_receipts.py", "ward_release_checker_for_transfer")
followup_checker = load_checker(ROOT / "tools" / "check_governance_evidence_release_followups.py", "ward_followup_checker_for_transfer")


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_time(value: str | None, field: str) -> datetime:
    if not value:
        raise ValueError(f"{field} missing")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} is not ISO-8601 parseable: {value}") from exc


def require(cond: bool, msg: str, errors: list[str]) -> None:
    if not cond:
        errors.append(msg)


def resolve_ref(ref: dict[str, Any], errors: list[str], checker: Any, label: str) -> tuple[dict[str, Any] | None, Path | None]:
    if not isinstance(ref, dict):
        errors.append(f"{label} must be an object")
        return None, None
    path_value = ref.get("receipt_path")
    if not path_value:
        errors.append(f"{label}.receipt_path missing")
        return None, None
    path = (ROOT / path_value).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append(f"{label}.receipt_path escapes repository root")
        return None, None
    if not path.exists():
        errors.append(f"{label}.receipt_path missing on disk: {path_value}")
        return None, None
    actual = sha256(path)
    if ref.get("receipt_sha256") != actual:
        errors.append(f"{label}.receipt_sha256 does not match referenced receipt bytes")
    obj = load_json(path)
    if ref.get("receipt_id") != obj.get("receipt_id"):
        errors.append(f"{label}.receipt_id does not match referenced receipt")
    ref_errors = checker.validate_receipt(obj, path)
    if ref_errors:
        errors.append(f"referenced {label} is invalid: " + "; ".join(ref_errors))
    return obj, path


def source_chain_ok(receipt: dict[str, Any], errors: list[str]) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    chain = receipt.get("source_chain_ref") or {}
    release, _ = resolve_ref(chain.get("source_release_receipt_ref"), errors, release_checker, "source_chain_ref.source_release_receipt_ref")
    latest = None
    if chain.get("latest_followup_receipt_ref"):
        latest, _ = resolve_ref(chain.get("latest_followup_receipt_ref"), errors, followup_checker, "source_chain_ref.latest_followup_receipt_ref")
        if release and latest:
            latest_release_state = latest.get("source_release_state") or {}
            if latest_release_state.get("source_release_id") != release.get("receipt_id"):
                errors.append("latest_followup_receipt_ref does not point at the same source release")
            try:
                if parse_time(latest.get("receipt_time"), "latest followup receipt_time") < parse_time(release.get("receipt_time"), "source release receipt_time"):
                    errors.append("latest follow-up predates source release")
            except ValueError as exc:
                errors.append(str(exc))
    if chain.get("chain_digest") is None:
        errors.append("source_chain_ref.chain_digest missing")
    if chain.get("source_chain_checked") is not True:
        errors.append("source_chain_ref.source_chain_checked must be true")
    return release, latest


def request_ok(receipt: dict[str, Any], release: dict[str, Any] | None, errors: list[str]) -> str | None:
    req = receipt.get("transfer_request") or {}
    kind = req.get("transfer_kind")
    require(kind in TRANSFER_KINDS, "transfer_request.transfer_kind invalid or missing", errors)
    for field in ["request_id", "requester", "recipient_class", "purpose", "transfer_reason", "requested_at", "effective_at", "review_by"]:
        require(bool(req.get(field)), f"transfer_request.{field} missing", errors)
    try:
        requested = parse_time(req.get("requested_at"), "transfer_request.requested_at")
        effective = parse_time(req.get("effective_at"), "transfer_request.effective_at")
        parse_time(req.get("review_by"), "transfer_request.review_by")
        if effective < requested:
            errors.append("transfer_request.effective_at predates requested_at")
    except ValueError as exc:
        errors.append(str(exc))
    if release:
        rel_req = release.get("release_request") or {}
        if req.get("recipient_class") != rel_req.get("recipient_class"):
            errors.append("transfer_request.recipient_class does not match source release")
        if req.get("purpose") != rel_req.get("purpose"):
            errors.append("transfer_request.purpose does not match source release purpose")
    if req.get("transfer_scope") not in {"release_status_contact", "stewardship_record", "projection_policy_custody", "custody_operator", "status_channel"}:
        errors.append("transfer_request.transfer_scope invalid or missing")
    return kind


def predecessor_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    pred = receipt.get("predecessor_binding") or {}
    for field in ["predecessor_id", "predecessor_role", "active_before", "ended_at", "termination_reason", "notification_channel"]:
        require(pred.get(field) not in (None, ""), f"predecessor_binding.{field} missing", errors)
    if pred.get("active_before") is not True:
        errors.append("predecessor_binding.active_before must be true")
    if pred.get("no_continuing_authority") is not True:
        errors.append("predecessor_binding.no_continuing_authority must be true")
    if pred.get("predecessor_notified") is not True:
        errors.append("predecessor_binding.predecessor_notified must be true")
    try:
        parse_time(pred.get("ended_at"), "predecessor_binding.ended_at")
    except ValueError as exc:
        errors.append(str(exc))


def successor_ok(receipt: dict[str, Any], kind: str | None, errors: list[str]) -> str | None:
    succ = receipt.get("successor_binding") or {}
    state = succ.get("acceptance_state")
    require(state in ACCEPTANCE_STATES, "successor_binding.acceptance_state invalid or missing", errors)
    for field in ["successor_id", "successor_role", "proof_digest"]:
        require(bool(succ.get(field)), f"successor_binding.{field} missing", errors)
    for field in ["recipient_bound", "purpose_bound", "scope_matches_predecessor", "no_scope_expansion", "no_authority_upgrade", "no_redelegation_without_warrant"]:
        if succ.get(field) is not True:
            errors.append(f"successor_binding.{field} must be true")
    if state == "accepted" and not succ.get("acceptance_time"):
        errors.append("accepted successor requires successor_binding.acceptance_time")
    if state == "accepted":
        try:
            parse_time(succ.get("acceptance_time"), "successor_binding.acceptance_time")
        except ValueError as exc:
            errors.append(str(exc))
    if state in {"pending", "dual_control_pending", "held_recheck", "refused"} and succ.get("reuse_allowed_before_acceptance") is True:
        errors.append("successor_binding allows reuse before successor acceptance")
    if kind == "emergency_successor_hold" and state == "accepted":
        errors.append("emergency_successor_hold must remain pending/held/quarantined until ordinary proof is rechecked")
    return state


def continuity_ok(receipt: dict[str, Any], release: dict[str, Any] | None, latest: dict[str, Any] | None, kind: str | None, errors: list[str]) -> None:
    cont = receipt.get("continuity_checks") or {}
    for field in ["release_receipt_sha256_checked", "source_state_mirrored", "status_pointer_chain_checked", "no_stale_artifact_reuse", "no_authority_upgrade"]:
        if cont.get(field) is not True:
            errors.append(f"continuity_checks.{field} must be true")
    if latest and cont.get("latest_followup_checked") is not True:
        errors.append("continuity_checks.latest_followup_checked must be true when a latest follow-up is referenced")
    if release:
        rel_req = release.get("release_request") or {}
        rel_manifest = release.get("payload_manifest") or {}
        mirrors = {
            "source_release_id": release.get("receipt_id"),
            "release_recipient_class": rel_req.get("recipient_class"),
            "release_purpose": rel_req.get("purpose"),
            "source_item_digest": rel_manifest.get("item_digest"),
            "projection_policy_digest": rel_req.get("projection_policy_digest"),
        }
        for field, expected in mirrors.items():
            if cont.get(field) != expected:
                errors.append(f"continuity_checks.{field} does not mirror source release")
    if latest:
        if cont.get("latest_followup_id") != latest.get("receipt_id"):
            errors.append("continuity_checks.latest_followup_id does not mirror referenced follow-up")
        latest_state = (latest.get("followup_decision") or {}).get("state")
        if cont.get("latest_followup_state") != latest_state:
            errors.append("continuity_checks.latest_followup_state does not mirror referenced follow-up")
    if kind == "status_channel_rotation":
        if cont.get("status_pointer_rotation_required") is not True:
            errors.append("status_channel_rotation requires continuity_checks.status_pointer_rotation_required=true")
        if cont.get("old_status_channel_invalidated") is not True:
            errors.append("status_channel_rotation requires old_status_channel_invalidated=true")
        if not cont.get("new_status_pointer"):
            errors.append("status_channel_rotation requires continuity_checks.new_status_pointer")
        if cont.get("old_status_channel") and cont.get("new_status_pointer") == cont.get("old_status_channel"):
            errors.append("new_status_pointer must differ from old_status_channel")
    if cont.get("old_status_channel_invalidated") is False and cont.get("status_pointer_rotation_required") is True:
        errors.append("status pointer rotation cannot leave the old channel active")


def projection_ok(receipt: dict[str, Any], release: dict[str, Any] | None, errors: list[str]) -> None:
    proj = receipt.get("projection_safety") or {}
    for field in ["projection_class_preserved", "no_sensitive_evidence_released", "no_raw_partner_fragments", "no_private_org_map", "no_exact_hidden_counts_public", "no_authority_label_present"]:
        if proj.get(field) is not True:
            errors.append(f"projection_safety.{field} must be true")
    label = str(proj.get("watermark_label") or "").lower()
    if "not authority" not in label and "no authority" not in label:
        errors.append("projection_safety.watermark_label must visibly say the transfer receipt is not authority")
    recipient = (release.get("release_request") or {}).get("recipient_class") if release else None
    if recipient in PUBLIC_RECIPIENTS:
        if proj.get("public_successor_identity_mode") not in {"role_only", "opaque_contact", "status_pointer_only"}:
            errors.append("public transfer must not expose named successor identity")
        if proj.get("private_steward_identity_released") is True:
            errors.append("public transfer leaks private steward identity")


def effects_ok(receipt: dict[str, Any], release: dict[str, Any] | None, latest: dict[str, Any] | None, errors: list[str]) -> None:
    closure = receipt.get("effect_closure") or {}
    effects = set(closure.get("effects_performed") or [])
    if closure.get("safe_transfer_effects_only") is not True:
        errors.append("effect_closure.safe_transfer_effects_only must be true")
    if closure.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if closure.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")
    high = effects & HIGH_CONSEQUENCE_EFFECTS
    if high:
        errors.append("succession transfer performs high-consequence effects: " + ", ".join(sorted(high)))
    unsafe = effects - SAFE_TRANSFER_EFFECTS
    if unsafe:
        errors.append("succession transfer performs unsupported effects: " + ", ".join(sorted(unsafe)))
    preserved = set(closure.get("forbidden_effects_preserved") or [])
    missing_required = REQUIRED_FORBIDDEN - preserved
    if missing_required:
        errors.append("effect_closure omits required forbidden effects: " + ", ".join(sorted(missing_required)))
    if release:
        source_forbidden = set(((release.get("effect_closure") or {}).get("forbidden_effects_preserved") or []))
        missing = source_forbidden - preserved
        if missing:
            errors.append("effect_closure drops source release forbidden effects: " + ", ".join(sorted(missing)))
    if latest:
        source_forbidden = set(((latest.get("effect_closure") or {}).get("forbidden_effects_preserved") or []))
        missing = source_forbidden - preserved
        if missing:
            errors.append("effect_closure drops latest follow-up forbidden effects: " + ", ".join(sorted(missing)))


def decision_ok(receipt: dict[str, Any], kind: str | None, acceptance: str | None, errors: list[str]) -> None:
    decision = receipt.get("transfer_decision") or {}
    state = decision.get("state")
    if state not in TRANSFER_STATES:
        errors.append("transfer_decision.state invalid or missing")
    if kind and state not in KIND_TO_STATES.get(kind, set()):
        errors.append(f"transfer_decision.state {state} is inconsistent with {kind}")
    if acceptance and state not in ACCEPTANCE_TO_ALLOWED_STATES.get(acceptance, set()):
        errors.append(f"transfer_decision.state {state} is inconsistent with successor acceptance state {acceptance}")
    if not decision.get("reason_codes"):
        errors.append("transfer_decision.reason_codes missing")
    if decision.get("no_authority_granted") is not True:
        errors.append("transfer_decision.no_authority_granted must be true")
    if decision.get("release_reuse_state") not in {"refresh_required", "status_only", "held_until_acceptance", "quarantined", "refused"}:
        errors.append("transfer_decision.release_reuse_state invalid or missing")
    if acceptance in {"pending", "dual_control_pending", "held_recheck"} and decision.get("release_reuse_state") not in {"held_until_acceptance", "refresh_required", "quarantined"}:
        errors.append("pending successor cannot allow current release reuse")
    if state in {"transfer_recorded", "rotation_recorded"} and decision.get("status_pointer_visible") is not True:
        errors.append("recorded transfer/rotation requires visible status pointer")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    require(receipt.get("schema") == "ward.governance-succession-transfer-receipt.v0", "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == "ward.governance.succession-transfer-receipt.v0", "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == "succession_transfer_receipt_only", "authority_surface must be succession_transfer_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))
    release, latest = source_chain_ok(receipt, errors)
    kind = request_ok(receipt, release, errors)
    predecessor_ok(receipt, errors)
    acceptance = successor_ok(receipt, kind, errors)
    continuity_ok(receipt, release, latest, kind, errors)
    projection_ok(receipt, release, errors)
    effects_ok(receipt, release, latest, errors)
    decision_ok(receipt, kind, acceptance, errors)
    return errors


def main() -> int:
    valid_paths = sorted(TRANSFER_DIR.glob("*.valid.json"))
    invalid_paths = sorted((TRANSFER_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance succession-transfer fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance succession-transfer fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance succession-transfer check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance succession-transfer check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
