#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Any
import sys

from governance_common import (
    ROOT,
    load_json,
    parse_time,
    require,
    run_fixture_checker,
    stable_digest,
    validate_ref,
)

CONVERGENCE_DIR = ROOT / "fixtures" / "governance-receiver-convergence"
SCHEMA = "ward.governance-receiver-convergence-receipt.v0"
RECEIPT_NAME = "ward.governance.receiver-convergence-receipt.v0"
AUTHORITY_SURFACE = "receiver_convergence_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}

VALID_STATES = {
    "all_receivers_converged_refresh_required",
    "partial_receiver_lag_quarantined",
    "divergent_status_channel_cut_held",
    "duplicate_receiver_observation_suppressed",
    "receiver_fork_quarantined",
    "invalid_convergence_rejected",
}
VALID_OBSERVATION_STATES = {
    "receiver_reconciled",
    "receiver_lag_quarantined",
    "divergent_cut_held",
    "duplicate_observation_suppressed",
    "receiver_fork_quarantined",
    "not_required_noop",
    "invalid_rejected",
}
SAFE_EFFECTS = {
    "record_receiver_convergence_receipt",
    "record_receiver_reconciliation_ref",
    "record_receiver_set_digest",
    "record_overlap_digest",
    "record_convergence_gap",
    "quarantine_lagging_receivers",
    "suppress_duplicate_receiver_observation",
    "hold_divergent_cut_for_review",
    "hold_receiver_fork_for_review",
    "request_receiver_reconciliation",
    "publish_convergence_status",
    "notify_receiver_owner",
    "mark_convergence_noop",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "budget_spend",
    "delegate",
    "export_raw_evidence",
    "force_consumer_action",
    "grant_authority",
    "learning_use",
    "merge_divergent_status_channels",
    "privacy_waiver",
    "promote_global_current_head",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "reuse_as_authority",
    "semantic_repair",
    "status_signal_as_action",
    "treat_ack_as_refresh",
    "update_current_head_without_replay",
    "update_global_status_pointer",
    "update_status_pointer",
}
REQUIRED_FORBIDDEN = {
    "acknowledgment_as_authority",
    "acknowledgment_as_refresh",
    "action_without_packet",
    "authority_reuse_without_packet",
    "budget_spend",
    "cache_as_authority",
    "cached_head_reuse_without_refresh",
    "consumer_reconciliation_as_authority",
    "dead_letter_as_delivery",
    "delegate_without_warrant",
    "delivery_ack_as_consumer_refresh",
    "divergent_cut_as_current",
    "duplicate_delivery_as_new_change",
    "event_log_as_grant",
    "export_without_receipt",
    "future_action",
    "global_status_pointer_update",
    "learning_use",
    "missing_receiver_hidden",
    "notification_as_recertification",
    "partial_receiver_convergence_as_complete",
    "poll_delivery_as_order_proof",
    "privacy_waiver_without_packet",
    "push_ack_as_consumer_refresh",
    "receiver_convergence_as_authority",
    "receiver_convergence_as_recertification",
    "receiver_fork_as_current",
    "receiver_quorum_as_authority",
    "receiver_reconciliation_ref_mismatch",
    "receiver_set_scope_expansion",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "resolution_as_authority",
    "reuse_without_refresh",
    "sealed_branch_disclosure",
    "signal_as_authority",
    "stale_receiver_reuse",
    "stale_signal_as_current",
    "status_channel_cut_upgrade",
    "status_channel_replay_as_authority",
    "status_pointer_as_grant",
    "status_signal_as_action",
    "unprojected_disclosure",
}


def receiver_set_material(observations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "receiver_id_hash": obs.get("receiver_id_hash"),
            "receiver_class": obs.get("receiver_class"),
            "status_channel_id_hash": obs.get("status_channel_id_hash"),
            "required": obs.get("required"),
        }
        for obs in observations
    ]


def resolve_source_reconciliation(ref: dict[str, Any], idx: int, errors: list[str]) -> dict[str, Any] | None:
    source = validate_ref(
        ref,
        label=f"source_reconciliation_refs[{idx}]",
        expected_schema="ward.governance-signal-notification-reconciliation-receipt.v0",
        checker_script=None,
        checker_module_name=f"ward_signal_notification_reconciliation_checker_for_receiver_convergence_{idx}",
        errors=errors,
    )
    if not source:
        return None
    scope = source.get("reconciliation_scope") or {}
    decision = source.get("reconciliation_decision") or {}
    summary = source.get("reconciliation_summary") or {}
    mirrors = {
        "reconciliation_state": decision.get("state"),
        "cache_reuse_state": decision.get("cache_reuse_state"),
        "recipient_class": scope.get("recipient_class"),
        "purpose": scope.get("purpose"),
        "source_release_id": scope.get("source_release_id"),
        "source_signal_event_key": scope.get("source_signal_event_key"),
        "source_signal_subject_digest": scope.get("source_signal_subject_digest"),
        "cache_subject_digest": scope.get("cache_subject_digest"),
        "affected_consumer_set_digest": scope.get("affected_consumer_set_digest"),
        "expected_consumer_count": scope.get("expected_consumer_count"),
        "stale_consumers_remaining": summary.get("stale_consumers_remaining"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_reconciliation_refs[{idx}].{field} does not mirror referenced reconciliation receipt")
    if decision.get("no_authority_granted") is not True:
        errors.append(f"source_reconciliation_refs[{idx}] referenced reconciliation must grant no authority")
    return source


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be receiver_convergence_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def scope_and_sources_ok(receipt: dict[str, Any], source_receipts: list[dict[str, Any] | None], errors: list[str]) -> None:
    scope = receipt.get("convergence_scope") or {}
    for field in [
        "convergence_plan_id",
        "convergence_reason",
        "recipient_class",
        "purpose",
        "source_release_id",
        "source_signal_event_key",
        "source_signal_subject_digest",
        "cache_subject_digest",
        "receiver_set_digest",
        "expected_receiver_count",
        "overlap_consumer_set_digest",
        "convergence_cut_time",
        "convergence_deadline",
    ]:
        if scope.get(field) in (None, ""):
            errors.append(f"convergence_scope.{field} missing")
    try:
        cut = parse_time(scope.get("convergence_cut_time"), "convergence_scope.convergence_cut_time")
        deadline = parse_time(scope.get("convergence_deadline"), "convergence_scope.convergence_deadline")
        if deadline < cut:
            errors.append("convergence_scope.convergence_deadline must not precede convergence_cut_time")
    except ValueError as exc:
        errors.append(str(exc))
    refs = receipt.get("source_reconciliation_refs")
    if not isinstance(refs, list) or not refs:
        errors.append("source_reconciliation_refs must be a non-empty list")
        refs = []
    observations = receipt.get("receiver_observations")
    if not isinstance(observations, list) or not observations:
        errors.append("receiver_observations must be a non-empty list")
        observations = []
    required_observations = [obs for obs in observations if obs.get("required") is True]
    if scope.get("expected_receiver_count") != len(required_observations):
        errors.append("convergence_scope.expected_receiver_count must equal required receiver observations")
    if scope.get("receiver_set_digest") != stable_digest(receiver_set_material(observations)):
        errors.append("convergence_scope.receiver_set_digest does not match receiver_observations")
    consumer_digests = [obs.get("affected_consumer_set_digest") for obs in observations if obs.get("affected_consumer_set_digest")]
    if scope.get("overlap_consumer_set_digest") != stable_digest(sorted(set(consumer_digests))):
        errors.append("convergence_scope.overlap_consumer_set_digest does not match observed affected consumer digests")
    for idx, ref in enumerate(refs):
        for field in ["recipient_class", "purpose", "source_release_id", "source_signal_event_key", "source_signal_subject_digest", "cache_subject_digest"]:
            if scope.get(field) != ref.get(field):
                errors.append(f"convergence_scope.{field} must mirror source_reconciliation_refs[{idx}]")


def observations_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    refs = receipt.get("source_reconciliation_refs") or []
    observations = receipt.get("receiver_observations") or []
    seen_receiver_cut: set[tuple[str, str]] = set()
    for idx, obs in enumerate(observations):
        for field in [
            "receiver_id_hash",
            "receiver_class",
            "status_channel_id_hash",
            "status_channel_cut_digest",
            "status_channel_watermark",
            "source_reconciliation_ref_index",
            "source_receipt_id",
            "source_receipt_sha256",
            "local_reconciliation_state",
            "cache_reuse_state",
            "affected_consumer_set_digest",
            "expected_consumer_count",
            "stale_consumers_remaining",
            "observation_state",
        ]:
            if obs.get(field) in (None, ""):
                errors.append(f"receiver_observations[{idx}].{field} missing")
        if not str(obs.get("receiver_id_hash", "")).startswith("sha256:"):
            errors.append(f"receiver_observations[{idx}].receiver_id_hash must be hashed")
        if not str(obs.get("status_channel_id_hash", "")).startswith("sha256:"):
            errors.append(f"receiver_observations[{idx}].status_channel_id_hash must be hashed")
        if obs.get("raw_receiver_id"):
            errors.append(f"receiver_observations[{idx}] must not expose raw_receiver_id")
        if obs.get("raw_status_channel"):
            errors.append(f"receiver_observations[{idx}] must not expose raw_status_channel")
        if obs.get("observation_state") not in VALID_OBSERVATION_STATES:
            errors.append(f"receiver_observations[{idx}].observation_state invalid")
        ref_index = obs.get("source_reconciliation_ref_index")
        if not isinstance(ref_index, int) or ref_index < 0 or ref_index >= len(refs):
            errors.append(f"receiver_observations[{idx}].source_reconciliation_ref_index out of range")
            continue
        ref = refs[ref_index]
        mirrors = {
            "source_receipt_id": ref.get("receipt_id"),
            "source_receipt_sha256": ref.get("receipt_sha256"),
            "local_reconciliation_state": ref.get("reconciliation_state"),
            "cache_reuse_state": ref.get("cache_reuse_state"),
            "affected_consumer_set_digest": ref.get("affected_consumer_set_digest"),
            "expected_consumer_count": ref.get("expected_consumer_count"),
            "stale_consumers_remaining": ref.get("stale_consumers_remaining"),
        }
        for field, expected in mirrors.items():
            if obs.get(field) != expected:
                errors.append(f"receiver_observations[{idx}].{field} must mirror source_reconciliation_refs[{ref_index}]")
        key = (obs.get("receiver_id_hash"), obs.get("status_channel_cut_digest"))
        if key in seen_receiver_cut and obs.get("observation_state") != "duplicate_observation_suppressed":
            errors.append(f"receiver_observations[{idx}] repeats receiver/cut without duplicate suppression")
        seen_receiver_cut.add(key)
        if obs.get("observation_state") in {"receiver_lag_quarantined", "receiver_fork_quarantined", "divergent_cut_held"}:
            if not obs.get("quarantine_pointer") and not obs.get("hold_pointer"):
                errors.append(f"receiver_observations[{idx}] unsafe state must carry quarantine_pointer or hold_pointer")
        if obs.get("observation_state") == "receiver_reconciled" and obs.get("stale_consumers_remaining") not in (0, None):
            errors.append(f"receiver_observations[{idx}] reconciled receiver cannot have stale consumers remaining")


def summary_and_decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    observations = receipt.get("receiver_observations") or []
    summary = receipt.get("convergence_summary") or {}
    decision = receipt.get("convergence_decision") or {}
    state = decision.get("state")
    if state not in VALID_STATES:
        errors.append("convergence_decision.state invalid")
    counts = {
        "reconciled_receiver_count": sum(1 for o in observations if o.get("observation_state") == "receiver_reconciled"),
        "lagging_receiver_count": sum(1 for o in observations if o.get("observation_state") == "receiver_lag_quarantined"),
        "divergent_cut_count": sum(1 for o in observations if o.get("observation_state") == "divergent_cut_held"),
        "duplicate_suppressed_count": sum(1 for o in observations if o.get("observation_state") == "duplicate_observation_suppressed"),
        "receiver_fork_count": sum(1 for o in observations if o.get("observation_state") == "receiver_fork_quarantined"),
        "expected_receiver_count": sum(1 for o in observations if o.get("required") is True),
    }
    for field, expected in counts.items():
        if summary.get(field) != expected:
            errors.append(f"convergence_summary.{field} must equal derived count {expected}")
    stale_expected = counts["lagging_receiver_count"] + counts["divergent_cut_count"] + counts["receiver_fork_count"]
    if summary.get("stale_receivers_remaining") != stale_expected:
        errors.append("convergence_summary.stale_receivers_remaining must equal lagging+divergent+fork receivers")
    for field in [
        "ack_as_authority",
        "ack_as_refresh",
        "delivery_ack_as_consumer_refresh",
        "receiver_convergence_as_authority",
        "receiver_quorum_as_authority",
        "convergence_as_recertification",
        "partial_convergence_as_complete",
        "status_pointer_update_allowed",
    ]:
        if summary.get(field) is not False:
            errors.append(f"convergence_summary.{field} must be false")
    if summary.get("counts_bucketed_or_internal") is not True:
        errors.append("convergence_summary.counts_bucketed_or_internal must be true")
    if summary.get("exact_counts_public") is not False:
        errors.append("convergence_summary.exact_counts_public must be false")
    if decision.get("no_authority_granted") is not True:
        errors.append("convergence_decision.no_authority_granted must be true")
    for field in ["source_reconciliations_unmodified", "requires_receiver_replay_before_reuse"]:
        if decision.get(field) is not True:
            errors.append(f"convergence_decision.{field} must be true")
    for field in ["winner_selected", "receiver_quorum_as_authority", "convergence_as_recertification"]:
        if decision.get(field) is not False:
            errors.append(f"convergence_decision.{field} must be false")
    if state == "all_receivers_converged_refresh_required":
        if summary.get("stale_receivers_remaining") != 0 or summary.get("all_required_receivers_converged") is not True:
            errors.append("all_receivers_converged state requires all receivers converged and no stale receivers")
        if decision.get("cache_reuse_state") != "refresh_required":
            errors.append("all_receivers_converged state must keep cache_reuse_state refresh_required")
    if state == "partial_receiver_lag_quarantined":
        if counts["lagging_receiver_count"] < 1 or summary.get("partial_convergence_as_complete") is not False:
            errors.append("partial_receiver_lag state requires lagging receiver and must not be complete")
        if decision.get("cache_reuse_state") != "quarantine_required":
            errors.append("partial_receiver_lag state must require quarantine")
    if state == "divergent_status_channel_cut_held":
        if counts["divergent_cut_count"] < 1:
            errors.append("divergent_status_channel_cut state requires divergent cut observation")
        if len({o.get("status_channel_cut_digest") for o in observations if o.get("required") is True}) < 2:
            errors.append("divergent_status_channel_cut state requires at least two required status-channel cuts")
        if decision.get("cache_reuse_state") != "held_due_to_divergence":
            errors.append("divergent_status_channel_cut state must be held_due_to_divergence")
    if state == "duplicate_receiver_observation_suppressed":
        if counts["duplicate_suppressed_count"] < 1:
            errors.append("duplicate state requires duplicate suppressed observation")
        if decision.get("cache_reuse_state") != "unchanged_duplicate":
            errors.append("duplicate state must keep cache_reuse_state unchanged_duplicate")
    if state == "receiver_fork_quarantined":
        if counts["receiver_fork_count"] < 1:
            errors.append("receiver_fork state requires fork quarantine observation")
        if decision.get("cache_reuse_state") not in {"quarantine_required", "held_due_to_fork"}:
            errors.append("receiver_fork state must require quarantine or fork hold")


def closure_projection_effects_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    scope = receipt.get("convergence_scope") or {}
    closure = receipt.get("convergence_closure") or {}
    projection = receipt.get("projection_safety") or {}
    effects = receipt.get("effect_closure") or {}
    for field in [
        "requires_source_reconciliation_receipts",
        "requires_receiver_set_digest",
        "stale_receivers_notified_or_quarantined",
        "no_reuse_until_all_receivers_rechecked",
        "source_reconciliations_mutated",
        "status_pointer_update_allowed",
        "receiver_convergence_can_grant_authority",
        "global_winner_selected",
    ]:
        if field not in closure:
            errors.append(f"convergence_closure.{field} missing")
    expected_bool = {
        "requires_source_reconciliation_receipts": True,
        "requires_receiver_set_digest": True,
        "stale_receivers_notified_or_quarantined": True,
        "no_reuse_until_all_receivers_rechecked": True,
        "source_reconciliations_mutated": False,
        "status_pointer_update_allowed": False,
        "receiver_convergence_can_grant_authority": False,
        "global_winner_selected": False,
    }
    for field, expected in expected_bool.items():
        if closure.get(field) is not expected:
            errors.append(f"convergence_closure.{field} must be {expected}")
    if projection.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if projection.get("no_exact_hidden_counts_public") is not True:
        errors.append("projection_safety.no_exact_hidden_counts_public must be true")
    if "not authority" not in str(projection.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    if scope.get("recipient_class") in PUBLIC_RECIPIENTS:
        for field in [
            "reveals_receiver_identity_public",
            "reveals_status_channel_private",
            "reveals_named_private_stewards",
            "reveals_private_org_map",
            "reveals_raw_partner_fragments",
            "reveals_recipient_private_contact",
            "sealed_reconciliation_payload_inline",
            "sealed_signal_payload_inline",
            "sealed_notification_payload_inline",
        ]:
            if projection.get(field) is not False:
                errors.append(f"projection_safety.{field} must be false for public recipients")
        if projection.get("hashed_or_class_only_receivers") is not True:
            errors.append("projection_safety.hashed_or_class_only_receivers must be true for public recipients")
    actual_effects = set(effects.get("actual_effects") or [])
    forbidden = set(effects.get("forbidden_effects") or [])
    if not actual_effects:
        errors.append("effect_closure.actual_effects missing")
    unsafe = sorted(actual_effects - SAFE_EFFECTS)
    if unsafe:
        errors.append("effect_closure.actual_effects contains unsupported effects: " + ", ".join(unsafe))
    high = sorted(actual_effects & HIGH_CONSEQUENCE_EFFECTS)
    if high:
        errors.append("effect_closure.actual_effects contains high-consequence effects: " + ", ".join(high))
    missing_forbidden = sorted(REQUIRED_FORBIDDEN - forbidden)
    if missing_forbidden:
        errors.append("effect_closure.forbidden_effects missing required fences: " + ", ".join(missing_forbidden[:8]))
    for field in ["no_authority_upgrade", "no_high_consequence_effects", "safe_receiver_convergence_effects_only"]:
        if effects.get(field) is not True:
            errors.append(f"effect_closure.{field} must be true")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    refs = receipt.get("source_reconciliation_refs") or []
    source_receipts = []
    if isinstance(refs, list):
        for idx, ref in enumerate(refs):
            if not isinstance(ref, dict):
                errors.append(f"source_reconciliation_refs[{idx}] must be an object")
                source_receipts.append(None)
                continue
            source_receipts.append(resolve_source_reconciliation(ref, idx, errors))
    scope_and_sources_ok(receipt, source_receipts, errors)
    observations_ok(receipt, errors)
    summary_and_decision_ok(receipt, errors)
    closure_projection_effects_ok(receipt, errors)
    return errors


def main() -> int:
    return run_fixture_checker(
        fixture_dir=CONVERGENCE_DIR,
        valid_glob="*.valid.json",
        invalid_glob="*.invalid.json",
        validate_receipt=validate_receipt,
        label="Governance receiver-convergence receipt",
    )


if __name__ == "__main__":
    sys.exit(main())
