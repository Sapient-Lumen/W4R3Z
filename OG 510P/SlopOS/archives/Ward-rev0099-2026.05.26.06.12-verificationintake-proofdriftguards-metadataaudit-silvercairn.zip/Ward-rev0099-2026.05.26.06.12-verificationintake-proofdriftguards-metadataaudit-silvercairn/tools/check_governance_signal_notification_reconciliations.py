#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Any
import sys

from governance_common import (
    ROOT,
    load_json,
    parse_time,
    require,
    run_fixture_checker,
    stable_digest,
    validate_ref,
)

RECON_DIR = ROOT / "fixtures" / "governance-signal-notification-reconciliation"
SCHEMA = "ward.governance-signal-notification-reconciliation-receipt.v0"
RECEIPT_NAME = "ward.governance.signal-notification-reconciliation-receipt.v0"
AUTHORITY_SURFACE = "signal_notification_reconciliation_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}

VALID_STATES = {
    "all_consumers_recertified_refresh_required",
    "partial_recertification_quarantined",
    "dead_letter_reconciliation_quarantined",
    "duplicate_reconciliation_suppressed",
    "conflict_reconciliation_held",
    "invalid_reconciliation_rejected",
}
VALID_REFRESH_STATES = {
    "consumer_recertified",
    "pending_recertification_quarantined",
    "dead_lettered_quarantined",
    "duplicate_suppressed",
    "conflict_hold_pending_review",
    "not_required_noop",
    "invalid_rejected",
}
SAFE_EFFECTS = {
    "record_signal_notification_reconciliation_receipt",
    "record_consumer_recertification_ref",
    "record_reconciliation_gap",
    "record_consumer_set_digest",
    "record_refresh_gap",
    "quarantine_unrefreshed_consumers",
    "suppress_duplicate_reconciliation",
    "hold_conflict_for_review",
    "request_consumer_recertification",
    "publish_reconciliation_status",
    "notify_stale_consumer_owner",
    "mark_reconciliation_noop",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "budget_spend",
    "delegate",
    "export_raw_evidence",
    "force_consumer_action",
    "grant_authority",
    "learning_use",
    "privacy_waiver",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "reuse_as_authority",
    "semantic_repair",
    "status_signal_as_action",
    "treat_ack_as_refresh",
    "update_current_head_without_replay",
    "update_status_pointer",
}
REQUIRED_FORBIDDEN = {
    "acknowledgment_as_authority",
    "acknowledgment_as_refresh",
    "action_without_packet",
    "authority_reuse_without_packet",
    "budget_spend",
    "cache_as_authority",
    "cached_head_reuse_without_refresh",
    "consumer_reconciliation_as_authority",
    "dead_letter_as_delivery",
    "delegate_without_warrant",
    "delivery_ack_as_consumer_refresh",
    "duplicate_delivery_as_new_change",
    "event_log_as_grant",
    "export_without_receipt",
    "future_action",
    "learning_use",
    "missing_consumer_hidden",
    "notification_as_recertification",
    "notification_scope_expansion",
    "partial_reconciliation_as_complete",
    "poll_delivery_as_order_proof",
    "privacy_waiver_without_packet",
    "push_ack_as_consumer_refresh",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "reconciliation_as_recertification",
    "recertification_ref_mismatch",
    "resolution_as_authority",
    "reuse_without_refresh",
    "sealed_branch_disclosure",
    "signal_as_authority",
    "stale_consumer_reuse",
    "stale_signal_as_current",
    "status_channel_replay_as_authority",
    "status_pointer_as_grant",
    "status_signal_as_action",
    "unprojected_disclosure",
}


def resolve_source_notification(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    source = validate_ref(
        ref,
        label="source_signal_notification_ref",
        expected_schema="ward.governance-signal-notification-receipt.v0",
        checker_script="check_governance_signal_notifications.py",
        checker_module_name="ward_signal_notification_checker_for_reconciliation",
        errors=errors,
    )
    if not source:
        return None
    scope = source.get("notification_scope") or {}
    decision = source.get("notification_decision") or {}
    plan = source.get("delivery_plan") or {}
    summary = source.get("acknowledgment_summary") or {}
    mirrors = {
        "notification_state": decision.get("state"),
        "cache_reuse_state": decision.get("cache_reuse_state"),
        "recipient_class": scope.get("recipient_class"),
        "purpose": scope.get("purpose"),
        "source_release_id": scope.get("source_release_id"),
        "source_signal_event_key": scope.get("source_signal_event_key"),
        "source_signal_subject_digest": scope.get("source_signal_subject_digest"),
        "cache_subject_digest": scope.get("cache_subject_digest"),
        "affected_consumer_set_digest": scope.get("affected_consumer_set_digest"),
        "expected_consumer_count": scope.get("expected_consumer_count"),
        "notification_payload_digest": plan.get("notification_payload_digest"),
        "local_refresh_required": summary.get("local_refresh_required"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_signal_notification_ref.{field} does not mirror source signal-notification receipt")
    return source


def resolve_recertification(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    source = validate_ref(
        ref,
        label="consumer_recertification_ref",
        expected_schema="ward.governance-recertification-receipt.v0",
        checker_script="check_governance_recertifications.py",
        checker_module_name="ward_recertification_checker_for_reconciliation",
        errors=errors,
    )
    if not source:
        return None
    scope = source.get("recertification_scope") or {}
    binding = source.get("cache_binding") or {}
    decision = source.get("recertification_decision") or {}
    mirrors = {
        "recertification_state": decision.get("state"),
        "cached_resolution_reuse_state": decision.get("cached_resolution_reuse_state"),
        "source_release_id": scope.get("source_release_id"),
        "recipient_class": scope.get("recipient_class"),
        "purpose": scope.get("purpose"),
        "source_item_digest": scope.get("source_item_digest"),
        "projection_policy_digest": scope.get("projection_policy_digest"),
        "cache_subject_digest": binding.get("cache_subject_digest"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"consumer_recertification_ref.{field} does not mirror referenced recertification receipt")
    if decision.get("no_authority_granted") is not True:
        errors.append("consumer_recertification_ref referenced recertification must grant no authority")
    return source


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be signal_notification_reconciliation_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def scope_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    scope = receipt.get("reconciliation_scope") or {}
    ref = receipt.get("source_signal_notification_ref") or {}
    for field in [
        "reconciliation_plan_id",
        "reconciliation_reason",
        "recipient_class",
        "purpose",
        "source_release_id",
        "source_signal_event_key",
        "source_signal_subject_digest",
        "cache_subject_digest",
        "affected_consumer_set_digest",
        "expected_consumer_count",
        "reconciliation_cut_time",
        "reconciliation_deadline",
    ]:
        if scope.get(field) in (None, ""):
            errors.append(f"reconciliation_scope.{field} missing")
    mirrors = {
        "recipient_class": ref.get("recipient_class"),
        "purpose": ref.get("purpose"),
        "source_release_id": ref.get("source_release_id"),
        "source_signal_event_key": ref.get("source_signal_event_key"),
        "source_signal_subject_digest": ref.get("source_signal_subject_digest"),
        "cache_subject_digest": ref.get("cache_subject_digest"),
        "affected_consumer_set_digest": ref.get("affected_consumer_set_digest"),
        "expected_consumer_count": ref.get("expected_consumer_count"),
    }
    for field, expected in mirrors.items():
        if scope.get(field) != expected:
            errors.append(f"reconciliation_scope.{field} must mirror source_signal_notification_ref")
    try:
        cut = parse_time(scope.get("reconciliation_cut_time"), "reconciliation_scope.reconciliation_cut_time")
        deadline = parse_time(scope.get("reconciliation_deadline"), "reconciliation_scope.reconciliation_deadline")
        if deadline < cut:
            errors.append("reconciliation_scope.reconciliation_deadline must not precede reconciliation_cut_time")
    except ValueError as exc:
        errors.append(str(exc))
    consumers = scope.get("affected_consumers")
    if not isinstance(consumers, list):
        errors.append("reconciliation_scope.affected_consumers must be a list")
        consumers = []
    if source:
        expected_consumers = (source.get("notification_scope") or {}).get("affected_consumers") or []
        if consumers != expected_consumers:
            errors.append("reconciliation_scope.affected_consumers must exactly mirror source notification affected_consumers")
    if scope.get("affected_consumer_set_digest") != stable_digest(consumers):
        errors.append("reconciliation_scope.affected_consumer_set_digest does not match affected_consumers")
    required = [c for c in consumers if c.get("required") is True]
    if scope.get("expected_consumer_count") != len(required):
        errors.append("reconciliation_scope.expected_consumer_count must equal required affected consumers")
    if len([c.get("consumer_id_hash") for c in consumers]) != len({c.get("consumer_id_hash") for c in consumers}):
        errors.append("reconciliation_scope.affected_consumers contains duplicate consumer_id_hash values")


def source_delivery_by_consumer(source: dict[str, Any] | None) -> dict[str, dict[str, Any]]:
    if not source:
        return {}
    return {obs.get("consumer_id_hash"): obs for obs in source.get("consumer_observations") or []}


def observations_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> dict[str, int]:
    observations = receipt.get("refresh_observations")
    if not isinstance(observations, list):
        errors.append("refresh_observations must be a list")
        observations = []
    scope_consumers = (receipt.get("reconciliation_scope") or {}).get("affected_consumers") or []
    expected_ids = {c.get("consumer_id_hash") for c in scope_consumers}
    seen: set[str] = set()
    counts = {"recertified": 0, "pending": 0, "dead": 0, "dup": 0, "conflict": 0, "noop": 0, "invalid": 0}
    source_obs = source_delivery_by_consumer(source)
    ref = receipt.get("source_signal_notification_ref") or {}
    for obs in observations:
        cid = obs.get("consumer_id_hash")
        if not cid:
            errors.append("each refresh_observation needs consumer_id_hash")
            continue
        if cid in seen:
            errors.append("refresh_observations contains duplicate consumer_id_hash values")
        seen.add(cid)
        if cid not in expected_ids:
            errors.append("refresh_observation consumer_id_hash not present in source affected consumer set")
        source_delivery = source_obs.get(cid) or {}
        if obs.get("source_delivery_state") != source_delivery.get("delivery_state"):
            errors.append("refresh_observation.source_delivery_state must mirror source notification delivery_state")
        source_state = source_delivery.get("delivery_state")
        if source_state == "dead_lettered_quarantined" and obs.get("refresh_state") != "dead_lettered_quarantined":
            errors.append("dead-lettered source consumers cannot be reconciled as refreshed without a newer notification receipt")
        if source_state == "duplicate_suppressed" and obs.get("refresh_state") != "duplicate_suppressed":
            errors.append("duplicate-suppressed source consumers cannot be promoted to refresh")
        if source_state == "conflict_hold_notified" and obs.get("refresh_state") != "conflict_hold_pending_review":
            errors.append("conflict-hold source consumers must remain pending review")
        if obs.get("acknowledgment_digest") and obs.get("acknowledgment_digest") != source_delivery.get("ack_digest"):
            errors.append("refresh_observation.acknowledgment_digest must mirror source notification ack_digest when present")
        if obs.get("ack_as_authority") is not False:
            errors.append("refresh_observation.ack_as_authority must be false")
        if obs.get("ack_as_refresh") is not False:
            errors.append("refresh_observation.ack_as_refresh must be false")
        if obs.get("delivery_ack_as_consumer_refresh") is not False:
            errors.append("refresh_observation.delivery_ack_as_consumer_refresh must be false")
        if obs.get("refresh_state") not in VALID_REFRESH_STATES:
            errors.append("refresh_observation.refresh_state invalid or missing")
        state = obs.get("refresh_state")
        if state == "consumer_recertified":
            counts["recertified"] += 1
            if obs.get("local_refresh_observed") is not True:
                errors.append("consumer_recertified requires local_refresh_observed true")
            recert = resolve_recertification(obs.get("consumer_recertification_ref") or {}, errors)
            if recert:
                rref = obs.get("consumer_recertification_ref") or {}
                mirrors = {
                    "source_release_id": ref.get("source_release_id"),
                    "recipient_class": ref.get("recipient_class"),
                    "purpose": ref.get("purpose"),
                    "cache_subject_digest": ref.get("cache_subject_digest"),
                }
                for field, expected in mirrors.items():
                    if rref.get(field) != expected:
                        errors.append(f"consumer_recertification_ref.{field} must mirror source notification")
                if rref.get("recertification_state") not in {"cached_resolution_invalidated", "current_cache_recertified", "recertification_recheck_required"}:
                    errors.append("consumer_recertified requires a current/invalidated/recheck recertification state")
        elif state == "pending_recertification_quarantined":
            counts["pending"] += 1
            if obs.get("local_refresh_observed") is not False:
                errors.append("pending_recertification_quarantined requires local_refresh_observed false")
            if not obs.get("quarantine_pointer"):
                errors.append("pending_recertification_quarantined requires quarantine_pointer")
        elif state == "dead_lettered_quarantined":
            counts["dead"] += 1
            if obs.get("local_refresh_observed") is not False:
                errors.append("dead_lettered_quarantined requires local_refresh_observed false")
            if not obs.get("quarantine_pointer") or not obs.get("dead_letter_pointer"):
                errors.append("dead_lettered_quarantined requires quarantine_pointer and dead_letter_pointer")
        elif state == "duplicate_suppressed":
            counts["dup"] += 1
            if obs.get("local_refresh_observed") is not False:
                errors.append("duplicate_suppressed requires local_refresh_observed false")
            if not obs.get("duplicate_of_notification_id"):
                errors.append("duplicate_suppressed requires duplicate_of_notification_id")
        elif state == "conflict_hold_pending_review":
            counts["conflict"] += 1
            if obs.get("local_refresh_observed") is not False:
                errors.append("conflict_hold_pending_review requires local_refresh_observed false")
            if not obs.get("review_lane_pointer"):
                errors.append("conflict_hold_pending_review requires review_lane_pointer")
        elif state == "not_required_noop":
            counts["noop"] += 1
            if obs.get("local_refresh_observed") is not False:
                errors.append("not_required_noop requires local_refresh_observed false")
        elif state == "invalid_rejected":
            counts["invalid"] += 1
    if seen != expected_ids:
        errors.append("refresh_observations must cover exactly every expected affected consumer")
    return counts


def summary_ok(receipt: dict[str, Any], counts: dict[str, int], errors: list[str]) -> None:
    summary = receipt.get("reconciliation_summary") or {}
    expected = (receipt.get("reconciliation_scope") or {}).get("expected_consumer_count")
    if summary.get("expected_consumer_count") != expected:
        errors.append("reconciliation_summary.expected_consumer_count must mirror scope")
    mapping = {
        "recertified_count": "recertified",
        "pending_recertification_count": "pending",
        "dead_lettered_count": "dead",
        "duplicate_suppressed_count": "dup",
        "conflict_hold_count": "conflict",
        "noop_count": "noop",
        "invalid_rejected_count": "invalid",
    }
    for field, key in mapping.items():
        if summary.get(field) != counts[key]:
            errors.append(f"reconciliation_summary.{field} does not match refresh_observations")
    stale = counts["pending"] + counts["dead"]
    if summary.get("stale_consumers_remaining") != stale:
        errors.append("reconciliation_summary.stale_consumers_remaining must equal pending + dead-lettered consumers")
    all_recert = expected is not None and counts["recertified"] == expected and stale == 0 and counts["conflict"] == 0
    if summary.get("all_required_consumers_recertified") != all_recert:
        errors.append("reconciliation_summary.all_required_consumers_recertified is inconsistent")
    for field in [
        "ack_as_authority",
        "ack_as_refresh",
        "delivery_ack_as_consumer_refresh",
        "reconciliation_as_authority",
        "reconciliation_as_recertification",
        "partial_reconciliation_as_complete",
        "exact_counts_public",
    ]:
        if summary.get(field) is not False:
            errors.append(f"reconciliation_summary.{field} must be false")
    if summary.get("counts_bucketed_or_internal") is not True:
        errors.append("reconciliation_summary.counts_bucketed_or_internal must be true")
    if summary.get("cache_reuse_state") not in {"refresh_required", "quarantine_required", "unchanged_duplicate", "held_due_to_conflict", "rejected"}:
        errors.append("reconciliation_summary.cache_reuse_state invalid or missing")


def closure_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    closure = receipt.get("reconciliation_closure") or {}
    scope = receipt.get("reconciliation_scope") or {}
    if closure.get("blocked_cache_subject_digest") != scope.get("cache_subject_digest"):
        errors.append("reconciliation_closure.blocked_cache_subject_digest must mirror scope cache_subject_digest")
    required_true = [
        "requires_consumer_recertification_receipts",
        "missing_consumers_not_hidden",
        "unrefreshed_consumers_quarantined",
        "no_reuse_until_recertified",
        "stale_consumers_notified_or_quarantined",
    ]
    for field in required_true:
        if closure.get(field) is not True:
            errors.append(f"reconciliation_closure.{field} must be true")
    required_false = [
        "source_notification_mutated",
        "notification_can_grant_authority",
        "reconciliation_can_grant_authority",
        "status_pointer_update_allowed",
    ]
    for field in required_false:
        if closure.get(field) is not False:
            errors.append(f"reconciliation_closure.{field} must be false")


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    projection = receipt.get("projection_safety") or {}
    recipient_class = (receipt.get("reconciliation_scope") or {}).get("recipient_class")
    if projection.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(projection.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must visibly say not authority")
    for field in [
        "sealed_signal_payload_inline",
        "sealed_notification_payload_inline",
        "sealed_recertification_payload_inline",
        "reveals_private_org_map",
        "reveals_raw_partner_fragments",
        "reveals_reviewer_identities",
        "reveals_named_private_stewards",
        "reveals_recipient_private_contact",
    ]:
        if projection.get(field) is not False:
            errors.append(f"projection_safety.{field} must be false")
    if recipient_class in PUBLIC_RECIPIENTS:
        if projection.get("reveals_consumer_identity_public") is not False:
            errors.append("public reconciliation must not reveal consumer identities")
        if projection.get("no_exact_hidden_counts_public") is not True:
            errors.append("public reconciliation must not expose exact hidden counts")
        if projection.get("hashed_or_class_only_consumers") is not True:
            errors.append("public reconciliation must use hashed/class-only consumers")
        if projection.get("bucketed_or_presence_only_disclosure") is not True:
            errors.append("public reconciliation must use bucketed or presence-only disclosure")


def effects_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    effect = receipt.get("effect_closure") or {}
    effects = set(effect.get("effects_performed") or [])
    forbidden = set(effect.get("forbidden_effects_preserved") or [])
    unknown = sorted(effects - SAFE_EFFECTS)
    if unknown:
        errors.append("effect_closure.effects_performed contains unsafe/unknown effects: " + ", ".join(unknown))
    high = sorted(effects & HIGH_CONSEQUENCE_EFFECTS)
    if high:
        errors.append("effect_closure.effects_performed contains high-consequence effects: " + ", ".join(high))
    missing = sorted(REQUIRED_FORBIDDEN - forbidden)
    if missing:
        errors.append("effect_closure.forbidden_effects_preserved missing: " + ", ".join(missing))
    if effect.get("safe_signal_notification_reconciliation_effects_only") is not True:
        errors.append("effect_closure.safe_signal_notification_reconciliation_effects_only must be true")
    if effect.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if effect.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")


def decision_ok(receipt: dict[str, Any], counts: dict[str, int], errors: list[str]) -> None:
    decision = receipt.get("reconciliation_decision") or {}
    state = decision.get("state")
    source_state = (receipt.get("source_signal_notification_ref") or {}).get("notification_state")
    summary = receipt.get("reconciliation_summary") or {}
    if state not in VALID_STATES:
        errors.append("reconciliation_decision.state invalid or missing")
        return
    expected_cache = {
        "all_consumers_recertified_refresh_required": "refresh_required",
        "partial_recertification_quarantined": "quarantine_required",
        "dead_letter_reconciliation_quarantined": "quarantine_required",
        "duplicate_reconciliation_suppressed": "unchanged_duplicate",
        "conflict_reconciliation_held": "held_due_to_conflict",
        "invalid_reconciliation_rejected": "rejected",
    }
    if decision.get("cache_reuse_state") != expected_cache.get(state):
        errors.append(f"{state} requires cache_reuse_state {expected_cache.get(state)}")
    if summary.get("cache_reuse_state") != decision.get("cache_reuse_state"):
        errors.append("reconciliation_summary.cache_reuse_state must mirror decision")
    for field in ["no_authority_granted", "source_notification_unmodified"]:
        if decision.get(field) is not True:
            errors.append(f"reconciliation_decision.{field} must be true")
    for field in ["reconciliation_as_recertification", "acknowledgment_as_refresh", "winner_selected"]:
        if decision.get(field) is not False:
            errors.append(f"reconciliation_decision.{field} must be false")
    if state == "all_consumers_recertified_refresh_required":
        if source_state != "all_consumers_notified_refresh_required":
            errors.append("all_consumers_recertified_refresh_required requires all-consumers-notified source")
        if summary.get("all_required_consumers_recertified") is not True:
            errors.append("all_consumers_recertified_refresh_required requires all consumers recertified")
        if counts["pending"] or counts["dead"] or counts["conflict"]:
            errors.append("all_consumers_recertified_refresh_required cannot have pending/dead/conflict consumers")
    if state == "partial_recertification_quarantined":
        if source_state not in {"all_consumers_notified_refresh_required", "partial_notification_quarantined"}:
            errors.append("partial_recertification_quarantined requires recertification-capable source notification")
        if counts["pending"] <= 0:
            errors.append("partial_recertification_quarantined requires pending quarantined consumers")
        if summary.get("all_required_consumers_recertified") is not False:
            errors.append("partial_recertification_quarantined must not claim all recertified")
    if state == "dead_letter_reconciliation_quarantined":
        if source_state != "dead_lettered_notification_quarantined":
            errors.append("dead_letter_reconciliation_quarantined requires dead-lettered source notification")
        if counts["dead"] <= 0:
            errors.append("dead_letter_reconciliation_quarantined requires dead-lettered consumers")
    if state == "duplicate_reconciliation_suppressed":
        if source_state != "duplicate_notification_suppressed":
            errors.append("duplicate_reconciliation_suppressed requires duplicate source notification")
        if counts["dup"] <= 0:
            errors.append("duplicate_reconciliation_suppressed requires duplicate_suppressed observations")
    if state == "conflict_reconciliation_held":
        if source_state != "conflict_notification_held":
            errors.append("conflict_reconciliation_held requires conflict source notification")
        if counts["conflict"] <= 0:
            errors.append("conflict_reconciliation_held requires conflict-hold observations")
        if decision.get("winner_selected") is not False:
            errors.append("conflict_reconciliation_held must not select a winner")
    if state == "invalid_reconciliation_rejected" and counts["invalid"] <= 0:
        errors.append("invalid_reconciliation_rejected requires invalid_rejected observations")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    source = resolve_source_notification(receipt.get("source_signal_notification_ref") or {}, errors)
    scope_ok(receipt, source, errors)
    counts = observations_ok(receipt, source, errors)
    summary_ok(receipt, counts, errors)
    closure_ok(receipt, errors)
    projection_ok(receipt, errors)
    effects_ok(receipt, errors)
    decision_ok(receipt, counts, errors)
    return errors


def main() -> int:
    return run_fixture_checker(
        fixture_dir=RECON_DIR,
        valid_glob="*.valid.json",
        invalid_glob="*.invalid.json",
        validate_receipt=validate_receipt,
        label="Governance signal-notification reconciliation",
    )


if __name__ == "__main__":
    sys.exit(main())
