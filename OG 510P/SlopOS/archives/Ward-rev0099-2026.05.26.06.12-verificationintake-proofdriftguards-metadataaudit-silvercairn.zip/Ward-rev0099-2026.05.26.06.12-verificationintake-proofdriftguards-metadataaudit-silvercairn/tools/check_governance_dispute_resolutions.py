#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
RESOLUTION_DIR = ROOT / "fixtures" / "governance-dispute-resolution"
SCHEMA = "ward.governance-dispute-resolution-receipt.v0"
RECEIPT_NAME = "ward.governance.dispute-resolution-receipt.v0"
AUTHORITY_SURFACE = "dispute_resolution_receipt_only"

ELIGIBLE_SOURCE_STATES = {
    "fork_detected_hold",
    "disputed_head_quarantined",
    "chain_recheck_required",
    "successor_pending_recheck",
    "historical_minimized",
}
VALID_DECISION_STATES = {
    "current_head_recovered",
    "quarantine_sustained",
    "successor_resolution_pending",
    "historical_resolution_recorded",
    "resolution_recheck_required",
}
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}
SAFE_RESOLUTION_EFFECTS = {
    "record_dispute_resolution_receipt",
    "record_branch_disposition",
    "record_recovered_status_pointer",
    "sustain_quarantine",
    "publish_status_pointer_update",
    "notify_recipients",
    "request_recheck",
    "retain_minimized_resolution",
    "record_successor_acceptance",
    "rotate_status_channel",
    "record_no_current_head",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "budget_spend",
    "delegate",
    "export_raw_evidence",
    "grant_authority",
    "learning_use",
    "privacy_waiver",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "reuse_as_authority",
    "semantic_repair",
}
REQUIRED_FORBIDDEN = {
    "ack_as_authority",
    "action_reenable",
    "action_without_packet",
    "authority_reuse_without_packet",
    "broader_scope",
    "budget_spend",
    "delegate_without_warrant",
    "export_without_receipt",
    "future_action",
    "learning_use",
    "losing_branch_reuse",
    "old_channel_reuse",
    "privacy_waiver_without_packet",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "resolution_as_authority",
    "reuse_without_refresh",
    "sealed_branch_disclosure",
    "stale_bundle_reuse",
    "status_pointer_as_grant",
    "successor_as_authority",
    "unprojected_disclosure",
}


def load_checker(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load checker {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

chain_checker = load_checker(ROOT / "tools" / "check_governance_chain_integrity.py", "ward_chain_checker_for_resolution")


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_time(value: str | None, field: str) -> datetime:
    if not value:
        raise ValueError(f"{field} missing")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} is not ISO-8601 parseable: {value}") from exc


def require(cond: bool, msg: str, errors: list[str]) -> None:
    if not cond:
        errors.append(msg)


def branch_digest(branch_ids: list[str]) -> str:
    payload = "\n".join(branch_ids).encode()
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def resolve_source_chain(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    if ref.get("receipt_sha256_checked") is not True:
        errors.append("source_chain_ref.receipt_sha256_checked must be true")
    rel = ref.get("receipt_path")
    if not rel:
        errors.append("source_chain_ref.receipt_path missing")
        return None
    path = (ROOT / rel).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append(f"source chain path escapes repository root: {rel}")
        return None
    if not path.exists():
        errors.append(f"source chain path missing on disk: {rel}")
        return None
    actual_sha = sha256(path)
    if ref.get("receipt_sha256") != actual_sha:
        errors.append("source_chain_ref.receipt_sha256 mismatch")
    obj = load_json(path)
    if obj.get("schema") != "ward.governance-chain-integrity-receipt.v0":
        errors.append("source_chain_ref must point at a governance-chain-integrity receipt")
    if ref.get("receipt_id") != obj.get("receipt_id"):
        errors.append("source_chain_ref.receipt_id does not match referenced receipt")
    chain_errors = chain_checker.validate_receipt(obj, path)
    if chain_errors:
        errors.append("referenced source chain is invalid: " + "; ".join(chain_errors))
    scope = obj.get("chain_scope") or {}
    decision = obj.get("chain_decision") or {}
    fork = obj.get("fork_resolution") or {}
    mirrors = {
        "observed_state": decision.get("state"),
        "source_chain_digest": (obj.get("chain_digest") or {}).get("computed"),
        "source_release_id": scope.get("source_release_id"),
        "recipient_class": scope.get("recipient_class"),
        "purpose": scope.get("purpose"),
        "projection_policy_digest": scope.get("projection_policy_digest"),
        "source_item_digest": scope.get("source_item_digest"),
        "fork_state": fork.get("fork_state"),
        "branch_count": fork.get("branch_count"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_chain_ref.{field} does not mirror source chain")
    if decision.get("state") not in ELIGIBLE_SOURCE_STATES:
        errors.append("source chain is already canonical or otherwise not eligible for dispute-resolution receipt")
    return obj


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be dispute_resolution_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def scope_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    if source is None:
        return
    scope = receipt.get("resolution_scope") or {}
    source_scope = source.get("chain_scope") or {}
    for field in ["source_release_id", "recipient_class", "purpose", "source_item_digest", "projection_policy_digest"]:
        if scope.get(field) != source_scope.get(field):
            errors.append(f"resolution_scope.{field} must mirror source chain")
    if scope.get("resolution_kind") not in {"fork_resolution", "successor_acceptance_resolution", "quarantine_sustainment", "historical_minimization_resolution", "recheck_resolution"}:
        errors.append("resolution_scope.resolution_kind invalid or missing")
    try:
        parse_time(scope.get("resolution_cut_time"), "resolution_scope.resolution_cut_time")
    except ValueError as exc:
        errors.append(str(exc))


def branch_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    branch = receipt.get("branch_evidence") or {}
    decision = receipt.get("resolution_decision") or {}
    recovered = receipt.get("recovered_head") or {}
    branch_ids = branch.get("branch_ids_observed") or []
    dispositions = branch.get("branch_dispositions") or []
    if not branch_ids:
        errors.append("branch_evidence.branch_ids_observed missing")
    if len(branch_ids) != len(set(branch_ids)):
        errors.append("branch_evidence.branch_ids_observed must be unique")
    if branch.get("branch_ids_digest") != branch_digest(branch_ids):
        errors.append("branch_evidence.branch_ids_digest does not match branch_ids_observed")
    if branch.get("all_branches_observed") is not True:
        errors.append("branch_evidence.all_branches_observed must be true")
    if branch.get("losing_branch_reuse_allowed") is not False:
        errors.append("branch_evidence.losing_branch_reuse_allowed must be false")
    if branch.get("noncanonical_branch_reuse_allowed") is not False:
        errors.append("branch_evidence.noncanonical_branch_reuse_allowed must be false")
    disposition_ids = {d.get("branch_id") for d in dispositions if isinstance(d, dict)}
    if set(branch_ids) != disposition_ids:
        errors.append("branch_evidence.branch_dispositions must cover every observed branch exactly")
    for item in dispositions:
        if item.get("disposition") not in {"selected_current_status_pointer", "rejected_noncanonical", "quarantined", "historical_only", "pending_recheck"}:
            errors.append("branch_evidence branch disposition invalid")
        if item.get("reuse_allowed_without_refresh") is not False:
            errors.append("branch_evidence branch reuse_allowed_without_refresh must be false")
    selected = branch.get("selected_branch_id")
    state = decision.get("state")
    if state == "current_head_recovered":
        if not selected or selected not in branch_ids:
            errors.append("current_head_recovered requires selected_branch_id among observed branches")
        if recovered.get("head_receipt_id") != selected:
            errors.append("recovered_head.head_receipt_id must match selected_branch_id")
    else:
        if selected is not None and state in {"quarantine_sustained", "resolution_recheck_required"}:
            errors.append("quarantine/recheck resolutions must not select a current branch")
    if source is not None:
        fork = source.get("fork_resolution") or {}
        for branch_id in [fork.get("canonical_branch_id"), *(fork.get("competing_branch_ids") or [])]:
            if branch_id and branch_id not in branch_ids:
                errors.append("branch_evidence does not include source chain branch id " + branch_id)


def procedure_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    proc = receipt.get("resolution_procedure") or {}
    scope = receipt.get("resolution_scope") or {}
    decision = receipt.get("resolution_decision") or {}
    required_true = [
        "source_chain_replayed",
        "source_chain_digest_checked",
        "resolver_independence_checked",
        "resolver_conflict_disclosed",
        "release_scope_constant",
        "recipient_scope_constant",
        "purpose_constant",
        "projection_policy_constant_or_declared",
        "source_item_digest_constant",
        "old_status_channel_invalidated",
        "losing_branches_notified",
        "no_source_mutation",
        "no_authority_upgrade",
    ]
    for field in required_true:
        if proc.get(field) is not True:
            errors.append(f"resolution_procedure.{field} must be true")
    if decision.get("state") == "current_head_recovered":
        if proc.get("current_status_rechecked") is not True:
            errors.append("current_head_recovered requires current_status_rechecked")
        if proc.get("successor_acceptance_present") is not True:
            errors.append("current_head_recovered requires successor_acceptance_present")
    if scope.get("resolution_kind") == "successor_acceptance_resolution" and proc.get("successor_acceptance_present") is not True:
        errors.append("successor_acceptance_resolution requires successor_acceptance_present")
    if not proc.get("reason_codes"):
        errors.append("resolution_procedure.reason_codes missing")


def recovered_head_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    head = receipt.get("recovered_head") or {}
    decision = receipt.get("resolution_decision") or {}
    state = decision.get("state")
    if head.get("reuse_allowed_without_refresh") is not False:
        errors.append("recovered_head.reuse_allowed_without_refresh must be false")
    if head.get("source_packet_replay_required") is not True:
        errors.append("recovered_head.source_packet_replay_required must be true")
    if head.get("status_pointer_as_authority") is not False:
        errors.append("recovered_head.status_pointer_as_authority must be false")
    if state == "current_head_recovered":
        if head.get("current_head_published") is not True:
            errors.append("current_head_recovered must publish a recovered current status pointer")
        if not head.get("status_pointer"):
            errors.append("current_head_recovered requires status_pointer")
        if head.get("no_current_head") is not False:
            errors.append("current_head_recovered must set no_current_head false")
        if head.get("old_status_channels_invalidated") is not True:
            errors.append("current_head_recovered requires old_status_channels_invalidated")
    elif state in {"quarantine_sustained", "resolution_recheck_required", "successor_resolution_pending"}:
        if head.get("current_head_published") is not False:
            errors.append("held resolution must not publish current head")
        if head.get("no_current_head") is not True:
            errors.append("held resolution must set no_current_head true")
        if head.get("status_pointer") not in (None, ""):
            errors.append("held resolution must not expose current status pointer")
    elif state == "historical_resolution_recorded":
        if head.get("current_head_published") is not False:
            errors.append("historical resolution must not publish current head")
        if head.get("historical_only") is not True:
            errors.append("historical resolution requires historical_only true")


def notification_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    note = receipt.get("notification_status") or {}
    if note.get("recipients_notified") is not True:
        errors.append("notification_status.recipients_notified must be true")
    if note.get("status_channel_updated") is not True:
        errors.append("notification_status.status_channel_updated must be true")
    if note.get("old_channel_notice_sent") is not True:
        errors.append("notification_status.old_channel_notice_sent must be true")
    if note.get("notification_digests_checked") is not True:
        errors.append("notification_status.notification_digests_checked must be true")
    if not note.get("notice_modes"):
        errors.append("notification_status.notice_modes missing")
    if note.get("recipient_ack_required_for_authority") is not False:
        errors.append("notification_status.recipient_ack_required_for_authority must be false")


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    scope = receipt.get("resolution_scope") or {}
    proj = receipt.get("projection_safety") or {}
    public = scope.get("recipient_class") in PUBLIC_RECIPIENTS or proj.get("projection_class") == "public_minimized"
    if proj.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(proj.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    sensitive_false = [
        "sealed_branch_evidence_inline",
        "reveals_private_org_map",
        "reveals_raw_partner_fragments",
        "reveals_reviewer_identities",
        "reveals_named_private_stewards",
        "reveals_conflict_details_public",
    ]
    for field in sensitive_false:
        if proj.get(field) is not False:
            errors.append(f"projection_safety.{field} must be false")
    if public:
        if proj.get("no_exact_hidden_branch_counts_public") is not True:
            errors.append("public resolution must not reveal exact hidden branch counts")
        if proj.get("branch_details_minimized") is not True:
            errors.append("public resolution must minimize branch details")
        if proj.get("bucketed_or_presence_only_disclosure") is not True:
            errors.append("public resolution requires bucketed or presence-only disclosure")


def effects_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    effects = receipt.get("effect_closure") or {}
    performed = set(effects.get("effects_performed") or [])
    preserved = set(effects.get("forbidden_effects_preserved") or [])
    if effects.get("safe_resolution_effects_only") is not True:
        errors.append("effect_closure.safe_resolution_effects_only must be true")
    if effects.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if effects.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")
    extra = performed - SAFE_RESOLUTION_EFFECTS
    if extra:
        errors.append("effect_closure has non-resolution effects: " + ", ".join(sorted(extra)))
    high = performed & HIGH_CONSEQUENCE_EFFECTS
    if high:
        errors.append("effect_closure performs high consequence effects: " + ", ".join(sorted(high)))
    missing = REQUIRED_FORBIDDEN - preserved
    if missing:
        errors.append("effect_closure missing required forbidden effects: " + ", ".join(sorted(missing)))


def decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    decision = receipt.get("resolution_decision") or {}
    head = receipt.get("recovered_head") or {}
    state = decision.get("state")
    if state not in VALID_DECISION_STATES:
        errors.append("resolution_decision.state invalid or missing")
    if not decision.get("reason_codes"):
        errors.append("resolution_decision.reason_codes missing")
    if decision.get("no_authority_granted") is not True:
        errors.append("resolution_decision.no_authority_granted must be true")
    if decision.get("source_chain_mutated") is not False:
        errors.append("resolution_decision.source_chain_mutated must be false")
    if decision.get("release_reuse_state") not in {"refresh_required", "held_due_to_quarantine", "held_until_successor_acceptance", "historical_only", "recheck_required"}:
        errors.append("resolution_decision.release_reuse_state invalid or missing")
    if state == "current_head_recovered" and decision.get("release_reuse_state") != "refresh_required":
        errors.append("current_head_recovered must require refresh before reuse")
    if state == "quarantine_sustained" and decision.get("release_reuse_state") != "held_due_to_quarantine":
        errors.append("quarantine_sustained must hold reuse due to quarantine")
    if state == "successor_resolution_pending" and decision.get("release_reuse_state") != "held_until_successor_acceptance":
        errors.append("successor_resolution_pending must hold until successor acceptance")
    if state == "historical_resolution_recorded" and decision.get("release_reuse_state") != "historical_only":
        errors.append("historical resolution must be historical_only")
    if state != "current_head_recovered" and head.get("current_head_published") is True:
        errors.append("only current_head_recovered may publish a current head")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    source = resolve_source_chain(receipt.get("source_chain_ref") or {}, errors)
    scope_ok(receipt, source, errors)
    branch_ok(receipt, source, errors)
    procedure_ok(receipt, errors)
    recovered_head_ok(receipt, errors)
    notification_ok(receipt, errors)
    projection_ok(receipt, errors)
    effects_ok(receipt, errors)
    decision_ok(receipt, errors)
    return errors


def main() -> int:
    valid_paths = sorted(RESOLUTION_DIR.glob("*.valid.json"))
    invalid_paths = sorted((RESOLUTION_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance dispute-resolution fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance dispute-resolution fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance dispute-resolution check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance dispute-resolution check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
