#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Any
import sys

from governance_common import (
    ROOT,
    load_json,
    parse_time,
    require,
    run_fixture_checker,
    stable_digest,
    validate_ref,
)

REUSE_GATE_DIR = ROOT / "fixtures" / "governance-reuse-gate"
SCHEMA = "ward.governance-reuse-gate-receipt.v0"
RECEIPT_NAME = "ward.governance.reuse-gate-receipt.v0"
AUTHORITY_SURFACE = "reuse_gate_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}

VALID_STATES = {
    "display_reuse_allowed_refresh_required",
    "internal_review_reuse_allowed",
    "evidence_release_required_hold",
    "high_consequence_refused",
    "receiver_gap_quarantine_hold",
    "invalid_reuse_rejected",
}
SAFE_EFFECTS = {
    "record_reuse_gate_receipt",
    "record_source_convergence_ref",
    "record_consequence_binding",
    "publish_no_authority_reuse_status",
    "allow_public_minimized_display",
    "allow_internal_review_replay",
    "hold_for_evidence_release",
    "refuse_high_consequence_reuse",
    "quarantine_receiver_gap",
    "request_handoff_packet_replay",
    "request_evidence_release_receipt",
    "request_recertification_refresh",
    "mark_reuse_noop",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "approve_export",
    "budget_spend",
    "delegate",
    "export_raw_evidence",
    "force_consumer_action",
    "grant_authority",
    "learning_use",
    "merge_divergent_status_channels",
    "privacy_waiver",
    "promote_global_current_head",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "semantic_repair",
    "status_pointer_update",
    "update_current_head",
    "update_status_pointer",
}
REQUIRED_FORBIDDEN = {
    "action_without_packet",
    "approval_by_convergence",
    "authority_reuse_without_packet",
    "budget_spend",
    "cache_as_authority",
    "cached_head_reuse_without_refresh",
    "convergence_as_authority",
    "delegate_without_warrant",
    "display_reuse_as_export_authority",
    "evidence_release_without_release_receipt",
    "export_without_receipt",
    "future_action",
    "global_status_pointer_update",
    "high_consequence_without_handoff_packet",
    "learning_use",
    "partial_receiver_convergence_as_complete",
    "privacy_waiver_without_packet",
    "receiver_convergence_as_authority",
    "receiver_convergence_as_recertification",
    "receiver_fork_as_current",
    "receiver_gap_hidden",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "reuse_gate_as_authority",
    "reuse_purpose_drift",
    "reuse_without_refresh",
    "sealed_branch_disclosure",
    "semantic_repair_without_warrant",
    "status_pointer_as_grant",
    "unprojected_disclosure",
}
ALLOWED_DISPLAY_EFFECTS = {"public_minimized_display", "status_badge_render", "review_route_hint"}
INTERNAL_REVIEW_EFFECTS = {"internal_review_replay", "internal_audit_note"}
EXPORT_EFFECTS = {"evidence_bundle_release", "dashboard_export", "external_release"}
HIGH_REQUEST_EFFECTS = {"semantic_repair", "action_reenable", "remedy", "budget_spend", "delegate"}


def resolve_source_convergence(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    source = validate_ref(
        ref,
        label="source_convergence_ref",
        expected_schema="ward.governance-receiver-convergence-receipt.v0",
        checker_script=None,
        checker_module_name="ward_receiver_convergence_checker_for_reuse_gate",
        errors=errors,
    )
    if not source:
        return None
    scope = source.get("convergence_scope") or {}
    decision = source.get("convergence_decision") or {}
    summary = source.get("convergence_summary") or {}
    mirrors = {
        "convergence_state": decision.get("state"),
        "cache_reuse_state": decision.get("cache_reuse_state"),
        "recipient_class": scope.get("recipient_class"),
        "purpose": scope.get("purpose"),
        "source_release_id": scope.get("source_release_id"),
        "source_signal_event_key": scope.get("source_signal_event_key"),
        "source_signal_subject_digest": scope.get("source_signal_subject_digest"),
        "cache_subject_digest": scope.get("cache_subject_digest"),
        "receiver_set_digest": scope.get("receiver_set_digest"),
        "overlap_consumer_set_digest": scope.get("overlap_consumer_set_digest"),
        "stale_receivers_remaining": summary.get("stale_receivers_remaining"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_convergence_ref.{field} does not mirror referenced receiver-convergence receipt")
    if decision.get("no_authority_granted") is not True:
        errors.append("referenced receiver-convergence receipt must grant no authority")
    return source


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be reuse_gate_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def request_and_basis_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    ref = receipt.get("source_convergence_ref") or {}
    req = receipt.get("reuse_request") or {}
    basis = receipt.get("basis_checks") or {}
    binding = receipt.get("consequence_binding") or {}
    for field in [
        "request_id",
        "requester_class",
        "requested_purpose",
        "requested_consequence_class",
        "requested_effect",
        "recipient_class",
        "source_release_id",
        "source_signal_event_key",
        "cache_subject_digest",
        "projection_policy_id",
        "request_time",
        "requested_until",
    ]:
        if req.get(field) in (None, ""):
            errors.append(f"reuse_request.{field} missing")
    try:
        start = parse_time(req.get("request_time"), "reuse_request.request_time")
        until = parse_time(req.get("requested_until"), "reuse_request.requested_until")
        if until < start:
            errors.append("reuse_request.requested_until must not precede request_time")
    except ValueError as exc:
        errors.append(str(exc))
    mirrors = {
        "requested_purpose": ref.get("purpose"),
        "recipient_class": ref.get("recipient_class"),
        "source_release_id": ref.get("source_release_id"),
        "source_signal_event_key": ref.get("source_signal_event_key"),
        "cache_subject_digest": ref.get("cache_subject_digest"),
    }
    for field, expected in mirrors.items():
        if req.get(field) != expected:
            errors.append(f"reuse_request.{field} must mirror source_convergence_ref")
    for field in [
        "source_convergence_digest_checked",
        "source_packet_replay_required",
        "receiver_replay_required_before_high_consequence",
        "evidence_release_required_for_export",
        "recertification_required_before_cache_reuse",
        "projection_policy_current_checked",
        "receiver_gap_blocks_reuse",
    ]:
        if field not in basis:
            errors.append(f"basis_checks.{field} missing")
    if basis.get("source_convergence_digest_checked") is not True:
        errors.append("basis_checks.source_convergence_digest_checked must be true")
    if basis.get("source_packet_replay_required") is not True:
        errors.append("basis_checks.source_packet_replay_required must be true")
    if basis.get("receiver_replay_required_before_high_consequence") is not True:
        errors.append("basis_checks.receiver_replay_required_before_high_consequence must be true")
    if basis.get("evidence_release_required_for_export") is not True:
        errors.append("basis_checks.evidence_release_required_for_export must be true")
    if basis.get("recertification_required_before_cache_reuse") is not True:
        errors.append("basis_checks.recertification_required_before_cache_reuse must be true")
    if basis.get("projection_policy_current_checked") is not True:
        errors.append("basis_checks.projection_policy_current_checked must be true")
    source_state = ref.get("convergence_state")
    all_converged = source_state == "all_receivers_converged_refresh_required"
    if basis.get("all_required_receivers_converged") is not all_converged:
        errors.append("basis_checks.all_required_receivers_converged must reflect source convergence state")
    if ref.get("stale_receivers_remaining", 0) not in (0, None):
        if basis.get("receiver_gap_blocks_reuse") is not True:
            errors.append("basis_checks.receiver_gap_blocks_reuse must be true when stale receivers remain")
    for field in [
        "bound_request_id",
        "requested_consequence_class",
        "requested_effect",
        "consequence_scope_digest",
        "max_consequence_allowed",
        "requires_fresh_packet_for_high_consequence",
        "requires_evidence_release_for_export",
        "allows_scope_expansion",
    ]:
        if binding.get(field) in (None, ""):
            errors.append(f"consequence_binding.{field} missing")
    if binding.get("bound_request_id") != req.get("request_id"):
        errors.append("consequence_binding.bound_request_id must equal reuse_request.request_id")
    if binding.get("requested_consequence_class") != req.get("requested_consequence_class"):
        errors.append("consequence_binding.requested_consequence_class must mirror reuse_request")
    if binding.get("requested_effect") != req.get("requested_effect"):
        errors.append("consequence_binding.requested_effect must mirror reuse_request")
    expected_scope = stable_digest({
        "request_id": req.get("request_id"),
        "purpose": req.get("requested_purpose"),
        "recipient_class": req.get("recipient_class"),
        "source_release_id": req.get("source_release_id"),
        "cache_subject_digest": req.get("cache_subject_digest"),
        "requested_consequence_class": req.get("requested_consequence_class"),
        "requested_effect": req.get("requested_effect"),
        "projection_policy_id": req.get("projection_policy_id"),
    })
    if binding.get("consequence_scope_digest") != expected_scope:
        errors.append("consequence_binding.consequence_scope_digest does not match reuse request")
    if binding.get("requires_fresh_packet_for_high_consequence") is not True:
        errors.append("consequence_binding.requires_fresh_packet_for_high_consequence must be true")
    if binding.get("requires_evidence_release_for_export") is not True:
        errors.append("consequence_binding.requires_evidence_release_for_export must be true")
    if binding.get("allows_scope_expansion") is not False:
        errors.append("consequence_binding.allows_scope_expansion must be false")


def summary_and_decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_convergence_ref") or {}
    req = receipt.get("reuse_request") or {}
    summary = receipt.get("gate_summary") or {}
    decision = receipt.get("gate_decision") or {}
    state = decision.get("state")
    effect = req.get("requested_effect")
    consequence_class = req.get("requested_consequence_class")
    if state not in VALID_STATES:
        errors.append("gate_decision.state invalid")
    for field in [
        "source_convergence_as_authority",
        "reuse_gate_as_authority",
        "export_without_release",
        "high_consequence_without_packet",
        "cache_reuse_without_refresh",
        "status_pointer_update_allowed",
        "receiver_gap_hidden",
        "scope_expansion_allowed",
    ]:
        if summary.get(field) is not False:
            errors.append(f"gate_summary.{field} must be false")
    if summary.get("no_authority_granted") is not True:
        errors.append("gate_summary.no_authority_granted must be true")
    if summary.get("source_convergence_state") != ref.get("convergence_state"):
        errors.append("gate_summary.source_convergence_state must mirror source_convergence_ref")
    if summary.get("requested_effect") != effect:
        errors.append("gate_summary.requested_effect must mirror reuse_request")
    if summary.get("requested_consequence_class") != consequence_class:
        errors.append("gate_summary.requested_consequence_class must mirror reuse_request")
    if decision.get("no_authority_granted") is not True:
        errors.append("gate_decision.no_authority_granted must be true")
    for field in ["source_convergence_unmodified", "requires_source_packet_replay_for_consequence"]:
        if decision.get(field) is not True:
            errors.append(f"gate_decision.{field} must be true")
    if decision.get("status_pointer_update_allowed") is not False:
        errors.append("gate_decision.status_pointer_update_allowed must be false")
    if decision.get("scope_expansion_allowed") is not False:
        errors.append("gate_decision.scope_expansion_allowed must be false")
    source_all = ref.get("convergence_state") == "all_receivers_converged_refresh_required"
    stale = ref.get("stale_receivers_remaining") not in (0, None)
    if state == "display_reuse_allowed_refresh_required":
        if not source_all or stale:
            errors.append("display reuse requires all receivers converged and no stale receivers")
        if effect not in ALLOWED_DISPLAY_EFFECTS or consequence_class != "low_public_display":
            errors.append("display reuse state requires low_public_display and a display/review-route effect")
        if decision.get("reuse_allowed") is not True or decision.get("reuse_hold") is not False or decision.get("reuse_refused") is not False:
            errors.append("display reuse state must allow reuse without hold/refusal")
        if decision.get("cache_reuse_state") != "refresh_required":
            errors.append("display reuse state must keep cache_reuse_state refresh_required")
    if state == "internal_review_reuse_allowed":
        if not source_all or stale:
            errors.append("internal review reuse requires all receivers converged and no stale receivers")
        if effect not in INTERNAL_REVIEW_EFFECTS or consequence_class != "internal_review":
            errors.append("internal review state requires internal_review consequence and effect")
        if decision.get("reuse_allowed") is not True:
            errors.append("internal review state must allow reuse")
    if state == "evidence_release_required_hold":
        if effect not in EXPORT_EFFECTS or consequence_class not in {"external_release", "dashboard_export"}:
            errors.append("evidence release hold requires export/release consequence")
        if decision.get("reuse_allowed") is not False or decision.get("reuse_hold") is not True:
            errors.append("evidence release hold must hold rather than allow reuse")
        if decision.get("requires_evidence_release_receipt") is not True:
            errors.append("evidence release hold must require evidence-release receipt")
    if state == "high_consequence_refused":
        if effect not in HIGH_REQUEST_EFFECTS and consequence_class not in {"high_consequence_action", "semantic_repair", "remedy"}:
            errors.append("high-consequence refusal must bind a high-consequence request")
        if decision.get("reuse_refused") is not True or decision.get("reuse_allowed") is not False:
            errors.append("high-consequence refusal must refuse reuse")
        if decision.get("requires_handoff_packet_replay") is not True:
            errors.append("high-consequence refusal must require handoff packet replay")
    if state == "receiver_gap_quarantine_hold":
        if not stale:
            errors.append("receiver-gap hold requires stale receivers remaining")
        if decision.get("reuse_allowed") is not False or decision.get("reuse_hold") is not True:
            errors.append("receiver-gap hold must hold rather than allow reuse")
        if decision.get("cache_reuse_state") != "quarantine_required":
            errors.append("receiver-gap hold must require quarantine")


def closure_projection_effects_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    req = receipt.get("reuse_request") or {}
    closure = receipt.get("gate_closure") or {}
    projection = receipt.get("projection_safety") or {}
    effects = receipt.get("effect_closure") or {}
    expected_bool = {
        "source_convergence_mutated": False,
        "source_convergence_can_grant_authority": False,
        "reuse_gate_can_grant_authority": False,
        "status_pointer_update_allowed": False,
        "requires_source_convergence_ref": True,
        "requires_consequence_scope_digest": True,
        "requires_no_authority_label": True,
        "requires_refresh_before_cache_reuse": True,
        "requires_evidence_release_for_export": True,
        "requires_handoff_packet_for_high_consequence": True,
    }
    for field, expected in expected_bool.items():
        if closure.get(field) is not expected:
            errors.append(f"gate_closure.{field} must be {expected}")
    if projection.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(projection.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    if projection.get("projection_policy_id") != req.get("projection_policy_id"):
        errors.append("projection_safety.projection_policy_id must mirror reuse_request")
    if req.get("recipient_class") in PUBLIC_RECIPIENTS:
        for field in [
            "reveals_receiver_identity_public",
            "reveals_status_channel_private",
            "reveals_named_private_stewards",
            "reveals_private_org_map",
            "reveals_raw_partner_fragments",
            "reveals_recipient_private_contact",
            "sealed_convergence_payload_inline",
            "sealed_signal_payload_inline",
        ]:
            if projection.get(field) is not False:
                errors.append(f"projection_safety.{field} must be false for public recipients")
        if projection.get("hashed_or_class_only_subjects") is not True:
            errors.append("projection_safety.hashed_or_class_only_subjects must be true for public recipients")
    actual_effects = set(effects.get("actual_effects") or [])
    forbidden = set(effects.get("forbidden_effects") or [])
    if not actual_effects:
        errors.append("effect_closure.actual_effects missing")
    unsafe = sorted(actual_effects - SAFE_EFFECTS)
    if unsafe:
        errors.append("effect_closure.actual_effects contains unsupported effects: " + ", ".join(unsafe))
    high = sorted(actual_effects & HIGH_CONSEQUENCE_EFFECTS)
    if high:
        errors.append("effect_closure.actual_effects contains high-consequence effects: " + ", ".join(high))
    missing_forbidden = sorted(REQUIRED_FORBIDDEN - forbidden)
    if missing_forbidden:
        errors.append("effect_closure.forbidden_effects missing required fences: " + ", ".join(missing_forbidden[:8]))
    for field in ["no_authority_upgrade", "no_high_consequence_effects", "safe_reuse_gate_effects_only"]:
        if effects.get(field) is not True:
            errors.append(f"effect_closure.{field} must be true")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    ref = receipt.get("source_convergence_ref")
    source = None
    if not isinstance(ref, dict):
        errors.append("source_convergence_ref must be an object")
    else:
        source = resolve_source_convergence(ref, errors)
    request_and_basis_ok(receipt, source, errors)
    summary_and_decision_ok(receipt, errors)
    closure_projection_effects_ok(receipt, errors)
    return errors


def main() -> int:
    return run_fixture_checker(
        fixture_dir=REUSE_GATE_DIR,
        valid_glob="*.valid.json",
        invalid_glob="*.invalid.json",
        validate_receipt=validate_receipt,
        label="Governance reuse-gate receipt",
    )


if __name__ == "__main__":
    sys.exit(main())
