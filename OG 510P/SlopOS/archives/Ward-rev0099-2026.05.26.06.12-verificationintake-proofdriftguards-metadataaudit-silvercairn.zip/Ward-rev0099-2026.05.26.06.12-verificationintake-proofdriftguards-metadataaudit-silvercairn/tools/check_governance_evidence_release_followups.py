#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
FOLLOWUP_DIR = ROOT / "fixtures" / "governance-evidence-release-followup"

PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}
SAFE_FOLLOWUP_EFFECTS = {
    "record_recipient_ack",
    "issue_refresh_notice",
    "issue_revocation_notice",
    "issue_correction_notice",
    "issue_stale_bundle_quarantine",
    "issue_reuse_refusal",
    "retain_minimized_followup_receipt",
    "mark_release_stale",
    "request_downstream_quarantine",
    "publish_status_pointer",
    "notify_recipient",
    "hold_followup_for_recheck",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "approve_dashboard_export",
    "raw_partner_fragment_export",
    "raw_partner_fragment_access",
    "publish_raw_partner_fragments",
    "waive_privacy",
    "action_reenable",
    "remedy",
    "semantic_repair",
    "budget_spend",
    "delegate",
    "approve",
    "learning_use",
    "reuse_as_authority",
}
FOLLOWUP_KINDS = {
    "recipient_ack",
    "release_refresh",
    "release_revocation",
    "release_correction",
    "stale_bundle_quarantine",
    "reuse_refusal",
    "followup_recheck_hold",
}
FOLLOWUP_ACTIONS = {
    "ack_record_only",
    "refresh_notice_only",
    "revocation_notice_only",
    "correction_notice_only",
    "quarantine_notice_only",
    "reuse_refusal_only",
    "held_recheck_notice_only",
    "none",
}
DRIFT_STATES = {
    "no_drift",
    "release_expired",
    "packet_digest_changed",
    "projection_policy_changed",
    "sealed_omission_changed",
    "owner_map_changed",
    "source_receipt_invalidated",
    "recipient_misuse_reported",
    "downstream_recheck_failed",
    "correction_required",
}
DECISION_STATES = {
    "ack_recorded",
    "release_still_current",
    "refresh_notice_issued",
    "revocation_issued",
    "correction_issued",
    "stale_bundle_quarantined",
    "reuse_refused",
    "followup_held_recheck_required",
}
KIND_TO_STATES = {
    "recipient_ack": {"ack_recorded"},
    "release_refresh": {"release_still_current", "refresh_notice_issued"},
    "release_revocation": {"revocation_issued"},
    "release_correction": {"correction_issued"},
    "stale_bundle_quarantine": {"stale_bundle_quarantined"},
    "reuse_refusal": {"reuse_refused"},
    "followup_recheck_hold": {"followup_held_recheck_required"},
}
KIND_TO_ACTIONS = {
    "recipient_ack": {"ack_record_only"},
    "release_refresh": {"refresh_notice_only", "none"},
    "release_revocation": {"revocation_notice_only"},
    "release_correction": {"correction_notice_only"},
    "stale_bundle_quarantine": {"quarantine_notice_only"},
    "reuse_refusal": {"reuse_refusal_only"},
    "followup_recheck_hold": {"held_recheck_notice_only", "none"},
}
STATUS_ACTIONS = {"revocation_notice_only", "correction_notice_only", "quarantine_notice_only", "reuse_refusal_only", "refresh_notice_only"}


def load_checker(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load checker {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

release_checker = load_checker(ROOT / "tools" / "check_governance_evidence_release_receipts.py", "ward_release_checker")


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_time(value: str | None, field: str) -> datetime:
    if not value:
        raise ValueError(f"{field} missing")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} is not ISO-8601 parseable: {value}") from exc


def require(cond: bool, msg: str, errors: list[str]) -> None:
    if not cond:
        errors.append(msg)


def resolve_release_ref(ref: dict[str, Any], errors: list[str]) -> tuple[dict[str, Any] | None, Path | None]:
    if not isinstance(ref, dict):
        errors.append("source_release_receipt_ref must be an object")
        return None, None
    path_value = ref.get("receipt_path")
    if not path_value:
        errors.append("source_release_receipt_ref.receipt_path missing")
        return None, None
    path = (ROOT / path_value).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append("source_release_receipt_ref.receipt_path escapes repository root")
        return None, None
    if not path.exists():
        errors.append(f"source_release_receipt_ref.receipt_path missing on disk: {path_value}")
        return None, None
    actual = sha256(path)
    if ref.get("receipt_sha256") != actual:
        errors.append("source_release_receipt_ref.receipt_sha256 does not match release receipt bytes")
    obj = load_json(path)
    if ref.get("receipt_id") != obj.get("receipt_id"):
        errors.append("source_release_receipt_ref.receipt_id does not match referenced release")
    release_errors = release_checker.validate_receipt(obj, path)
    if release_errors:
        errors.append("referenced evidence-release receipt is invalid: " + "; ".join(release_errors))
    return obj, path


def request_ok(receipt: dict[str, Any], release: dict[str, Any], errors: list[str]) -> str | None:
    req = receipt.get("followup_request") or {}
    kind = req.get("followup_kind")
    require(kind in FOLLOWUP_KINDS, "followup_request.followup_kind invalid or missing", errors)
    for field in ["request_id", "requester", "recipient_class", "purpose", "trigger", "issued_at", "response_due_at"]:
        require(bool(req.get(field)), f"followup_request.{field} missing", errors)
    if release:
        rel_req = release.get("release_request") or {}
        if req.get("recipient_class") != rel_req.get("recipient_class"):
            errors.append("followup_request.recipient_class does not match source release")
        if req.get("purpose") != rel_req.get("purpose"):
            errors.append("followup_request.purpose does not match source release purpose")
    try:
        parse_time(req.get("issued_at"), "followup_request.issued_at")
        parse_time(req.get("response_due_at"), "followup_request.response_due_at")
    except ValueError as exc:
        errors.append(str(exc))
    return kind


def source_state_ok(receipt: dict[str, Any], release: dict[str, Any], errors: list[str]) -> None:
    state = receipt.get("source_release_state") or {}
    if state.get("source_receipt_sha256_checked") is not True:
        errors.append("source_release_state.source_receipt_sha256_checked must be true")
    if state.get("no_authority_upgrade") is not True:
        errors.append("source_release_state.no_authority_upgrade must be true")
    if not release:
        return
    rel_req = release.get("release_request") or {}
    rel_dec = release.get("release_decision") or {}
    rel_manifest = release.get("payload_manifest") or {}
    mirrors = {
        "source_release_id": release.get("receipt_id"),
        "release_decision_state": rel_dec.get("state"),
        "release_expires_at": rel_req.get("expires_at"),
        "release_recipient_class": rel_req.get("recipient_class"),
        "release_purpose": rel_req.get("purpose"),
        "source_item_digest": rel_manifest.get("item_digest"),
        "projection_policy_digest": rel_req.get("projection_policy_digest"),
    }
    for field, expected in mirrors.items():
        if state.get(field) != expected:
            errors.append(f"source_release_state.{field} does not mirror source release")


def trigger_ok(receipt: dict[str, Any], release: dict[str, Any], kind: str | None, receipt_time: datetime | None, errors: list[str]) -> str | None:
    trig = receipt.get("trigger_basis") or {}
    drift = trig.get("source_drift_state")
    require(drift in DRIFT_STATES, "trigger_basis.source_drift_state invalid or missing", errors)
    require(bool(trig.get("basis_digest")), "trigger_basis.basis_digest missing", errors)
    require(bool(trig.get("reason_codes")), "trigger_basis.reason_codes missing", errors)
    if trig.get("detected_after_release") is not True:
        errors.append("trigger_basis.detected_after_release must be true")
    try:
        trigger_time = parse_time(trig.get("trigger_time"), "trigger_basis.trigger_time")
        release_time = parse_time(release.get("receipt_time"), "source release receipt_time") if release else None
        if release_time and trigger_time < release_time:
            errors.append("trigger_basis.trigger_time predates source release")
    except ValueError as exc:
        errors.append(str(exc))
        trigger_time = None
    if kind in {"release_revocation", "release_correction", "stale_bundle_quarantine", "reuse_refusal"} and drift == "no_drift":
        errors.append(f"{kind} requires a non-no_drift trigger")
    if kind == "recipient_ack" and drift != "no_drift":
        errors.append("recipient_ack must not smuggle drift handling into an acknowledgment")
    if drift == "release_expired" and release:
        try:
            expiry = parse_time((release.get("release_request") or {}).get("expires_at"), "source release expires_at")
            if trigger_time and trigger_time <= expiry:
                errors.append("release_expired trigger must occur after source release expiry")
        except ValueError as exc:
            errors.append(str(exc))
    return drift


def notice_ok(receipt: dict[str, Any], release: dict[str, Any], kind: str | None, errors: list[str]) -> None:
    notice = receipt.get("recipient_notice") or {}
    for field in ["recipient_bound", "purpose_bound", "channel_matches_release", "no_authority_label_present"]:
        if notice.get(field) is not True:
            errors.append(f"recipient_notice.{field} must be true")
    if notice.get("notice_required") is True and notice.get("notice_sent") is not True:
        errors.append("recipient_notice.notice_sent must be true when notice_required is true")
    if notice.get("notice_required") is True and not notice.get("notification_channel"):
        errors.append("recipient_notice.notification_channel missing for required notice")
    if kind in {"release_revocation", "release_correction", "stale_bundle_quarantine", "reuse_refusal"} and notice.get("notice_required") is not True:
        errors.append(f"{kind} requires recipient notice")
    ack_state = notice.get("ack_state")
    if ack_state not in {"not_required", "pending", "received", "refused", "overdue"}:
        errors.append("recipient_notice.ack_state invalid or missing")
    if notice.get("ack_required") is True:
        if not notice.get("ack_time"):
            errors.append("recipient_notice.ack_time missing when ack_required is true")
        else:
            try:
                ack_time = parse_time(notice.get("ack_time"), "recipient_notice.ack_time")
                release_time = parse_time(release.get("receipt_time"), "source release receipt_time") if release else None
                if release_time and ack_time < release_time:
                    errors.append("recipient_notice.ack_time predates source release")
            except ValueError as exc:
                errors.append(str(exc))
    if kind == "recipient_ack" and (notice.get("ack_required") is not True or ack_state != "received"):
        errors.append("recipient_ack requires ack_required=true and ack_state=received")
    label = str(notice.get("watermark_label") or "").lower()
    if "not authority" not in label and "no authority" not in label:
        errors.append("recipient_notice.watermark_label must visibly say the follow-up is not authority")


def payload_ok(receipt: dict[str, Any], release: dict[str, Any], kind: str | None, drift: str | None, errors: list[str]) -> str | None:
    payload = receipt.get("payload_update") or {}
    action = payload.get("followup_action")
    require(action in FOLLOWUP_ACTIONS, "payload_update.followup_action invalid or missing", errors)
    if kind and action not in KIND_TO_ACTIONS.get(kind, set()):
        errors.append(f"payload_update.followup_action {action} is inconsistent with {kind}")
    if release and payload.get("supersedes_release_id") != release.get("receipt_id"):
        errors.append("payload_update.supersedes_release_id does not match source release")
    if payload.get("original_release_mutated") is True:
        errors.append("payload_update must not mutate original immutable release receipt")
    if action in STATUS_ACTIONS:
        if not payload.get("status_pointer"):
            errors.append("payload_update.status_pointer missing for status-bearing follow-up")
        if payload.get("stale_artifact_label") is not True:
            errors.append("payload_update.stale_artifact_label must be true for status-bearing follow-up")
    if kind == "release_correction":
        if not payload.get("field_delta_digest"):
            errors.append("release_correction requires payload_update.field_delta_digest")
        if payload.get("omission_delta_disclosed") is not True:
            errors.append("release_correction requires payload_update.omission_delta_disclosed=true")
    if drift == "sealed_omission_changed" and payload.get("omission_delta_disclosed") is not True:
        errors.append("sealed_omission_changed requires omission_delta_disclosed=true")
    recipient = (release.get("release_request") or {}).get("recipient_class") if release else None
    if recipient in PUBLIC_RECIPIENTS:
        if payload.get("contains_sensitive_evidence") is True:
            errors.append("public follow-up payload contains sensitive evidence")
        if payload.get("exact_hidden_counts_released") is True:
            errors.append("public follow-up payload releases exact hidden counts")
    if payload.get("reuse_allowed_without_refresh") is True:
        errors.append("payload_update allows reuse without refresh")
    return action


def effects_ok(receipt: dict[str, Any], release: dict[str, Any], errors: list[str]) -> None:
    closure = receipt.get("effect_closure") or {}
    effects = set(closure.get("effects_performed") or [])
    if closure.get("safe_followup_effects_only") is not True:
        errors.append("effect_closure.safe_followup_effects_only must be true")
    if closure.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if closure.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")
    high = effects & HIGH_CONSEQUENCE_EFFECTS
    if high:
        errors.append("evidence-release follow-up performs high-consequence effects: " + ", ".join(sorted(high)))
    unsafe = effects - SAFE_FOLLOWUP_EFFECTS
    if unsafe:
        errors.append("evidence-release follow-up performs unsupported effects: " + ", ".join(sorted(unsafe)))
    preserved = set(closure.get("forbidden_effects_preserved") or [])
    source_forbidden = set(((release.get("effect_closure") or {}).get("forbidden_effects_preserved") or [])) if release else set()
    missing = source_forbidden - preserved
    if missing:
        errors.append("effect_closure drops source release forbidden effects: " + ", ".join(sorted(missing)))


def decision_ok(receipt: dict[str, Any], release: dict[str, Any], kind: str | None, drift: str | None, action: str | None, receipt_time: datetime | None, errors: list[str]) -> None:
    decision = receipt.get("followup_decision") or {}
    state = decision.get("state")
    if state not in DECISION_STATES:
        errors.append("followup_decision.state invalid or missing")
    if kind and state not in KIND_TO_STATES.get(kind, set()):
        errors.append(f"followup_decision.state {state} is inconsistent with {kind}")
    if not decision.get("reason_codes"):
        errors.append("followup_decision.reason_codes missing")
    if decision.get("no_authority_granted") is not True:
        errors.append("followup_decision.no_authority_granted must be true")
    if state == "release_still_current" and drift != "no_drift":
        errors.append("release_still_current requires trigger_basis.source_drift_state=no_drift")
    if release and receipt_time and state == "release_still_current":
        try:
            expiry = parse_time((release.get("release_request") or {}).get("expires_at"), "source release expires_at")
            if receipt_time >= expiry:
                errors.append("expired source release cannot be marked release_still_current")
        except ValueError as exc:
            errors.append(str(exc))
    if state in {"revocation_issued", "correction_issued", "stale_bundle_quarantined", "reuse_refused"} and action == "none":
        errors.append("state requires a visible follow-up action")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    require(receipt.get("schema") == "ward.governance-evidence-release-followup-receipt.v0", "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == "ward.governance.evidence-release-followup-receipt.v0", "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == "evidence_release_followup_receipt_only", "authority_surface must be evidence_release_followup_receipt_only", errors)
    try:
        receipt_time = parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))
        receipt_time = None
    release, _ = resolve_release_ref(receipt.get("source_release_receipt_ref"), errors)
    kind = request_ok(receipt, release or {}, errors)
    source_state_ok(receipt, release or {}, errors)
    drift = trigger_ok(receipt, release or {}, kind, receipt_time, errors)
    notice_ok(receipt, release or {}, kind, errors)
    action = payload_ok(receipt, release or {}, kind, drift, errors)
    effects_ok(receipt, release or {}, errors)
    decision_ok(receipt, release or {}, kind, drift, action, receipt_time, errors)
    return errors


def main() -> int:
    valid_paths = sorted(FOLLOWUP_DIR.glob("*.valid.json"))
    invalid_paths = sorted((FOLLOWUP_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance evidence-release follow-up fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance evidence-release follow-up fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance evidence-release follow-up check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance evidence-release follow-up check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
