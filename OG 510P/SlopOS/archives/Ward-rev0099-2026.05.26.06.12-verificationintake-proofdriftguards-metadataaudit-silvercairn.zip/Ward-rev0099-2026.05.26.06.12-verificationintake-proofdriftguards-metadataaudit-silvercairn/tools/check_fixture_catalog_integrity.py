#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    errors: list[str] = []
    registry = load_json(ROOT / "tools" / "governance_checker_registry.json")
    fixture_entries = [e for e in registry.get("entries", []) if e.get("fixture_dir")]
    for entry in fixture_entries:
        fid = entry.get("id")
        fixture_dir = ROOT / entry["fixture_dir"]
        schema_id = entry.get("schema_id")
        if not fixture_dir.exists():
            errors.append(f"{fid}: fixture directory missing")
            continue
        direct_valid = sorted(fixture_dir.glob("*.valid.json"))
        direct_invalid = sorted(fixture_dir.glob("*.invalid.json"))
        negative_dir = fixture_dir / "negative"
        negative_invalid = sorted(negative_dir.glob("*.invalid.json")) if negative_dir.exists() else []
        negative_valid = sorted(negative_dir.glob("*.valid.json")) if negative_dir.exists() else []
        if not direct_valid:
            errors.append(f"{fid}: no direct positive *.valid.json fixtures")
        if direct_invalid:
            errors.append(f"{fid}: invalid fixtures must live under negative/: " + ", ".join(p.name for p in direct_invalid[:5]))
        if not negative_dir.exists():
            errors.append(f"{fid}: negative/ directory missing")
        if not negative_invalid:
            errors.append(f"{fid}: no negative/*.invalid.json fixtures")
        if negative_valid:
            errors.append(f"{fid}: positive fixtures must not live under negative/: " + ", ".join(p.name for p in negative_valid[:5]))
        for path in direct_valid + negative_invalid:
            rel = str(path.relative_to(ROOT))
            if not re.fullmatch(r"[a-z0-9][a-z0-9\-]*(\.valid|\.invalid)\.json", path.name):
                errors.append(f"{fid}: fixture filename is not slugged: {rel}")
            try:
                obj = load_json(path)
            except Exception as exc:
                errors.append(f"{fid}: fixture is not parseable JSON: {rel}: {exc}")
                continue
            if obj.get("schema") != schema_id:
                errors.append(f"{fid}: fixture schema drift in {rel}: {obj.get('schema')} != {schema_id}")
            # Older early-pass fixtures predate uniform receipt_id / authority_surface fields.
            # Schema parity and layout are mandatory here; semantic field requirements stay in family checkers.
            if path.suffix != ".json":
                errors.append(f"{fid}: fixture suffix must be .json: {rel}")
        # Allow explicitly nested support fixtures only when their directory is not negative.
        support_json = [p for p in fixture_dir.rglob("*.json") if p not in direct_valid and p not in negative_invalid]
        for path in support_json:
            parts = path.relative_to(fixture_dir).parts
            if parts and parts[0] == "negative":
                errors.append(f"{fid}: unsupported JSON under negative/: {path.relative_to(ROOT)}")
    if errors:
        print("Fixture catalog integrity check failed.")
        for err in errors:
            print(" -", err)
        return 1
    print(f"Fixture catalog integrity check passed ({len(fixture_entries)} fixture-backed families audited).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
