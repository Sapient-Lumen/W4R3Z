#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_AUDIT_TOOLS = {
    "check_repo_hygiene.py",
    "check_doc_index_integrity.py",
    "check_fixture_catalog_integrity.py",
    "check_schema_catalog_integrity.py",
    "check_tool_runbook_integrity.py",
    "check_metadata_lineage_integrity.py",
    "check_governance_suite.py",
}


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    errors: list[str] = []
    tools_readme = (ROOT / "tools" / "README.md").read_text(encoding="utf-8")
    makefile = (ROOT / "Makefile").read_text(encoding="utf-8")
    registry = load_json(ROOT / "tools" / "governance_checker_registry.json")
    registry_scripts = {entry.get("script") for entry in registry.get("entries", []) if entry.get("script")}
    tool_files = {path.name for path in (ROOT / "tools").glob("check_*.py")}

    missing_registered = sorted(script for script in registry_scripts if script not in tools_readme)
    if missing_registered:
        errors.append("tools/README.md missing registered governance checkers: " + ", ".join(missing_registered))

    missing_audits = sorted(script for script in REQUIRED_AUDIT_TOOLS if script not in tools_readme)
    if missing_audits:
        errors.append("tools/README.md missing required audit/runbook tools: " + ", ".join(missing_audits))

    missing_on_disk = sorted((registry_scripts | REQUIRED_AUDIT_TOOLS) - tool_files)
    if missing_on_disk:
        errors.append("registered/audited tools missing on disk: " + ", ".join(missing_on_disk))

    missing_make = sorted(script for script in REQUIRED_AUDIT_TOOLS if script not in makefile and script != "check_governance_suite.py")
    if "check_governance_suite.py" not in makefile:
        missing_make.append("check_governance_suite.py")
    if missing_make:
        errors.append("Makefile check target missing required audit/runbook tools: " + ", ".join(missing_make))

    bullets = re.findall(r"^- `([^`]+\.py)`", tools_readme, flags=re.MULTILINE)
    duplicate_bullets = sorted({b for b in bullets if bullets.count(b) > 1})
    if duplicate_bullets:
        errors.append("tools/README.md has duplicate tool bullets: " + ", ".join(duplicate_bullets))

    if errors:
        print("Tool runbook integrity check failed.")
        for err in errors:
            print(" -", err)
        return 1
    print(f"Tool runbook integrity check passed ({len(registry_scripts)} registered governance scripts and {len(REQUIRED_AUDIT_TOOLS)} runbook tools checked).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
