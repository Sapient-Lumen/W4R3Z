#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
CONTINUITY_DIR = ROOT / "fixtures" / "governance-search-continuity"
PUBLIC_VIEWS = {"public", "external", "partner_public", "public_redacted"}
SAFE_EFFECTS = {"render", "show_page", "navigate_search", "request_recheck", "open_review", "retain_minimized_receipt", "disclose_presence_only", "disclose_bucketed_count", "disclose_noisy_count"}
HIGH_CONSEQUENCE_EFFECTS = {"export", "repair", "semantic_change", "action_reenable", "remedy", "learning_use", "budget_spend", "delegate", "approve"}
DRIFT_KEYS = [
    "query_digest_unchanged",
    "request_fingerprint_unchanged",
    "projection_policy_unchanged",
    "owner_map_epoch_unchanged",
    "packet_compaction_watermark_unchanged",
]
SENSITIVE_REASON_CLASSES = {"private_org_map", "reviewer_identity", "incident_detail", "partner_fragment", "named_conflict", "sealed_person"}

spec = importlib.util.spec_from_file_location("ward_batch_checker", ROOT / "tools" / "check_governance_batch_search_receipts.py")
if spec is None or spec.loader is None:
    raise RuntimeError("Could not load batch/search checker")
ward_batch_checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ward_batch_checker)


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_time(value: str | None, field: str) -> datetime:
    if not value:
        raise ValueError(f"{field} missing")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} is not ISO-8601 parseable: {value}") from exc


def require(cond: bool, msg: str, errors: list[str]) -> None:
    if not cond:
        errors.append(msg)


def resolve_batch_ref(ref: dict[str, Any], errors: list[str], label: str) -> dict[str, Any] | None:
    if not isinstance(ref, dict):
        errors.append(f"{label} must be an object")
        return None
    path_value = ref.get("receipt_path")
    if not path_value:
        errors.append(f"{label}.receipt_path missing")
        return None
    path = (ROOT / path_value).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append(f"{label}.receipt_path escapes repository root")
        return None
    if not path.exists():
        errors.append(f"{label}.receipt_path missing on disk: {path_value}")
        return None
    actual = sha256(path)
    if ref.get("receipt_sha256") != actual:
        errors.append(f"{label}.receipt_sha256 does not match receipt bytes")
    receipt = load_json(path)
    if ref.get("receipt_id") != receipt.get("receipt_id"):
        errors.append(f"{label}.receipt_id does not match referenced receipt")
    batch_errors = ward_batch_checker.validate_receipt(receipt, path)
    if batch_errors:
        errors.append(f"{label} references invalid batch/search receipt: " + "; ".join(batch_errors))
    return receipt


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    projection = receipt.get("projection_safety") or {}
    view = projection.get("view")
    if view in PUBLIC_VIEWS:
        if projection.get("contains_sensitive_evidence") is not False:
            errors.append("public/external search-continuity receipt contains sensitive evidence")
        if projection.get("sealed_evidence_inline") is not False:
            errors.append("public/external search-continuity receipt inlines sealed evidence")
        for flag in ["reveals_private_org_map", "reveals_raw_partner_fragments", "reveals_reviewer_identities", "reveals_incident_details"]:
            if projection.get(flag) is not False:
                errors.append(f"public/external search-continuity receipt leaks {flag}")


def sealed_omissions_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    sealed = receipt.get("sealed_omissions") or {}
    projection = receipt.get("projection_safety") or {}
    view = projection.get("view")
    mode = sealed.get("disclosure_mode")
    if mode not in {"none", "presence_only", "bucketed_range", "dp_noisy_count"}:
        errors.append("sealed_omissions.disclosure_mode invalid or missing")
        return
    if sealed.get("sealed_rows_present") is False and mode != "none":
        errors.append("sealed_omissions mode must be none when no sealed rows are present")
    if sealed.get("sealed_rows_present") is True:
        for field in ["details_redacted", "existence_oracle_guard", "no_per_subject_breakdown"]:
            if sealed.get(field) is not True:
                errors.append(f"sealed_omissions.{field} must be true when sealed rows are present")
    if view in PUBLIC_VIEWS:
        if mode == "exact_count" or "exact_count" in sealed:
            errors.append("public/external sealed omissions cannot disclose exact_count")
        if sealed.get("details_redacted") is not True and sealed.get("sealed_rows_present") is True:
            errors.append("public/external sealed omissions must redact details")
        if sealed.get("existence_oracle_guard") is not True and sealed.get("sealed_rows_present") is True:
            errors.append("public/external sealed omissions require existence_oracle_guard=true")
        if sealed.get("no_per_subject_breakdown") is not True and sealed.get("sealed_rows_present") is True:
            errors.append("public/external sealed omissions cannot expose per-subject breakdowns")
        sensitive_reasons = set(sealed.get("reason_classes") or []) & SENSITIVE_REASON_CLASSES
        if sensitive_reasons:
            errors.append("public/external sealed omission reason_classes leak sensitive categories: " + ", ".join(sorted(sensitive_reasons)))
    if mode == "bucketed_range":
        if not sealed.get("bucketed_count"):
            errors.append("bucketed_range disclosure requires sealed_omissions.bucketed_count")
        if (sealed.get("min_bucket_size") or 0) < 5:
            errors.append("bucketed_range disclosure requires min_bucket_size >= 5")
    if mode == "dp_noisy_count":
        for field in ["privacy_budget_ref", "privacy_unit", "noise_model", "composition_window"]:
            if not sealed.get(field):
                errors.append(f"dp_noisy_count disclosure requires sealed_omissions.{field}")
        if not isinstance(sealed.get("epsilon_max"), (int, float)) or sealed.get("epsilon_max") <= 0:
            errors.append("dp_noisy_count disclosure requires positive epsilon_max")
        if sealed.get("no_exact_count_fallback") is not True:
            errors.append("dp_noisy_count disclosure requires no_exact_count_fallback=true")
    if sealed.get("count_basis") == "raw_authority_count":
        errors.append("sealed_omissions.count_basis cannot be raw_authority_count")


def continuity_ok(receipt: dict[str, Any], previous_batch: dict[str, Any] | None, current_batch: dict[str, Any] | None, errors: list[str]) -> None:
    request = receipt.get("request") or {}
    basis = receipt.get("continuity_basis") or {}
    drift = receipt.get("drift_response") or {}
    for field in ["operation", "query_digest", "request_fingerprint", "projection_policy_digest", "cursor_token"]:
        if not request.get(field):
            errors.append(f"request.{field} missing")
    if request.get("kind") != "search_continuation":
        errors.append("request.kind must be search_continuation")
    if not isinstance(request.get("page_index"), int) or request.get("page_index") < 1:
        errors.append("request.page_index must be an integer >= 1")
    for field in ["cursor_binds_query_digest", "cursor_binds_projection_policy_digest", "cursor_binds_prior_receipt_digest"]:
        if request.get(field) is not True:
            errors.append(f"request.{field} must be true")
    if request.get("cursor_expires_at"):
        try:
            parse_time(request.get("cursor_expires_at"), "request.cursor_expires_at")
        except ValueError as exc:
            errors.append(str(exc))
    if request.get("page_index", 1) > 1 and previous_batch is None:
        errors.append("page_index > 1 requires previous_batch_search_receipt_ref")
    if current_batch:
        current_request = current_batch.get("request") or {}
        if current_request.get("query_digest") != request.get("query_digest"):
            errors.append("current batch/search receipt query_digest does not match continuity request")
        if current_request.get("operation") != request.get("operation"):
            errors.append("current batch/search receipt operation does not match continuity request")
    if previous_batch and request.get("continuation_claimed_from_previous_query", True):
        previous_request = previous_batch.get("request") or {}
        if basis.get("query_digest_unchanged") is True and previous_request.get("query_digest") != request.get("query_digest"):
            errors.append("basis claims query_digest unchanged but previous batch query_digest differs")
    for key in DRIFT_KEYS:
        if basis.get(key) is not True and basis.get(key) is not False:
            errors.append(f"continuity_basis.{key} must be boolean")
    if basis.get("prior_digest_chained") is not True:
        errors.append("continuity_basis.prior_digest_chained must be true")
    drift_detected = basis.get("drift_detected") or []
    if not isinstance(drift_detected, list):
        errors.append("continuity_basis.drift_detected must be a list")
        drift_detected = []
    any_basis_changed = any(basis.get(key) is False for key in DRIFT_KEYS) or bool(drift_detected)
    state = drift.get("state")
    if state not in {"continued_same_snapshot", "held_recheckpoint_required", "new_receipt_issued", "new_search_required"}:
        errors.append("drift_response.state invalid or missing")
    if drift.get("no_authority_upgrade") is not True:
        errors.append("drift_response.no_authority_upgrade must be true")
    if state == "continued_same_snapshot":
        if any_basis_changed:
            errors.append("continued_same_snapshot is forbidden when any continuity basis drift is detected")
        if basis.get("continuation_claimed") is not True:
            errors.append("continued_same_snapshot requires continuity_basis.continuation_claimed=true")
    else:
        if not any_basis_changed:
            errors.append("held/new-search drift_response state requires at least one basis drift")
        if basis.get("continuation_claimed") is not False:
            errors.append("drifted search must not claim same continuation")
        if not drift.get("reason_codes"):
            errors.append("drifted search requires drift_response.reason_codes")
    if any_basis_changed and state == "continued_same_snapshot":
        errors.append("basis drift cannot be rendered as a normal continuation")


def completeness_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    sealed = receipt.get("sealed_omissions") or {}
    completeness = receipt.get("completeness") or {}
    if completeness.get("partial_results_disclosed") is not True:
        errors.append("completeness.partial_results_disclosed must be true")
    if completeness.get("omission_basis_visible") is not True:
        errors.append("completeness.omission_basis_visible must be true")
    total_omissions = (completeness.get("omitted_due_to_projection_count_visible") or 0) + (completeness.get("omitted_due_to_replay_count_visible") or 0)
    if sealed.get("sealed_rows_present") is True:
        total_omissions += 1
    if total_omissions > 0 and completeness.get("complete_result_claimed") is True:
        errors.append("receipt claims complete_result while omissions or sealed rows are present")


def effects_ok(receipt: dict[str, Any], current_batch: dict[str, Any] | None, errors: list[str]) -> None:
    effect = receipt.get("effect_closure") or {}
    effects = set(effect.get("effects_performed") or [])
    if effect.get("safe_effects_only") is not True:
        errors.append("effect_closure.safe_effects_only must be true")
    if effect.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if effect.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")
    high = effects & HIGH_CONSEQUENCE_EFFECTS
    if high:
        errors.append("search-continuity receipt performs high-consequence effects: " + ", ".join(sorted(high)))
    unsafe = effects - SAFE_EFFECTS
    if unsafe:
        errors.append("search-continuity receipt performs unsupported effects: " + ", ".join(sorted(unsafe)))
    state_summary = receipt.get("state_summary") or {}
    if state_summary.get("authority_count_claimed") is True:
        errors.append("state_summary.authority_count_claimed must be false")
    if state_summary.get("states_preserved_from_current_batch") is not True:
        errors.append("state_summary.states_preserved_from_current_batch must be true")
    if current_batch:
        result_state = (current_batch.get("aggregation") or {}).get("result_state")
        if state_summary.get("current_batch_result_state") != result_state:
            errors.append("state_summary.current_batch_result_state does not mirror current batch aggregation.result_state")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    require(receipt.get("schema") == "ward.governance-search-continuity-receipt.v0", "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == "ward.governance.search-continuity-receipt.v0", "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == "search_continuity_receipt_only", "authority_surface must be search_continuity_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))

    page_refs = receipt.get("page_receipts") or {}
    previous_batch = None
    if page_refs.get("previous_batch_search_receipt_ref"):
        previous_batch = resolve_batch_ref(page_refs.get("previous_batch_search_receipt_ref"), errors, "previous_batch_search_receipt_ref")
    current_batch = resolve_batch_ref(page_refs.get("current_batch_search_receipt_ref"), errors, "current_batch_search_receipt_ref")

    continuity_ok(receipt, previous_batch, current_batch, errors)
    projection_ok(receipt, errors)
    sealed_omissions_ok(receipt, errors)
    completeness_ok(receipt, errors)
    effects_ok(receipt, current_batch, errors)
    return errors


def main() -> int:
    valid_paths = sorted(CONTINUITY_DIR.glob("*.valid.json"))
    invalid_paths = sorted((CONTINUITY_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance search-continuity fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance search-continuity fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance search-continuity receipt check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance search-continuity receipt check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
