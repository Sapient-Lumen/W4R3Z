#!/usr/bin/env python3
"""Ward governance decision consumer receipt fixture checker.

This checker verifies pass LXXXI's rule: a downstream consumer may render,
retain, attach, or schedule work from a governance decision event only when it
keeps the event digest-bound, preserves weakness and forbidden effects, and
records replay/compaction posture. It is intentionally not a general event bus.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import importlib.util
import json
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
RECEIPT_DIR = ROOT / "fixtures" / "governance-decision-consumer"
EVENT_CHECKER = ROOT / "tools" / "check_governance_decision_events.py"

spec = importlib.util.spec_from_file_location("ward_event_checker", EVENT_CHECKER)
event_checker = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(event_checker)
validate_event = event_checker.validate_event
parse_time = event_checker.parse_time

HIGH_CONSEQUENCE_EFFECTS = {
    "approve_dashboard_export",
    "reenable_action",
    "approve_remedy",
    "waive_privacy",
    "publish_raw_partner_fragments",
    "raw_partner_fragment_access",
    "emergency_raw_partner_fragment_access",
    "approve_recompute_budget",
}
SAFE_HISTORICAL_EFFECTS = {
    "retain_minimized_receipt",
    "render_historical_badge",
    "attach_historical_receipt",
    "open_review_request",
    "record_replay_diff",
}
PUBLIC_VIEWS = {"public", "external"}
SENSITIVE_FLAGS = {
    "reveals_sealed_conflict_details",
    "reveals_raw_partner_fragments",
    "reveals_reviewer_identities",
    "reveals_private_org_map",
    "reveals_incident_details",
}
ALLOWED_STATUS = {"replayed_current", "downgraded_historical", "held_pending_packet"}
ALLOWED_CONSUMER_STATES = {
    "routing_hint_only",
    "review_only",
    "needs_rehydration",
    "authority_missing",
    "handoff_unaccepted",
    "expired_warrant",
    "privacy_projection_block",
    "agent_boundary_violation",
    "consequence_grade",
    "refuse",
    "historical_receipt_only",
}


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text())
    except Exception as exc:  # pragma: no cover
        raise ValueError(f"{path}: cannot parse JSON: {exc}") from exc


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def resolve_event(receipt: dict[str, Any], errors: list[str]) -> tuple[dict[str, Any] | None, Path | None]:
    ref = receipt.get("event_ref") or {}
    event_path_value = ref.get("event_path")
    require(bool(ref.get("event_id")), "event_ref.event_id missing", errors)
    require(bool(event_path_value), "event_ref.event_path missing", errors)
    require(bool(ref.get("event_sha256")), "event_ref.event_sha256 missing", errors)
    if not event_path_value:
        return None, None
    event_path = (ROOT / event_path_value).resolve()
    try:
        event_path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append("event_ref.event_path escapes repository root")
        return None, None
    if not event_path.exists():
        errors.append(f"event_ref.event_path missing on disk: {event_path_value}")
        return None, None
    actual_digest = sha256(event_path)
    if ref.get("event_sha256") != actual_digest:
        errors.append("event_ref.event_sha256 does not match event bytes")
    event = load_json(event_path)
    if ref.get("event_id") != event.get("event_id"):
        errors.append("event_ref.event_id does not match event event_id")
    event_errors = validate_event(event, event_path)
    if event_errors:
        errors.append("referenced governance decision event is not valid: " + "; ".join(event_errors))
    return event, event_path


def state_not_stronger(event_state: str, consumer_state: str) -> bool:
    if event_state == consumer_state:
        return True
    if consumer_state in {"review_only", "needs_rehydration", "authority_missing", "refuse", "historical_receipt_only"}:
        return True
    if event_state == "routing_hint_only" and consumer_state == "routing_hint_only":
        return True
    return False


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    projection = receipt.get("projection") or {}
    view = projection.get("view")
    if view in PUBLIC_VIEWS:
        if projection.get("contains_sensitive_evidence") is True:
            errors.append("public/external consumer receipt contains sensitive evidence")
        if projection.get("sealed_evidence_inline") is True:
            errors.append("public/external consumer receipt inlines sealed evidence")
        for flag in SENSITIVE_FLAGS:
            if projection.get(flag) is True:
                errors.append(f"public/external consumer receipt leaks {flag}")


def compaction_guard_ok(receipt: dict[str, Any], replay_status: str, effects: set[str], errors: list[str]) -> None:
    guard = receipt.get("compaction_guard") or {}
    mode = guard.get("stream_mode")
    require(mode in {"not_streamed", "append_only", "compacted"}, "compaction_guard.stream_mode invalid or missing", errors)
    if mode in {"append_only", "compacted"}:
        for field in ["source_stream", "consumer_watermark", "snapshot_basis"]:
            if not guard.get(field):
                errors.append(f"compaction_guard.{field} missing for streamed receipt")
    if mode == "compacted":
        if guard.get("tombstone_retention_checked") is not True:
            errors.append("compacted stream receipt missing tombstone_retention_checked=true")
        if not guard.get("delete_retention_window"):
            errors.append("compacted stream receipt missing delete_retention_window")
        if guard.get("snapshot_basis") not in {"full_scan_within_tombstone_retention", "anchored_snapshot_with_replay_tail"}:
            errors.append("compacted stream receipt has unsafe snapshot_basis")
        if guard.get("event_compacted_away") is True:
            if guard.get("materialized_state") != "historical_receipt_only":
                errors.append("compacted-away event must materialize only as historical_receipt_only")
            if replay_status != "downgraded_historical":
                errors.append("compacted-away event must use downgraded_historical replay status")
            if effects - SAFE_HISTORICAL_EFFECTS:
                errors.append("compacted-away event performed non-historical effects")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    require(receipt.get("schema") == "ward.governance-decision-consumer-receipt.v0", "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == "ward.governance.decision.consumer-receipt.v0", "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == "consumer_receipt_only", "consumer receipt authority_surface must be consumer_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))

    event, _ = resolve_event(receipt, errors)
    consumer = receipt.get("consumer") or {}
    if event and consumer.get("profile") != event.get("consumer_profile"):
        errors.append("consumer.profile does not match referenced event consumer_profile")

    packet_ref = receipt.get("packet_ref") or {}
    if event:
        event_packet = event.get("packet_ref") or {}
        for field in ["packet_id", "packet_path", "packet_sha256"]:
            if packet_ref.get(field) != event_packet.get(field):
                errors.append(f"packet_ref.{field} does not mirror referenced event")

    replay = receipt.get("replay_check") or {}
    replay_status = replay.get("status")
    require(replay_status in ALLOWED_STATUS, "replay_check.status invalid or missing", errors)
    if replay_status == "replayed_current":
        for field in ["event_digest_ok", "packet_digest_ok", "packet_replayed", "event_replayed"]:
            if replay.get(field) is not True:
                errors.append(f"replayed_current receipt missing replay_check.{field}=true")
        if replay.get("downgrade_reasons"):
            errors.append("replayed_current receipt must not carry downgrade_reasons")
    elif replay_status in {"downgraded_historical", "held_pending_packet"}:
        if not replay.get("downgrade_reasons"):
            errors.append(f"{replay_status} receipt must name downgrade_reasons")

    state = receipt.get("state_interpretation") or {}
    event_state = state.get("event_state")
    consumer_state = state.get("consumer_state")
    require(event_state in ALLOWED_CONSUMER_STATES, "state_interpretation.event_state invalid or missing", errors)
    require(consumer_state in ALLOWED_CONSUMER_STATES, "state_interpretation.consumer_state invalid or missing", errors)
    if event and event_state != (event.get("decision") or {}).get("state"):
        errors.append("state_interpretation.event_state does not match event decision.state")
    if event_state and consumer_state and not state_not_stronger(event_state, consumer_state):
        errors.append("consumer_state is stronger than event_state")
    if state.get("weakness_visible") is not True:
        errors.append("consumer receipt must make weakness_visible=true")
    if state.get("non_authority_statement") is not True:
        errors.append("consumer receipt must keep non_authority_statement=true")

    closure = receipt.get("effect_closure") or {}
    effects = set(closure.get("effects_performed") or [])
    if event:
        allowed = set((event.get("decision") or {}).get("allowed_effects") or []) | SAFE_HISTORICAL_EFFECTS
        unexpected = sorted(effects - allowed)
        if unexpected:
            errors.append("consumer performed effects not allowed by event or historical-safe set: " + ", ".join(unexpected))
        event_forbidden = set(event.get("forbidden_effects") or [])
        preserved = set(closure.get("forbidden_effects_preserved") or [])
        missing = sorted(event_forbidden - preserved)
        if missing:
            errors.append("consumer did not preserve forbidden effects: " + ", ".join(missing))
    if event_state != "consequence_grade" and effects & HIGH_CONSEQUENCE_EFFECTS:
        errors.append("weak event state performed high-consequence effects")
    if replay_status != "replayed_current" and effects - SAFE_HISTORICAL_EFFECTS:
        errors.append("non-current replay performed non-historical effects")

    replay_diff = receipt.get("replay_diff") or {}
    if replay_diff:
        if replay_diff.get("after_state") != consumer_state:
            errors.append("replay_diff.after_state must match consumer_state")
        if replay_diff.get("change_class") == "upgrade":
            errors.append("consumer replay diff must not be an upgrade")
        if replay_diff.get("packet_digest_checked") is not True and replay_status == "replayed_current":
            errors.append("current replay diff must confirm packet_digest_checked=true")

    projection_ok(receipt, errors)
    compaction_guard_ok(receipt, replay_status or "", effects, errors)
    return errors


def main() -> int:
    valid_paths = sorted(RECEIPT_DIR.glob("*.valid.json"))
    invalid_paths = sorted((RECEIPT_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance decision consumer fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance decision consumer fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance decision consumer receipt check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance decision consumer receipt check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
