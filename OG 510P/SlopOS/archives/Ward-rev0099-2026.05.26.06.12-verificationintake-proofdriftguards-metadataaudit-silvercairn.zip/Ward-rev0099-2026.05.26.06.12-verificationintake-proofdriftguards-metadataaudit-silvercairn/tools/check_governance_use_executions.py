#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
from typing import Any
import sys

from governance_common import (
    ROOT,
    parse_time,
    require,
    run_fixture_checker,
    stable_digest,
    validate_ref,
)

USE_EXECUTION_DIR = ROOT / "fixtures" / "governance-use-execution"
SCHEMA = "ward.governance-use-execution-receipt.v0"
RECEIPT_NAME = "ward.governance.use-execution-receipt.v0"
AUTHORITY_SURFACE = "use_execution_receipt_only"
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}

VALID_STATES = {
    "executed_public_display_refresh_required",
    "executed_internal_review_refresh_required",
    "held_no_execution_evidence_release_required",
    "refused_noop_high_consequence",
    "quarantined_no_execution_receiver_gap",
    "invalid_use_execution_rejected",
}
SAFE_EXECUTION_EFFECTS = {
    "record_use_execution_receipt",
    "record_source_reuse_gate_ref",
    "record_actual_effect_digest",
    "publish_no_authority_use_status",
    "render_public_minimized_status",
    "render_internal_review_replay",
    "hold_without_execution",
    "refuse_without_execution",
    "quarantine_without_execution",
    "request_evidence_release_receipt",
    "request_handoff_packet_replay",
    "request_recertification_refresh",
    "mark_use_noop",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "approve_export",
    "budget_spend",
    "delegate",
    "evidence_bundle_release",
    "export_raw_evidence",
    "force_consumer_action",
    "grant_authority",
    "learning_use",
    "merge_divergent_status_channels",
    "privacy_waiver",
    "promote_global_current_head",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "semantic_repair",
    "status_pointer_update",
    "update_current_head",
    "update_status_pointer",
}
REQUIRED_FORBIDDEN = {
    "action_without_packet",
    "actual_effect_drift",
    "approval_by_convergence",
    "authority_reuse_without_packet",
    "budget_spend",
    "cache_as_authority",
    "cached_head_reuse_without_refresh",
    "convergence_as_authority",
    "delegate_without_warrant",
    "display_reuse_as_export_authority",
    "evidence_release_without_release_receipt",
    "execution_outside_gate_window",
    "export_from_display_gate",
    "export_without_receipt",
    "future_action",
    "gate_decision_mutation",
    "global_status_pointer_update",
    "high_consequence_without_handoff_packet",
    "learning_use",
    "partial_receiver_convergence_as_complete",
    "privacy_waiver_without_packet",
    "receiver_convergence_as_authority",
    "receiver_convergence_as_recertification",
    "receiver_fork_as_current",
    "receiver_gap_hidden",
    "recipient_projection_drift",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "reuse_gate_as_authority",
    "reuse_gate_execution_as_authority",
    "reuse_purpose_drift",
    "reuse_without_refresh",
    "sealed_branch_disclosure",
    "semantic_repair_without_warrant",
    "status_pointer_as_grant",
    "unprojected_disclosure",
    "use_execution_as_authority",
}


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == SCHEMA, "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == RECEIPT_NAME, "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == AUTHORITY_SURFACE, "authority_surface must be use_execution_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def resolve_source_gate(ref: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    source = validate_ref(
        ref,
        label="source_reuse_gate_ref",
        expected_schema="ward.governance-reuse-gate-receipt.v0",
        checker_script="check_governance_reuse_gates.py",
        checker_module_name="ward_reuse_gate_checker_for_use_execution",
        errors=errors,
    )
    if not source:
        return None
    req = source.get("reuse_request") or {}
    decision = source.get("gate_decision") or {}
    binding = source.get("consequence_binding") or {}
    projection = source.get("projection_safety") or {}
    mirrors = {
        "gate_state": decision.get("state"),
        "reuse_allowed": decision.get("reuse_allowed"),
        "reuse_hold": decision.get("reuse_hold"),
        "reuse_refused": decision.get("reuse_refused"),
        "request_id": req.get("request_id"),
        "requested_purpose": req.get("requested_purpose"),
        "requested_consequence_class": req.get("requested_consequence_class"),
        "requested_effect": req.get("requested_effect"),
        "recipient_class": req.get("recipient_class"),
        "projection_policy_id": req.get("projection_policy_id"),
        "requested_until": req.get("requested_until"),
        "consequence_scope_digest": binding.get("consequence_scope_digest"),
        "no_authority_label_present": projection.get("no_authority_label_present"),
    }
    for field, expected in mirrors.items():
        if ref.get(field) != expected:
            errors.append(f"source_reuse_gate_ref.{field} does not mirror referenced reuse-gate receipt")
    if decision.get("no_authority_granted") is not True:
        errors.append("referenced reuse-gate receipt must grant no authority")
    return source


def request_and_binding_ok(receipt: dict[str, Any], source: dict[str, Any] | None, errors: list[str]) -> None:
    ref = receipt.get("source_reuse_gate_ref") or {}
    req = receipt.get("execution_request") or {}
    checks = receipt.get("pre_execution_checks") or {}
    binding = receipt.get("execution_binding") or {}
    for field in [
        "execution_id", "requested_gate_id", "actor_class", "actual_purpose",
        "actual_consequence_class", "actual_effect", "recipient_class",
        "projection_policy_id", "execution_target", "executed_at", "execution_window_end",
    ]:
        if req.get(field) in (None, ""):
            errors.append(f"execution_request.{field} missing")
    try:
        executed_at = parse_time(req.get("executed_at"), "execution_request.executed_at")
        window_end = parse_time(req.get("execution_window_end"), "execution_request.execution_window_end")
        gate_until = parse_time(ref.get("requested_until"), "source_reuse_gate_ref.requested_until")
        if window_end < executed_at:
            errors.append("execution_request.execution_window_end must not precede executed_at")
        if executed_at > gate_until:
            errors.append("execution_request.executed_at must not exceed source gate requested_until")
    except ValueError as exc:
        errors.append(str(exc))
    if req.get("requested_gate_id") != ref.get("receipt_id"):
        errors.append("execution_request.requested_gate_id must equal source_reuse_gate_ref.receipt_id")
    for req_field, ref_field in [
        ("actual_purpose", "requested_purpose"),
        ("actual_consequence_class", "requested_consequence_class"),
        ("actual_effect", "requested_effect"),
        ("recipient_class", "recipient_class"),
        ("projection_policy_id", "projection_policy_id"),
    ]:
        if req.get(req_field) != ref.get(ref_field):
            errors.append(f"execution_request.{req_field} must mirror source_reuse_gate_ref.{ref_field}")
    for field in [
        "source_reuse_gate_digest_checked", "gate_decision_current_checked",
        "execution_within_gate_window", "purpose_matches_gate",
        "effect_matches_gate", "recipient_scope_matches_gate",
        "projection_policy_matches_gate", "no_authority_label_required",
        "gate_hold_blocks_execution", "gate_refusal_blocks_execution",
        "receiver_gap_blocks_execution", "evidence_release_receipt_present",
    ]:
        if field not in checks:
            errors.append(f"pre_execution_checks.{field} missing")
    for field in [
        "source_reuse_gate_digest_checked", "gate_decision_current_checked",
        "execution_within_gate_window", "purpose_matches_gate",
        "effect_matches_gate", "recipient_scope_matches_gate",
        "projection_policy_matches_gate", "no_authority_label_required",
    ]:
        if checks.get(field) is not True:
            errors.append(f"pre_execution_checks.{field} must be true")
    state = ref.get("gate_state")
    if (state or "").endswith("hold") or state in {"evidence_release_required_hold", "receiver_gap_quarantine_hold"}:
        if checks.get("gate_hold_blocks_execution") is not True:
            errors.append("pre_execution_checks.gate_hold_blocks_execution must be true for source gate holds")
    else:
        if checks.get("gate_hold_blocks_execution") is not False:
            errors.append("pre_execution_checks.gate_hold_blocks_execution must be false when source gate is not a hold")
    if state == "high_consequence_refused":
        if checks.get("gate_refusal_blocks_execution") is not True:
            errors.append("pre_execution_checks.gate_refusal_blocks_execution must be true for refused gates")
    else:
        if checks.get("gate_refusal_blocks_execution") is not False:
            errors.append("pre_execution_checks.gate_refusal_blocks_execution must be false when source gate is not refused")
    if state == "receiver_gap_quarantine_hold":
        if checks.get("receiver_gap_blocks_execution") is not True:
            errors.append("pre_execution_checks.receiver_gap_blocks_execution must be true for receiver-gap gates")
    else:
        if checks.get("receiver_gap_blocks_execution") is not False:
            errors.append("pre_execution_checks.receiver_gap_blocks_execution must be false when no receiver gap is held")
    if req.get("actual_consequence_class") in {"external_release", "dashboard_export"}:
        if checks.get("evidence_release_receipt_present") is not True:
            # A hold fixture may intentionally prove no execution occurred; decision check enforces that it held.
            pass
    for field in [
        "bound_execution_id", "bound_gate_receipt_id", "bound_gate_decision_state",
        "gate_consequence_scope_digest", "actual_effect_digest", "source_gate_unmodified",
    ]:
        if binding.get(field) in (None, ""):
            errors.append(f"execution_binding.{field} missing")
    if binding.get("bound_execution_id") != req.get("execution_id"):
        errors.append("execution_binding.bound_execution_id must equal execution_request.execution_id")
    if binding.get("bound_gate_receipt_id") != ref.get("receipt_id"):
        errors.append("execution_binding.bound_gate_receipt_id must equal source_reuse_gate_ref.receipt_id")
    if binding.get("bound_gate_decision_state") != ref.get("gate_state"):
        errors.append("execution_binding.bound_gate_decision_state must mirror source_reuse_gate_ref.gate_state")
    if binding.get("gate_consequence_scope_digest") != ref.get("consequence_scope_digest"):
        errors.append("execution_binding.gate_consequence_scope_digest must mirror source gate consequence scope")
    expected = stable_digest({
        "execution_id": req.get("execution_id"),
        "gate_receipt_id": ref.get("receipt_id"),
        "gate_state": ref.get("gate_state"),
        "purpose": req.get("actual_purpose"),
        "consequence_class": req.get("actual_consequence_class"),
        "effect": req.get("actual_effect"),
        "recipient_class": req.get("recipient_class"),
        "projection_policy_id": req.get("projection_policy_id"),
        "execution_target": req.get("execution_target"),
    })
    if binding.get("actual_effect_digest") != expected:
        errors.append("execution_binding.actual_effect_digest does not match execution request")
    if binding.get("source_gate_unmodified") is not True:
        errors.append("execution_binding.source_gate_unmodified must be true")


def projection_and_closure_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    req = receipt.get("execution_request") or {}
    projection = receipt.get("projection_safety") or {}
    closure = receipt.get("execution_closure") or {}
    if projection.get("projection_policy_id") != req.get("projection_policy_id"):
        errors.append("projection_safety.projection_policy_id must mirror execution_request")
    if projection.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(projection.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    if req.get("recipient_class") in PUBLIC_RECIPIENTS:
        for field in [
            "reveals_receiver_identity_public", "reveals_status_channel_private",
            "reveals_named_private_stewards", "reveals_private_org_map",
            "reveals_raw_partner_fragments", "reveals_recipient_private_contact",
            "sealed_gate_payload_inline", "sealed_source_payload_inline",
        ]:
            if projection.get(field) is not False:
                errors.append(f"projection_safety.{field} must be false for public recipients")
        if projection.get("hashed_or_class_only_subjects") is not True:
            errors.append("projection_safety.hashed_or_class_only_subjects must be true for public recipients")
    expected_bool = {
        "source_reuse_gate_mutated": False,
        "source_convergence_mutated": False,
        "source_status_pointer_mutated": False,
        "use_execution_can_grant_authority": False,
        "reuse_gate_can_grant_authority": False,
        "status_pointer_update_allowed": False,
        "scope_expansion_allowed": False,
        "requires_no_authority_label": True,
        "requires_source_gate_ref": True,
        "requires_actual_effect_digest": True,
        "source_packet_replay_still_required": True,
        "safe_execution_effects_only": True,
        "no_authority_upgrade": True,
        "no_high_consequence_effects": True,
    }
    for field, expected in expected_bool.items():
        if closure.get(field) is not expected:
            errors.append(f"execution_closure.{field} must be {expected}")
    actual = set(closure.get("actual_effects") or [])
    forbidden = set(closure.get("forbidden_effects") or [])
    if not actual:
        errors.append("execution_closure.actual_effects missing")
    unsupported = sorted(actual - SAFE_EXECUTION_EFFECTS)
    if unsupported:
        errors.append("execution_closure.actual_effects contains unsupported effects: " + ", ".join(unsupported))
    high = sorted(actual & HIGH_CONSEQUENCE_EFFECTS)
    if high:
        errors.append("execution_closure.actual_effects contains high-consequence effects: " + ", ".join(high))
    missing = sorted(REQUIRED_FORBIDDEN - forbidden)
    if missing:
        errors.append("execution_closure.forbidden_effects missing required fences: " + ", ".join(missing[:8]))


def decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    ref = receipt.get("source_reuse_gate_ref") or {}
    req = receipt.get("execution_request") or {}
    checks = receipt.get("pre_execution_checks") or {}
    closure = receipt.get("execution_closure") or {}
    decision = receipt.get("execution_decision") or {}
    state = decision.get("state")
    gate_state = ref.get("gate_state")
    actual_effects = set(closure.get("actual_effects") or [])
    if state not in VALID_STATES:
        errors.append("execution_decision.state invalid")
    if decision.get("no_authority_granted") is not True:
        errors.append("execution_decision.no_authority_granted must be true")
    if decision.get("status_pointer_update_allowed") is not False:
        errors.append("execution_decision.status_pointer_update_allowed must be false")
    if decision.get("scope_expansion_allowed") is not False:
        errors.append("execution_decision.scope_expansion_allowed must be false")
    if state == "executed_public_display_refresh_required":
        if gate_state != "display_reuse_allowed_refresh_required":
            errors.append("public display execution requires display reuse gate")
        if req.get("actual_effect") != "public_minimized_display":
            errors.append("public display execution requires public_minimized_display effect")
        if decision.get("execution_performed") is not True or decision.get("execution_held") is not False or decision.get("execution_refused") is not False:
            errors.append("public display execution must be performed, not held/refused")
        if "render_public_minimized_status" not in actual_effects:
            errors.append("public display execution must render public minimized status")
        if decision.get("refresh_still_required") is not True:
            errors.append("public display execution must keep refresh_still_required true")
    if state == "executed_internal_review_refresh_required":
        if gate_state != "internal_review_reuse_allowed":
            errors.append("internal review execution requires internal review reuse gate")
        if req.get("actual_effect") != "internal_review_replay":
            errors.append("internal review execution requires internal_review_replay effect")
        if decision.get("execution_performed") is not True:
            errors.append("internal review execution must be performed")
        if "render_internal_review_replay" not in actual_effects:
            errors.append("internal review execution must render internal review replay")
        if decision.get("refresh_still_required") is not True:
            errors.append("internal review execution must keep refresh_still_required true")
    if state == "held_no_execution_evidence_release_required":
        if gate_state != "evidence_release_required_hold":
            errors.append("evidence-release hold execution requires evidence-release hold gate")
        if decision.get("execution_performed") is not False or decision.get("execution_held") is not True:
            errors.append("evidence-release hold must not perform execution")
        if decision.get("evidence_release_still_required") is not True:
            errors.append("evidence-release hold must keep evidence_release_still_required true")
        if "hold_without_execution" not in actual_effects or checks.get("evidence_release_receipt_present") is not False:
            errors.append("evidence-release hold must record hold_without_execution and no release receipt")
    if state == "refused_noop_high_consequence":
        if gate_state != "high_consequence_refused":
            errors.append("high-consequence noop requires refused source gate")
        if decision.get("execution_performed") is not False or decision.get("execution_refused") is not True:
            errors.append("high-consequence noop must refuse without execution")
        if decision.get("handoff_packet_still_required") is not True:
            errors.append("high-consequence noop must keep handoff_packet_still_required true")
        if "refuse_without_execution" not in actual_effects:
            errors.append("high-consequence noop must record refuse_without_execution")
    if state == "quarantined_no_execution_receiver_gap":
        if gate_state != "receiver_gap_quarantine_hold":
            errors.append("receiver-gap quarantine requires receiver-gap source gate")
        if decision.get("execution_performed") is not False or decision.get("execution_quarantined") is not True:
            errors.append("receiver-gap state must quarantine without execution")
        if "quarantine_without_execution" not in actual_effects:
            errors.append("receiver-gap state must record quarantine_without_execution")
    performed = decision.get("execution_performed") is True
    if not performed and ("render_public_minimized_status" in actual_effects or "render_internal_review_replay" in actual_effects):
        errors.append("no-execution decisions cannot render downstream effects")
    if performed and gate_state in {"evidence_release_required_hold", "high_consequence_refused", "receiver_gap_quarantine_hold"}:
        errors.append("held/refused/quarantined source gates cannot be executed")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    ref = receipt.get("source_reuse_gate_ref")
    source = None
    if not isinstance(ref, dict):
        errors.append("source_reuse_gate_ref must be an object")
    else:
        source = resolve_source_gate(ref, errors)
    request_and_binding_ok(receipt, source, errors)
    projection_and_closure_ok(receipt, errors)
    decision_ok(receipt, errors)
    return errors


def main() -> int:
    return run_fixture_checker(
        fixture_dir=USE_EXECUTION_DIR,
        valid_glob="*.valid.json",
        invalid_glob="*.invalid.json",
        validate_receipt=validate_receipt,
        label="Governance use-execution receipt",
    )


if __name__ == "__main__":
    sys.exit(main())
