#!/usr/bin/env python3
"""Tiny Ward governance handoff fixture checker.

This is not a general authorization engine. It checks enough of the v0 packet
fixtures to prevent the known rev0078 false-authority collapses from passing.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import json
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
FIXTURE_DIR = ROOT / "fixtures" / "governance-handoff"
PROOF_IDS = [f"PO-GOV-{i:03d}" for i in range(1, 12)]
ALLOWED_POSTURES = {"consequence_grade", "allowed"}

BUDGET_ACTIONS = {"approve_recompute_budget", "run_backfill", "approve_backfill", "recompute"}
PRIVACY_ACTIONS = {"waive_privacy", "raw_partner_fragment_access", "emergency_raw_partner_fragment_access"}
AGENT_FORBIDDEN_ACTIONS = {
    "review_crosswalk_repair",
    "approve_crosswalk_repair",
    "approve_dashboard_export",
    "approve_remedy",
    "approve_recompute_budget",
    "reenable_action",
    "waive_privacy",
    "accept_escalation",
}
NON_AUTHORITY_BASIS_PREFIXES = (
    "catalog_owner",
    "dashboard_owner",
    "old_owner",
    "on_call",
    "ticket_assignee",
    "tool_call_leash",
    "owner_hint",
    "chat_assignment",
    "page_sent",
    "reviewer_assignment",
)
ROUTING_HINT_ACTIONS = {
    "route_to_steward",
    "surface_owner_hint",
    "open_review_hint",
    "suggest_contact",
}
SENSITIVE_PROJECTION_FLAGS = {
    "reveals_sealed_conflict_details",
    "reveals_raw_partner_fragments",
    "reveals_reviewer_identities",
    "reveals_private_org_map",
    "reveals_incident_details",
}


def parse_time(value: str | None, label: str) -> datetime:
    if not value:
        raise ValueError(f"missing timestamp for {label}")
    try:
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        dt = datetime.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"invalid timestamp for {label}: {value}") from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text())
    except Exception as exc:  # pragma: no cover - intentionally direct CLI message
        raise ValueError(f"{path}: cannot parse JSON: {exc}") from exc


def is_allowed(posture: str) -> bool:
    return posture in ALLOWED_POSTURES


def active_charter(packet: dict[str, Any], as_of: datetime, errors: list[str]) -> dict[str, Any] | None:
    charter = packet.get("stewardship_charter") or {}
    if charter.get("status") != "active":
        return None
    try:
        review_by = parse_time(charter.get("review_by"), "stewardship_charter.review_by")
        last_rehydrated = parse_time(charter.get("last_rehydrated_at"), "stewardship_charter.last_rehydrated_at")
    except ValueError as exc:
        errors.append(str(exc))
        return None
    if review_by < as_of:
        return None
    max_days = charter.get("max_staleness_days")
    if isinstance(max_days, int):
        age_days = (as_of - last_rehydrated).total_seconds() / 86400
        if age_days > max_days:
            return None
    return charter


def active_warrants(packet: dict[str, Any], as_of: datetime, errors: list[str]) -> list[dict[str, Any]]:
    warrants = []
    for warrant in packet.get("delegation_warrants", []):
        if warrant.get("status") != "active":
            continue
        try:
            expires_at = parse_time(warrant.get("expires_at"), f"{warrant.get('warrant_id', '<warrant>')}.expires_at")
        except ValueError as exc:
            errors.append(str(exc))
            continue
        if expires_at >= as_of:
            warrants.append(warrant)
    return warrants


def accepted_handoffs(packet: dict[str, Any]) -> list[dict[str, Any]]:
    accepted = {"accepted", "partial", "emergency_only", "closed"}
    return [h for h in packet.get("escalation_handoffs", []) if h.get("acceptance") in accepted]


def basis_is_non_authority(basis: list[str]) -> bool:
    return any(any(item.startswith(prefix) for prefix in NON_AUTHORITY_BASIS_PREFIXES) for item in basis)


def actor_is_agent(packet: dict[str, Any], actor: str) -> dict[str, Any] | None:
    for boundary in packet.get("agent_boundaries", []):
        if boundary.get("agent_id") == actor:
            return boundary
    return None


def has_warrant_authority(actor: str, action: str, warrants: list[dict[str, Any]]) -> bool:
    for warrant in warrants:
        if warrant.get("delegatee") != actor:
            continue
        if action in warrant.get("denied_capabilities", []):
            return False
        if action in warrant.get("granted_capabilities", []):
            return True
    return False


def has_charter_authority(actor: str, action: str, charter: dict[str, Any] | None) -> bool:
    if not charter:
        return False
    if action in charter.get("excluded_powers", []):
        return False
    parties = {p.get("id") for p in charter.get("accountable_parties", [])}
    return actor in parties and action in charter.get("permitted_duties", [])


def has_handoff_authority(actor: str, action: str, handoffs: list[dict[str, Any]]) -> bool:
    for handoff in handoffs:
        if handoff.get("to_lane") == actor and action in handoff.get("authority_granted", []):
            return True
    return False


def budget_ok(packet: dict[str, Any], action: str, actor: str) -> bool:
    if action not in BUDGET_ACTIONS:
        return True
    recompute = (packet.get("budget") or {}).get("recompute") or {}
    return recompute.get("status") == "approved" and recompute.get("approver") == actor


def privacy_ok(packet: dict[str, Any], action: str) -> bool:
    if action not in PRIVACY_ACTIONS:
        return True
    bg = packet.get("break_glass") or {}
    return bool(bg.get("used") and bg.get("review_debt_recorded"))


def no_conflict(packet: dict[str, Any], action: str) -> bool:
    conflicts = packet.get("conflicts") or {}
    if conflicts.get("unresolved"):
        return False
    if action in {"approve_remedy", "reenable_action", "approve_dashboard_export"}:
        return action in set(conflicts.get("dual_control_satisfied_for", []))
    return True




def break_glass_ok(packet: dict[str, Any], action: str, as_of: datetime, errors: list[str]) -> bool:
    bg = packet.get("break_glass") or {}
    if not bg.get("used"):
        return action not in PRIVACY_ACTIONS
    for field in ["trigger", "scope", "expires_at", "post_hoc_review_by", "rollback_plan", "review_debt_recorded"]:
        if not bg.get(field):
            errors.append(f"break_glass missing required field: {field}")
            return False
    try:
        expires_at = parse_time(bg.get("expires_at"), "break_glass.expires_at")
    except ValueError as exc:
        errors.append(str(exc))
        return False
    if expires_at < as_of:
        errors.append("break_glass has expired")
        return False
    allowed_interim = set(bg.get("allowed_interim_actions") or [])
    if action in PRIVACY_ACTIONS and action not in allowed_interim:
        errors.append(f"{action} is not inside break_glass.allowed_interim_actions")
        return False
    if not bg.get("review_debt_recorded"):
        errors.append("break_glass review debt not recorded")
        return False
    return True


def projection_ok(packet: dict[str, Any], errors: list[str]) -> bool:
    pp = packet.get("privacy_projection") or {}
    ok = True
    if pp.get("no_existence_oracle") is not True:
        errors.append("privacy_projection.no_existence_oracle must be true")
        ok = False
    for view_name in ["public_view", "external_view"]:
        view = pp.get(view_name) or {}
        for flag in SENSITIVE_PROJECTION_FLAGS:
            if view.get(flag) is True:
                errors.append(f"{view_name} leaks sensitive governance evidence via {flag}")
                ok = False
    return ok


def routing_hint_ok(packet: dict[str, Any], evaluated: dict[str, Any], errors: list[str]) -> bool:
    mode = packet.get("routing_hint_mode") or {}
    action = evaluated.get("action")
    ok = True
    if action not in ROUTING_HINT_ACTIONS:
        errors.append(f"{action} is not an allowed routing-hint action")
        ok = False
    if mode.get("enabled") is not True:
        errors.append("routing_hint_only action missing routing_hint_mode.enabled")
        ok = False
    if mode.get("read_only") is not True:
        errors.append("routing_hint_only action must be read_only")
        ok = False
    if mode.get("sensitive_evidence_carried") is True:
        errors.append("routing_hint_only action carries sensitive evidence")
        ok = False
    if mode.get("evidence_detail") not in {"public_label_only", "internal_label_only", "redacted_route_only"}:
        errors.append("routing_hint_only action has too much or unclear evidence detail")
        ok = False
    forbidden = set(mode.get("forbidden_promotions") or [])
    if not {"semantic_repair", "approve_dashboard_export", "reenable_action", "waive_privacy"}.issubset(forbidden):
        errors.append("routing_hint_mode.forbidden_promotions is missing required authority fences")
        ok = False
    return ok


def validate_packet(packet: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []

    require(packet.get("schema") == "ward.governance-handoff-packet.v0", "wrong or missing schema", errors)
    for field in [
        "packet_id", "validation_context", "subject", "requested_actions", "stewardship_charter",
        "delegation_warrants", "escalation_handoffs", "agent_boundaries", "budget",
        "privacy_projection", "proof_obligations", "evaluated_actions",
    ]:
        require(field in packet, f"missing required field: {field}", errors)

    try:
        as_of = parse_time((packet.get("validation_context") or {}).get("as_of"), "validation_context.as_of")
    except ValueError as exc:
        errors.append(str(exc))
        as_of = datetime.now(timezone.utc)

    proof = packet.get("proof_obligations") or {}
    missing_proofs = [po for po in PROOF_IDS if po not in proof]
    if missing_proofs:
        errors.append("missing proof obligations: " + ", ".join(missing_proofs))

    allowed_actions = [a for a in packet.get("evaluated_actions", []) if is_allowed(a.get("posture", ""))]
    if allowed_actions:
        failed = [po for po, status in proof.items() if str(status).startswith("fail")]
        if failed:
            errors.append("consequence-grade action present while proof obligations fail: " + ", ".join(sorted(failed)))

    projection_ok(packet, errors)

    charter = active_charter(packet, as_of, errors)
    warrants = active_warrants(packet, as_of, errors)
    handoffs = accepted_handoffs(packet)

    for evaluated in packet.get("evaluated_actions", []):
        posture = evaluated.get("posture")
        if posture == "routing_hint_only":
            routing_hint_ok(packet, evaluated, errors)
            continue
        if not is_allowed(posture):
            continue
        actor = evaluated.get("actor")
        action = evaluated.get("action")
        basis = evaluated.get("basis") or []
        if not actor or not action:
            errors.append("allowed evaluated action missing actor or action")
            continue

        if basis_is_non_authority(basis):
            errors.append(f"{actor}:{action} relies on non-authority basis {basis}")

        agent = actor_is_agent(packet, actor)
        if agent:
            if action in AGENT_FORBIDDEN_ACTIONS or agent.get("may_approve") is not True:
                errors.append(f"{actor}:{action} violates agent boundary")
            if agent.get("steward_of_record") is True:
                errors.append(f"{actor} cannot be steward_of_record")
            if agent.get("may_accept_escalation") is True and action == "accept_escalation":
                errors.append(f"{actor} cannot accept escalation without explicit non-v0 review")

        has_authority = (
            has_charter_authority(actor, action, charter)
            or has_warrant_authority(actor, action, warrants)
            or has_handoff_authority(actor, action, handoffs)
        )
        if not has_authority:
            errors.append(f"{actor}:{action} lacks active charter, warrant, or accepted handoff authority")

        if not budget_ok(packet, action, actor):
            errors.append(f"{actor}:{action} lacks matching budget approval")

        if not privacy_ok(packet, action):
            errors.append(f"{actor}:{action} lacks privacy/break-glass review debt")

        if not break_glass_ok(packet, action, as_of, errors):
            errors.append(f"{actor}:{action} lacks complete break-glass closure")

        if not no_conflict(packet, action):
            errors.append(f"{actor}:{action} has unresolved conflict/quorum problem")

    for requested in packet.get("requested_actions", []):
        via = requested.get("via_delegatee")
        if not via:
            continue
        parent = [w for w in warrants if w.get("delegatee") == via]
        if not parent or any(w.get("re_delegation") == "forbidden" for w in parent):
            # Only an error if the redelegated action was marked allowed.
            for evaluated in allowed_actions:
                if evaluated.get("actor") == requested.get("actor") and evaluated.get("action") == requested.get("action"):
                    errors.append(f"{requested.get('actor')}:{requested.get('action')} is forbidden re-delegation from {via}")

    bg = packet.get("break_glass") or {}
    if bg.get("used") and not bg.get("review_debt_recorded"):
        for evaluated in allowed_actions:
            if evaluated.get("action") in PRIVACY_ACTIONS or "break_glass" in (evaluated.get("basis") or []):
                errors.append("break-glass action allowed without review debt")

    return errors


def main() -> int:
    valid_paths = sorted(FIXTURE_DIR.glob("*.valid.json"))
    invalid_paths = sorted((FIXTURE_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance handoff fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance handoff fixtures found.")
        return 1

    failures: list[str] = []

    for path in valid_paths:
        errors = validate_packet(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))

    for path in invalid_paths:
        errors = validate_packet(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")

    if failures:
        print("Governance handoff fixture check failed.")
        for failure in failures:
            print(failure)
        return 1

    print(f"Governance handoff check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
