#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_json(rel: str):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def main() -> int:
    errors: list[str] = []
    receipt = load_json("REVISION-RECEIPT.json")
    status = load_json("SURFACE-STATUS.json")
    docs_readme = (ROOT / "docs" / "README.md").read_text(encoding="utf-8")
    root_readme = (ROOT / "README.md").read_text(encoding="utf-8")
    start_here = (ROOT / "START_HERE.md").read_text(encoding="utf-8")
    revision = receipt.get("revision")
    summary = receipt.get("summary")
    if revision not in docs_readme or revision not in root_readme or revision not in start_here:
        errors.append("current revision must be present in docs/README.md, README.md, and START_HERE.md")
    if summary not in root_readme or summary not in start_here:
        errors.append("current revision summary must be present in README.md and START_HERE.md")
    latest_addition_docs = [p for p in receipt.get("hygiene_additions", []) if p.endswith(".md")]
    for rel in latest_addition_docs:
        if rel not in docs_readme:
            errors.append(f"docs/README.md missing latest addition: {rel}")
        if not (ROOT / rel).exists():
            errors.append(f"revision receipt latest addition missing on disk: {rel}")
    latest_surfaces = status.get("latest_surfaces") or {}
    for name, rel in latest_surfaces.items():
        if isinstance(rel, str) and rel.endswith(".md") and rel not in docs_readme:
            errors.append(f"docs/README.md missing latest surface {name}: {rel}")
    specimen_docs = sorted(
        str(path.relative_to(ROOT))
        for path in (ROOT / "docs" / "30-architecture").glob("specimen-flow-*.md")
        if path.name != "specimen-flow-index.md"
    )
    specimen_index = (ROOT / "docs" / "30-architecture" / "specimen-flow-index.md").read_text(encoding="utf-8")
    if specimen_docs:
        latest_specimen = specimen_docs[-1]
        if latest_specimen not in docs_readme:
            errors.append("docs/README.md missing latest specimen path")
        if latest_specimen not in specimen_index:
            errors.append("specimen-flow-index.md missing latest specimen path")
    stale_latest = re.findall(r"Latest research pass: `([^`]+)`", docs_readme)
    if stale_latest:
        expected = latest_surfaces.get("research_synthesis")
        if expected and stale_latest[0] != expected:
            errors.append("docs/README.md first latest research pass line does not match SURFACE-STATUS latest_surfaces")
    if errors:
        print("Doc index integrity check failed.")
        for err in errors:
            print(" -", err)
        return 1
    print(f"Doc index integrity check passed for {revision} ({len(latest_addition_docs)} latest docs checked).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
