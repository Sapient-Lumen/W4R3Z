#!/usr/bin/env python3
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
CHAIN_DIR = ROOT / "fixtures" / "governance-chain-integrity"

ROLES_TO_SCHEMA = {
    "release": "ward.governance-evidence-release-receipt.v0",
    "followup": "ward.governance-evidence-release-followup-receipt.v0",
    "transfer": "ward.governance-succession-transfer-receipt.v0",
}
SCHEMA_TO_ROLE = {v: k for k, v in ROLES_TO_SCHEMA.items()}
VALID_STATES = {
    "canonical_head_recorded",
    "revoked_head_recorded",
    "fork_detected_hold",
    "disputed_head_quarantined",
    "chain_recheck_required",
    "historical_minimized",
    "successor_pending_recheck",
}
FORK_STATES = {"none", "detected", "resolved", "quarantined"}
PUBLIC_RECIPIENTS = {"public", "external_public", "partner_public"}
SAFE_CHAIN_EFFECTS = {
    "record_chain_integrity_receipt",
    "record_canonical_head_pointer",
    "record_fork_hold",
    "publish_status_pointer_update",
    "request_recheck",
    "retain_minimized_chain_receipt",
    "quarantine_disputed_chain",
    "notify_chain_watchers",
}
HIGH_CONSEQUENCE_EFFECTS = {
    "action_reenable",
    "approve_dashboard_export",
    "budget_spend",
    "delegate",
    "export_raw_evidence",
    "grant_authority",
    "learning_use",
    "privacy_waiver",
    "raw_partner_fragment_export",
    "release_without_receipt",
    "remedy",
    "repair",
    "reuse_as_authority",
    "semantic_repair",
}
REQUIRED_FORBIDDEN = {
    "ack_as_authority",
    "action_reenable",
    "action_without_packet",
    "authority_reuse_without_packet",
    "broader_scope",
    "budget_spend",
    "delegate_without_warrant",
    "export_without_receipt",
    "future_action",
    "learning_use",
    "old_channel_reuse",
    "privacy_waiver_without_packet",
    "recipient_scope_expansion",
    "release_without_receipt",
    "remedy_without_packet",
    "repair",
    "reuse_without_refresh",
    "stale_bundle_reuse",
    "successor_as_authority",
    "unprojected_disclosure",
}


def load_checker(path: Path, module_name: str):
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load checker {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

release_checker = load_checker(ROOT / "tools" / "check_governance_evidence_release_receipts.py", "ward_release_checker_for_chain")
followup_checker = load_checker(ROOT / "tools" / "check_governance_evidence_release_followups.py", "ward_followup_checker_for_chain")
transfer_checker = load_checker(ROOT / "tools" / "check_governance_succession_transfers.py", "ward_transfer_checker_for_chain")
CHECKER_BY_SCHEMA = {
    "ward.governance-evidence-release-receipt.v0": release_checker,
    "ward.governance-evidence-release-followup-receipt.v0": followup_checker,
    "ward.governance-succession-transfer-receipt.v0": transfer_checker,
}


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_time(value: str | None, field: str) -> datetime:
    if not value:
        raise ValueError(f"{field} missing")
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field} is not ISO-8601 parseable: {value}") from exc


def require(cond: bool, msg: str, errors: list[str]) -> None:
    if not cond:
        errors.append(msg)


def computed_chain_digest(ids: list[str], shas: list[str]) -> str:
    payload = "\n".join(f"{i}:{s}" for i, s in zip(ids, shas)).encode()
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def state_of(obj: dict[str, Any]) -> str | None:
    for key in ["release_decision", "followup_decision", "transfer_decision"]:
        if isinstance(obj.get(key), dict):
            return obj[key].get("state")
    return None


def release_id_of(obj: dict[str, Any]) -> str | None:
    schema = obj.get("schema")
    if schema == "ward.governance-evidence-release-receipt.v0":
        return obj.get("receipt_id")
    if schema == "ward.governance-evidence-release-followup-receipt.v0":
        return (obj.get("source_release_receipt_ref") or {}).get("receipt_id")
    if schema == "ward.governance-succession-transfer-receipt.v0":
        return ((obj.get("source_chain_ref") or {}).get("source_release_receipt_ref") or {}).get("receipt_id")
    return None


def purpose_of(obj: dict[str, Any]) -> str | None:
    schema = obj.get("schema")
    if schema == "ward.governance-evidence-release-receipt.v0":
        return (obj.get("release_request") or {}).get("purpose")
    if schema == "ward.governance-evidence-release-followup-receipt.v0":
        return (obj.get("followup_request") or {}).get("purpose")
    if schema == "ward.governance-succession-transfer-receipt.v0":
        return (obj.get("transfer_request") or {}).get("purpose")
    return None


def recipient_of(obj: dict[str, Any]) -> str | None:
    schema = obj.get("schema")
    if schema == "ward.governance-evidence-release-receipt.v0":
        return (obj.get("release_request") or {}).get("recipient_class")
    if schema == "ward.governance-evidence-release-followup-receipt.v0":
        return (obj.get("followup_request") or {}).get("recipient_class")
    if schema == "ward.governance-succession-transfer-receipt.v0":
        return (obj.get("transfer_request") or {}).get("recipient_class")
    return None


def projection_policy_of(obj: dict[str, Any]) -> str | None:
    schema = obj.get("schema")
    if schema == "ward.governance-evidence-release-receipt.v0":
        return (obj.get("release_request") or {}).get("projection_policy_digest")
    if schema == "ward.governance-evidence-release-followup-receipt.v0":
        return (obj.get("source_release_state") or {}).get("projection_policy_digest")
    if schema == "ward.governance-succession-transfer-receipt.v0":
        return (obj.get("continuity_checks") or {}).get("projection_policy_digest")
    return None


def item_digest_of(obj: dict[str, Any]) -> str | None:
    schema = obj.get("schema")
    if schema == "ward.governance-evidence-release-receipt.v0":
        return (obj.get("payload_manifest") or {}).get("item_digest")
    if schema == "ward.governance-evidence-release-followup-receipt.v0":
        return (obj.get("source_release_state") or {}).get("source_item_digest")
    if schema == "ward.governance-succession-transfer-receipt.v0":
        return (obj.get("continuity_checks") or {}).get("source_item_digest")
    return None


def resolve_member(member: dict[str, Any], errors: list[str]) -> dict[str, Any] | None:
    role = member.get("role")
    expected_schema = ROLES_TO_SCHEMA.get(role)
    if not expected_schema:
        errors.append("lineage member role invalid or missing")
        return None
    if member.get("receipt_schema") != expected_schema:
        errors.append(f"lineage member {member.get('receipt_id')} schema does not match role {role}")
    if member.get("receipt_sha256_checked") is not True:
        errors.append(f"lineage member {member.get('receipt_id')} was not digest-checked")
    rel = member.get("receipt_path")
    if not rel:
        errors.append("lineage member receipt_path missing")
        return None
    path = (ROOT / rel).resolve()
    try:
        path.relative_to(ROOT.resolve())
    except ValueError:
        errors.append(f"lineage member path escapes repository root: {rel}")
        return None
    if not path.exists():
        errors.append(f"lineage member path missing on disk: {rel}")
        return None
    actual_sha = sha256(path)
    if member.get("receipt_sha256") != actual_sha:
        errors.append(f"lineage member {member.get('receipt_id')} digest mismatch")
    obj = load_json(path)
    if member.get("receipt_id") != obj.get("receipt_id"):
        errors.append(f"lineage member {member.get('receipt_id')} id does not match referenced receipt")
    if obj.get("schema") != expected_schema:
        errors.append(f"referenced receipt schema does not match member role {role}")
    checker = CHECKER_BY_SCHEMA.get(obj.get("schema"))
    if checker is None:
        errors.append(f"no checker for referenced receipt schema {obj.get('schema')}")
    else:
        ref_errors = checker.validate_receipt(obj, path)
        if ref_errors:
            errors.append(f"referenced member {member.get('receipt_id')} is invalid: " + "; ".join(ref_errors))
    if member.get("observed_state") != state_of(obj):
        errors.append(f"lineage member {member.get('receipt_id')} observed_state does not mirror receipt")
    if member.get("observed_time") != obj.get("receipt_time"):
        errors.append(f"lineage member {member.get('receipt_id')} observed_time does not mirror receipt")
    mirrors = {
        "source_release_id": release_id_of(obj),
        "purpose": purpose_of(obj),
        "recipient_class": recipient_of(obj),
        "projection_policy_digest": projection_policy_of(obj),
        "source_item_digest": item_digest_of(obj),
    }
    for field, expected in mirrors.items():
        if member.get(field) != expected:
            errors.append(f"lineage member {member.get('receipt_id')} {field} does not mirror receipt")
    return obj


def top_level_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    require(receipt.get("schema") == "ward.governance-chain-integrity-receipt.v0", "wrong or missing schema", errors)
    require(receipt.get("receipt_name") == "ward.governance.chain-integrity-receipt.v0", "wrong or missing receipt_name", errors)
    require(receipt.get("authority_surface") == "chain_integrity_receipt_only", "authority_surface must be chain_integrity_receipt_only", errors)
    try:
        parse_time(receipt.get("receipt_time"), "receipt_time")
    except ValueError as exc:
        errors.append(str(exc))


def lineage_ok(receipt: dict[str, Any], errors: list[str]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    members = receipt.get("lineage_members") or []
    if len(members) < 2:
        errors.append("lineage_members must have at least two members")
    indexes = [m.get("order_index") for m in members]
    if indexes != sorted(indexes) or len(set(indexes)) != len(indexes):
        errors.append("lineage member order_index values must be monotonic and unique")
    if indexes and indexes[0] != 1:
        errors.append("lineage member order_index must start at 1")
    roles = [m.get("role") for m in members]
    if roles.count("release") != 1 or (roles and roles[0] != "release"):
        errors.append("lineage must contain exactly one release member at the head")
    objects: list[dict[str, Any]] = []
    for member in members:
        obj = resolve_member(member, errors)
        if obj:
            objects.append(obj)
    return members, objects


def chain_digest_ok(receipt: dict[str, Any], members: list[dict[str, Any]], errors: list[str]) -> None:
    d = receipt.get("chain_digest") or {}
    ids = [m.get("receipt_id") for m in members]
    shas = [m.get("receipt_sha256") for m in members]
    if d.get("ordered_receipt_ids") != ids:
        errors.append("chain_digest.ordered_receipt_ids does not match lineage order")
    if d.get("ordered_receipt_sha256") != shas:
        errors.append("chain_digest.ordered_receipt_sha256 does not match lineage order")
    if not d.get("computed"):
        errors.append("chain_digest.computed missing")
    elif d.get("computed") != computed_chain_digest(ids, shas):
        errors.append("chain_digest.computed does not match ordered member ids and digests")


def scope_and_continuity_ok(receipt: dict[str, Any], members: list[dict[str, Any]], errors: list[str]) -> None:
    scope = receipt.get("chain_scope") or {}
    checks = receipt.get("continuity_checks") or {}
    first = members[0] if members else {}
    for field in ["source_release_id", "recipient_class", "purpose", "source_item_digest", "projection_policy_digest"]:
        if scope.get(field) != first.get(field if field != "source_release_id" else "receipt_id") and field == "source_release_id":
            pass
        # explicit checks below avoid the awkward release id/field distinction
    if first:
        if scope.get("source_release_id") != first.get("receipt_id"):
            errors.append("chain_scope.source_release_id does not match release member")
        for field in ["recipient_class", "purpose", "source_item_digest", "projection_policy_digest"]:
            if scope.get(field) != first.get(field):
                errors.append(f"chain_scope.{field} does not match release member")
    for member in members:
        if member.get("source_release_id") != scope.get("source_release_id"):
            errors.append(f"member {member.get('receipt_id')} source_release_id is outside chain scope")
        for field in ["recipient_class", "purpose", "source_item_digest"]:
            if member.get(field) != scope.get(field):
                errors.append(f"member {member.get('receipt_id')} {field} is outside chain scope")
        # Projection-policy changes are allowed only if explicitly held; v0 fixtures keep it constant.
        if member.get("projection_policy_digest") != scope.get("projection_policy_digest"):
            errors.append(f"member {member.get('receipt_id')} projection policy drift is not declared")
    required_true = [
        "all_member_digests_checked",
        "order_indexes_monotonic",
        "release_member_unique",
        "followups_match_source_release",
        "transfers_match_source_chain",
        "latest_followup_dependency_present_before_transfer",
        "purpose_constant",
        "recipient_constant",
        "projection_policy_constant_or_declared",
        "source_item_digest_constant",
        "no_stale_artifact_reuse",
        "no_authority_upgrade",
    ]
    for field in required_true:
        if checks.get(field) is not True:
            errors.append(f"continuity_checks.{field} must be true")
    # Verify each transfer's latest follow-up, if any, appears earlier in the chain.
    seen = set()
    for member in members:
        if member.get("role") == "transfer" and member.get("latest_followup_id"):
            if member.get("latest_followup_id") not in seen:
                errors.append(f"transfer {member.get('receipt_id')} latest_followup_id does not appear earlier in lineage")
        seen.add(member.get("receipt_id"))
    transfer_members = [m for m in members if m.get("role") == "transfer"]
    if transfer_members and not checks.get("old_status_channels_invalidated"):
        errors.append("continuity_checks.old_status_channels_invalidated must be true when transfers are present")
    for member in transfer_members:
        if member.get("old_status_channel_invalidated") is not True:
            errors.append(f"transfer {member.get('receipt_id')} leaves old status channel active")


def head_and_fork_ok(receipt: dict[str, Any], members: list[dict[str, Any]], errors: list[str]) -> None:
    head = receipt.get("canonical_head") or {}
    fork = receipt.get("fork_resolution") or {}
    decision = receipt.get("chain_decision") or {}
    fork_state = fork.get("fork_state")
    if fork_state not in FORK_STATES:
        errors.append("fork_resolution.fork_state invalid or missing")
    decision_state = decision.get("state")
    if decision_state not in VALID_STATES:
        errors.append("chain_decision.state invalid or missing")
    transfer_members = [m for m in members if m.get("role") == "transfer"]
    last_transfer = transfer_members[-1] if transfer_members else None
    if fork_state in {"detected", "quarantined"}:
        if decision_state not in {"fork_detected_hold", "disputed_head_quarantined"}:
            errors.append("detected/quarantined fork must not be recorded as canonical")
        if fork.get("no_current_head") is not True:
            errors.append("forked chain must set no_current_head")
        if fork.get("noncanonical_branch_reuse_allowed") is not False:
            errors.append("noncanonical branch reuse must be forbidden")
        if head.get("head_receipt_id") is not None:
            errors.append("fork hold must not publish a canonical head receipt id")
        if decision.get("release_reuse_state") != "held_due_to_fork":
            errors.append("forked chain must hold release reuse")
    else:
        if fork.get("branch_count") != 1:
            errors.append("non-forked chain must have branch_count 1")
        if head.get("no_open_noncanonical_heads") is not True:
            errors.append("canonical chain must assert no open noncanonical heads")
        if last_transfer:
            if head.get("head_receipt_id") != last_transfer.get("receipt_id"):
                errors.append("canonical head must be the latest transfer member")
            if head.get("head_receipt_role") != "transfer":
                errors.append("canonical head role must be transfer when transfers are present")
            if head.get("head_state") != last_transfer.get("observed_state"):
                errors.append("canonical head state does not mirror latest transfer")
        if decision_state == "canonical_head_recorded" and not last_transfer:
            errors.append("canonical_head_recorded requires a transfer head")
        if head.get("old_channels_invalidated") is not True:
            errors.append("canonical_head.old_channels_invalidated must be true")
    if head.get("reuse_allowed_without_refresh") is not False:
        errors.append("canonical_head.reuse_allowed_without_refresh must be false")


def projection_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    scope = receipt.get("chain_scope") or {}
    proj = receipt.get("projection_safety") or {}
    public = scope.get("recipient_class") in PUBLIC_RECIPIENTS or proj.get("projection_class") == "public_minimized"
    if proj.get("no_authority_label_present") is not True:
        errors.append("projection_safety.no_authority_label_present must be true")
    if "not authority" not in str(proj.get("watermark_label", "")).lower():
        errors.append("projection_safety.watermark_label must say not authority")
    sensitive_fields = [
        "private_branch_evidence_released",
        "sealed_evidence_inline",
        "reveals_private_org_map",
        "reveals_raw_partner_fragments",
        "reveals_reviewer_identities",
    ]
    for field in sensitive_fields:
        if proj.get(field) is not False:
            errors.append(f"projection_safety.{field} must be false")
    if public:
        if proj.get("public_named_steward_ids_released") is not False:
            errors.append("public chain receipt must not release named steward ids")
        if proj.get("no_exact_hidden_counts_public") is not True:
            errors.append("public chain receipt must not reveal exact hidden counts")


def effects_ok(receipt: dict[str, Any], members: list[dict[str, Any]], errors: list[str]) -> None:
    effects = receipt.get("effect_closure") or {}
    performed = set(effects.get("effects_performed") or [])
    preserved = set(effects.get("forbidden_effects_preserved") or [])
    if effects.get("safe_chain_effects_only") is not True:
        errors.append("effect_closure.safe_chain_effects_only must be true")
    if effects.get("no_high_consequence_effects") is not True:
        errors.append("effect_closure.no_high_consequence_effects must be true")
    if effects.get("no_authority_upgrade") is not True:
        errors.append("effect_closure.no_authority_upgrade must be true")
    extra = performed - SAFE_CHAIN_EFFECTS
    if extra:
        errors.append("effect_closure has non-chain effects: " + ", ".join(sorted(extra)))
    high = performed & HIGH_CONSEQUENCE_EFFECTS
    if high:
        errors.append("effect_closure performs high consequence effects: " + ", ".join(sorted(high)))
    missing_required = REQUIRED_FORBIDDEN - preserved
    if missing_required:
        errors.append("effect_closure missing required forbidden effects: " + ", ".join(sorted(missing_required)))
    for member in members:
        source_forbidden = set(member.get("forbidden_effects_preserved") or [])
        missing = source_forbidden - preserved
        if missing:
            errors.append(f"effect_closure drops forbidden effects from {member.get('receipt_id')}: " + ", ".join(sorted(missing)))


def decision_ok(receipt: dict[str, Any], errors: list[str]) -> None:
    decision = receipt.get("chain_decision") or {}
    if decision.get("state") not in VALID_STATES:
        errors.append("chain_decision.state invalid or missing")
    if not decision.get("reason_codes"):
        errors.append("chain_decision.reason_codes missing")
    if decision.get("no_authority_granted") is not True:
        errors.append("chain_decision.no_authority_granted must be true")
    if decision.get("release_reuse_state") not in {"refresh_required", "held_due_to_fork", "held_until_acceptance", "quarantined", "historical_only"}:
        errors.append("chain_decision.release_reuse_state invalid or missing")
    if decision.get("state") == "successor_pending_recheck" and decision.get("release_reuse_state") != "held_until_acceptance":
        errors.append("successor_pending_recheck must hold release reuse until acceptance")


def validate_receipt(receipt: dict[str, Any], path: Path) -> list[str]:
    errors: list[str] = []
    top_level_ok(receipt, errors)
    members, _ = lineage_ok(receipt, errors)
    chain_digest_ok(receipt, members, errors)
    scope_and_continuity_ok(receipt, members, errors)
    head_and_fork_ok(receipt, members, errors)
    projection_ok(receipt, errors)
    effects_ok(receipt, members, errors)
    decision_ok(receipt, errors)
    return errors


def main() -> int:
    valid_paths = sorted(CHAIN_DIR.glob("*.valid.json"))
    invalid_paths = sorted((CHAIN_DIR / "negative").glob("*.invalid.json"))
    if not valid_paths:
        print("No valid governance chain-integrity fixtures found.")
        return 1
    if not invalid_paths:
        print("No negative governance chain-integrity fixtures found.")
        return 1
    failures: list[str] = []
    for path in valid_paths:
        errors = validate_receipt(load_json(path), path)
        if errors:
            failures.append(f"{path} should be valid but failed:\n  - " + "\n  - ".join(errors))
    for path in invalid_paths:
        errors = validate_receipt(load_json(path), path)
        if not errors:
            failures.append(f"{path} should be invalid but passed")
    if failures:
        print("Governance chain-integrity check failed.")
        for failure in failures:
            print(failure)
        return 1
    print(f"Governance chain-integrity check passed ({len(valid_paths)} valid, {len(invalid_paths)} negative fixtures).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
