# ADR-0000: Template

## Status
Proposed / Accepted / Deprecated

## Context
What problem are we solving?

## Decision
What did we decide?

## Consequences
What becomes easier/harder now?
