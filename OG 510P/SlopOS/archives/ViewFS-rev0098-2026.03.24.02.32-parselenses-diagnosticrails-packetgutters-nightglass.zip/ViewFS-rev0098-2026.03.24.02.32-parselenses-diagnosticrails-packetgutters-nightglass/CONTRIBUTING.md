# Contributing

This repository is an archive of *our* specs, invariants, decisions, and evidence pointers.

## Contribution types
- **Research note**: add a REF entry in `docs/00-meta/bibliography.md` (<=3 bullets: key idea / why / implication).
- **RFC**: propose a change with alternatives + evidence plan (`rfcs/`).
- **ADR**: record a decision once evidence exists (`adrs/`).
- **Evidence**: register internal artifacts in `docs/00-meta/evidence-index.md`.

## Hard rules
- Every new security/correctness claim must map to Claim IDs + Invariant IDs.
- Every new assumption must be added to the threat model with an ID.
- Prefer citations over quotes; avoid large pasted external text.
- Do not silently harden a tentative posture into a commitment; move unresolved design energy into open questions.

## Review gates
- Anything that changes authority, persistence, revocation, or path-compat semantics requires updates to:
  - `docs/10-threat-model/assumption-registry.md`
  - `docs/20-assurance/claim-registry.md`
  - `docs/20-assurance/invariant-registry.md`
  - one architecture posture doc or RFC
