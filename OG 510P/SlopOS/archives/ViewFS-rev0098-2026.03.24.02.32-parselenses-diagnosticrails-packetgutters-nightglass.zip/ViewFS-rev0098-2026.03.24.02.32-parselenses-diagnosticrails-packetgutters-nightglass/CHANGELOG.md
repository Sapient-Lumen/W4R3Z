# Changelog

## Revised098 (2026-03-24)
- Continued online research on incremental parsing, syntax-highlighting honesty, advisory shell diagnostics, and the distinction between parsed structure, compiled packets, and prepared actions.
- Added `rfcs/0090-viewfs-keep-editable-buffers-parsed-structures-advisory-diagnostics-compiled-command-packets-prepared-actions-and-receipts-separate.md` so buffer text, parser/highlight structure, diagnostics, compiled packets, prepared actions, and durable receipts stay on distinct seams.
- Added `docs/30-architecture/editable-buffers-parsed-structures-advisory-diagnostics-and-compiled-packets.md` and `docs/70-shell/parse-lenses-diagnostic-rails-and-packet-gutters.md` to capture the new shell-editing seam and collect shell ideas around parse lenses, recovery veils, diagnostic rails, packet gutters, and compile-diff cards.
- Refreshed the architecture overview, design splits, SlopOS seam map, inspiration docs, SlopOS evaluation, shell super-awesome moves, shell terminal ideas, and shell terminal protocol sketch with the new research.
- Expanded bibliography, moving-head source tracking, review queue, evidence index, context-pack coverage, and lint requirements; regenerated `out/context_pack.md` and restamped the release manifest for the new archive.

## Revised097 (2026-03-24)
- Continued external research on typed abbreviation/alias expansion, overlay/module activation, command-palette and key-table interaction layers, and honest command-surface resolution for a future custom ViewFS shell.
- Added `docs/30-architecture/command-surface-layers-key-actions-and-external-launches.md` so built-in verbs, lexical expansions, semantic command layers, key actions/widgets, external launches, and durable receipts stay class-aware.
- Added `docs/70-shell/verb-provenance-cards-overlay-racks-and-keytable-lamps.md` to collect shell ideas around verb provenance cards, abbr gutters, overlay racks, key-table lamps, and which ladders.
- Added `rfcs/0089-viewfs-keep-built-in-verbs-lexical-expansions-semantic-command-layers-key-actions-external-launches-and-receipts-separate.md` to freeze the new command-surface seam while leaving alias models, overlay formats, and palette protocols intentionally undecided.
- Refreshed the architecture overview, design splits, SlopOS seam map, inspiration map, SlopOS evaluation, shell super-awesome moves, and shell-terminal protocol sketch with the new research.
- Expanded bibliography, moving-head source tracking, review queue, evidence index, context-pack coverage, and lint requirements; regenerated `out/context_pack.md` and restamped the release manifest for the new archive.

## Revised096 (2026-03-23)
- Continued online research on shell startup honesty, explicit customization bundles, ambient startup/profile scripts, project-local activation hooks, and terminal integration provenance.
- Added `rfcs/0088-viewfs-keep-built-in-shell-affordances-explicit-customization-bundles-startup-files-project-hooks-and-receipts-separate.md` to keep custom-shell delight separate from ambient startup lore.
- Added `docs/30-architecture/built-in-shell-affordances-customization-bundles-startup-files-and-project-hooks.md` and `docs/70-shell/clean-start-lamps-bundle-ledgers-and-hook-quarantine.md` to capture the new shell/startup seam and collect shell/terminal product ideas around clean-start lamps, bundle ledgers, prompt provenance, and hook quarantine.
- Refreshed architecture overview, design splits, SlopOS seam map, inspiration docs, shell notes, bibliography/review tracking, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revision 0095 — 2026-03-23
- add `rfcs/0087-viewfs-keep-native-attaches-adapted-attaches-coerced-representations-local-realizations-and-receipts-separate.md`, freezing the rule that native attaches, adapted attaches, coerced representations, local realizations, and receipts/history remain separate truths instead of collapsing into one flattering `opened natively` story
- add `docs/30-architecture/native-attaches-adapted-attaches-coerced-representations-and-local-realizations.md`, sharpening the architecture split between direct receiver-native fit, wrapper/relay-backed usability, alternate typed representations, explicit make-local transitions, and durable aftermath while SlopOS is still deciding deeper object-store and portal machinery
- add `docs/70-shell/attach-mode-badges-adapter-veils-and-virtuality-lamps.md`, capturing shell/terminal moves like attach-mode badges, adapter veils, virtuality lamps, same-object-versus-translated drawers, and make-local-for-native ladders for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new native/adapted/coerced/localized seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for Android SAF virtual files and WIT resource handles; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revision 0094 — 2026-03-23
- add `rfcs/0086-viewfs-keep-privilege-brackets-borrowed-authority-call-chain-contexts-deny-only-hints-and-receipts-separate.md`, freezing the rule that privilege brackets, borrowed authority, call-chain context, deny-only routing hints, and receipts/history remain separate truths instead of collapsing into one flattering `helper did it` story
- add `docs/30-architecture/privilege-brackets-borrowed-authority-call-chain-contexts-and-deny-only-hints.md`, sharpening the architecture split between bounded helper execution, real borrowed handles, non-authoritative caller provenance, deny-only veto posture, and durable aftermath while SlopOS is still deciding deeper helper/runtime carriers
- add `docs/70-shell/bracket-rails-caller-badges-and-who-asked-drawers.md`, capturing shell/terminal moves like bracket rails, caller badges, who-asked drawers, deputy-fog warnings, deny-only shutters, and borrowed-authority drawers for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new bracket/borrowed-authority/call-context seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for Hardy’s confused deputy paper, Java Scoped Values, Python `contextvars`, Node `AsyncLocalStorage`, and ASP.NET’s ambient-state caution; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revised093 (2026-03-23)
- Continued online research on Plan 9 plumbing, Android Intent URI-grant behavior, XDG request lifetimes, Wayland representation offers, and shell-side route/authority honesty.
- Added `docs/30-architecture/route-envelopes-authority-sidecars-sink-bindings-and-receipts.md` to keep typed route capsules, optional authority sidecars, sink-side acceptance/bind/import, and durable receipts on distinct seams.
- Added `docs/70-shell/route-slips-authority-sidecars-and-sink-trays.md` to collect ideas around route slips, designation-only pills, sidecar chips, sink trays, and dry-run route diffs.
- Added `rfcs/0085-viewfs-keep-route-envelopes-authority-sidecars-sink-bindings-and-receipts-separate.md` so future proposals must classify whether they change routing, sidecars, sink consequence, or only history.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography/review tracking, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised092 (2026-03-23)
- Continued online research on receiver-side import/adoption truth, foreign-backed provider usability, projected local views, explicit localization, and shell/terminal semantics that can tell `borrowed here`, `projected here`, and `local here` apart.
- Added `rfcs/0084-viewfs-keep-foreign-backed-borrows-compat-attaches-projected-imports-local-realizations-and-receipts-separate.md` so foreign-backed borrows, compat attaches, projected imports, local realizations, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/foreign-backed-borrows-compat-attaches-projected-imports-and-local-realizations.md` and `docs/70-shell/borrow-rails-projection-badges-and-make-here-ladders.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with borrow rails, projection badges, make-here ladders, provider-owned halos, and dataless/materialized lamps.
- Expanded bibliography/source tracking/review queue with Apple File Provider materialization and Fuchsia explicit namespace-entry precedents.
- Updated context-pack/lint coverage so RFC 0084 and the new architecture/shell docs ride along automatically.

## Revised091 (2026-03-23)
- Continued online research on local duplication, live-handle lending, representation-export fallbacks, portal/file-transfer mediation, and shell/terminal semantics that can tell `held here`, `lendable here`, `bytes only`, and `history only` apart.
- Added `rfcs/0083-viewfs-keep-current-possession-local-duplication-live-lends-representation-exports-and-receipts-separate.md` so current possession, local duplication, live lends, representation exports, and receipts/history stay visibly distinct.
- Added `docs/30-architecture/current-possession-local-duplication-live-lends-and-representation-exports.md` and `docs/70-shell/lend-ladders-lane-fit-badges-and-bytes-only-fallbacks.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with lend ladders, lane-fit badges, bytes-only fallbacks, share sheets, and same-object-versus-new-representation drawers.
- Expanded bibliography/source tracking/review queue with Mach port rights, seL4 Grant/GrantReply transfer rules, and kitty TTY file-transfer precedents.
- Updated context-pack/lint coverage so RFC 0083 and the new architecture/shell docs ride along automatically.

## Revision 0090 — 2026-03-23
- add `rfcs/0082-viewfs-keep-live-possession-status-carriers-local-holds-successor-refresh-and-receipts-separate.md`, freezing the rule that live possession, watch/status carriers, local hold/quarantine posture, successor/refresh posture, post-watch invocability, and receipts/history remain separate truths instead of collapsing into one vague `still valid` story
- add `docs/30-architecture/live-possession-status-carriers-local-holds-and-successor-refresh.md`, sharpening the architecture split between what is still held here, what later status material says, how the local receiver reacts, what hold or quarantine is active, what successor/refresh is owed, and what is invokable now after watch processing
- add `docs/70-shell/watch-braids-hold-rails-and-successor-lanterns.md`, capturing shell/terminal moves like watch braids, hold rails, successor lanterns, stale-watch fog, and quarantine shutters for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new live-possession / watch-status / hold / successor seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for RFC 7662 token introspection, RFC 7009 token revocation, W3C Bitstring Status List v1.0, RFC 6960 OCSP, RFC 5280 `certificateHold` / `removeFromCRL`, and TUF freshness / root rotation; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revision 0089 — 2026-03-23
- add `rfcs/0081-viewfs-keep-current-possession-freshness-step-up-current-invocability-and-receipts-separate.md`, freezing the rule that current possession, freshness/recency posture, step-up posture, local presence/user-verification posture, current invocability, and receipts/history remain separate truths instead of collapsing into one vague `authorized now` story
- add `docs/30-architecture/current-possession-freshness-step-up-and-current-invocability.md`, sharpening the architecture split between what is held here, what is fresh enough, what still needs stronger auth or local presence, what is invokable now, and what is merely historical trace while SlopOS is still deciding deeper auth-mediation and capability-store mechanics
- add `docs/70-shell/step-up-ladders-recency-shutters-and-why-not-now-drawers.md`, capturing shell/terminal moves like step-up ladders, recency shutters, presence pins, satisfaction ghosts, and why-not-now drawers for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new possession/freshness/invocability seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for RFC 9470 step-up auth, OIDC `max_age` / `auth_time`, WebAuthn presence/verification, and Android Keystore authentication gating; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revision 0088 — 2026-03-23
- add `rfcs/0080-viewfs-keep-claim-tickets-holder-bound-grants-passable-live-handles-spent-tickets-and-receipts-separate.md`, freezing the rule that redeemable claim tickets, holder-bound grants, passable live handles, spent/expired tickets, and receipts/history remain separate truths instead of collapsing into one vague `token` or `handle`
- add `docs/30-architecture/claim-tickets-holder-bound-grants-and-spent-receipts.md`, sharpening the architecture split between redeemable authority, holder-proof-gated authority, freely passable live handles, and anti-replay historical traces while SlopOS is still deciding deeper object-store and portal machinery
- add `docs/70-shell/redemption-ladders-holder-proof-badges-and-spent-ghosts.md`, capturing shell/terminal moves like redemption ladders, holder-proof badges, burn-after-use chips, proof drawers, and spent ghosts for a future capability-native transcript UI
- refresh `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/90-inspirations/slopos-datacube-evaluation.md`, and `docs/90-inspirations/inspirations-mapped.md` so this new claim/holder-bound/passable/spent seam is reflected across the design surface without overfreezing the backend
- add bibliography, head-register, and review-queue coverage for OAuth authorization codes, DPoP, and Android PendingIntent replay guidance; regenerate `out/context_pack.md`; restamp `RELEASE-MANIFEST.json`; and keep `make lint` clean

## Revised087 (2026-03-23)
- Continued online research on provider-ready versus locally realized truth, promisor/substituter models, restore/reacquire obligations, and shell/terminal semantics that can tell `can be supplied later` apart from `exists here now`.
- Added `rfcs/0079-viewfs-keep-provider-ready-claims-reacquire-obligations-local-realizations-live-handles-and-receipts-separate.md` so provider-ready claims, reacquire/repair duties, local realizations, live handles, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/provider-ready-claims-reacquire-obligations-local-realizations-and-live-handles.md` and `docs/70-shell/make-local-ladders-provider-owned-badges-and-repair-rails.md`, and refreshed architecture/shell notes with make-local ladders, provider-owned badges, repair rails, offline fog, and locality lamps.
- Refreshed `docs/90-inspirations/slopos-datacube-evaluation.md`, `docs/90-inspirations/inspirations-mapped.md`, bibliography, external-source head/review registers, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.
## Revised086 (2026-03-23)
- Continued online research on published/discoverable presence, freshness-scoped readiness, mediated grant-needed posture, and semantic shell/terminal metadata while keeping SlopOS design-phase uncertainty front and center.
- Added `rfcs/0078-viewfs-keep-presence-adverts-readiness-current-authority-and-receipts-separate.md` so provider/catalog presence, readiness/serving truth, grant-needed posture, current authority, and receipts/history stay visibly distinct.
- Added `docs/30-architecture/presence-adverts-readiness-current-authority-and-receipts.md` and `docs/70-shell/presence-halos-readiness-lamps-and-withdrawn-ghosts.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with presence halos, readiness lamps, withdrawn ghosts, grant-needed ladders, and advert ledgers.
- Expanded bibliography/source tracking/review queue with Fuchsia outgoing-capability, MCP roots, DNS-SD, and Kubernetes EndpointSlice precedents.
- Updated context-pack/lint coverage so RFC 0078 and the new architecture/shell docs ride along automatically.

## Revised085 (2026-03-23)
- Continued online research on search permission, browse/list disclosure, exact-name opens under held roots, match-quality mediation, and semantic shell/terminal metadata while keeping SlopOS design-phase uncertainty front and center.
- Added `rfcs/0077-viewfs-keep-discoverability-enumeration-exact-opens-fit-notes-and-receipts-separate.md` so direct authority, exact-name reachability, enumeration/listability, advisory fit notes/suggestions, and receipts/history stay visibly distinct.
- Added `docs/30-architecture/discoverability-enumeration-exact-name-reachability-and-fit-notes.md` and `docs/70-shell/dark-directories-known-name-chips-and-browse-gates.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with dark directories, known-name chips, browse gates, fit sheets, and search-result dimmers.
- Expanded bibliography/source tracking/review queue with Linux `access(2)` and WASI rights precedents.
- Updated context-pack/lint coverage so RFC 0077 and the new architecture/shell docs ride along automatically.

## Revised084 (2026-03-23)
- Continued online research on explicit handle authority, rooted compat walkers, portal/powerbox mediation, content-addressed archival stores, imported namespace fragments, and semantic terminal metadata while keeping SlopOS design-phase uncertainty front and center.
- Added `rfcs/0076-viewfs-keep-explicit-handle-opens-rooted-compat-pathwalks-ambient-escapes-and-receipts-separate.md` so direct-handle opens, rooted compat walks, portal-mediated grants/projections, ambient host escapes, and receipts/history stay visibly distinct.
- Added `docs/30-architecture/explicit-handle-opens-rooted-compat-pathwalks-and-ambient-escapes.md` and `docs/70-shell/ambient-debt-sirens-safe-open-ladders-and-escape-hatch-receipts.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with safe-open ladders, ambient-debt sirens, route provenance drawers, and replace-this-debt affordances.
- Expanded bibliography/source tracking/review queue with Sandstorm powerbox, Foundation CAS, and Plan 9 import precedents.
- Updated context-pack/lint coverage so RFC 0076 and the new architecture/shell docs ride along automatically.

## Revised083 (2026-03-23)
- Continued online research on Plan 9 per-process namespaces, Fuchsia namespace publication and dictionary capabilities, XDG request/file/document portal restricted views, and shell/terminal semantics that can tell `in store`, `projected`, `live now`, `published here`, and `history only` apart.
- Added `rfcs/0075-viewfs-keep-store-membership-synthetic-views-live-handles-published-names-and-receipts-separate.md` so store membership, synthetic/mediated view projection, live authority, current publication, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/store-membership-synthetic-views-live-handles-and-published-names.md` and `docs/70-shell/published-name-ledgers-and-synthetic-view-badges.md`, then refreshed architecture, shell, inspiration, and SlopOS evaluation notes with published-name ledgers, synthetic-view badges, publish-here ladders, and projection/locality truth.
- Refreshed the source-head register/review queue and cleaned the stale nested prior-archive folder out of the repo before packaging the new archive.
- Updated context-pack/lint coverage so RFC 0075 and the new architecture/shell docs ride along automatically.

## Revised082 (2026-03-23)
- Continued online research on per-process namespaces, startup-delivered handles, narrow continuity lockers, explicit local handle courier lanes, badged handle copies, and semantic terminal protocols while keeping SlopOS design-phase uncertainty front and center.
- Added `docs/30-architecture/activation-carriers-badged-handle-copies-and-object-identity.md` to pin the low-regret seam between activation carriers, live handle copies, issuer badges/witnesses, immutable object refs, local binds, later revival designators, and receipts/history.
- Added `docs/70-shell/activation-slots-issuer-badges-and-handoff-sheets.md` and refreshed shell notes/protocol sketches with activation-sheet cards, child-slot maps, copy-lineage drawers, handoff sheets, issuer chips, paste/import capsules, and truth-grade command blocks.
- Refreshed the architecture overview, design-splits, SlopOS seam map, inspiration map, SlopOS datacube evaluation, README hygiene, source-head tracking, and evidence index for the new startup/handoff seam.
- Updated context-pack/lint coverage so the new architecture/shell docs ride along automatically.

## Revised081 (2026-03-23)
- Continued external research on exact-basis delta application, reconstruction, and honest fallback lanes for ViewFS while keeping SlopOS datacube alignment explicit.
- Added `rfcs/0074-viewfs-keep-delta-recipes-exact-bases-apply-sessions-reconstructed-objects-and-receipts-separate.md`.
- Added architecture and shell notes for delta recipes, basis cards, apply ladders, and rebuilt-from lineage.
- Refreshed the SlopOS seam map, datacube evaluation, inspiration map, bibliography, external-source review tracking, and evidence index.
- Updated context-pack/lint coverage so the new RFC and docs ride along automatically.

## Revised080 (2026-03-23)
- Continued online research on sparse/local byte coverage, range requests, lazy pulling, multipart checksum caveats, and chunked-object layouts.
- Added `rfcs/0073-viewfs-keep-partial-residency-chunk-layouts-whole-object-proofs-live-range-sessions-and-receipts-separate.md` to keep partial residency, layout metadata, whole-object proofs, live range sessions, and receipts intentionally decoupled.
- Added `docs/30-architecture/partial-residency-chunk-layouts-and-whole-object-proofs.md` to capture the design posture around sparse objects, completeness truth, proof strength, and remote-fill reachability without prematurely standardizing one sparse-store schema.
- Added `docs/70-shell/hole-maps-range-panels-and-whole-proof-ladders.md` so the custom shell+terminal ambition is grounded in honest sparse/full/proof semantics rather than one fake download state.
- Refreshed architecture overview, design-splits, SlopOS seam map, inspiration mapping, SlopOS datacube evaluation, bibliography/source tracking, evidence index, context-pack coverage, and release manifest for the new research pass.

## Revised079 (2026-03-23)
- Continued online research on version validators, guarded writes, compare-and-swap mutation, writable staging sessions, coordination holds, and shell/terminal UX that can tell `observed base`, `draft`, `hold`, `commit gate`, and `winning durable version` apart.
- Added `rfcs/0072-viewfs-keep-observed-validators-writable-sessions-write-holds-commit-preconditions-committed-versions-and-receipts-separate.md` so observed validators/bases, private writable sessions, live write holds, exact commit preconditions, winning committed versions, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/observed-validators-writable-sessions-and-commit-cuts.md` and `docs/70-shell/draft-gutters-commit-shutters-and-stale-base-lamps.md`, then refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/inspirations-mapped.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new validator/draft/commit seam and shell payoffs.
- Expanded bibliography/source tracking/review queue/evidence index with HTTP conditional request, Cloud Storage precondition, and File System Access writable-session precedents.
- Fixed repo hygiene so context-pack and lint coverage now carry RFC 0072 and the new architecture/shell docs before packaging the new archive.

## Revised078 (2026-03-23)
- Continued online research on watch bookmarks, continuation cursors, sync watermarks, longpoll/watch resume semantics, explicit rescan/relist flows, and shell/terminal UX that can tell `cursor`, `caught up through`, `following now`, `rebuilt set`, and `gap verdict` apart.
- Added `rfcs/0071-viewfs-keep-continuation-cursors-sync-watermarks-live-subscriptions-rebuilt-snapshots-gap-verdicts-and-receipts-separate.md` so provider continuation tokens, sync watermarks, live follow state, rebuilt snapshots, gap/reset verdicts, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/continuation-cursors-watermarks-and-live-subscriptions.md` and `docs/70-shell/waterline-cards-gap-badges-and-resync-ladders.md`, then refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, `docs/90-inspirations/inspirations-mapped.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new cursor/watermark/subscription/rebuild seam and shell payoffs.
- Expanded bibliography/source tracking/review queue/evidence index with Kubernetes watch/bookmark, Dropbox change cursor, Watchman clockspec, and Apple FSEvents rescan precedents.
- Fixed repo hygiene so context-pack and lint coverage now carry RFC 0071 before packaging the new archive.

## Revised077 (2026-03-23)
- Continued online research on label taxonomies, selector-safe grouping keys, policy-bearing labels, trusted chrome badges, and shell/terminal semantics that can tell `annotation`, `selector`, `policy`, `trusted badge`, and `history` apart.
- Added `rfcs/0070-viewfs-keep-advisory-annotations-selector-labels-policy-labels-trusted-badges-and-receipts-separate.md` so freeform annotations, selector labels, policy-bearing labels, trusted chrome badges, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/annotations-selector-labels-policy-labels-and-trusted-badges.md` and `docs/70-shell/label-chips-selector-rails-and-trusted-badges.md`, then refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/90-inspirations/inspirations-mapped.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new label/selector/policy/chrome seam and shell payoffs.
- Expanded bibliography/source tracking/review queue/evidence index with Kubernetes, OCI annotations, SELinux, TLP, iTerm2 badge/status, and WezTerm right-status precedents.
- Fixed repo hygiene so context-pack and lint coverage now carry RFC 0069, RFC 0070, and the new architecture/shell docs before packaging the new archive.

## Revised076 (2026-03-23)
- Continued online research on declared-versus-derived type evidence, MIME/type databases, handler/default association layers, preview-versus-open boundaries, and shell/terminal semantics that can tell `claimed type`, `derived type`, `associated handler`, `chosen opener`, and `live editor/viewer state` apart.
- Added `rfcs/0069-viewfs-keep-declared-types-derived-types-handler-associations-chosen-openers-live-open-state-and-receipts-separate.md` so type claims, derived classifications, handler associations, chosen openers, live open state, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/type-evidence-handler-choice-and-live-open-state.md` and refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` with the new type/handler/open-state seam and a sharper evaluation of what SlopOS OpenURI / typed-payload / content-type boundaries do and do not settle.
- Added `docs/70-shell/type-lenses-handler-racks-and-open-state-badges.md` and refreshed `docs/70-shell/shell-super-awesome-moves.md` and `docs/70-shell/shell-terminal-ideas.md` with type lenses, handler racks, disagreement cards, why-this-opener drawers, and open-state badges for the future custom shell+terminal.
- Refreshed `docs/90-inspirations/slopos-datacube-evaluation.md`, `docs/90-inspirations/inspirations-mapped.md`, bibliography, moving-head tracking, review queue, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revised075 (2026-03-23)
- Continued online research on stable object identity versus current placement, locate-only versus broader live handle rights, explicit provider-advertised affordances, and shell/terminal semantics that can tell `same object` from `same placement` and `supported in principle` from `permitted with what you hold`.
- Added `rfcs/0068-viewfs-keep-object-identity-view-placement-current-handle-rights-advertised-operations-and-receipts-separate.md` so exact object identity, current placement in one view, current handle-rights posture, advertised operations, and durable receipts/history stay visibly distinct.
- Added `docs/30-architecture/identity-placement-rights-and-affordances.md` and refreshed `docs/30-architecture/architecture-overview.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` with the new identity/placement/rights/affordance seam and a sharper evaluation of what SlopOS namespace / powerbox / capability posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/70-shell/shell-terminal-ideas.md` with place cards, verb ledgers, affordance lenses, why-not drawers, and protocol metadata that keeps identity, placement, current rights, and advertised verbs visibly distinct.
- Refreshed `docs/90-inspirations/slopos-datacube-evaluation.md`, `docs/90-inspirations/inspirations-mapped.md`, bibliography, moving-head tracking, review queue, trajectory map, assumptions/claims/non-claims/invariants, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised074 (2026-03-23)
- Continued online research on user-activation gating, activation/focus tokens, enabled-versus-active interaction state, and truthful shell UX for gesture-driven actions.
- Added `rfcs/0067-viewfs-keep-gesture-evidence-activation-tokens-armed-state-active-control-and-receipts-separate.md` so fresh gesture proof, transferable activation batons, armed/enabled lanes, active control, and durable receipts stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new interaction-proof / active-control seam and a sharper evaluation of what SlopOS capture/attention posture does and does not settle.
- Refreshed `docs/70-shell/shell-terminal-protocol-sketch.md` and `docs/70-shell/shell-super-awesome-moves.md` with activation baton chips, arming rails, and foreground-transfer card ideas for the future custom shell+terminal.
- Expanded bibliography and moving-head source tracking with HTML / Wayland / XDG portal / Win32 foreground-transfer precedents, refreshed the external review queue, regenerated the context pack and release manifest, and kept lint clean.

## Revised073 (2026-03-23)
- Continued online research on typed transcript routing, lazy link resolution, explicit hyperlink semantics, and shell selection UX.
- Added `rfcs/0066-viewfs-keep-selected-regions-entity-candidates-route-envelopes-prepared-actions-and-receipts-separate.md` to keep selected regions, extracted typed entities, route envelopes, prepared actions, and receipts separate.
- Refreshed shell and architecture notes with **entity peels**, **route slips**, and **hypertruth badges** ideas for the future custom shell+terminal.
- Expanded bibliography/source tracking with Plan 9 plumber, OSC 8 hyperlink, LSP document-link, and kitty hints precedents.
- Fixed context-pack coverage so it now includes RFCs 0065 and 0066 before packaging the new archive.

## Revised072 (2026-03-23)
- Continued online research on completion systems, lazy detail resolution, insertion semantics, trusted shell command reporting, and shell/terminal UX that can tell `candidate`, `inserted`, `compiled`, and `ready` apart.
- Added `rfcs/0065-viewfs-keep-completion-candidates-accepted-insertions-compiled-command-packets-prepared-actions-and-receipts-separate.md` so advisory completion rows, accepted prompt-buffer state, compiled command packets, prepared actions, and durable receipts/history stay visibly distinct.
- Refreshed completion, shell, and protocol docs with **ghost rows**, **detail drawers**, **accept-word ladders**, **packet gutters**, and **rerun safety badges** that make the terminal smarter without laundering suggestions into authority.
- Updated the SlopOS seam map and datacube evaluation to steal the strongest lesson from the current `mcp-completion-import-boundary-v0.md`: provider-local completion suggestions are not selector/default/workflow truth.
- Refreshed bibliography, moving-head source tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revised071 (2026-03-23)
- Continued online research on smart folders, live metadata queries, saved-search manifests, portal-gated index services, and shell/terminal semantics that can tell `recipe`, `snapshot`, `live feed`, and `local basket` apart.
- Added `rfcs/0064-viewfs-keep-query-manifests-result-snapshots-live-feeds-materialized-collections-live-binds-and-receipts-separate.md` so saved queries, snapshots, live feeds, materialized local sets, current binds, and durable receipts/history stay visibly distinct.
- Expanded query and shell docs with `freeze to basket`, `query-versus-basket drift`, `materialized set`, and `bound here` truth surfaces.
- Refreshed the SlopOS seam map, datacube evaluation, inspirations map, bibliography/source-tracking, assurance registries, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised070 (2026-03-23)
- Continued online research on request handles versus session handles, portal-owned live state, transfer/session lifecycle precedents, and shell/terminal semantics that can tell `request succeeded once` from `portal still active now` and from `adopted here now`.
- Added `rfcs/0063-viewfs-keep-request-handles-session-handles-portal-owned-live-state-and-receipts-separate.md` so request rows, session/transfer objects, portal-owned live state, local adopted binds/live handles, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/portal-grant-lifecycle-notes.md`, `docs/30-architecture/requests-candidates-selections-and-imports.md`, `docs/30-architecture/imports-exports-transfers-and-promised-files.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new request-versus-session-versus-live-state seam and a sharper evaluation of what SlopOS background/capshell/portal posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with request ledgers, session cards, portal-state lenses, adoption shutters, and transcript metadata that keeps request identity separate from portal-owned live state and from current local authority.
- Refreshed bibliography, source tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revised069 (2026-03-23)
- Continued online research on provenance attestations, endorsement/reference bundles, local appraisal/admission boundaries, transparency/audit precedents, and shell/terminal semantics that can tell `well-described` from `admitted here now`.
- Added `rfcs/0062-viewfs-keep-provenance-attestations-endorsement-bundles-local-admission-verdicts-live-handles-and-receipts-separate.md` so provenance claims, endorsement bundles/trust-root inputs, local admission verdicts, current live handles, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new provenance-versus-admission seam and a sharper evaluation of what SlopOS attestation / endorsement / document-portal posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with provenance ribbons, endorsement stacks, verdict shutters, and transcript metadata that keeps claims and endorsements separate from local admission and from live authority.
- Refreshed bibliography, source tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised068 (2026-03-23)
- Continued online research on permission-state versus current authority, explicit revoke/delete/expiry state, revival/recontact designators, and shell/terminal semantics that can tell `granted` from `live now` and `revoked` from generic `stale`.
- Added `rfcs/0061-viewfs-keep-permission-outlooks-revival-designators-live-handles-death-state-verdicts-and-receipts-separate.md` so permission outlook, revival designators, current live handles, explicit death-state verdicts, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/revocation-and-durable-grants-design-space.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new permission-versus-liveness seam and a sharper evaluation of what SlopOS document/lease/powerbox posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with permission lights, death certificates, preflight gutters, repair ladders, and transcript metadata that keeps permission outlook separate from current authority and from dead-state history.
- Refreshed bibliography, moving-head tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised067 (2026-03-23)
- Continued online research on declared caveats versus enforced attenuation, proxy-first lease/membrane delegation, explicit revocation surfaces, and shell/terminal semantics that can tell `caveat declared` from `enforced now`.
- Added `rfcs/0060-viewfs-keep-caveat-sets-membrane-leases-live-handles-and-receipts-separate.md` so caveat sets, membrane/lease proxies, live handles, revival designators, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/rights-attenuation-and-bundles.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new caveat-versus-enforcement seam and a sharper evaluation of what SlopOS D-LEASE / CH-CAPX / capability-semantics posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with caveat laminates, membrane badges, expiry gutters, renewal ladders, and transcript metadata that keeps declared bounds separate from enforced current authority.
- Refreshed bibliography, source tracking, review queue, assumptions/claims/non-claims, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised066 (2026-03-23)
- Continued online research on designation-versus-authority, capability URLs, sturdyref locators, security-scoped bookmark persistence, document-portal mediation, and terminal metadata that can keep `designation only` visibly different from `authority-bearing ticket`.
- Added `rfcs/0059-viewfs-keep-non-authoritative-designators-authority-bearing-tickets-local-aliases-live-handles-and-receipts-separate.md` so note-friendly designators, authority-bearing tickets, local aliases/binds, live handles, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new designation-versus-authority seam and a sharper evaluation of what SlopOS wallet / plumb / document-handle / CapStore posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-ideas.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with inert-designator-paste, ticket chips, explicit authority-reveal ladders, and transcript metadata that keeps designators separate from tickets.
- Refreshed bibliography, source tracking, review queue, evidence index, lint coverage, context-pack coverage, and release manifest for the new revision.

## Revised065 (2026-03-23)
- Continued online research on mediated transfer/handoff, explicit local adoption, UNIX `SCM_RIGHTS`, Fuchsia handle duplication/transfer, Wayland data offers, security-scoped durable reopen caution, and shell/terminal semantics that keep `offered` visibly different from `adopted here now`.
- Added `rfcs/0058-viewfs-keep-transfer-offers-live-handle-copies-revival-designators-adopted-binds-and-receipts-separate.md` so transfer offers, accepted representations, live copied handles, later revival designators, adopted local binds, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new handoff-versus-adoption seam and a sharper evaluation of what SlopOS capshell pipeline / CAPX / import-to-docref posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with transfer sheets, adoption rails, issuer/courier witness chips, and `offer-only` versus `adopted-here` shell truth ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, lint requirements, and release manifest for the new revision.

## Revised064 (2026-03-23)
- Continued online research on durable reopen designators, bookmark-style revalidation, exact-handle restart continuity, per-component persistent state versus running authority, and shell/terminal protocol ideas for making `remembered` visibly different from `live now`.
- Added `rfcs/0057-viewfs-keep-remembered-designators-revalidation-continuity-lockers-live-handles-and-receipts-separate.md` so remembered designators, explicit revalidation acts, narrow continuity lockers, revived live handles/binds, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new remembered-versus-live continuity seam and a sharper evaluation of what SlopOS CapStore / activation-handoff / document-portal posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with reopen-truth ladders, continuity lockers, stale-target repair rails, and semantic transcript ideas that keep remembered designation separate from current authority.
- Refreshed bibliography, external-source tracking/review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised063 (2026-03-23)
- Continued online research on portal-mediated import boundaries, per-process/per-component namespace construction, durable document IDs versus current handles, and shell/terminal integration patterns that make `source ref only` visibly different from `fresh local object`.
- Added `rfcs/0056-viewfs-keep-imported-source-refs-materialized-local-objects-docrefs-and-receipts-separate.md` so imported source refs, explicit materialization, fresh local objects, local durable docrefs, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new import-localization seam and a sharper evaluation of what SlopOS document-portal / import-to-docref posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with localize-first import cards, docref ladders, semantic freshness labels, and truth-honest shell integration ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised062 (2026-03-23)
- Continued online research on content/object descriptors, digest-authoritative versus locator-hint references, creator-populated capability namespaces, portal-scoped document import, and shell UX that can tell `descriptor only` from `live handle now`.
- Added `rfcs/0055-viewfs-keep-content-descriptors-live-handles-and-receipts-separate.md` so descriptor envelopes, live handles/binds, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new descriptor-first seam and a sharper evaluation of what SlopOS artifact/document-handle posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with descriptor cards, hydrate-later ladders, object chips, and descriptor-truth shell ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised061 (2026-03-23)
- Continued online research on unnamed temporary objects, publish-later namespace binding, `O_TMPFILE` / `linkat(..., AT_EMPTY_PATH)` style publication, and shell UX that can tell `draft object` from `published name here`.
- Added `rfcs/0054-viewfs-keep-unnamed-objects-namespace-publication-and-receipts-separate.md` so unpublished objects, publication anchors, publication acts, visible names, and durable history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new unnamed-object / namespace-publication seam and a sharper evaluation of what SlopOS CapStore/view/document-handle posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with draft-object cards, publish-later ladders, parent-anchor publish sheets, and publication-receipt ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised060 (2026-03-23)
- Continued online research on attached-namespace propagation posture, peer groups, detached-then-attached propagation timing, and shell UX that can show local-only versus shared blast radius honestly.
- Added `rfcs/0053-viewfs-keep-live-binds-propagation-posture-peer-groups-and-receipts-separate.md` so one current bind, its propagation posture, any peer/upstream relationship, and durable history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new bind-versus-propagation seam and a sharper evaluation of what SlopOS view / replication posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with propagation badges, blast-radius previews, peer/upstream drawers, and attach-private-first ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised059 (2026-03-23)
- Continued online research on multi-path namespace mutation, source-versus-destination parent anchors, Fuchsia vnode-token/cookie rename mechanics, Capsicum source/destination directory rights, and Linux `renameat2()` collision/exchange modes.
- Added `rfcs/0052-viewfs-keep-object-identity-parent-anchors-namespace-mutations-and-receipts-separate.md` so object identity, source parent anchor, destination parent anchor, namespace-mutation mode, and durable mutation history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new namespace-mutation seam and a sharper evaluation of what SlopOS handle/root/docref posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with two-anchor rename cards, overwrite/exchange ladders, anchor-gap warnings, and name-diff receipt ideas.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised058 (2026-03-23)
- Continued online research on launch-boundary descriptor inheritance, `O_CLOEXEC` race avoidance, `posix_spawn()` inheritance defaults, bulk close-on-exec shutters, and the newer `FD_CLOFORK` precedent.
- Added `rfcs/0051-viewfs-keep-current-handles-launch-inheritance-child-slots-and-launch-receipts-separate.md` so current handle possession, launch-boundary inheritance posture, exact child-slot delivery, and durable launch history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new launch-inheritance seam and a sharper evaluation of what SlopOS activation / exec-pack / handle-table posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with inheritance shutters, child-slot maps, launch-boundary diff cards, and authority-leak sirens.
- Refreshed bibliography, source tracking, review queue, evidence index, context-pack coverage, release manifest, and repaired shell-terminal protocol numbering around the handle-class event while touching those hygiene surfaces.

## Revised057 (2026-03-23)
- Continued online research on locator/metadata handles, `O_PATH`-style designation semantics, detached mount/object handles, `AT_EMPTY_PATH` metadata operations, and shell UX that can tell `inspect-only` from `readable now`.
- Added `rfcs/0050-viewfs-keep-locator-handles-byte-io-handles-and-durable-refs-separate.md` so locator handles, live byte-I/O handles, reopen/escalation acts, and durable history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new handle-class seam and a sharper evaluation of what SlopOS cwd-root / handle-table posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with handle-class badges, inspect-first cards, open-for-more-power ladders, and locator-versus-byte-I/O truth ideas.
- Refreshed bibliography, moving-head tracking, review queue, evidence index, context-pack coverage, and release manifest for the new revision.

## Revised056 (2026-03-22)
- Continued online research on open-file-description aliasing, descriptor duplication, cross-process handle copying, and shell UX that can tell `same object` from `same live cursor/lock state`.
- Added `rfcs/0049-viewfs-keep-handle-slots-live-handle-copies-shared-open-state-and-independent-reopens-separate.md` so slot-local bindings, live handle copies, shared open-state groups, independent reopens, and durable history stay visibly distinct.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md`, `docs/30-architecture/slopos-seam-map.md`, and `docs/90-inspirations/slopos-datacube-evaluation.md` with the new handle-topology seam and a sharper evaluation of what SlopOS handle-table posture does and does not settle.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with twin-handle badges, duplicate-vs-reopen ladders, and shared-open-state drawer ideas.
- Refreshed bibliography, moving-head tracking, review queue, evidence index, context pack, lint/context-pack coverage, and release manifest for the new revision; also repaired the missing Revision 055 evidence-index entries while touching the hygiene surfaces.

## Revised055 (2026-03-22)
- Continued online research on explicit runner/runtime selection, environment-hosted launch choices, structured launch/runtime config, and terminal UX that keeps the live mutable prompt area separate from scrollback history.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around exec objects versus runner/runtime choice versus bootstrap posture so ViewFS can steal launch-hosting lessons without freezing a runtime mechanism too early.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md`, and added `rfcs/0048-viewfs-keep-exec-objects-runners-bootstrap-posture-and-live-sessions-separate.md` so exec objects, runner/runtime choice, bootstrap posture, live sessions, and durable history stay visibly distinct while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with runner badges, bootstrap shutters, and mutable-prompt-dock ideas that make the future custom shell+terminal stronger without pretending terminal history and live draft state are the same thing.
- Expanded bibliography and moving-head source tracking with Fuchsia runner/environment and OCI runtime-config precedents plus iTerm2 command-selection / mutable-area precedents, refreshed the external review queue, and regenerated the context pack and release manifest for the new archive.

## Revised054 (2026-03-22)
- Continued online research on UNIX job control, controlling-terminal posture, foreground process groups, login-time TTY adoption, and shell chrome that tells the truth about where interactive input and terminal-generated signals will actually land.
- Added `rfcs/0047-viewfs-keep-live-process-handles-terminal-streams-controlling-tty-and-foreground-turns-separate.md` so running-command identity, stream lanes, controlling-terminal posture, foreground turns, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/observe-attach-control-and-sideband-lanes.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` so observe/attach shells stop flattening process handles, stdio/PTY streams, controlling TTY state, current foreground ownership, and history into one vague attached bit.
- Expanded `docs/70-shell/follow-tails-attach-rails-and-control-panes.md`, `docs/70-shell/shell-super-awesome-moves.md`, and `docs/70-shell/shell-terminal-protocol-sketch.md` with foreground-baton pills, TTY-lease badges, and interrupt-preview rails that make the future custom shell+terminal richer without pretending transcript rows are live control.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the new job-control / controlling-terminal seam, added bibliography + source-review entries for classic UNIX job-control / TTY precedents, and refreshed the context pack, evidence index, and release manifest for the new archive.

## Revised053 (2026-03-22)
- Continued online research on clipboard/selection ownership, offered representations, explicit transfer retrieval, permission-gated typed clipboard reads, and how those lessons should shape ViewFS import/paste honesty while SlopOS remains in design.
- Added `rfcs/0046-viewfs-keep-selection-owners-offers-pasted-input-and-imported-objects-separate.md` so current selection ownership, offered representations, pasted prompt bytes, imported objects, and durable receipts/history stay visibly distinct.
- Refreshed `docs/30-architecture/imports-exports-transfers-and-promised-files.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and `docs/30-architecture/slopos-seam-map.md` so clipboard/selection owner/source, accepted representation, prompt paste, imported object identity, and durable reopen do not collapse back together.
- Expanded `docs/70-shell/shipping-lanes-boundary-previews-and-promised-outputs.md`, `docs/70-shell/shell-super-awesome-moves.md`, and `docs/70-shell/shell-terminal-protocol-sketch.md` with clipboard-offer cards, MIME-aware transfer truth, and paste-versus-import ladders that make the future custom shell+terminal richer without pretending paste is authority.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` and `docs/90-inspirations/inspirations-mapped.md` with the new transfer/clipboard seam, added bibliography + source-review entries for Wayland primary selection, ICCCM selections, and kitty clipboard docs, and refreshed the context pack, evidence index, and release manifest for the new archive.

## Revised052 (2026-03-22)
- Continued online research on exact startup code closure, loader search policy, late dynamic imports/plugins, and shell chrome that tells the truth about closure certainty instead of only exec-object identity.
- Added `rfcs/0045-viewfs-keep-exec-objects-startup-code-closure-loader-policy-and-late-imports-separate.md` to keep exact exec objects, startup code closure, loader policy/search posture, late import/plugin lanes, and launch/history artifacts on distinct seams.
- Updated `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around exact executable objects versus startup code closure, grounded against SlopOS Capshell code-closure drafts.
- Updated `docs/30-architecture/design-splits-and-non-decisions.md` and `docs/30-architecture/slopos-seam-map.md` so exec objects, startup closure, loader debt, late imports, and receipts stay visibly distinct while SlopOS is still moving.
- Updated `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with closure-certainty badges, loader-debt warnings, and late-import route-sheet ideas.
- Refreshed README, bibliography, external-source tracking, review queue, evidence index, lint/context-pack coverage, context pack, and release manifest for the new revision.

## Revised051 (2026-03-22)
- Continued online research on exact executable-object launch, file-descriptor-based execution, activation-time credential delivery, and prompt-aware terminal chrome for launch inspection.
- Added `rfcs/0044-viewfs-keep-exec-objects-startup-credentials-and-launch-basis-separate.md` to keep exact exec objects, explicit interpreter/script entry, argv/env basis, startup credential slots, and launch/history artifacts on distinct seams.
- Updated `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around exact exec objects and activation-time credentials, grounded against SlopOS Capshell posture drafts.
- Updated `docs/30-architecture/design-splits-and-non-decisions.md` and `docs/30-architecture/slopos-seam-map.md` so launch basis, exec objects, startup credentials, and launch receipts stay visibly distinct while SlopOS is still moving.
- Updated `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with launch-basis cards, credential drawers, and exact-exec-object badge ideas.
- Refreshed README, bibliography, external-source tracking, review queue, context pack, and release manifest for the new revision.

## Revised050 (2026-03-22)
- Continued online research on detached namespace fragments, explicit attach acts, pre-attach posture, bracketed-paste input origin, and disambiguated terminal key packets.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around detached namespace fragments so ViewFS can steal explicit pre-attach/attach ideas without collapsing them into global paths, durable naming, or durable reopen.
- Refreshed `docs/30-architecture/slopos-seam-map.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and new `rfcs/0043-viewfs-keep-detached-view-fragments-pre-attach-posture-and-live-binds-separate.md` so prepared fragments, pre-attach posture, live binds, current placement, and receipts stay visibly distinct while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md`, `docs/70-shell/shell-terminal-protocol-sketch.md`, and `docs/90-inspirations/inspirations-mapped.md` with paste-capsule, prompt-local input-origin, and disambiguated-key-packet ideas that make the future custom shell+terminal stronger without pretending pasted bytes or ambiguous escape codes are authority.
- Expanded bibliography and moving-head source tracking with Linux `open_tree` / `move_mount` / `mount_setattr`, xterm bracketed paste, and kitty keyboard precedents, refreshed the external review queue, regenerated the context pack, and rebuilt the release manifest for the new archive.

## Revised048 (2026-03-22)
- Continued online research on capability-shaped running-process handles, lifecycle-control versus deep-inspection rights, and shell chrome that tells the truth about live-versus-history command objects.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around exact running-process identity so ViewFS can steal process-descriptor ideas without collapsing them into transcript folklore or broad debugger power.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md`, and added `rfcs/0042-viewfs-keep-command-packets-live-process-handles-control-rights-and-deep-inspection-separate.md` so command packets, live process handles, lifecycle-control rights, deeper inspection rights, and history rows stay visibly distinct while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with live-process-card and right-badging ideas that make the future custom shell+terminal stronger without pretending PIDs or transcript rows are authority.
- Expanded bibliography and moving-head source tracking with Linux pidfd and FreeBSD procdesc precedents, refreshed the external review queue, regenerated the context pack, and rebuilt the release manifest for the new archive.

## Revised047 (2026-03-22)
- Continued online research on courier provenance, peer-credential witness surfaces, structured terminal command packets, and exact-action shell chrome.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around **courier provenance** and **structured command packets** so ViewFS can steal exact local-transfer and escalation patterns without collapsing them into object identity, durable receipt, or transcript folklore.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so peer witnesses, transferred live handles, structured command packets, plain transcript rows, and durable receipts stay visibly distinct while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with peer-witness courier drawers and explicit command-packet promotion ideas that make the future custom shell+terminal more powerful without pretending copied text is authority.
- Expanded bibliography and moving-head source tracking with Linux peer-credential / SO_PASSCRED and VS Code structured terminal-command attachment precedents, repaired a small hygiene gap by bringing RFC 0041 into lint/context-pack coverage, and regenerated the context pack and release manifest for the new archive.

## Revised046 (2026-03-22)
- Continued online research on startup-delivered handles, activation carriers, badged capability copies, command-block truth ladders, and action-gated terminal chrome.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around activation kits and issuer-visible handle copies so ViewFS can steal explicit startup delivery without collapsing it into durable identity or durable reopen.
- Refreshed `docs/30-architecture/slopos-seam-map.md`, `docs/30-architecture/design-splits-and-non-decisions.md`, and new `rfcs/0041-viewfs-keep-activation-carriers-badged-handle-copies-and-object-identity-separate.md` so activation slots, live handle copies, issuer badges, immutable object refs, and receipts stay visibly distinct while SlopOS is still moving.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with activation-kit cards, truth-graded command blocks, selection-packet / primary-target, and badged-handle drawer ideas that make the terminal richer without pretending transcript guesswork is authority.
- Expanded bibliography and moving-head source tracking with seL4 badged-capability, systemd socket-activation, and VS Code shell-integration precedents, refreshed the external review queue, and regenerated the context pack and release manifest for the new archive.

## Revised045 (2026-03-22)
- Continued online research on exact local handle transfer, transient byte staging, freeze-for-review semantics, and shell/terminal UX for commit-last import/export flows.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a new low-regret seam around transient exact-byte staging capsules so ViewFS can steal useful local-transfer and review patterns without freezing a persistence model.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so staged capsules, couriered live handles, committed objects, durable reopen refs, and ordinary history rows stay visibly distinct.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with sealed-capsule, explicit-handle-courier, and commit-last shell ideas worth stealing.
- Expanded `docs/00-meta/bibliography.md`, the moving-head head register, and the external review queue with Linux memfd/seal and explicit fd-passing precedents, then regenerated the context pack and release manifest for the new archive.

## Revised044 (2026-03-22)
- Continued online research on narrow continuity versus durable persistence, exact object identity versus current placement, provider-declared operation surfaces, and truthful shell/terminal review chrome.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` so the current SlopOS datacube is evaluated through two more low-regret lenses: restart-stable exact-handle continuity is a useful middle seam, and action menus should be driven by exact object/handle affordances instead of path folklore.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so ViewFS keeps resumable lane lockers, durable reopen refs, persistent roots, object identity, current placement, and advertised operations on visibly different seams while SlopOS is still moving.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with handle-locker, resumable-lane, exact-action-menu, and provider-flag shell ideas that make the terminal stronger without pretending transcript guesses are authority.
- Extended bibliography and moving-head review tracking with a systemd file-descriptor-store precedent, refreshed Android/terminal moving-head source dates used again in this pass, and regenerated the context pack and release manifest for the new archive.

## Revised043 (2026-03-22)
- Continued online research on narrow continuity versus durable persistence, creator-populated per-process namespaces, portal request/transfer lifetimes, structured shell output, and trusted-but-restricted terminal UX.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` so the current SlopOS datacube is evaluated not just through CapStore/AttrFS/Capshell, but also through a new low-regret continuity lens: narrow escrow/resume should stay separate from durable reopen and persistent authority.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so ViewFS keeps continuity/escrow, durable reopen, persistent roots, and queued follow-up control on visibly different seams while SlopOS is still moving.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with trusted-review-lane, collapsible-command-section, steering-rail, and structured-object-drawer ideas that make the terminal richer without lying about authority.
- Extended bibliography and moving-head review tracking with current Fuchsia idle-stop/handle-escrow and VS Code terminal-section precedents, then regenerated the context pack and release manifest for the new archive.

## Revised042 (2026-03-22)
- Continued online research on optional capability persistence, durable-root rollback/resurrection problems, view-scoped query/smart-folder posture, portal request lifetimes, and semantic shell/terminal metadata.
- Deepened `docs/90-inspirations/slopos-datacube-evaluation.md` with a more explicit reading of the SlopOS datacube through CapStore, AttrFS, and Capshell, focusing on low-regret separations rather than mechanism lock-in.
- Refreshed `docs/30-architecture/slopos-seam-map.md` and `docs/30-architecture/design-splits-and-non-decisions.md` so immutable storage, optional durable roots, durable reopen, snapshot query, live feed, and ambient inventory stay visibly separate while SlopOS remains in design.
- Expanded `docs/70-shell/shell-super-awesome-moves.md` and `docs/90-inspirations/inspirations-mapped.md` with pane-var, semantic-zone, truth-labeled-history, and persistence/query lessons worth stealing.
- Repaired bibliography coverage for missing referenced sources, added CapROS/TreeSLS persistence references, updated moving-head review tracking, and regenerated the context pack and release manifest for the new revision.

## Revised041 (2026-03-22)
- Continued online research on capability-native object stores, explicit transfer mediation, creator-populated namespaces, structured shell metadata, and restricted-but-productive terminal UX.
- Added `docs/90-inspirations/slopos-datacube-evaluation.md` to record what ViewFS should copy now from the uploaded SlopOS datacube, what it should only copy lightly, what it should postpone while SlopOS is still moving, and which shell/terminal ideas feel promising without freezing them.
- Refreshed `docs/30-architecture/design-splits-and-non-decisions.md` with a sharper low-regret freeze line: keep identity, naming, mutable heads, reopen state, request/selection/grant/bind, browse-vs-trust, and compat debt visibly separate.
- Refreshed `docs/70-shell/shell-super-awesome-moves.md` with semantic-inspector, restricted-badge, typed-link, and prompt-local click ideas that keep terminal delight subordinate to authority truth.
- Refreshed `docs/90-inspirations/inspirations-mapped.md` with another explicit lesson that transfer lanes should negotiate offers and representations rather than smuggling ambient reach back in.
- Expanded `docs/00-meta/bibliography.md`, the external-source head register, and the review queue with a Wayland data-offer precedent for typed mediated transfer.
- Tightened repo hygiene by bringing inspiration docs into the context pack and lint requirements, and by adding the Revision 040 live-session seam files that earlier lint rules forgot to enumerate.
- Updated `README.md`, the evidence index, the context pack, and the release manifest for the new archive.

## Revised040 (2026-03-22)
- Continued online research on live-session interaction seams: follow/query versus interactive attach, control messages versus synchronous updates, injected debug exec, sideband tunnels, read-only clients, and active-versus-armed interaction state.
- Added `docs/30-architecture/observe-attach-control-and-sideband-lanes.md` to keep read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable transcripts on distinct seams.
- Added `docs/70-shell/follow-tails-attach-rails-and-control-panes.md` so ViewFS can collect shell ideas around follow tails, attach rails, control panes, debug launch drawers, sideband badges, and live-session receipts.
- Added `rfcs/0040-viewfs-keep-observe-attach-control-and-sideband-lanes-separate.md` so future proposals must classify whether they change observe/query, interactive attach, control messages, exec/debug, sideband access, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with current notes from kubectl live-session verbs, tmux read-only/control-mode clients, Temporal queries/signals/updates, and XDG InputCapture state transitions.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised039 (2026-03-22)
- Continued online research on deferred-work control seams: request close/abort, best-effort cancellation, detach/delete versus remote stop, force termination, reset/fork from history, retained-result expiry, and shell UX for honest stop ladders.
- Added `docs/30-architecture/cancel-terminate-forget-reset-and-rerun.md` to keep close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipts on distinct seams.
- Added `docs/70-shell/stop-ladders-detach-rails-and-rerun-forks.md` so ViewFS can collect shell ideas around stop ladders, detach rails, termination fuses, retry-vs-fork drawers, result-retention lockers, and stop receipts.
- Added `rfcs/0039-viewfs-keep-cancel-terminate-forget-reset-and-rerun-separate.md` so future proposals must classify whether they change close/cancel, termination, detach/delete, retry-fresh, reset/fork/attach, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with current notes from XDG Request close semantics, Google long-running operation cancel/delete/expiry guidance, MCP task cancellation/deletion/keepAlive semantics, Temporal interrupt/reset/reuse posture, and current session-fork UX.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised038 (2026-03-22)
- Continued online research on deferred-work seams: portal request handles, task-augmented helper requests, progress lanes, input-required checkpoints, long-running-operation polling, background permission/status, and shell UX for honest queued follow-ups.
- Added `docs/30-architecture/requests-tasks-progress-and-results.md` to keep immediate requests, accepted task wrappers, live progress/status streams, input-required checkpoints, deferred final result retrieval, and durable receipts on distinct seams.
- Added `docs/70-shell/task-badges-progress-lanes-and-result-lockers.md` so ViewFS can collect shell ideas around task badges, progress lanes, input-required drawers, queue rails, result lockers, and task receipts.
- Added `rfcs/0038-viewfs-keep-requests-tasks-progress-and-results-separate.md` so future proposals must classify whether they change immediate request submission, accepted task wrappers, live progress, input-required checkpoints, deferred final result retrieval, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with current notes from the MCP tasks/progress drafts, XDG request/background portals, Google long-running operations, and current VS Code task/background-agent UX.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised037 (2026-03-22)
- Continued online research on MCP feature classes, request-scoped helper binding, completion disclosure risks, interactive helper surfaces, and terminal-native helper catalog UX.
- Added `docs/30-architecture/resources-prompts-tools-apps-and-bindings.md` to keep helper-exposed resources, prompts, tools, app surfaces, completion suggestions, request-bound attachments, live invocation/results, and durable receipts on distinct seams.
- Added `docs/70-shell/resource-shelves-prompt-chips-tool-racks-and-app-docks.md` so ViewFS can collect shell ideas around resource shelves, prompt chips, tool racks, app docks, completion popovers, binding trays, and invocation receipts.
- Added `rfcs/0037-viewfs-keep-resources-prompts-tools-apps-and-bindings-separate.md` so future proposals must classify whether they change feature catalogs, completion hints, request bindings, live invocations/results, or only durable history.
- Fixed a repo hygiene gap by adding missing helper-lifecycle assurance entries to the claim and invariant registries before layering the new helper-feature seam on top.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with current notes from the MCP specification, MCP completion utility, VS Code MCP catalogs, and prompt/tool binding posture.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

- Continued online research on helper lifecycle seams: publisher trust, install/config source, enablement, start approvals, live brokered sessions, request-scoped tool selection, and lifecycle receipts.
- Added `docs/30-architecture/publisher-trust-helper-installs-and-live-sessions.md` to keep publisher trust, installed helper packages, configured helper definitions, enabled state, start approvals, live sessions, request-scoped selections, and receipts on distinct seams.
- Added `docs/70-shell/publisher-badges-start-gates-and-tool-racks.md` so ViewFS can collect shell ideas around publisher badges, installed cards, start-gate drawers, live-session beacons, tool racks, trust-reset sparks, and lifecycle receipts.
- Added `rfcs/0036-viewfs-keep-publisher-trust-helper-installs-and-live-sessions-separate.md` so future proposals must classify whether they change publisher trust, install/config state, enablement, start gates, live sessions, request-scoped tool selection, or only durable history.

## Revised035 (2026-03-22)
- Continued online research on protected configuration scopes, source-class authorability, manual-invocation versus auto-apply helper material, central permission brokers, and terminal-native authorability UX.
- Added `docs/30-architecture/protected-scopes-authorability-and-invocation-lanes.md` to keep protected-authorable state, carrier/discovery presence, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipts on distinct seams.
- Added `docs/70-shell/protected-badges-authorability-matrices-and-latched-invokes.md` so ViewFS can collect shell ideas around protected chips, authorability matrix drawers, latched invokes, broker badges, and invoke-vs-adopt receipt cards.
- Added `rfcs/0035-viewfs-keep-protected-scopes-authorability-and-invocation-lanes-separate.md` so future proposals must classify whether they change protected-only state classes, invoke-only helper material, trust-gated adoption lanes, effective active state, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from Git protected configuration and `safe.directory`, VS Code prompt files/custom agents, restricted configurations and managed policies, and Deno permission brokers.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised034 (2026-03-22)
- Continued online research on managed policy authorship, trust-state withholding, trusted carriers versus authorable sources, current plugin/server trust posture, and terminal-native source-aware shell UX.
- Added `docs/30-architecture/policy-authors-carriers-and-advisory-sources.md` to keep author classes, carrier/container classes, trust gates, advisory-only sources, effective active state, and durable receipts on distinct seams.
- Added `docs/70-shell/author-badges-carrier-tags-and-advisory-rails.md` so ViewFS can collect shell ideas around author badges, carrier tags, advisory-only rails, trust-tunnel warnings, and authorability fuse drawers.
- Added `rfcs/0034-viewfs-keep-policy-authors-carriers-and-advisory-sources-separate.md` so future proposals must classify whether they change author classes, carrier classes, trust gates, advisory-only rails, effective active state, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from VS Code customization discovery, plugin MCP trust posture, workspace trust/security boundaries, managed-policy overrides, Git origin/scope inspection, Deno deny precedence, and modern terminal shell-integration overlays.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised033 (2026-03-22)
- Continued online research on enterprise policy overrides, trust-gated workspace values, imported/discovered helper configs, source-stack inspection, and source-aware shell/terminal UX.
- Added `docs/30-architecture/policy-sources-trust-gates-and-precedence.md` to keep owner/org policy sources, trust-state gates, user/profile preferences, workspace/imported proposal sources, effective active state, and durable receipts on distinct seams.
- Added `docs/70-shell/origin-stacks-trust-shutters-and-override-ledgers.md` so ViewFS can collect shell ideas around origin stacks, trust shutters, import quarantine trays, winner chips, and override ledgers.
- Added `rfcs/0033-viewfs-keep-policy-sources-trust-gates-and-precedence-separate.md` so future proposals must classify whether they change authoritative policy sources, trust-state gating, lower-precedence preferences, imported helper material, effective active state, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from VS Code enterprise AI policies, workspace trust/restricted configurations, MCP configuration/discovery/reset-trust posture, Git origin/scope inspection, and Deno deny/audit posture.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised032 (2026-03-22)
- Continued online research on explicit deny precedence, scope applicability, restricted-but-useful configuration posture, current session versus broader adoption scopes, and terminal UX for narrowing instead of widening.
- Added `docs/30-architecture/deny-ceilings-narrowing-and-scope-eligibility.md` to keep deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and durable adoption receipts on distinct seams.
- Added `docs/70-shell/ceiling-pills-narrowing-previews-and-scope-fuses.md` so ViewFS can collect shell ideas around ceiling pills, narrowing previews, scope fuses, and adopt-the-narrowest-safe-rung flows.
- Added `rfcs/0032-viewfs-keep-deny-ceilings-narrowing-and-scope-eligibility-separate.md` so future proposals must classify whether they change authoritative ceilings, scope eligibility, narrowing transforms, escalation interactions, or only durable history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from Cedar deny semantics, Deno deny precedence and audit logs, VS Code configuration scopes, Workspace Trust restricted configurations, current agent-tool permission levels, and VS Code 1.112 terminal/session ergonomics.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised031 (2026-03-22)
- Continued online research on proposal provenance, explicit scope/adoption ladders, configuration-origin diagnostics, MCP trust prompts, session-vs-workspace approval scopes, and authority-vs-agent role separation.
- Added `docs/30-architecture/proposers-lanes-escalations-and-adoptions.md` to keep proposal origins, proposal scopes, escalation requests, authoritative adoptions, and durable adoption receipts on distinct seams.
- Added `docs/70-shell/proposer-badges-escalation-ladders-and-adoption-gates.md` so ViewFS can collect shell ideas around proposer badges, scope chips, escalation ladders, adoption gates, and quiet decline/adoption history.
- Added `rfcs/0031-viewfs-keep-proposers-lanes-escalations-and-adoptions-separate.md` so future proposals must classify whether they change proposal sources, proposal scopes, escalation interactions, authoritative adoptions, or only durable adoption history.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from Git config origin/scope inspection, VS Code chat customization diagnostics, MCP server trust/config scopes, agent permission scopes, and polkit’s authority-versus-authentication-agent split.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised030 (2026-03-22)
- Continued external research on policy-family selection, exact consistency cuts, fallback precedence, and shell-native repair UX.
- Added `docs/30-architecture/policy-families-cuts-fallbacks-and-repair.md` to pin the seam between policy-family choice, exact authoritative cuts, fallback candidates, repair proposals, and durable selection receipts.
- Added `rfcs/0030-viewfs-keep-policy-families-cuts-fallbacks-and-repair-separate.md` to keep policy-aware shell recovery from silently swapping judges.
- Added `docs/70-shell/cut-pickers-fallback-rails-and-repair-prompts.md` and extended shell protocol/idea docs with cut-picker, fallback-rail, and selection-receipt terminal moves.
- Expanded `docs/90-inspirations/inspirations-mapped.md`, the bibliography, and external-source review tracking with new notes from OPA discovery/config precedence and SpiceDB consistency/ZedToken handling.
- Updated repo hygiene surfaces: context pack includes the new docs, lint requires them, the evidence index records the new revision, and the release manifest is regenerated for the new archive.

## Revised029 (2026-03-22)
- Continued online research on policy validation versus runtime authorization, policy-engine versus enforcement seams, temporary authorization cautionary cases, decision-log redaction, and terminal-native policy/debug overlays.
- Added `docs/30-architecture/schemas-policies-advice-diagnostics-and-decision-logs.md` to keep schema/validation material, authoritative policy/caveat material, shell advice rails, per-decision diagnostics, and durable logs/receipts on distinct seams.
- Added `docs/70-shell/policy-lenses-advice-rails-and-decision-traces.md` so ViewFS can collect shell ideas around policy lenses, non-authoritative advice rails, diagnostic cards, and audit-trace chips.
- Added `rfcs/0029-viewfs-keep-schemas-policies-advice-diagnostics-and-decision-logs-separate.md` so future proposals must classify whether they change validation material, authoritative policy, shell advice, decision diagnostics, or only durable logs/history.
- Updated README, trajectory map, roadmap, architecture overview, SlopOS seam map, shell protocol/ideas, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised028 (2026-03-22)
- Continued online research on attenuation caveats, authorization consistency/freshness witnesses, denial/audit explainability, and shell/terminal affordances for witness/caveat inspection.
- Added `docs/30-architecture/witness-packs-caveats-freshness-and-why-records.md` to keep admissible witness material, caveat sets, freshness/consistency witnesses, why-records, and durable receipts on distinct seams.
- Added `docs/70-shell/caveat-chips-witness-drawers-and-why-panels.md` so replay/import/run UX can become more explainable without turning history into standing authority.
- Added `rfcs/0028-viewfs-keep-witness-packs-caveats-freshness-and-why-records-separate.md` to force future proposals to classify whether they change witness material, caveats, freshness evidence, why-records, or only durable history.
- Updated README, trajectory map, roadmap, architecture overview, SlopOS seam map, shell protocol/ideas, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised027 (2026-03-22)
- Continued online research on exact-basis approval, stale durable refs, reauthorization-on-input-change, bounded durable reopen lists, and semantic terminal metadata for replay/renewal UX.
- Added `docs/30-architecture/basis-records-drift-checks-and-reconsent.md` to keep reuse candidates, exact prior basis records, drift checks, fresh reconsent, renewed artifacts, and history receipts on distinct seams.
- Added `docs/70-shell/basis-diffs-reconsent-ladders-and-renewal-guards.md` so replay, renewal, and receipt-only fallbacks can be ambitious without treating past success as current authority.
- Added `rfcs/0027-viewfs-keep-basis-records-drift-checks-and-reconsent-separate.md` to force future proposals to classify whether they change basis records, drift checks, reconsent checkpoints, renewed artifacts, or only history.
- Updated architecture overview, SlopOS seam map, shell protocol/ideas, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, roadmap, trajectory map, context pack, lint requirements, and release manifest for the new revision.

## Revised026 (2026-03-22)
- Continued online research on temporary authority sharing, revocation/expiry vocabulary, security-scoped reopen flows, explicit permission prompts, and shell/terminal affordances for borrowed authority.
- Added `docs/30-architecture/loans-delegations-recalls-and-expiry.md` to keep lend requests, live borrowed authority, durable delegated refs, issuer-side recall/expiry controls, and loan-end receipts on distinct seams.
- Added `docs/70-shell/lend-once-drawers-borrow-badges-and-recall-rails.md` to collect shell ideas around lend-once drawers, borrowed-authority badges, expiry rails, recall cards, and promote-from-borrow flows.
- Added `rfcs/0026-viewfs-keep-loans-delegations-recalls-and-expiry-separate.md` so future proposals must classify whether they affect borrow requests, live loans, durable delegated refs, issuer-side recall/expiry controls, or only history/receipts.
- Updated architecture overview, SlopOS seam map, shell ideas, inspirations, bibliography/review tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised025 (2026-03-22)
- Continued online research on saved workflows, notebook/runbook UX, workspace-vs-user automation boundaries, explicit promotion flows, and replay safety.
- Added `docs/30-architecture/suggestions-recipes-promotions-and-runs.md` to keep externally suggested automation, promoted user-owned workflows, prepared run plans, committed runs, and history/receipts on distinct seams.
- Added `docs/70-shell/suggestion-trays-promotion-lanes-and-replay-guards.md` to collect shell ideas around suggestion trays, explicit promotion, source-drift badges, notebook truth states, and replay guards.
- Added `rfcs/0025-viewfs-keep-suggestions-recipes-promotions-and-runs-separate.md` so future proposals must classify suggestion sources, promotion acts, user-owned workflows, prepared plans, committed runs, and history separately.
- Updated trajectory map, roadmap, architecture overview, design-splits guidance, SlopOS seam map, shell ideas, inspiration map, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised024 (2026-03-22)
- Continued online research on typed route/action preparation, exact approval-basis binding, provider-supported operation flags, runtime permission prompts, restricted-but-productive execution posture, and terminal metadata for plan/result inspection.
- Added `docs/30-architecture/intents-route-plans-approvals-and-results.md` to keep user intent, prepared route plans, approval checkpoints, committed execution, and result receipts on distinct seams.
- Added `docs/70-shell/route-plans-approval-checkpoints-and-result-cards.md` to collect shell ideas around route-plan cards, prepare-versus-commit, approval diffs, restricted productivity, and result cards.
- Added `rfcs/0024-viewfs-keep-intents-plans-approvals-and-results-separate.md` so future proposals must classify whether they are changing intent, plan, approval, execution, or only result/history surfaces.
- Updated README, changelog, trajectory map, roadmap, architecture overview, design-splits note, shell protocol sketch, shell-terminal ideas, shell super-awesome notes, SlopOS seam map, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised023 (2026-03-22)
- Continued online research on portal request objects, chooser-owned candidate sets, restricted synthetic grant views, provider-supported operation surfaces, Capsicum adoption/tooling lessons, and quiet restricted-mode UX for mediated imports.
- Added `docs/30-architecture/requests-candidates-selections-and-imports.md` to keep mediated request objects, candidate/designation surfaces, selections, minted grants/refs, live binds, and receipts on distinct seams.
- Added `docs/70-shell/chooser-sheets-staging-trays-and-grant-ledgers.md` to collect shell ideas around chooser sheets, request chips, staging trays, provider-ops-aware route sheets, grant ledgers, and ephemeral-first import UX.
- Added `rfcs/0023-viewfs-keep-requests-selections-grants-and-binds-separate.md` so future proposals must classify whether they are changing interaction state, candidate/designation surfaces, selected outcomes, minted grants/refs, live binds, or only history surfaces.
- Updated README, changelog, trajectory map, architecture overview, design-splits note, portal-grant lifecycle notes, shell protocol sketch, shell super-awesome notes, shell-terminal ideas, SlopOS seam map, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised022 (2026-03-22)
- Continued online research on creator-populated namespaces, grouped capability dictionaries, restricted synthetic grant views, shell block/mark integration, and structured-shell UX for honest launch rehearsals.
- Added `docs/30-architecture/bundles-view-fragments-and-launch-kits.md` to keep grouped authority objects, view fragments/templates, live binds, child launch kits, and receipts on distinct seams.
- Added `docs/70-shell/launch-rehearsals-kit-cards-and-view-panes.md` to collect shell ideas around launch rehearsals, kit cards, pane view cards, cross-pane handoff sheets, and strip/rebind-friendly replay.
- Added `rfcs/0022-viewfs-keep-bundles-view-fragments-and-launch-kits-separate.md` so future proposals must classify whether they are changing grouped authority, namespace templates, live binds, child launch assembly, or only receipt/history surfaces.
- Updated README, changelog, trajectory map, architecture overview, design-splits note, shell protocol sketch, SlopOS seam map, inspiration map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised021 (2026-03-22)
- Continued online research on retention-vs-cache semantics, explicit hydration/materialization, mirrors, offline bundles, service-worker-style prefetch hints, and object-store warm-up UX.
- Added `docs/30-architecture/pins-caches-prefetch-and-hydration.md` to keep prefetch hints, caches, hydration acts, pins, mirrors, and offline bundles on distinct seams.
- Added `docs/70-shell/offline-readiness-hydration-and-pin-hygiene.md` to collect shell ideas around hydration plans, offline-readiness badges, warm-up trays, bundle lanes, and pin explain flows.
- Added `rfcs/0021-viewfs-keep-pins-caches-prefetch-and-hydration-separate.md` so future design work must classify whether it is changing prefetch, cache, hydrate, pin, mirror, or offline-bundle semantics.
- Updated architecture overview, design-splits note, SlopOS seam map, inspiration map, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised020 (2026-03-22)
- Continued online research on document-picker lane splits, transfer sessions, save-as/create-only flows, move-versus-copy outcome reporting, delete-on-paste protocols, and promised-file drag/drop materialization.
- Added `docs/30-architecture/imports-exports-transfers-and-promised-files.md` to keep import/open/save/move/transfer/share/promise lanes on distinct seams.
- Added `docs/70-shell/shipping-lanes-boundary-previews-and-promised-outputs.md` to collect shell ideas around boundary previews, shipping lanes, move outcome cards, and promise/materialize UX.
- Added `rfcs/0020-viewfs-keep-import-export-transfer-share-and-promises-separate.md` so future proposals must classify whether they are importing, opening in place, saving/exporting, moving, transferring, delegating, or only promising future materialization.
- Updated README, architecture overview, SlopOS seam map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised019 (2026-03-21)
- Continued online research on saved-search/smart-folder semantics, query-manifest file formats, snapshot-versus-live-query behavior, index-policy boundaries, and truthful shell UX for result sets.
- Added `docs/30-architecture/query-manifests-result-snapshots-and-live-feeds.md` to keep query recipes, result snapshots, live feeds, smart-folder surfaces, and authority on distinct seams.
- Added `docs/70-shell/smart-folders-freeze-diffs-and-match-lenses.md` to collect shell ideas around freeze/thaw, snapshot diffs, truthful smart-folder badges, and “why did this match?” lenses.
- Added `rfcs/0019-viewfs-keep-query-manifests-snapshots-and-live-feeds-separate.md` so future proposals must classify whether they are changing a query recipe, a result snapshot, a live feed, or only a shell/journal surface.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised018 (2026-03-22)
- Continued online research on conditional writes/deletes, compare-and-swap ref updates, WebDAV lock tokens/timeouts, lease-backed distributed locks, field ownership/conflicts, and stale-write recovery UX.
- Added `docs/30-architecture/leases-preconditions-and-conflicts.md` to keep optimistic preconditions, short leases/reservations, ownership hints, conflict artifacts, and explicit override acts on distinct seams.
- Added `docs/70-shell/reservations-preconditions-and-merge-lanes.md` to collect shell ideas around guarded save, reservation badges, blocked-write explain panels, merge lanes, and force-with-lease style takeover flows.
- Added `rfcs/0018-viewfs-keep-preconditions-leases-and-conflicts-separate.md` so future proposals must classify whether they are changing expected-old guards, create-if-absent semantics, reservations, ownership hints, conflict artifacts, or override acts.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised017 (2026-03-22)
- Continued online research on snapshots, copy-on-write clones, worktree/fork ergonomics, backup/replication streams, boot-environment style rollback, and atomic deployment/pin workflows.
- Added `docs/30-architecture/checkpoints-clones-and-publication.md` to keep checkpoints, writable forks/worktrees, backup streams, publish candidates, and activation targets on distinct seams.
- Added `docs/70-shell/checkpoints-forks-and-time-travel.md` to collect shell ideas around cheap checkpoints, instant forks, truthful time-travel badges, promotion lanes, rollback previews, and “what would I lose?” inspectors.
- Added `rfcs/0017-viewfs-keep-checkpoints-clones-backups-and-publication-separate.md` so future proposals must classify whether they are changing checkpoint, fork, branch/head, replication, publication, or activation semantics.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, assumptions/claims/invariants/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised016 (2026-03-22)
- Continued online research on trash/recycle behavior, durable recovery metadata, root-based garbage collection, local history/timeline UX, and reflog-style head recovery.
- Added `docs/30-architecture/trash-retention-and-purge.md` to keep remove/unbind, trash entries, recovery history, retention roots, purge eligibility, and purge acts on distinct seams.
- Added `docs/70-shell/trash-trays-retention-lenses-and-undo.md` to collect shell ideas around trash trays, retention-root inspectors, purge previews, restore-plan cards, and explicit undo timelines.
- Added `rfcs/0016-viewfs-keep-trash-retention-and-purge-separate.md` so future proposals must classify whether they are changing a binding/name, a trash entry, a recovery-history entry, a retention root, purge eligibility, or an actual purge act.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised015 (2026-03-21)
- Continued online research on Gatekeeper/quarantine metadata, Mark-of-the-Web, dangerous-download handling, isolated-open precedents, and the ways risky-object UX quietly collapses into trust when a design is careless.
- Added `docs/30-architecture/origin-quarantine-and-trust-transitions.md` to keep origin evidence, quarantine state, safe-open lanes, explicit trust/clear decisions, derivative exports, and live authority on separate seams.
- Added `docs/70-shell/origin-badges-and-safe-open-ladders.md` to collect shell ideas around origin badges, trust ladders, explain-risk panels, receipt cards, and safe-open-first actions.
- Added `rfcs/0015-viewfs-keep-origin-quarantine-and-trust-separate.md` so future proposals must classify whether they are about origin, quarantine, safe-open, trust-clear, derivative artifacts, or live authority.
- Updated architecture overview, SlopOS seam map, inspiration map, bibliography, external-source tracking, trajectory map, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised014 (2026-03-21)
- Continued online research on rooted path resolution, symlink escape restrictions, bookmark/reopen semantics, Shell Links/shortcut retargeting, and shell UX for explicit link classes.
- Added `docs/30-architecture/links-aliases-and-shortcuts.md` to keep live handles, local names, namespace links, durable reopen refs, route/launch shortcuts, and receipt links on separate seams.
- Added `docs/70-shell/link-lenses-breadcrumbs-and-relink.md` to collect shell ideas around link lenses, breadcrumb provenance, dead-link triage, compare-target views, and explicit relink flows.
- Added `rfcs/0014-viewfs-keep-links-aliases-and-shortcuts-separate.md` so future proposals must classify whether they are changing authority, aliasing, durable reopen, route behavior, or only transcript UX.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, context pack, lint requirements, evidence index, and release manifest for the new revision.

## Revised013 (2026-03-21)
- Continued online research on file-watching APIs, recrawl/overflow behavior, persistent change journals, remote-filesystem caveats, and shell UX for live watch panels.
- Added `docs/30-architecture/watchers-notifications-and-rebuilds.md` to keep watch registrations, event feeds, rebuilt snapshots, and watch receipts separate from live authority.
- Added `docs/70-shell/watch-blocks-and-settle-badges.md` to collect shell ideas around watch blocks, scope cards, pulse summaries, settle badges, rebuild actions, and truthful live panes.
- Added `rfcs/0013-viewfs-keep-watchers-and-event-feeds-advisory.md` so future proposals must classify whether they are changing authority, subscriptions, event feeds, rebuilt snapshots, or only transcript UX.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, context pack, lint requirements, evidence index, and release manifest for the new revision.

## Revised012 (2026-03-22)
- Continued online research on preview panes, read-only inspection, Quick Look-style observation sessions, preview-host isolation, notebook rich-output gating, and derived observation artifacts.
- Added `docs/30-architecture/previews-extractors-and-observation-surfaces.md` to keep live authority, observation sessions, derived preview artifacts, and transcript receipts visibly separate in the ViewFS model.
- Added `docs/70-shell/peek-panes-and-inert-inspectors.md` to collect shell ideas around space-to-peek, compare mode, provider badges, authority ladders, preview receipts, and terminal inspector overlays.
- Added `rfcs/0012-viewfs-keep-previews-and-extractors-separate-from-authority.md` so future proposals must classify whether they affect authority, preview/extraction sessions, derived artifacts, or transcript surfaces.
- Updated architecture overview, SlopOS seam map, bibliography, external-source tracking, README, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised011 (2026-03-22)
- Continued online research on workspace trust/restricted mode, per-directory env-hook gating, project security prompts, notebook trust, and shell onboarding UX.
- Added `docs/30-architecture/workspace-trust-and-automation-gates.md` to keep workspace/tree access, inert metadata reading, workspace-defined automation, and user/global automation on distinct seams.
- Added `docs/70-shell/workspace-onboarding-and-trust-badges.md` to collect shell ideas around browse-first project opening, trust badges, automation manifests, reapproval diffs, and user-vs-workspace workflows.
- Added `rfcs/0011-viewfs-keep-workspace-access-separate-from-workspace-trust.md` so future proposals must classify whether they are granting access to a workspace tree or permission to execute workspace-defined automation.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised010 (2026-03-21)
- Continued online research on background indexing, recent-item registries, selector/palette UX, sandboxed metadata extraction, and provenance-rich command palettes.
- Added `docs/30-architecture/indexes-recents-and-selectors.md` to keep indexes, recent-item stores, and selector rows advisory rather than identity- or authority-bearing.
- Added `docs/70-shell/palette-selectors-and-provenance-lenses.md` to collect shell ideas around one powerful omnibox/palette with explicit class badges, provenance peeks, and truthful action states.
- Added `rfcs/0010-viewfs-keep-indexes-recents-and-palettes-advisory.md` so future proposals must classify registries/search surfaces separately from handles, refs, receipts, and names.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised009 (2026-03-21)
- Continued online research on session-state persistence, portal request lifetimes, block/notebook/workflow UX, semantic shell metadata, and truthful replay/rebind behavior.
- Added `docs/30-architecture/session-state-and-authority.md` to keep shell/session memory, pane/workspace restore, notebooks, workflows, and recent-item caches separate from live authority.
- Added `docs/70-shell/journals-notebooks-and-safe-replay.md` to collect ideas around journal blocks, notebook cells, workflow rows, typed palette badges, and safe replay modes.
- Added `rfcs/0009-viewfs-keep-session-state-and-authority-separate.md` so future proposals must classify session state separately from live handles, durable refs, and receipts.
- Updated architecture overview, SlopOS seam map, inspirations, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised008 (2026-03-21)
- Continued online research on handle-vs-ref semantics, portal request/response lifecycles, durable reopen failure modes, and shell/terminal UX for authority summaries and receipt cards.
- Added `docs/30-architecture/handles-refs-and-receipts.md` to keep live handles, durable refs, and transcript receipts visibly separate in the ViewFS model.
- Added `docs/70-shell/authority-hud-and-receipt-cards.md` to collect ideas around visible authority HUDs, compact receipt cards, safe transcript sharing, and honest replay/rebind UX.
- Added `rfcs/0008-viewfs-keep-handles-refs-and-receipts-separate.md` so future proposals must classify whether they affect live authority, durable reopen, or audit/transcript artifacts.
- Updated architecture overview, SlopOS seam map, portal lifecycle notes, shell protocol sketch, semantic marks note, inspiration map, bibliography, external-source tracking, assumptions/claims/non-claims, evidence index, context pack, lint requirements, and release manifest for the new revision.

## Revised007 (2026-03-21)
- Continued external research on immutable identity versus mutable heads, durable reopen versus recent-item UX, typed reveal/launch routing, and semantic terminal marks/hyperlink overlays.
- Added `docs/30-architecture/object-identity-recents-and-reveal.md` to keep immutable object refs, local names, durable reopen handles, workspace binds, and reveal/launch routes on distinct seams.
- Added `docs/70-shell/semantic-marks-links-and-overlays.md` to collect protocol-driven shell/terminal ideas around marks, typed object links, inspect overlays, and honest recent-item states.
- Added `rfcs/0007-viewfs-keep-identity-recents-and-reveal-separate.md` so future proposals must classify whether they are about identity, naming, durable reopen, workspace binding, or routing.
- Refreshed architecture overview, SlopOS seam map, shell protocol notes, inspirations, bibliography/review surfaces, assumptions/claims/non-claims, context pack, lint gate, and release manifest for the new revision.

## Revised006 (2026-03-21)
- Continued online research on workspace/tree grants, chooser-versus-transfer durability, URI launch boundaries, typed routing, semantic zones, and shell completion ergonomics.
- Added `docs/30-architecture/workspace-grants-and-rebinding.md` to keep workspace/tree binds separate from single-object open, transfer, durable reopen, and OpenURI launch/reveal.
- Added `docs/70-shell/truthful-completions-and-routing.md` to collect shell ideas around authority-aware completions, stale-grant handling, typed routes, and palette results that preserve object kind and seam.
- Added `rfcs/0006-viewfs-separate-workspace-grants-from-recents-and-openuri.md` so future proposals must classify whether they are opening, rebinding, reopening, transferring, or routing.
- Updated architecture overview, SlopOS seam map, portal grant notes, shell protocol sketch, inspirations, claims/assumptions/non-claims, bibliography, review tracking, context pack, lint requirements, and release manifest for the new revision.

## Revised005 (2026-03-21)
- Continued online research on rooted compat walkers, ambient-authority markers, Linux backstop sandboxing, OpenURI/reveal flows, and shell product ideas that can stay capability-honest.
- Added `docs/30-architecture/host-bridge-and-backstop-posture.md` to separate bring-up tactics such as preopens, `openat2`-style rooted walking, ambient-debt markers, and Landlock from the actual ViewFS semantic core.
- Expanded `docs/30-architecture/portal-grant-lifecycle-notes.md` with grant classes and receipt states so import/open, transfer, save/export, durable reopen, and bound-workspace semantics remain visibly distinct.
- Added `docs/70-shell/shell-super-awesome-moves.md` to collect higher-ambition terminal ideas such as object palettes, authority diffs, receipt trays, route sheets, and safe replay with stripped authority.
- Extended the shell protocol sketch, inspiration map, SlopOS seam map, and architecture overview with the new research.
- Refreshed bibliography, external-source tracking, evidence index, assumptions/claims/invariants/non-claims, trajectory map, roadmap, context pack, lint requirements, and release manifest for the new revision.

## Revised004 (2026-03-21)
- Continued online research on namespace composition, grant durability, revocation costs, explicit rights attenuation, terminal metadata, and workflow UX.
- Added `docs/30-architecture/design-splits-and-non-decisions.md` to keep identity, naming, mutable state, and durable grants intentionally decoupled until evidence justifies otherwise.
- Added `docs/30-architecture/revocation-and-durable-grants-design-space.md` to clarify ephemeral grants, durable reopen, and strong live revocation as separate commitments.
- Added `docs/70-shell/shell-terminal-protocol-sketch.md` so shell/terminal ambition is grounded in explicit metadata rather than screen scraping or hidden ambient state.
- Added `rfcs/0004-viewfs-separate-questions-before-freezing.md` to make future semantic coupling earn its way into the design.
- Updated architecture overview, seam map, inspiration map, claims/assumptions/invariants/non-claims, bibliography, review tracking, evidence index, roadmap, and trajectory map for the new research pass.

## Revised003 (2026-03-21)
- Continued external research on rights attenuation, capability bundles, mutable-over-immutable work state, persistent grant failure modes, and terminal UX patterns.
- Added `docs/30-architecture/mutable-work-state-design-space.md` to capture the main non-POSIX options for editable state without prematurely standardizing one.
- Added `docs/30-architecture/rights-attenuation-and-bundles.md` to pin the idea that rights reduction and bundle grouping must stay explicit and inspectable.
- Added `docs/30-architecture/portal-grant-lifecycle-notes.md` to map open/save/reopen/transfer flows, durable versus ephemeral grants, and the failure lessons from prior ecosystems.
- Added `rfcs/0003-viewfs-open-research-spikes.md` to keep the next experiments narrow, testable, and deliberately non-final.
- Expanded `docs/70-shell/shell-terminal-ideas.md` with visible view badges, authority previews, receipt-aware blocks, terminal domains, and local-first notebooks/workflows.
- Expanded `docs/90-inspirations/inspirations-mapped.md` and the bibliography with new lessons from Capsicum rights, cap-std, Android SAF, Tahoe-LAFS mutable slots, and recent bookmark/persistent-grant cautionary evidence.
- Updated repo hygiene surfaces: release manifest tooling now accepts packaging metadata via environment variables, the context pack includes the new must-read docs, and the REF review register/queue were extended.

## Revised002 (2026-03-21)
- Continued external research on namespace composition, capability grouping, mediated transfer, mutable-over-immutable models, and shell/terminal interaction.
- Added `docs/30-architecture/slopos-seam-map.md` to keep ViewFS aligned with SlopOS datacube surfaces instead of inventing parallel semantics.
- Added `rfcs/0002-viewfs-decision-freeze-and-spike-plan.md` to record which major decisions remain intentionally deferred and which prototypes should answer them.
- Expanded `docs/70-shell/shell-terminal-ideas.md` with ideas around semantic zones, plumb-style routing, command palettes, notebooks, and mediated drag/drop transfer.
- Expanded `docs/90-inspirations/inspirations-mapped.md` with new lessons, especially around grouped capability bundles, transfer portals, mutable overlays over immutable stores, and stable mutable anchors.
- Added a compact `RELEASE-MANIFEST.json` and updated repo tooling/context-pack generation for better datacube hygiene.
- Updated bibliography, external-source head tracking, review queue, claims, assumptions, non-claims, evidence index, roadmap, and trajectory map.

## Revised001 (2026-03-21)
- Seeded the first ViewFS datacube archive with repo hygiene, charter, trajectory map, claim/invariant skeletons, and a first RFC.
- Added architecture notes for:
  - immutable-first object store posture,
  - explicit per-process namespace posture,
  - portal-mediated import posture,
  - path compatibility membrane posture.
- Added a curated inspiration map covering capability systems, namespaces, portals, content-addressed stores, and terminal UX patterns.
- Added a shell/terminal idea file focused on structured pipelines, capability-aware completions, block transcripts, clickable receipts, and multiplexed view domains.
- Added external-source head tracking surfaces for moving-head docs used during design review.
