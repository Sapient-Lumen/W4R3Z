# RFC-0022: Keep bundles, view fragments, live binds, launch kits, and receipts separate

## Status
Proposed.

## Problem
ViewFS already tries hard not to collapse identity, naming, mutable heads, reopen, transfer, trust, and warm-state classes.
A new collapse risk is now visible:
- grouped authority bundle,
- reusable namespace fragment,
- live bind into the current process view,
- child-process launch material,
- and transcript/history receipt

can all start to look like “one convenient file-ish object”.

That would be a mistake. It would smuggle ambient behavior back in through convenience.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat the following as distinct classes:
- **AuthorityBundle** / dictionary / kit object,
- **ViewFragment** / namespace template,
- **ViewBind** as a mutation of a concrete view,
- **LaunchKit** / exec-pack assembly for a child process,
- and **Receipt** as history, not live authority.

New live authority should appear through explicit bind/rebind or launch assembly acts, not because a child process or helper silently reinterpreted some remembered object.

## Consequences
- grouped authority can stay reusable without becoming hidden inheritance
- pane state and child-launch state can be compared honestly
- saved workflows/notebooks can stay useful without silently serializing live authority
- the shell can rehearse launches and explain authority diffs before execution
- SlopOS view mutation, capshell exec-pack, and portal receipt seams remain aligned instead of being replaced by a second object model

## Non-goals
This RFC does not choose:
- a final stored schema for bundles or fragments,
- a final shell syntax for bind / launch / with / route operations,
- a final launch-kit encoding,
- a final persistence story for saved kits,
- or a final rule for whether bundles can contain refs, handles, receipts, or any mix.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing a **bundle**, a **view fragment**, a **live bind**, a **launch kit**, or only a **receipt/history** surface?
- Who assembled the child namespace, and can the child widen it by itself?
- What is live authority now versus only a remembered recipe?
- If something is moved between panes/processes, is that a bind, a transfer, a route, or only receipt reuse?
- Does the shell preserve the difference between current pane truth and candidate child launch truth?

If the answer is “they are basically all one object for convenience,” the burden of proof should be high.
