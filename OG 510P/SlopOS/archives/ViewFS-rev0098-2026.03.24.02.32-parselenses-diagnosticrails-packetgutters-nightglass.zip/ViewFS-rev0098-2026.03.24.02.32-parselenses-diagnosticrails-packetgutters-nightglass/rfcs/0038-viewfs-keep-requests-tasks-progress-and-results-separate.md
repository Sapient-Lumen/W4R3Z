# RFC-0038: Keep requests, tasks, progress, and results separate

Status: Draft  
Updated: 2026-03-22  
Decision family: deferred work / helper tasking / shell ergonomics

## Summary
ViewFS should keep one more seam explicit while helper-aware shelling and automation are still fluid:

**immediate request ≠ accepted task wrapper ≠ live status/progress stream ≠ input-required checkpoint ≠ deferred final result retrieval ≠ durable receipt/history**

This keeps the shell free to queue, watch, steer, cancel, and retrieve deferred work **without letting task acceptance, background permission, or old results quietly become current authority or fake completion**.

## Motivation
Revision 0037 froze the split between helper feature kinds, request binding, live invocation, and durable receipts.

That still leaves a dangerous gap:
- a helper/tool can accept work now without finishing now,
- emit progress without having a final result,
- pause for more input without that state being either success or generic failure,
- and keep result retrieval separate from both task acceptance and progress observation.

Current precedent makes this risk real:
- XDG portals keep a request handle alive for the duration of the interaction and deliver the result later,
- MCP tasks use a two-phase response where the accepted task wrapper is not the final result,
- MCP progress uses a separate progress lane,
- Google long-running operations keep polling/waiting distinct from the initiating call,
- XDG Background separates permission to keep running from current status messages,
- VS Code task/agent UX already needs explicit treatment of background/watch completion and queued follow-ups.

## Decision
For future ViewFS design work, proposals must classify whether they are changing:
1. **immediate requests** — exact request/intent submission now,
2. **accepted task wrappers** — deferred-work acceptance/lifecycle objects,
3. **live status/progress streams** — advisory running-state surfaces,
4. **input-required checkpoints** — explicit waits for additional user/system input,
5. **deferred final result retrieval** — final result/error availability and retrieval,
6. **durable receipts/history** — what only records past task acceptance/progress/input/result outcomes.

## Consequences
### Positive
- gives ViewFS a clean way to say “accepted”, “still running”, “needs input”, and “final result retrieved” are different truths;
- creates room for strong shell UX around background/deferred work without pretending requests are blocking calls;
- keeps background permission and status text from laundering themselves into task ownership or durable success;
- aligns with SlopOS mediator/effect-contract posture and with current helper/task ecosystems.

### Costs
- one more family of task-state objects to explain;
- richer receipts and shell chrome;
- more typed UI than a single vague “job” or “background task” badge.

## Non-goals
- freezing the final ViewFS task schema,
- deciding whether every deferred operation shares one task wrapper,
- deciding the final retention/TTL/keepalive policy for task metadata or results,
- deciding whether result lockers are pane-bound, request-bound, or helper-session-bound by default.

## Near-term prototype
Build one deferred-work shell flow with:
- task badge,
- progress lane,
- input-required drawer,
- queue rail,
- result locker,
- task receipt that preserves acceptance/progress/input/result truth.

If that feels magical **and** honest, keep the seam. If it feels noisy, trim the UI before trimming the boundary.
