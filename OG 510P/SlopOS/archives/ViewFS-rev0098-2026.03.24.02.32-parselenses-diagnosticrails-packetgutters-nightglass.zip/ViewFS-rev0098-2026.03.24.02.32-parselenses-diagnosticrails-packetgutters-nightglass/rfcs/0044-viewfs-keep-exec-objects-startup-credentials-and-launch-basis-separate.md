# RFC 0044: Keep exec objects, startup credentials, and launch basis separate

Status: draft guardrail RFC.

## Why this exists
ViewFS already separates route plans, command packets, live process handles, detached fragments, and durable receipts.
A new design pressure is appearing around **exact launch meaning before a child starts**:
- a reviewed launch may want to point at one exact executable object or exact staged byte object,
- explicit interpreter/script entry is a separate seam from executable-object identity,
- argv/env/cwd shaping is a separate launch-basis seam,
- activation-time credential delivery is another separate lane,
- and the later receipt/history artifact still is not the same thing as any of the above.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design.

## Distinct truths

### 1. Exact exec object
Question:
- what exact executable object or exact staged byte object is intended to run?

Examples:
- an executable-object handle
- an exact staged exec object
- a digest-bound launch target

### 2. Explicit script/interpreter entry
Question:
- is this launch native binary execution, or one explicit interpreter plus one explicit script/input object?

Examples:
- interpreter handle plus script object
- exact script-entry arrangement
- explicit non-shebang entry record

### 3. Launch basis
Question:
- what argv/env/cwd/root shaping was prepared for this launch?

Examples:
- argv basis record
- env delta card
- cwd/root launch posture

### 4. Startup credential lane
Question:
- what activation-time credential slots, if any, were delivered to the child?

Examples:
- credential slot descriptors
- activation-only private-file delivery
- startup credential receipt stubs

### 5. Receipt / history artifact
Question:
- what durable artifact records that the launch was prepared or committed?

Examples:
- launch receipts
- route-plan receipts
- history rows
- reviewed command blocks

## Guardrail
A system should be allowed to review and commit a launch without collapsing these classes.
It must not silently pretend that:
- a reviewed command string or mutable path alias is already exact executable identity,
- startup credentials are morally the same thing as environment variables or ordinary namespace binds,
- a launch receipt still carries live launch authority,
- or one shell history row is enough to recreate the original launch basis exactly.

## Implications for ViewFS
- launch review should be able to say `exec object`, `script input`, `argv/env basis`, `credential slot`, `launched`, or `history only` as different truths;
- exact-exec-object launch should remain compatible with per-platform handle or exact-byte staging mechanisms without forcing one kernel primitive into the architecture;
- startup credential presence should be visible without ever dumping secret contents into transcript flow;
- replay should begin from fresh planning or reviewed receipts, not by assuming an old command row still implies the original exec object and startup credential set.

## Non-decisions
This RFC does **not** decide:
- which platform primitives implement exact-exec-object launch;
- whether startup credentials are carried as private files, handles, slots, or another narrow lane;
- whether any activation-time credential can later be promoted into durable reopen;
- how much exact launch-basis diffing Phase 1 shell chrome should surface by default.

## Shell consequences
The custom shell+terminal should be allowed to grow:
- launch basis cards,
- exact-exec-object badges,
- startup credential drawers,
- and history-versus-exact-launch truth transitions,
without claiming more than the current launch basis actually supports.
