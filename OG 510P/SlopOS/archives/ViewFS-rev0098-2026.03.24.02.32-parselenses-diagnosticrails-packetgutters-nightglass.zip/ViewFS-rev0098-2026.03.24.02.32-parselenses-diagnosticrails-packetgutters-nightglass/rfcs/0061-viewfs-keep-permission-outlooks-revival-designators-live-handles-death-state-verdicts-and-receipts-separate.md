# RFC-0061: Keep permission outlooks, revival designators, live handles, death-state verdicts, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates designation from authority, and declared caveats from enforced attenuation.
The next low-regret seam is **permission/liveness state versus current authority**.

A shell-visible `granted`, `prompt`, `denied`, `needs revalidate`, `revoked`, `expired`, `issuer unavailable`, or `history only` badge is not the same thing as a current live handle.
Neither is the same thing as one stored designator that might help later.

If we collapse those classes too early, we make at least four mistakes:

1. **permission outlook becomes fake authority**
   - a preflight light like `granted` starts being treated as if the shell already has a live handle.

2. **dead-state gets flattened into vague staleness**
   - `revoked`, `expired`, `target changed`, and `issuer offline` all become the same unhelpful red badge.

3. **repair paths disappear**
   - the system forgets whether the next honest step is `request`, `revalidate`, `rebind`, `import fresh`, or `give up and stay history-only`.

4. **history starts masquerading as liveness**
   - an old receipt or recent-item row gets mistaken for proof that the underlying authority is still usable now.

## The seam

Keep these classes visibly distinct:

1. **permission outlook / eligibility state**
   - one current preflight view such as `granted`, `prompt`, `denied`, `grantable_here`, `revalidate_needed`, or `policy_blocked`.
   - useful for prediction, routing, and shell chrome.
   - not by itself proof that a live handle is already held.

2. **revival designator / recontact token**
   - a stored thing that may let the system later request, restore, or revalidate access.
   - not the same thing as current authority.

3. **live handle / bind now**
   - one currently held handle/capability/bind that can be used now.
   - this is the current-authority truth.

4. **death-state verdict / liveness tombstone**
   - an explicit negative or terminal state such as `revoked`, `expired`, `deleted`, `target changed`, `issuer unavailable`, `membrane dropped`, or `policy denied`.
   - should preserve the reason class, not collapse back into vague `stale`.

5. **receipt / history**
   - evidence that a grant, request, import, revive, deny, expiry, or revocation happened once.
   - not current authority.

## Working posture

- ViewFS should expose **permission outlook** as advisory preflight, not authority.
- ViewFS should expose **death-state verdicts** as explicit repairable or terminal outcomes, not generic errors.
- ViewFS should prefer exact reason classes over one all-purpose `stale` bucket.
- Shell UX should expose whether a visible row/chip is:
  - `permission outlook only`
  - `designator only`
  - `live handle now`
  - `dead-state verdict`
  - `receipt only`

## What to steal

- W3C Permissions / File System Access: `granted`, `prompt`, and `denied` are useful because they are explicit *states*, not hidden heuristics.
- Android SAF: stable document IDs and per-document capability flags are useful, but still distinct from whether the app currently has permission and from whether the target still opens cleanly.
- XDG Documents: `GrantPermissions`, `RevokePermissions`, `Delete`, and `Info` are separate acts with inspectable consequences.
- zcaps: expiry and revocation handling stay first-class rather than becoming invisible folklore.
- seL4: revoke is explicit; user-level design should avoid pretending authority loss is mysterious.

## Phase-1 non-decisions

This RFC does **not** decide:
- whether ViewFS uses one universal permission-state vocabulary or family-specific vocabularies,
- whether all death-state verdicts are durable or only some are receipted,
- whether revival designators are provider-local only or sometimes portable,
- whether the shell can proactively subscribe to permission/liveness changes,
- whether every dead-state verdict has an automatic repair lane.

## Shell consequences

The shell/terminal should gain:
- **permission lights** such as `granted`, `prompt`, `denied`, `revalidate`, `policy blocked`,
- **death certificates** such as `revoked`, `expired`, `issuer offline`, `target changed`, `history only`,
- **repair ladders** that prefer `request`, `revalidate`, `rebind`, or `import fresh` over generic reopen magic,
- **preflight gutters** that show outlook before execution without pretending the result is already held,
- transcript rows that can distinguish `permission looks good` from `live authority held now`.

## Design bar

Before ViewFS standardizes any durable reopen or delegated-share story, it should be able to answer:

1. Is the shell showing current authority, only permission outlook, or only history?
2. If something died, can the user tell whether it was revoked, expired, deleted, changed, or merely needs revalidation?
3. What is the next honest repair step: request, revalidate, rebind, import fresh, or none?
4. Can the shell explain that difference without collapsing everything into `stale`?
