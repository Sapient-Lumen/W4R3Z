# RFC 0047: Keep live process handles, terminal streams, controlling TTY bindings, and foreground turns separate

## Status
Accepted for design-phase guardrails.

## Why this exists
ViewFS already keeps:
- command packets separate from live process handles,
- observe/attach/control/debug/sideband lanes separate,
- and prompt-local input separate from old transcript text.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design:

**a live process handle, the stdio/PTY streams wired to it, the controlling-terminal relationship, the current foreground-turn / interrupt-target state, and durable transcript/history are different classes.**

That sounds subtle.
It matters immediately if the future shell wants to be honest about:
- whether a pane is only mirroring output,
- whether stdin is actually live,
- whether Ctrl-C / Ctrl-Z will reach the thing the user thinks it will,
- whether a job is backgrounded versus foregrounded,
- whether an attach is sharing an existing controlling TTY or creating a new one,
- and whether a remembered command row still has any live relationship to a terminal at all.

## Lessons from the past
Classic UNIX job control already drew these seams for a reason:
- sessions, process groups, and foreground jobs are distinct layers;
- only the foreground process group may read from the controlling terminal;
- signal-generating terminal keys target the foreground process group;
- `login_tty()` can make one file descriptor become the controlling terminal *and* redirect stdio;
- `/dev/tty` is a synonym for the controlling terminal of the current process, not a generic proof that some stream is attached;
- detaching a controlling terminal is another explicit act again.

The lesson for ViewFS is not “copy POSIX job control literally.”
The lesson is: **do not let one pretty shell card collapse process identity, byte streams, controlling-terminal posture, foreground ownership, and transcript history into one thing.**

## Guardrail
ViewFS should keep these classes visibly separate:
1. **Live process handle** — the running command/session object.
2. **Terminal stream lane** — pipes, PTY streams, mirrored output, stdin openness, stderr split/merge, etc.
3. **Controlling-TTY binding** — whether this process/session actually owns or is attached to a controlling terminal.
4. **Foreground turn / interrupt target** — whether this job currently owns interactive terminal input/signals.
5. **Receipt/history** — durable text or cards about what happened.

## Consequences
We should be able to say things like:
- `running now`
- `stdout mirrored`
- `stdin live`
- `pty attached`
- `controlling tty`
- `foreground turn`
- `backgrounded`
- `detached`
- `history only`

without laundering them into one fake “connected” bit.

## Good answers might look like
- supervisor-local live process refs
- explicit stream-lane descriptors
- PTY or controlling-terminal posture descriptors
- explicit foreground-turn / signal-target metadata
- durable launch/attach/detach/stop receipts

## What this does not decide
This RFC does **not** decide:
- whether ViewFS uses PTYs, richer brokered terminal objects, or another cross-platform stream primitive;
- whether foreground turns are modeled directly or only exposed as shell metadata;
- whether attach-with-TTY always reuses a prior controlling terminal or sometimes provisions a new carrier;
- whether signal routing is implemented by host job control, helper mediation, or another adapter layer.

## Shell implications worth stealing
A future custom shell/terminal should expose:
- **foreground baton pills** — who currently owns Ctrl-C/Ctrl-Z style input;
- **TTY lease badges** — whether a job merely streams bytes or actually owns a controlling terminal relationship;
- **attach rails** that distinguish `observe`, `stdin live`, `pty attached`, `controlling tty`, and `foreground now`;
- **interrupt previews** that say where terminal-generated signals will actually go;
- **history cards** that preserve these truths after the job is gone without pretending the job is still live.

## Why this is a low-regret move
Even if SlopOS later changes its exact Capshell, portal, or supervisor mechanism, this split stays useful.
It is the kind of boundary that keeps the shell honest while the deeper implementation is still moving.
