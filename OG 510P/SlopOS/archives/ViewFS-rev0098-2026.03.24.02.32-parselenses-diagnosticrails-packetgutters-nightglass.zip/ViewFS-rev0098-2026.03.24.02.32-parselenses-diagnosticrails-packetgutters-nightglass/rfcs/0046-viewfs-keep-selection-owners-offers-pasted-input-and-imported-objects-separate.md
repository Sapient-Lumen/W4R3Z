# RFC-0046: Keep selection owners, offered representations, pasted input, and imported objects separate

Status: Draft  
Date: 2026-03-22

## Decision

**transient selection ownership/source, offered representations, accepted transfer acts, pasted prompt input, imported/materialized objects, and durable receipts/history are different classes.**

ViewFS should therefore preserve at least these seams:
- the **current owner/source** of a clipboard/selection/transfer offer,
- the **representations advertised** for that offer,
- the **one representation actually accepted and transferred**,
- the **prompt-input or transient bytes** that arrived in this shell pane,
- the **explicit import/materialization/bind act** that may happen later,
- and the **receipt/history artifact** that remains afterward.

## Why

Clipboard and selection history keeps teaching the same lesson:
- X11 selections are not durable stores; they are owner/requestor transfer relationships.
- Wayland data offers and primary-selection offers advertise MIME types and only transfer bytes once the receiver explicitly requests a representation.
- modern terminals can distinguish paste-origin input from ordinary typing, and some now expose richer clipboard protocols with MIME introspection and permission prompts.

Those are all warnings against flattening “selected”, “copied”, “pasted”, “imported”, and “reopen later” into one vague object story.

## Guardrails we can freeze now

- owning the current clipboard/selection is not the same thing as giving another process a durable object ref;
- an offered MIME/type list is not the same thing as the exact representation the receiver accepted;
- pasted prompt bytes are not automatically a local object import;
- importing/materializing bytes is a visibly new act, not a hidden side effect of merely inspecting or pasting;
- clipboard/selection history is an optional privileged helper lane, not a baseline capability of every pane;
- document-style durable reopen should stay separate from transfer/clipboard lanes even when the payload happens to name the same thing.

## Product implications

A future custom shell+terminal should be able to show:
- a **selection/clipboard offer card** with owner/source witness, offered MIME types, and expiry/replace state;
- a **paste capsule** when bytes are inserted into a prompt, distinct from later import or bind acts;
- an explicit **import this payload** / **bind here** / **receipt only** ladder;
- and a small **clipboard-history or clipboard-manager badge** only when some privileged helper is actually retaining past offers.

## Non-goals

This does **not** decide:
- the final clipboard/selection protocol,
- whether ViewFS offers both primary-selection-style and clipboard-style lanes,
- how MIME/type registries are encoded,
- or whether clipboard history exists at all in Phase 1.

## Consequences

Good:
- portal-mediated imports stay honest about when authority or durable identity is actually minted;
- shell UX can be much richer without lying that pasted bytes are already safe, durable, or re-openable;
- SlopOS alignment improves because transfer-portal drafts, durable-docref drafts, and capshell prompt input can stay on visibly different seams.

Cost:
- some workflows will require one more explicit step (`paste` then `import`, or `offer` then `retrieve`) rather than one magical “open” button.

## Review question

For any future proposal, ask:
- Is this changing a **selection owner/source**, an **offer**, an **accepted transfer**, **pasted prompt input**, an **import/materialization/bind**, a **durable reopen artifact**, or only a **receipt/history** surface?
