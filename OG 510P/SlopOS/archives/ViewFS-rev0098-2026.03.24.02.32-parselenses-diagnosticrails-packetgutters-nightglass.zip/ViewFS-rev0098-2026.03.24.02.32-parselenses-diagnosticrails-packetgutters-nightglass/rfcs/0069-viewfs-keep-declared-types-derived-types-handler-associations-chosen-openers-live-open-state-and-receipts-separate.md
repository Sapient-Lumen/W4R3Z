# RFC-0069: Keep declared types, derived types, handler associations, chosen openers, live open state, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already tries to keep identity apart from placement, current handle rights apart from provider affordances, and previews apart from authority.
The next low-regret seam is **declared type / derived type / handler association / chosen opener / live open state**.

One object's declared media/type hint is not the same thing as a type derived from bytes, tags, or structure.
One type classification is not the same thing as a list of associated handlers or candidate tools.
One associated/default handler is not the same thing as the opener actually chosen for this act in this pane.
And none of those are the same thing as one current live viewer/editor session or a receipt.

If ViewFS collapses those classes too early, we make at least six mistakes:

1. **declared type starts masquerading as computed truth**
   - one MIME/UTType/file-extension hint starts acting like the final classification even when sniffing, magic, or structure says otherwise.

2. **computed type starts masquerading as identity**
   - one type label starts acting like the object itself instead of just one current classification view over it.

3. **handler association starts masquerading as user choice**
   - a candidate/default app starts acting like the exact opener the user chose for this act.

4. **chosen opener starts masquerading as durable policy truth**
   - one `open with X` action starts silently becoming a sticky global default or future routing promise.

5. **live open state starts masquerading as current authority elsewhere**
   - one active viewer/editor session starts acting like every pane or process now holds the same handle or mutation lane.

6. **history starts masquerading as current openability truth**
   - one old receipt that something opened once starts acting like the current type classification, current handler availability, or current opener state.

## The seam

Keep these classes visibly distinct:

1. **declared type / supplied type**
   - one type claimed by metadata, extension, provider field, manifest entry, header, or upstream source.
   - useful for routing and explanation.
   - not final truth by itself.

2. **derived type / computed type**
   - one type inferred from bytes, signatures, structure, or higher-confidence local analysis.
   - may disagree with the declared type.
   - still not object identity or authority.

3. **handler association set**
   - the tools/apps/helpers currently associated with a type or object class.
   - may include defaults, preferences, or provider-advertised viewers/editors.
   - not proof that one opener was chosen for this act.

4. **chosen opener / route choice**
   - the exact tool/viewer/editor/helper selected for one act in one pane/session.
   - may be user-chosen, rule-chosen, or mediator-chosen.
   - should not silently become a sticky future default.

5. **live open state / live editor-viewer session**
   - the current active viewer/editor/helper session for one object or representation.
   - may be read-only, editable, detached, disposable, external, portal-owned, or local.
   - not a synonym for current authority in every other pane.

6. **receipt / history**
   - evidence that one object was classified, associated, opened, previewed, edited, or routed in some way.
   - useful for explanation and replay hints.
   - not current classification, current association, or current live state.

## Working posture

- ViewFS should let declared type and derived type coexist and disagree visibly.
- ViewFS should let handler associations stay advisory/discoverable without pretending they are already chosen.
- ViewFS should let one chosen opener remain one act-local route decision unless the user makes a stronger preference move.
- ViewFS should let live open/editor state stay explicit and scoped instead of laundering it into general authority.
- ViewFS should keep receipts/history useful for explanation without treating them as present openability truth.

## What to steal

- **WHATWG MIME Sniffing**: supplied MIME type and computed MIME type are separate metadata classes, and sniffing can be context-specific.
- **freedesktop shared-mime-info**: globs, magic, aliases, and subclassing are separate database contributions rather than one magic extension rule.
- **freedesktop mime-apps**: associated/default applications are listed separately from the underlying MIME/type database and from one actual open act.
- **Apple Uniform Type Identifiers**: one declared type can conform to broader supertypes and map to MIME/file tags without being only an extension string.
- **Android DocumentsProvider**: `COLUMN_MIME_TYPE` and per-document flags are explicit provider surfaces; one document can also be virtual and expose alternative streamable representations.
- **Windows Preview Handlers**: preview is a lightweight, read-only hosted act without launching the associated application.

## Shell consequences

The shell/terminal should gain:
- **type lenses** that can show `declared`, `derived`, `disagrees`, `virtual`, `representation available`, or `unknown`;
- **handler racks** that can show `associated`, `default`, `suggested`, `chosen now`, or `unavailable here`;
- **open-state badges** that can show `previewing`, `editing`, `external`, `portal-owned`, `detached`, `disposed`, or `history only`;
- **sniff-truth drawers** for `declared says pdf`, `derived says zip`, `open safely`, `choose inert viewer`, or `route via helper`;
- **why-this-opener drawers** so one launch row can explain whether it came from user choice, default association, policy, or explicit route slip.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal type taxonomy for every object and representation,
- whether ViewFS stores all derived classifications durably or computes many on demand,
- whether handler associations come from providers, shell adapters, local policy, or a mixed model,
- whether opener choice lives in the shell, a portal, or a helper daemon for every platform,
- whether live open/editor sessions are shell-owned, provider-owned, or external on every platform.

## Design bar

Before ViewFS standardizes richer open-with/type-routing behavior, it should be able to answer:

1. Is this label a declared type, a derived type, a handler association, a chosen opener, one live open state, or only history?
2. Can declared and derived type disagree without forcing one to silently overwrite the other?
3. Can a handler be associated with a type without pretending it has already been chosen for this act?
4. Can one chosen opener stay act-local instead of silently becoming the future default?
5. Can live preview/editor state stay scoped instead of laundering itself into ambient authority elsewhere?
6. Can old receipts remain useful without silently becoming current type/openability truth?
