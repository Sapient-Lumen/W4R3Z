# RFC-0007: Keep object identity, recents, workspace binds, and reveal/launch separate

Status: Draft

## Problem
Filesystem-like systems often drift toward a single overloaded primitive where one token, path, or bookmark is expected to answer all of these questions at once:
- what immutable object is this?
- what name does it have in my current world?
- what mutable head should I reopen next time?
- what did the user previously approve?
- what should a click or “open” action do now?

That collapse looks convenient early and becomes expensive later.

## Proposal
Freeze one design rule for the design phase:

> ViewFS proposals must classify whether they are about **immutable object identity**, **view-local naming**, **durable reopen/grant**, **workspace binding**, or **route/reveal/launch behavior**. They may relate these surfaces, but must not silently merge them.

## Why this helps
- keeps SlopOS seam reuse possible (`view`, document portal, OpenURI, transfer, safe shell/plumb)
- reduces confused-deputy risk from “click means grant” UI accidents
- avoids turning recent-items into ambient authority
- lets the object store remain simple while reopen/workspace ergonomics evolve independently

## Guardrails
1. An immutable object ref must not automatically imply durable reopen.
2. A recent item must not automatically imply current authority.
3. A reveal/launch route must not automatically mint a new local-object grant.
4. A workspace bind must be transcript-visible as stronger than a one-file open.
5. Shell/terminal links must preserve kind and route semantics instead of degrading into raw paths or generic URIs.

## Non-goals
- choosing a final durable-handle schema
- choosing a final recent-items schema
- choosing a final shell hyperlink wire format
- deciding whether stable mutable heads exist in ViewFS Phase 1

## Required evidence before future coupling
Any later proposal that wants to merge two of the surfaces above should bring:
- at least one concrete user workflow improved by the coupling,
- at least one abuse case that becomes easier to reason about rather than harder,
- a transcript/receipt story showing the merge remains inspectable,
- and a failure-mode story for rename/move/stale-grant cases.

## Immediate implication
Continue treating ViewFS as:
- immutable object store,
- explicit handle/view system,
- portal-mediated grants and reopen,
- typed shell/terminal routes,
with recents and reveal remaining useful UX layers rather than foundational authority semantics.
