# RFC-0066: Keep selected regions, extracted entity candidates, route envelopes, prepared actions, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates completion suggestions from accepted insertions and compiled packets.
The next low-regret seam is **selected screen region / typed entity candidate / routed intent envelope**.

A highlighted span of transcript text is not yet one typed object.
A typed object candidate is not yet one resolved target or one chosen route.
A resolved target is still not one plumb message or route envelope.
A route envelope is still not one prepared action.
And none of those are the same thing as a historical receipt.

If we collapse those classes too early, we make at least five mistakes:

1. **highlight starts masquerading as semantics**
   - one selected range of bytes starts acting like the shell already knows it is a path, digest, object ref, receipt ref, or URL.

2. **recognition starts masquerading as routing**
   - one extracted candidate starts acting like a route choice or an approved intent.

3. **lazy target resolution starts masquerading as fixed meaning**
   - on-hover/on-focus detail starts acting like the candidate was always one fully resolved object.

4. **hyperlink rendering starts masquerading as authority**
   - one OSC 8-marked region or typed link starts acting like clicking it should directly open, launch, or import something.

5. **history starts masquerading as current routeability**
   - an old selected span, route packet, or past click receipt starts acting like the current pane still has the same valid targets and rights.

## The seam

Keep these classes visibly distinct:

1. **selected region / matched screen span**
   - one highlighted transcript range, hover target, terminal hint match, or block-local cell span.
   - may come from mouse selection, keyboard hints, semantic marks, or explicit links.
   - not by itself one typed object.

2. **extracted entity candidate**
   - one shell/terminal/provider guess or declaration such as `path-ish`, `lineref`, `digest`, `object_ref`, `receipt_ref`, `uri`, `query_ref`, or `unknown`.
   - may be heuristic or explicit.
   - not by itself one chosen target or route.

3. **resolved entity detail / target expansion**
   - extra detail fetched or computed for one candidate.
   - may include object kind, host mismatch, current existence, current view-local bind, or destination detail.
   - not by itself one routed action.

4. **route envelope / plumb packet**
   - one typed, reviewable envelope that says what action family is being proposed and on what subject.
   - may say `inspect`, `reveal`, `open_in_tool`, `launch_uri`, `rebind`, `import_here`, `compose_packet`, or `receipt_only`.
   - not by itself one approved action.

5. **prepared action / route plan**
   - one exact action basis after route choice, target resolution, and any needed revalidation/preflight.
   - may still be `approval needed`, `portal needed`, `rebind needed`, `hostname mismatch`, or `ready`.
   - not history.

6. **receipt / history**
   - evidence that one region was selected, one entity was recognized, one route envelope was formed, or one action ran.
   - not current authority.

## Working posture

- ViewFS should let terminal selection and hyperlink UX feel immediate without pretending every selected span is already a typed object.
- ViewFS should keep explicit entity extraction and lazy target resolution inspectable instead of burying them in one click.
- ViewFS should keep plumb/route envelopes typed and reviewable instead of letting raw strings become action or authority.
- ViewFS should keep typed links and routed actions separate even when they render as ordinary hyperlinks.
- ViewFS should keep history useful for teaching/replay without silently reviving current routeability.

## What to steal

- **Plan 9 plumber**: typed message routing, rewriting, dispatch, and held-for-delivery behavior are a great reminder that routing envelopes are their own class.
- **OSC 8 hyperlink discipline**: hyperlinks are display/cell attributes and may need host checks for `file://` targets rather than blind open.
- **LSP document links**: a document range can be linked before its final target is resolved; `data` can survive from link discovery to lazy resolve.
- **kitty hints**: selecting visible text and acting on it can be powerful exactly because matching and actions remain configurable and explicit.

## Shell consequences

The shell/terminal should gain:
- **entity peels** that reveal what the current highlight might mean without committing to a route;
- **lazy resolve drawers** that can say `host mismatch`, `object missing`, `receipt only`, or `view bind exists here` before any action is prepared;
- **route slips** that promote one entity candidate into one typed plumb/route envelope instead of jumping straight from click to side effect;
- **hypertruth badges** so the shell can say `heuristic text`, `explicit link`, `resolved target`, `prepared route`, or `receipt only`;
- **selection replay guards** so old transcript regions stay useful without becoming current authority or current routing truth.

## Phase-1 non-decisions

This RFC does **not** decide:
- the final entity-candidate taxonomy,
- whether entity extraction is shell-owned, terminal-assisted, or helper-assisted,
- whether route envelopes reuse one shared schema with other ViewFS packets,
- whether all typed links render through OSC 8 or a richer terminal-side protocol,
- whether selection history is stored by default.

## Design bar

Before ViewFS standardizes stronger transcript-click/selection routing, it should be able to answer:

1. Is the user looking at one selected span, one entity candidate, one resolved target detail set, one route envelope, one prepared action, or only history?
2. Can the shell show and revise entity extraction without silently changing the action that would run?
3. Can explicit hyperlinks stay typed and reviewable rather than becoming blind `open`?
4. Can host mismatch / missing target / stale receipt states degrade honestly before action preparation?
5. Can old selections and old route receipts remain useful without silently becoming current authority or current routing truth?
