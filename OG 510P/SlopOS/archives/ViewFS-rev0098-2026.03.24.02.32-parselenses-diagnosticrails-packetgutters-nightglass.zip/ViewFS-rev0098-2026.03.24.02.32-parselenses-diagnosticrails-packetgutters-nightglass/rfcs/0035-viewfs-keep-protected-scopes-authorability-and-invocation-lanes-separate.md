# RFC-0035: Keep protected scopes, authorability, and invocation lanes separate

Status: Draft  
Updated: 2026-03-22  
Decision family: source admissibility / protected state / shell ergonomics

## Summary
ViewFS should keep one more seam explicit while source-aware shelling is still fluid:

**protected-authorable state ≠ carrier/discovery presence ≠ invoke-only helper material ≠ trust-gated adoption lane ≠ effective active state ≠ durable receipt/history**

This keeps the shell free to discover, rank, and one-shot invoke helper material aggressively **without letting lower-trust carriers or workspace material silently author sticky always-on state**.

## Motivation
Revision 0034 froze the split between policy authors, trusted carriers, trust gates, advisory-only sources, active state, and durable history.

That still leaves a dangerous gap:
- some source classes may legitimately **carry** useful helper material,
- some helpers may be perfectly safe to **invoke once**,
- but that does not mean the same source class may **author protected or always-on state**.

Current precedent makes this risk real:
- Git only respects some settings in protected configuration,
- VS Code distinguishes manually invoked prompt files from automatically applied instructions,
- VS Code custom agents can come from workspace, profile, organization, built-in, or extension sources,
- and Deno can hand all permission decisions to a broker that suppresses local flags and prompts.

## Decision
For future ViewFS design work, proposals must classify whether they are changing:
1. **protected-authorable state classes** — state that may only be authored from explicitly protected source classes,
2. **carrier/discovery presence** — what merely transported or exposed candidate material,
3. **invoke-only helper material** — one-shot/manual material that must not auto-apply,
4. **trust-gated adoption lanes** — explicit review/adoption paths where broader standing state may be written,
5. **effective active state** — what is currently live,
6. **durable receipts/history** — what only explains past invocation/adoption/outcome.

## Consequences
### Positive
- gives ViewFS a clean way to say “visible”, “invokeable”, and “authorable” are different;
- creates a first-class narrow success path (`invoke once`) instead of treating non-adoption as failure;
- prevents trusted carriers from silently becoming authors of protected or always-on state;
- keeps future broker/owner/org authority lanes visibly distinct from shell-local prompts.

### Costs
- one more matrix to inspect and explain;
- more vocabulary in shell UX and receipts;
- some state classes may need hard-deny source cells early.

## Non-goals
- freezing the final source-class × state-class matrix,
- deciding which lower-trust sources, if any, may later become adoptable for always-on state,
- freezing a final serialization for matrix cells or invocation receipts,
- deciding prompt chrome versus drawer placement.

## Near-term prototype
Build one source-aware shell flow with:
- protected chip,
- authorability matrix drawer,
- latched invoke button,
- broker badge,
- receipt card that preserves invoke-vs-adopt truth.

If that feels magical **and** honest, keep the seam. If it feels noisy, trim the UI before trimming the boundary.

