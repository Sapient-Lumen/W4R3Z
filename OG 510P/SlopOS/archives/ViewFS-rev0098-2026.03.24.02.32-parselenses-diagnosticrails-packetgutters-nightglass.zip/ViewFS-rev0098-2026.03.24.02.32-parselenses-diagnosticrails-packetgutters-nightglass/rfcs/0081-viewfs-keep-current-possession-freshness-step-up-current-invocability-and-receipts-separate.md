# RFC 0081: Keep current possession, freshness/step-up posture, current invocability, and receipts separate

Status: exploratory

## Why this exists

ViewFS already distinguishes:
- provider adverts from readiness,
- provider-ready from local-realized,
- claim tickets from holder-bound grants,
- and live handles from receipts.

The next easy collapse is more subtle:
people start treating **current possession** of a local object, holder-bound grant, or live handle as if that alone meant **usable right now**.

But several real systems keep showing the opposite:
- one handle or token can be present,
- yet stronger or fresher authentication may still be required,
- local presence or verification may still be required,
- one recency bound may still be unsatisfied,
- or one provider-local invocation gate may still withhold actual use.

That split is worth freezing now while SlopOS is still deciding deeper object-store, portal, and auth-mediation machinery.

## The separation

Keep these classes separate:
- **current possession** of a local object, local realization, claim, grant, or live handle;
- **freshness / recency posture** such as `older than allowed`, `fresh enough now`, or `unknown`;
- **step-up or stronger-auth requirement** such as `need stronger factor`, `need reauth`, or `need holder proof again`;
- **local presence / user verification posture** such as `touch needed`, `verify user`, `device auth needed`, or `not required`;
- **current invocability here now** meaning `the action may actually proceed in this pane/process/context now`;
- **spent / satisfied step-up traces** such as `freshly reauthed`, `presence satisfied for this attempt`, or `challenge failed`;
- **durable receipts/history** describing what happened before.

Do **not** flatten these into one vague story like `live handle`, `signed in`, `fresh`, or `authorized`.

## Historical lesson

Several useful systems already warn against this collapse:
- WebAuthn separates possession of one scoped credential from the current authentication ceremony, which includes a test of user presence or user verification.
- OAuth step-up authentication (RFC 9470) lets a protected resource say the authentication event associated with the current token is not strong enough or not recent enough, and it can challenge with `acr_values` and `max_age`.
- OpenID Connect keeps `max_age`, `auth_time`, and requested `acr` values explicit instead of pretending any existing login automatically satisfies current requirements.
- Android Keystore/biometric flows make the same point locally: a non-exportable key can exist on the device, yet actual use can still require current user authentication.
- Harbor's companion design work around proximity signals and timebound codes is a good nearby reminder that some routes are context-gated even when the token-ish artifact itself is real.

## ViewFS rule

ViewFS should preserve distinct lanes for:
1. possession / local realization,
2. freshness or recency posture,
3. stronger-auth / step-up posture,
4. local presence / user-verification posture,
5. current invocability here now,
6. spent/satisfied/failed challenge traces,
7. durable receipts/history,
8. any later publication/binding of resulting authority, which is still a separate question.

## Why this helps ViewFS

- It stops `held here now` from masquerading as `invokable here now`.
- It stops freshness or step-up challenges from disappearing into generic `permission denied` folklore.
- It gives the shell a truthful way to say `held`, `local`, `stale for this action`, `step-up needed`, `presence needed`, `freshly satisfied`, or `history only`.
- It keeps room for SlopOS to settle auth mediation, capability leases, proof carriers, and portal-local policies later without forcing ViewFS to pretend all live authority is instantly invokable.
- It makes challenge review, `why not now?` UX, and safe replay much easier without committing to one final auth or proof substrate.

## What this does not decide

This RFC intentionally does **not** decide:
- whether step-up proof is provider-local, shell-mediated, authagent-mediated, or another service lane;
- whether local presence/user verification is represented as badges, leases, lanes, or narrower transient receipts;
- whether a successfully satisfied challenge opens a reusable invocability window or only one immediate action;
- whether some invocability gates are purely local while others are provider-verified;
- whether ViewFS itself will ever standardize one assurance taxonomy across providers.

## Shell consequences

A future ViewFS shell should be able to show:
- `held now`,
- `local now`,
- `fresh enough`,
- `too old for this action`,
- `step-up needed`,
- `presence needed`,
- `verified for this action`,
- `challenge failed`,
- and `history only`

as visibly different truths.

It should also be able to render one honest ladder that says:
`inspect possession` → `see why not invokable` → `satisfy freshness or step-up` → `prove presence if needed` → `invoke now`
without implying that any earlier row already guaranteed the later powers.

## SlopOS alignment

This separation fits SlopOS well because SlopOS already pins imported OAuth/MCP step-up-authentication semantics as **provider-local reauthentication guidance and verifier context only**, and it separately refuses to let crypto-service interactive auth knobs silently become one portable generic unlock plane.
ViewFS can therefore standardize the *shape* of possession-versus-current-invocability truth now while leaving assurance vocabularies, proof carriers, provider trust, and local UX mechanics open longer.
