# RFC-0067: Keep gesture evidence, activation tokens, armed state, active control, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates request handles from sessions, route slips from prepared actions, and selected entities from current authority.
The next low-regret seam is **gesture evidence / activation baton / armed-or-enabled state / active control or foreground turn**.

A recent keypress, pointer serial, notification click, or shortcut trigger is not itself a durable capability.
A transferable activation token is not itself one chosen live handle or bind.
An armed or enabled session is not the same thing as active control.
Active control is not the same thing as durable authority or history.
And none of those are the same thing as a receipt.

If we collapse those classes too early, we make at least five mistakes:

1. **input evidence starts masquerading as authority**
   - one click, keypress, or shortcut trigger starts acting like the shell now owns standing power rather than one short-lived interaction fact.

2. **activation tokens start masquerading as current control**
   - one baton or pass-along token starts acting like the target pane/app already owns focus, control, or imported authority.

3. **armed state starts masquerading as active state**
   - a prepared capture / chooser / route / handoff lane starts acting as if bytes or control are already flowing.

4. **foreground or active control starts masquerading as durable grant**
   - a current interaction privilege or focus turn starts acting like a reopen ticket or standing capability.

5. **history starts masquerading as a fresh user gesture**
   - a prior click, notification, or approval receipt starts acting like a still-consumable baton for a new side effect.

## The seam

Keep these classes visibly distinct:

1. **gesture evidence / user-action witness**
   - one keypress, pointer/touch event, shortcut activation, notification click, or other fresh interaction fact.
   - may be represented as a serial, transient-activation state, shortcut event, or equivalent witness.
   - not by itself a durable capability.

2. **activation token / transferable baton**
   - one short-lived token that can be offered to another component or app so it may request activation or foreground transfer.
   - may be consumed, expire, or be refused.
   - not by itself active control.

3. **armed / enabled interaction state**
   - one request/session/capture lane that is prepared or enabled but not yet actively delivering control or input.
   - examples: an enabled capture session, a prepared chooser, a route waiting for a baton, an adoption rail waiting for user confirmation.
   - not the same thing as active use.

4. **active control / foreground turn**
   - one current state where control, focus, or captured input is actually flowing now.
   - may be compositor-owned or portal-owned.
   - not durable reopen authority.

5. **receipt / history**
   - evidence that one gesture happened, one baton was minted or passed, one lane was armed, or one active control turn began/ended.
   - not current freshness or current authority.

## Working posture

- ViewFS should treat fresh interaction evidence as short-lived and local in meaning unless an explicit baton/token seam says otherwise.
- ViewFS should keep transferable activation tokens visibly separate from live handles, binds, or durable refs.
- ViewFS should keep `armed` / `enabled` visibly separate from `active` / `foreground now`.
- ViewFS should treat current active control as a narrow interaction truth, not as durable authority.
- ViewFS should keep receipts/history useful for explanation and replay while refusing to treat them as fresh gesture proof.

## What to steal

- **HTML user activation**: sticky, transient, and activation-consuming states are a great reminder that recent user action is a timed/consumable class rather than standing authority.
- **Wayland serials and xdg-activation**: user-event serials and activation tokens are a strong precedent for passing interaction proof without pretending it is current focus already.
- **XDG InputCapture**: `enabled` and `active` are separate states, and the compositor decides when active capture actually begins.
- **Windows foreground transfer**: foreground privilege can be delegated narrowly and can expire on later input instead of becoming a standing ambient right.

## Shell consequences

The shell/terminal should gain:
- **activation baton chips** that show `fresh`, `consumable`, `expired`, `passed`, or `refused` instead of hiding interaction proof in invisible state;
- **arming rails** that show `prepared`, `waiting for baton`, `enabled`, `active`, `ended`, or `history only`;
- **foreground-transfer cards** so cross-pane/app handoff can say `you may ask to activate` without pretending activation already happened;
- **consume-once guards** so one click/keypress/shortcut cannot silently trigger several stronger side effects;
- **gesture truth badges** that distinguish `fresh user action`, `transferred token`, `armed only`, `active now`, and `receipt only`.

## Phase-1 non-decisions

This RFC does **not** decide:
- a universal activation-token format,
- whether ViewFS mints its own baton objects or only relays platform-native ones,
- whether all panes expose a common active/foreground model,
- whether every portal-driven action needs a baton in Phase 1,
- whether gesture receipts are persisted by default.

## Design bar

Before ViewFS standardizes stronger click/shortcut/focus-driven actions, it should be able to answer:

1. Is the shell looking at fresh gesture evidence, a transferable baton, an armed lane, active control, or only history?
2. Can one consumed baton fail honestly without pretending the underlying object or plan was wrong?
3. Can `enabled` / `armed` stay visibly distinct from `active` / `foreground now`?
4. Can past receipts explain why an action happened without silently replaying the required gesture proof?
5. Can the shell degrade honestly when activation or focus transfer is refused, expired, or compositor-blocked?
