# RFC-0073: Keep partial residency, chunk layouts, whole-object proofs, live range sessions, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates prefetch, cache warmth, hydration, mirroring, and offline bundles.
The next low-regret seam is **partial residency / chunk-layout knowledge / whole-object proof / live range session**.

Having some local bytes is not the same thing as having the whole object.
Knowing the chunk or shard layout is not the same thing as knowing which bytes are currently present locally.
A resumable or lazy-pullable representation is not the same thing as a complete, locally verified object.
A multipart identifier or per-part checksum story is not the same thing as a single whole-object proof.
A current range reader is not the same thing as durable local completeness.
And none of those are the same thing as a durable receipt.

If we collapse those classes too early, we make at least six mistakes:

1. **slice-local bytes start masquerading as full local truth**
   - a process sees some bytes or some files and assumes the object is fully present.

2. **layout metadata starts masquerading as byte coverage**
   - chunk grids, shard maps, TOCs, or range indexes get mistaken for actual residency.

3. **composite identifiers start masquerading as whole-object proofs**
   - multipart ETags or per-part checksums get treated like one exact whole-object digest.

4. **lazy execution starts masquerading as full hydration**
   - on-demand fetch becomes folklore for `already local`.

5. **live range sessions start masquerading as retained local state**
   - an active ability to stream missing bytes gets confused with offline completeness.

6. **receipts start masquerading as current byte coverage**
   - a past transcript row gets replayed as if today's local store still has the same sparse/full coverage.

## The seam

Keep these classes visibly distinct:

1. **partial residency / local coverage map**
   - which exact ranges, chunks, files, or shards are currently present locally.
   - useful for sparse access, previews, and resumable hydration.
   - not proof of full local completeness.

2. **chunk / shard / TOC layout knowledge**
   - metadata that says how a representation is partitioned or seeked.
   - useful for efficient range fetch and sparse scheduling.
   - not the same thing as current local byte presence.

3. **whole-object completeness verdict**
   - one statement such as `partial`, `prefix-only`, `all ranges present`, `all named chunks present`, or `unknown`.
   - useful for shell truth and offline/readiness decisions.
   - not itself an integrity proof.

4. **whole-object proof / validator**
   - one digest, exact checksum, or other whole-object witness that says the complete representation matches expectation.
   - useful for durable trust, dedupe, and replay-safe reasoning.
   - not the same thing as a composite per-part identifier.

5. **live range session / remote fill path**
   - one current ability to ask a provider, mirror, or lazy-pull helper for missing parts.
   - useful for sparse execution or preview.
   - not the same thing as durable offline completeness.

6. **receipt / history**
   - evidence that some coverage map, layout, completeness verdict, proof, or live range path existed at one time.
   - useful for explanation and audit.
   - not current local byte state.

## Working posture

- ViewFS should let providers expose sparse/range-local state without pretending that means the whole object is present.
- ViewFS should keep partition/layout metadata explicit because it is useful for scheduling and UX, but it should never stand in for byte coverage truth.
- ViewFS should let whole-object proof stay stronger than multipart/composite identifiers and stronger than mere `all chunks fetched` folklore.
- ViewFS should treat lazy-pull or remote-fill ability as a current service/session seam, not as proof of local completeness.
- ViewFS should keep receipts/history useful while refusing to let them silently revive current sparse/full residency truth.

## What to steal

- **HTTP range requests and recombination rules**: partial responses can be transferred and recombined only under tight validator conditions.
- **HTTP caching for incomplete responses**: caches may store incomplete responses, but they must not answer a complete request as if incomplete bytes were full truth.
- **eStargz / Stargz lazy pulling**: a representation can stay standard-compatible and lazily fetch only needed files or chunks at runtime.
- **Amazon S3 multipart uploads and checksums**: multipart ETags are not always whole-object MD5, and full-object checksums are a stronger separate lane.
- **Zarr chunk grids and codecs**: chunk partition metadata is valuable, but it is still metadata describing storage layout rather than local coverage or whole-object verification.

## Shell consequences

The shell/terminal should gain:
- **hole maps** that show `ranges 0-64K local`, `chunks 3-9 missing`, `prefix only`, `complete`, or `unknown`;
- **range panels** that keep `coverage`, `layout`, `remote fill`, `whole proof`, and `history only` in one honest drawer;
- **whole-proof ladders** that make `trust partial`, `fill missing`, `verify complete`, `seal local copy`, or `stay receipt only` different acts;
- **offline honesty lamps** that say `runnable by lazy fill`, `fully local`, `needs network for holes`, `proof missing`, or `history only`;
- **composite-checksum warnings** that explain when a current identifier is per-part/composite rather than a whole-object witness.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal sparse-coverage representation across all object families,
- whether ViewFS normalizes on byte ranges, file extents, chunks, shards, or several of them in different seams,
- whether a whole-object proof is always required before publication, launch, or offline export,
- whether live range fill is portal-owned, helper-owned, shell-owned, or provider-owned in Phase 1,
- whether partial residency can ever satisfy some workflows without any attempt to reach full completeness.

## Design bar

Before ViewFS standardizes richer sparse/lazy object flows, it should be able to answer:

1. Is this thing a local coverage map, layout hint, completeness verdict, whole-object proof, live range session, or only a receipt?
2. Can the shell tell the user whether an object is full-local, sparse-local, remote-fillable, or history only?
3. Can the system explain when a current identifier is composite/per-part rather than one exact whole-object witness?
4. Can lazy execution or preview stay useful without silently claiming full hydration or offline readiness?
5. Can receipts stay useful for explanation without silently reviving current coverage or remote-fill state?
