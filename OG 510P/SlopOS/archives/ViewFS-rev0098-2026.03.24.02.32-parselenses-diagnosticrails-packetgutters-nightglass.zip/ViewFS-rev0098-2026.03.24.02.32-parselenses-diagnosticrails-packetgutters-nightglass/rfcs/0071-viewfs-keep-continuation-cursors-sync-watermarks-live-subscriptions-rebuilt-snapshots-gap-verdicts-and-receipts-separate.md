# RFC-0071: Keep continuation cursors, sync watermarks, live subscriptions, rebuilt snapshots, gap verdicts, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates query manifests from materialized collections and watch registrations from authority.
The next low-regret seam is **continuation cursor / sync watermark / live subscription / rebuilt snapshot / gap verdict**.

A token that lets a client ask for the next page is not the same thing as a token that says “I have processed everything up to here.”
A sync watermark is not the same thing as a live subscription.
A live subscription is not the same thing as a rebuilt current snapshot.
A rebuilt snapshot is not the same thing as a gap or overflow verdict.
And none of those are the same thing as a durable receipt.

If we collapse those classes too early, we make at least six mistakes:

1. **pagination state starts masquerading as current truth**
   - a `continue` token or cursor gets treated as if it proves the visible list is current.

2. **watermarks start masquerading as subscriptions**
   - “processed through X” quietly turns into “still watching live now.”

3. **subscriptions start masquerading as snapshots**
   - one longpoll/watch/feed handle gets treated as if it already names a stable current set.

4. **gap states disappear into generic stale badges**
   - overflow, reset, retention-window loss, and provider recrawl all get flattened into one unhelpful failure.

5. **receipts start masquerading as resumable state**
   - an old transcript row or receipt gets mistaken for a still-valid cursor or current sync point.

6. **resume tokens start masquerading as authority**
   - a provider-specific cursor gets copied around as if it were a durable object ref, grant, or capability.

## The seam

Keep these classes visibly distinct:

1. **continuation cursor**
   - provider-issued state for fetching the next page or later delta batch.
   - may expire or reset.
   - useful for client efficiency.
   - not proof of current visible state.

2. **sync watermark / bookmark / last-seen point**
   - a statement like “processed through resource version X / event id Y / clock Z.”
   - useful for honesty, replay, compare, and resume attempts.
   - not itself a live subscription.

3. **live subscription / wait primitive**
   - one current longpoll, watch, stream, or follow registration.
   - may be idle, blocked, active, or ended.
   - not itself the current set of matching objects.

4. **rebuilt snapshot / relisted state**
   - the current visible set after explicit relist, requery, rebuild, or rescan.
   - may be current as of some watermark.
   - different from the subscription used to keep it fresh.

5. **gap verdict / degraded state**
   - overflow, reset, resource-version-too-old, recrawl, provider-reset, remote-risk, unsupported, or unknown gap.
   - tells the shell what kind of repair is needed.
   - not just one generic `stale` bit.

6. **receipt / history**
   - evidence that a cursor, watermark, subscription, rebuild, or gap verdict existed at one time.
   - useful for explanation and audit.
   - not current resume state.

## Working posture

- ViewFS should let providers hand back continuation cursors without pretending those tokens are canonical object refs.
- ViewFS should let shells surface last-processed watermarks without pretending they are current live subscriptions.
- ViewFS should let live subscriptions exist without pretending they are durable or replay-safe.
- ViewFS should let rebuilt snapshots be explicit, inspectable acts rather than invisible implementation folklore.
- ViewFS should keep gap and reset verdicts sharp enough to drive honest repair UX.
- ViewFS should keep receipts/history useful while refusing to let them silently revive current cursor/subscription state.

## What to steal

- **Kubernetes watch bookmarks / resourceVersion**: a bookmark can say what point a stream has caught up to without pretending to be one durable subscription or one current materialized set.
- **Dropbox folder cursors**: the same cursor family can support pagination and later delta polling, yet cursors can still expire and require relist/reset.
- **Watchman clock ids**: abstract clocks are better than wall-clock timestamps for change tracking, but they are still query-state tokens, not object authority.
- **Apple FSEvents event IDs and rescan flags**: incremental event feeds need explicit rescan/rebuild stories when drops, coalescing, root changes, or wrap/lag happen.

## Shell consequences

The shell/terminal should gain:
- **waterline cards** that show `listed through`, `caught up through`, or `needs relist from`;
- **gap badges** that say `overflow`, `cursor reset`, `resource version too old`, `recrawl`, `provider reset`, or `history only`;
- **resync ladders** like `continue`, `longpoll now`, `relist`, `rebuild from root`, `pin snapshot`, or `stay receipt only`;
- **dual-state query panes** that distinguish `current frozen snapshot` from `live follow from watermark`;
- **copy ladders** that separate `copy visible rows`, `copy watermark`, `copy cursor receipt`, and `copy query manifest`.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal cursor or watermark schema for all providers,
- whether ViewFS normalizes provider-specific reset/error taxonomy into one final enum,
- whether rebuilt snapshots are materialized objects, side indexes, or shell-owned caches,
- whether live subscriptions are shell-owned, provider-owned, or terminal-owned on every platform,
- whether any cursor/watermark is durable across device, profile, or account boundaries.

## Design bar

Before ViewFS standardizes richer sync/follow/query UX, it should be able to answer:

1. Is this thing a continuation cursor, a sync watermark, a live subscription, a rebuilt snapshot, a gap verdict, or only a receipt?
2. Can the shell tell the user whether the visible state came from incremental continuation or explicit rebuild?
3. Can the system explain exactly why a resume attempt failed: expiry, retention-window loss, root change, provider reset, or unsupported?
4. Can receipts stay useful for explanation without silently reviving current provider state?
5. Can copied tokens stay visibly non-authoritative so they do not become accidental designators or covert grants?
