# RFC-0019: Keep query manifests, result snapshots, live feeds, and smart-folder surfaces on separate seams

## Status
Proposed.

## Problem
ViewFS already distinguishes handles, refs, receipts, session state, registries, trust gates, previews, watch feeds, links, origin/quarantine, delete/recovery, time-travel, and write-coordination semantics.

Another easy collapse is to treat every “smart folder” or saved search as if it were one thing:
- the saved query definition,
- the most recent result set,
- the standing live-update subscription,
- the UI folder/sidebar pin,
- and the authority to open whatever currently matches.

History says those are not the same question.

## Proposal
For Phase 1 and nearby spikes, ViewFS should keep at least these classes distinct:
- **query manifest**,
- **result snapshot**,
- **live feed / subscription**,
- **smart-folder / selector surface**,
- **match receipt / journal artifact**.

Any proposal that collapses them should pay a high burden of proof.

## Consequences
- SlopOS `attrfs` alignment gets sharper instead of blurrier
- saved queries can remain shell-owned and transcript-visible
- users can freeze/thaw/diff results honestly without conflating them with current authority
- indexing policy, extraction policy, and live-feed health can remain inspectable
- smart-folder UX can still be excellent while preserving capability discipline

## Non-goals
This RFC does not choose:
- a final QueryManifest schema,
- a final live-feed protocol,
- a final result-snapshot serialization format,
- a final match-lens explanation schema,
- or a final indexing engine.

## Adoption test
A future ViewFS proposal should answer:
- Is this thing a **query manifest**, a **result snapshot**, a **live feed**, a **smart-folder surface**, or a **match receipt**?
- Can the shell tell the user whether the current view is frozen, live, stale, or index-degraded?
- Does any saved-query or result object accidentally become bearer authority?
- If live updates exist, can the user pause/freeze them while inspecting results?
- If a query depends on extracted metadata or host indexing, is that debt visible?

If the answer is “it’s just a smart folder,” the burden of proof should be high.
