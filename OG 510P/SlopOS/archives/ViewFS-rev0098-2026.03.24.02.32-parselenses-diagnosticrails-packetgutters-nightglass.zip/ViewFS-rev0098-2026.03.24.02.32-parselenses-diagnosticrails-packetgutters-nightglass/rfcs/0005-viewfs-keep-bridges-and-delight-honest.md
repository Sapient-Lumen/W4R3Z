# RFC-0005: Keep bridges and delight honest

Status: Draft
Updated: 2026-03-21

## Summary
ViewFS should aggressively pursue great shell/terminal UX and practical bring-up tactics **without** letting either of those silently redefine the core model.

This RFC proposes three design-phase rules:
1. host bridges/backstops stay visibly subordinate to handles/views/portals/receipts,
2. grant classes stay explicit even if protocol bytes remain open,
3. shell delight must improve authority visibility rather than hide it.

## Why this RFC exists
ViewFS and SlopOS are both still design-phase. That makes two mistakes especially tempting:
- using host implementation tactics (ambient path opens, rooted walkers, sandbox layers) and then slowly treating them as the real model,
- shipping delightful shell features that accidentally become a covert ambient-authority surface.

This RFC is meant to keep those mistakes reviewable.

## Proposal

### P1. Host bridge tactics are allowed, but must emit debt
Examples:
- preopen-style compat adapters
- rooted host path walkers
- explicit ambient-authority escape hatches
- host sandbox backstops

Policy:
- these may be used during bring-up and compat work,
- they must remain transcript-visible or otherwise inspectable,
- they do not become the user-facing explanation of why access was allowed.

### P2. Receipt classes remain distinct
At minimum, ViewFS should continue to distinguish:
- open/import
- transfer
- save/export
- durable reopen
- bound workspace/view environment

Policy:
- future protocol proposals may rename or refine these,
- but they should not collapse into one vague “file access” receipt.

### P3. Delight features must expose authority, not smuggle it
Examples of allowed ambition:
- object palette
- authority diff preview
- receipt tray
- explain-access inspector
- route sheet for object/URI actions
- safe replay with stripped authority

Policy:
- these features should make authority easier to reason about,
- not create hidden durable grants, generic helper execution, or silent fallback behavior.

## Acceptance bar for future exceptions
A future proposal that weakens one of these rules must provide:
1. a concrete user or interoperability problem,
2. a threat/recovery story,
3. transcript-visible semantics,
4. and one narrow prototype showing that the exception really buys something.

## Immediate consequences
- host fallback during bring-up should produce explicit debt markers/receipts,
- route sheets should preserve file/document versus URI seams,
- durable reopen should remain explicit and inspectable,
- shell notebooks/workflows should reference receipts/views rather than smuggling hidden authority.

## Non-goals
- this RFC does not choose the final shell syntax,
- this RFC does not choose the final receipt schema,
- this RFC does not require Linux-specific backstops,
- this RFC does not ban future tighter coupling when evidence justifies it.
