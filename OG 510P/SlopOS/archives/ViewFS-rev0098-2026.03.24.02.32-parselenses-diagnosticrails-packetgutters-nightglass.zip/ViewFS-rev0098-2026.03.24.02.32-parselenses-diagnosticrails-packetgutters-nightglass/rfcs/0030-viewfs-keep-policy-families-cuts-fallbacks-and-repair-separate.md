# RFC-0030 — Keep policy families, cuts, fallbacks, and repair proposals separate

## Status
Accepted (archive guardrail)

## Why
The ViewFS shell is now ambitious enough that we need one more anti-collapse seam.
While SlopOS and ViewFS are both still in design, we should freeze as little concrete schema as possible — but we should freeze one principle now:

**policy family/catalog choice, exact authoritative cut/consistency choice, fallback candidates, repair proposals, and durable selection receipts are different classes.**

If they collapse, the shell will eventually lie.
A repair hint will become a silent policy-family switch, history will become an accidental selector, and “latest safe fallback” will quietly turn into ambient policy negotiation.

## Decision
ViewFS must preserve a visible distinction between at least these classes:
1. **Policy family/catalog choice** — which family/domain of rules is in play conceptually
2. **Exact authoritative cut** — the exact selected revision/digest/consistency posture used for one evaluation
3. **Fallback candidate** — an alternate family/cut that could be used, but is not active yet
4. **Repair proposal** — non-authoritative guidance for recovering from invalid, stale, missing, or mismatched policy state
5. **Selection receipt/history** — durable, bounded history of which family/cut was used or declined previously

## Consequences
### Good
- the shell can suggest safer alternates and recovery flows without silently changing judges;
- policy-family experiments can proceed without freezing one negotiation protocol too early;
- replay/reopen/history stay useful without becoming hidden selectors;
- SlopOS alignment improves because this mirrors explicit policy-selection and exact-basis discipline.

### Costs
- more object classes to explain in docs and shell UI;
- more explicit metadata in prompt chrome, cards, and receipts;
- more temptation to over-design a policy-family catalog before real evidence exists.

## Non-goals
This RFC does not choose:
- a final policy language,
- a final policy-family catalog schema,
- a final negotiation or migration protocol,
- a final consistency-token schema,
- or a final shell protocol for cut pickers, fallback rails, or repair prompts.

It only freezes the boundary.

## Required design rule for future changes
Any future proposal that touches policy-aware import/run/replay/rebind UX must classify whether it changes:
- policy family/catalog choice,
- exact authoritative cut / consistency posture,
- fallback candidates,
- repair proposals,
- selection receipts/history,
- or some explicit combination of the above.

If a proposal cannot say which class it changes, it is probably collapsing seams by accident.
