# RFC-0076: Keep explicit-handle opens, rooted compat pathwalks, ambient escapes, and receipts separate

## Status
Proposed.

## Problem
ViewFS already separates object identity, live handles, published names, and synthetic views.
A new collapse risk sits one layer lower in the everyday `open` story:
- an actor already holds a live handle and opens through that explicit authority,
- an actor walks a path inside an already-held root/view through a narrow compat membrane,
- a mediator or portal is asked to mint or project access,
- or a host-global ambient escape hatch is used.

Those are not interchangeable classes.
If ViewFS flattens them into one generic `open(path)` story, it will silently re-import ambient folklore and make the shell lie about where authority came from.

## Proposal
For Phase 1 and nearby spikes, ViewFS should preserve a hard distinction between:

1. **Explicit-handle open / current authority**
   - the actor already holds a live handle or routed designation with current rights
   - and opens/acts through that authority directly

2. **Rooted compat pathwalk**
   - a path walk performed only inside an already-held root/view/designator
   - with explicit no-escape posture, explicit symlink/magic-link policy, and loud debt labeling

3. **Portal / mediated import or reveal**
   - a chooser, request, powerbox, or other mediator-owned lane that may return a selection, grant, synthetic projection, or local materialization result

4. **Ambient escape hatch**
   - a host-global path or environment lookup outside the held root/view authority story
   - used only as explicit bring-up debt or policy-gated fallback

5. **Receipt / history**
   - durable explanation of which lane was used, what narrowing or mediation occurred, and whether any ambient debt was incurred

Published names remain a separate seam from RFC-0075: one current local bind is not the same thing as any of the above.

## Consequences
- ViewFS can tolerate rooted compatibility helpers without pretending they are the same as capability-native direct opens.
- Portal-mediated imports remain honest about user mediation and synthetic projection instead of vanishing behind fake local path certainty.
- Ambient debt becomes inspectable and searchable instead of hiding in shell folklore.
- Shell/product work can teach users a truthful `safe-open ladder` rather than one fake universal open gesture.

## Non-goals
This RFC does not choose:
- one final rooted pathwalk API,
- one final portal/import protocol,
- one final object-store schema,
- one final symlink or alias policy for compat walkers,
- or one final ambient-debt elimination schedule.

## Adoption test
A future ViewFS proposal should answer:
- Did the actor already hold **explicit current authority**, or did the system perform a **rooted compat walk**?
- Was authority minted or projected by a **portal/mediator**, or did the system use an **ambient host escape**?
- If a path string is shown, does it describe a compat/locality surface rather than pretend to be the essence of authority?
- Is there a **receipt** that says which lane actually happened?

If the answer becomes `it all feels like open(path) for convenience`, the burden of proof should be high.
