# RFC-0074: Keep delta recipes, exact bases, apply sessions, reconstructed objects, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates partial local coverage from whole-object proof and separates observed base state from committed winners.
The next low-regret seam is **delta recipe / exact basis / apply session / reconstructed object**.

A patch or delta package is not the same thing as the object it can help reconstruct.
A remembered base id is not the same thing as proof that the base bytes are present locally right now.
A current apply session is not the same thing as a newly materialized durable object.
A delta that worked once is not the same thing as a general transform that can be replayed safely forever.
And none of those are the same thing as a durable receipt.

If we collapse those classes too early, we make at least six mistakes:

1. **delta packages start masquerading as whole objects**
   - a process sees `patch available` and assumes the target object already exists locally.

2. **basis names start masquerading as current local basis truth**
   - an old `from X to Y` hint gets replayed as if base `X` is still present, still exact, and still approved.

3. **apply sessions start masquerading as committed durable state**
   - a scratch reconstruction or temporary merge result gets confused with the final durable object identity.

4. **reconstructed objects start masquerading as authority continuity**
   - the fact that bytes can be rebuilt gets mistaken for possession of the same live handle, same namespace bind, or same reopen story as before.

5. **transport efficiency starts masquerading as semantic sameness**
   - rsync-style, bsdiff-style, or VCDIFF-style savings get treated as proof that the reconstructed result is semantically interchangeable with every related object lane.

6. **receipts start masquerading as current reconstructability**
   - a past `applied delta successfully` row gets replayed as if the needed base and recipe are still present and still policy-admissible today.

## The seam

Keep these classes visibly distinct:

1. **delta recipe / transform artifact**
   - one patch, delta stream, or transform description.
   - useful for transport efficiency and reconstruction.
   - not itself the whole target object.

2. **exact basis requirement**
   - one statement of which exact prior object, validator, or window is required.
   - useful for honesty and safe reconstruction.
   - not proof that the basis is present locally now.

3. **apply / reconstruction session**
   - one current act that combines basis material plus a delta recipe.
   - useful for materializing bytes in scratch space or into a new object.
   - not itself the durable target object identity.

4. **reconstructed object / target result**
   - one newly reconstituted byte object or tree result.
   - useful for publish, launch, compare, or later import.
   - not the same thing as the delta recipe that helped create it.

5. **fallback / full-fetch lane**
   - one current way to abandon delta reconstruction and retrieve the whole target object directly.
   - useful when basis is missing, validators mismatch, or policy refuses apply.
   - not the same thing as the delta recipe or as current local completeness.

6. **receipt / history**
   - evidence that a delta, basis, apply session, reconstruction, or fallback act existed at one time.
   - useful for explanation and audit.
   - not current reconstructability truth.

## Working posture

- ViewFS should allow efficient update/import lanes that depend on explicit transform artifacts without pretending the transform is the object.
- ViewFS should keep basis requirements explicit and inspectable because `from X` is a stronger statement than `roughly compatible with something old`.
- ViewFS should let reconstruction happen in scratch or staging space without silently laundering scratch results into committed durable identity.
- ViewFS should keep `reconstructed target object` stronger than `delta recipe present` and stronger than `receipt says it worked before`.
- ViewFS should keep direct full-fetch / full-import fallback explicit because failed or untrusted delta application is not the same thing as missing object identity.

## What to steal

- **HTTP If-Range and delta encoding**: clients can ask for partial or delta help against an exact validator/basis, but mismatch falls back to the whole current representation rather than pretending the old basis still applies.
- **VCDIFF target windows**: delta streams are expressed in terms of source data segments or earlier target data, making the basis/result distinction explicit.
- **OSTree static deltas**: one delta can target an exact pair of commit objects, and `from NULL` is a different lane that behaves more like reconstruction from scratch.
- **zsync / rsync-style matching**: a client can reuse existing local bytes to avoid re-downloading unchanged material, but that is still a reconstruction act based on exact block/basis knowledge rather than magical object continuity.

## Shell consequences

The shell/terminal should gain:
- **basis cards** that show `needs base X`, `base local`, `base missing`, `base mismatched`, or `history only`;
- **delta peels** that keep `recipe`, `basis`, `apply now`, `full fetch`, `reconstructed result`, and `receipt` in one honest drawer;
- **apply ladders** that make `apply in scratch`, `verify reconstructed`, `materialize new object`, `fetch full target instead`, or `stay receipt only` different acts;
- **fallback lamps** that say `delta-ready`, `basis missing`, `full fetch required`, `policy blocked`, or `history only`;
- **result-lineage badges** that explain `rebuilt from X + recipe R` without pretending that is the same thing as live-handle continuity or same-path folklore.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal delta format for ViewFS,
- whether ViewFS ever standardizes delta recipes as first-class portable objects rather than provider-local helpers,
- whether apply sessions are shell-owned, provider-owned, helper-owned, or runtime-owned in Phase 1,
- whether reconstructed targets always get fresh object identity or may sometimes alias existing immutable content underneath,
- whether any delta lane is mandatory for import, sync, publish, or offline bundle workflows.

## Design bar

Before ViewFS standardizes richer delta/reconstruction flows, it should be able to answer:

1. Is this thing a delta recipe, an exact basis requirement, an apply session, a reconstructed target object, a full-fetch fallback lane, or only a receipt?
2. Can the shell tell the user whether the required basis is present, exact, mismatched, or unknown?
3. Can reconstruction happen in scratch space without silently claiming durable commit or live-handle continuity?
4. Can the system explain when it fell back to full retrieval instead of delta apply?
5. Can receipts stay useful for explanation without silently reviving current reconstructability truth?
