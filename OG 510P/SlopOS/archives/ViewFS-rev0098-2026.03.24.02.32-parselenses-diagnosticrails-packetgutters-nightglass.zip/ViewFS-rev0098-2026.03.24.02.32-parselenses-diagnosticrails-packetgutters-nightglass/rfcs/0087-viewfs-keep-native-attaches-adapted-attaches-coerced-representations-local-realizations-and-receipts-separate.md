# RFC-0087: Keep native attaches, adapted attaches, coerced representations, local realizations, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates foreign-backed borrow from projected locality and true local realization.
The next low-regret seam is **native attach / adapted attach / coerced representation / local realization / durable receipt**.

A thing can be usable here now without being usable here **natively**.
A thing can be made attachable through one adapter or relay without that adapter becoming the core object model.
A thing can be viewable as one alternate typed representation without that representation being the same object semantics.
And none of those are the same thing as a local realization or a durable receipt.

If we collapse those classes too early, we make at least five mistakes:

1. **adapter-backed usability starts masquerading as native fit**
   - one wrapper, relay, or runtime shim quietly becomes `the way this object really is`.

2. **coerced representations start masquerading as same-object access**
   - a preview stream, rendered export, or typed coercion quietly becomes `opened the object itself`.

3. **projected names start masquerading as attach fidelity**
   - because a thing appears under one local path/view, the shell stops saying whether the receiver is talking to the native thing, one adapter, or one translated surface.

4. **local realization starts masquerading as the only repair path**
   - every lane mismatch turns into an automatic copy/materialize step instead of an explicit choice.

5. **history starts masquerading as current attachability**
   - an old success via one adapter or alternate representation starts acting like the same lane still exists now.

## The seam

Keep these classes visibly distinct:

1. **native attach**
   - the receiver has a directly usable handle/view/object surface for the current pane/process/lane.
   - examples: a current handle the lane understands directly, a directly attachable directory/service/object surface, one current same-object attachment.

2. **adapted attach**
   - the receiver is using a wrapper, relay, compatibility shim, or runtime adapter.
   - examples: fd-style wrapper over a non-fd-native handle, relay-mounted subtree, compatibility service proxy, shell/runtime adapter for one foreign resource.
   - useful and often correct, but still not the same thing as native attach.

3. **coerced representation**
   - the receiver only has one alternate representation, render, or typed stream.
   - examples: virtual document coerced to `image/png`, preview-only bytes, export-only MIME surface, translated representation chosen by the sink.
   - this may be enough for viewing/preview/import, but it is not the same thing as same-object attach.

4. **local realization**
   - the receiver explicitly chooses to make stronger local state here.
   - examples: make-local copy, materialized replica, object-store member, explicit local conversion result.
   - still not automatically the same thing as native same-object attach.

5. **receipt / history**
   - durable evidence that one native attach, adapted attach, coercion, or realization happened before.
   - not current fit, not current lane support, and not current authority by itself.

## Working posture

- ViewFS should allow `usable here through adapter` without implying `natively attachable here`.
- ViewFS should allow `representation available` without implying `same object opened`.
- ViewFS should allow `make local` as an explicit fidelity/locality transition instead of one silent fallback.
- ViewFS should keep receipts/history explanation-rich while refusing to let them silently revive current attach mode.

## What to steal

- **Android SAF virtual files** (REF-ANDROID-VIRTUALFILES, REF-ANDROID-SAF): a provider can expose something the app may browse and select even when the client cannot directly `openInputStream()` it; the client may need to request an alternate MIME type instead.
- **WIT resources / handles** (REF-WIT-RESOURCE-HANDLES): resources are handles to entities outside the component, and passing them by owned or borrowed handle is different from copying plain data.
- **XDG Documents portal** (REF-XDG-DOCUMENTS, REF-XDG-DOCS-FUSE): a mediator can project a controlled FUSE view without claiming that the receiver now has ambient native host-path truth.
- **Fuchsia namespaces** (REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-COMPONENT-NSENTRY): per-component namespace assembly and explicit path→directory attachments reinforce that attachability is receiver-local and non-global.
- **Foundry / Harbor sibling cubes**: both are already pressuring the ecosystem toward stronger honesty about foreign-backed utility, materialization, consequence envelopes, and smaller-than-adoption aftermath objects.

## Shell consequences

The shell/terminal should gain:
- **attach-mode badges** that render `native`, `adapted`, `relay`, `coerced`, `localized`, or `history only` as different truths;
- **adapter veils** so a row can say exactly what glue is in the path;
- **virtuality lamps** when the strongest available lane is one alternate representation rather than same-object attach;
- **same-object versus translated drawers** so the user can inspect whether they are touching the thing itself or one derived surface;
- **make-local-for-native ladders** when stronger local/native semantics are desired.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal wrapper/relay ABI,
- one universal typed-representation taxonomy,
- whether every adapted attach is process-local, machine-local, or cross-machine,
- whether local realization always preserves same-object identity semantics,
- whether native attach is ever mandatory for Phase 1 workflows.

## Design bar

Before ViewFS standardizes richer attach/import UX, it should be able to answer:

1. Is the shell talking about native attach, adapted attach, coerced representation, local realization, or only history?
2. Can the shell explain why a lane is adapter-backed instead of natively attachable?
3. Can the shell explain when one representation is only preview/import/render truth rather than same-object truth?
4. Can `make local` remain an explicit step instead of a hidden repair?
5. Can old attach/coercion receipts stay useful without silently reviving current fit?
