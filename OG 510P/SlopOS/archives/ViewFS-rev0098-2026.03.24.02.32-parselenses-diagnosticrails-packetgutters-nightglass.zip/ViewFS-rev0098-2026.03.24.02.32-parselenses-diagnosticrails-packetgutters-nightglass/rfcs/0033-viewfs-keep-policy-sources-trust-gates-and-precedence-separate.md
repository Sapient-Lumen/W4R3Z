# RFC-0033: Keep policy sources, trust gates, and precedence separate

Status: Draft
Owner: archive
Created: 2026-03-22

## Summary
ViewFS should keep **owner/org policy sources**, **trust-state gates**, **user/profile preferences**, **workspace/imported proposal sources**, **effective active state**, and **durable receipts/history** on distinct seams.

## Why
Revision 032 made deny ceilings and scope eligibility explicit.
The next likely failure mode is subtler: once the shell knows about multiple sources and multiple trust states, it becomes tempting to treat “present somewhere” as “effective now.”

This RFC says that must remain impossible by construction.

## Required split
Future proposals must classify whether they are changing:
1. authoritative owner/org policy sources or ceilings,
2. trust-state gating,
3. user/profile preference layers,
4. workspace/imported/helper proposal material,
5. effective active state,
6. or only durable history/receipts.

## Consequences
- owner/org ceilings stay visibly distinct from user/profile preference layers;
- trust gating stays distinct from source origin;
- imported/discovered helper material stays proposal-like until explicitly reviewed;
- effective-state inspection preserves both the winner and the losers;
- receipts preserve source-stack and trust-gate reasoning without becoming live sources.

## Non-goals
This RFC does **not** freeze:
- a final source taxonomy,
- a final precedence lattice,
- a final trust-gate state machine,
- a final serialized import-tray schema,
- or a final activation-receipt schema.

## Near-term prototype
Prototype one flow only:
- origin stack badge,
- trust shutter,
- import quarantine tray,
- override ledger,
- effective winner chip,
- durable activation receipt.
