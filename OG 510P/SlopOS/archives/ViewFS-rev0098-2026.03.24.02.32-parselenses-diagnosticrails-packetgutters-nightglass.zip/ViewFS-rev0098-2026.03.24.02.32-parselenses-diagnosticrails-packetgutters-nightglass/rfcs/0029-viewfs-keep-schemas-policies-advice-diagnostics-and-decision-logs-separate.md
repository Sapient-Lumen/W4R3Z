# RFC-0029 — Keep schemas, policies, advice rails, diagnostics, and decision logs separate

## Status
Accepted (archive guardrail)

## Why
The ViewFS shell is getting ambitious enough that we need to defend one more anti-collapse seam.
While SlopOS and ViewFS are both still in design, we should freeze as little concrete schema as possible — but we should freeze one principle now:

**schema/validation material, authoritative policy/caveat material, shell advice/ranking heuristics, per-decision diagnostics, and durable logs/receipts are different classes.**

If they collapse, the shell will eventually lie.
Helpful suggestions will turn into de facto policy, debug traces will start behaving like permissions, and “why” surfaces will become accidental bearer channels.

## Decision
ViewFS must preserve a visible distinction between at least these classes:
1. **Policy schema / validation material** — structural checks and type expectations for policy/request families
2. **Authoritative policy set** — the exact rule/caveat/guardrail material used for a decision
3. **Advice rail** — shell-local hints, ranking, defaults, repair suggestions, or narrowed alternates that do not count as authorization
4. **Decision diagnostics** — per-evaluation explanatory material such as determining rules, vetoes, errors, drift, or missing witnesses
5. **Decision logs / receipts** — durable, bounded, redacted history/debug artifacts that never imply current authority by themselves

## Consequences
### Good
- the shell can become much smarter without becoming semantically dishonest;
- policy-language choice stays open longer;
- debugging and audit surfaces can grow without becoming replay loopholes;
- SlopOS alignment improves because this mirrors approval-basis and explain-posture discipline.

### Costs
- more object classes to explain in docs and shell UI;
- more explicit metadata in transcripts and overlays;
- more temptation to over-design schemas before they are needed.

## Non-goals
This RFC does not choose:
- a final policy language,
- a final schema-validation mechanism,
- a final diagnostics schema,
- a final decision-log export format,
- or a final shell protocol for policy/advice overlays.

It only freezes the boundary.

## Required design rule for future changes
Any future proposal that touches policy-aware import/run/replay/rebind UX must classify whether it changes:
- validation/schema material,
- authoritative policy material,
- shell advice rails,
- decision diagnostics,
- decision logs/receipts,
- or some explicit combination of the above.

If a proposal cannot say which class it changes, it is probably collapsing seams by accident.
