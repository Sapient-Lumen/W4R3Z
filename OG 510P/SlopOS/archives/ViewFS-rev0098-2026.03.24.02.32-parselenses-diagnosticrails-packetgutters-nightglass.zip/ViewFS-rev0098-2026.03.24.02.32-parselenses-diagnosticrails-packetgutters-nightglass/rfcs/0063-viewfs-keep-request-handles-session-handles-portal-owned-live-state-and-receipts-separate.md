# RFC-0063: Keep request handles, session handles, portal-owned live state, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates designation from authority, liveness from permission outlook, and claims from local admission.
The next low-regret seam is **portal request identity / long-lived portal state / current live authority**.

A request handle for one interaction is not the same thing as one long-lived session handle.
Neither is the same thing as one portal-owned current state such as `background allowed`, `shortcut bound`, `monitor running`, or `transfer still open`.
And none of those are the same thing as one live handle or bind already installed in this pane.

If we collapse those classes too early, we make at least four mistakes:

1. **request identity starts masquerading as live state**
   - one request token or request row gets treated as proof that the portal still holds the same state now.

2. **session identity starts masquerading as current authority**
   - a long-lived session or transfer object gets treated as if this pane already holds the exact current bind or live handle that session may permit.

3. **portal-owned state starts masquerading as local possession**
   - a portal-side `active`, `bound`, `allowed`, or `running` status gets mistaken for proof that the current process has already adopted the resulting authority locally.

4. **history starts masquerading as current truth**
   - an old request/response receipt gets treated as proof that the same session, transfer, or bound capability is still active now.

## The seam

Keep these classes visibly distinct:

1. **request handle / request identity**
   - one interaction in flight or one completed interaction record.
   - may support `pending`, `cancelled`, `succeeded`, `dismissed`, or `errored` states.
   - not by itself one long-lived session or live bind.

2. **session handle / transfer key / portal-owned durable interaction object**
   - one longer-lived portal object or transfer lane created by a successful request.
   - may stay alive beyond the initial dialog.
   - still not by itself one adopted local bind or live pane authority.

3. **portal-owned live state**
   - one current state inside the mediator such as `session open`, `transfer open`, `background allowed`, `shortcut active`, `monitor ending`, or `closed by portal`.
   - a portal-local truth, not a transcript receipt and not current local possession by itself.

4. **local adopted bind / live handle now**
   - one currently held capability, bind, or namespace insertion installed in this process or pane.
   - this is still the current-authority truth.

5. **receipt / history**
   - evidence that one request completed, one session was created, one transfer closed, one binding was listed, or one state change happened once.
   - not current authority.

## Working posture

- ViewFS should keep request rows visible without implying that a long-lived session or grant still exists.
- ViewFS should keep session handles, transfer keys, and portal-owned current state inspectable without implying that the current pane already adopted the result.
- ViewFS should keep local adopted binds and live handles as the current-authority truth.
- ViewFS should keep history rows descriptive rather than reviving old request/session success by inspection.

## What to steal

- **XDG Request**: a request object exists for the duration of the interaction and resolves by response, rather than pretending one portal call is synchronous magic.
- **XDG Session**: long-lived sessions have their own handle, lifecycle, and close signal distinct from request completion.
- **XDG Inhibit / ScreenCast / GlobalShortcuts**: one request may create or modify one session, while later events and state changes are reported on the session seam rather than by replaying the request.
- **XDG FileTransfer**: transfer start, add, retrieve, autostop, and close stay separate enough to model a real courier lane instead of a fake path handoff.
- **Android SAF**: persistence may survive restart, but moved/deleted targets still fail later and require fresh user mediation.

## Phase-1 non-decisions

This RFC does **not** decide:
- whether ViewFS exposes any generic `list portal state` API in Phase 1,
- whether portal-owned live state is watcher-driven, query-driven, or both,
- whether every request/session family shares one universal lifecycle enum,
- whether transfer keys and session handles share any common encoding,
- whether portal-owned state is shell-only chrome, queryable by apps, or partly both.

## Shell consequences

The shell/terminal should gain:
- **request ledgers** that can show `pending`, `succeeded`, `cancelled`, `dismissed`, `timed out`, or `errored` without implying durable state;
- **session cards** that can show `open`, `configured`, `active`, `paused`, `ending`, `closed`, or `closed by portal` as portal-owned current state;
- **adoption shutters** that can show whether the current pane adopted the result locally, or only observed a request/session outcome;
- **repair rails** that can distinguish `retry request`, `reopen session`, `adopt again`, `list current state`, and `history only`;
- transcript rows that can distinguish `request only`, `session only`, `portal active`, `adopted here`, and `receipt only`.

## Design bar

Before ViewFS standardizes any stronger portal/session model, it should be able to answer:

1. Is the shell showing a request row, a session/transfer object, portal-owned current state, one local live bind, or only history?
2. Can the user tell whether the portal still considers the session/transfer open without assuming the current pane already adopted the result?
3. Can one old request success remain useful for explanation without silently counting as current state or current authority?
4. Can the shell tell users whether repair means `reissue request`, `rejoin session`, `retrieve again`, `adopt locally`, or `ask again`?
