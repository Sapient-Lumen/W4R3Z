# RFC-0084: Keep foreign-backed borrows, compat attaches, projected imports, local realizations, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates provider-ready from local-realized truth and already separates live lends from representation exports.
The next low-regret seam is **foreign-backed borrow / receiver-local compat attach / projected import / local realization / durable receipt**.

A thing that is usable through another provider or mediator is not automatically local here.
A thing that is attachable through one wrapper or relay is not automatically a local object-store member.
A thing that appears under one projected namespace entry is not automatically a fully localized object.
And none of those are the same thing as a receipt.

If we collapse those classes too early, we make at least five mistakes:

1. **provider-backed usability starts masquerading as local ownership**
   - the shell quietly treats `I can open this through that provider` as `this object already lives here now`.

2. **receiver-local wrappers start masquerading as core semantics**
   - one shim, proxy, fd-wrapper, or relay lane becomes the definition of what the object *is*.

3. **projected imports start masquerading as localization**
   - a portal or provider-published synthetic name looks like a permanent local object-store fact.

4. **materialized caches start masquerading as owned local objects**
   - a dataless/materialized replica or temporary import copy quietly becomes a claim about durable local ownership.

5. **history starts masquerading as present adoptability**
   - an old import, attach, or materialize receipt starts acting like the same lane is still possible now.

## The seam

Keep these classes visibly distinct:

1. **foreign-backed borrow**
   - current usability still depends on another provider, broker, portal, or service.
   - examples: provider-owned content URI, security-scoped URL, remote file-provider item, portal-backed document entry.
   - may be durable enough to revisit later, but it is still exterior-backed truth.

2. **compat attach / relay attach**
   - the receiver has made the foreign-backed thing usable in this pane/process/lane through a wrapper, relay, mount point, or runtime adapter.
   - examples: fd-style wrapper around a directory handle, relay-mounted subtree, borrowed service-backed namespace entry, runtime adapter for a foreign cell.
   - this is a current local usability act, not a local object-store claim.

3. **projected import**
   - a mediator/provider publishes a scoped local view/name for the receiver without claiming full localization.
   - examples: document-portal path, synthetic view entry, scoped projected document, projected directory subtree.
   - useful and inspectable, but still not the same thing as local realization.

4. **local realization**
   - the receiver has explicitly made bytes/object state local here.
   - examples: imported copy, localized object-store member, materialized local replica, explicit `make here` result.
   - still not automatically the same thing as current live-handle possession or durable reopen truth.

5. **receipt / history**
   - durable evidence that a borrow, attach, projection, or localization happened before.
   - not current provider reachability, not current attach posture, and not current locality.

## Working posture

- ViewFS should allow `borrowed here` without implying `owned here`.
- ViewFS should allow `attached through wrapper` without implying `this wrapper is the core object model`.
- ViewFS should allow `projected into my namespace` without implying `fully localized in my store`.
- ViewFS should allow `localized now` without implying `the original foreign backing no longer matters`.
- ViewFS should keep receipts/history useful for explanation and replay while refusing to treat them as current locality truth.

## What to steal

- **Android SAF / DocumentsProvider** (REF-ANDROID-SAF, REF-ANDROID-DOCPROVIDER): stable document IDs, dynamic roots, provider-declared capabilities, and the split between `ACTION_GET_CONTENT` copy-import and `ACTION_OPEN_DOCUMENT` persistent provider-owned access are excellent receiver-side import lessons.
- **Apple document picker + security-scoped access** (REF-APPLE-DOCPICKER-ACCESS, REF-APPLE-SECSTART, REF-APPLE-SECBOOKMARK-ENABLE): open-in-place returns a security-scoped exterior-backed URL with explicit start/stop discipline, while import/export use copies.
- **Apple File Provider materialization** (REF-APPLE-FILEPROVIDER-SYNC): provider-backed items can be dataless or materialized locally, which is exactly the kind of locality distinction ViewFS should preserve.
- **XDG Documents portal** (REF-XDG-DOCUMENTS, REF-XDG-DOCS-FUSE): a mediator can expose a restricted projected filesystem view keyed by document IDs and permissions without pretending that projected paths are native ambient ownership.
- **Fuchsia namespace entries** (REF-FUCHSIA-COMPONENT-NSENTRY, REF-FUCHSIA-FSARCH): receiver-local usability can come from explicit path→directory namespace entries and wrappers over handles without those wrappers deciding final storage semantics.
- **Foundry companion cube**: foreign cells, compat membranes, restore/reacquire rails, and borrowed-handle posture all reinforce the same humility about foreign-backed utility.

## Shell consequences

The shell/terminal should gain:
- **borrow rails** that render `foreign-backed`, `wrapped here`, `projected here`, `localized here`, or `history only` as different truths;
- **projection badges** that say `portal view`, `provider projection`, `compat attach`, `materialized cache`, or `local object`;
- **make-here ladders** that let the user choose `use borrowed`, `attach via wrapper`, `project into this pane`, `make local copy`, or `receipt only`;
- **provider-owned halos** and **dataless/materialized lamps** so the shell can explain why an item opens slowly, vanishes offline, or still depends on another service;
- **why-not-adopt drawers** for `provider missing`, `wrapper required`, `projection only`, `localize explicitly`, or `history only`.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal foreign-wrapper ABI,
- whether every projection comes from a portal rather than a provider/runtime helper,
- whether local realization means exact byte copy, local mirror, or local object-store commit in every case,
- whether provider-backed borrows may survive offline or relaunch by default,
- whether projected imports are durable names, per-process binds, or both.

## Design bar

Before ViewFS standardizes richer import/adoption UX, it should be able to answer:

1. Is the shell talking about a foreign-backed borrow, a compat attach, a projected import, a local realization, or only history?
2. Can something be immediately usable here without pretending it is already localized here?
3. Can projected views stay visibly synthetic and scoped instead of masquerading as native ambient paths?
4. Can `make here` produce an explicit locality transition with a receipt?
5. Can old import/materialization receipts remain useful without silently reviving current adoptability?
