# RFC-0068: Keep object identity, view placement, current handle rights, advertised operations, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates immutable object identity from durable reopen, current live handles from history, and current binds from namespace mutation receipts.
The next low-regret seam is **object identity / current placement in a view / current rights on a live handle / currently advertised operations**.

One stable object ID is not the same thing as one place where that object appears.
One place where that object appears is not the same thing as one currently held handle with a particular rights mask.
One currently held handle with a particular rights mask is not the same thing as the broader set of operations the provider is prepared to support for that object or placement.
And none of those are the same thing as a receipt.

If we collapse those classes too early, we make at least five mistakes:

1. **names start masquerading as object identity**
   - one path-shaped string starts acting like the object itself instead of one current placement in one view.

2. **one placement starts masquerading as all placements**
   - the shell forgets that the same object may appear in several parents or views at once.

3. **handle rights start masquerading as provider affordances**
   - a locate-only or read-only handle starts acting like a full mutate-capable object just because the provider supports rename/move/delete in some contexts.

4. **provider affordances start masquerading as current authority**
   - a menu item advertised by a provider starts acting like the current pane definitely holds the right live handle to do it now.

5. **history starts masquerading as current affordance truth**
   - an old receipt about what was possible once starts acting like current placement, current rights, or current supported operations.

## The seam

Keep these classes visibly distinct:

1. **object identity**
   - one exact object or document identity.
   - stable across placement changes when the provider supports that model.
   - not itself a menu of verbs.

2. **current placement in one view**
   - one current parent/bind/alias/location where the object appears in this view or pane.
   - may differ across views, processes, or provider-local directories.
   - not itself proof of current mutation authority.

3. **current handle rights / slot posture**
   - the rights currently attached to one live handle, bind, or slot in this pane.
   - examples: locate-only, read-bytes, write-bytes, traverse, update-attributes, execute.
   - not the same thing as every operation the provider could support in some other context.

4. **advertised operations / affordances**
   - the operations the provider or object currently says are meaningful for this target or placement.
   - examples: rename, copy, move, delete, remove-from-parent, thumbnail, settings, create-within, link-into, publish-here.
   - may change dynamically.
   - not itself proof that the current pane holds enough authority to do the operation now.

5. **receipt / history**
   - evidence that one object appeared here, one menu was shown, one operation was supported then, or one act succeeded/failed.
   - not current placement, current rights, or current affordance truth.

## Working posture

- ViewFS should let one exact object identity appear in multiple placements without laundering those placements into the identity itself.
- ViewFS should let one handle be inspect/locate/traverse-only without pretending it is equivalent to a read/write or mutate-capable handle.
- ViewFS should let providers advertise operations explicitly enough to drive action menus and route slips without pretending that advertisement alone proves current authority.
- ViewFS should intersect **placement truth**, **current handle rights**, **provider-advertised affordances**, and **current policy/gate state** when building action surfaces.
- ViewFS should keep receipts/history useful for explanation and replay while refusing to treat them as current affordance truth.

## What to steal

- **Android DocumentsProvider / DocumentsContract**: one opaque document ID may be included as a child of multiple directories, while `COLUMN_FLAGS` advertises operations such as rename, copy, move, delete, metadata, settings, or web-link generation.
- **Linux `O_PATH`**: a handle can designate location and support descriptor-level operations without opening the file for normal byte I/O.
- **Capsicum rights**: a currently held descriptor can be refined so some operations remain possible and others are denied.
- **Fuchsia capabilities and `fuchsia.io` rights**: capabilities combine access with a set of rights inside one component namespace, and concrete filesystem operations demand specific rights sets.
- **HTTP `Allow`**: one target resource can advertise the methods currently supported for it, and that advertised set can change dynamically.

## Shell consequences

The shell/terminal should gain:
- **place cards** that can say `same object also appears in…` without pretending those names are the identity;
- **verb ledgers** that render `provider says yes`, `current handle says no`, `policy says ask`, `view says not here`, or `history only` as different reasons;
- **affordance lenses** that separate `what this is`, `where it is here`, `what I hold now`, and `what can be done here`;
- **filtered action menus** that remove or explain verbs based on the real intersection of placement, rights, affordance, and current gate state;
- **why-not drawers** for `rename unsupported here`, `move supported by provider but not with this handle`, `copy allowed but import needed`, `thumbnail available`, or `settings available elsewhere`.

## Phase-1 non-decisions

This RFC does **not** decide:
- one final affordance schema or verb taxonomy,
- whether advertised operations are provider-native, shell-computed, or mixed,
- whether placements are parent/name pairs, alias objects, or higher-level binds,
- whether the shell exposes raw right bits or only one normalized summary,
- whether all providers participate in one universal affordance-discovery API.

## Design bar

Before ViewFS standardizes smarter action menus or stronger namespace affordance APIs, it should be able to answer:

1. Is the shell looking at object identity, one placement here, one current handle-rights set, one advertised operation set, or only history?
2. Can the same object appear in two places without those places silently becoming the identity?
3. Can one object advertise an operation while one current handle still lacks the authority to do it now?
4. Can action menus explain `supported in principle` versus `permitted with what you hold` versus `not valid at this placement`?
5. Can old receipts stay useful for explanation without silently becoming current affordance truth?
