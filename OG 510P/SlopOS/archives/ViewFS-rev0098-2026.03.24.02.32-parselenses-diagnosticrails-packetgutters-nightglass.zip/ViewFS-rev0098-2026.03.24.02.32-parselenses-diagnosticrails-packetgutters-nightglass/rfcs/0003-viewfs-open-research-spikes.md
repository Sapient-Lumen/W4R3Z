# RFC-0003: ViewFS open research spikes

Status: Draft
Updated: 2026-03-21

## Summary
ViewFS is still in the design phase, and so is SlopOS. This RFC records the next handful of spikes that seem worth running **without** pretending they settle the final architecture.

The goal is to answer only the questions that are blocking confidence in the first object-store + handle + view + portal stack.

## Guiding constraint
A spike should:
- isolate one hard uncertainty,
- keep authority edges explicit,
- produce an inspectable artifact or receipt,
- and avoid accidentally standardizing syntax or persistence semantics too early.

## Spikes worth doing next

### S1. Immutable object pack + manifest root
Question:
- can the object store stay extremely small while still giving useful snapshot and closure ergonomics?

Deliverable:
- blob/object pack format
- root manifest object
- exact digest + inspection command

Non-goal:
- writable random-access file API

### S2. Handle rights duplication and attenuation
Question:
- what is the smallest useful rights lattice for files/directories/views in Phase 1?

Deliverable:
- handle inspector
- duplicate-with-reduced-rights operation
- proof that rights can shrink but not grow in place

Non-goal:
- perfect final rights taxonomy

### S3. Portal open/save/reopen receipt flow
Question:
- what metadata is actually needed for open, save, reopen, revoke, and transfer receipts?

Deliverable:
- chooser/open flow
- save/export flow
- one durable reopen experiment
- explicit receipt rendering

Non-goal:
- universal cross-app bookmark format

### S4. Mutable work-state experiment over immutable roots
Question:
- does a root-pointer or journal model give enough ergonomics before we even think about a general mutable-slot object?

Deliverable:
- one editable workspace prototype over immutable content
- snapshot/save/undo story
- comparison note against a stable-slot variant

Non-goal:
- final answer for all mutation workloads

### S5. Shell/terminal semantic-block demo
Question:
- can the shell make authority, provenance, and receipts legible enough that users will not reach for ambient escape hatches?

Deliverable:
- prompt badge with active view/domain
- semantic command blocks
- clickable receipts/inspectors
- one notebook/playbook example

Non-goal:
- final shell syntax or scripting language

## Things we should still avoid deciding
- whether ViewFS has one universal mutable object kind
- whether bundle/dictionary objects are stored, routed, or both
- whether durable grants are token-like, handle-reopen records, or something else long-term
- whether query/smart-folder surfaces are filesystem-native or shell-owned manifest objects
- whether compat paths are synthetic tree overlays, libc shims, or both

## Expected output of each spike
Each spike should produce:
- one short note saying what it proved and what it did not,
- one transcript or receipt sample,
- one list of assumptions that would become dangerous if generalized.
