# RFC 0056: Keep imported source refs, materialized local objects, local docrefs, and receipts separate

Status: exploratory

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports. That combination gets much easier to evolve if ViewFS keeps one more seam sharp early: an **imported source ref** should not silently become a **fresh local object**, and neither should silently become a **local durable docref** or a **durable receipt/history row**.

That lesson matters while SlopOS is still in design because it lets ViewFS freeze a separation early **without** freezing one import substrate, one sync model, or one durable-reopen story too early.

## The separation
Keep these classes separate:
- imported source refs / source-side designators / remote bearer-ish offers
- explicit import or materialization acts
- fresh local objects with their own local identity/descriptor
- local non-bearer docrefs or durable reopen designators
- live handles or binds carrying current authority
- durable receipts / later history rows

Do **not** flatten them into one vague story like “the imported file”.

## Historical lesson
Portal and document systems work best when they separate **designation**, **materialization**, **durable reopen**, and **current access**.

The XDG Documents portal exposes outside files to sandboxed apps through a controlled, per-app document view instead of ambient filesystem access. Android's document-provider model similarly relies on stable document IDs and persisted grants rather than pretending every selection is a global path. And the current SlopOS document-portal/import-boundary drafts add an especially valuable restraint: when the workflow starts from a source ref or remote capability, document-style reopening should begin only **after** explicit materialization has created a fresh local object and provider-local docref.

That is exactly the low-regret shape ViewFS should steal.

## ViewFS rule
ViewFS should preserve a distinct lane for:
1. identifying or receiving one imported source ref / offer,
2. explicitly materializing local bytes or a local object when the user or policy chooses,
3. separately minting one local object descriptor/identity for what now exists here,
4. separately minting one local durable docref/reopen handle if the platform wants that affordance,
5. separately minting or binding one current live handle when current authority is actually needed,
6. separately recording one receipt/history row about import, materialization, publication, reopen, or transfer,
7. later inspecting those rows without turning them back into bearer authority.

## Why this helps ViewFS
- It stops “remote source ref” from smuggling itself into “local durable reopen”.
- It lets portal/import UX say `source ref only`, `materializing`, `fresh local object`, `local docref`, `live handle now`, or `receipt only` as different truths.
- It gives the future shell an honest ladder for import flows without pretending durable reopen and live authority are the same thing.
- It preserves freedom about sync, mirroring, pinning, import-by-copy, import-by-fetch, and local publication while SlopOS and ViewFS are both still moving.

## What this does not decide
This RFC intentionally does **not** decide:
- whether ViewFS Phase 1 imports always copy bytes locally versus sometimes stage fetch-on-demand,
- whether every imported object always gets a durable local docref,
- whether local docrefs are portal-only, shell-visible, or purely internal,
- whether local docrefs resolve through one provider, many providers, or a capability router,
- whether source refs and local object descriptors ever share syntax,
- whether publication into one namespace/view happens at materialization time, later, or never.

## Shell consequences
A future ViewFS shell should be able to show:
- `source ref only`,
- `materializing`,
- `fresh local object`,
- `local docref`,
- `live handle now`,
- and `receipt/history only`
as different truths.

It should also be able to render one import ladder that says:
`inspect source` → `materialize local object` → `mint local docref` → `bind/publish here`
without implying that any earlier step silently grants the later ones.

## SlopOS alignment
This separation fits SlopOS well because SlopOS already keeps reaching toward explicit source refs, explicit portals, explicit local handles, and non-bearer durable reopen designators instead of ambient rediscovery. ViewFS can therefore borrow the *shape* of import-localization now, while leaving fetch policy, CapStore durability, namespace publication, and reopen routing open longer.
