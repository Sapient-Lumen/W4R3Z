# RFC-0072: Keep observed validators, writable sessions, write holds, commit preconditions, committed versions, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates optimistic preconditions, leases, and conflict receipts.
The next low-regret seam is **observed validator / private writable session / live write hold / commit precondition / committed version**.

A version token that says “this is what I read” is not the same thing as a live local writable session.
A local writable session is not the same thing as a shared write hold or lock token.
A write hold is not the same thing as the exact precondition attached to one commit attempt.
A commit precondition is not the same thing as the committed version that actually won.
And none of those are the same thing as a durable receipt.

If we collapse those classes too early, we make at least six mistakes:

1. **observed bases start masquerading as live write authority**
   - one stale validator token gets treated like permission to commit.

2. **draft sessions start masquerading as shared holds**
   - a local scratch writer or swap file quietly becomes a claim that nobody else can write.

3. **holds start masquerading as exact commit conditions**
   - “I currently hold something” gets mistaken for “this commit was checked against that exact base.”

4. **committed heads disappear into session folklore**
   - the system forgets which version actually became durable versus which draft merely existed locally.

5. **receipts start masquerading as resumable write sessions**
   - an old transcript row gets replayed as if the private draft or lock were still alive.

6. **last-writer-wins leaks in through convenience**
   - multi-writer or multi-tab editing silently falls back to overwriting because draft, hold, precondition, and commit state were never kept separate.

## The seam

Keep these classes visibly distinct:

1. **observed validator / expected base**
   - ETag, generation, mod-revision, content digest, or equivalent exact basis the user/tool observed.
   - useful for compare-before-commit and stale-base honesty.
   - not a writable session.

2. **private writable session / draft buffer**
   - one local working stream, swap file, temp copy, or private staging object.
   - useful for editing and preview.
   - not proof that the shared target stayed still.

3. **live write hold / lease / lock token**
   - one current coordination artifact that may prefer or restrict a writer.
   - may expire or disappear.
   - not the same thing as the exact commit precondition.

4. **commit precondition**
   - one explicit `if still equals X` gate attached to one mutation attempt.
   - useful for compare-and-swap semantics.
   - may reference an observed validator and maybe a hold.
   - not itself the committed result.

5. **committed version / generation / head**
   - the version that actually became durable after one accepted mutation.
   - may differ from what another local draft expected.
   - useful for receipts, later reads, and follow-on edits.

6. **receipt / history**
   - evidence that an observed base, writable session, hold, precondition, or commit outcome existed at one time.
   - useful for explanation and audit.
   - not current writable state.

## Working posture

- ViewFS should let tools/shells keep exact observed validators without pretending they are current write authority.
- ViewFS should let private writable sessions exist without pretending they grant coordination against other writers.
- ViewFS should keep live holds narrow, inspectable, and obviously separate from exact commit predicates.
- ViewFS should treat each commit attempt as an explicit compare/commit act over named basis material rather than an ambient “save latest” gesture.
- ViewFS should surface the committed version that actually won instead of letting draft-local success folklore replace durable truth.
- ViewFS should keep receipts/history useful while refusing to let them silently revive drafts, locks, or current write authority.

## What to steal

- **HTTP conditional requests**: `If-Match` and `If-None-Match` are sharp precedents for exact guarded mutation.
- **Google Cloud Storage generation / metageneration preconditions**: object stores can expose safe read-modify-write without pretending one object key implies one ambient writer.
- **etcd compare-and-swap transactions**: one transaction can guard a mutation on exact prior state instead of optimistic folklore.
- **WebDAV lock tokens**: coordination holds can exist, refresh, and expire, but they are still separate from write privilege and separate from the current committed version.
- **File System Access writable sessions**: one local writable stream can use a private swap/staging story and still remain distinct from the final committed bytes and from exclusive multi-writer coordination.
- **Kubernetes resourceVersion on write paths**: exact observed revision can guard one update attempt without becoming a universal lock manager.

## Shell consequences

The shell/terminal should gain:
- **stale-base lamps** that show `based on X`, `target moved to Y`, or `receipt only`;
- **draft gutters** that show `private draft`, `sealed for commit`, `shared hold present`, or `history only`;
- **commit shutters** that make `commit if base still matches`, `commit if absent`, `commit under hold`, `rebase draft`, or `fork new object` different acts;
- **write-hold meters** that show `exclusive`, `advisory`, `expired`, `uncertain`, or `none` without pretending that is the same thing as exact commit truth;
- **commit receipts** that say which validator/have-hold basis was used and which committed version actually won.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal validator field across all providers and object families,
- whether ViewFS uses generations, digests, epochs, mod-revisions, or several of them in different seams,
- whether any write hold is mandatory, advisory, local-only, or provider-owned in Phase 1,
- whether private writable sessions are shell-owned, provider-owned, or lower-level runtime objects,
- whether multi-object commits are supported in Phase 1 or only later.

## Design bar

Before ViewFS standardizes richer edit/commit flows, it should be able to answer:

1. Is this thing an observed validator, a private writable session, a live write hold, a commit precondition, a committed version, or only a receipt?
2. Can the shell tell the user whether a write failed because the base moved, the hold expired, or the policy/authority lane denied it?
3. Can the system show which committed version actually won instead of just saying “save succeeded” locally?
4. Can draft-local editing stay useful without silently claiming exclusive shared authority?
5. Can receipts stay useful for explanation without silently reviving write sessions, holds, or current authority?
