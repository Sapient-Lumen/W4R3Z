# RFC-0017: Keep checkpoints, writable forks/worktrees, backup streams, publication, and activation/rollback on separate seams

## Status
Proposed.

## Problem
ViewFS already distinguishes handles, refs, receipts, session state, registries, trust gates, previews, watch feeds, links, origin/quarantine, and delete/recovery semantics.
Another easy collapse is to treat all time-travel-ish operations as if they were the same thing:

- local checkpoints,
- read-only snapshots,
- writable forks/worktrees,
- branch/head movement,
- backup or replication streams,
- published/deployable artifacts,
- activation/rollback targets.

History says these are not the same question.

## Proposal
For Phase 1 and nearby spikes, ViewFS should keep at least these classes distinct:
- checkpoint intent,
- read-only snapshot,
- writable fork/worktree,
- branch/head movement,
- backup/replication stream,
- published/deployable artifact,
- activation/rollback target.

Any proposal that collapses them should pay a high burden of proof.

## Consequences
- the shell can make experimentation cheap without pretending every checkpoint is a backup or release
- immutable-first storage can stay simple while time-travel UX becomes unusually good
- publication and deployment can add stronger review/provenance later without redesigning local checkpoints
- activation/rollback can remain explainable as state-selection, not raw object identity
- backup/export can stay honest about transport and survivability rather than silently becoming live workspace semantics

## Non-goals
This RFC does not choose:
- a final snapshot format,
- a final worktree/fork schema,
- a final replication/export protocol,
- a final publication/promotion policy,
- or a final activation/rollback mechanism.

## Adoption test
A future ViewFS proposal should answer:
- Is this creating a **checkpoint**, a **writable fork**, a **head/ref move**, a **backup/export**, a **publish candidate**, or an **activation choice**?
- Is the result local-only, replicated, published, pinned, or active-next?
- Does the user get a truthful diff/restore/explain path?
- Does any receipt or notebook entry accidentally become live authority?
- Is the proposal making stronger backup/publication/activation promises than the mechanism can justify?

If the answer is “users just think of this as history,” the burden of proof should be high.
