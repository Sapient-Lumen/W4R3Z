# RFC 0045: Keep exec objects, startup code closure, loader policy, and late imports separate

Status: draft guardrail RFC.

## Why this exists
ViewFS already keeps exact exec objects, script entry, launch basis, startup credentials, and launch receipts on separate seams.
A new design pressure is now appearing around **what code actually becomes part of the process once that exact executable object starts**:
- one reviewed launch may point at one exact executable object,
- the loader/interpreter may still resolve startup shared libraries, runtime support code, or other native dependencies through separate policy,
- later plugin or extension loading may happen after startup through a still different lane,
- and the later receipt/history artifact still is not the same thing as any of the above.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design.

## Distinct truths

### 1. Exact exec object
Question:
- what exact executable object or exact staged byte object is intended to start?

Examples:
- executable-object handle
- exact staged exec object
- digest-bound launch target

### 2. Startup code closure
Question:
- what startup loader/interpreter/shared-library closure is allowed to participate before the child is considered started?

Examples:
- exact startup closure manifest
- loader-approved dependency set
- reviewed runtime-support closure

### 3. Loader / resolver policy
Question:
- what search and resolution posture is allowed while startup code is being resolved?

Examples:
- exact no-search loader policy
- restricted explicit search roots
- compat fallback debt marker

### 4. Late import / plugin lane
Question:
- what happens after startup when the process later requests plugins, extensions, modules, or dynamically loaded code?

Examples:
- explicit late-import request
- reviewed plugin grant
- runtime extension receipt

### 5. Receipt / history artifact
Question:
- what durable artifact records that launch or import happened?

Examples:
- launch receipt
- closure review receipt
- plugin/import receipt
- history row

## Guardrail
A system should be allowed to review and commit a launch without collapsing these classes.
It must not silently pretend that:
- binding one exact exec object already proves the exact startup code closure,
- loader search policy is morally the same thing as object identity,
- later plugin/module imports are the same lane as startup code closure,
- or a launch/history row is enough to prove that the same runtime closure was used again.

## Implications for ViewFS
- launch review should be able to say `exec object`, `startup closure exact`, `loader policy`, `late import lane`, `launch receipt`, or `history only` as different truths;
- SlopOS-style exact-exec-object launch remains valuable, but ViewFS should still keep native code closure and later plugin/import behavior on visibly different seams;
- ambient loader search, current-directory DLL lookup, mutable `PATH`/`LD_LIBRARY_PATH`-style behavior, and other host-default search folklore should stay loud compat debt rather than silently becoming reviewed launch meaning;
- replay should begin from fresh planning or reviewed receipts, not from assuming an old command row still implies the same loader search posture or dynamic-import closure.

## Non-decisions
This RFC does **not** decide:
- how ViewFS would represent an exact startup closure, if it ever does;
- whether startup closure is manifested, staged, bundled, or carried by another launch object;
- whether any late plugin/module import lane is approved interactively, policy-gated, or fully disabled in Phase 1;
- how much closure detail the default shell chrome should show before expansion.

## Shell consequences
The custom shell+terminal should be allowed to grow:
- closure-certainty badges,
- loader-debt warnings,
- startup-closure preview drawers,
- and late-import/plugin route sheets,
without claiming more than the current launch and runtime posture actually supports.
