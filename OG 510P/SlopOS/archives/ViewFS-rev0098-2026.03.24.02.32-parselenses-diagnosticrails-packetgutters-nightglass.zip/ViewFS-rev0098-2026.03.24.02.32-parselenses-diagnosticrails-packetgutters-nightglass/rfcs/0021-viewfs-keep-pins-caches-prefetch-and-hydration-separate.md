# RFC-0021: Keep pins, caches, prefetch, hydration, mirrors, and offline bundles on separate seams

## Status
Proposed.

## Problem
ViewFS already keeps many tempting collapses apart: handles versus refs, receipts versus authority, previews versus execution, checkpoints versus publication, and imports versus transfers.

Another dangerous collapse is to treat every “make bytes available locally” operation as one vague cache/download feature.
In practice these are different questions:
- are we only hinting that something will likely be useful soon?
- are we opportunistically caching it?
- are we hydrating an exact working set or closure for a local workflow?
- are we changing retention policy with a pin/root?
- are we mirroring a bounded corpus elsewhere?
- or are we producing/consuming a self-contained offline bundle?

## Proposal
For Phase 1 and nearby spikes, ViewFS should keep those classes distinct.
Any proposal that merges them should pay a high burden of proof and explain what becomes harder to inspect, budget, retain, evict, or use offline truthfully.

## Consequences
- shell UX can expose `hint`, `cache`, `hydrate`, `pin`, `mirror`, and `bundle` as honest states instead of one ambiguous spinner
- retention/GC behavior remains inspectable
- offline-readiness becomes a user-visible status instead of folklore
- publication/activation seams stay distinct from mirror and bundle workflows
- “warm but discardable” no longer masquerades as “kept on purpose”

## Non-goals
This RFC does not choose:
- the final cache eviction policy or quota design,
- the final pin/root schema,
- the final closure model for hydration,
- the final mirror topology or transport protocol,
- or the final shell syntax.

## Adoption test
A future ViewFS proposal should answer:
- Is this action a **prefetch hint**, **cache warm-up**, **hydration**, **pin/root change**, **mirror/replica sync**, or **offline bundle** lane?
- If local bytes are present, are they merely cached, or explicitly retained?
- If something is “offline-ready”, what exact closure or bundle made that true?
- If something is mirrored, does that imply publication or activation? (It usually should not.)
- If something is pinned, who or what is keeping it live, and how is that inspected?

If the answer is “it’s just downloading/caching,” the burden of proof should be high.
