# RFC 0053: Keep live binds, propagation posture, peer groups, and receipts separate

## Status
Accepted for design-phase guardrails.

## Why this exists
ViewFS already keeps:
- detached namespace fragments separate from live binds,
- object identity separate from current names and placements,
- and current handles separate from durable refs and receipts.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design:

**one live bind in one explicit process view, that bind's propagation posture, any peer/master group relationship or blast radius, and the durable receipt/history artifact are different classes.**

That matters immediately if the future shell wants to be honest about:
- whether something is merely attached here right now,
- whether later namespace changes under or around that bind stay local,
- whether they propagate to peers or only arrive from a master/upstream view,
- whether the bind is intentionally unbindable / non-cloneable,
- and whether a receipt is merely describing one attachment choice rather than reviving live propagation behavior later.

## Lessons from the past
Classic namespace systems already make this split unavoidable:
- Linux mount propagation is a **per-mount-point** setting rather than a property of the underlying filesystem object alone; mounts may be private, shared, slave, or unbindable.
- Shared mounts participate in peer groups, slave mounts receive propagation from a master group without propagating back, and unbindable mounts are private mounts that recursive bind operations prune instead of replicating.
- `open_tree(OPEN_TREE_CLONE)` creates a detached mount object that is not yet associated with the caller's mount namespace, and propagation does not apply until the object is later attached; propagation events that happened before attachment are not replayed afterward.
- `mount_setattr()` keeps propagation posture explicit as its own field, where callers either leave propagation unchanged or choose exactly one of `MS_PRIVATE`, `MS_SHARED`, `MS_SLAVE`, or `MS_UNBINDABLE`.

The lesson for ViewFS is not “be Linux mounts” or “freeze one shared-subtree mechanism.”
The lesson is: **do not let `attached here now` silently imply `local only`, `shared to peers`, `receives from upstream`, or `safe to replicate/bind again`, and do not let one generic bind row hide that blast radius.**

## Guardrail
ViewFS should keep these classes visibly separate:
1. **Live bind / current placement** — one current attachment in one explicit process or pane view.
2. **Propagation posture** — whether that bind is private, shared, slave/dependent, unbindable, or otherwise locally constrained.
3. **Peer/master relationship** — any current peer-group membership, upstream/master relationship, or blast-radius facts implied by the posture.
4. **Future mutation/arrival effects** — whether later namespace changes under or around this bind stay local, propagate out, or arrive from elsewhere.
5. **Bind receipt / history** — durable evidence describing one reviewed attach/rebind choice.

## Consequences
We should be able to say things like:
- `attached here, local only`
- `attached here, shared to peers`
- `attached here, receives upstream only`
- `attached here, not cloneable`
- `peer group known`
- `peer group hidden`
- `receipt only`

without laundering them into one fake `bound here` bit.

## Good answers might look like
- explicit bind cards that show `attached here` separately from `local only`, `shared`, `slave`, or `unbindable`
- blast-radius previews on attach/rebind review sheets
- peer-group / upstream drawers that explain who may see later namespace changes without pretending peer IDs are durable object identity
- namespace receipts that record whether the bind posture was private/shared/slave/unbindable at review time
- shell route sheets that keep `attach privately`, `attach with peer propagation`, and `receipt only` distinct

## What this does not decide
This RFC does **not** decide:
- whether ViewFS Phase 1 must expose all four classic propagation postures everywhere;
- whether the underlying implementation uses kernel mount propagation, explicit ViewFS view fan-out, owner-routed replication, or some other transport;
- whether peer/master relationships are surfaced as stable local IDs, opaque receipts, or only as qualitative blast-radius descriptions;
- what the default propagation posture should be for every future bind/import lane.

## Shell implications worth stealing
A future custom shell/terminal should expose:
- **propagation badges** such as `local only`, `shared`, `receive only`, or `not cloneable`;
- **blast-radius previews** before rebind/attach acts;
- **peer/upstream drawers** that explain why a current bind may see or affect other views;
- **attach-private-first** and other explicit posture choices instead of silently inheriting broad propagation.

## Why this is a low-regret move
Even if SlopOS later changes its exact view-attachment, replication, or local-namespace implementation, this split stays useful.
It is the kind of boundary that keeps explicit per-process namespaces, object-store binds, portal-mediated imports, and shell chrome honest while the deeper design is still moving.
