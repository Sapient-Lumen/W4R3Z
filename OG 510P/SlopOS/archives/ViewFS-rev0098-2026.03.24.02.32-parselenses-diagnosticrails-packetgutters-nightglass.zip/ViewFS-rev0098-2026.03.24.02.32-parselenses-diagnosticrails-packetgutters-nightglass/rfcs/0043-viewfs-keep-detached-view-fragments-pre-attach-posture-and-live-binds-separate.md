# RFC 0043: Keep detached view fragments, pre-attach posture, and live binds separate

Status: draft guardrail RFC.

## Why this exists
ViewFS already separates immutable object identity, live handles, durable refs, and receipts.
A new design pressure is appearing around explicit per-process namespaces:
- a launcher or shell may want to prepare one exact subtree or namespace fragment before a child starts,
- some narrow posture may need to be chosen while that fragment is still detached,
- attachment into one concrete process namespace is a separate act,
- and the final visible placement in a running view still is not the same thing as a durable reopen story.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design.

## Distinct truths

### 1. Detached view fragment
Question:
- what exact unattached fragment or subtree has been prepared?

Examples:
- a detached fragment descriptor
- a prepared subtree handle
- a shell-owned namespace fragment card

### 2. Pre-attach posture
Question:
- what narrow posture, if any, was chosen while the fragment was still detached?

Examples:
- attach-time-only flags
- a prepared resolve posture
- a shell-visible “prepared as read-only” or similar tag

### 3. Live bind / attachment act
Question:
- where, and by what act, was that fragment attached into one concrete process namespace?

Examples:
- an attach plan
- a bind act into one pane/view
- a child-launch namespace assembly step

### 4. Current visible placement
Question:
- where is the fragment visible right now from this running process view?

Examples:
- one synthetic cwd/root placement
- one bound slot in a pane
- one current local name from this view

### 5. Receipt / history artifact
Question:
- what durable artifact records that one of the above happened?

Examples:
- attach receipts
- launch receipts
- history rows
- route-plan receipts

## Guardrail
A system should be allowed to prepare a namespace fragment before it is attached.
It must not silently pretend that:
- a detached fragment is already a live bind,
- a live bind is the same thing as durable reopen,
- current visible placement is the same thing as the fragment itself,
- or a receipt/history row still carries current binding authority.

## Implications for ViewFS
- the custom shell should be allowed to show `prepared fragment`, `attached here`, `not attached`, `detached again`, or `receipt only` as different states;
- attach/bind should produce an explicit receipt instead of dissolving into path folklore;
- per-process namespace assembly can stay explicit without forcing a global mount-table worldview;
- pre-attach posture should remain narrow and inspectable instead of becoming hidden mutable state on a later live bind;
- replay/rebind flows should begin from fragments, plans, or receipts, not by assuming a remembered path is still truth.

## Non-decisions
This RFC does **not** decide:
- whether ViewFS uses mount-like detached objects, handle-table recipes, launcher-owned fragments, or another primitive;
- which posture changes are legal before attach and which are impossible in Phase 1;
- whether fragments can be shared across processes, machines, or reboots;
- whether a live bind can later be reified back into a detached fragment.

## Shell consequences
The custom shell+terminal should be allowed to grow:
- prepared-fragment cards,
- attach receipts,
- bind-here versus receipt-only route sheets,
- and attach-aware prompt badges,
without claiming more than the current fragment or bind actually supports.
