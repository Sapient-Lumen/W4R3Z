# RFC 0079: Keep provider-ready claims, reacquire obligations, local realizations, live handles, and receipts separate

Status: exploratory

## Why this exists

ViewFS already keeps **presence adverts**, **freshness-scoped readiness**, **fit notes**, and **current authority** more honest than a traditional path-centric shell.
The next easy mistake is subtler: treating `the provider could supply this`, `this can likely be re-fetched or substituted`, `this resume still owes repair work`, and `this now exists locally here` as the same truth.

That flattening will come back the moment ViewFS grows a real object store plus portal-mediated imports plus explicit per-process namespace plus shell-native `make local` flows.
It is therefore worth freezing one more seam now while SlopOS is still visibly in design.

## The separation

Keep these classes separate:
- provider/catalog advert saying a thing may exist or may be selectable;
- provider-ready / satisfiable-on-demand claim saying the provider could probably supply bytes or a capability later;
- explicit reacquire / restore obligation saying local repair, rebind, reauth, or refetch work is still owed;
- local realization / local materialization saying bytes or an object now exist here in the local substrate;
- current live handle / current authority saying a process actually holds usable authority now;
- durable receipt / history rows saying some earlier import, realization, repair, or adoption happened before.

Do **not** flatten them into one vague `available` or `present` story.

## Historical lesson

Several useful systems already resist this collapse:
- Git partial clone tracks **promisor remotes** and handles **missing objects** differently from corruption or fully local objects.
- Nix treats **realisation** as an explicit act that may confirm a path is already valid, download substitutes, or build outputs; store-path information alone does not guarantee current local validity.
- Fuchsia capability routing explicitly distinguishes a component declaring that it wants a capability from that capability actually being available at runtime through a valid route.
- Foundry's current companion work also keeps **restore obligations**, **availability class**, **borrowed handles**, and **owned-handle swap** separate instead of collapsing them into one fuzzy readiness bit.

That is exactly the low-regret shape ViewFS should steal.

## ViewFS rule

ViewFS should preserve a distinct lane for:
1. advertising or cataloging that some object/service may exist,
2. separately claiming that it is satisfiable by fetch/substitute/rebind/reacquire,
3. separately recording any restore/reacquire duties still owed,
4. separately materializing or realizing local bytes/object state,
5. separately handing out a live current handle when authority is actually needed now,
6. separately recording receipts/history about those transitions,
7. later inspecting those rows without reviving present authority or pretending local realization still exists.

## Why this helps ViewFS

- It stops `provider says yes` from masquerading as `local object exists here now`.
- It lets the shell say `advertised`, `provider-ready`, `reacquire needed`, `realizing now`, `local now`, `live handle now`, or `history only` as different truths.
- It makes offline readiness much more honest: a thing can be easy to reacquire later without being local now.
- It keeps room for SlopOS to settle portal/import/CapStore/restore details later without forcing ViewFS to lie in the meantime.

## What this does not decide

This RFC intentionally does **not** decide:
- whether provider-ready claims come from one portal, one object store, many providers, or a helper mesh;
- whether realization always copies bytes locally versus sometimes pins a locally backed projection;
- whether reacquire obligations are shell-owned, portal-owned, supervisor-owned, or spread across those layers;
- whether realization can complete lazily or only as one eager materialization act;
- whether provider-ready state is authoritative enough to drive background prefetch by default.

## Shell consequences

A future ViewFS shell should be able to show:
- `advertised only`,
- `provider-ready`,
- `reacquire needed`,
- `realizing now`,
- `local realized`,
- `live handle now`,
- and `receipt/history only`
as different truths.

It should also be able to render one honest ladder that says:
`inspect advert` → `ask provider / substitute` → `reacquire / repair if needed` → `make local` → `bind here / hand to process`
without implying that any earlier step silently grants the later ones.

## SlopOS alignment

This separation fits SlopOS especially well because SlopOS already keeps live-session authority, restore/import seams, activation continuity, and provider-owned state more explicit than mainstream path UIs do.
ViewFS can therefore borrow the *shape* of provider-ready-versus-local-realized truth now while leaving CapStore durability, local object-store layout, repair ownership, and portal/import machinery open longer.
