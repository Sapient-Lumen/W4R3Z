# RFC-0027: Keep basis records, drift checks, reconsent checkpoints, and renewed authority separate

## Status
Proposed.

## Problem
ViewFS already tries not to collapse imports into binds, plans into execution, suggested automation into user-owned workflow truth, or temporary loans into durable shared-handle folklore.
A fresh collapse risk is now visible anywhere the system wants to **reuse** prior success:

- a prior receipt, workflow, reopen ref, or borrowed-authority outcome the user wants to act from again,
- the exact prior basis that was reviewed or depended on,
- the present-time drift check against that basis,
- any fresh reconsent or issuer renewal step,
- the new artifact issued now,
- and the historical receipt that survives afterward

can drift toward “one replay object”.

That would be a mistake.
It would let old success masquerade as current approval, hide why fresh review is required, blur receipt/history with live authority, and make mutable-basis drift silently follow the head.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat the following as distinct classes:

- **ReuseCandidate** / some prior artifact the user wants to act from again,
- **BasisRecord** / compact exact record of what was reviewed or depended on before,
- **DriftCheck** / present-time comparison verdict against that basis,
- **ReconsentCheckpoint** / fresh human or issuer review required now,
- **RenewedArtifact** / the fresh live borrow, durable ref, bind, or prepared plan issued now,
- and **ReuseReceipt** / durable history explaining exact reuse, narrowed reuse, fresh reconsent, denial, receipt-only, or source-missing outcome.

The default reading should be:
- a past success is not current authority,
- a basis record is not a drift verdict,
- a drift verdict is not approval,
- reconsent is not the renewed artifact,
- and a renewed artifact should get fresh identity/receipt lineage instead of mutating history into the present.

## Consequences
- replay and reopen flows begin from fresh comparison against current state instead of pretending old receipts float forward
- the shell can offer `reuse exact`, `reuse narrowed`, `fresh chooser`, `fresh lend`, `fresh temp view`, and `receipt only` without lying
- stale-basis denials, missing-source failures, and narrowed-operation renewals become transcript-visible outcomes
- renewal to a more durable class can remain an explicit step instead of an accidental side effect of success again
- durable reopen lists can stay bounded, pruneable, and visibly distinct from live current access

## Non-goals
This RFC does not choose:
- a final `BasisRecord`, `DriftCheck`, `ReconsentCheckpoint`, or `ReuseReceipt` schema,
- whether all reuse/renewal flows share one substrate primitive,
- exact drift-state enums,
- whether basis records are always durable,
- or final shell syntax for `reuse`, `renew`, `reconsent`, `rebind`, or `receipt-only`.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing a **reuse candidate**, an exact **basis record**, a current **drift check**, a **reconsent checkpoint**, a fresh **renewed artifact**, or only **history/receipt**?
- Can the shell say whether reuse is exact, narrowed, reconsent-required, receipt-only, or impossible because the source vanished?
- Does mutable-basis drift force a fresh act instead of silently following the new head/state?
- Does the renewed artifact get fresh lineage instead of mutating an old receipt into current live authority?
- Can the transcript say *why* reuse changed class?

If the answer is “for convenience these are basically the same object,” the burden of proof should be high.
