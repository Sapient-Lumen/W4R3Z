# RFC-0083: Keep current possession, local duplication, live lends, representation exports, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates current possession from current invocability, claim tickets from holder-bound grants, and transfer offers from receiver-local adoption.
The next low-regret seam is **current possession / local duplication posture / live-lend posture / representation-export posture / durable receipts**.

One current held handle is not the same thing as one local duplicate of that handle.
One local duplicate is not the same thing as one live lend that can cross a courier lane into another actor.
One live lend is not the same thing as one mediated representation export that only yields bytes, a projected document, or another downgraded form.
And none of those are the same thing as a receipt.

If we collapse those classes too early, we make at least five mistakes:

1. **holding starts masquerading as shareability**
   - a local `have` state quietly becomes `can send anywhere` even when no such lane exists.

2. **local duplication starts masquerading as boundary crossing**
   - a same-host duplicate or same-process slot copy quietly becomes a claim that another sandbox, machine, or portal target can receive the live thing.

3. **live lends start masquerading as representation exports**
   - an exact live handle courier lane gets confused with bytes-only, doc-projection, or one-shot export paths.

4. **representation offers start masquerading as current authority**
   - an app that can receive one MIME type or portal-exported document is treated as already holding the original live object or full rights.

5. **history starts masquerading as current export posture**
   - an old `shared`, `copied`, or `sent` receipt starts acting like the current actor can still duplicate, lend, or export the object the same way.

## The seam

Keep these classes visibly distinct:

1. **current possession**
   - one exact held object/handle/view in this process, pane, or session now.
   - says nothing yet about duplication or transfer.

2. **local duplication / attenuation posture**
   - whether the current actor can make another local copy or a narrower local derivative.
   - examples: duplicate as-is, duplicate narrowed, duplicate forbidden, duplicate unknown.
   - still not a claim that another actor can receive it.

3. **live lend / courier posture**
   - whether the current actor can hand another actor a live authority-bearing thing now over one explicit courier lane.
   - examples: same-host descriptor copy, same-runtime capability send, same-session batched handoff, single-use live send.
   - still not the same thing as exporting bytes or durable reopen material.

4. **representation export posture**
   - whether the current actor can export a weaker representation instead of the live original.
   - examples: MIME conversion, bytes snapshot, projected document, docref, file-transfer payload, claim ticket, receipt only.
   - may succeed even when live lending is impossible.

5. **receipt / history**
   - durable evidence that a duplicate, lend, export, or refusal happened before.
   - not current possession, not current live-lend posture, and not current export posture.

## Working posture

- ViewFS should treat `I hold it now` as weaker than `I can duplicate it now`.
- ViewFS should treat `I can duplicate it locally` as weaker than `I can lend it live across this lane`.
- ViewFS should treat `I can lend it live` as distinct from `I can only export one representation`.
- ViewFS should allow multiple export classes to coexist: exact live lend, attenuated live lend, projected-doc export, bytes snapshot export, receipt-only export.
- ViewFS should keep receipts/history useful for explanation and replay while refusing to treat them as present export posture.

## What to steal

- **Mach port rights** (REF-MACH-PORT-RIGHTS): send, receive, and send-once rights are different classes, and rights can be moved or copied through IPC instead of being assumed ambiently portable.
- **seL4 endpoint rights and Grant/GrantReply** (REF-SEL4-GRANT): send, receive, and capability-carrying transfer stay explicit; capability transfer requires Grant-style rights and attenuation remains monotonic.
- **UNIX `SCM_RIGHTS`** (REF-UNIX-SCMRIGHTS): what crosses the socket is effectively a duplicate reference to an open file description in another table, not a magical path reopen or a durable token.
- **Wayland data offers** (REF-WAYLAND-DATADEVICES): source and destination negotiate offered representations explicitly, and the receiver chooses one representation before data transfer happens.
- **XDG FileTransfer** (REF-XDG-FILETRANSFER): some cross-app transfers should be mediated as exported files/documents rather than raw live authority handoff.
- **kitty file transfer over TTY** (REF-KITTY-FILETRANSFER): even a terminal can support explicit file-transfer sessions as a distinct lane, with its own fit and confirmation, instead of pretending copy/paste or scp folklore is the only route.

## Shell consequences

The shell/terminal should gain:
- **lend ladders** that render `hold only`, `duplicate locally`, `lend live`, `lend narrowed`, `bytes only`, `projected doc`, `receipt only`, or `history only` as different truths;
- **lane-fit badges** that say which courier or export lane actually fits (`local copy`, `socket lend`, `portal export`, `tty transfer`, `none`);
- **bytes-only fallback chips** when exact live lending is impossible but representation export remains available;
- **share sheets** that explain `same object`, `new representation`, `projected document`, `single-use live lend`, or `receipt only` instead of one vague `share` verb;
- **why-not-send drawers** for `held but non-lendable`, `lendable locally only`, `representation export available`, `portal required`, or `history only`.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal export taxonomy for every provider and object kind,
- whether live lends are kernel-native, runtime-native, shell-mediated, or split across those layers,
- whether representation export always materializes bytes or may also mint projected/synthetic views,
- whether any live lend ever crosses reboot, machine, or user boundaries,
- whether one TTY transfer lane belongs in the ViewFS protocol itself or remains a terminal-specific adjunct.

## Design bar

Before ViewFS standardizes richer share/send/export UX, it should be able to answer:

1. Is the shell talking about current possession, local duplication, live lending, representation export, or only history?
2. Can one actor duplicate locally without that implying live lend across a trust or sandbox boundary?
3. Can one actor fail to lend live yet still export a weaker representation honestly?
4. Can the shell explain `exact live lend`, `attenuated live lend`, `bytes-only export`, `projected doc export`, and `receipt only` as different outcomes?
5. Can old send/share receipts remain useful without silently reviving current export posture?
