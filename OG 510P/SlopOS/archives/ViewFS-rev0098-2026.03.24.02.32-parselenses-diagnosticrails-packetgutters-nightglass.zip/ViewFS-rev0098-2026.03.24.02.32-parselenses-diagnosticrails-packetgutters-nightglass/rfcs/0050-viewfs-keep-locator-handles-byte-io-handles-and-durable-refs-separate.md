# RFC 0050: Keep locator handles, byte-I/O handles, and durable refs separate

## Status
Accepted for design-phase guardrails.

## Why this exists
ViewFS already keeps:
- immutable object identity separate from current names and mutable heads,
- live handle copies separate from durable reopen refs,
- and rooted resolution posture separate from current placement.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design:

**a locator/metadata handle, a live byte-I/O handle, a rights-escalation or reopen act, and a durable ref/history artifact are different classes.**

That matters immediately if the future shell wants to be honest about:
- whether a current root/object handle can only locate, stat, or route to an object,
- whether the current handle can actually read bytes, write bytes, append, or execute,
- whether `open for read` or `reopen for write` is minting a new operational handle rather than merely re-labeling an inspect-only one,
- and whether a durable ref/history row is only describing a past capability state instead of reviving live I/O.

## Lessons from the past
Classic UNIX/Linux file-descriptor semantics already make this split unavoidable:
- `O_PATH` produces a file descriptor that indicates a location in the filesystem tree and supports file-descriptor-level operations, while `read(2)`, `write(2)`, `ioctl(2)`, and `mmap(2)` on that descriptor fail with `EBADF`;
- the same `O_PATH` handle can still serve as a `dirfd` for `openat()` and related `*at()` calls, be duplicated, and be passed over UNIX-domain sockets;
- `statx()` with `AT_EMPTY_PATH` can operate directly on a file descriptor, including one obtained with `O_PATH`, without requiring a pathname walk;
- `open_tree()` without `OPEN_TREE_CLONE` can return an `O_PATH`-style descriptor, while `OPEN_TREE_CLONE` creates a detached mount object instead of merely giving the caller a byte-I/O handle;
- `open(2)` also documents nonstandard access mode `3`, which checks read/write permission and returns a descriptor that cannot be used for reading or writing, but can still be used for device-specific `ioctl(2)` operations.

The lesson for ViewFS is not “be POSIX” or “standardize Linux `O_PATH`.”
The lesson is: **do not let one nice-looking handle row collapse designation, metadata inspection, rooted walk, live byte I/O, and durable reopen/history into one thing.**

## Guardrail
ViewFS should keep these classes visibly separate:
1. **Locator / metadata handle** — current authority to point at an object or root and perform route/inspect/metadata operations without implying byte I/O.
2. **Live byte-I/O handle** — current authority to read, write, append, stream, or otherwise operate on bytes right now.
3. **Rights-escalation or reopen act** — an explicit step that mints a more operational handle (for example `open for read`, `reopen for write`, or `exec now`) rather than silently upgrading a locator.
4. **Durable ref / history** — a remembered designation, ref, or receipt describing how the object was reached or reopened previously.

## Consequences
We should be able to say things like:
- `locator only`
- `root/walk only`
- `metadata only`
- `read now`
- `append now`
- `needs reopen for write`
- `durable ref`
- `receipt only`

without laundering them into one fake “this handle is open” bit.

## Good answers might look like
- exact handle-class badges for current namespace entries and launch kits
- explicit `open for read` / `reopen for write` / `receipt only` route options
- import and bind surfaces that can carry inspect-only handles without pretending the pane already has byte I/O
- shell cards that explain `locator only` versus `readable now` versus `needs reopen`
- rooted-resolution lanes that can walk from a bound root without implying ambient read access to every object reached later

## What this does not decide
This RFC does **not** decide:
- a universal portable handle-class taxonomy for every future ViewFS object kind;
- whether every object kind in Phase 1 has a meaningful metadata-only / locator-only class;
- whether `exec now` is modeled as reopening, direct activation, or another lane entirely for every runtime;
- whether provider-local backends expose these classes directly or emulate them behind a more portable ViewFS contract.

## Shell implications worth stealing
A future custom shell/terminal should expose:
- **handle-class badges** that can say `locate`, `metadata`, `read`, `append`, `write`, `exec`, or `receipt`;
- **inspect-first cards** where portal selections and route sheets can stay useful before any byte-I/O grant is minted;
- **open-for-more-power ladders** that show when a locator is becoming a live read/write handle;
- **root badges** that tell the truth about `walk from here` versus `read object now`.

## Why this is a low-regret move
Even if SlopOS later changes its exact handle families, runtime shims, or durable-ref story, this split stays useful.
It is the kind of boundary that keeps object-store handles, per-process namespace assembly, portal-mediated imports, and shell chrome honest while the deeper design is still moving.
