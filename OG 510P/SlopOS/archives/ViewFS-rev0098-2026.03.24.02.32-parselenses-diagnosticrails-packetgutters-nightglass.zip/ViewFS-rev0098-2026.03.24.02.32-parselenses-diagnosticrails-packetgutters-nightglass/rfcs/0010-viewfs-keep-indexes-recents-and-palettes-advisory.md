# RFC-0010: Keep indexes, recents, and palettes advisory

## Status
Proposed.

## Problem
ViewFS is accumulating very attractive discovery surfaces:
- smart queries,
- recent items,
- searchable workflows,
- command palettes,
- notebook search,
- route sheets,
- transcript search.

Those surfaces are useful, but they risk collapsing into a hidden ambient-authority layer if “found in an index” starts to mean “may now open”.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat indexes, recent-item stores, palette rows, and other selector registries as **advisory surfaces**.
They may:
- point to live handles,
- point to durable refs,
- point to receipts,
- summarize search/query state,
- and help the user rebind or reopen.

They should **not** themselves count as canonical identity or bearer authority.

## Consequences
- palette/search UX can become dramatically better without weakening the model
- recent items can stay useful even when stale
- smart folders and saved queries can remain shell-owned manifests
- background indexing and extracted metadata can stay visibly subordinate to views, handles, refs, and receipts

## Non-goals
This RFC does not choose:
- a final index engine,
- a final search ranking algorithm,
- a final selector protocol,
- a final RecentHint/SelectorRow schema,
- or whether some narrow host-side discovery backstop is needed during bring-up.

## Adoption test
A future ViewFS proposal should answer:
- Is this thing an **index/selector/registry**, or is it a **live handle**, **durable ref**, **receipt**, or **name in a view**?
- Does this search/palette row preserve provenance and current status?
- Could a user tell why the row is actionable, stale, receipt-only, or portal-gated?
- If the row leads to authority, where is the explicit reopen/rebind/portal step?

If the answer is “the index found it, so the shell just opened it”, the burden of proof should be high.
