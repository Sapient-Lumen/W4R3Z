# RFC-0015: Keep origin, quarantine, safe-open, and trust transitions on separate seams

## Status
Proposed.

## Problem
ViewFS already distinguishes handles, refs, receipts, session state, registries, workspace trust, previews, watch feeds, and link-like objects.
Another easy collapse is to treat all risky-object handling as if it were one thing:

- origin metadata,
- quarantine / risk state,
- preview or safe-open lanes,
- explicit clear / trust decisions,
- sanitized export derivatives,
- or live execution/open authority.

History says that is a bad collapse. The useful precedents keep trying to separate these questions, and the failures happen when those seams get blurred.

## Proposal
For Phase 1 and nearby spikes, ViewFS should keep at least these classes distinct:
- origin evidence,
- quarantine/risk state,
- safe-open/preview session state,
- explicit clear/trust receipts,
- fresh derivative artifacts,
- and live open/exec authority.

Any proposal that collapses them should pay a high burden of proof.

## Consequences
- the shell can be delightfully informative without turning history into trust
- safe-open can stay useful without mutating the original object in place
- notebook/workspace UX can preserve browse-first / trust-later behavior
- future sanitized-export flows can mint new artifacts honestly
- SlopOS quarantine/safe-open seams can be specialized rather than bypassed

## Non-goals
This RFC does not choose:
- a final quarantine metadata schema,
- a final origin taxonomy,
- a final trusted-source policy,
- a final safe-open execution environment,
- or a final clear / sanitize receipt schema.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing **origin evidence**, **quarantine state**, **safe-open session state**, **trust/clear state**, **a derivative artifact**, or **live authority**?
- Does preview/open-safe mutate the source object?
- Is a trusted derivative being confused with the original object?
- What exactly survives into history, recents, and notebooks?
- If the object is code-bearing, does the proposal still default to a sharper gate than a simple preview?

If the answer is “it is convenient to treat these as basically the same thing,” the burden of proof should be high.
