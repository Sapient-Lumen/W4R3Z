# RFC-0032: Keep deny ceilings, narrowing, and scope eligibility separate

Status: Draft
Owner: archive
Created: 2026-03-22

## Summary
ViewFS should keep **deny ceilings**, **scope-eligibility rules**, **narrowing transforms**, **escalation attempts**, and **adoption receipts/history** on distinct seams.

## Why
Revision 031 made it clear that proposal origin and scope should be inspectable.
The next likely failure mode is letting a smart shell treat “something similar was allowed before” as permission to widen, persist, or work around a veto now.

This RFC says that must remain impossible by construction.

## Required split
Future proposals must classify whether they are changing:
1. authoritative deny ceilings,
2. authoritative scope-eligibility rules,
3. narrowing transforms,
4. pending escalation interactions,
5. or only durable adoption history.

## Consequences
- explicit deny ceilings win over remembered convenience;
- some proposal origins may be categorically non-widenable beyond narrow scopes;
- narrowing is a first-class successful outcome rather than a failed broad request;
- a shell may recommend narrower legal alternatives without becoming an authority;
- receipts must preserve both requested scope and effective scope.

## Non-goals
This RFC does **not** freeze:
- a final policy language,
- a final scope lattice,
- a final origin-class taxonomy,
- a final deny-code vocabulary,
- or a final serialized receipt schema.

## Near-term prototype
Prototype one flow only:
- proposer badge,
- ceiling pill,
- narrowing preview,
- scope fuse,
- adopt-narrowest-safe-rung,
- durable receipt.
