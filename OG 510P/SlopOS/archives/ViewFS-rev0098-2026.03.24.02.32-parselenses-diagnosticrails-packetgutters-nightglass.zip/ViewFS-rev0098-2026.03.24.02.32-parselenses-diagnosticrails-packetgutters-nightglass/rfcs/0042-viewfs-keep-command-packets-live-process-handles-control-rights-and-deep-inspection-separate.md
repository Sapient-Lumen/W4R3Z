# RFC 0042: Keep command packets, live process handles, control rights, and deep inspection separate

Status: draft guardrail RFC.

## Why this exists
ViewFS already separates transcript history, structured command packets, live handles, durable reopen, and explicit route plans.
A new design pressure is appearing around running commands:
- the shell wants command blocks to be first-class objects,
- supervisors may hold exact live process descriptors instead of only numeric PIDs,
- some process handles support lifecycle control such as wait/poll/signal,
- some stronger process handles can also expose deep inspection or descriptor-duplication power,
- and none of that should collapse into one fuzzy "running command" story.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design.

## Distinct truths

### 1. Command packet / launch request
Question:
- what exact command, launch pack, or reviewed execution request was prepared?

Examples:
- a command packet
- a launch-kit entry
- a reviewed execution-plan card
- a transcript-promoted exact command block

### 2. Live process handle / running command instance
Question:
- what exact currently running process or command instance exists right now?

Examples:
- a process descriptor
- a live supervisor-owned process ref
- a running command card bound to one current child instance

### 3. Lifecycle-control rights
Question:
- what exact actions are allowed against that live process instance?

Examples:
- wait / poll for exit
- graceful interrupt / cancel
- force terminate / signal
- attach-to-output or completion observation

### 4. Deep inspection or namespace-follow authority
Question:
- what stronger powers, if any, exist to inspect or enter the process's current state?

Examples:
- debugger / peer-inspection handles
- duplicate-another-fd authority
- namespace-follow / enter authority
- memory / register / procfs-introspection lanes

### 5. Transcript / history artifacts
Question:
- what durable or transcript artifact records that one of the above happened?

Examples:
- transcript rows
- result receipts
- exit cards
- route-plan receipts
- history-only command packets

## Guardrail
A shell should be allowed to make live commands much more legible.
It must not silently pretend that:
- a command packet is a live process handle,
- a live process handle automatically includes deep inspection,
- a lifecycle-control affordance implies namespace-entry or fd-duplication power,
- or a history row still carries current process authority.

## Implications for ViewFS
- the custom shell should prefer exact running-command objects over numeric-PID folklore or transcript scraping;
- a live process card should badge whether it is `history only`, `observe only`, `waitable`, `interruptible`, `terminable`, or `deep inspect available`;
- prepared command packets should remain useful after exit without pretending to be current live control;
- deep inspection / debugger / namespace-follow powers should return as separate lanes instead of hiding inside ordinary command cards;
- review and replay flows should begin from command packets or receipts, not by reusing stale process handles.

## Non-decisions
This RFC does **not** decide:
- whether ViewFS uses pidfds, process descriptors, supervisor-local IDs, or another implementation primitive;
- whether lifecycle control and deep inspection are carried by one primitive or several narrower ones;
- whether any live process handle can cross reboot, machine, or user boundaries;
- whether attach/debug/inspection flows are owned by the shell, a supervisor, or another service.

## Shell consequences
The custom shell+terminal should be allowed to grow:
- live process cards attached to command blocks,
- exact wait / stop / inspect affordances with truth badges,
- running-versus-history drawers,
- and process-aware route sheets,
without claiming more than the current handle class actually supports.
