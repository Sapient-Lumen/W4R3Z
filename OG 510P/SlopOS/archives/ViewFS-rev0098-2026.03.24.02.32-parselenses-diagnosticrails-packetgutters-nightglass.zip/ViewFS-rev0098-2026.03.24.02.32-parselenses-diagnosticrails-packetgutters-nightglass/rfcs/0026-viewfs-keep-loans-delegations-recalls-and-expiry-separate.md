# RFC-0026: Keep loans, delegated refs, recalls, and expiry separate

## Status
Proposed.

## Problem
ViewFS already tries not to collapse imports into live binds, plans into executions, or suggested automation into user-owned workflow truth.
A fresh collapse risk is now visible in any shell or portal flow that temporarily shares authority:

- a request to borrow or lend,
- a live attenuated borrowed handle,
- a durable delegated or reopenable reference,
- issuer-side recall/expiry control,
- and the receipt/history of how a loan ended

can drift toward “one shared handle object”.

That would be a mistake.
It would hide whether authority is live now or only reopenable later, blur issuer-versus-borrower powers, make expiry and deletion indistinguishable, and let a successful one-off run quietly become standing ambient access.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat the following as distinct classes:

- **LoanRequest** / a request or prepared ask to borrow authority,
- **BorrowedHandleSet** / live current attenuated authority usable by a process, pane, or run,
- **DelegatedRef** / durable or semi-durable descriptor that may later reopen or re-consent,
- **RecallControl** / issuer-side power to revoke, shorten, or deny renewal,
- and **LoanEndReceipt** / durable history explaining relinquish, recall, expiry, denial, drift, or disappearance.

The default reading should be:
- a request is not yet a loan,
- a live loan is not a durable delegated ref,
- issuer recall power is not the same thing as borrower access,
- expiry/recall is not deletion,
- and promotion from temporary borrow to durable reopen/delegation is explicit.

## Consequences
- child-launch and cross-pane sharing can default to bounded loans instead of silently durable persistence
- the shell can offer `lend for this run` and `lend until pane closes` without pretending those are forever
- receipts can distinguish `relinquished`, `recalled`, `expired`, `basis drift`, and `missing source`
- durable reopen/delegation can remain a visible promotion step instead of an accidental side effect of success once
- grouped authority can stay inspectable even when temporarily shared

## Non-goals
This RFC does not choose:
- a final `BorrowedHandleSet`, `DelegatedRef`, or `RecallControl` schema,
- whether all loans share one substrate primitive,
- exact TTL/expiry encoding,
- whether recall is universal or optional in every profile,
- or final shell syntax for `lend`, `renew`, `promote`, or `recall`.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing a **lend request**, a live **borrowed authority** class, a **durable delegated ref**, an issuer-side **recall/expiry control**, or only **history/receipt**?
- Can the shell say whether authority is live now, only durable for later, expiring soon, or already gone?
- Does promotion from ephemeral borrow to durable delegation require an explicit act?
- Are borrower-visible powers and issuer-side recall powers distinct?
- When a loan ends, can the transcript say *why*?

If the answer is “for convenience these are basically the same object,” the burden of proof should be high.
