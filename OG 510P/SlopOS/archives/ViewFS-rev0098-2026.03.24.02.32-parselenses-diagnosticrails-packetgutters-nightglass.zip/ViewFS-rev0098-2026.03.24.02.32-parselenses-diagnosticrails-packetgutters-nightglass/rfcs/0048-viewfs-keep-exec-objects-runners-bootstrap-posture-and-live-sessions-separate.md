# RFC 0048: Keep exec objects, runners, bootstrap posture, and live sessions separate

## Status
Accepted for design-phase guardrails.

## Why this exists
ViewFS already keeps:
- exact exec objects separate from startup credentials,
- startup code closure separate from loader debt and late imports,
- and live process handles separate from terminal stream / foreground-turn posture.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design:

**the exact thing selected to run, the runner/runtime that gets to host it, the startup/bootstrap posture around it, the resulting live session, and durable history are different classes.**

That matters immediately if the future shell wants to be honest about:
- whether a launch is `native`, `web`, `wasi`, `interpreter`, `container-ish`, or another explicit runner family,
- whether the runner came from the current environment/launch kit or from some compat fallback,
- whether startup is `clean`, `explicit customization bundle`, or carrying startup-hook / profile debt,
- whether the result is an interactive live session, a detached service/helper, or only a receipt/history row,
- and whether lifecycle controls belong to the runner/session layer rather than to object identity.

## Lessons from the past
Fuchsia already separates these layers on purpose:
- runner capabilities are registered to an environment;
- a component's `program` section selects a runner and runner-specific options;
- component manager sends `ComponentStartInfo` to the selected runner, including the executable and namespace;
- and lifecycle control after start runs through the runner/controller channel.

OCI makes the same broader point in a different vocabulary:
- runtime config has a root filesystem section,
- a separate process section with terminal / args / env / cwd / user,
- and additional sandboxing/runtime features such as capabilities, labels, rlimits, scheduler, and hooks.

The lesson for ViewFS is not “copy Fuchsia” or “become OCI.”
The lesson is: **do not let one launch row collapse executable identity, hosting runner, bootstrap policy, and live session truth into one thing.**

## Guardrail
ViewFS should keep these classes visibly separate:
1. **Exec object / script input** — the exact artifact or exact staged bytes selected to run.
2. **Runner/runtime** — the explicit host/runtime family that will interpret or host that object.
3. **Bootstrap posture** — whether startup is clean, explicit-bundle-driven, or carrying compat/startup-hook debt.
4. **Live session** — the resulting running subject/service/interactive session.
5. **Receipt/history** — durable records about what happened.

## Consequences
We should be able to say things like:
- `exec exact`
- `runner=native`
- `runner=wasi`
- `runner debt`
- `bootstrap clean`
- `startup-hook debt`
- `interactive live`
- `detached helper`
- `history only`

without laundering them into one fake “ran command” bit.

## Good answers might look like
- exact exec-object handles or exact staged-byte objects
- explicit runner/runtime descriptors
- bootstrap/startup-profile posture descriptors
- live session handles/cards
- launch and lifecycle receipts

## What this does not decide
This RFC does **not** decide:
- the final runner taxonomy for ViewFS or SlopOS;
- whether runner choice is fully portable or partly provider-local in Phase 1;
- whether bootstrap posture is represented as explicit bundles, shutters, or another review surface;
- whether one runner can host several session kinds with one shared controller shape.

## Shell implications worth stealing
A future custom shell/terminal should expose:
- **runner badges** on launch-review cards and command blocks;
- **bootstrap shutters** that say whether startup was clean, explicitly customized, or carrying compat debt;
- **session-kind pills** such as `interactive`, `batch`, `detached helper`, or `receipt only`;
- **clear runner/session diffs** so replay can explain what changed without pretending the executable object changed.

## Why this is a low-regret move
Even if SlopOS later changes its exact launch kits, component model, or service/runtime structure, this split stays useful.
It is the kind of boundary that keeps launch review and shell chrome honest while the deeper implementation is still moving.
