# RFC 0059: Keep non-authoritative designators, authority-bearing tickets, local aliases, live handles, and receipts separate

Status: exploratory

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports.
After separating remembered designators, revival designators, and transfer/adoption lanes, there is one more class boundary worth freezing early:

- a **non-authoritative designator** (`this is how I refer to it in notes / recents / palettes / digests / route sheets`)
- an **authority-bearing ticket** (`possession may let me reopen, recontact, or fetch authority later`)
- a **local alias or bind** (`this pane/process currently names it here`)
- a **live handle / current authority**
- and a **durable receipt/history row**

should stay visibly different.

This matters while SlopOS is still in design because the easiest mistake now would be to let one convenient pasteable token become all of: designation, revival authority, current placement, and history.

## The separation

Keep these classes separate:

- designation-only labels, recents rows, digest cards, route targets, and human-stable references
- authority-bearing tickets for later reopen / recontact / fetch
- local aliases or binds inside one current view
- live handles or currently held authority
- durable receipts/history

Do **not** flatten them into one vague story like “this bookmark/open token/URL is the file”.

## Historical lesson

A lot of useful systems make the danger visible once you look closely.

Capability URLs are convenient precisely because the URL itself grants access, which is also why standards guidance warns that URLs are not generally secret-bearing containers and may leak.
OCapN sturdyref locators are even sharper: the locator includes enough information to obtain a CapTP reference and the draft spec explicitly says the sturdyref should be considered a capability.
Apple security-scoped bookmarks are a strong desktop caution: persistent access across relaunch is useful, but validation/storage semantics become security-critical the moment the bookmark itself can recover access later.
The XDG document portal points the safer way for routine desktop use: the portal projects a restricted local view and keeps document-store IDs/permissions under a mediator instead of encouraging raw bearer-ish paste tokens everywhere.

ViewFS should steal the separations, not the accidental folklore.

## ViewFS rule

ViewFS should preserve distinct lanes for:

1. designation-only references suitable for transcript text, palette entries, notes, search hits, receipts, and share-without-authority UI;
2. authority-bearing tickets that are explicitly marked as such and are never silently treated as ordinary notes/links;
3. local alias/bind facts that describe where something is named in one current pane/process view;
4. live handles that represent current authority right now;
5. receipt/history artifacts that describe what happened without reviving authority merely by being inspected.

## Why this helps ViewFS

- It stops a copied note/URI/title/digest from silently becoming a bearer token.
- It stops a durable reopen/ref story from pretending to be an inert label.
- It lets the shell show `designation only`, `ticket`, `bound here`, `live now`, or `receipt only` as different truths.
- It preserves freedom about whether Phase 1 durable reopen is local-only, wallet-held, mediator-held, or mostly deferred.
- It gives ViewFS a principled way to steal from capability URLs, sturdyrefs, bookmarks, portals, and wallets without inheriting their most confusing UI habits.

## Shell consequences

A future ViewFS shell should be able to render:

- `designation only`
- `authority-bearing ticket`
- `ticket requires revalidation`
- `bound in this pane`
- `live handle present`
- `receipt/history only`

as visibly different classes.

The default paste/open behavior should be conservative:
- ordinary text paste stays inert,
- typed route sheets may inspect or store a designation,
- revealing a ticket’s authority should be an explicit action,
- and adopting/binding the result into the current pane should be a later explicit action again.

## What this does not decide

This RFC intentionally does **not** decide:

- whether ViewFS Phase 1 exposes any authority-bearing ticket directly to users,
- whether durable reopen is mediator-held, wallet-held, or provider-held,
- whether human-facing designators are digest-first, title-first, or mixed,
- whether some authority-bearing tickets can ever cross machines or trust domains,
- whether any authority-bearing ticket is stable enough to be user-copyable by default.

## SlopOS alignment

This separation fits SlopOS well because SlopOS already has nearby but distinct draft seams for:
- document portal + durable file handles,
- capability wallets that are explicitly descriptive rather than authoritative,
- plumb/intent envelopes that route actions without being bearer authority by themselves,
- and optional CapStore / sturdyref persistence that is powerful enough to stay scary and explicit.

ViewFS can therefore borrow the *shape* of designation-versus-authority now, while leaving ticket format, wallet posture, and durable reopen breadth open longer.

