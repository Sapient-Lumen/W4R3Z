# RFC 0049: Keep handle slots, live handle copies, shared open state, and independent reopens separate

## Status
Accepted for design-phase guardrails.

## Why this exists
ViewFS already keeps:
- exact child handle-table population separate from ambient inheritance,
- live handle copies separate from durable object identity,
- and durable reopen separate from mere recents/history.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design:

**a child handle slot, a live handle copy, the shared open-state group that copy may alias, an independent reopen, and durable history are different classes.**

That matters immediately if the future shell wants to be honest about:
- whether slot `7` is just another local name for the same live cursor/append/lock state as slot `4`,
- whether a transferred handle from another process is a copy of that same live open state or a fresh reopen,
- whether a `reopen independently` action is narrowing authority or merely duplicating the same mutable I/O state,
- and whether history/receipts are only describing a past sharing decision instead of reviving it.

## Lessons from the past
Classic UNIX open-file-description semantics already make this split unavoidable:
- `open()` creates a new **open file description** that records file offset and file status flags;
- `dup()` creates a new file descriptor that refers to the **same** open file description and therefore shares offset and status flags;
- `SCM_RIGHTS` over UNIX-domain sockets is more accurately described as passing a reference to the same open file description into another process;
- `pidfd_getfd()` duplicates another process's file descriptor into the caller while still referring to the same open file description;
- `flock()` locks are associated with the open file description, so duplicate descriptors share and release the same lock.

The lesson for ViewFS is not “be POSIX” or “expose Linux file descriptors everywhere.”
The lesson is: **do not let one nice-looking handle row collapse slot numbering, live aliasing, shared cursor/lock state, fresh reopen, and history into one thing.**

## Guardrail
ViewFS should keep these classes visibly separate:
1. **Handle slot / local binding** — the per-process or per-pane slot/name used in one current namespace or handle table.
2. **Live handle copy / alias** — another current reference to a live thing.
3. **Shared open-state group** — the mutable read/write cursor, status flags, lock/lease state, or similar live I/O posture that several current handles may alias.
4. **Independent reopen** — a fresh handle to the same underlying object with independent cursor/state.
5. **Receipt/history** — durable records about sharing, duplication, lending, or reopening.

## Consequences
We should be able to say things like:
- `slot=7`
- `same live open-state as slot=4`
- `shared cursor`
- `shared lock/lease`
- `fresh reopen`
- `receipt only`

without laundering them into one fake “this is the file” bit.

## Good answers might look like
- exact slot/binding descriptors for current namespace assembly
- explicit `duplicate current live handle` versus `reopen independently` actions
- local-only open-state-group witness IDs or twin badges
- receipts that say whether a courier/import preserved live aliasing or minted a fresh reopen
- shell cards that can explain `same object, same live cursor` versus `same object, independent cursor`

## What this does not decide
This RFC does **not** decide:
- a universal portable open-state taxonomy for every future ViewFS object kind;
- whether every ViewFS handle family even has cursor/lock/lease semantics in Phase 1;
- whether cross-process lending of live handles is available everywhere or remains provider-local in Phase 1;
- whether independent reopen always exists for every imported/borrowed object kind.

## Shell implications worth stealing
A future custom shell/terminal should expose:
- **twin-handle badges** that can say `same live cursor`, `shared append`, or `fresh reopen`;
- **duplicate-versus-reopen ladders** instead of one ambiguous copy button;
- **shared-open-state drawers** that show which panes or children currently alias one live stream/cursor/lock state;
- **reopen independently** as a first-class safe action when the user wants the same object without the same mutable I/O posture.

## Why this is a low-regret move
Even if SlopOS later changes its exact handle families, document refs, or launch kits, this split stays useful.
It is the kind of boundary that keeps handle transfer/import UX and shell chrome honest while the deeper object-store and runtime design is still moving.
