# RFC-0025: Keep suggestions, promoted recipes, and run history separate

## Status
Proposed.

## Problem
ViewFS already tries not to collapse session memory into live authority, and it now keeps intent/plan/approval/result classes distinct.
A fresh collapse risk is visible in the shell and automation layers:

- **externally suggested automation** from workspaces, receipts, shared notebooks, or route rules,
- **promoted user-owned recipes/workflows**,
- **exact prepared run plans** compiled against current state,
- **committed runs**,
- and **result/history artifacts**

can all drift toward “one saved workflow object”.

That would be a mistake.
It would let repositories and shared playbooks quietly rewrite the user’s automation vocabulary, hide source drift, make replay lie about what is current, and turn historical success into disguised standing trust.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat the following as distinct classes:

- **SuggestedRecipe** / externally sourced reusable automation idea,
- **PromotionReceipt** / proof that a suggestion was copied or adopted under explicit choices,
- **UserWorkflow** / user-owned reusable recipe,
- **PreparedRunPlan** / one exact current-state realization of a suggestion or workflow,
- **RunRecord** / the in-flight committed run,
- and **RunReceipt** / durable history of what actually happened.

The default reading should be:
- suggestion is not yet mine,
- promotion is not inheritance,
- saved recipe is not yet prepared plan,
- prepared plan is not standing approval,
- run history is not live authority,
- and notebooks/playbooks are not hidden grant containers.

## Consequences
- workspace-suggested or receipt-derived automation can stay inspectable before trust or adoption
- users can promote useful automation into their own workflow space without following upstream silently
- source drift can become a first-class `reinspect` / `re-promote` state
- replay can begin from a fresh prepared plan instead of pretending an old successful run is current truth
- notebook and workflow export can stay useful without becoming disguised capability export

## Non-goals
This RFC does not choose:
- a final `SuggestedRecipe`, `UserWorkflow`, or notebook-cell schema,
- whether promoted workflows live in one or many stores,
- whether source-following workflows ever exist as a distinct opt-in class,
- how sync/sharing/team workflows work,
- or final shell syntax for `promote`, `prepare`, `run once`, or `re-promote`.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing a **suggestion source**, a **promotion** act, a **user-owned workflow**, a **prepared plan**, a live **run**, or only **history/receipt**?
- Can the shell say whether a workflow is still source-derived, already promoted, or changed upstream?
- Does replay start from fresh planning against current state?
- Does a notebook or workflow export stay class-aware instead of serializing live authority?
- If source drift exists, is reinspection/re-promotion explicit instead of automatic?

If the answer is “for convenience they are basically the same object,” the burden of proof should be high.
