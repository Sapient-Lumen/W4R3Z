# RFC 0058: Keep transfer offers, live handle copies, revival designators, adopted binds, and receipts separate

Status: exploratory

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports. As that picture gets sharper, one more seam becomes worth freezing early:

- a **transfer offer or courier event** (`I can send this now`, `these representations are available`, `this lane carried something`)
- a **live handle copy / attenuated current authority** that is usable right now
- a **revival designator** for later reconnect/reopen/revalidation
- an **adopted local bind/slot** in the receiver's current namespace or handle table
- and a **durable receipt/history row**

should stay visibly different.

That lesson matters while SlopOS is still in design because it lets ViewFS freeze a separation early **without** freezing one universal handoff substrate, one hidden peer-transfer trick, or one durable-capability-ticket story too early.

## The separation
Keep these classes separate:
- transfer/courier offers
- accepted transfer mode / representation choice
- live current handle copies, including attenuated copies
- revival designators for later reconnect/reopen
- local adoption/binding into one receiving pane/process view
- and durable receipts/history rows

Do **not** flatten them into one vague story like “I shared the file”.

## Historical lesson
The best precedents all separate **offer**, **current authority**, **later revival**, and **local adoption**.

Wayland data transfer uses a `wl_data_source` and `wl_data_offer`; supported MIME types are advertised first, and the receiver explicitly requests one representation and provides a file descriptor for transfer later. `SCM_RIGHTS` in UNIX domain sockets is even sharper: what is passed is effectively another reference to the same open file description, not a fresh reopen or a durable token. Fuchsia handles make duplication and transfer explicit, and rights can be dropped during duplication/transfer rather than widened. systemd's fdstore is useful as a cautionary comparison: exact-handle continuity can be real and valuable, but it remains intentionally narrow and manager-mediated. Security-scoped bookmark history is the other cautionary side of the lesson: persistent re-open machinery is powerful enough that its validation and storage semantics become security-critical.

That is exactly the low-regret shape ViewFS should steal.

## ViewFS rule
ViewFS should preserve distinct lanes for:
1. surfacing one transfer/courier offer or lane witness,
2. explicitly choosing whether the result is bytes, a live copied handle, a narrowed/attenuated live copy, or a revival designator,
3. separately deciding whether the receiver merely stores/notes that thing or actually adopts it into a current local bind/slot,
4. separately surfacing issuer/source/courier witness information,
5. separately recording a receipt/history row about offer, send, receive, adopt, reject, narrow, revalidate, or drop,
6. later inspecting those rows without turning them back into bearer authority.

## Why this helps ViewFS
- It stops `I offered/shared something` from smuggling itself into `the receiver has it bound now`.
- It stops `I copied a live handle` from smuggling itself into `I created a durable reopen designator`.
- It gives ViewFS room to support explicit peer handoff, explicit adoption, and later re-open/revalidation without pretending they are the same substrate.
- It lets shell UX say `offer only`, `accepted as bytes`, `live copy`, `attenuated live copy`, `stored designator`, `adopted here`, or `receipt only` as different truths.
- It preserves freedom about courier protocols, pipe/pipeline behavior, app handoff, drag/drop, cross-pane exchange, and durable restart/reopen while SlopOS and ViewFS are both still moving.

## What this does not decide
This RFC intentionally does **not** decide:
- whether ViewFS Phase 1 supports cross-pane/process live-handle transfer at all,
- whether adoption is shell-owned, launcher-owned, or provider-owned,
- whether revival designators are provider-local only or can ever cross machine/user boundaries,
- whether some transfers are bytes-only by policy,
- whether every handle family supports attenuation, transfer, or later revival,
- whether any future durable capability graph exists outside optional later profiles.

## Shell consequences
A future ViewFS shell should be able to show:
- `offer available`,
- `accepted representation=bytes`,
- `live alias`,
- `attenuated copy`,
- `stored for later revalidation`,
- `adopted into this pane`,
- `rejected`,
- and `receipt/history only`

as different truths.

It should also be able to render one handoff ladder that says:
`offer` → `choose representation` → `receive` → `adopt here`
without implying that any earlier step silently grants the later ones.

## SlopOS alignment
This separation fits SlopOS well because SlopOS already leans toward:
- no hidden peer-stage raw-handle passing in capshell pipelines,
- explicit remote-delegation import envelopes instead of ambient rediscovery,
- fresh-local-object-first bridges for routine document-style workflows,
- and manager-mediated exact continuity that is narrower than universal persistence.

ViewFS can therefore borrow the *shape* of explicit handoff-versus-adoption now, while leaving cross-stage transport, shell courier lanes, revival-designator breadth, and durable persistence stories open longer.
