# RFC 0054: Keep unnamed objects, namespace publication, and receipts separate

Status: exploratory

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports. Historical filesystems already contain one very useful anti-collapse lesson: an object can exist before it has a public name, and the act that publishes that object into a namespace is a separate step from creating or mutating the object itself.

That lesson matters while SlopOS is still in design because it lets ViewFS freeze a separation early **without** freezing a publication mechanism too early.

## The separation
Keep these classes separate:
- unnamed object / draft object state
- publication target / parent anchor
- publication act and collision posture
- resulting live bind / visible name in this namespace
- durable receipt / later history

Do **not** flatten them into one vague story like “saved file”.

## Historical lesson
Linux `O_TMPFILE` creates an unnamed file in a directory's filesystem. The object can be fully written and adjusted before it is linked into the namespace. `linkat(..., AT_EMPTY_PATH)` then turns that unnamed object into a named object when publication is desired. That means:
- object bytes can exist before a name exists,
- publication can be delayed,
- publication can be reviewable,
- and the later visible name is not the same thing as the object's earlier existence.

That is exactly the low-regret shape ViewFS should steal.

## ViewFS rule
ViewFS should preserve a distinct lane for:
1. create or receive an unnamed object,
2. inspect or mutate it while still unpublished,
3. select one publication anchor and one collision posture,
4. perform one receipted publication act,
5. later remember the publication as history without turning history into live authority.

## Why this helps ViewFS
- It keeps object identity separate from namespace naming.
- It keeps portal/import UX honest: `received bytes` is not yet `published in this pane`.
- It enables safer shell flows such as review-before-publish and publish-private-first.
- It avoids temp-file folklore where hidden names accidentally become ambient authority.

## What this does not decide
This RFC intentionally does **not** decide:
- whether unnamed objects live in RAM, on disk, or in a SlopOS CapStore-like substrate,
- whether publication happens through one kernel primitive, a user-space object-store transaction, or a higher-level namespace service,
- whether collision policies are universal across all backends,
- whether publication and live binding are the same act in every runtime.

## Shell consequences
A future ViewFS shell should be able to show:
- `draft object` or `unpublished object`,
- the candidate publication anchor,
- collision posture such as `new only` / `replace` / `exchange` where supported,
- the exact publication receipt,
- and the difference between `published name here` and `history only`.

## SlopOS alignment
This separation fits SlopOS well because SlopOS already prefers explicit handles, explicit views, and explicit mediators over ambient rediscovery. ViewFS can therefore borrow the *shape* of unnamed-then-published objects now, while leaving the eventual CapStore / View / Document-Portal mechanisms open longer.
