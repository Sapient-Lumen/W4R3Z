# RFC-0002: ViewFS decision freeze and spike plan

## Status
Draft

## Why this exists
ViewFS is being designed while SlopOS itself is still in design motion. That makes premature certainty especially expensive. This RFC records the decisions we should intentionally **not** make yet, and the short list of spikes that can answer the real risks.

## Decisions that stay open on purpose
The following are explicitly deferred until evidence exists:
- final on-disk pack format
- final hash algorithm
- mutable directory/in-place update semantics
- revocation mechanics for durable grants
- symlink/hardlink policy
- grouped capability bundle/container semantics
- saved-query object model
- final shell language syntax
- distributed sync/replication story

## Things we should decide early
We *should* keep these stable now:
1. object storage starts immutable-first
2. authority is expressed through handles with rights
3. per-process roots are explicit synthetic views
4. import/export/transfer happen through portals and receipts
5. path APIs are a compatibility membrane only

## Spikes worth doing soon

### Spike S1 — preopen compatibility membrane
Goal:
- prove that legacy path calls can be confined to explicit view roots.

Questions answered:
- what does `/work` actually map to?
- what are the exact failure-on-escape semantics?
- how much compatibility pressure appears immediately?

### Spike S2 — chooser/open/save/transfer receipt flow
Goal:
- prototype portal-mediated file open, save, and inter-app transfer with transcript-visible receipts.

Questions answered:
- what metadata belongs in a receipt?
- what durability knobs actually matter to users?
- can drag/drop and clipboard flows use the same model?

### Spike S3 — shell/terminal semantic block prototype
Goal:
- test a terminal that knows prompt/input/output boundaries, active view identity, and clickable receipts.

Questions answered:
- what metadata must the shell emit?
- how much safer do authority previews become?
- what transcript model feels natural?

### Spike S4 — mutable work-state sidecar
Goal:
- layer an explicit working journal/root-pointer update model over immutable objects.

Questions answered:
- do we need tree-level changesets, per-object journals, or manifest rebasing?
- how ugly is conflict handling?
- can the resulting state stay inspectable and replayable?

### Spike S5 — view-scoped query and smart-folder prototype
Goal:
- prove that search/smart-folder behavior can remain view-scoped and handle-returning.

Questions answered:
- what does a saved query object actually need?
- how much indexing is useful before it becomes a global oracle?
- what shell ownership model feels coherent?

## Explicit anti-spikes
Avoid spending early cycles on:
- full POSIX fidelity
- a new block allocator or journaling filesystem format
- cluster/distributed storage before local semantics are solid
- global search/index daemons
- shell syntax bikeshedding disconnected from authority UX

## Exit criteria
This RFC has done its job when future revisions can point to one or more spikes and say:
- *this decision remains open by policy*, or
- *this decision is now backed by evidence, so it can be promoted.*
