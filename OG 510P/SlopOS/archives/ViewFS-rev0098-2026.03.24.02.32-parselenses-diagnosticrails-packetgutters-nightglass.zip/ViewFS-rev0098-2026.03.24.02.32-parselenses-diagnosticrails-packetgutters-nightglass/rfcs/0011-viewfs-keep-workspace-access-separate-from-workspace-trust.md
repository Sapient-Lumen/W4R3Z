# RFC-0011: Keep workspace access separate from workspace automation trust

## Status
Proposed.

## Problem
ViewFS already distinguishes handles, refs, receipts, session state, and advisory registries.
A remaining temptation is to collapse **workspace access** into **workspace automation trust**.

That collapse is attractive because users often expect “open project” to mean:
- bind the folder,
- discover tasks,
- load env hooks,
- trust debug launchers,
- enable notebook execution,
- enable project agents/tools,
- and maybe restore old workflows.

But the historical lesson from modern developer tooling is that these are different trust decisions.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat:
- workspace/tree binding,
- workspace metadata parsing,
- workspace-defined automation,
- and user/global automation

as distinct classes.

Opening or rebinding a workspace should not automatically authorize workspace-defined automation.

## Consequences
- a workspace can open in a useful restricted/browse-only state
- tasks/debuggers/notebooks/env hooks can be inspected before they execute
- user-owned workflows can stay distinct from workspace-contributed automation
- trust invalidation can focus on automation-bearing surfaces rather than every file change
- shell UX can be exciting without hiding important trust transitions

## Non-goals
This RFC does not choose:
- a final trust-record schema,
- a final workspace-manifest format,
- a final set of automation classes,
- a final trusted-location policy,
- or a final rule for when parent/root trust is acceptable.

## Adoption test
A future ViewFS proposal should answer:
- Is this about **workspace access**, **workspace metadata**, **workspace automation**, or **user/global automation**?
- Can the workspace be bound and browsed safely before any automation runs?
- What exact automation classes become enabled, and how is that shown to the user?
- What change would force re-approval?
- Does the shell preserve the difference between workspace-suggested actions and user-owned workflows?

If the answer is “opening the folder just enables all the project behavior,” the burden of proof should be high.
