# RFC-0039: Keep cancel, terminate, forget, reset, and rerun separate

Status: Draft  
Updated: 2026-03-22  
Decision family: deferred work / stop controls / shell ergonomics

## Summary
ViewFS should keep one more seam explicit while deferred-work shelling and helper tasking are still fluid:

**close/cancel request ≠ force terminate run ≠ detach/delete retained task state or result ≠ retry fresh request ≠ reset/fork from prior history ≠ durable receipt/history**

This keeps the shell free to stop, detach, forget, retry, fork, and reattach **without letting one vague “stop” or “try again” verb silently change remote work, retained results, or current authority in surprising ways**.

## Motivation
Revision 0038 froze the split between immediate request submission, accepted task wrappers, live progress, input-required checkpoints, final result retrieval, and durable history.

That still leaves a dangerous gap:
- a user may want to close an interaction without observing a final result,
- request graceful cancellation without force-killing,
- delete retained results without claiming the remote work stopped,
- retry fresh without reusing old state,
- or explicitly fork/reset from earlier basis rather than starting from scratch.

Current precedent makes this risk real:
- XDG Request.Close ends the interaction and emits no Response signal,
- Google long-running operations keep CancelOperation separate from DeleteOperation,
- MCP tasks keep cancellation asynchronous/best-effort and deletion separate,
- Temporal keeps cancellation, termination, reset, reuse, and conflict policies distinct,
- current shell/session tools already expose branching, parallel sessions, and checkpoint forks.

## Decision
For future ViewFS design work, proposals must classify whether they are changing:
1. **close/cancel acts** — ending or gracefully interrupting an interaction/run,
2. **force termination acts** — immediate stop without graceful cleanup,
3. **detach/delete acts** — dropping retained state, result lockers, or local interest without claiming the work stopped,
4. **retry fresh acts** — new attempts without prior run state,
5. **reset/fork/attach acts** — new or reused attempts that explicitly reference prior history or an existing live run,
6. **durable receipts/history** — what only records that one of those acts happened in the past.

## Consequences
### Positive
- gives ViewFS a clean way to say “I stopped watching” versus “I stopped the work”;
- preserves graceful-cancel versus force-kill honesty;
- creates room for great shell UX around retry, fork, and attach-to-existing without hidden run reuse;
- aligns with SlopOS mediator/effect-contract posture and with current deferred-work ecosystems.

### Costs
- one more family of stop/control objects to explain;
- richer receipts and shell chrome;
- more typed UI than a single vague stop/retry menu.

## Non-goals
- freezing the final stop-control schema for ViewFS,
- deciding whether every helper/provider must support all stop/control acts,
- deciding final retention or GC policy for lockers, task metadata, or receipts,
- deciding whether reset/fork is available in Phase 1 or only later experiments.

## Near-term prototype
Build one deferred-work shell flow with:
- stop ladder,
- detach rail,
- termination fuse,
- retry-vs-fork drawer,
- result-retention locker,
- stop receipt that preserves close/cancel/terminate/detach/retry/fork truth.

If that feels magical **and** honest, keep the seam. If it feels noisy, trim the UI before trimming the boundary.
