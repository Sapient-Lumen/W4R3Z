# RFC-0070: Keep advisory annotations, selector labels, policy labels, trusted badges, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates object identity from placement, current handle rights from advertised verbs, and type evidence from opener choice.
The next low-regret seam is **advisory annotation / selector label / policy-bearing label / trusted badge**.

A freeform note, provenance hint, or tool annotation is not the same thing as a label that participates in grouping and selection.
A selector label is not the same thing as a policy-bearing label that affects handling, routing, export, or access posture.
A policy-bearing label is not the same thing as one badge rendered in trusted shell chrome.
And none of those are the same thing as a durable receipt.

If we collapse those classes too early, we make at least five mistakes:

1. **descriptive notes start masquerading as query truth**
   - a freeform annotation or imported tag starts acting like something that selectors and smart collections may safely depend on.

2. **selector labels start masquerading as policy**
   - a grouping key such as `project=alpha` starts behaving like a handling boundary or authority cut even though it was never minted for that purpose.

3. **policy labels start masquerading as ordinary decoration**
   - a quarantine, handling, or sensitivity label gets buried among colorful chips and loses the stronger semantics it needs.

4. **trusted chrome starts masquerading as object metadata**
   - a tab badge or HUD chip set by the shell, portal, or provider starts being copied around as if it were intrinsic object truth.

5. **history starts masquerading as current labeling truth**
   - an old label snapshot or badge receipt starts acting like current selector state, current policy, or current chrome state.

## The seam

Keep these classes visibly distinct:

1. **advisory annotation / note / metadata blob**
   - arbitrary non-identifying metadata.
   - may be freeform, structured, provider-authored, user-authored, or tool-authored.
   - useful for explanation and provenance.
   - not inherently selector-safe and not inherently policy-bearing.

2. **selector label / grouping key**
   - compact metadata intended to support grouping, search, matching, or collection membership.
   - may drive selectors, saved queries, or smart baskets.
   - not by itself one access-control or handling rule.

3. **policy-bearing label / handling boundary**
   - a label that affects handling, export, review, quarantine, routing, or authorization posture.
   - examples: sensitivity/handling classes, quarantine state, MAC-style context, review-required state.
   - stronger than ordinary decoration and should be modeled as such.

4. **trusted badge / shell-owned chrome projection**
   - a shell, portal, or trusted helper projecting current state into badges, status bars, tab strips, drawers, or overlays.
   - may summarize annotations, selector labels, policy labels, or live state.
   - not itself the canonical source of object truth.

5. **receipt / history**
   - evidence that an annotation existed, a selector matched, a policy label was present, or a badge was rendered at one time.
   - useful for audit and explanation.
   - not current truth.

## Working posture

- ViewFS should allow rich advisory annotations without silently promoting them into selector semantics.
- ViewFS should allow selector labels to drive grouping and queries without silently promoting them into handling policy.
- ViewFS should keep policy-bearing labels explicit, inspectable, and harder to spoof than decorative labels.
- ViewFS should keep trusted chrome obviously shell-owned or mediator-owned so copied text, pasted labels, and screenshots do not masquerade as current authority or policy truth.
- ViewFS should keep receipts/history useful while refusing to let them silently revive current label state.

## What to steal

- **Kubernetes labels vs annotations**: labels are for identifying/selecting/grouping while annotations carry arbitrary non-identifying metadata.
- **OCI annotations**: arbitrary metadata is useful, but unknown keys must not explode consumers or silently become hard semantics.
- **SELinux security contexts**: some labels really are policy-bearing and live in a separate stronger lane.
- **TLP**: some labels define sharing boundaries but are still not a full control or classification system.
- **Steward trusted-chrome posture**: badges, titles, and status labels should remain provenance-labeled shell chrome rather than transcript or object truth.

## Shell consequences

The shell/terminal should gain:
- **label ledgers** that separate `annotation`, `selector`, `policy`, `shell badge`, and `history only` rows;
- **selector rails** that explain which compact labels are query-safe and which notes are just notes;
- **trusted badge shutters** so policy-bearing labels render in shell-owned chrome instead of getting lost among decorative chips;
- **why-this-badge drawers** that answer whether a visible label came from object metadata, provider state, local policy, or shell synthesis;
- **copy-as-text / copy-as-selector / copy-receipt** ladders so label-like things do not all paste with the same authority.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal label taxonomy for all ViewFS objects,
- whether selector labels are stored on objects, on placements, or in side indexes,
- whether policy-bearing labels are local-only, provider-owned, or hybrid,
- whether trusted badges are terminal-native, shell-native, or helper-native on every platform,
- whether all annotations are first-class queryable objects.

## Design bar

Before ViewFS standardizes richer label UX or metadata import/export flows, it should be able to answer:

1. Is this thing an advisory annotation, a selector label, a policy-bearing label, a trusted badge, or only a receipt?
2. Can the shell tell the user which labels are safe to use for grouping and which are merely descriptive?
3. Can policy-bearing labels stay explicit and strong without collapsing into decorative chrome?
4. Can trusted badges explain where their content came from without pretending to be canonical object truth?
5. Can old receipts stay useful for explanation without silently reviving current label state?
