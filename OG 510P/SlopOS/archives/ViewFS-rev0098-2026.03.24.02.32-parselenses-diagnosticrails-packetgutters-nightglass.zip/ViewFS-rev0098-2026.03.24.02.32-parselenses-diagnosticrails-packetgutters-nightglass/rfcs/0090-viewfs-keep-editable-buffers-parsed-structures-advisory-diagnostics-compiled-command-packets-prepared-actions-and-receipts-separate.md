# RFC-0090: Keep editable buffers, parsed structures, advisory diagnostics, compiled command packets, prepared actions, and receipts separate

Status: exploratory  
Date: 2026-03-24

## Why this exists

ViewFS already separates command suggestions from accepted insertions and compiled packets.
The next low-regret seam is **editable command text / parse-and-highlight structure / advisory diagnostics / bound packet / prepared action basis**.

A colorful buffer is not yet one parsed structure.
A parsed structure is not yet one diagnostic verdict.
Diagnostics are not yet one bound packet.
A compiled packet is not yet one prepared action.
And none of those are the same thing as one durable receipt.

If we collapse those classes too early, we make at least six mistakes:

1. **highlighting starts masquerading as authority**
   - a green-looking token starts acting like a granted/openable object or a runnable plan.

2. **parser recovery starts masquerading as exact intent**
   - a best-effort structure extracted from incomplete text starts acting like a stable command meaning.

3. **diagnostics start masquerading as enforcement**
   - lint, warnings, and hints start acting like current policy truth or approval state.

4. **compiled packets start masquerading as current readiness**
   - a bound packet starts acting like a launched or approved action before review/preflight is done.

5. **history starts masquerading as current parse or bind truth**
   - old packets or old diagnostics start acting like today's buffer meaning.

6. **shell delight starts depending on one parser forever**
   - the product quietly freezes around one parser/highlighter/linter instead of keeping that substrate swappable.

## The seam

Keep these classes visibly distinct:

1. **editable buffer**
   - the current mutable text/structured fragments under the cursor.
   - may still be incomplete, dirty, or mid-edit.

2. **parsed structure / highlight model**
   - best current structural understanding of the buffer.
   - may include token classes, grouping, recovered structure, or placeholder nodes.
   - not by itself one execution plan.

3. **advisory diagnostic**
   - warning, error, hint, lint, or note about the current buffer/parse.
   - may come from syntax checks, shell-specific rules, or helper analyzers.
   - not by itself one deny, grant, or approval state.

4. **compiled command packet**
   - parsed/bound interpretation of the current buffer against this pane's current objects, namespace, helper bindings, and receipts.
   - stronger than buffer text and stronger than parser color.
   - still not one approved or launched action by itself.

5. **prepared action**
   - one exact ready-for-review / ready-for-launch act after preflight and routing decisions.
   - may still be `approval needed`, `portal needed`, `rebind needed`, or `ready`.

6. **receipt / history**
   - evidence that one buffer existed, one parse/diagnostic state was shown, one packet was compiled, or one action ran.
   - not current authority.

## Working posture

- ViewFS should let the shell feel immediate with color, structure, and inline help without laundering any of that into current authority.
- ViewFS should keep parser/highlighter choice replaceable instead of making one parse tree the ontology of the system.
- ViewFS should keep diagnostics advisory unless they are explicitly promoted into some stronger gate elsewhere.
- ViewFS should keep compiled packets explainable in terms of current pane-local objects, receipts, and bindings.
- ViewFS should keep receipts/history descriptive rather than reviving old parse/bind truth.

## What to steal

- **tree-sitter**: incremental parse/update and robust structure even under syntax error are perfect precedents for shell-side structure that is useful before the line is finished.
- **LSP diagnostics**: diagnostics are a separate channel from text buffers and from completion/execute flows.
- **ShellCheck**: shell diagnostics can be very helpful while staying advisory and explanatory.
- **fish syntax highlighting**: fast inline feedback can stay immediate without implying execution or authority.

## Shell consequences

The shell/terminal should gain:
- **parse lenses** that show current structural understanding without pretending it is one final plan;
- **error-recovery veils** when the parser is guessing through incomplete text;
- **diagnostic rails** that can say `syntax`, `lint`, `hint`, `policy advice`, or `history-only` instead of one generic red squiggle;
- **packet gutters** that only appear once current pane-local binding/compile has happened;
- **prepared-action shutters** that keep compile truth separate from review/launch truth.

## Phase-1 non-decisions

This RFC does **not** decide:
- one final shell parser,
- one final highlighting token taxonomy,
- one final diagnostic engine or lint rule family,
- whether command packets are textual, structured, or mixed,
- whether helper analyzers run in-process, out-of-process, or on-demand.

## Design bar

Before ViewFS standardizes stronger shell parsing/diagnostic UX, it should be able to answer:

1. Is the shell showing raw editable text, parse/highlight structure, advisory diagnostics, a compiled packet, a prepared action, or only history?
2. Can parser recovery stay visibly weaker than exact current packet meaning?
3. Can diagnostics explain themselves without impersonating approval or enforcement?
4. Can the shell explain which current pane-local objects/bindings shaped a compiled packet?
5. Can history remain useful without silently becoming current parse or bind truth?
