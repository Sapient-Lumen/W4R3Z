# RFC 0057: Keep remembered designators, revalidation acts, continuity lockers, live handles, and receipts separate

Status: exploratory

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports. As that picture gets sharper, one more seam becomes worth freezing early:

- a **remembered designator** for later reopen (`docref`, bookmark-like designator, persisted URI-style designation, receipt pointer)
- a **revalidation or resolution act** that checks whether that remembered thing still maps to a usable target
- an **exact continuity locker** that preserves one already-live handle across a narrow restart boundary
- a **revived live handle or bind** that carries authority right now
- and a **durable receipt/history row**

should stay visibly different.

That lesson matters while SlopOS is still in design because it lets ViewFS freeze a separation early **without** freezing one universal persistence substrate, one reopen protocol, or one restart-continuity story too early.

## The separation
Keep these classes separate:
- remembered designators for later reopen
- explicit revalidation / resolution attempts
- optional exact continuity lockers that preserve a currently-live handle across a narrow manager-mediated restart boundary
- revived live handles or binds carrying current authority now
- stale / target-missing / grant-expired outcomes
- durable receipts / later history rows

Do **not** flatten them into one vague story like “it remembers the file”.

## Historical lesson
The best precedents all separate **remembered designation**, **fresh validation**, **current access**, and **narrow exact continuity**.

The XDG Documents portal proves present access with an open file descriptor, then separately returns a document-store `doc_id`, and even distinguishes session-only versus persistent entries. Android's Storage Access Framework likewise separates a stable document ID from the grant lifecycle, and explicitly warns that even persistable URI permission does not survive moves or deletion of the underlying document. Apple's security-scoped flows make the separation even sharper: bookmark data is for relaunch, bookmark resolution is a separate step, and `startAccessingSecurityScopedResource()` is another explicit step again for current access. systemd's fdstore shows a narrower but very valuable continuity seam: exact live file descriptors may be preserved across restart when explicitly enabled, but that is still not a general durable-authority graph.

That is exactly the low-regret shape ViewFS should steal.

## ViewFS rule
ViewFS should preserve distinct lanes for:
1. storing or remembering one designator for possible future reopen,
2. explicitly attempting to resolve / revalidate that remembered thing,
3. separately determining whether one exact continuity locker exists for a previously-live handle,
4. separately reviving or minting one current live handle/bind only when current authority is actually needed,
5. separately surfacing stale / moved / revoked / missing outcomes,
6. separately recording one receipt/history row about remember, resolve, revive, fail, or drop events,
7. later inspecting those rows without turning them back into bearer authority.

## Why this helps ViewFS
- It stops `remembered later` from smuggling itself into `live handle now`.
- It gives ViewFS room to support both designator-based reopen and narrow exact-handle restart continuity without pretending they are the same substrate.
- It lets shell UX say `remembered`, `needs revalidate`, `exact locker available`, `revived live handle`, `stale`, or `receipt only` as different truths.
- It preserves freedom about CapStore, manager-held lockers, portal docrefs, shell-visible bookmarks, and restart policies while SlopOS and ViewFS are both still moving.

## What this does not decide
This RFC intentionally does **not** decide:
- whether ViewFS Phase 1 exposes any user-visible remembered designator at all,
- whether exact continuity lockers are available in Phase 1 or only later,
- whether continuity lockers are manager-owned, provider-owned, or shell-mediated,
- whether remembered designators are minted only from local docrefs or can also point at other future ViewFS object classes,
- whether revalidation always requires user involvement when a target has drifted,
- whether broad durable capability graphs ever exist outside optional future profiles.

## Shell consequences
A future ViewFS shell should be able to show:
- `remembered designator`,
- `resolving/revalidating`,
- `exact locker available`,
- `revived live handle`,
- `stale or moved`,
- `grant needed`,
- and `receipt/history only`
as different truths.

It should also be able to render one continuity ladder that says:
`remember` → `revalidate` → `revive live handle` → `bind/publish here`
without implying that any earlier step silently grants the later ones.

## SlopOS alignment
This separation fits SlopOS well because SlopOS already keeps converging toward:
- explicit non-bearer document handles,
- optional durable/persistent profiles rather than mandatory ambient persistence,
- inbound-only activation continuity,
- and manager-mediated handle preservation that is intentionally narrower than universal persistence.

ViewFS can therefore borrow the *shape* of remembered-versus-live continuity now, while leaving CapStore breadth, restart semantics, namespace publication, and reopen routing open longer.
