# RFC-0024: Keep intents, route plans, approvals, and results separate

## Status
Proposed.

## Problem
ViewFS already tries not to collapse identity, naming, grants, binds, launch kits, and receipts.
A fresh collapse risk is now visible in the shell and portal layers:

- the **intent** a user or tool expresses,
- the **route/action plan** the system prepares,
- the **approval checkpoint** tied to exact mutable basis and exact authority deltas,
- the **committed execution** that runs,
- and the **result receipt/history** that survives afterward

can all drift toward “one action object”.

That would be a mistake.
It would make route sheets commit too early, make approvals float across mutable state, make replay lie about what is still possible, and turn historical receipts into disguised bearer authority.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat the following as distinct classes:

- **IntentRecord** / what the caller wants in broad terms,
- **RoutePlan** / one exact prepared realization of that intent,
- **ApprovalCheckpoint** / exact reviewed action basis and authority delta,
- **ExecutionRecord** / the in-flight committed act,
- and **ResultReceipt** / durable history of what actually happened.

The default reading should be:
- intent is not yet plan,
- plan is not yet approval,
- approval is not yet execution,
- execution is not yet success,
- and result history is not live authority.

## Consequences
- route sheets can stay inspectable instead of becoming hidden side-effect launchers
- approvals can stay bound to exact plans/actions rather than floating mutable targets
- restricted or inspect-only states can stay productive instead of looking like generic failures
- replay can begin from fresh planning instead of pretending historical success equals current authority
- SlopOS approval-basis, explain, denial, and outcome-receipt seams stay aligned instead of being replaced by one magical shell action model

## Non-goals
This RFC does not choose:
- a final `IntentRecord`, `RoutePlan`, or `ApprovalCheckpoint` schema,
- whether every action family shares one exact plan structure,
- the final taxonomy of result states,
- final shell syntax for `prepare`, `commit`, `approve`, or `reroute`,
- or whether harmless local inspections ever skip explicit plan cards.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing an **intent**, a **plan**, an **approval checkpoint**, a live **execution**, or only a **result/history** surface?
- Is approval bound to one exact action/plan digest, or is it drifting toward “whatever is current later”?
- Can the shell show the action in a restricted inspect-only state before commit?
- If replay exists, does it start from a fresh plan against current state?
- Does the result artifact remain receipt/history instead of reusable live authority?

If the answer is “for convenience they are basically the same object,” the burden of proof should be high.
