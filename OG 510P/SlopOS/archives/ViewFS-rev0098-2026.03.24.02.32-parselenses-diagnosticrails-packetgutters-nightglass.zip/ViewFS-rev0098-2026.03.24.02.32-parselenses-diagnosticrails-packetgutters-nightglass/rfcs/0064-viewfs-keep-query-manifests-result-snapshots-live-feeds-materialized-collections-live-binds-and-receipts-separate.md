# RFC-0064: Keep query manifests, result snapshots, live feeds, materialized collections, live binds, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

RFC-0019 already kept **query manifests**, **result snapshots**, and **live feeds** separate.
The next low-regret refinement is to keep all of those separate from any **materialized local collection** and from any **current bind of that collection into one pane or namespace**.

History keeps offering seductive query UX:
- Finder Smart Folders save criteria and auto-update their file list,
- `NSMetadataQuery` has an initial gather plus a live-update phase,
- Haiku queries can be live virtual objects,
- Windows saved searches store a query manifest that reopening re-runs,
- modern desktop search services can be portal-gated or sandbox-gated.

The trap is always the same:
- a saved recipe starts masquerading as one durable collection object,
- a current hit list starts masquerading as one exact frozen member set,
- and a live query surface starts masquerading as one live authority-bearing folder.

ViewFS should refuse that collapse.

## The seam

Keep these classes visibly distinct:

1. **query manifest**
   - one saved query recipe, explicit view binding, and presentation hints.
   - may be shell-owned and durable.
   - not by itself one current result set.

2. **result snapshot**
   - one evaluation result at one moment.
   - exact enough to diff, review, share, or compare.
   - not by itself a standing live subscription.

3. **live query feed**
   - one advisory stream of entered/left/changed events relative to a query/view pair.
   - may be paused, overflowed, degraded, or stale.
   - not by itself a frozen member set or a collection object.

4. **materialized local collection**
   - one local object that records an exact member set, possibly curated or edited after creation.
   - may be named, pinned, exported, diffed, or reopened later.
   - not the same thing as the query that produced it.

5. **live bind / current namespace placement**
   - one current placement of a materialized collection or query surface into this pane/view.
   - this is still current-local-state truth.
   - not the same thing as the collection object itself or the query recipe behind it.

6. **receipt / history**
   - evidence that a query ran, a snapshot froze, a basket/collection was minted, or a bind occurred.
   - not current authority.

## Working posture

- ViewFS should let saved smart queries feel first-class without pretending they are collection objects.
- ViewFS should make result snapshots easy to diff/share/promote without pretending they are live subscriptions.
- ViewFS should make live query feeds optional, bounded, and explicitly pauseable.
- ViewFS should treat “freeze this exact member set into a local basket/collection” as a separate act.
- ViewFS should treat “bind that collection here” as another separate act again.
- ViewFS should keep receipts/history descriptive instead of silently reviving any of the above.

## What to steal

- **Apple Smart Folders**: saved criteria can feel folder-like without being the files themselves.
- **Apple `NSMetadataQuery`**: initial gather and live updates are distinct, and pausing updates while inspecting results is a real product move.
- **Haiku queries**: a query can be a live virtual object with enter/leave notifications, which is powerful precisely because its liveness is explicit.
- **Windows saved searches**: a saved-search file can remain an inspectable recipe object instead of a hidden collection database.
- **GNOME LocalSearch + portals**: indexed discovery is useful, but sandboxed apps not having default access is an excellent reminder that search surfaces are their own authority seam.

## Shell consequences

The shell/terminal should gain:
- **freeze-set buttons** that explicitly mint a snapshot from a live query surface;
- **basket / materialize rails** that can turn one snapshot into one local collection object;
- **query-versus-basket badges** that can say `recipe`, `snapshot`, `live`, `materialized set`, `bound here`, or `history only`;
- **drift lenses** that compare `what matches now` versus `what this basket captured then`;
- **adopt-here shutters** that answer whether this pane is viewing one live query surface, one materialized collection, or only one receipt.

## Phase-1 non-decisions

This RFC does **not** decide:
- whether the eventual materialized collection object is folder-shaped, manifest-shaped, set-shaped, or basket-shaped,
- whether collection objects are editable by membership or always rebuilt from a new snapshot,
- whether live query feeds are daemon-backed, portal-backed, provider-backed, or mostly shell-owned,
- whether one collection object has any stronger reopen or sharing powers than an ordinary snapshot receipt,
- whether smart queries are user-global, workspace-local, pane-local, or some mix.

## Design bar

Before ViewFS standardizes any stronger smart-folder / saved-set model, it should be able to answer:

1. Is the shell showing a recipe, a current snapshot, a live update stream, a materialized collection object, one current bind, or only history?
2. Can the user freeze the exact current member set without silently subscribing to future change?
3. Can the user materialize a local collection object without pretending that the old query recipe is the same thing?
4. Can the user compare `matches now` versus `captured then` without the shell guessing?
5. Can one old query success remain useful for explanation without silently counting as current local bind or current authority?
