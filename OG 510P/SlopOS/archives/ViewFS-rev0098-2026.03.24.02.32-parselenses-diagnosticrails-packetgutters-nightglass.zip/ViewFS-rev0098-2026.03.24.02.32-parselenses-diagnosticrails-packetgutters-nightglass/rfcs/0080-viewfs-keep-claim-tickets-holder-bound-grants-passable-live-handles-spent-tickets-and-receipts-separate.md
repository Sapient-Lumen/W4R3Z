# RFC 0080: Keep claim tickets, holder-bound grants, passable live handles, spent tickets, and receipts separate

Status: exploratory

## Why this exists

ViewFS already keeps **designation**, **provider-ready claims**, **local realization**, and **current live handles** more honest than mainstream path folklore.
The next easy collapse is inside the broad bucket of `authority-bearing ticket` itself:

- a **redeemable or claim-style ticket** that can mint or recover stronger authority later,
- a **holder-bound grant** that only works for the current proving holder/session/key,
- a **passable live handle** that can actually be copied or handed off now,
- a **spent or consumed ticket** that should no longer redeem,
- and a **durable receipt/history row**

should stay visibly different.

That split is worth freezing now while SlopOS is still deciding deeper CapStore, portal, and continuity details.

## The separation

Keep these classes separate:
- redeemable claim tickets that can be presented to mint or recover stronger authority later;
- holder-bound grants that require the current holder/session/key/proof rather than behaving like replayable bearer material;
- passable live handles that may actually be copied, inherited, or couriered to another process now;
- spent, consumed, withdrawn, or expired claim artifacts that remain inspectable but should not redeem again;
- durable receipts/history describing when claim, redemption, spend, refusal, or expiry happened.

Do **not** flatten them into one vague story like `token`, `ticket`, or `handle`.

## Historical lesson

Several useful systems already warn against this collapse:
- OAuth authorization codes are short-lived, single-use, and bound to a client/redirection context; they are not durable bearer handles.
- DPoP makes a sharper point by sender-constraining issued tokens to possession of a key pair instead of treating them as freely replayable bearer material.
- Android PendingIntent guidance explicitly warns that replay is a risk unless one-shot posture is used for actions that should only happen once.
- XDG portal Request and Session objects also help: a request handle or session handle is a mediator-owned live interaction/session object, not a generic durable capability blob.
- Steward's companion design work now also distinguishes compact **consumable grants** and **holder-bound grants**, which is a good sign that this is a low-regret seam rather than premature complexity.

## ViewFS rule

ViewFS should preserve distinct lanes for:
1. claim/redeem tickets,
2. holder-bound grants,
3. passable live handles,
4. spent/expired/withdrawn tickets,
5. durable receipts/history,
6. later local publication/binding of any resulting live handle,
7. later local realization or provider-backed locality truth, which still remains a separate question.

## Why this helps ViewFS

- It stops a redeemable claim from masquerading as a live handle already held now.
- It stops holder-bound proof requirements from vanishing into replayable bearer folklore.
- It gives the shell a truthful way to say `redeemable`, `holder proof needed`, `passable now`, `spent`, or `history only`.
- It keeps room for SlopOS to settle portal/import and continuity machinery later without forcing ViewFS to pretend all authority artifacts are the same class.
- It makes one-shot, burn-after-use, and anti-replay UX possible without committing to a universal token wallet design.

## What this does not decide

This RFC intentionally does **not** decide:
- whether claim tickets are ever user-copyable by default;
- whether holder-bound proof is key-based, session-based, issuer-badged, or a smaller local proof family;
- whether some grants can switch from holder-bound to passable under explicit re-issuance;
- whether spent tickets remain visible forever or are eventually compacted into thinner receipts;
- whether the object store itself keeps any redeemable artifacts or whether a portal/mediator owns them all.

## Shell consequences

A future ViewFS shell should be able to show:
- `claim ticket`,
- `redeemable once`,
- `holder proof needed`,
- `live handle passable now`,
- `spent`,
- `expired`,
- and `receipt/history only`

as visibly different truths.

It should also be able to render one honest ladder that says:
`inspect claim` → `redeem here` → `prove holder if needed` → `obtain live handle` → `publish/bind here or hand off`
without implying that any earlier row already granted the later powers.

## SlopOS alignment

This separation fits SlopOS well because SlopOS already pushes imported DPoP/PKCE/auth-material toward provider-local binding rather than portable bearer folklore, and Steward is exploring compact consumable-grant and holder-bound-grant posture nearby.
ViewFS can therefore borrow the *shape* of one-shot-versus-holder-bound-versus-passable authority now while leaving ticket format, proof method, and CapStore persistence breadth open longer.
