# RFC 0051: Keep current handles, launch inheritance, child slots, and launch receipts separate

## Status
Accepted for design-phase guardrails.

## Why this exists
ViewFS already keeps:
- current slot/local binding separate from shared open state,
- locator handles separate from live byte-I/O handles,
- and launch kits separate from durable history.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design:

**a handle currently held in one pane/process, the policy for whether it may cross a launch boundary, the exact slot/name delivered to a child, and the durable launch receipt/history artifact are different classes.**

That matters immediately if the future shell wants to be honest about:
- whether the current pane merely holds a live handle right now,
- whether that handle is barred from launch inheritance unless explicitly reviewed,
- whether a reviewed child launch receives a copy in one exact activation slot or fd position,
- and whether a durable receipt is only describing the launch decision rather than reviving child authority later.

## Lessons from the past
Classic UNIX/POSIX already make this split unavoidable:
- `exec` keeps file descriptors open in the new process image unless `FD_CLOEXEC` is set, and the descriptors that remain open preserve the attributes of the same open file description;
- `open(2)` documents `O_CLOEXEC` as essential in multithreaded programs because a separate `fcntl(..., F_SETFD, FD_CLOEXEC)` step races with another thread doing `fork()+execve()`;
- `posix_spawn()` follows ordinary exec semantics unless explicit file actions are supplied, so inherited descriptors are still a separate launch-time lane rather than a property of the object itself;
- `close_range(..., CLOSE_RANGE_CLOEXEC)` exists precisely because launch-boundary inheritance often needs an explicit bulk shutter;
- POSIX.1-2024 specifies `FD_CLOFORK` / `F_DUPFD_CLOFORK`, and OpenBSD already exposes `FD_CLOFORK`, reinforcing the deeper lesson that inheritance across `fork` can deserve its own explicit posture too.

The lesson for ViewFS is not "be POSIX" or "standardize Linux/OpenBSD fd flags."
The lesson is: **do not let current possession of authority silently become child authority merely because the host launch path makes descriptor inheritance convenient.**

## Guardrail
ViewFS should keep these classes visibly separate:
1. **Current handle possession** — a live handle currently present in this pane/process/view.
2. **Launch-inheritance posture** — whether that current handle is barred, eligible, or explicitly selected for crossing a spawn/exec boundary.
3. **Exact child delivery slot** — the child-local activation slot / fd position / named entry that actually receives a reviewed inherited copy.
4. **Launch receipt / history** — durable evidence describing what crossed the boundary during one reviewed launch.

## Consequences
We should be able to say things like:
- `held here only`
- `launch-shuttered`
- `eligible but not selected`
- `selected for child slot stdin`
- `selected for child slot fd=7`
- `launched with 2 inherited handles`
- `receipt only`

without laundering them into one fake `the child has this` bit.

## Good answers might look like
- default launch kits that inherit nothing except explicit reviewed stdio/activation slots
- launch review cards showing `held now` versus `crosses launch boundary`
- inheritance shutters and bulk `close-on-launch` rails
- child-slot maps that name exactly where reviewed copies will land
- receipts that remember one reviewed launch boundary crossing without reviving it later

## What this does not decide
This RFC does **not** decide:
- the exact portable representation of child-local slots (`fd`, named activation slot, both, or something else);
- whether ViewFS implements launch shutters with `FD_CLOEXEC`, explicit spawn actions, supervisor-side reconstruction, or another host-specific mechanism;
- whether any future `close-on-fork` style posture becomes a Phase 1 requirement or remains only a useful precedent;
- whether non-process targets (services, remote workers, containers, foreign cells) reuse the same child-slot vocabulary or only the same higher-level separation.

## Shell implications worth stealing
A future custom shell/terminal should expose:
- **inheritance shutters** that show which current handles are blocked from launch by default;
- **launch-boundary diff cards** that show `held here` versus `crosses into child` before Enter commits;
- **child-slot maps** that name exactly where inherited copies land;
- **authority leak sirens** that warn when a draft launch is about to carry more live handles than expected.

## Why this is a low-regret move
Even if SlopOS later changes its exact CH-FDSET shape, activation-carrier schema, or launcher mechanics, this split stays useful.
It is the kind of boundary that keeps object-store handles, per-process namespace assembly, portal-mediated imports, and shell chrome honest while the deeper design is still moving.
