# RFC 0041: Keep activation carriers, badged handle copies, and object identity separate

Status: draft guardrail RFC.

## Why this exists
ViewFS already separates immutable object identity, live authority, local naming, durable reopen, and transcript history.
A new design pressure is appearing at process startup and handoff time:
- launchers or supervisors may hand in already-open resources,
- copied handles may be attenuated or tagged with issuer-visible badge/witness material,
- shell history may want to explain where those handles came from,
- and none of that should collapse into one fuzzy "open" or "object id" story.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design.

## Distinct truths

### 1. Activation carrier / launch slot
Question:
- through what reviewed startup slot or launch-kit entry was this resource handed to the child?

Examples:
- `stdin`/`stdout`-like startup carriers
- named activation slots
- launch-kit entries
- view-fragment or cwd/root startup bindings

### 2. Live handle copy
Question:
- what exact live handle copy is currently installed in the process or pane?

Examples:
- a handle-table entry
- a rights-reduced duplicate
- a continuity-locker-restored live handle

### 3. Issuer-visible badge / witness on the copy
Question:
- what issuer-local badge, lineage tag, or witness is attached to this copy of authority?

Examples:
- issuer-visible badge values
- minted lineage labels
- route-plan source tags
- shell-visible handle provenance chips

### 4. Underlying object identity
Question:
- what exact immutable object or exact mutable target does this handle ultimately refer to?

Examples:
- immutable object refs
- exact mutable anchors
- committed object-store identity

### 5. Launch / history artifacts
Question:
- what durable or transcript artifact records that one of the above happened?

Examples:
- launch receipts
- route-plan receipts
- continuity/restore receipts
- transcript-linked witness cards

## Guardrail
A startup carrier or badge may help explain where a live handle came from.
It must not silently masquerade as:
- immutable object identity,
- a stable future path,
- durable reopen authority,
- or a trust verdict about the object itself.

## Implications for ViewFS
- launch should prefer handed-in resources over child rediscovery through ambient globals;
- activation-slot names should remain separate from local bind names and from immutable identity;
- copied handles may carry issuer-visible badge/witness metadata, but that metadata should describe the copy/issuer lane rather than the object itself;
- shell UX should be able to say `activation slot`, `live handle`, `issuer badge`, `object ref`, and `receipt only` as different truths;
- replay or reopen should not reuse prior activation carriers unless an explicit current lane says so.

## Non-decisions
This RFC does **not** decide:
- the exact badge encoding or whether badges are kernel-, runtime-, or shell-level;
- whether activation kits are shell-owned, supervisor-owned, portal-owned, or split across them;
- whether any issuer-visible badge crosses reboot, machine, or user boundaries;
- whether startup delivery uses FDs, namespace fragments, handles, descriptors, or several of these.

## Shell consequences
The custom shell+terminal should be allowed to grow:
- activation-kit preview cards,
- badged-handle drawers,
- truth-graded command blocks,
- and selection packets with explicit action ladders,
without claiming more than the current truth source actually supports.
