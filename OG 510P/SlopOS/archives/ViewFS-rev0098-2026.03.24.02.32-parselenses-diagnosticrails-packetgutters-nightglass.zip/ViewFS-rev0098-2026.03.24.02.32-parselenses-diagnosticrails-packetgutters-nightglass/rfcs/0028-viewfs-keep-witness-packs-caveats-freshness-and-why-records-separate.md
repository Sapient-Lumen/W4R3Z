# RFC-0028: Keep witness packs, caveat sets, freshness tokens, and why-records separate

## Status
Proposed.

## Problem
ViewFS already tries not to collapse imports into binds, plans into execution, suggestions into user-owned workflows, loans into durable refs, or replay into floating approval.
A fresh collapse risk is now visible anywhere the system wants to *justify* or *reuse* a decision:

- the exact local facts that are admissible as basis material,
- the narrowing conditions or caveats attached to the move,
- any freshness/consistency witness for the evaluated state cut,
- the current explanation of why the system allowed/narrowed/denied the move,
- and the durable history receipt afterward

can drift toward “one justification blob”.

That would be a mistake.
It would make explanations hard to inspect, encourage sticky approval folklore, blur attenuation with evidence, and turn history into a stealth authority cache.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat the following as distinct classes:

- **WitnessPack** / exact local facts admissible as basis material,
- **CaveatSet** / explicit narrowing conditions or usage constraints,
- **FreshnessToken** / consistency or freshness witness for the evaluated basis cut,
- **WhyRecord** / compact explanation object for the current allow/narrow/deny outcome,
- and **DecisionReceipt** / durable history artifact for the completed attempt.

The default reading should be:
- witness material is not the same thing as caveats,
- caveats are not the same thing as freshness evidence,
- freshness evidence is not current approval,
- a why-record is not a bearer grant,
- and receipts must stay explainable without becoming live authority.

## Consequences
- replay/import/renewal flows can explain *which class* changed instead of collapsing every problem into `stale`
- caveat-preserving or caveat-tightening replay becomes a routine UX feature
- current allow/narrow/deny reasoning can be transcript-visible without serializing live authority
- provider-supported-operation drift can become an exact witness mismatch instead of a surprise failure
- shell UX can expose witness drawers, caveat chips, freshness badges, and why panels as first-class objects

## Non-goals
This RFC does not choose:
- a final schema for `WitnessPack`, `CaveatSet`, `FreshnessToken`, or `WhyRecord`,
- whether freshness tokens are shared across all families or family-specific,
- exact deny/why enums,
- whether caveats can attach to saved recipes as well as live delegated artifacts,
- or final shell syntax for `why`, `witness`, `caveats`, or `recheck`.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing a **witness pack**, a **caveat set**, a **freshness token**, a **why-record**, or only **receipt/history**?
- Can the shell say whether failure came from witness mismatch, caveat conflict, freshness uncertainty, issuer/policy veto, or explicit receipt-only downgrade?
- Does any explanation artifact remain non-authoritative even when it is durable and shareable?
- Can replay or renewal preserve or tighten caveats without pretending old approval floats forward?
- Can the transcript say *why* the class changed?

If the answer is “for convenience these are all basically one justification object,” the burden of proof should be high.
