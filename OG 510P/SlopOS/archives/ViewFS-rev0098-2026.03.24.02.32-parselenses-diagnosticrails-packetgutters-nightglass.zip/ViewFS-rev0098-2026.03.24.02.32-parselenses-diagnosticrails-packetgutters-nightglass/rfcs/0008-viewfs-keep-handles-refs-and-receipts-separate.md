# RFC-0008: Keep live handles, durable refs, and transcript receipts separate

## Status
Proposed.

## Problem
Design-phase filesystem projects often end up with one overloaded token that tries to serve as:
- current authority,
- durable reopen memory,
- route/recent item identifier,
- and audit/history artifact.

That would make ViewFS harder to secure, harder to explain, and harder to build a great shell around.

## Proposal
For Phase 1 and early design spikes, ViewFS should treat the following as distinct classes:
1. **live handles** — active authority-bearing object/view values;
2. **durable refs** — non-bearer reopen/rebind descriptors that require revalidation;
3. **transcript receipts** — audit-visible records of chooser/open/save/transfer/rebind outcomes.

## Consequences
- Shell history/transcripts do not silently serialize live authority.
- Recent-item and workspace UX can be helpful without pretending that “remembered” means “still authorized”.
- Portal/request flows can have explicit outcomes and receipt cards without forcing those receipts to be durable authority tokens.
- SlopOS seams such as handle bindings, CH-DOCREF-like descriptors, and transcripted outcomes remain aligned instead of being compressed into one primitive.

## Non-goals
This RFC does not choose:
- the final wire format for any of the three classes,
- the final durable-ref schema,
- whether live handles can ever be checkpointed under narrow local conditions,
- or the final shell protocol fields for HUD/receipt rendering.

## Adoption test
A future ViewFS proposal should have to answer:
- Is this about a **live handle**, a **durable ref**, or a **receipt**?
- If it crosses classes, where is the explicit transition?
- Can the shell tell the user which class they are looking at?

If the answer is “one token does all of it”, the burden of proof should be high.
