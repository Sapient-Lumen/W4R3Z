# RFC 0055: Keep content descriptors, live handles, and receipts separate

Status: exploratory

## Why this exists

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports. That combination becomes much easier to evolve if ViewFS keeps one more seam sharp early: a **content descriptor** should not silently become a **live handle**, and neither should silently become a **durable receipt/history row**.

That lesson matters while SlopOS is still in design because it lets ViewFS freeze a separation early **without** freezing one fetch model, one publication model, or one object-store implementation too early.

## The separation
Keep these classes separate:
- content descriptor / object descriptor
- descriptor hints such as media type, size, or locator hint
- live handle or live bind that carries current authority
- durable receipt / later history row

Do **not** flatten them into one vague story like “the file”.

## Historical lesson
Modern content-addressed systems repeatedly separate **what object is being described** from **how or whether it is currently reachable**.

OCI content descriptors carry a digest, media type, and size so one piece of content can be referred to securely across manifests and transport surfaces. IPFS content identifiers similarly point by content rather than by storage location. And SlopOS's current artifact-reference draft already leans the same way: digest is authoritative while locator is a hint.

That is exactly the low-regret shape ViewFS should steal.

## ViewFS rule
ViewFS should preserve a distinct lane for:
1. naming or computing one exact object/content descriptor,
2. optionally attaching non-authoritative hints such as media type, byte size, or locator hints,
3. separately minting or receiving one live handle/bind when current authority is actually needed,
4. separately recording one receipt/history row about imports, hydration, publication, or transfer,
5. later inspecting those rows without turning them back into bearer authority.

## Why this helps ViewFS
- It keeps object identity separate from live authority.
- It lets portal/import UX say `descriptor only` without pretending bytes are already readable here.
- It gives the future shell a stable thing to render as an object card even before the system commits to one publication or hydration mechanism.
- It makes `hydrate`, `bind here`, `reopen`, and `publish` reviewable follow-on acts instead of accidental side effects of naming.

## What this does not decide
This RFC intentionally does **not** decide:
- which hash algorithm or descriptor envelope is canonical,
- whether descriptors always point at local bytes versus fetchable remote bytes,
- whether every live handle always corresponds to one immutable descriptor,
- whether hydration, pinning, mirroring, and publication share one mechanism,
- whether descriptor hints are stored in the object store, a sidecar index, or a portal/request surface.

## Shell consequences
A future ViewFS shell should be able to show:
- `descriptor only`,
- `local bytes present`,
- `live handle now`,
- `published here`,
- and `receipt/history only`
as different truths.

It should also be able to show one compact object card containing digest/object ID, media type, size, and locator hint **without** implying that the card itself is current authority.

## SlopOS alignment
This separation fits SlopOS well because SlopOS already keeps reaching toward explicit descriptors, explicit handles, and explicit portals instead of ambient rediscovery. ViewFS can therefore borrow the *shape* of descriptor-first object identity now, while leaving CapStore details, hydration policy, and publication/bind mechanisms open longer.
