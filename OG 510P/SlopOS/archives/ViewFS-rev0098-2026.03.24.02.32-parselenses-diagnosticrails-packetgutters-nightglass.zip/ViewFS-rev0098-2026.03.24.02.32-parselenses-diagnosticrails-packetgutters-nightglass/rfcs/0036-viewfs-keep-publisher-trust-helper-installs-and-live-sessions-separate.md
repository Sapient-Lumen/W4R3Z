# RFC-0036: Keep publisher trust, helper installs, and live sessions separate

Status: Draft  
Updated: 2026-03-22  
Decision family: helper lifecycle / start gates / shell ergonomics

## Summary
ViewFS should keep one more seam explicit while source-aware shelling is still fluid:

**publisher trust ≠ installed helper package ≠ configured helper/server definition ≠ enabled state ≠ start approval ≠ live brokered session ≠ request-scoped tool selection ≠ durable receipt/history**

This keeps the shell free to discover, install, stage, and selectively use helpers **without letting installation, remembered configuration, or stale enablement quietly become current live authority**.

## Motivation
Revision 0035 froze the split between protected-authorable state, carrier/discovery presence, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable history.

That still leaves a dangerous gap:
- a helper can be installed without being configured,
- configured without being enabled,
- enabled without being approved to start,
- started without all of its tools being selected for the current request,
- and previously live without being live now.

Current precedent makes this risk real:
- VS Code now distinguishes extension-publisher trust, MCP server start trust, enablement state, and request-scoped tool selection,
- plugin MCP servers have a different trust/start path than workspace MCP servers,
- and Deno’s permission broker shows that a live broker lane is stronger than local remembered flags or prompts.

## Decision
For future ViewFS design work, proposals must classify whether they are changing:
1. **publisher trust** — trust in the carrier/marketplace/publisher source,
2. **installed helper packages** — what is present on disk/profile/workspace,
3. **configured helper definitions** — discovered/configured server or tool definitions plus provenance,
4. **enabled state** — toggles that determine whether a helper is eligible to start,
5. **start approvals** — current trust/admission checks required before the helper becomes live,
6. **live brokered sessions** — running helpers with concrete runtime identity and capabilities,
7. **request-scoped selection** — the subset of tools/prompts/resources chosen for one action,
8. **durable receipts/history** — what only records past install/enable/start/select/stop outcomes.

## Consequences
### Positive
- gives ViewFS a clean way to say “installed”, “enabled”, “approved to start”, and “live now” are different truths;
- creates room for strong shell UX without turning helper discovery into ambient authority;
- makes request-scoped tool selection truthful even when many helpers are present or live;
- keeps future helper/broker/session stories compatible with SlopOS role boundaries and powerbox posture.

### Costs
- one more lifecycle model to inspect and explain;
- richer receipts and shell chrome;
- some helper classes may need multiple visible gates before use.

## Non-goals
- freezing the final helper/package/plugin/server taxonomy,
- deciding whether any helper class may auto-start from protected sources,
- deciding the final schema for lifecycle receipts, start approvals, or live session descriptors,
- deciding the final shell placement for cards, racks, or beacons.

## Near-term prototype
Build one helper-aware shell flow with:
- publisher badge,
- installed card,
- start gate drawer,
- live-session beacon,
- request-scoped tool rack,
- lifecycle receipt that preserves install/enable/start/select truth.

If that feels magical **and** honest, keep the seam. If it feels noisy, trim the UI before trimming the boundary.
