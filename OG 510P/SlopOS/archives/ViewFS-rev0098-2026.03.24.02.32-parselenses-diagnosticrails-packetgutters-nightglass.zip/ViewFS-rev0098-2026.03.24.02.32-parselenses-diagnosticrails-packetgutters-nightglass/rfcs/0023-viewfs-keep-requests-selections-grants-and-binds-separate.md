# RFC-0023: Keep request objects, candidate sets, selections, grants, and live binds separate

## Status
Proposed.

## Problem
ViewFS already tries not to collapse identity, naming, reopen, transfer, trust, warm state, grouped authority, and launch assembly.
A fresh collapse risk is now visible around portal/powerbox flows:

- the **request object** representing a mediated interaction,
- the **candidate/designation surface** the chooser/provider searched through,
- the **selection** the user actually made,
- the **grant/ref** that was minted,
- the **live bind** installed into a pane or launch kit,
- and the **receipt/history** that remembers it

can all drift toward “one opened object”.

That would be a mistake.
It would hide where authority came from, make history lie about what is still live, and encourage candidate enumeration to become ambient inventory.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat the following as distinct classes:

- **ImportRequest** / chooser/save/rebind interaction object,
- **CandidateSet** / chooser-owned designation surface,
- **SelectionRecord** / what the user designated,
- **ImportGrant** or **DurableRef** / the actual minted authority outcome,
- **ViewBind** / mutation of a concrete process view,
- and **Receipt** / history, not live authority.

The default reading should be:
- request state is interaction state,
- selection is not yet live authority,
- minted grants/refs are not necessarily bound here,
- durable upgrade is explicit,
- and bind/rebind into a concrete pane or child launch remains a separate act when it matters.

## Consequences
- chooser/provider search can stay powerful without becoming generic machine inventory
- shell history can distinguish `selected`, `granted`, `bound here`, `reopenable`, and `receipt only`
- durable reopen can remain explicit instead of leaking out of every open
- request cancellation, timeout, and completion can stay auditable as request facts rather than fake object states
- SlopOS powerbox/document-portal/view seams stay aligned instead of being replaced by a single “open token” object model

## Non-goals
This RFC does not choose:
- a final chooser/result schema,
- whether candidate descriptors ever persist outside the mediator,
- a final durable-upgrade protocol,
- a final shell syntax for `bind here` / `keep for later` / `launch with`,
- or a final rule for when bind is automatic versus staged.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing a **request**, a **candidate set**, a **selection**, a **grant/ref**, a **live bind**, or only a **receipt/history** surface?
- Does the caller learn the whole candidate inventory, or only the selected result?
- Is persistence explicit, or is it leaking in as a side effect of ordinary open?
- What is live authority here now versus only an eligible result or remembered receipt?
- If something enters a pane or launch kit, where is the explicit bind/rebind/install step?

If the answer is “they are basically all one object for convenience,” the burden of proof should be high.

