# RFC-0086: Keep privilege brackets, borrowed authority, call-chain contexts, deny-only hints, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already keeps route envelopes, sidecars, sink consequences, and receipts separate.
It already keeps current possession, invocability, watch status, and holder-bound grants separate.
The next low-regret seam is different: **privilege bracket**, **borrowed authority**, **call-chain context**, **deny-only routing hint**, and **durable receipt/history**.

This seam matters because helper-rich shells, automation blocks, plugins, and relay processes are where capability systems quietly regress into confused-deputy folklore.
A helper may need to act *for* a caller while still using narrowly borrowed authority.
A stack trace or caller chain may explain who asked.
A deny-only route hint may veto a dangerous path.
None of those should be allowed to silently turn into new authority.
And none of them are the same thing as a durable receipt that explains what happened later.

If we collapse these classes too early, we make at least five mistakes:

1. **dynamic context masquerades as authority**
   - caller metadata or task-local context starts acting like a grant.

2. **borrowed authority becomes invisible**
   - a helper seems to act on its own instead of on a bounded delegation or bracket.

3. **deny-only hints become hidden allow paths**
   - provenance or plugin-origin context starts widening instead of only narrowing or vetoing.

4. **ambient helper state quietly returns**
   - globals, thread-locals, or async-locals become a hidden capability side channel.

5. **history masquerades as current bracket state**
   - an old explanation of who asked looks like proof that the same borrowed authority is active now.

## The seam

Keep these classes visibly distinct:

1. **privilege bracket**
   - a bounded execution region where a helper may exercise some borrowed authority.
   - starts explicitly and ends explicitly.
   - does not become a process-wide mode switch.

2. **borrowed authority**
   - the actual handle/capability/set of handles being exercised on the caller's behalf.
   - may be narrower than the helper's own standing local tools.
   - should stay inspectable as authority, not as mere context.

3. **call-chain context**
   - bounded, non-authoritative metadata about who asked, which helper path ran, or which pane/plugin originated the action.
   - useful for audit, debug, and deny-only routing.
   - not current authority by itself.

4. **deny-only hint / veto input**
   - optional narrowing or veto material derived from caller/context provenance.
   - can block, dim, or force re-route.
   - must not widen authority or impersonate one.

5. **receipt / history**
   - durable evidence that one bracket ran, one authority set was borrowed, one call-chain context was observed, and one consequence happened.
   - not a current bracket, not a current call context, not a current grant.

## Working posture

- ViewFS should prefer **explicit privilege brackets** over ambient helper globals.
- Borrowed authority should stay visible as a real object/handle posture, not dissolve into helper identity.
- Call-chain context should remain **bounded and non-authoritative**.
- Deny-only hints should be allowed to veto or narrow, but never to silently add rights.
- Receipts should preserve explanation without reviving bracket state.

## What to steal

- **Hardy's confused deputy lesson**: the problem appears when one tool carries authority from multiple masters and cannot keep them apart.
- **Scoped dynamic context** from modern runtimes: bounded, automatically unwound propagation is healthier than mutable ambient globals.
- **Structured async context** patterns: `run`/`exit`-style boundaries and snapshotting are better than forever ambient task baggage.
- **SlopOS RFC-0118**: privilege bracketing and bounded non-authoritative call-chain descriptors are already the right instinct nearby.
- **Harbor/Foundry sibling pressure**: issuer/origin cards and explicit helper residue are healthier than helper folklore.

## Shell consequences

The shell/terminal should gain:
- **bracket rails** that show when a helper is inside one explicit borrowed-authority region;
- **caller badges** and **call-frame chips** that answer `who asked?` without pretending to authorize;
- **why-did-the-helper-do-that drawers** that separate borrowed handle truth from caller-context truth;
- **deputy fog warnings** when a helper would cross from bracketed use into ambient helper state;
- **deny-only shutters** that explain when plugin/helper provenance vetoed one route;
- **receipt cards** that preserve the whole explanation after the bracket ends.

## Phase-1 non-decisions

This RFC does **not** decide:
- one final call-chain schema,
- whether call-chain frames are kernel-adjacent, runtime-local, or shell-only,
- whether any deny-only hints are standardized beyond a tiny initial set,
- one final privilege-bracket API across every language/runtime,
- whether some helpers get special bracket ergonomics in the shell.

## Design bar

Before ViewFS standardizes richer helper/plugin/automation UX, it should be able to answer:

1. Is this current authority, current bracket state, current call context, a deny-only hint, or only history?
2. Can the shell show who asked without laundering that into authority?
3. Can a helper borrow explicit handles without quietly depending on ambient task-local globals?
4. Can caller or plugin provenance veto dangerous routes without becoming an allow path?
5. Can old receipts explain a past helper action without reviving its bracket or authority now?
