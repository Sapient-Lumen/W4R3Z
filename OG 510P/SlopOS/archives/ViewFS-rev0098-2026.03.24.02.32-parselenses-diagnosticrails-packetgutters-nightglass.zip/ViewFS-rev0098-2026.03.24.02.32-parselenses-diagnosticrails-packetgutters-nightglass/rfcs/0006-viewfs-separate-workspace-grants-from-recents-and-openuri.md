# RFC-0006: keep workspace grants, recents, and OpenURI orthogonal

## Status
Draft.

## Why this exists
ViewFS is converging on the idea that grant classes matter.
The next likely design mistake is to blur together several superficially similar actions:
- open a file now,
- bind a folder/tree into my working view,
- reopen a recent item later,
- drag/drop or paste a file between tools,
- launch or reveal something externally via URI routing.

Those should feel related in the UI but remain distinct in the authority model.

## Problem statement
Legacy platforms often let users and developers talk about all of the above as “opening something”.
That word hides different powers:
- transient read access,
- durable reopen,
- broad tree access,
- inter-app transfer,
- or pure launch/routing with no returned local-object capability.

If ViewFS collapses them too early, the shell may feel convenient at first but the transcript, receipts, and policy story will become muddy.

## Proposal
Any future ViewFS design touching chooser/open/save/rebind/reopen/reveal should explicitly classify itself as one of these:

1. **single-object open/import**
2. **transfer/handoff**
3. **destination/save grant**
4. **durable reopen**
5. **workspace/tree bind**
6. **URI launch/reveal route**

A proposal may compose more than one class, but it must say so and must keep the resulting receipts distinguishable.

## Design consequences
- `workspace/tree bind` should usually land as a view-binding receipt, not just a document-open receipt.
- `durable reopen` should not silently become `workspace/tree bind`.
- `URI launch/reveal route` should not mint local-object authority by accident.
- `transfer/handoff` should not persist across sessions unless explicitly promoted.
- shell route sheets and palettes should preserve these distinctions rather than collapsing back into generic “open” UX.

## Why this fits SlopOS
The SlopOS datacube already keeps relevant seams separate:
- D-NS / view bindings
- document portal / document handles
- transfer portal / plumbing
- OpenURI boundaries
- capability-safe shell surfaces

ViewFS should specialize those seams instead of compressing them into a faux traditional filesystem story.

## What this RFC is not doing
- not standardizing a final receipt schema
- not choosing between handle, bundle, or view-fragment workspace grants
- not defining revocation mechanics
- not defining a final shell grammar

## A narrow test for future proposals
If a future proposal says “open” or “reopen”, reviewers should be able to ask:
- is this returning local-object authority or just routing a launch?
- is this session-bounded, durable, or workspace-binding?
- does the receipt tell those apart?
- can the shell explain the difference afterward?

If the answer is “not really”, the proposal is probably hiding too much.
