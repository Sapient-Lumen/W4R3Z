# RFC-0077: Keep discoverability, enumeration, exact-name reachability, fit notes, and receipts separate

## Status
Proposed.

## Problem
ViewFS already separates object identity, live handles, published names, synthetic views, rooted compat walks, and ambient escape debt.
A new collapse risk sits one layer over that in the everyday `browse` and `open` story:
- a process can already hold a live handle,
- a process can know one exact child name inside a held root and open it,
- a process can enumerate/list a container,
- a mediator can suggest candidates or fit classes,
- or history can merely remember that something existed once.

Those are not interchangeable classes.
If ViewFS flattens them into one vague `you can see it, therefore you can open it` story, the shell will lie about why an item appeared, what rights exist now, and whether a suggestion is only advice.

## Proposal
For Phase 1 and nearby spikes, ViewFS should preserve a hard distinction between:

1. **Direct current authority / live handle**
   - the actor already holds a live handle or direct designation with current rights
   - and acts through that authority directly

2. **Exact-name reachability inside a held root/view**
   - the actor does not have general browse power
   - but can attempt an exact child lookup/open inside an already-held root/view/designator

3. **Enumeration / listability / browse authority**
   - the actor can list names, inspect entries, or walk a container interactively
   - which is a stronger metadata-disclosure surface than merely knowing one exact name

4. **Fit notes / suggestions / mediation hints**
   - a portal, chooser, powerbox, shell helper, search index, or provider offers candidates, match quality, or scope hints
   - but that does not itself prove current authority, local publication, or stable existence

5. **Receipt / history**
   - durable explanation of what was listable, what was only reachable by exact name, what was only suggested, and what actually opened or imported

Published names, synthetic views, and ambient escape debt remain separate seams from RFC-0075 and RFC-0076.

## Consequences
- ViewFS can preserve metadata-minimizing lookup and exact-name opens without pretending every reachable child is browse-visible.
- Search, chooser, and completion UI can stay richly helpful without silently claiming authority.
- Portal/import UX can explain why a candidate appeared and what stronger step is still needed.
- Shell/product work can distinguish `known name`, `browseable`, `suggested only`, and `opened now` instead of flattening them into one fake file-explorer truth.

## Non-goals
This RFC does not choose:
- one final directory/container rights lattice,
- one final browse or search protocol,
- one final index/search owner,
- one final local-name lookup API,
- or one final disclosure policy for every provider.

## Adoption test
A future ViewFS proposal should answer:
- Did the actor already hold **direct current authority**?
- Was the target merely **reachable by exact known name** inside a held root/view?
- Was the container actually **enumerable/listable**?
- Was the item only **suggested / ranked / fit-noted** by a mediator or helper?
- Is there a **receipt** that says which of those truths actually held?

If the answer becomes `the shell showed it, so it must have been openable`, the burden of proof should be high.
