# RFC-0016: Keep remove/unbind, trash, recovery history, retention roots, and purge on separate seams

## Status
Proposed.

## Problem
ViewFS already distinguishes handles, refs, receipts, session state, registries, workspace trust, previews, watches, links, and origin/trust flows.
Another easy collapse is to treat all delete-like operations as if they were the same thing:

- removing a name from a view,
- moving something to a recoverable trash,
- keeping local recovery history,
- dropping or retaining explicit roots,
- garbage-collection eligibility,
- actual purge,
- or stronger destruction claims.

History says these are not the same question.

## Proposal
For Phase 1 and nearby spikes, ViewFS should keep at least these classes distinct:
- remove / unbind intent,
- trash / recycle entry,
- recovery history,
- retention roots,
- purge eligibility,
- purge / collection act,
- and any stronger destruction claim.

Any proposal that collapses them should pay a high burden of proof.

## Consequences
- the shell can offer great undo/restore UX without lying about storage fate
- immutable-first storage can stay simple while user-facing recovery still feels modern
- retention roots can be explained instead of becoming spooky action at a distance
- purge can be previewed and policy-driven rather than hidden inside `delete`
- stronger destruction claims can remain deferred until the proof story exists

## Non-goals
This RFC does not choose:
- a final trash storage format,
- a final restore-plan schema,
- a final retention policy,
- a final purge scheduler,
- or any secure-deletion promise.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing **a view binding/name**, **a trash entry**, **a recovery-history entry**, **a retention root**, **purge eligibility**, or **a purge act**?
- Can the user tell what still keeps the object live?
- What exactly disappears after purge versus after mere trash/unbind?
- Does any receipt or timeline entry accidentally become live authority?
- Is the proposal making a stronger destruction claim than the mechanism can justify?

If the answer is “users think of all of this as delete anyway,” the burden of proof should be high.
