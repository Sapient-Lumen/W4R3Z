# RFC-0085: Keep route envelopes, authority sidecars, sink bindings, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already keeps selected regions, entity candidates, route envelopes, prepared actions, and receipts separate.
It already keeps foreign-backed borrows, projected imports, local realizations, and live lends on distinct seams.
The next low-regret seam is **typed route envelope / optional authority sidecar / sink-side grant or bind / durable receipt**.

A typed intent or plumb message is not current authority.
A message that *mentions* a subject is not the same thing as a lane that can actually hand the sink usable authority.
A sidecar that summarizes or narrows authority is still not the same thing as the sink actually holding a live bind, projected import, local realization, or accepted representation.
And none of those are the same thing as a receipt.

If we collapse those classes too early, we make at least five mistakes:

1. **designation starts masquerading as authority**
   - a route slip that points at something starts acting like the sink already has current rights to it.

2. **message envelopes start masquerading as transfer lanes**
   - one convenient packet format quietly becomes an ambient capability courier.

3. **non-authoritative summaries start masquerading as capability containers**
   - wallet-like descriptors, digests, or notes begin acting like reopen/import power.

4. **sink-side acceptance starts masquerading as source-side promise**
   - a sender says `shared`, but the sink never actually accepted, bound, projected, or localized anything.

5. **history starts masquerading as current routeability**
   - an old route or receipt starts pretending the same lane still exists, the same sidecar still fits, or the same sink still holds authority.

## The seam

Keep these classes visibly distinct:

1. **route envelope / route capsule**
   - a typed request, intent, or plumb packet describing *what should happen* and *what subject is in play*.
   - may contain names, refs, digests, fit notes, and requested verbs.
   - not current authority by itself.

2. **authority sidecar**
   - optional non-authoritative or narrowly authoritative adjunct material carried *with* the route.
   - examples: wallet digests, capability-class summaries, per-URI grant candidates, exact offered representations, required proofs, or portal request handles.
   - useful for explanation, narrowing, or sink decision-making, but still not identical to sink-held authority.

3. **sink-side acceptance / bind / import**
   - the receiving pane/process actually accepts one representation, receives one live grant, projects one local view, binds one name, or localizes one object.
   - this is where real local consequence begins.
   - the exact consequence may still be `representation only`, `projected only`, `bind only`, or `localized here`.

4. **receipt / history**
   - durable evidence that a route envelope existed, a sidecar was presented, and a sink either accepted or rejected some concrete consequence.
   - not a standing route promise, not a hidden replay token, and not proof that the sink still holds authority now.

## Working posture

- ViewFS should allow **designation-only route capsules** without implying any current grant.
- ViewFS should allow **authority sidecars** that help the sink judge fit, scope, or narrowing without turning those sidecars into capability containers.
- ViewFS should allow **sink-local acceptance** to remain explicit about what actually happened: representation accepted, live bind accepted, projected import accepted, or localization accepted.
- ViewFS should keep **receipts/history** useful for audit, replay planning, and explanation while refusing to let them behave like live sidecars or current sink authority.

## What to steal

- **Plan 9 plumbing** (REF-PLAN9-PLUMB, REF-PLAN9-PLUMBER4): typed routed messages are a real product advantage, but they stay messages, not ambient capability folklore.
- **SlopOS plumb + capshell drafts**: `rfcs/0117-plumb-messages-and-cli-intents.md` already keeps CH-PLUMBMSG non-authoritative, while `rfcs/0116-capability-wallets.md` keeps wallet descriptors non-authoritative too.
- **Android Intent URI grants** (REF-ANDROID-SHARE-FILE, REF-ANDROID-URIPERMISSION, REF-ANDROID-GRANTURIPERMISSION): an Intent envelope, any ClipData/URI it names, and the temporary permission grant are related but still not the same class.
- **XDG portal requests** (REF-XDG-PORTAL-DESIGN, REF-XDG-REQUEST): request objects are request-local lifetimes that later resolve with results; request existence is not the same thing as final grant/bind truth.
- **Wayland data offers** (REF-WAYLAND-DATADEVICES): offered representations, chosen representation, and actual transferred bytes remain distinct.
- **Foundry companion cube**: attached sidecars, foreign-backed adoption rails, and explicit attach/adopt gates reinforce the same humility about message-versus-adoption truth.

## Shell consequences

The shell/terminal should gain:
- **route slips** that say `designation only`, `route capsule`, or `requires authority sidecar` instead of pretending every click/open is the same;
- **authority sidecars** shown as explicit chips or drawers: `wallet digest`, `uri grant candidate`, `representation offers`, `needs portal`, `proof required`;
- **sink trays** that show what the receiver actually accepted: `text only`, `representation accepted`, `projected here`, `bound here`, `localized here`, or `declined`;
- **dry-run route diffs** that compare the same route capsule with and without sidecars;
- **post-route receipts** that record the exact sink consequence rather than one flattering `sent` or `opened` row.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal route-envelope schema for every family,
- whether every sidecar is shell-owned, portal-owned, provider-owned, or mixed,
- whether sidecars may ever carry live narrow authority or only descriptors/digests,
- one universal sink-binding vocabulary across representation transfer, projected import, live bind, and localization,
- whether replay can auto-represent prior sidecars or must always re-negotiate them.

## Design bar

Before ViewFS standardizes richer route/import/share UX, it should be able to answer:

1. Is the user looking at one route capsule, one sidecar, one sink acceptance, or only history?
2. Can the shell show `designation only` without promising current authority?
3. Can sidecars remain explicit and inspectable instead of disappearing into hidden helper magic?
4. Can the sink record exactly what it accepted instead of one vague `opened/shared/imported` outcome?
5. Can old receipts help replay planning without behaving like current grants or current route guarantees?
