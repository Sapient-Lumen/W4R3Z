# RFC 0082: Keep live possession, status carriers, local holds, successor refresh, and receipts separate

Status: exploratory

## Why this exists

ViewFS already distinguishes:
- adverts from readiness,
- provider-ready from local-realized,
- claim tickets from holder-bound grants,
- and current possession from current invocability.

The next easy collapse happens after that:
people start treating **what is held here now** as if it already carries one timeless `still good` bit.

But several real systems keep showing the opposite:
- one credential or token can still be present while a live status query says it is inactive;
- one signed bundle can still verify while newer status material says `suspended`, `refresh`, or `message`;
- one certificate can move onto `certificateHold` and later come off again;
- one repository can still have valid old metadata in hand while freshness/watch rules force a local freeze until newer metadata or successor roots arrive.

That split is worth freezing now while SlopOS is still deciding deeper object-store, portal, and watch/status machinery.

## The separation

Keep these classes separate:
- **live possession** of a local object, local realization, holder-bound grant, or live handle;
- **status carrier / watch material** that says something new about that subject without replacing the base object or base proof;
- **receiver stance** describing how this local process/workspace/shell interprets and acts on the incoming status;
- **local hold / attenuation / quarantine posture** such as `suspended here`, `narrowed here`, `quarantined here`, or `ignored with reason`;
- **successor / refresh posture** such as `new witness available`, `new epoch/root needed`, `replacement available`, or `refresh advised`;
- **current invocability after watch processing**, which is still a narrower truth than raw possession;
- **durable receipts/history** describing what happened before.

Do **not** flatten these into one vague story like `valid`, `revoked`, `trusted`, or `still okay`.

## Historical lesson

Several useful systems already warn against this collapse:
- OAuth token introspection (RFC 7662) explicitly asks about the **current state** of a token, including whether it is active, what rights it carries, and in what authorization context it was granted.
- OAuth token revocation (RFC 7009) reminds us that self-contained tokens, server-side token handles, and short-lived tokens all produce different revocation/update behavior.
- OCSP (RFC 6960) keeps certificate status separate from the certificate itself and distinguishes `good`, `revoked`, and `unknown`; it also makes room for revocation reason and freshness windows.
- RFC 5280 keeps `certificateHold` and `removeFromCRL` visible, showing that some bad-standing states are reversible and should not be modeled as timeless destruction.
- W3C Bitstring Status List v1.0 keeps status material smaller than the base credential and gives separate purposes like `refresh`, `revocation`, `suspension`, and `message`.
- TUF keeps signed metadata freshness and root-key rotation explicit, including expiry, freeze detection, and out-of-band successor-root recovery.
- Ward's sibling work around status carriers, suspension rails, refresh notices, attenuation events, and receiver stance is a nearby reminder that later status inputs and local consequence should not collapse into one truth bit.

## ViewFS rule

ViewFS should preserve distinct lanes for:
1. live possession / local realization,
2. status carrier or watch-stream truth,
3. receiver stance,
4. local hold/attenuation/quarantine posture,
5. successor/refresh posture,
6. current invocability after watch processing,
7. durable receipts/history,
8. any later rebound or successor-adoption, which is still a separate question.

## Why this helps ViewFS

- It stops `held now` from masquerading as `still in good standing now`.
- It stops one incoming status list, watch event, or successor hint from silently rewriting base object identity.
- It gives the shell a truthful way to say `held`, `watch stale`, `suspended here`, `quarantined`, `refresh available`, `successor root needed`, `invokable now`, or `history only`.
- It leaves room for SlopOS to settle watch transport, status-carrier format, successor adoption, and policy ownership later without forcing ViewFS to pretend those are already one mechanism.
- It gives imports and shell transcripts a clean place to record why a previously good thing is temporarily narrowed, waiting on refresh, or displaced by a successor.

## What this does not decide

This RFC intentionally does **not** decide:
- whether status carriers are pulled, pushed, stapled, cached, holder-provided, or supervisor-provided;
- whether successor refresh is portal-mediated, shell-mediated, provider-mediated, or another service lane;
- whether some holds are reversible while others burn a path permanently;
- whether receiver stance is per-object, per-view, per-workspace, or per-provider;
- whether ViewFS itself will ever standardize one universal status taxonomy across providers.

## Shell consequences

A future ViewFS shell should be able to show:
- `held now`,
- `watch current`,
- `watch stale`,
- `suspended here`,
- `quarantined here`,
- `refresh available`,
- `successor required`,
- `invokable now`,
- and `history only`

as visibly different truths.

It should also be able to render one honest ladder that says:
`inspect possession` → `inspect watch/status` → `see local stance/hold` → `refresh or adopt successor if needed` → `invoke now`
without implying that any earlier row already guaranteed the later powers.

## SlopOS alignment

This separation fits SlopOS well because SlopOS already keeps imported provider status, recent-auth guidance, durable receipts, and local authority consequences on distinct seams, and sibling cubes like Ward and Harbor are sharpening exactly the kinds of continuous-signal / attenuation / refresh distinctions that make this split valuable.
ViewFS can therefore standardize the *shape* of watch-status truth now while leaving status carriers, watch receivers, successor epochs, and local hold mechanics open longer.
