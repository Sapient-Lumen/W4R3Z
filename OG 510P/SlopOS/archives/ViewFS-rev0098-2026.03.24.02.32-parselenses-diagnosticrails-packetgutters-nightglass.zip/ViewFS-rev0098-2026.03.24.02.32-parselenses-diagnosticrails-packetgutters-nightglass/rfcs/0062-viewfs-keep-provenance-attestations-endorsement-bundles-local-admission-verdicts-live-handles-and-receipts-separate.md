# RFC-0062: Keep provenance attestations, endorsement bundles, local admission verdicts, live handles, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates designation from authority, and permission outlook from live authority.
The next low-regret seam is **provenance / endorsement / local admission**.

A provenance attestation about where bytes came from or how they were produced is not the same thing as one endorsement bundle or trust-root choice.
Neither is the same thing as one local admission verdict such as `preview only`, `safe open only`, `admit runnable`, `needs review`, or `deny`.
And none of those are the same thing as one live handle held now.

If we collapse those classes too early, we make at least four mistakes:

1. **provenance starts masquerading as approval**
   - a signed or well-structured claim about origin, build, or review gets treated as if the local shell has already decided the object is runnable here.

2. **endorsements start masquerading as universal truth**
   - one signer, notary, transparency log, or reference-value bundle starts outrunning local policy and context.

3. **admission starts masquerading as possession**
   - a local `admitted` or `safe-open only` verdict gets mistaken for proof that the pane already has a live handle or namespace bind.

4. **history starts masquerading as current safety**
   - an old receipt or prior admit card gets mistaken for proof that the same verdict still applies now.

## The seam

Keep these classes visibly distinct:

1. **provenance attestation / claim envelope**
   - one statement about where bytes came from, how they were built, reviewed, imported, or transformed.
   - may be signed, structured, or richly evidenced.
   - not by itself one admission decision.

2. **endorsement bundle / trust-root input**
   - one local or imported set of endorsements, trusted signers, reference values, threshold/delegation metadata, or transparency-log witness material.
   - useful for appraisal.
   - not by itself one local verdict or live handle.

3. **local admission verdict / runnable-open posture**
   - one local decision such as `preview only`, `safe open`, `document only`, `admit runnable`, `deny`, `needs review`, or `history only`.
   - a local policy output, not current authority by itself.

4. **live handle / bind now**
   - one currently held capability, bind, or namespace insertion that can be used now.
   - this is still the current-authority truth.

5. **receipt / history**
   - evidence that one provenance check, endorsement fetch, local admission, deny, or runnable bind happened once.
   - not current authority.

## Working posture

- ViewFS should keep provenance claims inspectable even when the local verdict is still unknown or negative.
- ViewFS should keep endorsement bundles and trust-root choices visible without pretending they automatically outrank local policy.
- ViewFS should keep local admission verdicts explicit and explainable.
- ViewFS should keep live handles as the current-authority truth.
- ViewFS should keep receipts/history descriptive rather than reviving prior approval by inspection.

## What to steal

- **in-toto / SLSA**: statement, predicate, provenance, and verification remain distinct from the final relying-party decision.
- **RATS**: endorsements and reference values are verifier inputs, while appraisal policy produces the verdict.
- **TUF**: roles and delegations keep “who may speak about what” explicit instead of flattening trust into one signer.
- **Sigstore transparency**: append-only visibility is useful audit material, but logging one signature event is still not the same thing as local admission.
- **Gatekeeper / MOTW**: good guarded-open systems keep origin/provenance/risk signals, local admission, and actual open/exec separate.

## Phase-1 non-decisions

This RFC does **not** decide:
- the final provenance or attestation schema for ViewFS objects,
- whether every import or object class carries structured provenance in Phase 1,
- whether endorsement bundles are cached locally, mediator-provided, user-chosen, or all of the above,
- whether transparency-log style witnesses are local-only, optional, or absent in early phases,
- whether ViewFS exposes one universal local-admission taxonomy or several family-specific ones.

## Shell consequences

The shell/terminal should gain:
- **provenance ribbons** that can show `imported from`, `built by`, `reviewed by`, `derived from`, or `unknown provenance` without implying admission;
- **endorsement stacks** that can show `signed`, `threshold met`, `transparency logged`, `reference matched`, or `endorsement missing` as appraisal inputs;
- **verdict shutters** that can show `preview only`, `safe-open only`, `admit document`, `admit runnable`, `needs review`, or `deny` as local outputs;
- a **why-runnable inspector** that answers which claim, endorsement, and local rule grounded the current verdict;
- transcript rows that can distinguish `well-described`, `well-endorsed`, `locally admitted`, `live now`, and `receipt only`.

## Design bar

Before ViewFS standardizes any stronger trust/provenance/admission flow, it should be able to answer:

1. Is the shell showing a claim about origin/build/import, one endorsement input, one local admit/deny verdict, one live handle, or only history?
2. Can the user tell which signer/endorser or threshold/delegation lane mattered without treating that as universal truth?
3. Can the shell explain why something is `preview only`, `safe-open only`, `admit runnable`, or `deny` without claiming it already holds a live handle?
4. Can old admit/deny receipts stay useful for explanation without silently becoming standing approval?
