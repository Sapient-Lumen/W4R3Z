# RFC-0037: Keep resources, prompts, tools, apps, and bindings separate

Status: Draft  
Updated: 2026-03-22  
Decision family: helper feature catalogs / request binding / shell ergonomics

## Summary
ViewFS should keep one more seam explicit while helper-aware shelling is still fluid:

**resource descriptor ≠ prompt template ≠ tool descriptor ≠ interactive app surface ≠ completion suggestion ≠ request-bound attachment/selection ≠ live invocation/result ≠ durable receipt/history**

This keeps the shell free to browse, complete, attach, invoke, and replay helper-backed features **without letting catalog presence, prompt convenience, or old results quietly become current authority**.

## Motivation
Revision 0036 froze the split between publisher trust, installed helper packages, configured helper definitions, enabled state, start approvals, live sessions, request-scoped selection, and durable history.

That still leaves a dangerous gap:
- a helper can expose resources without any of them being bound now,
- expose prompts without any of them being adopted or expanded now,
- expose tools without any of them being approved or invoked now,
- expose an interactive app without that app being a generic object-open or route act,
- and offer completions without those suggestions counting as current authority.

Current precedent makes this risk real:
- MCP explicitly distinguishes resources, prompts, and tools,
- VS Code adds interactive apps and request-scoped tool enablement,
- MCP completions are only suggestions for prompt/resource arguments and carry their own disclosure risks.

## Decision
For future ViewFS design work, proposals must classify whether they are changing:
1. **resource descriptors** — helper-exposed context/data surfaces,
2. **prompt templates** — helper-exposed templated message/workflow surfaces,
3. **tool descriptors** — helper-exposed invocable function surfaces,
4. **interactive app surfaces** — helper-exposed interactive UI/session surfaces,
5. **completion suggestions** — helper-provided ranked hints for prompt/resource arguments,
6. **request-bound attachments/selections** — the exact subset currently attached or enabled for one request/pane/run,
7. **live invocation/results** — what actually rendered, launched, ran, succeeded, or failed now,
8. **durable receipts/history** — what only records past browse/attach/invoke/deny outcomes.

## Consequences
### Positive
- gives ViewFS a clean way to say “visible in the helper catalog”, “attached to this request”, and “actually executed” are different truths;
- creates room for strong shell UX without turning helper catalogs into hidden authority;
- keeps completion/help surfaces useful without laundering hints into current bindings;
- keeps future helper catalogs compatible with SlopOS plumb, capshell, and mediator posture.

### Costs
- one more helper-feature model to inspect and explain;
- richer receipts and shell chrome;
- more typed UI than a single generic “helper item” list.

## Non-goals
- freezing the final helper feature taxonomy,
- deciding whether interactive apps are first-class ViewFS objects,
- deciding the final schema for completion items, binding trays, or invocation receipts,
- deciding whether prompt templates may promote directly into user workflows.

## Near-term prototype
Build one helper-feature shell flow with:
- resource shelf,
- prompt chip,
- tool rack,
- app dock,
- completion popover,
- binding tray,
- invocation receipt that preserves feature-class truth.

If that feels magical **and** honest, keep the seam. If it feels noisy, trim the UI before trimming the boundary.
