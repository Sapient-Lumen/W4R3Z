# RFC-0004: Separate questions before freezing semantics

Status: Draft
Updated: 2026-03-21

## Summary
ViewFS and SlopOS are both still design-phase systems. This RFC argues that four questions should remain explicitly separate until evidence forces a coupling:
- immutable object identity,
- namespace naming within a view,
- mutable current-state semantics,
- and durable grant persistence / reopen.

This is not philosophical purity. It is a way to avoid locking in the wrong overloaded primitive too early.

## Problem statement
Traditional filesystem folklore often lets one thing try to do too much:
- a path doubles as discovery and identity,
- a file handle doubles as content identity and current mutable head,
- a bookmark or reopen token doubles as both user intent and durable authority.

That compression can be convenient, but it hides the exact edges ViewFS is trying to make explicit.

## Proposal
For ViewFS Phase 1 and early spikes, treat these as different surfaces:

### P1. Identity surface
- immutable object IDs
- manifest IDs
- exact closure references

### P2. Naming surface
- view bindings
- directory lookup
- synthetic local roots

### P3. Mutable-work surface
- root-pointer updates
- journals / changesets
- anchors / claims
- or other explicit current-head machinery

### P4. Grant persistence surface
- ephemeral grants
- transfer receipts
- durable reopen receipts / document references
- explicit revalidation outcomes

## Why this should be policy, not just taste
Because ViewFS is still early, any accidental coupling now will get repeated across:
- launch semantics,
- shell UX,
- portal receipts,
- compat path APIs,
- and later sync / collaboration work.

If we keep the questions separate, Phase 1 can still ship useful results without deciding the final answers to mutation, revocation, and naming stability.

## Immediate implications
- compat paths stay a membrane, not the identity model
- durable grants must say whether they are ephemeral, durable, or already revalidated
- mutable work-state spikes do not get to redefine immutable object IDs
- shell prompts and inspectors should display these distinctions explicitly

## Acceptance bar for future coupling
A future proposal may couple two of these surfaces only if it provides:
1. a concrete user problem that cannot be solved with the split model,
2. a clear threat and recovery story,
3. transcript-visible semantics,
4. and at least one narrow prototype or interoperability need.

## Good next experiments
- one immutable-object reopen flow
- one mutable-workspace reopen flow
- one compat path explanation tool
- one terminal block inspector that distinguishes object ID, current view name, mutable head, and durable receipt state

## Non-goals
- this RFC does not choose the final mutable model
- this RFC does not choose a final durable bookmark / docref format
- this RFC does not ban future stable mutable IDs
- this RFC does not settle final shell syntax
