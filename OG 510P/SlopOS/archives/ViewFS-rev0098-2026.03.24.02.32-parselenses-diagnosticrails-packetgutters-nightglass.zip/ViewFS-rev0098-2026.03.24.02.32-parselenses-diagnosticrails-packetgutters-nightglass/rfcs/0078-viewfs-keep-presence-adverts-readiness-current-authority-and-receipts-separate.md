# RFC-0078: Keep presence adverts, readiness, current authority, and receipts separate

## Status
Proposed.

## Problem
ViewFS already separates direct current authority, exact-name reachability, browse/list disclosure, synthetic views, published names, and receipts.
A new collapse risk sits one layer over that in every future chooser, palette, shell pane, and provider catalog:
- a provider can advertise that a thing or route exists,
- a provider can say it is ready/servable right now,
- a mediator can still require a fresh grant,
- a process can already hold direct current authority,
- or history can merely remember that an advert or ready state once existed.

Those are not interchangeable classes.
If ViewFS flattens them into one vague `it showed up, therefore it is usable` story, the shell will lie about freshness, mediate stale offers as if they were handles, and turn soft presence into fake current truth.

## Proposal
For Phase 1 and nearby spikes, ViewFS should preserve a hard distinction between:

1. **Presence advert / catalog presence**
   - a provider, helper, portal, catalog, outgoing directory, or discovery surface says an object, route, or affordance exists
   - but this may only be a published/discoverable offer, not a usable grant

2. **Readiness / serving truth**
   - the provider says the thing is ready, usable, or should currently accept work
   - this may still be weaker than direct local authority and may decay quickly

3. **Direct current authority / live handle**
   - the actor already holds the current authority needed to act
   - this remains stronger than any advert, catalog row, or ready bit

4. **Mediated grantability / grant-needed posture**
   - the system knows the next lane is `ask portal`, `resolve detour`, `request bind`, or `reacquire first`
   - that is a useful product truth, but it is not the same thing as already-held authority

5. **Receipt / history**
   - durable explanation of what was advertised, what was ready, what required mediation, and what authority actually existed or was granted

Published names, synthetic views, discoverability/listability, and ambient escape debt remain separate seams from RFC-0075, RFC-0076, and RFC-0077.

## Consequences
- ViewFS can expose catalogs, launch surfaces, and provider presence without pretending visibility equals authority.
- Shell/UI work can say `advertised`, `ready`, `grant needed`, `held now`, or `history only` instead of one fake `available` badge.
- Portal/import flows can explain stale/withdrawn/cooling-down offers without collapsing into path folklore.
- SlopOS alignment improves because design-phase discovery, catalog, and mediation surfaces stay informative without becoming early backend commitments.

## Non-goals
This RFC does not choose:
- one final advert protocol,
- one final readiness/watch vocabulary,
- one final catalog/index owner,
- one final grantability state machine,
- or one final provider-side publication schema.

## Adoption test
A future ViewFS proposal should answer:
- Is this merely **advertised / cataloged**?
- Is it currently **ready / serving**?
- Does the actor already hold **direct current authority**?
- Does it still require a **mediated grant / reacquire** step?
- Is there only a **receipt / history** row?

If the answer becomes `the shell saw it, so it must be usable now`, the burden of proof should be high.
