# RFC-0013: Keep watchers, notifications, and event feeds advisory and rebuild-friendly

## Status
Proposed.

## Problem
ViewFS already distinguishes handles, refs, receipts, session state, advisory registries, workspace trust, and preview/observation seams.
Another tempting collapse is to treat **watch registrations and change feeds** as if they were equivalent to **truthful authority-bearing state**.

That collapse is attractive because users want:
- live workspace panes,
- auto-refreshing smart folders,
- watchable transcripts,
- notification trays,
- and palette rows that always feel fresh.

But the historical precedents keep saying the same thing: watch feeds can overflow, coalesce, recrawl, lose continuity, or be weak on remote providers.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat:
- live handles/views,
- watch registrations,
- event feeds,
- rebuilt snapshots,
- and watch receipts/transcript traces

as distinct classes.

Watching a scope should not itself imply broader access, complete inventory, or replayable bearer authority.

## Consequences
- the shell can have exciting live-update UX without lying about freshness or scope
- incremental watchers can degrade honestly into explicit rebuild/rescan paths
- transcripts can safely retain watch receipts without reactivating live subscriptions
- query/smart-folder refresh can stay scoped to explicit views instead of becoming ambient inventory
- SlopOS background/notification seams can be specialized instead of bypassed

## Non-goals
This RFC does not choose:
- a final watch protocol,
- a final event taxonomy,
- a final watch-health enum,
- a final remote/distributed watch policy,
- or a final persistence model for watch history.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing **live authority**, a **watch registration**, an **event feed**, a **rebuilt snapshot**, or only a **receipt/transcript surface**?
- What happens when events are dropped, coalesced, or the provider says coverage is degraded?
- How does the design make rebuild/rescan explicit?
- Does a watch ever mint authority to newly mentioned objects outside the bound scope?
- What survives into history/share/restore, and is any of it bearer authority?

If the answer is “the feed is quiet so the state is definitely complete,” the burden of proof should be high.
