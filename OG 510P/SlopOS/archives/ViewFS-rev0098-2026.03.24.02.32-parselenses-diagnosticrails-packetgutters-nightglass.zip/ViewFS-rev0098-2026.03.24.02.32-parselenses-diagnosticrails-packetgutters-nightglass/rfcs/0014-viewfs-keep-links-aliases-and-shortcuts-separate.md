# RFC-0014: Keep links, aliases, shortcuts, and retargetable names on separate seams

## Status
Proposed.

## Problem
ViewFS already distinguishes handles, refs, receipts, session state, registries, workspace trust, preview seams, and watch seams.
Another easy collapse is to treat every link-like thing as if it were the same object:

- namespace alias,
- symlink-like object,
- durable reopen ref,
- shortcut/route object,
- transcript hyperlink,
- or live handle.

Historical systems keep these apart for good reasons:
- symlink/path traversal is security-sensitive,
- bookmarks exist because paths are fragile,
- desktop shortcuts often carry launch semantics,
- and histories/transcripts are not the same thing as current authority.

## Proposal
For Phase 1 and nearby spikes, ViewFS should keep at least these classes distinct:
- live handles,
- view-local names,
- namespace link objects,
- durable reopen refs,
- route/launch shortcuts,
- and link receipts/transcript traces.

Any proposal that collapses them should pay a high burden of proof.

## Consequences
- the shell can be richly clickable without smuggling authority through history
- durable reopen can stay non-bearer and explicitly revalidated
- route sheets / launch shortcuts can stay useful without becoming identity truth
- compat symlink support can be bounded and nofollow-aware without defining core semantics
- SlopOS document/openuri/safe-open seams can be specialized instead of bypassed

## Non-goals
This RFC does not choose:
- a final symlink/alias object format,
- a final hard-link policy,
- a final bookmark/reopen encoding,
- a final retarget heuristic,
- or a final terminal link protocol.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing a **live handle**, a **view-local binding**, a **namespace link object**, a **durable reopen ref**, a **route/launch shortcut**, or only a **receipt/transcript surface**?
- Does any auto-resolution or retargeting widen authority?
- Is the object bearer authority now, or only a way to attempt reopen/rebind later?
- If it renders as clickable text, what exactly will happen on click?
- What survives into history/share/restore, and is any of it live authority?

If the answer is “it is convenient to treat these as basically the same thing,” the burden of proof should be high.

