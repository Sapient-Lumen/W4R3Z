# RFC-0065: Keep completion candidates, accepted insertions, compiled command packets, prepared actions, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates helper-feature catalogs from request bindings and live results.
The next low-regret seam is **candidate suggestion / accepted buffer state / compiled action basis**.

A completion row or ghost-text suggestion is not the same thing as one insertion that now lives in the mutable prompt buffer.
Neither is the same thing as one compiled command packet that has been parsed and bound against the current pane, view, receipts, and object references.
Neither is the same thing as one prepared action/route plan that is actually ready for approval or launch.
And none of those are the same thing as one historical receipt.

If we collapse those classes too early, we make at least five mistakes:

1. **ranking starts masquerading as intent**
   - one highly ranked suggestion starts acting like the shell already knows what the user meant.

2. **accepted text starts masquerading as a plan**
   - a word or line inserted into the editable prompt starts acting like a compiled request or command packet.

3. **lazy detail starts masquerading as stable semantics**
   - extra description loaded while one row is highlighted starts acting like a durable property of the accepted insertion.

4. **heuristically observed command text starts masquerading as exact truth**
   - scraped or guessed command lines start acting like trusted packets suitable for rerun or delegation.

5. **history starts masquerading as current readiness**
   - an old accepted insertion or run receipt starts acting like a currently compiled packet for this pane.

## The seam

Keep these classes visibly distinct:

1. **completion candidate / ghost suggestion**
   - one advisory row, popup item, or inline suggestion.
   - ranked, filtered, and optionally partial.
   - not by itself one accepted insertion or current plan.

2. **resolved candidate detail**
   - extra detail fetched or computed when one candidate is focused or inspected.
   - may include provenance, rights hints, docs, or cost/warning notes.
   - not by itself one accepted insertion.

3. **accepted insertion / current mutable buffer state**
   - text or structured fragments now inserted into the editable prompt.
   - may be accepted fully or one word/segment at a time.
   - not by itself one compiled packet or one prepared action.

4. **compiled command packet / bound argument object**
   - one parsed/bound interpretation of the current buffer against this pane's current objects, receipts, namespace, and helper bindings.
   - may be `heuristic`, `shell reported`, `nonce verified`, or `object composed`.
   - stronger than raw text, still not one approved action by itself.

5. **prepared action / route plan**
   - one exact action basis after compile, preflight, and any needed approval shaping.
   - may still be `approval needed`, `portal needed`, `rebind needed`, or `ready`.
   - not the same thing as history.

6. **receipt / history**
   - evidence that one suggestion was shown, one insertion was accepted, one packet was compiled, or one action ran.
   - not current authority.

## Working posture

- ViewFS should let completions be rich and immediate without letting candidate ranking imply intent or authorization.
- ViewFS should let accepted insertions remain editable prompt state instead of silently promoting them into plans.
- ViewFS should keep packet compilation explicit enough that the shell can explain what current objects, receipts, or bindings were used.
- ViewFS should keep trusted command packets and merely observed text visibly different.
- ViewFS should keep receipts/history descriptive instead of silently reviving prior compiled state.

## What to steal

- **MCP completion**: prompt/resource argument completion is advisory, bounded, and security-sensitive rather than a selector/default oracle.
- **LSP completion / resolve**: list rows, lazy detail loading, and insertion semantics are distinct seams; insertion-defining fields should not drift when detail is resolved.
- **fish autosuggestions**: accepting one suggestion or one word is its own explicit act and still does not execute anything.
- **VS Code shell integration**: exact shell-reported commands and nonce-verified trust are stronger than heuristically observed terminal text.

## Shell consequences

The shell/terminal should gain:
- **ghost rows** that can stay advisory until accepted;
- **detail drawers** that load provenance/rights/docs on focus without pretending the insertion changed;
- **accept-word / accept-fragment** ladders that preserve fish-like speed without laundering the row into execution;
- **packet gutters** that appear only after insertion/parse and can say `heuristic`, `shell reported`, `trusted`, `portal needed`, `rebind needed`, or `ready`;
- **rerun safety badges** so only trusted or explicitly object-composed packets qualify for one-keystroke replay.

## Phase-1 non-decisions

This RFC does **not** decide:
- the final completion metadata wire format,
- whether packet compilation is shell-owned, helper-assisted, or terminal-assisted,
- whether ViewFS stores accepted insertions as transcript artifacts by default,
- whether all command packets are textual, structured, or mixed,
- whether nonce/trust semantics are shell-native, terminal-mediated, or both.

## Design bar

Before ViewFS standardizes any stronger completion or command-packet UX, it should be able to answer:

1. Is the shell showing a candidate, extra detail for a focused candidate, an accepted insertion, a compiled packet, a prepared action, or only history?
2. Can the user accept one word/fragment without that counting as approval or execution?
3. Can the shell explain which pane-local bindings, objects, or receipts shaped the compiled packet?
4. Can merely observed command text stay visibly weaker than a trusted command packet?
5. Can history remain useful for replay and teaching without silently becoming current compiled truth?
