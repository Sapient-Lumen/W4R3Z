# RFC-0060: Keep caveat sets, membrane leases, live handles, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates designation from authority, and durable reopen from current live handles.
The next low-regret seam is **declared caveats versus enforced attenuation**.

A macaroon caveat list, a zcap `allowedAction`/expiry chain, a shell-visible “read-only until tonight” card, and one current working delegated handle are not the same truth.
Neither is the same thing as a durable history row saying such a delegation happened once.

If we collapse those classes too early, we make at least four mistakes:

1. **display metadata becomes fake authority**
   - a transcript chip that says `read-only` starts being treated like the enforcement mechanism.

2. **bearer-ish envelopes become overtrusted**
   - exported caveat-bearing tokens start being mistaken for current local authority rather than one thing that still needs import/revalidation/adoption.

3. **live proxy/membrane semantics disappear**
   - the design forgets whether attenuation is enforced by a live local proxy, by verifier-side checks, by both, or by neither.

4. **history starts masquerading as liveness**
   - a past delegation receipt gets mistaken for proof that the delegated lane is still valid now.

## The seam

Keep these classes visibly distinct:

1. **caveat set / attenuation terms**
   - declarative narrowing terms such as action allowlists, audience restrictions, expiry/deadline hints, use limits, or locality constraints.
   - may travel in descriptors, envelopes, or transcript cards.
   - are not by themselves proof that anything is currently being enforced.

2. **enforced membrane / lease proxy**
   - a current mediator/proxy object that actually checks bounds and forwards or denies.
   - this is the active enforcement surface when the system chooses membrane-style delegation.

3. **live delegated handle now**
   - one currently held handle/capability/bind that can be used now.
   - it may have arrived through direct duplication, through proxy issuance, or through local re-adoption after verification.

4. **revival / revalidation designator**
   - a stored thing that may let the system later ask for a new live handle.
   - not the same thing as current authority.

5. **receipt / history**
   - evidence that a caveated or leased delegation was offered, approved, imported, renewed, revoked, or expired.
   - not current authority.

## Working posture

- ViewFS should prefer **attenuation by construction**.
- If attenuation is token-shaped, caveats must be monotonic and inspectable.
- If attenuation is proxy-shaped, the proxy should be the authority and the transcript should say so.
- Shell UX should expose whether enforcement is:
  - `descriptor only`
  - `verifier-checked`
  - `proxy-enforced now`
  - `live local handle`
  - `receipt only`

## What to steal

- Macaroons: caveats are first-class narrowing terms.
- zcaps: delegated capabilities carry explicit action and expiry constraints and revocation is endpoint-shaped.
- seL4: copy/mint with reduced rights is explicit, and revoke is explicit too.
- SlopOS D-LEASE: the proxy is the authority; descriptors are evidence, not authority.
- Capsicum/Fuchsia: possession of the current live authority matters; ambient namespace does not rescue you.

## Phase-1 non-decisions

This RFC does **not** decide:
- whether ViewFS uses macaroons, zcaps, sturdyrefs, or a custom envelope,
- whether proxy/membrane enforcement is universal or only for selected seams,
- whether any authority-bearing export is portable across devices or only local,
- whether expiry is wall-clock, monotonic, use-count, or policy-driven for every family,
- whether the custom shell ever exposes raw authority-bearing tickets by default.

## Shell consequences

The shell/terminal should gain:
- **caveat laminates**: compact visible cards for declared bounds,
- **membrane badges**: “enforced by local proxy”, “verifier checked”, or “designator only”,
- **expiry / use-budget gutters** that are visibly advisory unless tied to a current live membrane,
- **renew / revalidate / adopt** ladders instead of one magical “open again” verb,
- transcript rows that can distinguish `caveat-declared` from `caveat-enforced-now`.

## Design bar

Before ViewFS standardizes any attenuation/export path, it should be able to answer:

1. Where is the narrowing actually enforced?
2. Can the recipient tell whether they have current authority or only a caveated designator?
3. What exactly expires or gets revoked: the token, the proxy, the local handle, or just the history row?
4. Can the shell explain that difference without heroic security knowledge?
