# RFC-0031 — Keep proposers, proposal lanes, escalations, and adoptions separate

## Status
Accepted (archive guardrail)

## Why
The ViewFS shell is now ambitious enough that we need one more anti-collapse seam.
While SlopOS and ViewFS are both still in design, we should freeze as little concrete schema as possible — but we should freeze one principle now:

**proposal origin/source, proposal lane/scope, escalation requests, authoritative adoptions, and durable adoption receipts are different classes.**

If they collapse, the shell will eventually lie.
A workspace hint will become standing policy, a receipt replay will become a hidden proposer, and a helpful one-shot fix will quietly persist at broader scope than anyone reviewed.

## Decision
ViewFS must preserve a visible distinction between at least these classes:
1. **Proposal origin/source** — who or what authored the suggestion (`workspace`, `profile`, `org`, `history`, `receipt`, `mediator`, `shell-local`, etc.)
2. **Proposal lane/scope** — what target class is being proposed and how broad the requested effect would be (`once`, `pane`, `session`, `workspace`, `profile`, `org`, etc.)
3. **Escalation request** — a pending, reviewable interaction asking whether the proposed change may widen or persist
4. **Authoritative adoption** — the exact explicit act that makes the proposal live at a chosen scope, under current ceilings and denials
5. **Adoption receipt/history** — durable, bounded history of what was proposed, what was reviewed, what was adopted or declined, and at what scope

## Consequences
### Good
- the shell can surface smarter suggestions, repair hints, and workflow promotions without silently changing live truth;
- proposal provenance and scope become inspectable instead of folklore;
- SlopOS alignment improves because this mirrors explicit-basis, explicit-selection, and explicit-role discipline;
- future helper lanes can grow without forcing a final precedence lattice today.

### Costs
- more object classes to explain in docs and shell UI;
- more explicit metadata in prompt chrome, cards, and receipts;
- more temptation to over-design proposer taxonomies before real evidence exists.

## Non-goals
This RFC does not choose:
- a final proposer taxonomy,
- a final persistence schema for proposal/adoption receipts,
- a final precedence lattice between workspace/profile/org and explicit one-shot actions,
- a final escalation protocol,
- or a final shell protocol for proposer badges, scope chips, or adoption gates.

It only freezes the boundary.

## Required design rule for future changes
Any future proposal that touches policy-aware import/run/replay/rebind/workflow UX must classify whether it changes:
- proposal origins/sources,
- proposal lanes/scopes,
- escalation requests,
- authoritative adoptions,
- adoption receipts/history,
- or some explicit combination of the above.

If a proposal cannot say which class it changes, it is probably collapsing seams by accident.
