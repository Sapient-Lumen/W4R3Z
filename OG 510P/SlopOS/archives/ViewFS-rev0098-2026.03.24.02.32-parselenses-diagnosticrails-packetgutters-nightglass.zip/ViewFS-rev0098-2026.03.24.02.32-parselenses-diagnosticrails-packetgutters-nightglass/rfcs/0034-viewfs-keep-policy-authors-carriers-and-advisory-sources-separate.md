# RFC-0034: Keep policy authors, carriers, and advisory-only sources separate

Status: Draft  
Updated: 2026-03-22  
Decision family: source layering / trust gating / shell ergonomics

## Summary
ViewFS should keep one more seam explicit while policy-aware shelling is still fluid:

**author class ≠ carrier/container class ≠ trust gate ≠ advisory-only source ≠ effective active state ≠ durable receipt/history**

This keeps the shell free to discover, render, rank, and quarantine helper material aggressively **without letting the thing that carried a suggestion quietly become the thing that may author ceilings, trust gates, or active policy**.

## Motivation
Revision 0033 froze source precedence between owner/org policy, trust gates, user/profile preferences, workspace/imported material, and effective state.

That still leaves a dangerous gap:
- a trusted plugin/package/workspace/parent repo can **carry** material,
- a shell can surface that material beautifully,
- but none of that should automatically mean the carrier can **author** ceilings or trust gates.

Current product precedent makes this risk real:
- managed policies can override lower-precedence settings,
- restricted mode can keep workspace material visible but withheld,
- plugin-provided MCP servers can be implicitly trusted via plugin install while workspace-provided ones still need a different trust path,
- and Git-style origin/scope inspection is valuable precisely because layered config otherwise becomes folklore.

## Decision
For future ViewFS design work, proposals must classify whether they are changing:
1. **author classes** — who may author ceilings, trust gates, or effective preferences at all,
2. **carrier classes** — what transported or exposed candidate material,
3. **trust gates** — what source areas are admissible as active inputs right now,
4. **advisory-only rails** — what may propose, rank, or explain but may not author,
5. **effective active state** — what is currently live,
6. **durable receipts/history** — what only explains past evaluation/adoption.

## Consequences
### Positive
- makes “trusted carrier” and “authorized author” visibly different;
- gives the shell room to be ambitious without becoming a hidden second policy engine;
- keeps plugin/workspace/history/import rails useful even when they are not authorable;
- preserves exact debugging about why something stayed advisory-only.

### Costs
- more vocabulary in shell and receipt surfaces;
- some future source classes may need explicit policy-family-specific admissibility matrices;
- one more seam to teach in the archive.

## Non-goals
- freezing the final taxonomy of author classes,
- deciding whether plugins/extensions/packages can ever author higher-trust state,
- freezing the final serialization for author/carrier split receipts,
- deciding prompt chrome versus drawer placement.

## Near-term prototype
Build one source-aware shell flow with:
- author badge,
- carrier tag,
- advisory-only rail,
- trust-tunnel warning,
- authorability fuse drawer,
- activation receipt.

If that feels magical **and** honest, keep the seam. If it feels noisy, trim the UI before trimming the boundary.
