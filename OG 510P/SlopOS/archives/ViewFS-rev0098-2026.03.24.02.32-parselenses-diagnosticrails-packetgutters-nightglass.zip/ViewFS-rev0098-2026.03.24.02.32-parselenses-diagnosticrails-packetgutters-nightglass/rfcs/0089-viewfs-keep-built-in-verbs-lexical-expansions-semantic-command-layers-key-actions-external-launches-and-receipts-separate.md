# RFC-0089: Keep built-in verbs, lexical expansions, semantic command layers, key actions, external launches, and receipts separate

Status: exploratory  
Date: 2026-03-24

## Why this exists

Revision 0088 kept built-in shell baseline, reviewed customization bundles, startup files, project hooks, and receipts separate.
The next low-regret shell seam is **built-in verb / lexical expansion / semantic command layer / key action / external launch / durable receipt**.

A future custom shell can feel dramatically better than POSIX-era shells without inheriting the old confusion where one typed token, one keypress, one alias, one overlay, one wrapper function, and one external executable all look like the same thing.
That confusion is one of the oldest shell footguns:
- users cannot tell whether they are invoking product-native semantics or ambient shell glue,
- keybound widgets silently impersonate typed commands,
- abbreviations and aliases quietly hide what will really run,
- overlay/module activation changes command meaning without clear visibility,
- and history later lies about what surface is active now.

If ViewFS collapses these classes too early, it makes at least six mistakes:

1. **lexical shortcuts start masquerading as semantic commands**
   - one abbreviation or snippet expansion looks like a real command definition or built-in verb.

2. **overlay activation starts masquerading as product baseline**
   - a temporary command layer quietly redefines what a familiar token means.

3. **keybound actions start masquerading as typed command namespace**
   - one palette action or widget looks like a command the user could reason about in transcripts and receipts, even when it is editor-local interaction logic.

4. **external launches start masquerading as shell-native verbs**
   - the shell stops telling the truth about whether it is calling one product-native operation or just launching one executable object/script entry.

5. **history starts masquerading as active command surface**
   - because one alias/overlay/widget once existed, later panes stop telling the truth about what is active now.

6. **delight starts depending on folklore resolution rules**
   - command palettes, keymaps, and pretty prompts become hard to debug because no one can answer `what exactly won?`.

## The seam

Keep these classes visibly distinct:

1. **built-in verb**
   - one product-native shell command/action with stable help, semantics, and provenance.
   - examples: ViewFS-native `open`, `bind`, `route`, `receipt`, `publish`, `make-local`.

2. **lexical expansion**
   - typed-input rewriting before semantic command resolution.
   - examples: abbreviations, snippet-like expansions, alias-style token replacement, shorthand text macros.
   - not the same thing as one semantic command definition.

3. **semantic command layer**
   - one explicit user/module/overlay-provided command surface.
   - examples: custom commands, wrappers, exported overlay commands, reviewed workflow verbs.
   - may be activated/deactivated independently from startup baseline.

4. **key action / widget**
   - one interaction-mode or editor-local action reachable from a keymap, command palette, or widget surface.
   - examples: resize table, selection action, prompt widget, quick-terminal toggle, command-palette action.
   - not automatically part of the typed command namespace.

5. **external launch**
   - one external executable/script/app/object launch target.
   - may still be exact and capability-safe, but remains distinct from built-in shell verbs and shell-local semantic layers.

6. **receipt / history**
   - durable evidence that a built-in verb, expansion, overlay command, widget action, or external launch was proposed, chosen, blocked, or run before.
   - not current active command surface by itself.

## Working posture

- ViewFS should make typed command resolution inspectable enough to answer `builtin`, `expansion`, `overlay/custom`, `widget`, `external`, or `history only`.
- ViewFS should let the shell stay powerful with built-in verbs and explicit overlays instead of ambient alias/function folklore.
- ViewFS should let users preview lexical expansion separately from semantic command resolution.
- ViewFS should let key tables and command palettes stay excellent without pretending every key action belongs in transcript command history.
- ViewFS should keep external launches exact and capability-safe without flattening them into shell-native verbs.
- ViewFS should keep receipts/history explanation-rich while refusing to let them silently revive active overlays or old command winners.

## What to steal

- **SlopOS capshell posture**: explicit structured argv/launch meaning, explicit startup posture, and resistance to ambient shell folklore.
- **fish abbreviations** (REF-FISH-ABBR): typed abbreviations only expand for typed commands, not scripts, which is exactly the kind of lexical-versus-semantic honesty ViewFS needs.
- **Nushell overlays** (REF-NU-OVERLAYS): command layers can be activated and deactivated on demand instead of silently living in one global soup.
- **Nushell custom commands and `which`** (REF-NU-CUSTOMCOMMANDS, REF-NU-WHICH): custom commands can be first-class, and the shell can tell whether a name resolves to a program file, alias, or custom command.
- **zsh ZLE widgets** (REF-ZSH-ZLE): key-driven widget actions are a real surface of their own and should not be conflated with the typed command namespace.
- **Ghostty key tables and command palette** (REF-GHOSTTY-KEYTABLES, REF-GHOSTTY-CMDPALETTE): modal keybinding tables and palette actions are powerful precisely because they are explicit interaction layers.
- **VS Code profiles** (REF-VSCODE-PROFILES): settings, keyboard shortcuts, snippets, tasks, extensions, and MCP servers can be sliced as different profile contents instead of one blob.

## Shell consequences

The shell/terminal should gain:
- **verb provenance cards** that say `built-in`, `expanded`, `overlay`, `widget`, `external`, or `history only`;
- **abbr gutters** that preview lexical expansion before execution;
- **overlay racks** showing which command layers are active and what they contribute;
- **key-table lamps** that show when a modal interaction layer is active;
- **which ladders** that compare resolution winners across built-in verbs, overlay commands, and external launches;
- **palette/typed diff drawers** that explain whether one action is only a key/widget action or also a typed verb.

## Phase-1 non-decisions

This RFC does **not** decide:
- one final shell language,
- whether ViewFS supports traditional aliases at all or only explicit abbreviation/custom-command objects,
- one universal overlay/module format,
- one final command-palette protocol,
- whether every key action can ever be promoted into one typed verb,
- or a complete portability story across every host shell/runtime.

## Design bar

Before ViewFS standardizes richer command-surface UX, it should be able to answer:

1. Is this thing a built-in verb, lexical expansion, semantic overlay/custom command, key action, external launch, or only history?
2. Can the shell explain why a typed token resolved the way it did without guesswork?
3. Can users preview abbreviation/expansion separately from actual semantic resolution?
4. Can overlay activation/deactivation stay explicit and inspectable?
5. Can command palettes and key tables stay powerful without polluting transcript truth?
6. Can old receipts remain useful without silently reviving current command winners?
