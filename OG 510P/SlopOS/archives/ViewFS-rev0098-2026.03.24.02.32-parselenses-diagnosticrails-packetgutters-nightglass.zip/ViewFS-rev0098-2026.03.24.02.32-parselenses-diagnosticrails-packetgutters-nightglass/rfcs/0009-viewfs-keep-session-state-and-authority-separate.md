# RFC-0009: Keep session state and authority separate

## Status
Proposed.

## Problem
As ViewFS shell/terminal ideas get better, the system will naturally accumulate more saved state:
- command history,
- recent objects/directories,
- pane layouts,
- pinned blocks,
- notebooks,
- workflows,
- replay recipes.

If that state is allowed to silently stand in for live authority, ViewFS will recreate ambient-authority behavior under prettier names.

## Proposal
For Phase 1 and nearby design spikes, ViewFS should treat **session state** as a distinct class from:
1. live handles,
2. durable refs,
3. transcript receipts.

Session state may point at those other classes, summarize them, and help reacquire them, but it should not be treated as bearer authority by default.

## Consequences
- shell restore can be rich without silently reviving grants
- notebooks/workflows can be shareable without becoming disguised capability export formats
- recents/history can stay useful while admitting `portal needed`, `rebind needed`, `receipt only`, or `stale`
- the terminal can become dramatically better without undermining the capability model

## Non-goals
This RFC does not choose:
- a final SessionManifest schema,
- a final notebook/workflow file format,
- a final replay protocol,
- or whether some narrow local-only checkpoint format may later include authority under heavy constraints.

## Adoption test
A future ViewFS proposal should answer:
- Is this saved thing just **session state**, or is it a **durable ref**, **receipt**, or **live handle**?
- If it helps reacquire authority, where is the explicit rebind/reopen transition?
- Can the shell explain why an item is `ready`, `portal`, `receipt-only`, or `stale`?

If the answer is “history restored it automatically”, the burden of proof should be high.
