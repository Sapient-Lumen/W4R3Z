# RFC-0020: Keep import, export, move, transfer, share, and promise-later materialization on separate seams

## Status
Proposed.

## Problem
ViewFS already keeps many tempting collapses apart: handles versus refs, receipts versus authority, workspace access versus trust, previews versus execution, trash versus purge, checkpoints versus publication, and query manifests versus result snapshots.

Another dangerous collapse is to treat every cross-boundary object workflow as one vague file operation.
In practice these are different questions:
- import/copy-in,
- open in place,
- save/export,
- move/rehome,
- transfer/drag-drop/clipboard,
- share/delegate,
- promised/virtual file materialization.

## Proposal
For Phase 1 and nearby spikes, ViewFS should keep those classes distinct.
Any proposal that merges them should pay a high burden of proof and explain what becomes harder to inspect, audit, revoke, or replay safely.

## Consequences
- chooser/document/docref flows stay distinct from transfer offers and retrieval
- shell UX can expose truthful lanes instead of generic `open` / `copy`
- promised files can become a delightful feature without pretending they are already-live objects
- move/delete-on-paste style outcomes can be transcript-visible
- destination grants can stay narrower than broad directory authority

## Non-goals
This RFC does not choose:
- final receipt schemas for import/export/transfer/promise lanes,
- final provider rules for overwrite/replace,
- final materialization location for promised files,
- or final shell syntax.

## Adoption test
A future ViewFS proposal should answer:
- Is this action an **import**, **open**, **save/export**, **move**, **transfer**, **share/delegate**, or **promise/materialize** lane?
- Does it mint fresh local identity, preserve in-place authority, or only publish an offer?
- If the result is a move, where is the explicit outcome receipt?
- If the result is a promise, when do bytes actually exist and who can claim them?
- If a transfer later becomes an import or workspace bind, is that promotion explicit?

If the answer is “it’s just a file operation,” the burden of proof should be high.
