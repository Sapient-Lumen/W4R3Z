# RFC 0052: Keep object identity, parent anchors, namespace mutations, and receipts separate

## Status
Accepted for design-phase guardrails.

## Why this exists
ViewFS already keeps:
- object identity separate from current names and mutable heads,
- rooted walk handles separate from live byte-I/O handles,
- and durable refs/receipts separate from current authority.

This RFC keeps one more low-regret split visible while SlopOS and ViewFS are both still in design:

**the object being referred to, the source parent anchor, the destination parent anchor, the namespace-mutation act, and the durable mutation receipt/history artifact are different classes.**

That matters immediately if the future shell wants to be honest about:
- whether the current thing is only an object or file being named,
- whether the caller has the source-parent authority needed to remove that name from one namespace position,
- whether the caller has the destination-parent authority needed to create or replace another name,
- whether the act is `rename`, `link`, `unlink`, `replace`, `exchange`, or `create-new-only`,
- and whether a durable receipt is merely describing one namespace edit rather than reviving authority later.

## Lessons from the past
Classic filesystem APIs already make this split unavoidable:
- Fuchsia’s filesystem architecture notes that path-based operations like `rename` and `link` are unlike `open` because they act on multiple paths at once, must open both parent directories, and use a vnode token/cookie so the source-parent operation can safely refer to the destination parent;
- Capsicum rights make directory-mutation powers explicit: `CAP_RENAMEAT` is required on the source directory descriptor, `CAP_LINKAT` on the destination directory descriptor, and `CAP_UNLINKAT` on the destination descriptor when a rename will replace an existing target;
- Linux `renameat2()` exposes that mutation mode is its own dimension too, with flags such as `RENAME_NOREPLACE` and `RENAME_EXCHANGE` changing collision and swap behavior without changing object identity.

The lesson for ViewFS is not “be POSIX” or “copy one rename syscall family.”
The lesson is: **do not let current access to an object silently imply authority to rewrite the namespace around it, and do not let one generic `move` button hide source anchor, destination anchor, and replace/swap posture.**

## Guardrail
ViewFS should keep these classes visibly separate:
1. **Object identity / subject ref** — the thing whose current name or placement is being discussed.
2. **Source parent anchor** — the current namespace anchor that authorizes removing or detaching the existing name.
3. **Destination parent anchor** — the namespace anchor that authorizes creating, linking, replacing, or exchanging the destination name.
4. **Namespace-mutation act** — the reviewed operation (`rename`, `link`, `unlink`, `replace`, `exchange`, `mkdir`, etc.) plus its collision posture.
5. **Mutation receipt / history** — durable evidence describing one reviewed namespace edit.

## Consequences
We should be able to say things like:
- `object selected`
- `source parent only`
- `destination parent missing`
- `rename within same parent`
- `cross-parent move`
- `create-new only`
- `replace existing target`
- `exchange names`
- `receipt only`

without laundering them into one fake `can move this file` bit.

## Good answers might look like
- explicit source-parent and destination-parent cards on move/rename sheets
- mutation ladders that separate `rename`, `link`, `unlink`, `replace`, and `exchange`
- namespace-edit receipts that record source anchor, destination anchor, and collision posture
- shell review cards that can say `same object, new name` without pretending the byte/data handle changed
- route sheets that keep name changes separate from object import, byte I/O, or durable reopen

## What this does not decide
This RFC does **not** decide:
- the final Phase 1 set of namespace-mutation verbs ViewFS must expose;
- whether all providers support atomic exchange, noreplace, or replace-if-exists natively;
- whether cross-parent moves are implemented as one primitive, as a provider-local token/cookie trick, or as a higher-level compound transaction;
- whether every future object kind participates in namespace mutation the same way ordinary files/directories do.

## Shell implications worth stealing
A future custom shell/terminal should expose:
- **two-anchor rename/move cards** showing source parent, destination parent, and object identity separately;
- **collision-mode ladders** such as `create new only`, `replace target`, or `exchange names`;
- **name-diff receipts** that say `same object, different placement/name` without implying byte changes;
- **anchor-gap warnings** when the user can inspect an object but lacks one parent anchor needed for the requested namespace edit.

## Why this is a low-regret move
Even if SlopOS later changes its exact directory-handle, docref, or portal-import mechanics, this split stays useful.
It is the kind of boundary that keeps object-store identity, capability handles, explicit per-process namespaces, portal-mediated imports, and shell chrome honest while the deeper design is still moving.
