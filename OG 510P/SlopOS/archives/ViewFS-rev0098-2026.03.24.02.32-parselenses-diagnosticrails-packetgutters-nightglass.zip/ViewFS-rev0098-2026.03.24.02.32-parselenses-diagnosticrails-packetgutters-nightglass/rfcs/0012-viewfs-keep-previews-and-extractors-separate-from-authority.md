# RFC-0012: Keep previews, extractors, and observation sessions separate from authority

## Status
Proposed.

## Problem
ViewFS already distinguishes handles, refs, receipts, session state, advisory registries, and workspace trust.
Another tempting collapse is to treat **preview / extraction / inspection** as if it were equivalent to **open / execute / trust / reopen**.

That collapse is attractive because users want:
- instant peek panes,
- inline notebook outputs,
- side-by-side compare,
- thumbnails and extracted text,
- and quick open from the same surface.

But the best historical precedents keep preview read-only, bounded, and visibly separate.

## Proposal
For Phase 1 and nearby spikes, ViewFS should treat:
- live handles/views,
- preview or observation sessions,
- derived preview/extraction artifacts,
- and transcript receipts

as distinct classes.

Previewing a thing should not itself imply full open, execution, workspace trust, durable reopen, or durable authority export.

## Consequences
- the shell can have genuinely delightful preview UX without lying about authority
- derived artifacts such as extracted text or thumbnails can remain sidecars rather than becoming hidden source truth
- transcripts can safely retain preview receipts without becoming bearer-capability channels
- trust-sensitive rich outputs can degrade honestly instead of forcing an all-or-nothing model
- SlopOS preview/extraction boundaries can be specialized rather than bypassed

## Non-goals
This RFC does not choose:
- a final preview protocol,
- a final preview-provider registry,
- a final derived-artifact retention policy,
- a final cache policy,
- or a final rule for when a preview may support limited editing.

## Adoption test
A future ViewFS proposal should answer:
- Is this changing **live authority**, a **preview/observation session**, a **derived artifact**, or only a **receipt/transcript surface**?
- Can the same object still be inspected safely without launching the full app or enabling execution?
- Does the design preserve the difference between source bytes and derived renderings/extractions?
- What exactly gets persisted, and is any of it bearer authority?
- How does the shell explain blocked, degraded, or trust-gated preview states?

If the answer is “previewing it just counts as opening/trusting it,” the burden of proof should be high.
