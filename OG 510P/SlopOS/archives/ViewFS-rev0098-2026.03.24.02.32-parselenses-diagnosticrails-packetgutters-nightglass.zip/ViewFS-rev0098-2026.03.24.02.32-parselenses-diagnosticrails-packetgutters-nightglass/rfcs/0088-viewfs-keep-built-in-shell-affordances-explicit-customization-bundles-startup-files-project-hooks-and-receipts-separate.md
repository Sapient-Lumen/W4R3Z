# RFC-0088: Keep built-in shell affordances, explicit customization bundles, startup files, project hooks, and receipts separate

Status: exploratory  
Date: 2026-03-23

## Why this exists

ViewFS already separates exact exec objects, runner/runtime choice, bootstrap posture, workspace trust, and live sessions.
The next low-regret shell seam is **built-in shell affordance / explicit reviewed customization bundle / user-profile startup file / project-local activation hook / durable receipt**.

A future custom shell can be delightful without inheriting the ambient shell tradition that every start, prompt redraw, directory change, or project open is secretly a code-loading event.
Built-in prompt rendering, completions, palettes, receipts, and terminal integration are one class.
A reviewed customization bundle chosen by the user is another.
A host/user startup file such as a profile or rc script is another.
A project-local activation hook such as `.envrc`, `.env`, or one repo-managed activation script is another again.
And none of those are the same thing as one durable receipt that such a thing once ran or was explicitly blocked.

If we collapse those classes too early, we make at least five mistakes:

1. **ambient startup code starts masquerading as product baseline**
   - every prompt affordance silently depends on whatever host/user dotfiles happened to run first.

2. **project-local hook execution starts masquerading as harmless browsing**
   - opening or rebinding a directory turns into unreviewed code execution with misleadingly calm UI.

3. **reviewed customization starts masquerading as arbitrary profile import**
   - a digest-bound user-approved bundle gets flattened into the same class as ambient `~/.bashrc` or host-specific profile scripts.

4. **terminal integration starts masquerading as general startup permission**
   - manual shell-integration snippets, prompt markers, and cwd signals quietly become permission to run arbitrary startup code.

5. **history starts masquerading as current startup truth**
   - because one shell once sourced a profile or allowed a project hook, later sessions stop telling the truth about what is active now.

## The seam

Keep these classes visibly distinct:

1. **built-in shell affordance**
   - shipped prompt rendering, completion, semantic marks, receipt views, palettes, notebook chrome, and other product-native shell behaviors.
   - not loaded from host startup code.

2. **explicit customization bundle**
   - one reviewed, digest-bound, user-promoted shell customization artifact.
   - examples: explicit prompt theme bundle, reviewed alias/function pack, explicit shell-integration module, user-owned workflow pack.
   - smaller and more inspectable than ambient startup-file execution.

3. **startup file / profile script**
   - host/user-level startup code that runs because the shell starts.
   - examples: `~/.bashrc`, `~/.zshrc`, PowerShell profiles, host-level shell init scripts.
   - powerful, sometimes useful, but still not product baseline or reviewed customization by default.

4. **project-local activation hook**
   - directory or project-scoped code/data that requests activation when entering a tree or launching in a workspace.
   - examples: `.envrc`, `.env`, repo-local activation scripts, per-project shell bootstrap files.
   - stronger and riskier than mere browsing or project binding.

5. **receipt / history**
   - durable evidence that one startup file, customization bundle, or project hook was proposed, blocked, approved, or executed before.
   - not current shell baseline and not current authority by itself.

## Working posture

- ViewFS should let the shell stay useful in a **clean built-in baseline** without needing host/user startup scripts.
- ViewFS should let users promote useful shell customizations into explicit reviewed bundles instead of normalizing ambient rc/profile lore.
- ViewFS should keep project-local activation hooks behind explicit trust/review gates.
- ViewFS should make prompt/terminal integration inspectable and manually sourceable without treating that as permission for arbitrary startup code.
- ViewFS should keep receipts/history explanation-rich while refusing to let them silently revive current startup posture.

## What to steal

- **SlopOS capshell startup-profile posture**: no implicit rc/profile files, no per-directory hooks, and no prompt/cwd code-loading events in the reviewed baseline.
- **direnv allow + require_allowed** (REF-DIRENV-ALLOW, REF-DIRENV-REQUIREALLOWED): explicit allow and re-allow-on-change is the right emotional model for project-local activation hooks.
- **VS Code Workspace Trust / Restricted Mode** (REF-VSCODE-WORKSPACE-TRUST, REF-VSCODE-COPILOT-SECURITY): browsing a project can stay useful while tasks, debugging, workspace settings, and agents remain withheld until trust is granted.
- **Ghostty shell integration** (REF-GHOSTTY-SHELL-INTEGRATION): shell integration should be inspectable and manually sourceable, especially when users switch shells or bypass normal startup paths.
- **PowerShell profiles** (REF-POWERSHELL-PROFILES): startup profiles are real executable scripts and should be treated as such instead of as harmless personalization mist.

## Shell consequences

The shell/terminal should gain:
- **clean-start lamps** that say `built-in only`, `reviewed bundle`, `host profile active`, `project hook pending`, `project hook blocked`, or `history only`;
- **bundle ledgers** that show which explicit user-owned customization bundles are active and what they changed;
- **profile-debt drawers** that make ambient rc/profile execution visible instead of silently blessable;
- **hook quarantine shutters** so project-local activation requests can be inspected, diffed, allowed once, promoted, or denied;
- **prompt provenance cards** that explain whether a fancy prompt came from built-in shell code, a reviewed bundle, one startup script, or one project hook.

## Phase-1 non-decisions

This RFC does **not** decide:
- one universal shell-customization bundle format,
- whether ViewFS ever imports legacy rc/profile files directly,
- whether project-local hook review is once/pane/session/workspace/profile scoped,
- one permanent taxonomy for prompt/theme/plugin customization objects,
- whether every host shell can participate equally in the clean baseline.

## Design bar

Before ViewFS standardizes richer shell personalization/import UX, it should be able to answer:

1. Is the shell talking about built-in baseline, reviewed bundle, startup file, project hook, or only history?
2. Can the shell explain why a prompt or alias/function exists without screen scraping or guesswork?
3. Can project browsing remain useful while activation hooks stay withheld pending review?
4. Can useful ambient profile ideas be promoted into explicit reviewed bundles instead of normalized ambiently?
5. Can old approvals/history stay useful without silently reviving current startup posture?
