# RFC-0075: Keep store membership, synthetic views, live handles, published names, and receipts separate

## Status
Proposed.

## Problem
ViewFS already works hard not to collapse object identity, durable reopen, live handles, and current namespace binds.
A remaining collapse risk is now visible at the exact seam the user will feel first:
- an object that exists in the store,
- a restricted or synthetic view that projects it somewhere,
- a live capability handle that can act on it now,
- a published name inside one concrete process namespace,
- and the historical receipt that says how that happened.

Those are not the same class.
If ViewFS treats them as one convenient “file object,” it will accidentally re-invent ambient path folklore under a capability-friendly paint job.

## Proposal
For Phase 1 and nearby spikes, ViewFS should preserve a hard distinction between:

1. **Store membership / object ref**
   - the fact that some local object exists in the object store
   - and perhaps has a stable content or manifest descriptor

2. **Synthetic view / portal projection**
   - a restricted, mediated, or provider-shaped namespace view that makes an object reachable somewhere
   - without implying local publication into every pane/process view

3. **Live handle / current authority**
   - a capability the holder can use now
   - distinct from both store membership and view publication

4. **Published name / local bind**
   - the fact that one object or view is currently attached at one place in one concrete per-process namespace
   - which may change without changing the object itself

5. **Receipt / history**
   - the durable explanation of how a selection, import, projection, publish, or bind occurred
   - which should stay inspectable without reviving authority by default

## Consequences
- ViewFS can keep the object store small and immutable-first without freezing one final namespace or portal model.
- Portal-mediated imports can stay honest about request objects, restricted synthetic views, and later local publication.
- The shell can show `in store`, `projected by portal`, `live handle here`, `published in this pane`, and `receipt only` as different truths.
- Future capability dictionaries, bundles, or view fragments remain easier to reason about because grouped authority still does not automatically equal publication.

## Non-goals
This RFC does not choose:
- one final object-store schema,
- one final portal/import protocol,
- one final publication syntax,
- one final overlay or multi-bind model,
- or one final persistence rule for synthetic portal-style views.

## Adoption test
A future ViewFS proposal should answer:
- Is the thing merely **in the store**, or also **reachable through a synthetic/mediated view**?
- Does the actor have a **live handle now**, or only a **receipt/designator**?
- Is the object **published here** in this pane/process, or only available somewhere else?
- Did a portal/provider project the object into a restricted view, or did ViewFS locally publish it into a process namespace?
- If a path-like label is shown, is it describing one current publication site rather than object essence?

If the answer becomes “it is all one file-ish thing for convenience,” the burden of proof should be high.
