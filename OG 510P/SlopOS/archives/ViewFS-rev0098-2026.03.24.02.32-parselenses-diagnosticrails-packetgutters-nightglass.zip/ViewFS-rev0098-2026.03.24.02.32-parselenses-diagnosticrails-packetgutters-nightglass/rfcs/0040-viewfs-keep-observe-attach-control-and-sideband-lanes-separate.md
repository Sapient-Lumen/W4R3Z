# RFC-0040: Keep observe, attach, control, and sideband lanes separate

Status: Draft  
Updated: 2026-03-22  
Decision family: live sessions / shell ergonomics / deferred interaction

## Summary
ViewFS should keep one more seam explicit while live-session shelling and helper interaction are still fluid:

**read-only observe/query/follow lane ≠ interactive attach lane ≠ control-message lane ≠ injected exec/debug lane ≠ sideband tunnel/forward lane ≠ durable transcript/history**

This keeps the shell free to watch, attach, signal, update, debug, and tunnel **without letting one vague “connected session” concept silently change current authority, control rights, or history semantics**.

## Motivation
Revision 0039 froze the split between close/cancel, terminate, detach/delete, retry-fresh, reset/fork/attach, and durable history.

That still leaves a dangerous gap:
- a user may want to follow output without gaining stdin,
- attach read-only without becoming a controller,
- send a control message without opening a shell,
- inject a debug command without pretending it is the original process,
- or open a port-forward/proxy lane without confusing that with object authority.

Current precedent makes this risk real:
- Kubernetes keeps `logs`, `attach`, `exec`, and `port-forward` distinct,
- `tmux` keeps read-only clients and control mode distinct,
- Temporal keeps Queries, Signals, and Updates distinct,
- XDG InputCapture keeps `enabled` distinct from `active`,
- live-session transcripts routinely outlive the actual session/control channel.

## Decision
For future ViewFS design work, proposals must classify whether they are changing:
1. **observe/query/follow lanes** — read-only live observation or query answers,
2. **interactive attach lanes** — attachment to existing live surfaces with stdin/tty semantics,
3. **control-message lanes** — typed control/update/query channels distinct from transcript flow,
4. **exec/debug lanes** — new injected commands or debug shells distinct from the original live surface,
5. **sideband lanes** — forwarded ports, proxies, tunnels, or auxiliary access channels,
6. **durable transcript/history** — what only records that one of those acts happened in the past.

## Consequences
### Positive
- gives ViewFS a clean way to say “I only watched” versus “I could type into it”;
- preserves observe-only and read-only modes as first-class truths;
- creates room for great shell UX around control panes, sideband badges, and debug drawers;
- aligns with SlopOS mediator/session posture and with current live-session ecosystems.

### Costs
- one more family of live-session objects to explain;
- richer shell chrome and receipt cards;
- more typed UI than a single vague connected-session model.

## Non-goals
- freezing the final live-session schema for ViewFS,
- deciding whether every helper/provider must support every live-session lane,
- deciding final multiplexing protocol for control panes,
- deciding whether debug exec always spawns a new child view in Phase 1.

## Near-term prototype
Build one live-session shell flow with:
- follow tail,
- read-only versus interactive attach rail,
- control pane,
- debug launch drawer,
- sideband badge,
- live-session receipt preserving observe/attach/control/debug/tunnel truth.

If that feels magical **and** honest, keep the seam. If it feels noisy, trim the UI before trimming the boundary.
