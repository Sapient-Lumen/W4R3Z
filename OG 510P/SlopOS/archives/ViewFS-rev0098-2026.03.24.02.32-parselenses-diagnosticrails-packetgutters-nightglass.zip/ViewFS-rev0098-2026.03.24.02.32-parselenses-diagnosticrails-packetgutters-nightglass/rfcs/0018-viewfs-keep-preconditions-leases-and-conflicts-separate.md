# RFC-0018: Keep optimistic preconditions, short leases, ownership hints, conflict artifacts, and override acts on separate seams

## Status
Proposed.

## Problem
ViewFS already distinguishes handles, refs, receipts, session state, registries, trust gates, previews, watch feeds, links, origin/quarantine, delete/recovery, and time-travel semantics.

Another easy collapse is to treat all concurrent-write behavior as if it were one thing called “locking”:
- expected-old / compare-and-swap preconditions,
- create-if-absent semantics,
- short leases / reservations,
- ownership or field-claim metadata,
- rejected-write / conflict artifacts,
- explicit override / takeover acts.

History says these are not the same question.

## Proposal
For Phase 1 and nearby spikes, ViewFS should keep at least these classes distinct:
- optimistic precondition,
- create-if-absent guard,
- short lease / reservation,
- ownership hint / field claim,
- conflict artifact / receipt,
- explicit override / takeover.

Any proposal that collapses them should pay a high burden of proof.

## Consequences
- the shell can make ordinary writes safe by default without requiring a giant lock manager
- bounded reservations remain possible without becoming the only write gate
- conflict handling can be transcript-visible and merge-friendly instead of opaque
- future field/subtree ownership ideas can be explored without committing the whole object model to them
- override/takeover can remain honest, reviewable, and explicit rather than a hidden retry path

## Non-goals
This RFC does not choose:
- a final mutable-head schema,
- a final version/generation/digest token format,
- a final lease object schema,
- a final ownership or field-claim model,
- or a final merge artifact format.

## Adoption test
A future ViewFS proposal should answer:
- Is this an **optimistic precondition**, a **reservation/lease**, an **ownership hint**, a **conflict artifact**, or an **override**?
- Does failure produce a truthful compare/retry/merge/takeover path?
- Does any token or receipt accidentally become live bearer authority?
- Could the same user goal be met by expected-old compare-and-swap rather than a stronger locking commitment?
- If override exists, is it explicit and transcript-visible?

If the answer is “users just think of this as locking,” the burden of proof should be high.
