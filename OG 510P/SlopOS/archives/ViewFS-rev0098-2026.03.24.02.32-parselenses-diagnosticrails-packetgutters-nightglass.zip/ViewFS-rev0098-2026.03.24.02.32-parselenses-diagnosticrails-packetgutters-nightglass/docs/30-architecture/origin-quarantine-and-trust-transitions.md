# Origin, quarantine, trust, and safe-open transitions

Purpose: keep **origin evidence**, **quarantine/risk state**, **safe-open disposition**, **explicit clear/trust decisions**, and **live execution/open authority** on separate seams.

## Core rule
ViewFS should distinguish at least six related but different things:
- **origin evidence** — where the object came from (`network`, `email`, `transfer`, `workspace`, `local tool`, `unknown`) and how it arrived,
- **quarantine / risk state** — whether the object is currently considered risky or requires a guarded path,
- **preview / safe-open session** — a constrained observational or disposable opening mode,
- **explicit clear / trust decision** — a user-visible, transcript-visible act that changes how one object or one bounded class may be handled,
- **sanitized or re-exported derivative** — a fresh artifact produced by an explicit safe-open/export/sanitize workflow,
- **live open / exec authority** — current ability to hand the object to a full viewer, interpreter, or launcher.

Those should not silently collapse into one primitive.

A user should be able to say:
- “this object came from mail or the network,”
- “this object is still quarantined,”
- “this session is preview/safe-open only,”
- “this exact object was explicitly cleared,”
- “this exported derivative is a new artifact, not the old risk state with a nicer name,”
- or “this is currently executable/openable with live authority.”

## Why this matters
Historically, systems try to help with downloaded or transferred risk, but the boundary gets muddy fast:
- origin metadata is attached but not preserved consistently,
- preview/open paths quietly become trust-clearing paths,
- a broad trusted directory or location bypasses later checks,
- shell history and recent items forget the risk story,
- or a convenience click silently treats “downloaded once” as “trusted forever.”

That is exactly the sort of collapse ViewFS should avoid while SlopOS is still in design.

## Useful precedents
- **REF-APPLE-QUARANTINEKEY**: Apple exposes quarantine properties as file metadata rather than pretending the question does not exist.
- **REF-APPLE-GATEKEEPER** and **REF-APPLE-SAFEOPEN**: Gatekeeper tries to ensure only trusted software runs and warns users before opening unknown developers’ apps.
- **REF-APPLE-GATEKEEPER-BYPASS**: Apple security content keeps recording quarantine / Gatekeeper bypasses, which is a reminder that origin/risk machinery is valuable but brittle.
- **REF-MS-ATTACHMENTMGR**: Windows explicitly marks attachments with zone-of-origin information because otherwise it cannot make proper risk assessments.
- **REF-MS-MOTW-OFFICE**: Microsoft Office treats Mark-of-the-Web as a separate signal that can block macros and push documents into guarded handling.
- **REF-MS-APPGUARD**: untrusted files can be opened in an isolated container rather than being silently trusted.
- **REF-MS-SMARTSCREEN** and **REF-EDGE-DL-DANGER**: reputation and dangerous-file-type signals influence how downloads are interrupted or blocked, which is useful inspiration for shell badges and safe-open rails.
- SlopOS already has adjacent seams here: `rfcs/0053-origin-quarantine-and-safe-open.md`, `open-untrusted-posture-v0.md`, `quarantined-execution-boundary-v0.md`, `quarantined-code-input-boundary-v0.md`, and `rfcs/0054-authority-diffs-and-consent-receipts.md` / `rfcs/0069-capability-diffs-for-consent-and-receipts.md`.

## Recommended ViewFS reading of the split

### 1. Origin evidence should be visible and monotonic, not magical authority
ViewFS should preserve useful provenance such as:
- source class,
- arrival route,
- parent/transfer relationship,
- and transcript-visible receipts.

But origin evidence is not, by itself:
- trust,
- live authority,
- or durable reopen success.

### 2. Quarantine should stay object-local and sticky until explicit change
A risky object should be able to stay risky even if it is:
- copied,
- rebound into a workspace,
- shown in recents,
- rendered in a palette,
- or previewed in a shell pane.

Do not let “it moved” or “it was clicked” become a silent clear.

### 3. Safe-open / preview should be a lane, not a clearance event
A safe-open path is useful exactly because it is **not** the same thing as:
- full trust,
- execution eligibility,
- broad workspace approval,
- or durable reopen success.

The shell should feel great here:
- `peek`,
- `open safe`,
- `open in disposable`,
- `export sanitized`,
- `request clear`,
- `show why blocked`.

But it should not mutate trust in place just because an inert viewer succeeded.

### 4. Clear / trust decisions should be explicit, narrow, and receipted
If ViewFS ever clears or narrows quarantine, that should be:
- object-local or narrowly scoped,
- transcript-visible,
- explainable,
- and reviewable later.

Path-wide or directory-wide trust is historically convenient but dangerous. Broad “trusted location” semantics should therefore be treated with a high burden of proof.

### 5. A fresh derivative is not the same object with a cleaner vibe
If a safe-open, sanitize, or export path produces a new artifact, ViewFS should preserve the distinction between:
- original risky object,
- trusted/cleared source object,
- and fresh derivative artifact.

That keeps the object store honest and makes receipts much more valuable.

### 6. Code-bearing and document-bearing paths may need different defaults
A capability-native system can afford to say:
- document-like objects default to preview/safe-open rails,
- exact code / script / executable inputs stay blocked or require a sharper override,
- and shell tooling should say which class it believes it is handling.

This mirrors the useful part of existing ecosystems without inheriting their ambient path assumptions.

### 7. Recents, links, notebooks, and palettes must preserve the risk story
If something is:
- `quarantined`,
- `preview-only`,
- `safe-openable`,
- `clear requested`,
- `cleared-local`,
- `rebind needed`,
- or `receipt only`,

the shell should keep saying so later.

A great terminal should make the truth easier to see, not easier to forget.

## A promising future object family
Without freezing names yet, ViewFS may eventually want ideas such as:
- **OriginReceipt** — a transcript-safe note of where/how an object arrived,
- **QuarantineMark** — risk-state metadata attached to an object or derivative,
- **SafeOpenSession** — a constrained preview/open lane with explicit export/keep actions,
- **TrustDecisionReceipt** — evidence that a user or policy explicitly cleared/approved something,
- **SanitizedExportReceipt** — evidence that a fresh derivative was minted through a bounded workflow.

The seam discipline matters more than the nouns.

## How this maps onto SlopOS seams
- **origin/quarantine/safe-open** ↔ `rfcs/0053-origin-quarantine-and-safe-open.md`
- **durable document grants** ↔ `rfcs/0089-document-portal-and-durable-file-handles.md`
- **exact reveal / launch boundaries** ↔ `openuri-portal-posture-v0.md`, `openuri-showitem-exactness-boundary-v0.md`
- **quarantined code/document boundaries** ↔ `quarantined-execution-boundary-v0.md`, `quarantined-code-input-boundary-v0.md`, `open-untrusted-posture-v0.md`
- **consent / explain / receipt UX** ↔ `rfcs/0069-capability-diffs-for-consent-and-receipts.md`, `rfcs/0115-capability-safe-shell-and-automation.md`

## Shell implications
- every row/link/object card should be able to show `origin`, `risk state`, and `next allowed action`
- recent-item and palette rows should preserve `quarantined`, `safe-open`, `cleared-local`, or `receipt-only` states
- shell clicks should default to `peek` or `open safe` when the object is risky, not to generic full-open
- clear/trust decisions should produce receipt cards and authority diffs
- safe-open sessions should make `export derivative` and `copy receipt` feel first-class
- “why blocked?” should be a one-keystroke explanation surface

## Anti-goals
- treating origin metadata as if it were already trust
- treating preview/safe-open success as if it cleared the source object
- broad trusted-path or trusted-workspace semantics by default
- letting notebook/session restore silently forget quarantine state
- turning transcript clicks into invisible trust overrides
