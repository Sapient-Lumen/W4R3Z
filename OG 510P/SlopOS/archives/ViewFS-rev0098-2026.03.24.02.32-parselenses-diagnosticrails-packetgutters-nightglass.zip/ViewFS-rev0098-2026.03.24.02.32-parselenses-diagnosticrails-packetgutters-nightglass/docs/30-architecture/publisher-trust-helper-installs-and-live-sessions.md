# Publisher trust, helper installs, and live sessions

Purpose: keep the next helper/tool seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough shell and helper ambition that we need one more anti-collapse boundary:
**publisher trust ≠ installed helper package ≠ configured helper/server definition ≠ enabled state ≠ start approval ≠ live brokered session ≠ request-scoped tool selection ≠ durable receipt/history**.

That split is the safest way to let the shell discover and stage helpers aggressively **without letting installation, discovery, or remembered enablement quietly become standing live authority**.

## Why this seam matters now
SlopOS already points this way:
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md` keeps cross-boundary designation and consent concentrated in a mediator.
- `docs/30-architecture/authagent-provider-role-boundary-v0.md` keeps provider/agent surfaces role-distinct from the underlying authority.
- `rfcs/0115-capability-safe-shell-and-automation.md` keeps automation explicit-only at startup and resists ambient rc/profile drift.
- `docs/30-architecture/capshell-startup-profile-posture-v0.md` declines implicit rc/profile and per-directory hook loading.
- `docs/30-architecture/powerbox-posture-v0.md` already refuses generic remembered-grant libraries and app-visible approval inventories.

ViewFS should preserve that posture in future helper/tool UX instead of creating a softer second story where:
- trusting a publisher quietly means every installed helper is effectively live forever,
- finding or installing a helper silently starts it,
- enabling a helper silently grants current-session or future-session authority,
- or past live sessions quietly count as current authority because the package is still installed.

## Lessons we must learn from the past

### 1. Publisher trust, package install, and server start are different events
VS Code now has explicit extension-publisher trust prompts, and its agent plugin docs say plugin MCP servers are implicitly trusted when the plugin is installed, unlike workspace MCP servers which do not get the same startup trust path.

Why this matters:
- ViewFS should expect **publisher trust** to be a separate class from **installed package presence**;
- installation can still be a precondition for later use without meaning a helper may start or run now;
- different carrier classes may deserve different startup-trust rules even if they surface similar helper definitions.

### 2. Configuration origin, enablement, and start approval are different seams
VS Code’s MCP docs keep configuration in `mcp.json`, store enable/disable state separately from that shared configuration, allow global or per-workspace enablement, and require trust confirmation before a server starts; the security docs say MCP trust can be revoked and re-prompted after configuration changes.

Why this matters:
- ViewFS should keep **configured helper definition**, **enabled state**, and **start approval** as separate classes;
- a shared workspace definition should not be laundered into local enablement or live authority;
- config drift and trust reset should invalidate live-start assumptions without pretending the helper vanished.

### 3. A live brokered session is stronger than remembered setup state
Deno’s permission broker is the cleanest warning here: once the broker is active, local flags and prompts are no longer authoritative.

Why this matters:
- ViewFS should treat a **live brokered session** as a separate authority-bearing object;
- remembered install/config/enable state should never masquerade as a current live session;
- the shell needs a visible way to say “installed”, “enabled”, “approved to start”, and “currently live” are not the same.

### 4. Request-scoped tool selection is not the same as helper availability
VS Code keeps tool selection separate too: tools can be toggled in the tools picker per request/session, even after the server exists and is running.

Why this matters:
- ViewFS should keep **live session** distinct from **request-scoped selection**;
- a live helper can expose many tools/resources/prompts without all of them being active in the current action;
- receipts should preserve whether a result came from install-time trust, start-time approval, request-time selection, or some combination.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **PublisherTrustRecord** — trust in a marketplace/publisher/origin class, not in every helper outcome forever
- **InstalledHelper** — a package or helper bundle present on disk/profile/workspace
- **HelperDefinition** — discovered/configured tool/server definition plus provenance and location
- **EnablementState** — local toggle state that may be global, profile-local, workspace-local, or pane/session-local
- **StartGate** — the current approval/trust verdict required before the helper may become live
- **LiveSession** — a started helper/server/broker session with concrete runtime identity and capabilities
- **RequestSelection** — the subset of tools/prompts/resources actually selected for the current operation
- **LifecycleReceipt** — durable history saying what was installed, enabled, started, selected, denied, stopped, revoked, or merely remembered

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **publisher badges** — who vouched for install, separate from whether anything is running now
- **installed cards** — present-on-disk/profile/workspace, but not necessarily enabled or live
- **enable toggles with visible scope** — global, workspace, session, or pane
- **start gates** — a clear “may start?” checkpoint that survives config drift and trust resets
- **live-session beacons** — a loud marker when a helper is actually running and what session/pane it belongs to
- **tool racks** — request-scoped selection surfaces that do not lie about global availability
- **lifecycle receipts** — installed, enabled, start-approved, live, selected, denied, revoked, stopped, or historical-only

That is the right way to make a shell feel ambitious without letting “installed” quietly turn into “live and authorized”.

## What not to decide yet
- the final package/plugin/helper taxonomy,
- whether helper installation is ever allowed directly from workspace-carried material,
- whether certain helper classes may auto-start from protected sources only,
- the final schema for start approvals, enablement toggles, live session descriptors, or lifecycle receipts,
- whether request-scoped tool selection should be pane-bound, session-bound, or action-bound by default.
