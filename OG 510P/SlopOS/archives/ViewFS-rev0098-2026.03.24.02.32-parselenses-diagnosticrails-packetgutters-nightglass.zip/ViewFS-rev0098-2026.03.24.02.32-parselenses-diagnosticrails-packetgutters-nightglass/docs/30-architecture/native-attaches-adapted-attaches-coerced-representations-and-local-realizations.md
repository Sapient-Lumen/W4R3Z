# Native attaches, adapted attaches, coerced representations, and local realizations

This note sharpens one more low-regret ViewFS separation:
**directly usable here in this lane**, **usable only through one adapter or relay**, **available only as one alternate representation**, **explicitly made stronger/local here**, and **remembered in receipts/history** are different truths.

Relevant precedents:
- **REF-ANDROID-VIRTUALFILES** and **REF-ANDROID-SAF**: a selected document can be provider-owned and persistently accessible, while some virtual files still require alternate MIME coercion and cannot be opened directly as ordinary byte streams.
- **REF-WIT-RESOURCE-HANDLES**: resources are handles to external entities and can be passed by owned or borrowed handle instead of copied like plain data.
- **REF-XDG-DOCUMENTS** and **REF-XDG-DOCS-FUSE**: a mediator can expose selected files through a restricted projected filesystem without claiming ambient host-path semantics.
- **REF-FUCHSIA-NAMESPACE** and **REF-FUCHSIA-COMPONENT-NSENTRY**: attachability is receiver-local because each component gets an explicit namespace assembled from attached subtrees/entries.

## Why the split matters

Receiver-side UX gets confused when it cannot answer whether the current lane is:
- directly native for this process/pane/tool,
- dependent on one wrapper or relay,
- only one translated or preview representation,
- explicitly materialized/localized,
- or merely historical.

Those are different product and security truths.
An adapted attach may be perfectly fine while still being the wrong place to infer object ontology.
A coerced representation may be enough for preview, import, or transfer while still being the wrong place to claim same-object edits.
A local realization may improve fidelity and offline behavior, but it should stay explicit.
A receipt should explain prior fit without pretending the same fit still exists now.

## Working posture

### Native attach is worth naming directly
The shell should be free to say `native here` or `direct attach`.
That is a receiver-lane property, not a claim that the object is universally native everywhere.

### Adapted attach is a real success, not a shame state
A wrapper, relay, or compatibility membrane may be exactly the right way to use something in this pane or tool.
The only design requirement is that the shell stays honest about the adapter.

### Coerced representation is often the right answer
Sometimes the truthful thing to expose is not `same object attached` but `alternate representation available`.
ViewFS should preserve that distinction instead of laundering every preview/render/import lane into the same object story.

### Local realization is an explicit choice
When stronger local/native semantics are desired, the shell should expose that as an explicit transition rather than a silent fallback.

### History should stay non-reviving
A durable trace that a thing once attached natively, adapted, or through one alternate representation is useful.
It is not current fit.

## Receiver-side classification worth standardizing early

A useful receiver-side classification for shell UX and protocol experiments is:
- `attach_native`
- `attach_adapter`
- `attach_relay`
- `representation_coerced`
- `representation_preview_only`
- `localize_for_native`
- `localize_copy`
- `localize_object`
- `receipt_only`
- `history_only`

This is intentionally posture-oriented.
It does **not** decide one final object-store schema, one wrapper ABI, or one universal transport.

## Shell and terminal payoffs

A truthful shell can turn this split into product leverage:
- **attach-mode badges** instead of one fake `open/import/use` verb;
- **adapter veils** that make wrappers and relays inspectable instead of invisible;
- **virtuality lamps** when the current best lane is one translated/preview representation;
- **same-object versus translated drawers** so users can see whether edits, previews, or sends are happening on the same object or on one representation;
- **make-local-for-native ladders** that upgrade fidelity/locality explicitly.

## What not to freeze yet

Do **not** freeze yet:
- one final wrapper/relay taxonomy,
- one universal list of alternate representations,
- whether translated representations are always cacheable or durable,
- whether native attach ever becomes a hard requirement for some classes,
- or one permanent answer to how same-object fidelity is surfaced on every lane.

The separation is worth freezing now.
The exact adapters, transports, and realization machinery are not.
