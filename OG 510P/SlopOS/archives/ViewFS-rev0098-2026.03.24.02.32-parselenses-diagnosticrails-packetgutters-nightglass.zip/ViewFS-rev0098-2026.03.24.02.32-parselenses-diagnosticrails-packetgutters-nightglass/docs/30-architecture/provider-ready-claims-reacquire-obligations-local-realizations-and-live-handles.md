# Provider-ready claims, reacquire obligations, local realizations, and live handles

History keeps offering a tempting lie:
if a provider says the thing exists, or can probably be supplied later, UIs start rendering that as if the thing were already local and usable.

That lie is exactly what ViewFS should avoid while it is still building a brand-new object-store + capability-handle + explicit-namespace model.

Useful precedents point the other way:
- **REF-GIT-PARTIAL-CLONE**: Git can know that missing objects are expected from a promisor remote, but that is still not the same thing as those objects being local now.
- **REF-NIX-REALISE** and **REF-NIX-SSH-SUBSTITUTER**: Nix makes `realise` explicit, and substituters are explicit sources for producing a path when it is not already valid locally.
- **REF-FUCHSIA-AVAILABILITY** and **REF-FUCHSIA-CAPS**: a component can declare that it uses a capability, yet runtime availability still depends on a valid route.

## The split

Keep these classes separate:

### 1. Advert/catalog presence
`Someone says this may exist.`

Examples:
- a chooser/provider row,
- a helper catalog entry,
- a remembered object card,
- a promisor-like hint that a source may supply something.

This is discoverability, not current locality.

### 2. Provider-ready / satisfiable-on-demand claim
`Someone says this can probably be supplied if asked.`

Examples:
- a promisor remote that can fetch missing objects,
- a substituter that can produce a store path,
- a capability route that should be available if the route resolves,
- a provider that says `materialize on request`.

This is stronger than a mere advert, but it is still not local realization.

### 3. Reacquire / repair obligation
`Local truth is not complete yet; some repair or reacquire step is still owed.`

Examples:
- a restore that still needs uniqueness repair,
- a ref that must be rebound or reauthorized,
- a remote-backed artifact that needs fetch or substitution before local use,
- a provider-owned handle that is still only borrowable from elsewhere.

This should stay visible because it is the difference between `works now locally` and `could work after one more repair lane`.

### 4. Local realization / local materialization
`The bytes/object/view now exist here in the local substrate.`

Examples:
- object bytes now present in the local store,
- a local draft capsule committed,
- a local realized subtree or projected copy,
- a hydrated closure now resident here.

This is where offline/locality claims begin to become true.

### 5. Live handle / current authority
`A process currently holds usable authority now.`

This is still distinct from local realization because:
- a live handle may still point to provider-owned or foreign-backed utility,
- a realized local object may exist without any process currently holding a live handle,
- a process may hold a handle only after an explicit bind/publication/adoption step.

### 6. Durable receipt/history
`Something happened before.`

Receipts may remember adverts, provider-ready outcomes, realization acts, repair steps, and binds.
They should remain inspectable without reviving any of those states.

## Anti-collapse rules

- Do not let `provider-ready` silently render as `local now`.
- Do not let a restore/rebind obligation hide behind a green `available` badge.
- Do not let a local realized object imply that some process already holds current authority.
- Do not let a live foreign-backed handle imply local ownership or local durability.
- Do not let old realization receipts masquerade as current local residence.

## ViewFS posture

A good Phase 1 ViewFS should be comfortable saying all of these distinctly:
- `advertised, not yet asked for`
- `provider-ready, local fetch still needed`
- `reacquire needed before stronger claim`
- `realizing here now`
- `realized locally`
- `live handle held now`
- `history only`

That vocabulary gives us a lot of freedom later.
It leaves object-store shape, portal protocol shape, and continuity-owner shape open, while already making the shell, receipts, and import flows much harder to lie with.

## Shell consequences

The future shell gets several high-value truths from this split:
- a **make-local ladder** can exist without pretending every chooser row already names local bytes;
- **provider-owned badges** can explain when a useful thing is still backed elsewhere;
- **repair rails** can name why a resumed or remembered thing is not fully ready yet;
- **offline/locality lamps** can distinguish `reacquirable later` from `local now`;
- **history drawers** can explain how something became local without turning that drawer into present authority.
