# Partial residency, chunk layouts, whole-object proofs, and live range sessions

Purpose: keep **current local byte/chunk coverage**, **layout metadata**, **whole-object completeness**, **whole-object proofs**, **live range-fill sessions**, and **receipts/history** on separate seams.

Large-object systems tempt designers to collapse these into one vague story of “the object is here”.
The precedents say otherwise.
A system may know how an object is partitioned, hold only some ranges locally, be able to fetch missing chunks on demand, and still not have a full local proof of the entire object.

## Useful precedents
- **REF-RFC9110-RANGE**: 206 responses transfer one or more parts of the selected representation, and partial responses can only be recombined safely under validator rules.
- **REF-RFC9111-INCOMPLETE**: caches may store incomplete responses, but they must not answer a complete request as if incomplete bytes were complete truth.
- **REF-STARGZ-OVERVIEW** and **REF-STARGZ-ESTARGZ**: an OCI-compatible image can stay lazily pullable and fetch only needed files/chunks during execution.
- **REF-AWS-S3-OBJECT-ETAG** and **REF-AWS-S3-MPU-OVERVIEW**: multipart object identifiers/checksums may be composite or otherwise not equal to one whole-object MD5, while full-object checksum validation is a stronger separate lane.
- **REF-ZARR-V3-CORE**: chunk grid and codec metadata describe partitioning and encoded chunk representation, which is valuable without being the same thing as local chunk presence or whole-array proof.

## Distinctions worth preserving

### 1. Local coverage is not whole-object completeness
A local store may have:
- a prefix only,
- a sparse set of ranges,
- a subset of chunks/shards,
- or the entire object.

The shell should be able to say which one is true.
`some bytes present` should never silently become `fully local`.

### 2. Layout knowledge is not residency
A chunk grid, shard map, TOC, file index, or range plan says how a representation can be accessed.
It does not say which pieces are present locally right now.

### 3. Completeness is not proof
An implementation may believe all expected chunks are present locally and still not hold one whole-object digest/proof.
Conversely, it may know one trusted whole-object digest while still lacking some ranges locally.
Those two truths are both useful and should stay separate.

### 4. Composite per-part identifiers are not whole-object truth
Multipart uploads, per-part checksums, and similar composite identifiers are often useful operationally.
They should not silently become the ViewFS-native answer to “do we have one exact proof of the whole object?”

### 5. Live remote fill is not offline readiness
A process might be able to read missing bytes because a lazy-pull helper or provider is still reachable.
That does not mean the object is complete locally or that it will work offline later.

### 6. Receipts are not current sparse/full state
A past hydration/range-fill/verification event is evidence that something happened.
It is not proof that current local coverage, current proof material, or current remote-fill reachability remain unchanged.

## Shape that feels promising
ViewFS probably wants different object/receipt families such as:
- **CoverageMap** — current local ranges/chunks/shards present
- **LayoutMap** — chunk grid / shard plan / TOC / codec metadata
- **CompletenessVerdict** — `partial`, `complete`, `unknown`, `prefix-only`, etc.
- **WholeProof** — exact whole-object digest/checksum/witness
- **RangeFillSession** — current lazy/range provider path for missing data
- **CoverageReceipt** — durable history about sparse/full state observed at one time

The exact schemas can wait.
The class separation should not.

## Nifty ideas worth stealing
- **Hole maps**: visual sparse/full coverage truth instead of one generic download spinner.
- **Range panels**: a shell drawer that keeps `coverage`, `layout`, `proof`, and `remote fill` visibly separate.
- **Whole-proof ladders**: actions like `fetch missing`, `verify full`, `seal local`, `stay sparse`, or `open receipt`.
- **Offline honesty lamps**: `fully local`, `works only with remote fill`, `proof missing`, or `history only`.
- **Composite-checksum warnings**: explain when a current identifier is not one exact whole-object digest.

## What not to decide yet
- one canonical sparse-coverage schema across all object families,
- whether coverage is tracked as byte ranges, chunks, shards, files, or some provider-specific hybrid,
- whether full proof is mandatory for every publish/launch/export act,
- whether range fill is portal-owned, helper-owned, provider-owned, or shell-owned in Phase 1,
- the final exact UX for `sparse but runnable` versus `full and sealed`.

## Near-term recommendation
For ViewFS Phase 1 and nearby spikes:
1. keep **coverage**, **layout**, **completeness**, **proof**, **live range fill**, and **receipts** as explicit vocabulary,
2. keep composite identifiers weaker than whole-object proofs,
3. make sparse/full truth transcript-visible,
4. keep lazy fill and offline readiness visibly distinct,
5. and refuse to let receipts silently stand in for present coverage.
