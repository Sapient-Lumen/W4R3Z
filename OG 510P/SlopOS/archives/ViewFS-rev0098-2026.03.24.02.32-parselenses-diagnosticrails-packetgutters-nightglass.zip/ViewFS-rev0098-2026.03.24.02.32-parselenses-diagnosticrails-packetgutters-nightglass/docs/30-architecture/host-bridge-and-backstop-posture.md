# Host bridge and backstop posture

Purpose: keep ViewFS honest during bring-up by separating **implementation backstops** from **ViewFS semantics**.

ViewFS is still design-phase. That means we will likely rely on host kernels, runtimes, and compat adapters while the real object-store + handle + view model is still being proven. This is fine **if** we keep the layers explicit.

## Core distinction
- **ViewFS semantics** are the user-facing truths we want to preserve across implementations: immutable object IDs, explicit handles, explicit views, portal receipts, and path compatibility as a membrane.
- **Host bridges/backstops** are temporary or platform-specific tactics that help us implement or constrain those semantics while the system matures.

The failure mode to avoid is letting a host tactic silently become “the filesystem really works this way.”

## Four backstop classes worth using carefully

### 1. Preopen-style compat roots
Precedents:
- REF-WASMTIME-PREOPEN
- REF-FUCHSIA-NAMESPACE

Use:
- bind one or more explicit directory roots into a child environment
- keep all path walking relative to those prebound roots
- avoid any promise that the host machine `/` is the truth

Implication for ViewFS:
- good bring-up tactic for compat shells, runtimes, and early foreign-cell adapters
- not a reason to treat guest paths as the authority model

### 2. Escape-hardening path walkers
Precedent:
- REF-OPENAT2

Use:
- when a compat membrane must walk paths on a host filesystem, use a rooted resolver that fails closed on escapes, symlink tricks, mount crossings, and ambiguous races
- keep path walking tied to an already-held directory/root handle

Implication for ViewFS:
- a compat path service should prefer an `openat2`-style discipline even if the final system later has its own walker
- every “cannot prove containment” result should deny or require an explicit retry path, not silently widen authority

### 3. Explicit ambient-authority markers
Precedent:
- REF-CAPSTD

Use:
- any code path that reaches out to the host filesystem by ambient path should require a loud explicit marker
- this is especially useful for bring-up utilities, migration tools, tests, and escape hatches

Implication for ViewFS:
- ambient fallback can exist during design-phase bring-up, but it must be treated as **debt**, not as normal behavior
- the shell/transcript should mark these moments visibly

### 4. Host defense in depth
Precedent:
- REF-LANDLOCK

Use:
- if ViewFS is hosted on Linux during early prototypes, a host-side sandbox can reduce the blast radius of compatibility mistakes
- this can be stacked under the higher-level ViewFS model

Implication for ViewFS:
- host sandboxes are welcome as backstops
- they must not define ViewFS semantics, become the sole explanation of authority, or replace receipts/views/handles in user-facing reasoning

## What the shell should expose
If a command, tool, or compat cell relies on host backstops, the transcript should be able to show:
- which view/root it thought it was using
- whether path compatibility was involved
- whether any ambient fallback occurred
- which host backstop profile was active
- whether the operation was constrained by a lower-level sandbox

This suggests a useful concept for early builds:
- **debt receipts** for ambient or host-path fallback
- **bridge receipts** for compat-path operations that relied on a host walker

These receipts are not final protocol commitments. They are observability tools that keep bring-up honest.

## What not to decide yet
Do **not** freeze any of these too early:
- final Linux-specific hardening profile
- whether Landlock or another backstop is mandatory
- final ambient-debt receipt schema
- whether compat path walking lives in one service or several
- whether a preopen adapter is the only foreign-runtime bridge

## Near-term recommendation
For the next ViewFS spikes, keep this policy:
1. prefer explicit handles/views first
2. use preopen/rooted compat only as a membrane
3. use escape-hardening walkers when host paths are unavoidable
4. require visible ambient-debt markers for host fallbacks
5. optionally add host-side sandboxing as defense in depth

That gives us safer prototypes without pretending the host implementation details are the design itself.
