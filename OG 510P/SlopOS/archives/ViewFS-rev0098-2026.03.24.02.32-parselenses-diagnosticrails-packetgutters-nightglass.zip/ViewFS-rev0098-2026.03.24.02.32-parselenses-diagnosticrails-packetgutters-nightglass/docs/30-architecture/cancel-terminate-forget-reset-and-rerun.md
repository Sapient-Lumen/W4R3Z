# Cancel, terminate, forget, reset, and rerun

Purpose: keep the next deferred-work seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough helper, task, and background-session ambition that we need one more anti-collapse boundary:
**close/cancel request ≠ force terminate run ≠ detach/delete retained task state or result ≠ retry fresh request ≠ reset/fork from prior history ≠ durable receipt/history**.

That split is the safest way to let the shell expose rich deferred-work control **without letting “stop”, “forget”, or “try again” quietly mean whatever the current subsystem happened to implement.**

## Why this seam matters now
SlopOS already points this way:
- `rfcs/0115-capability-safe-shell-and-automation.md` keeps automation startup explicit and warns against ambient follow-on control.
- `rfcs/0117-plumb-messages-and-cli-intents.md` keeps request envelopes, execution, and outcomes distinct.
- `docs/30-architecture/acp-acceptance-completion-posture-v0.md` and neighboring receipt notes already keep accepted, completed, denied, and historical outcome classes distinct.
- `docs/30-architecture/background-request-state-posture-v0.md` and `background-lease-posture-v0.md` already refuse to collapse permission to keep running with current live status.
- `docs/30-architecture/attention-durable-status-boundary-v0.md` and related attention notes already treat “what is still asking for attention now” as different from durable records.

ViewFS should preserve that posture in future helper/task flows instead of creating a softer second story where:
- cancel looks the same as kill,
- deleting retained state looks the same as stopping live work,
- retrying looks the same as attaching to an existing run,
- reset-from-history looks the same as rerun-from-scratch,
- or a forgotten local locker looks like the remote task vanished too.

## Lessons we must learn from the past

### 1. Closing an interaction is not the same thing as observing its terminal result
The XDG portal Request object keeps a request alive for the duration of the user interaction. Calling `Request.Close` ends the interaction, and in that case a `Response` signal is not emitted.

Why this matters:
- ViewFS should treat a close/abort act as its own control event, not as a synthetic `cancelled` result object.
- If the shell shows `closed`, that should mean “interaction ended locally,” not “we observed a final cancelled result from the provider.”
- Request-close receipts should stay different from task/result receipts.

### 2. Cancelling work is different from forgetting the tracking object
Google’s long-running `Operations` interface makes the distinction unusually crisp: `CancelOperation` is best-effort and may fail to stop the work, while `DeleteOperation` means the client is no longer interested in the result and explicitly does **not** cancel the operation. `GetOperation` remains the way to learn the latest state.

The MCP Tasks SEP points the same way. A task may move through `submitted`, `working`, `input_required`, `completed`, `failed`, `cancelled`, or `unknown`. Cancellation is asynchronous and best-effort, so requestors are expected to keep polling `tasks/get` to confirm `cancelled`. Separately, receivers may support deleting task metadata/results, and requestors are encouraged to delete sensitive tasks promptly rather than relying only on keep-alive expiry.

Why this matters:
- ViewFS should keep **cancel** and **forget/detach** as different verbs and different receipt classes.
- “I no longer want to watch/keep this task” should not imply “the underlying work has stopped.”
- Result lockers should be allowed to disappear while remote work continues, and remote work should be allowed to stop while history remains.

### 3. Graceful cancellation is not the same thing as force termination
Temporal explicitly distinguishes cancellation from termination. Cancellation is the graceful stop path that allows cleanup; termination is the immediate force-stop path for stuck executions.

Why this matters:
- ViewFS should not flatten `cancel` and `kill` into one generic stop button.
- The shell should admit that graceful cancellation may leave time for cleanup and final receipts, while force termination may not.
- Receipt/history should preserve whether an execution had a chance to react, clean up, and emit final state.

### 4. Reset/fork is not the same thing as retry from scratch
Temporal’s reset model is particularly useful here: reset terminates the current execution, starts a new execution from a chosen point in event history, copies history up to that point, resumes with current code, and discards later progress. Temporal’s Workflow ID and Run ID model also distinguishes reuse policy, conflict policy, `Use Existing`, and `Terminate Existing` behaviors.

Why this matters:
- ViewFS should not treat `retry`, `rerun`, `reset to checkpoint`, `fork from checkpoint`, and `use existing run` as the same control act.
- A reset/fork act should carry an explicit basis and a reason, not just masquerade as another retry.
- The shell should be able to show “new fresh attempt”, “attach/use existing”, and “fork/reset from earlier state” as visibly different lanes.

### 5. Retention and expiry are real seams, not housekeeping trivia
AIP-151 says long-running operation resources may expire after completion and gives 30 days as a rule of thumb. The MCP Tasks SEP similarly keeps `keepAlive` explicit and allows task/results deletion after terminal completion and keep-alive expiry.

Why this matters:
- ViewFS should keep retained-result lifetime explicit instead of implying lockers live forever.
- Expiry, deletion, and history-only state should be visible terminal outcomes, not mysterious missing results.
- Sensitive results should be forgettable on purpose, not only by timeout.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **CloseOrCancelAct** — “stop asking / stop gracefully if you can” for a live request or task
- **TerminateAct** — force-stop act for stuck or runaway work
- **DetachOrDeleteAct** — drop local interest, tracking, retained result, or sensitive metadata without claiming the remote work stopped
- **RetryAct** — fresh attempt with new task/run identity
- **ResetOrForkAct** — new attempt that explicitly cites prior basis/history/checkpoint
- **StopReceipt** — durable history saying whether we closed, requested cancellation, observed confirmed cancellation, force-terminated, detached/forgot, retried, reset, forked, attached to an existing run, or only lost retained state by expiry

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **stop ladders** — `close`, `cancel gracefully`, `terminate now`, `detach only`, `forget locker`, `retry fresh`, `fork/reset`
- **detach rails** — “stop watching” or “delete retained result” that are visibly different from stopping remote work
- **reset/fork cards** — explicit checkpoint/history basis plus reason, not a magical rerun
- **existing-run chips** — attach to or reuse the currently open run without pretending a new run was created
- **expiry badges** — `result expired`, `history only`, `forgot locally`, `remote still running`, `cancel requested`, `cancel confirmed`

That is the right way to make a shell feel ambitious without letting deferred control quietly become hidden standing authority or ambiguous folklore.

## What not to decide yet
- the final stop-act schema for ViewFS or SlopOS,
- whether graceful cancel and request close share a common wrapper or only common chrome,
- whether result deletion is always local or can request remote deletion too,
- whether reset/fork always references task history, request history, or another basis record,
- whether “use existing” is pane-bound, helper-session-bound, or a general cross-pane act.
