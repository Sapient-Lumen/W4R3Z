# Store membership, synthetic views, live handles, and published names

Purpose: keep **object-store existence**, **restricted/synthetic view projection**, **current live authority**, **current publication inside one process view**, and **historical receipts** on distinct seams.

The temptation is obvious.
If an object can be imported through a portal, projected into a restricted synthetic tree, opened through a handle, and then published somewhere under a name, it feels convenient to flatten all of that into “the file.”

That shortcut is attractive and dangerous.
It makes local names sound more durable than they are, makes portal projections sound more native than they are, and makes live authority look like a property of any pretty path the shell happens to show.

## Useful precedents
- **REF-PLAN9**: the foundations are a per-process name space and a simple message-oriented file system protocol.
- **REF-FUCHSIA-NAMESPACE**: components consume namespaces they are given and can publish objects through an outgoing directory in the form of a namespace to other components.
- **REF-FUCHSIA-DICTCAP**: grouped capabilities can be aggregated, nested, retrieved, and extended without collapsing into one ambient tree.
- **REF-XDG-REQUEST**: long-lived mediated choices are represented through request objects rather than pretending one chooser action is one instant synchronous open.
- **REF-XDG-FILECHOOSER** and **REF-XDG-DOCUMENTS**: selected files may become reachable through a restricted synthetic view, and that restricted view is still not the same thing as broad native namespace publication.

## Distinctions worth preserving

### 1. Store membership is not published name
An object may exist in the ViewFS object store without being published anywhere in any current pane/process namespace.

That is especially important for:
- fresh imports still under review,
- draft objects not yet published,
- cached/localized bytes,
- and content-addressed or descriptor-addressed objects that should not automatically become user-visible path entries.

### 2. Synthetic view is not local publication
A portal/provider may project an object into a restricted synthetic view.
That does **not** mean the object has been locally published into every current ViewFS pane/process namespace.

A synthetic view answers “reachable through this mediated surface.”
A local publication answers “attached here, now, under this name, in this process view.”

### 3. Live handle is not publication
A process may hold a live handle to an object that is not currently published under any name in its namespace.
Conversely, a view may publish a name whose current open affordances depend on what handle or authority the actor actually holds now.

This is why `published here` and `live authority here` should remain separate shell truths.

### 4. Portal request/session state is not object locality
A request row, chooser session, or mediator-side current state may remain open or remembered even when:
- no local object has been materialized,
- no local publication has happened,
- or the old live handle is gone.

Portal/state ledgers should therefore stay visibly distinct from local publication ledgers.

### 5. Dictionary/bundle grouping is not namespace commitment
Capability dictionaries and bundles are useful because members can travel together, be nested, or be retrieved individually.
That does not mean the bundle itself is a committed namespace bind.

Grouping answers “what travels together.”
Publication answers “what is attached here.”

### 6. Published name is not durable reopen
A currently published path-like label should not silently imply:
- global machine identity,
- ambient re-open later,
- or survivability across revoke/restart/provider loss.

If ViewFS offers later re-open or revival, that should stay on explicit designator/ticket/receipt seams.

## Shape that feels promising
ViewFS probably wants user-visible truth labels such as:
- **InStore** — object exists locally but is not published here
- **SyntheticView** — reachable through a provider/portal-shaped restricted view
- **LiveHandle** — current authority exists here now
- **PublishedName** — attached under this name in this process view now
- **ReceiptOnly** — history/explanation without current authority

The exact schemas can wait.
The semantic split should not.

## Nifty ideas worth stealing
- **Published-name ledgers**: one object card can show every current publication site separately instead of pretending one path is the object.
- **Synthetic-view badges**: `portal view`, `provider projection`, `published here`, `launch-only`, and `receipt only` should be different chrome.
- **Publish-here last**: chooser/import flows should land in staging first, then publication into the current pane should be an explicit act.
- **Same-object multi-view diffing**: let the shell show that the same object is reachable through a restricted portal view, one current local bind, and maybe a child launch kit — all separately.
- **Outgoing publication cards**: if a pane/app publishes objects to a child or peer, show that as publication history rather than silent inheritance.

## What not to decide yet
- whether synthetic views are kernel-adjacent, service-owned, shell-owned, or mixed;
- whether publication sites are always single-slot binds in Phase 1 or later admit ordered overlays;
- whether portal-style restricted views are mostly local object projections, provider projections, or both;
- whether one object may be published simultaneously under many names and many view classes in early phases;
- whether publication ledgers are queryable objects, receipts, or mostly shell-owned explanatory state.

## Near-term recommendation
For the next narrow spikes:
1. keep **store membership**, **synthetic view**, **live handle**, **published name**, and **receipt** as explicit vocabulary,
2. make local publication into a pane/process namespace an explicit transcript-visible act,
3. keep portal/provider request state distinct from current local publication,
4. teach the shell to show `in store`, `projected`, `published here`, and `live handle now` as different truths,
5. and postpone any broader namespace/path folklore until the mediated-view and publication seams have been pressure-tested.
