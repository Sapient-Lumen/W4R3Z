# Policy sources, trust gates, and precedence

Purpose: keep the next policy-and-shell seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough policy-aware and automation-aware shell ambition that we need one more anti-collapse boundary:
**owner/org policy source ≠ trust-state gate ≠ user/profile preference ≠ workspace/imported proposal source ≠ effective active state ≠ durable receipt/history**.

That split is the safest way to let the shell surface helpful workspace hints, imported helper configurations, history-based suggestions, and local preferences **without silently letting a lower-trust source author ceilings or become the active truth by folklore**.

## Why this seam matters now
SlopOS already points this way:
- `rfcs/0028-veto-only-policy-bundles-for-automation.md` keeps policy non-amplifying and explicit.
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md` keeps chooser/mediator flows from becoming a generic authority plane.
- `rfcs/0115-capability-safe-shell-and-automation.md` keeps shell cleverness explainable without letting it mint power.
- `approval-basis-posture-v0.md` and nearby auth-mediation boundaries insist that approvals bind exact reviewed material rather than floating mutable context.

ViewFS should preserve that posture in shell UX instead of creating a second softer story where:
- a workspace-defined helper file quietly authors a broader deny ceiling,
- an imported/discovered helper config silently becomes active just because it looks plausible,
- a trust-state change silently rewrites user/profile preferences,
- or a receipt/history row quietly outranks owner/org policy because the shell wants to be helpful.

## Lessons we must learn from the past

### 1. Organization/device policy is a different class from user choice
VS Code’s enterprise policy docs are unusually crisp: enterprise policies can enforce specific configurations on managed devices, and those policies override user-configured settings. The AI enterprise settings docs extend that split to agent mode, hooks, MCP server sources, global auto-approval, terminal auto-approval, and per-tool auto-approval eligibility.

Why this matters:
- owner/org ceilings should be modeled as a distinct source class;
- a user/profile preference is not the same thing as an organization/device policy;
- “helpful local repair” should never outrank an owner/org ceiling.

### 2. Trust state is not the same thing as configuration source
VS Code Workspace Trust and the Workspace Trust extension guide are both strong precedents here. Restricted Mode disables or limits features such as agents, tasks, debugging, workspace settings, and extensions; extensions can also list `restrictedConfigurations`, which means workspace-defined values remain visible yet withheld until trust is granted.

Why this matters:
- trust state should be a separate gate, not just another config source;
- a workspace may be readable before it is trusted to supply effective automation or policy-affecting values;
- ViewFS should be able to show “workspace proposed this” while also showing “trust gate still closed.”

### 3. Imported or discovered helper configs are a different class from local truth
VS Code’s MCP docs are a good current product precedent. MCP configuration can live in the user profile or in the workspace, trust decisions can be reset, and MCP discovery can reuse MCP server configurations from other applications.

Why this matters:
- a discovered/imported helper source should land as a proposal/import class, not as automatic truth;
- imported helper configs deserve their own review surface and their own receipts;
- resetting trust should not be conflated with deleting the config source or vice versa.

### 4. Provenance and scope need first-class inspection
Git’s `git config` remains a great tiny precedent because it can expose both `--show-origin` and `--show-scope`.

Why this matters:
- users should be able to ask not just “what won?” but “where did this come from?” and “at what lane did it apply?”;
- a shell that cannot show origin and scope will eventually create policy superstition.

### 5. Local denials and auditability should stay loud even when prompts exist
Deno’s security model is still a useful product reminder: deny flags take precedence over allow flags, prompts are explicit, and permission audit logs can be emitted even when access is denied.

Why this matters:
- local/user ceilings should stay visibly distinct from softer preferences;
- effective-state inspection should preserve both the winning source and the denied alternatives;
- history/audit should help explain precedence without becoming a live source by itself.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **PolicySource** — who authored a policy-bearing or preference-bearing input (`owner`, `org`, `device`, `user-profile`, `workspace`, `imported-helper`, `history`, `mediator`, `shell-local`)
- **TrustGate** — whether a lower-trust source class is currently admissible as an effective input for this area (`restricted`, `workspace-trusted`, `import-reviewed`, etc.)
- **PreferenceLayer** — a non-authoritative or lower-authority layer such as a user/profile preference that may matter only if higher ceilings and trust gates allow it
- **ImportedProposal** — discovered or imported helper material that remains visible and inspectable without silently becoming effective
- **EffectiveState** — the exact currently active outcome, with winning source, blocked sources, trust posture, and explicit precedence reasoning
- **ActivationReceipt** — durable history showing what source was proposed, what gates applied, what won, what was withheld, and whether anything was merely imported/reviewed rather than activated

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **origin stack badges** — `owner`, `org`, `user`, `workspace`, `imported`, `history`
- **trust shutters** — a visible “workspace visible but withheld” or “import present but not yet reviewed” state
- **effective winner chips** — what currently won and why
- **override ledgers** — what lost, whether it lost by higher precedence or by a closed trust gate, and whether the losing source is merely advisory
- **import quarantine trays** — discovered configs and helper bundles that remain proposals until explicitly reviewed/promoted

That is the right way to make a shell feel ambitious without letting source layering turn into invisible ambient policy.

## What not to decide yet
- the final source taxonomy for every policy family or helper lane,
- the final precedence lattice between `owner`, `org`, `device`, `user-profile`, and explicit one-shot user actions,
- the final serialized schema for imported helper proposals or activation receipts,
- whether trust gates are globally uniform or policy-family specific,
- how much source-stack state belongs in prompt chrome versus drawers, cards, or notebooks.

## Near-term recommendation
For the next nearby spikes:
1. keep owner/org ceilings visibly distinct from user/profile preferences;
2. keep trust gates visibly distinct from configuration origin;
3. treat discovered/imported helper configs as proposal material until explicitly reviewed;
4. make effective-state inspection preserve both the winner and the losers;
5. record source-stack and trust-gate reasoning in durable receipts without turning receipts into live sources;
6. prototype one killer flow: **origin stack badge + trust shutter + override ledger + import quarantine tray + activation receipt**.
