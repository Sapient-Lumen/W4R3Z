# Delete, trash, recovery history, retention, and purge

Purpose: keep **remove-from-view**, **trash/recycle entry**, **recoverability history**, **retention roots**, and **purge / GC** on separate seams.

## Core rule
ViewFS should distinguish at least seven related but different things:
- **remove / unbind intent** — the user or tool no longer wants a name or binding to appear in the active view or workspace,
- **trash / recycle entry** — an object or subtree is moved into a recoverable holding area with metadata about where it came from and when it was removed,
- **recoverability history** — local timeline / undo / ref-log style history that can help rebind or restore even when the active view changed,
- **retention root** — an explicit thing that keeps immutable data or derivatives live for policy reasons,
- **purge eligibility** — a statement that something is no longer required by active roots and may be collected,
- **purge / collection act** — an explicit policy-driven operation that actually clears unreachable or expired material,
- **secure destruction claims** — any stronger statement about wiping or irrecoverability.

Those should not silently collapse into one primitive.

A user should be able to say:
- “take this out of my workspace,”
- “send this to trash so I can put it back,”
- “show me where this used to live,”
- “what history exists for this name or head,”
- “what roots are still keeping this data alive,”
- “what will be purged if I confirm,”
- or “this was permanently removed under a stronger destruction policy.”

## Why this matters
Historical desktop and store systems keep rediscovering the same lesson:
- user-facing delete often wants a recoverable holding area,
- the trashed artifact may get a new location or even a renamed collision-safe entry,
- retention is often controlled by explicit roots or policy instead of the current visible path,
- and recovery history is useful even when the object never lived in a traditional trash can.

That maps unusually well to ViewFS because the design already wants:
- immutable-first storage,
- explicit views and bindings,
- durable refs and receipts,
- and a shell that can be more helpful than “rm means pray.”

## Useful precedents
- **REF-FDO-TRASH**: the freedesktop Trash spec explicitly separates trashed content from `.trashinfo` metadata that records original path and deletion date.
- **REF-APPLE-TRASHITEM**: Apple’s `trashItem` returns the resulting URL because the item may be renamed when moved to the trash.
- **REF-MS-RECYCLEONDELETE**: Windows explicitly distinguishes recycle-bin deletion from permanent deletion through operation flags.
- **REF-NIX-STORE**, **REF-NIX-GCROOTS**, and **REF-NIX-GC**: an immutable store can stay live because of explicit roots even after a user-facing path or profile changes.
- **REF-VSCODE-LOCALHISTORY**: deleted or overwritten working files may still be recoverable through a local history timeline that is not the same as trash.
- **REF-GIT-REFLOG**: local ref movement history is often the real “undo” surface for names/heads even though underlying objects are immutable.
- SlopOS already has adjacent seams here even without a dedicated trash concept: `document-handle-schema-v0.md`, `acp-outcome-receipt-schema-v0.md`, `attention-durable-status-boundary-v0.md`, `background-request-state-posture-v0.md`, `explain-posture-v0.md`, and `rfcs/0115-capability-safe-shell-and-automation.md`.

## Recommended ViewFS reading of the split

### 1. Remove from a view is not the same thing as destroy the data
If a user removes something from `/work` or from a bound workspace view, the first semantic effect may only be:
- remove a name,
- withdraw a binding,
- or update a mutable head / work journal.

That action should not automatically imply:
- immediate purge,
- secure destruction,
- or loss of recovery context.

### 2. Trash is a recoverable holding area, not the truth of identity
A trash entry can preserve:
- original location or bound name,
- deletion/removal time,
- object kind,
- and maybe lightweight reason or actor metadata.

But the trash entry should not become:
- canonical object identity,
- the only recoverability story,
- or proof that immutable storage is about to disappear.

### 3. Recoverability history deserves its own seam
A local timeline or reflog-like surface can be useful for:
- recently rebound names,
- workspace head movement,
- deleted-but-restorable files,
- and “where did this object used to point?” questions.

That history is not the same thing as:
- live authority,
- current namespace state,
- or a trash bag full of files.

### 4. Retention roots should be explicit and inspectable
In an immutable-first store, something may remain live because of:
- an active workspace root,
- a durable ref,
- a pinned manifest,
- a notebook/session artifact,
- an audit/receipt retention policy,
- or a background hold.

The shell should be able to answer “what keeps this alive?” without laundering that answer into “therefore you may open it however you want.”

### 5. Purge should be policy-driven and previewable
Purge/GC should feel like a separate step:
- maybe scheduled,
- maybe user-requested,
- maybe policy-controlled,
- and ideally previewable.

Users should be able to ask:
- what is purge-eligible,
- what roots would be affected,
- how much space would clear,
- and what recovery paths would disappear.

### 6. Strong destruction claims deserve a much higher burden of proof
“Removed from my workspace” is easy.
“Gone from trash” is stronger.
“Unreachable by current roots” is stronger still.
“Securely destroyed” is an entirely different claim and may not belong in Phase 1 at all.

ViewFS should resist claiming the strongest thing when it only did the weakest one.

### 7. The shell can make recovery much better than legacy `rm`
A capability-native shell can afford richer verbs and cards such as:
- `trash`,
- `restore`,
- `show-original-location`,
- `show-retention-roots`,
- `preview-purge`,
- `pin`,
- `undo-unbind`,
- `copy-removal-receipt`.

Those should feel like first-class object operations, not afterthought wrappers around ambient path deletion.

## A promising future object family
Without freezing names yet, ViewFS may eventually want ideas such as:
- **TrashReceipt** — evidence that an object/view entry was removed into a recoverable holding area,
- **RestorePlan** — explicit mapping from current trash entry or timeline note back to a target binding,
- **RetentionRootReceipt** — explanation of why immutable data is still live,
- **PurgePreview** — a bounded answer about what would become unreachable or collectible,
- **RemovalHistoryEntry** — local timeline/ref-log style history for names, heads, or bindings.

The seam discipline matters more than the nouns.

## How this maps onto SlopOS seams
- **remove/unbind intent** ↔ `view-namespace-posture-v0.md`, `capshell-cwd-root-posture-v0.md`
- **durable refs / document-like restoration** ↔ `document-handle-schema-v0.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`
- **receipt and explain UX** ↔ `acp-outcome-receipt-schema-v0.md`, `explain-posture-v0.md`
- **background purge/retention state** ↔ `background-request-state-posture-v0.md`, `attention-durable-status-boundary-v0.md`
- **shell / automation recovery UX** ↔ `rfcs/0115-capability-safe-shell-and-automation.md`

## Shell implications
- every delete-like action should say whether it is `unbind`, `trash`, `drop ref`, `purge preview`, or `purge now`
- the shell should keep `trash`, `restorable`, `rooted`, `pinned`, `purge-eligible`, or `receipt-only` states visible in recents, palettes, and timelines
- “what keeps this alive?” should be a one-keystroke inspector
- purges should default to preview/dry-run first, with visible root impact
- restoring should produce a restore-plan card rather than silently writing to some guessed location
- undo history should preserve whether the thing being undone is a name movement, a view unbind, a trash move, or a head update

## Anti-goals
- treating `delete` as if it always means secure destruction
- treating `trash` as if it were canonical object identity
- making retention roots invisible and then surprising users when purge does or does not reclaim space
- letting shell history or palettes silently resurrect live authority
- promising hard-delete semantics before the object store, retention policy, and proof story can support them
