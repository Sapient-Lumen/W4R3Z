# Continuation cursors, sync watermarks, live subscriptions, rebuilt snapshots, and gap verdicts

ViewFS should not let one opaque token answer five different questions at once:
- **how do I ask for the next page or next delta batch?**
- **what point have I definitely processed through?**
- **am I still following live right now?**
- **what current state is actually rendered here?**
- **what kind of break or reset happened?**

Those truths interact, but they are not the same thing.

## Why this split matters

Datacube-like systems and query-heavy shells are tempted to turn every incremental token into magical truth.
That is exactly where systems become spooky:
- a continuation cursor starts being treated like a durable collection identity,
- a `last seen` marker starts being treated like a live watcher,
- a longpoll handle starts being treated like the current rendered set,
- a reset/overflow gets flattened into `stale`,
- and old transcript rows get mistaken for still-valid provider state.

The safer move is to keep at least six classes separate:

1. **continuation cursor**
   - provider-specific token for the next page or next change batch.
   - efficient and useful.
   - may expire or reset.
   - not current state by itself.

2. **sync watermark / bookmark**
   - the latest point the client knows it has processed through.
   - examples: resource version, event id, clock id, last-known cut.
   - useful for compare, repair, and UI honesty.
   - not a live subscription.

3. **live subscription / wait primitive**
   - one current watch, longpoll, or feed registration.
   - useful for prompt updates.
   - may still deliver nothing.
   - not the rendered set.

4. **rebuilt snapshot / relisted state**
   - the current collection state produced by relist, requery, or rebuild.
   - may be tied to one watermark.
   - not the same thing as the incremental token used later.

5. **gap verdict / repair posture**
   - what went wrong with continuity.
   - examples: expired cursor, resource version too old, dropped/coalesced events, root changed, provider reset, unsupported remote follow.
   - needed for honest repair UX.

6. **receipt / history**
   - evidence that any of the above existed or happened.
   - useful for explanation and audit.
   - not current resumable state.

## Lessons worth stealing

### Caught-up markers are useful and limited
Kubernetes is a very sharp precedent here.
A `BOOKMARK` event says the client is caught up through one `resourceVersion`, and `sendInitialEvents=true` can pair an initial synthetic snapshot with a later bookmark that marks the sync point.
That is excellent design because it keeps:
- current rendered state,
- last processed watermark,
- and ongoing watch subscription

from collapsing into one mystery blob.

Kubernetes is also honest about resets: a client can get `410 Gone` when it asks for a resource version outside retention, which forces repair instead of silent lies.

### Delta cursors are not durable object refs
Dropbox makes a similarly useful distinction.
Folder cursors are pointers to a folder at a point in time and can later fetch changes after that point, but they can expire and force a fresh `/files/list_folder` walk.
A longpoll call waits for change and then the client still uses `/continue` to fetch updates.
That is exactly the sort of split ViewFS should steal:
- wait primitive,
- continuation cursor,
- current rendered set,
- reset path.

### Logical clocks beat wall time, but they are still query state
Watchman is a good reminder that wall-clock timestamps are race-prone for change tracking.
Clock ids and named cursors improve correctness, but they are still query-state markers, not object authority.
That is a perfect warning for ViewFS shell design: a beautiful token chip should still be visibly `query sync state`, not a durable object designator.

### Incremental feeds need explicit rescan stories
Apple FSEvents says dropped events, root changes, or coalescing can require recursive rescan or full rescan, and the event stream exposes ids so clients can reason about lag.
That is the right attitude for ViewFS: gap detection and repair should be built into the model instead of hidden in implementation folklore.

## Working posture for ViewFS

- keep provider-issued continuation cursors opaque and visibly non-authoritative;
- keep sync watermarks inspectable and copyable as honesty artifacts, not as grants;
- keep live follow/watch registrations current-only and easy to drop;
- keep rebuilt snapshots explicit enough that the shell can say `relisted` or `rebuilt from watermark X`;
- keep gap verdicts specific enough to drive repair UX instead of one giant `stale` bucket;
- keep receipts/history useful without allowing them to silently revive cursors or subscriptions.

## SlopOS / datacube reading of this split

This maps well onto the current SlopOS drafts because SlopOS already keeps request identity, portal-owned live state, and durable status on different seams.
The thing to steal is not a giant global sync API.
It is the discipline that:
- a provider-issued cursor is not a portable ViewFS object ref,
- a processed-through watermark is not proof that a subscription still exists,
- a subscription is not the same thing as the current query result,
- and a repair/gap verdict deserves its own visible lane.

This is especially relevant to AttrFS-like query surfaces and import/follow UX.
Saved queries and smart collections will feel much better if ViewFS can say:
- `frozen snapshot at watermark X`,
- `following from watermark X`,
- `resume token expired`,
- `provider requested full relist`,
- `receipt only`.

## Shell product ideas

### Waterline cards
A query or watch pane should be able to render:
- `snapshot built through watermark X`
- `live follow from X`
- `cursor current`
- `cursor expired`
- `relist required`

without pretending any one of those is the whole story.

### Gap badges
The shell should prefer specific badges such as:
- `expired cursor`
- `bookmark missing`
- `resource version too old`
- `provider reset`
- `coalesced / must rescan`
- `remote-risk`
- `history only`

instead of one generic stale dot.

### Resync ladders
When continuity breaks, the next actions should be explicit:
- `continue`
- `wait / longpoll`
- `relist now`
- `rebuild from root`
- `freeze current rows`
- `open gap receipt`

### Snapshot-versus-follow chrome
A shell pane should be able to show whether it is:
- a frozen result snapshot,
- a live follow view,
- a rebuilt current set,
- or a receipt/history card.

That is the difference between delightful and spooky query UX.

## What not to decide yet

Do not decide yet:
- one final cross-provider cursor or watermark schema;
- one universal gap taxonomy;
- whether ViewFS stores rebuilt snapshots as first-class objects in Phase 1;
- whether longpoll/watch ownership lives in shell, provider, or terminal for every backend;
- whether any provider token can ever be shared beyond the local user/session.

Freeze the separation first.
