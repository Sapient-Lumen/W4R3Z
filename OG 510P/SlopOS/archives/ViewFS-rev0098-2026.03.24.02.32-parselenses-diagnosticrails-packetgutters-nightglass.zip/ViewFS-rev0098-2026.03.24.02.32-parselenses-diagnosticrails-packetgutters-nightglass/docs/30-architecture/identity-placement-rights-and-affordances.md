# Identity, placement, rights, and affordances

ViewFS should not let one path-shaped surface answer four different questions at once:
- **what object is this?**
- **where does it currently appear here?**
- **what authority do I hold right now?**
- **what operations are currently meaningful or advertised for this target?**

Those truths interact heavily, but they are not the same thing.

## Why this split matters

A capability-native object layer wants the shell to be smarter than ordinary pathname folklore.
That only works if the shell can tell the truth about four different seams:

1. **identity**
   - the stable object/document identity.
   - should survive many placement changes when the provider supports that model.

2. **placement**
   - the current parent/name/bind/alias by which the object appears in this view.
   - may differ across processes, views, or provider-local collections.

3. **rights held here now**
   - the exact authority attached to one live handle or bind in this pane.
   - may be narrower than the full object model.

4. **advertised affordances**
   - the provider-visible operations that make sense for this target or placement.
   - may depend on placement, current provider state, object kind, or server-side policy.

A fifth class matters too:

5. **receipt/history**
   - evidence about what used to be visible or possible.
   - useful for explanation, but not current truth.

## Lessons worth stealing

### Same object, many placements
Android's document model is a very sharp precedent.
`COLUMN_DOCUMENT_ID` is an opaque provider-local identity, and the docs explicitly say one document may be included as a child of multiple directories.
That is exactly the kind of seam ViewFS should preserve.

### Rights are not just names
Linux `O_PATH` is a good reminder that a handle can designate a location and support only descriptor-level operations while ordinary byte I/O fails.
Capsicum strengthens the same lesson by letting a descriptor be refined to a narrower operation set.
That means ViewFS should never infer byte I/O or mutation power from one placement string alone.

### Supported verbs deserve their own lane
Android `COLUMN_FLAGS` and HTTP `Allow` are both good precedents for explicit supported-operation advertisement.
In both families, the useful idea is not the exact wire format.
It is that supported verbs should be inspectable and can change dynamically, instead of being guessed from name shape or stale folklore.

### Namespace and rights still matter
Fuchsia capabilities combine access with rights, and the namespace a component receives is explicitly assembled.
That is a strong reminder that `what the target supports` and `what this pane currently holds` should remain distinct classes.

## Working posture for ViewFS

- keep object identity stable even when placement changes;
- keep placements explicit even when several placements refer to the same object;
- keep current handle-rights summaries explicit even when the shell shows friendly verb labels;
- keep advertised affordances explicit enough to drive action menus, route slips, and chooser follow-ups;
- keep receipts/history available for explanation without laundering them into current affordance truth.

## Shell product ideas

### Place cards
A selected object card should be able to say:
- `same object`
- `appears here as …`
- `also bound in …`
- `history saw it at …`

without pretending those placements are the object's identity.

### Verb ledgers
The shell should be able to explain each action row with small reason cells such as:
- `supported by provider`
- `unsupported at this placement`
- `current handle too narrow`
- `policy asks first`
- `history only`

That is much better than either giant disabled menus or late generic failures.

### Affordance lenses
A focused inspect drawer should separate:
- identity,
- placement,
- rights held now,
- advertised verbs,
- and receipt/history.

That lets the shell be extremely powerful without becoming spooky.

## What not to decide yet

Do not decide yet:
- one canonical verb vocabulary for every provider;
- whether advertised affordances are returned directly by providers, synthesized by adapters, or mixed;
- one universal placement schema;
- whether rights summaries are raw bitsets or normalized high-level badges.

Freeze the separation first.
