# Route envelopes, authority sidecars, sink bindings, and receipts

This note sharpens one more low-regret ViewFS separation:
**typed route capsule**, **optional authority sidecar**, **actual sink-side acceptance/bind/import**, and **durable receipt/history** are different truths.

Relevant precedents:
- **REF-PLAN9-PLUMB** and **REF-PLAN9-PLUMBER4**: typed routed messages are powerful precisely because they are messages with ports/rules, not magical current authority.
- **REF-ANDROID-SHARE-FILE**, **REF-ANDROID-URIPERMISSION**, and **REF-ANDROID-GRANTURIPERMISSION**: Android cleanly distinguishes the Intent envelope, the named content URI, and the temporary per-URI permission grant.
- **REF-XDG-PORTAL-DESIGN** and **REF-XDG-REQUEST**: portal requests have their own object lifetime and later responses, which helps keep request state separate from final outcome.
- **REF-WAYLAND-DATADEVICES**: offered representations, chosen MIME type, and actual transferred bytes stay distinct.
- **SlopOS RFC-0116 / RFC-0117**: wallet descriptors are non-authoritative, and plumb envelopes are non-authoritative too.

## Why the split matters

The future custom shell is going to traffic in route slips, open-with surfaces, share sheets, paste/import trays, and automation lanes.
That only stays honest if it can answer at least four different questions:
- what route was proposed?
- what explanatory or narrowing sidecar came with it?
- what did the sink actually accept here?
- what is merely durable history now?

Those questions differ because the consequences differ.
A route capsule may be totally harmless and copyable.
A sidecar may make the route more useful or auditable without carrying any reopen power.
A sink-side bind/import/localization can create genuine local consequence.
A receipt can explain all of that while authorizing nothing now.

## Working posture

### Route capsules should stay explicit and cheap
ViewFS should make it easy to generate typed route capsules from clicks, prompts, command blocks, result cards, and notebooks.
A route capsule should be safe to inspect, save, diff, and share precisely because it is not the same thing as current authority.

### Authority sidecars should stay inspectable instead of invisible
Sidecars are where a lot of shell magic usually goes to die.
ViewFS should resist that.
If a route was helped by a wallet digest, representation offer set, URI-grant candidate, or portal request handle, the shell should be able to show that.

### Sink acceptance is where actual local truth begins
The receiver should be able to say exactly what happened:
- `accepted text/plain`
- `accepted image/png`
- `accepted projected view`
- `accepted live bind`
- `localized copy here`
- `declined`

That is much more honest than one universal `opened` or `shared` verb.

### Receipts should preserve exact consequence without reviving it
A receipt should say what route capsule existed, what sidecars were presented, and what the sink accepted.
It should not silently become a replayable route guarantee or a current grant.

## Shell and terminal payoffs

A truthful shell can turn this split into product leverage:
- **route slips** that are copyable, diffable, and dry-runnable;
- **authority sidecar chips** for `wallet`, `uri grant`, `portal request`, `representation offers`, or `proof needed`;
- **sink trays** that show exact acceptance state per pane/process;
- **designation-only pills** so copied route text never pretends to be authority;
- **post-route bind cards** that say what really crossed the boundary and what remained merely descriptive.

## Receiver-side classification worth standardizing early

A useful classification for shell UX and protocol experiments is:
- `route_only`
- `route_plus_sidecar_descriptor`
- `route_plus_sidecar_narrowed`
- `sink_accept_representation`
- `sink_accept_bind`
- `sink_accept_projection`
- `sink_accept_localization`
- `sink_declined`
- `receipt_only`

This is intentionally posture-oriented.
It does **not** decide one final plumb wire format, one final sidecar schema family, or one final import/bind/localization backend.

## What not to freeze yet

Do **not** freeze yet:
- one universal sidecar taxonomy,
- whether route capsules and portal requests share a storage format,
- whether the same route capsule can drive both GUI and TTY sinks verbatim,
- whether some sidecars are pure descriptors while others can carry narrowly live authority,
- or one permanent answer to how replay rehydrates sidecars.

The separation is worth freezing now.
The transport and binding machinery are not.
