# Architecture overview

## Core split
ViewFS should be decomposed into five layers:
1. **Object store** — immutable blobs, manifests, and compact metadata.
2. **Handle layer** — object references plus rights and attenuation rules.
3. **View layer** — explicit per-process synthetic roots assembled from bindings.
4. **Portal / compat layer** — user-mediated imports/exports and optional path shims.
5. **Shell / transcript layer** — receipts, blocks, workflows, and inspection UX over the lower layers.

Host bridges/backstops such as preopen adapters, rooted host path walkers, or Linux sandboxing may be useful during bring-up, but they are implementation scaffolding rather than the semantic center of the design. Keep direct-handle opens, rooted compat pathwalks, portal-mediated grants/projections, ambient host escapes, current published names, discoverability/enumeration/exact-name-open truth, provider/catalog adverts, freshness-scoped readiness, provider-ready/reacquire/local-realized truth, grant-needed posture, current possession, freshness/step-up posture, current invocability, and receipts/history visibly separate too; see `docs/30-architecture/explicit-handle-opens-rooted-compat-pathwalks-and-ambient-escapes.md`, `docs/30-architecture/store-membership-synthetic-views-live-handles-and-published-names.md`, `docs/30-architecture/discoverability-enumeration-exact-name-reachability-and-fit-notes.md`, `docs/30-architecture/presence-adverts-readiness-current-authority-and-receipts.md`, `docs/30-architecture/provider-ready-claims-reacquire-obligations-local-realizations-and-live-handles.md`, `docs/30-architecture/foreign-backed-borrows-compat-attaches-projected-imports-and-local-realizations.md`, and `docs/30-architecture/current-possession-freshness-step-up-and-current-invocability.md`, and `docs/30-architecture/native-attaches-adapted-attaches-coerced-representations-and-local-realizations.md`. See `docs/30-architecture/host-bridge-and-backstop-posture.md`. Keep identity, reopen, reveal, handle/ref/receipt classes, saved session state, advisory registries, workspace-trust seams, preview/observation seams, watch/notification seams, link/alias/shortcut classes, grouped-authority classes, and launch-assembly classes distinct as well; keep exact object identity, current placement in a view, current handle-rights posture, and advertised affordances separate too; origin evidence, quarantine state, safe-open lanes, and trust transitions should stay separate too; delete/trash/recovery/retention/purge classes should stay separate as well; checkpoints, writable forks/worktrees, backup streams, publish candidates, and activation targets should stay separate too; see `docs/30-architecture/object-identity-recents-and-reveal.md`, `docs/30-architecture/handles-refs-and-receipts.md`, `docs/30-architecture/session-state-and-authority.md`, `docs/30-architecture/activation-carriers-badged-handle-copies-and-object-identity.md`, `docs/30-architecture/indexes-recents-and-selectors.md`, `docs/30-architecture/workspace-trust-and-automation-gates.md`, `docs/30-architecture/built-in-shell-affordances-customization-bundles-startup-files-and-project-hooks.md`, `docs/30-architecture/command-surface-layers-key-actions-and-external-launches.md`, `docs/30-architecture/previews-extractors-and-observation-surfaces.md`, `docs/30-architecture/watchers-notifications-and-rebuilds.md`, `docs/30-architecture/links-aliases-and-shortcuts.md`, `docs/30-architecture/identity-placement-rights-and-affordances.md`, `docs/30-architecture/origin-quarantine-and-trust-transitions.md`, `docs/30-architecture/trash-retention-and-purge.md`, `docs/30-architecture/checkpoints-clones-and-publication.md`, `docs/30-architecture/leases-preconditions-and-conflicts.md`, `docs/30-architecture/query-manifests-result-snapshots-and-live-feeds.md`, `docs/30-architecture/pins-caches-prefetch-and-hydration.md`, `docs/30-architecture/bundles-view-fragments-and-launch-kits.md`, `docs/30-architecture/requests-candidates-selections-and-imports.md`, and `docs/30-architecture/store-membership-synthetic-views-live-handles-and-published-names.md`; keep user intent, prepared route plans, approval checkpoints, committed execution, and result receipts separate as well; see `docs/30-architecture/intents-route-plans-approvals-and-results.md`; keep suggested automation, promoted user-owned workflows, prepared run plans, committed runs, and history receipts separate too; see `docs/30-architecture/suggestions-recipes-promotions-and-runs.md`; keep lend requests, live borrowed authority, durable delegated refs, issuer-side recall/expiry controls, and loan-end receipts separate as well; see `docs/30-architecture/loans-delegations-recalls-and-expiry.md`; keep reuse candidates, exact basis records, current drift checks, fresh reconsent checkpoints, renewed artifacts, and reuse receipts separate too; see `docs/30-architecture/basis-records-drift-checks-and-reconsent.md`; keep admissible witness packs, caveat sets, freshness/consistency witnesses, why-records, and durable receipts separate as well; see `docs/30-architecture/witness-packs-caveats-freshness-and-why-records.md`. Keep validation/schema material, authoritative policy/caveat material, shell advice rails, decision diagnostics, and durable logs/receipts separate too; see `docs/30-architecture/schemas-policies-advice-diagnostics-and-decision-logs.md`; and keep policy-family/catalog choice, exact authoritative cuts/consistency posture, fallback candidates, repair proposals, and selection receipts/history separate as well; see `docs/30-architecture/policy-families-cuts-fallbacks-and-repair.md`. Keep deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and adoption receipts/history separate as well; see `docs/30-architecture/deny-ceilings-narrowing-and-scope-eligibility.md`. Keep owner/org policy sources, trust-state gates, user/profile preference layers, workspace/imported proposal sources, effective active state, and durable receipts/history separate as well; see `docs/30-architecture/policy-sources-trust-gates-and-precedence.md`. Keep author classes, carrier/container classes, trust gates, advisory-only helper sources, effective active state, and durable receipts/history separate as well; see `docs/30-architecture/policy-authors-carriers-and-advisory-sources.md`. Keep protected-authorable state, carrier/discovery presence, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipts/history separate as well; see `docs/30-architecture/protected-scopes-authorability-and-invocation-lanes.md`. Keep publisher trust, installed helper packages, configured helper/server definitions, enabled state, start approvals, live brokered sessions, request-scoped tool selections, and durable receipts/history separate as well; see `docs/30-architecture/publisher-trust-helper-installs-and-live-sessions.md`. Keep helper-exposed resource descriptors, prompt templates, tool descriptors, app surfaces, completion suggestions, request-bound attachments/selections, live invocations/results, and durable receipts/history separate as well; see `docs/30-architecture/resources-prompts-tools-apps-and-bindings.md`. Keep immediate requests, accepted task wrappers, live progress/status streams, input-required checkpoints, deferred final results, and durable receipts/history separate as well; see `docs/30-architecture/requests-tasks-progress-and-results.md`. Keep transfer/courier offers, accepted representation choices, live copied handles, later revival designators, receiver-local adopted binds, and durable receipts/history separate as well; see `rfcs/0058-viewfs-keep-transfer-offers-live-handle-copies-revival-designators-adopted-binds-and-receipts-separate.md`.

## Design pressure
The danger zone is letting layer 4 or 5 quietly redefine layers 1–3. History suggests that once ambient paths, hidden inheritance, or folklore shell state sneak back in, capability systems lose their main benefit.

A second danger zone is premature mutable-state certainty. The object store can be boring now; mutable work state should stay an explicit design space until a few narrow spikes have pressure-tested journals, root-pointer updates, and stable-anchor models.

A third danger zone is semantic overloading. ViewFS should not casually make one thing serve as all of the following at once:
- immutable object identity,
- current name in a view,
- mutable current head,
- workspace/tree binding,
- durable reopen authority,
- recent-item / palette memory,
- and URI route/reveal state.

Those may interact, but they should remain separate questions until evidence proves a coupling is worth the cost. Saved shell/session memory should also stay separate from current authority.

A fourth danger zone is trusting workspace automation just because the workspace tree is visible. Browsing a project, parsing its metadata, and executing its tasks/env hooks/debug launchers/agents should remain distinct approvals.

A fourth-and-a-half danger zone is trusting shell delight just because the prompt looks local and friendly. Built-in shell affordances, explicit reviewed customization bundles, ambient host startup files, project-local activation hooks, and durable receipts/history should remain distinct approvals and truths too. Otherwise prompt rendering, aliases, completions, terminal integration, and per-directory activation quietly regress to ambient dotfile folklore.

A fourth-and-three-quarters danger zone is trusting command resolution just because one familiar token or keypress appears to work. Built-in verbs, lexical expansions, semantic command layers, key actions/widgets, external launches, and durable receipts/history should remain distinct truths too. Otherwise abbreviations, overlays, palette actions, key tables, wrappers, and external executables quietly regress to command-folklore soup.

A fourth-and-seven-eighths danger zone is trusting color, parse recovery, or diagnostics just because the line editor looks smart. Editable buffers, parsed/highlighted structure, advisory diagnostics, compiled command packets, prepared actions, and durable receipts/history should remain distinct truths too. Otherwise syntax color, parser guesses, lint hints, and stale packet chrome quietly regress into fake readiness.

A fifth danger zone is letting preview or extraction quietly redefine authority. A shell can have gorgeous peek panes, compare mode, and derived sidecars without pretending that preview equals open, trust, or durable reopen.

A sixth danger zone is treating change feeds as perfect truth. Watchers, recents, palettes, and smart folders can feel alive while still admitting overflow, recrawl, rebuild, and partial coverage states.

A seventh danger zone is letting every clickable link-like thing collapse into one class. Namespace aliasing, durable reopen, launch routes, and transcript receipts can all be useful, but they should not masquerade as the same kind of authority.

An eighth danger zone is letting origin and quarantine quietly collapse into trust. Previewing, rebinding, indexing, or remembering an object should not silently clear or bless it, and broad trusted-location semantics should carry a high burden of proof.

A ninth danger zone is treating all delete-like actions as if they were one thing. Removing a name from a view, moving something to a recoverable trash, keeping local history, holding immutable data live through roots, and actually purging collectible storage are different seams with different proof obligations.

A tenth danger zone is treating every time-travel-ish operation as “just a snapshot.” Cheap checkpoints, writable forks/worktrees, replicated backup streams, publish candidates, and activation/rollback targets have different promises and should stay visibly distinct.

An eleventh danger zone is flattening all concurrent-write behavior into “lock state.” Expected-old guards, create-if-absent semantics, short reservations, field/subtree ownership hints, conflict artifacts, and explicit takeover acts have different costs and should stay separate.

A twelfth danger zone is pretending a smart folder is one thing. The saved query recipe, the current result snapshot, the live update feed, the shell pin/sidebar surface, and the current authority over matches are all different classes and should stay visible as such.

A thirteenth danger zone is flattening import, open-in-place, save/export, move, transfer, share, and promise-later materialization into one generic file operation. Those lanes move different things across boundaries: some copy bytes, some delegate access, some only select a destination, and some only publish a promise to materialize bytes later.

A fourteenth danger zone is treating prefetch, cache warmth, hydration, pinning, mirroring, and offline bundles as one generic “download state”. Those classes make different promises about discardability, retention, locality, transport, and offline truth, and they should stay visibly separate.

A fifteenth danger zone is collapsing grouped authority, namespace templates, live view binds, child launch kits, and historical receipts into one convenience object. Those classes interact heavily, but they answer different questions: what travels together, what could be bound, what is bound now, what a child will launch with, and what only happened in the past.

A sixteenth danger zone is collapsing local object-store existence, synthetic portal/provider projection, current live-handle possession, current publication inside one process namespace, and durable receipt/history into one vague “file” concept. Those classes interact heavily, but they answer different questions: what exists locally, what is reachable through a mediated view, what current authority is held, what is published here now, and what only happened in the past.

A sixteenth danger zone is collapsing mediated interaction state, chooser-owned candidate sets, selected outcomes, minted grants/refs, live binds, and history into one magical “opened object”. Those classes answer different questions: what interaction is pending, what the mediator was willing to show, what the user designated, what authority was actually issued, what is bound into this pane now, and what only happened in the past.

A seventeenth danger zone is collapsing user intent, prepared route/action plans, approval checkpoints, committed execution, and result/history into one magical shell action. Those classes answer different questions too: what is being asked for, how the system would do it, what exact delta was reviewed, what actually ran, and what only happened in the past.

An eighteenth danger zone is collapsing externally suggested automation, promoted user-owned workflows, prepared run plans, committed runs, and history into one magical saved command. Those classes answer different questions too: where the idea came from, whether it is mine yet, how it would run now, what actually ran once, and what only happened in the past.

A nineteenth danger zone is collapsing lend requests, live borrowed handles, durable delegated refs, issuer-side recall/expiry controls, and loan-end history into one magical shared-handle object. Those classes answer different questions too: who is asking, what is live right now, what may be reopened later, who can end or renew the relationship, and what only happened in the past.

A twentieth danger zone is collapsing past success, exact prior basis, current drift, fresh reconsent, renewed authority, and reuse history into one magical replay object. Those classes answer different questions too: what worked before, what exactly was reviewed, what changed now, what must be approved again, what is live or reopenable now, and what only happened in the past.

A twenty-first danger zone is collapsing admissible witness material, caveat sets, freshness/consistency witnesses, why-records, and durable receipts into one magical justification object. Those classes answer different questions too: what facts are allowed to count, what narrowing is in force, what state cut was evaluated, why the system chose its current class, and what only happened in the past.

A twenty-second danger zone is collapsing proposal origins, proposal scopes, escalation requests, authoritative adoptions, and durable adoption receipts into one magical helper lane. Those classes answer different questions too: who suggested the change, how broad it wants to be, whether a higher-scope move is still pending, what exact act made something live, and what only happened in the past.

A twenty-third danger zone is collapsing deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and durable adoption history into one magical permission helper. Those classes answer different questions too: what is categorically forbidden, what combinations are admissible at all, what safer alternative is on offer, what widening step is still pending, and what only happened in the past.

A twenty-fourth danger zone is collapsing author classes, trusted carriers, trust gates, advisory-only rails, and durable history into one hidden trust tunnel. Those classes answer different questions too: who may author active truth at all, what merely transported candidate material here, what still blocks it, what can only advise, and what only happened in the past.

A twenty-fifth danger zone is collapsing helper-exposed resources, prompts, tools, interactive app surfaces, completion suggestions, request bindings, live invocations/results, and durable history into one magical helper item. Those classes answer different questions too: what context/data exists, what workflow template exists, what may be invoked, what interactive surface may be launched, what is only a hint, what is attached now, what actually ran now, and what only happened in the past.

A twenty-sixth danger zone is collapsing transfer offers, accepted representation choice, live copied handles, later revival designators, receiver-local adoption, and durable history into one vague shared/opened object. Those classes answer different questions too: what was offered, what the receiver accepted, what carries authority right now, what can only be revalidated later, what is actually bound here now, and what only happened in the past.

Another danger zone is collapsing foreign-backed usability, wrapper/relay attach posture, projected import posture, local realization, and durable history into one flattering `opened here` story. Those classes answer different questions too: does another provider still back this thing, what glue made it usable here, what scoped view or synthetic name exists locally, what bytes/object state were actually localized here, and what only happened in the past.

Another danger zone is collapsing native receiver fit, adapter/relay-backed usability, coerced alternate representations, local realization, and durable history into one flattering `opened natively` story. Those classes answer different questions too: is this lane directly native for the receiver, what glue is in the path, is the user seeing the same object or one translated surface, what stronger local/native state was explicitly made here, and what only happened in the past.

## Working build order
1. immutable blob + manifest storage
2. directory/object handle API
3. per-process view root construction
4. portal import/export receipt flow
5. path compatibility membrane
6. shell/terminal ergonomics
7. only then: mutable work-state experiments, query/index layers, stored bundle/fragment schemas, stronger revocation models, richer origin/quarantine workflows, final plan/approval/result schemas, final loan/delegation/expiry schemas, final reuse/basis/reconsent schemas, and final witness/caveat/freshness/why-record schemas

## Early object vocabulary (tentative)
- `Blob`
- `Directory`
- `Manifest`
- `View`
- `GrantReceipt`
- `DurableRef`
- maybe later: `ImportRequest`, `SelectionRecord`, `ImportGrant`, `WorkspaceGrant`, `IntentRecord`, `RoutePlan`, `ApprovalCheckpoint`, `ExecutionRecord`, `ResultReceipt`, `SuggestedRecipe`, `PromotionReceipt`, `UserWorkflow`, `PreparedRunPlan`, `RunRecord`, `RunReceipt`, `LoanRequest`, `BorrowedHandleSet`, `DelegatedRef`, `RecallControl`, `LoanEndReceipt`, `BasisRecord`, `DriftCheck`, `ReconsentCheckpoint`, `RenewedArtifact`, `ReuseReceipt`, `WorkJournal`, `SessionManifest`, `CapabilityBundle`, `ViewFragment`, `LaunchKit`, `OriginReceipt`, `QuarantineMark`, `EditLease`, `ConflictReceipt`, or `MutableAnchor`

Everything richer should justify itself with a short experiment or a very strong interoperability need.

A likely future rule: cheap checkpoints are good enough to encourage routine experimentation, but promotion to replicated/published/activatable state should remain a separate seam.

## Three things to keep visibly subordinate
- **Paths**: compatibility syntax over explicit bindings.
- **Bundles**: grouped capabilities for transport or launch ergonomics, not a hidden ambient namespace.
- **Launch kits**: child-process assembly objects derived from explicit inputs, not a synonym for stored bundles or current pane state.
- **Synthetic views**: restricted mediated/provider projections that make something reachable somewhere without implying native publication in every current ViewFS pane/process.
- **Published names**: current path-like attachments inside one concrete process view, not a synonym for object identity or durable reopen.
- **Import requests/results**: chooser interactions, selected outcomes, minted grants, and live binds should stay class-aware instead of collapsing into one “opened object”.
- **Prepared plans and approvals**: exact review/execution aids over explicit handles, views, and portals, not hidden standing grants or floating mutable approvals.
- **Proposal helpers and adoption gates**: source-aware suggestion and escalation aids over explicit handles, views, policies, and receipts, not hidden standing selectors or silent scope widening.
- **Suggested automation and promoted workflows**: source-aware shell aids over explicit handles, views, portals, and receipts, not hidden standing trust or source-following mutation.
- **Borrowed authority**: bounded live sharing over explicit handles/views, not a synonym for durable reopen or hidden session-wide trust.
- **Trusted carriers**: helpful transport and discovery lanes over explicit adoption/gating surfaces, not a synonym for authoring ceilings or active policy.
- **Reuse / renewal**: exact-basis comparison and reconsent aids over explicit handles, refs, views, and receipts, not a synonym for sticky approval or floating current authority.
- **Editable state**: likely a sidecar, journal, or root-pointer layer over immutable content rather than the base storage truth.

## Bring-up rule
During the design phase, host-side bridges and backstops are acceptable **only** if they stay visibly subordinate to handles, views, portals, and receipts. The implementation may lean on `openat2`-style rooted walking, preopen adapters, explicit ambient-authority markers, or Landlock-style host sandboxes, but those tactics must not become the user-facing explanation of why an operation was allowed.

## New anti-collapse pressure from Revision 029
ViewFS should also keep one more seam explicit while policy-aware shelling is still fluid: **validation/schema material, authoritative policy/caveat material, shell advice/ranking, per-decision diagnostics, and durable logs/receipts** should not collapse into one magical “policy helper.” That keeps the shell free to be smart, rank likely repairs, and render great why-panels without letting hints or history become enforcement truth.

## New anti-collapse pressure from Revision 031
ViewFS should also keep one more seam explicit while proposal-heavy shelling is still fluid: **proposal origin/source, proposal lane/scope, escalation requests, authoritative adoptions, and durable adoption receipts** should not collapse into one magical helper lane. That keeps the shell free to surface workspace/profile/org/history suggestions and repair hints without letting helpers or history become judges.

## New anti-collapse pressure from Revision 032
ViewFS should also keep one more seam explicit while scope control and shell escalation are still fluid: **deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and durable adoption receipts** should not collapse into one magical permission helper. That keeps the shell free to recommend safer narrower routes and great receipt-only fallbacks without letting advice, history, or queued actions widen current authority.

ViewFS should also keep one more seam explicit while source-aware shelling is still fluid: **author classes, carrier/container classes, trust gates, advisory-only helper sources, effective active state, and durable receipts/history** should not collapse into one hidden trust tunnel. That keeps the shell free to discover and render helper material aggressively without letting trusted carriers, history, or repair rails silently become the authors of current truth.

ViewFS should also keep one more seam explicit while source-aware shelling is still fluid: **protected-authorable state, carrier/discovery presence, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipts/history** should not collapse into one hidden auto-apply tunnel. That keeps the shell free to show rich lower-trust helpers and one-shot invokes without letting them silently author sticky state.

ViewFS should also keep one more seam explicit while helper-feature shelling is still fluid: **resource descriptors, prompt templates, tool descriptors, interactive app surfaces, completion suggestions, request-bound attachments/selections, live invocations/results, and durable receipts/history** should not collapse into one magical helper item. That keeps the shell free to expose rich helper catalogs and completions without letting visibility or old outcomes quietly become current request authority.

ViewFS should also keep one more seam explicit while custom-shell editing is still fluid: **editable buffers, parsed structures/highlight models, advisory diagnostics, compiled command packets, prepared actions, and durable receipts/history** should not collapse into one magical smart prompt. That keeps the shell free to offer tree-aware editing, syntax color, lint rails, and packet gutters without letting parser guesses or diagnostics impersonate current authority or current readiness.

A twenty-third danger zone is collapsing immediate requests, accepted task wrappers, live progress/status, input-required waits, deferred final results, and durable history into one vague “background job”. Those classes answer different questions: what was asked now, what was accepted for later work, what is merely the latest live status, what extra input is still needed, what final output is retrievable, and what only happened before.


A twenty-fourth danger zone is collapsing close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable history into one vague stop-or-rerun menu. Those classes answer different questions: did we end the interaction, request graceful cancellation, force-stop the run, merely stop watching/delete retained state, start a fresh attempt, branch from old state, attach to an existing run, or only record something that happened before.

## New anti-collapse pressure from Revision 039
ViewFS should also keep one more seam explicit while deferred control and shell stop/retry UX are still fluid: **close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipts/history** should not collapse into one magical stop-or-rerun menu. That keeps the shell free to stop gracefully, kill forcefully, forget locally, or branch deliberately without letting those verbs silently mutate remote work, retained payloads, or current authority.


A twenty-fifth danger zone is collapsing read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable history into one vague connected session. Those classes answer different questions: did we only watch output or state, could we type into the existing session, did we send a control/update message, did we spawn a fresh debug command, did we open a temporary sideband access path, or are we only looking at a transcript of something that already ended?

## New anti-collapse pressure from Revision 040
ViewFS should also keep one more seam explicit while live-session shelling and helper interaction are still fluid: **read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable transcripts/history** should not collapse into one magical connected session. That keeps the shell free to watch, attach, control, debug, or tunnel without letting those verbs silently swap control rights, mutate remote state, or resurrect history as a live channel.


## New anti-collapse pressure from Revision 076
ViewFS should also keep one more seam explicit while type/opening UX is still fluid: **declared type hints, derived/computed type evidence, handler association sets, act-local chosen openers, live open/editor state, and durable receipts/history** should not collapse into one magical `open with` truth. That keeps the shell free to expose great preview/editor choices, disagreement cards, and open-state badges without letting file suffixes, old defaults, or stale receipts silently become present authority.


## New anti-collapse pressure from Revision 078
ViewFS should also keep one more seam explicit while query/follow/live-update UX is still fluid: **continuation cursors, sync watermarks, live subscriptions, rebuilt snapshots, gap/reset verdicts, and durable receipts/history** should not collapse into one magical `live query` helper. That keeps the shell free to follow, relist, rebuild, and explain drift honestly without letting provider tokens, last-seen markers, or old receipts masquerade as current authority or current state.

## New anti-collapse pressure from Revision 079
ViewFS should also keep one more seam explicit while editing/import-repair/external-tool round-trips are still fluid: **observed validators, private writable sessions, live write holds, exact commit preconditions, committed durable versions, and receipts/history** should not collapse into one magical save state. That keeps the shell free to stage locally, guard commits on exact basis material, surface hold state honestly, and show the winning durable version without letting draft-local close/flush folklore become present truth.

A twenty-seventh danger zone is collapsing partial local coverage, partition/layout metadata, whole-object completeness, exact whole-object proofs, live lazy/range-fill reachability, and durable history into one vague `downloaded object` story. Those classes answer different questions too: what bytes are here now, how the object is partitioned, whether the whole thing is present, whether one exact whole-object witness exists, whether missing bytes can be fetched right now, and what was only true before.

## New anti-collapse pressure from Revision 080
ViewFS should also keep one more seam explicit while sparse/lazy object handling is still fluid: **partial residency/coverage maps, chunk-layout knowledge, whole-object completeness verdicts, whole-object proofs, live range-fill sessions, and durable receipts/history** should not collapse into one magical hydration state. That keeps the shell free to show hole maps, lazy-fill reachability, whole-proof ladders, and offline honesty without letting sparse local bytes or composite per-part identifiers silently become full-local truth.


A twenty-eighth danger zone is collapsing delta recipes, exact basis requirements, current apply sessions, reconstructed target objects, fallback full-fetch lanes, and durable history into one vague `updated object` story. Those classes answer different questions too: what transform artifact is available, what exact prior bytes it depends on, what reconstruction is happening now, what target bytes were materialized, whether the system had to abandon delta apply and fetch the whole object, and what only happened before.

## New anti-collapse pressure from Revision 081
ViewFS should also keep one more seam explicit while efficient repair/update/import flows are still fluid: **delta recipes, exact basis requirements, current apply sessions, reconstructed target objects, fallback full-fetch lanes, and durable receipts/history** should not collapse into one magical update helper. That keeps the shell free to show basis cards, apply ladders, fallback honesty, and rebuilt-from lineage without letting patch artifacts, old basis ids, or old receipts silently become current object truth.

## New anti-collapse pressure from Revision 082

## New anti-collapse pressure from Revision 087
ViewFS should also keep one more seam explicit while import/localization/restore UX is still fluid: **provider-ready claims, reacquire or repair obligations, local realizations, current live handles, and durable receipts/history** should not collapse into one magical `available` bit.

A provider may honestly be able to supply something later without that thing existing locally now. A restored or remembered object may still owe one repair step before stronger claims become true. A local realized object may exist here without any process currently holding authority. Keeping those truths split gives the future shell room for make-local ladders, provider-owned badges, repair rails, and offline honesty without forcing one final object-store or fetch mechanism too early.

ViewFS should keep one more seam explicit while SlopOS launch/import/durable-handle posture is still settling: **activation carriers, live handle copies, issuer-visible badges or courier witnesses, immutable object refs, receiver-local binds, later revival designators, and durable receipts/history** should not collapse into one vague `open` story.

A startup slot, portal result, or local courier lane can explain where authority came from now without masquerading as durable path truth or future rediscovery. A badge can explain copy lineage without becoming immutable identity. A receipt can explain what happened before without reviving present authority. That keeps the object-store and shell/terminal design honest while leaving room for SlopOS to settle more of the surrounding runtime and portal machinery first.


## Discoverability and authority should not collapse
ViewFS should also keep one more seam explicit while the custom shell, query panes, and portal-mediated import story are still fluid: **direct current authority, exact-name reachability inside a held root/view, enumeration/listability, advisory suggestions or fit notes, and durable receipts/history** should not collapse into one fake explorer truth. That keeps the shell free to show rich candidates, indexes, helper suggestions, and import options without letting `it appeared in UI` masquerade as `it was openable now`.

## Revision 088: claim tickets, holder proof, and spent traces

ViewFS should now also keep a sharper split *inside* the broad family of authority-bearing artifacts.
A **claim ticket** that may redeem into stronger authority later is not the same thing as a **holder-bound grant** that only works for the current proving holder, which is still not the same thing as a **passable live handle** that may actually be copied or couriered now.
A **spent/expired ticket** is yet another truth again: it should stay visible as anti-replay history without looking reusable.

This is a good low-regret seam for SlopOS-era design work because current SlopOS material already leans hard toward provider-local PKCE/DPoP binding rather than portable bearer folklore, and Steward is now exploring compact consumable-grant and holder-bound-grant posture nearby.
ViewFS can therefore standardize the vocabulary and shell UX around redemption, passability, proof, and spentness now while leaving token format, proof method, CapStore persistence, and redemption ownership open.

## Revision 089: possession is not current invocability

ViewFS should now also keep a sharper split *inside* the broad family of current authority stories.
A thing may be **held here now** or **realized here now** and still not be **invokable here now** for the current action.
Freshness may be too old. Stronger authentication may still be required. Immediate local presence or user verification may still be required. A prior satisfaction may already be spent and should only survive as history.

This is a good low-regret seam for SlopOS-era design work because current SlopOS material already pins imported step-up-authentication semantics as provider-local reauthentication guidance rather than portable recent-login truth, and Harbor is separately exploring proximity and timebound continuation ideas nearby.
ViewFS can therefore standardize the vocabulary and shell UX around possession, recency, step-up, local presence, and current invocability now while leaving assurance taxonomy, proof carrier, and mediator ownership open.


## Revision 090: standing-watch good status is not the same thing as live possession

ViewFS should now also keep a sharper split *inside* the broad family of current-authority and current-invocability stories.
A thing may still be **held here now** or **realized here now** and still not be **in good standing here now** after later watch/status processing.
Later status material may say `inactive`, `suspended`, `refresh`, `unknown`, or `replacement available`.
A local receiver may narrow, quarantine, or defer on that basis without destroying the base object or base handle truth.

This is a good low-regret seam for SlopOS-era design work because current SlopOS material already keeps provider-local status, durable receipt/history, and local authority consequences on distinct seams, and Ward is separately exploring status carriers, suspension rails, refresh notices, attenuation events, and receiver stance nearby.
ViewFS can therefore standardize the vocabulary and shell UX around live possession, watch/status carriers, local holds, successor refresh, and post-watch invocability now while leaving transport, policy ownership, and successor-adoption mechanism open.


## Revision 091: sender-side share truth should not collapse

ViewFS should now also keep a sharper split *inside* the broad family of current-authority and transfer stories.
A thing may be **held here now** and still not be **duplicable here now**.
It may be duplicable locally and still not be **lendable live across this boundary now**.
It may fail live lend and still support one **weaker representation export** such as bytes, a projected document, or a claim artifact.
A receipt that any of those happened is another truth again.

This is a good low-regret seam for SlopOS-era design work because current SlopOS material already treats transfer portals, document lanes, clipboard/drag-drop mediation, and attenuation as explicit seams rather than ambient aftermath.
ViewFS can therefore standardize the vocabulary and shell UX around possession, local duplication, live lends, representation exports, and receipts now while leaving the final courier ABI, export taxonomy, and receiver-adoption model open.


## Route capsules, authority sidecars, sink bindings, and receipts
ViewFS should also keep one more shell/import seam explicit while SlopOS plumb, wallet, and document-transfer posture is still settling: **typed route capsule**, **optional authority sidecar**, **actual sink-side acceptance/bind/import**, and **durable receipt/history** should not collapse into one flattering `open` or `share` story.
A route capsule is allowed to be copyable, inspectable, and harmless precisely because it is not sink-held authority by itself.
A sidecar may narrow, explain, or accompany the route without being the same thing as a live capability container.
And the sink should remain free to accept only one representation, one projected bind, one live bind, one localized copy, or nothing at all.
This is a good low-regret seam for SlopOS-era design work because current SlopOS material already keeps CH-PLUMBMSG non-authoritative, CH-WALLET non-authoritative, portal requests request-local, and document/transfer grants explicit rather than ambient.

## Privilege brackets, borrowed authority, call-chain contexts, deny-only hints, and receipts
ViewFS should also keep one more helper/automation seam explicit while SlopOS privilege-bracketing and sibling helper/origin material are still settling: **privilege bracket**, **borrowed authority**, **call-chain context**, **deny-only routing hint**, and **durable receipt/history** should not collapse into one vague `helper used its powers` story.
A privilege bracket is bounded execution posture.
Borrowed authority is actual current capability.
Call-chain context is explanation.
A deny-only hint can veto or dim one route without becoming an allow path.
And a receipt should remember all of that later without reviving bracket state or caller-local context.
This is a good low-regret seam for SlopOS-era design work because current SlopOS material already leans toward explicit privilege bracketing and bounded non-authoritative call-chain descriptors instead of ambient helper folklore.
