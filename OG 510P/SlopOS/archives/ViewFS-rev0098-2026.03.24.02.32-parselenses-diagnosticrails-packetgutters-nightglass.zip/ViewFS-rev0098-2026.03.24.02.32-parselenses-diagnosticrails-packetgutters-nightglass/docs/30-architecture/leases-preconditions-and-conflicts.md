# Leases, preconditions, ownership hints, and conflict artifacts

Purpose: keep **optimistic write preconditions**, **short-lived leases / reservations**, **ownership or field-claim hints**, **actual committed updates**, **conflict evidence / receipts**, and **override / takeover acts** on distinct seams.

## Core rule
ViewFS should distinguish at least six related but different things:
- **optimistic precondition** — “apply this update only if the object/head/binding still matches what I read”,
- **short-lived lease / reservation** — “for a bounded time, prefer one editor/actor as the current writer or coordinator”,
- **ownership hint / field claim** — “this actor currently intends to manage this object or subset of fields”,
- **actual committed update** — the mutation that changes a head, binding, manifest, or mutable workspace state,
- **conflict artifact / receipt** — machine-readable evidence that a write was rejected, diverged, overridden, or needs merge/review,
- **explicit override / takeover** — a user-visible act that intentionally bypasses an earlier precondition, lease, or ownership hint.

Those should not silently collapse into one primitive named “lock”.

A user should be able to say:
- “save this only if nobody changed it since I opened it,”
- “reserve this workspace head for a few minutes while I’m editing,”
- “show me who currently claims this field or subtree,”
- “why did this write fail?”,
- “compare my stale attempt with the current head,”
- or “take over intentionally and leave a receipt.”

## Why this matters
History keeps rediscovering the same lesson:
- **optimistic preconditions** scale better than mandatory global locks for many editing flows,
- **leases** are useful, but they are time-bounded and can disappear unexpectedly,
- **ownership metadata** can help explain multi-actor state without being the same thing as a lock,
- **conflict receipts** are more honest than silently retrying or stomping remote state,
- and **override** should be a named, reviewable act rather than a hidden fallback.

That maps well to ViewFS because the project already wants:
- immutable-first objects with explicit mutable seams layered above them,
- explicit views and bindings,
- receipts and explain surfaces,
- and a shell that can make collaboration, automation, and replay legible without smuggling in ambient authority.

## Useful precedents
- **REF-RFC9110-PRECONDITIONS**: HTTP gives strong optimistic-write primitives with `If-Match`, `If-None-Match`, and `412 Precondition Failed`.
- **REF-S3-CONDITIONAL-WRITES** and **REF-S3-CONDITIONAL-DELETES**: S3 shows that object storage can keep writes/deletes safe with explicit preconditions instead of default overwrites.
- **REF-GIT-FORCE-WITH-LEASE**: Git turns “replace remote state, but only if it is still what I think it is” into an explicit ergonomic verb.
- **REF-GIT-UPDATE-REF**: Git also has a low-level compare-and-swap style ref update primitive with an expected old value.
- **REF-WEBDAV-LOCKING**: WebDAV proves leases/locks can exist, but lock tokens, timeouts, and write privilege are separate concepts.
- **REF-ETCD-TXN**: etcd makes compare-and-swap and conditional atomic updates first-class.
- **REF-ETCD-LEASE** and **REF-ETCD-LOCK**: etcd ties lock lifetime to leases and auto-releases on expiry or revocation.
- **REF-K8S-SSA**: Kubernetes server-side apply shows the value of tracking field ownership/conflicts separately from raw object existence.
- **REF-AZURE-BLOB-CONCURRENCY**: Azure Blob Storage explicitly documents optimistic concurrency with `If-Match` and `412` on intervening writes.
- **REF-SQLITE-ISOLATION** and **REF-SQLITE-LOCKINGV3**: SQLite is a reminder that real commit/locking machinery gets complicated quickly and should not be romanticized.

## Recommended ViewFS reading of the split

### 1. Prefer optimistic preconditions for ordinary writes
For many ViewFS mutable seams, the default update style should likely be:
- read current head/binding state,
- prepare a candidate mutation,
- submit with an expected old version / digest / generation,
- fail with a conflict artifact if reality moved meanwhile.

That keeps the core model simple and scalable.

### 2. Leases should be bounded coordination tools, not the only write gate
A lease or reservation may still be useful for:
- long-lived editing sessions,
- UI hints that someone is actively working,
- serializing certain high-value mutations,
- or protecting a narrow operational seam.

But a lease should remain visibly different from:
- write privilege itself,
- immutable object identity,
- proof that nothing changed,
- or permanent ownership.

### 3. Ownership hints can be narrower than locks
Some systems need “who manages this field or subtree?” more than they need a giant mutex.
That suggests ViewFS may eventually benefit from:
- field/subtree claim metadata,
- “managed by actor X” explain surfaces,
- and conflict messages that can say *which* aspect collided.

This is different from making every write require a hard lock.

### 4. Conflict evidence should be a first-class artifact
A rejected update should be able to leave behind a durable, non-bearer artifact describing:
- target object/head/binding,
- expected old version,
- actual current version,
- candidate change identity,
- whether the failure was precondition, lease, ownership, or policy related,
- and what override/merge options exist.

That is much better than an opaque “409” or silent last-writer-wins.

### 5. Override should be explicit and transcript-visible
Sometimes taking over is the right answer.
If ViewFS ever allows override, it should feel like:
- `takeover`, `override`, or `force-with-lease`,
- ideally with a compare view,
- and with a receipt recording the reason and displaced state.

It should not feel like the system secretly retried until it won.

### 6. Leases are not authority and lock tokens are not ownership magic
WebDAV is a good caution here:
- having a lock does not grant general write privilege,
- lock tokens are opaque,
- timeouts are advisory and can disappear unexpectedly,
- and clients still need ordinary authorization.

That aligns strongly with SlopOS and ViewFS philosophy.

### 7. Keep the write classes small and named
A future ViewFS write API should probably be able to say whether an operation is:
- unconditional,
- create-if-absent,
- update-if-version-matches,
- update-while-holding-lease,
- update-with-ownership-claim,
- or explicit override/takeover.

The exact Phase 1 surface can stay open, but the classes should stay distinct.

## A promising future object / receipt family
Without freezing final names yet, ViewFS may eventually want ideas such as:
- **WritePrecondition** — expected old digest/version/generation for a mutable head or binding,
- **EditLease** — bounded reservation over some mutable seam,
- **OwnershipHint** — narrow non-authoritative claim about who currently manages a subtree/field class,
- **ConflictReceipt** — structured evidence of why a write was rejected or needs merge,
- **TakeoverReceipt** — evidence that an override intentionally displaced some earlier state or claim,
- **MergePlan** — proposed reconciliation artifact derived from a rejected optimistic write.

The seam discipline matters more than the nouns.

## How this maps onto SlopOS seams
- **non-authoritative conflict scope / serialization hints** ↔ `conflict-key-schema-v0.md`, `conflict-key-family-registry.md`
- **bounded lease descriptors and their non-liveness rule** ↔ `capability-lease-posture-v0.md`, `lease-descriptor-state-boundary-v0.md`
- **view-local binding mutation** ↔ `view-namespace-posture-v0.md`, `capshell-cwd-root-posture-v0.md`
- **receipts and explain surfaces** ↔ `acp-outcome-receipt-schema-v0.md`, `explain-posture-v0.md`
- **commutativity / no-global-order-by-accident posture** ↔ `commutativity-and-interface-scalability.md`

## Shell implications
- `save-if-unchanged`, `create-if-absent`, `reserve`, `renew`, `release`, `takeover`, `diff-conflict`, and `merge-preview` should be visibly different verbs
- the shell should be able to answer “is this stale?”, “is this reserved?”, “who claims this field?”, and “what changed since I started editing?”
- rejected writes should produce structured receipts rather than vague error strings
- conflicts should be explorable without granting new authority
- optimistic failure should usually suggest compare/refresh/merge before override

## Anti-goals
- making all mutation depend on one giant mandatory lock manager
- letting leases silently become durable ownership or general write authority
- last-writer-wins by default on mutable heads just because it is easy to implement
- hiding conflicts behind silent retries or best-effort overwrite loops
- forcing a final field-ownership model before ViewFS even has its first narrow mutable seam
