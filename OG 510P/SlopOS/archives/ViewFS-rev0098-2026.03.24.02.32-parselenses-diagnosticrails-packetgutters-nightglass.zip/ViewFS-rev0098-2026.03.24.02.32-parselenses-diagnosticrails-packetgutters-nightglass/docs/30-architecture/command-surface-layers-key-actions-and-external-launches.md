# Command-surface layers, key actions, and external launches

This note sharpens one more low-regret ViewFS separation:
**built-in verbs**, **lexical expansions**, **semantic command layers**, **key actions/widgets**, **external launches**, and **remembered receipts/history** are different truths.

Relevant precedents:
- **SlopOS capshell posture** keeps launch meaning structured and resists ambient shell folklore.
- **REF-FISH-ABBR** shows that typed abbreviations can be useful precisely because they stay typed-input expansion rather than script semantics.
- **REF-NU-OVERLAYS** shows that command layers can be activated/deactivated on demand rather than living in one hidden global namespace.
- **REF-NU-CUSTOMCOMMANDS** and **REF-NU-WHICH** show that custom commands can be first-class and the shell can explain whether one name maps to a program file, alias, or custom command.
- **REF-ZSH-ZLE** shows that keybound widgets are a real action surface of their own.
- **REF-GHOSTTY-KEYTABLES** and **REF-GHOSTTY-CMDPALETTE** show that modal key tables and palette actions are useful precisely because they are explicit interaction layers.
- **REF-VSCODE-PROFILES** shows that settings, shortcuts, snippets, tasks, extensions, and MCP servers can be included independently inside one profile rather than flattened into one customization blob.

## Why the split matters

A future custom shell becomes easier to trust when it can answer six different questions honestly:
- is this command surface built into the product?
- did the line first pass through one lexical expansion?
- is the winning command definition coming from one activated overlay or custom layer?
- is the action really one key/widget/palette behavior rather than a typed command?
- is the shell launching one external executable/object rather than one built-in semantic verb?
- what only happened in the past?

Those are different debugging, trust, transcript, and UX truths.
A shell that cannot answer them regresses toward the old folklore where aliases, functions, widgets, shell language tricks, and executables all hide behind one comforting verb-shaped illusion.

## Working posture

### Built-in verbs should stay visibly built-in
If ViewFS ships product-native shell verbs, they should remain inspectable and help-addressable as built-in semantics.
That is part of what makes the shell delightful without ambient drift.

### Lexical expansion deserves its own surface
Abbreviations and snippet-like expansions are useful precisely because they happen before semantic resolution.
The shell should preview them as such instead of pretending the expanded text or resulting winner was the original truth.

### Semantic command layers should stay explicit
Overlay/module/custom-command layers are excellent ideas when they are visible.
An activated layer should not silently impersonate product baseline.
A deactivated layer should not leave spooky transcript ambiguity behind.

### Key actions should remain a separate interaction plane
Key tables, widgets, and palette-only actions are one of the best ways to make the terminal super awesome.
They should stay distinct from typed command namespace and typed transcript history.

### External launch is still a different class
An exact external executable or script launch can be capability-safe and explicit.
It still is not the same thing as one built-in shell verb or one shell-native semantic command definition.

### History should stay non-reviving
Receipts that once showed one expansion, overlay winner, key action, or external launch are useful for explanation and replay planning.
They should not silently answer what is active now.

## Classification worth standardizing early

A useful command-surface classification for protocol experiments is:
- `builtin_verb`
- `lexical_expansion`
- `custom_command`
- `overlay_command`
- `key_action`
- `external_launch`
- `resolution_ambiguous`
- `receipt_only`
- `history_only`

This is intentionally posture-oriented.
It does **not** decide one final alias model, one final overlay format, or one final palette protocol.

## Shell and terminal payoffs

A truthful shell can turn this split into product leverage:
- **verb provenance cards** that explain the winner of command resolution;
- **abbr gutters** that preview lexical expansion before execution;
- **overlay racks** that show active/inactive command layers and what they added or shadowed;
- **which ladders** that show `builtin`, `overlay`, `custom`, and `external` candidates side by side;
- **key-table lamps** that show current modal interaction posture;
- **palette/typed diff drawers** that explain whether an action is only widget/palette-local or also exposed as one typed verb.

## What not to freeze yet

Do **not** freeze yet:
- one final alias/abbreviation/snippet object model,
- one universal overlay/module schema,
- whether every key action can be promoted into one typed verb,
- whether every external launch must appear in one unified command registry,
- or a universal compatibility story across host shells and terminals.

The separation is worth freezing now.
The exact carriers are not.
