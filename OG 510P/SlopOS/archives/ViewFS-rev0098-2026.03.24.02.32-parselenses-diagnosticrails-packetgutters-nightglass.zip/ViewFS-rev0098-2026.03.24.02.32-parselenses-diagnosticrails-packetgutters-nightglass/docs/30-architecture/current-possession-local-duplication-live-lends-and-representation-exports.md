# Current possession, local duplication, live lends, and representation exports

This note sharpens one more low-regret ViewFS separation:
**holding something here now**, **duplicating it locally**, **lending a live authority-bearing thing across a courier lane**, **exporting a weaker representation**, and **remembering that any of those happened before** are different truths.

Relevant precedents:
- **REF-MACH-PORT-RIGHTS**: Mach made send, receive, and send-once rights different first-class objects.
- **REF-SEL4-GRANT**: seL4 keeps send, receive, and capability-carrying transfer explicit, with Grant/GrantReply rights and monotonic attenuation.
- **REF-UNIX-SCMRIGHTS**: descriptor couriering is equivalent to duplicating an open file description into another process table, not a name-based reopen.
- **REF-WAYLAND-DATADEVICES**: transfer starts with an offer of representations, then destination-side selection, then actual data movement.
- **REF-XDG-FILETRANSFER**: some transfers are mediated document/file exports, not raw live-authority couriering.
- **REF-KITTY-FILETRANSFER**: even terminal-native file transfer is its own explicit lane rather than just clipboard or path folklore.

## Why the split matters

A capability-native system gets hurt when a single `share` or `send` verb hides too many different realities.
Users and implementers need to know at least five different things:
- do I merely hold this now?
- can I duplicate it locally?
- can I lend a live authority-bearing thing to another actor right now?
- if not, can I still export some weaker representation?
- or do I only have a receipt of something that happened before?

Those questions matter because the security and product consequences differ sharply.
A local duplicate might preserve the same underlying open state.
A live lend might preserve current authority while crossing a trust boundary.
A representation export might mint a new object, a weaker document view, or one MIME-converted byte stream.
A receipt might be great for transcript truth and terrible as present authority.

## Working posture

### Current possession is not current shareability
Holding a live handle now should not silently imply anything about duplication or cross-actor movement.
ViewFS should be free to say `held here` while also saying `non-duplicable`, `non-lendable`, or `representation export only`.

### Local duplication is its own class
A same-process or same-host duplicate should stay a separate, inspectable class.
It may preserve the same open-state lineage or rights family.
It should not quietly turn into a cross-sandbox or cross-machine export claim.

### Live lends are narrower than generic share/export
A live lend should mean one exact courier lane can carry current authority now.
That courier lane may be local-only, same-runtime only, socket-only, or single-use.
The fact that such a lane exists does not decide durable reopen, path naming, object-store commit, or history semantics.

### Representation exports are weaker but still valuable
ViewFS should preserve room for weaker export classes that are not lies:
- MIME/data conversions,
- exact bytes snapshots,
- projected documents,
- portal-exported file-transfer payloads,
- claim tickets,
- and receipt-only rows.

That class is valuable precisely because it keeps the system from pretending an exact live lend exists when it does not.

### Receipts/history should stay honest and non-reviving
A receipt that says `live lend happened`, `bytes export happened`, or `portal export happened` is useful truth.
It is not current export posture.
It is not evidence that the actor still holds the same authority or can repeat the same route now.

## Sender-side classification worth standardizing early

A useful sender-side classification for shell UX and protocol experiments is:
- `hold_only`
- `duplicate_local`
- `duplicate_local_narrowed`
- `lend_live`
- `lend_live_narrowed`
- `export_projected`
- `export_bytes`
- `export_claim`
- `receipt_only`
- `history_only`

This is intentionally sender-side and posture-oriented.
It does **not** decide one receiver-side adoption model, one transport ABI, or one persistent storage story.

## Shell and terminal payoffs

A truthful shell can turn this split into product leverage:
- **lend ladders** instead of one `share` button;
- **lane-fit badges** so the shell can say `socket lend works`, `portal export required`, `TTY transfer possible`, or `receipt only`;
- **bytes-only fallback chips** when representation export is the strongest safe route left;
- **same-object versus new-representation drawers** for inspect-before-send UX;
- **share receipts** that say whether the receiver got a live lend, a projected doc, a byte stream, or only a receipt row.

## What not to freeze yet

Do **not** freeze yet:
- one final live-lend transport,
- one final representation-export taxonomy,
- one universal receiver-adoption story,
- one universal cross-machine or cross-user rule,
- or one terminal-native file-transfer protocol as mandatory core behavior.

The separation is worth freezing now.
The final transports and encodings are not.
