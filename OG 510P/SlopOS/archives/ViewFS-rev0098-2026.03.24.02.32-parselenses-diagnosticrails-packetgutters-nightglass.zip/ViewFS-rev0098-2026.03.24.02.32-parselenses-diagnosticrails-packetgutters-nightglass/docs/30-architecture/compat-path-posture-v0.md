# Compatibility path posture v0 (membrane, not truth)

Purpose: support legacy software without letting paths reclaim the authority model.

## Posture
1. Path APIs are allowed only as a **compatibility membrane** over explicit handles and views.
2. Relative and absolute path lookup must stay **within the bound view root**.
3. If the platform cannot guarantee no-escape semantics, the compatibility layer must **fail closed**.
4. Legacy path calls should resolve through **prebound roots / preopens / synthetic mounts**, not ambient host lookup.
5. Compatibility is **killable** and should be measurable in transcripts/logs.

## Why this cut is worth making
- REF-CAPSICUM-SEC10 shows that compatibility can coexist with capability orientation.
- REF-WASMTIME-PREOPEN is an especially good pattern: libc can translate path calls into bounded preopened capabilities.
- REF-OPENAT2 demonstrates how easy it is for naive path resolution to escape intended roots.

## Deferred topics
- symlink policy
- `..` behavior details
- host-path presentation for prompts
- hardlink / rename semantics across synthetic roots
