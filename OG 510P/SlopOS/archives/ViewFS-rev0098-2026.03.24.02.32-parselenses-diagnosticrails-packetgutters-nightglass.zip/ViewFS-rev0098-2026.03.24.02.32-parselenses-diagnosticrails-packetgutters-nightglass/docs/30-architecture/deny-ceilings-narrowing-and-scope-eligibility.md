# Deny ceilings, narrowing, and scope eligibility

Purpose: keep ViewFS from turning clever shell help into hidden authority by separating **authoritative deny ceilings**, **authoritative scope-eligibility rules**, **narrowing suggestions**, **pending escalation attempts**, and **durable adoption receipts**.

## Guardrail
Do not collapse the following into one magical “permission choice” object:
- **deny ceiling** — an authoritative veto such as “this origin may never auto-adopt at workspace scope” or “this lane can never bypass review”
- **narrowing transform** — a safer alternative such as `once`, `pane`, `session`, `read-only`, `no-export`, or `receipt only`
- **scope-eligibility rule** — whether this proposal origin and target class are even admissible at the requested scope
- **escalation attempt** — a pending request to widen or persist a change
- **adoption receipt/history** — durable evidence that something was accepted, declined, narrowed, or blocked

The names can change.
The split should stay.

## Why this seam matters now
Revision 031 made proposal origins and adoption scopes explicit.
The next risk is subtler: once the shell knows *who proposed* something and *what scope* it wants, it becomes tempting to let the shell silently widen, persist, or route around a veto “because the user accepted something similar before.”

That is the exact collapse to resist while SlopOS and ViewFS are both still in the design phase.

## Lessons we must learn from the past

### 1. Explicit deny should beat broader allow
Cedar’s security guidance is a crisp reminder: authorization is default-deny, and a single `forbid` overrides `permit`.
Deno’s permission model reinforces the same product lesson: explicit `--deny-*` flags take precedence over corresponding allow flags.

Why this matters:
- ViewFS should keep explicit deny ceilings louder than remembered convenience.
- A wider adoption suggestion should never override an owner/user/organization-level veto merely because the shell has a plausible repair path.

### 2. Not every setting or behavior belongs at every scope
VS Code’s configuration scopes show that some settings are `resource`, some are `window`, some are `machine`, and scope determines where a setting is even applicable.
That is a useful shape for ViewFS too: some proposal classes may be eligible only for `once` or `session`, while others may be admissible for `workspace` or `profile` after explicit review.

Why this matters:
- scope is not just “how long should this last?”
- scope is also “is this kind of thing even admissible here?”

### 3. Restricted mode should suppress risky workspace-defined values before trust
VS Code’s Workspace Trust extension guidance is especially good here.
An extension can declare limited support in Restricted Mode and list `restrictedConfigurations` so workspace-defined values are withheld until trust is granted.

Why this matters:
- a workspace may be visible before it is trusted to supply effective settings or automation inputs;
- ViewFS should treat some proposal sources as non-widenable until a stronger trust transition occurs.

### 4. Session-scoped autonomy is a different class from broader standing adoption
VS Code’s current agent/tool permissions docs make the distinction visible: permission levels apply to the current chat session, but specific tool approvals may be granted for a single use, the current session, the current workspace, or all future invocations.
There is also a global auto-approve setting managed at the organization level.

Why this matters:
- `once`, `session`, `workspace`, `profile`, and `org` are not just labels on one slider;
- broader scopes imply different owners, review surfaces, and veto ceilings.

### 5. Narrowing should be a first-class success, not a second-rate denial
Deno allows narrow path/domain/process grants and explicit denials within broader allow posture.
That is a better UX instinct than “allow all or fail.”

Why this matters:
- ViewFS should make `use once`, `use in this pane`, `use for this session`, `read-only`, `no-export`, and `receipt only` feel like deliberate successful outcomes.
- Narrowing transforms should not be forced to masquerade as failed broader requests.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **DenyCeiling** — an authoritative veto such as “workspace-origin proposals may not auto-adopt beyond `once`” or “receipt/history may never request `profile` scope”
- **ScopeEligibilityRule** — a rule describing which origin + target-class + scope combinations are admissible at all
- **NarrowingTransform** — a reviewed downgrade from a broader or riskier request to a narrower/risk-reduced one
- **EscalationAttempt** — a pending interaction that asks to widen scope or change who owns the policy effect
- **AdoptionReceipt** — durable history of requested scope, effective scope, narrowing, denials, and who adopted or declined

The names can change.
The split should stay.

## What not to decide yet
- the final deny-ceiling vocabulary;
- the final scope lattice or whether `pane` and `session` are separate everywhere;
- the final matrix of which origin classes may request which scopes;
- the final serialized schema for narrowing transforms or adoption receipts;
- whether deny ceilings live purely in policy, partly in schema, or partly in owner config.

## Near-term recommendation
1. start with a **closed, reviewable matrix** of origin class × target class × requested scope;
2. let explicit deny ceilings win over remembered convenience and shell advice;
3. make narrowing a first-class successful outcome;
4. treat `once` and `session` as preferred default ladders for new proposal sources;
5. classify some proposal sources as **categorically non-widenable** until stronger trust is explicitly granted;
6. prototype one killer flow: **ceiling pill + narrowing preview + scope fuse + adoption receipt**.
