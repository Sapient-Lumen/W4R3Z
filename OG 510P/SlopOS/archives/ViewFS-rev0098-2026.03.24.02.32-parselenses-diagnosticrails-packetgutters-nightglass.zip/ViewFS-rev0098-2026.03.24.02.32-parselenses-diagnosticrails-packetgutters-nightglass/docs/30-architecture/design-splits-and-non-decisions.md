# Design splits and non-decisions

Purpose: prevent ViewFS from collapsing several distinct questions into one overloaded “filesystem object” too early.

This note is intentionally conservative. SlopOS is still in design, and so is ViewFS. The safest move is to keep the big questions **separate until evidence forces a coupling**.

## The four questions we should not collapse

### 1. Object identity
Question:
- what exact object is this?

Good answers tend to look like:
- immutable digest/object ID
- manifest ID
- exact closure reference

Why keep it separate:
- content identity is stable even when names, mutable heads, or grants change.
- provenance and caching stay legible.

### 2. Namespace naming
Question:
- what names can I currently walk from this view?

Good answers tend to look like:
- explicit view bindings
- directory handles
- synthetic local roots

Why keep it separate:
- the same object may appear in multiple views with different names.
- a name is a presentation/membership fact, not the object’s ultimate identity.

### 3. Mutable current state
Question:
- if this thing is editable, what is the “current head” and how does it advance?

Good answers might look like:
- root-pointer updates
- journals / changesets
- stable mutable anchors
- stable mutable slots

Why keep it separate:
- mutation semantics are where crash consistency, merge, undo, and attribution become expensive.
- the best answer may differ by workload.

### 4. Grant persistence
Question:
- how does previously granted access survive restart, handoff, or reopen?

Good answers might look like:
- ephemeral session grants
- durable reopen receipts
- explicit document references
- revalidated stable IDs with inspectable failure

Why keep it separate:
- “I can reopen it later” is not the same as “I know exactly which bytes this is” or “I can still find it by the same path.”
- durable grants are a major security surface.

## Historical lesson
Many systems become harder to reason about when they overload one primitive with too many meanings:
- a path tries to be identity, discovery, and authority,
- a mutable file handle tries to be both content identity and current head,
- a reopen token tries to be both user intent and permanent authority.

ViewFS should resist that compression.

## ViewFS-friendly decomposition
For the first useful slice, prefer this split:
- **identity** -> immutable object / manifest reference
- **authority** -> explicit handle with rights
- **naming** -> view-local bindings and directory lookup
- **editable head** -> separate mutable-work mechanism
- **reopen / persistence** -> explicit receipt or document reference

## What this means in practice

### Paths stay secondary
A compat path may help users or legacy tools, but it should not become the only carrier of:
- identity,
- authority,
- or durable reopen semantics.

### Stable IDs need narrow semantics
If a stable mutable ID appears later, it should mean one thing well.
For example:
- “this mutable slot exists”
- not simultaneously “this path is still valid”, “this content is unchanged”, and “all prior grants still apply”.

### Receipts should say what kind of stability they provide
A receipt should be able to distinguish:
- exact immutable object reference,
- mutable workspace head reference,
- ephemeral transfer grant,
- durable reopen grant,
- and failed revalidation.

### Shell UX should expose the split
The shell/terminal should help users see:
- exact object IDs,
- current view-local names,
- mutable workspace heads,
- and grant durability state,
without pretending they are the same thing.

## Concrete anti-coupling rules
- Do not make one path string the sole source of identity.
- Do not let a durable reopen token silently imply permanent path stability.
- Do not let mutable current-state handles masquerade as immutable content IDs.
- Do not let portal receipts hide whether they are ephemeral, durable, or already revalidated.
- Do not force one universal mutable mechanism before the first few spikes run.

## Questions still intentionally open
- whether mutable current state is primarily root-pointer, journal, anchor, or slot based
- whether durable reopen uses document-handle semantics, receipt chaining, or something else
- whether path compatibility lives in libc, shell helpers, runtime shims, or all three
- whether capability bundles are launch-only, stored objects, or both


## Another question we should not collapse

### 5. Cross-boundary object workflow lane
Question:
- is this action importing bytes, opening in place, selecting a destination, moving/rehomeing, publishing a transfer offer, delegating to another handler, or only promising later materialization?

Why keep it separate:
- these lanes move different things across boundaries. Some copy bytes, some delegate access, some only publish an offer or promise.
- shell UX becomes much more honest when it can say which lane is active.
- receipts and audit trails get much easier to trust.

Good answers might look like:
- import receipts
- destination grants
- transfer offers and delivery receipts
- move outcome receipts
- promise materialization receipts

## Yet another question we should not collapse

### 6. Warm-state and offline lane
Question:
- is this action only hinting/prefetching, opportunistically caching, hydrating exact bytes, pinning retention, mirroring a corpus, or producing a self-contained offline bundle?

Why keep it separate:
- these classes make different promises about discardability, retention, offline truth, and transport.
- shell UX becomes much more honest when it can distinguish `hint-only`, `cached`, `hydrated`, `pinned`, `mirrored`, and `offline-bundled`.
- GC/cleanup and offline readiness become inspectable instead of folkloric.

Good answers might look like:
- prefetch plans
- cache entries
- hydration receipts
- pin receipts
- mirror receipts
- offline bundle receipts

## One more question we should not collapse

### 7. Grouped authority, view fragments, live binds, and launch kits
Question:
- is this object grouping authority for transport/inspection, describing a namespace fragment that could be bound, mutating a concrete view right now, constructing a child launch environment, or only recording that one of those happened?

Why keep it separate:
- creator-populated namespace systems work because child launch state is assembled explicitly rather than rediscovered ambiently.
- the same bundle may feed several different child launches or live binds.
- the same fragment may be rebound into several views over time.
- receipts/history should stay useful without becoming bearer authority.

Good answers might look like:
- capability bundle / dictionary
- view fragment / template
- view bind receipt
- launch kit / exec pack
- launch receipt



## One last question we should not collapse

### 8. Mediated designation and import state
Question:
- is this thing a request object, a chooser-owned candidate surface, the selected designation, the minted grant/ref, a concrete live bind into this pane, or only a receipt/history artifact?

Why keep it separate:
- candidate enumeration and selected outcome are different security surfaces.
- persistence should be explicit instead of leaking out of ordinary open/import flows.
- shell UX gets much more honest when it can say `pending`, `selected`, `granted`, `bound here`, `reopenable`, or `receipt only`.

Good answers might look like:
- request objects / request chips
- candidate descriptors
- selection records
- ephemeral import grants
- durable reopen refs
- bind receipts and import receipts



## And another question we should not collapse

### 9. Intent, prepared plan, approval, and result
Question:
- is this thing merely an intent, one exact prepared route/action plan, an approval checkpoint tied to that exact plan, a live committed execution, or only a result/history artifact?

Why keep it separate:
- the shell becomes much more truthful when `prepare` is not yet `commit`.
- approvals should bind exact action basis rather than floating mutable targets.
- restricted / inspect-only modes become productively legible instead of looking like generic failures.
- replay gets safer when it starts from a fresh plan instead of an old receipt pretending to be live authority.

Good answers might look like:
- intent records
- route-plan cards
- approval checkpoints
- execution records
- result receipts


## And one more question we should not collapse

### 10. Activation carriers, live handle copies, issuer badges, and object identity
Question:
- is this thing the reviewed activation/launch slot, the live handle copy currently installed in a process, a minted issuer-visible badge or witness attached to that copy, the underlying immutable object identity, or only a launch/history artifact?

Why keep it separate:
- startup delivery and steady-state naming are different truths.
- a badge on a copied handle describes the copy or its issuer lane, not necessarily the object's identity.
- shell UX can become much more honest when it can say `activation slot`, `live handle`, `issuer badge`, `object ref`, or `receipt only` instead of flattening them into one fuzzy open event.

Good answers might look like:
- launch-kit / activation-slot entries
- live handle-table entries
- issuer-visible badge / witness fields
- immutable object refs
- launch receipts

## One more question we should not collapse

### 10. Suggested automation, promoted workflows, and run history
Question:
- is this thing only a suggestion sourced from a workspace/receipt/notebook, a promoted user-owned workflow, one exact prepared run plan, a committed run, or only a receipt/history artifact?

Why keep it separate:
- a repository or shared playbook should not silently rewrite the user’s workflow vocabulary.
- source drift should become `reinspect` / `re-promote`, not silent mutation.
- replay gets safer when it starts from a fresh plan instead of treating an old successful run as current truth.

Good answers might look like:
- suggestion trays
- promotion receipts
- user-owned workflows
- prepared run plans
- run receipts


## Two more questions we should not collapse

### 11. Immutable storage, durable roots, and durable reopen
Question:
- is this thing exact immutable storage, an optional durable-root/update story, or only a durable reopen/ref story?

Why keep it separate:
- persisting bytes is easier than persisting authority.
- rollback, resurrection, and device-state mismatch show up the moment durable authority graphs get ambitious.
- a reopen descriptor should not silently count as a broad durable authority graph.

Good answers might look like:
- immutable object IDs
- optional root commits / epoch-bound root updates
- narrow durable reopen refs and receipts

### 12. View-scoped query, live feed, and global inventory
Question:
- is this thing a snapshot query inside one view, a bounded live feed, a shell-owned saved-query manifest, or a provider-global inventory surface?

Why keep it separate:
- query becomes a second authority plane the moment it turns into generic existence/count/inventory probing.
- saved-query UX is useful long before app-visible background indexing deserves to exist.
- a live feed is not the same thing as a current result snapshot.

Good answers might look like:
- snapshot-first query results
- bounded live update feeds
- shell-owned smart-folder manifests
- explicit refusal to expose ambient global inventory in Phase 1

## One more question we should not collapse

### 13. Narrow continuity, durable reopen, and persistent authority
A resumed conversation, a reconnectable endpoint, a queued follow-up, a portal request still in flight, a durable reopen ref, and a persistent authority root are not the same thing.

Why this matters:
- the product wants continuity because humans hate losing context;
- the security model wants narrowness because durable authority is where rollback, resurrection, and stale-state bugs get scary;
- shell UX gets much better when “resume this exact lane” does not silently mean “restore everything you once touched.”

Working posture:
- continuity/escrow artifacts should be typed, scoped, and expiry-friendly;
- durable reopen should remain a separate, inspectable seam even if continuity exists;
- persistent authority should remain optional and scary rather than becoming the default explanation for every convenience feature;
- queued steering/follow-up controls should stay attached to live or resumable requests rather than being confused with saved workflows or durable grants.

## One more question we should not collapse

### 14. Stable identity, current placement, currently held rights, and advertised operations
An exact object ID, the names/binds by which the object is currently reachable here, the rights currently attached to a handle, and the operations the provider is prepared to support are not the same thing.

Why this matters:
- the same object may appear in multiple directories or views at once;
- a shell that guesses verbs from path shape will lie the moment a provider has tighter rules;
- route sheets and action menus become much more trustworthy when they are driven by exact affordance truth instead of filename folklore.

Working posture:
- identity should remain stable even when placement changes;
- rights summaries should remain separate from shell convenience guesses;
- advertised operations should be explicit enough to drive chooser follow-ups, context menus, and route sheets;
- unsupported actions should downgrade or explain themselves instead of surviving as generic buttons.
- this seam is now formalized further in `docs/30-architecture/identity-placement-rights-and-affordances.md` and `rfcs/0068-viewfs-keep-object-identity-view-placement-current-handle-rights-advertised-operations-and-receipts-separate.md`.

## Recommendation
Treat “object identity”, “name in a view”, “current mutable head”, and “durable reopen authority” as four separate design axes until a specific interoperability or UX problem proves otherwise. Treat immutable storage, optional durable roots, and durable reopen descriptors as separate questions too, rather than calling all persistence “the object”. Treat warm-state and offline lanes as a separate question too, rather than smuggling them into one vague cache feature. Treat view-scoped query, bounded live feeds, shell-owned saved-query manifests, and global inventory surfaces as separate questions too, rather than calling all of them “search”. Treat mediated request state, chooser-owned candidate surfaces, selected outcomes, minted grants/refs, and live binds as separate questions too, rather than calling all of them “the opened object”. Treat intent, prepared plan, approval, committed execution, and result/history as separate questions too, rather than calling all of them “the action”. Treat suggested automation, promoted user-owned workflows, prepared run plans, committed runs, and history/receipts as separate questions too, rather than calling all of them “the saved workflow”. Treat stable identity, current placement, current rights, advertised operations, provider/catalog presence, freshness-scoped readiness, grant-needed posture, and history/receipt truth as separate questions too, rather than letting one path-shaped string or one soft presence badge decide which actions appear.

## One more question we should not collapse

### 15. Transient staging bytes, committed objects, transferred live handles, and durable reopen refs
A draft byte capsule, a sealed staging capsule, a couriered live handle, a committed object-store object, a durable reopen ref, and a history receipt are not the same thing.

Why this matters:
- preview/import/export/editor-return flows often need exact bytes before anyone should promise durable storage or durable reopen;
- explicit local transfer is safer and more truthful when it moves an exact live staging object instead of asking another process to rediscover a path;
- shell UX gets much better when `draft`, `sealed`, `commit last`, and `discard` are visible states rather than temp-file folklore.

Working posture:
- ViewFS should allow explicit transient staging artifacts without treating them as the object-store truth model;
- commit-to-object-store should remain a visibly later act than stage-for-review or courier-to-peer;
- a live transferred handle should remain distinct from any durable reopen or durable authority story;
- history/receipt surfaces should describe staged capsules honestly instead of laundering them into ordinary files.

## One more question we should not collapse

### 16. Courier peer witness, transferred live handle, structured command packet, and transcript row
A peer-credential or courier witness, a transferred live handle, a structured command packet, a durable receipt, and a plain transcript row are not the same thing.

Why this matters:
- exact local transfer gets safer and more explainable when the shell can say **who** couriered something without pretending that witness is the object's immutable identity;
- a future custom shell will want to escalate or route exact command context without copy-pasting fragile transcript text;
- replay/reopen/reroute actions become much more trustworthy when they target explicit packets or explicit live handles rather than arbitrary highlighted strings.

Working posture:
- a courier witness should describe the sender lane/peer/copy provenance, not the underlying object identity;
- a transferred live handle should remain distinct from any witness metadata and distinct from later durable receipts/history;
- a structured command packet should require explicit promotion from a strong-truth block rather than being silently inferred from selected text;
- transcript text should stay useful for humans even when no packet/handle/witness object exists.


## Another question we should not collapse

### 19. Live binds, propagation posture, peer groups, and receipts
A current bind into one explicit process view, that bind's propagation posture, any peer/master-group relationship or blast radius, and a durable receipt are not the same thing.

Why this matters:
- explicit per-process namespace design gets much safer when `attached here` does not quietly imply `local only` or `shared to peers`;
- detached fragments can already exist before attachment, so it is useful to keep `attach now` separate from `how later namespace changes flow`;
- shell UX gets much better when it can say `local only`, `shared`, `receives upstream`, `not cloneable`, or `receipt only` as different truths.

Working posture:
- ViewFS should treat live bind state and propagation posture as separate reviewed facts;
- propagation / blast-radius posture should be explicit on attach/rebind review and on later inspect surfaces;
- peer/upstream relationships should describe current propagation shape, not durable object identity;
- receipt/history surfaces should record propagation posture honestly without reviving live propagation behavior later.

## Low-regret moves we can freeze even while SlopOS is still moving
See also: `docs/90-inspirations/slopos-datacube-evaluation.md`.

These are not mechanism decisions. They are anti-confusion guardrails.

Freeze these separations now:
- immutable object identity is not the same thing as a current name in a view;
- a current name in a view is not the same thing as a mutable editable head;
- a mutable editable head is not the same thing as a durable reopen/ref story;
- immutable storage is not the same thing as optional durable-root state or durable reopen state;
- a request object is not the same thing as a chooser-owned candidate set, a selected result, a minted grant, or a live bind;
- a live handle is not the same thing as a receipt, notebook entry, history row, or pane-restore artifact;
- an observe lane is not the same thing as attach, control, exec/debug, or sideband access;
- a query snapshot is not the same thing as a live feed, saved smart-folder manifest, or global inventory surface;
- a narrow continuity / escrow artifact is not the same thing as a durable reopen ref or persistent root state;
- a transient staging capsule is not the same thing as a committed object, a couriered live handle, or a durable reopen ref;
- a courier peer witness is not the same thing as transferred authority, object identity, or a durable receipt;
- a structured command packet is not the same thing as plain transcript text or a rerun approval;
- a transient selection owner or clipboard offer is not the same thing as pasted prompt bytes, an imported object, or a durable reopen artifact;
- a live bind is not the same thing as its propagation posture, peer/upstream relationship, blast radius, or durable receipt;
- an exact object ID is not the same thing as its current placement, currently held rights, or currently advertised operations;
- browse-first workspace visibility is not the same thing as trusting workspace-defined automation.

Prefer these working postures now:
- per-process namespaces should be creator-populated instead of rediscovered from ambient globals;
- attenuation should be common and widening should require a visibly new act;
- compat/path membranes may exist during bring-up, but they should stay loud debt instead of becoming the conceptual center;
- shell/terminal affordances should preserve whether something is a ref, receipt, route sheet, live bind, propagation-scoped bind, resumable lane, staged capsule, peer-witnessed courier artifact, command packet, history-only artifact, or exact-action menu source.

Continue postponing these choices:
- whether mutable work state is best modeled as journals, root-pointer updates, stable mutable slots, ordered claims, or something else;
- whether grouped capability kits are only launch/import transport, durable stored objects, or both;
- how much durable reopen should promise beyond explicit, inspectable, failure-friendly receipts;
- exact shell protocol details beyond the minimum semantic-zone, typed-link, and receipt-truth experiments.


## Another question we should not collapse

### 11. Command packets, live process handles, lifecycle control, and deep inspection
Question:
- is this thing only a prepared command packet, one exact live running-process handle, a lifecycle-control right, a deeper inspect/debug right, or only a transcript/history artifact?

Why keep it separate:
- running-command identity is useful, but it is not the same thing as a reusable command packet or a transcript row;
- some process handles only support wait/poll/signal, while stronger ones can expose debugger attach, namespace-follow, or descriptor duplication power;
- shell UX becomes much more honest when it can say `running now`, `waitable`, `stoppable`, `deep inspect available`, or `history only` instead of one vague process row.

Good answers might look like:
- command packets
- live process descriptors / supervisor-local process refs
- lifecycle-control handles
- deep-inspection / debugger handles
- exit receipts and history rows


### 10. Detached namespace fragment, pre-attach posture, and live bind
Question:
- is this thing an unattached fragment that could be bound somewhere later, a prepared pre-attach posture for that fragment, one concrete live bind into this process view, or only a receipt/history artifact?

Why keep it separate:
- a prepared fragment can be a useful object long before it is visible at any current path.
- the same fragment may be attached into different process views over time, or never attached at all.
- shell UX becomes much more honest when it can say `prepared`, `attached here`, `detached again`, or `receipt only` instead of pretending a fragment was always just “that directory.”

Good answers might look like:
- detached view-fragment descriptors
- pre-attach posture descriptors
- attach/bind plans
- live bind handles
- attach receipts

## Another question we should not collapse

### 12. Exact exec object, launch basis, startup credentials, and launch receipt
Question:
- is this thing the exact executable object, the explicit interpreter/script-entry arrangement, the argv/env/cwd launch basis, the activation-time credential set, or only a launch/history artifact?

Why keep it separate:
- execution by held handle or exact staged bytes is not the same thing as reopening whatever mutable name happens to point somewhere now;
- script/interpreter entry is a separate seam from executable-object identity;
- startup credentials are not morally the same thing as environment variables, ordinary view binds, or later durable authority;
- shell UX becomes much more honest when it can say `exec object`, `script input`, `argv/env basis`, `credential slot`, `launched`, or `history only` instead of one vague command row.

Good answers might look like:
- executable-object handles / exact-byte staged exec objects
- explicit interpreter-plus-script-entry descriptors
- argv/env/cwd launch-basis records
- activation-time credential slot descriptors
- launch receipts and history rows


## Yet another launch question we should not collapse

### 8. Exact exec object, startup code closure, loader policy, and late imports
Question:
- did we bind one exact executable object, preserve one exact startup code closure, run under one explicit loader/resolver posture, or merely allow later dynamic imports/plugins under some broader runtime lane?

Why keep it separate:
- exact exec-object identity is not the same thing as exact startup shared-library / interpreter closure.
- loader search policy is an ambient-risk surface in its own right and should not hide inside launch folklore.
- plugin/module loading after startup is a materially different lane from the initial reviewed launch.
- shell UX becomes much more honest when it can say `exec exact`, `startup closure exact`, `loader debt`, or `late import requested`.

Good answers might look like:
- exact exec-object handles
- startup-closure manifests
- loader-policy receipts
- explicit late-import / plugin receipts


## Yet another transfer question we should not collapse

### 9. Selection owner/source, offered representation, pasted input, and imported object
Question:
- is this thing only the current owner/source of a clipboard or selection offer, the representations that offer advertised, one accepted transfer/result payload, prompt input that happened to arrive by paste, a later imported/materialized object, or only a durable receipt/history artifact?

Why keep it separate:
- selection ownership is usually transient and replaceable; it is not the same thing as a stored object identity.
- offered MIME/type sets are not the same thing as the one representation the receiver actually accepted.
- prompt-local pasted bytes can be useful and even review-worthy without automatically becoming imported objects or live binds.
- clipboard history/manager behavior is a privileged optional helper lane, not a baseline truth of every pane.

Good answers might look like:
- selection-owner / offer-source descriptors
- offered-representation descriptors
- accepted-transfer / received-payload descriptors
- prompt input capsules
- explicit import/materialization/bind receipts
- durable history rows


## Yet another live-session question we should not collapse

### 13. Live process handle, terminal stream lane, controlling TTY, and foreground turn
Question:
- is this thing the running command/session object, one stdio or PTY stream lane, a controlling-terminal relationship, the current foreground-turn / interrupt-target state, or only a durable receipt/history artifact?

Why keep it separate:
- a running process can exist without any current controlling terminal at all;
- mirrored output or a PTY byte stream is not the same thing as owning terminal-generated signals or interactive input;
- foreground ownership is revocable current posture, not durable identity;
- shell UX becomes much more honest when it can say `running`, `stdout mirrored`, `stdin live`, `controlling tty`, `foreground now`, `backgrounded`, or `history only` instead of one vague attached bit.

Good answers might look like:
- live process descriptors / supervisor-local process refs
- stream-lane descriptors
- PTY / controlling-terminal posture descriptors
- foreground-turn / signal-target metadata
- attach/detach/stop receipts and history rows


## Yet another launch/session question we should not collapse

### 14. Exact exec object, runner/runtime, bootstrap posture, and live session
Question:
- is this thing the exact executable/script-input object, the runner/runtime family that gets to host it, the startup/bootstrap posture around it, the resulting live session, or only a durable receipt/history artifact?

Why keep it separate:
- one exact executable object does not by itself answer which runner/runtime will interpret or host it;
- a runner/runtime choice can carry its own lifecycle controller and sandbox envelope without changing object identity;
- startup/bootstrap posture (clean start, explicit customization bundle, or compat/startup-hook debt) is another lane again;
- shell UX becomes much more honest when it can say `exec exact`, `runner=native`, `runner=wasi`, `bootstrap clean`, `interactive live`, or `history only` instead of one vague run row.

Good answers might look like:
- exact exec-object handles / staged-byte objects
- explicit runner/runtime descriptors
- bootstrap/startup-profile posture descriptors
- live session handles/cards
- launch/lifecycle receipts and history rows


### 14b. Built-in shell baseline, reviewed customization bundle, startup file, and project hook
Question:
- is this thing the shipped built-in shell baseline, one explicit reviewed customization bundle, one ambient host/user startup file, one project-local activation hook, or only a durable receipt/history artifact?

Why keep it separate:
- delightful shell affordances do not require ambient rc/profile execution to explain themselves;
- one reviewed customization bundle is smaller, more inspectable, and more portable than arbitrary host startup files;
- project-local activation hooks are stronger than browsing and stronger than general shell personalization;
- shell UX gets much more honest when it can say `built-in only`, `bundle active`, `profile active`, `project hook pending`, or `history only` instead of one vague personalized startup row.

Good answers might look like:
- built-in shell-feature descriptors
- explicit customization-bundle objects
- startup-profile / startup-file posture descriptors
- project-hook review / approval / denial objects
- durable startup/history receipts


### 15. Handle slot, live handle copy, shared open state, and independent reopen
Question:
- is this thing only a current slot/local binding, another live handle copy to the same current open state, the shared mutable open-state group itself (cursor/status/lock/lease), a fresh independent reopen to the same object, or only a durable receipt/history artifact?

Why keep it separate:
- exact child-table population does not by itself say whether two current slots alias one mutable cursor/state or hold independent reopens;
- old UNIX semantics already show that duplication and cross-process passing often preserve one shared open file description with shared offset/status/lock state;
- a fresh reopen can point at the same object while intentionally *not* sharing the same live cursor/append/lease posture;
- shell UX becomes much more honest when it can say `slot=7`, `same live cursor as slot=4`, `fresh reopen`, or `history only` instead of one vague handle row.

Good answers might look like:
- current slot/binding descriptors
- explicit live-alias / duplicate-handle descriptors
- local shared-open-state witness/group metadata
- explicit independent reopen acts/receipts
- durable history rows describing past sharing or reopening decisions

## Another question we should not collapse

### 16. Locator/metadata handles, live byte-I/O handles, and durable refs
Question:
- is this thing only a current locator/metadata handle, a live read/write/append-capable handle, an explicit reopen/escalation act, or only a durable ref/history artifact?

Why keep it separate:
- a per-process namespace can be assembled around roots and object designations that do **not** automatically imply byte-I/O.
- inspect-first portal flows get much more honest when `selected` or `bound root` does not silently mean `readable now`.
- shell UX gets much more truthful when it can say `locate`, `metadata`, `read`, `write`, `needs reopen`, or `receipt only` as different states.

Good answers might look like:
- locator/root handles
- metadata-only inspection handles
- live read or write handles
- explicit `open for read` / `reopen for write` actions
- durable refs and receipts

## Another question we should not collapse

### 17. Current handle possession, launch inheritance posture, and exact child slot delivery
Question:
- is this thing only a live handle currently held in one pane/process, a policy posture about whether it may cross a launch boundary, the exact child-local slot/name that will receive a reviewed copy, or only a durable launch receipt/history artifact?

Why keep it separate:
- current possession of a live handle does not by itself mean any child should inherit it;
- classic `exec` semantics show that inheritance across launch is its own lane, and host defaults have historically been easy to get wrong;
- even when a handle is intentionally passed across launch, the exact child-local slot/name it lands in is another truth again;
- shell UX gets much more honest when it can say `held here`, `launch-shuttered`, `selected for child`, `child slot fd=7`, or `receipt only` instead of one vague passed-to-child story.

Good answers might look like:
- current-handle possession descriptors
- launch-boundary inheritance shutters / eligibility metadata
- explicit child-slot maps inside reviewed launch kits
- exact launch receipts naming what crossed the boundary
- durable history rows that describe but do not revive inherited handles

## Another question we should not collapse

### 18. Object identity, parent anchors, namespace mutations, and receipts
Question:
- is this thing the object itself, the source parent anchor, the destination parent anchor, the reviewed namespace mutation, or only a durable mutation receipt/history artifact?

Why keep it separate:
- holding an object or byte handle does not by itself answer whether the caller may remove one current name or create another;
- rename/link/unlink and replace/exchange operations act on namespace anchors and collision posture, not only on object bytes;
- multi-path operations are a classic source of accidental collapse because one nice `move` story hides at least two parent authorities and one mutation mode;
- shell UX gets much more honest when it can say `source parent missing`, `destination parent missing`, `rename only`, `replace target`, `exchange`, or `receipt only` instead of one vague move action.

Good answers might look like:
- object identity refs
- source-parent anchors
- destination-parent anchors
- explicit namespace-mutation plans (`rename`, `link`, `unlink`, `replace`, `exchange`)
- durable mutation receipts/history


## Yet another question we should not collapse

### 10. Unnamed objects, namespace publication, and later receipts
Question:
- is this thing an unpublished object/draft payload, a candidate publication anchor, one reviewed publication act, a currently visible bound name, or only a durable receipt/history artifact?

Why keep it separate:
- an object can be fully formed before it has a public name.
- publication can deserve its own review, collision posture, and parent-anchor selection.
- history should remember publication without becoming bearer authority.
- shell UX gets much more honest when it can say `draft object`, `publish here`, `published name`, or `receipt only`.

Good answers might look like:
- draft object handles
- publish sheets / parent-anchor cards
- publication receipts
- visible namespace binds
- durable history rows


## Another seam we should not collapse

### 11. Content descriptors, live handles, and receipts
Question:
- is this thing only a descriptor for exact content/object identity, a set of non-authoritative hints about that content, one current live handle/bind carrying authority, or only a durable receipt/history artifact?

Why keep it separate:
- a digest/object descriptor can stay useful even when no current live authority exists.
- locator hints, media type, and byte size are great shell/portal metadata, but they should not silently become bearer authority.
- portal/import UX gets much more honest when it can say `descriptor only`, `bind here`, `hydrate`, `publish`, or `receipt only` as different states.
- keeping descriptors separate preserves freedom about fetch, hydration, storage, and publication mechanisms while SlopOS is still moving.

Good answers might look like:
- immutable content descriptors
- descriptor sidecars / hint records
- live handles or live binds
- hydration receipts
- publication receipts
- transfer/import receipts


## Another seam we should not collapse

### 12. Imported source refs, materialized local objects, local docrefs, and receipts
Question:
- is this thing only an imported source ref/offer, one explicit materialization act, one fresh local object with local identity, one local durable docref/reopen designator, one current live handle/bind, or only a durable receipt/history artifact?

Why keep it separate:
- an imported source ref can be useful before any local bytes or local object exist.
- materialization is a reviewable act with copy/fetch/locality consequences of its own.
- a fresh local object is not the same thing as a durable docref for later reopen, and neither is the same thing as a live handle right now.
- shell UX gets much more honest when it can say `source ref only`, `materializing`, `fresh local object`, `local docref`, `live handle now`, or `receipt only` instead of one vague imported file story.

Good answers might look like:
- source-ref cards / import offers
- explicit materialization plans
- local object descriptors
- local docrefs / durable reopen designators
- live handles or live binds
- import/materialization/publication receipts/history


## Another seam we should not collapse

### 13. Remembered designators, continuity lockers, revived live handles, and receipts
Question:
- is this thing only a remembered designator for later reopen, one explicit revalidation/resolution act, one narrow exact-handle continuity locker, one revived live handle/bind carrying authority now, or only a durable receipt/history artifact?

Why keep it separate:
- remembered designation is useful even when no current live handle exists.
- system-level continuity lockers can preserve one exact live handle across restart without becoming a universal durable-authority substrate.
- stale / moved / revoked outcomes are valuable truths, not generic failures to be papered over.
- shell UX gets much more honest when it can say `remembered`, `needs revalidate`, `locker available`, `live again`, `stale`, or `receipt only`.

Good answers might look like:
- remembered docrefs / bookmark-like designators
- explicit resolve / revalidate acts
- manager-held exact continuity lockers
- revived live handles or binds
- stale-target / grant-needed outcomes
- durable continuity receipts/history

## Another seam we should not collapse

### 14. Transfer offers, live handle copies, revival designators, adopted binds, and receipts
Question:
- is this thing only a transfer/courier offer, one accepted representation choice, one live copied handle carrying authority now, one stored revival designator for later reconnect/reopen, one adopted local bind/slot in this pane/process, or only a durable receipt/history artifact?

Why keep it separate:
- an offer can be useful before the receiver has accepted anything.
- a live handle copy is not the same thing as a durable revival designator, and neither is the same thing as a receiver-local adopted bind.
- issuer/courier witness is useful truth but should not redefine object identity or current authority.
- shell UX gets much more honest when it can say `offer only`, `accepted as bytes`, `live alias`, `attenuated copy`, `stored for later`, `adopted here`, or `receipt only` instead of one vague shared/opened story.

Good answers might look like:
- transfer offers / courier events
- explicit representation-choice sheets
- live copied or attenuated handles
- revival designators / later reconnect records
- local adopted binds or slots
- transfer/adoption receipts/history

## Another question we should not collapse

### 20. Non-authoritative designators, authority-bearing tickets, local aliases, live handles, and receipts
A title, digest card, search hit, route target, recent-item row, or note-friendly designator is not the same thing as a bearer-ish reopen/recontact ticket; neither is the same thing as one current local alias in a pane, one live handle held now, or a durable receipt/history row.

Why this matters:
- once a user-copyable token mixes designation and authority, ordinary shell actions like paste, note-taking, sharing, and route selection start becoming covert delegation events;
- desktop history shows that persistent reopen artifacts can become security-critical once they can recover access after restart;
- shell UX gets much better when `designation only` and `authority-bearing ticket` are visibly different classes.

Working posture:
- ordinary designators should be cheap to inspect, search, sort, and share without reviving authority;
- authority-bearing tickets should be explicitly typed, visibly dangerous, and policy-killable;
- local aliases/binds should describe current placement inside one current view, not durable reopen power;
- receipts/history should describe which class was involved without becoming bearer authority by mere inspection.


## Another question we should not collapse

### 21. Caveat sets, membrane leases, live handles, and receipts
Question:
- is this thing only one declared set of caveats/attenuation terms, one current membrane or lease proxy that actually enforces them, one live delegated handle usable now, one revival designator for later revalidation, or only a durable receipt/history artifact?

Why keep it separate:
- a caveat list can be descriptive and still fail to say where enforcement really lives.
- a live membrane/proxy is not the same thing as one local handle copied into the receiver, and neither is the same thing as a later revival designator.
- past desktop and distributed-capability history both show that bearer-ish delegated artifacts become dangerous when the UI cannot distinguish declared bounds from enforced bounds.
- shell UX gets much more honest when it can say `caveat declared`, `proxy enforced`, `live handle now`, `revalidate later`, or `receipt only` instead of one vague delegated/opened story.

Working posture:
- keep declared caveat terms inspectable and monotonic;
- keep enforcement locus visible (`proxy`, `verifier`, `local handle`, or `none/currently stale`);
- keep renewal/revalidation explicit rather than implied by continued possession of a past descriptor;
- keep receipts/history descriptive, not authority-bearing.

Good answers might look like:
- caveat/constraint descriptors
- local membrane or lease-proxy objects
- live attenuated handles
- revival/revalidation designators
- durable delegation / renewal / revocation receipts

## Another question we should not collapse

### 22. Permission outlooks, revival designators, live handles, death-state verdicts, and receipts
Question:
- is this thing only one preflight permission/liveness outlook, one stored revival designator for later request/revalidate, one live handle/bind usable now, one explicit death-state verdict about why authority is gone, or only a durable receipt/history artifact?

Why keep it separate:
- `granted`, `prompt`, `denied`, `grantable_here`, or `revalidate_needed` are useful predictive truths, but they are still not live authority.
- a revival designator is useful even when no current live handle exists.
- explicit death-state verdicts like `revoked`, `expired`, `target changed`, `issuer unavailable`, or `policy denied` are much more repairable than one vague `stale` bucket.
- shell UX gets much more honest when it can say `permission looks good`, `designator only`, `live now`, `dead for this reason`, or `receipt only`.

Working posture:
- permission outlook should remain advisory/preflight, not authority.
- live handles should remain the current-authority truth.
- death-state verdicts should preserve reason class, not collapse into generic failure folklore.
- receipts/history should preserve what happened without reviving authority by inspection.

Good answers might look like:
- permission-state descriptors
- revival/recontact designators
- live local handles or binds
- revocation/expiry/deletion/change tombstones
- request/revalidation/repair receipts/history

## Another question we should not collapse

### 23. Provenance attestations, endorsement bundles, local admission verdicts, live handles, and receipts
Question:
- is this thing one provenance/production/import/review claim, one endorsement or trust-root input, one local admit/deny verdict, one live handle/bind usable now, or only a durable receipt/history artifact?

Why keep it separate:
- a structured or signed claim about where bytes came from is still not one local decision that the object may run here.
- endorsement bundles, threshold signatures, trust delegations, transparency-log witnesses, and reference values are appraisal inputs, not universal truth.
- a local verdict like `preview only`, `safe-open only`, `admit runnable`, or `deny` is still not proof that the pane already holds a live handle.
- shell UX gets much more honest when it can say `well-described`, `well-endorsed`, `admitted here`, `live now`, or `receipt only` instead of one vague trusted/opened story.

Working posture:
- provenance claims should remain inspectable even when admission is undecided or negative.
- endorsement bundles and trust-root choices should remain visible without outrunning local policy.
- local admission should remain explainable and revocable without pretending it is current handle possession.
- receipts/history should preserve how one verdict was reached without reviving standing approval by inspection.

Good answers might look like:
- provenance / attestation envelopes
- endorsement / threshold / trust-root bundles
- local admit / deny / safe-open verdict cards
- live local handles or binds
- audit / admit / deny receipts/history

## And one more question we should not collapse

### 11. Request rows, session/transfer objects, portal-owned live state, and local adopted binds
Question:
- is this thing one interaction request, one longer-lived session or transfer object, the portal's current view of that object's state, one local adopted bind/live handle, or only history?

Why keep it separate:
- portal-heavy systems routinely create one short-lived request seam and one longer-lived session seam.
- the portal may know that a session is `open`, `ending`, `closed`, `allowed`, or `bound` without that being proof that this pane still has one live adopted bind.
- shell UX gets much more honest when it can say `request only`, `session active`, `portal says closed`, `adopted here`, or `receipt only` instead of flattening them into one fuzzy open row.

Good answers might look like:
- request chips / request IDs
- session handles / transfer keys
- portal-state rows or monitors
- local adopted binds / live handles
- request/session receipts

## Another question we should not collapse

### 22. Completion candidates, accepted insertions, compiled command packets, prepared actions, and receipts
Question:
- is this thing only one completion candidate or ghost suggestion, one focused-candidate detail drawer, one accepted insertion in the mutable prompt buffer, one compiled command packet for this pane, one prepared action/route plan, or only one durable receipt/history artifact?

Why keep it separate:
- ranked suggestions and lazy detail are useful even when nothing has been accepted yet.
- accepted prompt text is still editable user state, not one current action plan.
- one compiled packet is stronger than text because it binds against current pane state, but it still is not the same thing as approval or launch.
- heuristically observed command text should stay visibly weaker than shell-reported or nonce-verified packets.
- shell UX gets much more honest when it can say `candidate only`, `detail loaded`, `inserted`, `compiled`, `approval needed`, `ready`, or `receipt only`.

Good answers might look like:
- completion/ghost rows
- focus-triggered detail drawers
- accepted word/fragment/full-line insertions
- compiled command packets with trust grade
- prepared route plans / action packets
- insertion/compile/run receipts/history

## Another question we should not collapse

### 24. Selected regions, extracted entity candidates, route envelopes, prepared actions, and receipts
Question:
- is this thing only one selected transcript/screen region, one extracted entity candidate, one lazily resolved target/detail set, one typed route envelope, one prepared action, or only one durable receipt/history artifact?

Why keep it separate:
- selected bytes or cells are still only a surface, not final semantics.
- one extracted entity candidate may still be heuristic or partial and may not survive focus/resolve checks.
- one resolved target/detail set is stronger than a candidate, but still not one route choice or approval.
- a typed route envelope is stronger than a hyperlink or selection, but it still is not one approved side effect.
- shell UX gets much more honest when it can say `selected`, `candidate`, `resolved`, `route slip`, `approval needed`, `ready`, or `receipt only`.

Good answers might look like:
- selected-region descriptors
- extracted entity candidates with confidence/source
- lazy-resolve target/detail drawers
- typed plumb/route envelopes
- prepared route cards / action packets
- selection/route receipts/history

## Another question we should not collapse

### 25. Gesture evidence, activation tokens, armed state, active control, and receipts
Question:
- is this thing only one fresh user-action witness, one transferable activation baton/token, one armed-or-enabled interaction lane, one current active-control / foreground state, or only one durable receipt/history artifact?

Why keep it separate:
- a recent click, keypress, shortcut, or notification action is still not one durable capability.
- a transferable activation token may let another component ask for activation, but it still is not one live handle or one guaranteed foreground turn.
- `armed` or `enabled` is stronger than `idle`, but weaker than `active now`.
- a current foreground/control turn is usually narrow and ephemeral; it should not masquerade as durable reopen or standing authority.
- shell UX gets much more honest when it can say `fresh gesture`, `activation baton`, `armed`, `active now`, or `receipt only` instead of one fuzzy interacted/opened story.

Good answers might look like:
- user-action serials or transient-activation witnesses
- transferable activation / focus-request tokens
- enabled capture or prepared chooser/session state
- active control / current foreground turn markers
- gesture / activation / control receipts/history


## New anti-collapse pressure from Revision 076
Another very low-regret seam to freeze while ViewFS and SlopOS are still fluid is **declared type / derived type / handler association / chosen opener / live open state / receipt**.

Why this matters:
- a claimed MIME/UTType or extension hint is not the same thing as a local derived classification;
- a type classification is not the same thing as a list of associated handlers;
- an associated/default handler is not the same thing as the opener actually chosen for one act;
- one chosen opener is not the same thing as one current live preview/editor session;
- and none of those are the same thing as history.

What to postpone:
- one universal type taxonomy,
- one universal handler registry ABI,
- one final priority rule between declared and derived type,
- and one final owner for opener choice across shell, portal, helper, and provider.

Freeze the separation first.


## New anti-collapse pressure from Revision 077
Another very low-regret seam to freeze while ViewFS and SlopOS are still fluid is **advisory annotation / selector label / policy-bearing label / trusted badge / receipt**.

Why this matters:
- a freeform or imported note is not the same thing as a compact grouping key that queries may rely on;
- a selector-safe grouping key is not the same thing as a policy-bearing label that affects handling or export posture;
- a policy-bearing label is not the same thing as shell-owned trusted chrome;
- a trusted badge is not the same thing as canonical object metadata;
- and none of those are the same thing as history.

What to postpone:
- one universal label taxonomy,
- whether selector labels live on objects, placements, or side indexes,
- whether policy-bearing labels are local-only or provider-visible,
- and one universal terminal/shell badge protocol.

Freeze the separation first.


## Revision 078: continuation cursors, sync watermarks, live subscriptions, rebuilt snapshots, and gap verdicts

Another especially useful seam is **resume token versus current truth**.
Kubernetes, Dropbox, Watchman, and FSEvents all point the same way:
- a continuation cursor or clockspec can help resume incremental work,
- a watermark can say what point the client has definitely processed through,
- a live watch/longpoll can wait for more changes,
- a rebuilt snapshot can re-establish current visible truth,
- and a reset/overflow/root-change verdict can tell the user why continuity broke.

Those should stay visibly distinct in ViewFS.
That gives us room to make smart folders, watch panes, and portal-backed result feeds feel excellent without deciding one universal cursor ABI or pretending provider tokens are durable object refs.

Do not decide yet:
- one universal cross-provider cursor/watermark schema;
- one final gap/reset taxonomy;
- whether rebuilt snapshots are stored objects, shell caches, or provider-owned cuts;
- whether live subscriptions are shell-owned, provider-owned, or terminal-owned for every backend.

## Revision 079: observed validators, writable sessions, write holds, commit preconditions, and committed versions

Another especially useful seam is **observed base versus durable winner**.
HTTP conditional requests, Cloud Storage preconditions, etcd compare-and-swap, WebDAV locking, and browser writable-session APIs all point the same way:
- the exact basis you observed is not the same thing as one local writable session,
- one writable session is not the same thing as one live hold or lock token,
- one hold is not the same thing as the exact commit precondition,
- and the committed version that actually won is not the same thing as draft-local close/flush folklore.

Those should stay visibly distinct in ViewFS.
That gives us room to make editing, import repair, external-editor round-trips, and shell commit UX feel excellent without deciding one final transaction or locking model too early.

Do not decide yet:
- one universal validator field across all providers and object families;
- whether ViewFS normalizes on digest, generation, epoch, mod-revision, or several of them;
- whether write holds are mandatory anywhere in Phase 1;
- whether writable sessions are shell-owned, provider-owned, or runtime-owned for every backend.

## Revision 080: partial residency, chunk layouts, and whole-object proofs

Another especially useful seam is **partial local residency versus whole-object truth**.
HTTP range transfers, HTTP incomplete-response caching, lazy-pulled OCI layers, multipart object checksums, and chunked array stores all point the same way:
- some local bytes are not the same thing as full local completeness,
- chunk/shard layout metadata is not the same thing as current local coverage,
- a live lazy-fill path is not the same thing as offline readiness,
- and composite/per-part identifiers are not the same thing as one whole-object proof.

Those should stay visibly distinct in ViewFS.
That gives us room to make sparse/lazy imports, previews, and large-object workflows feel excellent without deciding one final sparse-store schema or one final whole-proof policy too early.

Do not decide yet:
- one universal sparse coverage representation across all object families;
- whether ViewFS normalizes on byte ranges, chunks, shards, file extents, or provider-specific hybrids;
- whether full proof is mandatory for every publish/launch/export act;
- whether live range fill is shell-owned, portal-owned, helper-owned, or provider-owned for every backend.


### 26. Delta recipes, exact bases, apply sessions, reconstructed objects, and receipts
A delta or patch artifact is not the same thing as the target object it can help reconstruct.
An exact basis requirement is not proof that the basis is local or still exact now.
A current reconstruction/apply session is not the same thing as a durable committed object.
A reconstructed target is not the same thing as live-handle continuity or same-path continuity.
A fallback full fetch is its own lane.
And a receipt is only history.

This split matters because HTTP delta/range work, VCDIFF, OSTree static deltas, and zsync/rsync-style reuse all point to the same lesson: transport/update efficiency should not collapse into identity, continuity, or current authority truth.

Consequences:
- ViewFS should keep delta artifacts, exact basis witnesses, current apply state, reconstructed target objects, and fallback full-fetch decisions visibly distinct.
- The shell should be able to show `needs base X`, `base missing`, `apply in scratch`, `full fetch fallback`, and `rebuilt from X + R` as different truths.
- Receipts/history should explain when delta reconstruction happened before without silently reviving present reconstructability.

Non-decisions:
- one universal delta format,
- one universal basis vocabulary,
- one final owner for apply sessions,
- whether delta artifacts are provider-local only or portable first-class objects.

## Revision 082: activation carriers, copy lineage, and object truth

Another especially useful seam is **activation carrier versus current live handle copy versus issuer-visible badge/witness versus object identity**.
Plan 9 namespaces, Fuchsia capability-routed namespaces, systemd socket activation/fd-store practice, UNIX descriptor passing, and seL4 badge discipline all point the same way:
- the way authority arrives at startup or handoff time is not the same thing as the current live copy;
- the current live copy is not the same thing as immutable object identity;
- issuer/courier witness is not the same thing as trust verdict;
- a receiver-local bind is not the same thing as the launch slot that delivered it;
- and any later reopen/revival lane is not the same thing as the current open copy.

Those should stay visibly distinct in ViewFS.
That gives us room to make object-store/import/handoff flows excellent without deciding one final durable-handle substrate too early.

Do not decide yet:
- one universal startup-slot primitive across all runtimes and platforms;
- one universal durable continuity/revival mechanism;
- whether restart continuity is shell-owned, supervisor-owned, portal-owned, or split;
- whether every arriving live handle can reveal one exact immutable object ref;
- one final portal/import/courier taxonomy beyond the requirement that all lanes tell the same split truths.



### 27. Store membership, synthetic views, live handles, published names, and receipts
- is this thing merely a local object-store fact, one restricted synthetic portal/provider view, one current live handle, one current publication site in this process view, or only one durable receipt/history artifact?
- a current published name is not the same thing as local object-store existence, and neither is the same thing as current live authority.
- a restricted synthetic view should stay visibly different from native local publication here.
- portal request/session state is not proof that this pane still has one live handle or one current bind.
- path-like labels should therefore describe one current publication site, not object essence.

What to avoid collapsing:
- local object-store membership or descriptor truth
- mediated synthetic views / portal projections
- live current handles
- local published names / binds
- durable receipts and remembered designators

What not to decide yet:
- whether early synthetic views are shell-owned, service-owned, or lower-level runtime objects;
- whether publication is always single-slot in Phase 1 or later admits overlays/search lists;
- whether the main durable reopen story is local-only, mediator-held, provider-held, or mostly deferred.

## Explicit-handle opens, rooted compat pathwalks, and ambient escapes are different questions

One more low-regret split is worth pinning while SlopOS is still in design:
- `I already hold a live handle and opened through it`;
- `I walked a path inside an already-held root/view/designator`;
- `a portal/powerbox/mediator minted or projected access for me`;
- `I used an ambient host escape hatch`;
- and `I only have a receipt/history row`.

Those are not interchangeable truths.
A rooted compat pathwalk may be a perfectly pragmatic bring-up move, but it should still remain narrower and louder than either direct-handle authority or portal-mediated grants.
An ambient host escape should remain louder still.

Low-regret commitments now:
- prefer explicit handle opens whenever they are available;
- keep rooted compat walkers rooted in already-held authority and explicit no-escape policy;
- keep portal mediation transcript-visible instead of laundering it into a fake native path;
- make ambient escape hatches searchable debt instead of silent convenience;
- and keep published-name/locality truth separate from all of the above.

What not to freeze yet:
- the final rooted-walker API surface;
- the final portal/import wire protocol;
- whether early ambient escapes are blocked, policy-gated, or developer-mode only;
- whether compat walkers belong in libc, shell helpers, runtime glue, or service helpers.


## Discoverability, enumeration, exact-name opens, and fit notes are different questions
Do not freeze one flattened answer to `can the actor see it?` yet.
Important splits:
- direct current authority versus exact-name reachability inside a held root/view;
- exact-name reachability versus full enumeration/listability of a container;
- browse/list truth versus search/index/provider suggestion truth;
- match quality / fit explanation versus current openability;
- and durable receipts/history versus any of the above.

Low-regret posture now:
- allow narrower exact-name opens without assuming list rights;
- treat enumeration as a separately reviewable metadata-disclosure surface;
- keep suggestions and completion-like candidates advisory;
- receipt what truth actually held;
- and keep published-name/locality truth separate from all of the above.

## Another question we should not collapse

### 17. Presence adverts, readiness, grant-needed posture, and current authority
A provider advert, a freshness-scoped readiness claim, a `grant needed` next step, an already-held live handle, and a durable receipt are not the same thing.

Why this matters:
- discovery/presence UI is useful long before current authority exists;
- a stale ready bit can lie just as badly as a stale path string;
- shell UX gets much better when `shown`, `ready`, `grantable`, `held`, and `history only` are different truths.

Working posture:
- provider/catalog presence should stay visibly weaker than current live authority;
- readiness should stay freshness-scoped and decay-aware rather than turning into a timeless badge;
- `grant needed` should be a first-class shell truth instead of a generic failure later;
- receipts/history should remember adverts and ready states without claiming they still hold now.


## Another question we should not collapse

### 10. Provider-ready, reacquire-needed, and local-realized truth
Question:
- is this thing merely advertised, satisfiable from a provider/substituter/promisor source, still waiting on one repair/rebind/reauth step, already realized locally, actively held now, or only remembered in history?

Why keep it separate:
- provider-ready is a useful promise, but it is still not local residence.
- restored or remembered work often needs one more explicit repair step before stronger claims become true.
- offline UX becomes far more honest when `reacquirable later` does not masquerade as `local now`.
- shell actions such as `make local`, `bind here`, and `hand to child` become much easier to explain.

Good answers might look like:
- provider-ready claims
- reacquire / repair obligations
- local-realization receipts
- current live handles
- locality / bind receipts
- history-only rows

## Claim tickets versus holder-bound grants versus passable live handles

Another easy overdecision would be to pick one universal `ticket` story too early.
That would blur together at least four different classes:
- a redeemable claim that might mint stronger authority later,
- a holder-bound grant that works only for the current proving holder/session/key,
- a passable live handle that can actually be copied or inherited now,
- and a spent/expired artifact that only records anti-replay or historical truth.

ViewFS should freeze the separation, but not the mechanism.
We do **not** need to decide yet whether holder proof is key-based, issuer-badged, session-local, or something smaller; whether claim tickets live in the object store or only in a mediator; or whether spent tickets compact into thinner receipts later.
We only need the shell and repo vocabulary to stop lying by treating all of those as one thing.


## Possession versus current invocability

Another easy overdecision would be to pick one universal `authorized now` story too early.
That would blur together at least six different classes:
- something is local or held now,
- its prior authentication event is fresh enough,
- it satisfies the stronger assurance class this action wants,
- immediate local presence or user verification has been satisfied,
- the action is invokable here now,
- and the transcript keeps some historical trace of that satisfaction.

ViewFS should freeze the separation, but not the mechanism.
We do **not** need to decide yet whether freshness and step-up are provider-local only, shell-mediated, authagent-mediated, or split; whether one satisfied challenge opens a short reusable window; or whether local presence uses badges, leases, drawers, or one-shot proof receipts.
We only need the shell and repo vocabulary to stop lying by treating current possession as if it always meant current invocability.


## Standing-watch good status versus live possession

Another easy overdecision would be to pick one universal `still valid` story too early.
That would blur together at least six different classes:
- something is still held or local now,
- one later status carrier says something about it,
- the local receiver stance decides how much to believe or act on that signal,
- a reversible hold or quarantine may now be active,
- a refresh or successor may be available or required,
- and the transcript keeps some historical trace of all of this.

ViewFS should freeze the separation, but not the mechanism.
We do **not** need to decide yet whether watch/status material is pushed or pulled; whether successor refresh is portal-owned, shell-owned, or provider-owned; whether all holds are reversible; or whether every provider gets one universal status taxonomy.
We only need the shell and repo vocabulary to stop lying by treating all of those as one timeless `validity` noun.


## Possession, local duplication, live lends, and representation exports

Another easy overdecision would be to pick one universal `share` story too early.
That would blur together at least five different classes:
- something is held here now,
- something can be duplicated locally,
- something can be lent live across one explicit courier lane,
- something can only be exported as a weaker representation,
- and something only survives as a receipt/history row.

ViewFS should freeze the separation, but not the mechanism.
We do **not** need to decide yet whether live lends are kernel-native, runtime-native, portal-mediated, or terminal-mediated; whether weaker export always means byte materialization versus projected-document export; or whether any live lend crosses machine boundaries.
We only need the shell and repo vocabulary to stop lying by treating all of those as one flattering `share` verb.

## Foreign-backed borrows, compat attaches, projected imports, and local realizations are different questions

Questions to keep separate:
- is this thing still fundamentally backed by another provider or mediator?
- did we merely make it usable here through one wrapper, relay, or runtime adapter?
- was it projected into this pane/view as a scoped synthetic local entry?
- was it explicitly localized here as bytes/object state?
- or are we only holding a receipt/history row?

Why this matters:
- borrowed foreign-backed usability is often the most honest current state and should not be treated as a failed approximation of local ownership;
- wrapper/relay attaches are valuable bring-up and compatibility tools, but they should not silently become the ontology of the local object model;
- projected imports are stronger than mere discovery and weaker than local realization, so the shell should be able to say `projected here` without laundering that into `local object`;
- materialized caches/replicas may still be sync/provider-backed rather than canonical local object-store truth;
- a durable receipt that something was attached/projected/localized before should not silently revive current locality or current provider reachability.

Working rule:
- keep `borrow_foreign`, `attach_wrapper`, `project_here`, `localize_here`, and `receipt_only` as visibly distinct shell/transcript classes.
- keep `make here` as an explicit transition rather than an automatic side effect of every open/import path.

Do not decide yet:
- one universal wrapper/relay ABI,
- one final projected-import taxonomy,
- whether local realization always means exact byte copy versus local replica versus local object-store commit,
- whether provider-backed borrows are expected to survive relaunch/offline by default.



## Route envelopes, authority sidecars, sink bindings, and receipts are different questions

Ask explicitly:
- is this thing only one typed route/plumb envelope?
- is it one optional sidecar that narrows or explains the route?
- did a sink actually accept a representation, projected bind, live bind, or localized import?
- or is it only one durable receipt/history artifact?

Why keep these separate:
- a route envelope is useful because it can be copyable and inspectable without acting like current authority;
- a sidecar may help fit, narrowing, or audit without becoming a capability container;
- sink acceptance is where actual local consequence begins and should say exactly what happened;
- a receipt can preserve exact consequence without silently reviving it as current routeability or current sink-held authority.

Working rule:
- keep `route_only`, `route_plus_sidecar`, `sink_accept_representation`, `sink_accept_bind`, `sink_accept_projection`, `sink_accept_localization`, and `receipt_only` as visibly distinct shell/transcript classes.
- keep designation-only route slips cheap and safe to share, and keep sink-side consequence explicit.

Do not decide yet:
- one universal route-envelope schema across all families,
- one universal sidecar taxonomy,
- whether any sidecar can ever carry narrowly live authority,
- whether replay may auto-represent prior sidecars,
- whether every sink bind/import/localize outcome shares one final result schema.

## Privilege brackets, borrowed authority, call-chain contexts, deny-only hints, and receipts are different questions

Ask explicitly:
- is this helper currently inside one bounded privilege bracket?
- what exact authority is being borrowed inside that bracket?
- what caller/plugin/pane context merely explains who asked?
- is there only one deny-only provenance hint or veto?
- or is this only one durable receipt/history artifact?

Why keep these separate:
- one bracket is execution posture, not a process-wide mode bit;
- borrowed authority is real current capability and should not dissolve into provenance;
- call-chain context is explanatory and should not become a silent grant;
- deny-only hints can safely narrow or veto without widening;
- a receipt can preserve exact explanation without reviving bracket or caller state.

Working rule:
- keep `bracket_active`, `borrowed_authority_active`, `call_context_only`, `deny_only_hint_present`, `deny_only_veto_fired`, and `receipt_only` as visibly distinct shell/transcript classes.
- keep `who asked?` visible while refusing to let caller provenance impersonate authority.

Do not decide yet:
- one final call-chain frame taxonomy,
- one final privilege-bracket carrier/API,
- whether any call context crosses machine or user boundaries,
- one final deny-only rule vocabulary,
- whether borrowed-authority drawers always name exact handles versus capability classes.

## Native attaches, adapted attaches, coerced representations, and local realizations are different questions

Ask explicitly:
- is the receiver currently talking to a directly native lane for this pane/process/tool?
- is one wrapper, relay, or compatibility membrane making it usable here?
- is the receiver only getting one alternate representation, preview stream, or translated surface?
- was there an explicit make-local step to gain stronger native/local semantics?
- or is this only one receipt/history row?

Why keep these separate:
- direct native fit is valuable truth and should not be hidden behind one generic `opened` bit;
- adapted attaches are often the right answer, but they should stay inspectable instead of becoming ontology by accident;
- coerced representations are useful because preview/import/render lanes are often real success states even when same-object attach is unavailable;
- local realization should remain an explicit fidelity/locality transition rather than one silent repair step;
- a durable receipt that a lane once worked should not silently revive current attach fit.

Working rule:
- keep `attach_native`, `attach_adapter`, `attach_relay`, `representation_coerced`, `localize_for_native`, and `receipt_only` as visibly distinct shell/transcript classes.
- keep `same object` versus `translated representation` inspectable at the sink.

Do not decide yet:
- one universal wrapper/relay ABI,
- one final alternate-representation taxonomy,
- whether some lanes can skip directly from coerced representation to durable local objecthood,
- whether native attach is mandatory for any Phase 1 surface,
- whether every adapter path deserves one standard UX label.



## Revision 097: command-surface layers, key actions, and external launches

Another especially useful seam is **built-in verb versus lexical expansion versus semantic command layer versus key action versus external launch versus receipt/history**.

What to keep separate:
- built-in product-native shell verbs
- typed lexical expansions such as abbreviations or snippet-like rewrites
- explicit overlay/module/custom-command layers
- keybound widgets / palette-only actions / key-table modes
- exact external executable or script launches
- durable receipts and transcript history

Why it matters:
- shell UX gets much better when the user can ask `what exactly won?`;
- command palettes and key tables become easier to trust when they do not silently pollute transcript command truth;
- abbreviation preview can stay helpful without impersonating semantic resolution;
- overlay activation can stay powerful without pretending product baseline changed;
- external launches can remain exact and capability-safe without flattening into built-in semantics.

Do not freeze yet:
- one final alias/abbreviation/snippet object model,
- one universal overlay/module schema,
- whether every key action can ever promote into one typed verb,
- or one universal palette protocol across host shells and terminals.


## Revision 098: editable buffers, parsed structure, diagnostics, and prepared actions

Another especially useful seam is **editable buffer versus parsed/highlighted structure versus advisory diagnostics versus compiled packet versus prepared action versus receipt/history**.

What to keep separate:
- current mutable prompt/buffer text or fragments
- current best parse/highlight structure, including recovery state
- advisory syntax/lint/hint output
- pane-local compiled command packets bound against current handles/receipts
- prepared actions that are actually reviewable/launchable
- durable receipts/history

Why it matters:
- a colorful buffer should not impersonate current authority or readiness;
- parser recovery is useful, but it is not exact intent;
- diagnostics can explain without becoming enforcement;
- compiled packets can differ across panes even when the visible text matches;
- history should stay descriptive instead of silently reviving old compile truth.

Do not freeze yet:
- one final shell parser or grammar;
- one final highlight token taxonomy;
- one final diagnostic engine;
- one final packet object model;
- or whether analyzers are shell-native, helper-provided, or terminal-mediated.
