# Built-in shell affordances, customization bundles, startup files, and project hooks

This note sharpens one more low-regret ViewFS separation:
**shipped shell baseline**, **explicit reviewed customization bundle**, **host/user startup-file execution**, **project-local activation hook**, and **remembered receipts/history** are different truths.

Relevant precedents:
- **SlopOS capshell startup-profile posture** keeps startup explicit-only, forbids implicit rc/profile loading, and forbids prompt/cwd-triggered code loading in the reviewed baseline.
- **REF-DIRENV-ALLOW** and **REF-DIRENV-REQUIREALLOWED** show the right emotional model for per-directory activation: explicit allow and explicit re-allow after meaningful changes.
- **REF-VSCODE-WORKSPACE-TRUST** and **REF-VSCODE-COPILOT-SECURITY** show that browsing can stay useful while tasks, debugging, workspace settings, and agents remain withheld.
- **REF-GHOSTTY-SHELL-INTEGRATION** shows shell integration should remain inspectable and manually sourceable, especially when users switch shells.
- **REF-POWERSHELL-PROFILES** shows startup profiles are ordinary executable scripts that can run arbitrary customization logic at shell start.

## Why the split matters

A future custom shell becomes easier to trust when it can answer five different questions honestly:
- what is built into the product baseline?
- what has the user explicitly promoted and reviewed as a customization bundle?
- what ambient host/user startup code ran because the shell started?
- what project-local activation hook wants to run because the cwd/workspace changed?
- what only happened in the past?

Those are different product, security, and debugging truths.
A lovely prompt should not require ambient dotfile folklore to explain itself.
Browsing a repository should not quietly become activation-hook execution.
A reviewed shell bundle should not be flattened into the same class as arbitrary host profiles.
And a history row that once said `allowed` should not silently answer what is active now.

## Working posture

### Built-in shell delight should stay built-in
The shell can be ambitious and still start from a clean baseline.
Prompt rendering, semantic marks, receipt cards, notebooks, palettes, command blocks, and inspect drawers can all be shipped product behaviors rather than ambient startup-script consequences.

### Reviewed customization deserves a first-class class
Useful aliases, prompt themes, shell-integration helpers, and workflow snippets should be promotable into explicit reviewed bundles.
That gives users reuse and delight without normalizing ambient startup-file execution as the ontology.

### Startup files are real code, not harmless mist
Host/user profiles should be treated as executable startup surfaces.
If they are in play, the shell should say so.
If they are blocked, the shell should say so.
If users want to keep good parts, ViewFS should make promotion into explicit reviewed bundles easier than ambient drift.

### Project-local hooks deserve a separate gate
A repo-local `.envrc`, `.env`, or activation script is stronger than browsing and different from startup personalization.
ViewFS should keep those hooks behind explicit review/trust gates.

### History should stay non-reviving
Receipts that a profile or project hook once ran are useful for explanation, debugging, and repair.
They should not silently become the answer to what is currently active.

## Classification worth standardizing early

A useful shell/startup classification for protocol experiments is:
- `baseline_builtin`
- `custom_bundle_active`
- `custom_bundle_candidate`
- `startup_profile_active`
- `startup_profile_blocked`
- `project_hook_pending`
- `project_hook_allowed`
- `project_hook_denied`
- `project_hook_stale_reapproval`
- `receipt_only`
- `history_only`

This is intentionally posture-oriented.
It does **not** decide one final customization-bundle schema, one final trust scope lattice, or one universal host-shell compatibility layer.

## Shell and terminal payoffs

A truthful shell can turn this split into product leverage:
- **clean-start lamps** so the user knows whether the baseline is built-in, bundled, ambient-profile-backed, or project-hook-tainted;
- **bundle ledgers** that make explicit customization bundles inspectable, diffable, and promotable;
- **profile-debt drawers** that explain when host/user startup scripts changed startup truth;
- **hook quarantine shutters** that let project-local activation requests be inspected and approved without pretending browsing is execution;
- **prompt provenance cards** that explain where prompt behavior, aliases, completions, and integration came from.

## What not to freeze yet

Do **not** freeze yet:
- one final reviewed shell-bundle schema,
- whether any legacy host profiles can ever be imported directly,
- whether project-hook approvals are scoped by pane/session/workspace/profile,
- one final taxonomy for prompt/theme/plugin bundles,
- or a universal portability story across every host shell/runtime.

The separation is worth freezing now.
The exact bundle transport and compatibility machinery are not.
