# Schemas, policies, advice rails, diagnostics, and decision logs

Purpose: keep the next policy/control seam small while SlopOS and ViewFS are still in design.

ViewFS is accumulating enough shell ambition that we need one more hard class boundary:
**schema/validation material ≠ authoritative policy/caveat material ≠ shell advice/ranking heuristics ≠ per-decision diagnostics ≠ durable logs/receipts**.

That split is the safest way to make the shell extremely smart without letting “helpful” suggestions quietly become enforcement truth.

## Why this seam matters now
SlopOS already points in this direction:
- `approval-basis-posture-v0.md` insists that approvals bind exact action/basis material rather than floating mutable heads.
- `explain-posture-v0.md` keeps explanation artifacts non-authoritative.
- the auth-mediation family keeps mediation, prompts, and receipts from regrowing a hidden browser or generic credential plane.

ViewFS should match that posture rather than inventing a second softer story where:
- completion ranking implies authorization,
- route suggestions imply policy acceptance,
- history logs imply current permission,
- or a nice “why” panel becomes a bearer token in disguise.

## Lessons we must learn from the past

### 1. Policy validation is not runtime authorization
Cedar is unusually clear here: validation against schema is a separate operation, and schema changes can invalidate previously validated policies.
That means a future ViewFS policy family should not blur:
- “this policy bundle/schema was checked and looks structurally sane,”
- with “this concrete import/run/rebind is allowed right now.”

Why this matters:
- validation errors and runtime deny results need different repair paths;
- shell UX can surface both, but should never pretend one is the other.

### 2. Policy decision-making and policy enforcement should stay distinct
OPA’s core framing is valuable even if ViewFS never adopts Rego: the policy engine answers questions over structured input, while surrounding software still decides how to enforce or present the answer.

Why this matters:
- ViewFS can keep one exact decision lane while still letting the shell experiment with ranking, previews, advisors, or palette hints;
- enforcement surfaces should be narrow, while shell advice can remain fast-moving and killable.

### 3. Diagnostics are not policy, and logs are not authority
Cedar authorization responses include diagnostics such as determining policies and errors.
OPA decision logs exist for auditing and offline debugging, and they explicitly need masking/redaction controls.
That is the right split for ViewFS too:
- **decision diagnostics** explain one evaluation,
- **logs/receipts** preserve history and debugging material,
- neither should silently become standing authorization.

Why this matters:
- explanation can grow rich without becoming a replay loophole;
- audit durability and live authority can evolve separately.

### 4. Temporary authorization is a dangerous convenience seam
polkit is a good cautionary precedent because it explicitly distinguishes authority, session authentication agents, and temporary authorization obtained through authentication.
That is useful, but it also shows how easy it is for “helpful temporary approval” to become sticky folklore.

Why this matters:
- ViewFS should keep human approval acts, policy decisions, and retained/durable consequences on visibly different seams;
- any “remember for a while” behavior should be policy-visible and receipt-visible, not a hidden shell convenience cache.

### 5. Debug overlays are design tools, not just terminal candy
Ghostty’s recent OSC 133 work and debug overlay are a great reminder that shell metadata must be inspectable while the protocol is still evolving.
ViewFS should steal that instinct hard.

Why this matters:
- a capability-native shell will need developer-facing overlays for policy/advice/diagnostic state;
- honest introspection during bring-up prevents accidental semantic collapse later.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **PolicySchema** — structural/type expectations for the policy family or request family
- **PolicySet** — authoritative rules/caveats/guardrails used for current evaluation
- **AdviceRail** — shell-only ranking, completion, defaulting, or repair hints that never count as authorization
- **DecisionDiagnostic** — per-evaluation explanation object (`determining rules`, `errors`, `narrowing reason`, `missing witness`, `policy veto`)
- **DecisionLog** — durable audit/debug record, redacted and non-authoritative

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **policy lens** — what exact policy family and version/cut were consulted
- **advice rail** — what the shell is suggesting, ranked, or autofilling *without* claiming authorization
- **diagnostic card** — why the current candidate is allowed, narrowed, denied, or receipt-only
- **audit trace chip** — whether a durable redacted trace exists, and whether it is local-only/exportable/receipt-only
- **replay guard** — whether a historical success is being reused as evidence, as advice, or not at all

That is the right way to make the shell feel more capable than a classic terminal without letting “assistant hints” mutate into policy.

## What not to decide yet
- the final portable policy language for ViewFS or SlopOS-adjacent families,
- whether a policy family uses Cedar-like validation, OPA-like structured outputs, or something narrower,
- the final schema for diagnostics or decision logs,
- how much policy metadata should be rendered in ordinary prompt chrome versus drawers/panels,
- whether advice rails are purely local shell artifacts or shareable notebook/workflow hints.

## Near-term recommendation
For the next nearby spikes:
1. keep validation/schema checks distinct from runtime allow/deny/narrow decisions,
2. keep shell advice/ranking on a visibly non-authoritative **advice rail**,
3. produce compact **decision diagnostics** for meaningful allow/narrow/deny results,
4. keep any **decision log** redacted, bounded, and non-authoritative,
5. prototype one killer flow: **policy lens + advice rail + diagnostic card + audit-trace chip**,
6. and make all of that work even when the final policy language is still open.
