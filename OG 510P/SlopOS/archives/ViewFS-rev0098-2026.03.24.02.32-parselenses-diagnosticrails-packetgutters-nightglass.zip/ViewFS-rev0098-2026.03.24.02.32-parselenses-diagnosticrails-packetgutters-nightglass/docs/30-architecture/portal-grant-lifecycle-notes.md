# Portal grant lifecycle notes

Purpose: keep ViewFS portal design broad enough for real desktop workflows while staying disciplined about what becomes durable authority.

## ViewFS should treat these as one family
- open/import
- save/export
- reopen recent document
- drag/drop transfer
- clipboard file transfer
- terminal-to-app handoff

The lesson from existing desktop sandboxes is that these are all variants of **grant lifecycle management**, not isolated APIs.

## Useful precedents
- REF-XDG-FILECHOOSER: explicit chooser grants can make selected files accessible.
- REF-XDG-DOCUMENTS: exported files appear in a restricted view for the target application.
- REF-XDG-FILETRANSFER: drag/drop and copy/paste file exchange can be mediated through a transfer session, and those transfer exports are intentionally not durable across sessions.
- REF-ANDROID-SAF: persistent grants need stable IDs and still fail when the underlying object is moved or deleted.
- REF-APPLE-SSB-CVE2025: durable bookmark-style access can become a serious security problem if the persistence and validation story is too magical.

## The lifecycle we should model explicitly
1. **selection** — user or workflow picks an object or destination
2. **grant minting** — portal issues a handle plus receipt
3. **use** — object is opened, read, written, inspected, or transferred
4. **optional persistence** — durable reopen state is stored only when explicitly requested
5. **reopen / refresh** — portal revalidates stable identity and rights
6. **revoke / expire** — grant dies by user action, policy, or TTL
7. **audit / explain** — user can see why a grant exists and what it can still do


## Grant classes to keep separate
These classes should stay visible even if the final wire format changes:

### G1. Ephemeral open/import grant
- meant for immediate inspection or short-lived use
- default for chooser-open
- should expire with the session/workflow unless explicitly upgraded

### G2. Ephemeral transfer grant
- meant for drag/drop, copy/paste, or shell-to-app handoff
- should be short-lived and consumption-oriented
- should not quietly become a durable reopen permission

### G3. Destination/save grant
- meant for writing/exporting to a selected location
- should say whether it is one-shot, append-like, replace-like, or reusable
- should not silently become broad directory authority

### G4. Durable reopen grant
- meant for "open again later"
- needs stable identity, revalidation, and user inspection/revocation surfaces
- should be explicit and exceptional, not a side effect of every open

### G5. Bound workspace/view grant
- a handle/view binding that becomes part of a process or workflow environment
- stronger than a one-shot open, but not automatically the same as a durable reopen receipt
- should remain visibly distinct from user-facing document recents/history

## Receipt states to keep explicit
Receipts should be able to say at least:
- `issued` — a grant was minted
- `materialized` — the target was actually bound/opened/exported/transferred
- `durable` or `ephemeral` — lifetime class
- `revalidated` — reopen succeeded after checking identity/rights
- `expired` — lifetime ended naturally
- `withdrawn` or `revoked` — access was later removed by policy/user/provider
- `superseded` — a newer receipt replaced this one

The exact enum can wait, but the distinctions should not disappear.

## Guidance for ViewFS

### Keep ephemeral the default
- open/import should default to session-bounded or workflow-bounded grants.
- save/export destinations should default to explicit single-purpose sinks unless the user requests persistence.
- transfer sessions should default to short-lived, one-purpose receipts.

### Persistence should be explicit and inspectable
- a durable reopen token should never be silently created as a side effect of a normal open.
- persistent grants need stable target identity checks and a clear “this may stop working if the target changes” story.
- a management surface for active persistent grants should exist in the shell or system UI.

### Reopen must not silently widen rights
- reopened access should be clamped to the original grant class.
- replacing, moving, or retargeting the underlying object should trigger fresh validation or fresh consent.

### Transfer deserves first-class receipts
- drag/drop and clipboard file moves should produce receipts with sender, receiver, writability, and expiry semantics.
- the custom shell should be able to emit and consume these receipts directly.

## Design risks to avoid
- “recent items” automatically becoming durable authority
- save dialogs becoming hidden directory grants
- drag/drop bypassing the portal story because the UX feels ephemeral
- bookmark-style persistence that no one can inspect, revoke, or explain


## One more split worth preserving
- **workspace/tree bind** is not the same as durable reopen, even if the same chooser UI might lead to either.
- **URI launch/reveal** is not a local-object grant, even when the destination app ultimately shows a file-like thing.
- **recent items/history** should not quietly turn into view rebinding or broad directory authority.

That matters because ViewFS wants the shell to explain why a pane can see an object. A local view bind, a durable reopen receipt, and an external OpenURI launch are different explanations and should stay different.

## Another split worth preserving
- the **request object / interaction receipt** is not the same thing as the resulting durable grant
- the **durable ref** is not the same thing as the fresh live handle materialized after reopen
- shell transcripts should mostly remember receipts and refs, then regenerate live handles by explicit rebind/reopen

That split keeps auditability, portability, and authority easier to reason about.

## Yet another split worth preserving
- the **request object** is not the same thing as the **candidate universe** the chooser/provider searched
- the **candidate set** is not the same thing as the **selection**
- the **selection** is not the same thing as the **minted grant/ref**
- the **minted grant/ref** is not the same thing as the **live bind** installed into this pane or child launch

That split keeps candidate enumeration, persistence, binding, and history easier to reason about.

## Session-memory note
Portal flows should be allowed to leave behind receipts and optional durable refs in shell history/notebooks/workflows, but those artifacts should remain visibly distinct from the live authority they may have produced at the time.

## Extra split to preserve
A workspace/tree bind granted through a chooser or document portal should still remain separate from trusting workspace-defined automation such as tasks, env hooks, debug launchers, notebooks, or agents. Access and execution should not silently merge just because the same project root is involved.

## Another split worth preserving
- the **request handle** is not the same thing as one **session handle** or **transfer key** returned later
- the **session handle / transfer key** is not the same thing as the **portal's current state** for that object
- the **portal's current state** is not the same thing as one **local adopted bind/live handle** in this pane
- an old request/session receipt should not silently answer `is this still live now?`

That split matters because real portal families already do this: one request resolves once, one session or transfer object may live longer, and the current pane may or may not have adopted the result locally.
