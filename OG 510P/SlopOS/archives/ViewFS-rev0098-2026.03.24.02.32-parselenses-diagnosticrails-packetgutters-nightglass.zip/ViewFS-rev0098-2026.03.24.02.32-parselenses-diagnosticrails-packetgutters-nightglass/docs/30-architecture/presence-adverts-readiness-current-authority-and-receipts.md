# Presence adverts, readiness, current authority, and receipts

Purpose: keep **presence adverts/catalog presence**, **readiness or serving truth**, **mediated grant-needed posture**, **direct current authority**, and **historical receipts** on distinct seams.

One more low-regret move for ViewFS is to stop treating `it appears in a provider list`, `it should work now`, `I can ask for it`, and `I already hold it` as the same truth.
The custom shell and future portal/import story both get better if those states are made explicit instead of left to vibe.

## Useful precedents
- **REF-FUCHSIA-CAPS**, **REF-FUCHSIA-NAMESPACE**, and **REF-FUCHSIA-CONNECT**: Fuchsia separates the namespace a component consumes from the outgoing/exposed capabilities it publishes, which is a useful warning that publication/discoverability is not identical to a client already holding authority.
- **REF-MCP-ROOTS**, **REF-MCP-RESOURCES**, **REF-MCP-PROMPTS**, and **REF-MCP-TOOLS**: helper catalogs and list-change notifications can make discoverability rich and dynamic without becoming filesystem grants, current-state oracles, or completed invocations.
- **REF-XDG-REQUEST**, **REF-XDG-FILECHOOSER**, and **REF-XDG-DOCUMENTS**: mediated selection and request lifetimes stay explicit, and selected files may only become accessible through a restricted document view.
- **REF-DNSSD**: service-instance browsing is a discovery surface that still requires later resolution and contact.
- **REF-K8S-ENDPOINTSLICE**: discoverable endpoints can still vary in `ready`, `serving`, and `terminating` state, which is exactly the kind of anti-collapse discipline ViewFS needs around `shown` versus `usable now`.

## Distinctions worth preserving

### 1. Presence adverts are weaker than current authority
A provider saying `this exists` or `this can be chosen` is not the same thing as the actor already holding a live handle.
Catalog rows, presence adverts, and outgoing capability publication should stay visibly weaker than `held now` truth.

### 2. Readiness is a separate, decaying claim
`Ready now`, `servable`, `cooling down`, `withheld`, `withdrawn`, and `expired` are about current operability, not about identity or authority.
These states can change quickly.
That means they should stay freshness-scoped and receipted instead of being laundered into one timeless object badge.

### 3. Grant-needed posture is useful truth, but still not authority
It is valuable for the shell to say:
- `ask portal`,
- `request bind`,
- `needs reacquire`,
- `needs user pick`,
- `ready once granted`.

That is great product truth.
It is still not the same thing as already-held direct authority.

### 4. Receipts should remember adverts without pretending they are current
History may need to remember:
- which provider advertised something,
- whether it was ready then,
- what mediation step was still required,
- and whether a current grant was actually minted.

That memory is useful precisely because it is not itself current authority.

### 5. Local publication remains a separate seam
Even if a provider advertises something and it is ready, that still does not answer whether it is currently published into one concrete process namespace.
RFC-0075 still stands: local publication/binding should stay separate from store truth, projection truth, and current live authority.

## Shape that feels promising
ViewFS probably wants truth labels like:
- **AdvertisedOnly** — visible in a catalog, provider shelf, or outgoing publication surface
- **AdvertReady** — advertised plus freshness-scoped readiness claim
- **GrantNeeded** — actionable only after an explicit mediation/reacquire step
- **HandleHeld** — direct current authority already held
- **ReceiptOnly** — history/explanation without present authority

The exact encoding can wait.
The split should not.

## Nifty ideas worth stealing
- **Presence halos**: softly show `advertised`, `ready`, `cooling down`, `withdrawn`, or `expired` around route/object chips.
- **Readiness lamps**: small freshness-aware indicators that decay from `ready now` to `last known` to `history only`.
- **Withdrawn ghosts**: keep recently withdrawn adverts visible as dim ghosts with reasons instead of silently deleting them from the shell’s memory.
- **Grant-needed ladders**: explicit next-step UI like `ask portal`, `rebind here`, `reacquire`, or `open history`.
- **Advert ledgers**: inspectable provenance for which provider/helper advertised something and when.

## What not to decide yet
- one final advert/watch protocol for all providers;
- one final readiness state machine across object, route, and helper surfaces;
- whether adverts are pushed, pulled, or query-only in every backend;
- whether some providers skip readiness entirely and expose only direct-handle or direct-request lanes.

## Near-term recommendation
For the next narrow spikes:
1. keep advert truth separate from current authority,
2. keep readiness freshness-scoped and decay-aware,
3. keep `grant needed` separate from `held now`,
4. receipt what actually happened,
5. and make the shell tell that story directly instead of hiding it behind one fake `available` badge.
