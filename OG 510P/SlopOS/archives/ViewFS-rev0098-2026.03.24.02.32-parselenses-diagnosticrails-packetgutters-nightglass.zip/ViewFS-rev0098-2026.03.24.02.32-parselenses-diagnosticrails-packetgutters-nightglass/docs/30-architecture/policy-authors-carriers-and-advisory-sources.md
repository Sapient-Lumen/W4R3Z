# Policy authors, carriers, and advisory-only sources

Purpose: keep the next policy/trust seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough policy-aware shell ambition that we need one more anti-collapse boundary:
**author class ≠ carrier/container class ≠ trust gate ≠ advisory-only source ≠ effective active state ≠ durable receipt/history**.

That split is the safest way to let the shell discover, render, and reuse helper material aggressively **without letting the thing that carried a suggestion quietly become the thing that may author ceilings, trust gates, or active policy**.

## Why this seam matters now
SlopOS already points this way:
- `rfcs/0028-veto-only-policy-bundles-for-automation.md` keeps policy non-amplifying and explicit.
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md` keeps mediated user choice separate from ambient discovery.
- `rfcs/0115-capability-safe-shell-and-automation.md` keeps shell cleverness explainable without letting it mint power.
- `approval-basis-posture-v0.md`, `verification-policy-selection-boundary-v0.md`, and `authagent-provider-role-boundary-v0.md` already insist that evidence, helpers, and agents do not choose their own judge.

ViewFS should preserve that posture in shell UX instead of creating a softer second story where:
- a plugin/package/workspace carrier quietly gains the right to author deny ceilings,
- imported helper material silently authors a trust gate because the carrier is already trusted,
- a history row or discovered config file quietly stops being advisory and starts being live,
- or a shell-local “repair” quietly writes the active answer while pretending only to explain it.

## Lessons we must learn from the past

### 1. Managed policy is a distinct author class
VS Code’s enterprise policy docs and AI settings docs are unusually crisp: managed policies override lower-level settings, and organizations can centrally control agent mode, MCP sources, approvals, and related AI behavior.

Why this matters:
- some source classes are legitimate **authors** of ceilings and gates;
- those author classes should stay visibly distinct from user/profile preferences and imported helper material;
- shell repair flows must not masquerade as managed policy.

### 2. Trust gating is distinct from origin and from authorship
VS Code Workspace Trust and the extension trust guide remain strong precedents: Restricted Mode disables or limits risky workspace behavior, and `restrictedConfigurations` keeps workspace-defined values visible while withholding them until trust is granted.

Why this matters:
- trust gating should be a separate class from both **who authored something** and **what carried it here**;
- a workspace file may be visible and even intelligible while still being ineligible to become active;
- the shell should be able to say “present, carried by this workspace, but gate closed.”

### 3. Carriers can inherit trust without inheriting authorship
Current VS Code docs add a very relevant caution: plugin MCP servers are implicitly trusted when you install the plugin, unlike workspace MCP servers which show a separate trust prompt; customization docs also note that AI customization material can be discovered by walking up from the workspace toward the repository root.

Why this matters:
- a trusted **carrier** (plugin, package, parent repo, profile, bundle) can deliver powerful material;
- but carrier trust should not automatically grant the right to author every kind of state;
- ViewFS should treat “carried by a trusted thing” as different from “eligible to author ceilings/gates/effective policy”.

### 4. Provenance and scope need first-class inspection
Git’s `git config` is still a great tiny precedent because it can expose both `--show-origin` and `--show-scope`.

Why this matters:
- users should be able to ask not just “who won?” but “who authored this?”, “what carried it here?”, and “what scope could it legally affect?”;
- a shell that cannot separate author, carrier, and scope will eventually produce trust folklore.

### 5. Deny ceilings should still beat convenience, even when UX gets rich
Deno’s security model is still a useful product reminder: deny flags take precedence over allow flags, prompts stay explicit, and permission audit logs can be emitted.

Why this matters:
- explicit ceilings should still dominate even when the shell offers repair hints or richer routing;
- advisory-only sources should stay visibly advisory;
- durable receipts should explain why something stayed advisory instead of becoming active.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **AuthorClass** — the source class that is actually allowed to author a given kind of ceiling, trust gate, or effective preference (`owner`, `org`, `device`, maybe `user-profile`, maybe explicit one-shot user act`)
- **CarrierClass** — the thing that transported or exposed material (`workspace`, `parent-repo`, `plugin`, `profile file`, `imported bundle`, `receipt`, `history row`, `shell-local cache`)
- **TrustGate** — whether material from this carrier/source area is admissible as an active input for this policy family right now
- **AdvisorySource** — visible, inspectable material that can rank, explain, or propose but is categorically not allowed to author ceilings/gates by itself
- **EffectiveState** — the exact current outcome with author, carrier, gate posture, blocked alternatives, and precedence reasoning
- **ActivationReceipt** — durable history explaining who authored, what carried, what gates applied, what stayed advisory-only, and what actually became active

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **author badges** — `org authored`, `user authored`, `explicit one-shot adopt authored`
- **carrier tags** — `from plugin`, `from parent repo`, `from workspace`, `from receipt`, `from history`
- **advisory-only rails** — visible suggestion lanes that cannot directly widen or author policy
- **trust-tunnel warnings** — a loud cue when a trusted carrier is surfacing material that still is not eligible to author active state
- **authorability fuses** — a visible answer to “this source class may propose here but may not author this class of state”
- **origin/author split inspectors** — one drawer that shows both who authored the live answer and what merely carried the losing alternatives

That is the right way to make a shell feel ambitious without letting carrier trust silently become policy authorship.

## What not to decide yet
- the final taxonomy of author classes for every policy family,
- whether `user-profile` may author all gates or only some local preferences,
- whether plugins/extensions/packages can ever author anything above advisory or whether they remain carriers only,
- whether parent-repo / discovered-upward customization is always advisory or can become adoptable under some trust transitions,
- the final serialized schema for author/carrier split receipts,
- how much author/carrier state belongs in prompt chrome versus drawers, cards, or notebooks.

## Near-term recommendation
For the next nearby spikes:
1. make author class, carrier class, and trust gate separately inspectable;
2. define at least one **categorically advisory-only** source class and keep it honest in the shell;
3. treat plugin/package/workspace/parent-repo material as carrier-tracked inputs until explicitly adopted;
4. make effective-state inspection preserve both the winning **author** and the losing **carriers**;
5. record author-vs-carrier reasoning in durable receipts without turning receipts into live sources;
6. prototype one killer flow: **author badge + carrier tag + advisory-only rail + trust-tunnel warning + activation receipt**.
