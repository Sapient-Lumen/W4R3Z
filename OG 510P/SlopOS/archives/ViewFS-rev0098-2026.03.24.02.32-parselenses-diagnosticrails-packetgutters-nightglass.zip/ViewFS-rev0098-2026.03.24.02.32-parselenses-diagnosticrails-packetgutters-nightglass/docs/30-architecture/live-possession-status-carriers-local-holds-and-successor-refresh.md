# Live possession, status carriers, local holds, and successor refresh

One more lie is easy to import from older systems:
if something is still local or still held, UIs start talking as if that automatically means `still good now`.

That is not good enough for ViewFS.
The point of this project is not merely to hold objects and handles.
It is to make object-store truth, capability truth, namespace truth, mediated-import truth, **and watch/status truth** honest enough that the shell can say what is really true next.

Useful precedents point the other way:
- **REF-RFC7662-INTROSPECT**: a protected resource can ask for the current state of a token, including whether it is active and what authorization context it carries.
- **REF-RFC7009-REVOKE**: different token styles create different revocation/update trade-offs, which means `I still have the string` is not enough.
- **REF-RFC6960-OCSP** and **REF-RFC5280-CRL**: certificate status is a distinct layer, with `good`, `revoked`, `unknown`, `certificateHold`, and `removeFromCRL` making it clear that some states are reversible or freshness-bound.
- **REF-VC-BITSTRING-STATUS**: a compact status surface can stay smaller than the base credential while still carrying typed purposes like `refresh`, `revocation`, `suspension`, and `message`.
- **REF-TUF-METADATA** and **REF-TUF-SPEC**: signed state can still go stale, freeze, or require successor-root refresh even when old material is locally present.

## The split

Keep these classes separate.

### 1. Live possession / local realization
`This object, grant, or handle is here or held here now.`

Examples:
- a locally realized object,
- a live handle in this process,
- a holder-bound grant that still exists,
- a certificate, credential, or bundle still present in local state.

This is not yet the same thing as standing-watch good status.

### 2. Status carrier / watch material
`A smaller or later status artifact says something new about the subject.`

Examples:
- a token-introspection response,
- one status-list entry,
- an OCSP response,
- a signed attenuation event,
- a watch refresh or status bundle.

This is different from the base object and different from local consequence.

### 3. Receiver stance
`How does this local shell, workspace, or process interpret the incoming status?`

Examples:
- accept and narrow,
- suspend until refreshed,
- quarantine because the watch is stale or ambiguous,
- treat as advisory only,
- require a stronger local confirmation before changing consequence.

This is important because transmitted status is not identical to local policy.

### 4. Local hold / attenuation / quarantine posture
`What temporary or narrowing local consequence is in force right now?`

Examples:
- suspended here,
- narrowed here,
- quarantined here,
- spend hold active,
- watch stale, local hold asserted.

This is different from timeless destruction and different from base possession.

### 5. Successor / refresh posture
`Is a newer witness, root, epoch, or replacement available or required?`

Examples:
- refresh advised,
- successor available,
- successor root required,
- reissue needed,
- current watch too old, fetch new status.

This is different from current hold and different from history only.

### 6. Current invocability after watch processing
`Can the action proceed here now after all of the above has been considered?`

This is the narrow winning truth that should drive `go`, `invoke`, `open`, `export`, or `send`.

### 7. Durable receipt / history
`Something happened before.`

Receipts should remember watch updates, hold entries, refresh notices, successor adoptions, and resumed good-standing transitions without reviving present truth.

## Anti-collapse rules

- Do not let `held now` render as `still in good standing now`.
- Do not let one watch/status artifact silently replace base object identity.
- Do not let `suspended here` masquerade as timeless destruction.
- Do not let `refresh available` masquerade as `refresh already adopted`.
- Do not let a receipt/history row revive current good standing.

## ViewFS posture

A good Phase 1 ViewFS should be comfortable saying all of these distinctly:
- `held`
- `watch current`
- `watch stale`
- `status unknown here`
- `suspended here`
- `quarantined here`
- `refresh available`
- `successor required`
- `invokable now`
- `history only`

That vocabulary gives us freedom later.
It lets SlopOS keep evolving its status/watch transport, successor-epoch story, and local policy ownership without forcing ViewFS to flatten everything into one reusable `validity` noun.

## Shell consequences

The future shell gets several high-value truths from this split:
- a **watch braid** can show base object truth, latest status carrier, local stance, and hold posture side by side;
- **hold rails** can distinguish reversible suspension from harder quarantine or terminal withdrawal;
- **successor lanterns** can say whether a newer witness/root/credential is merely visible or actually adopted;
- **refresh shutters** can decay from `watch current` to `watch stale` without pretending the underlying handle vanished;
- **history ghosts** can preserve earlier good-standing or hold transitions without reviving them as current truth.
