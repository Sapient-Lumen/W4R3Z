# Proposers, proposal lanes, escalations, and adoptions

Purpose: keep the next policy-and-shell seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough policy-aware and automation-aware shell ambition that we need one more anti-collapse boundary:
**proposal origin/source ≠ proposal lane/scope ≠ escalation request ≠ authoritative adoption ≠ adoption receipt/history**.

That split is the safest way to let the shell surface helpful repairs, workspace hints, history-based suggestions, and mediator-owned recommendations **without silently letting helpers become judges**.

## Why this seam matters now
SlopOS already points this way:
- `verification-policy-selection-boundary-v0.md` keeps policy selection explicit rather than artifact-selected or silently defaulted.
- `approval-basis-posture-v0.md` insists that approval binds an exact reviewed basis rather than floating current heads.
- `authagent-provider-role-boundary-v0.md` keeps provider / agent / mediation roles from collapsing.
- `explain-posture-v0.md` keeps explanation useful without letting it become authority.

ViewFS should preserve that posture in shell UX instead of creating a softer second story where:
- a workspace hint quietly becomes the active policy family,
- a receipt replay silently repopulates the proposal surface as authority,
- a shell-local ranking quietly adopts a wider scope than the user reviewed,
- or a helper lane silently swaps from `once` to `workspace` or `profile` scope.

## Lessons we must learn from the past

### 1. Origin and scope should be inspectable, not folklore
Git is a very useful precedent here even though ViewFS is not a config system.
`git config` can show both **origin** and **scope** of a value via `--show-origin` and `--show-scope`.

Why this matters:
- when multiple proposal sources exist, users need to know not just *what* is suggested but *where it came from* and *how broadly it applies*;
- a shell that cannot say `workspace`, `profile`, `org`, `history`, or `once` will eventually create policy superstition.

### 2. Multiple proposal sources are fine if diagnostics say which ones are active
VS Code’s 2026 chat customization diagnostics are a strong product precedent: customizations may originate from **user profile, workspace, extensions, and GitHub organization**, and the diagnostics view exists precisely so users can see what is loaded and whether anything failed.

Why this matters:
- ViewFS should expect proposal sources to multiply over time;
- proposal origin diagnostics should arrive early, before the system gains too many helper lanes to explain from memory.

### 3. Proposal scope and trust state are separate from the configuration object itself
VS Code MCP servers are another strong precedent. Servers can be configured in the **user profile** or **workspace**, their enabled/disabled state is stored separately from the configuration, and when you add or change a workspace MCP server VS Code prompts you to confirm trust before starting it.

Why this matters:
- where a proposal lives is not the same thing as whether it is currently trusted, enabled, or adopted;
- ViewFS should keep source material, trust review, enablement, and current adoption separate.

### 4. The UI-side authentication or suggestion surface is not the authority
polkit remains a good caution here: the system architecture has an **Authority** and an **Authentication Agent per user session**. The agent helps gather consent/authentication, but the authority is still a different role.

Why this matters:
- a shell proposal surface, trust prompt, or suggestion tray should behave more like an authentication agent than an authority;
- that means it can help, explain, and escalate, but it should not silently decide.

### 5. Escalation scope needs explicit ceilings and explicit deny precedence
Deno’s permissions model is a useful product precedent. Runtime prompts can grant narrow access, explicit deny flags exist, and deny flags take precedence over allow flags.

Why this matters:
- ViewFS should make escalation scope visible (`once`, `pane`, `session`, `workspace`, `profile`, maybe later `org`) and should keep explicit narrower/deny posture louder than convenience remembers;
- if the user or owner config says “never let workspace proposals auto-adopt,” no helper lane should override that.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **ProposalOrigin** — who or what authored the suggestion (`user`, `workspace`, `extension`, `org`, `history`, `receipt`, `mediator`, `shell-local`)
- **ProposalLane** — what scope and target class the proposal is competing for (`once`, `pane`, `session`, `workspace`, `profile`, `org`; `policy-switch`, `repair`, `rebind`, `workflow-promotion`, etc.)
- **EscalationRequest** — a pending “may I widen/adopt this?” interaction that remains non-authoritative until accepted
- **AdoptionDecision** — the exact explicit act that says what was adopted, by whom, at what scope, under what ceilings and denials
- **AdoptionReceipt** — durable history showing what was proposed, what was reviewed, what was adopted or declined, and what scope actually took effect

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **proposer badges** — `workspace`, `profile`, `org`, `history`, `receipt`, `shell-local`
- **scope chips** — `once`, `pane`, `session`, `workspace`, `profile`, `org`
- **escalation ladders** — a visible choice to keep a suggestion narrow rather than silently persisting it
- **adoption gates** — the exact point where the system stops helping and starts changing live truth
- **decline receipts** — history that preserves “I looked and declined” without retrying the proposal forever

That is the right way to make a shell feel ambitious without turning convenience into ambient policy.

## What not to decide yet
- the final serialized schema for proposal origins, lanes, or adoption receipts,
- the final list of proposal sources that can exist in Phase 1,
- whether user-profile and user-owned library proposals are the same family or sibling families,
- the final precedence lattice between `workspace`, `profile`, `org`, and explicit one-shot user actions,
- how much proposer state belongs in prompt chrome versus drawers, cards, or notebook cells.

## Near-term recommendation
For the next nearby spikes:
1. keep proposal origin/source distinct from proposal scope,
2. keep proposal surfaces distinct from adoption decisions,
3. keep escalation requests visible and abortable until explicitly accepted,
4. make adoption receipts record both **who proposed** and **who adopted**,
5. prototype one killer flow: **proposer badge + scope chip + escalation ladder + adoption gate + decline/adoption receipt**,
6. and do all of that without forcing a final policy language, final precedence lattice, or final persistence schema yet.
