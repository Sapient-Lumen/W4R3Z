# Mutable work-state design space

Purpose: record the main ways ViewFS could support editable state **without** pretending that POSIX-style mutable inodes are the default answer.

This is a research note, not a decision.

## What history keeps telling us
- Immutable stores are easy to reason about and great for closure identity.
- The hard part is giving users and tools something that *feels editable* without silently reintroducing ambient global state.
- Systems that keep a stable mutable name but move the real mutation logic into sidecars, root pointers, or signed claims often keep better auditability than systems that start with “just mutate the main object in place”.

## Candidate shapes

### A. Root-pointer updates over immutable trees
Pattern:
- the current working tree is represented by one mutable pointer to an immutable tree root.
- edits create new immutable objects; “save” advances the root pointer.

Inspirations:
- REF-IPFS-MFS
- REF-NIX-CA
- REF-GIT-OBJECTS

Attractive because:
- the base store stays simple.
- snapshots fall out naturally.
- exact old states remain inspectable.

Costs:
- concurrent edits need conflict story.
- “who advanced the pointer” becomes a first-class event.
- direct random-write semantics may need staging buffers.

### B. Explicit work journals / changesets
Pattern:
- immutable base object + explicit journal of operations or changesets.
- materialized views are reconstructed by applying the journal.

Inspirations:
- REF-SQLITE-SESSION

Attractive because:
- mutation is explicit and mergeable.
- undo/redo and sync semantics can be built from the journal.
- journaling stays separable from stable object identity.

Costs:
- replay and compaction policies matter.
- journaling format can become too application-shaped if generalized too early.

### C. Stable mutable anchors plus ordered claims
Pattern:
- a stable logical name or anchor exists, but state changes are expressed as appended claims.

Inspirations:
- REF-PERKEEP-PERMANODE

Attractive because:
- stable identity and mutable history are clearly different things.
- provenance and attribution can stay obvious.

Costs:
- ordering / conflict / garbage-collection semantics become central.
- this can drift toward a collaboration protocol instead of a local filesystem layer.

### D. Stable mutable slots
Pattern:
- a mutable handle or slot has fixed identity while its contents change.

Inspirations:
- REF-TAHOE-MUTABLE

Attractive because:
- very intuitive for reopen and “current document” UX.
- stable IDs survive updates.

Costs:
- once the slot identity stops being content-derived, overwrite and revocation semantics become much more security-sensitive.
- replacing bytes under a stable authority can surprise caching, policy, or review logic.

## Provisional guidance
1. Start with **A** for general filesystem work state experiments.
2. Prototype **B** for explicit collaborative or undo-friendly workflows.
3. Keep **C** as a high-value idea for metadata-rich objects, manifests, and long-lived named collections.
4. Treat **D** as dangerous-but-useful; only adopt it after the handle, rights, and revocation story is much stronger.

## Things not to decide yet
- whether ViewFS has a single universal mutable-object type
- whether writes are page-like, record-like, or whole-object staged updates
- whether save is “replace root pointer”, “commit journal”, or “publish new anchor claim”
- whether mutable work state is kernel-visible, service-visible, or purely user-space in Phase 1

## Recommended spikes
- Spike M1: root-pointer working tree with explicit snapshot/save events
- Spike M2: changeset sidecar over immutable tree materialization
- Spike M3: named mutable-anchor prototype for project/workspace objects only
- Spike M4: stable mutable-slot reopen semantics under rights attenuation and policy checks

## Anti-goals
- no universal mutable inode model in Phase 1
- no assumption that the first mutable mechanism must serve every workload
- no silent retargeting of a stable handle to a semantically different object without transcript-visible evidence
