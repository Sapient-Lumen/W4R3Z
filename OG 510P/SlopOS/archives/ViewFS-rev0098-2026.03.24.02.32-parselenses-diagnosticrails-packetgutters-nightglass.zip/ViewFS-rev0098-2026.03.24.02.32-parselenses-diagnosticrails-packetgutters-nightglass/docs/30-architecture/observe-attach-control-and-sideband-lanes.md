# Observe, attach, control, and sideband lanes

Purpose: keep one more live-session seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough helper, task, and shell ambition that it needs another anti-collapse boundary:
**read-only observe/query/follow lane ≠ interactive attach lane ≠ control-message lane ≠ injected exec/debug lane ≠ sideband tunnel/forward lane ≠ durable transcript/history**.

That split is the safest way to let the shell expose rich live-session ergonomics **without letting `watch`, `attach`, `send`, `open tunnel`, `debug`, or old transcripts quietly count as the same kind of current authority**.

## Why this seam matters now
SlopOS already points this way:
- `rfcs/0115-capability-safe-shell-and-automation.md` keeps startup and execution explicit instead of ambient.
- `rfcs/0117-plumb-messages-and-cli-intents.md` keeps message envelopes, routing, and execution distinct.
- `docs/30-architecture/capshell-job-control-posture-v0.md` and `capshell-local-ipc-posture-v0.md` already warn against collapsing control channels into generic shell folklore.
- `docs/30-architecture/caprpc-session-posture-v0.md` and `background-request-state-posture-v0.md` already separate live continuity from durable status.
- `docs/30-architecture/attention-durable-status-boundary-v0.md` already treats active attention and durable history as different seams.

ViewFS should preserve that posture instead of creating a softer second story where:
- `follow logs` quietly becomes `interactive attach`,
- `query state` quietly becomes `change state`,
- `send signal` quietly becomes `spawn debug shell`,
- `open tunnel` quietly becomes `you now control the remote object`,
- or old transcripts quietly count as a still-live session.

## Lessons we must learn from the past

### 1. Observation and interaction are different kinds of connection
Kubernetes keeps `logs`, `attach`, `exec`, and `port-forward` separate commands. `kubectl logs -f` streams output like `tail -f`; `kubectl attach` connects to a running process and may interact with stdin; `kubectl exec` injects a new command; and `kubectl port-forward` opens a network tunnel that ends when the selected pod terminates.

Why this matters:
- ViewFS should not flatten `follow output`, `attach stdin`, `spawn debug command`, and `open sideband tunnel` into one “connected” bit.
- A shell transcript should be able to say whether the user merely watched, attached, executed a new command, or opened a side channel.
- Port-forward-like lanes should not masquerade as either a file/object grant or an interactive shell grant.

### 2. Read-only live presence and writable control must stay visibly different
`tmux` keeps read-only attachment, detaching, and control mode distinct. A read-only client can only use commands such as detach or switch-client; control mode is a separate text protocol; and sessions can be detached and reattached later.

Why this matters:
- ViewFS should preserve a strong distinction between observe-only live presence and interactive control.
- A read-only observer should not silently gain stdin or control-message powers because it is attached to the same live surface.
- Control-protocol clients deserve their own visible lane instead of being disguised as ordinary panes.

### 3. Read-only inspection, asynchronous control, and synchronous mutation are different verbs
Temporal keeps Queries, Signals, and Updates distinct. Queries read workflow state, Signals are asynchronous control messages, and Updates synchronously change workflow state and return a result.

Why this matters:
- ViewFS should separate read-only inspection from asynchronous control and from request/response mutations.
- A shell should be able to say “queried live state”, “sent control message”, and “performed synchronous update” as different truths.
- Old query answers or transcripts should not masquerade as live session control.

### 4. Enabled is not the same as active
The XDG InputCapture portal explicitly separates `enabled` from `active`: an application can request enabled capture, but the compositor decides when capture becomes active and which devices are captured.

Why this matters:
- ViewFS should not flatten requested attachment/control readiness into active live control.
- The shell should be able to say “armed”, “active”, “read-only”, or “control-owned-elsewhere” instead of one generic attached state.
- Mediators may own the transition from potential interaction to actual live control.

### 5. Transcripts and receipts are not live control handles
Once a portal Request interaction ends, the Request object is over; once a task result is retained, it is history; once a tmux client detaches, the session may continue but that client is no longer live.

Why this matters:
- ViewFS should keep durable transcript/history useful without letting them pose as still-live connections.
- Replay from history should go through an explicit lane such as observe, attach, control, exec, or tunnel rather than hidden resurrection.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **ObserveLane** — read-only live output, status, query answers, or follow streams
- **AttachLane** — interactive attachment to an existing live surface with stdin/tty semantics
- **ControlLane** — explicit control-message or control-protocol interaction that may change live state without being a transcript stream
- **ExecOrDebugLane** — injected command/debug surface distinct from the existing live process/session
- **SidebandLane** — forwarded port/proxy/tunnel or similar auxiliary access path
- **LiveSessionReceipt** — durable history saying whether the user observed, attached, sent control, spawned debug exec, opened a sideband, detached, or only retained a transcript

The names can change.
The split should stay.

## One more shell-truth split inside attach
Even inside `attach`, one more seam matters:
**live process handle ≠ stdio/PTY stream lane ≠ controlling-terminal posture ≠ current foreground-turn / interrupt-target ≠ durable transcript/history**.

Classic job control already makes this visible: a job can be running without owning the foreground turn, a stream can be mirrored without becoming the controlling terminal, and terminal-generated signals go to the current foreground process group rather than to every process whose output happens to be visible.

ViewFS should steal that honesty without overcommitting to POSIX internals. A future shell should be able to say `observe only`, `stdin live`, `pty attached`, `controlling tty`, `foreground now`, `backgrounded`, or `history only` as different truths.

## Shell consequences
The custom shell gets much better if it can admit:
- **follow tails** — stream output or query state without implying stdin or mutation
- **attach rails** — attach read-only or interactive to an existing live surface
- **control panes** — send typed control messages or updates without pretending they are logs or a shell
- **debug launch drawers** — spawn a new command or debug shell with loud provenance
- **sideband badges** — show forwarded ports/proxies/tunnels as separate lanes with separate lifetimes
- **live-session receipts** — preserve whether the user watched, attached, controlled, tunneled, or executed debug code

That is the right way to make a shell feel ambitious without letting live-session delight collapse into hidden ambient control.

## What not to decide yet
- the final wire schema for ObserveLane / AttachLane / ControlLane / SidebandLane,
- whether control-message lanes and synchronous update lanes share one envelope or only one UI family,
- whether read-only attach is always a subtype of attach or a sibling of observe,
- whether sideband lanes are always provider-owned tunnels or can be local relays,
- whether debug/exec lanes always create fresh child views or sometimes reuse existing live state.
