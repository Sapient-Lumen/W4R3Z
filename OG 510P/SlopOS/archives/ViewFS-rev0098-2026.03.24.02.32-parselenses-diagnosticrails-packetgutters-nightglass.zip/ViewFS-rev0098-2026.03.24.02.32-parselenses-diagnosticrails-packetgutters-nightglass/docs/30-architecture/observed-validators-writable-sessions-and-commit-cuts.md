# Observed validators, writable sessions, write holds, commit preconditions, and committed versions

ViewFS should not let one edit/save story answer six different questions at once:
- **what exact version did I observe when I started?**
- **what private writable draft or session am I editing in now?**
- **is there any current coordination hold or lock?**
- **what exact condition will this commit test?**
- **what version actually became durable if the commit wins?**
- **what remains only as history or receipt?**

Those truths interact, but they are not the same thing.

## Why this split matters

Object-store systems, document APIs, and shell UX all drift toward one magical `save` fiction.
That is exactly where they get spooky:
- one stale validator token is treated like current authority,
- one local swap file is treated like a shared reservation,
- one lease or lock is treated like proof that the base still matches,
- one local close/flush event is treated like proof of committed durable state,
- and one old transcript row is treated like a resumable draft.

The safer move is to keep at least six classes separate:

1. **observed validator / expected base**
   - exact state the user or tool observed before preparing a change.
   - examples: ETag, generation, resource version, mod-revision, digest.
   - useful for honest compare-before-commit.
   - not a draft.

2. **private writable session / draft**
   - one local editing or staging lane.
   - may be a temp copy, swap object, buffered stream, or sealed draft.
   - useful for editing.
   - not current shared truth.

3. **live write hold / lease / lock token**
   - one coordination artifact that may prefer or restrict writers.
   - may expire or vanish.
   - useful for serialized workflows.
   - not identical to the exact commit predicate.

4. **commit precondition**
   - exact gate attached to one mutation attempt.
   - examples: `if current validator == X`, `if absent`, `if hold token matches Y`.
   - useful for compare-and-swap.
   - not the committed outcome.

5. **committed version / generation / head**
   - the durable target state after one accepted mutation.
   - the only thing that should count as the post-commit truth.
   - different from the draft session that produced it.

6. **receipt / history**
   - evidence that any of the above existed or happened.
   - useful for explanation and audit.
   - not current write state.

## Lessons worth stealing

### Conditional mutation beats ambient overwrite
HTTP conditional requests are still one of the clearest precedents.
A mutation can be guarded by an exact validator with `If-Match` or by existence with `If-None-Match`.
That keeps read basis and commit act explicit.
It is a strong argument for ViewFS to expose guarded-write seams instead of ambient `save latest` behavior.

### Object stores can support safe read-modify-write
Cloud Storage is a good reminder that object stores are not forced into blind last-writer-wins.
Generation and metageneration preconditions let a request succeed only if the object is still in the expected state.
That is a useful precedent for ViewFS object/store mutations even if the final validator vocabulary stays open.

### Compare-and-swap transactions stay smaller than global locking
etcd shows the compact shape nicely: one atomic If/Then/Else transaction can protect keys from unintended concurrent updates and serve as a compare-and-swap primitive.
That is a much smaller commitment than building a giant mandatory lock manager before the mutation model is even stable.

### Coordination holds are useful but narrower than commit truth
WebDAV locking is a good caution.
Locks have tokens, can be refreshed, can carry timeouts, and can still disappear or conflict.
That makes them useful coordination aids, but they still are not the same thing as exact observed base, exact commit predicate, or durable committed head.

### Local writable sessions are their own class
The File System Access API is a nice reminder that one writable session can have its own staging semantics.
`createWritable()` can keep existing data or start empty, and browsers may expose `exclusive` versus `siloed` writer modes.
That is a strong precedent for keeping private draft sessions and coordination holds on different seams.

## Working posture for ViewFS

- keep observed validators inspectable and copyable as basis artifacts, not as current authority;
- keep private writable sessions local and obviously draft-like until an explicit commit succeeds;
- keep write holds narrow, inspectable, and easy to expire or drop;
- keep every commit attempt explicit about which base or existence predicate it depends on;
- keep committed-version truth separate from local close/flush folklore;
- keep receipts/history useful without allowing them to silently revive drafts or holds.

## SlopOS / datacube reading of this split

This maps well onto the current SlopOS drafts because SlopOS already distinguishes exact local witness material, validator-local preconditions, and durable commit stories.
The thing to steal is not a finished CapStore transaction ABI.
It is the discipline that:
- one observed validator is not a writable session,
- one writable session is not a hold,
- one hold is not the exact commit predicate,
- one accepted commit is not just `the draft closed`,
- and one receipt is not a live resume surface.

That reading fits particularly well with `acp-precondition-witness-posture-v0.md` and `capstore-commit-schema-v0.md` in the current SlopOS archive.
The former insists on exact local witness gates rather than ambient `latest` queries.
The latter keeps durable commit/update meaning explicit instead of folding it into mutable session folklore.

## Shell product ideas

### Stale-base lamps
An editor or object pane should be able to show:
- `based on validator X`
- `target moved to validator Y`
- `basis unknown`
- `history only`

without pretending those lights grant any write right.

### Draft gutters
A shell should be able to say:
- `private draft`
- `sealed for commit`
- `draft diverged from durable head`
- `draft orphaned`
- `history only`

That makes multi-tab or multi-tool editing much less spooky.

### Commit shutters
One save menu should be replaced by explicit ladders like:
- `commit if base still matches`
- `create if absent`
- `commit under current hold`
- `rebase draft to current head`
- `fork new object instead`
- `open commit receipt`

### Hold meters
If a coordination hold exists, the shell should say:
- `exclusive`
- `advisory`
- `expired`
- `uncertain`
- `none`

and keep that distinct from stale-base truth.

## What not to decide yet

Do not decide yet:
- one universal validator shape for every provider and object family;
- whether ViewFS prefers digest, generation, epoch, or revision counters everywhere;
- whether write holds are mandatory anywhere in Phase 1;
- whether draft sessions are shell-owned, provider-owned, or runtime-owned on every backend;
- whether multi-object atomic commit exists in Phase 1.

Freeze the separation first.
