# Workspace grants and rebinding notes

Purpose: keep **workspace/tree grants** distinct from single-object open, transfer, durable reopen, and generic URI launch.

ViewFS will almost certainly need a way to say “bind this chosen directory or object set into my working view” without pretending that every open, recent item, or external URI is the same thing. The risk is semantic collapse: once “open folder”, “recent file”, “drag/drop”, and “open URI” all look like one generic action, authority becomes hard to inspect and harder to keep narrow.

## Useful precedents
- REF-ANDROID-SAF: a user can grant access to a selected document tree, which is stronger than a single file open but still narrower than ambient storage.
- REF-XDG-FILECHOOSER and REF-XDG-DOCUMENTS: chooser-selected files may become accessible across sessions through a restricted view.
- REF-XDG-FILETRANSFER: transfer sessions are mediated and intentionally not durable across sessions.
- REF-XDG-OPENURI: opening a URI is a launch/routing action, not a local-object grant.
- REF-FUCHSIA-DICTCAP: grouped capabilities can be routed explicitly as a nested key/value bundle rather than hidden ambient inheritance.

## Distinctions worth preserving

### 1. Workspace/tree grant is not the same as single-object open
A workspace grant is stronger than “let me inspect this one object now”.
It should normally bind a directory/tree or explicit object bundle into a view slot and make that binding transcript-visible.

### 2. Workspace/tree grant is not the same as transfer
Drag/drop or clipboard exchange is about a bounded handoff between tools.
A workspace grant is about shaping the recipient's ongoing working view.
Those should not silently upgrade into each other.

### 3. Workspace/tree grant is not the same as durable reopen
“Open this again later” is about a user-facing recent/reopen story.
“Bind this into my workspace view” is about process/workflow environment construction.
A system may derive both from one chooser flow, but the resulting authorities should remain distinguishable.

### 4. Workspace/tree grant is not the same as URI launch
Opening `https:` or “reveal in external app” is routing to another handler under user control.
That does not by itself grant the requester durable local-object authority, and it should not be encoded as though it did.

### 5. Workspace/tree grant is not the same as mutable head semantics
A workspace binding may point at an immutable directory object, a mutable working head, or a view that can be refreshed later.
Those should remain separate design choices.

## Shape that feels promising
A workspace grant receipt probably needs to say:
- target kind: `directory`, `object_bundle`, or `view_fragment`
- rights summary
- durability class
- whether rebinding is allowed
- which view slot(s) were affected
- whether the grant came from chooser, transfer promotion, durable reopen, or explicit workflow construction

That gives the shell enough truth to explain why a pane sees what it sees.

## Rebinding should be explicit
ViewFS should likely support a visible **rebind** action:
- rebind slot to newer chosen object
- attach a new workspace tree to a spare slot
- drop an old workspace grant
- replay the same command against a fresh temp workspace

The important part is not the exact API surface yet. The important part is that rebinding is an explicit event with a receipt, not a background mutation hidden behind a path string.

## Nifty ideas worth stealing
- **Open directory as workspace** from REF-ANDROID-SAF, but transcript it as a view bind instead of generic storage permission.
- **Restricted synthetic views** from REF-XDG-DOCUMENTS, but keep the view local and explicit instead of pretending `/run/user/.../doc` is the design center.
- **Capability dictionaries** from REF-FUCHSIA-DICTCAP for multi-root workspaces such as `{src, data, out}`.
- **Transfer-to-workspace promotion** as an explicit upgrade path: a short-lived transfer receipt can be promoted into a bound workspace slot only with visible consent.

## What not to decide yet
- whether a workspace grant is one handle, a bundle/dictionary, or a view fragment
- whether durable workspace grants require stable provider IDs, local revalidation, or both
- whether rebinding happens in the shell, a launcher, or a dedicated view service
- whether mutable workspace heads exist in Phase 1 or only later spikes

## Near-term recommendation
For the next prototype, treat workspace grants as:
1. explicit receipt-bearing binds into a process view,
2. stronger than single open/import,
3. weaker and more inspectable than ambient home-directory access,
4. distinct from recent-item reopen,
5. and completely separate from generic URI launch.
