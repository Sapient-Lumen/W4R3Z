# Discoverability, enumeration, exact-name reachability, and fit notes

Purpose: keep **direct current authority**, **exact-name reachability inside a held root/view**, **enumeration/listability**, **mediated suggestion or fit notes**, and **historical receipts** on distinct seams.

Capability-native systems get safer and calmer when they avoid over-disclosure.
The next low-regret move for ViewFS is to stop treating `I can browse it`, `I can open it if I already know the name`, and `someone suggested it` as the same truth.

## Useful precedents
- **REF-LINUX-ACCESS**: path lookup depends on search permission on each prefix directory; this is already a warning that exact-name reachability is not identical to reading contents.
- **REF-WASI-P1-RIGHTS**: `RIGHTS_FD_READDIR` and `RIGHTS_PATH_OPEN` are distinct rights, so enumeration and exact child open are deliberately separate surfaces.
- **REF-FUCHSIA-CAPS** and **REF-FUCHSIA-DIR-CAPS**: capabilities combine a resource with rights and are surfaced through the component namespace, which is exactly the kind of explicit right-bearing discoverability ViewFS should imitate.
- **REF-SANDSTORM-POWERBOX**: mediation can rank matches and describe fit without pretending that every candidate is a current local binding.
- **REF-PLAN9-IMPORT**: imported namespace fragments are explicit locality changes, not proof that every visible path string is machine-global browse truth.

## Distinctions worth preserving

### 1. Direct current authority is the strongest truth
If an actor already holds a live handle, that is the strongest and cleanest truth.
The shell should say `opened via handle` or `acted through live authority`, not launder it through browse chrome.

### 2. Exact-name reachability is narrower than browse authority
A process may be able to attempt `open("child")` under a held root or preopen even when it cannot freely enumerate the container.
That is useful.
It is also narrower than browse power because it leaks less metadata.
ViewFS should keep `known child name` distinct from `list this directory`.

### 3. Enumeration/listability is a disclosure surface in its own right
Listing names, sizes, timestamps, or child classes is not just a prettier version of exact open.
It is a stronger metadata surface.
That means enumeration should stay separately grantable, deniable, and receipted instead of falling out of any ability to open by name.

### 4. Fit notes and suggestions are advisory, not authority
Powerbox-like mediation, shell suggestions, search results, and portal candidate lists are valuable.
But they are advisory scope/explanation surfaces:
- `likely match`,
- `preferred`,
- `advanced option`,
- `might work`,
- `history only`,
- `needs portal`,
- `exact name required`.

Those are not current authority.
They should stay visibly advisory.

### 5. Receipts matter because discoverability is easy to misremember
Users remember `I saw it in the UI` and forget whether that meant:
- I had the handle already,
- I knew one exact child name,
- I could browse the container,
- or a helper merely suggested it.

Receipts and explain drawers are the antidote.

## Shape that feels promising
ViewFS probably wants truth labels like:
- **HandleOnly** — direct live authority already held
- **KnownNameOpen** — exact-name open inside a held root/view
- **BrowseGrant** — explicit enumeration/listability rights
- **SuggestedOnly** — search/chooser/powerbox/helper candidate without current authority
- **ReceiptOnly** — history/explanation without present authority

The exact encoding can wait.
The split should not.

## Nifty ideas worth stealing
- **Dark directories**: containers where exact child names can be tried but listing is unavailable or policy-gated.
- **Known-name chips**: transcript-visible tokens that say `opened by exact name under root R`, not `was browse-visible`.
- **Browse gates**: explicit affordances for `request listing`, `stay exact-name only`, or `ask mediator for candidates`.
- **Fit sheets**: chooser/suggestion drawers that say why an item was suggested, what confidence/quality class it has, and what stronger step is still needed.
- **History dimming**: old search hits and receipts should stay visibly `seen before`, not `openable now`.

## What not to decide yet
- one final distinction between `lookup`, `stat`, `enumerate`, and `search` across every provider;
- whether search/index results come from shell-owned caches, portal providers, or lower-level services;
- whether exact-name reachability is exposed to apps directly or mostly through compat/runtime helpers;
- whether browse authority and metadata richness use one lattice or several small ones.

## Near-term recommendation
For the next narrow spikes:
1. keep exact-name open truth separate from browse truth,
2. let enumeration be a separately inspectable disclosure surface,
3. treat suggestions and fit notes as advisory only,
4. receipt which truth actually held,
5. and make the shell compare these lanes honestly instead of flattening them into one fake explorer/open story.
