# Requests, candidate sets, selections, grants, and live binds

Purpose: keep **portal/powerbox request objects**, **candidate/designation surfaces**, **selected outcomes**, **minted grants/refs**, **live view binds**, and **historical receipts** on distinct seams.

Portal-heavy systems often drift toward a comforting fiction:
the thing you “picked”, the thing the chooser briefly showed you, the grant that got minted, the live bind that entered your process, and the history row that remembers it all start to look like one generic “opened object”.

That shortcut is attractive and dangerous.
It hides where authority actually came from, encourages ambient inventory leaks, and makes shell history lie.

## Useful precedents
- **REF-XDG-REQUEST** and **REF-XDG-PORTAL-DESIGN**: portal interactions are modeled as long-running request objects with eventual responses, not as one synchronous magical open.
- **REF-XDG-FILECHOOSER**: the chooser asks for access and may make selected files accessible, potentially through the Documents portal and across sessions.
- **REF-XDG-DOCUMENTS**: exported files appear through a restricted synthetic view keyed by document IDs; adds can be session-only or persistent, and the caller proves access with an open file descriptor.
- **REF-ANDROID-SAF**: providers advertise which operations they support, persistence is explicit via `takePersistableUriPermission()`, and access can still fail if the target moves or is deleted.
- **REF-FUCHSIA-SANDBOXING** and **REF-FUCHSIA-NAMESPACE**: the more-authoritative creator assembles the child namespace rather than letting the child rediscover the world ambiently.

## Distinctions worth preserving

### 1. Request object is not candidate set
A **request** records that an interaction is in flight:
- open/import,
- bind-tree,
- save/export destination selection,
- durable-upgrade,
- or some related mediation act.

A **candidate set** is the bounded universe the chooser/provider is willing to show for that request.

Why this matters:
- request lifecycle (`pending`, `cancelled`, `completed`, `timed out`) is not the same thing as what candidates were visible.
- many good powerbox/portal designs keep the candidate universe chooser-owned rather than caller-owned.

### 2. Candidate set is not selection
A **candidate** is “one thing the mediator could offer”.
A **selection** is “what the user actually chose”.

Why this matters:
- enumerability is a security surface.
- the app often should learn only the selection/result, not the full inventory the chooser searched through.

### 3. Selection is not minted grant
A **selection record** says which object or destination the user chose.
A **minted grant** says what authority shape was actually issued:
- ephemeral open/import,
- one-shot save destination,
- transfer retrieval right,
- durable reopen ref,
- or only receipt/history.

Why this matters:
- the same selection might yield different authority classes depending on policy, provider support, or user choice.
- “you picked it” should not automatically mean “you can keep reopening it forever”.

### 4. Minted grant is not live bind
A **minted grant** is eligible authority.
A **live bind** is concrete authority installed into a specific process view, pane, or child launch kit.

Why this matters:
- a grant may remain unused, may be routed elsewhere, or may be transformed into a launch-only kit.
- shell panes need to explain `selected`, `granted`, and `bound here now` as different states.

### 5. Live bind is not durable memory
A **live bind** is current authority.
A **receipt/history row** is memory about the interaction.
A **durable ref** is a bounded reopen descriptor.

Why this matters:
- copied transcripts should usually preserve receipts and maybe refs, not silently transplant live binds.
- recents/history should help reopen or rebind, not pretend to be current authority.

### 6. Provider-supported operations are not rights already held
A chooser/provider may advertise:
- readable,
- writable,
- movable,
- thumbnailable,
- revealable,
- or durable-upgradable.

That advertisement is not itself a current right in the caller.

Why this matters:
- route sheets and shell actions should be filtered by provider support,
- but they still need a concrete result/grant/bind step before acting.

## Shape that feels promising
ViewFS probably wants distinct families such as:
- **ImportRequest** — the interaction object and its state
- **CandidateDescriptor** — chooser-owned/provider-owned candidate metadata, often not durable outside the interaction
- **SelectionRecord** — what the user actually designated
- **ImportGrant** — the issued ephemeral or durable authority outcome
- **DurableReopenRef** — explicit reopen memory, not a live bind
- **ViewBindReceipt** — proof that some grant/ref/object entered a concrete view
- **ImportReceipt** — audit/history record of the interaction

Exact schemas can wait. The class split should not.

## Nifty ideas worth stealing
- **Chooser-owned candidate sheets**: let the mediator own search, filtering, and candidate enumeration rather than exposing generic machine inventory to the caller.
- **Request chips**: surface in-flight portal requests in the shell as explicit chips/cards with `pending`, `cancelled`, or `completed` state.
- **Staging before bind**: selected results can land in a staging tray first, where the user chooses `bind here`, `launch with`, `save durable reopen`, or `receipt only`.
- **Ops-aware route sheets**: route only actions the provider says are supported, instead of showing fake universal affordances.
- **Late durable upgrade**: default to ephemeral import, then offer a deliberate `keep for later` upgrade path rather than silently persisting every open.

## What not to decide yet
- whether candidate descriptors ever escape the mediator at all
- whether selection records are durable outside receipts
- whether every import flow gets an explicit staging step or only some shell/front-end experiences
- whether durable upgrade is a separate portal call, a second receipt, or a policy bit on import
- whether bind happens automatically for some narrow flows or is always a second explicit act

## Near-term recommendation
For the next narrow spikes:
1. keep **request**, **candidate**, **selection**, **grant/ref**, **live bind**, and **receipt** as explicit vocabulary,
2. default to **chooser-owned candidate sets** instead of caller-visible inventory,
3. make durable upgrade explicit and inspectable,
4. teach the shell to show `selected`, `granted`, `bound here`, `reopenable`, and `receipt only` as different states,
5. and prototype one **staging-tray** flow before freezing any final import/result schema.

### 6. Request handle is not session/transfer object or current portal-owned state
A **request handle** says one chooser/powerbox/background/configuration interaction exists or existed.
A **session handle** or **transfer key** says one longer-lived portal-side object exists.
A **portal-owned current state** says whether that object is still open, active, closing, listed, or otherwise live inside the mediator.
None of those is automatically one **local adopted bind** in the current pane.

Why this matters:
- request history is valuable even after the session/transfer it created is gone.
- sessions and transfer objects may outlive the initial dialog and may emit later state changes.
- the shell should be able to say `request succeeded`, `session closed by portal`, or `adopted here` as different truths.

## Extra near-term recommendation
- keep **request ledgers** and **session cards** visible as separate shells surfaces.
- allow one pane to inspect portal-owned current state without claiming that it has already re-adopted the result locally.
- let repair flows start from the right seam: `retry request`, `rejoin/open session`, `retrieve transfer`, or `adopt here again`.
