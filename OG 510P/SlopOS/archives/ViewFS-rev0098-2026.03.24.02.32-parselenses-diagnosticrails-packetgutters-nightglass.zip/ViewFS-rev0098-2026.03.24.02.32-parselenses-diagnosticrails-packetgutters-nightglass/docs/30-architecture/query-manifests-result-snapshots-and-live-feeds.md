# Query manifests, result snapshots, and live feeds should stay on separate seams

Purpose: keep ViewFS smart queries and smart-folder UX **powerful and legible** without letting a saved search, a current result set, or a live update subscription quietly turn into hidden authority.

## Core rule
ViewFS should distinguish at least six things:
- **query manifest** — a saved, shell-owned query definition plus an explicit view binding and presentation hints,
- **result snapshot** — the set of matches returned at one evaluation moment,
- **live feed** — advisory entered/left/changed notifications relative to a query/view pair,
- **selector / smart-folder surface** — a folder-like or palette-like shell presentation over a manifest or snapshot,
- **index policy / extractor state** — what metadata may be indexed, where, and under what bounded extraction rules,
- **live authority** — the handles or bindings that the current view already possesses.

These are related. They are not the same object.

## Why this matters
History keeps offering attractive “smart folder” experiences:
- background indexes,
- saved searches,
- live query subscriptions,
- grouped result views,
- metadata-rich file organizers.

The trap is to collapse all of them into one magical object that somehow means:
- the query definition,
- the latest result set,
- the standing background watcher,
- the UI folder,
- and the authority to act on every match.

That collapse is exactly what ViewFS should avoid.

## Useful precedents
- **REF-APPLE-NSMETADATAQUERY**: Apple explicitly separates an initial gathering phase from a later live-update phase, and exposes explicit `disableUpdates` / `enableUpdates` control while the client inspects results.
- **REF-APPLE-SMARTFOLDERS**: Finder Smart Folders are saved criteria that automatically collect items matching those criteria; the saved object is not itself the matching files.
- **REF-WIN-SEARCH-MS**: Windows Search Folder uses a saved XML file format that stores the query for the search subsystem; the file is a query object, not the materialized results.
- **REF-GNOME-TRACKER**: Tracker powers search and app discovery through a shared background index, which is useful but also a classic ambient-inventory cautionary tale.
- **REF-GNOME-LOCALSEARCH**: indexing policy is explicit and persists across restarts; extraction/index scope should be treated as its own seam.
- **REF-APPLE-SPOTLIGHT-QUERYGUIDE**: result batches and live notifications are distinct, and applications may pause updates while working with the current results.

## Recommended ViewFS reading of the split

### 1. A query manifest is a recipe, not a live directory handle
A persistent saved query should contain things like:
- query digest / schema digest,
- explicit bound view or view-class reference,
- sort/group/presentation hints,
- shell-local labels or pins,
- optional notes about index requirements.

It should **not** itself count as:
- a result snapshot,
- a standing background watcher,
- or live authority over future matches.

### 2. A result snapshot is a freeze-frame
Evaluating a query against a view should yield a **snapshot-first** result set.
That snapshot may be:
- inspected,
- diffed against later runs,
- pinned into a notebook/journal block,
- or promoted into a compare surface.

The snapshot should not quietly mutate underneath the user unless the shell is explicitly showing a live-feed mode.

### 3. A live feed is advisory and bounded
If ViewFS later supports live query refresh, it should model that as a separate **feed/subscription** object or mode.
That feed should be:
- scoped to the view/query pair,
- lossy/rebuild-friendly when necessary,
- explicit about health and overflow,
- easy to pause/freeze while the user inspects a result set.

The Apple `disableUpdates` / `enableUpdates` idea is especially worth stealing here.

### 4. Smart-folder UI should preserve provenance
A folder-like UI surface may be backed by:
- a query manifest,
- a current snapshot,
- a live feed,
- or a shell-local pin to one of those.

The shell should keep those classes visible with status like:
- `saved query`,
- `snapshot`,
- `live`,
- `frozen`,
- `stale`,
- `re-run needed`,
- `index debt`.

### 5. Index scope and extraction policy stay separate from query meaning
It is fine for a query to depend on indexed metadata.
It is **not** fine for “this query exists” to silently imply:
- ambient indexing everywhere,
- persistent extractor daemons owned by arbitrary apps,
- or content-derived search over bytes that the current policy would otherwise treat as preview-only or quarantined.

### 6. Query results do not widen authority
Matches should be handles already reachable through the bound view, or candidates for a separate reopen/rebind/portal path if the surface is advisory-only.
Search success should not become a backdoor grant.

## A promising future object family
Without standardizing schema now, ViewFS may eventually want:
- **QueryManifest** — saved query definition + view binding + presentation hints,
- **ResultSnapshot** — frozen handle set plus evaluation metadata,
- **LiveQueryFeed** — advisory entered/left/changed updates,
- **QueryPin** — shell-local sidebar/palette/bookmark pin to a manifest or snapshot,
- **MatchReceipt** — transcript-visible evidence that a query run occurred and what it returned at that moment.

The posture is that these stay different classes, even if one UX surface can move fluidly between them.

## How this maps onto SlopOS seams
- **snapshot-first query against explicit view** ↔ `attrfs-posture-v0.md`
- **closed query AST / bounded predicates** ↔ `attribute-query-schema-v0.md`
- **saved-query persistence stays shell-owned** ↔ `attrfs-posture-v0.md` section 5
- **live updates remain optional and bounded** ↔ `attrfs-posture-v0.md` section 4
- **result rows / selector states remain advisory** ↔ `openuri-recent-items-boundary-v0.md`, `document-handle-schema-v0.md`, `explain-posture-v0.md`

SlopOS already has the right design instinct here. ViewFS should sharpen it, not blur it.

## Shell implications
- smart folders should be explainable as query manifests and/or snapshots
- result panes should support **freeze**, **thaw**, **re-run**, and **diff since last run**
- “why did this match?” should be answerable without opening the file
- live feeds should admit `paused`, `overflow`, `rebuild required`, or `index unavailable`
- transcript blocks should preserve query digest, view, and result-set summary without smuggling live authority

## Anti-goals
- a saved query object that secretly owns a daemon or hidden standing subscription
- a smart folder that silently shifts from snapshot to live mode without saying so
- search hits that count as authority simply because an index found them
- background indexing that quietly escapes the bound-view story
