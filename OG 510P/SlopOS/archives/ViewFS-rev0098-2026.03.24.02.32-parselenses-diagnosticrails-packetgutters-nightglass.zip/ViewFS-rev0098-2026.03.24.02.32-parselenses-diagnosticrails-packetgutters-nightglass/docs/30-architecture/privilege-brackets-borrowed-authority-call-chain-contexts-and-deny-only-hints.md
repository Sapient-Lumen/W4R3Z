# Privilege brackets, borrowed authority, call-chain contexts, deny-only hints, and receipts

This note sharpens one more low-regret ViewFS separation:
**privilege bracket**, **borrowed authority**, **call-chain context**, **deny-only routing hint**, and **durable receipt/history** are different truths.

Relevant precedents:
- **REF-CONFUSED-DEPUTY-HARDY**: the classic confused deputy appears when one tool carries authority from two masters and cannot keep them apart.
- **REF-JEP506-SCOPEDVALUES** and **REF-JAVA-SCOPEDVALUE-API**: bounded dynamic scope and `ScopedValue` bindings make one-way caller-to-callee dataflow explicit and automatically unwound.
- **REF-PY-CONTEXTVARS**: context-local state is meant to prevent state from bleeding unexpectedly in concurrent code.
- **REF-NODE-ASYNCLOCALSTORAGE**: `run()` gives bounded async context, `exit()` temporarily leaves it, and Node explicitly warns that `run()` should be preferred over `enterWith()`.
- **REF-ASPNET-HTTPCONTEXTACCESSOR**: ambient async-local request context is useful, but Microsoft warns it should be used with caution because it creates a dependency on ambient state.
- **SlopOS RFC-0118**: privilege brackets plus bounded non-authoritative call-chain descriptors are already the right native pressure nearby.

## Why the split matters

The future custom shell is going to have helpers, plugins, route sheets, notebook cells, portal relays, and automation blocks.
That only stays honest if it can answer at least five different questions:
- is a helper inside one explicit privileged bracket right now?
- what exact authority is being borrowed?
- who asked for the action?
- did caller/plugin provenance merely veto one path, or did authority actually change?
- what is only durable history now?

Those questions differ because the consequences differ.
A privilege bracket is an execution posture.
Borrowed authority is real current capability.
Call-chain context is explanation.
A deny-only hint is narrowing/veto input.
A receipt is aftermath.

## Working posture

### Privilege brackets should be explicit and bounded
ViewFS should prefer explicit bracketed helper execution over hidden process-wide or task-wide mode switches.
A bracket should begin for one operation or one tight block and end automatically.
It should be easy to inspect and hard to confuse with a durable permission change.

### Borrowed authority should stay visible as authority
If a helper is acting for a caller, the shell should be able to show which handles are being borrowed or exercised.
That is stronger truth than merely saying `requested by pane X`.
The helper may still have its own standing tools, but the borrowed set should remain separately visible.

### Call-chain context should stay bounded and non-authoritative
Caller, pane, block, helper, or plugin provenance is very useful for audit/debug and for deny-only gating.
It should still stay one explanatory surface rather than a grant.
This is the right place for `who asked?`, `through which helper?`, and `which pane/plugin path?` truth.

### Deny-only hints should narrow without widening
There is real product value in saying:
- `deny if untrusted helper is in the chain`,
- `deny if one preview pane initiated a destructive route`,
- `re-consent if one plugin-origin frame is present`.

That is useful precisely because it is **deny-only**.
ViewFS should resist any move where call provenance silently manufactures new authority.

### Receipts should preserve explanation without reviving it
A receipt can say which bracket existed, what borrowed authority was in play, which caller frames were present, and whether a deny-only veto fired.
It should not silently revive bracket state or caller-local context later.

## Shell and terminal payoffs

A truthful shell can turn this split into product leverage:
- **bracket rails** that show when a helper is inside one current borrowed-authority region;
- **caller badges** and **call-frame chips** that answer `who asked?` inline in transcript blocks;
- **borrowed-authority drawers** that show exact handles or exact capability classes being exercised;
- **deputy fog warnings** when a helper would fall back to ambient helper state or global singleton state;
- **deny-only shutters** that explain why one route was vetoed by provenance instead of by missing authority;
- **receipt cards** that preserve the whole explanation after execution ends.

## Classification worth standardizing early

A useful posture-oriented classification for shell UX and protocol experiments is:
- `bracket_none`
- `bracket_active`
- `borrowed_authority_active`
- `call_context_only`
- `deny_only_hint_present`
- `deny_only_veto_fired`
- `receipt_only`

This is intentionally posture-oriented.
It does **not** decide one final task-local API, one final call-frame schema, or one final deny-only rule language.

## What not to freeze yet

Do **not** freeze yet:
- one final call-chain frame taxonomy,
- whether call-chain frames ever cross machine or user boundaries,
- whether bracket state is language-runtime-local, shell-local, or lower-level,
- whether deny-only hints are standardized beyond a tiny starter family,
- or whether borrowed-authority drawers name exact handles versus exact capability classes in every UI.

The separation is worth freezing now.
The carrier and schema details are not.
