# Resources, prompts, tools, apps, and bindings

Purpose: keep the next helper-feature seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough helper/session/shell ambition that we need one more anti-collapse boundary:
**resource descriptor ≠ prompt template ≠ tool descriptor ≠ interactive app surface ≠ completion suggestion ≠ request-bound attachment/selection ≠ live invocation/result ≠ durable receipt/history**.

That split is the safest way to let the shell expose rich helper catalogs **without letting “available in the helper” quietly mean “already attached to this request”, “already executed”, or “safe to replay forever.”**

## Why this seam matters now
SlopOS already points this way:
- `rfcs/0115-capability-safe-shell-and-automation.md` keeps automation explicit-only at startup and treats effect contracts as real seams.
- `rfcs/0117-plumb-messages-and-cli-intents.md` keeps intent envelopes non-authoritative and refuses to smuggle raw capabilities through workflow glue.
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md` keeps user designation and current issuance concentrated in a mediator instead of generic helper folklore.
- `docs/30-architecture/authagent-provider-role-boundary-v0.md` keeps provider/agent surfaces role-distinct from the underlying authority.
- `docs/30-architecture/powerbox-posture-v0.md` already refuses generic remembered-grant inventories and broad hidden approval surfaces.

ViewFS should preserve that posture in future helper catalogs instead of creating a softer second story where:
- a resource URI looks like an already-attached current request input,
- a prompt template looks like an already-adopted workflow,
- a visible tool descriptor looks like an already-approved invocation,
- an interactive app surface looks like a plain route target with no extra session semantics,
- or a completion suggestion looks like current authority instead of only a hint.

## Lessons we must learn from the past

### 1. Resources, prompts, and tools are different feature classes
The current MCP specification is unusually crisp here:
- **resources** are context/data exposed by a server;
- **prompts** are templated messages/workflows;
- **tools** are invocable functions.
VS Code’s current MCP docs add a fourth practical product class: **interactive apps**.

Why this matters:
- ViewFS should not let one generic “helper item” class pretend those four things are identical;
- resource browsing, prompt retrieval, tool invocation, and app launching answer different questions and deserve different receipts;
- a future shell can still unify browsing UX without flattening the semantic classes.

### 2. Completion suggestions are not the same as bindings or authority
The MCP completion utility is a great warning sign. It offers autocomplete only for **prompt arguments** and **resource templates**, and the spec explicitly warns that implementations must validate inputs, rate-limit requests, control access to sensitive suggestions, and prevent completion-based information disclosure.

Why this matters:
- ViewFS should keep completion/advice surfaces distinct from current request bindings or live authority;
- completions can be wonderfully helpful without implying “you already have this”;
- replay history should not silently turn old completions into current bound inputs.

### 3. Request-bound selection is different from catalog presence
Current VS Code agent tooling keeps tool enablement per request, and prompt files can specify which tools are available for a prompt, including whole-server wildcards.

Why this matters:
- ViewFS should keep visible helper catalogs distinct from the subset actually bound to one request, pane, or run;
- a prompt template that mentions tools is still not the same thing as a completed invocation;
- a helper can expose many resources/prompts/tools/apps without all of them counting as current active inputs.

### 4. Live invocation and durable history are stronger than mere feature presence
Current VS Code tooling shows detailed tool calls in chat and allows approvals around tool use. That is a useful reminder that “what the helper offers”, “what this request bound”, and “what actually executed” should remain different truths.

Why this matters:
- ViewFS should keep invocation/result objects distinct from catalogs and bindings;
- durable receipts should say whether something was only browsed, attached, rendered, invoked, denied, or merely suggested;
- shell replay should be able to strip or rebind feature usage instead of pretending every prior helper interaction is safely rerunnable.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **ResourceDescriptor** — context/data surface with identity and provenance, not a current binding by itself
- **PromptTemplate** — templated workflow/message surface with arguments and provenance, not an adopted workflow by itself
- **ToolDescriptor** — invocable function surface with schema and approval posture, not a completed call by itself
- **AppSurface** — interactive helper UI/session entry point, not the same thing as a tool call or resource view
- **CompletionSuggestion** — ranked hint for prompt/resource arguments, not current authority
- **RequestBinding** — what this pane/request/run actually attached or enabled from the catalog
- **InvocationRecord** — what actually ran or rendered now, with result class and approval basis
- **FeatureReceipt** — durable history saying what was only browsed, attached, suggested, invoked, denied, or historical-only

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **resource shelves** — browseable context/data surfaces that are not yet bound
- **prompt chips** — templated workflow/message surfaces with visible argument slots and provenance
- **tool racks** — request-bound invocable functions, separate from mere catalog presence
- **app docks** — interactive helper surfaces with visible session ownership and lane
- **completion popovers** — clearly advisory suggestions for prompt/resource arguments
- **binding trays** — the exact subset currently attached to this request or pane
- **invocation receipts** — whether something was browsed, attached, rendered, invoked, denied, or replayed with stripping

That is the right way to make a shell feel ambitious without letting one helper catalog quietly become current authority.

## What not to decide yet
- the final helper feature taxonomy beyond the anti-collapse rule,
- whether interactive apps are first-class ViewFS objects or route/provider surfaces only,
- whether request bindings are pane-bound, run-bound, or prompt-bound by default,
- the final schema for resource/prompt/tool/app descriptors, completion items, binding sets, or invocation receipts,
- whether prompt templates may ever promote directly into user-owned workflows without an explicit promotion seam.
