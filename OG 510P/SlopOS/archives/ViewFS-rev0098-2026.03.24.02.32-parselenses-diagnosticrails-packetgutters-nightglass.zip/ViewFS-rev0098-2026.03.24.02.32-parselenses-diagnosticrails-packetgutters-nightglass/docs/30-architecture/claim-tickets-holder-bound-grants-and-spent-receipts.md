# Claim tickets, holder-bound grants, passable live handles, and spent receipts

History keeps offering another tempting lie:
if some compact object might later recover access, UIs start treating that object as if it were already a current reusable handle.

That lie gets especially dangerous in a design like ViewFS where we want:
- a brand-new object store,
- capability handles,
- explicit per-process namespaces,
- portal-mediated imports,
- and a custom shell that tells the truth about what can really happen next.

Useful precedents point the other way:
- **REF-RFC6749-AUTHCODE**: OAuth authorization codes are intentionally short-lived, single-use, and bound to a client/redirection context.
- **REF-RFC9449-DPOP**: DPoP sender-constrains issued tokens to possession of a key pair instead of leaving them as pure bearer material.
- **REF-ANDROID-PENDINGINTENT-SECURITY**: one-shot posture matters when a compact authority artifact could otherwise be replayed.
- **REF-XDG-REQUEST** and **REF-XDG-SESSION**: request/session handles are mediator-owned live interaction objects, not generic durable capability blobs.

## The split

Keep these classes separate:

### 1. Claim / redeem ticket
`Present this and stronger authority may be minted or recovered.`

Examples:
- a single-use import result,
- a short-lived approval code,
- a portal-issued redemption object,
- a restore/revival ticket that still needs explicit redemption.

This is not yet a passable live handle.

### 2. Holder-bound grant
`This works only for the current proving holder.`

Examples:
- a session-bound or proof-bound grant,
- a sender-constrained token,
- a lane that requires current holder proof before use,
- a live grant that may be inspectable but not freely replayable.

This is stronger than a claim ticket, but still not the same as a freely passable live handle.

### 3. Passable live handle
`A process currently holds usable authority that can be copied/inherited/couriered now.`

This is the point where ViewFS should speak in terms of handle copies, inheritance, handoff sheets, issuer badges, and bind/publication actions.

### 4. Spent / expired / withdrawn ticket
`This artifact records that something was already used or is no longer redeemable.`

This state matters because old tickets often look deceptively alive in transcripts and recents.
A spent artifact is neither an inert note nor a live handle.
It is a historical trace with anti-replay meaning.

### 5. Durable receipt / history
`Something happened before.`

Receipts should remember claim creation, redemption, spend, refusal, expiry, and any resulting publication/handoff.
They should remain inspectable without reviving present authority.

## Anti-collapse rules

- Do not let `claim ticket` render as `handle held now`.
- Do not let `holder-bound` silently degrade into replayable bearer folklore.
- Do not let `spent` look like `temporarily unavailable`.
- Do not let a handle handoff pretend to be the same class as claim redemption.
- Do not let a receipt/history card revive a claim just because the UI can still see it.

## ViewFS posture

A good Phase 1 ViewFS should be comfortable saying all of these distinctly:
- `redeemable`
- `redeemable once`
- `holder proof needed`
- `live handle held now`
- `passable now`
- `spent`
- `expired`
- `history only`

That vocabulary gives us freedom later.
It leaves ticket format, holder-proof method, and broader object-store persistence open, while already making the shell and import flows much harder to lie with.

## Shell consequences

The future shell gets several high-value truths from this split:
- a **redemption ladder** can show when a claim still must be spent to mint a stronger handle;
- **holder-proof badges** can explain when a grant is exact and live but still not freely replayable;
- **spent ghosts** can stay visible in history without pretending to be reusable;
- **burn-after-use chips** can warn the user before an action consumes a claim;
- **handoff sheets** can distinguish `redeem here` from `pass this live handle to that process`.
