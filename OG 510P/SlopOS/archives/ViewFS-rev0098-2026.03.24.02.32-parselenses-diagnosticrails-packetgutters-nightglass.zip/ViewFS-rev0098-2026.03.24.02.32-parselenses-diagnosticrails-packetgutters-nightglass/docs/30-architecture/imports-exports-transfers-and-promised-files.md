# Imports, exports, transfers, shares, and promised files

Purpose: keep **copy-in/import**, **open-in-place**, **save/export**, **move/rehome**, **transfer/drag-drop/clipboard**, **share/delegate**, and **promised or virtual file materialization** on distinct seams.

Object stores and capability systems make it very tempting to collapse these into one vague "file operation". Existing platforms mostly warn against that. Some operations copy bytes, some delegate access, some select a destination, some only offer transfer, and some promise to materialize bytes later if a sink actually asks for them.

## Useful precedents
- **REF-APPLE-DOCPICKER-OPS**: Apple’s document picker explicitly distinguishes import, export, open, and move.
- **REF-APPLE-DOCPICKER-ACCESS**: open/move give security-scoped in-place access; import/export copy instead.
- **REF-XDG-FILECHOOSER** and **REF-XDG-DOCUMENTS**: chooser-open can grant access through a restricted document view and can persist across sessions.
- **REF-XDG-FILETRANSFER**: transfer is a session with explicit add/retrieve/close semantics and `autostop` defaults.
- **REF-ANDROID-SAF** and **REF-ANDROID-CREATE-DOCUMENT**: browse/open, tree grants, and create/save-as are distinct SAF flows.
- **REF-WIN-SHELL-CLIPFORMATS** and **REF-WIN-SHELL-DATASCENARIOS**: copy-vs-move outcome must be reported explicitly; delete-on-paste is not just "cut means gone now".
- **REF-APPLE-FILEPROMISES**: drag/drop can promise a file that is only materialized at drop time.

## Distinctions worth preserving

### 1. Import/copy-in is not the same as open-in-place
Import creates or selects a **fresh local object** in the recipient's world.
Open-in-place keeps the source object authoritative and grants scoped live access.

That matters because ViewFS already leans toward fresh local identity for imported document workflows, while docref/reopen semantics stay non-bearer and scoped.

### 2. Save/export is not the same as move/rehome
Save/export usually means:
- choose a destination,
- write a copy or replacement there,
- and leave the original source object intact.

Move/rehome means the original logical object changes location or ownership expectations.
Those should not quietly share one receipt shape.

### 3. Transfer is not the same as import
Clipboard and drag/drop should often be modeled as **offers plus sink-side retrieval**, not as immediate local-object creation.
The receiver may inspect, reject, or partially consume a transfer.
Only an explicit follow-on act should promote that into a durable local import or workspace bind.

A second low-regret split is worth freezing now:
- the **current selection owner/source** is not the same thing as the **offer** it published,
- the **offered representation set** is not the same thing as the **one representation the sink accepted**,
- and **pasted prompt bytes** are not the same thing as an imported object or durable reopen artifact.

That keeps ViewFS honest about copy/paste and clipboard-style exchange: `copied`, `offered`, `retrieved as text/plain`, `pasted into prompt`, and `imported as local object` should be able to show up as different facts.

### 4. Share/delegate is not the same as export
Sharing often means "let some other app or user handle this".
Export means "materialize bytes at this destination".
A system may use one chooser for both, but the resulting authority and audit trail should not collapse.

### 5. Promised/virtual files are not the same as already-materialized files
A promised file is a commitment to materialize bytes later if a sink accepts the transfer.
That is a powerful idea for ViewFS shells and notebooks, but it should not be mistaken for:
- a live file handle,
- a durable object identity,
- or proof that the bytes already exist.

### 6. Move outcome must be explicit
Windows Shell is a useful warning here: move/copy/delete-on-paste outcomes are explicit because the source cannot safely infer what happened from a generic drag result.
ViewFS should preserve the same honesty: a transfer or move receipt should say whether the outcome was copy, move, rehome, replace, or failed.

### 7. Destination selection is not directory authority in general
A save-as style grant is narrower than "you may now browse and mutate this whole tree however you like".
Destination grants should remain explicit about whether they are:
- one-shot create,
- replace-if-confirmed,
- append-like,
- or reusable for a bounded workflow.

### 8. Transfer and import may have different identity stories
Import may intentionally mint fresh local object identity even when the source bytes match an earlier object.
Transfer may remain only an offer/receipt until the receiver asks for materialization.
These should stay visibly different.

## Shape that feels promising
ViewFS probably wants different receipt families for different lanes:
- **ImportReceipt** — a fresh local object or object set was minted
- **OpenGrantReceipt** — in-place access was granted
- **DestinationGrantReceipt** — a save/export destination was chosen
- **TransferOfferReceipt** — sender published a transferable offer
- **TransferDeliveryReceipt** — sink actually retrieved it
- **MoveOutcomeReceipt** — move/rehome result, including whether the source should delete or just update view state
- **PromiseMaterializationReceipt** — a promised file/object was actually materialized

The exact schemas can wait. The classes should not disappear.

## Nifty ideas worth stealing
- **File promises for shell output**: allow a command to offer a promised artifact that is only rendered/materialized if a sink drags, drops, pastes, or exports it.
- **Boundary previews**: before an action crosses a view or app boundary, show whether it is copying bytes, delegating access, selecting a destination, or promising future materialization.
- **Transfer promotion**: let a transfer receipt become an explicit import or workspace bind only through a visible second step.
- **Offer cards with MIME truth**: show current owner/source, offered representations, and the accepted representation separately.
- **Create-only save lanes**: Android’s `ACTION_CREATE_DOCUMENT` style reminder that save-as is not necessarily overwrite-in-place.
- **Move outcome cards**: after a drag/paste/move, record whether the source should keep, delete, or relabel the original object.

## What not to decide yet
- final receipt schemas for the lanes above
- whether promised files materialize in the sender, broker, or receiver scratch space
- final overwrite/replace semantics across providers
- whether a share/delegate flow always goes through transfer or can also mint a narrower route object
- exact shell verbs or flags for promise-vs-materialize actions

## Near-term recommendation
For ViewFS Phase 1 and nearby spikes:
1. keep **import**, **open**, **save/export**, **move**, **transfer**, **share/delegate**, and **promise** as explicit vocabulary,
2. keep chooser-open / docref / workspace bind separate from transfer and from generic share,
3. treat transfer as offer-plus-retrieval by default,
4. keep selection owner/source, offered representation, pasted prompt input, and imported object on visibly different seams,
5. make move outcome explicit in receipts,
6. and treat promised files as deferred materialization, not as hidden live authority.

## Extra split worth preserving
- the **transfer start key / session object** is not the same thing as one **retrieved representation**
- the **retrieved representation** is not the same thing as one **local imported object**
- the **transfer/session still open** truth is not the same thing as one **local adopted bind/live handle**
- and an old transfer receipt is not proof that retrieval/adoption would still succeed now

This is worth preserving because mediated courier flows often have several truthful states: started, files added, retrievable, retrieved once, autostopped, explicitly stopped, closed by portal, and adopted locally.
