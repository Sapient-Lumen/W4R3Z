# Requests, tasks, progress, and results

Purpose: keep the next helper/automation seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough shell, helper, and automation ambition that we need one more anti-collapse boundary:
**immediate request ≠ accepted task wrapper ≠ live status/progress stream ≠ input-required checkpoint ≠ deferred final result retrieval ≠ durable receipt/history**.

That split is the safest way to let the shell expose rich deferred-work UX **without letting “running in the background”, “showing progress”, or “I already got a task id” quietly mean “the result is here”, “the authority is still live”, or “this interaction is now a durable workflow by default.”**

## Why this seam matters now
SlopOS already points this way:
- `rfcs/0115-capability-safe-shell-and-automation.md` keeps automation explicit-only at startup and treats effect contracts as real seams.
- `rfcs/0117-plumb-messages-and-cli-intents.md` keeps intent envelopes distinct from execution results.
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md` keeps mediated request/response authority concentrated in explicit UX instead of hidden background folklore.
- `docs/30-architecture/effect-contract-schema-v0.md` and adjacent ACP/posture notes keep acceptance/completion meaning distinct from generic transcript residue.
- `docs/30-architecture/powerbox-posture-v0.md` and `docs/30-architecture/openuri-portal-posture-v0.md` already refuse to treat a pending mediated interaction as the same thing as a granted durable outcome.

ViewFS should preserve that posture in future helper/task flows instead of creating a softer second story where:
- a task handle looks like the final result,
- a progress message looks like durable completion,
- an `input_required` pause looks like silent authority widening,
- background permission looks like perpetual job ownership,
- or an old task result looks like the request is still live.

## Lessons we must learn from the past

### 1. Request handles are not results
The XDG portal request flow is crisp: the caller makes a portal request, gets a Request object handle, that object stays alive while the user interaction lasts, and the actual results arrive later on the `Response` signal. The Request object can also be explicitly closed.

Why this matters:
- ViewFS should not treat “there is a request handle” as “there is already a result”;
- a request object is interaction state, not a durable outcome object;
- the shell should be able to show pending, cancelled, closed, and responded states without pretending a final object already exists.

### 2. Accepted task wrappers are not the final operation result
The current MCP tasks spec makes the split explicit: a task-augmented request gets an immediate `CreateTaskResult`, but the actual underlying result only becomes available later through `tasks/result` after completion. The task status can move through states such as `submitted`, `working`, `input_required`, `completed`, `failed`, and `cancelled`.

Why this matters:
- ViewFS should not let a task ID or accepted wrapper masquerade as the completed output;
- `input_required` should be a first-class checkpoint rather than a weird half-failure;
- replay and shell receipts should preserve whether the user saw only acceptance, saw progress, supplied extra input, or actually retrieved a final result.

### 3. Progress is a separate lane, not the result channel
The MCP progress utility keeps progress updates separate by requiring a `progressToken` in request metadata. Google long-running operations make a related point: the API returns an `Operation`, clients poll or wait for the latest state separately, and `WaitOperation` is only best-effort.

Why this matters:
- progress should stay advisory and live, not a disguised result object;
- a still-moving progress bar or status line should not be recorded as durable success;
- ViewFS should preserve the difference between “still running”, “latest known state”, and “final retrievable result.”

### 4. Background permission is a different seam from task execution
The XDG Background portal is a useful warning sign. `RequestBackground` asks whether the app may run in the background or autostart later, while `SetStatus` separately sets a user-visible background status message.

Why this matters:
- a background/autostart grant is not the same thing as a live task instance;
- status text is not completion;
- ViewFS should not let “may continue later” collapse into “is currently running”, “owns the final result”, or “has durable standing authority forever.”

### 5. Shells already struggle when background work is under-modeled
VS Code task docs explicitly require background/watch tasks in ordered dependencies to have a problem matcher that tracks when they are “done”, and the January 2026 release notes add message steering and queueing while a request is still running plus renamed background agent sessions.

Why this matters:
- shells need an honest notion of pending work, not just scrollback text;
- “follow-up while still running” is useful, but only if the shell keeps the running request distinct from the queued follow-up and from any final result;
- ViewFS can steal the UX ambition without inheriting the ambiguity.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **ImmediateRequest** — the exact request/intent submitted now, before acceptance
- **TaskHandle** — accepted deferred-work wrapper with lifecycle metadata, not the final result
- **ProgressLane** — live advisory status/progress stream for one task or request
- **InputCheckpoint** — explicit `input_required`/approval-needed wait state with related-task linkage
- **FinalResult** — retrievable terminal output or terminal error of the underlying operation
- **TaskReceipt** — durable history saying whether we only got acceptance, saw progress, hit input-required, cancelled, failed, or retrieved the final result

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **task badges** — accepted, queued, working, input-needed, completed, failed, cancelled
- **progress lanes** — live status text and bounded progress that are visibly advisory
- **input-required drawers** — exact pending follow-up questions or approvals linked to one task
- **result lockers** — final outputs retrieved only after terminal completion, not before
- **queue rails** — follow-ups that are visibly waiting behind a still-running request instead of dissolving into scrollback
- **task receipts** — whether a block only created a task, watched it, supplied extra input, cancelled it, or actually retrieved the result

That is the right way to make a shell feel ambitious without letting deferred work quietly become a hidden second authority model.

## What not to decide yet
- the final task schema for ViewFS or SlopOS,
- whether every deferred operation should use one shared task wrapper or family-specific wrappers,
- whether result lockers are pane-bound, request-bound, or helper-session-bound by default,
- the final retention/TTL/keepalive policy for task metadata and results,
- whether background permission and deferred task wrappers ever share storage or only share surface chrome.
