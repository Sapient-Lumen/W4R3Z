# Editable buffers, parsed structures, advisory diagnostics, compiled packets, and prepared actions

ViewFS is headed toward a custom shell where buffer editing, capability-aware routing, and portal-mediated imports will all live unusually close to each other.
That will only stay honest if the shell keeps at least six classes distinct:

1. **editable buffer**
   - current mutable text/fragments under the cursor.
2. **parsed structure / highlight model**
   - current best structural understanding of the buffer.
3. **advisory diagnostic**
   - syntax/lint/hint output about the current buffer.
4. **compiled command packet**
   - pane-local parse/bind result against current objects, receipts, and helper bindings.
5. **prepared action**
   - exact current preflighted act that could be reviewed/launched.
6. **receipt / history**
   - durable record of what was shown, compiled, or run before.

## 1. Why this matters

The shell will otherwise start lying in subtle ways:
- syntax color will be mistaken for authority;
- parser recovery will be mistaken for exact intent;
- diagnostics will be mistaken for policy or approval truth;
- one compiled packet will be mistaken for a launched or approved action;
- one historical parse/packet will be mistaken for current truth.

That becomes especially dangerous once command lines can mention imported handles, projected views, route slips, sidecars, and capability-bearing shell nouns.
A pretty buffer should not quietly turn into a capability decision.

## 2. Lessons we must learn from the past

### 2.1 Incremental parsing is useful *before* exact meaning is settled

tree-sitter is a strong precedent because it is designed to update syntax structure incrementally as the source is edited, and to remain useful even with syntax errors.
That is a perfect reminder that ViewFS can standardize `parse lens` and `error recovery veil` shell UX now without committing to one final parse ontology.

### 2.2 Diagnostics are a parallel advisory channel, not the command itself

The LSP diagnostic model is a good precedent because diagnostics travel as their own information channel rather than pretending to be the text buffer or the execution request.
ShellCheck is a second strong reminder: static shell analysis is valuable precisely because it explains likely problems while remaining advisory.

### 2.3 Immediate inline feedback does not need to imply execution

fish is a good product precedent because syntax highlighting, autosuggestions, and completions make the shell feel alive while still preserving explicit acceptance and execution boundaries.
The lesson to steal is not `copy fish syntax`.
The lesson is that immediacy and honesty can coexist.

## 3. Working rule

Keep these shell-visible states separate:
- `buffer_dirty`
- `parse_partial`
- `parse_recovered`
- `diagnostic_only`
- `packet_compiled`
- `prepared_action`
- `receipt_only`

The shell may render many of these at once, but it should not collapse them into one flattering `ready` bit.

## 4. What to steal

- **Parse lenses**: a compact view of current structural understanding.
- **Recovery veils**: show when the parser is guessing through incomplete text.
- **Diagnostic rails**: split syntax/lint/hint/advice from harder gates.
- **Packet gutters**: show current pane-local bind/compile truth only after compilation.
- **Prepared-action shutters**: explicit transition from compiled packet to exact launchable act.

## 5. What not to decide yet

Do **not** freeze yet:
- one final shell grammar,
- one final parse tree format,
- one final diagnostic taxonomy,
- whether packets are always structured objects,
- whether analyzers are built-in, helper-provided, or terminal-mediated.

The low-regret move is to freeze the separations and shell honesty, not the parser stack.
