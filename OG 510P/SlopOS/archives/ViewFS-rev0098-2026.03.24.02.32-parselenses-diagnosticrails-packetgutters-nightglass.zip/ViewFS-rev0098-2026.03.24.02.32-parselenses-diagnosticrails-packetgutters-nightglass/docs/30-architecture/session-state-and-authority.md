# Session state is not authority

Purpose: keep saved shell state, pane/workspace layout memory, recent-item caches, notebooks, and replayable workflows from silently becoming a bearer-authority channel.

## Core rule
ViewFS should distinguish at least four things:
- **live authority** — handles/bindings that work right now in this process or pane,
- **durable refs** — non-bearer descriptors that may allow later reopen/rebind,
- **receipts** — historical evidence that a mediated interaction happened,
- **session state** — saved UI/workflow memory such as block history, pane layout, pinned items, recent directories, notebooks, and replay presets.

Session state may *point at* the other classes, but it is not itself the same thing.

## Why this matters
Great shells and terminals remember a lot:
- command history,
- current or recent directories,
- pane layouts,
- bookmarked outputs,
- notebook cells,
- reusable workflows,
- recent objects,
- replay presets.

That memory is useful. It is also exactly where capability systems can accidentally reintroduce ambient authority if they let “saved convenience” stand in for “current grant”.

## Useful precedents
- **REF-XDG-REQUEST**: request objects live only for the interaction and resolve to a response; they are not durable grant state.
- **REF-XDG-FILECHOOSER** and **REF-XDG-DOCUMENTS**: chooser flows can yield durable accessibility across sessions, but that durability is still a portal/document-store concern, not a generic “history entry is now authority” rule.
- **REF-XDG-FILETRANSFER**: transfer sessions are intentionally ephemeral and often autostop after first retrieval.
- **REF-ANDROID-SAF**: the system picker exposes both recent items and persistent access, but those are related rather than identical concerns.
- **REF-ITERM-SHELLINT**: shell integration can persist command, directory, and host history to disk, which is a strong reminder that saved session state grows quickly once the UX gets good.
- **REF-WEZTERM-SHELL-INT** and **REF-WEZTERM-USERVARS**: shells can deliberately emit pane metadata/state without pretending that all emitted state is authority.
- **REF-WARP-BLOCKS**, **REF-WARP-NOTEBOOKS**, **REF-WARP-WORKFLOWS**, and **REF-WARP-CMDPALETTE**: saved blocks, notebooks, workflows, and searchable palettes are great precedents for the *shape* of powerful shell UX.

## Recommended ViewFS reading of the split

### 1. Session state should be inspectable and portable-ish
Session state may be copied, exported, diffed, and replayed more freely than live handles.
That makes it ideal for:
- local notebook/runbook content,
- block history,
- palette indexes,
- pinned object cards,
- pane/workspace layout descriptors,
- “rerun this later” recipes.

But because it is more portable, it must be *less authority-bearing* by default.

### 2. Session state should remember class, not fake class
A saved item should record whether it points to:
- a live handle that only existed locally,
- a durable ref that can be reopened/rebound,
- a receipt that explains a past action,
- or only a textual/semantic memory (e.g. command block, note, search query).

The failure mode to avoid is “this looked like a bookmark, so the shell quietly turned it into authority.”

### 3. Replay should be explicit about rebind work
When replaying a command/workflow/notebook cell, ViewFS should be able to say:
- `ready` — needed authority already live here,
- `reopenable` — a durable ref exists and can be retried,
- `portal needed` — fresh user mediation required,
- `receipt only` — historical explanation exists but no reusable grant,
- `stale` — remembered target no longer validates,
- `stripped replay` — run without remembered grants on purpose.

That makes saved workflows useful without turning them into hidden capability bundles.

## What session state may legitimately contain
Safe-by-default ingredients include:
- command text and structured argument history,
- block/zone boundaries,
- display labels and local notes,
- receipt IDs/summaries,
- durable-ref IDs or descriptors when policy allows,
- stale/live/rebind-needed status,
- pane layout and view labels,
- pinned search queries and object filters,
- workflow parameter templates.

## What session state should not silently contain
Dangerous defaults include:
- serialized live handles,
- hidden bearer tokens for reopen,
- ambient host paths presented as if they were durable object truth,
- revived transfer-session secrets,
- shell history that auto-reactivates old authority just because the user typed a familiar command.

## A promising future object: SessionManifest
Without standardizing it yet, ViewFS may eventually want a **SessionManifest**-like object that records:
- pane/workspace arrangement,
- pinned blocks/receipts/refs,
- replay recipes,
- local notes/tags,
- desired-but-not-necessarily-live bindings.

The key posture is that a SessionManifest is a **memory and replay aid**, not a bearer grant bag.
It should re-enter the system through explicit rebind/reopen flows.

## How this maps onto SlopOS seams
- **receipts/outcomes** ↔ `acp-outcome-receipt-schema-v0.md`, `capshell-output-normal-form-v0.md`, `attention-durable-status-boundary-v0.md`
- **durable doc-style refs** ↔ `document-handle-schema-v0.md`, RFC-0089
- **recent/reveal/launch memory** ↔ `openuri-recent-items-boundary-v0.md`, `openuri-showitem-exactness-boundary-v0.md`
- **shell explainability** ↔ `explain-posture-v0.md`, `rfcs/0115-capability-safe-shell-and-automation.md`

SlopOS already has the raw seam vocabulary to keep “saved memory” different from “current authority”. ViewFS should reuse that discipline.

## Shell implications
- notebooks and workflows should attach refs/receipts as typed sidecars, not bury them in strings
- history search should surface `ready`, `rebind`, `portal`, and `receipt-only` states directly
- copying or sharing a notebook/block should carry notes and receipts by default, and durable refs only when policy allows
- a pane/session restore should rebuild layout and prompts first, then ask explicitly what authority to rebind

## Anti-goals
- equating “saved in history” with “still authorized”
- restoring a prior shell session by silently rehydrating old authority
- letting notebook/workflow export become a disguised capability-export format
- making recent directories/objects feel trustworthy when they are merely cached hints
