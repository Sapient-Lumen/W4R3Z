# Live handles, durable refs, and transcript receipts

Purpose: keep three related but different things from collapsing into one overloaded ViewFS primitive.

The split is:
- **live handle** — current in-process or in-session authority to an object or view;
- **durable ref** — a non-bearer descriptor that may allow a portal/service to re-open or rebind later, subject to identity and policy checks;
- **transcript receipt** — evidence that an interaction or grant event happened, useful for auditing, replay, and UI, but not itself authority.

## Why this matters
Capability-flavored systems get confusing fast when one token tries to be all of the following at once:
- a currently usable handle,
- a durable reopen reference,
- a recent-item memory,
- a workspace binding,
- and the transcript record of how the user got there.

ViewFS should resist that collapse.

## Useful precedents
- **REF-CAPSTD**: `Dir` is a live handle and ambient fallback is explicitly marked, which is a great precedent for “current authority value” versus “out-of-band escape”.
- **REF-ANDROID-SAF**: stable document IDs and persistent URI permissions enable reopening later, but moved/deleted targets still fail and require fresh consent.
- **REF-XDG-FILECHOOSER** and **REF-XDG-DOCUMENTS**: chooser/open may yield durable accessibility across sessions for selected files.
- **REF-XDG-FILETRANSFER**: transfer sessions and retrieval keys are intentionally session-bounded and consumption-oriented rather than durable reopen magic.
- **REF-XDG-REQUEST**: portal request handles exist only for the duration of the interaction and then resolve to a response signal with results.
- **SlopOS CH-DOCREF**: `document-handle-schema-v0.md` already frames a durable document reference as a descriptor, not as authority itself.

## Recommended ViewFS reading of the split

### 1. Live handles
Examples:
- a `DirectoryHandle` in a process view
- a rights-attenuated duplicate of that directory
- a current workspace binding in a shell pane
- an active file or object handle attached to a running command

Properties:
- immediately usable
- authority-bearing
- duplicable/attenuatable by explicit rules
- usually not safe or meaningful to persist by blind serialization
- may die with the process, the view, or the session

ViewFS implication:
- the shell can pass live handles between commands or panes only through explicit local routing/binding seams.

### 2. Durable refs
Examples:
- a SlopOS-style document reference
- a “reopen this workspace” descriptor
- a recent-item entry whose reopen path goes back through a portal/service

Properties:
- not the same thing as a live handle
- should be non-bearer by default
- must clamp rights and revalidate target identity
- can become stale if the target moved, was deleted, or policy changed
- should be inspectable and revocable

ViewFS implication:
- recent items and workspace rebinding should generally remember **durable refs plus local display metadata**, not raw live handles.

### 3. Transcript receipts
Examples:
- “user selected this object via chooser”
- “transfer session delivered these objects”
- “save/export wrote to this destination”
- “workspace bind happened with these declared rights”

Properties:
- explain how an operation happened
- should be searchable and attachable to command blocks
- may contain result identifiers or links to durable refs
- should not themselves silently re-open authority when copied around

ViewFS implication:
- the shell should attach receipts to transcript blocks, but clicking a receipt should open an inspect/rebind/reopen route sheet rather than yielding raw authority directly.

## How this maps onto SlopOS seams
- **live handle** ↔ handle tables, fdset-like bindings, active view slots, bound cwd roots
- **durable ref** ↔ CH-DOCREF / document portal style descriptors
- **transcript receipt** ↔ portal request/response outcomes, plumb receipts, audit-visible shell blocks

That is a good seam reuse story because SlopOS already distinguishes “descriptor”, “active binding”, and “record of an action”.

## Shell/terminal implications
- command blocks should store **receipt attachments**, not serialized live authority
- recents/history should say whether they reference a live handle, a durable ref, or just a transcript entry
- a copied transcript should sanitize to receipts and refs, not smuggle live handles across contexts
- “replay” should ask whether to rebind from a durable ref, prompt via portal again, or run without the missing authority

## Good defaults
- default to storing **receipt + optional durable ref**, not hidden live capability material
- regenerate live handles by explicit rebind/reopen actions
- make receipt inspection cheap and live-handle persistence expensive
- let the UI say `receipt only`, `reopenable`, `needs rebind`, or `live here only`

## Anti-goals
- one token that simultaneously means handle, durable grant, recent-item memory, and audit trail
- shell history that silently serializes live authority
- transcripts that are either useless text or dangerously authority-bearing
- “copy this block to another machine” semantics that pretend local handles are portable
