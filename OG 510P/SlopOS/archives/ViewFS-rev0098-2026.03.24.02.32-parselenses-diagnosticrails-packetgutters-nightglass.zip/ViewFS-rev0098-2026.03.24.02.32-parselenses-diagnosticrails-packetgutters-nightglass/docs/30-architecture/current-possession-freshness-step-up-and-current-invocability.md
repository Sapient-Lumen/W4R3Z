# Current possession, freshness/step-up posture, and current invocability

One more lie is easy to import from older systems:
if something is local, realized, or held right now, UIs start talking as if that automatically means `usable now`.

That is not good enough for ViewFS.
The point of this project is not merely to hold objects and handles.
It is to make object-store truth, capability truth, namespace truth, and mediated-import truth **honest enough that the shell can say what is really true next**.

Useful precedents point the other way:
- **REF-RFC9470-STEPUP**: a protected resource can say the authentication event associated with the current token is not strong enough or not recent enough, and challenge with `acr_values` and `max_age`.
- **REF-OIDC-CORE-MAXAGE**: `max_age` and `auth_time` keep recency explicit instead of pretending any existing login already satisfies a fresh requirement.
- **REF-WEBAUTHN-3**: authentication includes a test of user presence or user verification, and those facts are recorded separately instead of being implied by mere credential existence.
- **REF-ANDROID-KEYSTORE-AUTH**: a non-exportable local key may exist, yet key use can still require current user authentication.

## The split

Keep these classes separate.

### 1. Current possession / local realization
`This object, grant, or handle is here or held here now.`

Examples:
- a locally realized object,
- a live handle in this process,
- a holder-bound grant that still exists,
- a key or credential material that is resident on this device.

This is not yet the same thing as current invocability.

### 2. Freshness / recency posture
`Is the last acceptable authentication or proof event recent enough for this action?`

Examples:
- fresh enough now,
- older than allowed,
- freshness unknown,
- only historical evidence available.

This is different from possession and different from current authorization.

### 3. Step-up / stronger-auth posture
`Does this action require stronger or different authentication than was previously used?`

Examples:
- stronger factor needed,
- reauthentication required,
- assurance class mismatch,
- current level acceptable.

This is not the same thing as having no handle at all.

### 4. Local presence / user-verification posture
`Does this action still require an immediate local proof such as touch, unlock, biometric, or user verification?`

Examples:
- touch needed,
- verify user,
- device auth needed,
- satisfied for this attempt.

This is different from freshness and different from broad session/login truth.

### 5. Current invocability here now
`This action may actually proceed in this pane/process/context now.`

This is the narrow winning truth that should drive `go`, `invoke`, `open`, `decrypt`, `export`, or similar action verbs.

### 6. Challenge traces / spent satisfaction
`One freshness or verification challenge was satisfied, failed, expired, or spent.`

These traces matter because users and transcripts often need to know why one action worked once but cannot simply be replayed later.

### 7. Durable receipt / history
`Something happened before.`

Receipts should remember challenge, proof, invoke, refusal, expiry, and result outcomes without reviving present invocability.

## Anti-collapse rules

- Do not let `held now` render as `invokable now`.
- Do not let `local now` silently imply `fresh enough now`.
- Do not let one old `auth_time` or step-up success masquerade as timeless authority.
- Do not let `presence satisfied once` silently become `presence no longer matters`.
- Do not let a receipt/history row revive a fresh-invocation window.

## ViewFS posture

A good Phase 1 ViewFS should be comfortable saying all of these distinctly:
- `held`
- `local`
- `fresh enough`
- `too old for this action`
- `step-up needed`
- `presence needed`
- `verified for this attempt`
- `invokable now`
- `challenge failed`
- `history only`

That vocabulary gives us freedom later.
It lets SlopOS keep evolving its auth mediation, capability leases, and proof surfaces without forcing ViewFS to flatten everything into one reusable-power noun.

## Shell consequences

The future shell gets several high-value truths from this split:
- a **why-not-now drawer** can explain whether the blocker is missing authority, stale recency, stronger-auth demand, or unsatisfied local presence;
- **step-up ladders** can keep `held` and `invokable` visibly different;
- **recency shutters** can decay from `fresh` to `too old for this action` without pretending the underlying handle vanished;
- **presence pins** can show when one local proof is needed right now;
- **satisfaction ghosts** can preserve one recently satisfied or failed challenge without reviving it as current truth.
