# Indexes, recents, and selectors are advisory registries

Purpose: keep ViewFS search, recents, palettes, and smart selectors useful **without** letting them silently become object identity or bearer authority.

## Core rule
ViewFS should distinguish at least five things:
- **live authority** — handles/bindings that work right now in this view or process,
- **durable refs** — non-bearer descriptors that may allow later reopen/rebind,
- **receipts** — historical evidence that a mediated interaction happened,
- **identity / names** — immutable object IDs and current names within a view,
- **advisory registries** — indexes, recent-item databases, palette rows, saved queries, ranking caches, and search results.

Advisory registries may accelerate discovery, ranking, and navigation. They should not be mistaken for either:
- the canonical identity of an object, or
- the authority to act on that object.

## Why this matters
History keeps producing very powerful file discovery UX:
- background indexers,
- recent-file databases,
- smart folders,
- command palettes,
- directory history,
- cross-app launch/search surfaces.

Those are useful. They are also exactly where capability systems can accidentally recreate ambient authority if “the search result exists” starts to mean “the app may now open it”.

## Useful precedents
- **REF-GNOME-TRACKER**: a background index over the home directory can make search bars and media apps instantly useful, but it is also a classic ambient inventory surface.
- **REF-GNOME-LOCALSEARCH**: indexing policy, eligibility checks, and even metadata extraction can be treated as separate concerns; extraction can run in a separate sandboxed process.
- **REF-GTK-RECENT**: a recent-items facility is fundamentally a per-user metadata database keyed by URIs, not a proof of continuing authority.
- **REF-WARP-CMDPALETTE**: one searchable palette can unify many item kinds, but the rows are still filtered by kind rather than collapsed into one generic object.
- **REF-ITERM-SHELLINT**: directory and command history can become part of the terminal UX without claiming those memories are the same thing as a current live handle.
- **REF-CAPSTD**: explicit `Dir` handles are a strong reminder that discovery and current authority should remain separate.
- **REF-ANDROID-SAF**: a system can offer recent-file UX and directory-tree grants at the same time without making recency itself equal access.

## Recommended ViewFS reading of the split

### 1. Indexes should be scoped and class-aware
ViewFS should prefer:
- **view-scoped query/indexes** for D-ATTRFS-like smart-folder behavior,
- **shell-owned registries** for recents, palettes, and notebook/workflow search,
- **explicit bridge indexes** only when a host-side surface is clearly marked as bring-up debt.

Avoid treating any index as a machine-global ambient truth source.

### 2. A result row should preserve what kind of thing it is
A palette/search result should say whether it is:
- a live handle,
- a durable ref,
- a receipt,
- a recent-item hint,
- a saved query / smart folder,
- a workflow/notebook cell,
- a URI/route target,
- or plain note/history.

The bad old move is flattening all of these into “open”.

### 3. Ranking, recency, and metadata do not widen rights
A highly ranked row is still only:
- a pointer,
- a suggestion,
- a note,
- or a candidate for rebind/reopen.

Recency should improve navigation, not grant power.

### 4. Derived metadata extraction should stay separate from authority
If ViewFS later indexes content-derived metadata, it should strongly prefer:
- a dedicated extractor boundary,
- sandboxed or otherwise constrained extraction,
- explicit derived artifacts or index rows,
- no hidden conversion of extracted metadata into new object authority.

That is one of the better ideas to steal from REF-GNOME-LOCALSEARCH.

### 5. Recent-item stores should degrade honestly
A recent-item row may be:
- `ready`,
- `reopenable`,
- `rebind-needed`,
- `portal-needed`,
- `receipt-only`,
- or `stale`.

That is much better than pretending every old click target still works.

## A promising future object family
Without standardizing it yet, ViewFS may eventually want a small family such as:
- **RecentHint** — “this was seen/opened before”,
- **SelectorRow** — typed palette/search row,
- **QueryManifest** — shell-owned saved query,
- **DerivedIndexEntry** — metadata extracted under a bounded policy.

The posture is that these are **advisory** objects, not bearer objects.

## How this maps onto SlopOS seams
- **view-scoped query/search** ↔ `attrfs-posture-v0.md`, `attribute-query-schema-v0.md`
- **recent-item caution** ↔ `openuri-recent-items-boundary-v0.md`
- **durable reopen** ↔ `document-handle-schema-v0.md`, RFC-0089
- **route/reveal/launch separation** ↔ `openuri-portal-posture-v0.md`, `openuri-showitem-exactness-boundary-v0.md`
- **explainability / shell truthfulness** ↔ `explain-posture-v0.md`, `rfcs/0115-capability-safe-shell-and-automation.md`

SlopOS already has the seams needed to keep advisory discovery surfaces from laundering themselves into authority.

## Shell implications
- one palette may search many registries, but every row needs explicit class badges
- smart queries should remain visibly bound to a view or query manifest
- recent items should show provenance and validation state before action
- “why is this in the palette?” should be answerable from the UI
- transcript sharing should preserve receipts/notes more readily than live or durable authority

## Anti-goals
- turning a background index into a hidden ambient search oracle
- treating recent-item databases as durable authority stores
- letting palette convenience blur the line between workflow memory and current access
- making extracted metadata a backdoor around portal/view boundaries
