# Object identity, recents, and reveal are different seams

Purpose: keep ViewFS from accidentally collapsing **immutable object identity**, **document/workspace reopen**, **recent-item hints**, and **reveal/launch routing** into one overloaded filesystem primitive.

This note is intentionally conservative. It does **not** choose a final durable-handle format, final recent-items schema, or final object-ID display form.

## Why this matters now
ViewFS is still in the design phase, and SlopOS already has multiple nearby seams:
- explicit per-process views;
- document portal + durable handle ideas;
- OpenURI / reveal boundaries;
- transfer receipts;
- shell/plumb routing.

That is good news, but it means we can create confusion by pretending they are one thing.

The best outside precedents also separate these concerns:
- REF-NIX-STORE: immutable store objects are not “recent items” or mutable workspace heads;
- REF-PERKEEP-PERMANODE and REF-TAHOE-MUTABLE: mutable identity can sit above immutable blobs without becoming the same thing;
- REF-ANDROID-SAF: a directory-tree grant is a user-mediated access shape, not just a name;
- REF-XDG-FILECHOOSER / REF-XDG-DOCUMENTS / REF-XDG-OPENURI: open, durable access, and external launch are related but distinct flows.

## The four questions ViewFS should keep separate

### 1. What immutable object is this?
Examples:
- blob digest
- manifest/root digest
- content-addressed closure ID

Properties:
- stable under copy
- good for archival, deduplication, receipts, and caching
- bad as the only user-facing naming story

### 2. Under what names is it reachable from **this** view?
Examples:
- `/work/project-a`
- a slot inside a bound workspace view
- a routeable shell alias scoped to a pane/domain

Properties:
- local
- mutable
- may differ per process/pane
- should not be mistaken for global identity

### 3. What durable user-mediated grant or reopen story exists?
Examples:
- document reference / docref-like token
- workspace bind receipt
- explicit “reopen this project” receipt

Properties:
- bound to user consent or a prior portal action
- may fail if the provider moved, deleted, or reclassified the object
- should be inspectable and transcript-visible

### 4. What should happen when the user says “open” or “reveal”?
Examples:
- inspect inside the current shell
- rebind a workspace
- reveal a local document in a tool already holding the right seam
- launch an external URI handler

Properties:
- a routing problem
- may need a portal
- should preserve the seam instead of laundering everything into a path or URI

## The failure mode to avoid
A very tempting but dangerous collapse is:
- object ID == displayed name == recents entry == reopen token == reveal target == route payload

That collapse looks tidy at first, but it makes later security and UX reasoning much harder:
- renames become identity questions;
- recents become implicit authority;
- shell clicks become hidden reopen grants;
- “show in tool” quietly turns into “grant access again”.

## Better posture
Treat the following as distinct objects, even if they sometimes point at each other:
- **ObjectRef** — immutable identity or immutable-root identity
- **ViewName** — a local binding/path in a specific view
- **GrantReceipt** — evidence of a chooser/open/save/transfer/rebind decision
- **DocRef / ReopenRef** — a provider-specific durable reopen handle
- **RouteIntent** — a typed request to inspect/reveal/open/export/transfer
- **WorkspaceBind** — a stronger “attach this tree into my active view” act

## Nifty ideas worth stealing carefully
- From REF-ANDROID-SAF: a workspace/tree grant can be explicit and broader than one-file open without becoming ambient machine storage.
- From REF-PERKEEP-PERMANODE: mutable head and immutable content can be separate linked objects.
- From REF-TAHOE-MUTABLE: stable mutable slots are possible, but they carry their own coordination costs.
- From REF-XDG-OPENURI: reveal/launch should stay a route, not a quiet authority mint.
- From REF-WARP-CMDPALETTE and REF-PLAN9-PLUMB: the UI can search and route many object kinds without pretending they are all file paths.

## Shell and terminal implication
The shell should be able to distinguish at least these click/selection outcomes:
- `inspect object-ref`
- `open via current binding`
- `rebind workspace`
- `reopen durable grant`
- `reveal in current tool`
- `launch external uri`

Those may look similar in the UI, but the transcript and receipts should not pretend they are one event.

## SlopOS alignment
This split fits existing SlopOS seams well:
- view bindings for local names,
- document portal/docref for durable user-mediated reopen,
- OpenURI for launch/reveal routing,
- transfer portal for handoff,
- capability-safe shell/plumb for typed actions.

## Things not to decide yet
- whether docrefs ultimately target object IDs, provider IDs, or both
- whether recents entries store route intents, docrefs, or receipt references
- whether “reveal” is always non-authority-bearing
- whether workspace binds should later grow their own stronger handle class
- exact serialization of object refs in shell output

## Recommended spikes
1. **Rename vs reopen spike** — object renamed inside a workspace: what survives?
2. **Moved-provider spike** — durable reopen survives metadata changes but not provider disappearance: what is the user-visible failure story?
3. **Reveal vs grant spike** — click the same object in three contexts and verify the transcript makes the distinction obvious.
4. **Recent-items spike** — palette/search can list useful recents without implying silent durable access.
