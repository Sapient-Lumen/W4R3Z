# Protected scopes, authorability matrices, and invocation lanes

Purpose: keep the next policy/trust seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough policy-aware shell ambition that we need one more anti-collapse boundary:
**protected-authorable state ≠ carrier/discovery presence ≠ invoke-only helper material ≠ trust-gated adoption lane ≠ effective active state ≠ durable receipt/history**.

That split is the safest way to let the shell discover, rank, and even one-shot invoke helper material aggressively **without letting lower-trust carriers or workspace material silently author sticky always-on state**.

## Why this seam matters now
SlopOS already points this way:
- `rfcs/0028-veto-only-policy-bundles-for-automation.md` keeps policy non-amplifying and explicit.
- `approval-basis-posture-v0.md` keeps exact current basis separate from helper folklore.
- `verification-policy-selection-boundary-v0.md` keeps evidence and requests from choosing their own judge.
- `authagent-provider-role-boundary-v0.md` keeps consent/agent surfaces role-distinct from the authority.
- `uicap-scope-posture-v0.md` and `uicap-scope-schema-v0.md` already treat scope as a real typed seam rather than decoration.

ViewFS should preserve that posture in shell UX instead of creating a softer second story where:
- workspace or parent-repo material quietly authors protected state because it is visible,
- plugin-delivered material silently becomes always-on because the carrier is already trusted,
- a manually-invoked helper quietly upgrades itself into auto-applied truth,
- or a shell-local repair rail writes protected state while pretending only to explain it.

## Lessons we must learn from the past

### 1. Some settings are only respected from protected scopes
Git is unusually crisp here: protected configuration means system, global, and command scopes, and certain options are ignored outside those scopes. `safe.directory` and `safe.bareRepository` are explicit examples, precisely to prevent untrusted repositories from tampering with them.

Why this matters:
- ViewFS should expect some state classes to be **protected-authorable only**;
- repository/workspace-carried material can still be useful without being eligible to author those classes;
- a source-class × state-class matrix is safer than a generic “any visible config may matter” posture.

### 2. Managed policy and restricted workspace values are different failure modes
VS Code still gives a useful split: enterprise policies override lower-precedence settings, while `restrictedConfigurations` means workspace-defined values can be visible but withheld in Restricted Mode.

Why this matters:
- “present but withheld” is different from “present but overruled”;
- protected authorability and trust gating are different seams;
- ViewFS receipts and inspectors should preserve both stories instead of collapsing them into a single “inactive” bit.

### 3. Manual invocation is not the same as automatic influence
VS Code prompt files are manually invoked, while custom instructions are applied automatically. Custom agents add another shape: persistent role/tool bundles can come from workspace, profile, organization, built-in sources, or extensions.

Why this matters:
- ViewFS should keep **invoke-only helper material** distinct from auto-applied state;
- some lower-trust content may be perfectly acceptable for one-shot invocation but not for background, startup, or always-on adoption;
- shell UX should offer `invoke once` and `review for adoption` as separate paths.

### 4. Central brokers are stronger than local flags and prompts
Deno’s permission broker is a great modern reminder: once the broker is active, local allow/deny flags are ignored, interactive prompts disappear, and every permission decision goes through the broker.

Why this matters:
- if SlopOS/ViewFS grows a stronger owner/org/device authority lane, it should remain visibly authoritative;
- shell-local prompts and helper lanes should not masquerade as the final judge when a stronger broker/ceiling is in force;
- a central decision plane needs a visible badge, not silent dominance.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **SourceClass** — where material came from (`org`, `device`, `user-profile`, `workspace`, `parent-repo`, `plugin`, `history`, `receipt`, `imported bundle`)
- **StateClass** — what kind of thing is being authored (`deny ceiling`, `trust gate`, `always-on instruction`, `invoke-only helper`, `tool restriction bundle`, `prompt recommendation`, `effective active state`)
- **AuthorabilityCell** — the matrix answer for a specific source-class × state-class pair (`protected-only`, `adoptable`, `invoke-only`, `advisory-only`, `forbidden`)
- **InvocationLane** — a one-shot/manual path that does not by itself write always-on state
- **AdoptionLane** — an explicit path that may persist a state where allowed
- **EffectiveState** — the exact current winner plus why the losers were withheld, overruled, or invoke-only
- **ActivationReceipt** — durable history saying what was invoked, what was adopted, what stayed invoke-only, and what was categorically ineligible

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **protected chips** — `protected-only`, `invoke-only`, `adoptable`, `advisory-only`
- **matrix drawers** — one keystroke to answer whether this source class may author this state class at all
- **latched invoke buttons** — `run once`, `preview once`, `attach once`, `use for this pane only`
- **auto-apply locks** — a loud cue when a helper may be run manually but may not become always-on from this source
- **broker badges** — a visible cue when a stronger authority lane is deciding and local prompts are only explanatory
- **receipt cards that preserve the distinction** — invoked, adopted, withheld-by-gate, overruled-by-protected-source, or categorically not authorable

That is the right way to make a shell feel ambitious without letting helpful lower-trust material quietly turn into sticky authority.

## What not to decide yet
- the final source-class × state-class matrix for every policy family,
- whether `user-profile` may author every always-on class or only some local classes,
- whether plugins/extensions/packages may ever author anything above invoke-only/advisory,
- whether workspace or parent-repo material can ever become adoptable for always-on state after stronger trust transitions,
- the final serialized schema for matrix cells, invocation receipts, or adoption receipts,
- how much of this belongs in prompt chrome versus drawers, cards, or notebooks.

## Near-term recommendation
For the next nearby spikes:
1. define at least one **protected-only** state class and one **invoke-only** helper class;
2. add a source-class × state-class matrix drawer to the shell prototypes;
3. make `invoke once` a first-class success path rather than a failed adoption;
4. keep broker/owner/org authority visibly distinct from shell-local prompts;
5. record “why this stayed invoke-only or protected-only” in durable receipts;
6. prototype one killer flow: **protected chip + matrix drawer + latched invoke button + broker badge + receipt card**.

