# Portal import posture v0 (authority arrives by mediation)

Purpose: keep imports/exports explicit, inspectable, and user-comprehensible.

## Posture
1. If software needs new file/directory authority, it should obtain it through a **portal/chooser/import flow**, not by probing the machine.
2. Successful portal actions should yield **handles plus receipts**, not just strings.
3. The UX should make the scope and durability of a grant understandable.
4. Export/save flows should be symmetric enough that users can reason about them.
5. Persistence of grants is important enough to be explicit; it must not become folklore.

## Why this cut is worth making
- REF-FLATPAK-BASICS, REF-XDG-FILECHOOSER, and REF-XDG-DOCUMENTS show a practical model for mediated file authority.
- Restricted views created by explicit grants are a better precedent than broad static permissions.

## Open questions
- grant persistence defaults
- revocation model
- import vs export receipts
- batch grants
- directory-tree grants
