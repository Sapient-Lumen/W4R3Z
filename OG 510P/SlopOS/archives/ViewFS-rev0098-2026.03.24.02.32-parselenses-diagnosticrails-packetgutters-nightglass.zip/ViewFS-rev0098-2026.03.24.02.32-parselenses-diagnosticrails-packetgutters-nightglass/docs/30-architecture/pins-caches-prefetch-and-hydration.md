# Pins, caches, prefetch, hydration, mirrors, and offline bundles

Purpose: keep **prefetch hints**, **local caches**, **hydration/materialization acts**, **pins/retention roots**, **mirrors/replicas**, and **offline/self-contained bundles** on separate seams.

Object stores make these classes look temptingly similar because they all involve “having bytes around”. The precedents say otherwise. Good systems separate:
- **hinting** that something may be useful soon,
- **caching** it opportunistically for speed,
- **hydrating** it because a workflow now needs exact bytes locally,
- **pinning** it so retention/GC rules change,
- **mirroring** a bounded corpus elsewhere, and
- **packaging** a self-contained offline bundle for transport.

## Useful precedents
- **REF-IPFS-PERSISTENCE**: pinning protects content from GC; it is a retention promise, not a generic execution or naming promise.
- **REF-NIX-REALISE** and **REF-NIX-COPY**: realisation/hydration and closure-copy are explicit acts over store closures.
- **REF-NIX-PREFETCH-FILE**: prefetch is an explicit fetch-into-store operation that prints the resulting store path and content hash.
- **REF-OSTREE-REPO-MGMT**: full or partial mirrors exist for offline/faster access and are distinct from local deployment or activation.
- **REF-OSTREE-STATIC-DELTAS** and **REF-OSTREE-FORMATS**: self-contained static deltas are explicit transport artifacts, not just “whatever happens to be in cache”.
- **REF-SVCWORKER-SPEC** and **REF-MDNPREFETCH**: prefetch/caching are hint-driven and cache-scoped, with update/cache modes and partitioning caveats.
- **REF-MS-ALWAYSOFFLINE**: offline access can be a performance/availability mode over cached data without implying new identity or authority semantics.

## Distinctions worth preserving

### 1. Prefetch is not hydration
Prefetch means “you will probably want this soon; fetch early if resources allow.”
Hydration means “this workflow now needs exact bytes or a closure locally.”

Prefetch may be skipped, evicted, or partially satisfied. Hydration should produce an inspectable success/failure result.

### 2. Cache is not pin
A cache is usually discardable acceleration.
A pin/root means retention policy changes: the object or closure should stay live until explicitly unpinned or its roots change.

The worst mistake here would be to let “warm in cache” silently imply “kept on purpose forever”.

### 3. Hydration is not mirror
Hydration often means “materialize exactly what this local workflow needs right now.”
Mirror means “maintain a bounded copy of a corpus/repository/closure elsewhere, perhaps for offline or locality reasons.”

A mirror may include more than the current workflow needs. A hydrated working set may be much narrower than a mirror.

### 4. Mirror is not publish
Mirroring a repo or closure elsewhere is not the same as declaring it published, blessed, or activatable.
ViewFS already has separate seams for checkpoints, publication, and activation; mirrors should remain transport/topology objects, not release truth.

### 5. Offline bundle is not live cache
A self-contained transport artifact (bundle, delta, export file) should remain distinct from: 
- an opportunistic cache,
- a local mirror,
- a pin/root,
- or a hydrated working set.

It may be created from those things, but it is still its own object class with its own audit trail.

### 6. “Offline-ready” is a status, not a hidden grant
An object or workflow being offline-ready should mean something like:
- required bytes already hydrated locally,
- all needed closures are present,
- required roots/pins or transport artifacts are in place,
- and no extra network fetch is expected for the named workflow.

It should **not** imply broader browse authority, durable reopen success, workspace trust, or automatic publication.

### 7. Warmth should be inspectable
ViewFS should be able to tell the truth about whether something is:
- `hint-only`,
- `cached`,
- `hydrated`,
- `pinned`,
- `mirrored`,
- `offline-bundled`,
- or `stale / rehydrate-needed`.

That truth will matter a lot in the shell.

## Shape that feels promising
ViewFS probably wants different object/receipt families such as:
- **PrefetchPlan** — a hint or explicit plan to fetch soon
- **CacheEntry** — local acceleration state, discardable by policy
- **HydrationReceipt** — exact local materialization of bytes/closure succeeded or failed
- **PinReceipt** — retention state changed
- **MirrorReceipt** — bounded copy or sync completed somewhere
- **OfflineBundleReceipt** — a self-contained bundle/delta/export artifact was created or consumed

The exact schemas can wait. The class separation should not.

## Nifty ideas worth stealing
- **Offline-readiness badges**: tell the user whether a command/output/workspace is ready with no further fetches.
- **Hydration plans**: before a heavy action, show what closure/objects would be fetched, how large it is, and whether the result is cache-only or pinned.
- **Warm-up trays**: background-prefetch work should render as explicit jobs with `hint`, `warming`, `ready`, `evicted`, or `stale` status.
- **Pin hygiene cards**: show why something is still live (`manual pin`, `workspace root`, `published bundle`, `mirror retention`).
- **Offline bundles as first-class outputs**: let workflows emit a self-contained transport artifact deliberately instead of pretending cache state is enough.

## What not to decide yet
- the final cache eviction policy or quota story
- whether pins are per-object, per-closure, per-workspace, or all of the above
- whether mirrors live inside the same store namespace or a clearly separate repository family
- the final difference between “hydrate just enough to inspect” and “hydrate full closure for execution”
- exact shell verbs or receipt schemas for warm-up versus hydrate versus bundle

## Near-term recommendation
For ViewFS Phase 1 and nearby spikes:
1. keep **prefetch**, **cache**, **hydrate**, **pin**, **mirror**, and **offline bundle** as explicit vocabulary,
2. make hydration success/failure transcript-visible,
3. treat cache warmth as advisory state unless a pin/root says otherwise,
4. keep mirrors/transport artifacts separate from publication and activation,
5. and make offline-readiness a user-visible status rather than a hidden implementation detail.
