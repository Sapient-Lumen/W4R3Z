# Basis records, drift checks, reconsent, and renewed authority

Purpose: keep **reuse candidates**, **exact prior basis records**, **present-time drift checks**, **fresh reconsent checkpoints**, **newly issued authority**, and **history receipts** on distinct seams.

ViewFS is now rich enough that old success can start to masquerade as current permission.
That is dangerous.
A prior chooser result, durable reopen ref, workflow success, or borrowed-authority receipt can be *useful* without counting as a floating approval for whatever the same object or workflow means today.
Because SlopOS is still in design, this is exactly the kind of class boundary we should freeze early and the kind of final schema we should freeze late.

## Useful precedents
- **SlopOS `approval-basis-posture-v0.md`**: exact approval binds one exact action/basis; stale mutable basis requires a fresh action and, when required, fresh approval.
- **REF-DIRENV-REQUIREALLOWED**: watched upstream files can invalidate prior comfort and force re-authorization.
- **REF-APPLE-SECRESOLVE** and **REF-APPLE-SECSTART**: a durable security-scoped bookmark can resolve stale, and a resolved security-scoped URL still needs explicit start/stop live-access discipline.
- **REF-XDG-REQUEST** and **REF-XDG-DOCUMENTS**: request objects are temporary interaction state; document-store entries may be session-only or persistent, but they are still a distinct class from the request and from any current live bind.
- **REF-DENO-PERMISSIONS**: explicit allow/deny posture, prompt-mediated escalation, and permission audit logging keep reuse honest instead of magical.
- **REF-MS-FUTUREACCESSLIST**: durable reopen lists are bounded and app-maintained rather than invisible forever-state.

## Distinctions worth preserving

### 1. A prior success is not current authority
A transcript entry that says something worked before may be valuable evidence.
It is not automatically:
- a current live bind,
- a still-valid approval,
- a still-valid borrow,
- or a guarantee that the same intent can run again unchanged.

Why this matters:
- history stays useful without becoming hidden standing power.
- replay can begin from fresh planning instead of pretending old success is current truth.

### 2. A basis record is not a drift verdict
A **basis record** says what exactly was reviewed or depended on before, such as:
- object or descriptor identity,
- revision/epoch/head-like facts,
- trust posture,
- supported operations,
- attenuation details,
- watched inputs,
- or prior approval/receipt IDs.

A **drift verdict** says what has changed relative to that record *now*.

Why this matters:
- the shell can explain what changed instead of collapsing every failure into “stale”.
- a compact basis record can survive even if the drift verdict later becomes `unknown`, `missing`, or `narrowed`.

### 3. A drift verdict is not reconsent
A drift check may conclude:
- `exact`,
- `narrowed`,
- `drifted`,
- `missing-source`,
- or `unknown`.

That still does **not** itself approve the next action.
Fresh review may still be needed because:
- the operation class is risky,
- durability is being increased,
- the lender/issuer requires renewal review,
- or the trust source changed.

Why this matters:
- machine comparison and human approval stay separate.
- exactness checks do not quietly become floating permission caches.

### 4. Reconsent is not the renewed artifact
A **reconsent checkpoint** or **renewal review** says the user/issuer approved issuing something again under present conditions.
The **renewed artifact** is the new thing issued now:
- a fresh live borrowed handle set,
- a refreshed durable reopen ref,
- a new bind,
- or a fresh prepared run plan.

Why this matters:
- renewed state should have fresh identity/receipt lineage.
- it should not mutate the old receipt into “still live”.

### 5. Replay recipe and approval basis are different classes
A saved recipe or notebook cell may be structurally reusable even when the exact prior approval basis is stale.
Likewise, an exact prior basis snapshot may be useful for comparison even when the saved recipe changed.

Why this matters:
- recipe evolution and approval integrity should not be forced into one object.
- the shell can offer `replay from recipe`, `replay from receipt shape`, or `receipt only` as different moves.

### 6. Renewal can narrow, not only extend
A good reuse flow should allow:
- exact replay if basis still matches,
- replay with narrower rights,
- replay with fresh chooser/import,
- replay in a fresh temp view,
- or receipt-only replay.

Why this matters:
- renewal should not default to “keep all previous power”.
- attenuation becomes a routine product feature.

### 7. Durable reopen hygiene is not live permission state
A durable reopen ledger may keep bounded references for later.
That does not mean those references are:
- currently live,
- immune to staleness,
- or exempt from reconsent.

Why this matters:
- bounded explicit stores are healthier than magical forever-memory.
- maintenance, pruning, and expiry stay visible responsibilities.

### 8. Renewal failure reason should stay transcript-visible
A reuse attempt can fail because:
- the exact basis drifted,
- the source disappeared,
- supported operations narrowed,
- the lender refused renewal,
- trust posture changed,
- or the user chose receipt-only instead.

Why this matters:
- different repair paths need different UI.
- “stale” is not a sufficient explanation.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **ReuseCandidate** — some prior artifact the user wants to act from again
- **BasisRecord** — compact exact record of what was reviewed / depended on before
- **DriftCheck** — present-time comparison verdict against the recorded basis
- **ReconsentCheckpoint** — fresh review or issuer confirmation required now
- **RenewedArtifact** — the new live borrow, durable ref, bind, or prepared plan issued now
- **ReuseReceipt** — history artifact recording exact reuse, narrowed reuse, reconsent, denial, receipt-only, or source-missing outcome

The names can change later.
The split should stay.

## Shell consequences
A custom shell+terminal gets much better if it can offer:
- a **basis diff drawer** before replay/renew,
- prompt or pane badges like `exact`, `narrowed`, `reconsent`, `receipt-only`, or `source-missing`,
- `reuse exact`, `reuse narrowed`, `fresh chooser`, `fresh temp view`, and `receipt only` as first-class actions,
- watched-input chips that explain why reapproval is needed,
- and renewal receipts that clearly say whether the user renewed the *same* class, promoted to a more durable class, or was forced into a fresh import/borrow.

That would make replay and renewal feel powerful without turning past success into ambient authority.

## What not to decide yet
- the final serialized schema for `BasisRecord`, `DriftCheck`, `ReconsentCheckpoint`, or `ReuseReceipt`,
- whether all reuse flows share one common substrate primitive,
- exact drift-taxonomy enums,
- whether basis records are always durable or sometimes ephemeral,
- or final shell syntax for `reuse`, `renew`, `reconsent`, `rebind`, or `receipt-only`.

## Near-term recommendation
For Phase 1 and nearby spikes:
1. never let a past success receipt count as floating current approval,
2. record compact **basis records** whenever future replay/renewal matters,
3. run a fresh **drift check** before reuse of risky or authority-bearing actions,
4. require explicit **reconsent** whenever mutable basis, trust posture, or durability class changed,
5. issue a **fresh artifact + fresh receipt** instead of mutating history into current authority,
6. and prototype one killer flow: **basis diff drawer + reconsent ladder + renewal result card**.
