# Advisory annotations, selector labels, policy labels, and trusted badges

ViewFS should not let every little chip, tag, status pill, or imported metadata key answer all of these questions at once:
- **is this freeform descriptive metadata?**
- **is this safe to use in selectors and query manifests?**
- **does this label affect handling or policy?**
- **is this just current shell-owned chrome?**
- **is this only history?**

Those truths interact, but they are not the same thing.

## Why this split matters

A capability-native object layer wants rich metadata and rich shell chrome.
That only works if the shell can tell the truth about at least five classes:

1. **advisory annotations**
   - descriptive notes, provenance hints, tool metadata, imported manifest keys, comments, or attached structured blobs.
   - may be large, structured, and non-identifying.
   - useful for explanation and ecosystem interop.
   - not automatically selector-safe.

2. **selector labels**
   - compact keys intended for grouping, filtering, match rules, smart baskets, or saved queries.
   - intentionally narrower and more regular than arbitrary annotations.
   - useful for collection building.
   - not automatically policy-bearing.

3. **policy-bearing labels**
   - labels that affect handling, export, review, quarantine, routing, or authorization posture.
   - examples: quarantine, sensitivity/handling class, MAC-style context, review-required flags.
   - must remain visibly stronger than ordinary decoration.

4. **trusted badges**
   - shell/portal/helper-owned summaries rendered in HUD chrome, tab strips, status bars, overlays, or drawers.
   - may summarize annotations, selector labels, policy labels, or live state.
   - should be provenance-labeled because they are a presentation surface, not the canonical store.

5. **receipt/history**
   - evidence that one annotation, one selector label, one policy label, or one badge existed or was rendered before.
   - useful for explanation.
   - not current truth.

## Lessons worth stealing

### Labels and annotations deserve different lanes
Kubernetes is a great precedent because labels and annotations are both metadata but are intentionally split:
- labels support selection and grouping;
- annotations carry arbitrary non-identifying metadata.

That is a very useful seam for ViewFS too.
We should keep compact selector-safe labels separate from richer explanatory notes.

### Arbitrary metadata should stay arbitrary metadata
OCI annotations are intentionally arbitrary metadata, and consumers must tolerate unknown keys.
That is a good reminder that not every imported key/value should become native behavior or query truth.

### Some labels really are policy-bearing
SELinux security contexts are labels stored as extended attributes and participate in policy.
That is the opposite of a decorative chip.
If ViewFS ever uses policy-bearing labels, they should be modeled in a visibly stronger lane than ordinary tags.

### Handling labels are still not full control systems
TLP is a useful reminder that even stronger sharing-boundary labels are still not the same thing as a whole control/classification scheme.
That helps keep ViewFS modest: policy-bearing labels are useful, but they still should not silently become universal authority or execution truth.

### Chrome is a projection, not the substrate
Steward's label-surface and trusted-chrome posture remains a very good product lesson:
- a tab badge,
- a title,
- a status bar cell,
- or a right-status string
can be extremely useful while still remaining shell-owned presentation.

That means copied text, screenshots, or pasted labels should never be mistaken for canonical metadata or current policy truth.

## Working posture for ViewFS

- keep freeform annotations rich and interoperable;
- keep selector labels narrower and explicitly query-safe;
- keep policy-bearing labels explicit and harder to spoof;
- keep trusted badge chrome visibly shell-owned or mediator-owned;
- keep receipts/history useful without laundering old labels into current truth.

## Shell product ideas

### Label ledgers
An inspect drawer should separate:
- advisory annotations,
- selector labels,
- policy-bearing labels,
- shell/trusted badges,
- and receipt/history rows.

### Selector rails
When a user builds a saved query, smart basket, or filter, the shell should show which chips are:
- `selector safe`
- `annotation only`
- `policy only`
- `shell badge only`

That would make smart collections much more honest.

### Trusted badge shutters
Strong labels such as quarantine, review-required, or handling class should render in shell-owned chrome that can explain:
- where the label came from,
- whether it is current or stale,
- and whether it is advisory or policy-bearing.

### Copy ladders
Selection or copy flows should be able to distinguish:
- `copy text chip`
- `copy selector expression`
- `copy receipt`
- `copy object metadata reference`

That prevents innocent label copying from becoming accidental delegation or fake policy transfer.

## What not to decide yet

Do not decide yet:
- one final label schema for every object family;
- whether selector labels live on objects, placements, or indexes;
- whether policy labels are local-only or provider-visible;
- whether every badge is terminal-native, shell-native, or helper-native;
- whether labels have first-class transaction/history objects in Phase 1.

Freeze the separation first.
