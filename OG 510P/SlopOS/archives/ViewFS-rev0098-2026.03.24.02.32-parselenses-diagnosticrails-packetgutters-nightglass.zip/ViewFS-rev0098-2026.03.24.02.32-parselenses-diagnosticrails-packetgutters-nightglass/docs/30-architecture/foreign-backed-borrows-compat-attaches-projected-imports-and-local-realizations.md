# Foreign-backed borrows, compat attaches, projected imports, and local realizations

This note sharpens one more low-regret ViewFS separation:
**usable through another provider now**, **made attachable here through one wrapper or relay**, **projected into a scoped local view**, **explicitly localized here**, and **remembered in receipts/history** are different truths.

Relevant precedents:
- **REF-ANDROID-SAF** and **REF-ANDROID-DOCPROVIDER**: one document can have a stable identity, dynamic placement under roots, provider-declared capabilities, and either copy-import or provider-backed open semantics.
- **REF-APPLE-DOCPICKER-ACCESS**, **REF-APPLE-SECSTART**, and **REF-APPLE-SECBOOKMARK-ENABLE**: open-in-place gives a security-scoped exterior-backed URL with explicit start/stop discipline, while import/export are copy lanes.
- **REF-APPLE-FILEPROVIDER-SYNC**: provider-backed items can exist as dataless or materialized local replicas.
- **REF-XDG-DOCUMENTS** and **REF-XDG-DOCS-FUSE**: a mediator can expose selected files through a restricted projected filesystem keyed by document IDs and app permissions.
- **REF-FUCHSIA-COMPONENT-NSENTRY** and **REF-FUCHSIA-FSARCH**: a receiver namespace is an explicit set of path→directory attachments, and wrappers can make handle-backed services look like openable paths without changing underlying truth.

## Why the split matters

ViewFS is trying to build a capability-native object/view/import story without lying to the user.
That gets much easier if we distinguish at least five classes:
- is this still fundamentally backed by another provider or mediator?
- did we only make it usable here through one wrapper/relay?
- did we project it into this local namespace/view?
- did we actually localize the bytes/object state here?
- or do we only have a durable trace that one of those acts happened before?

Those questions matter because the product and security consequences differ sharply.
A foreign-backed borrow can disappear when the provider logs out, suspends, or goes offline.
A compat attach can make something usable in this process without deciding the long-term object model.
A projected import can be durable enough for one sandbox/view without being local ownership.
A materialized local copy can still be just one cache or sync replica rather than the canonical local object-store truth.
A receipt can explain everything and authorize nothing.

## Working posture

### Foreign-backed borrow is a real current class
ViewFS should be free to say `borrowed from provider` or `foreign-backed` without embarrassment.
That is not a failed state.
It is often the most honest description of what the user has right now.

### Compat attach is a usability layer, not ontology
A wrapper, relay, fd shim, or adapter may be the best way to make a foreign-backed object usable inside a process or runtime.
That still should not define the final ViewFS object model.
Keep the compatibility layer useful and explicit.

### Projected import is stronger than advisory discovery and weaker than localization
A projected import deserves its own class because it is stronger than a mere advert or candidate row.
Something really is visible and usable here.
But it is still weaker than explicit localization into the local object store.

### Local realization is explicit and should stay explicit
If the user or system chooses `make here`, that transition should be inspectable and receiptable.
The shell should not quietly pretend that every borrowed/projected thing was always local.

### Receipts/history should stay honest and non-reviving
A durable row saying `projected here`, `localized here`, or `attached here` is useful truth.
It is not evidence that the provider is still reachable or that the same lane still works now.

## Receiver-side classification worth standardizing early

A useful receiver-side classification for shell UX and protocol experiments is:
- `borrow_foreign`
- `attach_wrapper`
- `attach_wrapper_relayed`
- `project_here`
- `project_here_session`
- `localize_copy`
- `localize_replica`
- `localize_object`
- `receipt_only`
- `history_only`

This is intentionally receiver-side and posture-oriented.
It does **not** decide one final provider ABI, one portal wire format, or one durable object-store implementation.

## Shell and terminal payoffs

A truthful shell can turn this split into product leverage:
- **borrow rails** instead of one fake `open/import` button;
- **projection badges** so the shell can say `portal`, `provider`, `compat`, `materialized`, or `local object`;
- **make-here ladders** that preserve the exact locality transition the user chose;
- **provider-owned halos** and **dataless/materialized lamps** for items that still depend on another service;
- **why-not-adopt drawers** that explain `wrapper needed`, `projection only`, `localize explicitly`, or `provider gone`.

## What not to freeze yet

Do **not** freeze yet:
- one final foreign-wrapper or relay protocol,
- one final projected-import taxonomy,
- one universal `make local` storage contract,
- one rule for when materialized replicas become durable local objects,
- or one permanent answer to whether provider-backed borrows survive relaunch/offline.

The separation is worth freezing now.
The final adoption/localization machinery is not.
