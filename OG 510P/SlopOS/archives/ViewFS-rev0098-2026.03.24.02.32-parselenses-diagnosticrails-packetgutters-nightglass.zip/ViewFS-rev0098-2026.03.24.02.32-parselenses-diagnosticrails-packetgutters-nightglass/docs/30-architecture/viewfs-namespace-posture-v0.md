# ViewFS namespace posture v0 (synthetic local roots, not ambient global `/`)

Purpose: state the central namespace thesis clearly before compatibility work muddies it.

## Posture
1. Every process or component receives an **explicit view root**.
2. View roots are **synthetic and local**; there is no requirement for a machine-global root namespace.
3. Views are assembled from explicit bindings of handles into named slots or prefixes.
4. Paths, when they exist, are interpreted **within a view**, not against a hidden host-global authority plane.
5. Different processes may legitimately observe different `/` trees.

## Why this cut is worth making
- REF-FUCHSIA-NAMESPACE shows the power of per-component composite namespaces.
- REF-PLAN9 shows private namespace assembly is a major usability tool.
- REF-SEL4-CSPACE suggests a useful mental model for slot-oriented handle inventories.

## Early convention candidate
A conventional Phase 1 view may expose:
- `/app`
- `/work`
- `/in`
- `/out`
- `/tmp`
- `/state`
- `/svc`

This is a **convention**, not yet a hard ABI.
