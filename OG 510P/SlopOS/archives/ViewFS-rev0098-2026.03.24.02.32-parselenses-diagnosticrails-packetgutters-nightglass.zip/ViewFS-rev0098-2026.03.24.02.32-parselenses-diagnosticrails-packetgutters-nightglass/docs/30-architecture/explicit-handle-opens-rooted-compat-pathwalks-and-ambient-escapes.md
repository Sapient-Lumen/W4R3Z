# Explicit-handle opens, rooted compat pathwalks, and ambient escapes

Purpose: keep **current authority through an explicit handle**, **narrow rooted pathwalks inside an already-held root/view**, **portal-mediated access minting/projection**, **truly ambient host escapes**, and **historical receipts** on distinct seams.

A capability-native design can afford a little compatibility help.
What it cannot afford is pretending every way of finding a thing is the same moral act.

## Useful precedents
- **REF-CAPSICUM-SEC10** and **REF-CAPSICUM-RIGHTS**: once authority is anchored in current possession of descriptors/capabilities, global namespace dependence should shrink rather than quietly reappear.
- **REF-CAPSTD** and **REF-OPENAT2**: rooted walkers and explicit ambient markers are useful precisely because they say when the caller is using a compat membrane instead of ordinary capability-native authority.
- **REF-XDG-REQUEST**, **REF-XDG-FILECHOOSER**, and **REF-XDG-DOCUMENTS**: mediated choice plus restricted synthetic exposure is a different class from a local native publication or preexisting direct authority.
- **REF-SANDSTORM-POWERBOX**: isolated-by-default components can still exchange authority through explicit user-mediated powerbox flows with inspectable connection semantics.
- **REF-PLAN9-IMPORT**: imported namespace fragments are still imported fragments, not proof that every local string path is ambient machine truth.

## Distinctions worth preserving

### 1. Explicit-handle open is the clean lane
If the actor already holds a live handle, routed designation, or explicit object/reference capability with current rights, opening or acting through that handle is the cleanest truth.
The shell should prefer to say `opened via handle` rather than laundering that act into a pretty path string.

### 2. Rooted compat pathwalk is narrower than ambient reopen
A rooted compat walker can be practical during bring-up and legacy-tool support.
But it should stay visibly narrower than ambient host lookup:
- the walk starts from an already-held root/view/designator,
- no-escape and nofollow policy should be explicit,
- and the shell should mark the lane as compat debt rather than current-object essence.

This lane can be valuable.
It should not become the conceptual center.

### 3. Portal mediation is not direct possession
A chooser, request object, powerbox, or document portal may mint a grant, return a selected designator, or project access through a restricted synthetic view.
That still is not the same thing as the actor already holding a direct local handle from the start.

The shell should be able to say:
- `portal requested`,
- `selection granted`,
- `synthetic view active`,
- `published here`,
- or `receipt only`.

### 4. Ambient escape is debt, not convenience truth
Sometimes a bring-up path needs one loud ambient host escape hatch.
That should remain a policy-gated and transcript-visible debt class.
It should not hide inside shell helpers, implicit `PATH` rediscovery, or host-global `open this string somehow` folklore.

### 5. Receipts matter because users will forget the lane
A user or developer will remember `it opened` and forget whether that meant:
- direct handle authority,
- rooted compat walk,
- portal-mediated import,
- or ambient host escape.

Receipts and explain drawers are the antidote.

## Shape that feels promising
ViewFS probably wants shell- and protocol-visible truth labels like:
- **HandleOpen** — direct use of current explicit authority
- **RootedWalk** — compat walk inside an already-held root/view
- **PortalGrant** — mediator-owned request/selection/grant lane
- **AmbientEscape** — host-global fallback or external loophole
- **ReceiptOnly** — history/explanation without current authority

The exact encoding can wait.
The split should not.

## Nifty ideas worth stealing
- **Safe-open ladders**: for any object-ish target, show the order `use live handle` → `walk within held root` → `ask mediator` → `loud ambient escape`.
- **Ambient-debt sirens**: one obvious badge, searchable in transcript/history, whenever a command used an ambient host escape.
- **Route provenance drawers**: each `open` or click action should explain `opened via handle`, `walked under root X`, `granted by request Y`, or `escaped via ambient helper Z`.
- **Powerbox fit notes**: chooser/import sheets can explain why a candidate is in scope, what becomes local, and what remains mediated.
- **Imported-fragment badges**: an imported namespace fragment should stay visibly imported rather than pretending to be universal local path truth.

## What not to decide yet
- whether rooted compat walkers live in libc, shell helpers, launcher glue, or service helpers;
- whether early ambient escapes are blocked by policy, denied by default, or allowed only in marked developer modes;
- whether portal-mediated grants usually yield direct handles, synthetic projections, or publish-later candidates;
- whether rooted compat walkers are exposed to apps at all or mostly stay shell/runtime-side.

## Near-term recommendation
For the next narrow spikes:
1. prefer direct-handle language whenever that is the truth,
2. keep rooted compat walkers explicit and narrow,
3. make portal mediation transcript-visible instead of path-shaped folklore,
4. make every ambient escape loud and receipted,
5. and teach the shell to compare these lanes honestly instead of flattening them into one fake universal `open` story.
