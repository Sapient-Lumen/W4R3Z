# Intents, route plans, approvals, and execution results

Purpose: keep **user intent**, **prepared route/action plans**, **approval checkpoints**, **committed execution**, and **result receipts** on distinct seams.

A capability-native shell gets much better when it can prepare and explain what would happen before it commits. But that only stays honest if the prepared thing is not silently treated as already approved, already executed, or already live authority.

## Useful precedents
- **REF-PLAN9-PLUMB**: typed intents are more composable than ad-hoc string guessing.
- **REF-XDG-REQUEST** and **REF-XDG-OPENURI**: mediated actions have request objects and option-bearing interactions; asking, choosing, and completing are not one instant.
- **REF-ANDROID-DOCPROVIDER** and **REF-ANDROID-SAF**: provider-supported operations should be explicit, and persistence should remain a distinct step.
- **REF-DENO-PERMISSIONS**: a useful system can start in a denied-by-default posture and cross into stronger authority only through explicit grants or prompts.
- **REF-VSCODE-WORKSPACE-TRUST**: restricted mode is a productive state, not a failure state.
- SlopOS already points in the same direction through `approval-basis-posture-v0.md`, `explain-posture-v0.md`, `acp-outcome-receipt-schema-v0.md`, `denial-receipt-schema-v0.md`, and `intent-kind-registry.md`.

## Distinctions worth preserving

### 1. Intent is not plan
An intent says what the user wants in broad terms:
- inspect this object
- bind this tree here
- open this with something
- export this result
- run this command against that view

A plan says how the system would realize that intent:
- which subject class is involved,
- which route is being chosen,
- which provider-supported operations are actually admissible,
- which pane/view/launch kit would change,
- whether a portal/chooser/request will occur,
- and what authority delta would result.

Many plans may satisfy one intent.
That is exactly why the shell should not pretend the first discovered route is the truth.

### 2. Plan is not approval
A prepared plan is still only a candidate.
An approval checkpoint is a separate fact that should say, in effect:
- this exact plan or action digest was reviewed,
- under these exact basis facts,
- with these exact consequences,
- at this exact moment.

This is where SlopOS's approval-basis posture is especially valuable: approval should bind an exact action, not a floating “whatever is current when we finally run”.

### 3. Approval is not execution
A user or policy may approve a plan and the action may still:
- be cancelled,
- time out,
- fail preconditions,
- lose a provider race,
- be denied by a later state check,
- or only partly complete.

The shell should be able to say `approved`, `committed`, `completed`, `partially applied`, `denied`, or `timed out` as different states.

### 4. Restricted / inspect-only is not an error state
A route can be:
- inspectable now,
- bindable after portal consent,
- executable only after workspace trust,
- exportable only after destination choice,
- or impossible because the provider does not support the operation.

Those should not all collapse into a generic red error.
A productive restricted state is often the safest first state.

### 5. Supported operations are not universal verbs
Android's provider-flag lesson matters here: the UI should only promise actions the provider/source can actually support.
A route sheet should be willing to say:
- `inspect`
- `rebind here`
- `launch with portal`
- `export copy`
- `receipt only`

and omit fantasy verbs rather than showing a generic toolbar that lies.

### 6. Result receipt is not the same thing as the plan object
Once execution happens, the durable truth should live in a result/receipt surface.
That receipt may reference:
- the intent class,
- the chosen plan digest,
- the approval or denial evidence,
- the resulting authority delta,
- and the final outcome.

But the receipt should not become a hidden bearer token, a standing approval cache, or a silent replay capability.

### 7. Replay should begin from a new plan
Replay is safest when it means:
- recover the old intent,
- inspect or regenerate a fresh plan against current state,
- diff it against the prior executed plan,
- then ask whether to commit again.

That is more truthful than treating historical success as proof that the exact same authority path still exists.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **IntentRecord** — what the user/tool asked for
- **RoutePlan** — one exact candidate realization of that intent
- **ApprovalCheckpoint** — proof that this exact plan/action digest was allowed or deliberately blocked
- **ExecutionRecord** — the committed act while it is in flight
- **ResultReceipt** — durable history of what actually happened

The names can change later. The split should stay.

## Shell consequences
A custom shell+terminal gets much better if it can offer:
- `prepare` without `commit`,
- exact route-plan cards,
- provider-ops-aware action menus,
- approval diffs bound to exact plans,
- result cards that distinguish deny / partial / complete,
- and replay that begins from a fresh plan rather than stale magical authority.

This is one of the clearest ways to be super awesome without becoming misleading.

## What not to decide yet
- a final `IntentRecord` or `RoutePlan` schema,
- whether approval checkpoints are shell-owned, portal-owned, or family-specific objects in every case,
- the final taxonomy of result states,
- final command names for `prepare`, `approve`, `commit`, `reroute`, or `replay`,
- or whether some harmless intents can skip an explicit prepare card.

## Near-term recommendation
For Phase 1 and nearby spikes:
1. treat intent, plan, approval, execution, and result as distinct vocabulary,
2. make route sheets produce inspectable plans rather than immediate side effects,
3. bind approvals to exact plans/actions rather than floating mutable targets,
4. preserve restricted / inspect-only / blocked / denied / completed as different user-visible states,
5. and make replay start from a new plan diff, not from an old receipt pretending to be live authority.
