# Links, aliases, shortcuts, and retargetable names

Purpose: keep **helpful names and retargetable references** separate from **live authority**, **immutable object identity**, and **launch/route semantics**.

## Core rule
ViewFS should distinguish at least six related but different things:
- **live handle** — current authority to operate on an object inside a bound view or through a portal grant,
- **view-local binding/name** — a current name bound in a specific view,
- **namespace link object** — a symbolic-link-like indirection object interpreted within a local namespace,
- **durable reopen ref** — a bookmark / reopen descriptor / document reference used to try to regain access later,
- **route or launch shortcut** — a convenience object that describes how to reveal/open/launch something,
- **receipt / transcript trace** — evidence that some link/ref/route existed or was used.

Those should not silently collapse into one primitive.

A user should be able to say:
- “this is a live handle right now,”
- “this is just a name in this view,”
- “this is a retargetable alias object,”
- “this is a durable reopen reference that may need revalidation,”
- “this is only a route/launch shortcut,”
- or “this is only a receipt/history artifact.”

## Why this matters
Historically, “link” features keep mixing very different seams:
- POSIX-style symlink traversal turns path resolution into a security boundary.
- Hard links are storage/name aliasing, not user-facing durable reopen.
- Desktop shortcuts often carry launch behavior, not just object identity.
- Bookmark-style reopen references exist because plain paths are fragile.
- Transcripts and palettes love to render everything as “just click this”.

That is exactly how a capability-native design quietly regresses into ambient path folklore.

## Useful precedents
- **REF-OPENAT2** and **REF-LINUX-PATHLOOKUP**: Linux path-resolution restrictions exist because path walking through mutable components and symlinks is security-sensitive.
- **REF-CAPPRIMS-FS** and **REF-CAPSTD**: capability-oriented filesystem helpers make rooted resolution explicit, offer nofollow variants, and call out ambient authority when it is used.
- **REF-WIN-SHELLLINK**: Windows Shell Links are data objects that can carry path, working directory, arguments, icon, and resolution behavior; that is much richer than “an object identity”.
- **REF-WIN-HARDLINKS** and **REF-WIN-REPARSE**: hard links, junctions, symbolic links, and reparse points are different implementation seams with materially different limits and behaviors.
- **REF-APPLE-BOOKMARKS**: Apple explicitly treats paths and file-reference URLs as fragile for persistence and recommends bookmark data for durable location storage.
- **REF-APPLE-SECBOOKMARK**, **REF-APPLE-SECWITHSCOPE**, and **REF-APPLE-SECSTART**: security-scoped bookmark access is an explicit flow with creation options, resolution, and start-accessing calls.
- SlopOS already has adjacent seams for durable document references, exact reveal/open boundaries, and resolve-once materialization: `document-handle-schema-v0.md`, `openuri-showitem-exactness-boundary-v0.md`, `open-untrusted-materialization-boundary-v0.md`, and `import-to-docref-fresh-identity-boundary-v0.md`.

## Recommended ViewFS reading of the split

### 1. Namespace links should be local, typed, and non-ambient
If ViewFS ever has symlink-like objects, they should be interpreted:
- inside an explicit bound view,
- with obvious rooted/no-escape rules,
- and without silently minting access outside the already authorized scope.

A compat layer may need to *read* or *project* symlink-like objects, but that does not mean ViewFS core semantics should inherit global symlink folklore.

### 2. Hard-link-like aliasing should stay below the user model unless proven necessary
Hard links are useful implementation/storage tools, but they are not automatically the right user-facing abstraction for:
- durable reopen,
- route/reveal,
- or trustworthy shell history.

Phase 1 should avoid promising POSIX hard-link parity unless a concrete interoperability need forces it.

### 3. Durable reopen refs should be non-bearer and explicitly revalidated
Bookmarks / document refs / reopen refs are useful because paths move and names change.
But they should still be treated as:
- a *reopen attempt*,
- possibly stale,
- maybe requiring portal consent or rebind,
- and definitely not identical to a live handle.

### 4. Route/launch shortcuts should stay separate from local-object identity
A shortcut that says “open in editor”, “reveal in workspace”, or “launch this route” is not the same thing as:
- the object itself,
- a local namespace alias,
- or a durable reopen ref.

That matters because desktop shortcut systems often carry launch args and working directories.
ViewFS should not smuggle launch behavior into its object identity model.

### 5. Histories and transcripts may render links, but should not serialize authority
A transcript can safely keep:
- which object/ref/route was shown,
- what class it had,
- whether it was stale,
- and what action succeeded or failed.

It should not quietly turn those rendered links into bearer authority on replay/share/restore.

### 6. Safe-open materialization should stay resolve-once, not live-alias
When a user opens untrusted material or views content through preview/reveal paths, the safer default is still:
- resolve once,
- materialize a stable input object if needed,
- and keep save-back/export as an explicit later seam.

That lines up with the SlopOS datacube’s resolve-once materialization instincts.

## A promising future object family
Without freezing names yet, ViewFS may eventually want ideas such as:
- **NamespaceLink** — local indirection object interpreted inside a bound view,
- **ReopenRef** — durable non-bearer descriptor for later rebind/reopen,
- **RouteSheet** — typed reveal/open/launch shortcut,
- **LinkReceipt** — transcript-safe note that a link/ref/route was used,
- **RetargetReceipt** — evidence that a user intentionally repointed an alias/route.

The seam discipline matters more than the exact nouns.

## How this maps onto SlopOS seams
- **durable reopen / document identity** ↔ `document-handle-schema-v0.md`, `rfcs/0089-document-portal-and-durable-file-handles.md`
- **exact reveal/open routing** ↔ `openuri-showitem-exactness-boundary-v0.md`, `openuri-portal-posture-v0.md`
- **fresh import identity** ↔ `import-to-docref-fresh-identity-boundary-v0.md`
- **resolve-once safe-open materialization** ↔ `open-untrusted-materialization-boundary-v0.md`
- **capability-safe shell clicks/automation** ↔ `rfcs/0115-capability-safe-shell-and-automation.md`

## Shell implications
- every clickable/rendered link should show its class: `live`, `alias`, `reopen`, `route`, `receipt`
- shells should prefer explicit typed hyperlinks over cwd-heuristic “guess the file”
- relink/retarget flows should be explicit actions with diffable before/after targets
- breadcrumbs should show whether a name is a current view binding, an alias object, or just a remembered route
- stale aliases/refs should degrade honestly: `stale`, `moved`, `portal needed`, `rebind needed`, `receipt only`
- shell sharing should keep receipt cards and route sheets, not live handles

## Anti-goals
- treating every rendered link as if it were live authority
- promising host-global symlink/hardlink parity in Phase 1 without a real need
- letting shortcut/launch metadata become immutable object identity
- silently following alias chains outside an explicit bound view
- reviving authority from shell history just because something still looks clickable

