# Witness packs, caveats, freshness tokens, and why-records

Purpose: keep **admissible witness material**, **attenuating caveats**, **freshness/consistency witnesses**, **current decision explanations**, and **history receipts** on distinct seams.

ViewFS is now close to a subtle failure mode: once replay, renewal, imports, and borrowed authority all exist, the system may start treating “the stuff that justified the last decision” as one magical blob.
That would be a mistake.
SlopOS already points the other way: exact mutable basis should be bound as explicit witness material, preconditions should stay veto-only and local, and denial/receipt surfaces should stay deterministic and reviewable.
Because both SlopOS and ViewFS are still in design, this is exactly the moment to freeze the class boundary and delay the final encoding.

## Useful precedents
- **SlopOS `approval-basis-posture-v0.md`**: approval binds one exact action and exact mutable basis rather than a floating head.
- **SlopOS `acp-precondition-witness-posture-v0.md`**: admitted witness material is local, exact, bounded, and veto-only.
- **REF-MACAROONS-NDSS14**: caveats are a powerful precedent for attenuation and delegation conditions, but the caveat set is still distinct from the underlying token and from current evaluation.
- **REF-ZANZIBAR**: consistency/freshness tokens are useful because they pin *when* an authorization answer was evaluated without pretending the token itself is the policy or the grant.
- **REF-DENO-PERMISSIONS**: deny precedence and permission audit logs are a strong reminder that explanation surfaces matter as much as allow paths.
- **REF-FUCHSIA-SANDBOXING** and **REF-FUCHSIA-DICTCAP**: the parent assembles the namespace and grouped capabilities explicitly instead of letting a child infer authority from folklore.
- **REF-XDG-PORTAL-DESIGN** and **REF-XDG-DOCUMENTS**: file-oriented portal APIs are careful not to subvert the sandbox’s limited view, and pass files as document IDs or open fds rather than reopening generic ambient paths.

## Distinctions worth preserving

### 1. Witness material is not the same thing as caveats
A **witness pack** says what exact facts a decision depended on, such as:
- object or descriptor digests,
- exact provider-supported operation facts,
- revision/epoch/head facts,
- trust posture bits,
- issuer policy version or digest,
- or specific watched-input facts.

A **caveat set** says how a capability, plan, or reusable artifact is narrowed, such as:
- read-only,
- no background,
- no export,
- pane-local only,
- expires at end-of-run,
- or limited provider operations.

Why this matters:
- recorded facts and imposed narrowing should not be forced into one schema blob.
- the shell can explain whether something failed because the facts drifted or because the caveats now prohibit the move.

### 2. Caveats are not freshness/consistency witnesses
A **freshness token** (or consistency witness) says what observation moment or evaluation cut the system is comparing against.
It does **not** itself say:
- what rights exist,
- what attenuation is in force,
- or what the user approved.

Why this matters:
- stale or unknown freshness should force a narrower explanation path, not silently inherit the last answer.
- time/consistency evidence should stay detachable from the handle/ref/receipt that motivated the check.

### 3. Freshness evidence is not current approval
Even if a drift check says “the recorded basis still matches at this cut,” the next act may still need fresh approval because:
- durability is increasing,
- the action class is riskier,
- the issuer requires human renewal,
- the workspace trust state changed,
- or the route now crosses a different boundary.

Why this matters:
- exact comparison does not become floating permission.
- “it still matches” stays different from “you may do it again now.”

### 4. A why-record is not a live grant
A **why-record** should explain why the system allowed, narrowed, denied, or downgraded an action.
That record may bind:
- witness-pack digests,
- caveat-set digests,
- freshness token digests,
- relevant policy/issuer identifiers,
- and the resulting class (`exact`, `narrowed`, `reconsent`, `receipt-only`, `denied`).

It still should **not** be a bearer object or a hidden grant cache.

Why this matters:
- transcripts stay explainable without becoming a side-channel for authority resurrection.
- support/debugging tooling gets a durable story without making history executable.

### 5. Reusable recipes should carry caveats differently from witness packs
A saved recipe/workflow/notebook cell may carry default caveats such as `no-export` or `temp-view-only`.
Its witness pack for the *current* run should still be generated fresh.

Why this matters:
- recipe portability and approval integrity can evolve separately.
- a promoted workflow can stay useful without freezing old justification bytes as eternal truth.

### 6. The shell should make “why” inspectable before commit and after commit
The coolest shell move here is not another prompt.
It is a truthful inspector that can say:
- what exact facts were considered,
- which caveats are active,
- what freshness token or consistency cut is in play,
- what changed since the last known success,
- and why the result class is `exact`, `narrowed`, `reconsent`, `receipt-only`, or `denied`.

Why this matters:
- capability-native UX wins when explanation is first-class.
- this is the point where ViewFS can be super awesome without becoming magical.

### 7. Provider-declared operations belong in the witness pack, not as hidden shell heuristics
If a source/provider advertises what operations are supported, those facts should enter the witness pack as exact reviewed facts.
They should not live as ad-hoc shell guesses.

Why this matters:
- a route-plan diff can explain `provider no longer supports move` instead of generic failure.
- operation filtering stays truthful across replay and renewal.

### 8. Denial reasons need lineage too
A denial can be caused by:
- witness mismatch,
- stale or missing freshness token,
- caveat conflict,
- provider-op narrowing,
- policy/issuer veto,
- missing live bind,
- or user choice to stay receipt-only.

Why this matters:
- different failures need different repair paths.
- “permission denied” is not enough vocabulary for a system this explicit.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **WitnessPack** — exact local facts the system is allowed to treat as basis material
- **CaveatSet** — explicit narrowing conditions or usage constraints
- **FreshnessToken** — consistency/freshness witness for the evaluated basis cut
- **WhyRecord** — compact explanation object for why the system allowed, narrowed, denied, or downgraded a move
- **DecisionReceipt** — history artifact for the completed attempt

The names can change later.
The split should stay.

## Shell consequences
A custom shell+terminal gets much better if it can offer:
- a **witness drawer** that shows exact reviewed facts before replay/import/run,
- **caveat chips** that say `read-only`, `no-export`, `pane-local`, `temp-view`, or `expires-on-exit`,
- a **freshness badge** that says whether the current plan is using an exact cut, an old cut, or an unknown cut,
- a **why panel** that explains allow/narrow/deny without lying,
- and result cards that clearly separate `allowed because`, `narrowed because`, and `denied because`.

That is the right way to make the terminal feel more intelligent than a classic shell.

## What not to decide yet
- the final serialized schema for `WitnessPack`, `CaveatSet`, `FreshnessToken`, or `WhyRecord`,
- whether freshness tokens are shared across all families or family-specific,
- whether caveats live only on delegated artifacts or also on saved recipes,
- exact deny/why enum taxonomies,
- or final shell syntax for `why`, `witness`, `caveats`, or `recheck`.

## Near-term recommendation
For Phase 1 and nearby spikes:
1. record a compact **witness pack** whenever a run/import/replay decision is expected to be reusable,
2. keep **caveat sets** as explicit narrowing objects rather than prose or hidden defaults,
3. treat any **freshness token** as comparison evidence, not as approval,
4. produce a compact **why-record** for important allow/narrow/deny outcomes,
5. keep receipts durable and explainable but non-authoritative,
6. and prototype one killer flow: **witness drawer + caveat chips + freshness badge + why panel**.
