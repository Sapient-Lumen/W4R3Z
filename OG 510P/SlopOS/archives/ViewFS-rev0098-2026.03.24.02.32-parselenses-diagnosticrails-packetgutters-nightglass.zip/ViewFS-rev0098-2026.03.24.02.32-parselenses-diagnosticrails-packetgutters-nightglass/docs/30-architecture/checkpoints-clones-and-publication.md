# Checkpoints, snapshots, forks, backups, and publication

Purpose: keep **local checkpoints**, **read-only snapshots**, **writable forks/worktrees**, **backup or replication streams**, **published/deployable artifacts**, **activation/rollback targets**, and **long-term archival retention** on distinct seams.

## Core rule
ViewFS should distinguish at least seven related but different things:
- **checkpoint intent** — “freeze my current workspace/view state so I can compare or come back,”
- **read-only snapshot** — a stable point-in-time tree/object-set that is not itself the active mutable head,
- **writable fork / clone / worktree** — a new mutable workspace derived from some prior state,
- **branch/head/ref movement** — a named pointer that changes which state is current without implying that bytes were copied,
- **backup / replication stream** — material prepared for transport, disaster recovery, or off-device retention,
- **published / deployable artifact** — a reviewed object or tree promoted for sharing, install, or activation,
- **activation / rollback target** — a choice about what should become live next, not merely a fact that a snapshot exists.

Those should not silently collapse into one primitive.

A user should be able to say:
- “checkpoint this before I experiment,”
- “fork this into a fresh writable workspace,”
- “show me what changed since the last checkpoint,”
- “publish this candidate,”
- “replicate this elsewhere,”
- “pin that release for rollback,”
- or “activate that version on next launch.”

## Why this matters
Historical systems keep rediscovering the same lesson:
- **cheap snapshots** are wonderful for local safety and experimentation,
- **writable clones/worktrees** are a different promise from snapshots,
- **backup/replication** is not the same as local undo,
- **publication/deployment** usually adds review, naming, signing, or policy that plain checkpoints do not carry,
- and **activation/rollback** is a routing/state-transition decision, not just “pick any old snapshot.”

That maps well to ViewFS because the project already wants:
- immutable-first storage,
- explicit views and bindings,
- receipts and explain surfaces,
- and a shell that can make experimentation feel cheap without lying about what got promoted, replicated, or activated.

## Useful precedents
- **REF-APPLE-APFS-FEATURES**: APFS explicitly surfaces cloning, snapshots, copy-on-write design, and atomic safe-save primitives.
- **REF-ZFS-SNAPSHOT** and **REF-ZFS-CLONES**: ZFS keeps atomic snapshots, clones-from-snapshots, and clone-promotion as distinct operations.
- **REF-ZFS-BOOKMARK**: a bookmark records the point in time of a snapshot and can act as an incremental-send source without being the snapshot itself.
- **REF-BTRFS-SUBVOLUMES** and **REF-BTRFS-SEND**: Btrfs treats subvolumes/snapshots as one class of object while send/receive provides a distinct replication stream.
- **REF-GIT-WORKTREE** and **REF-GIT-REFLOG**: Git shows how multiple writable worktrees and local movement history can be helpful without making them the same seam.
- **REF-MS-VSS**: VSS is a strong reminder that point-in-time copies, backup coordination, transport, and restore all have separate moving parts.
- **REF-OSTREE-OVERVIEW** and **REF-OSTREE-MANUAL**: OSTree keeps content-addressed trees/refs separate from deploy, pin, switch, upgrade, and cleanup operations.
- **REF-RESTIC-FORGET**: retention policy and reclamation are separate operations even in snapshot-oriented backup tools.
- **REF-FREEBSD-BECTL**: boot environments are operationally useful because clone/snapshot state and activation/rollback are kept distinct enough for tooling to explain.

## Recommended ViewFS reading of the split

### 1. Checkpoint is a local safety move, not a publication event
A checkpoint should mean something like:
- capture the current reachable tree/state,
- preserve enough metadata to diff or restore later,
- and keep the result easy to inspect.

But a checkpoint should not automatically imply:
- public/shareable release status,
- durable external replication,
- or next-boot activation intent.

### 2. A writable fork/worktree is not just “the same snapshot, but live”
A writable derivative deserves its own seam because it may have:
- a fresh mutable head,
- its own journal or branch/ref state,
- its own workspace trust/automation decisions,
- and maybe its own retention/pin status.

That is why ViewFS should not let “fork workspace,” “rebind same tree,” and “restore old checkpoint” collapse into one action.

### 3. Named refs/branches are movement history, not data identity
A branch/head/ref is often the thing users think they are “on,” but it is not identical to:
- immutable content identity,
- the currently mounted/bound view,
- or the fact that a snapshot/clone exists.

This suggests ViewFS should keep pointer movement history first-class and inspectable.

### 4. Backup/replication streams are transport and survivability seams
A backup or send/receive stream is about:
- moving or preserving state elsewhere,
- surviving local loss,
- and maybe incremental transport.

It should not masquerade as:
- a local undo stack,
- a ready-to-activate workspace,
- or proof that the remote copy carries all the same live authority semantics.

### 5. Publication should be a promotion step
ViewFS will likely want a difference between:
- a private checkpoint,
- a local experimental fork,
- a candidate release/publish object,
- and a promoted/pinned deployable artifact.

Publication may eventually add:
- signing,
- naming,
- policy review,
- or stronger provenance.

The seam discipline matters more than the exact Phase 1 schema.

### 6. Activation/rollback should stay a routing decision
A shell or supervisor may choose to activate some candidate next,
but that act should remain visibly distinct from:
- creating a snapshot,
- forking a workspace,
- backing something up,
- or merely pinning it for later.

### 7. The shell can make time travel delightful if it tells the truth
ViewFS can be much better than legacy filesystems here by giving users:
- explicit checkpoints,
- cheap forks/worktrees,
- diffs against prior state,
- rollback previews,
- publish/promote lanes,
- and retention/pin cards.

But the shell should keep saying whether the current row is a:
- checkpoint,
- writable fork,
- branch/head,
- replicated backup,
- publish candidate,
- activated deployment,
- or receipt only.

## A promising future object family
Without freezing names yet, ViewFS may eventually want ideas such as:
- **CheckpointReceipt** — evidence that a workspace/view state was captured,
- **WorkspaceFork** — explicit writable derivative of some checkpoint/object root,
- **BranchHeadReceipt** — local record of named-head movement,
- **ReplicationStreamReceipt** — evidence that a checkpoint/tree was exported or mirrored elsewhere,
- **PublishCandidate** — a bounded object prepared for promotion/review,
- **ActivationPlan** — explanation of what would become live and what would remain behind.

The seam discipline matters more than the nouns.

## How this maps onto SlopOS seams
- **view-local snapshots / checkpoint mounts** ↔ `view-namespace-posture-v0.md`, `rfcs/0032-view-namespace-semantics-v1.md`
- **persistent object store + snapshots** ↔ `rfcs/0038-persistent-object-store-and-snapshots.md`
- **fresh disposable fork/clone hygiene** ↔ `disposable-domain-posture-v0.md`, `init-snapshot-posture-v0.md`
- **activation / next-live selection** ↔ `activation-posture-v0.md`, `activation-set-schema-v0.md`
- **update / deployable artifact boundaries** ↔ `update-posture-v0.md`, `update-manifest-schema-v0.md`, `boot-manifest-schema-v0.md`

## Shell implications
- `checkpoint`, `fork`, `publish`, `replicate`, `pin`, `activate`, and `rollback-preview` should be visibly different verbs
- every time-travel UI should show whether it is local-only, replicated, published, pinned, or active
- “restore” should specify whether it rebinds a current view, creates a new fork, or changes an activation pointer
- diff views should work across checkpoints/forks without implying publication or backup
- the shell should be able to answer “what is safe to throw away?” and “what is pinned for rollback?” separately

## Anti-goals
- treating every snapshot as if it were a backup
- treating every clone/fork as if it were just a rename of the active workspace
- treating publication as if it were just “make a checkpoint with a prettier name”
- treating activation/rollback as if any checkpoint automatically qualifies
- promising transport/backup semantics before the export/retention/provenance story is explicit
