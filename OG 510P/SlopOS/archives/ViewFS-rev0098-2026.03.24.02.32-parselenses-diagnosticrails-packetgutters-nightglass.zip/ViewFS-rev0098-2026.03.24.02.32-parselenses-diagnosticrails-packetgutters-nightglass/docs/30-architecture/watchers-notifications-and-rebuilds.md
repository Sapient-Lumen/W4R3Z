# Watchers, notifications, and rebuild-friendly event feeds

Purpose: keep **watch / notify / auto-refresh / live-update** workflows separate from **authority**, and keep change feeds **rebuild-friendly** instead of pretending they are perfect truth.

## Core rule
ViewFS should distinguish at least five related but different things:
- **live authority** — the current handles/views/rights a process actually holds,
- **watch registration** — a scoped subscription tied to a handle, view, query, or workspace bind,
- **event feed** — the stream of advisory change notifications delivered for that registration,
- **rebuilt snapshot** — the current state obtained by rewalking or requerying after drops/coalescing/gaps,
- **watch receipt / transcript trace** — evidence that a watch existed, refreshed, or reported degraded coverage.

Those should not silently collapse into one primitive.
Watching a thing should not automatically mean:
- you may now open any newly mentioned object,
- the feed is complete or lossless,
- the event names are a stable interchange schema,
- the shell can skip rebuild/rescan logic,
- or a transcript can replay the live subscription as bearer authority.

## Why this matters
Rich live surfaces are one of the most tempting places to smuggle ambient behavior back in:
- a shell wants a `watch` block that updates when files change,
- a workspace pane wants “live tasks / logs / outputs / modified files”,
- a smart-folder wants background refresh,
- a palette wants recency and freshness badges,
- and suddenly a lossy event stream is being treated as authoritative inventory.

Historical file-watching systems keep teaching the same lesson:
**notifications are useful, but recovery/rebuild logic matters more than pretending the feed is perfect.**

## Useful precedents
- **REF-INOTIFY**: Linux inotify explicitly warns that event queues can overflow and that robust applications should recover gracefully, potentially by rebuilding caches.
- **REF-FANOTIFY**: fanotify can return `FAN_NOFD` on overflow and has modes where the event object is identified by file handles rather than an already-open fd; this is a useful reminder that access notifications and object access are not the same seam.
- **REF-APPLE-FSEVENTS**: Apple FSEvents says dropped/root-changed cases require a rescan of the affected directory tree.
- **REF-WIN-READDIRCHANGES** and **REF-WIN-USN**: Windows distinguishes directory-scoped change notifications from the volume-level USN change journal; the journal is useful for recovery, but older records may disappear and clients may need to reindex.
- **REF-WATCHMAN-TROUBLE** and **REF-WATCHMAN-INSTALL**: Watchman documents recrawls/resource limits and warns that remote/distributed filesystems often produce poor results.
- SlopOS already has adjacent seams for explicit background/request state and durable status rather than hidden ambient watchers: `background-request-state-posture-v0.md`, `notification-request-state-posture-v0.md`, and `attention-durable-status-boundary-v0.md`.

## Recommended ViewFS reading of the split

### 1. Watchers are scoped subscriptions, not omniscient sensors
A watch should usually be tied to one of:
- a **directory handle**,
- a **view binding**,
- a **workspace bind**,
- or a **view-scoped query result**.

That makes watch scope explicit and keeps “what may notify me” separate from “what may I open”.

### 2. Event feeds are advisory, health-tracked, and rebuildable
ViewFS should treat event feeds as:
- incremental hints,
- not guaranteed-complete truth,
- with explicit health states such as `live`, `coalesced`, `overflow`, `recrawl`, `stale`, `unsupported`, or `remote-risk`.

When health degrades, consumers should switch from “incremental apply” to “rebuild current snapshot from the bound scope.”

### 3. Rebuild belongs in the model, not just in implementation folklore
A good watch API should make room for:
- explicit rescan/requery,
- monotonic watch epochs or sequence windows,
- provider badges showing where the feed came from,
- and transcript-visible degraded states.

If a watcher can drop events, the design should say so plainly.

### 4. Watch notifications should not mint authority to newly named objects
A watch may tell you that something changed within an already authorized scope.
It should not mean:
- you can walk outside that scope,
- you may automatically trust new active content,
- or your selector/palette now has ambient inventory of the whole machine.

### 5. Transcript/history should remember watch state without replaying live subscriptions
A transcript may safely remember:
- that a watch block existed,
- the scope it targeted,
- health/degraded states,
- a few summarized events,
- and when a rebuild occurred.

That transcript should not silently revive the old live watch registration.

### 6. Notification UX should degrade honestly
The shell should be willing to say:
- `live`,
- `settling`,
- `rebuild required`,
- `overflow`,
- `remote-risk`,
- `provider unavailable`,
- or `watch scope ended`.

That is better than pretending “no new notifications” means “nothing changed.”

## A promising future object family
Without freezing names yet, ViewFS may eventually want ideas such as:
- **WatchSubscription** — scoped live registration tied to a handle/view/query,
- **WatchHealth** — `live`, `coalesced`, `overflow`, `recrawl`, `stale`, `unsupported`, `remote-risk`,
- **WatchEpoch** — optional sequence/epoch marker to detect gaps,
- **WatchReceipt** — transcript-safe record that a watch existed and what health it had,
- **RebuildSnapshot** — explicit rebuilt state after a degraded feed.

The important thing is the seam discipline, not the exact nouns.

## How this maps onto SlopOS seams
- **background request state / durable status** ↔ `background-request-state-posture-v0.md`, `attention-durable-status-boundary-v0.md`
- **notification surfaces** ↔ `notification-request-state-posture-v0.md`
- **view-scoped query refresh** ↔ `attrfs-posture-v0.md`
- **shell-visible status / output** ↔ `capshell-output-normal-form-v0.md`
- **capability-safe shell automation** ↔ `rfcs/0115-capability-safe-shell-and-automation.md`

SlopOS already prefers explicit state surfaces over ambient folklore. ViewFS should reuse that instinct.

## Shell implications
- watch panels should show exact scope (`dir`, `view`, `workspace`, `query`)
- live panes should show health badges, not just pretty green dots
- event feeds should support a visible `rebuild now` action
- `watch` blocks should say whether they are incremental hints or rebuilt snapshots
- transcripts should keep watch receipts and health transitions without replaying live subscriptions
- smart folders should admit when they are stale, partial, or unsupported on the current backing provider

## Anti-goals
- treating watcher feeds as complete ambient filesystem truth
- making a watch registration equivalent to opening every future child object
- hiding overflow/recrawl/rebuild behavior behind a fake “always fresh” UI
- forcing remote/distributed mounts to pretend they have the same semantics as local scoped views
- letting transcripted event feeds silently become bearer authority or invisible automation triggers
