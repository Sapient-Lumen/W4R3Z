# Policy families, cuts, fallbacks, and repair proposals

Purpose: keep the next policy seam narrow while SlopOS and ViewFS are still in design.

ViewFS now has enough policy-aware shell ambition that we need one more anti-collapse boundary:
**policy family/catalog choice ≠ exact authoritative cut/consistency choice ≠ fallback candidate ≠ repair proposal ≠ selection receipt/history**.

That split is the safest way to let the shell suggest alternatives, migrate users through drift, and help them recover from invalid or stale policy state **without silently swapping judges**.

## Why this seam matters now
SlopOS already points this way:
- `verification-policy-selection-boundary-v0.md` keeps verification/appraisal policy as explicit local input and rejects artifact-selected/default-policy drift.
- `approval-basis-posture-v0.md` insists that approval binds exact reviewed basis material instead of floating current heads.
- `explain-posture-v0.md` keeps explanation artifacts durable but non-authoritative.

ViewFS should preserve that posture in shell UX instead of creating a second softer story where:
- a failed current policy cut silently reruns under a different one,
- a palette repair hint quietly becomes the selected policy family,
- a reused selection receipt implicitly authorizes a newer consistency cut,
- or “latest good policy” becomes ambient shell folklore.

## Lessons we must learn from the past

### 1. Dynamic selection needs explicit precedence
OPA discovery is useful here even if ViewFS never adopts OPA itself. Discovery bundles can generate configuration dynamically, but OPA still documents that bootstrap configuration overrides discovered configuration.

Why this matters:
- dynamic selection is not the same as silent precedence;
- if ViewFS ever offers policy-family negotiation or shell repair, it should carry an explicit precedence rule instead of letting whichever surface spoke last win.

### 2. Invalid or drifting policy should not silently fall through to a different judge
Cedar validation and authorization make two valuable points together:
- schemas/validation are distinct from runtime authorization;
- schema changes can invalidate previously validated policies;
- runtime authorization returns diagnostics and uses skip-on-error instead of letting one bad policy rewrite the whole control plane.

Why this matters:
- an invalid/stale candidate policy cut should produce a visible repair path, not an invisible automatic switch to some other family/cut;
- repair suggestions are useful, but they must stay visibly non-authoritative until accepted.

### 3. Freshness / consistency cut is a separate choice from the authorization answer
SpiceDB’s consistency modes are a strong concrete reminder that “what point in time did we evaluate against?” is its own dimension.
It distinguishes `at_least_as_fresh`, `at_exact_snapshot`, and `fully_consistent`, and treats the ZedToken as an opaque point-in-time token.

Why this matters:
- if ViewFS grows policy-family cuts or replayable decision cuts, the shell should expose the consistency/freshness choice as part of the authoritative cut rather than smuggling it through receipts or advice;
- a consistency token is comparison evidence, not itself approval.

### 4. Long-running mediated choice should remain an object until accepted
XDG Request is a useful UX precedent here. A long-running mediated interaction remains a request object until a response signal ends it.

Why this matters:
- a policy-family switch, fallback choice, or repair adoption can remain a visible pending object rather than an instant side effect;
- that keeps the shell fast without making every suggestion authoritative.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **PolicyFamily** — a named family or domain of rules/validation expectations
- **PolicyCut** — the exact chosen family revision / digest / consistency cut for one evaluation lane
- **FallbackCandidate** — an alternate family/cut that *could* be used, but is not yet authoritative
- **RepairProposal** — shell- or tool-generated guidance for how to recover from invalid, missing, stale, or mismatched policy state
- **PolicySelectionReceipt** — a durable, bounded record of which family/cut was used or declined for one interaction

The names can change.
The split should stay.

## Shell consequences
The custom shell gets much better if it can admit:
- **policy cut picker** — what exact family/cut is active *now*
- **fallback rail** — what alternates exist without pretending they are selected
- **repair prompt** — what the shell recommends after invalid/stale/missing policy state
- **consistency badge** — whether evaluation was exact, at-least-as-fresh, latest/fully-consistent, or unknown
- **selection receipt chip** — what was chosen before, without letting that history silently choose again now

That is the right way to make a policy-aware terminal feel powerful without turning it into a hidden policy negotiator.

## What not to decide yet
- the final storage schema for policy families/cuts in ViewFS,
- the final negotiation or migration protocol for switching policy families,
- whether policy families are local-only, importable, or shareable in Phase 1,
- whether consistency cut and policy cut should share one object or only one receipt envelope,
- how much of the cut picker belongs in prompt chrome versus drawers/panels.

## Near-term recommendation
For the next nearby spikes:
1. keep policy family/catalog selection distinct from exact chosen cut,
2. keep fallback candidates visibly non-authoritative,
3. keep repair proposals separate from committed selection,
4. record the exact selected cut and consistency posture in receipts,
5. prototype one killer flow: **policy lens + cut picker + fallback rail + repair prompt + selection receipt chip**,
6. and make all of that work without forcing a final policy language or final negotiation protocol yet.
