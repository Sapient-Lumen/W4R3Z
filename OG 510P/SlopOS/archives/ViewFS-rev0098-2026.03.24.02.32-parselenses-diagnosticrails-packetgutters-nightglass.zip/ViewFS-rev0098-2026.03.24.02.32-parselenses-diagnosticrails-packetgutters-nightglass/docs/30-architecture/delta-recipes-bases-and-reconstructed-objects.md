# Delta recipes, bases, and reconstructed objects

Purpose: keep **delta recipe artifacts**, **exact basis requirements**, **current apply sessions**, **reconstructed target objects**, **fallback full-fetch lanes**, and **durable receipts/history** on separate seams.

## 1. Why this seam matters

A capability-native object layer will eventually face efficient update, import, mirror, repair, or offline-refresh flows.
Those flows often use:
- a patch or delta,
- one exact base object or validator,
- one current reconstruction session,
- and one resulting target object.

Those are not the same class.

If ViewFS collapses them, it will make at least four bad promises:
- that a delta artifact is already the target object,
- that a remembered base id proves the base is local and exact today,
- that a scratch reconstruction result is already durable truth,
- and that a past successful apply receipt proves present reconstructability.

## 2. Vocabulary

- **delta recipe** — a transform artifact that helps derive one target from one basis or window family.
- **exact basis requirement** — one statement of which exact prior object / validator / window is required for safe apply.
- **apply session** — one current act of reconstructing a target from a basis plus a recipe.
- **reconstructed target** — the bytes or tree result produced by apply.
- **fallback full-fetch lane** — one current way to obtain the target whole when delta apply should not proceed.
- **receipt/history** — durable evidence about a prior delta/apply/fallback event.

## 3. Delta recipe is not target object

A delta recipe may be very small and very useful.
It is still not the same thing as:
- the exact target object bytes,
- one current local object handle,
- one current namespace bind,
- or one durable reopen story.

ViewFS should let shells and helpers carry around patch-like or delta-like artifacts without laundering them into `the object`.

## 4. Exact basis requirement is not present local basis truth

A recipe often depends on one exact basis.
That requirement is stronger than a fuzzy `older version` guess.

But a remembered basis id or validator does not prove:
- the base is still local,
- the base is still exact,
- the base is still policy-admissible,
- or the base still has any live-handle continuity with an older object view.

That means the shell should be able to show:
- `needs base X`,
- `base X local`,
- `base X not local`,
- `base validator mismatched`,
- `basis unknown`,
- `history only`.

## 5. Apply session is not durable target truth

A current reconstruction/apply act is its own lane.
It may create bytes in:
- scratch space,
- a temporary staging object,
- a provider-local apply buffer,
- or a fresh immutable object slot.

That act is still not the durable target object identity.
This is the same discipline ViewFS already wants for drafts, staging capsules, and commit-last flows.

## 6. Reconstructed target is not live-authority continuity

Even if reconstructed bytes exactly match some expected target, that does not by itself mean:
- the process has the same live handle as before,
- the target is bound in the same place as before,
- an old durable docref/ticket is now valid again,
- or the shell should pretend a path-like identity continued unchanged.

ViewFS should keep byte/result truth separate from authority continuity truth.

## 7. Fallback full retrieval is its own lane

Range, delta, and patch systems all end up needing a fallback lane.
Exact basis mismatch or policy refusal should be able to say:
- `cannot apply delta safely`,
- `fetch whole target instead`,
- `request new recipe`,
- or `stay receipt only`.

That fallback should remain visible.
Otherwise shells quietly produce magical behavior where the user cannot tell whether they reconstructed from local material or simply fetched the whole thing.

## 8. Past precedents worth stealing

- **HTTP If-Range**: a client with a partial copy can say, effectively, `if basis still matches, send the missing part; otherwise send the whole representation`.
- **HTTP delta encoding**: deltas are about the difference between instances, not a new identity for the delta itself.
- **VCDIFF**: one target window may be encoded against an explicit source segment or against earlier target material.
- **OSTree static deltas**: a delta can target an exact `from -> to` commit pair, and `from NULL` is a different lane.
- **zsync / rsync-style reuse**: local matching bytes can reduce transfer, but the result is still a reconstruction act against explicit checksum/index material.

## 9. Good shell/terminal moves

- **Basis cards** that say `from X`, `base local`, `base missing`, `base mismatch`, or `full fetch fallback`.
- **Delta peels** that keep recipe metadata, basis truth, apply posture, and result posture visible in one drawer.
- **Apply ladders** that offer `apply in scratch`, `verify result`, `materialize new object`, `fetch full target`, or `discard recipe`.
- **Fallback honesty lamps** that say whether the current object was reconstructed or fully fetched.
- **Result-lineage badges** that explain `rebuilt from X using recipe R` while staying separate from handle/bind/reopen truth.

## 10. Non-decisions

Do not decide yet:
- one canonical delta format,
- one universal basis vocabulary,
- one final ownership model for apply sessions,
- whether delta recipes are always transport artifacts, store artifacts, or just provider-local helpers,
- or whether delta-driven reconstruction is phase-1-critical for any one workflow.

Freeze the separation first.
