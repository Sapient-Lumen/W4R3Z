# Previews, extractors, and observation surfaces

Purpose: keep **preview / peek / inspect / extract** workflows separate from **live authority** and from **execution**.

## Core rule
ViewFS should distinguish at least four related but different things:
- **live authority** — the current handle/view rights a process actually holds,
- **observation session** — a temporary preview/peek/inspect/render session over already-authorized content,
- **derived observation artifact** — a thumbnail, extracted text, metadata card, waveform, or other sidecar result produced for inspection,
- **receipt / transcript trace** — evidence that a preview or extraction happened.

Those should not silently collapse into one primitive.
Previewing a thing should not automatically mean:
- durable reopen,
- write access,
- automation trust,
- app launch,
- or permission to run active content inside the preview surface.

## Why this matters
Preview UX is one of the easiest places to accidentally widen power because it feels harmless:
- a file manager wants a quick peek pane,
- a terminal wants inline cards and side-by-side compare,
- a shell wants to render notebook outputs or documents in place,
- a workflow wants metadata and extracted text “just to help selection”,
- and suddenly observation has become hidden launch, hidden scripting, or hidden indexing.

ViewFS wants exactly the opposite story:
**inspection should become richer while authority stays explicit.**

## Useful precedents
- **REF-WIN-PREVIEW-HANDLERS**: Windows preview handlers are explicitly lightweight, rich, read-only previews shown without launching the associated application.
- **REF-WIN-PREVIEW-GUIDE**: preview UI should stay minimal, fast, non-locking, and must block scripts/macros in the previewed file.
- **REF-APPLE-QUICKLOOK-WWDC24**: Quick Look is treated as a system preview tool with lifecycle-managed preview sessions and safe/secure file access language.
- **REF-XDG-BACKENDS**: XDG portals keep backend interfaces in separate processes that sandboxed apps cannot call directly, which is a strong precedent for keeping preview/extraction engines off the same seam as app-visible authority.
- **REF-VSCODE-JUPYTER-TRUST** and **REF-VSCODE-WORKSPACE-TRUST**: rich notebook outputs and execution should respect trust state; “viewing” and “executing” are different seams.
- SlopOS already has matching caution on the URI side: `openuri-preview-metadata-boundary-v0.md` and `openuri-content-extraction-boundary-v0.md` both refuse to treat generic launch as a hidden preview/extraction oracle.

## Recommended ViewFS reading of the split

### 1. Preview is a temporary observation session
A preview should usually be modeled as a short-lived session or lease:
- started from an already-authorized handle or explicit rebind,
- provider-specific about rendering,
- easy to close,
- and not itself a durable bearer object.

A preview session may expose interaction affordances, but it should still be recognizable as **observation**, not generic open/exec.

### 2. Extracted results are derived artifacts, not source truth
If ViewFS later supports:
- thumbnails,
- text extraction,
- page images,
- waveform summaries,
- notebook rich-output captures,
- simplified renderings,
- or semantic metadata,

those should be treated as **derived artifacts or sidecars**, not as magic properties that silently back-write onto the source object or expand the caller’s live authority.

### 3. Preview should not imply launch or trust
A good preview surface may allow:
- scrolling,
- text selection/copy,
- page navigation,
- compare mode,
- or simple scrub/seek,

without implying:
- “run the associated app”,
- “trust the notebook”,
- “allow workspace automation”,
- or “this transcript now carries reusable authority”.

### 4. Observation sessions should remain bounded and inspectable
Preview and extraction surfaces are tempting places to introduce hidden background work.
ViewFS should prefer:
- explicit provider badges,
- explicit close/stop affordances,
- explicit re-render or refresh actions,
- visible distinction between local preview and exported artifact,
- and resource ceilings for heavyweight renderers or extractors.

### 5. Transcript artifacts stay receipts, not bearer power
A terminal transcript may safely remember:
- that an object was previewed,
- which provider rendered it,
- whether the preview was partial,
- and what derived sidecar was emitted,

but that transcript should not silently become a reopen token or a live authority export.

### 6. Trust-sensitive previews should degrade honestly
For risky content classes, the shell should be willing to say:
- `preview blocked`,
- `static render only`,
- `rich output hidden`,
- `provider unavailable`,
- `trust required`,
- or `portal required`.

That is a better user story than pretending everything can always be richly previewed.

## A promising future object family
Without freezing names yet, ViewFS may eventually want ideas such as:
- **PreviewSession** — short-lived observation lease tied to a handle/view,
- **PreviewReceipt** — transcript-safe record of a preview event,
- **DerivedPreviewArtifact** — thumbnail/text/summary/sidecar output,
- **PreviewProviderRecord** — which renderer/extractor ran,
- **PreviewStatus** — `preview-only`, `static-render`, `rich-output-hidden`, `trust-required`, `stale`, `provider-missing`.

The important thing is the seam discipline, not the exact final nouns.

## How this maps onto SlopOS seams
- **preview metadata / unfurls stay separate** ↔ `openuri-preview-metadata-boundary-v0.md`
- **content extraction / reader-mode stays separate** ↔ `openuri-content-extraction-boundary-v0.md`
- **explicit view-scoped query stays separate from extraction** ↔ `attrfs-posture-v0.md`
- **shell safety / transcript-visible automation** ↔ `rfcs/0115-capability-safe-shell-and-automation.md`
- **output formatting remains a shell surface, not bearer authority** ↔ `capshell-output-normal-form-v0.md`

SlopOS already has the right instincts here. ViewFS should reuse them instead of treating preview as a loophole.

## Shell implications
- preview panes should show whether they are read-only, static, rich, blocked, or trust-gated
- extracted text or thumbnails should advertise that they are derived sidecars, not the source object itself
- selecting/copying from preview should be allowed more often than executing from preview
- one-keystroke “peek” is great, but it should not silently launch the full app
- transcripts should keep preview receipts and provider badges without replaying live preview authority
- compare mode should be explicit about whether it is comparing source objects, derived renders, or both

## Anti-goals
- treating preview as a generic open/execute shortcut
- allowing scripts/macros/notebook execution to run inside a nominally safe preview surface
- back-writing extracted semantics onto source objects by default
- hiding heavy background extraction/indexing behind a “harmless preview” affordance
- letting preview receipts or pasted cards silently count as durable authority
