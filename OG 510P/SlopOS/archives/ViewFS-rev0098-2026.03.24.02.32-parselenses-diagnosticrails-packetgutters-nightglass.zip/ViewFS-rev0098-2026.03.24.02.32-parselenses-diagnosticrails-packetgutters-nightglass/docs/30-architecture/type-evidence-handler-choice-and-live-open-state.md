# Type evidence, handler choice, and live open state

ViewFS should not let one filename extension or one `open with` row answer six different questions at once:
- **what type was claimed?**
- **what type do local bytes/structure suggest?**
- **what tools are associated with that type?**
- **what opener was chosen for this act?**
- **what viewer/editor state is live now?**
- **what only happened before?**

Those truths interact, but they are not the same thing.

## Why this split matters

A capability-native object layer wants the shell to be much smarter than `extension -> app` folklore.
That only works if the shell can tell the truth about at least five classes:

1. **declared type / supplied type**
   - from provider metadata, file tags, manifest entries, HTTP headers, extension maps, or upstream declarations.
   - useful for hints and routing.
   - spoofable and not final truth by itself.

2. **derived type / computed type**
   - from local sniffing, magic, structure, schemas, parser probes, or higher-confidence analysis.
   - may disagree with the declared type.

3. **handler association set**
   - the set of viewers/editors/helpers currently associated with the type or object class.
   - may include defaults and preferences.
   - not itself one actual open act.

4. **chosen opener / route choice**
   - the exact opener/viewer/editor/helper selected for one act in one pane/session.
   - may be explicit, rule-driven, or mediator-chosen.
   - should not silently become a sticky preference unless the user makes a stronger move.

5. **live open state**
   - the current active viewer/editor/helper session.
   - examples: previewing, editing, external, portal-owned, disposable, detached, closed.
   - not current authority everywhere else.

6. **receipt/history**
   - evidence that one type was seen, one opener was available, or one thing opened once.
   - useful for explanation, but not current truth.

## Lessons worth stealing

### Declared type and computed type deserve separate lanes
WHATWG MIME Sniffing keeps a supplied MIME type and a computed MIME type as different metadata classes.
That is a very good precedent for ViewFS: `declared type` and `derived type` should be inspectable separately.

freedesktop shared-mime-info sharpens the same lesson on the desktop side: glob rules, magic, aliases, and subclassing all participate in type knowledge, which is a reminder that type classification is more than a file suffix.

### Type taxonomy is not opener choice
Apple UTType is useful because one type can conform to broader supertypes and map to MIME/file tags.
That is a nice reminder that type classification should stay richer than `dot-extension -> one app`.

freedesktop mime-apps sharpens the routing side: associated/default applications live in `mimeapps.list`, which is separate from the type database itself and separate again from one actual open act.

### Preview is its own lane
Windows Preview Handlers are a strong precedent that preview is a lightweight, read-only hosted act that does not have to launch the associated application.
That means ViewFS can keep `preview` and `edit/open fully` as separate lanes even when the same object and type are involved.

### Representation choice can differ from nominal type
Android documents can advertise a concrete MIME type, may be directories, and may also be virtual documents that do not have byte representation in the nominal MIME type but do have alternative streamable formats.
That is a strong reminder that type claims, streamable representations, and chosen openers are different seams.

## Working posture for ViewFS

- keep declared type and derived type visible when they disagree;
- keep handler associations explicit and advisory until one opener is actually chosen;
- keep one chosen opener scoped to one act unless the user makes a stronger default/preference move;
- keep live open/editor state explicit enough to support receipts, repair, and shell chrome;
- keep receipts/history useful without laundering them into present openability truth.

## Shell product ideas

### Type lenses
A focused inspect drawer should separate:
- declared type,
- derived type,
- confidence/disagreement,
- virtual/alternate representations,
- handler associations,
- chosen opener,
- live open state,
- receipt/history.

### Handler racks
The shell should be able to show small rows like:
- `associated`
- `default`
- `chosen now`
- `safe preview`
- `needs import`
- `unavailable here`
- `history only`

That is much better than one generic open menu.

### Sniff-truth drawers
A selected object should be able to explain:
- `declared says application/pdf`
- `derived says application/zip`
- `open inertly`
- `choose different representation`
- `stay receipt only`

without pretending that type classification itself widened authority.

### Open-state badges
The transcript and side chrome should be able to show:
- `previewing`
- `editing`
- `external`
- `portal-owned`
- `detached`
- `closed`
- `history only`

That makes the shell dramatically more informative without becoming spooky.

## What not to decide yet

Do not decide yet:
- one final type schema for every object family;
- one final priority order between declared and derived type;
- one universal handler registry/discovery ABI;
- whether opener choice lives in the shell, portal, helper, or provider for every platform;
- whether every live open/editor session becomes a first-class stored object.

Freeze the separation first.
