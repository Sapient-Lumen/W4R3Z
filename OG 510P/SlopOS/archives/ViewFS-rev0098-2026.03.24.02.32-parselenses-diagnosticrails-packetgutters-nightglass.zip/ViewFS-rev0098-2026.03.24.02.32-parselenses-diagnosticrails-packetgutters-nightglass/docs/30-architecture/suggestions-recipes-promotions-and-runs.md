# Suggestions, promoted recipes, and run history

Purpose: keep **externally suggested automation**, **user-owned reusable recipes/workflows**, **prepared plan instances**, **committed runs**, and **result/history artifacts** on distinct seams.

A custom ViewFS shell gets much better when it can ingest good ideas from many places:
- workspace-contributed tasks and runbooks,
- receipts that suggest a next step,
- shared notebooks or playbooks,
- route rules that propose a workflow,
- and past successful blocks that look worth saving.

But that only stays honest if a suggested thing is not silently treated as already-owned user automation, already-trusted automation, already-prepared execution, or already-live authority.

## Useful precedents
- **REF-WARP-WORKFLOWS** and **REF-WARP-NOTEBOOKS**: saved commands and runnable notebooks are useful because they are searchable, parameterized, and reusable.
- **REF-VSCODE-TASKS**: workspace tasks are a distinct source of automation from user-owned commands.
- **REF-VSCODE-WORKSPACE-TRUST**: opening a workspace and trusting its automation remain separate decisions.
- **REF-DIRENV-ALLOW** and **REF-DIRENV-REQUIREALLOWED**: directory-scoped automation should require explicit authorization and re-authorization when watched files change.
- **REF-PLAN9-PLUMB**: typed routing lets systems suggest or hand off actions without pretending the suggestion is already execution.
- **REF-ITERM-SHELLINT**, **REF-WEZTERM-SHELL-INT**, and **REF-WARP-BLOCKS**: rich shell history and block UX can remember a lot without that memory needing to become standing authority.
- SlopOS already points the same direction through `rfcs/0046-workflow-plumbing-and-portals.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, `rfcs/0117-plumb-messages-and-cli-intents.md`, `approval-basis-posture-v0.md`, and `capshell-learnmode-posture-v0.md`.

## Distinctions worth preserving

### 1. Suggested automation is not user-owned automation
A **suggestion** is something the system found or received:
- a workspace task,
- a shared notebook cell,
- a route-sheet recommendation,
- a receipt-derived next step,
- or a repository-provided runbook.

A **user-owned recipe/workflow** is something the user has deliberately adopted into their own reusable toolbox.

Why this matters:
- provenance matters for trust and explainability.
- a workspace should not get to rewrite the user’s automation vocabulary by merely being opened.
- shared suggestions are easier to inspect, diff, and discard when they are not already “mine”.

### 2. Promotion is not inheritance
A **promotion** act should be explicit.
It can mean:
- copy this suggestion into a user-owned recipe,
- copy and narrow it,
- copy and strip ambient debt,
- or import it as note-only.

Why this matters:
- the promoted object should preserve source provenance without remaining controlled by the source.
- “always follow upstream workspace task changes” is a different and riskier promise than “I promoted a copy on Tuesday”.

### 3. User recipe is not prepared plan
A saved recipe/workflow says roughly what should happen with parameters and hints.
A prepared plan says exactly how the system would do it *now* against current state, current provider operations, current view bindings, and current trust posture.

Why this matters:
- the same recipe may compile to different exact plans over time.
- a saved recipe should stay portable enough to inspect/share/edit without freezing a stale execution basis into the document.

### 4. Prepared plan is not standing trust
A prepared plan may still depend on:
- missing workspace trust,
- missing portal consent,
- stale bindings,
- or changed watched automation files.

Why this matters:
- approval should remain exact and current-state-bound.
- replay should not treat “this recipe ran last week” as proof that today’s plan is already approved.

### 5. A run is not the recipe
A committed run produces one historical outcome:
- complete,
- partial,
- denied,
- cancelled,
- stale-basis,
- or receipt-only.

Why this matters:
- history should teach future runs without silently mutating the source recipe into new truth.
- a successful run may inspire a new recipe, but it should not automatically rewrite an existing one.

### 6. Notebook/playbook documents are not authority containers
A notebook may hold:
- notes,
- cells,
- suggested recipes,
- promoted recipes,
- receipt links,
- and replay presets.

Why this matters:
- a notebook should preserve how to re-enter a workflow, not become a disguised live-capability bundle.
- export and sharing become much safer when notebooks are obviously class-aware.

### 7. Source drift should be visible, not magical
A suggestion source may change:
- workspace task files,
- watched env-hook files,
- shared notebook content,
- or route rules.

Why this matters:
- source drift should produce `changed upstream`, `reinspect`, or `re-promote` states rather than silently mutating user-owned automation.
- the direnv re-allow instinct is useful here: relevant file changes should invalidate prior comfort.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **SuggestedRecipe** — externally sourced reusable automation idea
- **PromotionReceipt** — proof that a suggestion was copied/adopted into user space under explicit choices
- **UserWorkflow** — user-owned reusable recipe/workflow object
- **PreparedRunPlan** — exact current-state plan compiled from a recipe or suggestion
- **RunRecord** — one committed run while in flight
- **RunReceipt** — durable history of what actually happened

The names can change later. The split should stay.

## Shell consequences
A custom shell+terminal gets much better if it can offer:
- source-aware suggestion trays,
- `promote to mine` as a first-class act,
- recipe provenance badges,
- source-drift warnings,
- notebook cells that advertise `suggested`, `promoted`, `ready`, `blocked`, or `receipt-only`,
- and replay that starts from a fresh plan rather than from a stale saved run.

That is a strong route to “super awesome” without making the shell dishonest.

## What not to decide yet
- a final `SuggestedRecipe` or `UserWorkflow` schema,
- whether promoted recipes live in one store or several user-owned namespaces,
- whether notebook cells embed recipes or only reference them,
- whether source-following recipes ever exist as a separate opt-in class,
- or how much shared/playbook sync exists in Phase 1.

## Near-term recommendation
For Phase 1 and nearby spikes:
1. keep **suggestion**, **promotion**, **user-owned recipe**, **prepared plan**, **run**, and **receipt/history** as explicit vocabulary,
2. default workspace- or receipt-suggested automation to **inspectable but not mine yet**,
3. make promotion explicit and provenance-preserving,
4. show source drift and re-promotion as distinct states,
5. and prototype one notebook/workflow flow where `promote`, `prepare`, and `run` are visibly separate moves.
