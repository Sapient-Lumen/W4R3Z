# Workspace trust and automation gates

Purpose: keep **opening/binding a workspace tree** separate from **permitting workspace-defined automation**.

## Core rule
ViewFS should distinguish at least four related but different things:
- **workspace access** — a directory/tree is bound into a view so it can be browsed or edited as data,
- **workspace metadata** — settings, manifests, notes, and project descriptors that may be parsed as inert input,
- **workspace automation** — tasks, launchers, debug configs, agents, scripts, env hooks, notebook execution, or generated code actions sourced from the workspace,
- **user/global automation** — commands and recipes the user already trusted outside this workspace.

Opening or rebinding a workspace should **not** automatically authorize workspace automation.

## Why this matters
A lot of modern developer tooling blurs these steps:
- editors open a folder and immediately discover tasks, launch configs, and extensions,
- shells automatically source per-directory environment files,
- notebook tools make rich outputs and execution feel like part of “opening”,
- AI/automation surfaces can begin reading, running, or editing as soon as a project loads.

That is great for convenience and terrible for clarity if ViewFS wants authority to stay explicit.

## Useful precedents
- **REF-VSCODE-WORKSPACE-TRUST**: VS Code explicitly distinguishes browsing a project from trusting it to execute code; Restricted Mode limits features such as tasks, debugging, workspace settings, extensions, and AI agents.
- **REF-VSCODE-TASKS**: VS Code also distinguishes user-level tasks from workspace-tied tasks, which is a useful split between user automation and workspace automation.
- **REF-VSCODE-JUPYTER-TRUST**: notebook execution and rich outputs are treated as part of the trust boundary rather than mere viewing.
- **REF-JETBRAINS-PROJSEC**: JetBrains IDEs warn that tasks/configurations may execute during project opening and provide explicit trust decisions and trusted locations.
- **REF-DIRENV-ALLOW**: direnv requires an explicit `allow` step for per-directory environment activation and supports `deny`.
- **REF-DIRENV-REQUIREALLOWED**: direnv can force re-authorization when watched files change, which is a strong precedent for trust invalidation on project automation changes.
- **REF-ANDROID-SAF**: Android’s tree grants show that giving access to a directory subtree does not imply permission to run code from it.

## Recommended ViewFS reading of the split

### 1. Bind the workspace first
The first successful user action should usually mint a **WorkspaceBind**-like result:
- a directory/tree becomes visible in a view,
- the shell can browse/edit/search within that bound tree,
- but workspace-contributed automation remains inert.

This is the closest analogue to “open folder in restricted mode”.

### 2. Treat workspace automation as a second, typed grant family
Automation classes should stay visibly separate, for example:
- `env-hook`
- `task`
- `debug-launch`
- `agent`
- `notebook-exec`
- `workspace-tooling`
- maybe later: `codegen`, `formatter`, `project-service`

A workspace can be bound without any of those being trusted.

### 3. Parse metadata as data before treating it as authority
ViewFS should be willing to:
- read a workspace task file,
- show a launch configuration,
- inspect a notebook,
- diff an env-hook proposal,
- and explain what would run,

without granting permission to execute it.

That keeps inspection ahead of activation.

### 4. Keep user automation distinct from workspace automation
User-owned workflows, recipes, and global tools should remain a separate class from workspace-contributed ones.
A helpful shell can still offer:
- user-trusted commands against the workspace,
- workspace-suggested recipes in a blocked/inspect-only state,
- promotion paths from inspected workspace recipes into user-owned safe workflows.

This is one of the best ideas to steal from the distinction between VS Code user tasks and workspace tasks.

### 5. Trust should invalidate on meaningful workspace automation changes
If ViewFS records a durable “trusted workspace automation” state later, it should likely be invalidated by changes to the automation-bearing surface, not by every unrelated file edit.
The direnv `require_allowed` idea is strong here: changes to the relevant allow-listed files should require a re-approval step.

### 6. Trusted locations should be treated carefully
JetBrains and VS Code both expose trusted locations / trusted folders. That is useful, but it is also where scope creep can turn convenience into ambient trust.
If ViewFS ever adopts trusted parent roots or org-managed trust stores, it should keep them:
- visible,
- reviewable,
- revocable,
- and clearly separate from ordinary workspace binds.

## A promising future object family
Without freezing protocol names yet, ViewFS may eventually want concepts such as:
- **WorkspaceBindReceipt** — proof that a tree was bound into a view,
- **WorkspaceTrustRecord** — non-bearer statement that certain automation classes were approved,
- **AutomationManifest** — inert description of tasks/launchers/env hooks/agents sourced from the workspace,
- **AutomationDiff** — “what changed since this workspace was last trusted?”,
- **TrustStatus** — `browse-only`, `env-blocked`, `tasks-blocked`, `debug-blocked`, `agents-blocked`, `trusted`.

The important thing is the split, not the final names.

## How this maps onto SlopOS seams
- **workspace bind / view assembly** ↔ `view-namespace-posture-v0.md`, `capshell-cwd-root-posture-v0.md`, `capshell-filesystem-posture-v0.md`
- **command / task execution** ↔ `capshell-command-string-posture-v0.md`, `capshell-exec-pack-schema-v2.md`
- **word expansion / shell safety** ↔ `capshell-word-expansion-posture-v0.md`, `rfcs/0115-capability-safe-shell-and-automation.md`
- **document / chooser-mediated tree access** ↔ `document-portal-posture-v0.md`, `document-handle-schema-v0.md`
- **OpenURI / reveal remains separate** ↔ `openuri-portal-posture-v0.md`

SlopOS already has enough seams that ViewFS does not need “open project” to mean “execute project”.

## Shell implications
- opening a workspace should default to a **browse-only** or **restricted** badge, not silent full trust
- the shell should show which automation classes are blocked or trusted
- “why is this blocked?” should point to the manifest and the missing approval
- user/global workflows should be visibly distinct from workspace-suggested ones
- re-trust prompts should highlight the automation diff, not just re-ask a vague yes/no question
- notebook cells, debug configs, and task launchers should advertise whether they are inspect-only or executable

## Anti-goals
- binding a folder and silently running its startup automation
- letting workspace manifests piggyback on the same authority as live filesystem access
- treating “trusted location” as a hidden ambient-trust wildcard
- making task/debug/agent enablement irreversible or hard to inspect
- treating notebook outputs or task history as proof that current automation is still trusted
