# Rights attenuation and bundles

Purpose: pin two important ideas early:
1. **attenuation should be cheap and visible**, and
2. **bundles should be explicit transport/grouping objects, not hidden namespace inheritance**.

This file is intentionally pre-decisional.

## Rights attenuation

### Working posture
- handles should normally start no broader than the authority they actually need.
- duplication with reduced rights should be common.
- widening an existing handle should be impossible or should require minting a visibly new handle from a higher-authority parent.

### Lessons worth stealing
- REF-CAPSICUM-RIGHTS: rights can be reduced but not expanded on a descriptor.
- REF-FUCHSIA-DIR-CAPS and REF-FUCHSIA-RIGHTS: directory/object access is routed with rights rather than assumed globally.
- REF-CAPSTD: capability-oriented APIs become easier to audit when ambient authority is an explicit opt-in rather than a hidden fallback.

### Candidate right dimensions
- read / enumerate / stat
- create / write / append / replace
- execute / map-as-code
- rebind / attach-into-view
- delegate / duplicate / attenuate
- observe metadata / provenance / history

The exact lattice should remain small until there is evidence for finer splits.

## Capability bundles

### Why bundle at all?
Some workflows need to move several related handles together:
- launch a tool with `/work`, `/tmp`, one output sink, and one service directory
- hand a document plus its related export sink to a viewer
- move a small authority kit through a portal or shell workflow without re-deriving every piece by name

### The safe model
Bundles should be:
- explicit objects with typed members
- inspectable before use
- routeable through the same receipt/transcript story as other objects
- usable as *transport* or *launch convenience*, not as a backdoor to reintroduce ambient roots

### Inspirations
- REF-FUCHSIA-DICTCAP: dictionaries group capabilities as one routed unit and can nest.
- REF-WASI-CAPS and REF-WASMTIME-PREOPEN: runtime handles are the authority truth even when paths are used as compatibility syntax.
- SlopOS RFC-0115 wallet language suggests a good UX wrapper for inspection, even if the bundle object itself remains non-authoritative metadata at first.

## What not to do
- do not let “bundle” become “here is basically a private host filesystem again”.
- do not make bundle members discoverable by ambient search.
- do not let shell helpers silently widen bundle rights for convenience.

## Recommended experiments
- R1: handle duplication + attenuation rules with a tiny rights lattice
- R2: launch-time `CapabilityBundle` object with named members and receipt rendering
- R3: shell inspector that explains bundle contents and rights before execution
- R4: explicit ambient-authority marker in developer tools whenever a fallback to host paths is invoked

## Early UX idea
Every shell-visible handle or bundle should have an **explain** surface:
- where it came from,
- what rights it has,
- whether it is attenuated,
- whether it can be re-delegated,
- and what view or portal grant minted it.


## Declared caveats versus enforced attenuation

One more seam is worth freezing early:

- a **declared caveat set** (for example, `read-only`, `allowedAction=view`, `expires tonight`, `only from this route`) is not the same thing as
- one **enforced membrane / lease proxy** that actually checks those bounds on use, and neither is the same thing as
- one **live local handle** that is currently usable now.

Why this matters:
- macaroons and zcaps are powerful precisely because attenuation terms can travel with delegated authority,
- but SlopOS D-LEASE is a useful reminder that the **proxy may be the authority**, while descriptors are only audit/receipt material,
- and shell UX gets much better when it can tell `declared bounds` from `enforced here now`.

Low-regret posture:
- keep caveat sets monotonic and inspectable,
- keep enforcement locus visible,
- keep revival/revalidation separate from current handle use,
- do not let transcript hints or history rows masquerade as proof of live enforcement.
