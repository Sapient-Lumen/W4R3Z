# Activation carriers, badged handle copies, and object identity

ViewFS should keep one startup/handoff seam explicit while SlopOS is still fluid: **activation carrier**, **current live handle copy**, **issuer-visible badge/witness**, **underlying object identity**, **receiver-local bind/name**, **later revival designator**, and **history receipt** are not the same class.

That sounds fussy, but it prevents several ancient mistakes from sneaking back in under shiny capability-native branding:
- a startup slot stops pretending to be a durable path;
- a copied capability stops pretending to be immutable object identity;
- a courier/source witness stops pretending to be universal trust;
- a transcript receipt stops pretending to be still-live authority;
- and a later reopen lane, if it exists at all, stays a separate explicit promise.

This is a low-regret seam because SlopOS already leans in the right direction. Its launch assembly, handle-table population, capability-routed views, and portal/document-handle posture all emphasize explicit construction instead of ambient rediscovery. ViewFS can align with that posture without deciding the final object-store substrate, the exact durable-handle story, or one universal portal/import protocol today.

## 1. The classes we should refuse to collapse

### 1.1 Activation carrier
This is how authority arrives at startup or handoff time.
Examples:
- a named startup slot;
- a portal result row;
- a courier packet that contains a live handle;
- a reviewed route-plan output;
- a shell-local handoff sheet.

Questions it answers:
- where did this come from right now?
- through which reviewed lane did it enter?
- what child-local label or slot is attached to the delivery?

Questions it does **not** answer:
- what is the object's immutable identity?
- can it be reopened later?
- is the same authority still available after restart?
- should another process be able to rediscover it by name?

### 1.2 Live handle copy
This is the current usable authority in one process or pane.
It may be duplicated, attenuated, passed, or dropped.
It answers `usable here, now, with these rights`.
It does **not** imply durable reopen or universal portability.

### 1.3 Issuer badge or courier witness
This is metadata about the copy or the delivery lane.
Examples:
- service-manager startup slot provenance;
- peer credentials for a local courier event;
- an issuer badge on a minted handle copy;
- a portal-owned request/result witness.

It answers `who handed this to me` or `through what lane`.
It does **not** answer `what object is this forever`.

### 1.4 Underlying object identity
This is the narrowest durable sameness claim ViewFS can make.
If we have an immutable object ref, content address, or another exact object identifier, that is separate from both slot names and copy lineage.
It answers `what object is this`.
It does **not** answer `what rights do I currently hold` or `where did this copy come from`.

### 1.5 Receiver-local bind or local alias
A process may bind the arriving resource into its local namespace under a useful label.
That label is helpful ergonomics, not object truth.
It answers `what name does this process use for it right now`.
It does **not** answer `what slot delivered it` or `what durable name should every future process use`.

### 1.6 Later revival designator
If ViewFS eventually supports narrow continuity lockers, document handles, or other restart-friendly designators, those should remain a separate class.
They answer `what explicit lane might recreate or reacquire this later`.
They do **not** answer `is the current live copy still open`.

### 1.7 Receipt or history row
This is durable explanation only.
It answers `what happened before`.
It does **not** revive current authority.

## 2. Lessons we must learn from the past

### 2.1 Personal namespaces are powerful, but path centrality is a trap
Plan 9 got something profoundly right: each process can receive its own assembled namespace, and namespace construction is a first-class way to shape authority. The trap is thinking that because a namespace is powerful, every durable truth must become a path lookup again. ViewFS should steal **personal namespace assembly**, not `everything important becomes a string path`.

### 2.2 Creator-assembled capability views age better than ambient discovery
Fuchsia's namespace and capability routing story is a great modern reminder that a process can start with an explicit view assembled for it, with rights and role shaping decided outside the child. That is very close to the ViewFS/SlopOS seam we want. The lesson is not to copy declarative syntax; it is to keep startup authority **assembled**, not rediscovered later by ambient APIs.

### 2.3 Socket activation is a startup-delivery lesson, not a universal persistence story
Systemd socket activation is worth stealing because it makes startup-delivered handles normal. Systemd's fd store is also worth stealing, but only narrowly: it shows that a small, typed continuity locker can exist without becoming a magical general persistence substrate.

### 2.4 Local handle courier lanes should stay explicit
UNIX descriptor passing and related local courier mechanisms are useful because they make cross-process handoff an explicit act. The deep lesson is that a cross-process transfer should look like `send/receive a current copy`, not `whoever knows the old path can reopen it whenever`.

### 2.5 Badges belong to copies, not to object identity
seL4 badge practice is gold here. A badge can tell us something valuable about a minted copy or sender lane. But the minute we treat that badge as the object's immutable identity, we start lying to ourselves.

### 2.6 Shell history becomes dangerous when it silently upgrades itself into authority
Terminals and shells repeatedly drift into heuristics: cwd guessing, path scraping, click-to-open folklore, or replaying blocks whose authority context is gone. The lesson is not to avoid delight. It is to make the delight ride on explicit metadata, truth grades, and safe downgrade paths.

## 3. Low-regret architecture posture for ViewFS

### 3.1 Prefer handed-in resources over child rediscovery
If a child should have something, prefer handing it in through explicit slots, imports, portal results, or reviewed handoff packets rather than asking the child to rediscover it from mutable names.

### 3.2 Let slot names be useful, but obviously narrow
A slot can be stable inside one launch contract while still not meaning durable global name, immutable identity, or future reopen authority.
Recommended shell copy:
- `slot: source_tree`
- `live handle: yes`
- `object ref: known/unknown`
- `reopen lane: none/portal/document-handle/locker`
- `receipt: RID-...`

### 3.3 Keep copy lineage inspectable
When a handle is duplicated, narrowed, or couriered, preserve copy-lineage explanation:
- issuer or courier source;
- attenuation delta;
- launch slot or route-plan origin;
- whether the target is the same object ref or only heuristically related;
- whether any current peer/process witness exists.

### 3.4 Do not freeze one durable-handle story yet
Because SlopOS is still in design, ViewFS should avoid prematurely choosing whether restart continuity is driven by:
- portal-mediated document handles,
- narrow continuity lockers,
- object refs plus fresh rebind,
- app-specific remembered designators,
- or multiple lanes.

The seam matters now; the winning implementation can stay open.

### 3.5 Keep imports mediated, but plural
`portal-mediated imports` should remain an umbrella posture, not a single final protocol commitment.
Useful candidates can coexist:
- chooser-owned import for user intent;
- route-plan mediated local handoff;
- peer courier send/receive within one trust envelope;
- reviewed startup activation kit;
- durable document-handle reacquire lane.

What matters is that all of them surface the same split truths.

## 4. Suggested user-visible vocabulary

The future shell should be able to say these with discipline:
- `activation slot`
- `live handle`
- `issuer badge`
- `peer witness`
- `object ref`
- `local bind`
- `reopen lane`
- `receipt only`

Bad UI vocabulary to avoid:
- `opened` when the truth is only `selected`;
- `same file` when the truth is `same object ref unknown, same source label only`;
- `saved for later` when the truth is only `history receipt`;
- `trusted` when the truth is only `known courier witness`.

## 5. Custom shell and terminal moves worth stealing

### 5.1 Activation-sheet card
Before launch, show one compact card with:
- slot names;
- exact incoming handles/capsules;
- current rights summary;
- issuer/courier witness quality;
- whether each row has object identity, local bind only, or receipt only.

### 5.2 Child-slot diff
After launch, keep a receipt that says what crossed the boundary and under what child-local names.
This makes inheritance visible and helps kill accidental authority leaks.

### 5.3 Copy-lineage drawer
A per-handle inspector should show:
- parent/source handle;
- duplicate vs attenuated copy;
- badge/witness information;
- same-object-ref known/unknown;
- revival lane available/unavailable.

### 5.4 Handoff sheet
When one pane, tool, or app sends something to another, show a handoff sheet rather than a vague `open in...` event.
Suggested rows:
- `offered:` live handle / staged bytes / object ref / route packet
- `witness:` peer creds / issuer badge / portal request / none
- `adopted as:` slot or local bind
- `still live:` yes/no
- `history row:` receipt id

### 5.5 Truth-grade command blocks
Blocks should advertise whether they are:
- plain text,
- semantically marked,
- shell-reported command,
- reviewed command packet,
- or result receipt.

Only stronger classes get stronger actions.

### 5.6 Paste capsules
Steal bracketed-paste-style origin truth and make paste/import boundaries explicit.
A custom shell can distinguish:
- typed input,
- pasted text,
- imported object token,
- routed command packet.

That will make inspect-before-run ergonomics dramatically better.

### 5.7 Semantic transcript boundaries
Steal OSC 133 / semantic zone ideas liberally.
Prompt, input, output, route action, adoption result, and receipt emission should be explicit protocol events, not guessed from pixels.

## 6. Non-decisions to preserve

Do **not** decide yet:
- one universal on-disk object-store layout;
- one universal object-identity format beyond whatever narrow exact refs already exist;
- one exact startup-slot carrier primitive for every runtime and platform;
- whether restart continuity is shell-owned, supervisor-owned, portal-owned, or split;
- one global route/import protocol for all local and remote transfers;
- whether local bind names are stable across launches;
- whether every handle copy can reveal exact object identity;
- whether shell cards are terminal-native overlays, out-of-band HUD objects, or both.

## 7. Practical next experiments

1. Add one **activation-sheet** prototype to the shell/terminal protocol.
2. Add one **copy-lineage drawer** with `slot`, `rights`, `issuer`, `object_ref`, and `reopen_lane` fields.
3. Add one **handoff sheet** prototype for pane-to-pane or tool-to-tool send/receive.
4. Keep durable continuity limited to explicit lockers or portal/document-handle rows only.
5. Refuse any feature that makes old receipts or old slot names masquerade as present live authority.

That gives ViewFS a truthful object-store + capability + namespace direction while preserving room for SlopOS to settle the surrounding runtime and portal seams first.
