# Bundles, view fragments, workspace binds, and launch kits

Purpose: keep **grouped authority objects**, **namespace fragments/templates**, **live view bindings**, **per-process launch kits**, and **historical receipts** on distinct seams.

Capability-native systems repeatedly run into the same temptation: once we have several handles that travel together, it feels natural to let one object stand for **the bundle**, **the namespace subtree**, **the current bind**, **the launch environment**, and **the history artifact** all at once.

That shortcut is attractive and dangerous. It quietly rebuilds ambient behavior through convenience.

## Useful precedents
- **REF-FUCHSIA-SANDBOXING**: processes start with no capabilities; a creator passes handles, populates a private namespace, and the process cannot simply add new objects to its own namespace because that would self-grant authority.
- **REF-FUCHSIA-NAMESPACE** and **REF-FUCHSIA-SECURE**: `/` is private and synthetic rather than a machine-global truth.
- **REF-FUCHSIA-DICTCAP** and **REF-FUCHSIA-DICT-RFC**: grouped capabilities can be explicit, nested, and routed as a named structure.
- **REF-XDG-DOCUMENTS** and **REF-XDG-DOCS-FUSE**: durable access commonly appears as a restricted synthetic view rather than as a broadened global namespace.
- **REF-CAPSTD** and **REF-WASMTIME-PREOPEN**: runtime handles and explicit ambient-authority markers keep compatibility and convenience subordinate to authority truth.

## Distinctions worth preserving

### 1. Bundle is not view fragment
A **bundle** (or dictionary / authority kit) is a typed grouping of handles or refs.
A **view fragment** is a namespace-shaped subtree or template that could be bound into some view.

A bundle may contain members that could populate several different view layouts. A view fragment may be materialized from several sources and may outlive any one bundle.

### 2. View fragment is not live binding
A **view fragment** says what could be attached.
A **live bind** says what is attached right now into some concrete process view.

That difference matters for replay, handoff, permission review, and “why can this pane see this object?” explanations.

### 3. Live binding is not launch kit
A **live binding** mutates an existing view.
A **launch kit** assembles the child process start state: handle table, synthetic `/`, stdio, cwd binding, optional env, and any pre-bound service trees.

A launch kit may derive from existing binds, bundles, explicit receipts, and last-mile attenuation rules. It should not be forced to share one stored representation with any of them.

### 4. Launch kit is not receipt
A **launch kit** is authority that may be used now.
A **receipt** is history about how that authority was assembled or used.

Receipts should remain replay aids, audit artifacts, and teaching surfaces. They should not silently remain bearer authority.

### 5. Grouping should not become hidden inheritance
If several authorities travel together, that is a reason to name and inspect the grouping object.
It is **not** a reason to let children discover extra roots, widen rights, or recover members by ambient search.

### 6. Child namespaces should stay creator-populated
The cleanest lesson from capability systems is that the more-authoritative parent or launcher constructs the child namespace.
That means:
- new live binds come from explicit higher-authority acts,
- child-local edits cannot mint new authority from nowhere,
- and `/` should be explained as the result of assembly, not as a global given.

### 7. One object may participate in several classes, but the classes still matter
The same workflow may involve:
- a bundle used for inspection and transport,
- a fragment used as a namespace template,
- a bind receipt recording that it entered a view slot,
- and a launch receipt recording the final child assembly.

Shared implementation is fine later. Semantic collapse now is not.

## Shape that feels promising
ViewFS probably wants distinct object/receipt families such as:
- **AuthorityBundle** — named grouped members and rights summaries
- **ViewFragment** — a reusable subtree/template that can be bound into some view slot
- **ViewBindReceipt** — transcript-visible proof that a fragment or object entered a concrete view
- **LaunchKit** — child-process start material assembled from explicit inputs
- **LaunchReceipt** — what actually launched, with attenuation and debt notes

The exact schemas can wait. The class distinction should not.

## Nifty ideas worth stealing
- **Launch rehearsal cards**: before Enter commits, show the candidate child namespace assembly, rights summary, portal requirements, and any ambient debt.
- **Kit inspectors**: inspect grouped authority like a wallet/card rather than as invisible environment folklore.
- **View cards per pane**: show which binds are live here now, distinct from what a saved workflow merely remembers.
- **Bind-vs-launch diffing**: let the shell explain how the child kit differs from the current pane view.
- **Receipt-only save modes**: save a recipe or notebook cell without silently serializing live authority.

## What not to decide yet
- whether bundles are only transient launch helpers or also durable stored objects
- whether view fragments are explicit persisted objects or mostly derived templates
- whether launch kits have one canonical schema or several execution-family-specific renderings
- whether bundle members may be refs/receipts only, live handles only, or mixed
- whether shell syntax says `bind`, `kit`, `launch`, `with`, or something else

## Near-term recommendation
For the next narrow spikes:
1. keep **bundle**, **view fragment**, **live bind**, **launch kit**, and **receipt** as explicit vocabulary,
2. make child namespace assembly creator-visible and transcript-visible,
3. require explicit bind/rebind acts for new live authority,
4. let grouped authority travel as named inspectable members rather than hidden inheritance,
5. and prototype one shell-level rehearsal flow before freezing any stored bundle schema.
