# Claim registry

| ID | Claim |
|---|---|
| C-VIEWFS-1 | ViewFS core semantics do not require an ambient machine-global filesystem namespace. |
| C-VIEWFS-2 | Path compatibility can be constrained to authority already present in explicit handles/views. |
| C-VIEWFS-3 | Portal-mediated imports/exports can provide explicit, inspectable authority transitions. |
| C-VIEWFS-4 | A simple immutable-first object store is sufficient for the first useful ViewFS slice. |
| C-VIEWFS-5 | ViewFS can align with existing SlopOS seams for views, document handles, plumb-style messages, and transcripted execution rather than inventing parallel abstractions. |
| C-VIEWFS-6 | A first-class shell/terminal can materially improve safety by exposing view identity, authority previews, receipts, and semantic command/output boundaries. |
| C-VIEWFS-7 | ViewFS can remain useful while treating immutable identity, naming, mutable current state, and durable reopen authority as distinct surfaces rather than one overloaded filesystem primitive. |
| C-VIEWFS-8 | ViewFS can use host-side bridges and defense-in-depth backstops during bring-up while still keeping handles, views, portals, and receipts as the user-facing explanation of authority. |
| C-VIEWFS-9 | ViewFS can keep workspace/tree binds, durable reopen, transfer handoff, and URI launch as related but distinct authority classes instead of collapsing them into one generic “open” action. |
| C-VIEWFS-10 | ViewFS can give users convenient recent-item, reopen, and reveal workflows while still keeping immutable identity, workspace binding, and route behavior as distinct seams. |
| C-VIEWFS-11 | ViewFS can make shell history, recents, and workflow transcripts useful while still distinguishing live handles, durable refs, and receipt artifacts. |
| C-VIEWFS-12 | ViewFS can make journals, notebooks, workflows, and pane/session restore highly useful while still keeping saved session state distinct from live authority. |
| C-VIEWFS-13 | ViewFS can offer search, recents, smart selectors, and palette-driven navigation while still keeping those registries advisory rather than identity- or authority-bearing. |
| C-VIEWFS-14 | ViewFS can separate workspace/tree access from permission to execute workspace-defined automation, allowing a useful restricted project-opening mode without ambient startup behavior. |
| C-VIEWFS-15 | ViewFS can offer live watch panes, auto-refreshing queries, and notification UX while still keeping watch registrations and event feeds advisory, scoped, and rebuild-friendly rather than authority-bearing truth. |
| C-VIEWFS-16 | ViewFS can make clickable links, aliases, breadcrumbs, and shortcuts highly productive while still distinguishing live handles, local names, durable reopen refs, route objects, and receipt links. |

| C-VIEWFS-17 | ViewFS can make origin/quarantine UX highly legible while still distinguishing origin evidence, risk state, safe-open lanes, explicit trust receipts, and live authority. |
| C-VIEWFS-18 | ViewFS can offer cheap checkpoints, writable forks/worktrees, replication/export receipts, and publish/activation workflows while still keeping those classes visibly distinct in both the object model and the shell. |
| C-VIEWFS-19 | ViewFS can coordinate concurrent edits and automation honestly while keeping expected-old guards, short leases, ownership hints, conflict artifacts, and explicit takeovers as separate classes rather than one universal lock primitive. |
| C-VIEWFS-20 | ViewFS can offer shell-owned smart folders, snapshot result sets, and optional live query feeds while keeping query recipes, current results, feed health, and live authority as distinct user-visible classes. |
| C-VIEWFS-21 | ViewFS can offer prefetch, cache warmth, hydration, pinning, mirror workflows, and offline-readiness UX while still keeping those classes distinct from durable authority, publication, or activation semantics. |
| C-VIEWFS-22 | ViewFS can give users reusable authority kits and per-process namespace recipes while still keeping grouped authority, live binds, launch assembly, and receipt history as distinct user-visible classes. |
| C-VIEWFS-23 | ViewFS can make mediated chooser/import workflows delightful while still keeping request state, chooser-owned candidate sets, selected outcomes, minted grants/refs, live binds, and receipt history as distinct user-visible classes. |
| C-VIEWFS-24 | ViewFS can make route/action planning highly visible and interactive while still keeping intent, exact approval basis, committed execution, and result receipts as distinct user-visible classes. |
| C-VIEWFS-25 | ViewFS can make suggested automation, promoted user-owned workflows, notebook/runbook cells, and replay highly productive while still keeping suggestion provenance, prepared plans, committed runs, and history receipts as distinct user-visible classes. |
| C-VIEWFS-26 | ViewFS can support temporary authority sharing and renewal flows while still distinguishing live borrowed handles, durable delegated refs, issuer-side recall powers, and loan-end receipts. |
| C-VIEWFS-27 | ViewFS can make replay, reopen, and renewal highly productive while still keeping reuse candidates, exact basis records, current drift checks, fresh reconsent checkpoints, renewed artifacts, and history receipts as distinct user-visible classes. |
| C-VIEWFS-28 | ViewFS can make replay/import/run explanations highly legible while still keeping admissible witness material, caveat sets, freshness evidence, why-records, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-29 | ViewFS can make policy-aware shelling highly productive while still keeping validation/schema material, authoritative policy/caveat material, shell advice rails, decision diagnostics, and durable logs/receipts as distinct user-visible classes. |
| C-VIEWFS-30 | ViewFS can make policy-family selection, fallback, and repair UX highly productive while still keeping policy-family/catalog choice, exact authoritative cuts/consistency posture, fallback candidates, repair proposals, and durable selection receipts as distinct user-visible classes. |
| C-VIEWFS-31 | ViewFS can surface workspace/profile/org/history/helper proposals richly while still keeping proposal provenance, requested scope, explicit adoption, and durable adoption history as distinct user-visible classes. |
| C-VIEWFS-32 | ViewFS can surface deny ceilings and narrowing choices richly while still keeping authoritative ceilings, scope eligibility, narrowing transforms, escalation attempts, and durable adoption history as distinct user-visible classes. |
| C-VIEWFS-33 | ViewFS can make source-aware shell ergonomics highly productive while still keeping owner/org policy sources, trust-state gates, user/profile preferences, workspace/imported helper material, and effective active state as distinct user-visible classes. |
| C-VIEWFS-34 | ViewFS can make trusted carriers and rich discovery surfaces highly productive while still keeping policy author classes, carrier/container classes, trust gates, advisory-only sources, and effective active state as distinct user-visible classes. |
| C-VIEWFS-35 | ViewFS can make lower-trust helper material highly productive while still keeping protected-authorable state, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-36 | ViewFS can make helper lifecycle UX highly legible while still keeping publisher trust, installed helper packages, configured helper definitions, enabled state, start approvals, live sessions, request-scoped selections, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-37 | ViewFS can make helper feature catalogs highly productive while still keeping resources, prompts, tools, interactive app surfaces, completion suggestions, request-bound attachments, live invocation/results, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-38 | ViewFS can make deferred helper/automation work highly productive while still keeping immediate requests, accepted task wrappers, live progress/status, input-required checkpoints, deferred final results, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-39 | ViewFS can make deferred stop/retry control highly productive while still keeping close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-40 | ViewFS can make live-session shell UX highly productive while still keeping read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable transcripts as distinct user-visible classes. |

| C-VIEWFS-41 | ViewFS can make explicit sharing/handoff highly productive while still keeping transfer offers, accepted representations, live copied handles, later revival designators, receiver-local adopted binds, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-42 | ViewFS can make attenuation/delegation UX highly productive while still keeping declared caveat sets, enforced membrane/lease proxies, live attenuated handles, later revival designators, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-43 | ViewFS can make permission-state and repair UX highly productive while still keeping permission outlook, revival designators, current live handles, explicit death-state verdicts, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-44 | ViewFS can make provenance claims, endorsement inputs, local admit/deny verdicts, current live handles, and durable receipts highly visible while keeping those classes distinct in shell UX. |
| C-VIEWFS-45 | ViewFS can make request ledgers, session cards, portal-state lenses, and repair rails highly productive while still keeping request rows, session/transfer objects, portal-owned live state, local adopted binds/live handles, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-46 | ViewFS can make smart queries and smart folders highly productive while still keeping saved query recipes, current/frozen hit sets, live query feeds, materialized local collections, current binds, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-47 | ViewFS can make completion and replay UX highly productive while still keeping advisory candidates, accepted insertions, compiled command packets, prepared actions, trusted rerun affordances, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-48 | ViewFS can make place cards, verb ledgers, and affordance lenses highly productive while still keeping object identity, current placement, current handle-rights posture, advertised operations, and durable receipts as distinct user-visible classes. |
