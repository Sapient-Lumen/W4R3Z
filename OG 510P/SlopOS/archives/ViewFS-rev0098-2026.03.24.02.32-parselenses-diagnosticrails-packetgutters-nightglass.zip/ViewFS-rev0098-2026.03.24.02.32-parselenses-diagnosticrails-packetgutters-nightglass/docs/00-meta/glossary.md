# Glossary

- **View** — an explicit namespace object presented to a process or component as its local root.
- **Handle** — an unforgeable reference to an object plus rights.
- **Portal** — a mediated UX/service path that grants authority explicitly.
- **Object store** — the durable backing store for immutable blobs, manifests, and related metadata.
- **Compat membrane** — a deliberately subordinate path-based layer that maps legacy APIs onto explicit handles/views.
- **Grant receipt** — a durable, inspectable record that a portal-mediated action admitted some authority.
- **Snapshot root** — a manifest or root object that names a stable immutable closure.
