# LLM runbook

## Non-negotiables
- Do not silently enlarge authority.
- Do not treat path compatibility as the truth model.
- Keep portal/import/export semantics explicit.
- Mark unresolved choices as unresolved.
- Prefer stable vocabulary over catchy but vague prose.

## Must-read set before large edits
- `README.md`
- `docs/00-meta/charter.md`
- `docs/00-meta/trajectory-map.md`
- `docs/10-threat-model/assumption-registry.md`
- `docs/20-assurance/claim-registry.md`
- `docs/20-assurance/non-claims.md`
- `docs/30-architecture/architecture-overview.md`
- `rfcs/0001-viewfs-foundation-rfc.md`

## Output expectations
- Stable statements belong in architecture docs.
- Tentative design choices belong in the RFC until promoted.
- New references go through the bibliography.
- Update the changelog for every revision.
