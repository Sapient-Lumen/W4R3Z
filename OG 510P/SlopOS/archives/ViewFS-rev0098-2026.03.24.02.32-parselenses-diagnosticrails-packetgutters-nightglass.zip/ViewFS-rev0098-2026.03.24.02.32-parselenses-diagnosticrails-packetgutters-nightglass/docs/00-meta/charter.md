# Charter (canonical north star)

**Mission (canonical):** We are constructing a long-lived, evidence-tracked research archive to design ViewFS: a capability-native filesystem substrate for SlopOS whose core claims are explicit, narrow, and testable. ViewFS should unify immutable object storage, handle-based access, explicit per-process namespaces, and portal-mediated imports/exports while preserving room for future compatibility layers without letting those layers become hidden authority planes.

**Behaviors (canonical):**
scope-narrowly, delay-hard-commitments, minimize-ambient-authority, prefer-immutable-core,
keep-compat-killable, make-imports-explicit, record-open-questions, separate-claims-from-hunches,
steal-good-ideas, pressure-test-persistence, keep-shell-ux-excellent, iterate-forever.

## Archive size discipline
- Prefer pointers over pasted text or heavyweight artifacts.
- One canonical source per concept.
- Every “new thing” must justify itself as an assumption, claim, invariant, RFC, ADR, or evidence artifact.
