# Annotated bibliography (REF index)

Rule: each REF entry is <=3 bullets: **key idea** / **why it matters** / **implication for us**.
No pasted papers; just pointers.

## Capability systems / namespace control
- **REF-CAPSICUM-SEC10** — Watson et al., *Capsicum: practical capabilities for UNIX* — https://www.usenix.org/event/sec10/tech/full_papers/Watson.pdf
  - key: capability mode removes access to global namespaces while preserving a migration path from UNIX APIs
  - why: strongest precedent for “compatibility membrane, not ambient authority”
  - us: keep path shims subordinate to handles and explicit entry into bounded execution
- **REF-CAPSICUM-RIGHTS** — FreeBSD/Ubuntu `rights(4)` manpage — https://manpages.ubuntu.com/manpages/jammy/man4/rights.4freebsd.html
  - key: capability rights can be reduced but not expanded, and rights like lookup/create/exec are made explicit
  - why: useful model for a small rights lattice over ViewFS handles
  - us: treat attenuation as routine, widening as exceptional or impossible in place
- **REF-CAPSICUM-ADOPTION** — FreeBSD Foundation, *Capsicum Internship* — https://freebsdfoundation.org/project/capsicum-internship/
  - key: capability discipline is much easier when designed in from the start; retrofitting needs tracing and tooling because developers struggle to find where authority is missing
  - why: strong reminder that ViewFS must invest in diagnostics and explainability, not just principles prose
  - us: build request/grant/bind ledgers, explain inspectors, and ambient-debt tracing early
- **REF-EROS** — Shapiro et al., *EROS: a fast capability system* — https://flint.cs.yale.edu/cs428/doc/eros.pdf
  - key: persistent capabilities create hard ordering/cycle problems between data and authority
  - why: warns against casual mutable capability persistence
  - us: prefer immutable objects + snapshot roots before richer mutable transactions
- **REF-KEYKOS** — Bomberger et al., *The KeyKOS Nanokernel Architecture* — https://css.csail.mit.edu/6.566/2018/readings/keykos.pdf
  - key: small capability kernels benefited from tuned primitives, checkpoints, and compatibility layers
  - why: demonstrates that capability systems can host legacy interfaces without making them foundational
  - us: keep compat as a layer and make checkpoint/snapshot strategy explicit
- **REF-CAPROS-USERDRIVERS** — CapROS design note, *Persistence and Non-Persistence* — https://www.capros.org/design-notes/UserDrivers.html
  - key: persistent capability systems must treat device-facing state as a special case rather than assuming every capability can survive checkpoint/restart cleanly
  - why: excellent warning against casually equating durable authority with durable hardware state
  - us: keep persistent authority optional and keep device/host-bridge capabilities on a separate seam
- **REF-TREESLS-SOSP23** — Wu et al., *TreeSLS: A Whole-system Persistent Microkernel with Tree-structured State Checkpoint on NVM* — https://dl.acm.org/doi/10.1145/3600006.3613160
  - key: whole-system persistence can be simplified by following a capability tree and using failure-resilient checkpointing
  - why: modern evidence that persistence is powerful, but also architectural, not merely a storage feature
  - us: treat capability-tree checkpoint ideas as later experiments, not as a Phase 1 commitment
- **REF-SEL4-CSPACE** — seL4 capability tutorial / manual — https://docs.sel4.systems/Tutorials/capabilities.html
  - key: capabilities live in explicit slots/spaces, can be copied or moved, can be minted with reduced rights, and can be revoked through their derivation tree
  - why: excellent language for explicit handle inventories, attenuation, and issuer-visible recall
  - us: consider stable slot semantics for ViewFS handles and keep loan lineage/recall separate from possession of current access
- **REF-CAPSTD** — cap-std / Bytecode Alliance — https://docs.rs/cap-std/latest/cap_std/
  - key: capability-based APIs can make ambient authority an explicit opt-in marker instead of a silent fallback
  - why: excellent developer-experience precedent for bring-up and debt tracking
  - us: mark any ambient path escape hatch loudly in ViewFS tooling and shell UX

- **REF-CEDAR-AUTHZ** — Cedar authorization docs — https://docs.cedarpolicy.com/auth/authorization.html
  - key: authorization returns a decision plus diagnostics, including determining policies and errors
  - why: great precedent for compact decision diagnostics that do not themselves become authorization
  - us: render policy-aware why cards without letting them become standing approval
- **REF-CEDAR-VALIDATION** — Cedar validation docs — https://docs.cedarpolicy.com/policies/validation.html
  - key: validation against schema is a separate step from runtime authorization, and schema changes can invalidate previously validated policies
  - why: strong reminder to keep validation surfaces separate from runtime allow/deny surfaces
  - us: give the shell separate UX for invalid policy/schema drift versus runtime denial
- **REF-OPA-CORE** — Open Policy Agent docs — https://openpolicyagent.org/docs
  - key: policy decision-making is decoupled from policy enforcement, and policies can return structured outputs rather than only allow/deny
  - why: useful precedent for keeping authoritative decisions separate from shell heuristics and UI behavior
  - us: let ViewFS policy-aware shelling stay structured without turning shell advice into enforcement truth
- **REF-OPA-DECISIONLOGS** — OPA decision logs — https://openpolicyagent.org/docs/management-decision-logs
  - key: durable decision logs are for audit/offline debugging and require masking/redaction controls
  - why: strong precedent for keeping logs useful but non-authoritative
  - us: any decision-log/audit-trace surface in ViewFS should be bounded, redacted, and clearly historical
- **REF-OPA-DISCOVERY** — OPA discovery docs — https://openpolicyagent.org/docs/management-discovery
  - key: policy/config discovery can be dynamic, but bootstrap configuration still overrides discovered configuration
  - why: good precedent for explicit precedence rather than hidden auto-selection
  - us: if ViewFS grows policy-family negotiation, precedence and source-of-truth must stay visible
- **REF-POLKIT-AUTHORITY** — polkit reference manual / authority model — https://polkit.pages.freedesktop.org/polkit/polkit.8.html
  - key: authority, per-session authentication agents, and temporary authorization are distinct pieces of the system
  - why: cautionary reminder that temporary authorization is useful but easy to let become sticky folklore
  - us: keep mediation acts, temporary approvals, and durable consequences on visibly separate seams

- **REF-MACAROONS-NDSS14** — Birgisson et al., *Macaroons: Cookies with Contextual Caveats for Decentralized Authorization in the Cloud* — https://research.google/pubs/macaroons-cookies-with-contextual-caveats-for-decentralized-authorization-in-the-cloud/
  - key: delegation credentials can carry contextual caveats that narrow how they may be used
  - why: strong precedent for making attenuation conditions explicit and inspectable
  - us: keep caveat sets explicit and separate from witness material, freshness evidence, and receipts
- **REF-ZANZIBAR** — Pang et al., *Zanzibar: Google's Consistent, Global Authorization System* — https://research.google/pubs/zanzibar-googles-consistent-global-authorization-system/
  - key: authorization answers can be tied to explicit consistency/freshness tokens instead of silent moving-head reads
  - why: useful analogy for replay/renewal freshness evidence without importing ACL semantics wholesale
  - us: treat freshness tokens as comparison evidence, not as grants or approval caches
- **REF-SPICEDB-CONSISTENCY** — SpiceDB consistency docs — https://authzed.com/docs/spicedb/concepts/consistency
  - key: exact snapshots, at-least-as-fresh reads, and fully consistent reads are explicit modes, and ZedTokens name a point-in-time cut
  - why: excellent precedent for treating cut/freshness choice as separate from the authorization answer itself
  - us: if ViewFS records policy cuts or replay cuts, keep the cut token distinct from approval and advice

## Namespaces / routing
- **REF-FUCHSIA-NAMESPACE** — Fuchsia namespaces — https://fuchsia.dev/fuchsia-src/concepts/process/namespaces
  - key: no global root; each component receives its own composite namespace
  - why: directly matches ViewFS per-process root ambitions
  - us: make `/` synthetic and local to a view
- **REF-FUCHSIA-DIR-CAPS** — Fuchsia directory capabilities — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/directory
  - key: directories are capabilities routed with explicit rights
  - why: useful precedent for view slot bindings and rights attenuation
  - us: bind directories as capabilities, not as discovered paths
- **REF-FUCHSIA-RIGHTS** — Fuchsia handle rights — https://fuchsia.dev/fuchsia-src/concepts/kernel/rights
  - key: rights are attached to handles and can be reduced
  - why: capability attenuation should be first-class in ViewFS
  - us: design handle duplication / attenuation before fancy search features
- **REF-FUCHSIA-DICTCAP** — Fuchsia dictionary capabilities — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/dictionary
  - key: multiple capabilities can be grouped and routed as one nested key/value capability
  - why: attractive model for bundling launch-time or portal-time authority without collapsing back into ambient paths
  - us: explore explicit capability bundles/dictionaries rather than inventing hidden grouped handle handoff
- **REF-FUCHSIA-RUNNER** — Fuchsia component runners — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/runner
  - key: runner capabilities are registered through environments, selected by component program metadata, and receive start info including executable and namespace
  - why: strong primary-source precedent that “what runs” and “what runtime/runner hosts it” are different seams
  - us: keep exec object identity, runner/runtime choice, and resulting live session visibly separate
- **REF-FUCHSIA-CAPS** — Fuchsia capabilities overview — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities
  - key: components interact through routed capabilities, while some capability types are routed to environments rather than directly to instances
  - why: useful supporting precedent that environment-hosted choices should not be confused with instance-visible namespace contents
  - us: keep runner/environment posture separate from live per-process authority and object identity
- **REF-FUCHSIA-SECURE** — Fuchsia secure principles / no ambient authority — https://fuchsia.dev/fuchsia-src/concepts/principles/secure
  - key: Fuchsia explicitly frames itself as having no ambient authority and no global filesystem, with each program operating in its own local namespace
  - why: matches the clearest conceptual story we want ViewFS to tell
  - us: use this as language discipline, not just as implementation inspiration
- **REF-FUCHSIA-SANDBOXING** — Fuchsia software isolation / sandboxing model — https://fuchsia.dev/fuchsia-src/concepts/security/software_isolation
  - key: processes start with no capabilities; a creator passes handles, constructs the private namespace, and the child cannot add namespace objects by itself without self-granting authority
  - why: strongest current precedent for keeping bundle, bind, and child-launch assembly as distinct acts
  - us: make child namespace assembly creator-visible and keep launch kits separate from stored bundles or receipts

- **REF-FUCHSIA-DICT-RFC** — Fuchsia RFC-0235 component dictionaries — https://fuchsia.dev/fuchsia-src/contribute/governance/rfcs/0235_component_dictionaries
  - key: capability bundles can be explicit runtime and declarative objects rather than implicit inheritance
  - why: reinforces that grouped authority can stay visible and structured
  - us: if ViewFS grows bundles, keep them reviewable and named
- **REF-FUCHSIA-IDLE-STOP** — Fuchsia stop-idle / handle escrow docs — https://fuchsia.dev/fuchsia-src/development/components/stop_idle
  - key: a framework can escrow just enough handles/state to resume a narrow conversation later
  - why: strong precedent for continuity without pretending the whole authority graph was persisted
  - us: keep resume/escrow as its own typed seam, separate from durable reopen and persistent roots
- **REF-WASI-CAPS** — WASI capabilities note — https://github.com/WebAssembly/WASI/blob/main/docs/Capabilities.md
  - key: use runtime handles when multiple distinct live resources must coexist
  - why: exactly the ViewFS file/object handle case
  - us: prefer runtime handles over string re-resolution
- **REF-WASMTIME-PREOPEN** — Wasmtime WASI tutorial / preopened directory docs — https://github.com/bytecodealliance/wasmtime/blob/main/docs/WASI-tutorial.md
  - key: by default WebAssembly has no filesystem access; all path operations go through preopened handles
  - why: strongest compat pattern for ViewFS Phase 1
  - us: emulate preopens for legacy path APIs instead of making paths authoritative
- **REF-OPENAT2** — Linux `openat2(2)` manual — https://man7.org/linux/man-pages/man2/openat2.2.html
  - key: `RESOLVE_BENEATH` / `RESOLVE_IN_ROOT` exist because naive path rooting escapes easily
  - why: path compatibility is security-sensitive, even when “just starting from cwd”
  - us: no best-effort path membrane; fail closed on escape ambiguity
- **REF-LINUX-ACCESS** — Linux `access(2)` manual — https://man7.org/linux/man-pages/man2/access.2.html
  - key: a path is accessible only if each prefix directory grants search (execute) access
  - why: strong stable reminder that exact-name reachability and directory disclosure are different questions
  - us: keep `known child name works` distinct from browse/list truth
- **REF-WASI-P1-RIGHTS** — WASI Preview 1 rights docs — https://docs.rs/wasip1/latest/wasip1/
  - key: `RIGHTS_FD_READDIR` and `RIGHTS_PATH_OPEN` are separate rights
  - why: explicit precedent that enumeration and exact-name open are different surfaces
  - us: keep browse authority separate from exact-name reachability in ViewFS shells and providers
- **REF-LINUX-PATHLOOKUP** — Linux kernel docs, *Pathname lookup* — https://docs.kernel.org/filesystems/path-lookup.html
  - key: resolution-restriction flags block symlink and magic-link traversal across all path components
  - why: a rooted walker still needs explicit path-resolution policy
  - us: compat walkers should default to explicit nofollow/no-escape behavior rather than silent “best effort”
- **REF-CAPPRIMS-FS** — `cap_primitives::fs` docs — https://docs.rs/cap-primitives/latest/cap_primitives/fs/index.html
  - key: capability-oriented fs helpers expose rooted `open`/`open_dir`/`canonicalize` operations, plus explicit nofollow variants and absolute-target checks
  - why: good practical precedent for a compat membrane that never forgets its root
  - us: keep host-path helpers visibly capability-oriented and make nofollow a first-class option
- **REF-LANDLOCK** — Linux Landlock docs — https://docs.kernel.org/userspace-api/landlock.html
  - key: ambient rights can be restricted further by unprivileged user-space as a stackable safeguard
  - why: useful reminder that ViewFS can still benefit from lower-level backstops during bring-up
  - us: capability purity is primary, but ambient-rights restriction remains a valuable defense-in-depth tool
- **REF-PLAN9** — Pike et al., *Plan 9 from Bell Labs* — https://www.usenix.org/publications/compsystems/1995/sum_pike.pdf
  - key: private namespaces and uniform naming are powerful composition tools
  - why: ViewFS can learn from private namespaces without inheriting every “everything is a path” decision
  - us: steal personal namespace assembly, not ambient string centrality
- **REF-PLAN9-PLUMB** — Pike, *Plumbing and Other Utilities* — https://9p.io/sys/doc/plumb.html
  - key: a central typed message router lets programs exchange meaningful actions without every app inventing its own click/open heuristics
  - why: strong precedent for shell and terminal object-routing in a capability-native environment
  - us: receipts, handles, and open intents should be routeable objects, not just pasted strings
- **REF-DENO-PERMISSIONS** — Deno security and permissions — https://docs.deno.com/runtime/fundamentals/security/
  - key: secure-by-default runtimes can deny most I/O by default, expose explicit prompts/flags, and still remain usable
  - why: good precedent for inspect-first / approve-later action posture in the shell
  - us: keep prepare, approval, and commit as visibly distinct stages
- **REF-ANDROID-DOCPROVIDER** — Android custom document provider / `COLUMN_FLAGS` — https://developer.android.com/guide/topics/providers/create-document-provider
  - key: supported operations such as rename, copy, move, delete, and virtual-file export are provider-declared rather than guessed
  - why: excellent precedent for truthful route-plan cards and filtered action menus
  - us: only offer actions the source/provider actually supports
- **REF-MS-FUTUREACCESSLIST** — Windows FutureAccessList — https://learn.microsoft.com/en-us/windows/uwp/files/how-to-track-recently-used-files-and-folders
  - key: durable picked-item access is app-maintained, bounded, and not automatically garbage-collected by the platform
  - why: useful reminder that persistence surfaces need visible maintenance and limits
  - us: keep durable reopen stores explicit, reviewable, and pruneable

## Portals / mediated authority
- **REF-PLAN9-ACME** — plan9port `acme` manual — https://9fans.github.io/plan9port/man/man1/acme.html
  - key: text windows can expose rich services through files and structured control surfaces
  - why: reminds us that shell/editor/terminal UX can be objectful without abandoning text
  - us: inspire ViewFS route sheets, inspectors, and file-served control surfaces

- **REF-FLATPAK-BASICS** — Flatpak basic concepts — https://docs.flatpak.org/en/latest/basic-concepts.html
  - key: sandboxes default-deny and use portals for host interaction
  - why: clean desktop precedent for mediated file access
  - us: treat chooser/import/save as first-class authority events
- **REF-XDG-FILECHOOSER** — XDG FileChooser portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileChooser.html
  - key: chooser grants can make selected files accessible to sandboxed apps
  - why: matches ViewFS import flow expectations
  - us: portal-open must yield explicit handles and durable receipts
- **REF-XDG-DOCUMENTS** — XDG Documents portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Documents.html
  - key: document IDs can back a restricted synthetic view; per-app permissions can be granted or revoked; exported entries may be persistent or session-only
  - why: strong precedent for mediated import surfaces that stay inspectable and retractable
  - us: durable reopen, temporary lending, and issuer-side recall should be explicit classes rather than one sticky open state
- **REF-XDG-DOCS-FUSE** — XDG Documents & FUSE notes — https://flatpak.github.io/xdg-desktop-portal/docs/documents-and-fuse.html
  - key: the document portal can project a scoped virtual filesystem over selected files
  - why: useful design precedent for a synthetic view backed by grant state rather than ambient mounts
  - us: synthetic grant views should be inspectable and intentionally partial
- **REF-XDG-FILETRANSFER** — XDG FileTransfer portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileTransfer.html
  - key: drag/drop and copy/paste transfers are mediated by a transfer session that can export files to the target as needed
  - why: ViewFS should not limit mediation to file-pickers only
  - us: clipboard, drag/drop, and shell-to-app transfer should reuse the same portal/receipt story
- **REF-XDG-OPENURI** — XDG OpenURI portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.OpenURI.html
  - key: URI opening is mediated by a portal instead of direct helper execution
  - why: good precedent for typed external opening without ambient `xdg-open` semantics
  - us: keep URI launch as a separate seam from local file/document authority


- **REF-MACH-PORT-RIGHTS** — Apple Kernel Programming Guide, Mach overview — https://developer.apple.com/library/archive/documentation/Darwin/Conceptual/KernelProgramming/Mach/Mach.html
  - key: Mach splits send, receive, and send-once port rights, and rights can be copied or moved through IPC.
  - why: excellent precedent for not collapsing `have it`, `can send it`, and `can send it once` into one noun.
  - us: keep possession, live-lend posture, and consumable/send-once postures visibly distinct.
- **REF-SEL4-GRANT** — seL4 manual / API docs on endpoint rights and capability transfer — https://sel4.systems/Info/Docs/seL4-manual-latest.pdf
  - key: seL4 separates send/receive from Grant/GrantReply, and capability transfer only happens when the sending endpoint has the right grant posture.
  - why: strong precedent that couriering live authority is a narrower class than ordinary message send.
  - us: keep live-lend posture separate from plain routing, duplication, and bytes-only export.
- **REF-KITTY-FILETRANSFER** — kitty file transfer over the TTY — https://sw.kovidgoyal.net/kitty/file-transfer-protocol/
  - key: even terminals can expose an explicit file-transfer lane with its own representation and confirmation story.
  - why: good precedent for a custom shell+terminal that treats transfer lanes as first-class instead of as clipboard or path folklore.
  - us: explore TTY-native transfer badges and share sheets without making them the only export path.

- **REF-XDG-PORTAL-DESIGN** — XDG portal Requests / general flow — https://flatpak.github.io/xdg-desktop-portal/docs/requests.html
  - key: portal interactions have an explicit request object lifetime and a later response signal with results
  - why: excellent precedent for keeping request state separate from selected result, minted grant, and local bind
  - us: ViewFS imports should keep request, selection, and bind on different seams
- **REF-XDG-REQUEST** — XDG Request interface — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Request.html
  - key: a portal request object lives only for the user interaction and resolves to a response signal with results
  - why: excellent precedent for transcript-visible receipt objects that are not the same as durable grants
  - us: model chooser/save/rebind outcomes as request+response receipts distinct from reopen refs

- **REF-ANDROID-SAF** — Android Storage Access Framework — https://developer.android.com/guide/topics/providers/document-provider
  - key: long-term access is based on stable document IDs and explicit URI grants, yet moved/deleted objects still force re-consent or re-open logic
  - why: helpful precedent for durable grants that are useful but not magical
  - us: persistent reopen should depend on stable identity and visible failure semantics
- **REF-APPLE-SSB-CVE2025** — NVD record for CVE-2025-31191 — https://nvd.nist.gov/vuln/detail/cve-2025-31191
  - key: a recent security-scoped bookmark issue was fixed with improved state management after apps could access sensitive user data
  - why: durable grant mechanisms can become security-critical if validation and persistence semantics are too opaque
  - us: avoid invisible bookmark magic; keep durable grants inspectable and revocable

## Object stores / archival storage
- **REF-VENTI** — Quinlan and Dorward, *Venti* — https://9p.io/sys/doc/venti/venti.pdf
  - key: content hashes naturally enable write-once archival storage and deduplication
  - why: excellent model for immutable blob storage and snapshots
  - us: keep the backing store simple and immutable-first
- **REF-GIT-OBJECTS** — Git internals: objects — https://git-scm.com/book/en/v2/Git-Internals-Git-Objects
  - key: a simple content-addressed key-value store scales far with minimal object kinds
  - why: suggests a small core object vocabulary
  - us: start with blob/tree-ish/manifest primitives before adding richer object types
- **REF-NIX-CA** — Nix content-addressed store objects — https://nix.dev/manual/nix/2.26/store/store-object/content-address
  - key: content-addressed objects and closures can be separated from mutable working state
  - why: strong precedent for immutable application closures and reproducible roots
  - us: `/app` or equivalent closures should be immutable and content-addressed
- **REF-NIX-STORE** — Nix store manual — https://nix.dev/manual/nix/2.22/store/
  - key: the Nix store is an abstraction for immutable filesystem data with dependency closures
  - why: helpful broader precedent beyond just the content-addressed subfeature
  - us: keep immutable application/runtime closures distinct from mutable workspace state
- **REF-IPFS-CIDS** — IPFS content identifiers — https://docs.ipfs.tech/concepts/content-addressing/
  - key: content addressing and explicit data-model layers scale beyond single-file blobs
  - why: useful reminder that object identity and object transport can stay decoupled
  - us: keep ViewFS hash/object identity transport-agnostic and local-first by default
- **REF-IPFS-MFS** — IPFS file systems / MFS — https://docs.ipfs.tech/concepts/file-systems/
  - key: immutable content can sit under a mutable, name-based facade whose root pointer changes as edits happen
  - why: strong hint for how ViewFS might support working-state ergonomics without making mutable in-place storage foundational
  - us: explore mutable working sessions or root-pointer updates over immutable content, not inode-centric mutation first
- **REF-PERKEEP-PERMANODE** — Perkeep permanodes — https://perkeep.org/doc/schema/permanode
  - key: stable mutable objects can be modeled as immutable anchors plus ordered claims
  - why: provides a different way to think about “mutable names over immutable blobs” without inode inheritance
  - us: keep the idea in the inspiration set for manifests, named objects, or collaborative metadata, but do not commit yet
- **REF-TAHOE-MUTABLE** — Tahoe-LAFS mutable files — https://tahoe-lafs.readthedocs.io/en/latest/specifications/mutable.html
  - key: a mutable file can have a stable identifier even while its contents change
  - why: useful contrast case for stable mutable slots versus content-derived identity
  - us: prototype carefully before adopting any stable mutable-slot semantics in ViewFS
- **REF-SQLITE-SESSION** — SQLite session extension — https://sqlite.org/sessionintro.html
  - key: compact changesets, diff/apply, and conflict hooks can live above a stable base representation
  - why: useful inspiration for explicit work journals or tree-delta sidecars
  - us: if ViewFS needs mutable work state early, prototype explicit changesets before inventing a whole mutable store


## Search / indexing / recency inspiration
- **REF-GNOME-TRACKER** — GNOME Tracker / TinySPARQL overview — https://tracker.gnome.org/overview/
  - key: desktop search and media apps can be powered by a shared background index over user files
  - why: strong example of how helpful search surfaces can become ambient inventory surfaces
  - us: keep ViewFS query/indexes view-scoped or shell-owned rather than machine-global by default
- **REF-GNOME-LOCALSEARCH** — GNOME LocalSearch commandline reference — https://gnome.pages.gitlab.gnome.org/localsearch/commandline.html
  - key: indexing policy, extraction, eligibility, and existence checks are separable; metadata extraction can run in a separate sandboxed process
  - why: useful model for derived metadata hygiene and bounded extractor surfaces
  - us: if ViewFS ever extracts rich metadata, keep extractor boundaries explicit and sandboxed
- **REF-GTK-RECENT** — GTK RecentManager docs — https://gnome.pages.gitlab.gnome.org/gtk/gtk3/class.RecentManager.html
  - key: recent-file UX is fundamentally a per-user metadata database keyed by URIs and app metadata
  - why: good reminder that recency is a registry, not a capability
  - us: make recent-item stores advisory and class-aware
- **REF-APPLE-NSMETADATAQUERY** — Apple Developer docs, `NSMetadataQuery` — https://developer.apple.com/documentation/foundation/nsmetadataquery
  - key: metadata queries have an initial gathering phase and an optional live-update phase, with explicit update control while results are inspected
  - why: excellent precedent for keeping query recipe, current result set, and live feed distinct
  - us: ViewFS smart folders should support freeze/thaw and snapshot-vs-live truth badges
- **REF-APPLE-SPOTLIGHT-QUERYGUIDE** — Apple archive, *Searching File Metadata with NSMetadataQuery* — https://developer.apple.com/library/archive/documentation/Carbon/Conceptual/SpotlightQuery/Concepts/QueryingMetadata.html
  - key: queries deliver finish-gathering and update notifications in batches and can be run snapshot-first or with live updates
  - why: useful historical detail for result batching and feed semantics
  - us: keep live query updates advisory and batch-friendly rather than pretending lists are always current truth
- **REF-APPLE-SMARTFOLDERS** — Apple Support, *Create or change a Smart Folder on Mac* — https://support.apple.com/guide/mac-help/create-or-change-a-smart-folder-on-mac-mchlp2804/mac
  - key: a Smart Folder saves criteria that automatically collect matching items
  - why: strong UX precedent for shell-owned saved-query pins that feel folder-like
  - us: treat SmartFolder-like UX as a shell surface over a query manifest, not as a new authority object
- **REF-WIN-SEARCH-MS** — Microsoft Learn, *Saved search file format* — https://learn.microsoft.com/en-us/windows/win32/search/-search-savedsearchfileformat
  - key: Windows search folders are backed by a saved XML query file consumed by the search subsystem
  - why: good reminder that a saved search can be a plain manifest/recipe object
  - us: ViewFS QueryManifest can stay explicit and inspectable instead of becoming a hidden daemon-owned directory

- **REF-HAIKU-FSMODULES** — Haiku API docs, *The Haiku Book: File System Modules* — https://www.haiku-os.org/docs/api/fs_modules.html
  - key: a query is a fully virtual object and may be live, with explicit notifications when entries start or stop matching.
  - why: powerful filesystem precedent that live query surfaces are explicit classes rather than hidden background magic.
  - us: keep query manifests, result snapshots, live feeds, and materialized collections visibly separate.
- **REF-GNOME-SERVICES** — GNOME Developer docs, *Services / LocalSearch* — https://developer.gnome.org/documentation/introduction/overview/services.html
  - key: LocalSearch offers indexed search over a D-Bus service, and Flatpak apps do not get it by default but can request portal-mediated access.
  - why: strong caution that indexed discovery is useful precisely because it remains scoped rather than ambient.
  - us: any ViewFS smart-query/search surface should stay view-scoped, portal-gated, or shell-owned rather than machine-global by default.

## Links / aliases / retargeted names
- **REF-WIN-SHELLLINK** — Microsoft Learn, *Shell Links* — https://learn.microsoft.com/en-us/windows/win32/shell/links
  - key: a Shell Link is a data object for accessing another object and can carry path, working directory, arguments, icon, and resolution behavior
  - why: strong reminder that desktop shortcuts are richer than immutable object identity
  - us: keep route/launch shortcuts separate from live handles and durable reopen refs
- **REF-WIN-HARDLINKS** — Microsoft Learn, *Hard links and junctions* — https://learn.microsoft.com/en-us/windows/win32/fileio/hard-links-and-junctions
  - key: NTFS hard links, junctions, and symbolic-link-like constructs have materially different semantics and limits
  - why: “link” is not one thing, even on one platform
  - us: avoid promising one generic link primitive too early
- **REF-WIN-REPARSE** — Microsoft Learn, *Reparse points* — https://learn.microsoft.com/en-us/windows/win32/fileio/reparse-points
  - key: reparse points are tagged data interpreted by filters and have path-depth and payload limits
  - why: another reminder that implementation aliasing and user-facing shortcuts are different seams
  - us: keep storage indirection and user-visible alias UX separate
- **REF-APPLE-BOOKMARKS** — Apple File System Programming Guide, *Locating Files Using Bookmarks* — https://developer.apple.com/library/archive/documentation/FileManagement/Conceptual/FileSystemProgrammingGuide/AccessingFilesandDirectories/AccessingFilesandDirectories.html
  - key: Apple recommends bookmark data for persistent location storage because paths and file-reference URLs are fragile across moves and launches
  - why: good precedent for durable reopen descriptors that are not just paths
  - us: durable reopen should be explicit, inspectable, and non-bearer
- **REF-APPLE-SECBOOKMARK** — Apple docs, *Using Bookmark Data* — https://developer.apple.com/documentation/professional-video-applications/using-bookmark-data?language=objc
  - key: security-scoped bookmark data is the flow for sandboxed apps to access file-system resources
  - why: useful precedent for durable reopen with explicit security context
  - us: rebind/reopen should stay explicit rather than magical
- **REF-APPLE-SECWITHSCOPE** — Apple docs, `withSecurityScope` — https://developer.apple.com/documentation/Foundation/NSURL/BookmarkCreationOptions/withSecurityScope
  - key: bookmark creation can explicitly request security scope
  - why: authority-bearing persistence should be opt-in and typed
  - us: any ViewFS durable grant metadata should make scope/class obvious
- **REF-APPLE-SECSTART** — Apple docs, `startAccessingSecurityScopedResource()` — https://developer.apple.com/documentation/Foundation/URL/startAccessingSecurityScopedResource%28%29
  - key: a resolved security-scoped URL still needs explicit start-accessing discipline and balanced relinquish when access ends
  - why: a durable ref is not the same thing as an already-live authority handle
  - us: keep durable reopen, live borrowed access, and loan-end state visibly separate
- **REF-APPLE-SECRESOLVE** — Apple docs, `init(resolvingBookmarkData:options:relativeTo:bookmarkDataIsStale:)` — https://developer.apple.com/documentation/foundation/url/init%28resolvingbookmarkdata%3Aoptions%3Arelativeto%3Abookmarkdataisstale%3A%29-3ic6f
  - key: resolving bookmark data can report whether bookmark data is stale, and security-scoped resolution is an explicit option
  - why: durable reopen descriptors can age and may need refresh instead of silently following the resource
  - us: keep basis drift, rebasing, and reconsent visibly separate from current live authority

## Origin / quarantine / trusted-open precedents
- **REF-APPLE-QUARANTINEKEY** — Apple docs, `URLResourceKey.quarantinePropertiesKey` — https://developer.apple.com/documentation/foundation/urlresourcekey/quarantinepropertieskey
  - key: quarantine properties are explicit resource metadata rather than invisible folklore
  - why: strong precedent for separating origin/risk state from generic file identity
  - us: keep origin/quarantine inspectable in ViewFS and shell UX
- **REF-APPLE-GATEKEEPER** — Apple Platform Security, *Gatekeeper and runtime protection in macOS* — https://support.apple.com/guide/security/gatekeeper-and-runtime-protection-sec5599b66df/web
  - key: downloaded software is checked before first open to help ensure only trusted software runs
  - why: useful precedent for guarded-open behavior rather than blind launch
  - us: risky-object handling should prefer explicit guarded lanes over ambient launch
- **REF-APPLE-SAFEOPEN** — Apple Support, *Safely open apps on your Mac* — https://support.apple.com/en-us/102445
  - key: Gatekeeper checks developer identity, notarization, and malware signals for apps downloaded outside the App Store
  - why: reminds us that origin/risk UX needs clear user-facing language, not just hidden metadata
  - us: shell explanations and badges should be human-readable
- **REF-APPLE-GATEKEEPER-BYPASS** — Apple security content notes on quarantine / Gatekeeper bypass fixes — https://support.apple.com/en-us/125635
  - key: file-quarantine and Gatekeeper bypasses keep needing fixes
  - why: strong warning that quarantine machinery is valuable but brittle
  - us: never let origin/quarantine silently collapse into durable trust
- **REF-MS-ATTACHMENTMGR** — Microsoft Learn, *Policy CSP - AttachmentManager* — https://learn.microsoft.com/en-us/windows/client-management/mdm/policy-csp-attachmentmanager
  - key: Windows marks attachments with zone-of-origin information because otherwise it cannot make proper risk assessments
  - why: excellent precedent for preserving origin class separately from trust
  - us: keep arrival-route metadata visible and sticky
- **REF-MS-MOTW-OFFICE** — Microsoft Learn, *Macros from the internet are blocked by default in Office* — https://learn.microsoft.com/en-us/microsoft-365-apps/security/internet-macros-blocked
  - key: Mark-of-the-Web influences guarded document behavior and macro blocking
  - why: useful precedent for distinguishing document preview/open from active-content trust
  - us: keep code-bearing and document-bearing defaults visibly different
- **REF-MS-APPGUARD** — Microsoft Learn, *Microsoft Defender Application Guard overview* — https://learn.microsoft.com/en-us/windows/security/application-security/application-isolation/microsoft-defender-application-guard/md-app-guard-overview
  - key: untrusted files can be opened in an isolated container to protect trusted resources
  - why: strong precedent for a safe-open lane separate from full trust
  - us: ViewFS safe-open should feel useful without mutating trust in place
- **REF-MS-SMARTSCREEN** — Microsoft Learn, *Microsoft Defender SmartScreen overview* — https://learn.microsoft.com/en-us/windows/security/operating-system-security/virus-and-threat-protection/microsoft-defender-smartscreen/
  - key: SmartScreen protects against malicious sites, apps, and downloads using reputation signals
  - why: good reminder that risk signals can stay advisory and layered rather than absolute truth
  - us: origin/risk badges can inform UX without becoming the whole authority model
- **REF-EDGE-DL-DANGER** — Microsoft Learn, *Identify and interrupt downloads of potentially dangerous files* — https://learn.microsoft.com/en-us/deployedge/microsoft-edge-security-downloads-interruptions
  - key: browsers classify file types by dangerousness and apply different interruption/warning behavior
  - why: useful precedent for shell action hints and honest default verbs
  - us: prefer action ladders (`peek`, `open safe`, `request clear`) over one generic open action

## Provenance / endorsement / admission precedents
- **REF-RATS-RFC9334** — RFC 9334, *Remote ATtestation procedureS (RATS) Architecture* — https://www.rfc-editor.org/rfc/rfc9334.html
  - key: endorsements are produced by an endorser and consumed by a verifier; evidence, endorsements, and attestation results are different conceptual messages
  - why: excellent precedent for keeping claim, endorsement, and local verdict on separate seams
  - us: provenance/endorsement should not silently become local admission or live authority
- **REF-RATS-ENDORSEMENTS-DRAFT** — IETF Datatracker, *RATS Endorsements* — https://datatracker.ietf.org/doc/draft-ietf-rats-endorsements/
  - key: a verifier accepts evidence and uses appraisal policy plus endorsements/reference values to generate attestation results
  - why: strong precedent that endorsement/reference material is verifier input rather than exporter truth
  - us: ViewFS should keep endorsement stacks separate from local admit/deny verdicts
- **REF-IN-TOTO-ATTESTATION** — in-toto, *Attestation Framework* — https://github.com/in-toto/attestation
  - key: statement, predicate, envelope, and bundle are separate layers of attestation meaning
  - why: useful precedent for claim-envelope structure without conflating it with admission
  - us: provenance ribbons should stay distinct from policy verdicts and live handles
- **REF-SLSA-PROVENANCE** — SLSA, *Provenance* — https://slsa.dev/spec/v1.0/provenance
  - key: provenance is an attestation that a build platform produced a set of software artifacts through execution of a build definition
  - why: sharp reminder that provenance is a statement about production, not a final trust decision
  - us: build/import provenance should be inspectable without becoming local runnable truth
- **REF-SLSA-VERIFY-V1** — SLSA, *What’s new in SLSA v1.0* — https://slsa.dev/spec/v1.0/whats-new
  - key: provenance only helps when it is verified and compared to expectations
  - why: strong precedent that production of provenance and local acceptance of provenance are separate acts
  - us: shell UX should separate `claim present` from `claim verified here`
- **REF-TUF-ROLES** — TUF, *Roles and metadata* — https://theupdateframework.io/docs/metadata/
  - key: roles define who may perform which actions, and trust is scoped to information provided by the correctly designated party
  - why: great precedent for explicit role/delegation scope instead of one flattening signer bit
  - us: endorsement stacks should preserve who may speak for what
- **REF-SIGSTORE-REKOR** — Sigstore docs, *Rekor* — https://docs.sigstore.dev/logging/overview/
  - key: Rekor provides a signature transparency log and auditable record of signing events
  - why: strong precedent that transparency/audit material is useful without itself becoming admission
  - us: transparency witnesses should remain audit truth, not automatic admit truth

## Preview / observation surfaces
- **REF-WIN-PREVIEW-HANDLERS** — Microsoft Learn, *Preview Handlers and Shell Preview Host* — https://learn.microsoft.com/en-us/windows/win32/shell/preview-handlers
  - key: preview handlers provide lightweight, rich, read-only previews without launching the associated application
  - why: strong precedent for making preview observational rather than equivalent to open/exec
  - us: keep ViewFS peek panes separate from launch and trust
- **REF-WIN-PREVIEW-GUIDE** — Microsoft Learn, *Preview Handler Guidelines* — https://learn.microsoft.com/en-us/previous-versions/windows/desktop/legacy/cc144140%28v%3Dvs.85%29
  - key: previews should stay minimal, fast, non-locking, and block scripts/macros
  - why: great concrete checklist for inert preview surfaces
  - us: block active content in preview and keep preview chrome small
- **REF-APPLE-QUICKLOOK-WWDC24** — Apple WWDC24, *What’s new in Quick Look for visionOS* — https://developer.apple.com/videos/play/wwdc2024/10105/
  - key: Quick Look is a dedicated system preview tool with explicit lifecycle and safe/secure file-access framing
  - why: useful precedent for preview sessions that coexist with full applications instead of replacing them
  - us: model preview as a first-class observation session, not as a disguised full-open
- **REF-XDG-BACKENDS** — XDG Desktop Portal, *Backend D-Bus Interfaces* — https://flatpak.github.io/xdg-desktop-portal/docs/impl-dbus-interfaces.html
  - key: portal backends live in separate processes and are not directly accessible to sandboxed apps
  - why: useful precedent for keeping preview/extraction engines off the same seam as app-visible authority
  - us: prefer explicit preview providers/backends over hidden direct access from every consumer

## Shell / terminal inspiration
- **REF-NUSHELL** — Nushell pipelines — https://www.nushell.sh/book/pipelines.html
  - key: pipelines can carry structured data rather than only bytes
  - why: a capability-native shell should traffic in typed objects and receipts
  - us: let shell commands emit structured handle metadata by default
- **REF-FISH** — fish docs / tutorial — https://fishshell.com/docs/current/
  - key: syntax highlighting, autosuggestions, and completion ergonomics matter a lot
  - why: safer authority UX needs excellent interaction design
  - us: capability-aware completions and preview panes should feel effortless
- **REF-ITERM-SHELLINT** — iTerm2 shell integration — https://iterm2.com/documentation-shell-integration.html
  - key: prompt marks, command boundaries, cwd/host metadata, and recent-command/directory UX can all be driven by explicit shell escape sequences
  - why: practical precedent for mark-based navigation and searchable transcript UX
  - us: ViewFS blocks/marks/history should be derived from explicit metadata, not heuristics
- **REF-ITERM-CMDSELECT** — iTerm2 command selection and command URLs — https://iterm2.com/documentation-command-selection.html
  - key: selected command regions get their own info/share/bookmark/copy affordances and are treated as richer objects than plain text selection
  - why: strong precedent for command-block cards and explicit promotion from history to richer actions
  - us: keep selected history blocks separate from the live mutable prompt area and from launched sessions
- **REF-ITERM-CLEARBUFFER** — iTerm2 menu docs: clear buffer vs clear scrollback buffer — https://iterm2.com/3.2/documentation-menu-items.html
  - key: iTerm2 distinguishes clearing all terminal history plus the mutable area from clearing scrollback while preserving the mutable area
  - why: direct product precedent that live editable prompt state and scrollback history are different classes
  - us: build a prompt dock / mutable-area seam instead of flattening everything into one terminal buffer

- **REF-ITERM-OSC8** — iTerm2 OSC 8 anchor docs — https://iterm2.com/3.2/documentation-escape-codes.html
  - key: terminals can render clickable hyperlinks with explicit IDs and route targets
  - why: useful substrate for typed object/receipt links in shell output
  - us: object refs should stay typed even when rendered as links
- **REF-ITERM-SEMHIST** — iTerm2 semantic history / advanced profile prefs — https://iterm2.com/3.0/documentation-preferences.html
  - key: cmd-click opening can be driven by tracked cwd plus file-like text in output
  - why: powerful precedent and cautionary tale for heuristic shell navigation
  - us: support heuristic file opens only with honest badges and clear fallbacks to typed links
- **REF-GHOSTTY-SHELLINT** — Ghostty shell integration features — https://ghostty.org/docs/features/shell-integration
  - key: prompt-aware navigation, prompt cursor movement, and output selection are all unlocked by shell integration metadata
  - why: strong modern evidence that protocol-driven shell UX feels substantially better
  - us: emit enough metadata early so delight follows naturally
- **REF-GHOSTTY-OSC133-OVERLAY** — Ghostty 1.3.0 release notes / OSC 133 overlay — https://ghostty.org/docs/install/release-notes/1-3-0
  - key: a terminal inspector can expose semantic prompt/output regions directly to humans
  - why: debugging the metadata is part of making the UX trustworthy
  - us: build a ViewFS terminal inspector/debug overlay early
- **REF-WARP-BLOCKS** — Warp terminal blocks — https://docs.warp.dev/terminal/blocks
  - key: command + output as an atomic block is a better unit than a raw scroll stream
  - why: ViewFS shell receipts and grants should be grouped and shareable
  - us: represent imports/exports/transfers as blocks with attached metadata
- **REF-WARP-NOTEBOOKS** — Warp notebooks — https://docs.warp.dev/knowledge-and-collaboration/warp-drive/notebooks
  - key: runnable documentation can sit inside the terminal environment itself
  - why: attractive pattern for repeatable ViewFS workflows, onboarding, and admin playbooks
  - us: explore local-first notebooks that embed shell snippets and portal receipts
- **REF-WARP-WORKFLOWS** — Warp workflows — https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows
  - key: saved parameterized commands can be discoverable and editable without becoming shell aliases folklore
  - why: good fit for explicit ViewFS portal/import/export tasks and object inspection flows
  - us: build parameterized workflow objects with visible arguments and authority previews
- **REF-WARP-CMDPALETTE** — Warp command palette — https://docs.warp.dev/terminal/command-palette
  - key: one searchable palette can unify commands, docs, workflows, and navigation
  - why: promising UI for a shell whose objects are richer than plain commands
  - us: make views, receipts, manifests, workflows, and notebooks searchable from one place
- **REF-WEZTERM-HYPERLINKS** — WezTerm hyperlinks — https://wezterm.org/hyperlinks.html
  - key: terminals can expose clickable semantic links without cluttering output
  - why: good fit for handle IDs, receipts, manifests, and docs
  - us: make ViewFS object receipts clickable from terminal output
- **REF-WEZTERM-DOMAINS** — WezTerm domains / mux docs — https://wezterm.org/config/lua/config/default_domain.html
  - key: distinct UI domains remain user-comprehensible and can preserve current-directory semantics
  - why: ViewFS views may benefit from similarly visible domains
  - us: terminal tabs should expose active view identity clearly
- **REF-WEZTERM-SHELL-INT** — WezTerm shell integration — https://wezterm.org/shell-integration.html
  - key: terminals can understand working-directory state plus prompt/input/output semantic zones
  - why: ideal substrate for receipt-aware blocks and safe prompt UX
  - us: have the ViewFS shell emit working-directory + block-boundary metadata from day one
- **REF-WEZTERM-ZONES** — WezTerm semantic zones API — https://wezterm.org/config/lua/pane/get_semantic_zones.html
  - key: terminals can enumerate semantic `Prompt`, `Input`, and `Output` zones once the shell emits the right metadata
  - why: shows a practical route to receipt-aware blocks and click-safe selection
  - us: treat zones as a real protocol target for ViewFS shell metadata
- **REF-WEZTERM-USERVARS** — WezTerm user vars / pane vars — https://wezterm.org/config/lua/pane/get_user_vars.html
  - key: panes can carry explicit shell-published metadata that is distinct from process environment variables
  - why: strong precedent for pane chrome truth that does not masquerade as child authority
  - us: publish view/trust/debt/task hints as pane metadata rather than as ambient env lore

## Workspace trust / automation gating
- **REF-VSCODE-WORKSPACE-TRUST** — VS Code Workspace Trust — https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
  - key: a workspace can open in Restricted Mode where potentially harmful functionality is disabled or limited
  - why: strongest product precedent for browse-first / trust-later project opening
  - us: opening a workspace bind should not auto-enable workspace-defined automation
- **REF-VSCODE-TASKS** — VS Code tasks docs — https://code.visualstudio.com/docs/debugtest/tasks
  - key: user-level tasks are distinct from workspace tasks
  - why: useful split between user-owned automation and workspace-contributed automation
  - us: keep user workflows visibly separate from workspace recipes
- **REF-VSCODE-JUPYTER-TRUST** — VS Code Jupyter notebooks docs — https://code.visualstudio.com/docs/datascience/jupyter-notebooks
  - key: notebook execution and rich outputs are limited in untrusted workspaces
  - why: reinforces that “open notebook” and “run notebook” are different trust steps
  - us: notebook cells should be inspectable before they become executable
- **REF-JETBRAINS-PROJSEC** — IntelliJ IDEA project security — https://www.jetbrains.com/help/idea/project-security.html
  - key: opening a project from an unknown source triggers a trust decision and warns about tasks/configurations executed during opening
  - why: useful precedent for explicit project-security prompts and trusted locations
  - us: any trusted-root shortcut should remain reviewable and revocable
- **REF-DIRENV-ALLOW** — direnv manual — https://direnv.net/man/direnv.1.html
  - key: per-directory environment activation requires explicit allow/deny
  - why: good shell precedent for workspace automation gating
  - us: env-hook enablement should be explicit rather than inherited from path traversal
- **REF-DIRENV-REQUIREALLOWED** — direnv stdlib — https://direnv.net/man/direnv-stdlib.1.html
  - key: watched file changes can force re-authorization
  - why: strong precedent for trust invalidation when automation-bearing files change
  - us: reapproval should key off meaningful automation diffs rather than every file edit



## Watching / notifications / rebuild semantics
- **REF-INOTIFY** — Linux `inotify(7)` — https://man7.org/linux/man-pages/man7/inotify.7.html
  - key: file-watch queues can overflow and robust applications should recover gracefully, potentially by rebuilding caches
  - why: strongest reminder that watch feeds are incremental hints, not perfect truth
  - us: make overflow/rebuild a first-class ViewFS watch state
- **REF-FANOTIFY** — Linux `fanotify(7)` — https://man7.org/linux/man-pages/man7/fanotify.7.html
  - key: fanotify can identify objects by file handle and may deliver `FAN_NOFD` on overflow
  - why: useful contrast between access notification, object identity, and already-open authority
  - us: keep watch signals distinct from live handles and object access
- **REF-APPLE-FSEVENTS** — Apple File System Events / Programming Guide — https://developer.apple.com/documentation/coreservices/file_system_events
  - key: dropped events and root changes require rescanning watched directories/trees
  - why: powerful precedent for explicit rebuild semantics in watch UIs
  - us: teach ViewFS watch surfaces to admit recrawl/rebuild honestly
- **REF-K8S-API-CONCEPTS-WATCH** — Kubernetes docs, *API Concepts* — https://kubernetes.io/docs/reference/using-api/api-concepts/
  - key: watch `BOOKMARK` events, `resourceVersion`, chunked `continue` tokens, and `410 Gone` all keep incremental progress, current state, and repair paths explicit
  - why: excellent precedent for separating sync watermarks, subscriptions, rebuilt state, and reset verdicts
  - us: ViewFS should surface watermarks and reset reasons without pretending they are durable object refs or current state
- **REF-DROPBOX-DETECT-CHANGES** — Dropbox docs, *Detecting Changes Guide* — https://developers.dropbox.com/detecting-changes-guide
  - key: one folder cursor can support both continuation and later delta polling, yet cursors can expire and force a fresh list while longpoll stays a separate wait primitive
  - why: great precedent for keeping pagination/delta tokens, wait handles, and rebuilt visible state on different seams
  - us: keep provider cursors opaque, expose resync ladders, and never treat cursors as durable ViewFS refs
- **REF-WATCHMAN-CLOCKSPEC** — Watchman docs, *Clockspec* — https://facebook.github.io/watchman/docs/clockspec
  - key: wall-clock timestamps are race-prone, while logical clock ids and named cursors provide safer incremental change tracking
  - why: useful reminder that better sync tokens are still query-state markers, not object authority
  - us: watermarks should be inspectable honesty artifacts, not hidden grants or collection identities
- **REF-APPLE-FSEVENTS-GUIDE** — Apple File System Events Programming Guide, *Using the File System Events API* — https://developer.apple.com/library/archive/documentation/Darwin/Conceptual/FSEvents_ProgGuide/UsingtheFSEventsFramework/UsingtheFSEventsFramework.html
  - key: coalesced or dropped events and root changes require recursive/full rescan, and event ids help clients reason about progress through the stream
  - why: strong precedent for making rebuild and gap states explicit in any live-query/watch UX
  - us: ViewFS should render `must rescan`, `provider reset`, and `last good watermark` as first-class shell truth
- **REF-WIN-READDIRCHANGES** — Windows `ReadDirectoryChangesW` — https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-readdirectorychangesw
  - key: directory-scoped change notifications are separate from volume-wide journals
  - why: helpful distinction between local watch scope and larger recovery/index facilities
  - us: keep watch scope explicit and avoid pretending every live pane is a global feed
- **REF-WIN-USN** — Windows change journals / USN journal — https://learn.microsoft.com/en-us/windows/win32/fileio/change-journals
  - key: the USN journal is a persistent volume log useful for recovery, but records can age out and clients may need to reindex
  - why: good precedent for “incremental feed + rebuild path” instead of magical freshness
  - us: if ViewFS later has stronger journals, keep them distinct from UI watch subscriptions
- **REF-WATCHMAN-TROUBLE** — Watchman troubleshooting — https://facebook.github.io/watchman/docs/troubleshooting
  - key: resource limits and recrawls are operationally normal enough to deserve explicit warnings
  - why: excellent product precedent for surfacing degraded watch health instead of hiding it
  - us: expose `overflow`, `recrawl`, and `rebuild required` states in shell UX
- **REF-WATCHMAN-INSTALL** — Watchman installation notes — https://facebook.github.io/watchman/docs/install.html
  - key: file watching depends heavily on OS facilities and may behave poorly on remote/distributed filesystems
  - why: reminder not to promise local-watch semantics everywhere
  - us: show `remote-risk` / `unsupported` badges rather than silently overclaiming coverage

## Checkpoints / clones / deployment / backup separation
- **REF-APPLE-APFS-FEATURES** — Apple File System Guide, *Features* — https://developer.apple.com/library/archive/documentation/FileManagement/Conceptual/APFS_Guide/Features/Features.html
  - key: APFS explicitly surfaces cloning for files/directories, snapshots, copy-on-write design, and atomic safe-save primitives.
  - why: strong precedent that cheap local checkpoints/clones are worth having as first-class UX.
  - us: encourage routine checkpoints/forks, but keep them distinct from publication and activation.
- **REF-ZFS-SNAPSHOT** — OpenZFS `zfs-snapshot(8)` — https://openzfs.github.io/openzfs-docs/man/master/8/zfs-snapshot.8.html
  - key: snapshots are created atomically and represent a consistent point-in-time image.
  - why: useful precedent for cheap, trustworthy local checkpoint semantics.
  - us: make local checkpoints explicit and easy, but do not overload them with every other promise.
- **REF-ZFS-CLONES** — OpenZFS `zfs(8)` clones section — https://openzfs.github.io/openzfs-docs/man/master/8/zfs.8.html
  - key: clones are created from snapshots, and clone promotion is a separate operation.
  - why: good reminder that writable derivatives and “become independent” moves deserve their own seam.
  - us: keep writable forks/worktrees separate from checkpoints and activation targets.
- **REF-ZFS-BOOKMARK** — OpenZFS `zfs-bookmark(8)` — https://openzfs.github.io/openzfs-docs/man/master/8/zfs-bookmark.8.html
  - key: bookmarks record the point in time of a snapshot and can be used as incremental send sources without being the snapshot itself.
  - why: elegant proof that “reference to a point in time” can be distinct from “full live snapshot object.”
  - us: keep replication/export lineage receipts separate from local checkpoints.
- **REF-BTRFS-SUBVOLUMES** — Btrfs subvolumes/snapshots docs — https://btrfs.readthedocs.io/en/latest/Subvolumes.html
  - key: snapshots are subvolumes with given initial content, and modifications in a snapshot do not affect the original.
  - why: useful precedent for cheap workspace forks with clear mutation boundaries.
  - us: ViewFS forks/worktrees should feel cheap and independent without becoming magical aliases.
- **REF-BTRFS-SEND** — Btrfs send/receive — https://btrfs.readthedocs.io/en/latest/btrfs-send.html
  - key: send generates a stream describing changes between snapshots, with full and incremental modes.
  - why: strong example of replication/export as a distinct transport seam.
  - us: keep backup/export receipts separate from local undo or activation semantics.
- **REF-GIT-WORKTREE** — Git `worktree` — https://git-scm.com/docs/git-worktree
  - key: one repository can support multiple working trees with metadata that differentiates them.
  - why: great ergonomic precedent for cheap parallel experimentation.
  - us: let ViewFS users fork new writable workspaces cheaply without conflating them with publication or backup.
- **REF-MS-VSS** — Microsoft Volume Shadow Copy Service — https://learn.microsoft.com/en-us/windows-server/storage/file-server/volume-shadow-copy-service
  - key: consistent point-in-time copies, backup coordination, provider differences, transportable shadows, and restore are distinct concerns.
  - why: useful caution that “snapshot” often hides multiple moving parts.
  - us: keep checkpoint, backup/export, and restore/activation semantics explicit.
- **REF-OSTREE-OVERVIEW** — OSTree overview — https://ostreedev.github.io/ostree/introduction/
  - key: content-addressed trees/refs, atomic upgrades, and parallel-installable deployments stay distinct from package composition.
  - why: strong precedent for separating object-store truth from deployment/promotion workflow.
  - us: publication and activation in ViewFS should be promotion layers over the object store, not synonyms for checkpoints.
- **REF-OSTREE-MANUAL** — OSTree manual — https://ostreedev.github.io/ostree/man/
  - key: admin flows such as deploy, pin, switch, status, upgrade, undeploy, and cleanup are separate commands.
  - why: useful evidence that users can handle explicit lifecycle verbs if the tooling is good.
  - us: ViewFS shell verbs should tell the truth about pin/promote/activate/cleanup instead of flattening them.
- **REF-RESTIC-FORGET** — restic forget/prune docs — https://restic.readthedocs.io/en/latest/060_forget.html
  - key: snapshot removal and actual data reclamation are separate operations (`forget` then `prune`).
  - why: another reminder that retention/reclamation and snapshot history are distinct seams.
  - us: keep checkpoint history, retention, and purge separate in ViewFS too.
- **REF-FREEBSD-BECTL** — FreeBSD `bectl` manual page — https://man.freebsd.org/cgi/man.cgi?bectl=
  - key: boot-environment tooling treats snapshot/clone state and activation as operationally distinct.
  - why: reinforces that rollback/next-boot choices deserve explicit UX.
  - us: activation previews in ViewFS should remain a separate lane from local checkpoint creation.



## Preconditions / leases / conflicts / ownership
- **REF-RFC9110-PRECONDITIONS** — RFC 9110, HTTP Semantics — https://www.rfc-editor.org/rfc/rfc9110.html
  - key: origin servers evaluate `If-Match`, `If-Unmodified-Since`, and `If-None-Match` as request preconditions and return `412 Precondition Failed` when state-changing conditions fail.
  - why: strongest standards-track precedent for optimistic write guards.
  - us: prefer expected-old / guarded-write semantics over default blind overwrite.
- **REF-S3-CONDITIONAL-WRITES** — Amazon S3 conditional writes — https://docs.aws.amazon.com/AmazonS3/latest/userguide/conditional-writes.html
  - key: S3 supports conditional writes with `If-None-Match` and `If-Match`; `If-None-Match: *` prevents overwriting an existing key.
  - why: object-store precedent that conditional creation/update is practical and explicit.
  - us: keep create-if-absent and update-if-unchanged as named ViewFS write classes.
- **REF-S3-CONDITIONAL-DELETES** — Amazon S3 conditional deletes — https://docs.aws.amazon.com/AmazonS3/latest/userguide/conditional-deletes.html
  - key: S3 supports `If-Match` for delete safety and returns `412 Precondition Failed` on mismatch, with documented concurrent-operation edge cases.
  - why: deletion safety also benefits from explicit preconditions.
  - us: protect delete-like mutable seams with the same honesty as writes.
- **REF-GIT-FORCE-WITH-LEASE** — Git `push` documentation — https://git-scm.com/docs/git-push
  - key: `--force-with-lease` updates refs only if their current value still matches what the pusher expects.
  - why: beautiful product precedent for safe override/takeover UX.
  - us: prefer takeover-if-unchanged style verbs over generic force.
- **REF-GIT-UPDATE-REF** — Git `update-ref` documentation — https://git-scm.com/docs/git-update-ref
  - key: `git update-ref <ref> <newvalue> <oldvalue>` performs a compare-and-swap style update after verifying the current value matches the expected old value.
  - why: low-level precedent for expected-old ref/head mutation.
  - us: mutable ViewFS heads/bindings may want the same shape.
- **REF-WEBDAV-LOCKING** — RFC 4918, WebDAV locking — https://www.rfc-editor.org/rfc/rfc4918.html
  - key: write locks use opaque lock tokens, timeouts are advisory, and holding a lock does not itself confer write privilege.
  - why: excellent cautionary precedent for keeping locks, authorization, and timeouts separate.
  - us: if ViewFS ever has leases, keep them bounded, opaque, and non-magical.
- **REF-ETCD-TXN** — etcd API transactions — https://etcd.io/docs/v3.6/learning/api/
  - key: etcd transactions are atomic If/Then/Else constructs that support compare-and-swap and higher-level concurrency control.
  - why: distributed-systems precedent for guarded multi-step mutation without giant ambient locking.
  - us: future mutable seams may be cleaner with conditional transactions than with a central lock service.
- **REF-ETCD-LEASE** — etcd leases — https://etcd.io/docs/v3.6/dev-guide/interacting_v3/
  - key: keys attached to a lease live only as long as the lease; expiry deletes attached keys.
  - why: strong precedent for short-lived reservations with explicit lifetime semantics.
  - us: if ViewFS adopts reservations, tie them to bounded lease lifetime rather than fuzzy ownership.
- **REF-ETCD-LOCK** — etcd concurrency lock API — https://etcd.io/docs/v3.6/dev-guide/api_concurrency_reference_v3/
  - key: a lock is tied to a lease and is automatically released when that lease expires or is revoked.
  - why: useful proof that auto-release semantics are practical and explainable.
  - us: any ViewFS reservation should degrade honestly rather than pretending locks live forever.
- **REF-K8S-SSA** — Kubernetes Server-Side Apply — https://kubernetes.io/docs/reference/using-api/server-side-apply/
  - key: Kubernetes tracks field managers and rejects apply conflicts unless the caller explicitly forces an override.
  - why: compelling precedent for ownership hints/conflicts narrower than whole-object locks.
  - us: ViewFS may eventually benefit from subtree/field ownership explain surfaces without committing to a giant lock primitive.
- **REF-AZURE-BLOB-CONCURRENCY** — Azure Blob Storage concurrency — https://learn.microsoft.com/en-us/azure/storage/blobs/concurrency-manage
  - key: optimistic concurrency uses `If-Match` against blob ETags and returns HTTP `412` if another process updated the blob first.
  - why: another large-scale object-store precedent for expected-old updates.
  - us: guarded writes are not just a Git/HTTP trick; they work well for blob-like stores too.
- **REF-SQLITE-ISOLATION** — SQLite isolation — https://sqlite.org/isolation.html
  - key: SQLite documents isolation rules and visibility of concurrent changes explicitly.
  - why: reminder that real mutable-store semantics need careful explanation.
  - us: keep ViewFS mutation claims narrow and staged.
- **REF-SQLITE-LOCKINGV3** — SQLite locking and concurrency — https://sqlite.org/lockingv3.html
  - key: SQLite’s pager/locking model exists largely to avoid writer starvation and make atomic commits practical.
  - why: caution against romanticizing “just add locks” as a small feature.
  - us: keep the core object store boring and move concurrency semantics upward deliberately.


## Import / export / transfer / promise-later materialization
- **REF-APPLE-DOCPICKER-OPS** — Apple, *Accessing Documents* — https://developer.apple.com/library/archive/documentation/FileManagement/Conceptual/DocumentPickerProgrammingGuide/AccessingDocuments/AccessingDocuments.html
  - key: Apple’s document picker explicitly separates import, export, open, and move, and also distinguishes copy semantics from in-place access.
  - why: strongest product precedent that these lanes deserve explicit vocabulary.
  - us: keep import/open/save/move as different ViewFS classes instead of one generic file operation.
- **REF-APPLE-DOCPICKER-ACCESS** — Apple, *Accessing Documents* — https://developer.apple.com/library/archive/documentation/FileManagement/Conceptual/DocumentPickerProgrammingGuide/AccessingDocuments/AccessingDocuments.html
  - key: open/move return security-scoped URLs and require careful start/stop access discipline; import/export use copies instead.
  - why: great reminder that in-place access and copy-in/out have different risk and lifecycle semantics.
  - us: keep open-in-place/docref lanes separate from import/export lanes.
- **REF-APPLE-FILEPROVIDER-SYNC** — Apple Developer docs, *Synchronizing the File Provider Extension* — https://developer.apple.com/documentation/fileprovider/synchronizing-the-file-provider-extension
  - key: a provider-managed folder may contain dataless or materialized local copies while still syncing to remote storage.
  - why: strong precedent that foreign-backed usability and local materialization are different locality classes.
  - us: keep borrowed/projected/materialized/local-object truth visibly separate.
- **REF-ANDROID-CREATE-DOCUMENT** — Android Developers, *Access documents and other files from shared storage* — https://developer.android.com/training/data-storage/shared/documents-files
  - key: `ACTION_CREATE_DOCUMENT` is a save-as style destination picker and cannot overwrite an existing file; the system disambiguates names instead.
  - why: strong precedent that destination grants are their own lane and need truthful collision semantics.
  - us: save/export lanes should not quietly inherit overwrite-in-place or broad directory authority.
- **REF-WIN-SHELL-CLIPFORMATS** — Microsoft Learn, *Shell Clipboard Formats* — https://learn.microsoft.com/en-us/windows/win32/shell/clipboard
  - key: move-versus-copy preference and performed-drop outcome are explicit clipboard/data-object formats rather than an inferred side effect.
  - why: great precedent for explicit move/copy outcome receipts.
  - us: ViewFS should transcript whether an operation copied, moved, or only offered transfer.
- **REF-WIN-SHELL-DATASCENARIOS** — Microsoft Learn, *Handling Shell Data Transfer Scenarios* — https://learn.microsoft.com/en-us/windows/win32/shell/datascenarios
  - key: delete-on-paste and optimized move are explicit protocols where the source waits for outcome feedback before updating or deleting its view.
  - why: excellent product precedent for honest post-transfer outcome cards.
  - us: shell drag/drop and paste should report final lane outcomes instead of guessing.
- **REF-APPLE-FILEPROMISES** — Apple, *Supporting Drag and Drop Through File Promises* — https://developer.apple.com/documentation/AppKit/supporting-drag-and-drop-through-file-promises
  - key: a drag operation can promise file delivery at drop time rather than eagerly materializing the file.
  - why: one of the most exciting ideas to steal for a capability-native shell.
  - us: let ViewFS shell blocks offer promised outputs that materialize only when a sink actually claims them.


## Prefetch / cache / hydration / pins / mirrors / offline bundles
- **REF-IPFS-PERSISTENCE** — IPFS Persistence — https://docs.ipfs.tech/concepts/persistence/
  - key: pinned data is protected from routine garbage collection; pinning is explicitly about data retention and disk-space control.
  - why: strongest direct precedent for separating retention promises from ordinary cache warmth.
  - us: keep pin/root state separate from cached or hydrated state.
- **REF-NIX-REALISE** — Nix `nix-store --realise` — https://nix.dev/manual/nix/2.19/command-ref/nix-store/realise
  - key: realizing a path fetches or builds the required output-path closure explicitly.
  - why: useful precedent for an explicit hydration/materialization act over a closure.
  - us: ViewFS should make hydration a first-class, inspectable act rather than an accidental side effect.
- **REF-NIX-COPY** — Nix `nix copy` — https://nix.dev/manual/nix/2.18/command-ref/new-cli/nix3-copy
  - key: closure copy between stores is a deliberate transport operation.
  - why: excellent proof that copy/mirror/transport should stay explicit.
  - us: keep local hydration separate from mirror/replica/export workflows.
- **REF-NIX-PREFETCH-FILE** — Nix `nix store prefetch-file` — https://nix.dev/manual/nix/2.18/command-ref/new-cli/nix3-store-prefetch-file
  - key: prefetch downloads a file to the Nix store and prints the resulting store path plus content hash.
  - why: strong precedent for explicit warm-up/fetch preparation as its own command.
  - us: give ViewFS a deliberate prefetch/warm-up lane instead of hiding it inside open.
- **REF-OSTREE-REPO-MGMT** — OSTree repository management — https://ostreedev.github.io/ostree/repository-management/
  - key: OSTree supports full or partial mirroring for offline and faster access.
  - why: mirror semantics are distinct and valuable.
  - us: keep mirrors/replicas distinct from local hydration and from activation/publication.
- **REF-OSTREE-STATIC-DELTAS** — OSTree static deltas for offline updates — https://ostreedev.github.io/ostree/copying-deltas/
  - key: OSTree can generate self-contained static delta files for offline updates.
  - why: strong precedent for an explicit offline bundle / transport artifact.
  - us: keep self-contained bundles separate from caches and mirrors.
- **REF-OSTREE-FORMATS** — OSTree data formats — https://ostreedev.github.io/ostree/formats/
  - key: static deltas can be targeted between commits and include per-file delta techniques such as bsdiff.
  - why: reminder that transport artifacts can have their own performance logic without redefining the store’s semantic core.
  - us: offline bundles and hydrate paths can optimize aggressively while still staying separate seams.
- **REF-SVCWORKER-SPEC** — Service Workers specification — https://www.w3.org/TR/service-workers/
  - key: service worker registrations, update-via-cache modes, and worker lifetime/cache behavior are explicit parts of the model.
  - why: useful precedent that warm-state/update/cache policy deserves named states instead of folklore.
  - us: keep ViewFS warm-state semantics explicit and inspectable.
- **REF-MDNPREFETCH** — MDN `rel="prefetch"` — https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Attributes/rel/prefetch
  - key: prefetch is only a hint, uses lower-priority fetching, is constrained by cache headers, and lives in HTTP cache rather than as a durable promise.
  - why: concise product-level reminder that hints and durable readiness are different.
  - us: keep prefetch advisory and distinguish it from hydration.
- **REF-MS-ALWAYSOFFLINE** — Microsoft Always Offline mode — https://learn.microsoft.com/en-us/windows-server/storage/folder-redirection/enable-always-offline
  - key: Offline Files caches files/folders locally so they can be used when the network is unavailable, and Always Offline is a performance/availability mode over that cache.
  - why: useful caution that offline convenience is not a new identity or authority model.
  - us: make offline-readiness explicit without letting it masquerade as broader trust or publication.


## Proposal provenance / scope / adoption
- **REF-GIT-CONFIG-ORIGIN-SCOPE** — Git `git-config` documentation — https://git-scm.com/docs/git-config
  - key: `git config` can show both `--show-origin` and `--show-scope`, exposing where a value came from and at what scope it applies.
  - why: excellent precedent for keeping provenance and scope inspectable instead of folklore.
  - us: proposer badges and scope chips should stay explicit in ViewFS shell UX.
- **REF-VSCODE-CHAT-CUSTOM-DIAG** — VS Code 1.109 release notes, chat customization diagnostics — https://code.visualstudio.com/updates/v1_109
  - key: chat customization files can originate from user profile, workspace, extensions, and GitHub organization; diagnostics show loaded customizations and load errors.
  - why: strong product precedent for multiple proposal sources plus explicit diagnostics.
  - us: ViewFS should expect multiple helper/proposal lanes and surface their origins early.
- **REF-VSCODE-MCP-SERVERS** — VS Code MCP server management docs — https://code.visualstudio.com/docs/copilot/customization/mcp-servers
  - key: MCP servers can be configured in the user profile or workspace; enable/disable state is stored separately; adding/changing a workspace MCP server requires trust confirmation before start.
  - why: strong precedent that source config, trust review, enablement, and current activation are different classes.
  - us: keep proposal source, review state, enablement, and adoption separate in ViewFS.
- **REF-VSCODE-AGENT-PERMISSIONS** — VS Code agent permissions and approvals — https://code.visualstudio.com/blogs/2025/04/07/agentMode
  - key: tool invocation approval is transparent, and a tool can be allowed for the current session, workspace, or all future invocations.
  - why: strong product precedent for explicit adoption scope ladders.
  - us: ViewFS should prefer narrowest-first scope choices and make wider standing effects explicit.
- **REF-VSCODE-AUTOPILOT-PERMISSIONS** — VS Code 1.111 release notes, permission levels — https://code.visualstudio.com/updates/v1_111
  - key: the permissions picker controls autonomy for the current session and can change during a session.
  - why: another strong precedent for session-scoped adoption distinct from broader standing policy.
  - us: ViewFS should treat `session` as a first-class adoption scope rather than faking it as global or workspace state.
- **REF-VSCODE-WORKSPACE-TRUST** — VS Code Workspace Trust — https://code.visualstudio.com/docs/editing/workspaces/workspace-trust
  - key: browsing a folder and trusting it to execute code are different decisions; Restricted Mode disables or limits agents, tasks, debugging, workspace settings, and extensions.
  - why: strong product precedent for keeping visibility and execution/trust separate.
  - us: ViewFS proposal surfaces should stay useful before adoption.
- **REF-POLKIT-AUTHORITY** — polkit reference manual / authority model — https://polkit.pages.freedesktop.org/polkit/polkit.8.html
  - key: polkit’s architecture separates the Authority from per-session Authentication Agents and supports temporary authorizations.
  - why: excellent reminder that consent-gathering surfaces are not themselves authorities.
  - us: keep shell proposal/adoption surfaces role-distinct from the authoritative act.


## Deny ceilings / scope eligibility / narrowing
- **REF-CEDAR-SECURITY** — Cedar security semantics — https://docs.cedarpolicy.com/other/security.html
  - key: Cedar is default-deny and a single `forbid` overrides `permit`.
  - why: strong precedent that explicit deny ceilings should beat broader allows.
  - us: keep deny ceilings authoritative and louder than helper convenience.
- **REF-VSCODE-CONTRIB-SCOPES** — VS Code contribution-point configuration scopes — https://code.visualstudio.com/api/references/contribution-points
  - key: settings have explicit applicability scopes such as `resource`, `window`, `machine`, and `machine-overridable`.
  - why: strong precedent that scope is partly about admissibility, not just duration.
  - us: some ViewFS proposal classes may simply not belong at broader scopes.
- **REF-VSCODE-WORKSPACE-TRUST-EXT** — VS Code Workspace Trust extension guide — https://code.visualstudio.com/api/extension-guides/workspace-trust
  - key: extensions can declare limited support in Restricted Mode and list `restrictedConfigurations` so workspace-defined values are withheld until trust is granted.
  - why: strong precedent that risky workspace-defined values can be visible yet ineligible until trust changes.
  - us: keep source visibility separate from scope eligibility and effective adoption.
- **REF-VSCODE-AGENT-TOOLS** — VS Code agent tools and permission levels — https://code.visualstudio.com/docs/copilot/agents/agent-tools
  - key: permission levels apply to the current session, while individual tool approvals can be granted for single use, current session, current workspace, or all future invocations.
  - why: strong precedent that session autonomy, one-shot approval, and broader standing adoption are different classes.
  - us: ViewFS should prefer narrowest-first ladders and keep wider adoption explicit.
- **REF-VSCODE-CHAT-OVERVIEW** — VS Code chat overview — https://code.visualstudio.com/docs/copilot/chat/copilot-chat
  - key: the permissions picker controls how much autonomy the agent has during a session.
  - why: another current precedent for session-bounded autonomy as a first-class product control.
  - us: treat `session` as a real lane, not as a disguised global mode.
- **REF-VSCODE-112** — VS Code 1.112 release notes — https://code.visualstudio.com/updates/v1_112
  - key: local agent sessions gained steering/queueing, clickable relative file links resolve against active session-state directory, and Copilot CLI now shares permission-level controls.
  - why: great terminal/product precedent for explicit session state, queued steering, and honest relative-link resolution.
  - us: resolve links and queued follow-ups against explicit pane/request state instead of scrollback folklore.


## Policy source classes / trust gating / imported helper material
- **REF-VSCODE-AI-POLICIES** — VS Code enterprise AI settings — https://code.visualstudio.com/docs/enterprise/ai-settings
  - key: organization policies can disable agents/hooks, restrict MCP server sources, disable global auto-approval, and force specific tools to require manual approval; these policies override lower-precedence user choices on managed devices.
  - why: strong precedent that owner/org ceilings are a distinct source class.
  - us: keep owner/org policy sources visibly distinct from user/profile preferences and helper proposals.
- **REF-VSCODE-ENTERPRISE-POLICIES** — VS Code enterprise policies — https://code.visualstudio.com/docs/enterprise/policies
  - key: managed-device policies override user-configured settings, and Linux policy files are explicitly supported starting in VS Code 1.106.
  - why: strong current precedent for source precedence and managed override surfaces.
  - us: keep owner/device ceilings distinct from local preferences and explainable in shell UX.
- **REF-VSCODE-MCP-CONFIG** — VS Code MCP configuration reference — https://code.visualstudio.com/docs/copilot/reference/mcp-configuration
  - key: MCP configuration can live in the workspace or user profile, and trust decisions can be reset independently of the configuration source.
  - why: strong precedent that source origin, trust state, and effective activation are different classes.
  - us: keep imported/discovered helper material and trust shutters distinct from current effective state.
- **REF-VSCODE-AGENT-PLUGINS** — VS Code agent plugins docs — https://code.visualstudio.com/docs/copilot/customization/agent-plugins
  - key: plugin MCP servers are implicitly trusted when the plugin is installed, unlike workspace MCP servers which do not get the same startup trust path.
  - why: very current cautionary case that a trusted carrier can surface powerful material without proving that the carrier should author every kind of active state.
  - us: keep carrier trust distinct from policy authorship and trust-gate authorship.
- **REF-VSCODE-CUSTOMIZE-AI** — VS Code AI customization overview — https://code.visualstudio.com/docs/copilot/customization/overview
  - key: customization discovery can walk upward from workspace folders to the repository root and collect multiple customization types across that path.
  - why: strong current reminder that carrier/discovery surfaces can be broad and convenient.
  - us: track parent-repo/workspace carriers explicitly and keep their material advisory until adopted.
- **REF-VSCODE-COPILOT-SECURITY** — VS Code Copilot security docs — https://code.visualstudio.com/docs/copilot/security
  - key: trust boundaries explicitly include workspace trust, publisher trust, and tool approvals with scoped grants.
  - why: a strong current product precedent that multiple trust boundaries coexist and should stay inspectable.
  - us: keep author class, carrier class, trust gates, and scoped approvals visibly distinct.


## Protected scopes / authorability / invoke-only lanes
- **REF-GIT-PROTECTED-CONFIG** — Git protected configuration docs — https://www.kernel.org/pub/software/scm/git/docs/git-config.html
  - key: protected configuration refers to the system, global, and command scopes, and certain options are only respected there for security reasons.
  - why: excellent precedent that some state classes should only be authorable from protected sources.
  - us: keep a source-class × state-class authorability matrix explicit in ViewFS.
- **REF-GIT-SAFE-DIRECTORY** — Git `safe.directory` / `safe.bareRepository` docs — https://git-scm.com/docs/git-config
  - key: `safe.directory` and `safe.bareRepository` are only respected in protected configuration to prevent untrusted repositories from tampering with them.
  - why: a very crisp precedent for protected-only state classes.
  - us: some ViewFS state classes should be categorically non-authorable from workspace/repo-carried material.
- **REF-VSCODE-CUSTOM-INSTRUCTIONS** — VS Code custom instructions docs — https://code.visualstudio.com/docs/copilot/customization/custom-instructions
  - key: custom instructions are always-on guidance that automatically influences AI responses.
  - why: useful contrast with manually-invoked helpers.
  - us: keep always-on adopted state distinct from invoke-only helper material.
- **REF-VSCODE-PROMPT-FILES** — VS Code prompt files docs — https://code.visualstudio.com/docs/copilot/customization/prompt-files
  - key: prompt files are manually invoked, can specify tools/agents, and live in workspace or user scope.
  - why: strong product precedent for invoke-only helper material that should not auto-apply.
  - us: add `invoke once` as a first-class ViewFS success path.
- **REF-VSCODE-CUSTOM-AGENTS** — VS Code custom agents docs — https://code.visualstudio.com/docs/copilot/customization/custom-agents
  - key: custom agents can come from built-in, user profile, workspace, organization, or extension sources, and VS Code can surface their source.
  - why: strong precedent for source-class inspection and persistent role/tool bundles.
  - us: source badges and matrix drawers should show both origin class and state class.
- **REF-DENO-PERM-BROKER** — Deno permission broker docs — https://docs.deno.com/runtime/fundamentals/security/
  - key: when a permission broker is active, local allow/deny flags are ignored, prompts are suppressed, and every check goes to the broker.
  - why: great precedent for visibly stronger authority lanes.
  - us: if ViewFS grows a stronger broker/owner/org lane, the shell should badge that explicitly instead of pretending local prompts are authoritative.


## Helper installs / enablement / live-session seams
- **REF-VSCODE-PUBLISHER-TRUST** — VS Code 1.97 release notes (trusted publishers) — https://code.visualstudio.com/updates/v1_97
  - key: VS Code now prompts when you install an extension from a publisher for the first time, can implicitly trust dependent publishers during that flow, and lets users revoke trusted publishers later.
  - why: strong precedent that publisher trust is a separate class from installed-package presence.
  - us: keep publisher trust distinct from installed helper packages and from live session state.
- **REF-VSCODE-MCP-SERVERS-LIVE** — VS Code MCP server management docs — https://code.visualstudio.com/docs/copilot/customization/mcp-servers
  - key: MCP servers can be installed in user or workspace scope, require trust confirmation before start, store enable/disable state separately from shared config, and can expose tools/resources/prompts/apps once live.
  - why: strong precedent that install, config, enablement, start approval, live session, and request-scoped use are different seams.
  - us: keep installed cards, start gates, live-session beacons, and request-scoped tool racks distinct in ViewFS.
- **REF-VSCODE-PLUGIN-LIFECYCLE** — VS Code agent plugin docs — https://code.visualstudio.com/docs/copilot/customization/agent-plugins
  - key: plugin MCP servers are implicitly trusted when the plugin is installed, disabling a plugin stops its MCP servers, and enable/disable state is stored separately from shared configuration.
  - why: excellent cautionary case that install-time trust and runtime liveness are different truths.
  - us: do not let installed helper presence silently become current live authority.
- **REF-VSCODE-112-LIFECYCLE** — VS Code 1.112 release notes — https://code.visualstudio.com/updates/v1_112
  - key: plugins and MCP servers can now be enabled/disabled globally or per-workspace without uninstalling them, and some plugin updates require approval because they may run new code.
  - why: strong current product precedent that install state, enablement, and code-running approval are different lifecycle steps.
  - us: keep enablement toggles and start gates separate from install receipts.
- **REF-VSCODE-COPILOT-BOUNDARIES** — VS Code Copilot security docs — https://code.visualstudio.com/docs/copilot/security
  - key: workspace trust, publisher trust, MCP server trust, and network-domain trust are separate consent boundaries; MCP trust re-prompts after configuration changes and session isolation is explicit.
  - why: strong precedent that helper use crosses multiple independent trust boundaries.
  - us: lifecycle receipts should preserve whether a helper was merely installed, start-approved, live, or selected for the current request.
- **REF-DENO-PERM-BROKER-LIVE** — Deno permission broker docs — https://docs.deno.com/runtime/fundamentals/security/
  - key: once the broker is active, local flags and prompts stop being authoritative.
  - why: clean precedent that a live brokered lane is stronger than remembered setup state.
  - us: keep live helper/broker sessions visibly distinct from installed/configured/enabled state.


## Helper feature catalogs / completion / request binding
- **REF-MCP-SPEC-FEATURES** — MCP specification overview — https://modelcontextprotocol.io/specification/2025-11-25
  - key: current MCP server features are resources, prompts, and tools.
  - why: strong reminder that helper-exposed feature kinds are intentionally distinct.
  - us: ViewFS should resist flattening helper catalogs into one generic item class.
- **REF-MCP-RESOURCES** — MCP resources spec — https://modelcontextprotocol.io/specification/2025-06-18/server/resources
  - key: resources share context/data such as files, schemas, or application-specific information, and are identified by URIs.
  - why: resources are a different semantic class from prompts or tool invocations.
  - us: a resource shelf should not masquerade as a tool call or a workflow template.
- **REF-MCP-PROMPTS** — MCP prompts spec — https://modelcontextprotocol.io/specification/2025-06-18/server/prompts
  - key: prompts are structured templates that can be discovered, retrieved, and customized with arguments.
  - why: prompt templates are a different semantic class from resources and tool calls.
  - us: prompt chips should stay distinct from adopted workflows and current invocations.
- **REF-MCP-TOOLS** — MCP tools spec — https://modelcontextprotocol.io/specification/2025-06-18/server/tools
  - key: tools are invocable functions exposed by a server and described with schemas.
  - why: visible tool descriptors are not the same thing as completed invocations or current request bindings.
  - us: keep tool racks and invocation receipts distinct.
- **REF-MCP-COMPLETION** — MCP completion utility — https://modelcontextprotocol.io/specification/draft/server/utilities/completion
  - key: completions apply to prompt arguments and resource templates; implementations must validate inputs, rate-limit, control sensitive suggestions, and prevent completion-based information disclosure.
  - why: completion surfaces are useful but not harmless or authority-bearing by default.
  - us: keep completion popovers distinct from current bindings or granted authority.

## Added in Revision 038
- **REF-MCP-TASKS** — MCP tasks draft/spec — https://modelcontextprotocol.io/specification/draft/basic/utilities/tasks
  - key: task-augmented requests use a two-phase pattern where acceptance returns task metadata and the actual result is retrieved later via `tasks/result`
  - why: strong precedent for keeping accepted-task wrappers distinct from final results
  - us: keep immediate requests, accepted task wrappers, input-needed checkpoints, and final results separate
- **REF-MCP-PROGRESS** — MCP progress utility — https://modelcontextprotocol.io/specification/2025-11-25/basic/utilities/progress
  - key: progress updates ride a separate progress token lane rather than the primary result channel
  - why: good precedent for progress lanes that stay advisory
  - us: keep live progress distinct from durable results or receipts
- **REF-XDG-REQUEST** — XDG portal Request interface — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Request.html
  - key: portal calls return a Request handle that lives for the duration of the interaction and emits a later `Response` signal
  - why: strong precedent for keeping request/interaction state separate from results
  - us: request objects in ViewFS should not masquerade as final outcomes
- **REF-XDG-BACKGROUND** — XDG Background portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Background.html
  - key: background/autostart permission and background status messaging are explicit, separate surfaces
  - why: useful warning against collapsing background permission, live status, and completion
  - us: keep background permission/status separate from task execution and final results
- **REF-GCLOUD-LRO** — Google long-running Operations interface — https://docs.cloud.google.com/service-infrastructure/docs/service-management/reference/rpc/google.longrunning
  - key: long-running APIs return an `Operation`; latest state is polled separately and `WaitOperation` is best-effort
  - why: strong precedent for distinguishing initiation, latest known state, and final retrievable result
  - us: result lockers and progress lanes should stay separate
- **REF-VSCODE-TASKS-BG** — VS Code task docs — https://code.visualstudio.com/docs/debugtest/tasks
  - key: background/watch tasks in ordered dependencies need explicit tracking for when they are “done”, and task output presentation is separately configurable
  - why: useful reminder that shells already need explicit deferred-work truth rather than plain output logs
  - us: keep queueing/completion/status distinct in shell UX
- **REF-VSCODE-109-BGAGENTS** — VS Code 1.109 release notes — https://code.visualstudio.com/updates/v1_109
  - key: current agent UX includes message steering/queueing while a request is still running and named background agent sessions
  - why: a good product precedent for follow-up-on-running-request UX
  - us: let ViewFS queue follow-ups honestly without collapsing them into the current running task
- **REF-VSCODE-110-TERMSECTIONS** — VS Code 1.110 release notes — https://code.visualstudio.com/updates/v1_110
  - key: terminal tool invocations can collapse into summary headers while preserving access to the full output
  - why: excellent product precedent for richer command sections without drowning the transcript
  - us: give ViewFS command blocks compact truth-bearing headers and expandable detail

- **REF-AIP151-LRO** — Google AIP-151 long-running operations — https://google.aip.dev/151
  - key: long-running operations may expire after completion; 30 days is a rule of thumb; parallel operations and execution errors are also explicit concerns
  - why: useful precedent for explicit result-retention and history-only degradation instead of magical infinite lockers
  - us: keep task/result expiry explicit and separate from stop acts or durable receipts
- **REF-TEMPORAL-INTERRUPT** — Temporal cancellation and termination docs — https://docs.temporal.io/evaluate/development-production-features/interrupt-workflow
  - key: cancellation is the graceful stop path; termination is the immediate force-stop path for stuck work
  - why: strong precedent for keeping stop ladders honest instead of one generic kill verb
  - us: distinguish graceful cancel from force terminate in ViewFS control UX and receipts
- **REF-TEMPORAL-WFID** — Temporal Workflow ID / Run ID docs — https://docs.temporal.io/workflow-execution/workflowid-runid
  - key: retries, resets, continue-as-new, reuse, conflict policy, and use-existing behavior all produce different run-identity consequences
  - why: excellent precedent for keeping retry, fork/reset, and attach-to-existing visibly distinct
  - us: model rerun controls as explicit new-run / attach / fork lanes rather than a single “try again” button
- **REF-VSCODE-CHAT-SESSIONS** — VS Code chat session management docs — https://code.visualstudio.com/docs/copilot/chat/chat-sessions
  - key: sessions can fork, run in parallel, and preserve checkpoints/history while remaining independent afterward
  - why: product precedent for branch-from-history UX that does not pretend to be the same running task
  - us: steal fork-from-checkpoint ideas for rerun drawers and result-history branching surfaces


## Added in Revision 040
- **REF-KUBECTL-ATTACH** — Kubernetes `kubectl attach` docs — https://kubernetes.io/docs/reference/kubectl/generated/kubectl_attach/
  - key: `attach` attaches to a process already running inside an existing container.
  - why: strong precedent that attachment is not the same act as log-follow or command injection.
  - us: keep interactive attach distinct from observe-only and debug-exec lanes.
- **REF-KUBECTL-LOGS** — Kubernetes `kubectl logs` docs — https://kubernetes.io/docs/reference/kubectl/generated/kubectl_logs/
  - key: `kubectl logs` prints logs and `-f` streams them like `tail -f`.
  - why: strong precedent that follow-only output is a first-class lane.
  - us: keep follow tails distinct from attach/control/exec lanes.
- **REF-KUBECTL-PORTFWD** — Kubernetes `kubectl port-forward` docs — https://kubernetes.io/docs/reference/kubectl/generated/kubectl_port-forward/
  - key: port forwarding opens a temporary local-to-remote tunnel and ends when the selected pod terminates.
  - why: strong precedent that sideband access has its own lifetime and semantics.
  - us: keep sideband tunnel lanes distinct from object grants or interactive shells.
- **REF-TMUX** — `tmux(1)` manual page — https://man7.org/linux/man-pages/man1/tmux.1.html
  - key: tmux distinguishes read-only clients, control mode, detach/reattach, and ordinary attached clients.
  - why: useful precedent for observe-only vs control-capable live presence.
  - us: keep read-only attach, control panes, and detached history visibly distinct.
- **REF-TEMPORAL-MESSAGES** — Temporal message handling docs — https://docs.temporal.io/handling-messages
  - key: Queries read state, Signals send asynchronous control, and Updates synchronously change state and return a result.
  - why: strong precedent that read-only inspection, asynchronous control, and synchronous mutation are different verbs.
  - us: keep query/observe lanes, control-message lanes, and synchronous update lanes separate.
- **REF-XDG-INPUTCAPTURE** — XDG InputCapture portal docs — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.InputCapture.html
  - key: input capture distinguishes `enabled` from `active`, and the compositor decides when capture becomes active.
  - why: excellent precedent that readiness/arming is not the same thing as active live control.
  - us: badge armed-versus-active attach/control state explicitly in shell chrome.

## Added in Revision 041
- **REF-WAYLAND-DATADEVICES** — Wayland protocol and model of operation / data sharing between clients — https://wayland.freedesktop.org/docs/book/Protocol.html
  - key: Wayland copy-paste and drag/drop use `wl_data_source` and `wl_data_offer`; clients negotiate a MIME type and transfer the data through an explicit passed file descriptor.
  - why: strong precedent that transfer should remain a typed mediated act rather than an ambient clipboard/path loophole.
  - us: keep ViewFS transfer lanes explicit about offer, acceptance, representation, and actual delivery.

## Added in Revision 044
- **REF-SYSTEMD-FDSTORE** — systemd `sd_notify_with_fds` / file descriptor store docs — https://www.freedesktop.org/software/systemd/man/latest/sd_pid_notify_with_fds.html
  - key: services can explicitly store selected file descriptors in the service manager and receive them back on the next start/restart; stop/discard and preserve are separate states.
  - why: excellent precedent for a narrow exact-handle continuity seam that does not pretend to be full persistent authority.
  - us: keep ViewFS continuity lockers typed, explicit, and narrower than durable reopen or persistent-root semantics.


## Added in Revision 045
- **REF-MEMFD-CREATE** — Linux `memfd_create(2)` manual — https://man7.org/linux/man-pages/man2/memfd_create.2.html
  - key: `memfd_create()` creates an anonymous, RAM-backed file descriptor that behaves like a regular file, but vanishes when references are dropped
  - why: strong precedent for explicit transient byte capsules that are exact without becoming named durable files
  - us: keep draft/staging objects separate from committed object-store identity
- **REF-MEMFD-SEALS** — Linux `F_GET_SEALS(2const)` manual — https://man7.org/linux/man-pages/man2/F_GET_SEALS.2const.html
  - key: memfd-backed files can be sealed so allowed operations shrink and seals can only be added, not removed
  - why: excellent precedent for reviewable “freeze this payload now” staging semantics
  - us: explore sealed staging capsules for compare-before-commit and exact export/import review
- **REF-UNIX-SCMRIGHTS** — Linux `unix(7)` manual — https://man7.org/linux/man-pages/man7/unix.7.html
  - key: UNIX domain sockets support passing file descriptors or process credentials using ancillary data
  - why: strong precedent for explicit local handle courier lanes instead of path reopen folklore
  - us: keep exact local transfer as an explicit send/receive act separate from durable reopen or durable grants



## Added in Revision 046
- **REF-SEL4-BADGES** — seL4 IPC tutorial / badged endpoint capabilities — https://docs.sel4.systems/Tutorials/libraries-2.html
  - key: a badge is applied to the sender's capability copy, not to the endpoint object itself, and minted copies can carry different badge values
  - why: excellent precedent for keeping issuer-visible handle-copy metadata separate from object identity
  - us: ViewFS can explore badged handle copies and lineage drawers without pretending the badge is the object's immutable identity
- **REF-SYSTEMD-SOCKETACT** — systemd `sd_listen_fds(3)` / `systemd.socket(5)` docs — https://www.freedesktop.org/software/systemd/man/sd_listen_fds.html
  - key: services can be started with file descriptors already handed in by the service manager via socket activation
  - why: strong precedent for activation kits and startup delivery that do not rely on ambient rediscovery
  - us: keep launch-slot delivery separate from steady-state naming and durable reopen
- **REF-VSCODE-SHELLINT** — VS Code terminal shell integration docs — https://code.visualstudio.com/docs/terminal/shell-integration
  - key: shell integration advertises quality levels and supports command decorations, sticky scroll, command-aware navigation, and nonce-protected sequences
  - why: strong product precedent for a truth ladder in terminal chrome rather than one fake trust bit
  - us: distinguish guessed blocks, marked blocks, shell-reported commands, and receipt-bound action objects before enabling stronger actions


## Added in Revision 047
- **REF-SOCKET-PASSCRED** — Linux `socket(7)` manual — https://man7.org/linux/man-pages/man7/socket.7.html
  - key: `SO_PASSCRED` enables receiving `SCM_CREDENTIALS`, and `SO_PEERCRED` returns the connected peer's credentials.
  - why: strong precedent that courier/source provenance can ride beside a transfer channel without redefining the transferred object.
  - us: keep courier witness separate from live transferred handle, object identity, and durable receipts.
- **REF-VSCODE-106-ATTCMD** — VS Code 1.106 release notes (Attach terminal commands to chat) — https://code.visualstudio.com/updates/v1_106
  - key: a tracked terminal command can be attached as structured context including command line, captured output, and exit code.
  - why: strong product precedent for promoting reviewed command blocks into explicit packets rather than copy-pasted transcript blobs.
  - us: let the ViewFS shell promote strong-truth command blocks into routeable/explainable command packets.


## Added in Revision 048
- **REF-LINUX-PIDFD** — Linux `pidfd_open(2)` manual — https://man7.org/linux/man-pages/man2/pidfd_open.2.html
  - key: `pidfd_open()` returns a file descriptor that refers to a process; pidfds can be polled, waited on, signaled, and used with `setns(2)`.
  - why: strong precedent that exact running-process identity can be a handle rather than a PID string, but that handle may also carry stronger powers than simple lifecycle control.
  - us: keep running-command identity separate from lifecycle-control rights and deeper inspection/namespace-follow lanes.
- **REF-LINUX-PIDFD-GETFD** — Linux `pidfd_getfd(2)` manual — https://man7.org/linux/man-pages/man2/pidfd_getfd.2.html
  - key: `pidfd_getfd()` duplicates another process's file descriptor into the caller, referring to the same open file description.
  - why: excellent caution that some process-handle-adjacent powers are much stronger than “observe or stop this command.”
  - us: do not let ordinary shell process cards silently imply fd-duplication or debugger-grade powers.
- **REF-FREEBSD-PROCDESC** — FreeBSD `procdesc(4)` manual — https://man.freebsd.org/cgi/man.cgi?query=procdesc&sektion=4
  - key: process descriptors are a file-descriptor-oriented interface to process signalling and control, designed for Capsicum and intended to replace PID-oriented races with capability-oriented references.
  - why: strong cross-platform precedent that process identity/control can be capability-shaped without ambient PID rediscovery.
  - us: explore exact running-command objects for ViewFS shell chrome without committing to one kernel mechanism.


## Added in Revision 050
- **REF-LINUX-OPEN-TREE** — Linux `open_tree(2)` manual — https://man7.org/linux/man-pages/man2/open_tree.2.html
  - key: `open_tree()` is part of Linux's file-descriptor-based mount API; with `OPEN_TREE_CLONE` it creates a detached mount object tied to a file descriptor and not yet mounted onto the filesystem.
  - why: strong precedent that a subtree/namespace fragment can exist before attachment.
  - us: keep detached view fragments separate from live binds and current placement.
- **REF-LINUX-MOVE-MOUNT** — Linux `move_mount(2)` manual — https://man7.org/linux/man-pages/man2/move_mount.2.html
  - key: `move_mount()` is the common mechanism used to attach detached mount objects created by `open_tree()` or `fsmount()`.
  - why: strong precedent that attach is a separate explicit act rather than part of fragment creation.
  - us: treat bind/attach as its own receipted lane.
- **REF-LINUX-MOUNT-SETATTR** — Linux `mount_setattr(2)` manual — https://manpages.ubuntu.com/manpages/resolute/man2/mount_setattr.2.html
  - key: some mount posture changes, such as ID mappings, require the mount to still be detached and not yet visible in a mount namespace.
  - why: strong precedent that some posture belongs to a pre-attach phase rather than to ordinary live placement.
  - us: keep pre-attach posture separate from live bind state.
- **REF-XTERM-BRACKETED-PASTE** — xterm bracketed paste notes — https://invisible-island.net/xterm/xterm-paste64.html
  - key: bracketed paste explicitly marks pasted text so the receiving shell/application can treat it differently from typed editing input.
  - why: strong precedent that input origin should be visible in terminal UX.
  - us: explore paste capsules, inspect-before-run, and prompt-local paste rails.
- **REF-KITTY-KEYBOARD** — kitty keyboard protocol — https://sw.kovidgoyal.net/kitty/keyboard-protocol/
  - key: the protocol supports disambiguated key events and optional press/repeat/release reporting.
  - why: strong precedent that richer terminal UX can ride explicit key packets instead of ambiguous legacy byte collisions.
  - us: explore prompt-local gesture lanes and high-fidelity key input for ViewFS shell chrome.

## Added in Revision 051
- **REF-MAN7-FEXECVE** — Linux `fexecve(3)` manual — https://man7.org/linux/man-pages/man3/fexecve.3.html
  - key: `fexecve()` executes a program identified by a file descriptor rather than a pathname.
  - why: strong precedent that launch identity can be exact-object-oriented instead of path-reopen-oriented.
  - us: keep exact exec objects separate from mutable path folklore.
- **REF-MAN7-EXECVEAT** — Linux `execveat(2)` manual — https://man7.org/linux/man-pages/man2/execveat.2.html
  - key: with `AT_EMPTY_PATH`, `execveat()` can execute the file referred to directly by a file descriptor.
  - why: strong precedent that execution-by-handle is a real OS seam, not just shell imagination.
  - us: allow ViewFS launch design to stay exact-object-first even if per-platform adapters differ.
- **REF-OCI-RUNTIME-CONFIG** — OCI runtime spec: configuration — https://github.com/opencontainers/runtime-spec/blob/main/config.md
  - key: runtime config separates root filesystem, process-to-run details, hooks, and sandbox/runtime features in one explicit surface.
  - why: strong cross-ecosystem precedent that launch target, hosting runtime, and bootstrap envelope should not collapse into one command row.
  - us: keep exec object, runner/runtime choice, bootstrap posture, and live session visibly separate.
- **REF-OCI-PROCESS-CONFIGGO** — OCI runtime spec Go bindings: `Process` struct — https://github.com/opencontainers/runtime-spec/blob/main/specs-go/config.go
  - key: the process section independently names terminal, args, env, cwd, user, capabilities, labels, rlimits, scheduler, and CPU affinity.
  - why: useful concrete reminder that a process launch is a structured bundle of distinct truths, not one string.
  - us: strengthen ViewFS launch-basis / runner-badge / session-kind shell chrome without overfitting to OCI.
- **REF-SYSTEMD-CREDENTIALS** — systemd credential docs — https://systemd.io/CREDENTIALS/
  - key: service credentials are acquired at activation time, released on deactivation, immutable during the run, and exposed through `$CREDENTIALS_DIRECTORY`.
  - why: strong precedent that startup credentials are a narrower launch-time lane than environment folklore or durable authority.
  - us: keep startup credential slots explicit, content-minimizing, and separate from env and durable reopen.


## Added in Revision 052
- **REF-LINUX-LDSO** — Linux `ld.so(8)` manual — https://man7.org/linux/man-pages/man8/ld.so.8.html
  - key: `LD_LIBRARY_PATH` influences shared-library search, empty path entries can mean the current working directory, `LD_PRELOAD` can inject extra shared objects, and these controls are only partly suppressed in secure-execution mode.
  - why: strong precedent that exact executable-object launch is still not the same thing as exact startup code closure.
  - us: keep startup code closure and loader search posture separate from exec-object identity.
- **REF-LINUX-DLOPEN** — Linux `dlopen(3)` manual — https://man7.org/linux/man-pages/man3/dlopen.3.html
  - key: `dlopen()` resolves libraries using RPATH/RUNPATH, `LD_LIBRARY_PATH`, cache/default directories, and automatically loads dependency chains under the same rules.
  - why: strong precedent that late dynamic imports are a separate lane from initial exec-object selection.
  - us: keep later plugin/module imports separate from startup closure and from launch history.
- **REF-WIN-DLL-SEARCH** — Microsoft Dynamic-link library search order docs — https://learn.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-search-order
  - key: Windows DLL resolution depends on search order, safe DLL search mode, per-process changes such as `SetDllDirectory`, and `LOAD_LIBRARY_SEARCH_*` flags.
  - why: strong precedent that loader search policy is its own risk surface and not just part of executable identity.
  - us: keep loader/search posture explicit debt or explicit policy rather than hidden launch folklore.
- **REF-WIN-LOADLIBRARY** — Microsoft `LoadLibraryA` docs — https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-loadlibrarya
  - key: `LoadLibrary` uses DLL search order unless given a full path, loaded-module identity is per-process, and Microsoft explicitly warns not to use `SearchPath` to find a DLL for a later `LoadLibrary` call.
  - why: strong precedent that late imports/plugins are their own lane and that name-based rediscovery can be security-sensitive.
  - us: late plugin/import requests should be visible, reviewable, and separate from startup closure claims.


## Added in Revision 053
- **REF-WAYLAND-PRIMARY-SELECTION** — Wayland primary selection protocol — https://wayland.app/protocols/primary-selection-unstable-v1
  - key: primary-selection offers advertise MIME types and only transfer bytes when the receiver explicitly requests one representation via a file descriptor.
  - why: strong precedent that current selection ownership, offered representation sets, and accepted transfers are different truths.
  - us: keep clipboard/selection owner, accepted representation, prompt paste, and imported-object acts visibly separate.
- **REF-X11-ICCCM-SELECTIONS** — ICCCM selections / owner-requestor transfer conventions — https://tronche.com/gui/x/icccm/sec-2.html
  - key: X11 selections are owner/requestor transfer relationships; ownership can change, requestors choose properties/targets, and large transfers are incremental.
  - why: strong historical warning that clipboard/selection is not the same thing as a durable shared object store.
  - us: avoid turning copy/paste history into hidden durable authority.
- **REF-KITTY-CLIPBOARD** — kitty clipboard protocol — https://sw.kovidgoyal.net/kitty/clipboard/
  - key: terminals can expose typed clipboard reads/writes, permission-gate reads, list available MIME types, and distinguish clipboard from primary selection.
  - why: strong product precedent that rich clipboard UX can still stay explicit and reviewable.
  - us: explore clipboard-offer cards, MIME inspection, and paste/import ladders without treating raw paste as the whole model.


## Added in Revision 054
- **REF-LINUX-CREDENTIALS-JC** — Linux `credentials(7)` manual — https://man7.org/linux/man-pages/man7/credentials.7.html
  - key: sessions, process groups, controlling terminals, foreground jobs, and terminal-generated signals are explicit layers of classic job control.
  - why: strong precedent that running-process identity is not the same thing as interactive terminal ownership.
  - us: keep live process handles, terminal streams, controlling-TTY posture, and foreground turns visibly separate.
- **REF-LINUX-SETPGID** — Linux `setpgid(2)` / `getpgrp(2)` manual — https://man7.org/linux/man-pages/man2/getpgrp.2.html
  - key: only the foreground process group may read from the controlling terminal, and `tcgetpgrp` / `tcsetpgrp` manage that foreground group.
  - why: strong precedent that foreground ownership is explicit current posture, not just whichever process is visible in a pane.
  - us: surface foreground-turn / interrupt-target truth separately from process cards or transcript rows.
- **REF-LINUX-SETSID** — Linux `setsid(2)` manual — https://man7.org/linux/man-pages/man2/setsid.2.html
  - key: sessions and controlling-terminal hangup behavior are explicit; when a session leader terminates, SIGHUP is sent to the foreground process group of the controlling terminal.
  - why: strong reminder that terminal lifecycle and foreground ownership are separate from mere byte streams.
  - us: keep detach/hangup posture visible instead of hiding it in generic session language.
- **REF-GLIBC-LOGINTTY** — glibc manual `login_tty()` docs — https://sourceware.org/glibc/manual/latest/html_node/Logging-In-and-Out.html
  - key: `login_tty()` makes one fd the controlling terminal and redirects stdin/stdout/stderr to it.
  - why: strong precedent that stream wiring and controlling-terminal adoption are related but still explicit acts.
  - us: do not let ViewFS attach UX pretend that visible streams automatically imply controlling-terminal ownership.
- **REF-LINUX-TTY4** — Linux `tty(4)` manual — https://man7.org/linux/man-pages/man4/tty.4.html
  - key: `/dev/tty` names the controlling terminal of the current process, and `TIOCNOTTY` detaches a process from its controlling terminal.
  - why: strong precedent that a controlling-terminal relationship is its own posture and can be explicitly detached.
  - us: keep controlling-TTY posture and detach receipts separate from generic process/session identity.


## Added in Revision 056
- **REF-MAN7-OPEN** — Linux `open(2)` manual — https://man7.org/linux/man-pages/man2/open.2.html
  - key: `open()` creates a new open file description that records file offset and file status flags, and the returned file descriptor is a reference to that open file description.
  - why: strong precedent that a current descriptor/slot and the mutable open state it refers to are different layers.
  - us: keep slot/local binding separate from shared live open state.
- **REF-MAN7-DUP** — Linux `dup(2)` manual — https://man7.org/linux/man-pages/man2/dup.2.html
  - key: `dup()` creates another file descriptor referring to the same open file description, sharing file offset and status flags while not sharing descriptor flags like `FD_CLOEXEC`.
  - why: strong precedent that “copy this handle” can mean “alias one live open state,” not “mint an independent reopen.”
  - us: keep duplicate-handle lanes separate from independent reopen lanes in ViewFS and shell chrome.
- **REF-LINUX-FLOCK** — Linux `flock(2)` manual — https://man7.org/linux/man-pages/man2/flock.2.html
  - key: `flock()` locks are associated with the open file description, so duplicate descriptors share and can release the same lock, while independently opened descriptors are treated separately.
  - why: strong precedent that live lock/lease state can attach to the shared open-state layer rather than to object identity or slot identity.
  - us: keep shared-open-state / lease / lock truth visible instead of hiding it inside generic handle rows.

## Added in Revision 057
- **REF-LINUX-OPATH** — Linux `open(2)` manual (`O_PATH`) — https://man7.org/linux/man-pages/man2/open.2.html
  - key: `O_PATH` yields a descriptor that indicates a location in the filesystem tree and supports descriptor-level operations, while `read`, `write`, `ioctl`, and `mmap` on that descriptor fail with `EBADF`.
  - why: strong precedent that designation/metadata handles and byte-I/O handles are different classes.
  - us: keep locator/root handles separate from live read/write handles in ViewFS and shell chrome.
- **REF-LINUX-STATX** — Linux `statx(2)` manual — https://man7.org/linux/man-pages/man2/statx.2.html
  - key: `statx()` with `AT_EMPTY_PATH` can operate on the file referred to by a descriptor, including one obtained with `O_PATH`, without requiring a pathname walk.
  - why: strong precedent that metadata/inspection flows can stay attached to a current handle without implying byte-I/O.
  - us: support inspect-first cards and metadata-only handle classes without pretending they are already open streams.
- **REF-LINUX-OPENTREE** — Linux `open_tree(2)` manual — https://man7.org/linux/man-pages/man2/open_tree.2.html
  - key: `open_tree()` can return an `O_PATH`-style descriptor, while `OPEN_TREE_CLONE` creates a detached mount object rather than a generic byte-I/O descriptor.
  - why: strong precedent that rooted designation objects and detached namespace fragments are not the same thing as live data-stream handles.
  - us: keep root/walk handles, detached fragments, and live byte-I/O on visibly separate seams.

## Added in Revision 058
- **REF-MAN7-EXEC3P** — POSIX `exec(3p)` manual — https://man7.org/linux/man-pages/man3/exec.3p.html
  - key: file descriptors open in the calling process remain open in the new process image except those with `FD_CLOEXEC`, and descriptors that remain open preserve the attributes of the same open file description.
  - why: strong precedent that launch-boundary inheritance is its own truth surface and not a property of the object alone.
  - us: keep current handle possession separate from reviewed child delivery.
- **REF-MAN7-POSIX-SPAWN** — Linux `posix_spawn(3)` manual — https://man7.org/linux/man-pages/man3/posix_spawn.3.html
  - key: if `file_actions` is `NULL`, normal exec semantics apply and pre-open descriptors remain open in the new process except those marked close-on-exec.
  - why: strong precedent that spawn/launch review needs explicit file-action / child-slot thinking instead of assuming a clean slate.
  - us: keep launch-boundary shutters and exact child-slot maps explicit in ViewFS.
- **REF-MAN7-CLOSE-RANGE** — Linux `close_range(2)` manual — https://man7.org/linux/man-pages/man2/close_range.2.html
  - key: `close_range(..., CLOSE_RANGE_CLOEXEC)` sets the close-on-exec flag across a range of descriptors instead of closing them immediately.
  - why: strong precedent that bulk launch-boundary shutters are a real systems need.
  - us: support inheritance shutters and leak-siren UX without pretending every live handle should cross launch.
- **REF-MAN7-FCNTL** — Linux `fcntl(2)` manual — https://man7.org/linux/man-pages/man2/fcntl.2.html
  - key: POSIX.1-2024 specifies `FD_CLOFORK` and `F_DUPFD_CLOFORK`, though Linux does not support them.
  - why: strong precedent that inheritance across `fork` can deserve an explicit posture separate from `exec` inheritance.
  - us: keep the higher-level separation visible without committing to one host mechanism.
- **REF-OPENBSD-FCNTL** — OpenBSD `fcntl(2)` manual — https://man.openbsd.org/fcntl.2
  - key: OpenBSD exposes both `FD_CLOEXEC` and `FD_CLOFORK` in `F_GETFD` / `F_SETFD`.
  - why: concrete precedent that close-on-fork is not just theory and that inheritance posture can have more than one boundary.
  - us: treat launch-boundary inheritance as explicit reviewable posture rather than an accidental side effect.

## Added in Revision 059
- **REF-FUCHSIA-FSARCH** — Fuchsia, *Filesystem Architecture* — https://fuchsia.dev/fuchsia-src/concepts/filesystems/filesystems
  - key: path-based operations like `rename` and `link` act on multiple paths, open both parent directories, and use a vnode token/cookie so one parent operation can safely refer to the other.
  - why: strong precedent that namespace mutation is not the same thing as opening or reading one object.
  - us: keep object identity, source parent anchor, destination parent anchor, and mutation act visibly separate.
- **REF-FREEBSD-RIGHTS-LIVE** — FreeBSD `rights(4)` manual — https://man.freebsd.org/cgi/man.cgi?apropos=0&manpath=FreeBSD+10.0-RELEASE&query=rights&sektion=4
  - key: `CAP_RENAMEAT` is required on the source directory descriptor, `CAP_LINKAT` on the destination directory descriptor, and `CAP_UNLINKAT` on the destination when a rename replaces an existing target.
  - why: strong precedent that source-parent and destination-parent namespace powers are different rights, not one generic object right.
  - us: surface separate source/destination parent badges and keep overwrite authority explicit.
- **REF-MAN7-RENAME** — Linux `rename(2)` / `renameat2(2)` manual — https://man7.org/linux/man-pages/man2/rename.2.html
  - key: `renameat2()` makes collision policy explicit with flags such as `RENAME_NOREPLACE` and `RENAME_EXCHANGE`, while open descriptors for the old path remain unaffected.
  - why: strong precedent that namespace mutation mode is its own truth surface and not a side effect of opening a file.
  - us: support explicit collision-mode ladders and `same object, new placement` receipts without conflating them with byte handles.


## Added in Revision 060
- **REF-MAN7-MOUNTNS** — Linux `mount_namespaces(7)` manual — https://man7.org/linux/man-pages/man7/mount_namespaces.7.html
  - key: mount propagation is a per-mount-point setting; mounts may be shared, private, slave, or unbindable, peer groups are visible in `/proc/*/mountinfo`, and new mounts under shared parents inherit shared propagation.
  - why: strong precedent that a current attachment and its later propagation/blast radius are different layers.
  - us: keep live binds, propagation posture, peer/upstream relationships, and receipts visibly separate.


## Added in Revision 061
- **REF-LINUX-OTMPFILE** — Linux `open(2)` manual (`O_TMPFILE`) — https://man7.org/linux/man-pages/man2/open.2.html
  - key: `O_TMPFILE` creates an unnamed temporary regular file in the target filesystem; the object persists until the last descriptor closes unless it is later given a name.
  - why: strong precedent that object creation and namespace publication are different acts.
  - us: keep draft objects and published names on different seams.
- **REF-MAN7-LINKAT** — Linux `linkat(2)` manual — https://man7.org/linux/man-pages/man2/link.2.html
  - key: `linkat()` with `AT_EMPTY_PATH` can link an unnamed `O_TMPFILE` object into the filesystem, turning an already-existing unnamed object into a visible name.
  - why: strong precedent that namespace publication can be an explicit later act with its own target anchor and collision consequences.
  - us: keep publication anchors, publication acts, and receipts separate from object creation.


## Added in Revision 062
- **REF-OCI-DESCRIPTOR** — OCI image spec, descriptor.md — https://github.com/opencontainers/image-spec/blob/main/descriptor.md
  - key: OCI content descriptors carry digest, media type, and size, and the descriptor is the secure way to refer to external content in the Merkle/DAG model.
  - why: strong precedent that exact content description can be useful and durable without being the same thing as a current live handle or placement.
  - us: keep ViewFS content/object descriptors separate from live handles/binds and separate again from receipts/history.


## Added in Revision 063
- **REF-FUCHSIA-HANDLES** — Fuchsia kernel handles — https://fuchsia.dev/fuchsia-src/concepts/kernel/handles
  - key: a handle carries object reference + rights, can be duplicated with fewer rights, and handle transfer is explicit rather than ambient.
  - why: strong precedent that current authority, duplication, and later rights-drop are separate seams from durable designation.
  - us: keep live handles separate from imported source refs, local docrefs, and receipts.
- **REF-KITTY-SHELLINT** — kitty shell integration docs — https://sw.kovidgoyal.net/kitty/shell-integration/
  - key: shell integration can be auto-bootstrapped through terminal-provided startup plumbing and environment hints.
  - why: strong cautionary precedent that great shell chrome can come with hidden bootstrap magic and invisible state.
  - us: keep semantic shell integration rich but inspectable, and never let bootstrap tricks smuggle authority.
- **REF-SD-NOTIFY-BARRIER** — systemd `sd_notify(3)` barrier docs — https://man7.org/linux/man-pages/man3/sd_notify.3.html
  - key: barrier-style acknowledgement can distinguish notifications already processed from later/outstanding ones.
  - why: strong precedent that exact-run attribution and ordering barriers matter when late metadata could otherwise be misattributed.
  - us: give ViewFS shell semantics explicit epochs/barriers instead of trusting every late event equally.


## Added in Revision 064
- **REF-FUCHSIA-LIFECYCLE** — Fuchsia component lifecycle — https://fuchsia.dev/fuchsia-src/concepts/components/v2/lifecycle
  - key: component instances may retain isolated persistent state while not running; stopping preserves persistent state, while destruction removes persistent state and new instances get distinct identity/state.
  - why: strong precedent that continuity across restart is not the same thing as carrying one current live authority surface forever.
  - us: keep remembered continuity and restarted-live authority separate.
- **REF-CONTOUR-OSC133** — Contour, *OSC 133 - Shell Integration* — https://contour-terminal.org/vt-extensions/osc-133-shell-integration/
  - key: the protocol cleanly marks prompt start/end, command output start, and command finished, and can optionally carry the command line.
  - why: strong precedent for explicit semantic transcript boundaries instead of heuristic prompt scraping.
  - us: give ViewFS shell/terminal protocol explicit semantic blocks and run-local attribution.


## Added in Revision 065
- **REF-WINDOWS-TERMINAL-SHELLINT** — Windows Terminal blog, *Shell integration in the Windows Terminal* — https://devblogs.microsoft.com/commandline/shell-integration-in-the-windows-terminal/
  - key: semantic prompt/command/output marks enable command jumps, command-output selection, and same-CWD spawning, but the feature works only when the shell emits explicit metadata.
  - why: strong product precedent that the terminal gets dramatically better when command blocks are semantically segmented instead of heuristically scraped.
  - us: keep ViewFS terminal semantics explicit, inspectable, and rich enough to render transfer/adoption truth per command block.
- **REF-MS-SECBOOKMARK-CVE2025** — Microsoft Security Blog, *Analyzing CVE-2025-31191: A macOS security-scoped bookmarks-based sandbox escape* — https://www.microsoft.com/en-us/security/blog/2025/05/01/analyzing-cve-2025-31191-a-macos-security-scoped-bookmarks-based-sandbox-escape/
  - key: persistent bookmark/reopen machinery became security-critical enough that replacing the signing secret let attackers forge trusted bookmark entries and regain file access without fresh user interaction until Apple fixed the bug in March 2025.
  - why: excellent caution that durable revival/designator stories need explicit validation, narrow scope, and inspectable storage semantics.
  - us: keep ViewFS revival designators provider-local, policy-killable, and visibly separate from live handles or local adopted binds.

## Added in Revision 066
- **REF-W3C-CAPURL** — W3C TAG Finding, *Good Practices for Capability URLs* — https://www.w3.org/2001/tag/doc/capability-urls/
  - key: capability URLs grant access to whoever has the URL, but URLs are prone to accidental disclosure and leakage
  - why: strongest simple warning that designation-looking strings can secretly be authority
  - us: keep note-friendly designators separate from authority-bearing tickets
- **REF-OCAPN-LOCATORS** — OCapN draft spec, *Locators / Sturdyref Locator* — https://github.com/ocapn/ocapn/blob/main/draft-specifications/Locators.md
  - key: a sturdyref locator encodes peer locator plus swiss number and should itself be considered a capability
  - why: sharp object-capability precedent for later-revival tickets that are not ordinary names
  - us: authority-bearing tickets should be visibly typed and never masquerade as inert bookmarks
- **REF-APPLE-APPSANDBOX-FILES** — Apple Developer docs, *Accessing files from the macOS App Sandbox* — https://developer.apple.com/documentation/security/accessing-files-from-the-macos-app-sandbox
  - key: security-scoped bookmarks are for persistent access after relaunch rather than ordinary same-run file access
  - why: strong desktop precedent that durable access artifacts are a special class
  - us: ViewFS durable reopen should remain explicit, inspectable, and non-default
- **REF-APPLE-SECBOOKMARK-ENABLE** — Apple Developer docs, *Enabling Security-Scoped Bookmark and URL Access* — https://developer.apple.com/documentation/professional-video-applications/enabling-security-scoped-bookmark-and-url-access
  - key: sandboxed apps must opt into security-scoped bookmark/URL access to retain file-system access across launches
  - why: good reminder that durable reopen is not just ordinary naming
  - us: treat authority-bearing tickets as a privileged seam, not a convenience string


## Added in Revision 067
- **REF-ZCAP-LD** — W3C CCG, *Authorization Capabilities for Linked Data v0.3* — https://w3c-ccg.github.io/zcap-spec/
  - key: delegated zcaps must expire, can carry explicit `allowedAction` constraints, and revocation is endpoint-shaped rather than invisible ambient magic.
  - why: strong precedent that declared delegation bounds and revocation lifecycle need first-class representation.
  - us: keep caveat sets, revocation/revalidation flows, and current live authority on distinct seams.
- **REF-SEL4-MANUAL-LATEST** — seL4 Reference Manual (latest) — https://sel4.systems/Info/Docs/seL4-manual-latest.pdf
  - key: capabilities can be copied or minted with specified rights/badges, and revoke is an explicit operation over derived children.
  - why: strong precedent that attenuation and revocation should be explicit acts rather than side effects of naming or history.
  - us: keep declared caveats, enforced attenuation, and receipts/history visibly separate.
- **REF-CAPSICUM-HANDBOOK** — FreeBSD Handbook, *Capsicum* — https://docs.freebsd.org/en/books/handbook/security/
  - key: Capsicum makes file descriptors into capabilities and capability mode removes ambient namespace dependence.
  - why: strong reminder that current possession of capability-bearing handles matters more than ambient filesystem folklore.
  - us: keep live handle truth distinct from descriptive caveat cards or durable history.

## Added in Revision 068
- **REF-W3C-PERMISSIONS** — W3C, *Permissions* — https://w3c.github.io/permissions/
  - key: permission state is explicit (`granted`, `prompt`, `denied`), and requesting permission returns `granted` or `denied` instead of pretending the caller already has the capability.
  - why: strong precedent that preflight permission outlook is a useful state class separate from current authority.
  - us: render permission lights as advisory/preflight, not as proof of live handles.
- **REF-WICG-FSACCESS** — WICG, *File System Access* — https://wicg.github.io/file-system-access/
  - key: file-system handles expose `queryPermission()` / `requestPermission()`, and operations distinguish `prompt` versus `denied` instead of burying repair in generic I/O errors.
  - why: strong precedent that file-like authority benefits from explicit permission-state and repair vocabulary.
  - us: keep permission outlook, live handle possession, and death-state verdicts on separate seams.
- **REF-XDG-SESSION** — XDG Session interface — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Session.html
- **REF-XDG-INHIBIT** — XDG Inhibit portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Inhibit.html
- **REF-XDG-GLOBALSHORTCUTS** — XDG Global Shortcuts portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.GlobalShortcuts.html

## Added in Revision 072
- **REF-MCP-COMPLETION-20250618** — MCP completion utility (2025-06-18) — https://modelcontextprotocol.io/specification/2025-06-18/server/utilities/completion
  - key: completion is for prompt/resource argument suggestions, uses reference types plus optional prior-argument context, returns bounded ranked values, and carries explicit security requirements.
  - why: strong precedent that suggestion mechanics are advisory and security-sensitive rather than selector/default truth.
  - us: keep completion candidates, focused detail, accepted insertions, and compiled packets on separate seams.
- **REF-LSP-COMPLETION-317** — Language Server Protocol 3.17 completion / resolve — https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/
  - key: completion list rows, lazy `completionItem/resolve`, and insertion-defining fields are separate; insertion semantics must not drift when detail is resolved.
  - why: strong precedent for keeping candidate detail-loading distinct from accepted insertion meaning.
  - us: ViewFS shell should keep ghost rows, detail drawers, accepted insertions, and packet compilation separate.
- **REF-FISH-COMPLETIONS** — fish docs, *Writing your own completions* — https://fishshell.com/docs/current/completions.html
  - key: completions are explicit candidate lists with argument-specific and condition-specific behavior.
  - why: good precedent that fast shell completion can still stay structured and explicit.
  - us: let ViewFS completion candidates carry kind/truth metadata without implying execution.
- **REF-FISH-INTERACTIVE** — fish docs, *Interactive use* — https://fishshell.com/docs/current/interactive.html
  - key: autosuggestions can be accepted whole or a word at a time, and they do not execute unless accepted.
  - why: strong product precedent for accept-word/accept-fragment ladders that still preserve user control.
  - us: ViewFS should make suggestion acceptance explicit and keep accepted insertion distinct from compiled action.
- **REF-VSCODE-TERMINAL-API-TRUST** — VS Code API, terminal shell execution trust — https://code.visualstudio.com/api/references/vscode-api
  - key: VS Code distinguishes command-line confidence/trust levels and uses nonce verification to treat explicitly reported command lines as safer for rerun.
  - why: strong precedent that heuristically observed command text and trusted command packets should not get the same replay affordances.
  - us: add packet-truth grades and rerun safety badges to the ViewFS terminal.

## Added in Revision 073
- **REF-PLAN9-PLUMBER4** — Plan 9 from User Space, *plumber(4)* — https://9fans.github.io/plan9port/man/man4/plumber.html
  - key: the plumber receives, examines, rewrites, and dispatches plumb messages between programs, with typed ports and held-for-delivery behavior.
  - why: strong precedent that a route/message envelope is its own object class rather than just a click on text.
  - us: keep selected text, route envelopes, prepared actions, and receipts on separate seams.
- **REF-OSC8-HYPERLINKS** — Egmont Koblinger, *Hyperlinks in Terminal Emulators* — https://gist.github.com/egmontkob/eb114294efbcd5adb1944c9f3cb5feda
  - key: OSC 8 hyperlinks behave like cell attributes, not DOM anchors; `file://` targets should include hostnames and mismatches should not blindly open locally.
  - why: strong precedent that link rendering and routed action semantics should stay separate.
  - us: ViewFS should treat explicit links as typed/display objects first, then route through inspected route slips.
- **REF-LSP-DOCLINK-317** — Language Server Protocol 3.17 document links / resolve — https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/
  - key: a document range can expose a link before its `target` is present, and lazy `documentLink/resolve` can fill the target later while preserving `data`.
  - why: excellent precedent for selection-range / candidate / lazy-resolve / prepared-route separations.
  - us: keep extracted entity candidates and resolved targets separate in the ViewFS shell.
- **REF-KITTY-HINTS** — kitty docs, *Hints kitten* — https://sw.kovidgoyal.net/kitty/kittens/hints/
  - key: kitty can select arbitrary visible text snippets and bind different actions or custom matching scripts to them.
  - why: strong product precedent that selection and action mapping can be fast and explicit without becoming ambient semantics.
  - us: explore entity peels, hint-picked route slips, and configurable match/action ladders in the custom shell.

## Added in Revision 074
- **REF-HTML-USER-ACTIVATION** — WHATWG HTML Standard, *APIs gated by user activation* — https://html.spec.whatwg.org/multipage/interaction.html
  - key: HTML distinguishes sticky activation, transient activation, activation-consuming calls, and history-action activation.
  - why: strong precedent that recent user action is a timed/consumable class, not ambient standing authority.
  - us: keep fresh gesture proof, consume-once batons, and durable authority on different seams.
- **REF-XDG-ACTIVATION-V1** — Wayland xdg-activation protocol — https://wayland.app/protocols/xdg-activation-v1
  - key: a client can mint an activation token and offer it to another client, but the compositor may still decline the requested activation.
  - why: strong precedent that transferable activation proof is not the same thing as current foreground control.
  - us: treat activation batons as narrow, expiring interaction artifacts rather than as durable grants.
- **REF-XDG-INPUTCAPTURE** — XDG Desktop Portal, *Input Capture* — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.InputCapture.html
  - key: input capture has distinct `enabled` and `active` states, and the compositor decides when active capture actually begins.
  - why: excellent precedent for keeping armed/enabled state visibly weaker than active now.
  - us: add arming rails and active-control truth badges to the future shell.
- **REF-MS-ALLOWSETFOREGROUND** — Microsoft Learn, *AllowSetForegroundWindow* — https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-allowsetforegroundwindow
  - key: a process that already may set the foreground window can pass that privilege to another process, and the ability can be lost on later user input.
  - why: strong precedent that foreground privilege can be narrow, transferable, and expiring rather than ambient.
  - us: treat focus/foreground transfer as a baton, not as durable power.
- **REF-MS-COALLOWSETFOREGROUND** — Microsoft Learn, *CoAllowSetForegroundWindow* — https://learn.microsoft.com/en-us/windows/win32/api/objbase/nf-objbase-coallowsetforegroundwindow
  - key: foreground privilege can be passed to an out-of-process COM object, but the call only confers the privilege and does not itself activate the target window.
  - why: strong precedent that delegated activation eligibility is not the same thing as current active control.
  - us: keep `may ask to activate` visibly separate from `active now` in ViewFS shell chrome.
- **REF-WAYLAND-XDGSHELL-USERACTION** — Wayland xdg-shell protocol, user-action serial requirements — https://wayland.app/protocols/xdg-shell
  - key: interactive move/resize/popup-grab requests must be made in response to user action and carry the serial of that user event; invalid or stale serials may be ignored.
  - why: strong precedent that user-action evidence is specific, fresh, and not a permanent right.
  - us: make gesture evidence explicit and expiring rather than hidden in shell folklore.

- **REF-FUCHSIA-IO-RIGHTS** — Fuchsia `fuchsia.io` reference — https://fuchsia.dev/reference/fidl/fuchsia.io
  - key: concrete filesystem operations require specific rights sets, and insufficient rights yield access denial.
  - why: strong precedent that one current handle-rights posture is its own truth surface.
  - us: keep current rights separate from identity, placement, and advertised verbs.
- **REF-RFC9110-ALLOW** — RFC 9110, HTTP `Allow` header — https://www.rfc-editor.org/rfc/rfc9110.html
  - key: a target resource can advertise the methods currently supported for it, and that set can change dynamically.
  - why: strong precedent that supported verbs deserve their own inspectable lane instead of path-based guessing.
  - us: drive shell action menus from explicit affordance truth rather than filename folklore.


## Added in Revision 076
- **REF-MIMESNIFF** — WHATWG MIME Sniffing Standard — https://mimesniff.spec.whatwg.org/
  - key: resources carry a supplied MIME type and a computed MIME type, and sniffing can be context-specific.
  - why: strong precedent that declared type and derived type are different metadata classes.
  - us: keep claimed type hints, local type derivation, opener choice, and live open state on separate seams.
- **REF-SHARED-MIME-INFO** — freedesktop.org Shared MIME-info Database spec — https://specifications.freedesktop.org/shared-mime-info/latest/
  - key: desktop MIME knowledge is built from contributed XML with globs, magic, aliases, and subclassing, then compiled by `update-mime-database`.
  - why: strong precedent that type classification is richer than extension folklore and should stay inspectable.
  - us: let ViewFS surface multiple type-evidence lanes instead of one suffix-driven truth.
- **REF-APPLE-UTTYPE** — Apple Developer Documentation, Uniform Type Identifiers — https://developer.apple.com/documentation/uniformtypeidentifiers
  - key: UTType provides common type identifiers for files and data, maps to MIME/file tags, and supports conformance to broader supertypes.
  - why: strong precedent that one type can participate in a richer taxonomy than `extension -> app`.
  - us: keep type taxonomy/classification separate from opener choice and live editor state.
- **REF-FDO-MIMEAPPS** — freedesktop.org, Association between MIME types and applications — https://specifications.freedesktop.org/mime-apps/latest-single/
  - key: `mimeapps.list` keeps added/default application associations separate from the MIME database, and default selection follows its own search/order rules.
  - why: strong precedent that handler association/defaults are their own lane rather than the type itself or one actual open act.
  - us: keep associated handlers, chosen opener, and live open state separate in ViewFS shell routing.


## Labels / annotations / trusted badge surfaces
- **REF-K8S-LABELS** — Kubernetes: Labels and Selectors — https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/
  - key: labels are compact metadata used for identifying/grouping objects via selectors; they do not provide uniqueness
  - why: strong primary-source precedent for selector-safe label lanes
  - us: keep query-safe/grouping labels separate from notes and separate from policy labels
- **REF-K8S-ANNOTATIONS** — Kubernetes: Annotations — https://kubernetes.io/docs/concepts/overview/working-with-objects/annotations/
  - key: annotations are arbitrary non-identifying metadata and are not used to identify or select objects
  - why: strong primary-source precedent for rich notes/metadata lanes that do not become selector truth
  - us: keep advisory annotations separate from saved-query / smart-basket selector semantics
- **REF-OCI-ANNOTATIONS** — OCI Annotations Spec — https://specs.opencontainers.org/image-spec/annotations/
  - key: OCI annotations are arbitrary metadata; unknown keys must not explode consumers
  - why: useful precedent for metadata-rich ecosystems that still refuse to turn every key into hard native semantics
  - us: imported metadata should remain advisory unless explicitly promoted into a stronger ViewFS lane
- **REF-SELINUX-CONTEXTS** — Red Hat SELinux Security Contexts — https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/5/html/deployment_guide/sec-selinux-security-contexts
  - key: SELinux stores security labels/contexts as extended attributes and uses them as policy-bearing labels
  - why: strong primary-source reminder that some labels really are policy lanes rather than decorative metadata
  - us: if ViewFS grows policy-bearing labels, keep them visibly stronger than ordinary chips/tags
- **REF-FIRST-TLP20** — FIRST Traffic Light Protocol 2.0 — https://www.first.org/tlp/
  - key: TLP labels indicate sharing boundaries but are not a full formal classification or control system
  - why: useful reminder that handling labels are helpful yet still narrower than universal authority/policy truth
  - us: keep handling labels explicit without overclaiming what they decide by themselves
- **REF-ITERM2-BADGES** — iTerm2 Badges — https://iterm2.com/documentation-badges.html
  - key: badge is a large dynamic session label set from variables/escape sequences
  - why: concrete terminal precedent for rich label chrome that is obviously presentation-owned
  - us: trusted badge shutters can live in shell chrome without becoming canonical object metadata
- **REF-ITERM2-STATUSBAR** — iTerm2 Status Bar — https://iterm2.com/documentation-status-bar.html
  - key: configurable/scriptable status components show up-to-date environment info and can expose useful interactions
  - why: concrete precedent for shell-owned chrome lanes carrying dynamic labels and controls
  - us: build badge/status lanes as explicit chrome, not transcript or object truth
- **REF-WEZTERM-RIGHT-STATUS** — WezTerm `set_right_status` — https://wezterm.org/config/lua/window/set_right_status.html
  - key: terminals can render dynamic right-status text derived from shell integration/current pane state
  - why: strong precedent for rich status labels that are still obviously presentation surfaces
  - us: support trusted right-status / HUD lanes while keeping provenance and freshness explicit

- **REF-RFC7232-CONDITIONAL** — RFC 7232, HTTP conditional requests — https://www.rfc-editor.org/rfc/rfc7232.html
  - key: `If-Match` uses strong comparison and is commonly used with state-changing methods to prevent lost updates; `If-None-Match: *` can prevent unintended creation/overwrite when a representation already exists.
  - why: strong stable precedent for exact guarded mutation based on observed validator state.
  - us: keep observed base, commit predicate, and winning durable version visibly separate from local draft state.
- **REF-GCS-PRECONDITIONS** — Google Cloud Storage request preconditions — https://docs.cloud.google.com/storage/docs/request-preconditions
  - key: requests proceed only if the targeted resource meets generation/metageneration criteria, supporting safe read-modify-write and conditional operations.
  - why: strong object-store precedent that safe writes do not require ambient overwrite semantics.
  - us: let ViewFS object mutations depend on explicit expected state without forcing one global lock story.
- **REF-MDN-CREATEWRITABLE** — FileSystemFileHandle `createWritable()` — https://developer.mozilla.org/en-US/docs/Web/API/FileSystemFileHandle/createWritable
  - key: writable sessions can be private staging streams with `keepExistingData`, and browsers may expose `exclusive` versus `siloed` writer modes.
  - why: strong precedent that one local writable session is its own class and is not automatically the final committed durable state.
  - us: keep draft sessions, coordination holds, and winning durable versions visibly distinct in shell and protocol design.

- **REF-RFC9110-RANGE** — RFC 9110, HTTP Semantics (Range / 206 Partial Content) — https://www.rfc-editor.org/rfc/rfc9110.html
  - key: 206 transfers one or more parts of the selected representation; clients may need to recombine only under strong-validator discipline.
  - why: strong stable precedent that partial transfers are not whole-object truth.
  - us: keep sparse coverage, recombination rules, and whole-object proof separate.
- **REF-RFC9111-INCOMPLETE** — RFC 9111, HTTP Caching (incomplete responses) — https://www.rfc-editor.org/rfc/rfc9111.html
  - key: caches may store incomplete responses, but they must not answer complete requests as if incomplete bytes were complete truth.
  - why: strong stable precedent for honest partial-state handling.
  - us: keep partial residency separate from full-local completeness.
- **REF-STARGZ-OVERVIEW** — Stargz Snapshotter overview — https://github.com/containerd/stargz-snapshotter/blob/main/docs/overview.md
  - key: eStargz images are lazily pullable while remaining standard-compatible with OCI/Docker registries.
  - why: strong precedent that lazy pull can coexist with standard object identity/format.
  - us: keep live remote fill separate from full local completeness.
- **REF-STARGZ-ESTARGZ** — eStargz overview — https://github.com/containerd/stargz-snapshotter/blob/main/docs/estargz.md
  - key: containers can start without waiting for entire layer contents to be local; needed files/chunks are fetched on demand.
  - why: concrete precedent for `runnable by lazy fill` versus `fully local`.
  - us: shell should surface sparse/lazy truth instead of flattening it into one download bit.
- **REF-AWS-S3-OBJECT-ETAG** — Amazon S3 Object API (`ETag`) — https://docs.aws.amazon.com/AmazonS3/latest/API/API_Object.html
  - key: S3 ETags may or may not be MD5 digests; multipart-upload objects do not use MD5 ETags.
  - why: strong warning that operational object identifiers/checksums can be weaker or differently scoped than one whole-object proof.
  - us: keep composite/per-part identifiers separate from whole-object witness truth.
- **REF-AWS-S3-MPU-OVERVIEW** — Amazon S3 multipart upload overview — https://docs.aws.amazon.com/AmazonS3/latest/userguide/mpuoverview.html
  - key: multipart completion concatenates parts; resulting ETag is not necessarily MD5; full-object checksum validation is a separate stronger lane.
  - why: strong object-store precedent that multipart assembly and full-object proof are different classes.
  - us: keep part-level/composite state separate from whole-object verification.
- **REF-AWS-S3-INTEGRITY** — Amazon S3 integrity/checksum guidance — https://docs.aws.amazon.com/AmazonS3/latest/userguide/checking-object-integrity.html
  - key: multipart uploads have composite and full-object checksum modes, and some full-object checksum work happens separately from upload part handling.
  - why: strong precedent that object integrity stories have multiple layers.
  - us: keep whole proof stronger than part-level/composite checksum lanes.
- **REF-ZARR-V3-CORE** — Zarr v3 core specification — https://zarr-specs.readthedocs.io/en/latest/v3/core/index.html
  - key: arrays are partitioned into chunks on a grid and codecs define encoded chunk representation in the store.
  - why: strong precedent that partition/layout metadata is useful without being the same thing as local coverage or whole-object proof.
  - us: keep chunk layout knowledge separate from current sparse/full residency truth.


- **REF-RFC9110-IFRANGE** — RFC 9110, HTTP Semantics (`If-Range`) — https://www.rfc-editor.org/rfc/rfc9110.html
  - key: `If-Range` says, effectively, send the requested range if the validator still matches; otherwise ignore `Range` and send the whole current representation.
  - why: strong stable precedent that exact basis mismatch should fall back honestly rather than pretending partial reconstruction is still safe.
  - us: keep basis truth and fallback full-fetch lanes explicit.
- **REF-RFC3229-DELTAHTTP** — RFC 3229, Delta encoding in HTTP — https://www.rfc-editor.org/rfc/rfc3229.html
  - key: HTTP can transfer deltas against base instances, uses `226 IM Used`, and can carry `Delta-Base` to identify the base instance separately from the current one.
  - why: strong stable precedent that delta recipes and current instances are different classes.
  - us: keep delta artifacts, exact bases, and reconstructed current objects separate.
- **REF-RFC3284-VCDIFF** — RFC 3284, VCDIFF Generic Differencing and Compression Data Format — https://www.rfc-editor.org/rfc/rfc3284.html
  - key: target windows are encoded against explicit source segments or earlier target data; reconstruction consumes those windows/instructions to rebuild the target.
  - why: strong stable precedent that one delta recipe is defined relative to explicit basis material and is not the target object itself.
  - us: keep recipe, basis, apply session, and reconstructed target distinct.
- **REF-OSTREE-STATIC-DELTAS** — OSTree static deltas — https://ostreedev.github.io/ostree/formats/
  - key: OSTree static deltas target exact commit pairs and also support `from NULL` reconstruction from scratch.
  - why: strong content-addressed-store precedent that `from base` and `from scratch` are different lanes.
  - us: keep exact-basis and full-fetch/reconstruct-from-scratch paths visible.
- **REF-ZSYNC-THEORY** — zsync theory / control-file docs — https://zsync.moria.org.uk/paper200501/ch02.html
  - key: zsync reuses local bytes through checksum/control-file matching so the client can reconstruct a current file with less transfer.
  - why: useful precedent that local byte reuse is still an explicit reconstruction act rather than magical object continuity.
  - us: keep basis reuse, reconstruction sessions, and resulting object truth separate.

- **REF-SANDSTORM-POWERBOX** — Sandstorm powerbox docs — https://docs.sandstorm.io/en/latest/developing/powerbox/
  - key: isolated grains exchange capabilities through explicit user-mediated powerbox flows rather than ambient reach.
  - why: strong precedent that mediation can explain and audit connection fit/locality instead of collapsing everything into a path open.
  - us: import sheets should explain candidate scope, resulting locality, and whether access stays mediated.
- **REF-PLAN9-IMPORT** — Plan 9 `import` manual — https://9fans.github.io/plan9port/man/man4/import.html
  - key: remote services and namespace fragments can be imported into a local namespace explicitly.
  - why: strong precedent that imported fragments are useful without pretending they are ambient machine-global path truth.
  - us: badge imported namespace fragments and keep publication/locality honest.
- **REF-FOUNDATION-CAS** — A content-addressed file store — https://swtch.com/~rsc/papers/fndn/
  - key: content-addressed archival storage can deduplicate and preserve byte content very effectively over time.
  - why: strong reminder that storage truth and byte identity are separable from current authority and publication truth.
  - us: let the object store be content-addressed without overpromising reopen/locality semantics.

## Added in Revision 086
- **REF-FUCHSIA-CONNECT** — Fuchsia connect components / outgoing directory — https://fuchsia.dev/fuchsia-src/development/components/connect
  - key: components consume a namespace while separately publishing capabilities through an outgoing directory and exposed directory.
  - why: publication/discoverability is a different class from a client already holding authority.
  - us: keep adverts/catalog presence separate from current handles or binds.
- **REF-MCP-ROOTS** — MCP roots spec — https://modelcontextprotocol.io/specification/2025-06-18/client/roots
  - key: roots define boundaries of where servers can operate and the list can change.
  - why: helper-visible roots are useful scope hints without becoming generic filesystem grant truth.
  - us: keep scope adverts/catalogs separate from grants and local binds.
- **REF-DNSSD** — RFC 6763 DNS-Based Service Discovery — https://www.rfc-editor.org/rfc/rfc6763.html
  - key: clients can browse named service instances and then resolve them separately.
  - why: discovery presence and later usable contact are distinct stages.
  - us: keep provider adverts separate from ready/held-now authority truth.
- **REF-K8S-ENDPOINTSLICE** — Kubernetes EndpointSlice conditions — https://kubernetes.io/docs/concepts/services-networking/endpoint-slices/
  - key: endpoint visibility is not one bit; conditions include `ready`, `serving`, and `terminating`.
  - why: freshness-scoped readiness is a different class from discoverability alone.
  - us: keep `advertised`, `ready now`, and `history only` visibly separate in shell chrome.

## Added in Revision 087
- **REF-GIT-PARTIAL-CLONE** — Git partial clone documentation — https://git-scm.com/docs/partial-clone/2.33.0
  - key: partial clone allows missing objects to be demand-fetched later from promisor remotes; Git also marks promisor packfiles specially so missing-by-design is not confused with corruption.
  - why: strong precedent that provider-ready and local-present are different truths.
  - us: keep promisor/provider-ready rows separate from local-realized rows.
- **REF-NIX-SSH-SUBSTITUTER** — Nix SSH substituter docs — https://nix.dev/manual/nix/2.26/package-management/ssh-substituter
  - key: if a needed path is not available locally, Nix can consult an SSH substituter, then other substituters, then fall back to building from source.
  - why: strong precedent that `can be supplied` is a separate lane from `already valid locally`.
  - us: shell should distinguish source/provider ladders from local-realization truth.
- **REF-FUCHSIA-AVAILABILITY** — Fuchsia capability availability — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/availability
  - key: a component can declare that it uses a capability, yet runtime availability still depends on the routing chain actually making it available.
  - why: strong precedent that declared/provider-expected availability is not identical to present runtime truth.
  - us: keep provider-ready or route-expected states distinct from held-now/local-now states.
- **REF-GHOSTTY-CURSORCLICK** — Ghostty cursor-click-to-move config reference — https://ghostty.org/docs/config/reference
  - key: cursor movement at prompts depends on explicit OSC 133 prompt marking rather than heuristic prompt guessing.
  - why: another good shell precedent for protocol-marked truth instead of inferred text-state.
  - us: ViewFS terminal locality/repair hints should ride explicit sideband marks.

## Added in Revision 088
- `REF-RFC6749-AUTHCODE` — RFC 6749 authorization code rules: short-lived, single-use, and bound to client identifier plus redirection URI.
- `REF-RFC9449-DPOP` — RFC 9449 sender-constraining precedent: bind issued OAuth tokens to possession of a key pair instead of pure bearer replay.
- `REF-ANDROID-PENDINGINTENT-SECURITY` — Android security guidance on replayable PendingIntent artifacts and one-shot mitigation.
- `REF-XDG-REQUEST` — XDG portal Request object lifetime / close / response semantics.
- `REF-XDG-SESSION` — XDG portal Session object lifetime / close semantics.


## Added in Revision 089
- **REF-RFC9470-STEPUP** — RFC 9470 OAuth 2.0 Step Up Authentication Challenge Protocol — https://www.rfc-editor.org/rfc/rfc9470.html
  - key: a protected resource can say the authentication event associated with the current token is not strong enough or not recent enough, and challenge with `acr_values` and `max_age`.
  - why: strong precedent that current possession of one token is not the same thing as current invocability for one action.
  - us: keep possession/local-realization, recency posture, step-up posture, and invokable-now truth visibly separate.
- **REF-OIDC-CORE-MAXAGE** — OpenID Connect Core 1.0 (`max_age`, `auth_time`, `acr`) — https://openid.net/specs/openid-connect-core-1_0.html
  - key: `max_age` forces explicit recency checking and `auth_time` records when active authentication occurred.
  - why: strong precedent that recent-enough authentication is a different class from generic signed-in posture.
  - us: let the shell speak in terms like `fresh enough` and `too old for this action` without inventing one universal login truth.
- **REF-WEBAUTHN-3** — Web Authentication Level 3 — https://www.w3.org/TR/webauthn-3/
  - key: authentication includes a test of user presence or user verification, and those outcomes are explicit instead of implied by mere credential existence.
  - why: strong precedent that scoped credential possession is different from current action-time proof.
  - us: keep local presence / verification posture separate from possession and from durable receipts.
- **REF-ANDROID-KEYSTORE-AUTH** — Android Keystore authentication-gated key use — https://developer.android.com/privacy-and-security/keystore
  - key: a non-exportable local key can exist while key use still requires current user authentication.
  - why: excellent local-device precedent that possession/locality is not the same thing as current invocability.
  - us: keep `held locally` separate from `usable for this action now` in ViewFS shell chrome.


## Status carriers / revocation / freshness watch
- **REF-RFC7662-INTROSPECT** — RFC 7662, *OAuth 2.0 Token Introspection* — https://datatracker.ietf.org/doc/html/rfc7662
  - key: a resource can ask for the current state of a token, including whether it is active and in what authorization context it was granted
  - why: strongest precedent for `held token` versus `current-state check` being different truths
  - us: keep watch/status carriers and post-watch invocability separate from possession
- **REF-RFC7009-REVOKE** — RFC 7009, *OAuth 2.0 Token Revocation* — https://datatracker.ietf.org/doc/html/rfc7009
  - key: revocation/update behavior depends heavily on whether tokens are self-contained, handled server-side, or short-lived
  - why: good warning that possession style determines how much later status can be known immediately
  - us: avoid one universal revocation folklore for ViewFS handles/grants
- **REF-RFC6960-OCSP** — RFC 6960, *Online Certificate Status Protocol (OCSP)* — https://datatracker.ietf.org/doc/html/rfc6960
  - key: current certificate status is queried separately and can be `good`, `revoked`, or `unknown`, with explicit freshness fields
  - why: excellent precedent for smaller status carriers and freshness-scoped standing-watch truth
  - us: separate base proof/object truth from later status/watch truth and local holds
- **REF-RFC5280-CRL** — RFC 5280, *Internet X.509 Public Key Infrastructure Certificate and CRL Profile* — https://datatracker.ietf.org/doc/html/rfc5280
  - key: CRL reason codes include `certificateHold` and `removeFromCRL`, making reversible hold explicit
  - why: strong precedent for reversible suspension instead of flattening everything into permanent invalidation
  - us: make hold rails and resumed-good transitions first-class shell truths
- **REF-VC-BITSTRING-STATUS** — W3C, *Bitstring Status List v1.0* — https://www.w3.org/TR/vc-bitstring-status-list/
  - key: compact status entries can carry distinct purposes like `refresh`, `revocation`, `suspension`, and `message`
  - why: great model for status carriers smaller than base credentials/objects
  - us: status lanes in ViewFS can stay smaller than object identity or durable receipts
- **REF-TUF-METADATA** — TUF docs, *Roles and metadata* — https://theupdateframework.io/docs/metadata/
  - key: signed metadata always includes expiry so clients can detect outdated metadata and refuse older state
  - why: freshness/watch truth often rides on separate metadata clocks
  - us: keep stale-watch posture and successor refresh separate from possession
- **REF-TUF-SPEC** — The Update Framework, *Specification* — https://theupdateframework.github.io/specification/latest/
  - key: compromised root keys can require normal rotation or out-of-band successor-root recovery depending on threshold compromise
  - why: excellent precedent for successor-required posture and nontrivial recovery after status changes
  - us: give the shell room for successor lanterns and refresh/adopt ladders without prematurely freezing the mechanism


## Added in Revision 093
- **REF-ANDROID-SHARE-FILE** — Android Developers, *Sharing a file* — https://developer.android.com/training/secure-file-sharing/share-file
  - key: apps share content URIs via Intents and grant temporary access by setting permission flags on the Intent.
  - why: strong precedent that the route/message envelope and the actual temporary authority grant are related but not the same thing.
  - us: keep route capsules separate from authority sidecars and sink-held grants.
- **REF-ANDROID-URIPERMISSION** — Android Developers, *UriPermission* — https://developer.android.com/reference/android/content/UriPermission
  - key: URI permission grants are their own objects created via Intent flags or explicit grant calls.
  - why: good precedent that current granted access should be inspectable as a class separate from the envelope that mentioned the URI.
  - us: ViewFS can render authority sidecars and sink-held grants as distinct shell objects.
- **REF-ANDROID-GRANTURIPERMISSION** — Android Developers, `<grant-uri-permission>` — https://developer.android.com/guide/topics/manifest/grant-uri-permission-element
  - key: providers may designate path subsets eligible for one-time grant-based access rather than exposing blanket access.
  - why: useful precedent that routeable subject designation and eventual granted scope are related but still distinct.
  - us: keep subject mention, sidecar scope, and sink-held consequence separate.

- **REF-CONFUSED-DEPUTY-HARDY** — Hardy, *The Confused Deputy (or why capabilities might have been invented)* — https://www.cis.upenn.edu/~sga001/classes/cis331f19/resources/hardy88confused.pdf
  - key: one tool carrying authority from multiple masters can be tricked into using the wrong authority because it cannot keep them apart
  - why: the cleanest historical warning for helper/plugin/automation design
  - us: keep brackets, borrowed handles, caller context, and deny-only provenance separate
- **REF-JEP506-SCOPEDVALUES** — OpenJDK JEP 506, *Scoped Values* — https://openjdk.org/jeps/506
  - key: scoped values are bounded, easier to reason about than thread-locals, and aimed at one-way caller-to-callee dataflow
  - why: strong precedent for explicit bounded dynamic scope instead of ambient mutable helper state
  - us: favor explicit privilege brackets and automatic unwind over long-lived hidden context
- **REF-JAVA-SCOPEDVALUE-API** — Java API docs, `ScopedValue` — https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/ScopedValue.html
  - key: bindings are bounded, revert automatically, support rebinding, and the key itself should be treated as a capability
  - why: excellent concrete API shape for bounded helper context that does not silently become a global mode
  - us: bracketed helper execution should be explicit, bounded, and inspectable
- **REF-PY-CONTEXTVARS** — Python `contextvars` docs — https://docs.python.org/3/library/contextvars.html
  - key: context-local state is meant to avoid state bleeding unexpectedly across concurrent code, and reset tokens restore prior state
  - why: strong precedent for bounded context instead of mutable ambient thread/task globals
  - us: any shell/runtime-local caller context should unwind cleanly and stay non-authoritative
- **REF-NODE-ASYNCLOCALSTORAGE** — Node.js async context tracking docs — https://nodejs.org/api/async_context.html
  - key: `run()` bounds async context, `exit()` leaves it, and Node warns `run()` should generally be preferred over `enterWith()`
  - why: useful precedent for explicit context brackets plus clear warnings about context bleed
  - us: helper execution should default to bounded brackets and visibly warn on ambient-ish fallback
- **REF-ASPNET-HTTPCONTEXTACCESSOR** — Microsoft Learn, `IHttpContextAccessor` — https://learn.microsoft.com/en-us/dotnet/api/microsoft.aspnetcore.http.ihttpcontextaccessor?view=aspnetcore-10.0
  - key: ambient async-local request context is useful but Microsoft explicitly warns it should be used with caution because it depends on ambient state and can hurt testing/perf
  - why: strong mainstream warning that convenient ambient context still corrodes clarity
  - us: keep caller context explanatory and bounded; do not let it become hidden authority

- **REF-ANDROID-VIRTUALFILES** — Android Developers, *Access documents and other files from shared storage* (virtual files section) — https://developer.android.com/training/data-storage/shared/documents-files
  - key: some SAF documents are virtual, cannot be directly opened as ordinary byte streams, and require alternate MIME coercion
  - why: perfect precedent for distinguishing same-object/native attach from translated representation availability
  - us: surface `coerced representation` and `virtuality` as honest shell truths instead of flattening them into `opened`
- **REF-WIT-RESOURCE-HANDLES** — Bytecode Alliance, *WIT Reference* / WebAssembly Component Model — https://component-model.bytecodealliance.org/design/wit.html
  - key: resources are handles to entities outside the component and are passed as owned or borrowed handles rather than copied plain data
  - why: excellent precedent for receiver-visible handle truth that stays distinct from copied representations
  - us: keep native handle fit, adapted usability, translated representation, and local realization on different seams



## Added in Revision 096
- **REF-GHOSTTY-SHELL-INTEGRATION** — Ghostty docs, *Shell Integration* — https://ghostty.org/docs/features/shell-integration
  - key: shell integration can be manually sourced in shell configuration so it keeps working in more scenarios such as when users switch shells.
  - why: strong precedent that terminal integration should stay inspectable and explicit instead of silently depending on one startup path.
  - us: ViewFS should treat terminal integration as an explicit, debuggable shell surface rather than as blanket startup permission.
- **REF-POWERSHELL-PROFILES** — Microsoft Learn, *about_Profiles* — https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_profiles?view=powershell-7.5
  - key: a PowerShell profile is a script that runs when PowerShell starts and can add commands, aliases, functions, variables, modules, and drives.
  - why: crisp warning that startup profiles are executable code, not harmless personalization mist.
  - us: keep host/user startup files visibly distinct from built-in shell baseline and reviewed customization bundles.


## Added in Revision 097
- **REF-VSCODE-PROFILES** — VS Code docs, *Profiles in Visual Studio Code* — https://code.visualstudio.com/docs/configure/profiles
  - key: profiles can include only a subset of configurations such as settings, keyboard shortcuts, MCP servers, snippets, tasks, and extensions.
  - why: strong precedent that shell/editor customization surfaces are healthier when sliced into explicit classes instead of one blob.
  - us: keep command-surface layers and interaction/profile layers explicit instead of flattening them into one shell-customization noun.
- **REF-FISH-ABBR** — fish-shell docs, *abbr - manage fish abbreviations* — https://fishshell.com/docs/current/cmds/abbr.html
  - key: abbreviations are user-defined words replaced with longer phrases when entered, and only typed-in commands use abbreviations; scripts do not.
  - why: crisp precedent that lexical expansion can stay useful without masquerading as script semantics or first-class command identity.
  - us: keep typed lexical expansion separate from built-in verbs, overlay commands, and external launches.
- **REF-NU-OVERLAYS** — Nushell book, *Overlays* — https://www.nushell.sh/book/overlays.html
  - key: overlays are layers of definitions (custom commands, aliases, environment variables) that can be activated and deactivated on demand.
  - why: excellent precedent for explicit command-layer activation instead of one hidden global command soup.
  - us: shell UI should expose overlay racks and activation/deactivation truth.
- **REF-NU-CUSTOMCOMMANDS** — Nushell book, *Custom Commands* — https://www.nushell.sh/book/custom_commands.html
  - key: custom commands act as first-class commands, appear in help, can participate in pipelines, and are parsed with real-time type checking.
  - why: strong precedent that user-defined command surfaces can be first-class without pretending to be mere aliases or external launches.
  - us: keep semantic command layers separate from lexical expansion and external execution.
- **REF-NU-WHICH** — Nushell commands, *which* — https://www.nushell.sh/commands/docs/which.html
  - key: `which` can report whether a name resolves to a program file, alias, or custom command.
  - why: direct precedent for command-resolution explainability.
  - us: build verb-provenance cards and which ladders into the ViewFS shell.
- **REF-ZSH-ZLE** — Zsh manual, *Zsh Line Editor* — https://zsh.sourceforge.io/Doc/Release/Zsh-Line-Editor.html
  - key: editor actions are widgets; widgets can be built-in or user-defined; user-defined widgets are implemented as shell functions and bound into keymaps.
  - why: strong reminder that keybound interaction actions are a distinct surface from typed command namespace.
  - us: keep key actions/widgets and key-table state visibly separate from typed verb resolution.
- **REF-GHOSTTY-KEYTABLES** — Ghostty release notes 1.3.0, *Key Tables, Chained Keybinds, and catch_all* — https://ghostty.org/docs/install/release-notes/1-3-0
  - key: Ghostty key tables are named sets of keybindings that can be activated or deactivated on demand, with visible UI indication when active.
  - why: excellent precedent for explicit modal interaction layers instead of hidden keymap drift.
  - us: add key-table lamps and mode visibility to the future ViewFS shell.
- **REF-GHOSTTY-CMDPALETTE** — Ghostty docs, *toggle_command_palette* — https://ghostty.org/docs/config/keybind/reference
  - key: the command palette is a popup listing actions, associated keybindings, search/filter, and action execution.
  - why: strong precedent that palette actions are their own interaction surface.
  - us: keep palette-only actions distinct from typed verbs and external launches.


## Added in Revision 098
- **REF-TREESITTER** — Tree-sitter docs, *Introduction* — https://tree-sitter.github.io/tree-sitter/
  - key: Tree-sitter is an incremental parsing library that can efficiently update syntax trees as source is edited and remain useful in the presence of syntax errors.
  - why: perfect precedent for keeping parser/highlight structure useful without pretending it is final command meaning.
  - us: add parse lenses and recovery veils to the ViewFS shell without freezing one parser stack.
- **REF-LSP-DIAGNOSTICS-317** — Language Server Protocol 3.17 spec, diagnostics (`textDocument/publishDiagnostics`) — https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/
  - key: diagnostics are delivered as their own structured information channel rather than collapsing into the source buffer or execution request.
  - why: strong precedent for keeping syntax/lint/hint output separate from buffer text and prepared actions.
  - us: keep diagnostic rails advisory and distinct from compiled packets or approval state.
- **REF-SHELLCHECK** — ShellCheck — https://www.shellcheck.net/
  - key: ShellCheck is a static analysis tool for shell scripts that finds bugs, warnings, and suggestions.
  - why: shell diagnostics can be highly valuable while still remaining explanatory and advisory.
  - us: diagnostic rails should explain shell problems without impersonating policy or execution truth.
- **REF-FISH-SYNTAX** — fish-shell docs, *Tutorial* / syntax highlighting — https://fishshell.com/docs/current/tutorial.html
  - key: fish provides syntax highlighting while typing, plus autosuggestions and completion, giving immediate feedback before execution.
  - why: excellent precedent that immediacy and honesty can coexist in shell UX.
  - us: ViewFS should make smart shell editing vivid without letting color or inline hints impersonate current authority.
