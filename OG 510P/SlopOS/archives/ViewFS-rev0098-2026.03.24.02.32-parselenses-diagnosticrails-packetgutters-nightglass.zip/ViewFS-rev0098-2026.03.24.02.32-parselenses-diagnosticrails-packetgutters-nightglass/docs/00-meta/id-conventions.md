# ID conventions

- **A-***: assumptions
- **C-***: claims
- **I-***: invariants
- **PO-***: proof obligations
- **RFC-XXXX**: proposals
- **ADR-XXXX**: decisions
- **REF-***: external references
- **EVID-YYYY-NNN**: internal evidence artifacts
