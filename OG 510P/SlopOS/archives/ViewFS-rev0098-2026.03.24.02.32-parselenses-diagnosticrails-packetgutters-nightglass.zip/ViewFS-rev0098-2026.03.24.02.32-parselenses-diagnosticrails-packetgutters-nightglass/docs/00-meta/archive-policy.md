# Archive policy (keep it small, keep it sharp)

## What belongs here
- Our specs, assumptions, claims, invariants, RFCs, ADRs, and evidence pointers.
- Small curated summaries of external work via REF entries.
- Research notes that narrow future decisions or expose costly traps.

## Cite > copy
- External sources must be registered as **REF-IDs**.
- Internal work products must be registered as **EVID-IDs**.
- Main docs should cite REF/EVID IDs instead of pasting large excerpts.

## When to create a new document
Only if:
1. it introduces a stable new axis,
2. it will be referenced by at least one architecture doc or RFC, and
3. it is smaller than the confusion created by burying the topic elsewhere.

## Compression rule
If a doc grows beyond ~6–8 screens:
- keep stable statements in-place,
- move exploration into an RFC or research note,
- keep pointers instead of narrative history.

## Review gates
No change to authority, persistence, or compatibility semantics without updating:
- assumptions,
- claims and invariants,
- non-claims,
- changelog.
