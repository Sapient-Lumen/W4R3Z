# Roadmap

## Phase A0 — archive seed
- repo hygiene
- charter / claims / non-claims
- bibliography and research map
- first RFC

## Phase A1 — minimal substrate design
- immutable blob + manifest object model
- directory/object handle vocabulary
- per-process view root posture
- portal import/export posture

## Phase A1.5 — alignment and decision freezing
- map ViewFS onto existing SlopOS seams instead of inventing parallel concepts
- record explicit deferred decisions
- identify a short list of spikes that answer real risk instead of speculative architecture curiosity

## Phase A2 — bounded compatibility
- synthetic path membrane
- cwd / root semantics
- failure-on-escape rules
- transcript-visible import/export receipts
- host-bridge bring-up discipline and ambient-debt visibility

## Phase A3 — shell and terminal differentiation
- structured pipelines over handles/receipts
- clickable blocks and receipts
- capability-aware completion and previews
- explicit view/domain switching UX
- workspace/tree bind and rebind UX distinct from recent-item reopen and URI launch
- plumb-style routing and transferable receipts
- typed route sheets and explain-access inspection
- prepare-versus-commit action planning with exact approval diffs and result cards
- suggestion-tray and promote-to-user-workflow UX distinct from prepare/run/history
- basis-diff and reconsent-ladder UX distinct from current authority and old receipts
- witness-drawer, caveat-chip, and why-panel UX distinct from live authority and durable history
- policy-lens, advice-rail, and diagnostic-card UX distinct from authoritative policy and durable audit history
- cut-picker, fallback-rail, and repair-prompt UX distinct from exact policy-family selection and durable selection history
- proposer-badge, scope-chip, escalation-ladder, and adoption-gate UX distinct from authoritative adoption and durable history
- ceiling-pill, narrowing-preview, scope-fuse, and adopt-narrowest-safe-rung UX distinct from authoritative ceilings and durable history
- resource-shelf, prompt-chip, tool-rack, app-dock, and completion-popover UX distinct from request binding and live invocation history
- task-badge, progress-lane, input-required drawer, queue rail, and result-locker UX distinct from immediate requests and durable history
- stop-ladder, detach-rail, termination-fuse, retry-vs-fork drawer, and result-retention locker UX distinct from immediate stop acts and durable history
- follow-tail, attach-rail, control-pane, debug-launch drawer, and sideband-badge UX distinct from transcript history and object authority

## Phase A4 — deferred hard decisions
- revocation semantics
- mutable directory transactions
- query/index model
- replication / sync model
- symlink/hardlink policy
- grouped capability bundle semantics
- whether immutable identity, naming, mutable heads, and durable grants ever need tighter coupling
- whether intent/plan/approval/result families need a shared schema or stay family-specific
- whether suggestion/promotion/workflow families need a shared schema or stay family-specific
- whether reuse/basis/drift/reconsent/renewal families need a shared schema or stay family-specific
- whether witness/caveat/freshness/why-record families need a shared schema or stay family-specific
- whether validation/policy/advice/diagnostic/log families need a shared schema or stay family-specific
- whether policy-family/catalog, exact cut, fallback, repair, and selection-receipt families need a shared schema or stay family-specific
- whether proposer/source, proposal-lane/scope, escalation, adoption, and adoption-receipt families need a shared schema or stay family-specific
- whether deny-ceiling, scope-eligibility, narrowing-transform, escalation-attempt, and adoption-receipt families need a shared schema or stay family-specific
- whether resource/prompt/tool/app/completion, request-binding, invocation/result, and durable-receipt families need a shared schema or stay family-specific
- whether close/cancel, terminate, detach/delete, retry-fresh, reset/fork/attach, and durable-receipt families need a shared schema or stay family-specific
- whether observe/query/follow, interactive attach, control-message, exec/debug, sideband, and durable-transcript families need a shared schema or stay family-specific
- keep session-state memory, journals, notebooks, and replay aids clearly separate from live authority while the shell UX grows richer
- keep indexes, recents, and selector registries clearly advisory instead of letting search surfaces become authority by accident
- prototype a protected-authorability matrix and one-shot invoke lane before deciding whether any lower-trust source classes may ever author always-on state
- prototype a helper lifecycle rack that keeps install/config state, enablement, start approval, live session, and request-scoped selection visibly distinct before deciding whether any helpers may auto-start or persist live authority across sessions
- prototype a helper-feature catalog flow that keeps resources, prompts, tools, interactive apps, completions, request bindings, and live invocation receipts visibly distinct before deciding whether any of those classes should share schemas or replay shortcuts
- prototype a live-session lane flow that keeps follow/query, attach, control, debug-exec, sideband access, and transcript history visibly distinct before deciding whether any of those classes should share schemas or shortcuts
