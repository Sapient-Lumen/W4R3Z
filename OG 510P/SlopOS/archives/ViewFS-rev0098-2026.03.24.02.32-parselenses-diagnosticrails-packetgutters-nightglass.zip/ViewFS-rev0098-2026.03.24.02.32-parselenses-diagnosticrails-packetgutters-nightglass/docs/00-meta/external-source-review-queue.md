# External source review queue

Purpose: keep mutable docs re-review visible.

## Snapshot
- moving-head refs tracked: **131**
- exact byte locks: **0**
- earliest review date: **2026-04-15**

| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-15` | `REF-FLATPAK-BASICS` | portal posture | re-check portal narrative before making UX guarantees |
| `2026-04-15` | `REF-XDG-FILECHOOSER` | chooser/import | re-check persistence / access wording before protocol pinning |
| `2026-04-15` | `REF-XDG-DOCUMENTS` | document export/import | re-check restricted-view behavior before stronger analogy |
| `2026-04-15` | `REF-XDG-FILETRANSFER` | transfer mediation | re-check transfer-session semantics before adopting clipboard/dragdrop receipts |
| `2026-04-15` | `REF-WARP-BLOCKS` | terminal UX | re-check block model before UI-specific commitments |
| `2026-04-15` | `REF-WARP-NOTEBOOKS` | runnable docs | re-check notebook feature boundaries before promising playbook objects |
| `2026-04-15` | `REF-WARP-WORKFLOWS` | saved commands | re-check workflow/search model |
| `2026-04-15` | `REF-WARP-CMDPALETTE` | searchable palette | re-check search/filter affordances |
| `2026-04-15` | `REF-WEZTERM-SHELL-INT` | shell/terminal protocol | re-check OSC/semantic-zone wording before freezing protocol ideas |
| `2026-04-15` | `REF-GNOME-TRACKER` | search/indexing | re-check background-index and scope wording before adopting any stronger search analogy |
| `2026-04-15` | `REF-GNOME-LOCALSEARCH` | metadata extraction | re-check sandboxed-extractor and index-policy wording before freezing derived-metadata ideas |
| `2026-04-15` | `REF-GTK-RECENT` | recents / selector UX | re-check recent-manager wording before treating recent-item stores as a stable analogy |
| `2026-04-15` | `REF-WEZTERM-ZONES` | shell/terminal protocol | re-check semantic-zone API details before assuming terminal affordances map 1:1 to ViewFS receipts |
| `2026-04-20` | `REF-WASI-CAPS` | capability model | re-check runtime-handle guidance |
| `2026-04-20` | `REF-WASMTIME-PREOPEN` | compat membrane | re-check preopen API assumptions |
| `2026-04-20` | `REF-CAPSICUM-RIGHTS` | rights attenuation | re-check rights taxonomy before narrowing ViewFS handle rights |
| `2026-04-20` | `REF-CAPSTD` | ambient-authority marker UX | re-check API/story before making developer-tool commitments |
| `2026-04-20` | `REF-ANDROID-SAF` | durable grants | re-check stable ID / persistence wording |
| `2026-04-20` | `REF-APPLE-SSB-CVE2025` | cautionary security note | re-check reference details if it becomes load-bearing beyond “durable grants can go wrong” |
| `2026-05-01` | `REF-FUCHSIA-NAMESPACE` | per-view root | re-check namespace wording and non-global root claims |
| `2026-05-01` | `REF-FUCHSIA-DIR-CAPS` | routed directories | re-check rights and route wording |
| `2026-05-01` | `REF-FUCHSIA-RIGHTS` | handle attenuation | re-check rights reduction semantics |
| `2026-05-01` | `REF-FUCHSIA-DICTCAP` | grouped caps | re-check dictionary capability semantics |
| `2026-05-15` | `REF-NIX-CA` | object addressing | re-check manual section |
| `2026-05-15` | `REF-IPFS-CIDS` | content identity | re-check docs wording |
| `2026-05-15` | `REF-IPFS-MFS` | mutable facade | re-check root-pointer and mutable facade claims |
| `2026-05-15` | `REF-TAHOE-MUTABLE` | stable mutable slots | re-check contrast-case wording |
| `2026-05-15` | `REF-SQLITE-SESSION` | changeset model | re-check session/changeset semantics |
| `2026-05-15` | `REF-NUSHELL` | shell UX | re-check structured pipeline docs |
| `2026-05-15` | `REF-FISH` | shell UX | re-check interaction claims |
| `2026-05-15` | `REF-WEZTERM-HYPERLINKS` | terminal UX | re-check hyperlink support language |
| `2026-05-15` | `REF-WEZTERM-DOMAINS` | terminal UX | re-check domain terminology |
| `2026-06-01` | `REF-PERKEEP-PERMANODE` | mutable anchor model | re-check permanode/claim semantics before relying on the analogy |
| `2026-04-15` | `REF-XDG-DOCS-FUSE` | synthetic grant views | re-check scoped virtual-filesystem wording before making stronger implementation analogies |
| `2026-05-01` | `REF-FUCHSIA-DICT-RFC` | grouped authority | re-check dictionary capability semantics before any bundle proposal grows storage or routing teeth |
| `2026-05-15` | `REF-LANDLOCK` | defense in depth | re-check sandbox/backstop claims before binding Linux-specific bring-up tactics |
| `2026-04-15` | `REF-XDG-OPENURI` | typed URI routing | re-check portal launch semantics before promising route-sheet behavior |
| `2026-05-01` | `REF-FUCHSIA-SECURE` | no-ambient-authority language | re-check conceptual framing before quoting it as a foundational slogan |
| `2026-05-01` | `REF-FUCHSIA-SANDBOXING` | launch-kit / namespace assembly | re-check creator-populated namespace wording before stronger launch-kit commitments |
| `2026-05-01` | `REF-FUCHSIA-IDLE-STOP` | narrow continuity / escrow | re-check handle-escrow wording before stronger continuity or resume commitments |
| `2026-05-15` | `REF-PLAN9-ACME` | text UI object surfaces | re-check the analogy before binding any editor/shell control model too tightly to acme |
| `2026-04-20` | `REF-ITERM-SHELLINT` | shell/terminal protocol | re-check mark/history/recent-directory details before stronger UX commitments |
| `2026-04-20` | `REF-ITERM-OSC8` | object links | re-check hyperlink semantics before freezing link metadata ideas |
| `2026-04-20` | `REF-GHOSTTY-SHELLINT` | shell integration UX | re-check shell integration feature assumptions |
| `2026-04-20` | `REF-GHOSTTY-OSC133-OVERLAY` | protocol debugging UX | re-check overlay/debug inspector analogy before promising tooling |
| `2026-05-15` | `REF-NIX-STORE` | immutable closure framing | re-check manual wording before stronger object-store analogies |
| `2026-04-15` | `REF-XDG-REQUEST` | portal interaction receipts | re-check request/response wording before freezing receipt-card analogies |
| `2026-04-15` | `REF-WEZTERM-USERVARS` | pane metadata | re-check user-var behavior before depending on it for pane badges or replay-state UI |
| `2026-04-20` | `REF-ITERM-HISTDISK` | saved shell memory | re-check persistence wording before stronger restore/history commitments |
| `2026-04-15` | `REF-XDG-BACKENDS` | preview/extractor backend split | re-check backend/frontend accessibility wording before stronger provider-isolation claims |
| `2026-04-20` | `REF-WIN-PREVIEW-HANDLERS` | preview UX / safety | re-check lightweight read-only and low-integrity-host wording before stronger preview-host assumptions |
| `2026-04-20` | `REF-WIN-PREVIEW-GUIDE` | inert preview rules | re-check script/macro-blocking and non-locking wording before turning it into a hard ViewFS checklist |
| `2026-04-20` | `REF-APPLE-QUICKLOOK-WWDC24` | preview-session UX | re-check lifecycle/safe-access language before stronger session-model commitments |
| `2026-04-20` | `REF-VSCODE-WORKSPACE-TRUST` | workspace trust | re-check restricted-mode and disabled-feature wording before stronger automation-gating commitments |
| `2026-04-20` | `REF-VSCODE-110-TERMSECTIONS` | terminal command sections | re-check collapsible-terminal-section wording before stronger shell chrome commitments |
| `2026-04-20` | `REF-VSCODE-TASKS` | shell/workflow split | re-check user-task versus workspace-task wording before freezing workflow ownership language |
| `2026-04-20` | `REF-VSCODE-JUPYTER-TRUST` | notebook trust | re-check untrusted-notebook behavior before stronger notebook-gating commitments |
| `2026-04-20` | `REF-JETBRAINS-PROJSEC` | project trust | re-check trusted-location and opening-warning wording before stronger workspace-onboarding analogies |
| `2026-04-20` | `REF-DIRENV-ALLOW` | env hook gating | re-check allow/deny wording before formalizing env-hook trust flows |
| `2026-04-20` | `REF-DIRENV-REQUIREALLOWED` | trust invalidation | re-check watched-file reauthorization semantics before adopting automation-diff invalidation language |
| `2026-04-20` | `REF-WAYLAND-DATADEVICES` | transfer mediation | re-check data-offer / MIME-negotiation wording before stronger clipboard or drag-drop commitments |
| `2026-04-20` | `REF-INOTIFY` | watch feeds | re-check overflow/recovery wording before freezing watch-health language |
| `2026-04-20` | `REF-FANOTIFY` | watch feeds | re-check handle/no-fd wording before drawing stronger authority contrasts |
| `2026-04-20` | `REF-APPLE-FSEVENTS` | watch feeds | re-check rescan/root-change wording before stronger rebuild commitments |
| `2026-04-20` | `REF-WIN-READDIRCHANGES` | watch feeds | re-check directory-scope wording before stronger UI analogies |
| `2026-04-20` | `REF-WIN-USN` | rebuild/recovery | re-check journal/reindex wording before stronger log-design analogies |
| `2026-04-20` | `REF-WATCHMAN-TROUBLE` | watch UX / degraded states | re-check recrawl/limit-warning wording before harder UX commitments |
| `2026-04-20` | `REF-WATCHMAN-INSTALL` | provider coverage | re-check remote/distributed watch caveat wording before policy commitments |

| `2026-04-20` | `REF-LINUX-PATHLOOKUP` | compat walker policy | re-check no-symlink/no-magic-link wording before freezing a path policy |
| `2026-04-20` | `REF-CAPPRIMS-FS` | compat membrane / helper APIs | re-check rooted/nofollow helper behavior before copying host helper semantics |
| `2026-04-20` | `REF-WIN-SHELLLINK` | shortcut / route objects | re-check resolution and launch-metadata wording before making shortcut analogies load-bearing |
| `2026-04-20` | `REF-WIN-HARDLINKS` | aliasing classes | re-check hard-link/junction distinctions before any cross-platform “link” claims |
| `2026-04-20` | `REF-WIN-REPARSE` | storage indirection limits | re-check reparse-point limit/behavior wording before deeper implementation analogies |
| `2026-04-20` | `REF-APPLE-BOOKMARKS` | durable reopen refs | re-check bookmark-vs-path guidance before stronger reopen claims |
| `2026-04-20` | `REF-APPLE-SECBOOKMARK` | security-scoped reopen | re-check bookmark-data flow wording before protocol analogies |
| `2026-04-20` | `REF-APPLE-SECWITHSCOPE` | scope typing | re-check read-only/read-write wording before grant-class analogies |
| `2026-04-20` | `REF-APPLE-SECSTART` | live-access step | re-check start-accessing wording before stronger “ref vs handle” claims |
| `2026-04-20` | `REF-APPLE-SECRESOLVE` | stale bookmark resolution | re-check stale-flag wording before stronger rebasing / reconsent analogies |
| `2026-04-20` | `REF-ITERM-SEMHIST` | heuristic link UX | re-check cwd-tracked semantic-history wording before shell click-policy commitments |

| `2026-04-20` | `REF-APPLE-QUARANTINEKEY` | origin / quarantine metadata | re-check quarantine-property wording before freezing object-state vocabulary |
| `2026-04-20` | `REF-APPLE-GATEKEEPER` | guarded-open UX | re-check Apple guarded-open wording before stronger launch analogies |
| `2026-04-20` | `REF-APPLE-SAFEOPEN` | user-facing trust copy | re-check support-language framing before stronger shell UX commitments |
| `2026-04-20` | `REF-APPLE-GATEKEEPER-BYPASS` | cautionary security note | re-check bug-history details if it becomes more than a cautionary signal |
| `2026-04-20` | `REF-MS-ATTACHMENTMGR` | origin / zone metadata | re-check zone-of-origin wording before freezing origin metadata language |
| `2026-04-20` | `REF-MS-MOTW-OFFICE` | guarded documents | re-check MOTW / trusted-document wording before stronger doc/code split claims |
| `2026-04-20` | `REF-MS-APPGUARD` | isolated open | re-check isolated-open wording before stronger safe-open commitments |
| `2026-04-20` | `REF-MS-SMARTSCREEN` | reputation / warnings | re-check reputation-signal framing before stronger shell badge commitments |
| `2026-04-20` | `REF-EDGE-DL-DANGER` | dangerous download ladder | re-check dangerous-file-type wording before freezing action-ladder vocabulary |

| `2026-04-20` | `REF-FDO-TRASH` | trash / recoverable delete | re-check trashinfo/original-path/deletion-date wording before freezing any restore-plan vocabulary |
| `2026-04-20` | `REF-APPLE-TRASHITEM` | recoverable delete | re-check resulting-URL / rename-on-trash wording before stronger collision-handling claims |
| `2026-04-20` | `REF-MS-RECYCLEONDELETE` | recycle-vs-permanent-delete split | re-check explicit-flag wording before freezing shell verb ladders |
| `2026-05-15` | `REF-NIX-GCROOTS` | retention roots | re-check root/live-set wording before stronger retention-inspector commitments |
| `2026-05-15` | `REF-NIX-GC` | purge / GC | re-check print-roots/print-live wording before stronger purge-preview analogies |
| `2026-04-20` | `REF-VSCODE-LOCALHISTORY` | recovery timelines | re-check deleted-file restore wording before stronger shell timeline commitments |
| `2026-04-20` | `REF-GIT-REFLOG` | head/name recovery | re-check reflog/time-specifier wording before deeper history-model analogies |

| `2026-05-15` | `REF-APPLE-APFS-FEATURES` | checkpoint/clone UX | archive doc; re-check against current Apple guidance before freezing any platform-specific clone claims |
| `2026-05-15` | `REF-ZFS-SNAPSHOT` | checkpoint semantics | re-check atomic snapshot wording before deeper object-model analogies |
| `2026-05-15` | `REF-ZFS-CLONES` | writable forks/worktrees | re-check clone/promotion wording before stronger fork semantics |
| `2026-05-15` | `REF-ZFS-BOOKMARK` | replication lineage | re-check bookmark/send wording before deeper lineage-receipt analogies |
| `2026-05-15` | `REF-BTRFS-SUBVOLUMES` | workspace forks | re-check snapshot/subvolume wording before stronger fork claims |
| `2026-05-15` | `REF-BTRFS-SEND` | backup/export streams | re-check full/incremental stream wording before export-protocol analogies |
| `2026-04-20` | `REF-GIT-WORKTREE` | parallel workspaces | re-check worktree metadata wording before stronger shell UX commitments |
| `2026-04-20` | `REF-MS-VSS` | checkpoint vs backup | re-check provider/transport wording before stronger backup/restore analogies |
| `2026-05-15` | `REF-OSTREE-OVERVIEW` | publication/deployment split | re-check tree/ref/deployment wording before promotion-lane commitments |
| `2026-05-15` | `REF-OSTREE-MANUAL` | lifecycle verbs | re-check pin/deploy/switch/cleanup command split before UX commitments |
| `2026-04-20` | `REF-RESTIC-FORGET` | retention / reclaim | re-check forget/prune wording before tighter retention-policy analogies |
| `2026-05-15` | `REF-FREEBSD-BECTL` | activation / rollback | re-check boot-environment clone/activation wording before stronger rollback analogies |

| `2026-06-01` | `REF-RFC9110-PRECONDITIONS` | optimistic preconditions | standards text is stable, but re-check section anchors before using exact precedence language in a hard decision |
| `2026-04-20` | `REF-S3-CONDITIONAL-WRITES` | object-store writes | re-check API/error wording before stronger guarded-write commitments |
| `2026-04-20` | `REF-S3-CONDITIONAL-DELETES` | guarded deletes | re-check concurrent-delete caveats before deeper delete-model analogies |
| `2026-04-20` | `REF-GIT-FORCE-WITH-LEASE` | takeover UX | re-check documentation wording before stronger shell-verb commitments |
| `2026-04-20` | `REF-GIT-UPDATE-REF` | compare-and-swap refs | re-check oldvalue semantics before deeper mutable-head analogies |
| `2026-06-01` | `REF-WEBDAV-LOCKING` | lease/lock caution | standards text is stable, but re-check timeout/token sections before stronger lease claims |
| `2026-04-20` | `REF-ETCD-TXN` | conditional transactions | re-check transaction wording before multi-key mutation analogies |
| `2026-04-20` | `REF-ETCD-LEASE` | reservations / TTL | re-check expiry wording before stronger reservation-lifecycle commitments |
| `2026-04-20` | `REF-ETCD-LOCK` | auto-release leases | re-check lock/lease wording before stronger UI commitments |
| `2026-04-20` | `REF-K8S-SSA` | field ownership / conflicts | re-check conflict/force wording before deeper subtree-claim analogies |
| `2026-04-20` | `REF-AZURE-BLOB-CONCURRENCY` | guarded object writes | re-check ETag/412 wording before stronger blob-store claims |
| `2026-05-15` | `REF-SQLITE-ISOLATION` | mutation semantics caution | re-check isolation wording before using as a stronger design constraint |
| `2026-05-15` | `REF-SQLITE-LOCKINGV3` | lock complexity caution | re-check writer-starvation/locking wording before deeper low-level analogies |
| `2026-04-20` | `REF-APPLE-NSMETADATAQUERY` | query snapshots vs live feeds | re-check gathering/live-update wording before freezing any feed-control vocabulary |
| `2026-05-15` | `REF-APPLE-SPOTLIGHT-QUERYGUIDE` | batch/update guidance | archived source; re-check before deeper batching/notification commitments |
| `2026-04-20` | `REF-APPLE-SMARTFOLDERS` | saved-query UX | re-check saved-criteria wording before stronger shell-surface claims |
| `2026-04-20` | `REF-WIN-SEARCH-MS` | saved query manifests | re-check XML/query-file wording before stronger serialization commitments |

| `2026-05-15` | `REF-APPLE-DOCPICKER-OPS` | import/export/open/move lane split | archived source; re-check current Apple guidance before freezing any UI naming |
| `2026-05-15` | `REF-APPLE-DOCPICKER-ACCESS` | security-scoped in-place access | archived source; re-check access-discipline wording before stronger reopen claims |
| `2026-04-20` | `REF-ANDROID-CREATE-DOCUMENT` | create-only export/save-as | re-check overwrite/collision wording before stronger destination-grant commitments |
| `2026-04-20` | `REF-WIN-SHELL-CLIPFORMATS` | move/copy outcome reporting | re-check performed/preferred drop-effect wording before freezing outcome-card vocabulary |
| `2026-04-20` | `REF-WIN-SHELL-DATASCENARIOS` | delete-on-paste / optimized move | re-check async extraction / outcome steps before stronger transfer-lane claims |
| `2026-04-20` | `REF-APPLE-FILEPROMISES` | promised outputs | re-check wording before freezing promise/materialize terminology |
| `2026-04-20` | `REF-IPFS-PERSISTENCE` | retention vs GC | re-check pinning wording before stronger retention-root analogies |
| `2026-05-15` | `REF-NIX-REALISE` | hydration / realization | re-check closure-realization wording before stronger hydrate-closure commitments |
| `2026-05-15` | `REF-NIX-COPY` | mirror / transport | re-check closure-copy wording before stronger mirror/export analogies |
| `2026-05-15` | `REF-NIX-PREFETCH-FILE` | prefetch / warm-up | re-check output/hash wording before freezing warm-up receipt language |
| `2026-05-15` | `REF-OSTREE-REPO-MGMT` | mirrors / partial mirrors | re-check mirror wording before stronger replica-topology commitments |
| `2026-05-15` | `REF-OSTREE-STATIC-DELTAS` | offline bundles | re-check self-contained delta wording before stronger bundle-lane commitments |
| `2026-05-15` | `REF-OSTREE-FORMATS` | delta optimization | re-check bsdiff/static-delta wording before deeper transport-format analogies |
| `2026-06-01` | `REF-SVCWORKER-SPEC` | cache/update/lifetime states | standards text is stable, but re-check specific cache-mode wording before harder protocol analogies |
| `2026-04-20` | `REF-MDNPREFETCH` | prefetch hint semantics | re-check browser/cache-partitioning caveats before stronger cross-origin claims |
| `2026-04-20` | `REF-MS-ALWAYSOFFLINE` | offline cache UX | re-check offline-cache wording before stronger sync/readiness commitments |
| `2026-04-15` | `REF-XDG-PORTAL-DESIGN` | portal request/candidate separation | re-check request-object and file-argument wording before stronger import-surface commitments |
| `2026-04-20` | `REF-CAPSICUM-ADOPTION` | adoption/tooling lesson | re-check tracing / learning-curve wording before stronger repo-process commitments |

| `2026-04-20` | `REF-DENO-PERMISSIONS` | prepare/approve posture | re-check permission-prompt and same-privilege wording before stronger runtime analogies |
| `2026-04-20` | `REF-ANDROID-DOCPROVIDER` | provider-supported ops | re-check `COLUMN_FLAGS` / method mapping before freezing action-menu vocabulary |
| `2026-04-20` | `REF-MS-FUTUREACCESSLIST` | durable reopen list hygiene | re-check limit/pruning wording before stronger persistence-maintenance claims |

| `2026-04-20` | `REF-MACAROONS-NDSS14` | attenuation caveats | re-check paper landing page and framing before stronger caveat-schema commitments |
| `2026-04-20` | `REF-ZANZIBAR` | freshness / consistency witnesses | re-check consistency-token framing before stronger replay-freshness commitments |

## Added in Revision 029
- Re-check REF-CEDAR-AUTHZ and REF-CEDAR-VALIDATION before freezing any policy-family schema or diagnostics shape.
- Re-check REF-OPA-DECISIONLOGS before freezing any exportable decision-log or audit-trace format.
- Re-check REF-POLKIT-AUTHORITY before adopting any retained-authorization UX beyond explicit receipts and policy-visible expiry.

## Added in Revision 030
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-OPA-DISCOVERY` | policy-family selection / precedence | re-check bootstrap-overrides-discovered wording before freezing any automatic selection precedence language |
| `2026-04-20` | `REF-SPICEDB-CONSISTENCY` | policy cut / freshness | re-check exact-snapshot / at-least-as-fresh wording before freezing any cut-badge or replay-cut commitments |

## Added in Revision 031
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-GIT-CONFIG-ORIGIN-SCOPE` | proposer provenance / scope | re-check `--show-origin` and `--show-scope` wording before freezing provenance-chip vocabulary |
| `2026-04-20` | `REF-VSCODE-CHAT-CUSTOM-DIAG` | multiple proposal sources | re-check loaded-origin diagnostics wording before stronger proposal-origin commitments |
| `2026-04-20` | `REF-VSCODE-MCP-SERVERS` | workspace/profile config and trust | re-check enablement/trust/config split before stronger adoption-gate claims |
| `2026-04-20` | `REF-VSCODE-AGENT-PERMISSIONS` | adoption scopes | re-check session/workspace/all-future wording before freezing escalation-ladder vocabulary |
| `2026-04-20` | `REF-VSCODE-AUTOPILOT-PERMISSIONS` | session autonomy | re-check current-session picker wording before stronger session-scope claims |


## Added in Revision 032
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-CEDAR-SECURITY` | deny ceilings | re-check forbid-overrides-permit wording before freezing deny-ceiling vocabulary |
| `2026-04-20` | `REF-VSCODE-CONTRIB-SCOPES` | scope eligibility | re-check scope names and applicability wording before stronger scope-lattice claims |
| `2026-04-20` | `REF-VSCODE-WORKSPACE-TRUST-EXT` | restricted configurations | re-check `restrictedConfigurations` wording before stronger non-widenable-source claims |
| `2026-04-20` | `REF-VSCODE-AGENT-TOOLS` | session/workspace/future approval ladders | re-check approval-level wording before freezing adopt-narrowest ladder vocabulary |
| `2026-04-20` | `REF-VSCODE-CHAT-OVERVIEW` | session autonomy | re-check permissions-picker wording before stronger session-lane commitments |
| `2026-04-20` | `REF-VSCODE-112` | terminal/session ergonomics | re-check steering/queueing and relative-link wording before stronger session-state routing claims |


## Added in Revision 033
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-VSCODE-AI-POLICIES` | owner/org AI ceilings | re-check managed-policy and auto-approval wording before freezing source-precedence claims |
| `2026-04-20` | `REF-VSCODE-ENTERPRISE-POLICIES` | managed override precedence | re-check override wording before stronger owner/device ceiling commitments |
| `2026-04-20` | `REF-VSCODE-MCP-CONFIG` | config origin versus trust reset | re-check user/workspace/reset-trust wording before freezing import-tray or trust-shutter vocabulary |
## Added in Revision 034
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-VSCODE-AGENT-PLUGINS` | trusted carriers | re-check plugin-versus-workspace trust wording before freezing carrier-versus-author semantics |
| `2026-04-20` | `REF-VSCODE-CUSTOMIZE-AI` | parent-repo discovery | re-check upward-discovery wording before stronger parent-repo carrier claims |
| `2026-04-20` | `REF-VSCODE-COPILOT-SECURITY` | trust boundaries | re-check workspace/publisher/tool-approval wording before stronger author/gate taxonomy claims |

| `2026-04-20` | `REF-GIT-PROTECTED-CONFIG` | protected authorability | re-check protected-scope wording before freezing any stronger matrix or scope names |
| `2026-04-20` | `REF-GIT-SAFE-DIRECTORY` | protected-only state classes | re-check repo-safety wording before making protected-only claims load-bearing |
| `2026-04-20` | `REF-VSCODE-CUSTOM-INSTRUCTIONS` | auto-applied helper material | re-check automatic-influence wording before stronger always-on analogy |
| `2026-04-20` | `REF-VSCODE-PROMPT-FILES` | invoke-only helper lanes | re-check manual invocation / tool-priority wording before freezing invoke-latch UX |
| `2026-04-20` | `REF-VSCODE-CUSTOM-AGENTS` | source inspection / role bundles | re-check source-location and tool-restriction wording before stronger source-matrix commitments |
| `2026-04-20` | `REF-DENO-PERM-BROKER` | central decision lanes | re-check broker precedence wording before stronger “local prompts explanatory only” claims |

## Added in Revision 036
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-VSCODE-PUBLISHER-TRUST` | publisher trust | re-check publisher-trust / revoke wording before freezing publisher-badge semantics |
| `2026-04-20` | `REF-VSCODE-MCP-SERVERS-LIVE` | helper lifecycle | re-check install / start-confirm / enable-state wording before freezing helper lifecycle vocabulary |
| `2026-04-20` | `REF-VSCODE-PLUGIN-LIFECYCLE` | plugin versus workspace lifecycle | re-check plugin-start / disable-stops-server wording before stronger live-session claims |
| `2026-04-20` | `REF-VSCODE-112-LIFECYCLE` | enablement scopes | re-check global-versus-workspace enablement wording before freezing scope names for helper toggles |
| `2026-04-20` | `REF-VSCODE-COPILOT-BOUNDARIES` | trust-boundary layering | re-check MCP/publisher/workspace boundary wording before stronger start-gate or session-isolation claims |
| `2026-04-20` | `REF-DENO-PERM-BROKER-LIVE` | live broker lanes | re-check broker-authority wording before stronger live-session semantics |

| `2026-04-20` | `REF-MCP-SPEC-FEATURES` | helper feature taxonomy | re-check resources/prompts/tools wording before stronger catalog-taxonomy claims |
| `2026-04-20` | `REF-MCP-RESOURCES` | resource shelf | re-check URI/context wording before freezing resource-shelf language |
| `2026-04-20` | `REF-MCP-PROMPTS` | prompt chips | re-check prompt discovery/customization wording before freezing prompt-chip vocabulary |
| `2026-04-20` | `REF-MCP-TOOLS` | tool racks | re-check tool-schema wording before stronger invocation-taxonomy claims |
| `2026-04-20` | `REF-MCP-COMPLETION` | completion popovers | re-check security/disclosure wording before stronger completion-lane claims |

## Added in Revision 038
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-MCP-TASKS` | accepted-task versus final-result split | re-check task states / `tasks/result` wording before freezing task-badge vocabulary |
| `2026-04-20` | `REF-MCP-PROGRESS` | progress lanes | re-check progress-token wording before stronger live-progress commitments |
| `2026-04-15` | `REF-XDG-REQUEST` | request handles | re-check request-handle / response-signal wording before stronger task-request analogies |
| `2026-04-15` | `REF-XDG-BACKGROUND` | background permission / status | re-check background/status wording before stronger status-line commitments |
| `2026-05-15` | `REF-GCLOUD-LRO` | result lockers / wait semantics | re-check polling / wait-operation wording before freezing result-locker semantics |
| `2026-04-20` | `REF-VSCODE-TASKS-BG` | background task completion | re-check “done” / problem-matcher wording before stronger queue/completion claims |
| `2026-04-20` | `REF-VSCODE-109-BGAGENTS` | follow-up while running | re-check queueing/background-session wording before freezing queue-rail vocabulary |

## Added in Revision 039
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-05-15` | `REF-AIP151-LRO` | result-retention expiry | re-check expiry and parallel-operation wording before freezing locker-expiry or history-only semantics |
| `2026-04-20` | `REF-TEMPORAL-INTERRUPT` | stop ladders | re-check cancel-versus-terminate wording before freezing termination-fuse vocabulary |
| `2026-04-20` | `REF-TEMPORAL-WFID` | retry / fork / attach-existing | re-check reuse/conflict/reset wording before stronger retry-vs-fork claims |
| `2026-04-20` | `REF-VSCODE-CHAT-SESSIONS` | fork-from-checkpoint UX | re-check fork/session-independence wording before freezing rerun-fork drawer language |


## Added in Revision 040
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-KUBECTL-ATTACH` | interactive attach lanes | re-check attach/stdin wording before freezing attach-rail vocabulary |
| `2026-04-20` | `REF-KUBECTL-LOGS` | follow tails | re-check follow/tail wording before stronger observe-only claims |
| `2026-04-20` | `REF-KUBECTL-PORTFWD` | sideband tunnels | re-check tunnel-lifetime wording before freezing sideband-badge semantics |
| `2026-04-20` | `REF-TMUX` | read-only clients and control mode | re-check read-only/control-mode wording before stronger observer-versus-controller claims |
| `2026-04-20` | `REF-TEMPORAL-MESSAGES` | query/signal/update split | re-check query/signal/update wording before stronger control-pane claims |
| `2026-04-15` | `REF-XDG-INPUTCAPTURE` | armed versus active state | re-check enabled/active wording before stronger armed-versus-active badge claims |


## Added in Revision 042
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-05-15` | `REF-CAPROS-USERDRIVERS` | durable-authority/device seam | re-check device-state persistence wording before stronger persistent-authority claims |
| `2026-05-15` | `REF-TREESLS-SOSP23` | checkpoint/capability-tree inspiration | re-check whole-system persistence wording before deeper checkpoint commitments |

## Added in Revision 044
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-SYSTEMD-FDSTORE` | restart continuity / exact-handle lockers | re-check restart-versus-stop-preserve wording before stronger continuity-locker commitments |


## Added in Revision 045
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-MEMFD-CREATE` | transient staging capsules | re-check anonymous-file/staging wording before stronger capsule commitments |
| `2026-04-20` | `REF-MEMFD-SEALS` | freeze-for-review semantics | re-check sealing wording before stronger compare-before-commit commitments |
| `2026-04-20` | `REF-UNIX-SCMRIGHTS` | explicit local handle courier | re-check fd-passing wording before stronger courier-lane commitments |



## Added in Revision 046
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-SEL4-BADGES` | issuer-visible badge copies | re-check badge-on-cap-copy wording before stronger handle-lineage commitments |
| `2026-04-20` | `REF-SYSTEMD-SOCKETACT` | startup-delivered handle kits | re-check activation/listen-fd wording before freezing launch-slot vocabulary |
| `2026-04-20` | `REF-VSCODE-SHELLINT` | truth-grade command chrome | re-check quality/nonce/command-decoration wording before stronger block-trust-ladder commitments |

## Added in Revision 047
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-SOCKET-PASSCRED` | courier peer witness | re-check SO_PASSCRED / SO_PEERCRED wording before stronger courier-provenance commitments |
| `2026-04-20` | `REF-VSCODE-106-ATTCMD` | structured command packets | re-check attached-command-field wording before stronger command-packet commitments |


## Added in Revision 048
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-LINUX-PIDFD` | running-command handles | re-check wait/poll/signal/setns wording before stronger process-card commitments |
| `2026-04-20` | `REF-LINUX-PIDFD-GETFD` | deep inspection / fd-dup powers | re-check duplicate-fd wording before stronger inspect-right separation claims |
| `2026-05-15` | `REF-FREEBSD-PROCDESC` | cross-platform process descriptors | re-check procdesc/capsicum wording before stronger exact-process-handle claims |


## Added in Revision 050
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-LINUX-OPEN-TREE` | detached view fragments | re-check detached-mount wording before stronger prepared-fragment commitments |
| `2026-04-20` | `REF-LINUX-MOVE-MOUNT` | attach receipts / bind acts | re-check attach wording before freezing bind-receipt vocabulary |
| `2026-04-20` | `REF-LINUX-MOUNT-SETATTR` | pre-attach posture | re-check detached-only posture wording before stronger pre-attach-transform claims |
| `2026-04-20` | `REF-XTERM-BRACKETED-PASTE` | paste capsules / input origin | re-check paste-origin wording before stronger inspect-before-run claims |
| `2026-04-20` | `REF-KITTY-KEYBOARD` | key packets / prompt-local gestures | re-check press-repeat-release and disambiguation wording before stronger key-lane commitments |

## Added in Revision 051
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-MAN7-FEXECVE` | exact exec objects | re-check file-descriptor execution wording before stronger exec-object badge commitments |
| `2026-04-20` | `REF-MAN7-EXECVEAT` | fd-based launch adapters | re-check `AT_EMPTY_PATH` and adapter wording before stronger launch-by-handle claims |
| `2026-04-20` | `REF-SYSTEMD-CREDENTIALS` | startup credential slots | re-check activation-time/immutability wording before stronger credential-drawer commitments |


## Added in Revision 052
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-LINUX-LDSO` | startup code closure / loader debt | re-check LD_LIBRARY_PATH/current-directory wording before stronger closure-certainty commitments |
| `2026-04-20` | `REF-LINUX-DLOPEN` | late dynamic imports | re-check RPATH/RUNPATH and dependency-loading wording before stronger late-import lane commitments |
| `2026-04-20` | `REF-WIN-DLL-SEARCH` | loader search posture | re-check safe-DLL-search and LOAD_LIBRARY_SEARCH wording before stronger loader-debt claims |
| `2026-04-20` | `REF-WIN-LOADLIBRARY` | late plugin/import lane | re-check full-path/SearchPath caution wording before stronger import-route-sheet commitments |


## Added in Revision 053
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-WAYLAND-PRIMARY-SELECTION` | clipboard/selection offers | re-check offer-validity and receive-fd wording before stronger clipboard-offer-card commitments |
| `2026-05-15` | `REF-X11-ICCCM-SELECTIONS` | historical selection ownership | re-check selection-owner/requestor wording before stronger no-hidden-history claims |
| `2026-04-20` | `REF-KITTY-CLIPBOARD` | typed clipboard reads | re-check MIME-list / permission-prompt wording before stronger clipboard-inspector commitments |


## Added in Revision 054
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-LINUX-CREDENTIALS-JC` | job-control layering / foreground ownership | re-check foreground-job and controlling-terminal wording before stronger foreground-baton commitments |
| `2026-04-20` | `REF-LINUX-SETPGID` | foreground-turn / interrupt target | re-check `tcgetpgrp`/`tcsetpgrp` wording before stronger interrupt-preview commitments |
| `2026-04-20` | `REF-LINUX-SETSID` | detach / hangup posture | re-check hangup/session-leader wording before stronger detach-receipt commitments |
| `2026-04-20` | `REF-GLIBC-LOGINTTY` | controlling-terminal adoption | re-check `login_tty()` wording before stronger TTY-lease badge commitments |
| `2026-04-20` | `REF-LINUX-TTY4` | controlling-terminal detach | re-check `/dev/tty` and `TIOCNOTTY` wording before stronger controlling-TTY posture claims |

## Added in Revision 055
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-FUCHSIA-RUNNER` | runner/runtime lane | re-check environment-registered runner wording before stronger runner-badge commitments |
| `2026-04-20` | `REF-FUCHSIA-CAPS` | environment-vs-instance capabilities | re-check environment-routed capability wording before stronger launch-hosting claims |
| `2026-04-20` | `REF-OCI-RUNTIME-CONFIG` | structured launch/runtime config | re-check root/process/hook separation wording before stronger bootstrap-shutter commitments |
| `2026-04-20` | `REF-OCI-PROCESS-CONFIGGO` | process-bundle fields | re-check terminal/args/env/cwd/scheduler wording before stronger runner-card field commitments |
| `2026-04-20` | `REF-ITERM-CMDSELECT` | command blocks vs mutable prompt | re-check info/share/bookmark wording before stronger history-card commitments |
| `2026-04-20` | `REF-ITERM-CLEARBUFFER` | mutable prompt dock | re-check clear-buffer vs clear-scrollback wording before stronger prompt-dock commitments |

## Added in Revision 056
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-MAN7-OPEN` | shared-open-state layering | re-check open-file-description wording before stronger shared-cursor group commitments |
| `2026-04-20` | `REF-MAN7-DUP` | duplicate-versus-reopen UX | re-check shared-offset / descriptor-flag wording before stronger twin-handle badge commitments |
| `2026-04-20` | `REF-LINUX-FLOCK` | shared lock/lease truth | re-check lock-attached-to-open-state wording before stronger shared-lock drawer commitments |

## Added in Revision 057
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-LINUX-OPATH` | locator-vs-byte-I/O truth | re-check O_PATH allowed-operations wording before stronger inspect-first handle commitments |
| `2026-04-20` | `REF-LINUX-STATX` | metadata-on-current-handle | re-check AT_EMPTY_PATH wording before stronger metadata-only card commitments |
| `2026-04-20` | `REF-LINUX-OPENTREE` | rooted designation / detached fragment | re-check O_PATH-style descriptor wording before stronger root-badge commitments |

## Added in Revision 058
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-MAN7-EXEC3P` | launch-boundary inheritance truth | re-check exec descriptor-survival wording before stronger inheritance-shutter commitments |
| `2026-04-20` | `REF-MAN7-POSIX-SPAWN` | child-slot maps | re-check `file_actions` / inherited-descriptor wording before stronger child-slot UX commitments |
| `2026-04-20` | `REF-MAN7-CLOSE-RANGE` | bulk launch shutters | re-check `CLOSE_RANGE_CLOEXEC` wording before stronger leak-siren / shutter claims |
| `2026-04-20` | `REF-MAN7-FCNTL` | close-on-fork precedent | re-check POSIX.1-2024 `FD_CLOFORK` wording before stronger fork-boundary claims |
| `2026-04-20` | `REF-OPENBSD-FCNTL` | concrete close-on-fork support | re-check OpenBSD `F_GETFD/F_SETFD` wording before stronger fork-shutter analogies |

## Added in Revision 059
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-FUCHSIA-FSARCH` | multi-path namespace mutation | re-check parent-open / vnode-token wording before stronger two-anchor card commitments |
| `2026-04-20` | `REF-FREEBSD-RIGHTS-LIVE` | source-vs-destination parent rights | re-check `CAP_RENAMEAT` / `CAP_LINKAT` / `CAP_UNLINKAT` wording before stronger anchor-badge commitments |
| `2026-04-20` | `REF-MAN7-RENAME` | collision-mode ladders | re-check `RENAME_NOREPLACE` / `RENAME_EXCHANGE` wording before stronger overwrite/exchange UX commitments |


## Added in Revision 060
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-MAN7-MOUNTNS` | bind propagation / peer groups | re-check shared/private/slave/unbindable and peer-group wording before stronger blast-radius badge commitments |


## Added in Revision 061
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-LINUX-OTMPFILE` | unnamed-object / publish-later seam | re-check `O_TMPFILE` wording and supported-filesystem caveats before stronger draft-object commitments |
| `2026-04-20` | `REF-MAN7-LINKAT` | namespace publication | re-check `AT_EMPTY_PATH` / publication wording before stronger publish-sheet commitments |

## Added in Revision 062
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-OCI-DESCRIPTOR` | content descriptor envelope | re-check digest/size/media-type wording before freezing any descriptor schema commitments |


## Added in Revision 063
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-FUCHSIA-HANDLES` | handle-rights / duplicate-drop-rights | re-check duplicate/replace wording before stronger local-docref-vs-live-handle commitments |
| `2026-04-20` | `REF-KITTY-SHELLINT` | shell bootstrap posture | re-check auto-integration/bootstrap wording before stronger inspectable-shutter commitments |
| `2026-04-20` | `REF-SD-NOTIFY-BARRIER` | semantic epoch / barrier truth | re-check barrier ordering wording before stronger exact-run semantic attribution commitments |

| `2026-05-01` | `REF-FUCHSIA-LIFECYCLE` | restart continuity | re-check persistent-state versus restart wording before stronger continuity commitments |
| `2026-04-20` | `REF-CONTOUR-OSC133` | shell/terminal protocol | re-check prompt/output boundary wording before freezing protocol event names |

| `2026-04-20` | `REF-WINDOWS-TERMINAL-SHELLINT` | semantic command marks | re-check mark/selection wording before stronger protocol naming commitments |
| `2026-04-20` | `REF-MS-SECBOOKMARK-CVE2025` | durable designator caution | re-check post-fix guidance before stronger bookmark/designator claims |

## Added in Revision 066
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-06-01` | `REF-W3C-CAPURL` | designation-vs-authority caution | re-check wording on leak scenarios before stronger claims about user-copyable tickets |
| `2026-04-20` | `REF-OCAPN-LOCATORS` | sturdyref / authority-bearing locator | re-check locator structure and wording before stronger ticket-format commitments |
| `2026-04-20` | `REF-APPLE-APPSANDBOX-FILES` | durable reopen posture | re-check Apple bookmark guidance before stronger durable-reopen UX commitments |
| `2026-04-20` | `REF-APPLE-SECBOOKMARK-ENABLE` | persistent bookmark opt-in | re-check entitlement/opt-in wording before stronger macOS analogy claims |


## Added in Revision 067
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-ZCAP-LD` | declared-caveat / revocation lifecycle | re-check expiry / allowedAction / revocation wording before stronger ticket-or-lease commitments |
| `2026-05-15` | `REF-SEL4-MANUAL-LATEST` | explicit attenuation / revoke acts | re-check mint/revoke wording before stronger membrane-vs-handle claims |
| `2026-04-20` | `REF-CAPSICUM-HANDBOOK` | current-handle truth | re-check handbook wording before stronger fd-as-capability analogies in shell chrome |

## Added in Revision 068
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-W3C-PERMISSIONS` | permission-state vocabulary | re-check `granted/prompt/denied` wording before stronger cross-family permission-light commitments |
| `2026-04-20` | `REF-WICG-FSACCESS` | file-like permission query/request | re-check `queryPermission()` / `requestPermission()` semantics before stronger repair-ladder commitments |

| `2026-06-01` | `REF-RATS-RFC9334` | conceptual message split | re-check endorsement/evidence/result wording before stronger local-admission analogies |
| `2026-04-20` | `REF-RATS-ENDORSEMENTS-DRAFT` | verifier-local endorsement inputs | re-check draft wording and status before stronger endorsement-stack commitments |
| `2026-04-20` | `REF-IN-TOTO-ATTESTATION` | attestation layering | re-check statement/predicate/envelope wording before freezing claim-envelope vocabulary |
| `2026-04-20` | `REF-SLSA-PROVENANCE` | production provenance | re-check provenance wording before stronger import/build analogies |
| `2026-04-20` | `REF-SLSA-VERIFY-V1` | verification requirement | re-check v1.0 notes before stronger `claim present` versus `verified here` shell copy |
| `2026-04-20` | `REF-TUF-ROLES` | roles / delegations | re-check role/delegation wording before stronger endorsement-stack UI commitments |
| `2026-04-20` | `REF-SIGSTORE-REKOR` | transparency log | re-check transparency-log wording before stronger audit-witness commitments |

## Added in Revision 070
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-15` | `REF-XDG-SESSION` | long-lived portal session handles | re-check session-close / closed-signal wording before stronger session-card commitments |
| `2026-04-15` | `REF-XDG-INHIBIT` | request-vs-session-vs-current-state split | re-check monitor/session-state wording before stronger portal-state lens commitments |
| `2026-04-15` | `REF-XDG-GLOBALSHORTCUTS` | request-handle / session-handle / active-state split | re-check bind/list/activated wording before stronger request-ledger and session-card commitments |

## Added in Revision 071
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-05-15` | `REF-HAIKU-FSMODULES` | live virtual queries | re-check live-query wording before stronger freeze-to-basket commitments |
| `2026-04-20` | `REF-GNOME-SERVICES` | portal-gated indexed discovery | re-check Flatpak/portal wording before stronger index-debt badge commitments |

| `2026-04-20` | `REF-MCP-COMPLETION-20250618` | completion candidate vs packet seam | re-check reference/context/security wording before freezing packet-gutter vocabulary |
| `2026-04-20` | `REF-LSP-COMPLETION-317` | lazy detail vs insertion semantics | re-check resolve/insertion invariants before stronger shell protocol claims |
| `2026-04-20` | `REF-FISH-COMPLETIONS` | candidate-ladder UX | re-check candidate/condition wording before stronger completion-shape claims |
| `2026-04-20` | `REF-FISH-INTERACTIVE` | accept-word ladders | re-check autosuggestion acceptance wording before stronger shell-accept-mode claims |
| `2026-04-20` | `REF-VSCODE-TERMINAL-API-TRUST` | trusted rerun posture | re-check confidence/isTrusted wording before freezing packet-truth and replay policies |

## Added in Revision 073
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-05-15` | `REF-PLAN9-PLUMBER4` | typed route envelopes | re-check held-for-delivery and port wording before stronger route-slip claims |
| `2026-04-20` | `REF-OSC8-HYPERLINKS` | explicit hyperlinks / host mismatch | re-check file-hostname and link-attribute wording before stronger hypertruth claims |
| `2026-04-20` | `REF-LSP-DOCLINK-317` | lazy target resolution | re-check `target` missing / resolve semantics before freezing candidate-vs-resolved language |
| `2026-04-20` | `REF-KITTY-HINTS` | visible-text matching / action ladders | re-check customizable hints wording before stronger entity-peel UX claims |

## Added in Revision 074
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-HTML-USER-ACTIVATION` | gesture proof / consume-once posture | re-check sticky/transient/consuming wording before freezing baton vocabulary |
| `2026-04-20` | `REF-XDG-ACTIVATION-V1` | activation baton / foreground request | re-check token-offer / compositor-refusal wording before stronger activation-rail claims |
| `2026-04-20` | `REF-XDG-INPUTCAPTURE` | enabled-versus-active state | re-check trigger / enabled / active wording before freezing arming-rail semantics |
| `2026-04-20` | `REF-MS-ALLOWSETFOREGROUND` | foreground transfer | re-check expiry-on-input wording before stronger baton-expiry claims |
| `2026-04-20` | `REF-MS-COALLOWSETFOREGROUND` | delegated activation eligibility | re-check “confers privilege, does not activate” wording before stronger foreground-card claims |
| `2026-04-20` | `REF-WAYLAND-XDGSHELL-USERACTION` | user-action serials | re-check valid-serial / ignore wording before stronger gesture-witness claims |


## Added in Revision 075
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-FUCHSIA-IO-RIGHTS` | handle-rights posture | re-check rights-set wording before freezing normalized right-summary badges |
| `2026-05-15` | `REF-RFC9110-ALLOW` | advertised-verb surfaces | re-check dynamic-allow wording before freezing provider-affordance menu semantics |

| `2026-04-20` | `REF-MIMESNIFF` | declared-vs-derived type evidence | re-check supplied/computed/context-specific wording before stronger type-classification claims |
| `2026-04-20` | `REF-SHARED-MIME-INFO` | desktop type database | re-check glob/magic/alias/subclass wording before stronger handler or taxonomy claims |
| `2026-04-20` | `REF-APPLE-UTTYPE` | type conformance taxonomy | re-check conformance/tag mapping wording before stronger cross-platform type analogies |
| `2026-04-20` | `REF-FDO-MIMEAPPS` | handler association/default choice | re-check default-versus-added-association wording before stronger opener-selection claims |


## Added in Revision 077
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-K8S-LABELS` | selector-safe labels | re-check selector/grouping wording before freezing query-safe label vocabulary |
| `2026-04-20` | `REF-K8S-ANNOTATIONS` | advisory annotation lane | re-check non-identifying/arbitrary metadata wording before stronger annotation promotion claims |
| `2026-04-20` | `REF-OCI-ANNOTATIONS` | imported arbitrary metadata | re-check unknown-key / arbitrary-metadata wording before stronger interop claims |
| `2026-05-15` | `REF-SELINUX-CONTEXTS` | policy-bearing labels | re-check security-context wording before freezing policy-label terminology |
| `2026-05-15` | `REF-FIRST-TLP20` | handling labels | re-check “not a formal classification scheme” wording before stronger handling-label analogies |
| `2026-04-20` | `REF-ITERM2-BADGES` | trusted badge chrome | re-check variable/badge wording before stronger badge-shutter UI claims |
| `2026-04-20` | `REF-ITERM2-STATUSBAR` | shell-owned status lanes | re-check interaction/component wording before stronger shell chrome claims |
| `2026-04-20` | `REF-WEZTERM-RIGHT-STATUS` | right-status chrome | re-check right-status/current-pane wording before freezing HUD-label ideas |


## Added in Revision 078
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-K8S-API-CONCEPTS-WATCH` | watch bookmark / reset posture | re-check bookmark/sendInitialEvents/410 wording before stronger waterline or reset-taxonomy claims |
| `2026-04-20` | `REF-DROPBOX-DETECT-CHANGES` | cursor/longpoll split | re-check cursor-expiry and longpoll wording before stronger resync-ladder claims |
| `2026-04-20` | `REF-WATCHMAN-CLOCKSPEC` | logical clock versus wall time | re-check named-cursor/clock-id wording before freezing watermark-copy semantics |
| `2026-05-15` | `REF-APPLE-FSEVENTS-GUIDE` | rescan/root-change guidance | re-check must-scan/root-changed wording before stronger gap-badge commitments |

## Added in Revision 079
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-06-01` | `REF-RFC7232-CONDITIONAL` | guarded mutation / lost update | stable RFC, but re-check exact `If-Match` / `If-None-Match` wording before stronger write-gate commitments |
| `2026-04-20` | `REF-GCS-PRECONDITIONS` | object-store preconditions | re-check generation/metageneration wording before stronger multi-version object analogies |
| `2026-04-20` | `REF-MDN-CREATEWRITABLE` | writable-session staging | re-check `exclusive`/`siloed` wording before stronger multi-writer shell claims |

## Added in Revision 080
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-06-01` | `REF-RFC9110-RANGE` | partial transfer / recombination rules | stable RFC, but re-check exact 206/recombine wording before stronger sparse-coverage commitments |
| `2026-06-01` | `REF-RFC9111-INCOMPLETE` | incomplete-response honesty | stable RFC, but re-check incomplete-response wording before stronger cache-like sparse-local claims |
| `2026-04-20` | `REF-STARGZ-OVERVIEW` | OCI-compatible lazy pull | re-check compatibility/lazy-pull wording before stronger runtime claims |
| `2026-04-20` | `REF-STARGZ-ESTARGZ` | chunk-on-demand execution | re-check file/chunk-on-demand wording before stronger shell runtime badges |
| `2026-04-20` | `REF-AWS-S3-OBJECT-ETAG` | composite identifier caveats | re-check ETag wording before stronger composite-checksum warnings |
| `2026-04-20` | `REF-AWS-S3-MPU-OVERVIEW` | multipart completion/full checksum | re-check full-object checksum wording before stronger whole-proof ladders |
| `2026-04-20` | `REF-AWS-S3-INTEGRITY` | checksum mode layering | re-check full-object/composite wording before stronger proof taxonomy claims |
| `2026-04-20` | `REF-ZARR-V3-CORE` | chunk-grid/layout metadata | re-check chunk-grid/codec wording before stronger layout-badge claims |


## Added in Revision 081
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-06-01` | `REF-RFC9110-IFRANGE` | exact basis / full-fetch fallback | stable RFC, but re-check exact `If-Range` fallback wording before stronger repair/update commitments |
| `2026-06-01` | `REF-RFC3229-DELTAHTTP` | delta/base-instance split | stable RFC, but re-check `Delta-Base` / current-instance wording before stronger delta-recipe commitments |
| `2026-06-01` | `REF-RFC3284-VCDIFF` | source-window / target-window split | stable RFC, but re-check window/basis wording before stronger apply-session taxonomy claims |
| `2026-04-20` | `REF-OSTREE-STATIC-DELTAS` | commit-pair delta lanes | re-check `from NULL` / commit-pair wording before stronger full-fetch-vs-delta claims |
| `2026-05-15` | `REF-ZSYNC-THEORY` | local-byte-reuse reconstruction | re-check checksum/control-file wording before stronger basis-card UI claims |

| `2026-06-01` | `REF-PLAN9` | per-process namespaces | re-check foundational namespace wording before freezing stronger publication/locality claims |
| `2026-06-01` | `REF-PLAN9-PLUMB` | typed route rules | re-check routing-rule wording before stronger publish/plumb analogies |

| `2026-04-20` | `REF-SANDSTORM-POWERBOX` | mediation / import-fit notes | re-check scope/locality wording before copying chooser UX language |
| `2026-04-20` | `REF-PLAN9-IMPORT` | imported namespace fragments | re-check import/mount wording before stronger fragment-badge commitments |
| `2026-06-01` | `REF-FOUNDATION-CAS` | content-addressed storage caution | re-check archival/dedup framing before stronger permanence/economics claims |

- [ ] Re-check `REF-LINUX-ACCESS` before any hard ViewFS claim about search permission, exact-name reachability, or metadata-disclosure policy.
- [ ] Re-check `REF-WASI-P1-RIGHTS` before hardening any ViewFS browse/open rights vocabulary around `readdir`-style separation.

| `2026-04-20` | `REF-FUCHSIA-CONNECT` | outgoing publication / adverts | re-check outgoing/exposed directory wording before stronger advert/publication analogies |
| `2026-04-20` | `REF-MCP-ROOTS` | scope adverts / grant-needed posture | re-check roots/list wording before stronger catalog-vs-grant claims |
| `2027-03-23` | `REF-DNSSD` | browse/resolve separation | re-check if newer DNS-SD guidance changes the discovery-vs-resolution framing |
| `2026-04-20` | `REF-K8S-ENDPOINTSLICE` | readiness lamps / freshness decay | re-check ready/serving/terminating wording before stronger shell-lamp commitments |

| `2026-05-15` | `REF-GIT-PARTIAL-CLONE` | provider-ready / promisor semantics | re-check promisor/missing-object wording before freezing local-realization vocabulary |
| `2026-04-20` | `REF-NIX-SSH-SUBSTITUTER` | substitute/source ladders | re-check substituter fallback wording before stronger make-local commitments |
| `2026-04-20` | `REF-FUCHSIA-AVAILABILITY` | route expectation / runtime truth | re-check availability semantics before stronger provider-ready commitments |
| `2026-04-20` | `REF-GHOSTTY-CURSORCLICK` | shell/terminal protocol | re-check OSC133-dependent cursor-move wording before deeper protocol-debugger commitments |

## Added in Revision 088
| review_by | ref_id | area | note |
|---|---|---|---|
| `2027-03-23` | `REF-RFC6749-AUTHCODE` | redeemable claim tickets | stable RFC, but re-check exact single-use / client-binding wording before stronger claim-ticket commitments |
| `2027-03-23` | `REF-RFC9449-DPOP` | holder-bound grants | stable RFC, but re-check sender-constraining wording before stronger proof-badge commitments |
| `2026-04-20` | `REF-ANDROID-PENDINGINTENT-SECURITY` | consumable / one-shot grants | re-check replay and one-shot guidance before stronger burn-after-use shell claims |


## Added in Revision 089
| review_by | ref_id | area | note |
|---|---|---|---|
| `2027-03-23` | `REF-RFC9470-STEPUP` | step-up / recency challenge posture | stable RFC, but re-check `insufficient_user_authentication`, `acr_values`, and `max_age` wording before stronger shell-ladder commitments |
| `2026-06-01` | `REF-OIDC-CORE-MAXAGE` | explicit recency posture | re-check `max_age`, `auth_time`, and `acr` wording before stronger recency-shutter claims |
| `2026-04-20` | `REF-WEBAUTHN-3` | local presence / user verification | re-check UP/UV and ceremony wording before stronger presence-pin commitments |
| `2026-04-20` | `REF-ANDROID-KEYSTORE-AUTH` | local possession versus current key use | re-check authentication-required wording before stronger invokable-now claims |
| `2026-05-15` | `REF-VC-BITSTRING-STATUS` | status carriers | re-check status-purpose vocabulary before making protocol commitments |
| `2026-05-15` | `REF-TUF-METADATA` | freshness/watch posture | re-check expiry wording before stronger claims about stale-watch behavior |
| `2026-05-15` | `REF-TUF-SPEC` | successor refresh / root recovery | re-check root-rotation and freeze language before stronger recovery commitments |
| `2026-06-01` | `REF-RFC7662-INTROSPECT` | current-state queries | stable RFC, but re-check if later related RFCs materially narrow or extend semantics |
| `2026-06-01` | `REF-RFC7009-REVOKE` | revocation trade-offs | stable RFC, re-check only if adjacent OAuth guidance becomes load-bearing |
| `2026-06-01` | `REF-RFC6960-OCSP` | status carriers / freshness | stable RFC, re-check only if later revocation profiles become load-bearing |
| `2026-06-01` | `REF-RFC5280-CRL` | reversible hold precedent | stable RFC, re-check only if hold/resume semantics become more than analogy |

## Added in Revision 091
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-06-01` | `REF-MACH-PORT-RIGHTS` | right classes / send-once precedent | re-check send/receive/send-once wording before stronger live-lend or burn-after-use commitments |
| `2026-06-01` | `REF-SEL4-GRANT` | live capability transfer rights | re-check Grant/GrantReply wording before stronger courier-lane commitments |
| `2026-04-20` | `REF-KITTY-FILETRANSFER` | terminal-native transfer lanes | re-check protocol/confirmation wording before deeper TTY-transfer UX commitments |

## Added in Revision 092
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-APPLE-FILEPROVIDER-SYNC` | provider-backed materialization | re-check dataless/materialized wording before stronger locality-lamp commitments |
| `2026-04-20` | `REF-FUCHSIA-COMPONENT-NSENTRY` | explicit namespace attachments | re-check namespace-entry wording before stronger attach/projection commitments |


## Added in Revision 093
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-ANDROID-SHARE-FILE` | Intent envelope vs temporary URI grants | re-check temporary-grant lifetime wording before stronger sidecar claims |
| `2026-04-20` | `REF-ANDROID-URIPERMISSION` | grant object introspection | re-check granted-time and persistence wording before stronger sink-tray claims |
| `2026-04-20` | `REF-ANDROID-GRANTURIPERMISSION` | scoped grant subsets | re-check path-subset grant wording before stronger route-scope claims |

## Added in Revision 094
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-06-01` | `REF-CONFUSED-DEPUTY-HARDY` | confused deputy history | re-check mirror availability and citation wording before using as a longer direct quote source |
| `2026-04-20` | `REF-JEP506-SCOPEDVALUES` | bounded dynamic scope | re-check final OpenJDK wording before stronger release-specific claims |
| `2026-04-20` | `REF-JAVA-SCOPEDVALUE-API` | bounded bindings / rebinding | re-check API wording before freezing any bracket-field vocabulary |
| `2026-04-20` | `REF-PY-CONTEXTVARS` | context-local state | re-check reset-token/context-bleed wording before deeper runtime analogies |
| `2026-04-20` | `REF-NODE-ASYNCLOCALSTORAGE` | async context bounds | re-check `run` / `enterWith` / `exit` wording before stronger shell bracket claims |
| `2026-04-20` | `REF-ASPNET-HTTPCONTEXTACCESSOR` | ambient-state caution | re-check caution/perf wording before stronger ambient-context warnings |

## Added in Revision 095
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-ANDROID-VIRTUALFILES` | alternate-representation / virtual-file truth | re-check `openInputStream` / alternate-MIME wording before stronger virtuality-lamp commitments |
| `2026-04-20` | `REF-WIT-RESOURCE-HANDLES` | external handles / owned-vs-borrowed | re-check component-model wording before freezing any exact attach-mode field names |



## Added in Revision 096
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-GHOSTTY-SHELL-INTEGRATION` | inspectable terminal integration | re-check manual-sourcing wording before stronger terminal-integration claims |
| `2026-04-20` | `REF-POWERSHELL-PROFILES` | startup-profile execution | re-check host/profile matrix wording before stronger startup-script taxonomy claims |


## Added in Revision 097
| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-20` | `REF-VSCODE-PROFILES` | profile-sliced customization surfaces | re-check profile-content class list before stronger shell-profile taxonomy claims |
| `2026-04-20` | `REF-FISH-ABBR` | typed lexical expansion | re-check typed-versus-script wording before stronger abbreviation semantics claims |
| `2026-04-20` | `REF-NU-OVERLAYS` | explicit command layers | re-check activation/deactivation wording before stronger overlay-rack commitments |
| `2026-04-20` | `REF-NU-CUSTOMCOMMANDS` | first-class custom commands | re-check help/pipeline/type-check wording before stronger custom-command claims |
| `2026-04-20` | `REF-NU-WHICH` | command-resolution explainability | re-check alias/custom/program wording before stronger which-ladder claims |
| `2026-06-01` | `REF-ZSH-ZLE` | widget versus typed command surfaces | re-check widget semantics if we later formalize key-action metadata fields |
| `2026-04-20` | `REF-GHOSTTY-KEYTABLES` | explicit modal key tables | re-check UI-indicator and key-table wording before stronger key-table-lamp claims |
| `2026-04-20` | `REF-GHOSTTY-CMDPALETTE` | palette-only action surfaces | re-check palette field wording before stronger palette/typed diff claims |

| `2026-04-21` | `REF-TREESITTER` | incremental parse and error-recovery UX | re-check wording before stronger parse-lens or recovery-veil claims |
| `2026-06-01` | `REF-LSP-DIAGNOSTICS-317` | diagnostics as a separate channel | re-check exact diagnostics wording before stronger protocol-sketch claims |
| `2026-04-21` | `REF-SHELLCHECK` | shell diagnostics as advisory explanation | re-check if ShellCheck positioning or homepage wording changes |
| `2026-04-21` | `REF-FISH-SYNTAX` | inline syntax/highlight feedback | re-check syntax-highlighting wording before stronger shell-UX claims |
