# External source head register

Purpose: keep moving-head or presentation-layer external sources visible so we do not accidentally treat a mutable docs page as frozen law.

Status for Revision 043: **reviewed, not byte-locked**. We used current primary sources, but this repo has not yet downloaded and hashed exact artifacts for lock rows. That work should happen when a source becomes load-bearing enough to support a hard decision.

| ref_id | source type | volatility | retrieved_on | next_review_by | note |
|---|---|---|---|---|---|
| `REF-FUCHSIA-NAMESPACE` | web docs | moving-head | `2026-03-23` | `2026-05-01` | explicit namespace-assembly and role/rights-shaped layout inspiration only; do not overfit exact routing syntax |
| `REF-FUCHSIA-DIR-CAPS` | web docs | moving-head | `2026-03-21` | `2026-05-01` | rights-routing semantics are relevant; exact schema syntax is not load-bearing yet |
| `REF-FUCHSIA-RIGHTS` | web docs | moving-head | `2026-03-21` | `2026-05-01` | good for handle-rights vocabulary |
| `REF-FUCHSIA-DICTCAP` | web docs | moving-head | `2026-03-23` | `2026-05-01` | capability-bundle inspiration for future grouped authority surfaces |
| `REF-FUCHSIA-DICT-RFC` | web docs | moving-head | `2026-03-21` | `2026-05-01` | grouped-capability RFC is inspiration only; do not overfit Fuchsia declarative syntax |
| `REF-FUCHSIA-IDLE-STOP` | web docs | moving-head | `2026-03-22` | `2026-05-01` | handle-escrow / narrow-continuity precedent only; do not overfit framework lifecycle details |
| `REF-FLATPAK-BASICS` | web docs | moving-head | `2026-03-21` | `2026-04-15` | portal posture reference |
| `REF-XDG-FILECHOOSER` | web docs | moving-head | `2026-03-23` | `2026-04-15` | chooser semantics may evolve; re-check before binding protocol details |
| `REF-XDG-DOCUMENTS` | web docs | moving-head | `2026-03-23` | `2026-04-15` | document portal behavior is inspirational, not directly adopted |
| `REF-XDG-DOCS-FUSE` | web docs | moving-head | `2026-03-21` | `2026-04-15` | useful for scoped synthetic-view behavior, not for adopting FUSE literally |
| `REF-XDG-FILETRANSFER` | web docs | moving-head | `2026-03-21` | `2026-04-15` | transfer-session semantics are useful for drag/drop and clipboard flows |
| `REF-WASI-CAPS` | GitHub markdown | moving-head | `2026-03-21` | `2026-04-20` | capability taxonomy is useful; exact text may drift |
| `REF-WASMTIME-PREOPEN` | GitHub markdown | moving-head | `2026-03-21` | `2026-04-20` | compat-preopen pattern is highly relevant |
| `REF-CAPSICUM-RIGHTS` | man page mirror | moving-head | `2026-03-21` | `2026-04-20` | rights taxonomy inspiration; exact names may be too granular for ViewFS |
| `REF-CAPSTD` | docs.rs | moving-head | `2026-03-21` | `2026-04-20` | explicit ambient-authority marker inspiration |
| `REF-CAPROS-USERDRIVERS` | web docs | moving-head | `2026-03-22` | `2026-05-15` | persistence/device-state caution for durable-authority design |
| `REF-TREESLS-SOSP23` | paper landing page / ACM | moving-head | `2026-03-22` | `2026-05-15` | modern capability-tree checkpoint inspiration; do not treat as a Phase 1 commitment |
| `REF-ANDROID-SAF` | web docs | moving-head | `2026-03-22` | `2026-04-20` | durable grant, stable identity, and multi-placement precedent only |
| `REF-APPLE-SSB-CVE2025` | NVD entry | moving-head | `2026-03-21` | `2026-04-20` | cautionary source only; do not overfit one vendor bug into the whole design |
| `REF-NIX-CA` | web manual | moving-head | `2026-03-21` | `2026-05-15` | object-addressing precedent |
| `REF-IPFS-CIDS` | web docs | moving-head | `2026-03-21` | `2026-05-15` | transport/object-identity separation inspiration |
| `REF-IPFS-MFS` | web docs | moving-head | `2026-03-21` | `2026-05-15` | mutable-over-immutable facade inspiration |
| `REF-PERKEEP-PERMANODE` | web docs | moving-head | `2026-03-21` | `2026-06-01` | stable mutable anchor idea; not load-bearing yet |
| `REF-TAHOE-MUTABLE` | readthedocs | moving-head | `2026-03-21` | `2026-05-15` | stable mutable-slot contrast case |
| `REF-SQLITE-SESSION` | web docs | moving-head | `2026-03-21` | `2026-05-15` | changeset-sidecar inspiration only |
| `REF-NUSHELL` | web docs | moving-head | `2026-03-21` | `2026-05-15` | shell UX inspiration only |
| `REF-FISH` | web docs | moving-head | `2026-03-21` | `2026-05-15` | shell UX inspiration only |
| `REF-WARP-BLOCKS` | web docs | moving-head | `2026-03-21` | `2026-04-15` | terminal-block UX inspiration only |
| `REF-WARP-NOTEBOOKS` | web docs | moving-head | `2026-03-22` | `2026-04-15` | workflow/documentation UX inspiration |
| `REF-WARP-WORKFLOWS` | web docs | moving-head | `2026-03-22` | `2026-04-15` | saved-command UX inspiration |
| `REF-WARP-CMDPALETTE` | web docs | moving-head | `2026-03-21` | `2026-04-15` | searchable command/object palette inspiration |
| `REF-WEZTERM-HYPERLINKS` | web docs | moving-head | `2026-03-21` | `2026-05-15` | terminal hyperlink inspiration |
| `REF-WEZTERM-DOMAINS` | web docs | moving-head | `2026-03-21` | `2026-05-15` | terminal domain UI inspiration |
| `REF-WEZTERM-SHELL-INT` | web docs | moving-head | `2026-03-23` | `2026-04-15` | semantic-zone, cwd, and command-block protocol inspiration |
| `REF-WEZTERM-ZONES` | web docs | moving-head | `2026-03-23` | `2026-04-15` | semantic-zone API is useful for block/receipt UI but should not hard-freeze event naming yet |
| `REF-LANDLOCK` | kernel docs | moving-head | `2026-03-21` | `2026-05-15` | defense-in-depth backstop inspiration, not a ViewFS semantic dependency |
| `REF-FUCHSIA-SECURE` | web docs | moving-head | `2026-03-21` | `2026-05-01` | conceptual no-ambient-authority language; do not overfit exact prose |
| `REF-FUCHSIA-SANDBOXING` | web docs | moving-head | `2026-03-22` | `2026-05-01` | creator-populated namespace and no-self-grant precedent for launch-kit separation |
| `REF-XDG-OPENURI` | web docs | moving-head | `2026-03-21` | `2026-04-15` | URI-launch mediation inspiration only; keep separate from local-object grants |
| `REF-PLAN9-ACME` | web docs | moving-head | `2026-03-21` | `2026-05-15` | text-ui object/control-surface inspiration only |
| `REF-ITERM-SHELLINT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | mark/history/recent-directory and command-navigation UX inspiration only |
| `REF-ITERM-OSC8` | web docs | moving-head | `2026-03-21` | `2026-04-20` | hyperlink substrate inspiration; keep type/routing semantics in ViewFS layer |
| `REF-GHOSTTY-SHELLINT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | shell-integration feature list is inspiration only |
| `REF-GHOSTTY-OSC133-OVERLAY` | release notes | moving-head | `2026-03-22` | `2026-04-20` | overlay idea is useful for inspector/debug tooling and prompt-local interaction debugging, not a protocol dependency |
| `REF-NIX-STORE` | web manual | moving-head | `2026-03-21` | `2026-05-15` | immutable-store framing only; avoid importing Nix build semantics wholesale |
| `REF-XDG-REQUEST` | web docs | moving-head | `2026-03-23` | `2026-04-15` | request handles are useful receipt precedents; do not overfit DBus path syntax |
| `REF-WEZTERM-USERVARS` | web docs | moving-head | `2026-03-22` | `2026-04-15` | explicit pane-state signaling inspiration; keep metadata distinct from authority |
| `REF-ITERM-HISTDISK` | web docs | moving-head | `2026-03-21` | `2026-04-20` | saved shell-state precedent; useful caution for session-memory design |
| `REF-GNOME-TRACKER` | web docs | moving-head | `2026-03-21` | `2026-04-15` | desktop search/index precedent; keep ambient-inventory risk in mind |
| `REF-GNOME-LOCALSEARCH` | web docs | moving-head | `2026-03-21` | `2026-04-15` | extraction/index policy precedent; useful for bounded derived-metadata ideas |
| `REF-GTK-RECENT` | web docs | moving-head | `2026-03-21` | `2026-04-15` | recent-item registry precedent; keep recency distinct from authority |
| `REF-WIN-PREVIEW-HANDLERS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | preview-as-read-only precedent only; do not overfit COM host details |
| `REF-WIN-PREVIEW-GUIDE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | inert-preview checklist inspiration; exact UI guidance is not a ViewFS contract |
| `REF-APPLE-QUICKLOOK-WWDC24` | video transcript | moving-head | `2026-03-22` | `2026-04-20` | preview-session/lifecycle inspiration only |
| `REF-XDG-BACKENDS` | web docs | moving-head | `2026-03-22` | `2026-04-15` | backend/frontend split inspiration; do not overfit DBus/backend packaging |
| `REF-VSCODE-WORKSPACE-TRUST` | web docs | moving-head | `2026-03-22` | `2026-04-20` | restricted-mode workspace-opening precedent only |
| `REF-VSCODE-TASKS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | user-vs-workspace automation split inspiration only |
| `REF-VSCODE-JUPYTER-TRUST` | web docs | moving-head | `2026-03-22` | `2026-04-20` | notebook trust boundary inspiration only |
| `REF-JETBRAINS-PROJSEC` | web docs | moving-head | `2026-03-22` | `2026-04-20` | project-trust prompt/trusted-locations inspiration only |
| `REF-DIRENV-ALLOW` | web docs | moving-head | `2026-03-22` | `2026-04-20` | explicit per-directory allow/deny inspiration only |
| `REF-DIRENV-REQUIREALLOWED` | web docs | moving-head | `2026-03-22` | `2026-04-20` | trust-invalidation-on-file-change inspiration only |
| `REF-WAYLAND-DATADEVICES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | transfer/data-offer precedent only; do not overfit Wayland-specific MIME/device mechanics |

| `REF-INOTIFY` | man page | moving-head | `2026-03-21` | `2026-04-20` | overflow/rebuild wording is useful for watch-health design; exact Linux flags are not a ViewFS protocol commitment |
| `REF-FANOTIFY` | man page | moving-head | `2026-03-21` | `2026-04-20` | access-notification vs object-access contrast case only; do not overfit Linux event taxonomy |
| `REF-APPLE-FSEVENTS` | web docs | moving-head | `2026-03-21` | `2026-04-20` | rescan/root-change lessons are useful; exact Apple flags are not a ViewFS contract |
| `REF-WIN-READDIRCHANGES` | web docs | moving-head | `2026-03-21` | `2026-04-20` | directory-scoped watch analogy only; exact Win32 API shape is not load-bearing |
| `REF-WIN-USN` | web docs | moving-head | `2026-03-21` | `2026-04-20` | persistent change-log / reindex lesson only; do not overfit NTFS-specific details |
| `REF-WATCHMAN-TROUBLE` | web docs | moving-head | `2026-03-21` | `2026-04-20` | explicit recrawl/limit-warning UX inspiration only |
| `REF-WATCHMAN-INSTALL` | web docs | moving-head | `2026-03-21` | `2026-04-20` | remote/distributed watch caveat inspiration only |


| `REF-LINUX-PATHLOOKUP` | kernel docs | moving-head | `2026-03-21` | `2026-04-20` | path-resolution restriction wording is useful; exact Linux naming is not a ViewFS contract |
| `REF-CAPPRIMS-FS` | docs.rs | moving-head | `2026-03-21` | `2026-04-20` | rooted/nofollow helper inspiration only; do not overfit Rust API names |
| `REF-WIN-SHELLLINK` | web docs | moving-head | `2026-03-21` | `2026-04-20` | shortcut/route-object inspiration only; avoid copying COM object details |
| `REF-WIN-HARDLINKS` | web docs | moving-head | `2026-03-21` | `2026-04-20` | link-class contrast case only; do not overfit NTFS implementation details |
| `REF-WIN-REPARSE` | web docs | moving-head | `2026-03-21` | `2026-04-20` | implementation-indirection caution only; not a ViewFS object contract |
| `REF-APPLE-BOOKMARKS` | archived web docs | semi-stable | `2026-03-21` | `2026-04-20` | bookmark-vs-path guidance is useful, but archived wording should not be treated as modern sandbox law |
| `REF-APPLE-SECBOOKMARK` | web docs | moving-head | `2026-03-21` | `2026-04-20` | security-scoped bookmark flow inspiration only |
| `REF-APPLE-SECWITHSCOPE` | web docs | moving-head | `2026-03-21` | `2026-04-20` | scope-typed bookmark creation inspiration only |
| `REF-APPLE-SECSTART` | web docs | moving-head | `2026-03-21` | `2026-04-20` | explicit start-accessing step inspiration only |
| `REF-APPLE-SECRESOLVE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | stale-bookmark-resolution precedent only; do not overfit Apple URL APIs |
| `REF-ITERM-SEMHIST` | web docs | moving-head | `2026-03-21` | `2026-04-20` | semantic-history heuristic UX inspiration only; do not treat cwd-tracked guesses as authority semantics |
| `REF-APPLE-QUARANTINEKEY` | web docs | moving-head | `2026-03-21` | `2026-04-20` | quarantine-property API is useful vocabulary; exact API naming is not a ViewFS contract |
| `REF-APPLE-GATEKEEPER` | web docs | moving-head | `2026-03-21` | `2026-04-20` | guarded-open precedent only; do not overfit Apple-specific signing flow |
| `REF-APPLE-SAFEOPEN` | support doc | moving-head | `2026-03-21` | `2026-04-20` | user-facing explanation precedent only |
| `REF-APPLE-GATEKEEPER-BYPASS` | security content note | moving-head | `2026-03-21` | `2026-04-20` | cautionary bug-history source only; do not overfit one vendor bypass lineage |
| `REF-MS-ATTACHMENTMGR` | web docs | moving-head | `2026-03-21` | `2026-04-20` | zone-of-origin precedent; exact policy knobs are not a ViewFS contract |
| `REF-MS-MOTW-OFFICE` | web docs | moving-head | `2026-03-21` | `2026-04-20` | guarded-document precedent only; do not overfit Office product semantics |
| `REF-MS-APPGUARD` | web docs | moving-head | `2026-03-21` | `2026-04-20` | isolated-open precedent only; exact Hyper-V/container details are not load-bearing |
| `REF-MS-SMARTSCREEN` | web docs | moving-head | `2026-03-21` | `2026-04-20` | reputation-signal precedent only |
| `REF-EDGE-DL-DANGER` | web docs | moving-head | `2026-03-21` | `2026-04-20` | dangerous-file-type ladder inspiration only |


| `REF-FDO-TRASH` | web spec | moving-head | `2026-03-22` | `2026-04-20` | trash metadata / undelete precedent only; do not overfit XDG path layout |
| `REF-APPLE-TRASHITEM` | web docs | moving-head | `2026-03-22` | `2026-04-20` | trash-move / resulting-URL precedent only; exact Foundation API shape is not a ViewFS contract |
| `REF-MS-RECYCLEONDELETE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | recycle-vs-permanent-delete distinction inspiration only |
| `REF-NIX-GCROOTS` | web manual | moving-head | `2026-03-22` | `2026-05-15` | explicit-root retention precedent only; do not import Nix profile semantics wholesale |
| `REF-NIX-GC` | web manual | moving-head | `2026-03-22` | `2026-05-15` | separate purge/GC act precedent only |
| `REF-VSCODE-LOCALHISTORY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | local-history/timeline recovery inspiration only |
| `REF-GIT-REFLOG` | web docs | moving-head | `2026-03-22` | `2026-04-20` | reflog/time-travel analogy only; do not overfit Git ref syntax |
| `REF-APPLE-APFS-FEATURES` | web docs | archive docs | `2026-03-22` | `2026-05-15` | APFS feature list is older archive material; use for broad inspiration only |
| `REF-ZFS-SNAPSHOT` | web docs | moving-head | `2026-03-22` | `2026-05-15` | atomic snapshot wording is useful; exact CLI flags are not a ViewFS contract |
| `REF-ZFS-CLONES` | web docs | moving-head | `2026-03-22` | `2026-05-15` | clone/promotion split inspiration only |
| `REF-ZFS-BOOKMARK` | web docs | moving-head | `2026-03-22` | `2026-05-15` | bookmark/send split is useful lineage inspiration; do not overfit ZFS naming |
| `REF-BTRFS-SUBVOLUMES` | web docs | moving-head | `2026-03-22` | `2026-05-15` | snapshot/fork semantics inspiration only |
| `REF-BTRFS-SEND` | web docs | moving-head | `2026-03-22` | `2026-05-15` | replication-stream analogy only; exact stream format is not load-bearing |
| `REF-GIT-WORKTREE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | parallel writable workspace inspiration only |
| `REF-MS-VSS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | backup-coordination / provider split inspiration only |
| `REF-OSTREE-OVERVIEW` | web docs | moving-head | `2026-03-22` | `2026-05-15` | object-store/deployment split inspiration only |
| `REF-OSTREE-MANUAL` | web docs | moving-head | `2026-03-22` | `2026-05-15` | lifecycle-verb separation inspiration only |
| `REF-RESTIC-FORGET` | web docs | moving-head | `2026-03-22` | `2026-04-20` | retention vs prune wording inspiration only |
| `REF-FREEBSD-BECTL` | man page | moving-head | `2026-03-22` | `2026-05-15` | boot-environment activation analogy only |

| `REF-RFC9110-PRECONDITIONS` | RFC / standards text | stable | `2026-03-22` | `2026-06-01` | standards-track source; exact section text is load-bearing for optimistic-precondition wording |
| `REF-S3-CONDITIONAL-WRITES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | object-store conditional-write precedent; re-check API list / error wording before stronger commitments |
| `REF-S3-CONDITIONAL-DELETES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | delete-precondition wording may evolve; inspiration only |
| `REF-GIT-FORCE-WITH-LEASE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | ergonomic override precedent only; do not overfit exact CLI syntax |
| `REF-GIT-UPDATE-REF` | web docs | moving-head | `2026-03-22` | `2026-04-20` | compare-and-swap ref update precedent only |
| `REF-WEBDAV-LOCKING` | RFC / standards text | stable | `2026-03-22` | `2026-06-01` | lock-token / timeout / privilege split is load-bearing; exact XML surface is not |
| `REF-ETCD-TXN` | web docs | moving-head | `2026-03-22` | `2026-04-20` | conditional transaction precedent only; do not overfit etcd API shape |
| `REF-ETCD-LEASE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | lease TTL semantics are useful inspiration; exact etcdctl UX is not load-bearing |
| `REF-ETCD-LOCK` | web docs | moving-head | `2026-03-22` | `2026-04-20` | auto-release-on-lease-expiry precedent only |
| `REF-K8S-SSA` | web docs | moving-head | `2026-03-22` | `2026-04-20` | field-manager / conflict wording inspiration only; do not overfit K8s patch semantics |
| `REF-AZURE-BLOB-CONCURRENCY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | optimistic-object-write precedent only |
| `REF-SQLITE-ISOLATION` | web docs | moving-head | `2026-03-22` | `2026-05-15` | cautionary concurrency-background source |
| `REF-SQLITE-LOCKINGV3` | web docs | moving-head | `2026-03-22` | `2026-05-15` | cautionary low-level locking source |
| `REF-APPLE-NSMETADATAQUERY` | web docs | moving-head | `2026-03-21` | `2026-04-20` | snapshot-vs-live-query wording is useful; do not overfit Cocoa API names |
| `REF-APPLE-SPOTLIGHT-QUERYGUIDE` | archived web docs | semi-stable | `2026-03-21` | `2026-05-15` | historical batching/update guidance is useful, but archived API details are not a ViewFS contract |
| `REF-APPLE-SMARTFOLDERS` | support doc | moving-head | `2026-03-21` | `2026-04-20` | folder-like saved-query UX precedent only; exact Finder UI is not load-bearing |
| `REF-WIN-SEARCH-MS` | web docs | moving-head | `2026-03-21` | `2026-04-20` | saved-search file-format precedent only; do not overfit Windows XML schema |

| `REF-APPLE-DOCPICKER-OPS` | archived web docs | semi-stable | `2026-03-22` | `2026-05-15` | archived but still useful lane-separation source; do not overfit UIKit API names |
| `REF-APPLE-DOCPICKER-ACCESS` | archived web docs | semi-stable | `2026-03-22` | `2026-05-15` | security-scoped open/move guidance is useful; archived details are not a ViewFS contract |
| `REF-ANDROID-CREATE-DOCUMENT` | web docs | moving-head | `2026-03-22` | `2026-04-20` | save-as / create-only wording inspiration only; re-check restrictions before stronger provider claims |
| `REF-WIN-SHELL-CLIPFORMATS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | explicit move/copy outcome-format precedent only; do not overfit COM clipboard APIs |
| `REF-WIN-SHELL-DATASCENARIOS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | delete-on-paste / optimized-move protocol inspiration only |
| `REF-APPLE-FILEPROMISES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | promised-file materialization inspiration only; exact AppKit drag APIs are not load-bearing |
| `REF-IPFS-PERSISTENCE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | retention-vs-gc precedent only; do not import IPFS network economics wholesale |
| `REF-NIX-REALISE` | web manual | moving-head | `2026-03-22` | `2026-05-15` | explicit hydration/realization precedent only |
| `REF-NIX-COPY` | web manual | moving-head | `2026-03-22` | `2026-05-15` | explicit closure-copy / transport precedent only |
| `REF-NIX-PREFETCH-FILE` | web manual | moving-head | `2026-03-22` | `2026-05-15` | prefetch/warm-up precedent only; do not import Nix CLI shape wholesale |
| `REF-OSTREE-REPO-MGMT` | web docs | moving-head | `2026-03-22` | `2026-05-15` | mirror/offline-access precedent only |
| `REF-OSTREE-STATIC-DELTAS` | web docs | moving-head | `2026-03-22` | `2026-05-15` | self-contained offline bundle precedent only |
| `REF-OSTREE-FORMATS` | web docs | moving-head | `2026-03-22` | `2026-05-15` | delta-format optimization precedent only |
| `REF-SVCWORKER-SPEC` | standards spec | moving-head | `2026-03-22` | `2026-06-01` | explicit cache/update/lifetime-state precedent only |
| `REF-MDNPREFETCH` | web docs | moving-head | `2026-03-22` | `2026-04-20` | prefetch-is-hint wording inspiration only; re-check browser caveats before stronger claims |
| `REF-MS-ALWAYSOFFLINE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | offline-cache UX precedent only; do not import Windows sync semantics wholesale |

| `REF-XDG-PORTAL-DESIGN` | web docs | moving-head | `2026-03-22` | `2026-04-15` | portal design/validation/request-shape inspiration only; do not overfit DBus transport details |
| `REF-CAPSICUM-ADOPTION` | web docs | moving-head | `2026-03-22` | `2026-04-20` | adoption/tooling lesson only; do not overfit FreeBSD-specific developer workflow |
| `REF-DENO-PERMISSIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | runtime permission-prompt posture inspiration only; do not overfit Deno module-loader specifics |
| `REF-ANDROID-DOCPROVIDER` | web docs | moving-head | `2026-03-22` | `2026-04-20` | provider-declared operation flags inspiration only; exact Android API names are not a ViewFS contract |
| `REF-MS-FUTUREACCESSLIST` | web docs | moving-head | `2026-03-22` | `2026-04-20` | bounded durable-access-list precedent only; exact UWP list mechanics are not a ViewFS contract |
| `REF-CEDAR-AUTHZ` | web docs | moving-head | `2026-03-22` | `2026-04-20` | determining-policy/error diagnostics are strong inspiration; do not overfit Cedar syntax or effect model |
| `REF-CEDAR-VALIDATION` | web docs | moving-head | `2026-03-22` | `2026-04-20` | validation-vs-authorization split is important; re-check before binding any schema workflow details |
| `REF-OPA-CORE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | policy-engine-vs-enforcement framing is inspiration only; do not import Rego or OPA deployment shape wholesale |
| `REF-OPA-DECISIONLOGS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | audit/redaction lessons are useful; exact log fields are not a ViewFS contract |
| `REF-POLKIT-AUTHORITY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | temporary-authorization caution only; do not overfit desktop DBus packaging or auth-agent APIs |
| `REF-MACAROONS-NDSS14` | paper landing page | moving-head | `2026-03-22` | `2026-04-20` | attenuation-caveat inspiration only; do not overfit token construction details |
| `REF-ZANZIBAR` | paper landing page | moving-head | `2026-03-22` | `2026-04-20` | consistency/freshness-token inspiration only; do not import ACL policy semantics wholesale |
| `REF-OPA-DISCOVERY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | discovery/boot-override wording is inspiration for visible precedence, not a commitment to OPA-style deployment plumbing |
| `REF-SPICEDB-CONSISTENCY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | consistency-mode and ZedToken wording is inspiration for cut/freshness UX, not a commitment to ReBAC semantics |

| `REF-GIT-CONFIG-ORIGIN-SCOPE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | origin/scope inspection precedent only; do not import Git config semantics wholesale |
| `REF-VSCODE-CHAT-CUSTOM-DIAG` | web docs | moving-head | `2026-03-22` | `2026-04-20` | customization-origin diagnostics precedent only |
| `REF-VSCODE-MCP-SERVERS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | workspace-vs-profile config plus trust-prompt precedent only |
| `REF-VSCODE-AGENT-PERMISSIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | session/workspace/future approval-scope precedent only |
| `REF-VSCODE-AUTOPILOT-PERMISSIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | session-scoped autonomy picker precedent only |

| `REF-CEDAR-SECURITY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | explicit deny / forbid-overrides-permit inspiration only; do not overfit Cedar effect syntax wholesale |
| `REF-VSCODE-CONTRIB-SCOPES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | scope-applicability precedent only; do not import VS Code setting taxonomy wholesale |
| `REF-VSCODE-WORKSPACE-TRUST-EXT` | web docs | moving-head | `2026-03-22` | `2026-04-20` | restricted-configuration gating precedent only |
| `REF-VSCODE-AGENT-TOOLS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | session-vs-broader approval-ladder precedent only |
| `REF-VSCODE-CHAT-OVERVIEW` | web docs | moving-head | `2026-03-22` | `2026-04-20` | permissions-picker/current-session autonomy precedent only |
| `REF-VSCODE-112` | web docs | moving-head | `2026-03-22` | `2026-04-20` | steering/queueing and session-state link-resolution precedent only |
| `REF-VSCODE-AGENT-PLUGINS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | trusted-carrier versus workspace-trust contrast inspiration only |
| `REF-VSCODE-CUSTOMIZE-AI` | web docs | moving-head | `2026-03-22` | `2026-04-20` | parent-repo/workspace customization discovery precedent only |
| `REF-VSCODE-COPILOT-SECURITY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | trust-boundary split and scoped approval precedent only |

| `REF-GIT-PROTECTED-CONFIG` | web docs | moving-head | `2026-03-22` | `2026-04-20` | protected-scopes precedent only; do not overfit exact Git scope names into ViewFS policy families |
| `REF-GIT-SAFE-DIRECTORY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | protected-only setting precedent only; exact Git repo-safety semantics are not a ViewFS contract |
| `REF-VSCODE-CUSTOM-INSTRUCTIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | auto-applied guidance precedent only; exact AI product behavior may evolve |
| `REF-VSCODE-PROMPT-FILES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | invoke-only helper precedent only; do not overfit VS Code markdown/frontmatter schema |
| `REF-VSCODE-CUSTOM-AGENTS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | source-inspection / tool-restriction precedent only; exact VS Code agent file layout is not a ViewFS contract |
| `REF-DENO-PERM-BROKER` | web docs | moving-head | `2026-03-22` | `2026-04-20` | central-broker precedent only; exact env-var/socket details are not load-bearing |

| `REF-VSCODE-PUBLISHER-TRUST` | web docs | moving-head | `2026-03-22` | `2026-04-20` | publisher-trust precedent only; do not overfit VS Code extension-marketplace workflows into ViewFS helper installs |
| `REF-VSCODE-MCP-SERVERS-LIVE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | install/start/enable/use lifecycle precedent only; exact MCP UI or JSON fields are not a ViewFS contract |
| `REF-VSCODE-PLUGIN-LIFECYCLE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | plugin-install versus runtime-liveness precedent only; exact plugin packaging is not a ViewFS contract |
| `REF-VSCODE-112-LIFECYCLE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | enablement-scope and update-approval precedent only; exact VS Code toggle names may change |
| `REF-VSCODE-COPILOT-BOUNDARIES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | multiple trust-boundary precedent only; do not import VS Code-specific trust list mechanics wholesale |
| `REF-DENO-PERM-BROKER-LIVE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | live broker lane precedent only; exact broker transport details are not load-bearing |

| `REF-MCP-SPEC-FEATURES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | feature-kind split inspiration only; no commitment to raw MCP protocol adoption |
| `REF-MCP-RESOURCES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | resource-shelf precedent only; no commitment to URI shape or transport |
| `REF-MCP-PROMPTS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | prompt-chip precedent only; no commitment to MCP prompt schema |
| `REF-MCP-TOOLS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | tool-rack precedent only; no commitment to MCP tool-call ABI |
| `REF-MCP-COMPLETION` | web docs | moving-head | `2026-03-22` | `2026-04-20` | completion-popover and disclosure-risk precedent only |

| `REF-MCP-TASKS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | task-wrapper / final-result split inspiration only; no commitment to raw MCP task transport or field names |
| `REF-MCP-PROGRESS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | progress-lane precedent only; no commitment to MCP metadata shape |
| `REF-XDG-REQUEST` | web docs | moving-head | `2026-03-22` | `2026-04-15` | request-handle / later-response precedent only; do not overfit portal DBus object details |
| `REF-XDG-BACKGROUND` | web docs | moving-head | `2026-03-22` | `2026-04-15` | background-permission and status-message precedent only; exact portal options are not a ViewFS contract |
| `REF-GCLOUD-LRO` | web docs | moving-head | `2026-03-22` | `2026-05-15` | long-running-operation polling/wait precedent only; do not import Google API surface wholesale |
| `REF-VSCODE-TASKS-BG` | web docs | moving-head | `2026-03-22` | `2026-04-20` | background/watch-task completion precedent only; exact task JSON is not a ViewFS contract |
| `REF-VSCODE-109-BGAGENTS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | queued-follow-up and background-session UX precedent only; exact product wording may drift |
| `REF-VSCODE-110-TERMSECTIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | collapsible terminal-section precedent only; exact product chrome may drift |
| `REF-AIP151-LRO` | web docs | moving-head | `2026-03-22` | `2026-05-15` | operation-expiry and parallel-operation guidance inspiration only; do not import Google API surface wholesale |
| `REF-TEMPORAL-INTERRUPT` | web docs | moving-head | `2026-03-22` | `2026-04-20` | cancel-versus-terminate precedent only; exact Temporal control semantics are not a ViewFS contract |
| `REF-TEMPORAL-WFID` | web docs | moving-head | `2026-03-22` | `2026-04-20` | reset/reuse/use-existing precedent only; exact Temporal run-chain semantics are not a ViewFS contract |
| `REF-VSCODE-CHAT-SESSIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | fork/session-branch UX precedent only; exact product wording may drift |
| `REF-KUBECTL-ATTACH` | web docs | moving-head | `2026-03-22` | `2026-04-20` | live-session attach precedent only; do not overfit Kubernetes resource syntax |
| `REF-KUBECTL-LOGS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | follow-only output precedent; exact CLI flags are not load-bearing |
| `REF-KUBECTL-PORTFWD` | web docs | moving-head | `2026-03-22` | `2026-04-20` | sideband tunnel lifetime precedent only; do not overfit pod-specific semantics |
| `REF-TMUX` | man page mirror | moving-head | `2026-03-22` | `2026-04-20` | read-only client and control-mode precedent; exact command syntax is not load-bearing |
| `REF-TEMPORAL-MESSAGES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | query/signal/update split is highly relevant; SDK wording may drift |
| `REF-XDG-INPUTCAPTURE` | web docs | moving-head | `2026-03-22` | `2026-04-15` | enabled-versus-active precedent only; do not overfit compositor-specific details |
| `REF-SYSTEMD-FDSTORE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | narrow exact-handle continuity-locker precedent only; do not overfit systemd service mechanics into ViewFS persistence semantics |

| `REF-MEMFD-CREATE` | man page mirror | moving-head | `2026-03-22` | `2026-04-20` | transient exact-byte capsule inspiration only; do not overfit Linux-only staging primitives into ViewFS architecture |
| `REF-MEMFD-SEALS` | man page mirror | moving-head | `2026-03-22` | `2026-04-20` | freeze-for-review / commit-last inspiration only; exact Linux seal flags are not a ViewFS contract |
| `REF-UNIX-SCMRIGHTS` | man page mirror | moving-head | `2026-03-23` | `2026-04-20` | explicit local handle-courier precedent only; do not overfit AF_UNIX transport details into ViewFS transfer semantics |

| `REF-SEL4-BADGES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | badge-on-cap-copy precedent only; do not overfit seL4 IPC or CSpace mechanics into ViewFS handle metadata |
| `REF-SYSTEMD-SOCKETACT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | startup-delivered-handle-kit precedent only; do not overfit systemd unit/socket mechanics into ViewFS launch design |
| `REF-VSCODE-SHELLINT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | command-chrome truth-ladder precedent only; exact escape sequences and product chrome may drift |

| `REF-SOCKET-PASSCRED` | man page mirror | moving-head | `2026-03-22` | `2026-04-20` | courier-peer-witness precedent only; exact Linux socket options are not a ViewFS wire contract |
| `REF-VSCODE-106-ATTCMD` | web docs | moving-head | `2026-03-22` | `2026-04-20` | structured-command-packet precedent only; exact VS Code chat/product wording may drift |

| `REF-LINUX-PIDFD` | man page | moving-head | `2026-03-22` | `2026-04-20` | process-handle precedent only; do not overfit Linux-specific right surfaces |
| `REF-LINUX-PIDFD-GETFD` | man page | moving-head | `2026-03-22` | `2026-04-20` | cautionary stronger-process-rights precedent; keep separate from ordinary command cards |
| `REF-FREEBSD-PROCDESC` | man page | moving-head | `2026-03-22` | `2026-05-15` | cross-platform capability-shaped process reference precedent |

| `REF-LINUX-OPEN-TREE` | man page | moving-head | `2026-03-22` | `2026-04-20` | detached-fragment precedent only; do not overfit Linux mount internals into ViewFS namespace design |
| `REF-LINUX-MOVE-MOUNT` | man page | moving-head | `2026-03-22` | `2026-04-20` | attach-as-separate-act precedent only; exact Linux flags are not a ViewFS contract |
| `REF-LINUX-MOUNT-SETATTR` | man page mirror | moving-head | `2026-03-22` | `2026-04-20` | pre-attach posture precedent only; do not overfit Linux ID-mapped mount semantics |
| `REF-XTERM-BRACKETED-PASTE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | input-origin precedent only; exact escape sequences may drift by terminal/app support |
| `REF-KITTY-KEYBOARD` | web docs | moving-head | `2026-03-23` | `2026-04-20` | disambiguated-key-packet precedent only; exact kitty protocol details are not a ViewFS wire contract |

| `REF-MAN7-FEXECVE` | man page | moving-head | `2026-03-22` | `2026-04-20` | exact-exec-object precedent only; do not overfit Linux/GLIBC execution quirks into ViewFS launch design |
| `REF-MAN7-EXECVEAT` | man page | moving-head | `2026-03-22` | `2026-04-20` | fd-based launch precedent only; exact `AT_EMPTY_PATH` and script caveats are not a ViewFS contract |
| `REF-SYSTEMD-CREDENTIALS` | web docs | moving-head | `2026-03-23` | `2026-04-20` | activation-time immutable-credential precedent only; do not overfit systemd credential directories into ViewFS carrier choice |

| `REF-LINUX-LDSO` | man page | moving-head | `2026-03-22` | `2026-04-20` | loader-search / startup-code-closure precedent only; do not overfit ELF/glibc knobs into ViewFS architecture |
| `REF-LINUX-DLOPEN` | man page | moving-head | `2026-03-22` | `2026-04-20` | late dynamic-import precedent only; exact `dlopen` flags are not a ViewFS contract |
| `REF-WIN-DLL-SEARCH` | web docs | moving-head | `2026-03-22` | `2026-04-20` | DLL search-order precedent only; exact Win32 directory order is not a ViewFS contract |
| `REF-WIN-LOADLIBRARY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | late import / name-based rediscovery caution only; exact Win32 API wording may drift |

| `REF-WAYLAND-PRIMARY-SELECTION` | web docs | moving-head | `2026-03-22` | `2026-04-20` | selection-offer precedent only; do not overfit Wayland primary-selection mechanics into ViewFS clipboard design |
| `REF-X11-ICCCM-SELECTIONS` | web docs | semi-stable | `2026-03-22` | `2026-05-15` | historical selection-owner/requestor precedent only; keep X11 property mechanics as cautionary shape, not protocol commitment |
| `REF-KITTY-CLIPBOARD` | web docs | moving-head | `2026-03-22` | `2026-04-20` | typed clipboard / permission-gated-read precedent only; exact kitty escape codes are not a ViewFS wire contract |


| `REF-LINUX-CREDENTIALS-JC` | man page | moving-head | `2026-03-22` | `2026-04-20` | classic job-control layering precedent only; do not overfit POSIX session/process-group internals into ViewFS object models |
| `REF-LINUX-SETPGID` | man page | moving-head | `2026-03-22` | `2026-04-20` | foreground-process-group precedent only; exact `tcsetpgrp` mechanics are not a ViewFS contract |
| `REF-LINUX-SETSID` | man page | moving-head | `2026-03-22` | `2026-04-20` | hangup/session-leader precedent only; do not overfit POSIX session lifecycle into ViewFS continuity design |
| `REF-GLIBC-LOGINTTY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | controlling-terminal adoption precedent only; exact libc helper semantics are not a ViewFS wire contract |
| `REF-LINUX-TTY4` | man page | moving-head | `2026-03-22` | `2026-04-20` | controlling-terminal detach precedent only; `/dev/tty` path details are cautionary shape, not ViewFS naming guidance |

| `REF-FUCHSIA-RUNNER` | web docs | moving-head | `2026-03-22` | `2026-04-20` | runner-capability/environment precedent only; do not overfit Fuchsia component-manager specifics into ViewFS launch design |
| `REF-FUCHSIA-CAPS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | environment-routed capability precedent only; keep Fuchsia routing mechanics as shape, not commitment |
| `REF-OCI-RUNTIME-CONFIG` | GitHub spec doc | moving-head | `2026-03-22` | `2026-04-20` | structured runtime-config precedent only; exact OCI bundle fields are not a ViewFS contract |
| `REF-OCI-PROCESS-CONFIGGO` | GitHub source | moving-head | `2026-03-22` | `2026-04-20` | structured process-bundle precedent only; exact OCI/Linux fields are not a ViewFS contract |
| `REF-ITERM-CMDSELECT` | web docs | moving-head | `2026-03-22` | `2026-04-20` | command-block selection precedent only; exact iTerm2 UI affordances are not a ViewFS wire contract |
| `REF-ITERM-CLEARBUFFER` | web docs | moving-head | `2026-03-22` | `2026-04-20` | mutable-area-vs-scrollback precedent only; exact menu names may drift |

| `REF-MAN7-OPEN` | man page | moving-head | `2026-03-22` | `2026-04-20` | open-file-description precedent only; do not overfit Linux fd semantics into every ViewFS handle family |
| `REF-MAN7-DUP` | man page | moving-head | `2026-03-22` | `2026-04-20` | duplicate-vs-independent-reopen precedent only; exact `FD_CLOEXEC` details are not a ViewFS contract |
| `REF-LINUX-FLOCK` | man page | moving-head | `2026-03-22` | `2026-04-20` | lock-attaches-to-open-state precedent only; exact advisory-lock semantics are not a ViewFS contract |

| `REF-LINUX-OPATH` | man page | moving-head | `2026-03-23` | `2026-04-20` | locator/metadata-handle precedent only; do not overfit Linux `O_PATH` mechanics into every ViewFS handle family |
| `REF-LINUX-STATX` | man page | moving-head | `2026-03-23` | `2026-04-20` | metadata-via-current-handle precedent only; exact `statx` fields are not a ViewFS contract |
| `REF-LINUX-OPENTREE` | man page | moving-head | `2026-03-23` | `2026-04-20` | rooted-designation / detached-fragment precedent only; exact mount-fd mechanics are not a ViewFS contract |

| `REF-MAN7-EXEC3P` | man page | moving-head | `2026-03-23` | `2026-04-20` | launch-boundary inheritance precedent only; do not overfit POSIX exec cleanup details into all ViewFS launch families |
| `REF-MAN7-POSIX-SPAWN` | man page | moving-head | `2026-03-23` | `2026-04-20` | child-slot/file-action precedent only; exact POSIX spawn mechanics are not a ViewFS wire contract |
| `REF-MAN7-CLOSE-RANGE` | man page | moving-head | `2026-03-23` | `2026-04-20` | bulk close-on-exec shutter precedent only; exact Linux range semantics are not a ViewFS contract |
| `REF-MAN7-FCNTL` | man page | moving-head | `2026-03-23` | `2026-04-20` | `FD_CLOFORK` precedent only; Linux support gaps are cautionary shape, not product commitment |
| `REF-OPENBSD-FCNTL` | man page | moving-head | `2026-03-23` | `2026-04-20` | close-on-fork concrete precedent only; exact OpenBSD descriptor-flag behavior is not a ViewFS contract |

| `REF-FUCHSIA-FSARCH` | web docs | moving-head | `2026-03-23` | `2026-04-20` | multi-path namespace-mutation precedent only; do not overfit Fuchsia vnode-token/cookie mechanics into every ViewFS provider |
| `REF-FREEBSD-RIGHTS-LIVE` | man page | moving-head | `2026-03-23` | `2026-04-20` | source-vs-destination directory-rights precedent only; exact Capsicum right names are not a ViewFS wire contract |
| `REF-MAN7-RENAME` | man page | moving-head | `2026-03-23` | `2026-04-20` | rename/replace/exchange precedent only; exact `renameat2()` flags are not a universal ViewFS feature set |

| `REF-MAN7-MOUNTNS` | man page | moving-head | `2026-03-23` | `2026-04-20` | bind-propagation / peer-group precedent only; do not overfit Linux shared-subtree mechanics into every ViewFS backend |

| `REF-LINUX-OTMPFILE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | unnamed-object / publish-later precedent only; filesystem support details may drift |
| `REF-MAN7-LINKAT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | namespace-publication precedent only; exact capability requirements may vary by kernel/filesystem |
| `REF-OCI-DESCRIPTOR` | GitHub markdown | moving-head | `2026-03-23` | `2026-04-20` | descriptor-envelope precedent only; do not overfit OCI packaging semantics into ViewFS object-store design |

| `REF-FUCHSIA-HANDLES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | explicit handle-rights / duplicate-drop-rights precedent only; do not overfit Zircon object taxonomy into ViewFS handle classes |
| `REF-KITTY-SHELLINT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | shell-integration bootstrap caution only; exact kitty env/overlay details are not a ViewFS wire contract |
| `REF-SD-NOTIFY-BARRIER` | man page | moving-head | `2026-03-23` | `2026-04-20` | exact-run/barrier attribution precedent only; do not overfit systemd notification transport into ViewFS terminal protocol |

| `REF-FUCHSIA-LIFECYCLE` | web docs | moving-head | `2026-03-23` | `2026-05-01` | persistent-state-versus-running-authority precedent only; do not overfit Fuchsia lifecycle details into ViewFS continuity design |
| `REF-CONTOUR-OSC133` | web docs | moving-head | `2026-03-23` | `2026-04-20` | explicit prompt/command/output segmentation precedent only; exact OSC vocabulary is not a ViewFS wire contract |

| `REF-WINDOWS-TERMINAL-SHELLINT` | blog/web docs | moving-head | `2026-03-23` | `2026-04-20` | semantic prompt/output segmentation precedent only; exact Windows Terminal feature names may drift |
| `REF-MS-SECBOOKMARK-CVE2025` | security research blog | moving-head | `2026-03-23` | `2026-04-20` | security-scoped bookmark caution only; exploit details are precedent, not a ViewFS protocol contract |

| `REF-W3C-CAPURL` | web docs | semi-stable | `2026-03-23` | `2026-06-01` | capability-URL leak-risk precedent only; keep W3C web guidance as cautionary shape, not a ViewFS token format |
| `REF-OCAPN-LOCATORS` | GitHub spec doc | moving-head | `2026-03-23` | `2026-04-20` | sturdyref-locator precedent only; do not overfit OCapN URI syntax or swiss-num shape into ViewFS tickets |
| `REF-APPLE-APPSANDBOX-FILES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | security-scoped bookmark posture precedent only; exact Apple entitlement wording may drift |
| `REF-APPLE-SECBOOKMARK-ENABLE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | persistent bookmark opt-in precedent only; exact Apple API text may drift |
| `REF-ZCAP-LD` | web spec | moving-head | `2026-03-23` | `2026-04-20` | delegation/expiry/revocation wording is inspiration only; do not overfit current zcap wire details into ViewFS tickets |
| `REF-SEL4-MANUAL-LATEST` | PDF manual | moving-head | `2026-03-23` | `2026-05-15` | explicit mint/revoke precedent only; do not overfit seL4 CSpace mechanics into every ViewFS provider |
| `REF-CAPSICUM-HANDBOOK` | web docs | moving-head | `2026-03-23` | `2026-04-20` | capability-mode / fd-as-capability precedent only; keep exact FreeBSD wording as inspiration rather than contract |

| `REF-W3C-PERMISSIONS` | web spec | moving-head | `2026-03-23` | `2026-04-20` | permission-state vocabulary inspiration only; do not overfit browser-origin semantics |
| `REF-WICG-FSACCESS` | web spec | moving-head | `2026-03-23` | `2026-04-20` | permission query/request and repair-ladder inspiration only; do not overfit browser storage model |

| `REF-RATS-RFC9334` | RFC | stable | `2026-03-23` | `2026-06-01` | conceptual-message split precedent only; do not overfit remote-attestation workflow details |
| `REF-RATS-ENDORSEMENTS-DRAFT` | IETF draft | moving-head | `2026-03-23` | `2026-04-20` | endorsement/reference-value precedent only; draft status means wording may shift |
| `REF-IN-TOTO-ATTESTATION` | GitHub spec repo | moving-head | `2026-03-23` | `2026-04-20` | attestation-layering precedent only; exact JSON media types are not a ViewFS contract |
| `REF-SLSA-PROVENANCE` | web spec | moving-head | `2026-03-23` | `2026-04-20` | build-provenance precedent only; do not overfit software-build-only semantics |
| `REF-SLSA-VERIFY-V1` | web spec notes | moving-head | `2026-03-23` | `2026-04-20` | verification-separate-from-production precedent only |
| `REF-TUF-ROLES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | role/delegation precedent only; exact repository-role names are not a ViewFS contract |
| `REF-SIGSTORE-REKOR` | web docs | moving-head | `2026-03-23` | `2026-04-20` | transparency-log precedent only; public-log service details are not a ViewFS requirement |

| `REF-XDG-SESSION` | web docs | moving-head | `2026-03-23` | `2026-04-15` | long-lived session-handle and close-signal precedent only; do not overfit DBus object details |
| `REF-XDG-INHIBIT` | web docs | moving-head | `2026-03-23` | `2026-04-15` | request-vs-session-vs-monitoring-state precedent only; exact portal semantics are not a ViewFS contract |
| `REF-XDG-GLOBALSHORTCUTS` | web docs | moving-head | `2026-03-23` | `2026-04-15` | request-handle / session-handle / active-state split precedent only; exact shortcut taxonomy may evolve |

| `REF-HAIKU-FSMODULES` | web docs | semi-stable | `2026-03-23` | `2026-05-15` | live-query / virtual-query precedent only; do not overfit Haiku FS hook mechanics into ViewFS collection design |
| `REF-GNOME-SERVICES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | index-service / portal-gated-query precedent only; exact GNOME service names may drift |

| `REF-MCP-COMPLETION-20250618` | spec/web doc | moving-head | `2026-03-23` | `2026-04-20` | re-check completion reference/context/security wording before freezing candidate/packet vocabulary |
| `REF-LSP-COMPLETION-317` | spec/web doc | moving-head | `2026-03-23` | `2026-04-20` | re-check lazy resolve and insertion-field wording before freezing candidate-detail semantics |
| `REF-FISH-COMPLETIONS` | product docs | moving-head | `2026-03-23` | `2026-04-20` | re-check completion-condition wording before stronger candidate-shape claims |
| `REF-FISH-INTERACTIVE` | product docs | moving-head | `2026-03-23` | `2026-04-20` | re-check accept-word/autosuggestion wording before freezing insert-ladder UX |
| `REF-VSCODE-TERMINAL-API-TRUST` | product/API docs | moving-head | `2026-03-23` | `2026-04-20` | re-check command confidence/trust wording before freezing rerun-safety or packet-truth claims |
| `REF-PLAN9-PLUMBER4` | web docs | semi-stable | `2026-03-23` | `2026-05-15` | typed route-envelope precedent only; do not overfit Plan 9 port/rule mechanics into ViewFS packet law |
| `REF-OSC8-HYPERLINKS` | web gist/spec note | moving-head | `2026-03-23` | `2026-04-20` | hyperlink-as-cell-attribute precedent only; keep final typed-route semantics in ViewFS layer |
| `REF-LSP-DOCLINK-317` | spec/web doc | moving-head | `2026-03-23` | `2026-04-20` | re-check lazy-target/documentLink resolve wording before freezing entity-peel semantics |
| `REF-KITTY-HINTS` | product docs | moving-head | `2026-03-23` | `2026-04-20` | re-check hint matching/action customization wording before freezing route-slip UX |

| `REF-HTML-USER-ACTIVATION` | web spec | moving-head | `2026-03-23` | `2026-04-20` | user-action/consume-once precedent only; do not overfit HTML API classes into a universal ViewFS baton ABI |
| `REF-XDG-ACTIVATION-V1` | web protocol docs | moving-head | `2026-03-23` | `2026-04-20` | activation-token precedent only; exact token plumbing is compositor/portal-specific |
| `REF-XDG-INPUTCAPTURE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | enabled-vs-active control precedent only; exact trigger mechanics are not a ViewFS contract |
| `REF-MS-ALLOWSETFOREGROUND` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | foreground-transfer precedent only; exact Win32 conditions are inspiration, not ViewFS law |
| `REF-MS-COALLOWSETFOREGROUND` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | delegated foreground-eligibility precedent only; exact COM mechanics are not a ViewFS dependency |
| `REF-WAYLAND-XDGSHELL-USERACTION` | web protocol docs | moving-head | `2026-03-23` | `2026-04-20` | user-action-serial precedent only; keep final gesture-proof semantics in ViewFS layer |

| `REF-FUCHSIA-IO-RIGHTS` | web API docs | moving-head | `2026-03-23` | `2026-04-20` | re-check rights wording before freezing a normalized handle-rights vocabulary |
| `REF-RFC9110-ALLOW` | RFC/web spec | semi-stable | `2026-03-23` | `2026-05-15` | affordance-advertisement precedent only; do not overfit HTTP verb names into a universal ViewFS affordance ABI |

| `REF-MIMESNIFF` | web spec | moving-head | `2026-03-23` | `2026-04-20` | declared/computed MIME distinction precedent only; do not overfit browser fetch/context rules into the whole ViewFS type model |
| `REF-SHARED-MIME-INFO` | web spec | moving-head | `2026-03-23` | `2026-04-20` | desktop type-database precedent only; exact XML/glob/magic merge details may drift |
| `REF-APPLE-UTTYPE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | type-taxonomy/conformance precedent only; JS-rendered symbol details may drift |
| `REF-FDO-MIMEAPPS` | web spec | moving-head | `2026-03-23` | `2026-04-20` | handler-association/default-selection precedent only; desktop-env implementation details may drift |

| `REF-K8S-LABELS` | web docs | moving-head | `2026-03-23` | `2026-04-20` | selector-label precedent only; do not overfit Kubernetes object taxonomy into ViewFS metadata classes |
| `REF-K8S-ANNOTATIONS` | web docs | moving-head | `2026-03-23` | `2026-04-20` | arbitrary-metadata precedent only; do not overfit Kubernetes metadata shapes into ViewFS annotation storage |
| `REF-OCI-ANNOTATIONS` | web spec | moving-head | `2026-03-23` | `2026-04-20` | arbitrary-key/value metadata precedent only; exact OCI key namespaces are not a ViewFS contract |
| `REF-SELINUX-CONTEXTS` | vendor docs | semi-stable | `2026-03-23` | `2026-05-15` | policy-bearing label precedent only; do not overfit SELinux context tuple syntax into ViewFS policy labels |
| `REF-FIRST-TLP20` | standards/web docs | semi-stable | `2026-03-23` | `2026-05-15` | handling-boundary label precedent only; do not overfit TLP colors into ViewFS native label taxonomy |
| `REF-ITERM2-BADGES` | product docs | moving-head | `2026-03-23` | `2026-04-20` | dynamic badge-chrome precedent only; exact escape codes are not a ViewFS protocol contract |
| `REF-ITERM2-STATUSBAR` | product docs | moving-head | `2026-03-23` | `2026-04-20` | dynamic status-bar precedent only; exact widget list is product-specific |
| `REF-WEZTERM-RIGHT-STATUS` | product docs | moving-head | `2026-03-23` | `2026-04-20` | right-status chrome precedent only; exact Lua API details are not a ViewFS wire format |

| `REF-K8S-API-CONCEPTS-WATCH` | web docs | moving-head | `2026-03-23` | `2026-04-20` | watch-bookmark / resourceVersion / 410-reset precedent only; exact Kubernetes API query parameters are not a ViewFS wire contract |
| `REF-DROPBOX-DETECT-CHANGES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | folder-cursor / longpoll / reset precedent only; exact Dropbox endpoint names are provider-specific |
| `REF-WATCHMAN-CLOCKSPEC` | web docs | moving-head | `2026-03-23` | `2026-04-20` | logical-clock precedent only; exact clockspec syntax is not a universal ViewFS token format |
| `REF-APPLE-FSEVENTS-GUIDE` | archived web docs | semi-stable | `2026-03-23` | `2026-05-15` | rescan/root-change/event-id precedent only; archived Apple wording should not be treated as modern API law |

| `REF-RFC7232-CONDITIONAL` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | conditional-write / lost-update wording is load-bearing; exact header set is inspiration, not a ViewFS wire contract |
| `REF-GCS-PRECONDITIONS` | web docs | moving-head | `2026-03-23` | `2026-04-20` | generation/metageneration wording may evolve; object-store precondition precedent only |
| `REF-MDN-CREATEWRITABLE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | browser writer-mode wording may drift; writable-session precedent only |

| `REF-RFC9110-RANGE` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | range/206/recombination wording is load-bearing; exact HTTP header syntax is inspiration, not a ViewFS wire contract |
| `REF-RFC9111-INCOMPLETE` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | incomplete-response caching wording is load-bearing; exact cache directives are inspiration, not a ViewFS sparse-store ABI |
| `REF-STARGZ-OVERVIEW` | project docs | moving-head | `2026-03-23` | `2026-04-20` | lazy-pull / OCI-compat wording may evolve; precedent only |
| `REF-STARGZ-ESTARGZ` | project docs | moving-head | `2026-03-23` | `2026-04-20` | on-demand file/chunk fetch wording may evolve; precedent only |
| `REF-AWS-S3-OBJECT-ETAG` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | ETag/checksum wording may evolve; multipart/composite warning only |
| `REF-AWS-S3-MPU-OVERVIEW` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | multipart/full-checksum wording may evolve; object-store precedent only |
| `REF-AWS-S3-INTEGRITY` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | checksum-mode wording may evolve; integrity-layering precedent only |
| `REF-ZARR-V3-CORE` | web spec | moving-head | `2026-03-23` | `2026-04-20` | chunk-grid / codec wording may evolve; layout-metadata precedent only |


| `REF-RFC9110-IFRANGE` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | exact-basis/fallback wording is load-bearing; exact HTTP header syntax is inspiration, not a ViewFS wire contract |
| `REF-RFC3229-DELTAHTTP` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | delta/base-instance wording is load-bearing; exact 226/IM header syntax is inspiration, not a ViewFS wire contract |
| `REF-RFC3284-VCDIFF` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | source-window/target-window wording is load-bearing; exact binary format is inspiration, not a ViewFS mandatory codec |
| `REF-OSTREE-STATIC-DELTAS` | project docs | moving-head | `2026-03-23` | `2026-04-20` | exact static-delta wording may evolve; commit-pair and `from NULL` precedent only |
| `REF-ZSYNC-THEORY` | archived project docs | semi-stable | `2026-03-23` | `2026-05-15` | control-file/checksum wording may be brittle; local-byte-reuse precedent only |

| `REF-PLAN9` | paper/web docs | semi-stable | `2026-03-23` | `2026-06-01` | foundational per-process-namespace precedent only; do not overfit 9P/file-server mechanics into ViewFS object law |
| `REF-PLAN9-PLUMB` | web docs | semi-stable | `2026-03-23` | `2026-06-01` | typed routing-rule precedent only; do not overfit Plan 9 plumbing syntax into ViewFS transport law |

| `REF-SANDSTORM-POWERBOX` | Sandstorm docs | moving-head | `2026-03-23` | `2026-04-20` | mediation/candidate-fit wording may evolve; precedent only |
| `REF-PLAN9-IMPORT` | plan9port man page | moving-head | `2026-03-23` | `2026-04-20` | imported-fragment precedent only; exact command options are not a ViewFS contract |
| `REF-FOUNDATION-CAS` | paper copy | moving-head | `2026-03-23` | `2026-06-01` | archival CAS precedent is stable, but storage-economics wording should still be re-checked before quoting |
| `REF-LINUX-ACCESS` | man page | moving-head | `2026-03-23` | `2026-04-20` | exact-name reachability/search-permission precedent only; do not overfit POSIX directory semantics wholesale |
| `REF-WASI-P1-RIGHTS` | docs.rs | moving-head | `2026-03-23` | `2026-04-20` | browse-vs-open rights split is inspirational; exact constant names are not a final ViewFS API |

| `REF-FUCHSIA-CONNECT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | outgoing/exposed capability publication precedent only; do not overfit Fuchsia directory shapes |
| `REF-MCP-ROOTS` | web docs | moving-head | `2026-03-23` | `2026-04-20` | scope/catalog precedent only; no commitment to MCP roots transport or URI shape |
| `REF-DNSSD` | RFC/web docs | stable | `2026-03-23` | `2027-03-23` | browse/resolve separation precedent only; no commitment to network service discovery as a ViewFS transport |
| `REF-K8S-ENDPOINTSLICE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | freshness-scoped readiness precedent only; do not overfit Kubernetes endpoint lifecycle fields |

| `REF-GIT-PARTIAL-CLONE` | Git docs | semi-stable | `2026-03-23` | `2026-05-15` | promisor/missing-object precedent only; exact filter/protocol details are not a ViewFS wire contract |
| `REF-NIX-SSH-SUBSTITUTER` | Nix docs | moving-head | `2026-03-23` | `2026-04-20` | substituter/source-ladder precedent only; exact CLI and transport details may evolve |
| `REF-FUCHSIA-AVAILABILITY` | web docs | moving-head | `2026-03-23` | `2026-04-20` | route-expectation precedent only; exact Fuchsia availability taxonomy may evolve |
| `REF-GHOSTTY-CURSORCLICK` | product docs | moving-head | `2026-03-23` | `2026-04-20` | prompt-marking/cursor-move precedent only; exact config fields are product-specific |

| `REF-RFC6749-AUTHCODE` | RFC 6749 section 4.1.2 | stable | `2026-03-23` | `2027-03-23` | single-use, short-lived, client-bound claim precedent only; do not overfit OAuth redirect machinery |
| `REF-RFC9449-DPOP` | RFC 9449 | stable | `2026-03-23` | `2027-03-23` | sender-constraining / holder-bound precedent only; do not overfit OAuth/JWT wire details |
| `REF-ANDROID-PENDINGINTENT-SECURITY` | Android security docs | moving-head | `2026-03-23` | `2026-04-20` | replayable compact-authority artifact precedent only; exact API flags are Android-specific |

| `REF-RFC9470-STEPUP` | RFC / standards text | stable | `2026-03-23` | `2027-03-23` | step-up / recency challenge precedent only; do not overfit OAuth bearer challenge syntax into ViewFS wire contracts |
| `REF-OIDC-CORE-MAXAGE` | standards web spec | semi-stable | `2026-03-23` | `2026-06-01` | `max_age` / `auth_time` / `acr` recency precedent only; exact OIDC claim syntax is not a ViewFS schema |
| `REF-WEBAUTHN-3` | standards web spec | moving-head | `2026-03-23` | `2026-04-20` | user-presence / user-verification precedent only; exact authenticator flag layout may continue to evolve |
| `REF-ANDROID-KEYSTORE-AUTH` | Android security docs | moving-head | `2026-03-23` | `2026-04-20` | locally-held-but-auth-gated precedent only; exact Android API knobs are platform-specific |
| `REF-RFC7662-INTROSPECT` | RFC HTML | effectively stable | `2026-03-23` | `2026-06-01` | token current-state semantics are load-bearing for watch/status separation |
| `REF-RFC7009-REVOKE` | RFC HTML | effectively stable | `2026-03-23` | `2026-06-01` | revocation style trade-offs are precedent only; do not overfit OAuth token styles to ViewFS handles |
| `REF-RFC6960-OCSP` | RFC HTML | effectively stable | `2026-03-23` | `2026-06-01` | good/revoked/unknown plus freshness fields are strong status-carrier precedent |
| `REF-RFC5280-CRL` | RFC HTML | effectively stable | `2026-03-23` | `2026-06-01` | certificateHold/removeFromCRL are useful hold-resume precedent only |
| `REF-VC-BITSTRING-STATUS` | W3C Recommendation | moving-head | `2026-03-23` | `2026-05-15` | typed compact status carrier precedent; re-check if ViewFS ever imports more of the VC lifecycle stack |
| `REF-TUF-METADATA` | web docs | moving-head | `2026-03-23` | `2026-05-15` | metadata expiry/freshness wording is relevant; exact product/docs language may drift |
| `REF-TUF-SPEC` | web spec | moving-head | `2026-03-23` | `2026-05-15` | root-rotation / freeze-attack language is useful precedent; do not overfit the entire TUF role model |

| `REF-MACH-PORT-RIGHTS` | archived vendor docs | semi-stable | `2026-03-23` | `2026-06-01` | port-right-class precedent only; do not overfit Mach IPC object taxonomy into ViewFS object law |
| `REF-SEL4-GRANT` | PDF manual / API docs | semi-stable | `2026-03-23` | `2026-06-01` | live-authority-transfer-right precedent only; do not overfit seL4 endpoint/message ABI into ViewFS courier design |
| `REF-KITTY-FILETRANSFER` | product docs | moving-head | `2026-03-23` | `2026-04-20` | terminal-native transfer-lane precedent only; exact kitty protocol framing is not a mandatory ViewFS wire format |

| `REF-APPLE-FILEPROVIDER-SYNC` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | dataless/materialized locality precedent only; exact Apple sync lifecycle and API names may evolve |
| `REF-FUCHSIA-COMPONENT-NSENTRY` | FIDL reference docs | moving-head | `2026-03-23` | `2026-04-20` | explicit namespace-attach precedent only; exact FIDL/type names are not a ViewFS schema |

| `REF-ANDROID-SHARE-FILE` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | Intent/temporary-grant wording may evolve; route-envelope versus grant precedent only |
| `REF-ANDROID-URIPERMISSION` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | UriPermission field wording may evolve; grant-object precedent only |
| `REF-ANDROID-GRANTURIPERMISSION` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | manifest/path-subset wording may evolve; scoped-grant precedent only |

| `REF-CONFUSED-DEPUTY-HARDY` | PDF / paper mirror | semi-stable | `2026-03-23` | `2026-06-01` | foundational deputy-warning precedent only; do not overfit access-list-era details into ViewFS wire contracts |
| `REF-JEP506-SCOPEDVALUES` | OpenJDK JEP | moving-head | `2026-03-23` | `2026-04-20` | bounded-dynamic-scope precedent only; exact release/history details may evolve in OpenJDK docs |
| `REF-JAVA-SCOPEDVALUE-API` | vendor API docs | moving-head | `2026-03-23` | `2026-04-20` | bounded-binding/rebinding precedent only; exact Java API surface is not a ViewFS wire contract |
| `REF-PY-CONTEXTVARS` | language docs | moving-head | `2026-03-23` | `2026-04-20` | context-local/reset-token precedent only; exact Python object names are not a ViewFS schema |
| `REF-NODE-ASYNCLOCALSTORAGE` | runtime docs | moving-head | `2026-03-23` | `2026-04-20` | bounded async-context / context-bleed warning precedent only; exact Node API names are not a ViewFS protocol |
| `REF-ASPNET-HTTPCONTEXTACCESSOR` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | ambient-state caution precedent only; exact ASP.NET type names are not a ViewFS schema |

| `REF-ANDROID-VIRTUALFILES` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | virtual-file and alternate-MIME wording may evolve; representation-coercion precedent only |
| `REF-WIT-RESOURCE-HANDLES` | project docs | moving-head | `2026-03-23` | `2026-04-20` | component-model resource-handle wording may evolve; external-handle / owned-vs-borrowed precedent only |

| `REF-GHOSTTY-SHELL-INTEGRATION` | product docs | moving-head | `2026-03-23` | `2026-04-20` | shell-integration/manual-sourcing precedent only; exact Ghostty shell snippets are product-specific |
| `REF-POWERSHELL-PROFILES` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | startup-profile-as-script precedent only; exact host/profile matrix is PowerShell-specific |

| `REF-VSCODE-PROFILES` | product docs | moving-head | `2026-03-24` | `2026-04-20` | subsetted profile-content precedent only; exact VS Code profile payload classes may evolve |
| `REF-FISH-ABBR` | shell docs | moving-head | `2026-03-24` | `2026-04-20` | typed-only abbreviation precedent only; exact fish flags/functions are product-specific |
| `REF-NU-OVERLAYS` | shell docs | moving-head | `2026-03-24` | `2026-04-20` | explicit overlay-layer precedent only; exact Nushell commands/types are not a ViewFS schema |
| `REF-NU-CUSTOMCOMMANDS` | shell docs | moving-head | `2026-03-24` | `2026-04-20` | first-class custom-command precedent only; exact Nushell language features are not a ViewFS contract |
| `REF-NU-WHICH` | shell docs | moving-head | `2026-03-24` | `2026-04-20` | command-resolution explainability precedent only; exact Nushell output schema is not a ViewFS protocol |
| `REF-ZSH-ZLE` | shell manual | semi-stable | `2026-03-24` | `2026-06-01` | widget/keymap distinction precedent only; exact ZLE names are not a ViewFS schema |
| `REF-GHOSTTY-KEYTABLES` | product release notes | moving-head | `2026-03-24` | `2026-04-20` | explicit modal-key-table precedent only; exact Ghostty keybind syntax may evolve |
| `REF-GHOSTTY-CMDPALETTE` | product docs | moving-head | `2026-03-24` | `2026-04-20` | palette-action precedent only; exact Ghostty UI fields are product-specific |

| `REF-TREESITTER` | web docs | moving-head | `2026-03-24` | `2026-04-21` | incremental parse / error-recovery precedent only; do not overfit one grammar API or tree shape |
| `REF-LSP-DIAGNOSTICS-317` | web docs | semi-stable | `2026-03-24` | `2026-06-01` | diagnostic-channel precedent only; exact field names are not a ViewFS wire contract |
| `REF-SHELLCHECK` | web docs | moving-head | `2026-03-24` | `2026-04-21` | shell-diagnostic precedent only; exact rule catalog is not a ViewFS policy language |
| `REF-FISH-SYNTAX` | web docs | moving-head | `2026-03-24` | `2026-04-21` | inline shell-feedback precedent only; no commitment to fish parser/highlight semantics |
