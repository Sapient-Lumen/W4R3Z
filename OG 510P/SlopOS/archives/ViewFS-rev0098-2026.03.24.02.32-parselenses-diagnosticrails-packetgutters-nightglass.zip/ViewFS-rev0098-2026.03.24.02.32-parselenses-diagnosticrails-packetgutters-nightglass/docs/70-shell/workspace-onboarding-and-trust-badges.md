# Workspace onboarding and trust badges

Purpose: collect shell/terminal moves that make **opening a project feel great** without letting “open workspace” silently become “run workspace code”.

## North star
The ViewFS shell should make the first encounter with a workspace feel fast and rich:
- bind the tree,
- render its structure,
- show recent receipts and likely actions,
- preview tasks/debuggers/notebooks/env hooks,
- explain what is blocked,
- and let the user trust specific automation classes deliberately.

In other words: **browse first, trust later**.

## Best ideas worth stealing
- **REF-VSCODE-WORKSPACE-TRUST**: restricted mode as a first-class UX state rather than an obscure security preference.
- **REF-VSCODE-TASKS**: user-level tasks versus workspace tasks.
- **REF-VSCODE-JUPYTER-TRUST**: notebook execution and rich outputs should respect trust state.
- **REF-JETBRAINS-PROJSEC**: clear trust dialogs that name the risky classes (tasks/configurations executed during opening).
- **REF-DIRENV-ALLOW**: explicit allow/deny for per-directory env activation.
- **REF-DIRENV-REQUIREALLOWED**: re-approval after meaningful automation-file changes.
- **REF-WEZTERM-SHELL-INT**, **REF-ITERM-SHELLINT**, **REF-GHOSTTY-OSC133-OVERLAY**: semantic marks/zones/inspectors make state visible and navigable.
- **REF-WARP-BLOCKS** and **REF-WARP-CMDPALETTE**: block-based interaction plus one searchable action surface.

## Workspace opening states worth considering
A workspace tab/pane should probably advertise one of these:
- `browse-only`
- `tasks-blocked`
- `env-blocked`
- `debug-blocked`
- `agents-blocked`
- `notebook-exec-blocked`
- `trusted`
- `ambient-debt`

Those can be combined, but the important point is that the state is visible.

## Great onboarding flow
1. **Bind workspace** into a local view.
2. Show a **workspace card** with:
   - name / root bind source,
   - active view badge,
   - automation classes detected,
   - last trust state,
   - change summary since last trust,
   - obvious safe actions: browse, inspect, search, diff.
3. Keep automation rows **inspectable but blocked**.
4. Let the user trust:
   - one action now,
   - one automation class,
   - or the whole automation manifest.
5. Write a receipt/trust record that is separate from the workspace bind itself.

## Workspace card / inspector ideas
- **Automation manifest preview** showing tasks, env hooks, launchers, notebook kernels, agents, and custom tools.
- **Automation diff** since last trust.
- **Authority diff** showing what becomes newly executable if trust is granted.
- **Trust provenance** showing whether trust came from an explicit approval, an admin policy, or a parent/root policy.
- **Rebind + retrust split buttons** so access and execution are never conflated.

## Palette and command-line moves
The shell palette should support actions like:
- `bind workspace`
- `inspect automation`
- `trust tasks`
- `trust env hooks`
- `trust notebook exec`
- `revoke workspace trust`
- `show trust diff`
- `promote workspace recipe to user workflow`

A row should keep explicit badges for:
- `source: workspace` vs `source: user`
- `kind: task` / `env` / `debug` / `agent` / `note`
- `status: blocked` / `ready` / `stale` / `reapprove`

## Terminal niceties that would feel great
- **Restricted prompt chrome** when the current workspace is browse-only.
- **Per-block trust badges** on commands that came from workspace automation.
- **Receipt cards** for trust and revoke events.
- **Hover/inspect overlay** explaining why a task is blocked.
- **Reapproval marks** pinned to the prompt when automation files changed.
- **Workspace-local recent directories and tasks** that remain suggestive even when blocked.
- **Trust-aware notebooks** where cells can be read, diffed, and commented on before execution is enabled.

## One especially good trick to steal
Separate **workspace-suggested workflows** from **user-owned workflows**.
A workspace recipe can be:
- previewed,
- inspected,
- run once with a receipt,
- or promoted into a user-owned safe workflow.

That keeps convenience without silently letting repository content rewrite the shell’s automation behavior.

## Anti-goals
- a workspace opening flow that immediately sources env hooks or runs tasks
- hiding trust state in a settings page instead of the active shell surface
- replaying blocked workspace automation because “it worked last session”
- blurring workspace recipes and user-owned workflows into one history stream
- trusting a workspace just because it appears in recents or a palette
