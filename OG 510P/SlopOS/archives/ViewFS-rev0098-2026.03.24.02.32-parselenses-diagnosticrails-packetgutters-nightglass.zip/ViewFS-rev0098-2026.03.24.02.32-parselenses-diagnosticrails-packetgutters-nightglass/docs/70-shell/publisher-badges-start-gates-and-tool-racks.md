# Publisher badges, start gates, and tool racks

This note collects shell/terminal ideas for helper lifecycles that stay truthful.

The key seam:
**publisher trust ≠ installed helper package ≠ configured helper/server definition ≠ enabled state ≠ start approval ≠ live brokered session ≠ request-scoped tool selection ≠ durable receipt/history**.

If those collapse, the shell will lie in exactly the worst way:
- an installed helper will feel live when it is not,
- a live helper will feel selected for the current request when it is not,
- a remembered enable bit will feel like current approval,
- and a stale receipt will feel like standing authority.

## Shell moves worth stealing

### 1. Publisher badge
Every helper card should show:
- publisher / marketplace / source origin,
- whether that origin is currently trusted,
- whether install came from profile, workspace, import, or direct source.

That keeps “I trusted the carrier once” separate from “this helper is safe to start right now”.

### 2. Installed card, not just an on/off toggle
A helper card should distinguish:
- installed,
- configured,
- enabled,
- start-approved,
- live,
- selected for this request.

The card should make these look like different states, not a single “available” bit.

### 3. Start gate drawer
Before a helper becomes live, the shell should be able to show:
- what source defined it,
- what config changed since last run,
- whether trust was reset,
- whether a stronger broker or org policy blocks the start,
- what narrower start options exist (`start once`, `start sandboxed`, `start with read-only helper scope`, `history only`).

### 4. Live-session beacon
When a helper is actually live, show:
- runtime identity,
- where it is running,
- which pane/session owns it,
- current network/filesystem limits if sandboxes apply,
- whether it is broker-authoritative or merely local.

This should be loud enough that “live now” cannot be mistaken for “merely installed”.

### 5. Tool rack
A live helper may expose many tools/resources/prompts.
The shell should present a **tool rack** for the current request that says:
- which live helpers are available,
- which tools are selected for this request,
- which ones are visible but disabled,
- which require fresh approval,
- which are blocked by a higher ceiling.

### 6. Trust-reset spark
If config drift or trust reset means a helper must be re-approved before start, the shell should show a small but loud spark:
- `config changed since last live session`,
- `trust reset`,
- `publisher no longer trusted`,
- `session-only grant expired`.

### 7. Lifecycle receipts
Receipts should preserve the lifecycle truth:
- `installed only`,
- `configured only`,
- `enabled but not started`,
- `start denied`,
- `started for this session`,
- `tool selected for this request`,
- `stopped`,
- `revoked`,
- `history only`.

## Why this could make the terminal super awesome
A terminal that can tell the difference between installed helpers, live helper sessions, and request-scoped tool selection becomes dramatically more truthful and more powerful:
- you can stage lots of helpers without pretending they are running,
- you can keep live helper state visible in pane chrome,
- you can replay with helper state stripped or re-approved,
- and you can debug “why didn’t the tool run?” without reading hidden settings files.

## Guardrails
- installed helper presence must not imply standing authority,
- enablement state must stay separate from shared configuration,
- start approval must survive trust resets and config drift checks,
- request-scoped selection must not silently widen to all tools from a live helper,
- stopping a helper must visibly end its live-session beacon,
- receipts must never launder historical live state into current live state.
