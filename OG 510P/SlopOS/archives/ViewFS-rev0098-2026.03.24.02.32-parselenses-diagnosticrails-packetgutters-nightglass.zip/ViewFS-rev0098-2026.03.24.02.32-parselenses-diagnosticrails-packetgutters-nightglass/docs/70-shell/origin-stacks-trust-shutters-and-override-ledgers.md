# Origin stacks, trust shutters, import trays, and override ledgers

Purpose: make the ViewFS shell feel **super awesome** while staying brutally honest about which source is actually allowed to matter.

## North star
A great ViewFS shell should let a user see, at a glance:
- **who authored this input** — owner/org, user/profile, workspace, imported helper, history, mediator, shell-local
- **whether it is currently admissible** — trust shutter open or closed
- **what actually won** — the effective active state
- **what got overridden or withheld** — explicit loser reasons
- **what is only imported or historical** — visible, useful, but not live truth

That is much better than a shell that only knows “setting present” and “something overrode it somewhere.”

## Shell moves worth stealing

### 1. Origin stack drawer
Steal from Git’s origin/scope inspection and VS Code’s customization diagnostics.

A compact drawer should show:
- source class
- scope/lane
- file or receipt origin when appropriate
- trust posture
- whether the source is active, overridden, withheld, imported-only, or history-only

Super-awesome move:
- one keystroke opens the current pane/block’s origin stack from prompt chrome.

Guardrail:
- origin stack inspection is not an adoption or override act.

### 2. Trust shutter badge
Steal from Workspace Trust and `restrictedConfigurations`.

A small badge should say things like:
- `workspace visible, values withheld`
- `import present, review required`
- `profile active`
- `org ceiling active`

Super-awesome move:
- the badge can open straight into the exact reason a source is withheld.

Guardrail:
- opening the shutter UI must not itself grant trust or promote the source.

### 3. Import quarantine tray
Steal from MCP discovery/import posture.

When the shell sees helper material from another app, another workspace, or old receipts/history, it should land in a quarantine tray that clearly says:
- imported from where
- not active yet
- which scopes it could ever request
- what trust/review steps would be needed before it matters

Super-awesome move:
- let the user compare imported proposals against current local/profile/org state before promoting anything.

Guardrail:
- imported helper material never silently becomes active just because discovery is enabled.

### 4. Override ledger
Steal from enterprise policy overrides plus Deno-style deny/audit posture.

A ledger should answer:
- what source won
- what source lost
- whether it lost by precedence, explicit deny ceiling, or closed trust gate
- whether the losing source remains visible as advice only

Super-awesome move:
- “why didn’t this win?” becomes one keystroke away instead of a debugging ritual.

Guardrail:
- the ledger explains precedence; it is not itself an override surface.

## Prompt chrome / pane chrome ideas
- small **winner chip**: `org`, `profile`, `workspace-withheld`, `imported-only`, `history-only`
- **trust shutter pip** next to the winner chip: `open`, `closed`, `review`, `imported`
- **loser count badge** that opens the override ledger
- **import spark** when new helper material has been discovered but not reviewed

## Result-card ideas
A result card should be able to say:
- `workspace proposal visible, withheld by trust gate`
- `profile preference active; workspace value ignored`
- `owner/org ceiling active; local widening blocked`
- `imported helper reviewed, not activated`
- `history preserved; no live source changed`

## Notebook / replay ideas
- notebook cells should preserve the source stack as history only
- replay should compare recorded source stack versus current source stack before reuse
- imported helper material revived from history should land in the import tray, not in active state
- `receipt only` should remain a first-class honest outcome when source precedence or trust posture no longer matches

## Terminal protocol hints
The terminal protocol likely wants events for:
- **source stack** (sources present + scopes)
- **trust gate state** (open/closed/review/withheld)
- **effective winner** (authoritative current source)
- **override reasons** (precedence / deny / trust shutter)
- **import tray updates** (new discovered helper material)

That lets semantic terminals render rich source-aware UX without scraping text.

## What to avoid
- silently promoting imported helper configs into active truth
- treating trust-state changes as if they were source edits
- hiding owner/org ceilings behind generic “managed” badges with no lane/source detail
- letting history or receipt replay quietly outrank current local or org state
- collapsing “visible”, “trusted”, “active”, and “historical” into one single badge
