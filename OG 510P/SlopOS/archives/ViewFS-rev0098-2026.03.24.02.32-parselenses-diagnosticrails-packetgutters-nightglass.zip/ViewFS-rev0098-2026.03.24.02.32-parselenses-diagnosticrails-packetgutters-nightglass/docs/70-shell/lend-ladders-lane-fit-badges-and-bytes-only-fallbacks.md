# Lend ladders, lane-fit badges, and bytes-only fallbacks

One of the nicest shell moves available to ViewFS is to stop treating `share`, `send`, `copy`, `drop`, and `export` as one flattering verb.
This note collects shell/terminal ideas for the sender-side seam between **held here**, **duplicate locally**, **lend live**, **export one weaker representation**, and **history only**.

## 1. Lend ladders instead of one fake share action

For any object card, block attachment, or selected result, the shell should be able to render a small ladder like:
- `held only`
- `duplicate locally`
- `lend live`
- `lend narrowed`
- `projected doc`
- `bytes only`
- `receipt only`
- `history only`

The winning rung should be visible before the user commits.
This turns a vague `share` click into an honest route choice.

## 2. Lane-fit badges

The shell should carry tiny badges for the actual lane that fits now, such as:
- `local copy`
- `socket lend`
- `portal export`
- `tty transfer`
- `bytes snapshot`
- `projected doc`
- `none`

These badges should explain *why* the lane fits and *why* stronger lanes do not.

## 3. Bytes-only fallbacks should feel like a successful narrower choice

When an exact live lend is impossible, the shell should not just say `cannot share`.
It should be able to say:
- `live lend unavailable here`
- `bytes-only export available`
- `projected doc export available`
- `claim ticket available`

That is a much better user experience and a much more honest capability story.

## 4. Same-object versus new-representation drawers

Before send/export, a drawer should explain whether the receiver will get:
- another live reference to the same underlying thing,
- a narrowed live reference,
- a new representation of the same content,
- a projected document view,
- or only a receipt/history artifact.

This is the sender-side equivalent of a trustworthy route sheet.

## 5. Share receipts should preserve lane truth

After the act, the receipt row should say exactly what happened:
- `duplicated locally`
- `live lend via socket`
- `portal-exported document`
- `bytes snapshot sent`
- `TTY transfer started`
- `receipt copied only`

That makes later transcript review and replay far more honest.

## 6. Why-not-send drawers

A blocked send/share/export should be able to explain:
- `held here, but not duplicable`
- `duplicable locally only`
- `live lend forbidden across this boundary`
- `portal export required`
- `bytes snapshot available`
- `history only`

This is exactly the kind of shell honesty that ordinary desktop surfaces almost never provide.

## 7. Super-awesome terminal moves worth stealing

- **send-preview ghosts** that show `receiver gets exact live thing` versus `receiver gets new bytes`.
- **lane-fit gutters** attached to command blocks and drag/drop flows.
- **share sheets** that unify clipboard, drag/drop, pane-to-pane handoff, app export, and remote-terminal transfer under one truth-preserving chooser.
- **TTY transfer badges** so a terminal-native transfer session is visible as its own lane instead of as clipboard folklore.
- **post-send compare drawers** that let the user inspect `same object`, `new representation`, `portal projection`, or `receipt only` after the fact.

References: REF-MACH-PORT-RIGHTS, REF-SEL4-GRANT, REF-UNIX-SCMRIGHTS, REF-WAYLAND-DATADEVICES, REF-XDG-FILETRANSFER, REF-KITTY-FILETRANSFER.
