# Label chips, selector rails, and trusted badges

The future ViewFS shell should feel rich with labels **without** letting labels quietly become policy, authority, or object identity.
That means separating at least four visible classes:
- advisory annotation chips,
- selector-safe labels,
- policy-bearing labels,
- shell-owned trusted badges.

## What the shell should make obvious

### 1. Annotation chips are just notes unless promoted
A chip sourced from freeform metadata should look and behave like a note.
It may still be useful for provenance, explanation, or UI filtering, but it should not automatically become a saved-query key or a routing decision.

### 2. Selector-safe labels should be visibly narrower
Some labels are compact, normalized, and safe to use in grouping/filtering.
Those should have a visibly different posture such as:
- `selector safe`
- `queryable`
- `placement-local`
- `object-wide`

That makes smart baskets, freeze sets, and selector-building much more trustworthy.

### 3. Policy labels should render in stronger chrome
If a label affects handling or current posture, it should not be buried among decorative chips.
Examples:
- `quarantined`
- `review required`
- `sensitive`
- `export blocked`
- `local-only`

Those should live in trusted shell chrome with provenance and freshness labels.

### 4. Badges should explain themselves
A visible title/badge/right-status label should be able to answer:
- `rendered by shell`
- `reported by provider`
- `derived from metadata`
- `policy-backed`
- `history only`

That keeps powerful chrome from becoming spooky.

## Super-awesome product moves

### Label ledger
A side drawer that shows one row per label-like thing with columns such as:
- class (`annotation`, `selector`, `policy`, `badge`, `receipt`)
- origin (`user`, `provider`, `portal`, `shell`, `history`)
- scope (`object`, `placement`, `pane`, `session`)
- freshness (`current`, `needs refresh`, `history`)
- safe actions (`copy text`, `use in selector`, `inspect policy`, `open receipt`)

### Selector rail composer
When building a smart basket or filter, the shell should only offer selector-safe labels directly.
Everything else should require an explicit `promote to selector` review step or stay unavailable.

### Trusted badge shutters
The shell should have a stronger badge lane for policy-bearing truths.
Clicking one should open a drawer with:
- why the badge is present,
- who asserted it,
- whether it affects current handling,
- and what the next honest step is.

### Badge pin/follow modes
For volatile status labels, the shell should let the user choose:
- `follow current`
- `pin snapshot`
- `receipt only`

That is a nice way to keep dynamic chrome useful without lying about freshness.

### Copy ladders
Copying a label should be explicit:
- copy visible text
- copy selector expression
- copy metadata reference
- copy receipt

Different copy acts should produce different artifacts.

## Guardrails

- annotation chips must not silently become selector truth;
- selector labels must not silently become handling policy;
- policy labels must not hide inside decorative chip clouds;
- trusted badges must not masquerade as canonical object metadata;
- old badge receipts must not silently become current policy or current query truth.
