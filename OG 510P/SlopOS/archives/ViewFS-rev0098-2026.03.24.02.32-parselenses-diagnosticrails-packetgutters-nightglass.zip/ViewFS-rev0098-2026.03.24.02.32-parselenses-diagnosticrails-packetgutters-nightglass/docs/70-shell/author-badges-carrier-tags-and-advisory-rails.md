# Author badges, carrier tags, and advisory-only rails

Purpose: collect shell/terminal ideas for the next source-layering seam without freezing shell syntax.

ViewFS can be much more ambitious if it clearly distinguishes:
- who **authored** the live answer,
- what merely **carried** candidate material here,
- what is still behind a **trust gate**,
- and what is only an **advisory rail**.

## 1. Author badge beside the prompt / pane title
Every pane should be able to show a compact current-source badge such as:
- `auth: org`
- `auth: user`
- `auth: one-shot adopt`
- `auth: none (receipt only)`

Great effect:
- users can tell whether the live state came from a durable higher source or a local one-shot adoption.

Guardrail:
- author badges are about the current winner, not every visible carrier.

## 2. Carrier tags on cards and drawers
Every proposal/result/receipt card should be able to show where material came from:
- `carried by plugin`
- `carried by workspace`
- `carried by parent repo`
- `carried by history`
- `carried by receipt`

Great effect:
- trusted carriers stop being invisible;
- users can inspect “why did this suggestion even appear here?” without mistaking that for policy truth.

Guardrail:
- a carrier tag should never look like an adoption badge.

## 3. Advisory-only rails
Some rails should be visibly non-authoritative by design.
Examples:
- history-derived repair suggestions
- imported helper bundles awaiting review
- workspace or parent-repo suggestions in restricted mode
- plugin-provided convenience actions that are still below a local ceiling

Great effect:
- the shell gets smarter without becoming a hidden second policy engine.

Guardrail:
- actions launched from an advisory rail must still cross an explicit adoption gate if they would change active authority.

## 4. Trust-tunnel warnings
A trusted carrier can still be carrying something that is not eligible to author active state.
Examples:
- a trusted plugin surfaces a new helper server/config,
- a trusted parent repo surfaces AI customization/hook material,
- a trusted profile imports a bundle that is still only advisory here.

Great effect:
- users learn the difference between “this arrived through a trusted tunnel” and “this may author the current answer.”

Guardrail:
- trust-tunnel warnings should explain the next safe step, not just flash yellow.

## 5. Authorability fuse drawer
A single keystroke should answer:
- can this source class author a ceiling here?
- can it author a trust gate here?
- can it only propose?
- can it be adopted once/session/workspace/profile?
- what higher ceiling or gate is stopping it?

Great effect:
- it turns “why didn’t this take effect?” into an inspectable object instead of a guess.

Guardrail:
- the drawer is explanatory unless the user explicitly enters an adoption/review path.

## 6. Winner/loser split that names both author and carrier
Override ledgers should not stop at “who lost.” They should say:
- `winner authored by org`
- `loser carried by plugin, advisory only`
- `loser carried by workspace, trust gate closed`
- `loser carried by history, never authorable`

Great effect:
- the shell tells the truth about both precedence and admissibility.

Guardrail:
- “lost” should distinguish `blocked by ceiling`, `blocked by gate`, and `not authorable`.

## 7. Activation receipts should preserve the split
When something actually becomes active, the receipt should say at minimum:
- who authored the active result,
- what carried the proposal,
- what gate opened or stayed closed,
- what stayed advisory-only,
- whether anything broader was refused and narrowed.

Great effect:
- receipts become good debugging tools instead of just a yes/no log.

Guardrail:
- receipts are history, not a silent live source.

## 8. Terminal-native protocol hints
Steal from REF-WEZTERM-SHELL-INT and REF-GHOSTTY-OSC133-OVERLAY.

Use terminal metadata for:
- author badge in prompt chrome,
- carrier tags in block headers,
- one-keystroke authorability drawer,
- trust-tunnel warning overlays,
- receipt cards that preserve advisory-only state.

Great effect:
- the terminal becomes source-aware without screen-scraping scrollback.

Guardrail:
- terminal metadata should expose shell state, not redefine authority semantics.
