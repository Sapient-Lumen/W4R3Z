# Origin badges, trust ladders, and safe-open rails

Goal: make the ViewFS shell feel safer and more delightful by showing **where something came from**, **why it is guarded**, and **what the next allowed action is**.

## Principle
The shell should make risky objects easy to inspect and hard to launder.

That means users should see, at a glance:
- origin,
- current risk/quarantine state,
- whether a click will `peek`, `open safe`, `request clear`, `launch route`, or only show a receipt,
- and whether the action will produce a new derivative artifact.

## High-upside ideas

### 1. Origin badges everywhere they matter
Rows, breadcrumbs, palettes, and object cards can carry compact badges such as:
- `net`
- `mail`
- `transfer`
- `workspace`
- `local`
- `unknown`

These should be hints plus drill-down, not giant warning banners all the time.

### 2. Trust ladder instead of one scary yes/no banner
A small ladder is more honest than a single “blocked / allowed” bit:
- `receipt only`
- `quarantined`
- `peek ready`
- `safe-open ready`
- `clear requested`
- `cleared-local`
- `launchable`

That gives the shell a better vocabulary than generic “permission denied” or “double-click to trust.”

### 3. Default click = safest rich action
For a risky document-like object, Enter/click should prefer:
- `peek`
- then `open safe`
- and only later `request clear` or `launch fully`

Users still move fast, but the first action is observational instead of trust-mutating.

### 4. “Why is this blocked?” should be first-class
Every risky object should offer an explain panel that can say things like:
- downloaded from network last week,
- arrived through transfer session,
- code-bearing object in a quarantined state,
- safe-open available,
- clear would affect exactly one object,
- this notebook/workflow block is `receipt only` and does not carry live authority.

This is a great place to reuse receipt cards and authority diffs.

### 5. Safe-open rails should feel smooth, not punitive
A safe-open flow can still feel excellent:
- fast peek pane,
- side-by-side compare,
- searchable extracted text,
- disposable editing surface,
- `export derivative` button,
- `copy route sheet`,
- `copy trust receipt`,
- and visible cleanup state.

### 6. Risk state should survive into history and palettes
If an object was quarantined or only opened through a safe-open lane, history should remember that class.
Palette rows should not lazily downgrade into “just a file.”

### 7. Trust actions deserve receipt cards
When the user clears or trusts something, the shell should render a compact card with:
- object summary,
- previous state,
- new state,
- reason,
- scope,
- and whether a new derivative was created.

Those cards are valuable for collaboration and audit without exporting live authority.

### 8. Workspace onboarding should reflect origin and trust separately
A workspace opened from a transfer or download should show:
- workspace access state,
- automation trust state,
- object-origin summary,
- and whether tasks/notebooks/agents are still inert.

This keeps browse-first / trust-later legible.

### 9. Great keyboard verbs
The shell could eventually have concise verbs like:
- `peek`
- `open-safe`
- `explain-risk`
- `request-clear`
- `export-sanitized`
- `show-origin`
- `copy-receipt`
- `rebind-safe`

Not final syntax—just the shape of a good product.

## Tiny protocol ideas worth stealing
The shell-to-terminal protocol may eventually want metadata like:
- origin class,
- risk/quarantine state,
- preferred safe action,
- whether clear is available,
- whether the current object is code-bearing or document-like,
- and whether the current row is only a receipt.

This would make badges and action hints much more truthful.

## Product steals worth keeping in mind
- downloaded-file trust UX from Gatekeeper / MOTW systems,
- isolated-open ideas from Application Guard,
- concise state badges and block cards from modern terminals,
- and explicit “safe preview first” behavior from preview systems.

## Anti-goals
- a single giant “trust me” button that mutates too much at once
- clearing quarantine just because preview succeeded
- forgetting risk state in notebooks, recents, or palettes
- path-wide trust that silently widens what a later click can do
- making the terminal feel like a security lecture instead of a precise instrument
