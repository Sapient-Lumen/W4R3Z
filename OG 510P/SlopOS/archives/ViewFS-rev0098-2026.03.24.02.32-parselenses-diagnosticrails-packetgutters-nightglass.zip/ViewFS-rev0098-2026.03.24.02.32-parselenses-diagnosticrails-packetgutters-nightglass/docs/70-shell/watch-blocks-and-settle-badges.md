# Watch blocks, settle badges, and scoped live panes

Goal: make the ViewFS shell feel alive and delightful **without** pretending that file-watch feeds are perfect truth or silent authority.

## Principle
A great watch UI should feel:
- immediate,
- scoped,
- typed,
- honest about loss/degradation,
- and easy to rebuild.

The shell should never imply that “the watch pane is quiet” means “the world is unchanged.”

## High-upside ideas

### 1. Watch blocks as first-class transcript objects
A command like `watch`, `follow`, or `live` should render as a **watch block** with:
- target scope (`dir`, `view`, `workspace`, `query`),
- provider badge,
- health state,
- last event time,
- current rebuild epoch,
- and quick actions (`pause`, `rebuild`, `inspect scope`, `open route sheet`).

The block is a live UI surface, while the saved transcript only keeps a **WatchReceipt** summary.

### 2. Settle badges instead of false certainty
Borrow from build systems and file watchers:
- `settling` when many changes are arriving,
- `stable` after a quiet window,
- `overflow` when the incremental feed is no longer trustworthy,
- `rebuild required` when the shell has switched to snapshot refresh,
- `remote-risk` when the backing provider is known to be flaky for watching.

That is much more truthful than a single “watching…” spinner.

### 3. Scope cards and authority ladders
Every live pane should let the user hit one key to see:
- what handle/view/query powers the watch,
- whether the watch is incremental or rebuilt,
- what rights the pane does **not** have,
- and what would require an explicit rebind or portal grant.

### 4. Pulse cards instead of raw event spam
The default UX should probably summarize bursts into compact cards:
- `12 changes settled in /work/docs`
- `query refreshed: 3 added, 1 removed`
- `workspace state stale; rebuild requested`
- `provider dropped events; last good epoch 47`

Then the user can expand into the raw event list if needed.

### 5. Live smart folders with truth badges
A query-backed pane can be wonderful if it shows:
- query text or predicate,
- scope,
- freshness,
- partial coverage warning,
- and whether the current list is incremental or rebuilt.

This avoids recreating ambient inventory under the banner of “smart folders”.

### 6. Diff tickers and compare jumps
A watch block could support:
- jump to newest additions,
- jump to removals,
- compare last stable snapshot to current snapshot,
- pin a baseline and watch drift from it.

Very powerful, but still rooted in explicit scope and rebuildable state.

### 7. Notification tray as receipts, not secrets
The shell can keep a sidebar of recent watch pulses/receipts:
- changed objects,
- affected scope,
- degraded states,
- rebuild completions,
- user acknowledgements.

The tray should remember what happened without silently carrying live subscriptions across restore/share.

### 8. Watch-aware palettes and completions
Palette rows can be amazing when they show:
- `live watch`,
- `receipt only`,
- `rebuild needed`,
- `scope gone`,
- `provider unsupported`.

That makes suggestions fast **and** truthful.

## Tiny protocol ideas worth stealing
The shell-to-terminal protocol may eventually want metadata such as:
- watch block start/end,
- watch scope descriptor,
- health state changes,
- last stable timestamp,
- rebuild requested/completed,
- provider and coverage class.

Not final names—just a reminder that watch UX gets much better once status is explicit.

## Anti-goals
- a green dot that lies about freshness
- hidden background rescan work with no UI status
- transcripts that silently reactivate live watches on replay/share/restore
- generic raw-path watch panes that ignore scope/type/provider
- treating every change feed as if it were lossless and globally authoritative
