# Checkpoints, forks, and time-travel workspaces

Goal: make experimentation feel **cheap, fast, and reversible** without lying about what is merely local, what is replicated, and what is actually publishable or activatable.

## Principle
The shell should make it obvious whether an action:
- captured a local checkpoint,
- created a writable fork/worktree,
- moved a branch/head,
- exported a replication stream,
- promoted a publish candidate,
- pinned something for rollback,
- or changed what will become live next.

Great UX here is mostly **cheap checkpoints + explicit class badges + excellent diff/restore flows**.

## High-upside ideas

### 1. One-keystroke checkpoints
The shell should make “checkpoint before I try this” almost frictionless.
A good row/card could show:
- source workspace/view,
- checkpoint label,
- whether it is read-only,
- diff against current head,
- and whether it is local-only or already exported somewhere.

### 2. Instant forks/worktrees
Borrow the best part of `git worktree`: let a user spin up a new writable workspace from a checkpoint without forcing branch folklore onto every object.
A fork card should show:
- parent checkpoint,
- current branch/head if any,
- trust state,
- retention/pin state,
- and whether live imports/grants were re-requested or intentionally omitted.

### 3. A timeline that tells the truth
Time travel UI should badge rows like:
- `checkpoint`
- `fork`
- `branch move`
- `replicated`
- `publish candidate`
- `pinned`
- `active next`
- `receipt only`

This is much better than a vague “history” lane.

### 4. Diff everywhere
A terminal is unusually good at compact compare views. Useful compares include:
- current workspace vs last checkpoint,
- fork vs parent checkpoint,
- publish candidate vs active release,
- activation target vs current live state.

### 5. Rewind previews, not blind rollback
Before a rollback or activation change, show:
- what becomes live,
- what stays pinned,
- what local forks are unaffected,
- and what live handles/grants will not be recreated automatically.

### 6. Promotion lanes
A nice shell flow would separate:
- **checkpoint now**
- **fork for experiment**
- **mark as publish candidate**
- **promote / sign / pin**
- **activate next**

That turns “time travel” into a real working style instead of a rescue-only feature.

### 7. Backups/replication as a visibly different rail
Replication should feel first-class, but distinct. A row should say:
- destination,
- full vs incremental,
- source checkpoint/ref,
- verification status,
- and whether it is just a transport receipt or a local restorable copy.

### 8. Cheap branchy experimentation for non-Git things
One underused opportunity is giving normal object trees the feeling of branches/worktrees:
- compare two forks,
- open both side by side,
- copy one result into the other through explicit plumb/portal actions,
- then either discard, checkpoint, or publish.

### 9. “What would I lose?” inspector
Before dropping a checkpoint or fork, the shell should answer:
- Is this only local?
- Is it replicated elsewhere?
- Is it pinned for rollback?
- Is some publish candidate still based on it?
- Will any named head become dangling?

### 10. Delightful keyboard flow
Plausible future verbs / shortcuts:
- `c` → checkpoint current row/workspace
- `f` → fork into new worktree
- `D` → diff against parent or chosen checkpoint
- `m` → move/repoint current head
- `p` → mark publish candidate
- `P` → promote/pin
- `a` → activation preview
- `r` → replicate/export stream
- `u` → undo last head move or restore last checkpoint bind

Not final syntax—just the shape of an excellent product.

### 11. Receipts should stay shareable and non-bearer
Checkpoint cards, replication receipts, and activation previews should be easy to paste into transcripts or notebooks.
But they should stay receipts, not hidden live authority.

## Tiny protocol ideas worth stealing
The shell-to-terminal protocol may eventually want metadata like:
- checkpoint/fork/publish class,
- parent checkpoint or parent head,
- diff summary,
- replication state,
- pin/retention state,
- activation candidacy,
- and whether a row is only a receipt.

That would make badges, timelines, compare panes, and safe replay much more truthful.

## Product steals worth keeping in mind
- cheap snapshot/clone workflows from APFS, ZFS, and Btrfs,
- worktree-style multi-branch ergonomics from Git,
- explicit deployment/pin/rollback lanes from OSTree/boot-environment tooling,
- and the “forget vs prune” honesty of backup tools.

## Anti-goals
- one generic “history” view that hides the difference between checkpoints, forks, backups, and publish candidates
- rollback that silently tries to recreate external live authority
- calling an exported backup stream “just another local checkpoint”
- calling a local experiment “published” because it happens to be cheap to clone
- turning a gorgeous time-travel UI into a fuzzy authority model
