# Semantic marks, object links, and inspect overlays

Purpose: collect terminal/shell ideas that make ViewFS feel unusually powerful **because** the protocol is explicit, not because the UI is guessing.

This note is about interaction patterns, not final escape-sequence law.

## Lessons worth stealing

### 1. Prompt marks are better than scrollback archaeology
- REF-ITERM-SHELLINT and REF-WEZTERM-SHELL-INT show that once the shell reports prompt/input/output boundaries, the terminal can jump between commands, select one command's output, and recover working-directory context.
- REF-GHOSTTY-SHELLINT and REF-GHOSTTY-OSC133-OVERLAY show that shells and terminals benefit from being able to inspect the semantic regions directly.

Implication for ViewFS:
- every command block should be a first-class object with a visible start/end/exit-status boundary.

### 2. Hyperlinks are useful when they point at typed objects, not just URLs
- REF-ITERM-OSC8 shows that terminals can expose OSC 8 hyperlinks directly in output.
- ViewFS should use that affordance for **typed object refs, receipts, manifests, workflows, and docs**, with routing preserved by the shell/terminal protocol.

Implication:
- clicking an object link should open a small typed route sheet, not blindly execute `xdg-open`.

### 3. Marks and overlays can become debugging tools
- REF-GHOSTTY-OSC133-OVERLAY is especially interesting because it treats shell integration metadata as something humans can inspect.

Implication:
- a ViewFS terminal inspector should be able to show:
  - current view/domain badge
  - active workspace binding
  - prompt/input/output/receipt zones
  - attached object refs / grant receipts
  - ambient-debt markers if any compatibility escape hatch was used

## Minimal protocol ideas to prototype

### A. Block marks
For each command block, emit enough metadata for the terminal to know:
- where the prompt begins,
- where user input begins and ends,
- where output begins and ends,
- command exit status,
- view/domain at execution time.

This is the substrate for command navigation, block copy, safe replay, and receipt attachment.

### B. Object links
Allow shell output to attach a typed object link with:
- display label
- subject kind (`object_ref`, `grant_receipt`, `workspace_bind`, `workflow`, `manifest_ref`, `uri`)
- subject id
- preferred route kinds
- whether fresh portal mediation may still be required

The route should stay typed even if the terminal renders it like a hyperlink.

### C. Inspect overlay
A small overlay or side panel for the selected block/link should be able to answer:
- what view was active?
- what bindings were used?
- did this command depend on a durable grant, a workspace bind, or a one-shot transfer?
- was there any ambient-debt path?
- what route actions are valid right now?

### D. Honest recents
The terminal can absolutely have searchable command history, recent directories, and recent objects.
But each recent should advertise its state:
- ready
- needs rebind
- needs portal
- stale/missing
- ambient-debt

That keeps the shell fast without faking authority.

## Super-awesome moves worth exploring
- **Hover summary chips** for object links: tiny kind/rights/durability badges.
- **Receipt-in-scrollback**: a command block can inline a compact receipt chip and expand it on demand.
- **Explain-this-block**: one key shows the active view, bindings touched, receipts attached, and why a route is or is not available.
- **Ambient debt stripe**: a subtle but unmistakable visual stripe on blocks that used compatibility fallbacks.
- **Replay as dry-run**: replay the command text and workflow shape, but with no inherited grants unless the user reattaches them.
- **Workspace breadcrumb badge**: visible pane/tab badge showing which workspace binding the current block belongs to.
- **Route sheet on click**: clicking a link opens `inspect`, `reveal`, `rebind`, `reopen`, `export`, or `launch-uri` options instead of instantly committing to one.

## A very good small move
Add a terminal inspector/debug view early.
Ghostty's OSC 133 overlay is a reminder that protocol debugging is part of product quality, not just developer tooling.
If ViewFS wants a shell that is both delightful and trustworthy, it should make the metadata visible on purpose.

## Anti-goals
- no pretending that a recent item implies current authority
- no hidden “smart open” that silently decides between reveal, reopen, or launch
- no object links that discard kind information and become raw strings
- no dependency on one terminal emulator's private feature set

## Recommended prototype order
1. prompt/input/output/receipt marks
2. clickable typed object links
3. a tiny inspect overlay
4. honest recent-item states in the palette
5. optional block/receipt export and safe replay

See also `authority-hud-and-receipt-cards.md` for the higher-level prompt/pane chrome and receipt-card ideas that sit above these marks and links.

## Another especially good shell move

### 4. Entity peels before route slips
Steal from Plan 9 plumber, OSC 8, LSP document links, and kitty hints.

When the user hovers, selects, or hint-picks text, the shell should first open a tiny **entity peel** that says what the system thinks it found:
- `plain text`
- `path-ish candidate`
- `line ref candidate`
- `digest/object ref candidate`
- `receipt ref candidate`
- `URI candidate`
- `explicit link`

From there, the shell can lazily resolve more detail without pretending the route has already been chosen:
- does the target exist here?
- is the hostname local or mismatched?
- is this only history?
- is there already a current bind in this pane?

Only after that should the shell promote the candidate into one typed **route slip** like `inspect`, `reveal`, `open in tool`, `import here`, `launch uri`, or `compose packet`.

Why this is great:
- transcript clicks become much more powerful without becoming spooky;
- explicit links stay typed and reviewable instead of turning into blind `open`;
- heuristic extraction stays useful without silently becoming authority or execution.

Guardrail:
- selection, hover, or hyperlink rendering must never silently widen authority or skip the route-slip step for risky actions.
