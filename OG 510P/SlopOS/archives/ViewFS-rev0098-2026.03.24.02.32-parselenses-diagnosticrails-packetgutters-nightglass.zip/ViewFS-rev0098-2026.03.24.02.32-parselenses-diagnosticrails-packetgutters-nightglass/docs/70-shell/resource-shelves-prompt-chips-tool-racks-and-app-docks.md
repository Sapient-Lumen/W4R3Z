# Resource shelves, prompt chips, tool racks, and app docks

This note collects shell/terminal ideas for helper feature catalogs that stay truthful.

The key seam:
**resource descriptor ≠ prompt template ≠ tool descriptor ≠ interactive app surface ≠ completion suggestion ≠ request-bound attachment/selection ≠ live invocation/result ≠ durable receipt/history**.

If those collapse, the shell will lie in exactly the wrong way:
- browsing a resource will feel like binding it,
- selecting a prompt will feel like adopting it,
- seeing a tool will feel like already approving it,
- an app dock will feel like a plain object open,
- and an old invocation receipt will feel like current request state.

## Shell moves worth stealing

### 1. Resource shelf
A helper-aware pane should be able to show a **resource shelf**:
- context/data items from live helpers,
- provenance and freshness badges,
- whether the item is merely visible, currently attached, or only historical,
- whether preview is inert or needs a stronger lane.

### 2. Prompt chips
Prompt templates should show up as **prompt chips**, not as generic saved commands.
A chip should show:
- source helper and provenance,
- argument slots,
- whether completions exist for those slots,
- which tools/resources the prompt wants available,
- and whether invoking it would stay request-local or try to promote into a reusable workflow lane.

### 3. Tool rack
A **tool rack** should stay request-aware:
- visible tool descriptors from live helpers,
- the subset currently bound to this request,
- approval posture,
- whether the tool has already run in this request,
- whether its result is still only provisional/history.

### 4. App dock
Interactive helper surfaces deserve an **app dock** distinct from tools and resources.
The dock should show:
- which helper/session owns the app,
- whether the app is only launchable, currently open, or historical-only,
- whether it is pane-local or detached,
- what request or session it is coupled to.

### 5. Completion popover
Completion suggestions should stay clearly advisory.
A completion popover should show:
- prompt/resource argument being completed,
- source helper,
- whether suggestions are partial or rate-limited,
- whether selecting a suggestion only fills a field or also requests a stronger bind.

### 6. Binding tray
The shell should show one **binding tray** for the exact subset currently attached to the request:
- resources attached,
- prompts expanded,
- tools enabled for this action,
- apps linked or embedded for this turn,
- what is still only catalog-visible.

### 7. Invocation receipts
Receipts should preserve feature-class truth:
- `resource browsed`,
- `resource attached`,
- `prompt expanded`,
- `tool invoked`,
- `tool denied`,
- `app launched`,
- `completion only`,
- `history only`.

## Why this could make the terminal super awesome
A terminal that can tell the difference between helper feature kinds becomes dramatically more powerful:
- resource browsing can be rich without pretending it already changed the request,
- prompt templates can feel native without quietly becoming workflow truth,
- tool selection can stay crisp and request-local,
- interactive apps can exist without being disguised as files or commands,
- completions can be beautiful without laundering hints into authority.

## Guardrails
- catalog visibility must not imply current request binding,
- completions must remain hints until a stronger explicit act happens,
- prompt templates must not silently promote into durable workflows,
- tools must not look invoked just because they are visible or enabled,
- app docks must not hide extra session ownership or trust state,
- receipts must never launder historical invocations into current bindings.
