# Trash trays, retention lenses, and undo timelines

Goal: make deletion and recovery in the ViewFS shell feel **safer, clearer, and more reversible** without lying about what is actually still live.

## Principle
The shell should make it obvious whether an action:
- removed a name from a view,
- moved something to trash,
- left immutable data live because of a root,
- only created a recovery-history entry,
- or actually made something purge-eligible.

Great UX here is mostly **truthful classification + easy recovery**.

## High-upside ideas

### 1. A small action ladder instead of one scary `delete`
Rows, menus, and keybindings can prefer explicit verbs such as:
- `unbind`
- `trash`
- `restore`
- `pin`
- `drop-pin`
- `preview-purge`
- `purge`

This is much more honest than pretending all removal is one thing.

### 2. Trash trays, not one dark basement
The shell could show compact trays such as:
- `workspace trash`
- `session trash`
- `recently unbound`
- `restorable refs`

Each row should say:
- where it came from,
- when it moved,
- whether a collision-safe rename happened,
- and whether the underlying object is still held live by some other root.

### 3. “What keeps this alive?” lens
A one-keystroke inspector should answer questions like:
- pinned by workspace manifest,
- held by durable ref,
- referenced by notebook receipt,
- kept by policy-retention window,
- or purge-eligible if these two roots are dropped.

This is one of the best ideas to steal from root-based stores.

### 4. Purge previews should feel like git diff for storage fate
Before purge, show:
- candidate objects or entries,
- roots that still protect some of them,
- approximate reclaimable size,
- what recovery routes would disappear,
- and which things are only leaving trash versus becoming truly unreachable.

The terminal can make this compact and beautiful.

### 5. Undo timelines should be explicit about class
Timeline rows might say:
- `name removed from /work`
- `moved to workspace trash`
- `workspace head updated`
- `pin dropped`
- `purge preview generated`
- `restored to /work/docs`

This is better than a vague “undo delete.”

### 6. Restore plans, not blind puts
Restoring should produce a card that shows:
- original target,
- current collision risk,
- proposed new location if needed,
- whether rights/view bindings are sufficient,
- and whether the action only restores a name or also rebinds a workspace slot.

### 7. Local history and reflog feel for names and heads
A shell can borrow the good parts of:
- editor local history,
- Git reflog time-travel for names/heads,
- and recent-item timelines,

without turning them into bearer authority.

### 8. Delightful keyboard flow
Plausible future verbs / shortcuts:
- `dd` → trash current row
- `u` → undo last unbind/trash move
- `R` → restore with plan preview
- `K` → show retention roots
- `P` → preview purge
- `Shift-P` → purge confirmed set
- `Y` → copy removal / restore receipt

Not final syntax—just the shape of an excellent product.

### 9. Recovery receipts should be shareable, not dangerous
A receipt card can safely say:
- what moved,
- from where,
- when,
- who did it,
- what still keeps the object live,
- and what restore plan was used.

But it should not itself smuggle live authority.

## Tiny protocol ideas worth stealing
The shell-to-terminal protocol may eventually want metadata like:
- removal class (`unbind`, `trash`, `drop-root`, `purge-preview`, `purge`),
- recoverability state,
- original target / proposed restore target,
- root count or root summary,
- approximate reclaimable size,
- timeline position,
- and whether the current row is only a receipt.

This would make badges, timelines, and purge previews much more truthful.

## Product steals worth keeping in mind
- trash metadata and undelete behavior from desktop trash systems,
- local-history/timeline UX from editors,
- reflog-like head movement history from Git,
- and the inspectable-root story from immutable stores.

## Anti-goals
- a single red `delete` button that hides whether recovery exists
- silent purge without preview or root explanation
- restoring by guessing and overwriting without a plan card
- treating local history as if it were live authority
- making recovery feel like a forensic exercise instead of a first-class shell flow
