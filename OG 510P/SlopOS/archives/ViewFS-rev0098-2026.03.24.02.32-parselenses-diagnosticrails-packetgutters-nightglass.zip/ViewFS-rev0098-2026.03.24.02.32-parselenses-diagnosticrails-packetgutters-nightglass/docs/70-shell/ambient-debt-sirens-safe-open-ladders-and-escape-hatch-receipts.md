# Ambient-debt sirens, safe-open ladders, and escape-hatch receipts

Purpose: make the future custom shell+terminal brutally honest about how an object was actually reached: **direct handle**, **rooted compat walk**, **portal mediation**, **ambient host escape**, or **history only**.

## The shell should answer the embarrassing question directly
When something opens successfully, users deserve to know *how* it opened.
The shell should not force them to reverse-engineer that from a command string and a lucky path label.

## Moves worth stealing

### Safe-open ladders
Any open/reveal/import action should have a visible ladder like:
1. `use live handle`
2. `walk under held root`
3. `ask mediator / portal`
4. `ambient escape hatch`

The ladder should stop at the first lane that is actually available.
More importantly, the receipt should say which rung won.

### Ambient-debt sirens
If a command falls all the way to an ambient host escape, the shell should make that loud:
- one clear badge in the command block,
- one searchable transcript facet,
- one receipt row saying what ambient source was touched,
- and one easy path to replace that escape with a cleaner bind/grant next time.

### Escape-hatch receipts
A receipt for an ambient or compat escape should capture things like:
- target string or selector the user asked for,
- lane used (`handle`, `rooted walk`, `portal`, `ambient`),
- root/view or mediator involved,
- any narrowing or trust gate,
- resulting handle/publication if one was minted,
- and a `replace this debt later` affordance.

### Route provenance drawers
Clicking a path-like thing should be able to explain:
- `this was a published name in this pane`,
- `this was resolved by rooted walk under root R`,
- `this came from portal request Q`,
- `this used ambient helper H`,
- or `this is history only`.

### Fit notes on import sheets
Chooser/import UI can do more than show a list.
It can explain:
- why this candidate is in scope,
- whether it will stay mediated or become local,
- whether publication is immediate or explicit later,
- and what receipt/history will remain afterwards.

## Delightful chrome ideas
- **Debt sirens** that flash only when ambient or wide compat lanes were actually used.
- **Replace-this-debt buttons** that immediately let the user bind a cleaner root, keep a handle, or mint a publish-here card.
- **Open route pills** on command blocks: `handle`, `rooted`, `portal`, `ambient`, `history`.
- **Provenance minimaps** in the terminal gutter for recent commands that touched the outside world.
- **Manual-shell-integration health cards** so shell metadata emission is inspectable and recoverable instead of mystical.

## Protocol hints
The shell/terminal sideband probably wants event rows like:
- `open-route-start`
- `open-route-selected-lane`
- `ambient-debt-incurred`
- `portal-request-issued`
- `publication-created`
- `open-route-receipt`

That metadata should be emitted deliberately, the same way prompt/input/output marks and paste zones are better when explicit.

## What this avoids
- direct-handle truth being laundered into fake path centrality;
- rooted compat walkers becoming invisible and therefore permanent;
- portal mediation disappearing behind a path that looks native;
- ambient escapes hiding in success cases instead of only in obvious failures;
- and terminal delight being built on prompt folklore instead of inspectable semantics.
