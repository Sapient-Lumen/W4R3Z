# Type lenses, handler racks, and open-state badges

The future ViewFS shell should be able to tell the truth about type and opening without reducing everything to `filename.ext -> open in default app`.

## The basic ladder

The shell should keep at least these truth surfaces separate:
- **declared type**
- **derived type**
- **associated handlers**
- **chosen opener for this act**
- **live open state**
- **receipt/history**

That one split unlocks a lot of product quality.

## Type lenses
A focused object drawer should be able to show:
- `declared: application/pdf`
- `derived: application/zip`
- `confidence: low/high`
- `virtual representation available`
- `preview-safe`
- `edit requires stronger lane`

The point is not to expose scary internals.
It is to stop one path suffix or stale icon from masquerading as the whole truth.

## Handler racks
The shell should show handlers in a rack with visibly different roles:
- `associated`
- `default`
- `suggested`
- `chosen now`
- `safe preview`
- `disabled here`
- `history only`

That is better than a giant undifferentiated `Open With…` list.

## Why-this-opener drawers
When an opener is chosen, the shell should be able to answer:
- was it the user's explicit pick?
- a current local default?
- a type-derived suggestion?
- a safe-preview rule?
- a portal/provider choice?
- or only a historical suggestion?

That makes routing and replay much more trustworthy.

## Open-state badges
The transcript and side chrome should render states such as:
- `previewing`
- `editing`
- `external`
- `portal-owned`
- `detached`
- `closed`
- `history only`

This is one of the nicest possible shell moves because people constantly confuse `I opened this once`, `I am editing it now`, and `I can still get back to it`.

## Disagreement as a first-class UX feature
When declared and derived type disagree, do not hide it.
Show a compact disagreement card and offer a truthful ladder:
- `inspect as declared`
- `inspect as derived`
- `safe preview`
- `pick representation`
- `stay receipt only`

That would make the shell feel unusually competent.

## Guardrails
- A type label must not become object identity.
- A handler association must not become chosen opener truth.
- One chosen opener must not silently become a sticky future default.
- Live open state in one pane must not imply current authority everywhere else.
- Old receipts must not masquerade as current openability truth.
