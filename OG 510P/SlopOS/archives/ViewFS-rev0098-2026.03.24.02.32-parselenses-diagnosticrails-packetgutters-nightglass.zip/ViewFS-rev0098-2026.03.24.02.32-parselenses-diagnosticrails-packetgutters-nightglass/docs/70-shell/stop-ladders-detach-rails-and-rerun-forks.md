# Stop ladders, detach rails, and rerun forks

This note collects shell/terminal ideas for deferred work that stays truthful.

The key seam:
**close/cancel request ≠ force terminate run ≠ detach/delete retained task state or result ≠ retry fresh request ≠ reset/fork from prior history ≠ durable receipt/history**.

If those collapse, the shell will lie in exactly the wrong way:
- `stop` will blur graceful cleanup with force-kill,
- `forget` will look like remote work stopped,
- `retry` will silently reuse old state or old authority,
- `fork` will pretend to be a clean rerun,
- and an expired locker will look like a missing provider bug instead of an expected lifetime transition.

## Shell moves worth stealing

### 1. Stop ladder
A helper-aware pane should offer an explicit **stop ladder**:
- `close interaction`
- `cancel gracefully`
- `terminate now`
- `detach watch`
- `forget retained result`
- `retry fresh`
- `fork/reset from checkpoint`

The ladder should explain the likely consequences before commit.

### 2. Detach rail
A **detach rail** should make “I am done looking at this” feel different from “stop the work”:
- whether the remote work may still continue,
- whether progress updates will stop in this pane,
- whether retained results/metadata will be deleted locally,
- whether another pane/session can still observe or retrieve the task later.

### 3. Termination fuse
A **termination fuse** should stay louder than cancel:
- why graceful cancellation is insufficient,
- whether cleanup will be skipped,
- whether later receipts may be incomplete,
- whether force termination is even available for this helper/provider.

### 4. Retry-vs-fork drawer
A **retry-vs-fork drawer** should show:
- `retry fresh` — new request/run with no prior progress,
- `use existing` — attach to the currently open run,
- `fork/reset` — new run seeded from explicit prior history/checkpoint,
- what prior outputs/progress will be discarded,
- what current basis or reason will be recorded.

### 5. Result-retention locker
A **result locker** should say not just whether a result exists, but also:
- whether it is still retained,
- whether it was deleted intentionally,
- whether it expired by keep-alive,
- whether history remains even though payloads are gone,
- whether the underlying remote work is still live.

### 6. Stop receipt
Receipts should preserve stop/control truth:
- `interaction closed before response`
- `cancel requested`
- `cancel confirmed`
- `terminate requested`
- `terminated`
- `detached locally`
- `retained result deleted`
- `expired to history only`
- `retried fresh`
- `forked/reset from checkpoint`
- `attached to existing run`

## Why this could make the terminal super awesome
A terminal that can tell the difference between cancel, kill, forget, retry, attach, and fork becomes dramatically more useful:
- long-running helper work can be interrupted honestly instead of through one ambiguous stop verb,
- sensitive lockers can be deleted promptly without pretending the remote provider obeyed a kill signal,
- retry and reset can become inspectable power tools instead of mysterious “try again” buttons,
- background sessions can stay visible even when the user detaches from them,
- transcript history can show whether the user stopped work, stopped watching work, or started a new branch from old work.

## Guardrails
- close/abort should not masquerade as confirmed cancellation,
- cancel should not masquerade as force termination,
- detach/delete should not masquerade as remote stop,
- retry should not silently attach to an old run,
- reset/fork should always name its prior basis,
- expired lockers should degrade to history-only state instead of disappearing without explanation.
