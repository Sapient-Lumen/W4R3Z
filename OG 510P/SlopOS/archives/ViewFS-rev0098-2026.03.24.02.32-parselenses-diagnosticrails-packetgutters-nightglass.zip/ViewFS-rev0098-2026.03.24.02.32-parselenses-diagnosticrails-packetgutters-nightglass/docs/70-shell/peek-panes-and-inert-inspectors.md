# Peek panes and inert inspectors

Purpose: collect shell/terminal moves that make **preview feel magical** without letting preview quietly become authority, launch, or execution.

## North star
The ViewFS shell should make quick inspection delightful:
- hit one key to peek,
- see a fast preview in a split or overlay,
- browse a selection set,
- compare two objects side by side,
- copy safe text from the preview,
- and keep the entire thing visibly read-only unless a stronger action is taken.

In other words: **peek first, open later**.

## Best ideas worth stealing
- **REF-WIN-PREVIEW-HANDLERS** and **REF-WIN-PREVIEW-GUIDE**: lightweight, read-only preview without launching the full app; minimal UI; block scripts/macros.
- **REF-APPLE-QUICKLOOK-WWDC24**: a dedicated system preview tool can coexist with the main app and expose lifecycle/state cleanly.
- **REF-WEZTERM-SHELL-INT**, **REF-ITERM-SHELLINT**, **REF-GHOSTTY-OSC133-OVERLAY**: semantic marks/zones/inspectors make shell state visible and navigable.
- **REF-WARP-BLOCKS** and **REF-WARP-CMDPALETTE**: commands, outputs, and object actions should be grouped and searchable.
- **REF-VSCODE-JUPYTER-TRUST**: rich outputs can be hidden or degraded in untrusted contexts instead of pretending preview is all-or-nothing.

## Preview states worth showing honestly
A peek pane/card should probably advertise one of these:
- `preview-only`
- `static-render`
- `copyable-text`
- `provider-missing`
- `trust-required`
- `portal-required`
- `rich-output-hidden`
- `derived-sidecar`
- `stale`

These are good UX because they tell the truth about what the shell is doing.

## Great shell moves

### 1. Space-to-peek / split-to-peek
A file/object row, palette entry, or query result should support a very fast preview action:
- open in an overlay,
- open in a side split,
- or open in a lower peek drawer.

The preview should be obviously **secondary** to the underlying object, not a stealthy second authority model.

### 2. Provider badges
Every preview should show:
- provider (`text`, `image`, `pdf`, `media`, `notebook-static`, `hex`, `custom`),
- render mode (`source`, `static`, `derived`, `redacted`),
- and trust state.

That makes “what am I actually looking at?” answerable at a glance.

### 3. Side-by-side compare
One of the best product ideas worth stealing is easy compare mode:
- compare two selected images/documents,
- compare source object vs derived preview,
- compare current object vs last previewed object,
- or compare source text vs extracted text.

But the comparison chrome should be explicit about which side is source and which side is derived.

### 4. Safe text lift
The preview pane should often let the user:
- select text,
- copy snippets,
- copy metadata,
- or export an extracted sidecar,

without implying that the full associated app is now trusted to run.

### 5. Authority ladder controls
A preview pane could have explicit next-step actions such as:
- `reveal source`
- `open in full app`
- `export derived text`
- `rebind into workspace`
- `trust rich output`

That ladder is great because it turns hidden escalation into named actions.

### 6. Preview receipts and cards
If a command previews an object, the transcript block should gain a compact receipt card containing:
- object identity / local name,
- preview provider,
- trust/degrade state,
- whether any derived artifact was emitted,
- and whether the preview was partial or complete.

Those cards should be shareable without carrying live authority.

### 7. Inspector overlay for the terminal itself
The terminal should have a debug/inspect overlay showing:
- active view badge,
- current preview providers,
- recent preview receipts,
- blocked-vs-ready status,
- and the semantic zones/marks tied to the current command block.

This is one of the best routes to a shell that feels both futuristic and trustworthy.

## Especially good ideas
- **Pinned peek strip**: keep a narrow strip of the last few previews as visual breadcrumbs without turning them into recents-that-open.
- **Peek from palette**: palette rows should preview first and execute/open second.
- **Notebook static mode**: in restricted contexts, show notebook structure and previously rendered outputs only as inert artifacts.
- **Derived/source toggle**: when preview comes from extracted text or a thumbnail, let users flip between “derived” and “source bytes” views where possible.
- **Close all observers**: a single command should dismiss all active peek sessions.
- **Ambient-debt marker**: if a preview had to use a host bridge/provider outside the ideal ViewFS model, say so loudly.

## Anti-goals
- turning preview panes into mini-apps with toolbars, dialogs, or hidden execution
- hiding whether the user is seeing source bytes, derived content, or stale cache
- replaying preview cards as if they were durable open handles
- conflating “copy text from preview” with “trust this object/workspace/app”
- making preview infrastructure impossible to inspect or turn off
