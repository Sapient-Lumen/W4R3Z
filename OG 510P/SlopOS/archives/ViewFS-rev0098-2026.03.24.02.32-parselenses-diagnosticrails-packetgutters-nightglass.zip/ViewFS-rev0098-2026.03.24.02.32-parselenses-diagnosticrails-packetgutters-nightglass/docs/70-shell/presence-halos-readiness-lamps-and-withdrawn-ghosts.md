# Presence halos, readiness lamps, and withdrawn ghosts

Purpose: make the future custom shell+terminal honest about four different truths: **something is advertised**, **something is claimed ready now**, **something still needs a grant**, or **something is already held as current authority**.

## The shell should answer the freshness question directly
When a chooser row, palette item, or side shelf shows something promising, the shell should not force users to guess:
- is this merely catalog presence,
- is it ready right now,
- does it still need a portal/rebind/reacquire step,
- or do I already hold it?

## Moves worth stealing

### Presence halos
Wrap object/route/provider chips with a soft status ring that can say:
- `advertised`,
- `ready`,
- `grant needed`,
- `cooling down`,
- `withdrawn`,
- `expired`,
- `history only`.

This makes dynamic helper/provider truth visible without pretending it is the same as a live handle.

### Readiness lamps
Small freshness-aware lamps should decay visibly:
- `ready now`
- `last known ready`
- `unknown now`
- `withheld`
- `withdrawn`
- `history only`

The important part is not precision theater.
The important part is refusing to let one stale green badge flatter itself into current truth.

### Withdrawn ghosts
If a provider withdraws an advert or a ready state decays, keep a dim ghost row for a while.
Give it an exact reason like:
- `provider withdrew advert`,
- `freshness window expired`,
- `cooling down`,
- `grant revoked`,
- `history only`.

That is more honest and more humane than making useful affordances vanish with no trace.

### Grant-needed ladders
A palette or command block should be able to say:
- `ask portal`,
- `request bind here`,
- `reacquire grant`,
- `open advert ledger`,
- `show last receipt`.

That is how the shell stays helpful without falsely claiming it already has power.

### Advert ledgers
Rows that came from helper/provider discovery should be inspectable:
- who advertised it,
- when,
- what freshness class it had,
- whether it was only advertised or also ready,
- and whether a later grant was actually minted.

## Delightful chrome ideas
- **presence halos** around palette hits and route chips.
- **ready/last-known lamps** in pane chrome and chooser rows.
- **withdrawn ghosts** for things that fell out of scope but still matter historically.
- **grant-needed buttons** that jump straight into the smallest next mediation step.
- **advert provenance drawers** that keep providers, freshness, and receipt links visible.

## Protocol hints
The shell/terminal sideband probably wants event rows like:
- `presence-advertised`
- `presence-withheld`
- `readiness-declared`
- `readiness-decayed`
- `grant-needed-declared`
- `grant-acquired`
- `presence-withdrawn`
- `presence-history-only`

That metadata should be emitted deliberately, the same way prompt/input/output marks and paste zones are better when explicit.

## What this avoids
- stale provider presence pretending to be current local authority;
- a live catalog row being mistaken for a ready target;
- a ready target being mistaken for a granted one;
- vanished adverts erasing useful context;
- and future shell delight being built on invisible freshness guesses.
