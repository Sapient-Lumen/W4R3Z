# Caveat chips, witness drawers, freshness badges, and why panels

Purpose: make the ViewFS shell feel **super awesome** by letting users inspect *why* something can run, import, replay, or reopen **without** turning explanation into ambient authority.

## North star
A great ViewFS shell should let a user read these states at a glance:
- **witness-exact** — the current plan has an exact local witness pack
- **freshness-known** — the evaluated basis cut is explicit and reviewable
- **caveated** — the move is narrowed by explicit caveats
- **reconsent** — fresh approval/import/renewal is needed
- **receipt-only** — explanation/history is available, but no current authority is implied
- **why-denied** — the shell can say what exact class of thing blocked progress

That is much better than a terminal that only knows “command succeeded before” or “permission denied”.

## Best ideas worth stealing
- **REF-MACAROONS-NDSS14**: caveats are a great model for routine attenuation, but the terminal should render them as chips/cards instead of burying them in token bytes.
- **REF-ZANZIBAR**: consistency tokens are a useful reminder that “what state was this checked against?” deserves a visible answer.
- **REF-DENO-PERMISSIONS**: deny precedence and permission audit logs show that explanation and auditability are product features, not just security plumbing.
- **REF-WEZTERM-SHELL-INT** and **REF-WEZTERM-ZONES**: semantic prompt/input/output zones are an ideal substrate for rendering witness drawers and why panels without screen scraping.
- **REF-VSCODE-WORKSPACE-TRUST**: restricted-but-productive mode is real product value; the shell can explain why execution is narrowed or blocked without becoming inert.
- **REF-DIRENV-REQUIREALLOWED**: watched-input invalidation should feel like a visible reason, not random fragility.

## Witness drawers could be incredible
Activate a receipt, recipe, or durable reopen ref and get a **witness drawer**:
- exact facts currently being relied on,
- which of them came from current provider/view state,
- which of them were copied from prior basis material,
- which are missing,
- and which are now inexact or unknown.

That is the right place to be clever.

## Caveat chips belong in prompt chrome and result cards
A pane or block should be able to show chips like:
- `read-only`
- `no-export`
- `pane-local`
- `borrowed`
- `temp-view`
- `expires-on-exit`
- `freshness-unknown`

Those chips make attenuation and risk easy to see.

## Freshness badges should stay distinct from trust badges
A freshness badge could say:
- `cut exact`
- `cut old`
- `cut unknown`
- `provider changed`
- `issuer policy changed`

That badge should sit beside, not inside, trust/borrow/workspace badges.

## Why panels are the best replay UI
The next time a user replays, reopens, or renews, the shell should be able to show a **why panel**:
- why this is allowed unchanged,
- why this is only allowed narrowed,
- why fresh chooser/import is needed,
- why the shell is dropping to receipt-only,
- or why the route is denied.

This beats both silent success and generic failure.

## Great terminal-native moves
- **Why hotkey**: one keystroke opens the current block’s why panel.
- **Witness gutter**: a thin lane beside blocks showing witness/freshness/caveat state.
- **Caveat-preserving replay**: replay with stricter caveats, not only with old power.
- **Freshness recheck button**: rerun the drift/freshness check without committing the action.
- **Result stack chains**: receipt -> witness drawer -> why panel -> renewed artifact -> new receipt.

## Structured shell values worth exploring
A structured shell could let commands emit values such as:
- `witness_pack`
- `caveat_set`
- `freshness_token`
- `why_record`
- `decision_receipt`

That would make notebooks, palettes, inspectors, and panes far more truthful.

## A tiny honest prototype would already be great
The first prototype does not need a huge framework.
It would already be great to ship:
- one **witness drawer**,
- one **why panel**,
- one prompt badge for `freshness-known` versus `reconsent`,
- one row of **caveat chips**,
- and result cards that say *why* the class changed.

If that feels good, the shell will have found another real superpower rather than a more ornate rerun button.
