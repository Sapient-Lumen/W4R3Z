# Chooser sheets, staging trays, and grant ledgers

Purpose: make portal-heavy ViewFS workflows feel **super awesome** without blurring request state, selected outcomes, minted grants, and current pane authority.

## North star
The shell should make four truths obvious:
- **what request is in flight now**,
- **what the chooser actually selected**,
- **what kind of grant or ref was minted**,
- and **what entered this pane or launch kit as live authority**.

That one move would make portal-mediated imports feel less like mystery meat and more like a first-class object workflow.

## Best ideas worth stealing
- **REF-XDG-REQUEST** and **REF-XDG-PORTAL-DESIGN**: long-running mediated interactions deserve explicit request objects and visible completion/cancellation states.
- **REF-XDG-FILECHOOSER** and **REF-XDG-DOCUMENTS**: chooser selection, durable document-store identity, and restricted synthetic views are related but not identical.
- **REF-ANDROID-SAF**: the UI should only promise operations the provider actually supports, and persistence should be an explicit step.
- **REF-PLAN9-PLUMB**: routing gets dramatically better when intent is typed instead of guessed from pasted strings.
- **REF-WARP-BLOCKS**, **REF-WEZTERM-SHELL-INT**, and **REF-GHOSTTY-SHELLINT**: blocks, marks, and semantic metadata make interactions inspectable instead of folkloric.
- **REF-VSCODE-WORKSPACE-TRUST** and the Workspace Trust blog post: a useful restricted state can appear first, with stronger prompts delayed until the moment more dangerous behavior would begin.

## Chooser sheets should be explicit objects
When a command triggers mediated import, the shell should show a **chooser sheet** with:
- request kind (`open`, `bind tree`, `pick destination`, `upgrade persistence`, ...),
- requester pane / workflow,
- current state (`pending`, `completed`, `cancelled`, `timed out`),
- whether the candidate universe is chooser-owned,
- and any trust/quarantine/context badges relevant to the result.

This should look like a first-class work object, not a hidden side effect.

## Candidate browsing should not become ambient inventory
A chooser sheet may be powerful and searchable, but it should still admit:
- this is not the whole machine,
- this is provider-filtered,
- this is request-local,
- and the caller may only receive the chosen result, not the entire candidate list.

That honesty is a feature, not a flaw.

## Staging trays are where delight can stay truthful
After selection, results should be able to land in a **staging tray** before they become current authority.

A staging card could show:
- selected subject,
- provider/source,
- supported operations,
- ephemeral versus durable posture,
- trust/quarantine/origin state,
- bind target options,
- and whether the next step is `bind here`, `launch with`, `route elsewhere`, `save durable reopen`, or `receipt only`.

This is the missing seam between “I picked something” and “my process can now use it.”

## Grant ledgers should exist per pane
Each pane should have a compact **grant ledger** listing the last few mediated acts:
- request created,
- selection completed,
- ephemeral grant minted,
- durable upgrade granted,
- bound into pane,
- rebound into child launch,
- expired / revoked / stale.

That turns portal history into an inspectable operational surface instead of scrollback trivia.

## Great moves worth prototyping
- **Request chips in the prompt/header**: tiny visible badges for active chooser/save/upgrade interactions.
- **Selection-to-bind diff**: after choosing, show what would change in the current pane if the result were bound here.
- **Ops-aware action filtering**: only show actions the provider says it supports.
- **Ephemeral-first default**: `open now` first, then `keep for later` as a second deliberate action.
- **Route elsewhere**: selected results can become launch-kit input, another pane bind, transfer material, or receipt-only history instead of auto-binding here.
- **Quiet restricted mode**: let users inspect/import/browse first, then ask for stronger trust only when the workflow crosses into code execution or wider authority.

## Structured shell ideas
A shell event or palette row related to chooser/import flows should ideally carry:
- request state,
- subject class (`selection`, `ephemeral_grant`, `durable_ref`, `live_bind`, `receipt`),
- supported operations,
- current usability (`bindable_here`, `launch_only`, `reopenable`, `expired`, `receipt_only`),
- and any portal/trust/debt note.

That is how the shell becomes magical without pretending every selected thing is already current authority.

## A tiny honest prototype would already be great
The first prototype does not need full generality.
It would already be great to ship:
- visible request chips,
- one chooser sheet,
- one staging tray,
- one grant ledger,
- and one `bind here` versus `receipt only` versus `durable reopen` split.

If that feels smooth and comprehensible, then richer mediated import UX is worth the complexity.

