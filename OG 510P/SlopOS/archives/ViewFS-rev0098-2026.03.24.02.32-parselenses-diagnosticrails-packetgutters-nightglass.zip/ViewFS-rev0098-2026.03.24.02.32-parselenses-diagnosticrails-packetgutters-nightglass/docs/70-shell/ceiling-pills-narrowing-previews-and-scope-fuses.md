# Ceiling pills, narrowing previews, and scope fuses

Purpose: make the ViewFS shell feel **super awesome** while staying brutally honest about what cannot widen, what can only narrow, and what still needs an explicit adoption act.

## North star
A great ViewFS shell should let a user see, before committing:
- **what ceiling applies** — hard deny, trust gate, source-class ceiling, owner/org ceiling, or unknown
- **what scope is even admissible** — `once`, `pane`, `session`, `workspace`, `profile`, maybe later `org`
- **what narrower safe choices exist** — `use once`, `pin to pane`, `session only`, `read-only`, `no-export`, `receipt only`
- **what is still only advice** — a suggested narrowing is not yet live policy
- **what receipt will be written** — adopted, narrowed, declined, blocked by ceiling, or stale

## Shell moves worth stealing

### 1. Ceiling pill
A compact pill should say why widening is blocked or constrained:
- `deny`- `workspace not trusted`- `history may not widen`- `org ceiling`- `profile only`- `unknown until mediator`

Super-awesome move:
- one keystroke opens a tiny “why can’t this widen?” panel without dumping raw policy prose.

Guardrail:
- ceiling pills are explanation, not override buttons.

### 2. Narrowing preview
When a broader act is denied or discouraged, the shell should immediately preview safer alternatives:
- `use once`
- `use in this pane`
- `allow for this session`
- `read-only`
- `no-export`
- `receipt only`

Super-awesome move:
- the shell can default focus to the narrowest legal option so fast users stay fast without sleepwalking into broader standing effects.

Guardrail:
- a narrowing preview is still a proposal until explicitly chosen.

### 3. Scope fuse
A scope fuse is a visible indicator that this proposal source cannot cross some line:
- workspace suggestion cannot write profile state
- receipt/history cannot demand workspace trust
- stale proposal cannot skip fresh mediation
- helper lane cannot bypass deny ceilings

Super-awesome move:
- fuses can render directly in pane chrome and route-plan cards so users know *which line is real* before they hit Enter.

Guardrail:
- scope fuses should be enforced by authoritative policy/config, not only by shell convention.

### 4. Adopt-the-narrowest-safe-rung
The shell should have a first-class gesture for “take the narrowest legal version of this.”

Super-awesome move:
- one keystroke chooses the safest admissible rung and writes a receipt saying exactly what was requested versus what actually took effect.

Guardrail:
- if nothing admissible exists, the shell must say `receipt only` or `blocked`, not fake success.

### 5. Relative-link truthfulness
Recent terminal tooling has a nice lesson here: links and queued steering work best when they are tied to explicit session state rather than guessed from scrollback folklore.
ViewFS should therefore resolve relative file/object links against the explicit active pane/view session state, and queued follow-up actions should target the current route-plan/request object instead of becoming anonymous later shell text.

Super-awesome move:
- clickable relative links and queued steering become reliable because they ride the pane’s explicit state.

Guardrail:
- a clickable link is still route planning, not silent authority expansion.

## Prompt chrome / pane chrome ideas
- **ceiling pill** beside proposer/scope badges
- **scope fuse badge** when a proposal source is categorically non-widenable
- **narrowing spark** when a safer legal alternative exists
- **adopt narrowest** hotkey hint when one option is clearly safer than the rest

## Result-card ideas
A result card should be able to say:
- `requested workspace, adopted once`
- `blocked by org ceiling`
- `history source may not widen beyond session`
- `workspace trust missing; receipt only`
- `narrowed to read-only session grant`
- `declined; ceiling explained`

## Notebook / replay ideas
- replay should preserve the last applied ceiling and last effective scope as history only
- replay should compare recorded requested scope versus currently admissible scope
- `accept narrowest safe replay` should be a first-class action
- `receipt only` should stay a clean success class for stale, forbidden, or no-longer-admissible replays
