# Shell super-awesome moves

Purpose: collect unusually good shell/terminal ideas for ViewFS without prematurely freezing shell syntax.

These are product ideas, not protocol commitments. The common rule is: **every delightful feature should still tell the truth about authority.**

## 1. Object palette, not just command palette
Steal from REF-WARP-CMDPALETTE and REF-PLAN9-PLUMB.

One searchable palette should find:
- workflows
- notebooks/runbooks
- recent receipts
- object refs and manifests
- saved views
- routeable actions like `inspect`, `open`, `export`, `send`, `rebind`

Why this is great:
- it turns the shell into an object navigator, not just a text launcher
- it reduces hidden aliases and wiki archaeology

Guardrail:
- palette actions should show whether they are pure inspection, local mutation, transfer, or portal-mediated export before execution

## 2. Authority diff before Enter
Steal from REF-FISH and REF-NUSHELL.

When a command is ready to run, the shell should be able to show a tiny diff-like preview:
- reads from `/work` and `/in`
- writes to `/out` and `/state`
- may invoke `portal.file.open`
- may invoke `portal.xfer`
- contains ambient debt

Why this is great:
- users stop treating authority as invisible folklore
- dangerous surprises become visible before execution

Guardrail:
- this is a preview, not a false proof; uncertain cases should say so

## 3. Receipt tray for the current pane
Steal from REF-WARP-BLOCKS and REF-XDG-FILETRANSFER.

Each pane should have a small receipt tray showing the last few:
- imports
- exports
- transfers
- manifests
- debt receipts

Why this is great:
- receipts become reusable work objects instead of disappearing into scrollback
- drag/drop between tools can become explicit transfer actions

Guardrail:
- expiry and durability state should be visible on each receipt

## 4. Chooser sheets and staging trays
Steal from REF-XDG-REQUEST, REF-XDG-FILECHOOSER, REF-XDG-DOCUMENTS, and REF-ANDROID-SAF.

A mediated import should not just disappear into a dialog result.
The shell should show:
- request chip / chooser sheet,
- selected result,
- provider-supported operations,
- `bind here` / `launch with` / `keep for later` / `receipt only` choices,
- and then the resulting ledger entry.

Why this is great:
- portal-mediated workflows become inspectable and reusable
- “I selected it” stops pretending to mean “this pane already has it live”

Guardrail:
- candidate browsing should not become generic machine inventory, and durable upgrade should stay explicit

## 5. Explain access timeline
Steal from REF-WEZTERM-SHELL-INT plus the existing SlopOS transcript posture.

For any command block, the user should be able to ask:
- what object was touched
- how was it named here
- which grant/receipt made that possible
- did compat/path fallback occur
- did any authority persist afterward

Why this is great:
- it turns debugging and security inspection into the same UX

Guardrail:
- explanations should distinguish immutable object ID, current path name, mutable head, and durable receipt state

## 5. Route sheet instead of “open this string somehow”
Steal from REF-PLAN9-PLUMB, REF-XDG-OPENURI, and REF-PLAN9-ACME.

Selecting an object, receipt, or URI should open a typed route sheet:
- inspect object
- open with viewer/editor
- export
- send via transfer portal
- open URI externally
- reveal containing view binding

Why this is great:
- it makes object actions discoverable and auditable
- it unifies file-ish and URI-ish actions under explicit routing

Guardrail:
- local files should not silently become generic URI opens; route sheets should preserve the right seam

## 6. View-aware panes and split domains
Steal from REF-WEZTERM-DOMAINS and REF-FUCHSIA-NAMESPACE.

Every pane/tab should advertise:
- active view label
- synthetic cwd
- mutation posture
- ambient-debt status

Why this is great:
- panes become different authority domains, not just different scroll regions

Guardrail:
- copying a command from one pane to another should not silently copy its authority

## 7. Local-first runnable notebooks
Steal from REF-WARP-NOTEBOOKS.

Runbooks should support:
- markdown explanation
- runnable commands
- embedded receipts/manifests
- parameter prompts
- last-run outcomes
- plain Markdown export

Why this is great:
- the shell becomes a trustworthy operations notebook
- knowledge stays close to execution

Guardrail:
- notebooks should reference receipts and views explicitly; they should not smuggle hidden durable grants inside the document itself

## 8. Safe replay with stripped authority
This is a ViewFS-native move.

A finished block should offer:
- replay exactly
- replay read-only
- replay without exports
- replay in fresh temp view
- replay with explicit chooser re-consent

Why this is great:
- users can rerun workflows with less authority than the original
- it turns attenuation into a daily tool, not an exotic security feature

Guardrail:
- the replay UI must show which handles/grants were removed or re-requested

## 9. Ambient debt siren
Steal from REF-CAPSTD and REF-LANDLOCK.

If a command uses ambient host authority or a host-path compat escape, the shell should make it loud:
- visible badge in the block
- searchable debt receipt
- optional pane-wide warning until cleared

Why this is great:
- bring-up shortcuts stop masquerading as final design

Guardrail:
- do not make the warning ignorable by default in strict/dev-review modes

## 10. Background output should still be first-class
Steal from REF-WARP-BLOCKS.

If background work emits output, that output should land in explicit blocks with:
- source workflow/job identity
- view/domain
- attached receipts
- whether the job still has active authority

Why this is great:
- long-running work remains inspectable and routable

Guardrail:
- background output must not imply hidden background authority; it still needs an explicit grant story

## One narrow prototype to earn all this
The best first shell prototype is probably just:
- visible view badge
- block boundaries
- one-keystroke authority preview
- one receipt tray
- one explain-access inspector
- one loud ambient-debt marker

If that feels magical **and** honest, then the bigger notebook/palette/routing ideas are probably worth the complexity.


## 6. Route-plan card instead of instant side effect
Clicking a typed object, receipt, or route suggestion should normally open a **route-plan card** first.

That card should say:
- what intent is being satisfied,
- which route/provider/target is chosen,
- whether approval is needed,
- what authority delta would happen,
- and what the result card would likely record.

The super-awesome part is not instant execution. The super-awesome part is that the shell becomes fast *and* truthful.


## 11. Basis diff before replay or renewal
Steal from REF-DIRENV-REQUIREALLOWED, REF-APPLE-SECRESOLVE, and REF-DENO-PERMISSIONS.

Before rerunning from a receipt, notebook cell, workflow, or durable reopen ref, the shell should be able to show a tiny basis diff:
- what exact basis was recorded before
- what still matches
- what narrowed
- what disappeared
- whether fresh chooser / fresh lend / fresh temp view is required

Why this is great:
- users can move fast without pretending old success is current permission
- replay becomes truthful even when it cannot be exact

Guardrail:
- a basis diff is not itself approval; the UI must keep reconsent and renewed authority visibly separate

## 12. Cut picker before the shell swaps judges
Steal from REF-OPA-DISCOVERY, REF-CEDAR-VALIDATION, REF-SPICEDB-CONSISTENCY, and REF-XDG-REQUEST.

Before switching policy family/cut because of drift, invalid state, or a tempting newer candidate, the shell should be able to show a tiny cut picker:
- what family/cut is authoritative now
- what consistency posture it used
- what fallback candidates exist
- what the shell is only recommending as a repair
- whether the result would be `same family newer cut`, `exact snapshot`, `fresh latest`, `ask mediator`, or `history only`

Why this is great:
- the shell can help recover quickly without becoming a hidden policy negotiator
- users can tell whether a current answer came from explicit choice, repair adoption, or only history

Guardrail:
- a fallback rail or repair prompt is not itself an authoritative policy switch; the UI must keep the exact selected cut visibly separate from advice and history.



## 13. Proposer badge before the shell asks you to widen trust
Steal from REF-GIT-CONFIG-ORIGIN-SCOPE, REF-VSCODE-CHAT-CUSTOM-DIAG, REF-VSCODE-MCP-SERVERS, REF-VSCODE-AGENT-PERMISSIONS, and REF-POLKIT-AUTHORITY.

Before a workspace hint, receipt replay, history row, or shell-local repair becomes live at a broader scope, the shell should show:
- who proposed it
- what scope it is asking for
- whether it is only advice, pending escalation, or ready for adoption
- who is allowed to adopt it
- what receipt will be written if accepted or declined

Why this is great:
- the shell can stay fast and ambitious without becoming a hidden selector
- users can safely accept a narrow one-shot fix without accidentally persisting a wider standing rule

Guardrail:
- proposal surfaces must stay non-authoritative until an explicit adoption gate is crossed, and the gate must not silently widen from `once` to `workspace` or `profile`.


## 14. Ceiling pill before the shell widens anything
Steal from REF-CEDAR-SECURITY, REF-DENO-PERMISSIONS, REF-VSCODE-CONTRIB-SCOPES, REF-VSCODE-WORKSPACE-TRUST-EXT, and REF-VSCODE-AGENT-TOOLS.

Before a proposal tries to grow from `once` to `session`, `workspace`, `profile`, or beyond, the shell should show:
- what deny ceiling applies
- whether this origin/target combination is even admissible at that scope
- what narrower safe choices exist
- whether the result will be adopted, narrowed, blocked, or receipt-only

Why this is great:
- the shell can stay fast without becoming a loophole around owner, org, or trust ceilings
- users can accept the narrowest safe option almost instantly

Guardrail:
- a narrowing preview is not itself an adoption, and a ceiling explanation is not an override surface.


## 15. Origin stack before the shell treats “present” as “active”
Steal from REF-VSCODE-AI-POLICIES, REF-VSCODE-ENTERPRISE-POLICIES, REF-VSCODE-MCP-CONFIG, REF-GIT-CONFIG-ORIGIN-SCOPE, and REF-DENO-PERMISSIONS.

Before a workspace file, imported helper config, or remembered receipt is allowed to matter, the shell should be able to show a tiny origin stack:
- what sources exist
- which one currently wins
- which ones are merely visible but withheld by trust state
- whether an owner/org ceiling is suppressing a lower layer
- whether a source is only imported/history material rather than live truth

Why this is great:
- the shell can be extremely helpful without becoming a hidden policy blender
- users can inspect “why didn’t this take effect?” instantly instead of debugging folklore

Guardrail:
- opening the origin stack, trust shutter, or override ledger must not itself activate or promote anything.


## 12. Author badge + carrier tag + trust-tunnel siren
Steal from REF-GIT-CONFIG-ORIGIN-SCOPE, REF-VSCODE-ENTERPRISE-POLICIES, REF-VSCODE-AGENT-PLUGINS, and REF-VSCODE-WORKSPACE-TRUST.

The shell should be able to show three different facts at once:
- who authored the current active answer,
- what merely carried candidate material here,
- and whether a trust gate still blocks that carrier from becoming active truth.

Why this is great:
- trusted plugins, parent repos, or imported bundles stop turning into invisible policy tunnels;
- users can inspect why something is visible without mistaking that for why it is active.

Guardrail:
- carrier tags and trust-tunnel sirens are explanatory surfaces until the user explicitly enters an adoption or review path.


## 16. Protected chip + matrix drawer + latched invoke
Steal from REF-GIT-PROTECTED-CONFIG, REF-GIT-SAFE-DIRECTORY, REF-VSCODE-PROMPT-FILES, REF-VSCODE-CUSTOM-AGENTS, and REF-DENO-PERM-BROKER.

Before lower-trust helper material is allowed to matter, the shell should be able to show:
- whether the targeted state class is protected-only,
- whether this source class is only invoke-only or adoptable,
- whether a stronger broker/owner/org lane is currently deciding,
- what one-shot narrow path exists right now,
- and what receipt would be written for invoke versus adopt.

Why this is great:
- the shell can stay extremely helpful without turning visible helper material into sticky truth;
- users can take a productive one-shot path instantly without accidentally writing always-on state.

Guardrail:
- a matrix drawer or protected chip is not itself an override surface, and a latched invoke must not silently promote itself into future automatic behavior.


## 13. Tool rack instead of “installed therefore live”
Steal from REF-VSCODE-PUBLISHER-TRUST, REF-VSCODE-MCP-SERVERS-LIVE, REF-VSCODE-PLUGIN-LIFECYCLE, REF-VSCODE-COPILOT-BOUNDARIES, and REF-DENO-PERM-BROKER-LIVE.

A helper-aware terminal should be able to show:
- who vouched for install,
- whether the helper is merely installed or actually enabled,
- whether it still needs a start approval,
- whether it is live right now,
- and which tools/resources/prompts are selected for this request.

Why this is great:
- users can stage many helpers without pretending they are already running,
- “why didn’t that tool run?” becomes debuggable from terminal chrome,
- live helper state becomes visible without flattening everything into hidden settings.

Guardrail:
- do not let installed or enabled state masquerade as current live authority.


## 17. Resource shelf + prompt chip + tool rack + app dock
Steal from REF-MCP-RESOURCES, REF-MCP-PROMPTS, REF-MCP-TOOLS, REF-MCP-COMPLETION, REF-VSCODE-MCP-SERVERS-LIVE, and REF-WEZTERM-SHELL-INT.

A helper-aware terminal should be able to show four different things without flattening them:
- resources you may browse or attach,
- prompts you may fill or expand,
- tools you may enable or invoke,
- apps you may launch or dock.

And it should keep one more thing clearly advisory: completion suggestions for prompt/resource arguments.

Why this is great:
- helper catalogs become rich and fast without pretending every visible item is active now;
- prompt chips and resource shelves make request assembly inspectable;
- app docks make interactive helper surfaces possible without disguising them as files or commands.

Guardrail:
- catalog presence, completions, request binding, live invocation, and durable history must stay visibly different in terminal chrome and receipts.


## 18. Task badge + progress lane + result locker
Steal from REF-XDG-REQUEST, REF-MCP-TASKS, REF-MCP-PROGRESS, REF-GCLOUD-LRO, REF-XDG-BACKGROUND, REF-VSCODE-TASKS-BG, and REF-VSCODE-109-BGAGENTS.

A helper-aware terminal should be able to show:
- the exact request that was submitted now,
- whether it was merely accepted for deferred work,
- a live progress/status lane that is visibly advisory,
- whether more input is required before completion,
- a result locker only after the final output is actually retrievable,
- and what queued follow-ups are waiting behind the still-running task.

Why this is great:
- long-running work can feel native without pretending every request is a blocking call;
- follow-up steering stays honest because the current running task, queued next act, and final result are visibly different classes;
- background sessions become visible without turning “may continue later” into standing authority folklore.

Guardrail:
- acceptance must not imply final result availability, progress must not masquerade as durable success, and old task receipts must not pose as still-running requests.
- Treat `close`, `cancel`, `terminate`, `detach`, `retry fresh`, and `fork/reset` as different terminal-native control moves, and surface them through stop ladders, detach rails, and result-retention lockers instead of one generic stop button.


## 19. Follow tail + attach rail + control pane + sideband badge
Steal from REF-KUBECTL-LOGS, REF-KUBECTL-ATTACH, REF-KUBECTL-PORTFWD, REF-TMUX, REF-TEMPORAL-MESSAGES, REF-XDG-INPUTCAPTURE, and REF-WEZTERM-USERVARS.

A live-session-aware terminal should be able to show:
- whether the current lane is observe-only, read-only attach, interactive attach, control-message, debug exec, or sideband tunnel,
- whether interaction is merely armed or truly active,
- whether stdin is live,
- whether the user is seeing an old transcript or a live surface,
- and whether a tunnel or debug lane ends when the source run ends.

Why this is great:
- watching becomes safe and first-class instead of a crippled attach;
- control actions stop hiding inside log panes;
- debug exec becomes a loud deliberate move rather than a silent side effect;
- sideband access becomes visible and temporary instead of ambient.

Guardrail:
- observe/query lanes, attach lanes, control-message lanes, exec/debug lanes, sideband lanes, and durable transcripts must stay visibly different in pane chrome and receipts.

## 20. Semantic inspector overlay + restricted badge + prompt-local clicks
Steal from REF-WEZTERM-ZONES, REF-WEZTERM-USERVARS, REF-ITERM-SHELLINT, REF-GHOSTTY-OSC133-OVERLAY, REF-VSCODE-WORKSPACE-TRUST, and REF-PLAN9-PLUMB.

A ViewFS-native terminal should be able to show, without guesswork:
- which regions are prompt, input, output, sideband, or history-only transcript material,
- whether the current pane is `trusted`, `restricted`, `receipt only`, or carrying `compat debt`,
- which printed links are refs, receipts, route sheets, or plain text,
- and whether click-to-cursor is only valid inside the active prompt/input zone.

Why this is great:
- the shell can become much more interactive without hiding where live authority begins and ends;
- protocol bugs become debuggable because the terminal can display what semantic regions it believes exist;
- restricted-but-productive panes stop feeling broken because the terminal can explain their posture directly in chrome.

Guardrail:
- semantic overlays, trust badges, and typed links are explanatory surfaces; they must not silently widen access, auto-rebind old authority, or turn history text into live handles.


## 21. Pane vars, not env vars, for terminal truth
Steal from REF-WEZTERM-USERVARS, REF-WEZTERM-SHELL-INT, and REF-ITERM-SHELLINT.

The terminal should know some pane/session facts because the shell tells it deliberately, not because the child process environment happens to leak them.

Good candidates:
- active view label
- synthetic cwd label
- restricted/trusted/receipt-only posture
- current route-plan / task / request badge state
- ambient-debt present/clear

Why this is great:
- terminal chrome can stay truthful without pretending those badges are process authority;
- pane state can survive UX actions like splits, inspectors, and palette navigation without becoming hidden child config.

Guardrail:
- pane vars are explanatory metadata, not child-visible authority and not durable grants.

## 22. Scroll-to-prompt, zone-select, and prompt-local editing
Steal from REF-WEZTERM-ZONES, REF-ITERM-SHELLINT, and REF-GHOSTTY-OSC133-OVERLAY.

Once semantic prompt/input/output zones exist, the shell+terminal should exploit them shamelessly:
- jump to previous/next prompt
- select one command block exactly
- copy only the current output zone
- place the cursor by click only inside the live prompt/input zone

Why this is great:
- huge transcripts stay navigable;
- the interaction model stops pretending old output is editable current input.

Guardrail:
- zone navigation and selection must never silently turn transcript text into live handles or rerun commands on click.

## 23. Semantic history, but with truth labels on every row
Steal from REF-ITERM-SHELLINT, REF-ITERM-SEMHIST, REF-WARP-BLOCKS, and REF-PLAN9-PLUMB.

The shell should have glorious searchable history, but each row should declare what it actually is:
- plain text command
- typed route sheet
- receipt
- durable ref
- stale ref
- heuristic file-like guess

Why this is great:
- users get fast reuse without confusing “I once saw this path-like string” with “I still have authority”.

Guardrail:
- heuristic rows should be visibly heuristic, and replay from history should pass through the same route-plan / rebind / reconsent discipline as anything else.


## 24. Trusted review lanes + collapsible command sections + steering rails
Steal from REF-VSCODE-WORKSPACE-TRUST, REF-VSCODE-109-BGAGENTS, REF-VSCODE-110-TERMSECTIONS, REF-NUSHELL, and REF-PLAN9-PLUMB.

The ViewFS terminal should get more powerful in exactly the places where ordinary terminals get muddy:
- commands with side effects or widened authority should land in a separate trusted review lane instead of ordinary scrollback;
- long-running requests should expose `queue`, `steer`, `stop`, and `fork fresh` controls as structured chrome attached to the active lane;
- each command block should collapse to a compact header that preserves the exact command, scope, authority delta, basis/witness, and result badge;
- structured outputs should be explorable as rows/fields/receipts rather than forcing users to scrape plain text when the shell already knows the object shape.

Why this is great:
- the transcript stays readable even when commands get verbose or multi-step;
- steering a running action becomes an honest control surface instead of a folklore interrupt ritual;
- restricted workspaces and trusted review steps remain productive because the terminal explains why a lane is gated;
- typed route sheets, receipts, and object rows become first-class terminal citizens instead of side-panel exiles.

Guardrail:
- review lanes, collapsible sections, and structured drawers are explanation and approval surfaces; they must not auto-approve, auto-rerun, or silently coerce transcript text into live commands.

## 25. Handle lockers and resumable lanes instead of magical saved terminals
Steal from REF-FUCHSIA-IDLE-STOP, REF-SYSTEMD-FDSTORE, REF-XDG-REQUEST, and REF-XDG-FILETRANSFER.

The terminal should have a compact surface for lanes that can actually resume later:
- a locker card that says whether the thing is a live handle set, a resumable request, a restart-only lane, a durable reopen ref, or history only;
- explicit expiry / discard / preserve controls;
- clear scope labels like `this pane`, `this restart`, `this session`, or `durable reopen required`;
- a stale state that stays useful for explanation without pretending the lane is still live.

Why this is great:
- continuity becomes honest and inspectable instead of a spooky “saved terminal” myth;
- users can tell whether a restart is likely to work before they bet on it;
- shell chrome can surface useful resumable work without confusing it with receipts or durable grants.

Guardrail:
- a locker card must never imply that side effects, outputs, or authority were fully restored unless a stronger seam explicitly says so.

## 26. Action menus from exact affordances, not path folklore
Steal from REF-ANDROID-SAF, REF-ANDROID-DOCPROVIDER, REF-XDG-DOCUMENTS, and REF-PLAN9-PLUMB.

When the user selects or inspects an object, the shell should derive the action menu from exact object truth:
- what rights are on the current handle;
- what operations the provider/document surface says are supported;
- what transfer / reveal / reopen lanes are actually available;
- what is only a shell guess or a text heuristic.

Why this is great:
- menus become trustworthy because unsupported verbs disappear early or explain themselves;
- the same object can appear in several places without each path teaching a different lie;
- route sheets can show why `open`, `edit`, `share`, `reveal`, or `export` are present or absent.

Guardrail:
- a filename, extension, or old transcript row must not outrank explicit object/handle affordance truth when the shell decides which verbs to show.


## 27. Sealed staging capsules and commit-last rails
Steal from REF-MEMFD-CREATE, REF-MEMFD-SEALS, REF-UNIX-SCMRIGHTS, and REF-PLAN9-PLUMB.

The terminal should have a first-class way to hold exact bytes before they become durable objects:
- a **draft capsule** while bytes are still being assembled or returned from an external editor;
- a **sealed capsule** once reviewable bytes are frozen for comparison or transfer;
- an explicit **courier** act when that exact capsule is handed to another local process;
- a later **commit** act if those bytes deserve object-store identity;
- and a visible **discard** path when the capsule should simply vanish.

Why this is great:
- preview/import/export/editor-return flows can stay exact without smuggling path reopen folklore back into the design;
- the shell can show `draft`, `sealed`, `couriered`, `committed`, or `discarded` as truthful state instead of hiding everything behind temp files;
- compare-before-commit becomes natural because the staged bytes are a first-class thing.

Guardrail:
- a sealed capsule is not automatically a committed object, a durable reopen grant, or a standing capability; couriering exact bytes is still a narrower act than binding or persisting authority.



## 14. Activation-kit cards before launch
A launch should be able to open a tiny **activation-kit card** that says what is about to be handed to the child:
- view roots
- cwd/root synthetic bindings
- exact handles
- staged capsules
- continuity lockers
- ambient debt if any

Why this is great:
- startup stops looking like magic rediscovery
- the user can tell which resources are already in hand before the child runs

Guardrail:
- activation-slot names are not object identity, and they should not masquerade as durable reopen promises

## 15. Block truth ladder and action gates
A super-awesome terminal should treat visible command blocks as having a **truth grade**, not one fake universal trust bit.

Useful early ladder:
- visible text only
- marked block
- shell-reported command
- receipt-bound reviewed action object

Why this is great:
- the terminal can stay fast and humane without overclaiming what it knows
- stronger actions like replay, reopen, or route reuse can be gated on stronger truth

Guardrail:
- downgrade paths should keep nearby safe actions available instead of relabeling weaker truth as the stronger one

## 16. Selection packets and a separate primary target
Selections should become small explicit packets with kind, bounds, trust grade, context witness, and allowed action families.
At the same time, the shell should keep one separate **primary target** for strong keyboard actions and live routing.

Why this is great:
- selecting a historical object does not silently steal the role of the live target
- path-like text, receipt cards, prompt input, and reviewed command blocks can each get the right action ladder

Guardrail:
- hover or selection alone should never silently authorize rerun, reopen, or stronger binding

## 17. Badged-handle drawers
When a handle copy is minted or attenuated, the shell should be able to show a compact drawer with:
- issuer/source
- badge or witness tag
- rights delta
- activation slot or route-plan source
- exact object ref when known

Why this is great:
- users can understand where live authority came from without reading a novel
- copied-handle lineage becomes reusable shell truth instead of hidden runtime folklore

Guardrail:
- a badge or witness tag describes the copy/issuer lane, not the object's immutable identity


## 18. Peer-witness courier drawers
Steal from REF-UNIX-SCMRIGHTS, REF-SOCKET-PASSCRED, REF-SEL4-BADGES, and REF-PLAN9-PLUMB.

When a live handle, staging capsule, or routed packet is couriered locally, the shell should be able to open a compact drawer that shows:
- who sent it or what lane it came from
- what witness quality exists (`peer creds`, `issuer badge`, `route sheet`, `shell-only label`)
- what exact live things arrived
- what is still live now versus what is already history-only

Why this is great:
- exact local transfer becomes explainable without lying that the sender witness is the object's immutable identity
- the user can tell the difference between “same object, different copy lineage” and “new object I have never seen before”
- route sheets and review lanes become much more trustworthy because source context stays attached to the courier act

Guardrail:
- a courier witness is not a universal trust bit; it describes the courier lane or peer, not carte-blanche authority over whatever arrived.

## 19. Promote reviewed command blocks into explicit command packets
Steal from REF-VSCODE-106-ATTCMD, REF-VSCODE-SHELLINT, REF-NUSHELL, and the sibling Schell terminal notes.

A future custom shell should let the user promote a strongly-known command block into a **command packet** that can be routed, attached, or reviewed elsewhere.
Good early fields:
- command line / argv-ish text
- exit code or result state
- captured output slice or exact output reference
- cwd / target context when known
- truth grade and nearby witnesses / receipts

Why this is great:
- helper escalation stops depending on copy/paste from raw transcript text
- the terminal can share exactly what happened without pretending the whole session must be exported
- route sheets, review lanes, and later shell tools get a truthful structured object instead of a fragile text blob

Guardrail:
- packet promotion should be explicit, and a command packet is not automatically a rerun approval, durable receipt, or standing authority grant.


## 20. Live process cards with explicit right badges

A future custom shell should let a reviewed command block open a compact **live process card** while the command is still running.

That card should show:
- exact running-versus-history state,
- the current command packet / launch basis,
- whether the shell only has `wait`, `interrupt`, `terminate`, or stronger `inspect/debug` rights,
- and what witness/receipt will remain after exit.

Why this is great:
- the shell stops pretending that a PID in text is the command object;
- users get truthful control affordances without hidden debugger power;
- exit transitions become clean: `running now` can degrade to `history only` without losing context.

Guardrail:
- a live process card must not silently imply namespace entry, fd duplication, or debugger attach just because the shell can still stop or wait on the process.


## 14. Paste should become a visible input-origin lane, not a hidden command trigger
Steal from REF-XTERM-BRACKETED-PASTE.

When the shell is at a live prompt, pasted bytes should arrive as a distinct input-origin class.
The shell can then offer:
- plain paste into the prompt,
- quoted paste,
- paste into a scratch capsule,
- inspect-before-run for multi-line command paste,
- or route selected pasted paths/URIs through a typed route sheet instead of raw execution.

Why this is great:
- pasted text stops pretending to be the same thing as deliberate keystrokes
- multi-line clipboard accidents get a truthful safety rail
- imported snippets can become inspectable objects instead of disappearing into transcript folklore

Guardrail:
- paste origin should not silently authorize execution; the shell must keep `pasted`, `edited after paste`, and `explicitly launched` as different truths.

## 15. High-fidelity key packets can make terminal UX both richer and more honest
Steal from REF-KITTY-KEYBOARD.

When the terminal and shell both support it, key input should be able to arrive as disambiguated key packets instead of lossy legacy byte collisions.
That unlocks:
- shortcut layers that do not collide with transcript text,
- real press/repeat/release handling for TUIs and inspectors,
- prompt-local navigation and selection gestures that stay separate from transcript actions,
- and pane-level command/input widgets that do not rely on guessy escape-sequence folklore.

Why this is great:
- terminal interaction becomes less ambiguous and more inspectable
- richer shell chrome no longer has to steal ordinary text bytes to mean control actions
- custom ViewFS tools can have powerful keyboard UX without pretending every feature is just “characters in the PTY”

Guardrail:
- key packets are transport truth, not authority; richer shortcuts must still honor the same action gates, review lanes, and receipt-writing rules as mouse or palette actions.

## 21. Launch basis cards should expose exact exec meaning before run
Steal from REF-MAN7-FEXECVE, REF-MAN7-EXECVEAT, REF-SYSTEMD-CREDENTIALS, REF-VSCODE-SHELLINT, and the SlopOS Capshell notes.

Before a command executes, one action should open a compact **launch basis card** showing:
- exact exec object identity when known,
- whether launch is by held handle, exact staged bytes, or still carrying path-shaped debt,
- explicit interpreter/script-entry arrangement,
- argv/env/cwd deltas from the current pane baseline,
- and whether startup credential slots are present.

Why this is great:
- users can tell whether they are launching one reviewed object or just hoping a mutable name still points somewhere sensible;
- launch review becomes much more honest without forcing a heavy debugger or package-manager UI;
- restricted/review-first shells stay productive because the user can see what is missing before commit.

Guardrail:
- a launch basis card must not dump secret contents into transcript flow, and a path-shaped fallback should stay loud debt rather than quietly pretending to be exact launch identity.

## 22. Startup credential drawers should be explicit and content-minimizing
Steal from REF-SYSTEMD-CREDENTIALS and the SlopOS app-secret boundary notes.

When a child receives startup credentials, the shell should be able to show a compact drawer with:
- slot/name labels,
- origin lane or issuer,
- whether the credential is activation-only and immutable during the run,
- whether the child saw it as a private file, handle, or another narrow carrier,
- and what receipt or audit row remains after launch.

Why this is great:
- secrets stop leaking into environment folklore and transcript cargo-culting;
- users can review launch posture without ever seeing the secret material itself;
- launch replay and diff UX get much better because `credential slot present` is visible truth.

Guardrail:
- the drawer should reveal presence, origin, and lane quality, not the secret bytes themselves, and it must not imply durable reopen or standing share authority.


## 23. Closure-certainty badges should expose loader risk before run
Steal from REF-LINUX-LDSO, REF-LINUX-DLOPEN, REF-WIN-DLL-SEARCH, REF-WIN-LOADLIBRARY, and the SlopOS Capshell code-closure notes.

Before or just after a launch review, one action should open a compact **closure certainty** drawer showing:
- whether startup code closure is exact, partially known, or still carrying ambient loader debt,
- whether runtime resolution can still consult mutable search roots such as current-directory, PATH-like, or loader-specific search paths,
- whether later plugin/module imports are disabled, review-gated, or unconstrained,
- and what receipt remains if the process later asks for more code.

Why this is great:
- users can finally see the difference between `I launched one exact object` and `I launched one object that can still go shopping for code`;
- loader/search-order risk becomes visible without making the shell pretend to be a package manager or debugger;
- plugin/import review becomes a first-class shell action instead of a mystery hidden behind one green run button.

Guardrail:
- closure-certainty chrome should advertise truth and debt, not promise a final closure model; exact startup closure, compat debt, and later import approvals must remain visibly different classes.


## 23. Clipboard offer cards and paste ladders
Steal from REF-WAYLAND-PRIMARY-SELECTION, REF-X11-ICCCM-SELECTIONS, REF-KITTY-CLIPBOARD, and the existing transfer-lane notes.

A future custom shell should be able to surface a compact **clipboard/selection offer card** that shows:
- current owner/source witness when known,
- offered MIME types / representations,
- the one representation actually accepted,
- whether the result became prompt input, scratch-capsule bytes, or a local imported object,
- and whether some privileged clipboard-history manager retained it.

Why this is great:
- paste stops being a magical side door back to ambient paths or hidden durable grants;
- the user can choose `paste`, `quote`, `inspect`, `import`, `bind here`, or `receipt only` from one truthful ladder;
- rich terminal UX becomes safer because clipboard history and current selection ownership stay visibly different truths.

Guardrail:
- selection ownership or clipboard-manager retention must not masquerade as durable reopen authority or as proof that a local object was imported.


## 24. Foreground baton cards and TTY lease badges
Steal from REF-LINUX-CREDENTIALS-JC, REF-LINUX-SETPGID, REF-GLIBC-LOGINTTY, REF-LINUX-TTY4, REF-VSCODE-SHELLINT, and REF-GHOSTTY-OSC133-OVERLAY.

A future custom shell should be able to surface a compact **foreground baton** card showing:
- the exact running command/process card the pane is currently tied to,
- whether the pane is only mirroring output or also has live stdin,
- whether a PTY/controlling-terminal relationship exists,
- whether terminal-generated signals currently target this foreground job,
- and whether the current state is `foreground`, `backgrounded`, `detached`, or `history only`.

Why this is great:
- Ctrl-C, Ctrl-Z, and prompt-local editing stop feeling magical because the user can see who actually owns the turn;
- observe-only panes can stay useful without pretending they are interactive terminals;
- attach/detach flows become much easier to trust because `stream visible`, `stdin live`, `controlling tty`, and `foreground now` are visibly different truths.

Guardrail:
- a foreground baton card should advertise current interactive posture, not promise broad debugger power, namespace-follow power, or durable reopen.


## 25. Runner badges and bootstrap shutters should explain how launch will actually start
Steal from REF-FUCHSIA-RUNNER, REF-OCI-RUNTIME-CONFIG, REF-OCI-PROCESS-CONFIGGO, and the SlopOS Capshell startup-profile notes.

Before a command executes, one action should open a compact **runner / bootstrap** card showing:
- the selected runner/runtime family when known,
- whether that runner selection is explicit, environment-provided, or still carrying compat debt,
- whether startup is `clean`, `explicit customization bundle`, or `startup-hook / profile debt blocked`,
- whether the resulting session is expected to be `interactive`, `batch`, `detached helper`, or `receipt only`,
- and what lifecycle controller or follow/stop lane will exist after start.

Why this is great:
- users can tell the difference between “I am launching this exact thing” and “some runtime will decide how to host this later”;
- clean-start shells stay honest about startup hooks and profile debt without forcing an all-or-nothing policy UI;
- replay and route-plan diffs get much more useful because runner change and bootstrap change stop masquerading as object change.

Guardrail:
- runner badges and bootstrap shutters should advertise hosting truth and debt, not promise reproducibility or broader authority than the actual launch/session lanes provide.

## 26. Mutable prompt docks should stay separate from scrollback history
Steal from REF-ITERM-CMDSELECT, REF-ITERM-CLEARBUFFER, REF-ITERM-SHELLINT, and the sibling Schell terminal notes.

A future custom shell should treat the **live mutable prompt area** as a first-class object distinct from command blocks and scrollback history, with features like:
- `clear scrollback, keep prompt dock`,
- `zoom or share this command block without touching the live draft`,
- prompt-local notes/scratch text that do not rewrite history,
- and explicit promotion from draft prompt input into a reviewed command packet.

Why this is great:
- the user can clear, filter, or share history without losing unsent work;
- command selection becomes more powerful because selected history and live draft input are visibly different classes;
- review-first shells can keep a trustworthy `draft -> reviewed -> launched -> history` ladder instead of flattening everything into one terminal buffer.

Guardrail:
- the mutable prompt dock is local unsent state, not a durable recipe, not a running session, and not a history row; promotion across those seams should stay explicit and receipted.

## 27. Twin-handle badges and duplicate-versus-reopen ladders
Steal from REF-MAN7-OPEN, REF-MAN7-DUP, REF-UNIX-SCMRIGHTS, REF-LINUX-PIDFD-GETFD, REF-LINUX-FLOCK, and the SlopOS Capshell handle-table notes.

A future custom shell should be able to surface a compact **handle topology** drawer showing:
- the current slot/local binding in this pane or child,
- whether this handle is a live alias to another current handle,
- whether the alias shares cursor/status/lock/lease state,
- whether a `reopen independently` action is available,
- and what receipt/history row remains after a duplicate, lend, or reopen decision.

Why this is great:
- users can finally tell `same object` from `same live cursor` and stop being surprised by cross-pane reads/writes that move together;
- import/transfer UX gets more honest because `lend current live handle` and `mint fresh reopen` stop masquerading as one generic share action;
- review-first shells can offer safe narrower actions such as `reopen independently` instead of pushing users toward accidental live aliasing.

Guardrail:
- a twin-handle badge must advertise current aliasing truth, not promise durability, universal portability, or debugger-grade powers just because two handles currently share one open state.

## 28. Handle-class badges and open-for-more-power ladders
Steal from REF-LINUX-OPATH, REF-LINUX-STATX, REF-LINUX-OPENTREE, and the SlopOS cwd-root / handle-table posture notes.

A future custom shell should be able to surface a compact **handle class** card showing:
- whether the current thing is only a locator/root handle,
- whether it supports metadata-only inspection,
- whether it is readable or writable *right now*,
- whether `open for read` / `reopen for write` / `exec now` would mint a different operational handle,
- and what durable ref or receipt remains after the live handle goes away.

Why this is great:
- portal-mediated imports become much more honest because `selected` or `bound here` no longer quietly means `bytes already readable`;
- per-pane namespace badges can stay useful without pretending every root/object handle is already a data stream;
- review-first shells can offer inspect-first flows and only later escalate to byte I/O when the user actually wants it.

Guardrail:
- a handle-class badge must advertise current operational truth, not promise durability, universal portability, or that every backend exposes exactly the same classes.

## 29. Inheritance shutters, child-slot maps, and authority-leak sirens
Steal from REF-MAN7-OPEN, REF-MAN7-EXEC3P, REF-MAN7-POSIX-SPAWN, REF-MAN7-CLOSE-RANGE, REF-MAN7-FCNTL, REF-OPENBSD-FCNTL, and the SlopOS activation / handle-table posture notes.

A future custom shell should be able to surface a compact **launch-boundary** card showing:
- which live handles are currently held in this pane,
- which of them are shuttered from launch by default,
- which ones are explicitly selected to cross the boundary,
- the exact child-local slot/name each reviewed copy will land in,
- and what launch receipt/history row remains after the child exits.

Why this is great:
- users can finally tell `held here` from `child will receive this`, which is one of the oldest and easiest authority-leak mistakes in process-launch history;
- launch review becomes much more honest because `run this` stops quietly meaning `and also inherit whatever else happened to be open`;
- review-first shells can offer narrow fixes such as `shutter all extras`, `pass only stdio`, or `name this child slot explicitly` instead of making inheritance hygiene guesswork.

Guardrail:
- a launch-boundary card must advertise current inheritance truth, not promise durability, restart continuity, or universal cross-runtime portability just because one reviewed child launch received a copy.

## 30. Two-anchor rename cards, collision-mode ladders, and name-diff receipts
Steal from REF-FUCHSIA-FSARCH, REF-FREEBSD-RIGHTS-LIVE, REF-MAN7-RENAME, and the SlopOS cwd-root / document-portal notes.

A future custom shell should be able to surface a compact **namespace mutation** card showing:
- the object identity being discussed,
- the source parent anchor that currently owns the old name,
- the destination parent anchor that would receive the new name,
- the mutation mode (`rename`, `link`, `unlink`, `replace`, `exchange`),
- the collision posture (`create new only`, `replace if exists`, `exchange names`),
- and what receipt/history row remains after the namespace edit.

Why this is great:
- users can finally tell `same object, new name` from `new object imported` or `new byte handle opened`;
- cross-parent moves stop being magic because the shell can show both anchors explicitly instead of hiding them behind one path string;
- review-first shells can offer narrower actions such as `create new only` or `exchange names` instead of one dangerous overwrite-by-default move button.

Guardrail:
- a namespace-mutation card must advertise current naming/anchor truth, not promise byte-I/O authority, durable reopen, or that every backend supports every collision mode natively.


## 31. Propagation badges, blast-radius previews, and attach-private-first rails
Steal from REF-MAN7-MOUNTNS, REF-LINUX-OPEN-TREE, REF-LINUX-MOUNT-SETATTR, and the SlopOS view / replication posture notes.

A future custom shell should be able to surface a compact **bind propagation** card showing:
- that something is attached *here* right now,
- whether later namespace changes stay local, propagate to peers, or only arrive from an upstream/master lane,
- whether the bind is intentionally not cloneable / unbindable,
- any current peer/upstream relationship the shell knows about,
- and what receipt/history row remains after the attach or rebind act.

Why this is great:
- users can finally tell `bound here` from `bound here and may affect other views`, which is exactly the kind of hidden blast radius that capability-honest namespace UX should make explicit;
- attach/rebind review becomes much more honest because `attach this fragment` stops quietly meaning `and inherit whatever propagation posture happened to exist`;
- review-first shells can offer narrower actions such as `attach privately first` or `receive-only mirror` instead of one generic bind button.

Guardrail:
- a bind-propagation card must advertise current blast-radius truth, not promise durable replication, universal peer IDs, or one portable shared-subtree mechanism across all ViewFS backends.


## 32. Draft-object cards, publish-later ladders, and publication receipts
Steal from REF-LINUX-OTMPFILE, REF-MAN7-LINKAT, and the SlopOS CapStore / view-namespace posture notes.

A future custom shell should be able to surface a compact **publication** card showing:
- that an object already exists even though it has no public name yet,
- the candidate parent anchor or view where it could be published,
- the collision posture (`new only`, `replace`, `exchange`) where supported,
- whether publication would also create a live bind in the current pane or only a durable receipt,
- and what receipt/history row remains after the publication act.

Why this is great:
- users can finally tell `I received or built exact bytes` from `those bytes now have a visible name here`, which is a huge honesty win for imports, saves, exports, and editor-return flows;
- review-first shells can offer `publish later`, `publish privately first`, or `discard draft` instead of forcing every staging flow through temp-name folklore;
- namespace mutation UX gets safer because parent anchors and collision posture become explicit before anything becomes visible.

Guardrail:
- a publication card must advertise current naming/publication truth, not promise durable reopen, universal backend support for every collision mode, or that history rows are bearer authority.


## 33. Descriptor cards, hydrate-later ladders, and object chips that outlive authority
Steal from REF-OCI-DESCRIPTOR, REF-IPFS-CIDS, REF-VSCODE-SHELLINT, and the SlopOS artifact-reference posture notes.

A future custom shell should be able to surface a compact **descriptor card** showing:
- one digest/object ID,
- media type and byte size when known,
- any locator hint or source hint marked as non-authoritative,
- whether the current truth is `descriptor only`, `local bytes present`, `live handle now`, `published here`, or `receipt only`,
- and what receipt/history row remains after hydrate/bind/publish acts.

Why this is great:
- users can finally tell `I know what object this is` from `I can stream bytes right now`, which is exactly the distinction a capability-native object store needs;
- transcript/history can keep useful object chips even after authority expires because the shell is honest about descriptor-versus-handle truth;
- review-first shells can offer narrow follow-on acts such as `hydrate`, `bind here`, `publish here`, or `request portal import` instead of overloading one generic open button.

Guardrail:
- a descriptor card must advertise descriptor truth, not promise current byte-I/O authority, stable naming, durable reopen, or universal backend support for every follow-on act.


### 34. Localize-first import cards and docref ladders
When the user drags, pastes, chooses, routes, or receives one outside object, the shell should not instantly pretend that one durable local file already exists.
Instead it should surface one compact card that can honestly move through states like:
- `source ref only`
- `inspect source`
- `materializing`
- `fresh local object`
- `mint local docref`
- `bind/publish here`
- `receipt only`

Why this is super awesome:
- it makes portal/import boundaries visible instead of magical;
- it gives ViewFS one truthful place to show when local identity exists even before publication;
- it prevents the UI from laundering remote/source-side designation into local durable reopen.

### 35. Remembered, live, and provisional truth labels
The shell should treat truth labels as first-class chrome:
- `live now`
- `remembered`
- `provisional`
- `stale`
- `grant needed`
- `history only`

Why this is super awesome:
- it lets transcript rows and object chips stay useful after authority expires;
- it lets semantic shell integration be ambitious without pretending every parsed signal is equally authoritative;
- it gives operators the kind of confidence/debug posture that normal terminals hide.

### 36. Semantic epoch badges and resync rails
Every semantic side-channel stream should carry a visible epoch or run-local barrier marker so the terminal can say:
- `semantics synced to current shell`
- `late event from previous run`
- `provisional until barrier`
- `resync requested`

Why this is super awesome:
- it keeps command/object chrome honest when shells restart, panes reconnect, or helper plugins lag;
- it gives the custom shell a visible recovery move that is much better than silently hallucinating state;
- it lets advanced users debug shell integration without turning the whole terminal into protocol soup.


### 37. Reopen truth ladders and continuity lockers
When one object is only *remembered* rather than live, the shell should say so plainly.
A future custom shell should be able to render states like:
- `remembered designator`
- `revalidating now`
- `exact locker available`
- `revived live handle`
- `stale or moved`
- `grant needed`
- `history only`

Why this is super awesome:
- it lets restart/reopen UX feel powerful without lying about current authority;
- it gives users a clean mental model for why some objects come back instantly while others need revalidation or user help;
- it makes narrow manager-held continuity lockers useful without letting them silently grow into ambient persistent power.

### 38. Stale-target repair rails and continuity shelves
The shell should have one continuity shelf that can hold remembered-but-not-live objects and show what kind of repair is possible:
- `revalidate same target`
- `ask user again`
- `mint fresh local object`
- `discard remembered designator`
- `keep receipt only`

Why this is super awesome:
- stale or moved targets become explicit product states instead of weird broken-open failures;
- users can repair continuity without losing transcript context or pretending history rows are bearer authority;
- the same UI can cover portal docrefs, bookmark-like reopen, and exact restart lockers while keeping each lane honest.


## Transfer sheets and adoption rails

A future ViewFS shell should make cross-pane, shell-to-app, and app-to-shell exchange brutally honest.

When something is about to cross a boundary, the shell should be able to present a **transfer sheet** with visibly different choices such as:
- `offer only`
- `accept as bytes`
- `accept live copy`
- `accept attenuated live copy`
- `store revival designator`
- `adopt into this pane now`
- `receipt only`

Why this is great:
- it keeps `shared` from silently meaning `bound here with authority now`;
- it lets users pick a weaker/friendlier lane when that is enough;
- it keeps cross-pane and shell-to-app exchange aligned with a capability-native object store instead of recreating ambient clipboard/path folklore.

The terminal should also have compact **issuer/courier witness chips** such as `from pane 3`, `from route plan`, `from app handoff`, or `from reviewed import`, while keeping those chips visibly separate from object identity and separate again from current authority.

And once the receiver does something stronger, the shell should show an **adoption rail**:
`offered` → `received` → `adopted here` → `revalidate later`

That keeps the transcript honest about when something merely arrived, when it became current authority, and when only a later-designator remains.

## 12. Inert designator paste by default
Steal from REF-W3C-CAPURL, REF-OCAPN-LOCATORS, REF-XDG-DOCUMENTS, and REF-MS-SECBOOKMARK-CVE2025.

The shell should distinguish:
- plain designation text,
- typed designator chips,
- authority-bearing tickets,
- and live current handles.

Why this is great:
- users can copy references into notes, tickets, and chats without accidentally delegating authority;
- dangerous bearer-ish artifacts stop masquerading as innocent strings.

Guardrail:
- “reveal authority” should be a later explicit route-sheet action, never the default effect of paste or hover.


## 13. Caveat laminates and membrane badges
Steal from REF-MACAROONS-NDSS14, REF-ZCAP-LD, REF-SEL4-MANUAL-LATEST, REF-CAPSICUM-HANDBOOK, and the SlopOS D-LEASE posture.

The shell should distinguish:
- declared caveat cards,
- enforced membrane / lease badges,
- live local handle badges,
- revival designators for later,
- and receipt-only history rows.

Why this is great:
- users can see whether bounds are merely described or actually enforced now;
- renewal/revalidation becomes a visible ladder instead of spooky delegated magic;
- capability-heavy flows get more humane without lying about where authority lives.

Guardrail:
- every transcript card that shows caveats should also show an **enforcement locus** such as `proxy`, `verifier`, `local handle`, or `none/history`.

### 18. Permission lights versus death certificates
Steal from REF-W3C-PERMISSIONS, REF-WICG-FSACCESS, REF-XDG-DOCUMENTS, and REF-ANDROID-SAF:
- the transcript and side chrome should render **permission outlook** separately from **current live authority** and separately again from **dead-state verdicts**
- permission lights should carry explicit preflight states like `granted`, `prompt`, `denied`, `revalidate`, and `policy blocked`
- death certificates should carry explicit negative states like `revoked`, `expired`, `target changed`, `issuer offline`, `deleted`, and `history only`
- repair ladders should point at exact next verbs like `request`, `revalidate`, `rebind`, or `import fresh`
- live-handle badges should remain distinct again

This is another “super awesome” move because it turns one of the most confusing security/lifecycle truths into ordinary legible shell chrome instead of generic red errors.


### 19. Provenance ribbons, endorsement stacks, and verdict shutters
Steal from REF-RATS-RFC9334, REF-RATS-ENDORSEMENTS-DRAFT, REF-IN-TOTO-ATTESTATION, REF-SLSA-PROVENANCE, REF-TUF-ROLES, REF-SIGSTORE-REKOR, and Helm's trusted-chrome ideas:
- the transcript should render **provenance ribbons** separately from **endorsement stacks** and separately again from **local verdict shutters**
- provenance ribbons should answer `imported from`, `built by`, `derived from`, `reviewed from`, or `unknown` without implying admission
- endorsement stacks should answer `signed`, `threshold met`, `reference matched`, `transparency logged`, or `endorsement missing` without pretending those inputs outrank local policy
- verdict shutters should answer `preview only`, `safe-open only`, `admit document`, `admit runnable`, `needs review`, or `deny` as local shell-owned truth
- live-handle badges should remain distinct again

This is another “super awesome” move because it gives the future shell a way to feel brilliantly informative without turning every signature or attestation into magical current authority.

## 28. Request ledgers, session cards, and adoption shutters

A capability-honest shell should stop flattening portal interactions into one generic `opened` row.
It should keep at least four user-visible things apart:
- the **request row** (`pending`, `succeeded`, `cancelled`, `timed out`),
- the **session or transfer card** (`open`, `active`, `ending`, `closed`, `closed by portal`),
- the **local adoption shutter** (`not adopted here`, `adopted here`, `adoption stale`),
- and the **receipt/history row**.

That would make imports, durable reopen, clipboard/file-transfer, and future portal-heavy shell flows much more honest.
It also makes repair much better because the shell can say `retry request`, `rejoin session`, `retrieve again`, or `adopt locally` instead of guessing.

### Completion ghosts, detail drawers, and packet gutters
The shell should treat completion as a little state machine instead of one vague popup:
- **candidate ghost** — ranked advisory row only
- **detail drawer** — extra docs/provenance/rights hints fetched for one focused row
- **accepted insertion** — now in the mutable prompt buffer, still not a plan
- **compiled packet gutter** — parsed/bound against current pane objects and receipts
- **prepared action chip** — ready / approval needed / portal needed / rebind needed

That buys us several excellent moves:
- fish-style accept-one-word speed without accidentally invoking anything,
- LSP-style lazy detail without changing the insertion meaning underneath the user,
- MCP-style advisory completion without letting suggestions impersonate chooser defaults,
- and VS-Code-style trusted-shell packets without giving heuristic transcript scraping the same power.

A beautiful terminal trick here would be a **rerun safety badge**:
- `history text only`
- `heuristic packet`
- `shell reported`
- `nonce verified`
- `object composed`

Only the stronger grades should be eligible for no-confirmation replay.

## 35. Entity peels and route slips
A future custom shell should be able to treat highlighted transcript text, OSC 8 links, and hint-picked regions as **selection surfaces**, not as already-routed actions.

The delightful move is a tiny two-step ladder:
- first, an **entity peel** that says what the region seems to be (`plain text`, `path-ish`, `line ref`, `receipt ref`, `object ref`, `URI`, `explicit link`);
- second, a **route slip** that promotes one chosen meaning into one typed action basis such as `inspect`, `reveal`, `import here`, `open in tool`, `launch uri`, or `compose packet`.

Why this is super awesome:
- transcript navigation becomes much more capable than ordinary terminal hyperlinks;
- shell routing stays typed and reviewable;
- users can move quickly from output to the next action without letting selection itself become authority.

Guardrail:
- selected bytes, extracted meanings, routed envelopes, and prepared actions must stay visibly different truths.

## 36. Activation batons and arming rails
Steal from REF-HTML-USER-ACTIVATION, REF-XDG-ACTIVATION-V1, REF-XDG-INPUTCAPTURE, REF-MS-ALLOWSETFOREGROUND, and REF-MS-COALLOWSETFOREGROUND.

The shell should make interaction proof visible instead of spooky.
It should distinguish:
- **fresh gesture proof** (`click`, `keypress`, `shortcut`, `notification action`)
- **activation baton** (`may ask to activate`, `may request focus`, `consume once`)
- **armed lane** (`prepared`, `waiting for baton`, `enabled`)
- **active now** (`foreground now`, `capturing now`, `active control`)
- **receipt only**

Why this is super awesome:
- route plans and portal flows can stay fast without pretending every click already committed the stronger act;
- cross-pane/app handoff can say `you may ask to activate` instead of stealing focus or hiding failure;
- the terminal can finally tell the truth about why some actions are currently eligible and others need a fresh gesture.

Guardrail:
- one baton should normally be consume-once, expiring, and visibly weaker than durable authority or durable reopen.


## 37. Place cards, verb ledgers, and affordance lenses
A future custom shell should stop guessing verbs from path shape.
It should instead separate four truths for any focused object:
- **what object is this?**
- **where does it appear here?**
- **what authority do I hold right now?**
- **what operations does the provider currently advertise for this target?**

The delightful moves are:
- **place cards** that show `same object, also appears in …` without pretending those names are the identity;
- **verb ledgers** that show `provider says yes`, `current handle says no`, `policy says ask`, `view says not here`, or `history only`;
- **affordance lenses** that separate identity, placement, rights, verbs, and receipts in one compact drawer;
- **why-not drawers** that answer `rename unsupported here`, `delete supported by provider but not with this handle`, or `thumbnail available` instead of failing late.

Why this is super awesome:
- the shell gets smarter than ordinary file managers without becoming spooky;
- action menus become honest and highly contextual;
- the same object can appear in several places without the shell lying about what is identity versus placement.

Guardrail:
- advertised verbs are not the same thing as current authority, and old receipts are not current affordance truth.


## 38. Type lenses, handler racks, and open-state badges
A future custom shell should stop pretending one suffix or one old default explains everything about opening.
It should instead separate:
- **declared type**
- **derived type**
- **associated handlers**
- **chosen opener for this act**
- **live open state**
- **receipt only**

The delightful moves are:
- **type lenses** that show `declared`, `derived`, `virtual`, `disagrees`, or `unknown`;
- **handler racks** that show `associated`, `default`, `safe preview`, `chosen now`, or `unavailable here`;
- **why-this-opener drawers** that explain whether a route came from explicit user choice, current default, policy, or provider suggestion;
- **open-state badges** that show `previewing`, `editing`, `external`, `portal-owned`, `detached`, `closed`, or `history only`;
- **disagreement cards** with ladders like `inspect as declared`, `inspect as derived`, `safe preview`, `pick representation`, or `stay receipt only`.

Why this is super awesome:
- the shell becomes much smarter than ordinary `Open With…` chrome;
- preview/editor routing gets more legible without becoming spooky;
- and old defaults or old receipts stop masquerading as current openability truth.

Guardrail:
- a type label is not identity, a handler association is not chosen-opener truth, and one chosen opener is not global ambient authority.


## 41. Label ledgers and trusted badge shutters
The shell should be able to render label-like things in a way that never confuses:
- freeform annotations,
- selector-safe labels,
- policy-bearing labels,
- shell-owned trusted badges,
- and history.

What this unlocks:
- smart baskets and filters can rely on visibly query-safe labels instead of arbitrary notes;
- quarantine/review/sensitivity labels can live in stronger trusted chrome;
- copied chips can offer explicit ladders like `copy text`, `copy selector`, or `copy receipt`;
- dynamic title/right-status/badge surfaces can stay awesome without becoming spooky.



## 42. Waterline cards and gap-badge stacks
A future custom shell should treat live follow/query state as a first-class semantic lane instead of one hidden spinner.
That means visibly separating:
- `continue token`
- `caught up through`
- `following now`
- `rebuilt snapshot`
- `gap verdict`
- `history only`

The delightful moves are:
- **waterline cards** that show one visible set plus the watermark it is synced through;
- **gap-badge stacks** such as `expired cursor`, `resource version too old`, `must rescan`, or `provider reset`;
- **resync ladders** like `continue`, `wait`, `relist`, `rebuild`, `freeze rows`, or `open receipt`;
- **snapshot-versus-follow split views** so users can compare a stable set with live deltas instead of watching rows jump under the cursor.

Why this is super awesome:
- live query panes become much less spooky;
- the shell can be fast and honest at the same time;
- and provider-specific sync tokens stop masquerading as durable object truth.

## 43. Draft gutters, hold meters, and commit shutters
A future custom shell should stop pretending one local draft already explains concurrent write truth.
It should instead separate:
- **observed base / validator**
- **private writable session**
- **live write hold**
- **exact commit gate**
- **winning durable version**
- **receipt only**

The delightful moves are:
- **stale-base lamps** that say `based on X`, `target moved to Y`, or `history only`;
- **draft gutters** that say `private draft`, `sealed`, `diverged`, `orphaned`, or `receipt only`;
- **hold meters** that say `exclusive`, `advisory`, `renewable`, `expired`, or `none`;
- **commit shutters** that make `if-match`, `if-absent`, `under hold`, `rebase`, and `fork instead` visibly different acts;
- **winner receipts** that show which durable version actually won after a commit attempt.

Why this is super awesome:
- editing gets safer without turning into giant modal lock UI;
- multi-tab and external-tool round-trips become more honest;
- and local close/flush folklore stops masquerading as durable truth.

## 44. Hole maps, range panels, and whole-proof ladders
A future custom shell should stop pretending every object is simply `downloaded` or `not downloaded`.
It should instead separate:
- **current local coverage**
- **known layout**
- **whole-object completeness**
- **whole-object proof**
- **live remote fill**
- **history only**

The delightful moves are:
- **hole maps** that say `prefix`, `holes`, `all chunks`, `full local`, or `unknown`;
- **range panels** that keep `coverage`, `layout`, `proof`, `remote fill`, and `history` visibly separate;
- **whole-proof ladders** that make `fetch missing`, `verify whole`, `seal local`, `stay sparse`, and `open receipt` different acts;
- **offline honesty lamps** that say `fully local`, `partial local`, `remote-fill only`, `proof missing`, or `history only`;
- **composite-checksum warnings** that explain when a current identifier is multipart/composite rather than one whole-object witness.

Why this is super awesome:
- huge objects and lazy imports become understandable instead of spooky;
- the shell can stay fast without lying about what is local;
- and partial residency stops masquerading as durable offline truth.


## 46. Delta cards, basis lamps, and rebuilt-from lineage

When the shell knows an import, repair, or refresh can be satisfied by a delta recipe rather than a full fetch, it should not hide that behind one vague `update` button.
It should be able to show:
- a **basis card** saying `needs base X`, `base local`, `base mismatched`, or `history only`;
- a **delta peel** showing the recipe, exact basis requirement, current apply posture, fallback full-fetch lane, and result lineage;
- an **apply ladder** with actions like `apply in scratch`, `verify result`, `materialize fresh object`, `fetch full target`, or `discard recipe`;
- and a **rebuilt-from badge** saying `rebuilt from X + R` without pretending that means same live handle or same namespace bind.

That is the kind of move that makes the custom shell feel far more truthful and powerful than ordinary `download/update/open` UX.

## Activation sheets, handoff sheets, and copy-lineage drawers
- **Activation-sheet cards** before launch so a pane can show slot, rights, witness, object-ref truth, and reopen-lane truth in one compact review surface.
- **Child-slot maps** after launch so `held here`, `crosses boundary`, `attenuated on entry`, and `history only` stay visibly different.
- **Handoff sheets** for pane-to-pane, tool-to-tool, or app-to-app transfer so `offered`, `accepted`, `adopted here`, and `receipt only` do not collapse into one vague open event.
- **Copy-lineage drawers** that show duplicate vs attenuated copy, issuer badge/peer witness, same-object-ref known/unknown, and current reopen posture.
- **Issuer/courier chips** that are small enough for pane chrome but honest enough not to masquerade as object identity or trust verdict.



## 47. Published-name ledgers and synthetic-view badges
A future custom shell should stop pretending one visible path label already explains object locality and authority.
It should instead separate:
- **in store**
- **projected through a portal/provider view**
- **live handle here now**
- **published here in this process view**
- **receipt only**

The delightful moves are:
- **published-name ledgers** that show every current publication site for one object instead of only the last visible path;
- **synthetic-view badges** like `portal view`, `provider projection`, `published here`, `launch-only`, `stored only`, or `history only`;
- **publish-here ladders** so chooser/import results land in staging before they become current local binds;
- **same-object multi-view diffs** so panes can compare object ref, projection site, current publication, and current handle truth honestly;
- **where-is-it-really drawers** that separate object ref, store presence, live-handle state, publication sites, and durable receipts.

Why this is super awesome:
- portal/import flows stop feeling spooky;
- explicit per-process namespace assembly becomes visible instead of theoretical;
- and pretty path labels stop masquerading as durable object identity or universal reopen truth.

## Ambient-debt sirens and safe-open ladders

One shell move worth stealing now is a **safe-open ladder** that makes the actual access lane visible instead of pretending every successful open was the same act.
For any path-like click, reveal, import, or command-driven open, the shell should clearly step through:
- `use live handle`,
- `walk under held root`,
- `ask portal / mediator`,
- `ambient escape hatch`.

The winning rung should show up in command chrome, receipts, searchable transcript metadata, and explain drawers.
That is the product move that keeps compatibility useful without letting it quietly become the semantic center of ViewFS.

A matching **ambient-debt siren** should light up whenever a command used a host-global escape.
The important part is not shaming the user.
The important part is giving them an exact `replace this debt` route into a cleaner bind, handle, publication, or portal grant next time.


## Browse gates, dark directories, and known-name chips
A capability-honest shell should stop pretending that `shown in a pane` and `openable now` are the same thing.

Steal-worthy moves:
- **dark directories** that allow exact-name opens without automatic listing;
- **browse gates** that visibly escalate from `exact names only` to `list contents`;
- **known-name chips** that attach to command blocks when something opened by exact child name under a held root;
- **fit sheets** that rank candidates as `preferred`, `acceptable`, `advanced`, or `history only`;
- **search-result dimmers** so helper/index/history hits stay visually weaker than direct live authority.

## Presence halos, readiness lamps, and withdrawn ghosts
A future custom shell should be able to say not just `this exists`, but:
- `advertised`,
- `ready now`,
- `grant needed`,
- `withheld`,
- `withdrawn`,
- `history only`.

The delightful moves are:
- **presence halos** around palette/provider rows so soft presence is visible without masquerading as authority;
- **readiness lamps** that decay from `ready now` to `last known` instead of staying eternally green;
- **withdrawn ghosts** so a vanished affordance leaves a dim honest trace;
- **grant-needed ladders** that offer `ask portal`, `rebind here`, `reacquire`, or `show receipt` as distinct next steps;
- **advert ledgers** that explain who advertised something, when, and under what freshness caveat.

Why this is super awesome:
- helper/provider catalogs become much more useful without lying;
- SlopOS-style mediated imports can stay ambitious without prematurely freezing backend state machines;
- and the shell gets a genuinely new kind of honesty that ordinary path UIs almost never provide.


## More shell ideas from the provider-ready/local-realized seam
- object rows should be able to render `provider-ready`, `repair owed`, `realizing`, `local now`, `held now`, and `history only` as different truths;
- a tiny **provider-owned badge** should explain when current usefulness still depends on someone else backing the thing;
- the shell should keep a **make-local ladder** distinct from `bind here` or `hand to child`;
- remembered rows should support **offline fog** when they are only promisor/substituter backed;
- transcript filters should support `show me made-local`, `show me provider-ready`, and `show me repair-required`.


## Step-up ladders, recency shutters, and why-not-now drawers
A future custom shell should stop pretending that `held now` or `local now` already means `invokable now`.

Steal-worthy moves:
- **why-not-now drawers** that distinguish `missing authority`, `too old for this action`, `step-up needed`, `presence needed`, and `history only`;
- **step-up ladders** that show the repair path from `held` to `invokable` without laundering the gap away;
- **recency shutters** that decay honestly from `fresh enough` to `too old for this action`;
- **presence pins** for touch/verify/device-auth-now posture;
- **satisfaction ghosts** that remember one satisfied or failed challenge without reviving it as timeless authority.

Why this is super awesome:
- imports, opens, decrypts, exports, and cross-tool actions become dramatically easier to explain;
- the shell gets a genuinely new kind of honesty that ordinary path UIs almost never have;
- and SlopOS can keep evolving its auth mediation without forcing ViewFS to lie in the meantime.


## Watch-status honesty
- watch braids that keep `held`, `latest status`, `local stance`, `hold`, and `successor refresh` visibly different
- hold rails that make reversible suspension and quarantine first-class, reviewable shell outcomes
- successor lanterns that show `replacement available` versus `replacement adopted` instead of silently flipping state
- stale-watch fog that decays truth honestly without pretending the base handle vanished


## Lend ladders, lane-fit badges, and bytes-only fallbacks
- a **lend ladder** should let the user choose among `duplicate locally`, `lend live`, `lend narrowed`, `projected doc`, `bytes only`, or `receipt only` instead of one vague `share` action;
- **lane-fit badges** should say whether the strongest working route is `socket lend`, `portal export`, `tty transfer`, `bytes snapshot`, or `none`;
- **bytes-only fallback chips** should make weaker but honest export routes feel successful instead of second-class failures;
- **same-object versus new-representation drawers** should explain whether the receiver gets another live reference or one new exported artifact;
- **share receipts** should preserve exact lane truth so transcript history says what actually crossed the boundary.

## Borrow rails, projection badges, and make-here ladders
- **borrow rails** that let a row say `foreign-backed`, `wrapped here`, `projected here`, `make local`, or `history only` instead of one vague `open/import` verb;
- **projection badges** that distinguish `portal view`, `provider projection`, `compat attach`, `materialized replica`, and `local object`;
- **provider-owned halos** plus **dataless/materialized lamps** so smooth UX does not launder foreign-backed state into local-ownership folklore;
- **make-here ladders** that preserve whether the user chose to keep borrowing, project into a pane, or localize explicitly.



## Route slips + sink trays
- A click or command result should be promotable into a **route slip** rather than an immediate side effect.
- Route slips should show **authority sidecars** explicitly instead of burying them in helper magic.
- Every receiving pane should expose a **sink tray** that says what actually crossed the boundary.

## Bracket rails, caller badges, and deputy fog
- **bracket rails** should show when one helper/plugin/notebook block is inside one explicit borrowed-authority region instead of one vague magic-helper mode;
- **caller badges** and **call-frame chips** should answer `who asked?` without laundering that provenance into authority;
- **borrowed-authority drawers** should keep exact borrowed handles/capability classes separate from helper identity and from caller context;
- **deny-only shutters** should explain provenance vetoes in helper/plugin language instead of one fake `permission denied` blob;
- **deputy fog warnings** should appear when one helper falls back from explicit bracketed authority into ambient singleton / ambient async-local state.

## Attach-mode badges, adapter veils, and virtuality lamps
- **attach-mode badges** should let a row say `native`, `adapter`, `relay`, `coerced`, `localized`, or `history only` instead of one vague `open/import/use` verb;
- **adapter veils** should make fd-wrappers, runtime shims, relay services, and projected filesystem glue inspectable instead of invisible;
- **virtuality lamps** should tell the truth when the strongest working lane is one alternate representation or preview surface rather than same-object attach;
- **same-object versus translated drawers** should explain what kind of edit/send/import fidelity the current lane really offers;
- **make-local-for-native ladders** should preserve the exact transition from translated or adapted use into stronger local/native semantics.



## 26. Clean-start lamps and hook quarantine should make startup truth gorgeous instead of ambient
Steal from the SlopOS Capshell startup-profile notes, REF-DIRENV-ALLOW, REF-DIRENV-REQUIREALLOWED, REF-VSCODE-WORKSPACE-TRUST, REF-GHOSTTY-SHELL-INTEGRATION, and REF-POWERSHELL-PROFILES.

A future custom shell should be able to surface a compact **startup truth** card showing:
- whether the pane is `built-in only`, `reviewed bundle`, `host profile active`, `project hook pending`, `project hook denied`, or `history only`;
- which explicit customization bundles are active;
- whether one host/user startup file ran and where it came from;
- whether one project-local activation hook is pending, stale, or quarantined;
- and whether the user can `allow once`, `allow for workspace`, `deny`, or `promote useful bits`.

Why this is great:
- prompt weirdness, alias drift, and environment surprises become explainable instead of mystical;
- browsing a project can stay useful without quietly becoming execution;
- good ambient customizations can graduate into reviewed bundles instead of locking the product into dotfile folklore.

Guardrail:
- startup truth cards should advertise where behavior came from, not silently widen trust or current authority.


## 97. Verb provenance cards, overlay racks, and which ladders
Steal from REF-FISH-ABBR, REF-NU-OVERLAYS, REF-NU-CUSTOMCOMMANDS, REF-NU-WHICH, REF-ZSH-ZLE, REF-GHOSTTY-KEYTABLES, and REF-GHOSTTY-CMDPALETTE.

The shell should make command-surface truth explicit:
- whether the current winner is one built-in verb, one lexical expansion result, one overlay/custom command, one key action, or one external launch;
- which overlay layers are active and what they shadow;
- whether the current pane is in one modal key table;
- and whether one command-palette action is also available as a typed verb or only as a widget/action.

That would let the shell feel dramatically better than classic terminals without regressing into alias/widget folklore.


## Parse lenses and diagnostic rails

Steal from REF-TREESITTER, REF-LSP-DIAGNOSTICS-317, REF-SHELLCHECK, and REF-FISH-SYNTAX.

A future custom shell should make the difference among **editable buffer**, **parsed structure**, **diagnostic rail**, **compiled packet**, and **prepared action** feel obvious.

Great moves:
- **parse lenses** near the cursor that explain current segment structure without pretending the line is ready;
- **recovery fog** over guessed or incomplete regions;
- **diagnostic rails** with source badges like `parser`, `lint`, `policy advice`, and `history`;
- **packet gutters** that only appear after current pane-local binding/compile has happened;
- **compile-diff cards** when the same visible buffer binds differently because pane-local handles or receipts changed.

This is a very low-regret place to be ambitious, because it freezes UI honesty rather than one parser stack.
