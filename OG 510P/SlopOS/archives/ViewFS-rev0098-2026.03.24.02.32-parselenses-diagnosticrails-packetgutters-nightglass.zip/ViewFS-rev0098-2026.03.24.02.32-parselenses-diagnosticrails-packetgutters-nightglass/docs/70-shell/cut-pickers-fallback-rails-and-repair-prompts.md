# Cut pickers, fallback rails, repair prompts, and selection receipts

Purpose: make the ViewFS shell feel **super awesome** while staying brutally honest about which policy family/cut is actually in force.

## North star
A great ViewFS shell should let a user see, at a glance:
- **current judge** — which exact policy family/cut is authoritative for this action
- **consistency posture** — whether the answer came from an exact cut, an at-least-as-fresh cut, a latest/fully-consistent read, or an unknown posture
- **fallbacks available** — which alternates exist without pretending they are already selected
- **repair needed** — when the shell is helping recover from invalid, stale, missing, or mismatched policy state
- **history only** — when the shell only knows what used to be selected, not what is authoritative now

That is the right way to keep the shell fast and helpful without letting it quietly change which judge is in force.

## Shell moves worth stealing

### 1. Policy cut picker
A compact picker should show:
- active family name
- active cut/digest/version tag
- consistency badge
- why this cut won (`explicit`, `bootstrap`, `workspace-local`, `repair accepted`, `receipt replay`, `unknown`)

Super-awesome move:
- one keystroke opens the picker from prompt chrome or a result card.

Guardrail:
- opening the picker is inspect-only until the user commits a change.

### 2. Fallback rail
When another family/cut is available, the shell should show it on a visibly non-authoritative rail.
Good labels might include:
- `same family, newer cut`
- `same family, exact snapshot`
- `same family, latest`
- `workspace suggestion`
- `history only`
- `repair candidate`

Super-awesome move:
- the rail can rank safer/narrower alternates above broader or more magical ones.

Guardrail:
- no fallback may silently become active just because the current cut failed.

### 3. Repair prompt
When a current family/cut is invalid, missing, stale, or mismatched, the shell should show a repair prompt with explicit classes such as:
- `refresh same family`
- `retry at exact cut`
- `retry at-least-as-fresh`
- `ask mediator`
- `inspect diagnostics only`
- `receipt only`

Super-awesome move:
- repair prompts can be one keystroke away from diagnostic cards and why panels.

Guardrail:
- a repair prompt is advice until the user (or a higher-authority tool lane) explicitly accepts it.

### 4. Selection receipt chip
Past selections should be represented as durable chips/cards saying:
- which family/cut was selected,
- what consistency posture was used,
- what interaction chose it,
- whether that information is only historical now.

Super-awesome move:
- result cards and notebooks can preserve this chip for replay inspection.

Guardrail:
- history chips must never silently reselect the family/cut for a new action.

## Prompt chrome / pane chrome ideas
- small **judge badge** in pane chrome: `cedar@cut-abc`, `policy@latest`, `unknown`, `receipt-only`
- **consistency pip** next to the judge badge: `exact`, `fresh+`, `latest`, `unknown`
- **repair spark** when the current cut is invalid/stale and the shell has a non-authoritative next step
- **fallback count badge** that opens a non-authoritative alternates drawer

## Result-card ideas
A result card should be able to say:
- `used exact current cut`
- `used latest consistent cut`
- `repair suggested, not adopted`
- `repair adopted: same family newer cut`
- `fallback offered, not selected`
- `history only; current cut unknown`

## Notebook / replay ideas
- notebook cells should preserve the last known family/cut as history only
- replay should first compare `recorded family/cut` versus `current family/cut`
- any switch from one family/cut to another should route through the cut picker or repair prompt
- `receipt only` should be a first-class outcome when honest replay is not possible

## Terminal protocol hints
The terminal protocol likely wants events for:
- **policy selection** (authoritative family/cut + consistency posture)
- **fallback candidates** (non-authoritative alternates)
- **repair proposal** (non-authoritative recovery suggestion)
- **selection receipt** (durable history)

That lets semantic terminals render rich policy-aware UX without scraping strings.

## What to avoid
- silently switching to “latest good” policy when the chosen cut errors
- treating diagnostics or receipts as if they were current selection
- letting workspace-local hints silently override explicit local/owner-selected policy
- hiding consistency posture inside generic “allowed” or “denied” badges
- pretending a fallback rail is harmless if it can change the judge without an explicit act
