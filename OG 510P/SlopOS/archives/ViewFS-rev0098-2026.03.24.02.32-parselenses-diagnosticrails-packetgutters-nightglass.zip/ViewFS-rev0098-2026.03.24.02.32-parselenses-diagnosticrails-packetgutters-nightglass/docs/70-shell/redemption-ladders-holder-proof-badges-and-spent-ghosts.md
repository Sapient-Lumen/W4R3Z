# Redemption ladders, holder-proof badges, and spent ghosts

One of the easiest ways for a shell+terminal to lie is to blur together:
- `this compact thing might redeem into power`,
- `this only works for the current proving holder`,
- `this is a live passable handle now`,
- and `this old row merely records that something was already spent`.

A great ViewFS shell should make those classes feel obvious at a glance.

## Redemption ladders

When a command block, chooser result, or import card points at a claim-style object, the shell should be able to render a compact ladder like:

`claim` → `redeem here` → `holder proof maybe needed` → `live handle now` → `publish/bind or hand off`

Nice moves:
- one-click `redeem here once` when policy allows it,
- `redeem into this pane only` versus `redeem and hand to child`,
- `preview what will be consumed` before a one-shot action,
- `redeem into provider-owned session` when the result is still holder-bound rather than freely passable.

## Holder-proof badges

The shell should visibly mark when a useful thing is live but still bound to the current proving holder.

Examples:
- `holder-bound`
- `proof needed`
- `not passable yet`
- `session-bound`
- `sender-constrained`
- `passable now`
- `spent`

These badges are not just trust decoration.
They are replay and transfer truth.

## Spent ghosts

Whenever a one-shot claim or consumable grant has already been used, the shell should keep a visible but dimmed **spent ghost** instead of either hiding it completely or leaving it looking reusable.

Useful states:
- `spent`
- `expired`
- `withdrawn`
- `refused`
- `redeemed into live handle`
- `redeemed and published here`

This is especially important for receipts, notebooks, transcript history, and route cards.

## Burn-after-use chips

Before a consumable action fires, the shell should be able to show a tiny chip like:
- `one-shot`
- `burns on redeem`
- `redeem copies nothing`
- `redeem creates holder-bound session`
- `replay blocked`

That is the honest replacement for faux-generic `Open` buttons.

## Great transcript moves

A future custom shell+terminal could do several delightful things here:
- keep **claim-to-handle conversion receipts** inline with the command block that performed redemption;
- let users filter history by `redeemed`, `spent`, `holder-bound`, `passable`, or `expired`;
- render **proof drawers** that explain why an apparently live thing still cannot simply be copied to another process;
- attach **spent ghosts** to old transcript rows so replay-sensitive actions do not look tempting by accident;
- allow `redeem here, then publish into this pane` and `redeem here, then courier to child pid` as distinct actions.

## Why this matters

A capability-native shell becomes super awesome not just by being powerful, but by being precise about what sort of power is actually present.
A redeemable claim, a holder-bound grant, a passable live handle, and a spent receipt are different powers.
A terminal that can show those powers clearly will feel dramatically better than one that hides them behind generic filenames, URLs, or token-looking strings.
