# Link lenses, breadcrumb provenance, and explicit relink flows

Goal: make the ViewFS shell wonderfully clickable and navigable **without** pretending that every link-like thing is the same class of object or authority.

## Principle
The shell should let users move fast while always answering:
- what kind of link is this?
- is it live authority, a local alias, a durable reopen ref, a route, or only a receipt?
- what happens if I click it?
- what would require rebind, portal consent, or retargeting?

Fast is good. Ambiguous is not.

## High-upside ideas

### 1. Link lenses
Every rendered link can expose a tiny lens/peek with:
- class badge (`live`, `alias`, `reopen`, `route`, `receipt`),
- provider/source,
- current target summary,
- freshness/staleness,
- and next action (`inspect`, `rebind`, `relink`, `reveal`, `launch`, `copy receipt`).

This keeps clickability rich without laundering everything into “open”.

### 2. Breadcrumb provenance
Path-like breadcrumbs should say what each step actually is:
- current view binding,
- directory entry,
- alias object,
- synthetic compat segment,
- or remembered route.

That makes navigation feel grounded instead of magical.

### 3. Explicit relink / retarget flows
If a link-like object needs a new target, make it a visible action:
- show old target,
- show proposed new target,
- explain whether this changes a local alias, a route sheet, or a durable reopen ref,
- then emit a **RetargetReceipt** block.

This is better than silent auto-healing.

### 4. Typed hyperlinks over cwd heuristics
Terminals already support explicit hyperlinks nicely.
ViewFS should lean into that with typed object/route links, instead of relying mainly on “guess the file from current directory + line text” heuristics.

Heuristic opening can still exist as a fallback, but it should wear an honest badge like `heuristic`.

### 5. Dead-link triage cards
When a link fails, the shell should not just say “No such file”.
It should say whether the failure was:
- stale reopen ref,
- moved alias target,
- route requires portal,
- launch shortcut target missing,
- or heuristic resolution mismatch.

Then offer the next best action.

### 6. Compare target history
For aliases/routes/reopen refs, a user should be able to inspect:
- original target,
- current candidate target,
- why the system thinks they match or differ,
- and whether the system is merely suggesting a relink rather than asserting identity.

Great for trust and debugging.

### 7. Safe sharing modes
A shell transcript can export:
- clickable receipts,
- route sheets,
- and inert link cards

while stripping:
- live handles,
- live workspace binds,
- and hidden ambient assumptions.

That makes collaboration much safer.

### 8. Palette rows with link-class truth
Palette/omnibox results become much more useful when they can say:
- `live handle`
- `alias in current view`
- `reopen ref`
- `route only`
- `receipt only`
- `heuristic guess`

The row should say what clicking it will actually do.

## Tiny protocol ideas worth stealing
The shell-to-terminal protocol may eventually want metadata such as:
- rendered-link class,
- target object/ref/route type,
- current status (`live`, `stale`, `heuristic`, `moved`, `receipt-only`),
- last successful action,
- retarget available?,
- and whether modifier-click is required.

Not final names—just a reminder that link UX gets much better once the shell emits explicit class metadata.

## Product steals worth keeping in mind
- explicit terminal hyperlinks rather than cluttered raw URLs,
- command-click / modifier-click safety for opening,
- searchable command/object palettes,
- and semantic-history-style filename navigation only when clearly marked as heuristic.

## Anti-goals
- every clickable thing opens with the same action
- silent auto-retargeting with no receipt
- using shell history as a hidden bearer-capability transport
- disguising route/launch shortcuts as immutable object identity
- generic “file not found” errors when the system knows the failure class

