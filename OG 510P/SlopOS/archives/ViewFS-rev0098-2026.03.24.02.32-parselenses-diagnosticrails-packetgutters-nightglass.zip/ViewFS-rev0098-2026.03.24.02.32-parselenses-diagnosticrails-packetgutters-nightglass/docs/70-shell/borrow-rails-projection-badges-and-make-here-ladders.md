# Borrow rails, projection badges, and make-here ladders

One of the nicest receiver-side shell moves available to ViewFS is to stop treating `open`, `attach`, `import`, `localize`, and `sync` as one flattering verb.
This note collects shell/terminal ideas for the seam between **foreign-backed borrow**, **wrapper/relay attach**, **projected import**, **local realization**, and **history only**.

## 1. Borrow rails instead of one fake open/import action

For any object card, attachment row, or suggested import, the shell should be able to render a small rail like:
- `foreign-backed`
- `attach via wrapper`
- `attach via relay`
- `project here`
- `project here (session)`
- `make local copy`
- `make local replica`
- `local object`
- `receipt only`
- `history only`

The winning rail should be visible before the user commits.
This turns a vague `open` or `import` click into an honest locality choice.

## 2. Projection badges

The shell should carry tiny badges for the real receiver-side posture, such as:
- `provider-owned`
- `security-scoped`
- `portal view`
- `compat attach`
- `relay attach`
- `dataless`
- `materialized`
- `local object`
- `none`

These badges should explain *why* the current posture fits and *why* stronger local postures do not.

## 3. Make-here ladders should preserve the locality transition

When a user decides something needs to become truly local, the shell should not flatten that into a generic `save`.
It should be able to say:
- `continue borrowed`
- `project into this pane`
- `make local copy`
- `make local replica`
- `store as local object`

That is a much better user experience and a much more honest capability story.

## 4. Provider-owned halos and dataless/materialized lamps

If an item is still backed by another provider or only partially materialized locally, the shell should say so.
Useful chrome includes:
- a **provider-owned halo** around foreign-backed rows,
- a **dataless lamp** for items whose bytes are not fully local,
- a **materialized lamp** for items whose bytes are present now but may still sync back to a provider,
- a **projection badge** when the visible path/name is synthetic rather than local-store truth.

## 5. Why-not-adopt drawers

A blocked attach/import/localize action should be able to explain:
- `provider unavailable`
- `wrapper required here`
- `relay required across this lane`
- `projection available, localization not automatic`
- `localize explicitly`
- `history only`

This is exactly the kind of shell honesty that ordinary desktop surfaces almost never provide.

## 6. Super-awesome terminal moves worth stealing

- **make-here sidecars** attached to command blocks so the user can localize outputs explicitly.
- **foreign fog gutters** when a pane is still browsing provider-backed or projected material.
- **projection breadcrumbs** that keep synthetic/local path truth visible in terminal chrome.
- **attach receipts** that say `wrapped`, `projected`, `localized`, or `history only` after the fact.
- **locality compare drawers** that let the user inspect `borrowed`, `projected`, `materialized`, and `local object` as separate receiver-side states.

References: REF-ANDROID-SAF, REF-ANDROID-DOCPROVIDER, REF-APPLE-DOCPICKER-ACCESS, REF-APPLE-SECSTART, REF-APPLE-FILEPROVIDER-SYNC, REF-XDG-DOCUMENTS, REF-XDG-DOCS-FUSE, REF-FUCHSIA-COMPONENT-NSENTRY, REF-FUCHSIA-FSARCH.
