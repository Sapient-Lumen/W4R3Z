# Activation slots, issuer badges, and handoff sheets

A future ViewFS shell should make startup authority and cross-process transfer feel **amazing** without lying.
The shell+terminal does not need magical path folklore to be delightful.
It needs better objects:
- activation-sheet cards,
- handoff sheets,
- copy-lineage drawers,
- truth-grade command blocks,
- and semantic transcript boundaries.

This document collects the shell/product moves that become possible once ViewFS keeps activation carriers, live handle copies, issuer badges, local binds, object refs, and receipts separate.

## 1. Activation-sheet card

Before a launch commits, show a compact card:
- `slot`
- `kind` (`live handle`, `staged bytes`, `object ref`, `receipt only`)
- `rights`
- `issuer/courier witness`
- `object ref`
- `reopen lane`
- `child-local bind preview`

Why this is great:
- startup stops looking like ambient rediscovery magic;
- users can review the boundary before the child runs;
- shell history gains a durable explanation object that is richer than plain text.

Guardrail:
- the card must never let `slot` read like `stable path` or `same object forever`.

## 2. Child-slot map after launch

After launch, the shell should preserve a child-slot map showing:
- what actually crossed;
- what was dropped or shuttered;
- what was attenuated;
- and what receipt/history row remains.

Why this is great:
- one of the oldest process-launch mistakes is invisible inheritance;
- the map makes authority leaks obvious and teachable.

## 3. Copy-lineage drawer

Every strong handle card should be able to expand into a drawer with:
- `came from slot X` / `came from courier Y`
- `duplicate` vs `attenuated copy`
- `issuer badge` or `peer witness`
- `same object ref known/unknown`
- `current rights`
- `reopen lane`

Why this is great:
- users understand both the current live copy and how it arrived;
- debugger-like power becomes inspectable without debugger-like chrome everywhere.

## 4. Handoff sheets instead of vague open events

When something crosses panes, tools, or apps, create a handoff sheet.
Suggested rows:
- `offered by`
- `delivery lane`
- `offered class`
- `accepted class`
- `adopted as`
- `still live now`
- `receipt`

Why this is great:
- `open`, `send`, `adopt`, `route`, and `receipt only` stop collapsing into one vague action;
- transcript sharing becomes much safer because the receipt survives even when live authority does not.

## 5. Issuer badges and peer-witness chips

Compact chips can tell the truth at a glance:
- `manager slot`
- `portal result`
- `peer creds`
- `issuer badge`
- `shell-only label`
- `receipt only`

Why this is great:
- the transcript becomes skimmable without hiding nuance;
- trust and provenance stay visible without pretending to be one global verdict.

Guardrail:
- witness chips describe the delivery lane, not a universal trust bit.

## 6. Truth-grade command blocks

A custom shell should grade blocks explicitly:
- `text only`
- `semantically marked`
- `shell-reported command`
- `reviewed command packet`
- `receipt/result object`

Why this is great:
- strong actions like reroute, replay, adopt, or reissue can key off stronger truth;
- weaker blocks still get safe actions like copy, inspect, or promote to review.

## 7. Paste capsules and import capsules

The shell should distinguish:
- typed keystrokes,
- pasted text,
- imported object tokens,
- and structured route/command packets.

Why this is great:
- paste-driven accidents become easier to prevent;
- inspect-before-run becomes humane instead of patronizing.

## 8. Semantic boundaries the terminal should expose

The terminal protocol should make these explicit:
- prompt start/end
- input start/end
- output start/end
- route event start/end
- handoff sheet emitted
- receipt emitted
- activation-sheet reviewed
- child-slot map finalized

Why this is great:
- navigation, sticky review panes, searchable marks, and click-safe selection all get dramatically better when boundaries are semantic instead of scraped.

## 9. One tiny Authority HUD that would punch above its weight

Per pane, keep one tiny HUD with:
- `view`
- `slot count`
- `borrowed live authority count`
- `receipt-only count`
- `ambient debt`
- `trust grade`

That HUD makes the shell feel special immediately.
It also creates an honesty habit: every pane is explicit about what is live, what is remembered, and what is only history.

## 10. Anti-goals

Do not build:
- fake Unix-looking prompts that hide synthetic view roots;
- click-to-open behavior that silently upgrades old history into live authority;
- badges that imply immutable identity when they only describe copy lineage;
- replay that quietly reuses old slot names or old receipts as if they were current grants.

## 11. Near-term shell prototypes

Prototype these first:
1. activation-sheet card
2. child-slot map receipt
3. handoff sheet
4. copy-lineage drawer
5. truth-grade block chrome
6. pasted-vs-imported input chip

That sequence gives the future shell a real personality while staying faithful to the architecture.
