# Bracket rails, caller badges, and who-asked drawers

One of the best shell moves available to ViewFS is to stop pretending every helper, plugin, and automation block acts with one mysterious blob of authority.
This note collects shell/terminal ideas for the seam between **privilege bracket**, **borrowed authority**, **call-chain context**, **deny-only veto hints**, and **history only**.

## 1. Bracket rails

A transcript block or pane should be able to show when execution is currently inside one explicit borrowed-authority bracket.
That rail should answer:
- is the bracket active now?
- what kind of helper or block opened it?
- what authority class is borrowed inside it?
- when did it end?

That is much better than one vague `helper mode` idea.

## 2. Caller badges and call-frame chips

The shell should make `who asked?` visible without turning that into authority.
Useful chips include:
- `pane origin`
- `plugin origin`
- `route sheet origin`
- `notebook cell origin`
- `automation replay origin`
- `manual user step`

These should be badges or drawers, not hidden task-local folklore.

## 3. Borrowed-authority drawers

If a helper is acting on explicit borrowed handles, the shell should say so.
A drawer should be able to separate:
- caller provenance,
- helper identity,
- borrowed authority,
- helper-local standing tools,
- and any deny-only provenance veto.

That is the honesty bar for a shell that wants to be super awesome.

## 4. Deputy fog warnings

When a helper is about to cross from explicit bracketed use into ambient singleton / ambient async-local / global helper state, the shell should say so.
Not with panic.
With clarity:
- `leaving bracket`
- `ambient fallback`
- `context bleed risk`
- `helper global consulted`

That kind of warning will save people from magical-shell folklore.

## 5. Deny-only shutters

If one caller frame or helper provenance entry vetoes a route, the shell should render that as a deny-only shutter rather than one misleading `permission denied` blob.
Examples:
- `blocked because untrusted plugin in chain`
- `blocked because preview-only pane origin`
- `blocked because replay lane cannot invoke destructive helper`

## 6. Great terminal tricks worth stealing

- **who-asked drawers** on semantic command blocks.
- **caller badges** inline next to result blocks.
- **bracket rails** on the left gutter for helper-active regions.
- **borrowed-authority drawers** that expand without dumping raw capability guts into normal output.
- **deputy fog warnings** attached to the exact command/result block where ambient fallback happened.
- **deny-only shutters** that tell the user *why this route was vetoed* in provenance language, not path-error language.

## 7. Nice user-facing language

Instead of one fake `plugin did this` or `shell did this` label, the shell can say:
- `inside borrowed-authority bracket`
- `caller context only`
- `borrowed handles active`
- `deny-only provenance hint present`
- `vetoed by caller/helper chain`
- `receipt only`

That grammar is much easier to trust.

References: REF-CONFUSED-DEPUTY-HARDY, REF-JEP506-SCOPEDVALUES, REF-JAVA-SCOPEDVALUE-API, REF-PY-CONTEXTVARS, REF-NODE-ASYNCLOCALSTORAGE, REF-ASPNET-HTTPCONTEXTACCESSOR.
