# Waterline cards, gap badges, and resync ladders

A future ViewFS shell should make follow/query/live panes feel alive **without** pretending one cursor or bookmark is the same thing as current truth.
That means keeping at least five visible classes apart:
- continuation cursors,
- sync watermarks,
- live follow state,
- rebuilt snapshots,
- gap receipts/history.

## What the shell should make obvious

### 1. A cursor is not the visible set
A provider-issued cursor should render as a small technical token with posture like:
- `continue token`
- `opaque`
- `provider issued`
- `may expire`

It should never masquerade as a durable docref, object id, or collection object.

### 2. A watermark is an honesty artifact
The shell should show phrases like:
- `caught up through 12746`
- `snapshot as of c:123:234`
- `rebuilt through event id 9182`

That is excellent truth chrome, but it still is not a current subscription.

### 3. Live follow is its own state
A pane should be able to say:
- `following now`
- `waiting for changes`
- `paused`
- `ended`
- `provider reset`
- `history only`

That keeps one idle longpoll from being confused with a durable current set.

### 4. Gap reasons deserve strong badges
Instead of one generic stale badge, the shell should prefer:
- `expired cursor`
- `resource version too old`
- `provider reset`
- `must rescan`
- `root changed`
- `remote-risk`
- `unsupported`

Those reasons are much more actionable.

### 5. Rebuild should be visible and celebratory
When the shell repairs continuity, it should say so proudly:
- `relisted from provider`
- `rebuilt from root`
- `snapshot refreshed`
- `watermark advanced`

That turns repair into a first-class product move rather than background mystery work.

## Super-awesome product moves

### Waterline cards
A focused watch/query pane should have a compact card with:
- current visible mode (`snapshot`, `follow`, `rebuilt`, `receipt only`)
- last known watermark
- live follow state
- cursor posture (`current`, `expired`, `receipt only`)
- provider badge
- quick actions (`continue`, `pause`, `relist`, `freeze`, `open receipt`)

### Gap badge stack
If continuity broke, the shell should keep a small stacked explanation instead of one bit:
- `expired cursor`
- `relist needed`
- `last good watermark c:123:234`
- `raw provider token hidden`

### Resync ladders
Repair UI should be explicit:
- `continue from current cursor`
- `wait for changes`
- `relist and rebuild`
- `freeze rows before rebuild`
- `copy watermark`
- `open gap receipt`

### Snapshot/follow split view
One especially nice move is a dual-pane or split-card mode that shows:
- the last frozen stable set,
- the live follow delta since that set,
- and the current repair posture.

That makes smart folders and datacube-like panes far less disorienting.

### Copy ladders
Copying should separate:
- visible row text,
- query manifest,
- current watermark,
- receipt,
- never raw provider cursor by default.

If the shell ever exposes raw provider tokens, that should be a stronger inspect/debug path, not an everyday copy act.

## Guardrails

- cursors must not masquerade as durable object references;
- watermarks must not masquerade as live subscriptions;
- live follow state must not masquerade as the currently rendered snapshot;
- rebuilds must not happen silently with no UI explanation;
- gap receipts must not silently reactivate provider state on replay/share/restore.
