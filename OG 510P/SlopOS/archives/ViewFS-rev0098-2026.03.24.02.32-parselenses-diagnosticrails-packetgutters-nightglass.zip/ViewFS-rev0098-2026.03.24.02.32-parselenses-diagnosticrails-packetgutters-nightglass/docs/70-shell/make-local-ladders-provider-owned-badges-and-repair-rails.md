# Make-local ladders, provider-owned badges, and repair rails

One of the easiest ways for a shell+terminal to lie is to blur together:
- `I can see that this exists somewhere`,
- `the provider could probably supply it`,
- `one more repair/rebind step is still owed`,
- `it is fully local here now`,
- and `a process currently holds authority now`.

A great ViewFS shell should make those classes feel obvious at a glance.

## Make-local ladders

When a command block, chooser result, or object card points at something that is not yet fully local, the shell should be able to render a compact ladder like:

`advertised` → `provider-ready` → `reacquire needed` → `realizing` → `local now` → `bound here`

That ladder is the honest replacement for fake path-familiarity.

Nice moves:
- one-click `make local now` when policy allows it,
- `ask provider first` when the row is only an advert,
- `repair before localizing` when a restore/rebind/reauth step is still owed,
- `bind here after realization` instead of silently publishing the result into every pane.

## Provider-owned badges

The shell should visibly mark when current usefulness is still backed elsewhere.

Examples:
- `provider-owned`
- `foreign-backed`
- `borrowed utility`
- `substitutable`
- `promised remote`
- `local realized`
- `history only`

These badges should not be trust verdicts.
They are locality/custody truth.

## Repair rails

Whenever a remembered or resumed thing is not fully ready, the shell should expose a **repair rail** instead of a vague failure toast.

Useful rail states:
- `rebind needed`
- `reauth needed`
- `fetch needed`
- `substitute available`
- `provider unavailable`
- `reacquire blocked offline`
- `repair satisfied`

Repair rails are especially important for imported objects, resumed workspaces, and provider-backed long-running sessions.

## Locality lamps

Prompt and pane chrome should be able to show small locality lamps such as:
- `here now`
- `remote-ready`
- `needs fetch`
- `repair owed`
- `withdrawn`
- `receipt only`

This is the missing honesty layer between classic path-based shells and a capability-native object store.

## Great transcript moves

A future custom shell+terminal could do several delightful things here:
- keep **block-local realization receipts** so a user can inspect exactly when a command turned something from provider-ready into local;
- let users filter history by `made local`, `remote only`, `repair required`, or `bound here`;
- render **provider-owned drawers** that show who still owns the useful backing and what step would localize it;
- attach **offline fog** to rows that are only promisor/substituter backed;
- allow `bind realized result into this pane` as a distinct action after `make local` completes.

## Why this matters

A capability-native shell becomes super awesome not just by being powerful, but by being truthful.
`Could supply later`, `still provider-owned`, `locally realized`, and `live handle held now` are different powers.
A terminal that can show those powers clearly will feel dramatically better than one that hides them behind generic filenames and stale green dots.
