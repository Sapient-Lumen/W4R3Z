# Truthful completions and routing notes

Purpose: make the custom ViewFS shell feel **smarter than a normal shell** without lying about authority.

The easiest way to ruin a capability-native shell is to build beautiful UI that quietly assumes ambient path access. We want the opposite: a shell whose most delightful features make the authority story easier to see.

## What the good precedents suggest
- REF-FISH: autosuggestions, syntax highlighting, and filtered completion lists make the shell feel immediate.
- REF-NUSHELL: structured pipelines reduce fragile string parsing and make previews/completion richer.
- REF-WEZTERM-SHELL-INT and REF-WEZTERM-ZONES: if the shell emits explicit metadata, the terminal can understand prompt/input/output boundaries instead of guessing.
- REF-WARP-CMDPALETTE, REF-WARP-WORKFLOWS, and REF-WARP-NOTEBOOKS: searchable commands, reusable workflows, and runnable notebooks dramatically improve discoverability.
- REF-PLAN9-PLUMB and REF-XDG-OPENURI: typed routing beats “open this string somehow.”

## Completion should tell the truth
A completion candidate should ideally know:
- object kind
- source seam (`view`, `portal`, `transfer`, `workflow`, `history`)
- rights summary
- whether selecting it will need a portal or revalidation step
- whether it is stale because the original grant is gone

That is much better than presenting every suggestion like it were just another path segment.

## Autosuggestions should be authority-aware
History is useful, but history can lie.
A suggested command may mention a workspace binding or receipt that no longer exists in the current pane.

So a ViewFS shell should prefer these states:
- **ready** — current pane already has what the command needs
- **rebind-needed** — the command is known, but a workspace/doc grant must be refreshed
- **portal-needed** — execution will prompt for chooser/open/save/transfer mediation
- **ambient-debt** — the old command depended on a host-side escape hatch

This keeps fish-like helpfulness without pretending old authority magically persists.

## Routing should stay typed
Clicks, keybindings, and palette actions should preserve the seam:
- `inspect object`
- `open object in tool`
- `open uri externally`
- `export`
- `transfer`
- `rebind workspace`

That is much safer than turning everything into a URI or everything into a path.

## Semantic zones should include receipts
Prompt/input/output zones are already valuable.
ViewFS should go one step further and treat attached receipts as explicit block-local objects.
That would make it easy to:
- drag a receipt to another block as mediated input
- ask “why did this command have access?”
- save a command block as a workflow with its authority notes intact

## Object palette should merge discovery surfaces
One palette should search across:
- commands
- workflows
- notebooks
- recent receipts
- bound workspace slots
- routeable objects/manifests

The trick is that results must expose **what kind of thing** they are. A palette that collapses everything into fuzzy text results would be flashy but misleading.

## Completions and previews can be tiny but still brilliant
The shell does not need a giant permission dialog before every command.
It only needs a compact preview that can answer:
- reads from where?
- writes to where?
- any portal actions?
- any stale bindings?
- any ambient debt?

That one move could make ViewFS feel dramatically more powerful than a legacy shell.

## One especially good move
When the user accepts a completion that depends on a missing grant, do **not** fail with a confusing path error.
Offer the shortest truthful continuation:
- pick document
- rebind workspace
- reopen recent receipt
- run read-only instead
- cancel

That turns permission friction into a first-class UX moment instead of a mystery.

## What not to decide yet
- final wire format for completion metadata
- whether the terminal, shell, or helper daemon renders the palette
- whether workflows/notebooks are plain Markdown, richer manifests, or both
- exact event names for route actions and receipt attachments

## Narrow prototype recommendation
Start with:
1. completions carrying kind + rights-summary + stale/needs-portal flags,
2. one authority preview line,
3. semantic prompt/input/output/receipt zones,
4. one typed route sheet,
5. one object palette that can find commands, receipts, and workspaces.

If that feels magical, the bigger notebook/workflow system will have a solid foundation.


## Recent items and object links must stay typed
A palette result that says “project-a” is not enough.
The shell should know whether that result is:
- a local binding in the current view,
- a durable reopen handle,
- a workspace bind suggestion,
- a receipt from a past transfer,
- or just a routeable URI/object link.

That distinction is what prevents a “helpful” shell from silently turning history into authority.

## Accepting a suggestion is its own act
A highlighted completion row is still only advice.
The accepted insertion is the first stronger state.

That means the shell should support at least:
- **accept word**
- **accept fragment**
- **accept whole candidate**
- **inspect details without inserting**

fish gets a lot right here: fast acceptance is delightful exactly because it still does not execute anything.

## Inserted text is not a compiled action
Once text is in the buffer, the shell can do something stronger: compile one **command packet** against the current pane.
That packet can know:
- which object references were recognized,
- which receipt links were resolved,
- which current bindings were used,
- whether the result is only heuristic text parsing or stronger shell-native structure,
- and whether a portal/rebind/approval step still stands between the packet and execution.

That is much better than pretending the buffer itself is already one ready plan.

## Trusted packets should be visibly stronger than guessed text
The terminal will often know different grades of truth about a command line:
- scraped/heuristic text,
- shell-reported exact command text,
- nonce/trust-verified command text,
- or a packet composed directly from ViewFS objects.

Those are not the same.
They should not get the same replay affordances.

## A great product move
After a completion is accepted, show a tiny **packet gutter** under the prompt line:
- `compiled`
- `trusted` or `heuristic`
- `portal needed` / `rebind needed` / `approval needed` / `ready`

That would make the shell feel dramatically smarter without lying about what has happened yet.
