# Route plans, approval checkpoints, and result cards

Purpose: make the ViewFS shell feel **super awesome** by showing what will happen before it happens, without lying about approval or authority.

## North star
A great ViewFS shell should let a user move through five readable states:
- **intent** — what they want,
- **plan** — how the shell would do it,
- **approval** — what exact risky delta is being consented to,
- **execution** — what is happening now,
- **result** — what actually happened.

That sounds simple, but most shells blur at least three of those together.

## Best ideas worth stealing
- **REF-PLAN9-PLUMB**: route typed intents instead of guessed strings.
- **REF-XDG-REQUEST**: long-running mediated actions deserve visible request objects.
- **REF-DENO-PERMISSIONS**: denied-by-default with explicit runtime prompts can still feel usable when the boundary is clear.
- **REF-VSCODE-WORKSPACE-TRUST**: restricted mode can still be productive, so blocked execution does not need to feel broken.
- **REF-NUSHELL**: structured values make it easier to keep plan/result classes honest.
- **REF-WEZTERM-SHELL-INT**, **REF-ITERM-SHELLINT**, and **REF-GHOSTTY-OSC133-OVERLAY**: terminal metadata can make plans, prompts, and results visible rather than folkloric.

## Route-plan cards should exist before execution
One keystroke from a route sheet, receipt card, or command line should open a **route-plan card** showing:
- subject class,
- requested verb,
- chosen route,
- provider-supported operations,
- target pane/view/launch kit,
- approval checkpoint required or not,
- portal/trust/bind steps that may occur,
- exact authority delta,
- and what would be saved only as receipt/history.

This should feel as normal as opening a completion menu.

## Prepare should be a first-class shell action
The shell should distinguish:
- `prepare this`
- `commit this`
- `save this plan as a recipe`
- `copy receipt only`
- `replay with fresh planning`

That means users can inspect or share the plan without smuggling the authority.

## Approval checkpoints should be exact-diff surfaces
When approval is needed, the shell should show an **approval checkpoint** tied to the exact plan/action digest.
It should answer:
- what new authority would appear,
- what current bindings would change,
- whether the basis is mutable and could go stale,
- and whether approval is for this one exact action or merely for inspection.

The shell should never imply “approve whatever the current head is later”.

## Restricted is a proud state
A great shell should be confident enough to say:
- you can inspect this now,
- you can diff the would-be execution now,
- you can save a receipt-only recipe now,
- but you cannot execute until the missing portal/trust/approval step happens.

That is much better than pretending the command failed mysteriously.

## Result cards should distinguish outcome classes clearly
After execution, the block should get a **result card** that can honestly say:
- completed,
- partially applied,
- denied,
- cancelled,
- timed out,
- stale basis,
- rerouted,
- or receipt only.

The card should keep exact plan and approval references available for inspection without turning them into reusable bearer tokens.

## Great custom-terminal moves
- **Plan lane beside the prompt**: a compact chip showing whether the current command line is only text, a prepared plan, or a commit-ready plan.
- **Approval diff drawer**: a key opens the exact authority delta that would result from commit.
- **Result-stack cards**: each block can show plan -> approval -> result as a tiny vertical chain.
- **Terminal inspector overlay**: show prompt zones, plan zones, approval zones, and result zones for debugging and trust.
- **Prepare-on-hover, commit-on-confirm**: clicking a typed object link or palette row opens a plan first instead of executing immediately.
- **Replay with strip knobs**: replay identical intent, replay inspect-only, replay with fresh portal, replay in a fresh pane, replay with narrower rights.

## Structured shell values worth exploring
A structured shell could let commands emit values such as:
- `intent`
- `route_plan`
- `approval_needed`
- `approval_checkpoint`
- `execution_record`
- `result_receipt`

That would make pipelines and notebooks much more truthful than flattening everything back into strings.

## A tiny honest prototype would already be great
The first prototype does not need every action family.
It would already be great to ship:
- one route-plan card,
- one approval checkpoint card,
- one result card,
- one prepare-vs-commit split,
- and one replay-with-fresh-plan action.

If that feels good, the shell will have found a real advantage instead of only a pretty terminal skin.
