# Basis diffs, reconsent ladders, and renewal guards

Purpose: make the ViewFS shell feel **super awesome** by letting users reuse prior work fast **without** pretending a past success is current authority.

## North star
A great ViewFS shell should let a user read these states at a glance:
- **exact-basis** — the currently checked basis still matches the recorded one
- **narrowed** — reuse is possible, but only with reduced operations/rights/scope
- **reconsent** — a fresh approval/import/renewal step is required
- **receipt-only** — history is available, but no live authority is implied
- **source-missing** — the referenced source or descriptor is gone
- **unknown-drift** — enough changed that the shell cannot honestly promise equivalence

That is a much better shell story than silently treating “it worked last week” as standing permission today.

## Best ideas worth stealing
- **REF-DIRENV-REQUIREALLOWED**: when watched inputs change, re-authorization becomes explicit instead of sticky.
- **REF-APPLE-SECRESOLVE** plus **REF-APPLE-SECSTART**: durable reopen descriptors can age, and resolved live access still requires explicit enter/leave discipline.
- **REF-XDG-REQUEST** plus **REF-XDG-DOCUMENTS**: past interaction objects, persistent entries, and current live access are all different classes.
- **REF-DENO-PERMISSIONS**: allow/deny posture, prompts, and permission audit logs make renewal posture legible instead of magical.
- **REF-MS-FUTUREACCESSLIST**: durable reopen stores should be bounded and reviewable, not infinite hidden memory.
- **REF-WEZTERM-SHELL-INT** and **REF-ITERM-SHELLINT**: semantic shell metadata gives the terminal enough structure to render drift, reconsent, and renewal state beautifully.

## Basis diff drawers could be incredible
Imagine activating a receipt, workflow, notebook cell, or durable reopen ref and getting a **basis diff drawer**:
- what prior basis was recorded,
- what still matches,
- what narrowed,
- what disappeared,
- which watched inputs changed,
- whether the trust source changed,
- and what fresh actions are available now.

That is the right place to be smart.

## Reconsent ladders should stay calm and explicit
When exact reuse is no longer honest, the shell should offer a **reconsent ladder** rather than one generic failure dialog:
- `reuse exact` (only when honest)
- `reuse narrowed`
- `fresh chooser/import`
- `fresh lend for this run`
- `fresh temp view`
- `receipt only`

This makes the shell fast without making it sneaky.

## Renewal guards belong in pane chrome
A pane header, gutter, or prompt-adjacent HUD should be able to show:
- whether the current pane is running on exact basis or a narrowed renewal,
- whether any blocks are waiting on reconsent,
- whether any replayable artifacts have source drift,
- and whether renewal would promote to a more durable class.

The shell should not make users discover this through surprise denials later.

## Watched-input chips are a feature, not noise
Near a workflow, notebook cell, or durable reopen item, the shell should be able to show little chips like:
- `provider ops changed`
- `workspace trust changed`
- `watched file changed`
- `bookmark stale`
- `issuer policy changed`
- `source missing`

Those chips make reapproval and receipt-only fallbacks feel justified instead of arbitrary.

## Renewal result cards should be typed
A renewal or replay result card should clearly say one of:
- `reused exact`
- `reused narrowed`
- `fresh reconsent`
- `fresh import`
- `fresh borrow`
- `receipt only`
- `denied stale basis`
- `source missing`

That is much better than a generic “reopened” label.

## Great terminal-native moves
- **Basis gutter**: one slim lane listing replayable items and their current basis state for the pane.
- **Reconsent drawer hotkey**: one keystroke to inspect what changed before rerun.
- **Renewal strip knobs**: replay with no exports, read-only, no background, fresh temp view, or receipt-only.
- **Result-stack chains**: old receipt -> basis diff -> reconsent -> renewed artifact -> new receipt.
- **Prune-later reminders**: durable reopen items can show bounded-store pressure without pretending that pruning is the same as revocation.

## Structured shell values worth exploring
A structured shell could let commands emit values such as:
- `reuse_candidate`
- `basis_record`
- `drift_check`
- `reconsent_checkpoint`
- `renewed_artifact`
- `reuse_receipt`

That would make inspectors, route sheets, notebooks, and result trays much more truthful.

## A tiny honest prototype would already be great
The first prototype does not need a giant renewal framework.
It would already be great to ship:
- one **basis diff drawer**,
- one **reconsent ladder**,
- one prompt or pane badge for `exact` vs `reconsent`,
- one `receipt only` fallback,
- and one renewal result card that says *why*.

If that feels good, the shell will have found another real superpower rather than a fancier rerun button.
