# Launch rehearsals, kit cards, and view panes

Purpose: make a capability-native shell feel **super awesome** by exposing grouped authority and per-process namespace assembly **before execution**, not after an unpleasant surprise.

## North star
The shell should make three truths obvious at a glance:
- **what this pane can see now**,
- **what the next command would launch with**, and
- **which part is live authority versus memory/receipt/history**.

That one move could make ViewFS feel dramatically better than a traditional terminal.

## Best ideas worth stealing
- **REF-WEZTERM-SHELL-INT**, **REF-ITERM-SHELLINT**, and **REF-GHOSTTY-SHELLINT**: block boundaries, marks, cwd/view metadata, and command-finished events make terminal structure navigable.
- **REF-WARP-BLOCKS**: command blocks and reusable history objects are much better than raw scrollback.
- **REF-NUSHELL**: structured pipeline values can carry more truth than text-only glue.
- **REF-VSCODE-WORKSPACE-TRUST**: a restricted/browse-first state can still feel productive.
- **REF-FUCHSIA-SANDBOXING** and **REF-FUCHSIA-DICTCAP**: child namespaces and grouped capabilities should be explicit objects, not folklore.

## Launch rehearsal should be first-class
Before a command executes, one keystroke should open a **launch rehearsal** card showing:
- current pane view,
- candidate launch kit,
- which bundles/fragments/receipts it draws from,
- which members are live versus stale/ref-only,
- which portal actions may occur,
- whether any ambient debt is involved,
- and what will persist afterward.

That is better than both a hidden exec environment and a giant scary permission prompt.

## Kit cards should be reusable objects
A grouped authority object should render as a compact card with:
- kit/bundle label,
- named members (`src`, `data`, `out`, `svc`, `tmp`, ...),
- rights summaries,
- origin receipt,
- durability state,
- and whether any member requires rebind or fresh consent.

Dragging a card between panes should not silently copy authority. It should open a **bind / launch / receipt-only** chooser.

## View panes should advertise their current truth
Each pane or tab should have a tiny **view card** showing:
- view label / domain,
- current cwd binding,
- live workspace binds,
- trust state,
- ambient-debt state,
- offline/hydration state if relevant,
- and last authority-changing receipt.

That makes panes different capability domains instead of just different rectangles.

## Great moves worth prototyping
- **Launch diff**: compare current pane authority against the candidate child launch kit.
- **Replay with strip controls**: replay a block with `read-only`, `no export`, `fresh temp view`, or `re-consent required` toggles.
- **Kit-to-recipe freeze**: save the workflow structure and receipts without serializing live authority.
- **Rebind lane**: when a remembered kit is stale, offer explicit `rebind members` actions instead of a mysterious failure.
- **Authority breadcrumbs**: any output block can answer “which bind, kit, or portal receipt made this possible?”
- **Cross-pane handoff sheet**: moving something from one pane to another should present `transfer`, `bind`, `route`, or `receipt-only` as different actions.

## Structured shell ideas
The exact syntax can wait, but structured results would help a lot. For example, a completion/palette row or pipeline value could carry:
- subject class (`live_handle`, `bundle`, `view_fragment`, `receipt`, `uri`),
- current usability (`usable_here`, `needs_rebind`, `receipt_only`, `stale`),
- and a compact rights summary.

That is where a Nushell-like structured posture could make the shell feel magical **without lying**.

## A tiny honest prototype would already be great
The first shell prototype does not need everything.
It would already be amazing to ship:
- visible pane view cards,
- command blocks with receipts,
- one-key launch rehearsal,
- kit cards with member/right summaries,
- and a loud ambient-debt marker.

If that feels delightful and still totally explainable, the bigger notebook/palette/route-sheet future is worth pursuing.
