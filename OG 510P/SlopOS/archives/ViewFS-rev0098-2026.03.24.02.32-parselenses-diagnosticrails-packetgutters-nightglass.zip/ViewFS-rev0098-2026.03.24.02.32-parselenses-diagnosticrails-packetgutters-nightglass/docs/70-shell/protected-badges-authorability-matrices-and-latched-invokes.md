# Protected badges, authorability matrices, and latched invokes

Purpose: collect shell/terminal ideas for the next source/admissibility seam without freezing shell syntax.

ViewFS can be much more ambitious if it clearly distinguishes:
- what is **protected-authorable only**,
- what is merely **invoke-only** from this source class,
- what is **adoptable** after explicit review,
- and what is only **history/advice**.

## 1. Protected chip beside the prompt / pane title
Every pane should be able to show a compact chip such as:
- `protected-only`
- `invoke-only`
- `adoptable after review`
- `broker-owned`

Great effect:
- users can tell instantly whether the current lane may write always-on state or only run once.

Guardrail:
- the chip is explanatory until the user explicitly enters an invoke or adoption path.

## 2. Authorability matrix drawer
A single keystroke should answer:
- what source class this material came from,
- what state class it is trying to affect,
- whether the cell is `protected-only`, `adoptable`, `invoke-only`, `advisory-only`, or `forbidden`,
- what stronger source or gate is blocking a broader outcome.

Great effect:
- it turns “why didn’t this become active?” into a crisp inspectable object instead of folklore.

Guardrail:
- the drawer is not itself an override surface.

## 3. Latched invoke button
Some lower-trust material should have an explicit `invoke once` path that is proud of being narrow.
Examples:
- run this prompt/helper for the current chat block only,
- use this route suggestion for one launch only,
- attach this helper for this pane/session only,
- preview with this tool once without promoting it to always-on behavior.

Great effect:
- the shell can stay fast and helpful without pressuring the user into adoption.

Guardrail:
- a latched invoke must not silently write always-on state or widen future prompts.

## 4. Auto-apply lock icon
Some source/state combinations should be visually locked out of automatic influence.
Examples:
- workspace material may be browsable but not allowed to become always-on instructions,
- plugin-delivered helpers may be callable but not allowed to author ceilings,
- history/receipt material may recommend a replay path but not become startup truth.

Great effect:
- users stop mistaking “I can see it” for “it may auto-apply.”

Guardrail:
- the lock icon should explain the safe next move, such as invoke once, review, or ask owner policy.

## 5. Broker badge and judge handoff
When a stronger authority lane is in force, the shell should say so explicitly.
Examples:
- `org/device broker deciding`
- `local prompts explanatory only`
- `interactive prompts suppressed by broker`

Great effect:
- users can tell the difference between a rich local UI and the actual current judge.

Guardrail:
- broker badges are about decision ownership, not generic “managed” decoration.

## 6. Receipt cards that preserve invoke vs adopt
When an action completes, the receipt should say at minimum:
- what source class supplied the material,
- what state class was being targeted,
- whether the outcome was `invoked once`, `adopted`, `withheld`, `overruled`, or `forbidden`,
- what stronger source or gate caused the final result.

Great effect:
- the shell tells the truth about how help turned into action.

Guardrail:
- receipts are history, not hidden future state.

## 7. Terminal-native protocol hints
Steal from REF-WEZTERM-SHELL-INT and REF-GHOSTTY-OSC133-OVERLAY.

Use terminal metadata for:
- protected chips in prompt chrome,
- matrix drawer hotkeys,
- latched invoke badges on result cards,
- broker badges for managed sessions,
- receipt cards that preserve invoke-vs-adopt truth.

Great effect:
- the terminal becomes source-and-authorability-aware without screen-scraping scrollback.

Guardrail:
- terminal metadata should expose shell state, not redefine authority semantics.

