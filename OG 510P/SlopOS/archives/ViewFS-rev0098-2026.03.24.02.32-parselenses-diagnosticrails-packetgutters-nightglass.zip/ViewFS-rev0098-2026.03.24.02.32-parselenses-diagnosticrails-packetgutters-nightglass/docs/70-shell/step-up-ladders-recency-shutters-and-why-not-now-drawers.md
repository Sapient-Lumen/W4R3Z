# Step-up ladders, recency shutters, and why-not-now drawers

A future custom shell will get one enormous product win if it refuses one common lie:
`held now` should not automatically render as `usable now`.

That sounds obvious, but mainstream systems constantly flatten these classes:
- object exists locally,
- handle is live,
- token is present,
- user is generally signed in,
- therefore the current action should work.

Real systems do not work that way.
One action may still need:
- fresher proof,
- stronger authentication,
- immediate local presence,
- or one action-scoped satisfaction that should not silently replay forever.

## The shell moves worth stealing

### 1. Why-not-now drawers
For any blocked `open`, `invoke`, `export`, `decrypt`, or `send`, let the shell say:
- `missing authority`
- `held, but too old for this action`
- `held, but stronger auth needed`
- `held, but local presence needed`
- `held and invokable now`
- `history only`

That is much better than one fake `permission denied` banner.

### 2. Step-up ladders
A transcript row or object card should be able to offer:
`inspect possession` → `refresh auth` → `satisfy stronger requirement` → `verify presence` → `invoke now`

The value here is honesty.
The ladder should explain what class of missing truth is being repaired, not just dump the user into one mystery dialog.

### 3. Recency shutters
A good shell should let a row decay visibly from:
- `fresh enough`
- to `freshness aging`
- to `too old for this action`
- to `history only`

The underlying handle/object may still be present.
The thing that changed is current invocability.
That should be visible.

### 4. Presence pins
Actions that need one immediate local proof should say so with small chrome such as:
- `touch needed`
- `verify user`
- `device auth needed`
- `satisfied for this attempt`

This is especially important if ViewFS grows holder-bound or device-bound power later.

### 5. Satisfaction ghosts
The shell should remember that one challenge was:
- satisfied,
- failed,
- expired,
- or spent.

That gives users truthful replay ergonomics.
One prior successful challenge should help explain history without silently reviving current invocability.

## What makes this super awesome
- safer replay without fake timeless sessions;
- much better import/open/export diagnostics;
- cleaner portal/auth handoffs because the terminal can explain what the missing truth class is;
- and a genuinely new kind of transcript honesty: not just `what object`, but `what was still missing before the action could proceed`.
