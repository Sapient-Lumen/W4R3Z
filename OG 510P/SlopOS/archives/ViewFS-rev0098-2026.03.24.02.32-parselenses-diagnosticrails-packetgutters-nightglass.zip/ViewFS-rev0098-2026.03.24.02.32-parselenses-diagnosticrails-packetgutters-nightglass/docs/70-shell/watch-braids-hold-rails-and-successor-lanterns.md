# Watch braids, hold rails, and successor lanterns

A future custom shell will get another enormous product win if it refuses one common lie:
`still held here` should not automatically render as `still in good standing here`.

That sounds obvious, but real systems constantly flatten these classes:
- object or handle still exists,
- some old success or old verification happened,
- maybe one watch result or status glow exists somewhere,
- therefore the current action should work.

Real systems do not work that way.
One action may still be sitting under:
- a stale watch result,
- a reversible suspension,
- a local quarantine,
- or a successor/refresh notice that has not been adopted yet.

## The shell moves worth stealing

### 1. Watch braids
For any object card, transcript row, or action drawer, let the shell show:
- base possession truth,
- latest status carrier source,
- local receiver stance,
- local hold posture,
- refresh/successor posture,
- current invocability.

That is much better than one fake green/red badge.

### 2. Hold rails
A transcript row or object card should be able to offer:
`inspect base truth` → `inspect status carrier` → `see local hold` → `refresh/adopt successor` → `invoke now`

The value here is honesty.
The rail should explain what class of missing truth is being repaired, not just dump the user into one mystery retry.

### 3. Successor lanterns
A good shell should say when something newer exists with small honest chrome such as:
- `refresh available`
- `replacement available`
- `successor required`
- `still on older witness`
- `successor adopted`

This is especially important if ViewFS grows watched credentials, rotating roots, or renewable imports later.

### 4. Stale-watch fog
Rows should be able to decay visibly from:
- `watch current`
- to `aging`
- to `watch stale`
- to `history only`

The underlying handle/object may still be present.
The thing that changed is standing-watch confidence and local stance.
That should be visible.

### 5. Quarantine shutters and resumed-good ghosts
The shell should remember that a subject was:
- narrowed,
- suspended,
- quarantined,
- refreshed,
- resumed,
- or replaced by a successor.

That gives users truthful replay ergonomics.
One prior good state should help explain history without silently reviving current good standing.

## What makes this super awesome
- much better `why paused?` and `why not now?` answers;
- safer import/open/export flows when outside status changes later;
- clearer portal and provider follow-through because the terminal can show whether a weaker watch artifact, a local hold, or a successor requirement is the blocker;
- and a genuinely new kind of transcript honesty: not just `what object`, but `what later signal changed its local consequence`.
