# Authority HUD and receipt cards

Purpose: collect shell/terminal interaction ideas that make ViewFS feel outstanding while staying honest about where authority actually comes from.

## Core idea
A great ViewFS shell should make three things obvious at a glance:
1. **what live authority is active in this pane right now**,
2. **what durable refs or workspace binds could be re-opened/rebound**,
3. **what recent actions are just receipts or memories rather than usable authority**.

That suggests a light but explicit **authority HUD** plus compact **receipt cards** attached to command blocks.

## Precedents worth stealing
- **REF-WEZTERM-SHELL-INT**: explicit cwd + prompt/input/output metadata unlocks navigation and better pane semantics.
- **REF-ITERM-SHELLINT**: shell integration can keep track of command boundaries, cwd, host, marks, and command status.
- **REF-WEZTERM-HYPERLINKS** and **REF-ITERM-OSC8**: terminals can render clickable links cleanly when the target is explicit.
- **REF-XDG-REQUEST**: user-mediated operations naturally have a request object and a response/result event.
- **REF-WARP-BLOCKS**: command-plus-output is a better unit than a blind scroll stream.

## Authority HUD
The prompt area or pane chrome should be able to show a compact summary such as:
- active view/domain badge
- active workspace bind label
- whether the current cwd is a live local binding or a compat/path membrane
- high-level rights summary (`ro`, `rw`, `export`, `transfer-only`, etc.)
- ambient-debt marker if any host fallback was used
- stale/rebind-needed indicator for pinned recents or workspace refs

The HUD should be a **summary**, not a full policy explainer.
One key should expand it into a detail panel.

## Receipt cards
Each command block can optionally end with a compact receipt card. Examples:
- `opened 1 object via chooser · ephemeral · receipt only`
- `workspace rebound · rw tree grant · durable ref available`
- `transfer delivered 3 files · writable=false · autostop`
- `save/export completed · destination grant one-shot`
- `reopen failed · target moved/deleted · portal needed`

Receipt cards are useful because they keep the audit trail human-visible without making the terminal feel like a policy console.

## Great UX moves

### 1. Distinguish live from reopenable
A card or palette row should be able to say:
- `live here`
- `reopenable`
- `receipt only`
- `needs portal`
- `needs rebind`
- `stale`
- `ambient debt`

That is much better than pretending everything clickable is equally ready.

### 2. Make click behavior type-preserving
Clicking a receipt or object chip should open a route sheet with actions like:
- inspect
- reveal in current view
- rebind workspace
- reopen via portal/service
- export/share
- launch external URI

No generic “smart open” that launders the differences.

### 3. Keep transcript sharing safe by default
When a block is copied/shared/exported:
- include command text,
- include sanitized receipt summaries,
- optionally include durable-ref descriptors if policy allows,
- exclude live handles by default.

### 4. Add a tiny explainability overlay
One key should answer:
- what live bindings were present?
- did a portal interaction happen?
- is this block backed by a durable ref or only a receipt?
- what would it take to replay this command here?

### 5. Make recents searchable but honest
A unified palette can still be wonderful, but it should index separate sections for:
- views/workspaces
- live local objects
- durable refs / recents
- workflows/notebooks
- receipt history

That prevents “recent” from becoming another word for “currently authorized”.

## Minimal protocol hints
These ideas probably need only a few extra fields beyond the current shell protocol sketch:
- `authority_summary`
- `live_binding_ids`
- `durable_ref_ids`
- `receipt_ids`
- `replay_mode_hint`
- `staleness_state`

The exact wire format can wait.

## Delightful extras to steal later
- hover chips for rights/durability/state
- timeline scrubber that highlights authority-changing blocks
- pane badges that change when a workspace bind changes
- “replay stripped” mode that intentionally runs without grants first
- receipt card folding/expansion in scrollback
- inspector overlay that can visually outline the prompt/input/output/receipt regions

## Anti-goals
- no transcript that secretly carries live capability power
- no palette that hides whether an item is live, durable, or merely historical
- no receipt cards that pretend to be proof of current access
- no shell chrome that lies about authority to look simple
