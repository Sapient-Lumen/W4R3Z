# Proposer badges, escalation ladders, and adoption gates

Purpose: make the ViewFS shell feel **super awesome** while staying brutally honest about who is proposing a change, who may adopt it, and what scope would actually change.

## North star
A great ViewFS shell should let a user see, at a glance:
- **who proposed this** — `workspace`, `profile`, `org`, `history`, `receipt`, `mediator`, `shell-local`
- **what scope it is asking for** — `once`, `pane`, `session`, `workspace`, `profile`, `org`
- **whether it is only advice** — still non-authoritative and abortable
- **whether escalation is needed** — a higher-scope move should feel different from a one-shot act
- **who finally adopted or declined it** — so history explains changes instead of forcing guesswork

That is the right way to keep the shell fast and helpful without letting it quietly change who the current judge is.

## Shell moves worth stealing

### 1. Proposer badge
A compact badge should show:
- proposal origin (`workspace`, `profile`, `org`, `receipt`, `history`, `shell-local`)
- target class (`policy switch`, `repair`, `workflow promotion`, `rebind`, `open route`, `other`)
- whether the proposal is non-authoritative, blocked, or already escalated

Super-awesome move:
- one keystroke opens the proposal card from prompt chrome, a notebook cell, or a result card.

Guardrail:
- proposer badges are inspect-only until the user explicitly crosses an adoption gate.

### 2. Scope chip
Every meaningful proposal should advertise the scope it is asking for:
- `once`
- `pane`
- `session`
- `workspace`
- `profile`
- maybe later `org`

Super-awesome move:
- the shell can default to the narrowest viable scope and let the user widen it deliberately.

Guardrail:
- no proposal may silently widen from `once` to `workspace` or `profile`.

### 3. Escalation ladder
When a suggestion would need broader scope, the shell should show an explicit ladder such as:
- `use once`
- `pin to pane`
- `allow for session`
- `adopt for workspace`
- `save in profile`
- `decline`
- `receipt only`

Super-awesome move:
- each rung can preview what future interruptions it removes and what new standing effect it would create.

Guardrail:
- the ladder is still a proposal surface; nothing should change until one rung is explicitly chosen.

### 4. Adoption gate
Crossing from proposal to live truth should be loud.
The gate should say:
- what exact proposal is being adopted,
- who proposed it,
- who is allowed to adopt it,
- what scope will become live,
- what denials/ceilings still apply,
- and what receipt will be written.

Super-awesome move:
- one keystroke can accept the narrowest safe rung, while a wider rung needs a more explicit gesture.

Guardrail:
- if a higher-authority lane is needed, the shell should escalate visibly instead of “helpfully” faking the result.

### 5. Decline and quarantine receipts
The shell should remember that a proposal was reviewed and declined.
Useful states include:
- `declined once`
- `declined for session`
- `blocked by deny`
- `blocked by scope ceiling`
- `stale proposal`
- `proposal source changed; re-review needed`

Super-awesome move:
- declined proposals can collapse into a quiet history chip instead of reappearing every prompt.

Guardrail:
- a decline receipt is history, not a hidden standing veto beyond the scope the user chose.

## Prompt chrome / pane chrome ideas
- **proposer badge** in pane chrome: `workspace`, `profile`, `org`, `receipt`, `history`
- **scope chip** next to it: `once`, `session`, `workspace`, `profile`
- **escalation spark** when a proposal is asking for broader standing effect than current posture allows
- **adoption gate badge** when a suggestion is ready for explicit commit

## Result-card ideas
A result card should be able to say:
- `proposal shown, not adopted`
- `adopted once from workspace suggestion`
- `promoted from receipt to profile workflow`
- `blocked by deny ceiling`
- `history only; proposal source stale`
- `declined for this session`

## Notebook / replay ideas
- notebook cells should preserve proposer origin and last adopted scope as history only
- replay should first compare `recorded proposal source/scope` versus `current source/scope`
- any move from narrow to broader scope should route through the escalation ladder again
- `receipt only` should remain a first-class outcome for stale or no-longer-admissible proposals
