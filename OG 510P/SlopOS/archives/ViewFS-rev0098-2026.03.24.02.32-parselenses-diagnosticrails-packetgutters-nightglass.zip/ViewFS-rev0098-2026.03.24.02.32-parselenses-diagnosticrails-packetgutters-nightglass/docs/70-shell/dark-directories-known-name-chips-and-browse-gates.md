# Dark directories, known-name chips, browse gates, and fit sheets

Purpose: make the future custom shell+terminal honest about four different truths: **I already hold it**, **I can try this exact child name**, **I can browse/list this container**, or **something merely suggested it**.

## The shell should answer the awkward question directly
When something appears in UI chrome, users deserve to know why it appeared.
The shell should not make them guess whether a candidate was browse-visible, search-suggested, exact-name-only, or already held as live authority.

## Moves worth stealing

### Dark directories
Some containers should render as intentionally dark:
- child names are not automatically listed,
- exact-name access may still work,
- and the user can explicitly request a browse grant or mediator pass.

This is a calmer and more honest model than pretending the file tree is always browseable.

### Known-name chips
When a command succeeds by opening `child` under a held root/view without browse rights, the transcript should say so.
A compact chip like `known-name under /root-X` is far more honest than showing the result as if it came from an explorer pane.

### Browse gates
Directory/list panes should be able to say:
- `browse granted`,
- `exact names only`,
- `ask portal`,
- `suggested only`,
- `history only`.

That gives users a truthful path to more disclosure without silently widening it.

### Fit sheets
Chooser/search/import UI should explain:
- why a candidate appeared,
- whether it is `preferred`, `acceptable`, `advanced`, or `history only`,
- whether it is currently openable or only suggestive,
- whether a portal or publication step is still needed.

This steals the best part of powerbox-like systems: match quality becomes explanation, not fake authority.

### Search-result dimmers
Results coming from history, helpers, or indexes should stay visibly dimmer than direct live authority.
The shell should make `seen before`, `suggested now`, and `openable now` look different.

## Delightful chrome ideas
- **Dark-directory shutters** that hide names until a browse gate is explicitly crossed.
- **Known-name chips** attached to command blocks and open receipts.
- **Browse badges** like `listable`, `exact-name-only`, `portal-browse`, `suggested`, or `history`.
- **Fit sheets** with `preferred` / `acceptable` / `advanced` sections rather than one flat search list.
- **Disclosure ladders** that offer `try exact name` before `list everything` when that is the smaller truth.

## Protocol hints
The shell/terminal sideband probably wants event rows like:
- `candidate-suggested`
- `fit-quality-declared`
- `browse-gate-requested`
- `browse-gate-granted`
- `exact-name-open-attempted`
- `exact-name-open-succeeded`
- `result-history-only`

That metadata should be emitted deliberately, the same way prompt/input/output marks and paste zones are better when explicit.

## What this avoids
- browseability being mistaken for authority;
- exact-name opens being mistaken for directory disclosure;
- suggestions being mistaken for live bindings;
- history/search results pretending to be current truth;
- and delightful shell chrome being built on invisible widening instead of explicit semantics.
