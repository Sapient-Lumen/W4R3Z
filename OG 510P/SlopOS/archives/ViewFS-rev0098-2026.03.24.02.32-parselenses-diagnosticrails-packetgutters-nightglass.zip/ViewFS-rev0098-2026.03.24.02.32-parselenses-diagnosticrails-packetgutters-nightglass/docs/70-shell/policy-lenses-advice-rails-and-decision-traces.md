# Policy lenses, advice rails, diagnostic cards, and audit traces

Purpose: make the ViewFS shell feel **super awesome** while staying brutally honest about what is policy truth and what is only shell cleverness.

## North star
A great ViewFS shell should let a user see, at a glance:
- **policy-known** — a concrete policy family/cut was consulted
- **advice-only** — the shell is suggesting a move but that suggestion is not authorization
- **diagnostic-ready** — the shell can explain why the candidate is allowed, narrowed, denied, or receipt-only
- **audit-redacted** — a durable trace exists, but it is history/debug material rather than current authority
- **reconsent-needed** — the shell is falling back to fresh mediation instead of pretending history equals permission

That is much better than a terminal that only knows “tab completion found something” and “permission denied”.

## Best ideas worth stealing
- **REF-CEDAR-AUTHZ**: authorization responses that return a decision plus determining-policy/error diagnostics are a great model for compact decision cards.
- **REF-CEDAR-VALIDATION**: validation being separate from authorization is exactly the right reminder that policy-editing errors and runtime deny outcomes need different shell affordances.
- **REF-OPA-CORE** and **REF-OPA-DECISIONLOGS**: decouple policy decision-making from enforcement, and keep durable decision traces bounded/redacted.
- **REF-POLKIT-AUTHORITY**: authority, authentication agents, and temporary authorization are different objects; the shell should keep them visibly separate too.
- **REF-GHOSTTY-OSC133-OVERLAY** and **REF-WEZTERM-SHELL-INT**: semantic prompt zones plus debug overlays are the perfect substrate for policy/advice/diagnostic HUDs.

## Policy lenses could be incredible
Activate a candidate import/run/replay and get a **policy lens**:
- which policy family was consulted,
- whether the family/schema passed validation,
- which policy cut/version the shell believes it used,
- whether the shell is showing live decision diagnostics or only historical traces,
- and what caveat/policy family narrowed the move.

That is the right place to be clever.

## Advice rails should stay visibly non-authoritative
An **advice rail** could show:
- top-ranked likely next actions,
- safer narrowed alternatives,
- likely rebind targets,
- likely fresh-mediation repairs,
- or “same command but stripped of export/write power”.

The shell should brag about being helpful here.
It should never pretend that advice equals permission.

## Diagnostic cards beat generic failures
A **diagnostic card** should explain classes like:
- `allowed by exact policy`
- `denied by explicit veto`
- `narrowed by caveat`
- `invalid policy or schema drift`
- `missing witness or stale basis`
- `receipt-only because live authority is gone`

That is the right replay/import/run UX for a capability-native shell.

## Audit traces should feel useful but obviously historical
A durable **audit trace chip** should show:
- whether a decision trace exists,
- whether it was redacted,
- whether it is exportable or local-only,
- and whether it reflects the current policy cut or only a historical one.

That is how the shell can be debug-friendly without making logs act like permissions.

## Great terminal-native moves
- **Policy hotkey**: open the current block’s policy lens.
- **Advice rail gutter**: show ranked non-authoritative next steps beside the block.
- **Diagnostic card stack**: result card -> why panel -> policy lens -> audit trace.
- **Audit mode overlay**: highlight which parts of the UI are current decision truth versus historical explanation.
- **Safer-than-last-time replay**: let replay default to a narrower route the policy will still admit.

## Structured shell values worth exploring
A structured shell could let commands emit values such as:
- `policy_schema_status`
- `policy_set_ref`
- `advice_rail`
- `decision_diagnostic`
- `decision_log_ref`

That would make notebooks, palettes, overlays, and debugging panels far more truthful.

## A tiny honest prototype would already be great
The first prototype does not need a huge framework.
It would already be great to ship:
- one **policy lens**,
- one **advice rail** with loud non-authoritative labeling,
- one **diagnostic card**,
- one **audit trace chip**,
- and a prompt badge that distinguishes `policy-known` from `advice-only`.

If that feels good, the shell will have found another real superpower instead of just a fancier completion menu.
