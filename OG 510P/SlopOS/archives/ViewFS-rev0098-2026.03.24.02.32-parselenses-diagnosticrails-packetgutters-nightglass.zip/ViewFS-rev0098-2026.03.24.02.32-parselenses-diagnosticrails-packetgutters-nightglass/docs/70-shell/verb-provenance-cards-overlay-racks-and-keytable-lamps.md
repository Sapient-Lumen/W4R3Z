# Verb provenance cards, overlay racks, and key-table lamps

One of the nicest shell moves available to ViewFS is to stop pretending that built-in verbs, lexical shortcuts, overlay commands, palette actions, and external launches are all the same class.
This note collects shell/terminal ideas for the seam between **built-in verbs**, **lexical expansions**, **semantic command layers**, **key actions/widgets**, **external launches**, and **history only**.

## 1. Verb provenance cards

Every command block should be able to render a compact card like:
- `built-in verb`
- `expanded then built-in`
- `overlay command`
- `custom command`
- `key action only`
- `external launch`
- `history only`

The card should answer what actually won, not what the user vaguely meant.

## 2. Abbr gutters

Before execution, the shell should be able to preview lexical expansion inline:
- `gco` → `git checkout`
- `vfr` → `viewfs receipt`
- `route?` → one snippet or template candidate

The gutter should make it obvious that this is **input rewriting**, not yet the semantic winner.

## 3. Overlay racks

Activated command layers should be first-class objects in the shell UI.
Useful rack rows include:
- `git overlay active`
- `project helper overlay active`
- `receipt tools overlay active`
- `custom verbs shadowing 2 names`
- `overlay inactive, history only`

These racks should be diffable and easy to toggle.
That gives users powerful layering without hidden command drift.

## 4. Key-table lamps

When a modal interaction layer is active, the shell should say so.
Useful lamps include:
- `resize table active`
- `selection table active`
- `palette table active`
- `default keys`

A user should never have to guess why arrow keys, Enter, or one letter suddenly changed meaning.

## 5. Which ladders

A future ViewFS shell should make `which` dramatically better than classic shells.
A ladder for one token should be able to say:
- `built-in candidate`
- `overlay candidate`
- `custom command candidate`
- `external executable candidate`
- `hidden by active overlay`
- `history row only`

That is one of the easiest ways to make a custom shell feel powerful and honest at the same time.

## 6. Palette versus typed diff drawers

If one action is reachable from the command palette or a keybinding but not from the typed namespace, the shell should say so.
Useful drawers include:
- `palette-only action`
- `key-only widget`
- `also available as built-in verb`
- `custom overlay verb available`
- `external launch only`

That keeps transcript truth and interaction truth from drifting together.

## 7. Super-awesome terminal moves worth stealing

- **verb provenance cards** at the top of each block so users can tell what won without guesswork.
- **abbr gutters** that preview lexical expansion before the semantic winner is chosen.
- **overlay racks** in a side panel where users can activate, deactivate, diff, and inspect command layers.
- **key-table lamps** in pane chrome so modal keybinding posture is always visible.
- **which ladders** on hover / palette search that explain all visible winners and shadows.
- **replay as built-in only** actions so a user can rerun a step without expansion, overlay drift, or widget-only behavior.

References: SlopOS capshell posture, REF-FISH-ABBR, REF-NU-OVERLAYS, REF-NU-CUSTOMCOMMANDS, REF-NU-WHICH, REF-ZSH-ZLE, REF-GHOSTTY-KEYTABLES, REF-GHOSTTY-CMDPALETTE, REF-VSCODE-PROFILES.
