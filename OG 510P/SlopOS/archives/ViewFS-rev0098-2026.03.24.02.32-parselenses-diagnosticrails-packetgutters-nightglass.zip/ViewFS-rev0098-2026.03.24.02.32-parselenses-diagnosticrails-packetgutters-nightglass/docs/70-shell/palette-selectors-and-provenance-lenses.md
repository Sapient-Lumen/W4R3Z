# Palette selectors and provenance lenses

Purpose: collect shell/terminal moves that make ViewFS discovery feel magical **while remaining honest** about provenance, authority, and stale state.

## North star
The ViewFS shell should have one excellent selector surface — a palette / omnibox / jump bar — that can search across:
- live objects,
- durable refs,
- receipts,
- recent items,
- saved queries,
- workflows,
- notebooks,
- route targets,
- and local notes.

But the palette should never flatten them into one anonymous “open” action.

## Best ideas worth stealing
- **REF-WARP-CMDPALETTE**: one global search surface with filters for different item kinds.
- **REF-WARP-WORKFLOWS**: searchable parameterized commands belong in the same selector universe as actions and docs.
- **REF-ITERM-SHELLINT**: command/directory/host history becomes more powerful when the terminal knows where commands start and what directory they ran in.
- **REF-WEZTERM-SHELL-INT**: cwd plus prompt/input/output zones enable better pane-aware actions and navigation.
- **REF-GTK-RECENT**: recent-item registries are metadata-rich and useful, but obviously database-like rather than magical.
- **REF-GNOME-LOCALSEARCH**: search surfaces can expose eligibility, indexing status, and existence checks instead of only optimistic matches.

## The big rule
Every selector row should expose three dimensions:
1. **kind** — `live`, `ref`, `receipt`, `recent`, `query`, `workflow`, `uri`, `note`
2. **source** — `active view`, `journal`, `recent DB`, `query index`, `workspace`, `route sheet`
3. **status** — `ready`, `reopenable`, `rebind-needed`, `portal-needed`, `receipt-only`, `stale`, `ambient-debt`

That one discipline keeps the UI fast and exciting without lying.

## Provenance lens
A row should have a quick “why is this here?” lens showing:
- where it came from,
- when it was last seen or validated,
- whether it is based on live authority, a durable ref, a recent hint, or pure history,
- what action classes are possible from here.

This should be a first-class interaction, not debug-only trivia.

## Selector prefixes worth considering
Without freezing syntax, a palette could support scoped prefixes such as:
- `obj:` live objects in the active view
- `ref:` durable reopen refs
- `recent:` recent-item hints
- `query:` saved queries / smart folders
- `wf:` workflows
- `nb:` notebooks
- `receipt:` historical outcomes
- `uri:` route/launch targets

The important part is not the exact prefix spelling. The important part is that item classes stay visible.

## Better-than-normal preview behavior
A selector preview should prefer:
- metadata summaries,
- provenance/state badges,
- object kind,
- expected route/action classes,
- last validation result,
- related receipts or workflows.

It should be conservative about:
- content previews from quarantined or not-currently-authorized objects,
- assuming that a recent URI is still valid,
- silently traversing outside the active view.

## Great palette actions
For a selected row, offer typed actions such as:
- `inspect`
- `rebind`
- `reopen`
- `reveal in workspace`
- `route via portal`
- `show receipts`
- `copy typed ref`
- `promote to workflow`
- `pin as query`

This is much better than every row supporting a generic double-click open.

## Route sheets and selector rows should fit together
A selector row should be able to expand into a route sheet that says:
- what class of thing this is,
- what seams can handle it,
- what authority is missing,
- what policy/portal step would be required,
- whether a stripped/safe action is available.

This is where typed routing becomes delightful instead of bureaucratic.

## Nifty interaction ideas
- **Palette truth badges** that update live when a ref becomes stale or a workspace rebind succeeds.
- **Provenance peek** on hover or keypress.
- **Authority diff from selector** before replaying a workflow or reopening a recent item.
- **Recent-but-not-authorized rows** that still help you find the right rebind path.
- **Promote search to smart folder** only as a shell-owned query manifest.
- **Selector-to-journal links** so every row can jump to the block/receipt that created it.
- **Ambient-debt highlighting** when a row came from host-side discovery instead of a ViewFS-native seam.

## Anti-goals
- a palette that hides provenance because “that would be too technical”
- selectors that silently reacquire old authority on click
- recent-item UX that cannot explain why a row is stale or rebindable
- treating search hits as if they were canonical object IDs
