# Journals, notebooks, and safe replay

Purpose: collect shell/terminal moves that make ViewFS unusually powerful while keeping journals, saved blocks, notebooks, and workflows honest about authority.

## North star
The ViewFS shell should feel like it has memory, taste, and momentum:
- journals of what you did,
- notebooks of what you learned,
- workflows of what you repeat,
- palettes of what matters now.

But all of that should remain visibly separate from live capability state.

## Best ideas worth stealing
- **REF-WARP-BLOCKS**: make command+output an atomic, bookmarkable unit.
- **REF-WARP-NOTEBOOKS**: let runnable notes live near the terminal instead of in a totally separate tool.
- **REF-WARP-WORKFLOWS**: parameterized, searchable saved commands are genuinely useful.
- **REF-WARP-CMDPALETTE**: global search across commands, notes, workflows, and actions is the right interaction shape.
- **REF-WEZTERM-SHELL-INT** and **REF-WEZTERM-USERVARS**: shells can publish deliberate pane state and semantic regions to the terminal.
- **REF-ITERM-SHELLINT**: command/directory/host memory can become part of the terminal experience.
- **REF-NUSHELL**: structured data should flow through pipelines where possible.

## The big rule
Saved shell state should always tell you whether it is:
- `live authority`
- `reopenable ref`
- `receipt/history`
- `text/note only`

That one small classification makes a huge amount of UX possible without lying.

## Journal model
A journal is the chronological memory of work:
- block cards,
- command text,
- output summary,
- status,
- receipt chips,
- optional durable-ref chips,
- notes/tags.

Great journal moves:
- jump between authority-changing blocks,
- filter by object kind or view badge,
- collapse to just commands that widened authority,
- scrub by `opened`, `rebound`, `transferred`, `saved`, `failed`, `ambient debt`.

## Notebook model
A notebook is a curated, replayable document made from journal material.

Each cell or block can carry:
- command text or structured action spec,
- expected input shape,
- attached receipt summary,
- optional durable-ref sidecar,
- replay mode (`strict`, `safe`, `portal-ok`, `stripped`),
- local commentary.

The important thing is that the notebook preserves *how to re-enter the workflow*, not a hidden bag of live handles.

## Workflow model
A workflow is a named reusable action with parameters.

For ViewFS, a workflow row should ideally show:
- required object kinds / bindings,
- whether those bindings are currently live,
- whether durable refs exist,
- whether replay needs a chooser/portal,
- whether this workflow ever relied on an ambient fallback.

That makes workflows trustworthy instead of magical.

## Safe replay modes
### 1. Strict replay
Use only the exact live bindings already present. Fail if anything is missing.

### 2. Reopen/rebind replay
Attempt to reacquire needed authority from attached durable refs or workspace descriptors.

### 3. Portal-assisted replay
If authority is missing, explicitly ask the user through chooser/save/rebind routes.

### 4. Stripped replay
Run without remembered grants, even if refs exist, to see what the minimal dependency set really is.

This could become one of the coolest parts of the shell.

## Palette design
The palette should search across:
- live objects,
- durable refs,
- journals/receipts,
- notebooks,
- workflows,
- views/workspaces.

But results must stay typed. The palette should not flatten everything into “open”.

Useful row badges:
- `live`
- `ref`
- `receipt`
- `note`
- `workflow`
- `workspace`
- `stale`
- `portal`
- `ambient debt`

## Pane/session restore
A restored pane should come back with:
- journal blocks,
- notebook tabs,
- palette memory,
- layout,
- view/workspace labels,
- rebind suggestions.

It should **not** silently wake old authority just because the pane came back.

## Beautiful UX moves
- **Authority diff before replay**: show what new binds are needed versus what is already live.
- **Receipt-to-workflow promotion**: turn a successful block into a reusable workflow without copying hidden grants.
- **Notebook truth badges**: every cell says whether it is live/reopenable/receipt-only.
- **Session restore checklist**: “layout restored; 2 refs reopenable; 1 portal step needed; 1 stale item skipped”.
- **Timeline lane for authority-changing moments**: not all blocks matter equally.
- **Rebind once, fan out carefully**: after a successful workspace rebind, show which saved blocks or workflows just became runnable.

## Anti-goals
- notebooks that secretly serialize live capability state
- replay that silently widens authority to “make it work”
- palettes that hide whether an item is live or historical
- journals that cannot explain why a command is no longer runnable
