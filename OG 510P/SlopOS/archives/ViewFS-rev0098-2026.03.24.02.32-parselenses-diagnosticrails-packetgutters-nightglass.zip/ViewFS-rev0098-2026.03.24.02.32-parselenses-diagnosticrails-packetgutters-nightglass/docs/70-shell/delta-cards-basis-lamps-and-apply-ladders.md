# Delta cards, basis lamps, and apply ladders

The custom ViewFS shell should be able to handle efficient reconstruction/update flows without turning them into spooky magic.
That means making at least six truths visible:
- **recipe present**,
- **basis required**,
- **basis present/missing/mismatched**,
- **apply session running**,
- **reconstructed result materialized**,
- **fell back to full fetch**.

## 1. Basis cards

Whenever the shell knows a current delta/update/repair opportunity depends on one exact basis, it should surface a compact card such as:
- `recipe R targets T from base B`
- `base B local`
- `base validator mismatched`
- `basis not present here`
- `history only`

That keeps `needs B` separate from `have B` and separate again from `target T already exists locally`.

## 2. Delta peels

A delta-oriented object drawer should let the user peel the story apart:
- recipe metadata,
- exact basis requirement,
- apply safety/policy notes,
- reconstructed result if any,
- fallback whole-fetch path,
- receipt/history.

This is one of the nicest places to make the shell super awesome because most systems hide all of that behind `update` or `download`.

## 3. Basis lamps

The transcript and object cards should show compact truth lights such as:
- `basis exact`
- `basis local but unverified`
- `basis missing`
- `basis mismatched`
- `full fetch required`
- `history only`

That is dramatically better than one generic `update available` badge.

## 4. Apply ladders

The shell should not force one giant button.
Better ladders are:
- `apply in scratch`
- `verify reconstructed result`
- `materialize as fresh local object`
- `adopt/bind here`
- `fetch whole target instead`
- `discard recipe`

That preserves optionality while keeping reconstruction honest.

## 5. Rebuilt-from badges

When the shell *has* produced a target object from a basis plus recipe, it should say so explicitly:
- `rebuilt from B + R`
- `full target fetched instead`
- `delta apply abandoned`

Those are byte/result truths.
They are not the same thing as live-handle continuity, not the same thing as same-path continuity, and not the same thing as durable reopen authority.

## 6. Great transcript moves

A command block or route sheet could emit:
- a **basis witness chip**,
- a **recipe chip**,
- an **apply plan card**,
- a **fallback decision row**,
- and a **result lineage chip**.

That makes repair/update/import flows explainable and replayable without granting them magical authority.

## 7. What to avoid

Avoid:
- one vague `patched` or `updated` badge with no basis truth,
- silently swapping from delta reconstruction to full fetch with no visible record,
- pretending reconstructed bytes imply same live handle or same namespace bind,
- copy/pasteable bearer-like patch tickets with hidden authority semantics.

## 8. Why this will make the shell awesome

Because it lets the shell do something ordinary terminals and file choosers almost never do well:
show exactly **how** an object became current, what prior exact thing it depended on, and whether the system reconstructed it locally or gave up and fetched the whole target instead.

That is both honest and delightful.
