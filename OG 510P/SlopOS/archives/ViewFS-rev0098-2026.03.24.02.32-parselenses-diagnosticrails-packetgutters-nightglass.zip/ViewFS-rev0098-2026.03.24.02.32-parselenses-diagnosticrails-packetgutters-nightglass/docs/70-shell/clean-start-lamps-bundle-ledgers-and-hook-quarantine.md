# Clean-start lamps, bundle ledgers, and hook quarantine

One of the nicest shell moves available to ViewFS is to stop pretending that startup personalization, terminal integration, and project activation are all the same class.
This note collects shell/terminal ideas for the seam between **built-in shell baseline**, **explicit reviewed customization bundles**, **host/user startup files**, **project-local activation hooks**, and **history only**.

## 1. Clean-start lamps

Every shell pane should be able to render a compact lamp like:
- `built-in only`
- `reviewed bundle`
- `host profile active`
- `host profile blocked`
- `project hook pending`
- `project hook active`
- `project hook denied`
- `history only`

The lamp should answer what actually shaped this startup, not what the user vaguely intended last week.

## 2. Bundle ledgers

If explicit reviewed customization bundles are active, the shell should show them as first-class objects.
Useful ledger rows include:
- `prompt bundle`
- `alias/function pack`
- `completion pack`
- `shell integration module`
- `workspace helper bundle`

These ledgers should be diffable and promotable.
That gives users reusable delight without ambient rc/profile blur.

## 3. Profile-debt drawers

If a host/user startup file is in play, the shell should say so.
Useful drawers include:
- `~/.bashrc active`
- `PowerShell profile active`
- `ambient profile blocked`
- `manual import candidate`
- `promote useful bits`

The shell should make ambient profile use visible debt, not flattering baseline truth.

## 4. Hook quarantine shutters

Project-local activation requests deserve their own review surface.
Useful shutters include:
- `pending .envrc`
- `pending repo activation script`
- `allow once`
- `allow for workspace`
- `deny`
- `stale, re-review required`

These shutters should support diffing and provenance so a directory change never quietly becomes execution.

## 5. Prompt provenance cards

Before a user trusts a prompt, alias, completion, or shell integration behavior, the shell should be able to explain where it came from:
- `built-in shell code`
- `reviewed customization bundle`
- `startup profile script`
- `project-local hook`
- `history only`

That is a much better debugging and trust story than “the shell just does that.”

## 6. Super-awesome terminal moves worth stealing

- **clean-start lamps** at the top of each command block so the block knows whether it ran under built-in-only, reviewed-bundle, ambient-profile, or project-hook posture.
- **bundle ledgers** in a side panel where users can promote useful ambient snippets into explicit reviewed objects.
- **hook quarantine gutters** that appear on `cd` / workspace open when one project hook is pending or stale.
- **prompt provenance cards** that explain why the prompt/theme/integration changed.
- **replay without hooks** actions so users can rerun a command under built-in-only posture for debugging or trust comparison.

References: SlopOS `capshell-startup-profile-posture-v0.md`, REF-DIRENV-ALLOW, REF-DIRENV-REQUIREALLOWED, REF-VSCODE-WORKSPACE-TRUST, REF-VSCODE-COPILOT-SECURITY, REF-GHOSTTY-SHELL-INTEGRATION, REF-POWERSHELL-PROFILES.
