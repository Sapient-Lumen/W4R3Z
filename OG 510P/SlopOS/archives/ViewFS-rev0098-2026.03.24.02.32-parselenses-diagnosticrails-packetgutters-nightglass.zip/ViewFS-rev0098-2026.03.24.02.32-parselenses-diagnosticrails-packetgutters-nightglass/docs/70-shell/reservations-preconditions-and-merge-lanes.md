# Reservations, stale-write guards, and merge lanes

Goal: make concurrent editing and automation feel **truthful, fixable, and low-drama** without pretending the terminal has one magical global lock bit.

## Principle
The shell should make it obvious whether a write is:
- `safe now` because the precondition still matches,
- `stale` because the target moved,
- `reserved` because some bounded lease exists,
- `claim conflict` because another actor manages the relevant field/subtree,
- `override pending` because the user explicitly chose takeover,
- or `receipt only` because this row is just evidence about a failed or displaced attempt.

Great UX here is mostly **compare-before-commit + excellent stale/conflict states + explicit takeover receipts**.

## High-upside ideas

### 1. Save guarded by default
For normal editable objects, the first-class action should feel like:
- read current version,
- edit locally,
- save with an explicit expected-old value,
- and if the target moved, show a conflict card instead of stomping.

### 2. Reservation badges, not giant modal lock screens
A shell row could show:
- `reserved by me`
- `reserved by workflow X`
- `lease expired`
- `lease uncertain`
- `no reservation`

The key is making reservations visible and bounded, not mystical.

### 3. A “why blocked?” panel
When a write fails, one keystroke should answer:
- was the precondition stale?
- did a lease expire?
- is another actor claiming the field/subtree?
- did policy reject the takeover?
- what changed on the target since I started?

### 4. Conflict cards with side-by-side compare
A conflict card should show:
- my candidate change,
- current remote/current-head state,
- the version/digest I expected,
- the class of failure (`stale`, `lease`, `claim`, `policy`),
- and next actions: `refresh`, `merge`, `takeover`, `save elsewhere`, `discard`.

### 5. Lease strip / renew lane
If ViewFS has short leases later, the shell should make them pleasant:
- quick reserve,
- visible TTL,
- renew countdown,
- release now,
- auto-expire without drama,
- and a receipt when another actor legitimately takes over.

### 6. Force-with-lease as a product verb
One of the nicest ideas to steal is Git’s ergonomics here: an explicit “take over only if the target is still exactly what I think it is.”
That suggests a ViewFS verb family like:
- `save-if-unchanged`
- `move-head-if <digest>`
- `takeover-if <expected-old>`

Those are much better than a vague `--force`.

### 7. Ownership/claim lenses
If field/subtree claims ever appear, the shell should expose them as an inspect layer:
- who last asserted control,
- which fields/subtrees are under claim,
- whether the claim is shared, transferred, or stale,
- and whether override would strip someone else’s claim.

### 8. Gentle collaboration hints
A terminal can be unusually good at subtle coordination cues:
- who is editing,
- whether they still hold a live lease,
- whether the claim is only advisory,
- when your local edit first diverged,
- and whether merge is trivial or likely messy.

### 9. Safe override receipts
When a user intentionally overrides, the transcript should get a receipt row saying:
- what got displaced,
- which expected-old value was used,
- who/what held the prior lease or claim,
- and whether a compare was shown before takeover.

### 10. Replay should not replay the old lock fantasy
Notebook/workflow replay should be able to say:
- `re-run with fresh precondition`
- `reservation required`
- `current target moved`
- `manual merge required`

Saved workflows should not silently reuse stale assumptions.

### 11. Delightful keyboard flow
Plausible future verbs / shortcuts:
- `w` → guarded save
- `R` → reserve / renew
- `L` → release reservation
- `?` → why blocked?
- `D` → diff against current target
- `m` → open merge lane
- `T` → takeover preview
- `F` → takeover-if-unchanged
- `s` → save as new fork / alternate destination

Not final syntax—just the shape of an excellent product.

## Tiny protocol ideas worth stealing
The shell-to-terminal protocol may eventually want metadata like:
- expected-old digest/version,
- current target digest/version when known,
- reservation/lease state and TTL,
- ownership/claim class,
- conflict class,
- suggested next actions,
- and whether a row is merely a receipt.

That would make badges, blocked-write panels, merge lanes, and safe replay much more truthful.

## Product steals worth keeping in mind
- compare-and-swap / expected-old ergonomics from Git and HTTP conditional requests,
- bounded lease + auto-release behavior from etcd,
- field-ownership explanations from Kubernetes SSA,
- object-store preconditions from S3 and Azure Blob,
- and SQLite’s cautionary reminder that real writer coordination can get complicated quickly.

## Anti-goals
- one generic `locked` state that hides stale reads, expired reservations, and ownership conflicts under the same lie
- automatic last-writer-wins retry loops
- replay/workflow systems that silently reuse stale expectations
- turning lease tokens or ownership hints into bearer authority
- pretending merge/takeover are the same action
