# Draft gutters, commit shutters, and stale-base lamps

A future ViewFS shell should make editing feel safe and fast **without** pretending one local draft is already the durable truth.
That means keeping at least six visible classes apart:
- observed validator / basis,
- private writable session,
- live write hold,
- commit precondition,
- committed version,
- receipt/history.

## What the shell should make obvious

### 1. My base is not current truth
A current pane should be able to render:
- `based on ETag ...`
- `based on generation ...`
- `based on rev ...`
- `basis unknown`

That is excellent honesty chrome, but it still is not current write authority.

### 2. A private draft is not a shared hold
A shell should be able to say:
- `private draft`
- `temp copy`
- `sealed draft`
- `draft diverged`
- `receipt only`

That keeps multi-tab and multi-tool editing from getting spooky.

### 3. Hold state is its own lane
If a coordination hold exists, a pane should say:
- `exclusive`
- `advisory`
- `renewable`
- `expired`
- `uncertain`
- `none`

That should not be mistaken for `base still matches`.

### 4. Commit mode should be explicit
A shell should distinguish:
- `commit if base still matches`
- `create if absent`
- `commit under hold`
- `rebase first`
- `fork instead`
- `stay draft`

That is much better than one magical save button.

### 5. The committed winner should be visible
After a write, the shell should say:
- `committed as generation ...`
- `commit rejected, current head is ...`
- `commit already reflected`
- `receipt only`

That keeps local close/flush folklore from replacing durable truth.

## Super-awesome product moves

### Stale-base lamps
Every editable pane should have a compact lamp that can show:
- current basis id,
- whether the remote/head moved,
- whether compare-before-commit is still possible,
- and whether the row is history only.

### Draft gutters
A transcript/editor gutter should render draft state such as:
- `draft`
- `sealed`
- `dirty`
- `rebased`
- `orphaned`
- `history only`

with one-step actions like `rebase`, `compare`, `fork`, or `open receipt`.

### Commit shutters
Before a commit, the shell should make the exact mode explicit:
- `if-match this base`
- `if-absent`
- `under hold token`
- `unsafe overwrite disabled`

That turns concurrency safety into visible product design instead of backend folklore.

### Hold meters
If a hold exists, render:
- issuer/provider,
- hold kind,
- remaining time when known,
- whether it is advisory or required,
- and whether the current commit path actually depends on it.

### Winner receipts
Successful and failed writes should both leave structured rows that say:
- old basis,
- commit predicate,
- hold dependency if any,
- winning committed version,
- next actions (`refresh`, `rebase`, `fork`, `reopen draft`).

## Guardrails

- observed validators must not masquerade as current write authority;
- draft-local success must not masquerade as committed durable truth;
- holds must not masquerade as exact commit predicates;
- old receipts must not silently reopen drafts or revive holds.
