# Lend-once drawers, borrow badges, and recall rails

Purpose: make the ViewFS shell feel **super awesome** by turning temporary authority sharing into a visible, high-bandwidth interaction instead of a hidden ambient side effect.

## North star
A great ViewFS shell should let a user read these states at a glance:
- **requested** — someone or something asked to borrow authority
- **borrowed** — live attenuated authority is active *now*
- **expiring** — the borrow is still live but nearing its end condition
- **recalled** — the issuer ended it
- **relinquished** — the borrower gave it back cleanly
- **durable ref only** — reopen later may be possible, but there is no live authority right now
- **basis drift** — prior approval or watched inputs changed; renewal/re-approval is needed

This is a better shell story than pretending every successful open/run/share automatically created standing access forever.

## Best ideas worth stealing
- **REF-SEL4-CSPACE**: attenuated descendants plus explicit revoke lineage is a wonderful conceptual model for borrowed authority.
- **REF-XDG-DOCUMENTS**: session-only versus persistent entries, plus separate grant/revoke/delete methods, are exactly the kind of class honesty we want.
- **REF-APPLE-SECBOOKMARK**, **REF-APPLE-SECWITHSCOPE**, and **REF-APPLE-SECSTART**: durable bookmark, started live access, and relinquish are different moments.
- **REF-DENO-PERMISSIONS**: explicit prompt/deny states make permission posture legible.
- **REF-DIRENV-REQUIREALLOWED**: changed watched inputs should force re-authorization instead of silently broadening an old blessing.
- **REF-WEZTERM-SHELL-INT** and **REF-ITERM-SHELLINT**: semantic prompt/block metadata and command-history awareness give the terminal enough structure to display loan state beautifully.
- **REF-WARP-BLOCKS** and **REF-WARP-WORKFLOWS**: blocks/workflows/notebooks can surface contextual next steps without flattening them into hidden privilege.

## Lend should be a first-class shell verb
The shell should make these moves feel normal:
- `lend for this run`
- `lend until pane closes`
- `lend until child exits`
- `lend read only`
- `lend stripped`
- `promote to durable reopen`
- `recall now`
- `renew with review`

Those verbs are much more truthful than “open” or “share” when the real act is temporary borrowed authority.

## Borrow badges belong in the prompt chrome
A pane header, gutter, or prompt-adjacent HUD should be able to show:
- how many borrowed things are live,
- whether any are expiring soon,
- whether they are re-delegable,
- whether any came from a high-risk trust source,
- and whether a durable reopen ref exists after the loan ends.

The shell should not force users to infer this from random later errors.

## Lend-once drawers could be incredible
Imagine pressing one key on a route-plan card and getting a **lend drawer**:
- lender object(s)
- borrower target (pane, child process, notebook cell, workflow run)
- attenuation summary
- expiry rule
- whether promotion to durable is even allowed
- what the recall surface looks like
- and what receipt survives

That is the right place to be smart.

## Recall rails should be visible and calm
When the issuer can still end a loan, the shell should show it explicitly:
- a quiet recall pill while things are healthy,
- a louder expiring-soon badge near the end,
- and a crisp end-state receipt afterward.

The goal is not panic. The goal is that the shell never lies.

## Renew and promote should be different moves
The shell should distinguish:
- **renew** — keep the same temporary class a bit longer under fresh review
- **promote** — create or refresh a more durable reopen/delegation artifact

That avoids a common UI failure where “keep working” silently mutates into “standing authority forever”.

## Great terminal-native moves
- **Borrow gutter**: one slim lane listing active borrowed items for the current pane with time/condition badges.
- **Expiry rails**: soft timeline markers showing which borrowed items end on pane-close, child-exit, or timer.
- **Recall broadcast cards**: when a loan ends, emit a compact result card explaining *why*.
- **Promote-from-borrow diff**: before persistence, show exactly what class upgrade would happen.
- **Borrow-aware replay**: replay can ask whether to re-borrow, promote first, or run receipt-only.
- **Per-block loan legends**: command blocks can advertise `borrowed`, `durable-ref-only`, or `receipt-only` rather than one vague “linked file”.

## Structured shell values worth exploring
A structured shell could let commands emit values such as:
- `loan_request`
- `borrowed_handle_set`
- `delegated_ref`
- `recall_control`
- `loan_end_receipt`

That would make it much easier for notebooks, route sheets, and inspectors to stay truthful.

## A tiny honest prototype would already be great
The first prototype does not need a giant delegation system.
It would already be great to ship:
- one `lend for this run` flow,
- one visible borrowed-authority badge in the pane chrome,
- one expiry/recall indicator,
- one `promote to durable reopen` path,
- and one end-of-loan receipt that clearly says what happened.

If that feels good, the shell will have found a real superpower rather than a fancier permission dialog.
