# Shipping lanes, boundary previews, and promised outputs

Purpose: make ViewFS shell and terminal workflows around import/export/drag/share feel **truthful and delightful** instead of like one blurry “copy file” command.

## North star
The shell should make it obvious which lane the user is in:
- **import** — bring bytes/objects into the current world
- **open in place** — use a granted source object directly
- **save/export** — choose a destination and write there
- **move/rehome** — change where the logical object lives
- **transfer** — publish or retrieve a bounded offer
- **share/delegate** — route to another handler or recipient
- **promise** — say “I can materialize this artifact later if you actually take it”

That vocabulary is much more powerful than a generic `cp`-shaped UI if the shell renders it well.

## Best ideas worth stealing
- **REF-APPLE-DOCPICKER-OPS**: import/export/open/move deserve explicit verbs.
- **REF-XDG-FILETRANSFER**: transfer is session-shaped and retrieval-shaped, not ambient clipboard omniscience.
- **REF-WIN-SHELL-DATASCENARIOS**: move/delete-on-paste outcome needs explicit reporting back to the source.
- **REF-APPLE-FILEPROMISES**: delayed materialization can make drag/drop fast and elegant.
- **REF-WAYLAND-PRIMARY-SELECTION** and **REF-X11-ICCCM-SELECTIONS**: a current clipboard/selection owner, the offered representations, and the accepted transfer are separate truths.
- **REF-KITTY-CLIPBOARD**: clipboard access can be typed, permission-gated, and inspectable without collapsing into raw paste folklore.
- **REF-ANDROID-CREATE-DOCUMENT**: create/save-as deserves clear destination semantics and should not silently mean overwrite-in-place.

## Boundary preview line
Before a cross-boundary action commits, the shell should show a compact one-line preview such as:
- `import → fresh local object`
- `open → scoped live handle`
- `save as → create destination grant`
- `transfer → one-shot offer, pull by sink`
- `move → rehome if sink confirms`
- `promise → bytes not materialized yet`

That one line would do a lot of work.

## Shipping lanes as first-class blocks
Command blocks should be able to expose their outputs as lanes:
- **Inspect lane** — peek only
- **Import lane** — mint fresh local object
- **Transfer lane** — publish an offer for drag/drop/paste/share
- **Promise lane** — declare a lazily materialized output
- **Export lane** — choose a destination and write

A single command could expose several lanes at once, but the shell must keep them labeled.

## Promised outputs are especially cool
Promised outputs could make the terminal feel unusually modern:
- a heavy report generation command can expose a promise immediately,
- dragging it to another tool only materializes bytes if the sink actually accepts,
- a notebook/workflow can carry a **promise card** rather than a giant blob,
- and the shell can later show whether the promise was fulfilled, expired, or never claimed.

This is one of the best "steal it" ideas available right now.

## Move outcome cards
A drag/drop or cut/paste flow should not leave the user guessing.
After completion, the shell should attach a small outcome card:
- `copied`
- `moved`
- `optimized move`
- `delete on paste succeeded`
- `delivery failed; source kept`

That makes history much easier to trust.

## Great UX moves worth prototyping
- **Space to preview boundary**: one key reveals whether an action copies, delegates, moves, or only promises.
- **Promise badges**: `promised`, `materialized`, `expired`, `never claimed`.
- **Export-plan cards**: chosen destination, create/replace mode, and whether the lane was one-shot.
- **Transfer trays**: a shelf of active offers with TTL, receiver, and writability badges.
- **Clipboard offer cards**: owner/source witness, offered MIME types, accepted representation, and whether bytes became prompt input or a local import.
- **Promote transfer to import**: explicit follow-on action from a transfer receipt.
- **Safe paste / import**: paste as receipt, paste as import, or paste as live bind when applicable.
- **What crosses the boundary?** inspector: bytes, handle, route, promise, or receipt only.

## Nice command-language ideas
The exact syntax can wait, but commands should probably feel class-aware:
- `import <receipt-or-promise>`
- `export <object>`
- `transfer <object>`
- `share <object>`
- `move <object> --to <dest>`
- `materialize <promise>`

The trick is that these should point at typed objects and receipts, not just paths.

## Anti-goals
- one generic `open` or `copy` action that hides which lane is being used
- transfer history that silently becomes durable import authority
- promised files that count as delivered before any sink retrieves them
- save/export UI that quietly widens into broad directory mutation rights
- notebook cards that hide whether they contain bytes, a handle, a receipt, or only a promise


## Clipboard and selection should stay as their own lane
A custom shell can be much better than normal terminals here.
It should be able to show:
- `selection owner/source changed`,
- `offer advertises text/plain + text/uri-list`,
- `accepted representation: text/uri-list`,
- `pasted into prompt`,
- `imported as local object`,
- or `history-only / manager-retained`

as different outcomes rather than one blurry “paste happened” event.

That gives the user a clean ladder:
- paste into prompt,
- paste into scratch capsule,
- inspect offered MIME types,
- import as fresh object,
- bind here,
- or receipt only.
