# Published-name ledgers and synthetic-view badges

Purpose: make the future custom shell+terminal brutally honest about the difference between **stored object**, **portal/provider projection**, **live handle**, **current published name**, and **history**.

A lot of confusing file UX comes from showing one path label and letting the user infer everything else.
ViewFS can do better.

## The shell should answer different questions directly
For any object-ish thing the shell should be able to answer, separately:
- does it exist in the local object store?
- is it only reachable through a restricted synthetic/portal/provider view?
- do I hold a live handle right now?
- is it published in this pane/process namespace right now?
- is this only history/receipt?

Those answers should not be squeezed into one path chip.

## Moves worth stealing

### Published-name ledgers
Each object card should be able to open a small ledger showing:
- `published here at /work/current/report`
- `published to child kit at /input/report`
- `reachable via portal view`
- `stored only`
- `receipt only`

This is much more honest than pretending the last visible path is the object's identity.

### Synthetic-view badges
A small badge row can tell the truth without much UI weight:
- `portal view`
- `provider projection`
- `published here`
- `launch-only`
- `live handle`
- `stored only`
- `history only`

The important move is not the exact labels.
The important move is that projection/locality/publication remain visibly separate.

### Publish-here ladders
After a portal/import selection, the default should often be a staging tray rather than an automatic bind.
The ladder should make these different acts visible:
- `inspect`
- `materialize local object`
- `keep as portal projection`
- `publish in this pane`
- `publish to child launch`
- `receipt only`

### Same-object multi-view diffs
When two panes or a pane and a child kit talk about “the same thing,” the shell should be able to compare:
- same object ref / unknown
- same current publication site / different
- same live handle / duplicate / no
- same synthetic source view / different

That is far better than arguing over strings that happen to look similar.

### Outgoing publication cards
If a pane publishes something to a child or peer, the shell should show:
- the source object or view,
- the destination publication site,
- any narrowing done on the way,
- and whether the result is only launch-time, live now, or receipt only.

## Delightful chrome ideas
- **Name ledgers** that expand inline from an object card.
- **Projection shutters** that say `portal projection only` or `provider-local view` before the user assumes the object is native.
- **Publish-here last buttons** so imports stop auto-attaching just because the user chose something.
- **Where-is-it-really drawers** that separate object ref, store presence, current publication sites, and current live-handle truth.
- **Sibling-view badges** that show one object published in several panes without pretending those panes share all authority.

## What this avoids
- paths masquerading as object identity;
- portal/provider projections masquerading as native publication;
- local publication masquerading as durable reopen;
- receipts masquerading as current access;
- and shell convenience quietly reintroducing ambient authority folklore.
