# Attach-mode badges, adapter veils, and virtuality lamps

One of the nicest receiver-side shell moves available to ViewFS is to stop pretending that every successful open/import/use path has the same fidelity.
This note collects shell/terminal ideas for the seam between **native attach**, **adapted attach**, **coerced representation**, **local realization**, and **history only**.

## 1. Attach-mode badges instead of one fake open verb

For any object card, action row, or suggested intake, the shell should be able to render a compact badge like:
- `native`
- `adapter`
- `relay`
- `coerced`
- `preview only`
- `make local for native`
- `localized`
- `receipt only`
- `history only`

The winning badge should be visible before the user commits.
That turns one vague `open` click into an honest fit/fidelity choice.

## 2. Adapter veils

If a wrapper or relay is in the path, the shell should say so.
Useful chrome includes:
- `fd-wrapper`
- `runtime adapter`
- `relay service`
- `projected fuse view`
- `compat bridge`

These veils should explain why the current pane/tool needs glue and what stronger/native path would require.

## 3. Virtuality lamps

When the current best lane is one alternate representation rather than same-object attach, the shell should say so.
Useful lamps include:
- `virtual / alternate MIME`
- `preview representation`
- `export representation`
- `same object unavailable`
- `localize for native`

This is exactly the kind of honesty that almost no mainstream shell/desktop UI provides today.

## 4. Same-object versus translated drawers

Before a user edits, sends, drags, or exports something, the shell should be able to explain:
- `same object, native lane`
- `same object, adapted lane`
- `translated representation`
- `preview only`
- `local copy after commit`

That gives the user a real mental model instead of one flattering path string.

## 5. Make-local-for-native ladders

If stronger fidelity or offline/native semantics are desired, the shell should not silently copy.
It should let the user choose:
- `keep native if possible`
- `keep adapted`
- `use translated representation`
- `make local for native`
- `make local object`

## 6. Super-awesome terminal moves worth stealing

- **attach-mode pills** attached to command blocks so each block can say `native`, `adapter`, `coerced`, `localized`, or `history only`.
- **adapter veils** in the gutter when a block only succeeded through one relay or runtime shim.
- **virtuality lamps** for selections or paths that are previewable but not directly stream-openable.
- **same-object drawers** that compare direct attach against translated representation before export or handoff.
- **make-local sidecars** so the user can explicitly upgrade fidelity/locality after inspection.

References: REF-ANDROID-VIRTUALFILES, REF-ANDROID-SAF, REF-WIT-RESOURCE-HANDLES, REF-XDG-DOCUMENTS, REF-XDG-DOCS-FUSE, REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-COMPONENT-NSENTRY.
