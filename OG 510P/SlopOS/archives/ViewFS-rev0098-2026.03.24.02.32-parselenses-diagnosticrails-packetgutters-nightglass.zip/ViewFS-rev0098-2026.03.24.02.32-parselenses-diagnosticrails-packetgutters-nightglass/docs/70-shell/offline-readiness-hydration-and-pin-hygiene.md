# Offline readiness, hydration plans, and pin hygiene

Purpose: make ViewFS shell and terminal workflows around warm-up, offline use, and retention **truthful and delightful** instead of like one blurry “download/cache” spinner.

## North star
The shell should make it obvious which state an object or workflow is in:
- **hint-only** — we think you may want it soon
- **warming** — prefetch/caching is underway
- **cached** — useful bytes are present, but discardable
- **hydrated** — exact local bytes/closure needed by this workflow are present
- **pinned** — retention policy changed; GC/cleanup will not drop it casually
- **mirrored** — bounded corpus/repo copy exists elsewhere
- **offline-bundled** — a self-contained transport artifact exists
- **stale / rehydrate needed** — local warm state no longer matches what this workflow expects

That vocabulary is much more honest than a generic “available offline” badge.

## Best ideas worth stealing
- **REF-IPFS-PERSISTENCE**: pinning is specifically about retention versus garbage collection.
- **REF-NIX-PREFETCH-FILE** and **REF-NIX-REALISE**: fetch/warm and exact realization are separate acts.
- **REF-NIX-COPY**: closure-copy is a deliberate transport step, not a side effect of use.
- **REF-OSTREE-REPO-MGMT** and **REF-OSTREE-STATIC-DELTAS**: mirrors and self-contained deltas are explicit distribution tools.
- **REF-MDNPREFETCH** and **REF-SVCWORKER-SPEC**: speculative prefetch is a lower-priority hint path with cache/update semantics.
- **REF-MS-ALWAYSOFFLINE**: offline mode can be a useful UX, but it should still be explicit about what is cached locally.

## Hydration plans should be first-class
Before a command or workflow pulls in a lot of data, the shell should be able to show a compact hydration plan:
- what object/closure will be fetched,
- estimated bytes,
- whether this is `hint`, `cache`, `hydrate`, or `pin`,
- whether network is expected,
- and whether the result will be reusable across future runs.

That turns opaque warm-up into something users can reason about.

## Offline readiness cards
Every important block/output/workspace should be able to answer:
- Can this run with no more fetches?
- Are all required closures already hydrated?
- Is some content only cached and therefore discardable?
- Is there a self-contained offline bundle if I need to move this elsewhere?

A tiny card that says `offline-ready`, `needs hydrate`, `bundle available`, or `network required` would go a long way.

## Pin hygiene matters
Pins are powerful, but they can also quietly bloat stores.
The shell should expose why something is retained:
- manual pin,
- workspace root,
- mirror policy,
- retained bundle,
- or active deployment/publication pin.

That makes cleanup and GC much less mysterious.

## Great UX moves worth prototyping
- **Hydration preview line**: `hydrate → 248 MiB closure, no pin` or `prefetch → low priority cache hint`.
- **Warm-up trays**: active background warming jobs with clear states (`warming`, `paused`, `ready`, `evicted`, `failed`).
- **Offline readiness badges** on command blocks, notebooks, workspaces, and bundles.
- **Pin explain**: one key to reveal every root keeping an object/closure live.
- **Bundle lane**: a deliberate “make transportable offline artifact” action instead of overloading cache state.
- **Rehydrate cards**: when state is stale, show the delta between local warm state and expected closure.

## Nice command-language ideas
The exact syntax can wait, but commands should probably feel class-aware:
- `prefetch <object-or-closure>`
- `hydrate <object-or-closure>`
- `pin <object-or-closure>`
- `mirror <set-or-repo>`
- `bundle <object-or-closure>`
- `why-live <object-or-closure>`
- `offline-status <workflow>`

The key is that these should point at typed objects, manifests, receipts, or closures, not only paths.

## Anti-goals
- one generic cache spinner that hides whether bytes are hinted, cached, hydrated, pinned, or mirrored
- treating “available offline” as proof of durable authority or workspace trust
- pretending a cache hit is the same as a retention promise
- using mirror state as if it implied publication, blessing, or activation
- hiding why large objects remain live in the store
