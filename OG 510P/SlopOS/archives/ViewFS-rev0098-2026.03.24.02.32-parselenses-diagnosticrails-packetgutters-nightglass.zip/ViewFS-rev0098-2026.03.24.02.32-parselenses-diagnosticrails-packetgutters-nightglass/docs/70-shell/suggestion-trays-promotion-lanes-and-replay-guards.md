# Suggestion trays, promotion lanes, and replay guards

Purpose: make the ViewFS shell feel **super awesome** by letting great ideas flow in from workspaces, receipts, and notebooks without letting any of them silently become trusted personal automation.

## North star
A great ViewFS shell should let a user move through these readable states:
- **suggested** — this came from a workspace, shared notebook, receipt, or route rule
- **promoted** — I deliberately copied/adopted it into my own workflow space
- **prepared** — here is the exact current-state run plan
- **approved** — the exact risky delta was reviewed
- **ran** — one historical execution happened
- **receipt/history** — what survives is evidence, not standing authority

That sounds obvious, but many tools blur at least three of those together.

## Best ideas worth stealing
- **REF-WARP-WORKFLOWS** and **REF-WARP-NOTEBOOKS**: searchable reusable workflows and executable notebook-style docs are the right interaction shape.
- **REF-VSCODE-TASKS**: workspace tasks and user tasks should not look like one undifferentiated command pool.
- **REF-VSCODE-WORKSPACE-TRUST**: restricted mode is productive, so suggestion surfaces can stay useful before trust.
- **REF-DIRENV-ALLOW** and **REF-DIRENV-REQUIREALLOWED**: explicit allow plus re-allow-on-change is the right emotional model for source drift.
- **REF-WEZTERM-SHELL-INT**, **REF-ITERM-SHELLINT**, and **REF-WARP-BLOCKS**: semantic blocks, command history, and current-directory metadata make suggestion provenance and replay state visible.
- **REF-PLAN9-PLUMB**: typed routing means a block or receipt can suggest a next action without pretending it already is that action.

## Suggestion trays should exist before adoption
A workspace card, notebook cell, receipt card, or palette row should be able to open a **suggestion tray** showing:
- source (`workspace`, `shared notebook`, `receipt`, `route rule`, `user`),
- suggested verb and object class,
- whether it is blocked by trust or portal state,
- whether it contains ambient debt,
- whether it has changed since last inspection,
- and what happens if you `promote`, `prepare`, `run once`, or `keep as note`.

This should feel as normal as opening completions.

## Promote should be a first-class shell action
The shell should distinguish:
- `inspect suggestion`
- `promote to mine`
- `promote stripped`
- `prepare from source`
- `run once with receipt`
- `copy as note only`

That lets users keep good ideas without silently inheriting the source’s authority story.

## Recipe provenance should stay visible
A promoted workflow row should keep badges such as:
- `source: workspace` / `source: receipt` / `source: notebook`
- `owner: user`
- `state: changed-upstream` / `reinspect` / `ready` / `blocked`
- `trust: none` / `workspace-blocked` / `portal-needed` / `user-owned`

The shell should never imply that a promoted workflow is still the same class as its source.

## Drift should produce re-promotion and reinspection, not silent mutation
When watched source files or upstream notebook content change, the shell should show:
- what changed,
- whether the promoted copy diverged,
- whether the last successful run relied on older source material,
- and whether the next step is `reinspect`, `re-promote`, or `prepare fresh`.

That is much safer than “helpfully” mutating the user workflow behind their back.

## Notebook cells should advertise their class honestly
A notebook cell or block should be able to say:
- `suggested`
- `promoted`
- `prepared`
- `blocked`
- `ready`
- `receipt only`
- `changed upstream`

This keeps notebooks playable and shareable without turning them into disguised grant bags.

## Great custom-terminal moves
- **Suggestion lane beside the prompt**: a chip showing whether the current object under focus is only a suggestion, already promoted, or ready for prepare/run.
- **Promote diff drawer**: open a diff that shows what will be copied, stripped, or narrowed when promoting a suggestion into a user workflow.
- **Source-drift pips**: small badges in the gutter when a workflow’s upstream source changed since promotion or last run.
- **Result-to-workflow fork**: turn one successful run into a new user workflow without rewriting the source suggestion.
- **Notebook lane switcher**: convert a block between `note`, `suggestion`, `user workflow`, and `receipt link` deliberately.
- **Replay guards**: replay from the saved recipe with fresh planning, replay from the last result as note-only, replay stripped, or replay after explicit re-promotion.

## Structured shell values worth exploring
A structured shell could let commands emit values such as:
- `suggested_recipe`
- `promotion_receipt`
- `user_workflow`
- `prepared_run_plan`
- `run_record`
- `run_receipt`

That would let notebooks, palettes, and pipelines stay much more truthful than flattening everything into command strings.

## A tiny honest prototype would already be great
The first prototype does not need sync, teams, or a giant workflow library.
It would already be great to ship:
- one suggestion tray,
- one explicit `promote to mine` path,
- one source-drift badge,
- one prepare-from-promoted-workflow action,
- and one replay guard that insists on fresh planning.

If that feels good, the shell will have found a real advantage instead of just saving commands prettily.
