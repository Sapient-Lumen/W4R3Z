# Hole maps, range panels, and whole-proof ladders

A future custom shell/terminal should become great at telling the truth about **partial local bytes** without pretending every object is either simply `downloaded` or `not downloaded`.

## The seam to preserve
Keep these visibly separate:
- **coverage** — which ranges/chunks are local now
- **layout** — how the object is partitioned
- **completeness** — whether the whole object is present
- **whole proof** — whether one exact whole-object witness exists
- **live range fill** — whether missing bytes can be fetched now
- **history** — what used to be true

## Why this is exciting
A capability-oriented shell can make large objects, lazy imports, and partial hydration feel honest and powerful instead of spooky.
The transcript should be able to say:
- `sparse local`
- `prefix only`
- `all chunks local, whole proof missing`
- `network-backed lazy fill`
- `fully local + verified`
- `history only`

That is much better than one vague `downloaded` light.

## Moves worth stealing

### 1. Hole maps
A compact coverage visualization for one object/pane/card.
Examples:
- contiguous byte bars,
- chunk tiles,
- shard rings,
- or file-level coverage chips for bundle-like objects.

The important bit is honesty, not one rendering style.

### 2. Range panels
One trusted drawer should keep:
- object identity,
- current coverage,
- known layout,
- whole-proof state,
- live range-fill reachability,
- and recent receipts.

That gives the user one place to answer “what exactly do I have?”

### 3. Whole-proof ladders
Do not overload one `hydrate` or `verify` action.
Keep these acts distinct:
- `fetch missing ranges`
- `fill all named chunks`
- `verify whole object`
- `seal local copy`
- `stay sparse`
- `open receipt`

### 4. Offline honesty lamps
A small lamp should tell the user whether the current object/workflow is:
- `fully local`
- `partial local`
- `works with remote fill`
- `proof missing`
- `history only`

That will matter a lot for travel, spotty networks, and scripts.

### 5. Composite-checksum warnings
If the best current identifier is multipart/composite/per-part, the shell should say so explicitly.
`identifier present` should not silently mean `whole object proven`.

## Awesome transcript ideas
- **coverage chips**: `prefix`, `holes`, `all chunks`, `full local`, `unknown`
- **proof chips**: `composite`, `whole proof`, `proof missing`, `stale receipt`
- **remote-fill chips**: `reachable now`, `requires portal`, `unreachable`, `history only`
- **repair ladders**: `continue sparse`, `fill to full`, `verify`, `pin`, `seal export`, `open receipt`

## Guardrails
- sparse coverage should never impersonate full hydration,
- layout metadata should never impersonate current local bytes,
- whole proof should stay stronger than composite/per-part identifiers,
- and history should never impersonate current reachability or current coverage.
