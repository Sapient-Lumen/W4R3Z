# Task badges, progress lanes, and result lockers

This note collects shell/terminal ideas for deferred work that stays truthful.

The key seam:
**immediate request ≠ accepted task wrapper ≠ live status/progress stream ≠ input-required checkpoint ≠ deferred final result retrieval ≠ durable receipt/history**.

If those collapse, the shell will lie in exactly the wrong way:
- a task badge will feel like a result,
- a progress bar will feel like durable success,
- an input-needed pause will look like mysterious flakiness,
- background permission will feel like perpetual job ownership,
- and an old result receipt will feel like the request is still live now.

## Shell moves worth stealing

### 1. Task badge
A helper-aware pane should be able to show a **task badge**:
- `submitted`, `working`, `input-needed`, `completed`, `failed`, `cancelled`, `expired`
- source helper or subsystem
- whether we only have acceptance metadata or a retrievable final result
- whether the task is foregrounded in the pane or only a background session neighbor

### 2. Progress lane
A **progress lane** should stay clearly advisory:
- current status line
- bounded progress when available
- last update time
- whether the lane is still live or only the last known state
- whether the lane is for one direct request or a longer background session

### 3. Input-required drawer
An **input-required drawer** should be a proud first-class state, not an accidental error modal.
The drawer should show:
- which task/request is waiting,
- what extra input or approval is needed,
- what remains queued behind it,
- what happens if the user declines, cancels, or delays.

### 4. Result locker
The shell should have a **result locker** distinct from badges and progress:
- final outputs or terminal errors only after completion,
- whether the result is still retrievable or expired,
- whether the result has already been replayed, promoted, or archived,
- whether the locker contains only the final result or also the acceptance/progress lineage.

### 5. Queue rail
A **queue rail** should make follow-up steering honest:
- current running request,
- queued next actions,
- whether queued acts depend on the current task finishing,
- whether a queued act would need a fresh rebind or reconsent before it can start.

### 6. Task receipt
Receipts should preserve deferred-work truth:
- `task accepted only`,
- `progress observed`,
- `input requested`,
- `input supplied`,
- `task cancelled`,
- `task failed`,
- `final result retrieved`,
- `result expired/history only`.

## Why this could make the terminal super awesome
A terminal that can tell the difference between pending work, progress, input-needed checkpoints, and final results becomes dramatically more powerful:
- long-running helper work can feel native without pretending every request is a blocking function call,
- follow-up steering can be safe without dissolving into ambiguous scrollback,
- background sessions can stay visible without becoming hidden standing authority,
- result retrieval can be explicit and replayable without confusing “the task exists” with “the result is here.”

## Guardrails
- acceptance must not imply final result availability,
- progress lanes must remain advisory and live, not durable success,
- input-needed checkpoints must not silently widen authority or auto-answer themselves,
- background permission must not masquerade as live task ownership,
- result lockers must not make old receipts look like still-running requests,
- durable receipts must preserve whether we stopped at acceptance, watched progress, supplied more input, or actually retrieved the final result.
