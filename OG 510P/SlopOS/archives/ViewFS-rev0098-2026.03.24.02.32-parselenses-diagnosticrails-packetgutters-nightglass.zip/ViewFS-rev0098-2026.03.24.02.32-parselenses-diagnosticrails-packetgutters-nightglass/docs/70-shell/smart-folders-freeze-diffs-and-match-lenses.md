# Smart folders, freeze/thaw, and match lenses

Purpose: collect shell/terminal moves that make ViewFS query UX feel magical **without lying** about whether the user is looking at a saved recipe, a frozen snapshot, or a live feed.

## North star
The ViewFS shell should make “smart folders” feel first-class, but a smart folder should still tell the truth about whether it is:
- a saved query manifest,
- a just-ran snapshot,
- a live updating feed,
- or only a pinned selector/query row.

That honesty makes the shell better, not worse.

## Best ideas worth stealing
- **REF-APPLE-SMARTFOLDERS**: saved search criteria can feel like ordinary folders in the sidebar.
- **REF-APPLE-NSMETADATAQUERY**: result gathering and live updates are distinct modes; pausing updates while inspecting results is a great idea.
- **REF-WIN-SEARCH-MS**: a saved-search file can be a plain manifest/recipe object.
- **REF-GNOME-TRACKER**: shared search surfaces are very powerful, but also a warning sign if indexing scope becomes ambient or mysterious.
- **REF-GNOME-LOCALSEARCH**: indexing policy and extraction roots should be inspectable.

## Smart-folder truth badges
Every smart-folder-like surface should expose:
- **kind** — `query`, `snapshot`, `live feed`, `pin`
- **scope** — `bound view`, `workspace`, `local shell registry`, `host debt`
- **health** — `ready`, `paused`, `overflowed`, `rebuild required`, `index unavailable`, `stale`
- **freshness** — `ran 2m ago`, `live`, `frozen since 14:22`

That is far better than one ambiguous folder icon.

## Freeze / thaw is a feature, not a debug mode
One of the nicest ideas to steal from Apple’s metadata query story is explicit pause/resume while results are being inspected.

ViewFS shell should treat these as first-class actions:
- **freeze** — stop applying live deltas to the visible result set,
- **thaw** — resume live updates,
- **re-run** — produce a new fresh snapshot,
- **diff** — compare current snapshot against previous run or previous freeze,
- **promote** — pin the current snapshot into a journal/notebook card.

This is especially good for terminals because users hate list UIs that shift under their cursor.

## Match lenses
A selected result should have a quick lens showing:
- which attributes or clauses matched,
- whether the match came from declared metadata or content-derived extraction,
- whether the matching metadata is safe to preview,
- whether the object is live, rebind-needed, or receipt-only.

“Why did this match?” should be a one-keystroke answer.

## Delightful moves worth prototyping
- **Smart-folder sidebar pins** that can be either query manifests or pinned snapshots, with different badges.
- **Result diff cards** showing `entered`, `left`, and `still matching` since the last run/freeze.
- **Scoped live panes** where one pane shows live query updates and another shows a frozen inspectable snapshot.
- **Query-to-journal promotion** so a run becomes a durable receipt card with digest, view, count, and diff link.
- **Match-lens hover** for palette rows or table cells.
- **Re-run with same query in a different view** as an explicit comparison action.
- **Index debt badges** when a smart folder depends on host-side or not-yet-native indexing.
- **Authority-aware actions per result** like `inspect`, `rebind`, `peek`, `route`, `show match lens`, instead of a generic `open`.

## Query-workflow ideas
A user should be able to:
- run a query once and keep the snapshot,
- turn that query into a pinned smart folder,
- later thaw it into a live feed,
- then freeze again before comparing or sharing.

Those should feel like natural shell verbs, not like backend implementation details.

## Anti-goals
- a smart folder that silently switches between recipe, snapshot, and feed states
- result panes that reorder or mutate while the user is selecting items without an obvious live badge
- palette rows that cannot explain why they matched
- sharing a query notebook card that unintentionally serializes live authority
