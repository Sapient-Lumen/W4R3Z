# Follow tails, attach rails, and control panes

This note collects shell/terminal ideas for live-session ergonomics that stay truthful.

The key seam:
**read-only observe/query/follow lane ≠ interactive attach lane ≠ control-message lane ≠ injected exec/debug lane ≠ sideband tunnel/forward lane ≠ durable transcript/history**.

If those collapse, the shell will lie in exactly the wrong way:
- `watch` will quietly imply control,
- `attach` will hide whether stdin is live,
- `send` will hide whether the action was only a signal or a full mutation,
- `debug` will look like the original session,
- `tunnel` will look like object authority,
- and old transcripts will look like still-live sessions.

## Shell moves worth stealing

### 1. Follow tails
A helper-aware pane should offer explicit **follow tails** for:
- logs/output follow,
- read-only live status query,
- tail-since / tail-window views,
- watch-only observer mode.

The chrome should say whether the lane is output-only, query-only, or an advisory status stream.

### 2. Attach rail
An **attach rail** should separate:
- `observe only`,
- `interactive attach`,
- `attach with tty`,
- `read-only attach`,
- `detach and keep session running`.

The rail should explain whether stdin is live, whether the lane is shared with others, and whether attach is current or merely armed.

### 2b. Foreground baton pill
A pane that can really talk to a live job should advertise one more truth:
- whether this job currently owns the foreground turn,
- whether terminal-generated signals will go to it now,
- whether it merely has visible output,
- and whether a controlling TTY relationship exists at all.

That makes `observe`, `interactive`, `controlling tty`, and `foreground now` visibly different states instead of one vague attached badge.

### 3. Control pane
A **control pane** should be distinct from logs and shells:
- typed signal/control messages,
- synchronous update calls,
- query replies,
- explicit acknowledgements and failures,
- no pretending that these are ordinary command transcripts.

### 4. Debug launch drawer
A **debug launch drawer** should show when the user is about to:
- inject a new command,
- spawn a debug shell,
- add extra rights or tools,
- or branch into a temporary diagnostic lane.

It should stay louder than observe or attach.

### 5. Sideband badge
A **sideband badge** should advertise:
- forwarded port/proxy/tunnel kind,
- who owns the far side,
- whether it is local-only or externally reachable,
- whether the tunnel died because the source session died,
- and whether transcript history remains after the sideband closes.

### 6. Live-session receipt
Receipts should preserve live-session truth:
- `observed only`
- `followed output`
- `attached read-only`
- `attached interactive`
- `sent control message`
- `performed synchronous update`
- `spawned debug exec`
- `opened sideband tunnel`
- `detached`
- `history only`

## Why this could make the terminal super awesome
A terminal that can tell the difference between observe, attach, control, debug exec, and sideband access becomes dramatically more useful:
- remote/helper/live work can be inspected safely before control is granted,
- control actions can be rendered honestly without hiding inside log panes,
- debug launches can feel powerful without pretending they are the original session,
- tunnels and forwarded access can be visible and temporary instead of ambient,
- transcript history can stay useful without masquerading as still-live control.

## Guardrails
- follow/query panes should not masquerade as interactive attach,
- read-only attach should not silently gain stdin or control,
- control messages should not masquerade as plain transcript text,
- debug exec should not masquerade as the pre-existing run,
- sideband tunnels should not masquerade as object authority or durable grants,
- history should not masquerade as a live connection.
