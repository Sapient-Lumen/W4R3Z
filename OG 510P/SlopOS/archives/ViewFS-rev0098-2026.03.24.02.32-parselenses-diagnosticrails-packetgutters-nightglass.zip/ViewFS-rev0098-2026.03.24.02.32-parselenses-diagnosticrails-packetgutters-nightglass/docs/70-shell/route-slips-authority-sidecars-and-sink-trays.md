# Route slips, authority sidecars, and sink trays

One of the nicest shell moves available to ViewFS is to stop pretending every click, paste, share, open-with, and import action is the same thing.
This note collects shell/terminal ideas for the seam between **route capsule**, **authority sidecar**, **sink-side acceptance**, and **history only**.

## 1. Route slips

A route slip is the shell-visible version of a typed plumb/intent envelope.
It should be:
- cheap to inspect,
- easy to copy into notes or transcripts,
- diffable before commit,
- and explicitly labeled `designation only` when no current authority is attached.

A route slip should answer:
- what subject is in play,
- which verb is being proposed,
- which sink is targeted,
- and what the shell still does **not** know.

## 2. Authority sidecar chips

If a route is accompanied by useful adjunct material, the shell should show it as explicit sidecars such as:
- `wallet digest`
- `uri grant candidate`
- `portal request`
- `representation offers`
- `proof required`
- `fit note`
- `scope narrowed`

These should be drawers/chips, not invisible helper lore.

## 3. Sink trays instead of one flattering outcome verb

After a route lands, the receiving pane/process should be able to show one sink tray row like:
- `accepted text/plain`
- `accepted image/png`
- `accepted projected view`
- `accepted live bind`
- `localized copy`
- `declined`
- `history only`

That is the minimum honesty bar for a shell that wants to be super awesome.

## 4. Dry-run route diffs

The shell should be able to compare:
- route only,
- route + sidecar,
- route + stronger sidecar,
- and actual sink acceptance.

This makes it obvious whether the sidecar changed only explanation, narrowed scope, or enabled a genuinely new sink consequence.

## 5. Great terminal tricks worth stealing

- **designation-only pills** in semantic command blocks.
- **sidecar drawers** that can be expanded inline inside the transcript.
- **sink trays** attached to command/result blocks so cross-pane handoff stays visible.
- **route replay with re-negotiate** instead of fake timeless re-open.
- **copy-safe slips** that are intentionally shareable because they omit live authority.
- **why-did-this-open-here drawers** that show exact sink choice and exact sidecars used.

## 6. Nice user-facing language

Instead of one fake `open` or `share` label, the shell can say:
- `route only`
- `route + sidecar`
- `sink accepted representation`
- `sink accepted bind`
- `sink projected here`
- `sink localized here`
- `receipt only`

That grammar is much easier to trust.

References: REF-PLAN9-PLUMB, REF-PLAN9-PLUMBER4, REF-ANDROID-SHARE-FILE, REF-ANDROID-URIPERMISSION, REF-ANDROID-GRANTURIPERMISSION, REF-XDG-PORTAL-DESIGN, REF-XDG-REQUEST, REF-WAYLAND-DATADEVICES.
