# D-PLUMB document portal posture v0 (explicit persistence; non-bearer reopen; no app-visible grant inventory)

Purpose: pin an **implementable Phase 1** meaning for `portal.file.*` and CH-DOCREF so open/save/reopen workflows stay capability-shaped and path-free.
It narrows an already-present RFC/schema seam into something validators, UX, and harnesses can test without turning SlopOS into an ambient recent-doc database, a host-path API, or a silent persistence footgun.

## Posture (v0)

1) **`portal.file.*` remains manual-only in v0**
   - File open/save/export/share authority is obtained only through an interactive chooser/powerbox workflow.
   - There is no CH-ACP automation kind for `portal.file.*` in Phase 1.

2) **Persistence is explicit; chooser defaults stay ephemeral**
   - The default chooser result is a live scoped handle/cap for the current workflow.
   - A durable CH-DOCREF with `persistent=true` is minted only when the user or policy explicitly requests persistence.
   - Phase 1 rejects silent “always persistent” chooser defaults.

3) **CH-DOCREF remains non-bearer and origin-bound**
   - A docref alone is not authority.
   - Reopen authenticates the caller, enforces `origin.comp_id`, and re-applies active policy before any handle is issued.

4) **Reopen clamps; it never widens rights or target scope**
   - Reopened handles may not exceed the stored `rights` or `target_kind`.
   - A file grant does not become a directory grant, `read` does not become `read_write`, and reopening does not imply ambient sibling/ancestor discovery.
   - Directory grants remain scoped to the explicitly granted root; recursive breadth beyond that root requires a fresh mediated choice.
   - Safe-open composes with CH-DOCREF by resolving once and then materializing a request-local stable input object for the disposable; CH-DOCREF is not a promise of live preview/write-through semantics (`open-untrusted-materialization-boundary-v0.md`).
   - Safe-open viewers are also **inert by default**: document-embedded active content does not execute or trigger network/helper/print/file side effects merely because a docref-backed object was admitted to risky-open; any such effect becomes a new explicit workflow on the existing portal seam (`open-untrusted-active-content-boundary-v0.md`).
   - Safe-open keep/export also remains **fresh-destination-first**: the risky-open workflow does not overwrite an existing object in place merely because a chooser suggested the same name/path (`open-untrusted-export-destination-boundary-v0.md`).
   - Safe-open keep/export additionally records one exact `origin.parent_digest`, so a new kept artifact retains explicit parent evidence without inheriting the original document grant or `docref` identity (`open-untrusted-export-lineage-boundary-v0.md`).
   - Companion residue boundary: risky-open preview/open must not auto-enroll the source object into durable recent-doc / MRU / reopen surfaces or leave viewer residue (thumbnail/index/autosave/recovery state) outside the disposable; any durable reopen starts only from explicit keep/export or a fresh `portal.file.*` choice (`open-untrusted-viewer-residue-boundary-v0.md`).
   - Companion OpenURI recents boundary: generic `portal.uri.*` launch also does **not** become a portable recent-doc / reopen-enrollment seam; if persistence matters, it lives here on explicit CH-DOCREF / `portal.file.*` workflows instead (`openuri-recent-items-boundary-v0.md`).
   - Companion OpenURI materialization boundary: generic `portal.uri.*` launch also does **not** mint durable local objects, staged copies, or docrefs as a side effect of opening a URI; if durable bytes/object identity matter, they live here on explicit document/file workflows instead (`openuri-materialization-boundary-v0.md`).
- Companion OpenURI resource-grant boundary: generic `portal.uri.*` launch also does **not** mint URI permissions, security-scoped bookmarks, per-target document grants, or shareable local-object authority; if local-object handoff matters, it lives here or on explicit transfer workflows instead (`openuri-resource-grant-boundary-v0.md`).
   - Companion import boundary: when a workflow starts from CH-SREF / CH-CAPX, document workflows only begin after an explicit materialization step creates a **fresh local object** + provider-local docref; CH-DOCREF does not become a hidden bearer-backed docref shim or a live remote-object reopen path (`import-to-docref-boundary-v0.md`).
   - Companion fresh-identity boundary: that materialization step is **fresh-object-identity-first** and must not use XDG-style `reuse_existing` / `as-needed` semantics to hand back a pre-existing local document object/docref merely because the bytes match (`import-to-docref-fresh-identity-boundary-v0.md`).
   - Companion bearer-provenance boundary: the imported fresh local object may record one exact **`origin.import_ref_digest`** for the accepted bearer handoff, but routine document metadata never carries raw bearer bytes/capability URLs or hidden reopen/refresh instructions (`import-to-docref-bearer-provenance-boundary-v0.md`).
   - Companion bridge index: `import-to-docref-boundary-index.md` keeps the current `import-to-docref-*-boundary-v0.md` family enumerable so bearer→document bridge meaning does not silently widen by omission.
   - Companion MCP-roots import boundary: provider-local workspace roots exposed through MCP do **not** become directory grants, persistent bookmarks, chooser results, or docref shortcuts; if provider-local root-discovered bytes need routine document semantics they still cross explicit chooser/import/materialization seams here (`mcp-roots-import-boundary-v0.md`).
   - Companion MCP-resource import boundary: provider-local MCP resource catalogs, URI/templates, subscriptions/update notifications, annotations, and returned bytes do **not** become file/document grants, docrefs, watch registrations, or import shortcuts; if provider-local resource bytes need routine document semantics they still cross explicit chooser/import/materialization seams here (`mcp-resource-import-boundary-v0.md`).
   - Companion rendered-tool-UI file boundary: widget-uploaded files, file params, temporary preview/download URLs, and widget-triggered file export do **not** become a second document bridge or ambient export path; if widget-originated bytes need routine document semantics they still cross the explicit import/materialization seam here, and export remains host-mediated on the existing reviewed workflow (`tool-ui-file-boundary-v0.md`).

5) **Handles stay path-free and bounded**
   - `portal.file.*` returns capability-shaped handles or portal-owned view bindings, not host paths.
   - CH-DOCREF labels remain optional, bounded, and redaction-friendly.

6) **No app-visible grant inventory/list API in v0**
   - Phase 1 does not expose an ambient `list()` or “enumerate all prior grants” API to applications.
   - Any “manage remembered files” UI is shell/portal-owned and review-bound.

7) **Revocation and restore stay honest**
   - Revoked, expired, or replaced targets fail closed on reopen.
   - Restore must not resurrect revoked grants, and strict profiles MAY require fresh consent after restore.

8) **Sealed compat remains killable and non-ambient**
   - Any Foreign Cell open/save adapter must flow through `portal.file` / CH-DOCREF or an equivalent portal-issued handle.
   - Compat runtimes do not gain an ambient host-path escape hatch; the seam remains fail-closed behind `cfg.params.lane.portal.file`.

## Phase 1 non-goals (explicitly deferred)

- **ACP / background automation** for `portal.file.*`.
- **Ambient recent-document inventory APIs** visible to applications.
- **Auto-enrollment of risky-open previews** into durable recent-doc / reopen surfaces.
- **Host-path round-tripping** as an interop convenience.
- **Cross-app bearer sharing** by copying CH-DOCREF values around.
- **Implicit scope widening** from file→directory, read→write, or remembered directory grants becoming a general recursive host browser.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-PLUMB, D-POWERBOX)
- Schemas:
  - `document-handle-schema-v0.md` (CH-DOCREF v0)
  - `effect-contract-schema-v0.md` (`portal.file` effect family)
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.file.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.file`)
  - `pledge-token-mapping.md` (`portal.file`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-PLUMB-1, I-DOCREF-1, I-DOCREF-2, I-DOCREF-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-DOCREF-VALIDATE, PO-DOCREF-REOPEN, PO-DOCREF-ENF)
  - `open-untrusted-materialization-boundary-v0.md`
  - `open-untrusted-active-content-boundary-v0.md`
  - `open-untrusted-export-destination-boundary-v0.md`
  - `open-untrusted-export-lineage-boundary-v0.md`
  - `open-untrusted-viewer-residue-boundary-v0.md`
  - `docs/10-threat-model/abuse-cases.md` (AC-076)

CI drift gate:
- `tools/check_document_portal_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **manual-only / explicit persistence / no app-visible grant inventory** constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-FILECHOOSER.
- REF-XDG-PORTAL-DOCUMENTS.
- REF-APPLE-SECBOOKMARK.
- REF-ANDROID-SAF-DOCUMENTS.
