# Auth-teardown boundary v0 (no portable logout / disconnect / revocation seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable logout / sign-out / disconnect / revocation control surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how login/account/session teardown may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the user authenticated locally” into permission to sign the user out, revoke grants, or disconnect accounts through generic seams.

## Posture (v0)

1. **No portable auth-teardown seam in v0**
   - Phase 1 does **not** export a portable `logout`, `log_out`, `sign_out`, `signed_out`, `disconnect`, `disconnect_account`, `unlink_account`, `forget_account`, `revoke`, `revoke_token`, `revoke_grant`, `clear_session`, `clear_cookies`, `clear_login_state`, `end_session`, `rp_logout`, `frontchannel_logout`, `backchannel_logout`, `fedcm_disconnect`, or equivalent sign-out / disconnect / grant-teardown handoff on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, auth providers, and credential managers may maintain provider-local logout/disconnect/revocation workflows and request-local teardown UI, but those controls remain provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user finished or currently has a local sign-in session” as permission to mint or return a reusable sign-out / disconnect / revocation control across components/cells.

2. **Logout/disconnect/revocation is not a generic secret object, approval, or receipt outcome**
   - Logout, disconnect, and grant/token revocation may be operationally important, but they are not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because they affect local auth state.
   - **D-APPSECRET** remains about provider-derived app seeds, not about returning `logout`, `disconnect`, `revoke`, or equivalent account/session teardown controls.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about claiming authority to sign the user out, disconnect one provider/account, or revoke one grant/token set.
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about returning logout/disconnect/revocation controls as the outcome of local approval.

3. **Explicit local login/credential mediation is not permission to mint or relay teardown controls**
   - Existing ecosystems distinguish successful sign-in from portable teardown authority. OAuth 2.0 Token Revocation defines a dedicated revocation endpoint for revoking refresh/access tokens. OpenID Connect RP-Initiated Logout defines a dedicated logout request from a Relying Party to an OpenID Provider. FedCM likewise defines an explicit disconnect endpoint when account disconnection is supported. The common lesson is narrow: sign-out, disconnect, and revocation are first-class protocol/browser actions, not harmless residue of local login completion.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user complete a sign-in flow, but that does **not** justify returning `logout`, `disconnect`, `revoke`, `unlink_account`, or equivalent teardown controls on existing generic seams.
   - If a future product shape needs reviewed auth-teardown brokerage, it must return RFC-first with its own authority object, audit/privacy model, trusted-UI bindings, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to sign-out, disconnect, or grant revocation**
   - Agent tooling, shells, compat cells, and wrappers may propose “open this login page” or “use local sign-in,” but they must not silently sign the user out, disconnect accounts, revoke provider grants, clear browser cookies/profiles, or trigger hidden logout endpoints and browser/account-manager teardown flows as generic outputs.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient sign-out/disconnect/revocation channels through paths, env, hidden browser helpers, browser/profile stores, account-manager side APIs, or implicit network reachability.
   - It also keeps **D-LLM** honest: a model may propose an auth workflow, but it does not gain portable logout/disconnect/revocation authority merely because the user authenticated somewhere locally.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local browser/auth/account/session internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed auth-teardown brokerage seam must state its own conflict keys, commutativity preconditions, serialization point, freshness model, trusted-UI bindings, audit/privacy boundaries, and evidence story explicitly rather than inheriting folklore from browser profile management, IdP logout endpoints, or token-revocation helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `logout` / `sign_out` / `disconnect` / `revoke` / `unlink_account` export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded reusable sign-out/disconnect/revocation authority.
- No shell/helper fallback that quietly converts local sign-in into browser-profile clearing, logout endpoint triggering, or provider-account disconnect authority.
- No new CH-ACP kind or conflict-key family for auth-teardown brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenient mistake after the recent browser/auth-result/identity/login-state cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” “vault refs are not credential mediation,” “local sign-in is not browser-session export,” “local sign-in is not auth-result export,” “local sign-in is not identity-claim export,” and “local sign-in is not login-state export,” the next convenience instinct is obvious: “fine, then just let the tool sign the user out, disconnect the provider, or revoke the grant.” That sounds smaller than handing over a token set or account profile, but in practice it still recreates a generic ambient account-control channel through logout/disconnect/revocation actions that are difficult to reason about across product shapes and privacy regimes.

Pinning the boundary now keeps SlopOS from quietly turning reviewed local login mediation into portable teardown authority. It also leaves future work a clean choice: if the system ever needs explicit logout/disconnect/revocation brokerage, it can arrive as a small RFC-first seam with exact audit, privacy, and evidence semantics rather than as folklore smeared across launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local sign-in UX, but that does not standardize logout/disconnect/revocation control as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake account-teardown brokers or “disconnect the provider for me” helper machinery they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local login flows where useful without promising a general logout/disconnect/revocation export/import substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user completed or still has a login locally” with permission to trigger `logout`, `disconnect`, `revoke`, or `unlink_account`; reviewed auth-teardown workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_auth_teardown_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable auth-teardown seam / logout-disconnect-revocation is not a generic secret object or receipt outcome / explicit login mediation is not permission to mint or relay teardown controls / no hidden sign-out-disconnect-revoke fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-621**).

## References

- REF-RFC7009-TOKEN-REVOCATION.
- REF-OPENID-RP-INITIATED-LOGOUT.
- REF-W3C-FEDCM.
