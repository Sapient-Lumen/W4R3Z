# Auth-proof export boundary v0 (no portable proof-of-possession / auth-assertion export seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable proof-of-possession, challenge-signing, or auth-assertion export surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how auth-proof material may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the user completed a login locally” into a portable signer / assertion / proof broker.

## Posture (v0)

1. **No portable auth-proof export seam in v0**
   - Phase 1 does **not** export a portable `dpop_proof`, `proof_of_possession`, `client_assertion`, `signed_challenge`, `webauthn_assertion`, `assertion_response`, `holder_of_key_proof`, `tls_client_cert_proof`, `certificate_bound_token_proof`, `mtls_client_auth_proof`, `proof_of_login`, or equivalent auth-proof handoff on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, auth providers, authenticators, and credential managers may maintain provider-local keys, authenticators, or certificate state, but that state remains provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user finished a local sign-in flow” as permission to mint or return a reusable challenge response, proof JWT, authenticator assertion, or client-certificate proof across components/cells.

2. **Auth proofs are not generic secret objects, approvals, or receipt outcomes**
   - Proof-of-possession outputs, authenticator assertions, and challenge responses may be security-sensitive, but they are not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because they matter operationally.
   - **D-APPSECRET** remains about provider-derived app seeds, not about returning DPoP proof JWTs, WebAuthn assertion blobs, client-assertion JWTs, or certificate-proof artifacts.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about claiming that a user completed an authenticator ceremony or produced an app-consumable proof object.
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about returning proof/signature artifacts as the outcome of local approval.

3. **Explicit local login/credential mediation is not permission to mint or relay auth proofs**
   - Existing ecosystems distinguish local auth ceremonies from generic proof export. RFC 9449 defines DPoP as an explicit proof-of-possession mechanism with proof JWTs signed by a client-held key. RFC 8705 defines mutual-TLS client authentication and certificate-bound access tokens as dedicated certificate-presenting/token-binding surfaces. WebAuthn scopes assertion use to a relying party/origin and a concrete user-mediated ceremony.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user complete a sign-in flow, but that does **not** justify returning DPoP proofs, client-assertion JWTs, WebAuthn assertions, challenge signatures, or equivalent proof material on existing generic seams.
   - If a future product shape needs reviewed auth-proof brokerage, it must return RFC-first with its own authority object, replay model, trusted-UI story, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to challenge signing, authenticator assertion relay, or client-certificate proof relay**
   - Agent tooling, shells, compat cells, and wrappers may propose “continue with local sign-in” or “approve this challenge,” but they must not silently start signing arbitrary challenges, mint proof JWTs, trigger relying-party assertions, present bound client certificates, or relay authenticator outputs back as generic workflow results.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient proof/signing channels through paths, env, loopback helpers, hidden browser/authenticator bridges, inherited key handles, or implicit network reachability.
   - It also keeps **D-LLM** honest: a model may propose an auth workflow, but it does not gain portable proof-of-possession authority merely because the user authenticated somewhere locally.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local browser/authenticator/certificate internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed auth-proof brokerage seam must state its own conflict keys, commutativity preconditions, serialization point, trusted-UI bindings, replay boundaries, and evidence story explicitly rather than inheriting folklore from challenge-signing helpers, authenticator SDKs, or certificate-bound token stacks.

## Phase 1 non-goals (explicitly deferred)

- No portable `dpop_proof` / `proof_of_possession` / `client_assertion` / `webauthn_assertion` / `signed_challenge` / `tls_client_cert_proof` export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded a reusable auth proof or challenge-response artifact.
- No shell/helper fallback that quietly converts local sign-in into challenge signing, authenticator assertion relay, or certificate-proof relay authority.
- No new CH-ACP kind or conflict-key family for auth-proof brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenience mistake after the recent browser/result/context/identity/state/teardown cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” “vault refs are not credential mediation,” and “local sign-in is not token/session/account export,” the next convenience instinct is obvious: “fine, then just use the credential locally and hand the tool the proof.” That sounds narrower than handing over a token set, but in practice it still recreates a generic ambient auth bridge through challenge signing, sender-constrained proof JWTs, authenticator assertions, and certificate-bound token proofs that are difficult to reason about across product shapes.

Pinning the boundary now keeps SlopOS from quietly turning reviewed local login mediation into portable auth-proof export authority. It also leaves future work a clean choice: if the system ever needs explicit auth-proof brokerage, it can arrive as a small RFC-first seam with exact replay, ceremony, privacy, and evidence semantics rather than as folklore smeared across launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local sign-in/authenticator UX, but that does not standardize proof-JWT/assertion/challenge-signature return as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake challenge-signing brokers, authenticator relays, or certificate-proof helpers they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local auth ceremonies where useful without promising a general auth-proof export/import substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user completed a login locally” with permission to receive a DPoP proof, WebAuthn assertion, or equivalent challenge-response artifact; reviewed auth-proof workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_auth_proof_export_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable auth-proof export seam / auth proofs are not generic secret objects or receipt outcomes / explicit login mediation is not permission to mint or relay auth proofs / no hidden challenge-signing-authenticator-relay fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-624**).

## References

- REF-RFC9449-DPOP.
- REF-RFC8705-OAUTH-MTLS.
- REF-WEBAUTHN-3.
