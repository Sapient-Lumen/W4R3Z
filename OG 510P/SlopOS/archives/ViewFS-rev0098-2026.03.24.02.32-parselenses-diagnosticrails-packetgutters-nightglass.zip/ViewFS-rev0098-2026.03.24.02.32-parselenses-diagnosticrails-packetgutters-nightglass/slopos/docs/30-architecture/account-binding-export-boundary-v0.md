# Account-binding export boundary v0 (no portable linked-account / connected-account / default-account export seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login, linking, or provider-owned account mapping does **not** create a portable linked-account / connected-account / selected-account / default-account export surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how provider-owned account-binding state may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the host/provider already knows which account this is” into a portable substrate artifact.

## Posture (v0)

1. **No portable account-binding export seam in v0**
   - Phase 1 does **not** export a portable `linked_account`, `connected_account`, `selected_account`, `default_account`, `active_account_binding`, `provider_account_binding`, `workspace_binding`, `tenant_binding`, `account_link`, `connector_binding`, `connected_workspace`, `mapped_account`, `account_map`, or equivalent account-binding handoff on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, identity providers, MCP hosts, and application backends may maintain provider-local or request-local account mapping state, but that mapping remains provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user linked/logged in locally” as permission to mint or return a portable connected-account / default-account / workspace-binding artifact across components/cells.

2. **Account binding is not a generic secret object, approval outcome, or login-status synonym**
   - Connected-account state may be operationally important, but it is not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because a provider/backend needs it internally.
   - **D-APPSECRET** remains about provider-derived app seeds, not about exposing which provider account, tenant, workspace, or connector binding the host/backend mapped to the current user.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about returning “which account is linked,” “which workspace is active,” or “which provider binding will be used.”
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about turning local linking/account choice into a durable account-binding receipt.
   - Companion boundaries stay distinct on purpose: `identity-claim-export-boundary-v0.md` covers subject/email/profile disclosure, `login-state-export-boundary-v0.md` covers signed-in/account-availability state, and `auth-link-ui-trigger-boundary-v0.md` covers host-offered link/account-choice prompts. This boundary only removes the tempting middle claim that provider-owned account mapping itself becomes a portable artifact.

3. **Provider-owned account mapping stays provider-local, not portable substrate truth**
   - Current OpenAI Apps SDK guidance explicitly tells developers to authenticate so they can map ChatGPT identities to their internal accounts, and MCP's Enterprise-Managed Authorization extension explicitly lets an enterprise IdP grant access to many authorized MCP servers after one sign-in. Those are useful product patterns, but they still describe provider/enterprise-owned mapping and policy, not a generic app-visible or agent-visible linked-account export API.
   - SlopOS imports the narrow lesson: local login/linking may let a provider/backend decide which internal account, workspace, or tenant it will use, but that does **not** justify exporting that binding on existing generic seams.
   - If a future product shape needs reviewed account-binding brokerage, connected-account enumeration, or default-account selection/export, it must return RFC-first with its own authority object, privacy story, trusted-UI bindings, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to account-switcher scraping, connector-state reflection, or remembered-binding relay**
   - Agent tooling, shells, compat cells, widgets, and wrappers may propose login/link flows, but they must not silently scrape browser account switchers, connector settings, workspace choosers, linked-account chips, provider-side “currently connected” labels, or backend connection metadata and relay that as generic outputs.
   - They must also not infer portable account-binding truth from cached provider mappings, prior challenge outcomes, enterprise SSO reachability, or tool success/failure patterns.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient account-binding channels through paths, env, hidden browser helpers, implicit network reachability, cached connector state, or provider-specific account-switcher APIs.
   - It also keeps **D-LLM** honest: a model may propose a sign-in or linking workflow, but it does not gain portable authority to learn or name which provider-side account/workspace binding the host/backend chose.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local auth/account/linking internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed account-binding brokerage seam must state its own conflict keys, commutativity preconditions, serialization point, privacy boundaries, trusted-UI bindings, and evidence story explicitly rather than inheriting folklore from connector settings pages, identity SDKs, or host/provider account selectors.

## Phase 1 non-goals (explicitly deferred)

- No portable `linked_account` / `connected_account` / `selected_account` / `default_account` / `workspace_binding` / `tenant_binding` export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, auth challenge, or local sign-in flow also yielded a reusable provider-account binding.
- No shell/helper fallback that quietly converts local linking into account-switcher scraping, connector-state reflection, or remembered-binding relay authority.
- No new CH-ACP kind or conflict-key family for account-binding brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenient mistake after the recent auth-link, identity-claim, and login-state cuts. Once the archive says “no hidden browser,” “no auth-link trigger plane,” “no identity/profile export,” and “no signed-in/account-state export,” the next convenience instinct is obvious: “fine, then just tell the tool which connected account/workspace the host already picked.” That sounds smaller than returning a token set or user profile, but in practice it still recreates a generic ambient connector/account-binding plane that is hard to reason about across privacy regimes and product shapes.

Pinning the boundary now keeps SlopOS from quietly turning provider-owned account mapping into portable substrate truth. It also leaves future work a clean choice: if the system ever needs explicit account-binding brokerage or reviewed connected-account selection, it can arrive as a small RFC-first seam with exact privacy, replay, and evidence semantics rather than as folklore smeared across auth, launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local linking/sign-in UX, but that does not standardize linked-account or default-workspace return as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake connector-account brokers or remembered-account-selection machinery they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can permit bounded local sign-in/linking where useful without promising a general connected-account export/import substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the provider/backend knows which account this maps to” with permission to receive a `connected_account`, `selected_workspace`, or equivalent account-binding artifact; reviewed account-binding workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_account_binding_export_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable account-binding export seam / account binding is not a generic secret object or receipt outcome / provider-owned account mapping stays provider-local rather than portable substrate truth / no hidden account-switcher-scraping or connector-state reflection fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-658**).

## References

- REF-OPENAI-APPS-SDK-AUTH.
- REF-OPENAI-APPS-SDK-STATE.
- REF-MCP-ENTERPRISE-MANAGED-AUTH.
