# Auth-result export boundary v0 (no portable auth-code / token / login-result export seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable authorization-code, token-set, callback-result, or generic login-result export surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how existing auth-result material may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the user completed a login locally” into a portable result object.

## Posture (v0)

1. **No portable auth-result export seam in v0**
   - Phase 1 does **not** export a portable `authorization_code`, `access_token`, `refresh_token`, `id_token`, `token_set`, `login_result`, `auth_result`, `oauth_result`, `federated_result`, `device_code`, `user_code`, `verification_uri`, `callback_result`, `saml_assertion`, `proof_of_login`, or equivalent auth-result handoff on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, auth providers, and credential managers may maintain provider-local redirect/session/result state, but that state remains provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user finished a local sign-in flow” as permission to mint or return a portable code/token/assertion bundle across components/cells.

2. **Auth results are not generic secret objects, approvals, or receipt outcomes**
   - Authorization codes, token sets, federated assertions, and login callbacks may be security-sensitive, but they are not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because they matter operationally.
   - **D-APPSECRET** remains about provider-derived app seeds, not about returning OAuth refresh tokens, login JWTs, or account-link completion artifacts.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about claiming that a user selected an account, completed a redirect flow, or produced an app-consumable login result.
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about returning auth-result objects as the outcome of local approval.

3. **Explicit local login/credential mediation is not permission to mint or relay login results**
   - Existing ecosystems distinguish user-mediated sign-in from generic auth-result export. RFC 8252 routes native-app OAuth through an external user-agent and treats redirect-bound authorization responses as part of a dedicated app/session flow, not as a generic launcher or secret-store side effect. Chrome Auth Tab similarly returns an authentication result through a dedicated callback path. Android Credential Manager is likewise an explicit credential-exchange API rather than a meaning secretly inherited by unrelated secret or approval seams. RFC 9700 goes further and documents redirect-handling pitfalls, including cases where careless redirect behavior can disclose user credentials to the client.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user complete a sign-in flow, but that does **not** justify returning authorization codes, access tokens, refresh tokens, ID tokens, or equivalent login-result material on existing generic seams.
   - If a future product shape needs reviewed auth-result brokerage, it must return RFC-first with its own authority object, replay model, trusted-UI story, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to callback scraping, loopback capture, or token relay**
   - Agent tooling, shells, compat cells, and wrappers may propose “open this login page” or “use local sign-in,” but they must not silently start loopback listeners, intercept registered redirect URIs, scrape callback URLs from browser/UI state, read clipboard/shared callback text, or relay authorization codes/access tokens/refresh tokens/ID tokens back as generic outputs.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient callback or token channels through paths, env, loopback listeners, hidden browser helpers, or implicit network reachability.
   - It also keeps **D-LLM** honest: a model may propose an auth workflow, but it does not gain portable auth-result authority merely because the user authenticated somewhere locally.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local browser/auth/session internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed auth-result brokerage seam must state its own conflict keys, commutativity preconditions, serialization point, trusted-UI bindings, replay boundaries, and evidence story explicitly rather than inheriting folklore from redirect handlers, token SDKs, or credential managers.

## Phase 1 non-goals (explicitly deferred)

- No portable authorization-code / access-token / refresh-token / ID-token / federated-assertion export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded a reusable login result.
- No shell/helper fallback that quietly converts local sign-in into callback capture, loopback interception, or token relay authority.
- No new CH-ACP kind or conflict-key family for auth-result brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenient mistake after the recent LLM/secret/browser cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” “vault refs are not credential mediation,” and “local sign-in is not browser-session export,” the next convenience instinct is obvious: “fine, then just give the tool the auth result.” That sounds narrower than handing over a cookie jar, but in practice it still recreates a generic ambient auth bridge through codes, callbacks, token sets, and federated assertions that are difficult to reason about across product shapes.

Pinning the boundary now keeps SlopOS from quietly turning reviewed local login mediation into portable auth-result export authority. It also leaves future work a clean choice: if the system ever needs explicit auth-result brokerage, it can arrive as a small RFC-first seam with exact state, replay, and evidence semantics rather than as folklore smeared across launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local sign-in UX, but that does not standardize authorization-code/token/assertion return as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake callback brokers, loopback login helpers, or token-relay machinery they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local login flows where useful without promising a general auth-result export/import substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user completed a login locally” with permission to receive an authorization code, token set, or federated assertion; reviewed auth-result workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_auth_result_export_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable auth-result export seam / auth results are not generic secret objects or receipt outcomes / explicit login mediation is not permission to mint or relay login results / no hidden callback-scraping-token-relay fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-618**).

## References

- REF-RFC8252-NATIVE-APPS.
- REF-RFC9700-OAUTH-SECURITY.
- REF-CHROME-AUTH-TAB.
- REF-ANDROID-CREDENTIAL-MANAGER.
