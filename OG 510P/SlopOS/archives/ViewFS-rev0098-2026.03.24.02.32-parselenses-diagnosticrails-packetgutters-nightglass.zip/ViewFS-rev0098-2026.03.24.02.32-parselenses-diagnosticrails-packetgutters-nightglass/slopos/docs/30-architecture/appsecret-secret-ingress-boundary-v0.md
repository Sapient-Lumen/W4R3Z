# D-APPSECRET secret-ingress boundary v0 (no portable user-supplied secret / credential-import seam)

Purpose: pin one compact Phase-1 rule on the **D-APPSECRET / `portal.secret.*`** seam: per-application secret issuance does **not** become a portable password/API-key/OAuth-token import, paste/store, account-linking, or generic user-supplied secret-ingress workflow.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal request kind, **no new ACP**, and **no new conflict-key family**. It only narrows how existing secret-portal semantics may be interpreted.

## Posture (v0)

1. **No portable user-supplied secret / credential-import seam in v0**
   - Phase 1 does **not** export a portable `secret_value`, `password`, `api_key`, `bearer_token`, `refresh_token`, `authorization_code`, `private_key`, `pem`, `pkcs8`, `mnemonic`, `seed_phrase`, `ssh_private_key`, `set_secret`, `store_secret`, `import_secret`, or equivalent caller-supplied secret-bearing field/result on `portal.secret.*`, **CH-APPSECRET v0**, or adjacent app-secret request/receipt surfaces.
   - Providers may internally derive or unwrap per-app seed material from provider-held roots or hardware-backed stores, but that setup remains provider-local rather than app-facing portal meaning.
   - Phase 1 therefore does **not** reinterpret “secret portal” as a portable place to paste, import, escrow, or later re-read arbitrary secret bytes.

2. **App-secret issuance is about local protection seeds, not user credential storage**
   - **D-APPSECRET** remains a minimal app-seed seam for local confidentiality/integrity (`local_encrypt`, `local_integrity`, `kdf_seed`), not a password manager, shared token cache, or named credential store.
   - If an app needs to retain a user-entered API key, password, OAuth refresh token, or similar credential, that data must either remain inside app-local encrypted state or return on an explicit **D-VAULT** / future credential workflow; `portal.secret` itself does **not** standardize storage/search/share/recovery of that second class of secret.
   - This keeps per-app seed issuance distinct from **Secret Service**-style collection/item storage and from future vault semantics.

3. **Login / account-linking / credential brokerage stays on explicit mediation seams**
   - Existing ecosystems really do split these surfaces. The XDG Secret portal is for retrieving a **per-application secret**. Secret Service is a separate named-secret storage API. RFC 8252 routes OAuth for native apps through an external user-agent. WebAuthn and Android Credential Manager likewise treat credential use as a mediated authentication workflow.
   - Those can be valuable product workflows, but they allocate account selection, user verification, storage/retrieval, refresh, and result-handling semantics that are **not** harmless synonyms for issuing an app seed.
   - Phase 1 therefore does **not** reinterpret `portal.secret` as authority to show a login flow, ask for a password/passkey, or return account/credential results.

4. **No hidden agent/shell fallback from “need a secret” to “ask the user to paste one”**
   - Agent tooling, shell helpers, and compatibility wrappers may propose secret-related workflows, but they must not silently replace app-seed issuance with inline prompt/paste/storage behavior and then report that second workflow as generic `portal.secret` truth.
   - This keeps **D-LLM** and **D-APPSECRET** aligned: prompt text cannot smuggle a hidden credential-import plane under the label “secret portal”.
   - If a deployment wants reviewed user-entered credential workflows later, it must pay for them on an explicit seam with its own UX, redaction, conflict-key, and evidence story.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing issuance/rotation state remains ordered inside `svc:portal.secret` as already pinned by `app-secret-posture-v0.md`.
   - Any future secret-import/store/account-linking seam must state its own conflict keys, serialization point, replay rules, redaction posture, and evidence plan explicitly rather than inheriting folklore from keyrings, credential managers, or login helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `set_secret`, `store_password`, `save_api_key`, `save_token`, `import_pem`, `import_private_key`, `link_account`, `credential_provider`, or equivalent user-supplied secret / credential-ingress knob on `portal.secret.*`.
- No transcript-stable statement that `portal.secret` also completed login, account selection, passkey use, OAuth exchange, or user-provided secret storage.
- No shell/helper fallback that quietly promotes app-seed issuance into password/API-key/token paste-and-save behavior and reports that second workflow as generic portal truth.
- No new CH-ACP kind or conflict-key family for secret ingress in v0.

## Why this is worth pinning

This is a small entropy cost that closes an expensive future mistake. Without it, apps, wrappers, and agents quickly start depending on guessed semantics like “ask the user for an API key and store it in the secret portal,” “use `portal.secret` for OAuth refresh tokens,” or “treat app-secret issuance as account-linking with durable replay.” Once those assumptions land in transcripts and automation, they become hard to retract and they blur three intentionally separate surfaces: **minimal app seeds (D-APPSECRET)**, **durable credential objects (D-VAULT)**, and **interactive auth / account mediation**. Pinning the boundary now keeps SlopOS from quietly turning a narrow app-seed primitive into a hidden credential-ingress plane.

## Profile effect (A–D)

- **Secure workstation (A):** explicit login/vault tooling may still exist, but `portal.secret` does not standardize password/API-key/token storage as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting a fake per-guest credential-paste/store API when they often want external provisioning or operator-local secret injection instead.
- **Embedded / separation appliance (C):** appliance builds can expose bounded local protection seeds without promising a general credential manager or account-linking substrate they do not actually implement.
- **Agent/automation OS (D):** agents/tools cannot confuse “this app needs a secret” with permission to prompt for, ingest, and persist arbitrary user credentials under the `portal.secret` label; reviewed credential workflows must return on explicit future seams.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/app-secret-descriptor-schema-v0.md`
- `docs/30-architecture/portal-family-registry.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/30-architecture/llm-elicitation-boundary-v0.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0104-application-secrets-and-secret-portal.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_appsecret_secret_ingress_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable user-supplied secret / credential-import seam / app-secret issuance is about local protection seeds / login-credential brokerage stays on explicit mediation seams / no hidden paste-and-save fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-615**).

## References

- REF-XDG-PORTAL-SECRET.
- REF-SECRET-SERVICE-SPEC.
- REF-RFC8252-NATIVE-APPS.
- REF-WEBAUTHN-3.
- REF-ANDROID-CREDENTIAL-MANAGER.
