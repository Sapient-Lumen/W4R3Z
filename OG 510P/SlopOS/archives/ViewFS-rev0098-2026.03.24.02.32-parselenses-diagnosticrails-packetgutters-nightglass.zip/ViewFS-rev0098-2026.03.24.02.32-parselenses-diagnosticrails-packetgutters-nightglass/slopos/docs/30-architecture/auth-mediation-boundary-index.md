# Auth-mediation companion boundary index (v0)

Purpose: keep the **closed set of explicit-local-auth / credential-mediation companion boundary docs** enumerable.

Why this exists:
- the archive now pins multiple small boundaries that all defend the same expensive seam: agent/tool/server requests for user input, secret ingress, credential mediation, credential portability, pending-auth continuation, and local login do **not** silently regrow a generic browser, credential manager, password manager, enrollment surface, token/proof/session/account export, or account-control substrate,
- those boundary docs are individually crisp but easy to forget piecemeal because they span D-LLM, D-POWERBOX, D-UICAP, D-APPSECRET, D-VAULT, and D-PLUMB,
- `llm-operations-posture-v0.md`, `app-secret-posture-v0.md`, and `vault-posture-v0.md` keep the underlying Phase-1 meanings small, while this index is the **discovery surface** that says which companion boundaries currently keep explicit local auth/credential mediation bounded and non-portable.

This doc does **not** add a new schema, workflow family, or credential broker.
It is an entropy-reducing companion to `llm-operations-posture-v0.md`, `app-secret-posture-v0.md`, `vault-posture-v0.md`, and `secret-authority-adjunct-index.md`.

## Posture (v0)

1. **Closed family, not adjacent singleton folklore**
   - The current explicit-local-auth / credential-mediation meaning cuts are treated as one closed recovery surface, not neighboring facts readers are expected to rediscover manually.
2. **Entropy reduction only**
   - This index does not widen D-LLM, D-APPSECRET, D-VAULT, D-POWERBOX, D-UICAP, or D-PLUMB, and it does not introduce a browser API, callback protocol, account broker, password manager, token/session store, pending-auth broker, or credential exchange broker.
3. **Same-revision family maintenance**
   - Future auth/credential-mediation boundary growth must either attach to this family in the same revision or justify a different explicit discovery surface in the same revision.

## Phase 1 non-goals (explicitly deferred)

- No portable hidden-browser or embedded-webview authority path.
- No generic password / API-key / OAuth-token paste-store or account-linking seam.
- No portable password-manager / autofill / passkey / account-selection seam.
- No portable passkey-registration / authenticator-enrollment / credential-provisioning seam.
- No portable password-manager migration / passkey portability / credential import-export seam.
- No portable cookie-jar / authenticated-browser-session / replay-blob export seam.
- No portable pending-auth / continuation-handle / PKCE-device-backchannel relay seam.
- No portable account-linking / connect-account / auth-link trigger / choose-account seam.
- No portable authorization-code / token-set / callback-result / login-result export seam.
- No portable proof-of-possession / auth-assertion export seam.
- No portable granted-scope / resource-indicator / authorization-details / entitlement export seam.
- No portable subject / issuer / email / profile / account-identity export seam.
- No portable linked-account / connected-account / selected-account / default-account export seam.
- No portable signed-in / login-status / session-state / account-availability export seam.
- No portable logout / disconnect / revoke / unlink-account control seam.
- No hidden prompt-defined auth broker, token relay, or account-control family smuggled through this index.

## Inclusion rule

A doc belongs here if it removes exactly one tempting explicit-local-auth / credential-mediation meaning widening from Phase 1 by constraining one of:
- server/tool/model requests for more user input that would otherwise regrow a hidden browser, token relay, or generic inline secret-ingress plane,
- minimal app-seed ingress that would otherwise regrow password/API-key/OAuth-token paste-store or account-linking semantics,
- ref-bound secret storage that would otherwise regrow password-manager, autofill, passkey, or account-selection semantics,
- credential-enrollment control that would otherwise regrow passkey-registration, authenticator-enrollment, or account-upgrade semantics,
- credential portability or password-manager migration that would otherwise regrow password-manager export/import, passkey portability, or equivalent credential-exchange semantics,
- browser/session continuity that would otherwise regrow cookie-jar handoff, authenticated-browser-profile export, or replayable session-blob semantics,
- pending-auth continuation that would otherwise regrow PKCE verifier relay, device-flow code handoff, verification-URL relay, or backchannel polling semantics,
- auth-link/account-link triggers that would otherwise regrow `auth_required`, connect-account, account-choice, or account-broker trigger semantics,
- local-auth results that would otherwise regrow authorization-code, token-set, callback-result, or generic login-result export semantics,
- local-auth proof surfaces that would otherwise regrow DPoP / challenge-signing / authenticator-assertion / certificate-proof export semantics,
- local-auth authorization-context surfaces that would otherwise regrow granted-scope / resource-indicator / authorization-details / entitlement export semantics,
- local-auth identity surfaces that would otherwise regrow subject / issuer / email / profile / account-identity export semantics,
- local-auth account-binding surfaces that would otherwise regrow linked-account / connected-account / selected-account / default-account export semantics,
- local-auth status surfaces that would otherwise regrow signed-in / login-status / session-state / account-availability export semantics,
- local-auth teardown surfaces that would otherwise regrow logout / disconnect / revoke / unlink-account control semantics.

If future work needs a native credential-manager surface, portable credential-enrollment API, portable credential-exchange API, portable pending-auth / continuation-handle broker, portable browser/login continuation API, portable callback/token broker, portable auth-proof broker, portable authorization-context export API, portable identity/profile export API, portable connected-account / account-binding export API, portable login-status API, or portable sign-out/disconnect/revocation API instead, that work must return **RFC-first** as its own decision surface rather than hiding behind existing auth-adjacent convenience semantics.

## Member contract

Every auth-mediation family member doc must remain a **small tightening doc**, not a stealth workflow/spec expansion. Concretely, each member must:
- say the boundary is intentionally small and introduces **no new schema family**,
- preserve an explicit **no new ACP** / **no new conflict-key family** posture for v0,
- carry `## Family status (Phase 1)`, `## Wiring`, `## Evidence hook`, and `## References` sections so recovery/discovery shape stays uniform,
- restate that future nearby growth attaches to this family in the **same revision** rather than re-creating singleton lore,
- point its `## Evidence hook` at exactly one dedicated drift gate under `tools/` so family-member drift is machine-checked instead of reviewer-memory-only.

This contract does **not** add a new schema or workflow. It only keeps the closed family readable, enumerable, and LLM-recoverable as the member set grows.

## Closed companion boundary set (Phase 1)

### 1) User-input requests stay proposal-only until explicit local mediation

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`llm-elicitation-boundary-v0.md`](llm-elicitation-boundary-v0.md) | server/tool/model requests for more user input | requests for login/OAuth/payment/secret entry stay untrusted proposal material only; no hidden browser, token relay, or generic inline secret-ingress plane | explicit IF-CONSENT / trusted UI / secret portal workflow if ever needed |

### 2) App-secret ingress stays provider-issued seed issuance only

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`appsecret-secret-ingress-boundary-v0.md`](appsecret-secret-ingress-boundary-v0.md) | app-seed ingress/import semantics | `portal.secret` issues provider-derived app seeds only; it does not become a portable password/API-key/OAuth-token paste-store or account-linking seam | future RFC-first credential-ingress workflow if ever needed |

### 3) Vault refs stay secret-object authority, not credential mediation

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`vault-credential-mediation-boundary-v0.md`](vault-credential-mediation-boundary-v0.md) | vault-vs-credential-mediation surface split | D-VAULT / CH-SECRETREF stay secret-object authority only; they do not become a portable password-manager, autofill, passkey, account-selection, or auth-result seam | future RFC-first credential-provider / account-choice workflow if ever needed |

### 4) Local sign-in does not become credential-enrollment control

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`credential-enrollment-boundary-v0.md`](credential-enrollment-boundary-v0.md) | passkey-registration / authenticator-enrollment / account-upgrade control semantics | explicit local login or credential mediation does not yield a portable credential-enrollment, passkey-registration, or equivalent control seam | future RFC-first credential-enrollment workflow if ever needed |

### 5) Local sign-in does not become credential exchange

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`credential-exchange-boundary-v0.md`](credential-exchange-boundary-v0.md) | password-manager migration / passkey portability / credential import-export semantics | explicit local login or credential mediation does not yield a portable password-manager migration, passkey portability, or equivalent credential-exchange seam | future RFC-first credential portability workflow if ever needed |

### 6) Local sign-in does not become browser-session export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`browser-session-export-boundary-v0.md`](browser-session-export-boundary-v0.md) | cookie-jar / authenticated-browser-session / replay-blob semantics | explicit local login or credential mediation does not yield a portable cookie jar, authenticated browser profile, or replayable browser-session export seam | future RFC-first session-continuity workflow if ever needed |

### 7) Local sign-in does not become auth continuation export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-continuation-export-boundary-v0.md`](auth-continuation-export-boundary-v0.md) | pending-auth / continuation-handle / PKCE-device-backchannel relay semantics | explicit local login or credential mediation does not yield a portable PKCE verifier, device-flow code bundle, verification URL, `auth_req_id`, or equivalent pending-auth / continuation-handle seam | future RFC-first auth-resume / pending-auth brokerage workflow if ever needed |

### 8) Auth challenges do not become account-linking trigger authority

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-link-ui-trigger-boundary-v0.md`](auth-link-ui-trigger-boundary-v0.md) | auth-linking / account-choice / auth-broker trigger semantics | auth metadata/challenges may ask the host to offer local linking UI, but they do not yield a portable account-linking, account-choice, or auth-broker trigger seam | future RFC-first account-broker / linking workflow if ever needed |

### 9) Local sign-in does not become auth-result export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-result-export-boundary-v0.md`](auth-result-export-boundary-v0.md) | authorization-code / token-set / callback-result export semantics | explicit local login or credential mediation does not yield a portable authorization code, token set, callback result, or generic login-result export seam | future RFC-first callback / token broker if ever needed |

### 10) Local sign-in does not become auth-proof export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-proof-export-boundary-v0.md`](auth-proof-export-boundary-v0.md) | DPoP / challenge-signing / authenticator-assertion / certificate-proof export semantics | explicit local login or credential mediation does not yield a portable DPoP proof, client assertion, WebAuthn assertion, challenge signature, or equivalent auth-proof export seam | future RFC-first proof-broker workflow if ever needed |

### 11) Local sign-in does not become authorization-context export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`authorization-context-export-boundary-v0.md`](authorization-context-export-boundary-v0.md) | granted-scope / resource-indicator / authorization-details / entitlement export semantics | explicit local login or credential mediation does not yield a portable granted-scope, resource-indicator, authorization-details, permission, or entitlement export seam | future RFC-first grant-context workflow if ever needed |

### 12) Local sign-in does not become identity/profile export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`identity-claim-export-boundary-v0.md`](identity-claim-export-boundary-v0.md) | subject / issuer / email / profile / account-identity export semantics | explicit local login or credential mediation does not yield a portable subject, issuer, email, profile, or account-identity export seam | future RFC-first identity/profile disclosure workflow if ever needed |

### 13) Local sign-in does not become account-binding export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`account-binding-export-boundary-v0.md`](account-binding-export-boundary-v0.md) | linked-account / connected-account / default-account export semantics | explicit local login, linking, or provider-owned account mapping does not yield a portable linked-account, connected-account, selected-account, or default-account export seam | future RFC-first account-binding / connected-account workflow if ever needed |

### 14) Local sign-in does not become login-state export

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`login-state-export-boundary-v0.md`](login-state-export-boundary-v0.md) | signed-in / login-status / session-state / account-availability semantics | explicit local login or credential mediation does not yield a portable signed-in status, session-state, or account-availability export seam | future RFC-first login-status workflow if ever needed |

### 15) Local sign-in does not become auth teardown

| Boundary doc | Pins | Phase 1 meaning | Explicit seam instead |
|---|---|---|---|
| [`auth-teardown-boundary-v0.md`](auth-teardown-boundary-v0.md) | logout / disconnect / revoke / unlink-account control semantics | explicit local login or credential mediation does not yield a portable logout, disconnect, revoke, or unlink-account control seam | future RFC-first sign-out / disconnect / revocation workflow if ever needed |

## Review rule

Before adding another explicit-local-auth / credential-mediation companion boundary doc, answer these questions in order:
1) Is the change really an **auth-mediation meaning pin** rather than a new schema, workflow, or provider family?
2) Can the need be satisfied by an existing boundary doc already listed above?
3) If not, is the entropy cost worth paying for **one new boundary doc** rather than widening imported browser/credential/login folklore?

If the answer to (1) is yes and the answer to (2) is no, add the new doc here **in the same revision** and keep the drift gate aligned so discovery cannot silently rot.

## Wiring

This index must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/30-architecture/decision-map.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `tools/README.md`
- `CHANGELOG.md`

## Evidence hook

- `tools/check_auth_mediation_boundary_index.py` fails `make lint` if this companion family stops being discoverable, loses its closed member set, or drops its same-revision maintenance contract (**EVID-2026-622**).
- `tools/check_auth_mediation_family_contract.py` fails `make lint` if any auth-mediation family member drops the shared member-contract shape (family attachment clause, required recovery sections, explicit no-new-schema / no-new-ACP / no-new-conflict-key posture, or single dedicated checker) (**EVID-2026-628**).

## References

- REF-MCP-ELICITATION.
- REF-XDG-PORTAL-SECRET.
- REF-ANDROID-CREDENTIAL-MANAGER.
- REF-W3C-PASSKEY-ENDPOINTS.
- REF-ANDROID-PASSKEY-CREATE.
- REF-APPLE-PASSKEY-REGISTRATION-REQUEST.
- REF-APPLE-CREDENTIAL-EXPORT-MANAGER.
- REF-APPLE-CREDENTIAL-IMPORT-MANAGER.
- REF-FIDO-CXF.
- REF-RFC7636-PKCE.
- REF-OPENAI-APPS-SDK-AUTH.
- REF-RFC9728-PROTECTED-RESOURCE-METADATA.
- REF-RFC8628-DEVICE-GRANT.
- REF-OPENID-CIBA-CORE.
- REF-RFC9449-DPOP.
- REF-RFC8705-OAUTH-MTLS.
- REF-RFC6749-OAUTH-AUTHZ-FRAMEWORK.
- REF-RFC8707-RESOURCE-INDICATORS.
- REF-RFC9396-RICH-AUTHORIZATION-REQUESTS.
- REF-RFC7662-TOKEN-INTROSPECTION.
- REF-OPENID-CONNECT-CORE.
- REF-W3C-FEDCM.
- REF-OPENAI-APPS-SDK-STATE.
- REF-MCP-ENTERPRISE-MANAGED-AUTH.
- REF-OPENID-CONNECT-SESSION.
- REF-RFC7009-TOKEN-REVOCATION.
- REF-OPENID-RP-INITIATED-LOGOUT.
