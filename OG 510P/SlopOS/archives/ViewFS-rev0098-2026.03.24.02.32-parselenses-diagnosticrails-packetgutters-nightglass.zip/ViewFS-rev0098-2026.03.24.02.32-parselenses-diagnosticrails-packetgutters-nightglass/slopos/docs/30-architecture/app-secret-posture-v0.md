# D-APPSECRET posture v0 (minimal app-scoped seed; not a vault)

Purpose: pin an **implementable Phase 1** meaning for D-APPSECRET so application secrets stay small, explicit, and reviewable.
It narrows a tempting high-entropy seam into one thing: a per-application seed for local protection, not a general secret inventory.

This doc is intentionally narrow: it does **not** design a password manager, a shared credential store, a named key/value secret API, or a cross-application escrow system. The surrounding auth/credential-mediation cuts are indexed in `auth-mediation-boundary-index.md` so `portal.secret` does not drift back into browser/login/account folklore by adjacency.

## Posture (v0)

1) **No ambient secret constructors**
   - If D-APPSECRET is enabled, post-init components obtain application secret material only via `portal.secret`.
   - There is no ambient “lookup secret by name” syscall, environment convention, keyring side channel, or host helper bypass.
   - The seam remains fail-closed behind `cfg.params.lane.portal.secret`.

2) **Not a vault or named-secret inventory**
   - D-APPSECRET is a **minimal app-seed seam**, not D-VAULT.
   - Companion ingress boundary: `appsecret-secret-ingress-boundary-v0.md` additionally pins `portal.secret` as **provider-issued app-seed issuance only**, not a portable password/API-key/OAuth-token paste/store or account-linking seam.
   - Companion credential-enrollment boundary: `credential-enrollment-boundary-v0.md` additionally pins adjacent local-login flows as **not** yielding a portable credential-enrollment / passkey-registration control seam on `portal.secret` or adjacent approval surfaces.
   - Companion credential-exchange boundary: `credential-exchange-boundary-v0.md` additionally pins adjacent local-login flows as **not** yielding a portable credential-exchange / password-manager migration seam on `portal.secret` or adjacent approval surfaces.
   - Companion auth-continuation boundary: `auth-continuation-export-boundary-v0.md` additionally pins adjacent local-login flows as **not** yielding portable pending-auth / continuation-handle semantics on `portal.secret` or adjacent approval surfaces.
   - Companion auth-result boundary: `auth-result-export-boundary-v0.md` additionally pins adjacent local-login flows as **not** yielding a portable authorization-code/token-set/callback-result export seam on `portal.secret` or adjacent approval surfaces.
   - Companion auth-proof boundary: `auth-proof-export-boundary-v0.md` additionally pins adjacent local-login flows as **not** yielding a portable proof-of-possession / auth-assertion export seam on `portal.secret` or adjacent approval surfaces.
   - Companion authorization-context boundary: `authorization-context-export-boundary-v0.md` additionally pins adjacent local-login flows as **not** yielding a portable granted-scope / resource-indicator / authorization-details / entitlement export seam on `portal.secret` or adjacent approval surfaces.
   - Companion identity-claim boundary: `identity-claim-export-boundary-v0.md` additionally pins adjacent local-login flows as **not** yielding a portable subject/email/profile/account-identity export seam on `portal.secret` or adjacent approval surfaces.
   - Companion account-binding boundary: `account-binding-export-boundary-v0.md` additionally pins adjacent local-login/linking flows as **not** yielding a portable linked-account / connected-account / default-account export seam on `portal.secret` or adjacent approval surfaces.
   - Companion login-state boundary: `login-state-export-boundary-v0.md` additionally pins adjacent local-login flows as **not** yielding a portable signed-in/login-status/session-state/account-availability export seam on `portal.secret` or adjacent approval surfaces.
   - Companion auth-teardown boundary: `auth-teardown-boundary-v0.md` additionally pins adjacent local-login flows as **not** yielding a portable logout/disconnect/revocation control seam on `portal.secret` or adjacent approval surfaces.
   - Phase 1 does **not** claim collections, items, labels, attribute search, arbitrary secret names, enumeration, import/export, or cross-app sharing.
   - If we need password-manager / shared-secret semantics later, they come back as D-VAULT work with new policy and evidence hooks rather than widening `portal.secret` prose.

3) **Profile-scoped by default; wider scopes are explicit**
   - `scope="profile"` is the expected default v0 posture.
   - `scope="user"` and `scope="device"` are explicit widenings that policy may deny or clamp.
   - Requestors do not get to treat wider scope as ambient or implied by install origin.

4) **Rotation is explicit and transcript-visible**
   - Rotation is a separate, policy-gated act, not a silent background behavior.
   - Phase 1 does **not** claim automatic rotation timers, opportunistic epoch bumps, or hidden “rotate on next use” behavior.
   - If rotation occurs, the epoch bump is monotonic and visible through CH-APPSECRET / receipts.

5) **Handle-only is the stricter posture; bytes remain compatibility-only**
   - `delivery="handle"` is the stricter posture because key material remains non-exportable and composes with D-CRYPTOSVC.
   - `delivery="bytes"` remains the compatibility baseline when the platform chooses to support it, but it stays tightly bounded and must not leak into CH-LOG/CH-RECEIPT/CH-ARGV/CH-ENV.
   - D-APPSECRET is for **local confidentiality/integrity seeds**, not for broad crypto-agent semantics.

6) **No ACP automation kind in Phase 1**
   - `portal.secret.*` remains **manual-only v0** on the ACP surface.
   - Phase 1 does **not** introduce a `portal.secret.request` automation kind.
   - Any future automation path must first answer replay, rotation, scope-widening, and transcript/redaction questions explicitly.

7) **Externally visible state remains ordered inside the portal**
   - Even without an ACP kind in v0, secret issuance and rotation state are **ordered** within the portal because `(origin, scope, purpose, rotation_epoch)` live there.
   - Serialization boundary: `svc:portal.secret`.
   - Any future ACP surface must keep conflict keys and retry semantics explicit rather than inheriting hidden state from provider callbacks or caches.

8) **Sealed compat remains killable and non-ambient**
   - Any Foreign Cell use of app secrets must flow through explicit adapters and `portal.secret`; compat runtimes do not gain an ambient host keyring or secret-service channel.
   - The seam remains policy-killable and review-bound.

## Phase 1 non-goals (explicitly deferred)

- **No named secret collections/items/labels/attribute queries** under D-APPSECRET.
- **No cross-app sharing/import/export** or “open another app’s secret” flow.
- **No silent auto-rotation** tied to jobs/background activity.
- **No ACP automation kind** for `portal.secret.*` in Phase 1.
- **No claim that D-APPSECRET replaces D-VAULT** or a full credential manager.

## Wiring

- Decision surface: `decision-map.md` (D-APPSECRET).
- Schema:
  - `app-secret-descriptor-schema-v0.md` (CH-APPSECRET v0)
  - `auth-mediation-boundary-index.md` (closed discovery surface for the adjacent auth/credential mediation cuts)
  - `appsecret-secret-ingress-boundary-v0.md`
  - `credential-enrollment-boundary-v0.md`
  - `credential-exchange-boundary-v0.md`
  - `auth-continuation-export-boundary-v0.md`
  - `auth-result-export-boundary-v0.md`
  - `auth-proof-export-boundary-v0.md`
  - `authorization-context-export-boundary-v0.md`
  - `identity-claim-export-boundary-v0.md`
  - `account-binding-export-boundary-v0.md`
  - `login-state-export-boundary-v0.md`
  - `auth-teardown-boundary-v0.md`
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.secret.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.secret`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-APPSECRET-1..3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-APPSECRET-VALIDATE, PO-APPSECRET-ENF)
- Adjacent boundary: under `ext.microvm`, generation change does **not** imply blanket deletion/rotation of all app seeds, but freshness-bound attestation/release caches that protected their delivery must still be reacquired explicitly (`microvm-attestation-reacquire-posture-v0.md`). Reusable warm-start templates are cut before unsealed secret material enters guest memory, so post-delivery snapshots do not become ordinary fan-out bases (`microvm-template-snapshot-cut-posture-v0.md`).

CI drift gate:
- `tools/check_appsecret_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “minimal seed / not a vault / no silent auto-rotation / no ACP automation” constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-SECRET.
- REF-ANDROID-KEYSTORE.
- REF-SECRET-SERVICE-SPEC.
