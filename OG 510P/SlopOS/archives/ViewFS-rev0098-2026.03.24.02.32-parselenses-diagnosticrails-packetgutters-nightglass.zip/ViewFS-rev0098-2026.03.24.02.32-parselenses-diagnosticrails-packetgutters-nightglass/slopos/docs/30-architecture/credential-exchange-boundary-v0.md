# Credential-exchange boundary v0

Purpose: freeze one narrow **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable credential-exchange, password-manager migration, or passkey-portability surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how credential import/export and cross-provider portability may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the user authenticated locally” into a portable password/passkey migration broker.

## Posture (v0)

1. **No portable credential-exchange seam in v0**
   - Phase 1 does **not** export a portable `export_credentials`, `import_credentials`, `export_passkeys`, `import_passkeys`, `credential_exchange_request`, `credential_transfer_request`, `password_manager_export`, `password_manager_import`, `passkey_portability`, `credential_migration`, or equivalent credential-exchange/import-export handoff on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, auth providers, password managers, and credential managers may maintain provider-local import/export UX and provider-local migration state, but that lifecycle remains provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user finished a local sign-in flow” as permission to export a saved password/passkey, import credentials from another manager, or orchestrate a cross-provider migration across components/cells.

2. **Credential exchange is not a generic secret object, approval, or receipt outcome**
   - Importing or exporting credentials may be security-sensitive, but it is not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because a provider completed a local ceremony.
   - **D-APPSECRET** remains about provider-derived app seeds, not about returning password-manager export payloads, passkey-portability blobs, migration session handles, or import tickets.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about claiming that a user exported/imported passwords, passkeys, or federated credentials between providers.
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about returning “credentials migrated” as a generic reviewed outcome on existing seams.

3. **Explicit local login/credential mediation is not permission to import or export credentials**
   - Existing ecosystems distinguish local auth ceremonies from credential portability. Apple exposes dedicated `ASCredentialExportManager` and `ASCredentialImportManager` APIs for exchanging passkeys/passwords with other apps, and Apple’s passkeys guidance separately calls out secure import/export and passkey-management endpoints. FIDO’s Credential Exchange Format likewise treats credential migration as a dedicated provider-to-provider exchange format with explicit orchestrating-party requirements rather than as harmless login residue.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user complete a sign-in flow, but that does **not** justify returning credential-export/import control, migration payloads, or provider-to-provider exchange handles on existing generic seams.
   - If a future product shape needs reviewed credential portability or password-manager migration brokerage, it must return RFC-first with its own authority object, transfer/privacy rules, replay/duplication model, trusted-UI story, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to credential migration or passkey portability**
   - Agent tooling, shells, compat cells, and wrappers may propose “move my passkeys/passwords,” but they must not silently start export/import ceremonies, invoke credential-manager migration UX, or relay provider-specific credential-exchange flows back as generic workflow results.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient credential-migration channels through paths, env, loopback helpers, hidden provider bridges, inherited provider sessions, or implicit network reachability.
   - It also keeps **D-LLM** honest: a model may propose a migration workflow, but it does not gain portable passkey/password export/import authority merely because the user authenticated somewhere locally.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local password-manager / credential-manager internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed credential-portability seam must state its own conflict keys, commutativity preconditions, serialization point, transfer/storage/privacy rules, trusted-UI path, replay boundaries, and evidence story explicitly rather than inheriting folklore from password managers, passkey portability UX, or provider SDKs.

## Phase 1 non-goals (explicitly deferred)

- No portable `export_credentials` / `import_credentials` / `export_passkeys` / `import_passkeys` / `credential_exchange_request` / `credential_transfer_request` / `password_manager_export` / `password_manager_import` / `passkey_portability` export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded reusable credential-migration or password-manager portability authority.
- No shell/helper fallback that quietly converts local sign-in into cross-provider credential export/import or passkey portability authority.
- No new CH-ACP kind or conflict-key family for credential-exchange brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenience mistake after the recent browser/result/proof/context/identity/state/teardown/enrollment cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” “vault refs are not credential mediation,” and “local sign-in is not token/session/account/proof export or credential-enrollment control,” the next convenience instinct is obvious: “fine, then just export/import the credential for me.” That sounds narrower than handing over a token set, but in practice it still recreates a generic ambient credential broker through password/passkey migration and provider-to-provider portability flows that are difficult to reason about across product shapes.

Pinning the boundary now keeps SlopOS from quietly turning reviewed local login mediation into portable credential-exchange authority. It also leaves future work a clean choice: if the system ever needs explicit password-manager portability or passkey migration brokerage, it can arrive as a small RFC-first seam with exact transfer, privacy, replay, and evidence semantics rather than as folklore smeared across launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local password-manager and passkey-portability UX, but that does not standardize credential import/export control as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake password/passkey migration brokers they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local auth ceremonies where useful without promising a general credential import/export substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user authenticated locally” with permission to export/import passkeys or password-manager entries; reviewed credential-portability workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_credential_exchange_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable credential-exchange seam / credential exchange is not a generic secret object or receipt outcome / explicit login mediation is not permission to import or export credentials / no hidden credential-migration fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-626**).

## References

- REF-APPLE-PASSKEYS.
- REF-APPLE-CREDENTIAL-EXPORT-MANAGER.
- REF-APPLE-CREDENTIAL-IMPORT-MANAGER.
- REF-FIDO-CXF.
