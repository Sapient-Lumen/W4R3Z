# Auth-continuation export boundary v0 (no portable pending-auth / continuation-handle export seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable pending-auth, continuation-handle, or decoupled-auth progression surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how pending-auth state and auth-continuation artifacts may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the user started or completed a login locally” into a portable request-resume / poll / callback-state broker.

## Posture (v0)

1. **No portable auth-continuation export seam in v0**
   - Phase 1 does **not** export a portable `state`, `nonce`, `pkce_code_verifier`, `code_verifier`, `code_challenge`, `device_code`, `user_code`, `verification_uri`, `verification_uri_complete`, `auth_req_id`, `interaction_handle`, `continuation_handle`, `polling_handle`, `pending_auth`, `pending_login`, `auth_transaction`, or equivalent pending-auth / continuation-handle handoff on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, auth providers, authenticators, and credential managers may maintain provider-local request state for a concrete login or account-linking flow, but that state remains provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user started or completed a local sign-in flow” as permission to return a reusable pending-auth handle, polling token, PKCE verifier, device-flow code bundle, or equivalent continuation artifact across components/cells.

2. **Pending-auth handles are not generic secret objects, approvals, or receipt outcomes**
   - Auth-continuation artifacts may be sensitive or operationally important, but they are not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because they matter to an auth provider.
   - **D-APPSECRET** remains about provider-derived app seeds, not about returning PKCE verifier material, device-flow codes, verification URLs, CIBA request handles, or callback-state tuples.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about claiming that a user has an outstanding login transaction or that a caller may resume/poll an authentication ceremony elsewhere.
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about returning pending-auth handles or “continue login later” artifacts as the outcome of local approval.

3. **Explicit local login/credential mediation is not permission to export pending-auth state or continuation handles**
   - Existing ecosystems distinguish concrete auth progression handles from generic login completion. RFC 7636 defines PKCE around an explicit `code_verifier` / `code_challenge` pair for one authorization-code flow. RFC 8628 defines device authorization around explicit `device_code`, `user_code`, and verification URI artifacts for one constrained-input flow. OpenID CIBA defines a distinct `auth_req_id` for polling a specific backchannel authentication request.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user begin or complete a sign-in flow, but that does **not** justify returning request-state artifacts, polling handles, verifier material, or equivalent continuation state on existing generic seams.
   - If a future product shape needs reviewed auth-continuation brokerage, it must return RFC-first with its own authority object, replay/expiry model, trusted-UI story, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to PKCE/device/CIBA continuation relay**
   - Agent tooling, shells, compat cells, and wrappers may propose “continue login” or “finish linking this account,” but they must not silently start relaying PKCE verifier material, device-flow codes, verification URLs, callback-state tuples, backchannel request ids, or equivalent pending-auth handles back as generic workflow results.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient auth-continuation channels through paths, env, loopback helpers, hidden browser/provider bridges, inherited sessions, or implicit network reachability.
   - It also keeps **D-LLM** honest: a model may propose an auth workflow, but it does not gain portable “resume this login elsewhere” authority merely because a user authenticated or began authenticating somewhere locally.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local auth/browser/credential-manager internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed auth-continuation brokerage seam must state its own conflict keys, commutativity preconditions, serialization point, expiry/replay rules, trusted-UI bindings, and evidence story explicitly rather than inheriting folklore from PKCE helpers, device-flow SDKs, or backchannel-auth middleware.

## Phase 1 non-goals (explicitly deferred)

- No portable `state` / `nonce` / `pkce_code_verifier` / `code_verifier` / `device_code` / `user_code` / `verification_uri` / `verification_uri_complete` / `auth_req_id` / `continuation_handle` export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded a reusable pending-auth, polling, or request-resume artifact.
- No shell/helper fallback that quietly converts local sign-in into PKCE/device/backchannel continuation relay authority.
- No new CH-ACP kind or conflict-key family for auth-continuation brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenience mistake after the recent enrollment/exchange/result/proof/context/identity/state/teardown cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” “vault refs are not credential mediation,” and “local sign-in is not token/proof/session/account/credential-portability export,” the next convenience instinct is obvious: “fine, then just hand the tool the pending auth handle so it can finish later.” That sounds smaller than returning a token set, but in practice it still recreates a generic ambient auth bridge through PKCE verifiers, device-flow codes, verification URLs, and backchannel polling handles that are difficult to reason about across product shapes.

Pinning the boundary now keeps SlopOS from quietly turning reviewed local login mediation into portable pending-auth or continuation-handle authority. It also leaves future work a clean choice: if the system ever needs explicit auth-continuation brokerage, it can arrive as a small RFC-first seam with exact expiry, replay, privacy, and evidence semantics rather than as folklore smeared across launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local login/account-linking UX, but that does not standardize PKCE verifier tuples, device-flow codes, verification URLs, or backchannel request handles as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake auth-resume brokers, polling helpers, or callback-state relays they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local auth ceremonies where useful without promising a general pending-auth export/import substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user started or completed a login locally” with permission to receive a PKCE verifier, device-flow bundle, or equivalent pending-auth artifact; reviewed auth-resume workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_auth_continuation_export_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable pending-auth / continuation-handle export seam / pending-auth handles are not generic secret objects or receipt outcomes / explicit login mediation is not permission to export pending-auth state / no hidden PKCE-device-CIBA continuation relay fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-627**).

## References

- REF-RFC7636-PKCE.
- REF-RFC8628-DEVICE-GRANT.
- REF-OPENID-CIBA-CORE.
- REF-OPENID-CONNECT-CORE.
