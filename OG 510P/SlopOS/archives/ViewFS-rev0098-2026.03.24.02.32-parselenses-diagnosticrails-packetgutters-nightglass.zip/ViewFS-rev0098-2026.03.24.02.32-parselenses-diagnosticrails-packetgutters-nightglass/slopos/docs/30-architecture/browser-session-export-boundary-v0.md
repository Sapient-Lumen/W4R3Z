# Browser-session export boundary v0 (no portable cookie-jar / authenticated-browser-session export seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable browser-session export, cookie-jar handoff, authenticated-profile handle, or replayable web-session blob on any existing SlopOS authority surface.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how existing login/credential/browser state may be interpreted when agent tooling, portals, vaults, or compat wrappers try to turn “the user is signed in somewhere locally” into a portable authority object.

## Posture (v0)

1. **No portable browser-session export seam in v0**
   - Phase 1 does **not** export a portable `browser_session`, `authenticated_browser_session`, `cookie_jar`, `session_cookies`, `cookie_store_export`, `profile_export`, `session_export`, `session_resume_blob`, `authenticated_tab`, `browser_state_handle`, `web_session_backup`, or equivalent browser-session handoff/result on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, and auth providers may maintain local browser state, but that state remains provider-local live state rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “a user signed in through local mediation” as permission to export cookies, clone browser state, or pass an authenticated web session across components/cells.

2. **Browser session state is not a generic secret object or receipt outcome**
   - Cookies, browser profiles, federated-login session state, and site-specific authenticated browser state may be security-sensitive, but they are not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because they matter operationally.
   - **D-VAULT** remains about provider-owned secret objects and bounded ops, not about portable browser-state capture or session replay.
   - **D-POWERBOX / IF-CONSENT** remain about explicit local approval over exact action bytes, not about returning a browser-session artifact as the authority result.

3. **Explicit login/credential mediation is not permission to exfiltrate or replay browser state**
   - Existing ecosystems distinguish user-mediated sign-in from exportable browser session state. RFC 8252 requires native-app OAuth flows to use an external user-agent and explains that embedded user-agents are unsafe because host apps can capture credentials and copy session cookies. Chrome Auth Tab and platform browser-auth APIs provide browser-managed authentication flows with app callbacks/results, but they do not turn browser session state into a generic cross-component cookie-export substrate. DBSC goes further and treats protection against session export as the security goal, binding sessions to device-held keys rather than blessing cookie portability.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user complete a sign-in flow, but that does **not** justify exporting cookies, authenticated browser profiles, or replay blobs to the requester/agent.
   - If a future product shape needs reviewed browser-session continuity, it must return RFC-first with its own state model, trusted-UI story, redaction/evidence plan, and authority object semantics rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to browser-profile scraping or cookie reuse**
   - Agent tooling, shells, compat cells, and wrappers may propose “open this login page” or “use local login state,” but they must not silently scrape browser profiles, import/export cookie stores, forward authenticated browser state, or repackage browser-session artifacts as generic vault data, app secrets, or approval outcomes.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient web-session channels through paths, env, browser-profile mounts, or hidden host integration.
   - It also keeps **D-LLM** honest: a model may propose an auth workflow, but it does not gain portable browser-session authority as the result of that proposal.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: local provider/browser/session internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed browser-session or credential-continuity seam must state its own conflict keys, commutativity preconditions, serialization point, trusted-UI bindings, replay boundaries, and evidence story explicitly rather than inheriting folklore from browser profiles, cookie stores, or auth SDKs.

## Phase 1 non-goals (explicitly deferred)

- No portable cookie-jar export/import or authenticated-browser-session handle on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded reusable browser session state.
- No shell/helper fallback that quietly converts local sign-in state into browser-profile scraping, cookie export, or session replay authority.
- No new CH-ACP kind or conflict-key family for browser-session continuity in v0.

## Why this is worth pinning

This is a small entropy cost that closes the remaining easy mistake after the last few cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” and “vault refs are not credential mediation,” the next convenience instinct is obvious: “fine, then just reuse the user’s browser session.” That sounds pragmatic, but it quietly recreates ambient authority through cookie jars, browser-profile state, and replayable login blobs. Those are harder to reason about than explicit secret refs because they are broad, stateful, site-specific, and often invisible in transcripts.

Pinning the boundary now keeps SlopOS from quietly turning reviewed login mediation into portable browser-session export authority. It also gives future work a better direction: if we later need stronger web-session continuity, the archive should favor explicit device-/provider-bound proofs and dedicated authority objects over raw session copying.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich browser-auth UX locally, but that does not standardize cookie export or authenticated-browser-profile handoff as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake browser-session portability or cookie-forwarding machinery they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local sign-in where needed without promising a general browser-session export/import substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user completed a login locally” with permission to receive a cookie jar, authenticated browser profile, or replayable session blob; reviewed auth continuity must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_browser_session_export_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable browser-session export seam / browser session state is not a generic secret object or receipt outcome / explicit login mediation is not permission to replay browser state / no hidden agent-shell-compat fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-617**).

## References

- REF-RFC8252-NATIVE-APPS.
- REF-CHROME-AUTH-TAB.
- REF-CHROME-EPHEMERAL-CUSTOM-TABS.
- REF-W3C-DBSC.
