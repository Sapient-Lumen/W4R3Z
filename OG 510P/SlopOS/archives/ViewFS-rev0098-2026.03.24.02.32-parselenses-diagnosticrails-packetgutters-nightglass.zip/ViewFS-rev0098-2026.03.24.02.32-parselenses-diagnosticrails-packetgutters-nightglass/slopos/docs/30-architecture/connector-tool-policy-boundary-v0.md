# D-LLM connector/tool-policy boundary v0 (no portable connector-admin or allowed-tool policy seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / tool-selection** seam: host-local or request-local connector/app/MCP tool policy does **not** become a portable connector-admin, enabled-tool, or allowed-tool surface on existing SlopOS seams.

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, and **no new conflict-key family**. It only narrows how explicit tool catalogs and current connector ecosystems may be interpreted.

This doc is an **intentional singleton** today. It is listed in `boundary-family-map.md` until a broader reviewed connector-admin family exists.

## Posture (v0)

1) **No portable connector/tool-policy export or admin seam in v0.**
   - Phase 1 does **not** export a portable `enabled_connectors`, `connected_servers`, `connector_enabled`, `enabled_tools`, `disabled_tools`, `allowed_tools`, `tool_permissions`, `tool_usage_limits`, `connector_refresh`, `refresh_tools`, `connector_policy`, or equivalent host policy artifact on **CH-ACP v0**, **CH-REQCTX v1**, existing `portal.*` families, or other reviewed effect surfaces.
   - Hosts, callers, shells, and providers may internally decide which connectors are linked, which remote MCP servers are enabled for one conversation, which tool subsets are exposed, and which usage limits apply, but that policy remains host-local or request-local rather than portable requester-visible substrate meaning.

2) **Explicit tool catalogs do not imply policy introspection or policy mutation.**
   - `llm-operations-posture-v0.md` already pins tool/resource/prompt catalogs to explicit local configuration and bounded discovery.
   - Seeing an explicit bounded tool list does **not** imply a portable right to ask “which connectors are available but disabled?”, “turn this tool on/off”, “refresh tool metadata”, “which usage limits are configured?”, or “what hidden connector policy chose this catalog?” on generic LLM/control surfaces.
   - Phase 1 therefore declines any generic connector-manager, app-details-page, or tool-permission admin meaning on D-LLM itself.

3) **Request-local tool filters stay request-local.**
   - Current ecosystems already expose host-local connector settings that toggle tools on/off and refresh metadata, and API-level request parameters that filter an MCP server to `allowed_tools` or read-only subsets.
   - SlopOS imports the narrow lesson only: these are caller/host policy knobs for one host UX or one request shape, not portable artifacts that tools, widgets, compat layers, or agents may rely on across providers or product shapes.
   - Phase 1 therefore does **not** reinterpret request-local `allowed_tools` style filtering as durable connector policy truth, transcript-stable entitlement, or portable server/tool-admin state.

4) **No hidden connector-admin scraping, reflection, or inference fallback.**
   - Agents, shells, widgets, compat cells, and wrappers must not silently scrape connector settings pages, app-management UIs, attachment menus, hidden tool lists, or provider-side draft/developer-mode panels to infer stable disabled-tool policy, hidden connector inventory, or usage-limit truth.
   - They must also not infer portable policy truth from omissions in the visible tool list, approval prompts, auth prompts, error text, or latency/failure patterns.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient connector-admin channels through paths, env, hidden browser helpers, implicit network reachability, or provider-specific settings APIs.

5) **Commutativity / conflict-key stance.**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt kind**.
   - Existing ordering remains where it already lives: explicit SlopOS action/approval/policy surfaces on one side, host-local connector settings and request-local tool filters on the other.
   - Any future reviewed connector-admin or tool-policy seam must state its own conflict keys, commutativity preconditions, serialization point, kill switches, and evidence story explicitly rather than inheriting folklore from provider settings pages or request wrapper convenience flags.

## Phase 1 non-goals (explicitly deferred)

- No portable `enabled_connectors` / `connected_servers` / `connector_enabled` / `enabled_tools` / `disabled_tools` / `allowed_tools` export seam on D-LLM or existing reviewed portals.
- No portable “toggle tool on/off”, “refresh connector metadata”, or “set tool usage limit” control seam on generic LLM/control surfaces.
- No transcript-stable rule that a visible tool catalog reveals the full hidden connector inventory, disabled-tool inventory, or host-side policy that produced it.
- No shell/helper fallback that quietly turns host connector settings, developer-mode panels, or request wrapper flags into a generic connector-admin API.

## Why this is worth pinning

The archive already says the LLM sees only explicit bounded catalogs and gains no hidden install/discovery plane. The next convenience instinct is therefore obvious: “fine, then at least let the tool or agent ask which connectors are enabled, which tools are disabled, or what `allowed_tools` / usage-limit policy is in force.” Current ecosystems make that temptation real: ChatGPT developer tooling lets hosts toggle tools on or off and refresh metadata; remote MCP connector UIs let users enable/disable specific tools and set usage limits; and API wrappers can pass request-local MCP tool filters such as `allowed_tools` or read-only subsets.

That still does **not** mean SlopOS should standardize connector-admin or tool-policy semantics on D-LLM. Pinning the boundary now keeps explicit tool catalogs honest: the model can see the tools it is allowed to propose with, but it does not gain a portable introspection/control plane for the host-side policy that shaped that catalog.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still have rich connector settings and app-management UI, but generic LLM/control surfaces do not standardize host-local toggle/refresh/usage-limit policy as requester-visible substrate truth.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting a fake connector-admin API or portable policy-inspection plane they typically do not want to support.
- **Embedded / separation appliance (C):** appliance builds can expose tightly curated tool catalogs without promising a general connector-management surface.
- **Agent/automation OS (D):** agents can reason over the explicit tools in scope, but they cannot treat host connector settings, hidden disabled-tool inventory, or request-local `allowed_tools` filters as durable portable authority.

## Singleton status (Phase 1)

This doc remains an **intentional singleton** in `boundary-family-map.md` because **no broader multi-doc boundary family exists yet** on this seam.

If a second closely related boundary doc appears, introduce exactly one companion `*-boundary-index.md` in the **same revision** rather than letting singleton status linger by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_connector_tool_policy_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable connector/tool-policy export or admin seam / explicit tool catalogs do not imply policy introspection or mutation / request-local tool filters stay request-local / no hidden connector-admin scraping or inference fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-659**).

## References

- REF-OPENAI-API-DEVELOPER-MODE.
- REF-OPENAI-APPS-SDK-CONNECT-CHATGPT.
- REF-OPENAI-API-MCP-CONNECTORS.
- REF-MCP-REMOTE-CONNECTORS.
