# Credential-enrollment boundary v0 (no portable credential-enrollment / passkey-registration control seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable credential-enrollment, passkey-registration, or authenticator-provisioning control surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how credential-enrollment actions may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the user authenticated locally” into a portable passkey/security-key registration or credential-provisioning broker.

## Posture (v0)

1. **No portable credential-enrollment control seam in v0**
   - Phase 1 does **not** export a portable `create_passkey`, `register_passkey`, `create_credential`, `credential_registration_request`, `enroll_authenticator`, `register_security_key`, `passkey_upgrade`, `credential_provision`, or equivalent credential-enrollment control on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, auth providers, authenticators, and credential managers may maintain provider-local registration UX and provider-local credential stores, but that lifecycle remains provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user finished a local sign-in flow” as permission to create a passkey, enroll a security key, provision a new relying-party credential, or upgrade an account into a new credential form across components/cells.

2. **Credential enrollment is not a generic secret object, approval, or receipt outcome**
   - Creating or enrolling a credential may be security-sensitive, but it is not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because a provider completed a local ceremony.
   - **D-APPSECRET** remains about provider-derived app seeds, not about returning passkey-registration requests, authenticator-creation results, or provider-managed enrollment handles.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about claiming that a user registered a new passkey, security key, or federated account credential.
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about returning “credential created” as a generic reviewed outcome on existing seams.

3. **Explicit local login/credential mediation is not permission to register or provision credentials**
   - Existing ecosystems distinguish local auth ceremonies from credential creation/provisioning. WebAuthn defines credential creation as an explicit relying-party-bound API with user consent. Android Credential Manager exposes passkey creation through a dedicated create flow using server-provided options. Apple AuthenticationServices exposes dedicated public-key credential registration requests rather than treating passkey enrollment as a byproduct of generic sign-in.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user complete a sign-in flow, but that does **not** justify returning passkey-registration control, authenticator-enrollment control, or equivalent credential-provisioning authority on existing generic seams.
   - If a future product shape needs reviewed credential enrollment or credential-upgrade brokerage, it must return RFC-first with its own authority object, relying-party matching rules, replay/duplication model, trusted-UI story, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to passkey registration, authenticator enrollment, or credential-upgrade brokerage**
   - Agent tooling, shells, compat cells, and wrappers may propose “create a passkey” or “upgrade this account,” but they must not silently start credential-registration ceremonies, invoke authenticator-enrollment UX, or relay provider-specific create-credential flows back as generic workflow results.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient credential-enrollment channels through paths, env, loopback helpers, hidden browser/authenticator bridges, inherited provider sessions, or implicit network reachability.
   - It also keeps **D-LLM** honest: a model may propose an enrollment workflow, but it does not gain portable passkey-registration or authenticator-provisioning authority merely because the user authenticated somewhere locally.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local browser/authenticator/credential-manager internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed credential-enrollment brokerage seam must state its own conflict keys, commutativity preconditions, serialization point, relying-party bindings, trusted-UI path, replay boundaries, and evidence story explicitly rather than inheriting folklore from passkey managers, browser upgrade prompts, or authenticator SDKs.

## Phase 1 non-goals (explicitly deferred)

- No portable `create_passkey` / `register_passkey` / `create_credential` / `credential_registration_request` / `enroll_authenticator` / `register_security_key` / `passkey_upgrade` export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded reusable credential-enrollment or passkey-registration control.
- No shell/helper fallback that quietly converts local sign-in into passkey/security-key enrollment or account-upgrade authority.
- No new CH-ACP kind or conflict-key family for credential-enrollment brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenience mistake after the recent browser/result/proof/context/identity/state/teardown cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” “vault refs are not credential mediation,” and “local sign-in is not token/session/account/proof export,” the next convenience instinct is obvious: “fine, then just register the passkey locally and hand the app the result.” That sounds narrower than handing over a token set, but in practice it still recreates a generic ambient credential broker through passkey creation, security-key enrollment, and account-upgrade flows that are difficult to reason about across product shapes.

Pinning the boundary now keeps SlopOS from quietly turning reviewed local login mediation into portable credential-enrollment control authority. It also leaves future work a clean choice: if the system ever needs explicit credential-enrollment brokerage, it can arrive as a small RFC-first seam with exact relying-party, replay, privacy, and evidence semantics rather than as folklore smeared across launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local credential-creation UX, but that does not standardize passkey/security-key enrollment control as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake passkey-enrollment or authenticator-provisioning brokers they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local auth ceremonies where useful without promising a general credential-enrollment / passkey-registration substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user authenticated locally” with permission to create a new passkey, enroll a security key, or upgrade an account into a new credential form; reviewed enrollment workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_credential_enrollment_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable credential-enrollment control seam / enrollment is not a generic secret object or receipt outcome / explicit login mediation is not permission to register or provision credentials / no hidden enrollment-broker fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-625**).

## References

- REF-WEBAUTHN-3.
- REF-W3C-PASSKEY-ENDPOINTS.
- REF-ANDROID-PASSKEY-CREATE.
- REF-APPLE-PASSKEY-REGISTRATION-REQUEST.
