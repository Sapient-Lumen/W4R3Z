# Auth-link UI trigger boundary v0 (no hidden account-linking / auth-broker trigger plane)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-PLUMB** seam: OAuth linking metadata and auth challenges may cause the host to offer **local account-linking UI**, but they do **not** create a portable account-linking, account-choice, or auth-broker trigger surface on existing SlopOS authority seams.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how existing auth-link/auth-required material may be interpreted when agent tooling, widgets, portals, or compat wrappers try to turn “the tool says authentication is needed” into a portable authority surface.

## Posture (v0)

1. **No portable auth-link trigger seam in v0**
   - Phase 1 does **not** export a portable `link_account`, `connect_account`, `start_oauth`, `authenticate_tool`, `choose_account`, `reauthorize`, `show_login`, `show_oauth`, `auth_required`, `connected_account`, or equivalent auth-link trigger/control/result on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-AUTHZ v0**, **CH-VOL v0**, or **CH-PLUMBMSG v0**.
   - Tool `securitySchemes`, protected-resource metadata, `WWW-Authenticate` challenges, and runtime `_meta["mcp/www_authenticate"]` payloads may exist as provider-local descriptors/challenges that let the host decide whether to offer linking UI.
   - Those signals are therefore **challenge material only**, not requester-visible authority to make the host open login/account-linking UI on demand.

2. **Linking UI stays host-owned local mediation, not tool/widget-owned browser or account-choice authority**
   - A tool/server/widget may describe auth policy or return an auth challenge, but the host/provider decides whether, when, and how to present linking UI.
   - Existing challenge material does **not** grant direct browser-launch authority, callback registration, account chooser truth, password-manager/autofill/passkey semantics, or ambient credential relay.
   - This keeps the imported ecosystem feature honest: local linking may happen, but it stays **host-owned mediation** rather than a hidden app-controlled account broker.

3. **Auth challenges are not durable connected-state, identity, or approval truth**
   - A `401` / `WWW-Authenticate` / `_meta["mcp/www_authenticate"]` challenge only says the current request was unauthenticated or insufficiently authorized under provider policy.
   - It does **not** prove that the user has an account, which account is available, whether linking will succeed, which scopes were granted, or that some durable “connected app” state now exists.
   - Login-state, authorization-context, identity/profile, and auth-result meaning stay pinned separately by `login-state-export-boundary-v0.md`, `authorization-context-export-boundary-v0.md`, `identity-claim-export-boundary-v0.md`, and `auth-result-export-boundary-v0.md`.
   - **D-POWERBOX / IF-CONSENT** likewise remain about exact reviewed action approval, not about saying “this app is linked” or “this server may prompt for auth whenever it wants.”

4. **No hidden retry/orchestration fallback behind auth challenges**
   - Agent tooling, shells, widgets, and compat adapters may propose that the user link an account, but they must not silently spin hidden login retries, convert challenge state into a remembered permission toggle, or auto-retry privileged actions with ambient cached credentials outside explicit host/provider policy.
   - They must also not scrape auth-link prompts from rendered UI, infer durable connected-state from prior challenge outcomes, or smuggle account-broker semantics through generic workflow routing.
   - This keeps **sealed compat** honest: auth-linking remains killable by policy and must not create ambient callback, token, or connected-account channels through hidden browser helpers, paths/env, or implicit network reachability.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Challenge evaluation, linking-UI suppression/coalescing, and provider-local retry policy stay where they already live: inside host/provider auth machinery, not as a new transcript-stable SlopOS action language.
   - If successful linking later enables a real action, the downstream reviewed action/tool call owns its conflict keys, serialization point, and evidence story.

## Phase 1 non-goals (explicitly deferred)

- No portable account-linking / reconnect / reauthorize / choose-account trigger surface on D-LLM, D-POWERBOX, D-UICAP, or D-PLUMB.
- No portable `auth_required` / `connected` / `needs_link` truth artifact on generic workflow, secret, approval, or widget seams.
- No hidden fallback that turns auth challenges into silent browser launch, account-choice, or auto-retry authority.
- No new CH-ACP kind or conflict-key family for auth-linking/UI-trigger brokerage in v0.

## Why this is worth pinning

Current OpenAI Apps SDK auth docs explicitly say ChatGPT only shows its OAuth linking UI when the server both publishes the right metadata and returns runtime auth challenges, including `_meta["mcp/www_authenticate"]` for tool-level flows. That is a useful ecosystem feature, but it is also exactly the next ambiguity after the existing auth/result/login-state cuts: once the archive says “no hidden browser,” “no continuation export,” and “no auth-result export,” the next convenience instinct is to treat auth challenges as a generic connector/account-link broker.

Pinning the boundary now keeps the useful linking behavior while refusing that shortcut. SlopOS can support host-owned local linking mediation when product shapes need it, but the meaning remains small: auth challenges may request host mediation, not force a portable account-broker or durable connected-state plane into Phase 1.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still present rich local linking UX for tools/apps, but the challenge does not itself become portable account-linking, account-choice, or connected-state authority.
- **Cloud micro-VM substrate (B):** hosted profiles can surface bounded auth-required status where useful without promising a generic connector/account-broker substrate inside compute cells.
- **Embedded / separation appliance (C):** appliance builds can fail closed or map auth challenges to tightly bounded local mediation without importing broad browser/account-link folklore.
- **Agent/automation OS (D):** this is the highest-value case. Agents can observe that auth is needed, but they cannot directly trigger or own account-linking flows, infer durable connected-account state, or treat auth challenges as implicit permission to retry with ambient credentials.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/llm-operations-posture-v0.md`
- `docs/30-architecture/powerbox-posture-v0.md`
- `docs/30-architecture/plumb-posture-v0.md`
- `docs/70-llm-control/README.md`
- `docs/70-llm-control/llm-threats.md`
- `docs/00-meta/evidence-index.md`
- `docs/00-meta/bibliography.md`
- `tools/README.md`

## Evidence hook

- `tools/check_auth_link_ui_trigger_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable auth-link trigger seam / linking UI stays host-owned local mediation / auth challenges are not durable connected-state-identity-approval truth / no hidden retry-orchestration fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-657**).

## References

- REF-OPENAI-APPS-SDK-AUTH.
- REF-RFC9728-PROTECTED-RESOURCE-METADATA.
- REF-RFC8414-AS-METADATA.
