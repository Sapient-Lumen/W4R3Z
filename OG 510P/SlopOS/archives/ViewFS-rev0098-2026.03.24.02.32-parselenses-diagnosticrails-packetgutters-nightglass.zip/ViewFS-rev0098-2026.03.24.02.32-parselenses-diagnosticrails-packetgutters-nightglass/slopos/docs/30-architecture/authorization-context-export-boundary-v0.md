# Authorization-context export boundary v0 (no portable granted-scope / authorization-context export seam)

Purpose: pin one compact Phase-1 rule on the **D-LLM / D-POWERBOX / D-UICAP / D-APPSECRET / D-VAULT / D-PLUMB** seam: explicit local login or credential mediation does **not** create a portable granted-scope / resource-indicator / authorization-details / entitlement export surface on any existing SlopOS authority seam.

Status: Phase 1 boundary (tightening only).

This boundary is intentionally small. It introduces **no new schema family**, no new portal family, **no new ACP**, **no new conflict-key family**, and no new receipt kind. It only narrows how authorization context may be interpreted when agent tooling, portals, secret stores, or compat wrappers try to turn “the user completed a local auth flow” into a portable list of scopes, resources, grants, authorization details, or entitlements.

## Posture (v0)

1. **No portable authorization-context export seam in v0**
   - Phase 1 does **not** export a portable `scope`, `scopes`, `granted_scopes`, `scope_grants`, `resource`, `resources`, `resource_indicator`, `resource_indicators`, `authorization_details`, `grants`, `permissions`, `entitlements`, `granted_permissions`, `provider_capabilities`, `consented_access`, or equivalent granted-scope / resource / authorization-context handoff on **`portal.uri.*`**, **`portal.secret`**, **CH-SECRETREF v0**, **CH-SECRETPOL v0**, **CH-AUTHZ v0**, or **CH-VOL v0**.
   - Tools, shells, browsers, auth providers, and credential managers may maintain provider-local grant state and request-local knowledge about requested or granted scopes/resources, but that state remains provider-local or request-local rather than portable requester-visible substrate meaning.
   - Phase 1 therefore does **not** reinterpret “the user finished a local sign-in / consent flow” as permission to mint or return a reusable granted-scope / authorization-context result across components/cells.

2. **Granted scopes/resources are not a generic secret object, approval, or receipt outcome**
   - Granted scopes, authorization details, resource audiences, and provider-specific entitlements may be operationally important, but they are not promoted to generic vault material, app-secret ingress, or consent/receipt truth merely because they matter to downstream API use.
   - **D-APPSECRET** remains about provider-derived app seeds, not about returning `granted_scopes`, `resource_indicators`, `authorization_details`, or equivalent grant context.
   - **D-VAULT** remains about provider-owned secret objects under pinned policy, not about claiming that one exact authorization context was granted or remains valid.
   - **D-POWERBOX / IF-CONSENT** remain about exact reviewed action approval, not about returning granted-scope / entitlement inventories as the outcome of local approval.

3. **Explicit local login/credential mediation is not permission to mint or relay authorization context**
   - Existing ecosystems distinguish login completion from generic authorization-context export. OAuth 2.0 defines `scope` as an explicit authorization request/response parameter. Resource Indicators define explicit `resource` parameters for protected-resource targeting. Rich Authorization Requests define explicit `authorization_details` objects for fine-grained authorization context. Token Introspection defines an explicit endpoint that can return token metadata such as active state and scope to an authorized protected resource. The common lesson is narrow: granted authorization context is a first-class protocol artifact, not harmless residue of local login completion.
   - SlopOS imports the narrow lesson: explicit local mediation may help the user complete a sign-in or consent flow, but that does **not** justify returning `scope`, `granted_scopes`, `resource_indicators`, `authorization_details`, `permissions`, or equivalent granted-context material on existing generic seams.
   - If a future product shape needs reviewed authorization-context brokerage, it must return RFC-first with its own authority object, privacy model, freshness/replay story, trusted-UI bindings, conflict keys, and evidence plan rather than widening existing seams.

4. **No hidden agent / shell / compat fallback to grant scraping, entitlement probing, or consent-context relay**
   - Agent tooling, shells, compat cells, and wrappers may propose “open this login page” or “use local sign-in,” but they must not silently inspect IdP consent records, infer granted scopes from browser callbacks, scrape browser/account-manager grant UIs, call hidden introspection / metadata helpers, or relay provider-specific entitlement state back as generic outputs.
   - This keeps **sealed compat** honest: interop remains killable by policy and must not create ambient authorization-context channels through paths, env, hidden browser helpers, browser/profile stores, account-manager side APIs, or implicit network reachability.
   - It also keeps **D-LLM** honest: a model may propose an auth workflow, but it does not gain portable granted-scope / authorization-context authority merely because the user authenticated somewhere locally.

5. **Commutativity / conflict-key stance**
   - This boundary introduces **no new externally visible action family**, **no new ACP kind**, **no new conflict-key family**, and **no new receipt shape**.
   - Existing ordering remains where it already lives: provider-local browser/auth/account/grant internals on one side, explicit SlopOS actions/receipts on the other.
   - Any future reviewed authorization-context brokerage seam must state its own conflict keys, commutativity preconditions, serialization point, freshness model, trusted-UI bindings, privacy boundaries, and evidence story explicitly rather than inheriting folklore from OAuth response parameters, consent screens, or provider entitlement helpers.

## Phase 1 non-goals (explicitly deferred)

- No portable `scope` / `granted_scopes` / `resource_indicators` / `authorization_details` / `permissions` / `entitlements` export/import seam on D-PLUMB, D-APPSECRET, D-VAULT, D-POWERBOX, or D-LLM.
- No transcript-stable statement that an approval, secret read, URI launch, or local login flow also yielded reusable granted-scope / authorization-context material.
- No shell/helper fallback that quietly converts local sign-in into grant scraping, consent-summary scraping, or provider-entitlement relay authority.
- No new CH-ACP kind or conflict-key family for authorization-context brokerage in v0.

## Why this is worth pinning

This is a small entropy cost that closes the next convenient mistake after the recent browser/auth-result/identity/login-state/teardown cuts. Once the archive says “no hidden browser,” “no generic secret-ingress seam,” “vault refs are not credential mediation,” “local sign-in is not browser-session export,” “local sign-in is not auth-result export,” “local sign-in is not identity-claim export,” “local sign-in is not login-state export,” and “local sign-in is not auth-teardown control,” the next convenience instinct is obvious: “fine, then just tell the tool which scopes/resources/permissions the user granted.” That sounds narrower than handing over a token set or account profile, but in practice it still recreates a generic portable privilege surface through granted-scope and entitlement artifacts that are difficult to reason about across product shapes and privacy regimes.

Pinning the boundary now keeps SlopOS from quietly turning reviewed local login mediation into portable authorization-context export authority. It also leaves future work a clean choice: if the system ever needs explicit grant-context brokerage, it can arrive as a small RFC-first seam with exact freshness, privacy, and evidence semantics rather than as folklore smeared across launch, approval, and secret surfaces.

## Profile effect (A–D)

- **Secure workstation (A):** workstation builds may still use rich local sign-in UX, but that does not standardize granted-scope / entitlement return as requester-visible substrate meaning.
- **Cloud micro-VM substrate (B):** hosted profiles avoid inheriting fake grant-broker or “what scopes does the user have?” helper machinery they usually do not want to support.
- **Embedded / separation appliance (C):** appliance builds can allow bounded local login flows where useful without promising a general granted-scope / authorization-context export/import substrate.
- **Agent/automation OS (D):** agents/tools cannot confuse “the user completed a login/consent flow locally” with permission to receive `granted_scopes`, `resource_indicators`, `authorization_details`, or equivalent grant-context artifacts; reviewed authorization-context workflows must return on an explicit future seam.

## Family status (Phase 1)

This doc is a **member of the closed auth-mediation companion boundary family** in `auth-mediation-boundary-index.md`.
That family keeps explicit local auth / credential mediation meaning cuts discoverable as one set instead of adjacent singleton folklore.
Future nearby growth should attach to that family in the **same revision** rather than re-creating singleton status by inertia.

## Wiring

This boundary must remain wired from:
- `README.md`
- `docs/README.md`
- `docs/00-meta/llm-runbook.md`
- `docs/30-architecture/posture-index.md`
- `docs/00-meta/profile-posture-matrix.md`
- `docs/00-meta/resolved-history.md`
- `docs/30-architecture/boundary-family-map.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/app-secret-posture-v0.md`
- `docs/30-architecture/vault-posture-v0.md`
- `docs/30-architecture/secret-authority-adjunct-index.md`
- `docs/70-llm-control/llm-threats.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0070-sealed-secrets-and-vault-service.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/00-meta/evidence-index.md`
- `tools/README.md`

## Evidence hook

- `tools/check_authorization_context_export_boundary.py` fails `make lint` if this boundary stops being discoverable, loses its Phase 1 **no portable authorization-context export seam / granted scopes-resources are not a generic secret object or receipt outcome / explicit login mediation is not permission to mint or relay authorization context / no hidden grant-scraping fallback / no new ACP-or-conflict-key family** posture, or drops its primary REF wiring (**EVID-2026-623**).

## References

- REF-RFC6749-OAUTH-AUTHZ-FRAMEWORK.
- REF-RFC8707-RESOURCE-INDICATORS.
- REF-RFC9396-RICH-AUTHORIZATION-REQUESTS.
- REF-RFC7662-TOKEN-INTROSPECTION.
