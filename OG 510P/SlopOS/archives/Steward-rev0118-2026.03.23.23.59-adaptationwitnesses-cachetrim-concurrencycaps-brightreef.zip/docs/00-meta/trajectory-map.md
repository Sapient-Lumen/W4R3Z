# Trajectory map

## Current thesis

Steward should provide the **minimum coherent lifecycle fabric** for SlopOS:
- explicit component roots,
- foreground, accountable lifecycle ownership,
- supervisor-owned activation,
- explicit non-ambient launch context so reviewed entry and restart do not depend on login-shell or session folklore,
- explicit descriptor hygiene so inherited handles, stdio, and control channels do not become ambient launch truth,
- explicit tiny activation checkpoints so launch delivery, control-ready, serve-ready, and stop progression do not collapse into spawn folklore,
- explicit tiny continuity-escrow truth so preserved/redelivered continuity can stay separate from runtime-cycle identity, serving role, and takeover proof,
- explicit attributable short-lived transition helpers that stay separate from the supervised long-lived leaf,
- deterministic restart and stop semantics,
- readiness that is not guessed from spawn success,
- optional tiny readiness-generation witnesses so mid-run config/reload drift can be explained without a giant rollout algebra,
- optional tiny progress windows so start/reload work can be distinguished from stalled intermediate state without freezing a giant timeout grammar,
- explicit tiny hold-state truth so deliberate `paused`, `draining`, `frozen`, or `start-prevented` states can stay separate from `stalled`, `failed`, or ordinary `off`,
- dynamic external conditions that stay observational instead of hardening into fake boot-order facts,
- explicit but narrow activity accounting for in-flight work and drain state,
- explicit balanced activity brackets for runtimes that can honestly express begin/end work scopes,
- a small observational lifecycle/state vocabulary,
- bounded observation subscriptions that can carry snapshot-plus-change views without a hidden control bus,
- an optional tiny presence-advertisement seam so discoverable published presence can stay separate from readiness, serving truth, and runtime-cycle identity,
- an optional opaque runtime-cycle witness for correlating concrete runs without PID folklore,
- a compact end-of-cycle cause vocabulary so concrete runs can end with an explicit explanation instead of raw host trivia,
- compact status that is not log archaeology,
- explicit freshness decay so live status, busy/progress hints, and shell chrome can admit when they have become last-known rather than current,
- cooperative quiesce,
- shell/terminal integration with semantic boundaries rather than PTY folklore,
- an explicit action-surface posture so shell/terminal affordances stay target-bound and user-invoked,
- explicit precision fences so shell/terminal layers can admit capability or trust downgrade instead of preserving stale certainty,
- an explicit tiny mode-baseline and repair seam so prompt-critical shell/terminal state can be freshly reasserted instead of assumed after crashes, hops, or TUI detours,
- an explicit promotion path for selected long-running shell work that deserves first-class lifecycle accountability,
- explicit capability handshakes so richer shell/terminal semantics come from fresh observed support instead of compatibility folklore,
- explicit semantic epochs so shell/terminal markers, subscriptions, and actions can admit “that belonged to an older semantic world” after a hop or resync,
- explicit shell/terminal hop lineage so remote host, multiplexer, and preserved-semantic context stay scoped to the actual path rather than guessed from a flat PTY,
- compact confidence / provenance / trust annotations so shell/terminal observations can admit exactly how exact and rerun-safe they are,
- explicit provisional-state semantics so predictive local echo and incomplete shell metadata can stay useful without pretending tentative state is already confirmed,
- explicit attention hints so command-finished, needs-input, warning, and progress-like shell/terminal cues can stay focus-aware, freshness-scoped, and non-authoritative,
- explicit notification surfaces so OS toasts, mark-alert wakeups, and reveal actions can stay exact-anchor-bound, focus-aware, and action-bounded instead of becoming a hidden approval path,
- an explicit shell/terminal chrome lane so badges, sticky headers, tab titles, and side status cells can stay observational, freshness-scoped, and clearly separate from the canonical transcript,
- an explicit command-guide seam so visible rails, sticky headers, and prompt-local guide chrome can stay exact-frame-bound, filterable, and distinct from the durable transcript,
- an explicit transcript-landmark seam so marks, annotations, alerts, and exact jump targets can stay anchor-bound, provenance-labeled, and clearly separate from transcript truth or ambient control,
- an explicit context-inheritance seam so tabs, splits, reruns, and action-launched shells can inherit cwd or domain context per action without ambient pane folklore,
- an explicit spawn-selector seam so tabs, splits, reruns, and helper shells can choose reviewed program/profile/domain/cwd recipes instead of ambient `$SHELL`, profile, or pane folklore,
- an explicit remembered-shelf seam so recent commands, directories, and Steward objects can stay keyed to host/hop context, freshness-labeled, and clearly separate from live-state truth,
- an explicit observational session-variable seam so shell and terminal chrome, filtering, and remembered context stay scoped and useful without hardening into launch or policy truth,
- explicit target anchors so shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs without rendered-text scraping or raw-capability leakage,
- explicit bounded context handoff so exact command frames, output slices, receipts, and concrete runs can be exported or attached without ambient whole-scrollback sharing,
- explicit transfer-surface semantics so uploads, downloads, remote-file actions, and drag/drop handoff stay exact, direction-labeled, and clearly separate from clipboard or prompt folklore,
- explicit media-surface semantics so inline images, plots, doc previews, and background media stay exact-targeted, budgeted, and clearly separate from transfer/open folklore,
- explicit link-surface semantics so detected text, declared hyperlinks, semantic file links, and exact object opens stay provenance-labeled, action-bounded, and clearly separate from generic open folklore,
- explicit label-surface semantics so titles, badges, right-status text, and similar chrome labels stay provenance-labeled, override-scoped, and clearly separate from transcript or policy truth,
- explicit repair-gate semantics so repeated failures can cool down, become repair-required, and stay explainable instead of hiding behind ambient restart folklore,
- explicit workspace-snapshot semantics so saved layouts, reconnected processes, revived processes, and content-only restores stay visibly distinct instead of collapsing into session folklore,
- explicit replay-gate semantics so remembered, restored, or suspended commands can reopen as reviewed pending actions instead of silently rerunning from stale shell folklore.
- explicit exception witnesses so bypass-under-review, waived-under-expiry, and satisfied-gate truth can stay visibly separate from ordinary success or settled health.
- explicit headroom witnesses so allowed, approved, and ready can stay visibly separate from currently spendable restart / quota / rate-window headroom,
- explicit pressure witnesses so scoped stall / warning / critical pressure truth can stay visibly separate from serving mode, headroom, and failure,
- explicit backpressure witnesses so `queued`, `retry-after`, `shed`, and `stop-accepting` truth can stay visibly separate from pressure, headroom, and failure,
- explicit adaptation witnesses so cache trim, reduced concurrency, optional-work deferral, and other protective response truth can stay visibly separate from pressure, backpressure, and vague degraded folklore.

The current architecture compression is in [`../30-architecture/design-principles-v0.md`](../30-architecture/design-principles-v0.md).
The current freeze-late refusal set is in [`../30-architecture/non-decisions-v0.md`](../30-architecture/non-decisions-v0.md).

## Open questions (tracked as decision surfaces)
- **OQ-0001 activation allowlist shape**: how much activation-key structure belongs in `CH-COMP v0`, and how much should stay provider-local?
- **OQ-0002 readiness vocabulary**: what is the smallest closed set of startup/control-ready/readiness/liveness states that remains useful?
- **OQ-0003 dependency planning**: does phase 1 need an offline planner layer, or only local start-order constraints?
- **OQ-0004 continuity escrow**: what kinds of handles or state can legally survive restart, and how are they allowlisted?
- **OQ-0005 quiesce evidence**: what exact transcript/receipt shape should explain “why is this component not taking new work?”
- **OQ-0006 shell/terminal side channel**: what exact semantic markers, command-frame fields, and receipts should exist between shell and terminal?
- **OQ-0007 admin surface**: what external control surface, if any, is needed before phase 1 is real?
- **OQ-0008 compat membrane**: how much host init/service-manager behavior can live behind a compat membrane without leaking into Steward semantics?
- **OQ-0009 service package shape**: does Steward benefit from a minimal service-as-directory / bundle discipline, or should packaging stay entirely outside the portable contract?
- **OQ-0010 restart-loop posture**: how much restart-budget / cooldown vocabulary is phase-1-portable, and how much should remain implementation policy?
- **OQ-0011 status channel**: what compact state/status vocabulary should components report beyond ready/not-ready without recreating a giant ad hoc logging protocol?
- **OQ-0012 idle / transaction semantics**: which kinds of components deserve explicit idle or in-flight work accounting, and how much of that belongs in Steward versus runtime-specific adapters?
- **OQ-0013 shell marker provenance**: what minimum provenance or trust model should shell/terminal semantic markers use so rerun/copy/receipt UX stays helpful without becoming spoofable authority?
- **OQ-0014 transient command seam**: when should long-running shell-launched work stay a plain command, and when should it become a first-class transient service or lease-bearing background object?
- **OQ-0015 terminal input protocol**: what minimum keyboard/paste/click reporting should the custom shell+terminal standardize so interactive UX is explicit instead of timing-hack folklore?
- **OQ-0016 resilient remote shell transport**: how much roaming/local-echo/offline tolerance belongs in the shell+terminal contract versus a host-local transport layer?
- **OQ-0017 runtime-cycle witness**: what is the smallest portable cycle-identity/fence shape that helps avoid stale actions without implying a giant process API?
- **OQ-0018 termination-cause vocabulary**: what is the smallest portable end-of-cycle cause vocabulary that remains useful without pretending every runtime exposes the same exit/fault detail?
- **OQ-0019 action surfaces**: what tiny portable descriptor should explicit shell/terminal actions use so they stay user-invoked, target-bound, and stale-fenced across local/remote hops?

- **OQ-0020 observation subscriptions**: what tiny portable snapshot-plus-change subscription shape is worth freezing so terminals and UIs can avoid polling without creating a giant event bus?
- **OQ-0021 precision fences**: what minimum portable vocabulary should say when hops, multiplexers, or fallback paths downgraded cwd/command/trust precision, and how should resync work?
- **OQ-0022 capability handshake**: what is the smallest portable way for shells, terminals, and hop layers to report fresh semantic-feature support without trusting `TERM` folklore or creating a giant negotiation protocol?
- **OQ-0023 semantic epochs**: what is the smallest portable freshness-token shape that lets shell/terminal frames, actions, and subscriptions say “this belonged to an older semantic world” after hops, resync, or shell reset?
- **OQ-0024 hop lineage**: what is the smallest portable remote/multiplexer path hint that helps scope histories, titles, actions, and capability truth to the actual host/path without implying authentication or a giant transport graph?
- **OQ-0025 observation confidence**: what is the smallest portable low/medium/high plus trusted/provenance model that remains useful across shells, hops, and fallback parsers without pretending confidence is the same as authorization?
- **OQ-0026 provisional state**: what is the smallest portable pending/confirmed/revised/withdrawn model that lets shell/terminal UX hide latency without turning prediction into lifecycle truth?
- **OQ-0027 attention hints**: what is the smallest portable command-finished / needs-input / warning / progress hint model that stays user-filterable, focus-aware, and freshness-scoped without becoming a hidden control or notification bus?
- **OQ-0028 target anchors**: what is the smallest portable way to bind shell/terminal affordances to exact frames, receipts, transcript spans, and concrete runs without scraping rendered text or leaking raw capability into copied/exported output?
- **OQ-0029 chrome lane**: what is the smallest portable observational chrome surface for badges, titles, sticky headers, and side status cells, and how should it stay freshness-scoped, copy-safe, and clearly separate from the canonical transcript?
- **OQ-0030 mode baseline**: what is the smallest portable prompt-critical shell/terminal baseline worth naming explicitly, and how should light resync, baseline reassertion, and user-invoked hard reset stay distinct?
- **OQ-0031 context handoff**: what is the smallest portable bounded bundle for “attach/share this exact command interaction” so command text, exact output, exit data, cwd, witnesses, and receipt refs can be handed off without exporting a whole pane or inventing a giant transcript schema?
- **OQ-0032 repair gates**: what is the smallest portable active / cooling-down / repair-required model, and what exact explicit signal should clear or reset a repair gate without sneaking ambient policy in through the side door?
- **OQ-0033 launch baseline**: what is the smallest portable reviewed launch context worth freezing so component entry and restart stay explicit without importing a giant spawn-profile grammar?
- **OQ-0034 transition helpers**: what is the smallest portable vocabulary for short-lived prepare/drain/cleanup helpers so they stay attributable and bounded without importing a giant hook grammar?
- **OQ-0035 descriptor hygiene**: what is the smallest portable inherited-handle baseline worth naming explicitly so launch, activation, and shell/terminal control paths stay reviewed without importing a giant fd-table DSL?
- **OQ-0036 activation checkpoints**: what is the smallest portable checkpoint vocabulary worth naming explicitly so launch delivery, control-ready, serve-ready, and stop progression stay honest without freezing a giant phase graph?

- **OQ-0037 session variables**: what is the smallest portable observational variable model worth naming explicitly so chrome, palette filtering, and remembered shell context stay useful without becoming authority?
- **OQ-0038 activity brackets**: what is the smallest portable begin/end work-bracket model worth naming explicitly so "do not stop me yet" state stays balanced and attributable without becoming a generic lease or keepalive loophole?
- **OQ-0039 freshness decay**: what is the smallest portable freshness / renewal / last-known vocabulary worth naming explicitly so status, busy hints, and shell chrome can decay honestly without freezing a universal heartbeat contract?
- **OQ-0040 activation receipts**: what is the smallest portable exact-run receipt for delivered startup material and acknowledgement worth naming explicitly so activation stays reviewable without freezing a giant startup protocol?
- **OQ-0041 command guides**: what is the smallest portable guide-rail / sticky-header / scrollbar-mark model worth naming explicitly so visible command boundaries stay exact-object-backed, filterable, and clearly separate from transcript truth?
- **OQ-0042 context inheritance**: what is the smallest portable per-action inheritance model worth naming explicitly so tabs, splits, reruns, and action-launched shells can carry cwd or domain context without smuggling ambient pane folklore?
- **OQ-0043 spawn selectors**: what is the smallest portable reviewed spawn-selector model worth naming explicitly so tabs, splits, reruns, and helper shells can choose program/profile/domain/cwd recipes without ambient `$SHELL`, profile, or pane folklore?
- **OQ-0044 remembered shelves**: what is the smallest portable remembered-shelf model worth naming explicitly so recent commands, directories, and Steward objects can stay host-or-hop-scoped, freshness-labeled, and clearly separate from current live-state truth?
- **OQ-0045 transcript landmarks**: what is the smallest portable mark / annotation / alert / jump-target model worth naming explicitly so transcript landmarks stay exact-anchor-bound, provenance-labeled, and clearly separate from remembered shelves, guide chrome, or ambient control?
- **OQ-0046 workspace snapshots**: what is the smallest portable saved-layout / reconnect / revive / content-only-restore model worth naming explicitly so workspaces can reopen honestly without pretending remembered arrangements are live process truth?
- **OQ-0047 replay gates**: what is the smallest portable restore-or-history replay model worth naming explicitly so remembered, restored, or suspended commands can reopen as reviewed pending actions instead of silently rerunning from stale shell folklore?
- **OQ-0048 assist surfaces**: what is the smallest portable quick-fix / suggestion / current-input-help model worth naming explicitly so terminals can offer likely next actions without becoming an ambient second shell or silent auto-repair plane?
- **OQ-0049 session injection**: what is the smallest portable staged-command / env-load / history-policy model worth naming explicitly so UI-originated shell mutation stays explicit, scoped, and policy-bounded instead of becoming ambient session folklore?
- **OQ-0050 clipboard surfaces**: what is the smallest portable exact-copy / paste-mode / remote-clipboard policy model worth naming explicitly so clipboard flows stay useful without becoming ambient terminal folklore or silent structured-data loss?
- **OQ-0051 transfer surfaces**: what is the smallest portable exact upload / download / open-local / edit-local-and-sync / attach-object handoff model worth naming explicitly so richer file and object transfer stays reviewed, direction-labeled, and separate from clipboard or prompt folklore?
- **OQ-0052 retention surfaces**: what is the smallest portable retention-class / persistence-scope / erase policy model worth naming explicitly so remembered command, directory, paste, and host breadcrumbs can persist usefully without turning into ambient retained authority or surprise sync?
- **OQ-0053 automation surfaces**: what is the smallest portable exact-target / action-class / control-path / receipt model worth naming explicitly so scripts, hooks, remote-control APIs, and helper CLIs stay useful without becoming an ambient second control plane?
- **OQ-0054 notification surfaces**: what is the smallest portable exact-anchor / focus-policy / reveal-action / durable-truth split worth naming explicitly so command-finished toasts and alert-on-mark flows stay useful without becoming a hidden approval or control path?
- **OQ-0055 input surfaces**: what is the smallest portable key-event / composed-text / modal-key-table / unknown-key-policy / helper-injected-input split worth naming explicitly so the custom shell+terminal can be powerful without confusing typed intent, replay, and terminal-side control?
- **OQ-0056 link surfaces**: what is the smallest portable detected-link / declared-hyperlink / semantic-file-link / exact-object-target split worth naming explicitly so clickable shell/terminal affordances stay useful without turning guessed text into ambient open authority?
- **OQ-0057 execution ground**: what is the smallest portable ground-summary vocabulary worth naming explicitly so panes, command frames, receipt cards, and prediction rails can say what context they stand on without turning chrome, remembered context, or foreground baton hints into lifecycle authority?
- **OQ-0058 progress windows**: what is the smallest portable in-progress / held / extended / stalled vocabulary worth naming explicitly so bring-up and reload can stay honest without freezing a giant startup-timeout, rollout, or watchdog grammar?
- **OQ-0059 presence advertisement**: what is the smallest portable advertised / withheld / withdrawn / expired vocabulary worth naming explicitly so discoverable presence can stay honest without freezing a generic registry, lease, or balancer-membership plane?
- **OQ-0060 attach lanes**: what is the smallest portable observe / attach / control / debug vocabulary worth naming explicitly so shared shell/terminal presence can stay useful without freezing a giant collaboration, transport, or role family?
- **OQ-0061 proposal lanes**: what is the smallest portable proposal/help/conversation lane worth naming explicitly so agent chat, notebook command blocks, and terminal suggestions can stay useful without collapsing into ambient shell execution or a giant notebook family?
- **OQ-0062 approval rungs**: what is the smallest portable proposal / ask / scoped-auto / run-until-completion vocabulary worth naming explicitly so terminal autonomy can be useful without freezing a giant approval-policy matrix or ambient YOLO plane?
- **OQ-0062A exception witnesses**: what is the smallest portable bypass-under-review / waived-until / exception-expired vocabulary worth naming explicitly so deliberate exceptions stay visibly weaker than satisfied gates without freezing a giant waiver, break-glass, or reviewer-workflow family?
- **OQ-0063 revision settlement**: what is the smallest portable desired / observed / settled revision vocabulary worth naming explicitly so pending promotion, stale status, and rollback-to-last-settled guidance stay honest without freezing a giant rollout controller?
- **OQ-0064 headroom witnesses**: what is the smallest portable spendability / headroom vocabulary worth naming explicitly so allowed, approved, and ready can stay separate from quota, restart, seat, or rate-window exhaustion without freezing a giant wallet or capacity family?
- **OQ-0065 hold states**: what is the smallest portable `paused` / `draining` / `frozen` / `start-prevented` vocabulary worth naming explicitly so deliberate maintenance or policy holds stay separate from stall, failure, and ordinary off truth without freezing a giant maintenance or inhibit family?

- **OQ-0066 serve-state witnesses**: what is the smallest portable `serving` / `serving+terminating` / `draining` / `maintenance` / `degraded` vocabulary worth naming explicitly so new-work admission truth stays honest without freezing a giant traffic or service-mesh family?
- **OQ-0067 pressure witnesses**: what is the smallest portable scoped `ok` / `some` / `full` / `warning` / `critical` pressure vocabulary worth naming explicitly so stall/pressure truth stays honest without freezing a giant autoscaling, scheduler, or reclaim-policy family?

- **OQ-0068 backpressure witnesses**: what is the smallest portable `queued` / `retry-after` / `shed` / `stop-accepting` vocabulary worth naming explicitly so admission-throttle truth stays honest without freezing a giant overload, fair-queuing, or traffic-shaping family?
- **OQ-0069 adaptation witnesses**: what is the smallest portable `trim-cache` / `reduce-concurrency` / `defer-optional-work` / `narrow-mode` vocabulary worth naming explicitly so protective response truth stays honest without freezing a giant brownout, autoscaling, or remediation-policy family?

## Revision 118 focus
Deepen Steward's research around pressure-versus-adaptation honesty, explicit protective responses such as cache trim and reduced concurrency, SlopOS D-PRESSURE alignment, and terminal adaptation receipts while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant brownout, autoscaling, or remediation-policy family.

## Revision 117 focus
Deepen Steward's research around queue-versus-shed honesty, retry-after and pushback hints, SlopOS pressure/backpressure alignment, and terminal backpressure chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant overload, fair-queuing, or traffic-shaping family.

## Revision 116 focus
Deepen Steward's research around scoped pressure truth, early adaptation before eviction, SlopOS pressure/backpressure alignment, and terminal pressure chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant scheduler, autoscaler, or reclaim-action family.

## Revision 115 focus
Deepen Steward's research around serve-state truth, drain-versus-serving honesty, SlopOS/Helm pressure around explicit new-work gating, and terminal serve-mode chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant traffic or service family.

## Revision 114 focus
Deepen Steward's research around explicit exception footing, bypass-weaker-than-satisfaction discipline, SlopOS/Helm waiver pressure, and terminal exception chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant waiver or break-glass family.

## Revision 113 focus
Deepen Steward's research around deliberate hold modes, resume-versus-thaw-versus-undrain honesty, SlopOS/Helm maintenance pressure, and terminal hold chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant maintenance or inhibit family.

## Revision 112 focus
Deepen Steward's research around spendability-versus-authority truth, primary-versus-secondary ceilings, reset-versus-manual-clear honesty, and terminal headroom chips while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant quota or wallet family.

## Recently resolved (keep short)
- **OQ-0000 naming**: the project name is **Steward**.

## Revision 111 focus
Deepen Steward's research around desired-versus-observed-versus-settled revision truth, pending-promotion honesty, rollback-to-last-settled guidance, and terminal revision ribbons while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant rollout family.

## Revision 109 focus
Deepen Steward's research around approval/autonomy rungs, policy floors, sandbox-paired higher autonomy, and witness-first downgrade on reconnect while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant automation-policy family.

## Revision 108 focus
Deepen Steward's research around lane-labeled remembered search, shell-history hygiene, insert-versus-run defaults, and explicit retention/sync truth while keeping the archive lighter than SlopOS by landing one narrow posture doc plus note-level refinements and hygiene instead of a giant memory or search family.
