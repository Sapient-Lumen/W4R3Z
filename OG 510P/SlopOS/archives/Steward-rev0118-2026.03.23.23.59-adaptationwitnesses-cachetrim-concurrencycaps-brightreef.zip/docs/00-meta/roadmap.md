# Roadmap

## Revision 1: seed the datacube
- establish repo hygiene and packaging;
- identify narrow phase-1 seams;
- collect external lessons and shell/terminal ideas.

## Revision 2: harden the guardrails, not the whole architecture
- add a compact design-principles v0 note;
- strengthen lessons from historical supervisors and activation systems;
- sharpen shell/terminal direction around command frames, receipts, marks, and remote-aware semantic transport;
- automate source-review-queue generation to keep research hygiene light and repeatable.

## Revision 3: freeze late on purpose
- make non-decisions explicit so adjacent SlopOS uncertainties do not harden accidentally;
- improve shell/terminal notes around semantic markers and command-block UX;
- tighten source-lock hygiene and bibliography sync.

## Revision 4: observations before mutations
- add small posture notes for lifecycle observation vocabulary and compact current-state/status reporting;
- sharpen readiness around shallow/control-ready versus declared-work ready;
- collect shell-marker provenance and trust-model ideas instead of inventing a giant custom terminal protocol.

## Revision 11: subscriptions before bigger event stories
- add a narrow observation-subscription posture rather than freezing a giant event bus or control API;
- collect lessons around snapshot-plus-change views, coalescing, backpressure, and text-friendly remote-safe observation streams;
- tighten shell/terminal direction around prompt freshness, command-finish notifications, and subscription-backed UI without hidden ambient authority.

## Next likely revision
- decide whether Steward needs one explicit attach-lane receipt/status shape or can keep lane truth carried by existing ground/action surfaces a little longer;
- sketch the smallest denial/upgrade story for observe-only witness mode, interactive attach, control, and debug without inventing a giant collaboration family;
- decide how much of transport truth belongs in shell chrome versus receipts, and how much should remain adapter-local;
- prototype how attach-lane truth composes with command frames, action surfaces, fresh-intent witnesses, and bounded context handoff.

## Revision 8: cycle witnesses before bigger control planes
- add a narrow runtime-cycle witness posture rather than a giant generation or admin API;
- collect lessons around per-runtime-cycle identity, transaction-aware stop behavior, and semantic prompt ancestry;
- tighten shell/terminal direction around action chips, provenance, and stale-action fences while keeping the archive light.

## Longer horizon
- prototype a minimal user-space supervisor;
- define transcripts/receipts for lifecycle events;
- prove that restart/activation does not widen authority;
- define compat membranes for host service managers without importing their semantics.

## Revision 5: command frames and transient ideas
- add a small command-frame posture rather than freezing a big terminal protocol;
- collect more lessons from Dinit, Shepherd, tmux, Ghostty, fish, kitty, and xterm;
- tighten shell/terminal direction around parseable side channels, input-side semantics, and transient-service inspiration;
- improve repo hygiene by checking the head-register against the source-lock set.
