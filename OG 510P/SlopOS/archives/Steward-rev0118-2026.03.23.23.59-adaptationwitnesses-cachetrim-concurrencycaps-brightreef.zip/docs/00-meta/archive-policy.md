# Archive policy (keep it small, keep it sharp)

## What belongs here
- Our specs, invariants, claims, ADRs/RFCs, and evidence pointers.
- Small, curated summaries of external work via REF entries (no large quotes/copies).
- Build/provenance recipes and hashes for our trusted artifacts.

## Cite > copy
- External sources must be registered as **reference IDs** (bibliography).
- Internal demos/proofs/benchmarks must be registered as **EVID-IDs** (evidence index).
- ADRs and main docs cite REF/EVID IDs instead of re-deriving content.

## When to create a new document
Only if:
1) it will have an owner TOC, and
2) it will be referenced by ≥2 other docs or by an ADR, and
3) it introduces a stable new “axis” (toolchain, platform family, architecture boundary).

## Compression rule
If a doc grows beyond ~6–8 screens:
- keep stable statements in-place,
- move discussion and superseded reasoning into RFCs,
- keep pointers (REF/EVID/ADR) rather than prose history.

## Amnesia resistors (LLM-friendly continuity)
- Keep `docs/00-meta/llm-runbook.md` current (non-negotiables, must-read set, outputs).
- Use `make context-pack` to generate `out/context_pack.md` when handing off work between runs.

## Review gates
No change to lifecycle authority, platform assumptions, or shell/terminal semantics without updating:
- Threat model assumptions,
- Claim registry and invariant registry,
- Evidence plan (RFC) or evidence link (ADR).

## ID conventions (compact traceability)
- **A-***: assumptions (threat-model registry)
- **C-***: claims (claim registry)
- **I-***: invariants (invariant registry)
- **PO-***: proof obligations (PO registry)
- **IF-***: privileged surfaces (interface registry)
- **CH-***: schema IDs (schema registry)
- **RFC-XXXX**: proposals (rfcs/)
- **ADR-XXXX**: decisions (adrs/)
- **REF-***: external references (bibliography)
- **EVID-YYYY-NNN**: our evidence artifacts (evidence index)

Rule: new statements that matter must attach to at least one of {C, I, ADR, EVID}.

## Repo hygiene (keep it green)
- Run `make lint` before/after edits (IDs, links, no-raw-URLs, schema pointer checks, and discovery-surface checks).
- Generate `out/context_pack.md` via `make context-pack` when starting/ending large revisions.
- Refresh `docs/00-meta/external-source-review-queue.md` with `make source-review-queue` whenever source locks change.
