# Charter

**Mission:** Build a living archive that can guide the design of Steward, the SlopOS component lifecycle and activation fabric, in a way that stays explicit about authority, restart, readiness, quiesce, and shell/terminal semantics while SlopOS itself is still evolving.

## North-star sentence
Steward should make long-lived services explicit, restartable, and policy-bounded **without inheriting ambient Unix folklore as product semantics**.

## Non-goals for the archive
- deciding every interface up front;
- cloning a host service manager API;
- forcing a single runtime model onto all SlopOS components;
- mistaking research accumulation for a finished architecture.

## Success criteria for revision 1
- preserve archive continuity and packaging discipline;
- identify the narrow core seams Steward probably needs;
- capture the most important historical lessons and stealable ideas;
- keep the remaining uncertainty visible as open questions.
