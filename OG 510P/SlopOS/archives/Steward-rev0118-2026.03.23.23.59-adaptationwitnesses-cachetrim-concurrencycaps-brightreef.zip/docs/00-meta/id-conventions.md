# ID conventions

- **A-*** — assumptions
- **C-*** — claims
- **I-*** — invariants
- **PO-*** — proof obligations
- **IF-*** — privileged interfaces / surfaces
- **CH-*** — schema IDs
- **ADR-XXXX** — accepted architectural decisions
- **RFC-XXXX** — proposals
- **REF-*** — external references
- **EVID-YYYY-NNN** — local evidence and process artifacts
- **OQ-XXXX** — open questions
