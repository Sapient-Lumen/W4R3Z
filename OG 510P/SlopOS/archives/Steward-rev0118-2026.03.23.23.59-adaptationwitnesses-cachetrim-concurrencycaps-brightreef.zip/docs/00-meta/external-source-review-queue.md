# External source review queue

Generated from `external-source-locks.json`.

| reference ID | Retrieved | Review by | Reason |
| --- | --- | --- | --- |
| REF-APPLE-INHERITING-FDS | 2026-03-22 | 2026-09-22 | official reminder that inherited descriptors are authority and must be closed or constrained on child launch |
| REF-AWS-EC2-IDEMPOTENCY | 2026-03-22 | 2026-06-22 | client-token idempotency, mismatch behavior, and bounded retry equivalence |
| REF-AWS-ECS-IDEMPOTENCY | 2026-03-22 | 2026-06-22 | client-token TTL, outstanding request conflict, and prior-outcome replay |
| REF-AWS-S3-CONDITIONAL-WRITES | 2026-03-23 | 2026-06-23 | If-Match/If-None-Match conditional writes, 412 precondition failed, and 409 concurrent conflict behavior |
| REF-AWS-STS-ASSUMEROLE | 2026-03-23 | 2026-06-23 | temporary session credentials, intersection of role and session policy, source identity, and bounded session duration |
| REF-BASH-READLINE-INIT | 2026-03-22 | 2026-06-22 | bracketed paste behavior in readline shells |
| REF-CLAUDE-CODE-PERMISSIONS | 2026-03-23 | 2026-06-23 | distinct plan permission mode and approval rules |
| REF-CONSUL-AGENT-CHECK | 2026-03-23 | 2026-06-23 | TTL check renewal plus critical-state deregistration for explicit advertised presence aging |
| REF-CRASH-ONLY-SOFTWARE | 2026-03-23 | 2026-06-23 | historical crash-only design lesson: recover quickly and keep stop/start semantics simple |
| REF-DAEMONTOOLS-SUPERVISE | 2026-03-21 | 2026-09-21 | minimal supervision and restart-loop lessons |
| REF-DBUS-API-DESIGN | 2026-03-21 | 2026-06-21 | snapshot-plus-change, PropertiesChanged, ObjectManager, and explicit interface/versioning lessons |
| REF-DBUS-SPECIFICATION | 2026-03-23 | 2026-06-23 | activation-by-message and StartServiceByName TOCTOU guidance |
| REF-DBUS-SYSTEM-ACTIVATION | 2026-03-21 | 2026-06-21 | validated-name activation helper and cleared environment lesson |
| REF-DESKTOP-ENTRY-DBUS-ACTIVATION | 2026-03-23 | 2026-06-23 | D-Bus activation files and platform-data activation hints stay separate from lifecycle truth |
| REF-DESKTOP-NOTIFICATIONS-SPEC | 2026-03-22 | 2026-06-22 | notification actions may carry a separate activation token, reinforcing target-versus-foreground separation |
| REF-DINIT-OVERVIEW | 2026-03-21 | 2026-06-21 | middle-ground service manager and compact scope |
| REF-DINIT-SERVICE | 2026-03-21 | 2026-06-21 | service ready notification and restart limits |
| REF-ENVOY-ADAPTIVE-CONCURRENCY | 2026-03-23 | 2026-09-23 | official adaptive-concurrency control for reducing outstanding requests under rising latency/load |
| REF-ENVOY-HEALTHCHECKING | 2026-03-23 | 2026-06-23 | healthy plus degraded availability and drain-aware health responses support explicit serve-state truth |
| REF-ENVOY-OVERLOAD-MANAGER | 2026-03-23 | 2026-09-23 | official overload manager actions, load-shed points, queue-versus-shed distinctions, and timeout reduction under resource pressure |
| REF-ERLANG-OTP-SUPERVISOR | 2026-03-22 | 2026-09-22 | supervision model, workers vs supervisors, and restart intensity |
| REF-ETCD-API-TXN | 2026-03-23 | 2026-06-23 | Txn compare predicates, success/failure branches, watch progress notifications, and revision-based conditional mutation |
| REF-ETCD-CONCURRENCY-LOCK | 2026-03-23 | 2026-06-23 | lock ownership key, lease-bound current ownership, and election LeaderKey revision checks for guarding side effects |
| REF-ETCD-DATA-MODEL | 2026-03-23 | 2026-06-23 | monotonic revisions, watchable history, and compaction removing old revisions |
| REF-ETCD-LEASE-API | 2026-03-23 | 2026-06-23 | lease grant/keepalive/revoke semantics and attached-key expiry/deletion for narrow published presence |
| REF-ETCD-LEASES | 2026-03-22 | 2026-06-22 | lease TTL, keepalive, revoke, and remaining-time semantics for bounded live claims |
| REF-ETCD-MAINTENANCE | 2026-03-23 | 2026-06-23 | history compaction and required-revision-compacted failure mode |
| REF-FISH-OSC-MARKERS | 2026-03-21 | 2026-06-21 | OSC 7 cwd reporting, OSC 133 prompt markers, and click-aware prompt input |
| REF-FISH-TERMINAL-COMPAT | 2026-03-22 | 2026-06-22 | safe-ignore behavior for unsupported terminal features |
| REF-FREEBSD-CAP-ENTER | 2026-03-23 | 2026-06-23 | irreversible capability-mode precedent for monotonic authority narrowing |
| REF-FREEBSD-CAP-RIGHTS-LIMIT | 2026-03-23 | 2026-06-23 | one-way file-descriptor rights reduction precedent |
| REF-FREEBSD-CAPSICUM | 2026-03-22 | 2026-06-22 | capability-style compartmentalization precedent |
| REF-FREEBSD-PROCDESC | 2026-03-23 | 2026-06-23 | capability-oriented exact process descriptors as a race-resistant alternative to ambient PIDs |
| REF-FUCHSIA-API-RUBRIC | 2026-03-23 | 2026-06-23 | pull-semantics preference and lazy startup/shutdown-order lesson |
| REF-FUCHSIA-CAPABILITIES | 2026-03-23 | 2026-06-23 | weak capabilities, availability, and shutdown-order/cycle implications |
| REF-FUCHSIA-COMPONENT-RUNNER | 2026-03-23 | 2026-06-23 | OnEscrow event and redelivery via startup info on next start |
| REF-FUCHSIA-IDLE-STOP | 2026-03-23 | 2026-06-23 | idle stop with escrowed handles/state and prompt exit after OnEscrow |
| REF-FUCHSIA-LIFECYCLE | 2026-03-22 | 2026-06-22 | major lifecycle states and persistence across restarts |
| REF-FUCHSIA-MEMORY-RECLAMATION | 2026-03-23 | 2026-06-23 | warning/critical memory-pressure levels and userspace/kernel reclamation behavior |
| REF-FUCHSIA-PROCESS-LIFECYCLE | 2026-03-22 | 2026-06-22 | OnEscrow and Stop semantics reinforce narrow manager-redelivered continuity and kill-first honesty |
| REF-FUCHSIA-RUNNER | 2026-03-22 | 2026-06-22 | runner separation and runtime-launch seam |
| REF-FUCHSIA-STOP-IDLE | 2026-03-22 | 2026-06-22 | idle-stop guide shows narrow escrowed handles/state instead of a generic resurrection plane |
| REF-FUCHSIA-SYS2 | 2026-03-23 | 2026-06-23 | StartInstance binder channel and start-versus-running semantics |
| REF-GHOSTTY-CONFIG-REFERENCE | 2026-03-23 | 2026-06-23 | title override, title-report security gate, and shell-integration title feature |
| REF-GHOSTTY-FEATURES | 2026-03-23 | 2026-06-23 | GPU-accelerated rendering and Kitty graphics protocol support as first-class terminal features |
| REF-GHOSTTY-KEYBIND-ACTIONS | 2026-03-23 | 2026-06-23 | ignore/passthrough style key actions, read-only mode, mouse-reporting toggles, and end-key-sequence behavior |
| REF-GHOSTTY-KEYBIND-SEQUENCE | 2026-03-23 | 2026-06-23 | leader/key-sequence behavior, indefinite wait semantics, and flush rules for invalid or ended sequences |
| REF-GHOSTTY-OSC52 | 2026-03-22 | 2026-06-22 | remote/local clipboard operation details |
| REF-GHOSTTY-RELEASE-110 | 2026-03-22 | 2026-06-22 | security fix for leaking some file descriptors to the running shell or command |
| REF-GHOSTTY-RELEASE-120 | 2026-03-21 | 2026-06-21 | command palette evolution and terminal action exposure ideas |
| REF-GHOSTTY-RELEASE-130 | 2026-03-23 | 2026-06-23 | OSC 133 inspector/notification ideas and shell-integration-driven command tracking |
| REF-GHOSTTY-RESET-ACTION | 2026-03-21 | 2026-06-21 | explicit terminal reset action for broken terminal state |
| REF-GHOSTTY-SHELL-INTEGRATION | 2026-03-22 | 2026-06-22 | prompt jumps, click-to-move, and remote-comfort shell integration ideas |
| REF-GITHUB-PROTECTED-BRANCHES | 2026-03-23 | 2026-06-23 | branch protection bypass permissions and the explicit do-not-allow-bypass setting |
| REF-GITHUB-PUSH-PROTECTION-BYPASS | 2026-03-23 | 2026-06-23 | delegated bypass requests with designated reviewers, expiry, and explicit approval or denial |
| REF-GITHUB-RATE-LIMITS | 2026-03-23 | 2026-06-23 | primary headers, reset timing, and explicit secondary limits that may remain partly undisclosed |
| REF-GNU-SHEPHERD-MANUAL | 2026-03-22 | 2026-06-22 | respawn limits, delays, and service status history |
| REF-GNU-SHEPHERD-OVERVIEW | 2026-03-21 | 2026-06-21 | user and system service manager with socket activation and timers |
| REF-GNU-SHEPHERD-TRANSIENT | 2026-03-21 | 2026-06-21 | transient service maker and richer status ideas |
| REF-GNU-SHEPHERD-TRANSIENT-MAKER | 2026-03-21 | 2026-06-21 | manual for transient service maker and background promotion ideas |
| REF-GO-CONTEXT | 2026-03-22 | 2026-06-22 | deadlines, cancellation propagation, and explicit CancelFunc cleanup discipline |
| REF-GOOGLE-AIP-155 | 2026-03-22 | 2026-06-22 | request IDs and idempotency guarantees |
| REF-GOOGLE-CREDENTIAL-ACCESS-BOUNDARY | 2026-03-23 | 2026-06-23 | downscoped short-lived credentials with upper-bound permissions per resource |
| REF-GRPC-CANCELLATION | 2026-03-22 | 2026-06-22 | explicit cancellation and propagation for request-scoped work |
| REF-GRPC-DEADLINES | 2026-03-22 | 2026-06-22 | exact request deadlines and propagation for bounded work |
| REF-GRPC-HEDGING | 2026-03-23 | 2026-06-23 | server pushback via grpc-retry-pushback-ms plus retry throttling and hedged-request suppression |
| REF-GRPC-RETRY | 2026-03-23 | 2026-09-23 | official retry throttling and server pushback guidance for retry-later versus do-not-retry semantics |
| REF-GRPC-STATUS-CODES | 2026-03-23 | 2026-09-23 | official distinction between RESOURCE_EXHAUSTED and permission/auth failures |
| REF-HAPROXY-MANAGEMENT | 2026-03-23 | 2026-06-23 | ready, drain, and maint administrative states are a useful explicit service-admission precedent |
| REF-HAZELCAST-FENCEDLOCK | 2026-03-23 | 2026-06-23 | monotonic fencing tokens, stale old owner after pause/session loss, and external side-effect rejection by newer token |
| REF-HTML-USER-ACTIVATION | 2026-03-23 | 2026-06-23 | transient vs sticky activation, activation-consuming APIs, and navigator.userActivation state for recent local interaction gating |
| REF-HTTP-RFC9110 | 2026-03-23 | 2026-06-23 | If-Match lost-update protection, 412 precondition failed ordering, and conditional request precedence |
| REF-IETF-IDEMPOTENCY-KEY | 2026-03-22 | 2026-06-22 | draft idempotency-key uniqueness, fingerprint, expiry, and mismatch/conflict guidance |
| REF-ITERM2-BADGES | 2026-03-21 | 2026-06-21 | large session badge surface for dynamic observational status via explicit escape sequence |
| REF-ITERM2-COMMAND-SELECTION | 2026-03-21 | 2026-06-21 | command-scoped selection, info, bookmarking, and command URLs |
| REF-ITERM2-ESCAPE-CODES | 2026-03-23 | 2026-06-23 | OSC 8 hyperlinks and file://fragment routing into semantic-history file opening |
| REF-ITERM2-FEATURE-REPORTING | 2026-03-23 | 2026-06-23 | explicit feature reporting as a replacement for TERM folklore |
| REF-ITERM2-FEATURES | 2026-03-22 | 2026-06-22 | annotations and captured-output inspiration |
| REF-ITERM2-HOOKS | 2026-03-22 | 2026-06-22 | named hook surfaces that modify default behavior through explicit decorators and stable identifiers |
| REF-ITERM2-INLINE-IMAGES | 2026-03-22 | 2026-06-22 | inline-versus-download split, declared file size, and monitored download progress |
| REF-ITERM2-MENU-ITEMS | 2026-03-22 | 2026-06-22 | marks, annotations, and alert-on-mark UI |
| REF-ITERM2-ONE-PAGE | 2026-03-22 | 2026-06-22 | command history and recent directories keyed by username+hostname |
| REF-ITERM2-PREFERENCES-GENERAL | 2026-03-22 | 2026-06-22 | explicit save-to-disk policy for copy/paste history, command history, directory history, and remote host/user breadcrumbs |
| REF-ITERM2-RPCS | 2026-03-22 | 2026-06-22 | daemon-registered functions, invocation context filling, and global namespace caution |
| REF-ITERM2-SEMANTIC-HISTORY | 2026-03-22 | 2026-06-22 | per-line cwd tracked for open/edit routing and semantic history commands |
| REF-ITERM2-SESSION-RESTORATION | 2026-03-22 | 2026-06-22 | long-lived server reconnection versus content-only restoration |
| REF-ITERM2-SHELL-INTEGRATION | 2026-03-22 | 2026-06-22 | shell integration tracks command history, cwd, hostname, and remote-aware context |
| REF-ITERM2-STATUS-BAR | 2026-03-22 | 2026-06-22 | status bar shows cwd, host, user, and job as observational chrome fed by shell integration |
| REF-ITERM2-TMUX-INTEGRATION | 2026-03-21 | 2026-06-21 | tmux client crash can require stty sane to restore terminal state |
| REF-ITERM2-VARIABLES | 2026-03-22 | 2026-06-22 | session-scoped user variables suggest a good pattern for observational chrome and semantic shell memory |
| REF-K8S-APF | 2026-03-23 | 2026-09-23 | official queueing, fair isolation, and overload-admission behavior for kube-apiserver |
| REF-K8S-API-CONCEPTS | 2026-03-23 | 2026-06-23 | watch resourceVersion, bookmark events, streaming lists, and 410 Gone continuity-loss semantics |
| REF-K8S-DECLARATIVE-CONFIG | 2026-03-23 | 2026-06-23 | kubectl diff uses server-side dry-run and still requires real permissions |
| REF-K8S-DEPLOYMENT | 2026-03-23 | 2026-06-23 | pause-the-rollout use case plus progressDeadlineSeconds / minReadySeconds rollout truth |
| REF-K8S-ENDPOINTSLICES | 2026-03-23 | 2026-06-23 | official serving and terminating endpoint conditions for traffic-serving truth during drain/termination |
| REF-K8S-KUBELET-CONFIG | 2026-03-23 | 2026-06-23 | CrashLoopBackOffConfig maxContainerRestartPeriod bounds restart-delay accrual for container restarts |
| REF-K8S-LEASES | 2026-03-22 | 2026-06-22 | Lease objects, renewTime heartbeats, and lease-based coordination without implying a giant portable lease plane |
| REF-K8S-NODE-PRESSURE-EVICTION | 2026-03-23 | 2026-06-23 | node-pressure signals, reclaim-before-evict behavior, and eviction ordering under resource scarcity |
| REF-K8S-POD-LIFECYCLE | 2026-03-23 | 2026-06-23 | probe outcome and restart/removal consequences stay distinct |
| REF-K8S-PODS-OBSERVED-GENERATION | 2026-03-23 | 2026-06-23 | status.observedGeneration as a tiny stale-fence between latest desired spec and the generation current status actually reflects |
| REF-K8S-PROBES | 2026-03-23 | 2026-06-23 | explicit startup/readiness/liveness split with startup shielding |
| REF-K8S-RESOURCE-QUOTAS | 2026-03-23 | 2026-06-23 | hard quota enforcement, explicit 403 rejections, and namespace-scoped resource ceilings |
| REF-K8S-ROLLOUT-PAUSE | 2026-03-23 | 2026-06-23 | paused resources are not reconciled by a controller while current deployment state can keep functioning |
| REF-K8S-ROLLOUT-RESUME | 2026-03-23 | 2026-06-23 | resuming re-allows controller reconciliation for a paused deployment |
| REF-K8S-STATEFULSET | 2026-03-23 | 2026-06-23 | minReadySeconds / ordered rollout wait semantics |
| REF-KITTY-ACTIONS | 2026-03-22 | 2026-06-22 | command palette exposes mapped actions while shell-integration-powered output actions remain explicit |
| REF-KITTY-CHOOSE-FILES | 2026-03-22 | 2026-06-22 | exact file chooser semantics and chooser-default ephemerality ideas |
| REF-KITTY-CLIPBOARD | 2026-03-22 | 2026-06-22 | typed clipboard protocol and permission prompts |
| REF-KITTY-CONF | 2026-03-23 | 2026-06-23 | tab/window title templates, activity/progress label chrome, and clickable-link policy surfaces |
| REF-KITTY-DESKTOP-NOTIFICATIONS | 2026-03-22 | 2026-06-22 | SSH-capable notification transport and filtering ideas |
| REF-KITTY-FILE-TRANSFER-PROTOCOL | 2026-03-22 | 2026-06-22 | user-approved transfer sessions and explicit authorization boundary |
| REF-KITTY-GRAPHICS-PROTOCOL | 2026-03-23 | 2026-06-23 | pixel graphics integrated with text, alpha blending, scroll-with-text behavior, and local optimization goals |
| REF-KITTY-HINTS | 2026-03-22 | 2026-06-22 | visible-text selection and exact follow-on action inspiration |
| REF-KITTY-KEYBOARD-PROTOCOL | 2026-03-21 | 2026-06-21 | enhanced key event protocol with broader terminal adoption |
| REF-KITTY-LAUNCH | 2026-03-22 | 2026-06-22 | explicit launch recipes with cwd source classes, copied command/env caveats, and focus/location controls |
| REF-KITTY-MAPPING | 2026-03-23 | 2026-06-23 | multi-key mappings, modal mappings, send_text/send_key injection, unknown-key handling, and debug facilities |
| REF-KITTY-NOTIFY | 2026-03-22 | 2026-06-22 | SSH-capable notifications with optional activation/callback flow |
| REF-KITTY-OPEN-ACTIONS | 2026-03-21 | 2026-06-21 | hyperlink/open-action routing ideas for explicit terminal affordances |
| REF-KITTY-PROTOCOL-EXTENSIONS | 2026-03-21 | 2026-06-21 | small unobtrusive terminal extension philosophy and extensibility ideas |
| REF-KITTY-RC-PROTOCOL | 2026-03-22 | 2026-06-22 | json command envelopes, encrypted password auth, async ids, and streaming requests |
| REF-KITTY-REMOTE-CONTROL | 2026-03-22 | 2026-06-22 | fine-grained remote-control permissions, interactive approval, and custom authorization hooks |
| REF-KITTY-REMOTE-FILES | 2026-03-22 | 2026-06-22 | exact remote-file edit/open/download actions and nested-SSH limits |
| REF-KITTY-SHELL-INTEGRATION | 2026-03-23 | 2026-06-23 | prompt marks, exact-output paging, click-to-move, and remote cwd carry ideas |
| REF-KITTY-SSH | 2026-03-23 | 2026-06-23 | remote-aware shell integration transport ideas |
| REF-KITTY-TRANSFER | 2026-03-22 | 2026-06-22 | transfer over the TTY, nested-hop capability, and directory-preserving copies |
| REF-KUBECTL-DIFF | 2026-03-23 | 2026-06-23 | preview diff status semantics |
| REF-KUBECTL-DRAIN | 2026-03-23 | 2026-06-23 | drain, force, and disable-eviction semantics including explicit PDB bypass |
| REF-LANDLOCK-USERSPACE | 2026-03-23 | 2026-06-23 | stackable unprivileged restriction layers and ambient-rights reduction precedent |
| REF-LAUNCH-ACTIVATE-SOCKET | 2026-03-22 | 2026-06-22 | exact launchd socket retrieval keeps activation delivery explicit rather than ambient inheritance folklore |
| REF-LAUNCHD-JOBS | 2026-03-23 | 2026-06-23 | launchd job lifecycle, on-demand starts, and manager-owned launch context |
| REF-LAUNCHD-SOCKETS | 2026-03-23 | 2026-09-23 | socket activation and explicit socket delivery / check-in semantics |
| REF-LAUNCHD-XPC | 2026-03-21 | 2026-09-21 | activation and IPC adjacency |
| REF-LINUX-CGROUP-V2 | 2026-03-23 | 2026-06-23 | hierarchical process grouping and monotonic controller restrictions under the membrane |
| REF-LINUX-CHILD-SUBREAPER | 2026-03-23 | 2026-06-23 | subreaper orphan-adoption primitive useful for under-the-membrane child accounting |
| REF-LINUX-CLOSE-RANGE | 2026-03-22 | 2026-09-22 | bulk descriptor cleanup and unshare for launch hygiene |
| REF-LINUX-F-ADD-SEALS | 2026-03-23 | 2026-06-23 | one-way sealing semantics for immutable local activation capsules |
| REF-LINUX-MEMFD-CREATE | 2026-03-23 | 2026-06-23 | anonymous local file objects suitable for immutable startup capsule tricks under the membrane |
| REF-LINUX-PIDFD-OPEN | 2026-03-23 | 2026-06-23 | non-reused process observation handles and pollable wait semantics |
| REF-LINUX-PSI | 2026-03-23 | 2026-06-23 | cpu/memory/io stall pressure with scoped some/full semantics and dynamic-management guidance |
| REF-LINUX-WAITID-PIDFD | 2026-03-23 | 2026-06-23 | waiting on child exit via P_PIDFD |
| REF-MACAROONS | 2026-03-23 | 2026-06-23 | attenuation via caveats and decentralized derivation of more restricted credentials |
| REF-MOSH | 2026-03-21 | 2026-06-21 | roaming, intermittent connectivity, and predictive local echo ideas |
| REF-MOSH-PAPER | 2026-03-21 | 2026-06-21 | predictive client-side echo, application-layer framing, and intermittent-connectivity design lessons |
| REF-NCURSES-FAQ | 2026-03-21 | 2026-09-21 | terminal capability mismatch and pessimistic compatibility lessons |
| REF-NOMAD-CHECK-RESTART | 2026-03-23 | 2026-06-23 | unhealthy checks spend against explicit restart policy rather than a hidden recovery path |
| REF-NOMAD-DEPLOYMENT-STATUS | 2026-03-23 | 2026-06-23 | desired changes versus currently applied changes plus monitor/auto-revert deployment truth |
| REF-NOMAD-DISCONNECT | 2026-03-23 | 2026-06-23 | reconnect grace, unknown state, and replacement remaining distinct from restart or drain migration |
| REF-NOMAD-LIFECYCLE | 2026-03-23 | 2026-06-23 | prestart/poststart/poststop helpers and sidecar distinction as a pattern library |
| REF-NOMAD-NODE-DRAIN | 2026-03-23 | 2026-06-23 | drain mode prevents new tasks, migrates or completes existing allocations, and can stay ineligible for inspection |
| REF-NOMAD-QUOTA | 2026-03-23 | 2026-06-23 | region and namespace scoped cumulative resource ceilings including cpu, memory, devices, storage, and node pools |
| REF-NOMAD-RESCHEDULE | 2026-03-23 | 2026-06-23 | reschedule after restart exhaustion, drain/node-loss distinction, and retry window/delay semantics |
| REF-NOMAD-RESTART | 2026-03-23 | 2026-06-23 | local restart attempts and delay window kept separate from later rescheduling |
| REF-NOMAD-UPDATE | 2026-03-23 | 2026-06-23 | min_healthy_time / healthy_deadline / progress_deadline rollout gating |
| REF-NUSHELL-CUSTOM-COMPLETIONS | 2026-03-23 | 2026-06-23 | context-aware completions, completer-provided descriptions/styles, and advisory completion metadata |
| REF-NUSHELL-PIPELINES | 2026-03-22 | 2026-06-22 | structured pipeline values instead of string-only shell glue |
| REF-OAUTH-RFC6749 | 2026-03-23 | 2026-06-23 | single-use, short-lived authorization-code precedent for consumable transient grants |
| REF-OPENBSD-PLEDGE | 2026-03-23 | 2026-06-23 | one-way promise reduction precedent for monotonic authority narrowing |
| REF-OPENBSD-UNVEIL | 2026-03-22 | 2026-06-22 | lockable path-allowlist confinement precedent |
| REF-OPENRC-SUPERVISE-DAEMON | 2026-03-21 | 2026-09-21 | healthcheck and restart-adjunct guidance |
| REF-OSC133-SPEC | 2026-03-21 | 2026-06-21 | prompt/input/output marker vocabulary |
| REF-PLAN9-PLUMBING | 2026-03-22 | 2026-06-22 | message routing and typed plumb targets |
| REF-POSIX-TCSETPGRP | 2026-03-23 | 2026-06-23 | legacy terminal foreground-process-group semantics as a caution against freezing job-control worldview into Steward |
| REF-PSREADLINE-PREDICTORS | 2026-03-23 | 2026-06-23 | prediction source labels, inline versus list presentation, and accept-suggestion-by-word editor moves |
| REF-RFC6585 | 2026-03-23 | 2026-09-23 | official 429 Too Many Requests semantics and optional Retry-After guidance |
| REF-RFC8252-NATIVE-APPS | 2026-03-23 | 2026-06-23 | external-browser auth, exact redirect verification, and anti-embedded-user-agent lessons for shell detours |
| REF-RFC8693-TOKEN-EXCHANGE | 2026-03-23 | 2026-06-23 | attenuation-friendly token exchange, delegation vs impersonation, target resource/audience/scope, and no automatic live linkage between parent and child tokens |
| REF-RFC8705-MTLS | 2026-03-23 | 2026-06-23 | certificate-bound access and refresh tokens using mutual TLS so presented tokens must match the client certificate binding |
| REF-RFC9449-DPOP | 2026-03-23 | 2026-06-23 | sender-constrained tokens bound to a public key, per-request proof, target URI/method checks, and denial when proof or binding fails |
| REF-RFC9700-OAUTH-SECURITY-BCP | 2026-03-23 | 2026-06-23 | BCP recommending sender-constrained tokens and audience restriction to limit replay and leakage impact |
| REF-RUNIT-OVERVIEW | 2026-03-21 | 2026-09-21 | small service-supervision precedent |
| REF-S6-NOTIFYONCHECK | 2026-03-22 | 2026-06-22 | external readiness polling can be explicit but remains suboptimal compared with direct readiness signals |
| REF-S6-RC-OVERVIEW | 2026-03-22 | 2026-06-22 | oneshot versus longrun distinctions and ordered dependency transitions |
| REF-S6-RC-TRANSITIONS | 2026-03-21 | 2026-09-21 | transition accounting and known-down-state lessons |
| REF-S6-RC-UPDATE | 2026-03-23 | 2026-06-23 | computed live-state transitions, dry-run, and fail-rather-than-guess posture |
| REF-S6-RC-WHY | 2026-03-21 | 2026-09-21 | service-manager decomposition lesson |
| REF-S6-READY | 2026-03-21 | 2026-09-21 | readiness is not spawn success |
| REF-S6-SERVICEDIR | 2026-03-22 | 2026-06-22 | service directory semantics and the long-lived run-script leaf |
| REF-S6-SHALLOW-READINESS | 2026-03-21 | 2026-09-21 | shallow readiness warning and control-plane readiness distinction |
| REF-S6-SUPERVISE | 2026-03-22 | 2026-09-22 | foreground leaf supervision and explicit run/finish discipline |
| REF-SD-LISTEN-FDS-WITH-NAMES | 2026-03-22 | 2026-06-22 | named activation fd delivery / LISTEN_FDNAMES semantics |
| REF-SD-NOTIFY | 2026-03-23 | 2026-06-23 | READY/RELOADING/STOPPING plus explicit watchdog and timeout-extension handshake |
| REF-SD-WATCHDOG-ENABLED | 2026-03-23 | 2026-06-23 | manager-expected watchdog renewal is explicit, discoverable, and separate from broader service health |
| REF-SMF-MAINTENANCE | 2026-03-22 | 2026-09-22 | maintenance state and explicit clear/repair semantics |
| REF-SOLARIS-PROCESS-CONTRACTS | 2026-03-23 | 2026-06-23 | process contracts as create/control/observe objects and SMF failure attribution across multi-process services |
| REF-SOLARIS-SMF-CONTRACT-SERVICE | 2026-03-23 | 2026-06-23 | contract or daemon service model for several related processes managed as one service |
| REF-SOLARIS-SMF-RESTARTER | 2026-03-21 | 2026-09-21 | restarter pattern |
| REF-SYSTEMCTL | 2026-03-23 | 2026-06-23 | freeze/thaw, mask/unmask, and reset-failed semantics for explicit held versus start-prevented truth |
| REF-SYSTEMD-DAEMON | 2026-03-22 | 2026-06-22 | new-style daemon baseline and no-ambient launch guidance |
| REF-SYSTEMD-EXEC | 2026-03-21 | 2026-06-21 | per-runtime-cycle invocation identity and execution environment |
| REF-SYSTEMD-FDSTORE | 2026-03-23 | 2026-06-23 | bounded continuity-store and redelivery semantics |
| REF-SYSTEMD-INHIBIT-MAN | 2026-03-22 | 2026-06-22 | live bounded delay/block command-wrapper semantics |
| REF-SYSTEMD-INHIBITOR-LOCKS | 2026-03-22 | 2026-06-22 | official inhibitor-lock semantics and block/delay context |
| REF-SYSTEMD-MEMORY-PRESSURE | 2026-03-23 | 2026-06-23 | PSI-backed service-manager protocol for early memory-pressure handling and cache trimming |
| REF-SYSTEMD-RUN | 2026-03-21 | 2026-06-21 | official transient service/scope unit precedent |
| REF-SYSTEMD-SD-LISTEN-FDS | 2026-03-21 | 2026-06-21 | listener handoff |
| REF-SYSTEMD-SERVICE | 2026-03-23 | 2026-06-23 | service timeout and watchdog semantics for notify-capable services |
| REF-SYSTEMD-SOCKET-ACTIVATION | 2026-03-21 | 2026-06-21 | socket activation semantics |
| REF-SYSTEMD-UNIT | 2026-03-22 | 2026-06-22 | masked load state and stronger-than-disable start prevention context |
| REF-TERRAFORM-APPLY | 2026-03-23 | 2026-06-23 | saved plan apply semantics and approval boundary |
| REF-TERRAFORM-PLAN | 2026-03-23 | 2026-06-23 | speculative versus saved plan preview semantics |
| REF-TMUX-CHANGES | 2026-03-21 | 2026-06-21 | control-mode subscription and pause/resume fairness lessons |
| REF-TMUX-CONTROL-MODE | 2026-03-21 | 2026-06-21 | parseable text protocol with notifications and flow control |
| REF-VSCODE-AGENT-PLANNING | 2026-03-23 | 2026-06-23 | separate planning lane and session-scoped plan memory |
| REF-VSCODE-AGENT-TOOLS | 2026-03-23 | 2026-06-23 | tool approval can be one use, current session, current workspace, or future invocations; shell integration quality matters for terminal agents |
| REF-VSCODE-AI-SETTINGS | 2026-03-23 | 2026-06-23 | enterprise policy can hide higher autonomy rungs, force approval for specific tools, and disable terminal auto-approval |
| REF-VSCODE-INLINE-CHAT | 2026-03-23 | 2026-06-23 | terminal inline chat keeps suggestions inline but still routes through explicit Run versus Insert review |
| REF-VSCODE-SHELL-INTEGRATION | 2026-03-21 | 2026-06-21 | command detection, cwd, navigation, decorations |
| REF-VSCODE-SHELL-TRUST | 2026-03-21 | 2026-06-21 | trusted shell marker provenance and confidence model |
| REF-VSCODE-TERMINAL-ADVANCED | 2026-03-22 | 2026-06-22 | persistent sessions, reconnect/revive split, and environment inheritance cautions |
| REF-VSCODE-TERMINAL-BASICS | 2026-03-23 | 2026-06-23 | detected link classes, keyboard-accessible link opening, and file-link verification tradeoffs |
| REF-VSCODE-TERMINAL-LINK-PROVIDER | 2026-03-23 | 2026-06-23 | terminal link providers, handler callbacks, and trusted shell integration nonce relevance for rerun/open UX |
| REF-VSCODE-TERMINAL-PROFILES | 2026-03-22 | 2026-06-22 | reviewed shell profiles, unsafe profile detection, and explicit default-profile selection |
| REF-VSCODE-UPDATE-1066 | 2026-03-22 | 2026-06-22 | terminal scroll-bar annotations and command navigation |
| REF-VSCODE-UPDATE-1072 | 2026-03-22 | 2026-06-22 | terminal quick fixes as explicit user-invoked suggestions tied to shell integration |
| REF-VSCODE-UPDATE-1099 | 2026-03-23 | 2026-06-23 | rich versus basic versus none shell integration quality and detailed terminal diagnostics |
| REF-VSCODE-UPDATE-1102 | 2026-03-22 | 2026-06-22 | terminal suggest selection mode, multi-command support, and discoverability affordances |
| REF-VSCODE-UPDATE-1103 | 2026-03-22 | 2026-06-22 | terminal shell integration diagnostics / shell details |
| REF-VSCODE-UPDATE-1104 | 2026-03-22 | 2026-06-22 | terminal sticky scroll defaults / pager behavior |
| REF-VSCODE-UPDATE-1106 | 2026-03-21 | 2026-06-21 | attach terminal command to chat with command line, captured output, and exit code; hidden terminal reveal UX |
| REF-VSCODE-UPDATE-1107 | 2026-03-21 | 2026-06-21 | command status details in chat terminals, including start time, duration, and exit code |
| REF-VSCODE-UPDATE-1108 | 2026-03-22 | 2026-06-22 | shell-history suppression and explicit session/workspace allow rules for terminal tool commands |
| REF-VSCODE-UPDATE-1109 | 2026-03-22 | 2026-06-22 | richer terminal command details and kitty keyboard protocol support in the integrated terminal |
| REF-VSCODE-UPDATE-1110 | 2026-03-21 | 2026-06-21 | collapsible terminal command sections for scanable exact command/output review |
| REF-VSCODE-UPDATE-1111 | 2026-03-23 | 2026-06-23 | session-scoped permission picker distinguishes Default Approvals, Bypass Approvals, and Autopilot |
| REF-WARP-AGENT-MODALITY | 2026-03-23 | 2026-06-23 | explicit shell versus agent mode, conversation-local command traces, and lane-scoped controls |
| REF-WARP-AGENT-PROFILES | 2026-03-23 | 2026-06-23 | Agent Decides, Always ask, Always allow, Never, denylist precedence, and run-until-completion as a stronger autonomy rung |
| REF-WARP-BLOCKS | 2026-03-21 | 2026-06-21 | command-plus-output block idea |
| REF-WARP-COMMAND-SEARCH | 2026-03-22 | 2026-06-22 | unified remembered search spanning command history, workflows, environment variables, notebooks, prompts, and conversation history |
| REF-WARP-ENV-VARS | 2026-03-22 | 2026-06-22 | click-to-load session env bundles, subshell-scoped loads, and command-backed dynamic secret retrieval |
| REF-WARP-FULL-TERMINAL-USE | 2026-03-23 | 2026-06-23 | agent can attach to active PTY, propose actions in-session, and optionally widen approval within that session |
| REF-WARP-NOTEBOOKS | 2026-03-23 | 2026-06-23 | command blocks can insert into active terminal input rather than requiring silent immediate execution |
| REF-WARP-SSH | 2026-03-22 | 2026-06-22 | explicit consent, helper installation, and remote wrapper setup for richer terminal UX over SSH |
| REF-WARP-WORKFLOWS | 2026-03-23 | 2026-06-23 | workflow search and palette entries paste into active terminal input with editable arguments instead of silently executing |
| REF-WEZTERM-AUGMENT-COMMAND-PALETTE | 2026-03-22 | 2026-06-22 | explicit synchronous extension of command-palette entries with docs and actions |
| REF-WEZTERM-CLI | 2026-03-22 | 2026-06-22 | explicit cli-versus-gui split and experimental mux-server control path |
| REF-WEZTERM-FORMAT-TAB-TITLE | 2026-03-23 | 2026-06-23 | tab titles prefer explicitly set tab titles and otherwise fall back to active pane title; synchronous GUI-thread formatting caution |
| REF-WEZTERM-HYPERLINKS | 2026-03-23 | 2026-06-23 | OSC 8 explicit hyperlinks and hyperlink_rules/custom link recognition |
| REF-WEZTERM-IMGCAT | 2026-03-23 | 2026-06-23 | WezTerm imgcat support for the iTerm2 inline-image protocol, cursor-control extension, and explicit multiplexer limitation note |
| REF-WEZTERM-KEYBOARD-CONCEPTS | 2026-03-23 | 2026-06-23 | physical versus mapped keys, IME, dead keys, and stacked key-table concepts |
| REF-WEZTERM-KEYBOARD-ENCODING | 2026-03-23 | 2026-06-23 | xterm-compatible default encoding, modifyOtherKeys support, CSI-u caveats, and kitty keyboard protocol support |
| REF-WEZTERM-LAUNCH-MENU | 2026-03-22 | 2026-06-22 | launcher menu entries are explicit SpawnCommand objects with label, args, cwd, and env context |
| REF-WEZTERM-LAUNCHING-PROGRAMS | 2026-03-22 | 2026-06-22 | explicit default program and cwd rules; OSC 7 based cwd inheritance; $SHELL deliberately ignored unless explicitly overridden |
| REF-WEZTERM-MULTIPLEXING | 2026-03-22 | 2026-06-22 | persisting local tabs/windows and explicit domain model |
| REF-WEZTERM-NOTIFICATION-HANDLING | 2026-03-21 | 2026-06-21 | focus-aware toast notification handling and OSC 9 / 777 examples for attention-hint ideas |
| REF-WEZTERM-OPEN-URI | 2026-03-23 | 2026-06-23 | click/open event interception with explicit URI target and default-browser override behavior |
| REF-WEZTERM-PANE-INFORMATION | 2026-03-22 | 2026-06-22 | pane chrome can be built from explicit snapshots carrying user vars and progress state |
| REF-WEZTERM-PANE-USER-VARS | 2026-03-23 | 2026-06-23 | pane/user variables as a precedent for scoped observational shell context |
| REF-WEZTERM-RIGHT-STATUS | 2026-03-21 | 2026-06-21 | right status area in tab bar using pane cwd/hostname, including remote host via OSC 7 |
| REF-WEZTERM-SCROLL-TO-PROMPT | 2026-03-22 | 2026-06-22 | semantic prompt zones can power exact jump and selection actions without screen scraping |
| REF-WEZTERM-SEMANTIC-ZONE-AT | 2026-03-23 | 2026-06-23 | resolve exact semantic zone under a cell for line-local terminal actions |
| REF-WEZTERM-SEMANTIC-ZONES | 2026-03-23 | 2026-06-23 | prompt/input/output semantic-zone enumeration for exact terminal actions |
| REF-WEZTERM-SHELL-INTEGRATION | 2026-03-23 | 2026-06-23 | OSC 7/133/1337 shell integration and semantic zones for cwd, prompt/input/output, and additional shell state |
| REF-WEZTERM-SPAWNCOMMAND | 2026-03-22 | 2026-06-22 | explicit cwd and domain selection for new spawns; current pane domain as a named default |
| REF-WEZTERM-SYNC-RENDER | 2026-03-21 | 2026-06-21 | DECSET 2026 synchronized rendering as optional redraw batching hint |
| REF-WHATWG-SSE | 2026-03-23 | 2026-06-23 | Last-Event-ID reconnection precedent for resume-friendly opaque observation cursors on simple transports |
| REF-WINDOWS-JOB-OBJECTS | 2026-03-23 | 2026-06-23 | exact host-side workload grouping, aggregate accounting, waitability, and kill-on-close semantics |
| REF-WINDOWS-TERMINAL-ACTIONS | 2026-03-22 | 2026-06-22 | addMark and scrollToMark actions |
| REF-WINDOWS-TERMINAL-ADVANCED-PROFILE | 2026-03-22 | 2026-06-22 | autoMarkPrompts / scrollbar marks / prompt-click settings |
| REF-WINDOWS-TERMINAL-COMMAND-PALETTE | 2026-03-22 | 2026-06-22 | nested and iterable command-palette entries show explicit dynamic launch/action discovery |
| REF-WINDOWS-TERMINAL-INTERACTION | 2026-03-22 | 2026-06-22 | copy-on-select and copy formatting modes |
| REF-WINDOWS-TERMINAL-PROGRESS | 2026-03-21 | 2026-09-21 | OSC 9;4 progress ring/taskbar progress support as capability-gated progress hint precedent |
| REF-WINDOWS-TERMINAL-SAME-DIRECTORY | 2026-03-22 | 2026-06-22 | same-directory tab/pane spawning via explicit shell-reported cwd rather than ambient process guessing |
| REF-WINDOWS-TERMINAL-SHELL-INTEGRATION | 2026-03-22 | 2026-06-22 | stable marks, shell integration sequences, and exact output selection |
| REF-WINDOWS-TERMINAL-STARTUP | 2026-03-22 | 2026-06-22 | persisted window layout semantics and saved cwd caveat |
| REF-WINDOWS-TERMINAL-TAB-TITLE | 2026-03-23 | 2026-06-23 | starting profile tabTitle versus shell-controlled titles and shell-specific override behavior |
| REF-WINDOWS-TERMINAL-TIPS | 2026-03-21 | 2026-06-21 | smart tab titles and chrome-oriented shell integration tips separate from transcript output |
| REF-WINDOWS-TERMINATE-JOB-OBJECT | 2026-03-23 | 2026-06-23 | whole-job forced termination semantics for nested workload groups |
| REF-XDG-ACTIVATION-V1 | 2026-03-23 | 2026-06-23 | activation token semantics and compositor discretion |
| REF-XDG-PORTAL-GLOBALSHORTCUTS | 2026-03-22 | 2026-06-22 | session-scoped out-of-focus shortcut registration and signals |
| REF-XDG-PORTAL-INHIBIT | 2026-03-22 | 2026-06-22 | handle-scoped session-transition inhibition via portal request close |
| REF-XDG-PORTAL-INPUTCAPTURE | 2026-03-22 | 2026-06-22 | requested versus active input capture state and compositor control |
| REF-XDG-PORTAL-OPENURI | 2026-03-23 | 2026-06-23 | open-uri launch with separate activation-token hint and request handle |
| REF-XDG-PORTAL-REMOTE-DESKTOP | 2026-03-23 | 2026-06-23 | session handles plus single-use restore tokens suggest explicit expiring detour-return or resume objects |
| REF-XDG-PORTAL-REQUEST | 2026-03-23 | 2026-06-23 | explicit request-handle lifetime and eventual response for mediated UI interactions |
| REF-XDG-PORTAL-SESSION | 2026-03-23 | 2026-06-23 | long-lived session handle with explicit close and closed signal for portal-mediated sessions |
| REF-XPC-TRANSACTION-BEGIN | 2026-03-21 | 2026-09-21 | explicit in-flight transaction hint for idle policy |
| REF-XPC-TRANSACTION-END | 2026-03-21 | 2026-09-21 | explicit end of in-flight transaction hint |
| REF-XTERM-BRACKETED-PASTE | 2026-03-22 | 2026-06-22 | paste demarcation precedent |
| REF-XTERM-CTLSEQS | 2026-03-23 | 2026-06-23 | classic OSC 0/1/2 title-setting and title/window query control sequences as a provenance/security reminder |
| REF-XTERM-FAQ | 2026-03-21 | 2026-09-21 | TERM=xterm compatibility folklore cautions and terminal-description drift lessons |
| REF-XTERM-MANPAGE | 2026-03-21 | 2026-06-21 | full reset behavior including bracketed paste and title/pointer mode reset |
| REF-XTERM-MODIFIED-KEYS | 2026-03-23 | 2026-06-23 | modifyOtherKeys quirks and how xterm derives modified-key escape sequences from lookup strings plus original modifiers |
| REF-ZELLIJ-FEATURES | 2026-03-22 | 2026-06-22 | command panes, start_suspended, floating panes, and workspace-oriented UI ideas |
| REF-ZELLIJ-FILEPICKER | 2026-03-22 | 2026-06-22 | pane-cwd rooted picker and exact open-here ideas |
| REF-ZELLIJ-PLUGIN-PIPES | 2026-03-22 | 2026-06-22 | declared chooser-output piping between terminal surfaces |
| REF-ZELLIJ-PLUGINS | 2026-03-22 | 2026-06-22 | plugins as first-class workspace panes for inspector/tool surface inspiration |
| REF-ZELLIJ-RELEASE-044 | 2026-03-23 | 2026-06-23 | recent terminal workspace ideas including read-only sharing and explicit remote attach |
| REF-ZELLIJ-SESSION-RESURRECTION | 2026-03-23 | 2026-06-23 | session resurrection, revive/replay UX, and remembered-context cautions |
| REF-ZOOKEEPER-PROGRAMMER | 2026-03-23 | 2026-06-23 | ephemeral znodes tied to session lifetime with service-discovery relevance |
