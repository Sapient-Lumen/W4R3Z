# Evidence index

| EVID-ID | Kind | Description | Artifact |
| --- | --- | --- | --- |
| EVID-2026-001 | process | Initial Steward repo hygiene established: lint, context pack, package-release, verify-release. | `tools/` |
| EVID-2026-002 | research | Curated external-source lock set for the first Steward research pass. | `docs/00-meta/external-source-locks.json` |
| EVID-2026-003 | archive | First packaged Steward handoff archive with embedded manifest. | packaged zip |
| EVID-2026-004 | research | Second-pass research refresh covering daemontools, runit, launchd socket semantics, and block-oriented terminal ideas. | `docs/90-inspirations/` |
| EVID-2026-005 | process | External source review queue is generated from the lock file to reduce stale research metadata. | `tools/gen_external_source_review_queue.py` |
| EVID-2026-006 | archive | Second packaged Steward handoff archive with refreshed context pack and source-intake hygiene. | packaged zip |
| EVID-2026-007 | research | Seventh-pass research refresh covering D-Bus system activation, systemd transient units, Mosh resilience, and Ghostty command-finish notification ideas. | `docs/90-inspirations/` |
| EVID-2026-008 | archive | Seventh packaged Steward handoff archive with transient-promotion posture and refreshed source locks. | packaged zip |
| EVID-2026-009 | research | Eighth-pass research refresh covering per-runtime-cycle identity, stale-action fences, and semantic shell ancestry. | `docs/90-inspirations/` |
| EVID-2026-010 | archive | Eighth packaged Steward handoff archive with runtime-cycle witness posture and refreshed source locks. | packaged zip |
