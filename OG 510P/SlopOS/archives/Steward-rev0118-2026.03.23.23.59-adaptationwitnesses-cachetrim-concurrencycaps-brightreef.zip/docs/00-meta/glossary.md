# Glossary

- **Steward** — the SlopOS component lifecycle and activation fabric.
- **component root** — the explicit lifecycle target for supervision; not a raw PID or process subtree.
- **activation set** — the descriptive manifest of handles delivered when a component starts.
- **continuity escrow** — bounded, same-component carry-over of allowlisted handles or state across restart.
- **readiness** — “able to serve its declared role,” distinct from successful spawn.
- **startup** — initial boot/bring-up interval before readiness is expected.
- **liveness** — continued health / ability to make forward progress.
- **quiesce** — cooperative local gating and draining of new work.
- **semantic shell/terminal channel** — explicit side channel for prompts, command boundaries, working directory, marks, and receipts; not inferred from raw PTY bytes.
- **runtime-cycle witness** — opaque identifier for one concrete active/recent run of a component; distinct from component identity and from raw process IDs.
