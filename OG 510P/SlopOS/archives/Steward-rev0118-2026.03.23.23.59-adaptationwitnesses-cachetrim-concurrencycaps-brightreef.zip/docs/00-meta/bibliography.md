# Bibliography

External references locked for this archive.
- **REF-APPLE-INHERITING-FDS** — `Secure Coding Guide: Inheriting File Descriptors`. Retrieved 2026-03-22. URL: https://developer.apple.com/library/archive/documentation/Security/Conceptual/SecureCodingGuide/Articles/AccessControl.html

- **REF-AWS-EC2-IDEMPOTENCY** — `Ensuring idempotency in Amazon EC2 API requests`. Retrieved 2026-03-22. URL: https://docs.aws.amazon.com/ec2/latest/devguide/ec2-api-idempotency.html

- **REF-AWS-ECS-IDEMPOTENCY** — `Ensuring idempotency - Amazon Elastic Container Service`. Retrieved 2026-03-22. URL: https://docs.aws.amazon.com/AmazonECS/latest/APIReference/ECS_Idempotency.html

- **REF-AWS-S3-CONDITIONAL-WRITES** — `How to prevent object overwrites with conditional writes - Amazon S3`. Retrieved 2026-03-23. URL: https://docs.aws.amazon.com/AmazonS3/latest/userguide/conditional-writes.html

- **REF-AWS-STS-ASSUMEROLE** — `AssumeRole - AWS Security Token Service`. Retrieved 2026-03-23. URL: https://docs.aws.amazon.com/STS/latest/APIReference/API_AssumeRole.html

- **REF-BASH-READLINE-INIT** — `Readline Init File Syntax`. Retrieved 2026-03-22. URL: https://www.gnu.org/software/bash/manual/html_node/Readline-Init-File-Syntax.html

- **REF-CLAUDE-CODE-PERMISSIONS** — `Configure permissions - Claude Code Docs`. Retrieved 2026-03-23. URL: https://code.claude.com/docs/en/permissions

- **REF-CONSUL-AGENT-CHECK** — `Check - Agent - HTTP API | Consul`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/consul/api-docs/agent/check

- **REF-CRASH-ONLY-SOFTWARE** — `Crash-Only Software | USENIX`. Retrieved 2026-03-23. URL: https://www.usenix.org/conference/hotos-ix/crash-only-software

- **REF-DAEMONTOOLS-SUPERVISE** — `The supervise program`. Retrieved 2026-03-21. URL: https://cr.yp.to/daemontools/supervise.html

- **REF-DBUS-API-DESIGN** — `D-Bus API Design Guidelines`. Retrieved 2026-03-21. URL: https://dbus.freedesktop.org/doc/dbus-api-design.html

- **REF-DBUS-SPECIFICATION** — `dbus-specification.xml`. Retrieved 2026-03-23. URL: https://cgit.freedesktop.org/dbus/dbus/tree/doc/dbus-specification.xml

- **REF-DBUS-SYSTEM-ACTIVATION** — `system-activation.txt`. Retrieved 2026-03-21. URL: https://dbus.freedesktop.org/doc/system-activation.txt

- **REF-DESKTOP-ENTRY-DBUS-ACTIVATION** — `D-Bus Activation | Desktop Entry Specification`. Retrieved 2026-03-23. URL: https://specifications.freedesktop.org/desktop-entry/latest/dbus.html

- **REF-DESKTOP-NOTIFICATIONS-SPEC** — `Desktop Notifications Specification`. Retrieved 2026-03-22. URL: https://specifications.freedesktop.org/notification/latest-single

- **REF-DINIT-OVERVIEW** — `Dinit overview`. Retrieved 2026-03-21. URL: https://davmac.org/projects/dinit/

- **REF-DINIT-SERVICE** — `dinit-service(5)`. Retrieved 2026-03-21. URL: https://davmac.org/projects/dinit/man-pages-html/dinit-service.5.html

- **REF-ENVOY-ADAPTIVE-CONCURRENCY** — `Adaptive Concurrency`. Retrieved 2026-03-23. URL: https://www.envoyproxy.io/docs/envoy/latest/configuration/http/http_filters/adaptive_concurrency_filter

- **REF-ENVOY-HEALTHCHECKING** — `Health checking — envoy documentation`. Retrieved 2026-03-23. URL: https://www.envoyproxy.io/docs/envoy/latest/intro/arch_overview/upstream/health_checking

- **REF-ENVOY-OVERLOAD-MANAGER** — `Overload manager`. Retrieved 2026-03-23. URL: https://www.envoyproxy.io/docs/envoy/latest/configuration/operations/overload_manager/overload_manager

- **REF-ERLANG-OTP-SUPERVISOR** — `Supervisor Behaviour`. Retrieved 2026-03-22. URL: https://www.erlang.org/doc/system/sup_princ.html

- **REF-ETCD-API-TXN** — `API reference | etcd`. Retrieved 2026-03-23. URL: https://etcd.io/docs/v3.6/dev-guide/api_reference_v3/

- **REF-ETCD-CONCURRENCY-LOCK** — `API reference: concurrency | etcd`. Retrieved 2026-03-23. URL: https://etcd.io/docs/v3.6/dev-guide/api_concurrency_reference_v3/

- **REF-ETCD-DATA-MODEL** — `Data model | etcd`. Retrieved 2026-03-23. URL: https://etcd.io/docs/v3.5/learning/data_model/

- **REF-ETCD-LEASE-API** — `API reference | etcd`. Retrieved 2026-03-23. URL: https://etcd.io/docs/v3.6/dev-guide/api_reference_v3/

- **REF-ETCD-LEASES** — `Interacting with etcd`. Retrieved 2026-03-22. URL: https://etcd.io/docs/v3.3/dev-guide/interacting_v3/

- **REF-ETCD-MAINTENANCE** — `Maintenance | etcd`. Retrieved 2026-03-23. URL: https://etcd.io/docs/v3.5/op-guide/maintenance/

- **REF-FISH-OSC-MARKERS** — `fish shell release notes`. Retrieved 2026-03-21. URL: https://fishshell.com/docs/current/relnotes.html

- **REF-FISH-TERMINAL-COMPAT** — `Terminal Compatibility`. Retrieved 2026-03-22. URL: https://fishshell.com/docs/current/terminal-compatibility.html

- **REF-FREEBSD-CAP-ENTER** — `cap_enter`. Retrieved 2026-03-23. URL: https://man.freebsd.org/cgi/man.cgi?query=cap_enter

- **REF-FREEBSD-CAP-RIGHTS-LIMIT** — `cap_rights_limit`. Retrieved 2026-03-23. URL: https://man.freebsd.org/cgi/man.cgi?cap_rights_limit=

- **REF-FREEBSD-CAPSICUM** — `FreeBSD Handbook / Capsicum`. Retrieved 2026-03-22. URL: https://docs.freebsd.org/en/books/handbook/security/

- **REF-FREEBSD-PROCDESC** — `procdesc(4)`. Retrieved 2026-03-23. URL: https://man.freebsd.org/cgi/man.cgi?query=procdesc&sektion=4

- **REF-FUCHSIA-API-RUBRIC** — `FIDL API Rubric - Fuchsia.dev`. Retrieved 2026-03-23. URL: https://fuchsia.dev/fuchsia-src/development/api/fidl

- **REF-FUCHSIA-CAPABILITIES** — `Capabilities - Fuchsia.dev`. Retrieved 2026-03-23. URL: https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities

- **REF-FUCHSIA-COMPONENT-RUNNER** — `fuchsia.component.runner FIDL reference`. Retrieved 2026-03-23. URL: https://fuchsia.dev/reference/fidl/fuchsia.component.runner

- **REF-FUCHSIA-IDLE-STOP** — `Stop a component when it is idle`. Retrieved 2026-03-23. URL: https://fuchsia.dev/fuchsia-src/development/components/stop_idle

- **REF-FUCHSIA-LIFECYCLE** — `Component lifecycle`. Retrieved 2026-03-22. URL: https://fuchsia.dev/fuchsia-src/concepts/components/v2/lifecycle

- **REF-FUCHSIA-MEMORY-RECLAMATION** — `Memory reclamation in Fuchsia`. Retrieved 2026-03-23. URL: https://fuchsia.dev/fuchsia-src/concepts/memory/memory_reclamation

- **REF-FUCHSIA-PROCESS-LIFECYCLE** — `fuchsia.process.lifecycle`. Retrieved 2026-03-22. URL: https://fuchsia.dev/reference/fidl/fuchsia.process.lifecycle

- **REF-FUCHSIA-RUNNER** — `Component Runners`. Retrieved 2026-03-22. URL: https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/runner

- **REF-FUCHSIA-STOP-IDLE** — `Stop a component when it is idle`. Retrieved 2026-03-22. URL: https://fuchsia.dev/fuchsia-src/development/components/stop_idle

- **REF-FUCHSIA-SYS2** — `fuchsia.sys2`. Retrieved 2026-03-23. URL: https://fuchsia.dev/reference/fidl/fuchsia.sys2

- **REF-GHOSTTY-CONFIG-REFERENCE** — `Ghostty configuration reference`. Retrieved 2026-03-23. URL: https://ghostty.org/docs/config/reference

- **REF-GHOSTTY-FEATURES** — `Features`. Retrieved 2026-03-23. URL: https://ghostty.org/docs/features

- **REF-GHOSTTY-KEYBIND-ACTIONS** — `Keybinding Action Reference`. Retrieved 2026-03-23. URL: https://ghostty.org/docs/config/keybind/reference

- **REF-GHOSTTY-KEYBIND-SEQUENCE** — `Trigger Sequences`. Retrieved 2026-03-23. URL: https://ghostty.org/docs/config/keybind/sequence

- **REF-GHOSTTY-OSC52** — `Query or Change Clipboard Data (OSC 52)`. Retrieved 2026-03-22. URL: https://ghostty.org/docs/vt/osc/52

- **REF-GHOSTTY-RELEASE-110** — `Ghostty 1.1.0 release notes`. Retrieved 2026-03-22. URL: https://ghostty.org/docs/install/release-notes/1-1-0

- **REF-GHOSTTY-RELEASE-120** — `Ghostty 1.2.0 release notes`. Retrieved 2026-03-21. URL: https://ghostty.org/docs/install/release-notes/1-2-0

- **REF-GHOSTTY-RELEASE-130** — `Ghostty 1.3.0 release notes`. Retrieved 2026-03-23. URL: https://ghostty.org/docs/install/release-notes/1-3-0

- **REF-GHOSTTY-RESET-ACTION** — `Ghostty keybind action reference: reset`. Retrieved 2026-03-21. URL: https://ghostty.org/docs/config/keybind/reference

- **REF-GHOSTTY-SHELL-INTEGRATION** — `Ghostty shell integration`. Retrieved 2026-03-22. URL: https://ghostty.org/docs/features/shell-integration

- **REF-GITHUB-PROTECTED-BRANCHES** — `About protected branches - GitHub Docs`. Retrieved 2026-03-23. URL: https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches

- **REF-GITHUB-PUSH-PROTECTION-BYPASS** — `About bypass requests for push protection - GitHub Docs`. Retrieved 2026-03-23. URL: https://docs.github.com/en/code-security/concepts/secret-security/about-bypass-requests-for-push-protection

- **REF-GITHUB-RATE-LIMITS** — `Rate limits for the REST API`. Retrieved 2026-03-23. URL: https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api

- **REF-GNU-SHEPHERD-MANUAL** — `The GNU Shepherd Manual`. Retrieved 2026-03-22. URL: https://doc.guix.gnu.org/shepherd/latest/en/shepherd.html

- **REF-GNU-SHEPHERD-OVERVIEW** — `GNU Shepherd overview`. Retrieved 2026-03-21. URL: https://shepherding.services/

- **REF-GNU-SHEPHERD-TRANSIENT** — `GNU Shepherd 1.0.0 release notes`. Retrieved 2026-03-21. URL: https://shepherding.services/news/2024/12/the-shepherd-1.0.0-released/

- **REF-GNU-SHEPHERD-TRANSIENT-MAKER** — `Transient Service Maker (The GNU Shepherd Manual)`. Retrieved 2026-03-21. URL: https://www.gnu.org/software/shepherd/manual/html_node/Transient-Service-Maker.html

- **REF-GO-CONTEXT** — `context package`. Retrieved 2026-03-22. URL: https://pkg.go.dev/context

- **REF-GOOGLE-AIP-155** — `AIP-155: Request identification`. Retrieved 2026-03-22. URL: https://google.aip.dev/155

- **REF-GOOGLE-CREDENTIAL-ACCESS-BOUNDARY** — `Credential Access Boundaries overview`. Retrieved 2026-03-23. URL: https://docs.cloud.google.com/iam/docs/downscoping-short-lived-credentials

- **REF-GRPC-CANCELLATION** — `Cancellation`. Retrieved 2026-03-22. URL: https://grpc.io/docs/guides/cancellation/

- **REF-GRPC-DEADLINES** — `Deadlines`. Retrieved 2026-03-22. URL: https://grpc.io/docs/guides/deadlines/

- **REF-GRPC-HEDGING** — `Request Hedging | gRPC`. Retrieved 2026-03-23. URL: https://grpc.io/docs/guides/request-hedging/

- **REF-GRPC-RETRY** — `Retry`. Retrieved 2026-03-23. URL: https://grpc.io/docs/guides/retry/

- **REF-GRPC-STATUS-CODES** — `Status Codes`. Retrieved 2026-03-23. URL: https://grpc.io/docs/guides/status-codes/

- **REF-HAPROXY-MANAGEMENT** — `Management Guide — HAProxy`. Retrieved 2026-03-23. URL: https://www.haproxy.com/documentation/haproxy-configuration-manual/latest/management/

- **REF-HAZELCAST-FENCEDLOCK** — `FencedLock | Hazelcast Documentation`. Retrieved 2026-03-23. URL: https://docs.hazelcast.com/hazelcast/5.6/data-structures/fencedlock

- **REF-HTML-USER-ACTIVATION** — `HTML Standard — APIs gated by user activation / UserActivation`. Retrieved 2026-03-23. URL: https://html.spec.whatwg.org/multipage/interaction.html

- **REF-HTTP-RFC9110** — `RFC 9110 - HTTP Semantics`. Retrieved 2026-03-23. URL: https://httpwg.org/specs/rfc9110.html

- **REF-IETF-IDEMPOTENCY-KEY** — `The Idempotency-Key HTTP Header Field`. Retrieved 2026-03-22. URL: https://datatracker.ietf.org/doc/draft-ietf-httpapi-idempotency-key-header/

- **REF-ITERM2-BADGES** — `Badges`. Retrieved 2026-03-21. URL: https://iterm2.com/documentation-badges.html

- **REF-ITERM2-COMMAND-SELECTION** — `Command Selection and Command URLs Syntax`. Retrieved 2026-03-21. URL: https://iterm2.com/documentation-command-selection.html

- **REF-ITERM2-ESCAPE-CODES** — `Proprietary Escape Codes / OSC 8 anchor`. Retrieved 2026-03-23. URL: https://iterm2.com/documentation-escape-codes.html

- **REF-ITERM2-FEATURE-REPORTING** — `Terminal Feature Reporting`. Retrieved 2026-03-23. URL: https://iterm2.com/feature-reporting/

- **REF-ITERM2-FEATURES** — `Features - iTerm2 - macOS Terminal Replacement`. Retrieved 2026-03-22. URL: https://iterm2.com/features.html

- **REF-ITERM2-HOOKS** — `Hooks`. Retrieved 2026-03-22. URL: https://iterm2.com/python-api/tutorial/hooks.html

- **REF-ITERM2-INLINE-IMAGES** — `Inline Images Protocol`. Retrieved 2026-03-22. URL: https://iterm2.com/3.4/documentation-images.html

- **REF-ITERM2-MENU-ITEMS** — `Menu Items - Documentation - iTerm2 - macOS Terminal Replacement`. Retrieved 2026-03-22. URL: https://iterm2.com/documentation-menu-items.html

- **REF-ITERM2-ONE-PAGE** — `Documentation - iTerm2 - macOS Terminal Replacement`. Retrieved 2026-03-22. URL: https://iterm2.com/documentation-one-page.html

- **REF-ITERM2-PREFERENCES-GENERAL** — `General Preferences - Documentation - iTerm2 - macOS Terminal Replacement`. Retrieved 2026-03-22. URL: https://iterm2.com/documentation-preferences-general.html

- **REF-ITERM2-RPCS** — `RPCs`. Retrieved 2026-03-22. URL: https://iterm2.com/python-api/tutorial/rpcs.html

- **REF-ITERM2-SEMANTIC-HISTORY** — `Advanced Profile Preferences / Semantic History`. Retrieved 2026-03-22. URL: https://iterm2.com/documentation-preferences-profiles-advanced.html

- **REF-ITERM2-SESSION-RESTORATION** — `Session Restoration`. Retrieved 2026-03-22. URL: https://iterm2.com/documentation-restoration.html

- **REF-ITERM2-SHELL-INTEGRATION** — `iTerm2 shell integration`. Retrieved 2026-03-22. URL: https://iterm2.com/shell_integration.html

- **REF-ITERM2-STATUS-BAR** — `Status Bar`. Retrieved 2026-03-22. URL: https://iterm2.com/documentation-status-bar.html

- **REF-ITERM2-TMUX-INTEGRATION** — `tmux Integration`. Retrieved 2026-03-21. URL: https://iterm2.com/documentation-tmux-integration.html

- **REF-ITERM2-VARIABLES** — `Variables`. Retrieved 2026-03-22. URL: https://iterm2.com/documentation-variables.html

- **REF-K8S-APF** — `API Priority and Fairness | Kubernetes`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/concepts/cluster-administration/flow-control/

- **REF-K8S-API-CONCEPTS** — `Kubernetes API Concepts`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/reference/using-api/api-concepts/

- **REF-K8S-DECLARATIVE-CONFIG** — `Declarative Management of Kubernetes Objects Using Configuration Files`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/tasks/manage-kubernetes-objects/declarative-config/

- **REF-K8S-DEPLOYMENT** — `Deployments | Kubernetes`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

- **REF-K8S-ENDPOINTSLICES** — `EndpointSlices`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/concepts/services-networking/endpoint-slices/

- **REF-K8S-KUBELET-CONFIG** — `Kubelet Configuration (v1beta1)`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/reference/config-api/kubelet-config.v1beta1/

- **REF-K8S-LEASES** — `Leases | Kubernetes`. Retrieved 2026-03-22. URL: https://kubernetes.io/docs/concepts/architecture/leases/

- **REF-K8S-NODE-PRESSURE-EVICTION** — `Node-pressure Eviction`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/concepts/scheduling-eviction/node-pressure-eviction/

- **REF-K8S-POD-LIFECYCLE** — `Pod Lifecycle`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/

- **REF-K8S-PODS-OBSERVED-GENERATION** — `Pods | Kubernetes`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/concepts/workloads/pods/

- **REF-K8S-PROBES** — `Liveness, readiness, and startup probes`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/concepts/configuration/liveness-readiness-startup-probes/

- **REF-K8S-RESOURCE-QUOTAS** — `Resource Quotas`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/concepts/policy/resource-quotas/

- **REF-K8S-ROLLOUT-PAUSE** — `kubectl rollout pause | Kubernetes`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/reference/kubectl/generated/kubectl_rollout/kubectl_rollout_pause/

- **REF-K8S-ROLLOUT-RESUME** — `kubectl rollout resume | Kubernetes`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/reference/kubectl/generated/kubectl_rollout/kubectl_rollout_resume/

- **REF-K8S-STATEFULSET** — `StatefulSets | Kubernetes`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/concepts/workloads/controllers/statefulset/

- **REF-KITTY-ACTIONS** — `Mappable actions`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/actions/

- **REF-KITTY-CHOOSE-FILES** — `Selecting files, fast`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/kittens/choose-files/

- **REF-KITTY-CLIPBOARD** — `Copying all data types to the clipboard`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/clipboard/

- **REF-KITTY-CONF** — `kitty configuration reference`. Retrieved 2026-03-23. URL: https://sw.kovidgoyal.net/kitty/conf/

- **REF-KITTY-DESKTOP-NOTIFICATIONS** — `Desktop notifications`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/desktop-notifications/

- **REF-KITTY-FILE-TRANSFER-PROTOCOL** — `File transfer over the TTY`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/file-transfer-protocol/

- **REF-KITTY-GRAPHICS-PROTOCOL** — `Terminal graphics protocol`. Retrieved 2026-03-23. URL: https://sw.kovidgoyal.net/kitty/graphics-protocol/

- **REF-KITTY-HINTS** — `Hints`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/kittens/hints/

- **REF-KITTY-KEYBOARD-PROTOCOL** — `kitty keyboard protocol`. Retrieved 2026-03-21. URL: https://sw.kovidgoyal.net/kitty/keyboard-protocol/

- **REF-KITTY-LAUNCH** — `The launch command`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/launch/

- **REF-KITTY-MAPPING** — `Making your keyboard dance`. Retrieved 2026-03-23. URL: https://sw.kovidgoyal.net/kitty/mapping/

- **REF-KITTY-NOTIFY** — `notify`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/kittens/notify/

- **REF-KITTY-OPEN-ACTIONS** — `Scripting the mouse click`. Retrieved 2026-03-21. URL: https://sw.kovidgoyal.net/kitty/open_actions/

- **REF-KITTY-PROTOCOL-EXTENSIONS** — `Terminal protocol extensions`. Retrieved 2026-03-21. URL: https://sw.kovidgoyal.net/kitty/protocol-extensions/

- **REF-KITTY-RC-PROTOCOL** — `The kitty remote control protocol`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/rc_protocol/

- **REF-KITTY-REMOTE-CONTROL** — `Control kitty from scripts`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/remote-control/

- **REF-KITTY-REMOTE-FILES** — `Remote files`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/kittens/remote_file/

- **REF-KITTY-SHELL-INTEGRATION** — `kitty shell integration`. Retrieved 2026-03-23. URL: https://sw.kovidgoyal.net/kitty/shell-integration/

- **REF-KITTY-SSH** — `Truly convenient SSH`. Retrieved 2026-03-23. URL: https://sw.kovidgoyal.net/kitty/kittens/ssh/

- **REF-KITTY-TRANSFER** — `Transfer files`. Retrieved 2026-03-22. URL: https://sw.kovidgoyal.net/kitty/kittens/transfer/

- **REF-KUBECTL-DIFF** — `kubectl diff`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/reference/kubectl/generated/kubectl_diff/

- **REF-KUBECTL-DRAIN** — `kubectl drain | Kubernetes`. Retrieved 2026-03-23. URL: https://kubernetes.io/docs/reference/kubectl/generated/kubectl_drain/

- **REF-LANDLOCK-USERSPACE** — `Landlock: unprivileged access control`. Retrieved 2026-03-23. URL: https://docs.kernel.org/userspace-api/landlock.html

- **REF-LAUNCH-ACTIVATE-SOCKET** — `launch_activate_socket`. Retrieved 2026-03-22. URL: https://developer.apple.com/documentation/xpc/launch_activate_socket

- **REF-LAUNCHD-JOBS** — `Creating Launch Daemons and Agents`. Retrieved 2026-03-23. URL: https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/CreatingLaunchdJobs.html

- **REF-LAUNCHD-SOCKETS** — `launchd.plist(5)`. Retrieved 2026-03-23. URL: https://www.manpagez.com/man/5/launchd.plist/

- **REF-LAUNCHD-XPC** — `XPC overview`. Retrieved 2026-03-21. URL: https://developer.apple.com/documentation/xpc

- **REF-LINUX-CGROUP-V2** — `Control Group v2`. Retrieved 2026-03-23. URL: https://docs.kernel.org/admin-guide/cgroup-v2.html

- **REF-LINUX-CHILD-SUBREAPER** — `PR_SET_CHILD_SUBREAPER(2const)`. Retrieved 2026-03-23. URL: https://man7.org/linux/man-pages/man2/PR_SET_CHILD_SUBREAPER.2const.html

- **REF-LINUX-CLOSE-RANGE** — `close_range(2)`. Retrieved 2026-03-22. URL: https://man7.org/linux/man-pages/man2/close_range.2.html

- **REF-LINUX-F-ADD-SEALS** — `F_GET_SEALS(2const) / F_ADD_SEALS`. Retrieved 2026-03-23. URL: https://man7.org/linux/man-pages/man2/F_GET_SEALS.2const.html

- **REF-LINUX-MEMFD-CREATE** — `memfd_create(2)`. Retrieved 2026-03-23. URL: https://man7.org/linux/man-pages/man2/memfd_create.2.html

- **REF-LINUX-PIDFD-OPEN** — `pidfd_open(2)`. Retrieved 2026-03-23. URL: https://man7.org/linux/man-pages/man2/pidfd_open.2.html

- **REF-LINUX-PSI** — `PSI - Pressure Stall Information`. Retrieved 2026-03-23. URL: https://docs.kernel.org/accounting/psi.html

- **REF-LINUX-WAITID-PIDFD** — `wait(2) / waitid(P_PIDFD)`. Retrieved 2026-03-23. URL: https://man7.org/linux/man-pages/man2/wait.2.html

- **REF-MACAROONS** — `Macaroons: Cookies with Contextual Caveats for Decentralized Authorization in the Cloud`. Retrieved 2026-03-23. URL: https://research.google/pubs/macaroons-cookies-with-contextual-caveats-for-decentralized-authorization-in-the-cloud/

- **REF-MOSH** — `Mosh: the mobile shell`. Retrieved 2026-03-21. URL: https://mosh.org/

- **REF-MOSH-PAPER** — `Mosh: An Interactive Remote Shell for Mobile Clients`. Retrieved 2026-03-21. URL: https://mosh.org/mosh-paper.pdf

- **REF-NCURSES-FAQ** — `NCURSES FAQ`. Retrieved 2026-03-21. URL: https://invisible-island.net/ncurses/ncurses.faq.html

- **REF-NOMAD-CHECK-RESTART** — `check_restart block in the job specification | Nomad`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/nomad/docs/job-specification/check_restart

- **REF-NOMAD-DEPLOYMENT-STATUS** — `nomad deployment status command reference | Nomad | HashiCorp Developer`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/nomad/commands/deployment/status

- **REF-NOMAD-DISCONNECT** — `disconnect block in the job specification | Nomad`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/nomad/docs/job-specification/disconnect

- **REF-NOMAD-LIFECYCLE** — `lifecycle block in the job specification | Nomad`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/nomad/docs/job-specification/lifecycle

- **REF-NOMAD-NODE-DRAIN** — `nomad node drain command reference | Nomad | HashiCorp Developer`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/nomad/commands/node/drain

- **REF-NOMAD-QUOTA** — `Nomad resource quota specification`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/nomad/docs/other-specifications/quota

- **REF-NOMAD-RESCHEDULE** — `reschedule block in the job specification | Nomad`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/nomad/docs/job-specification/reschedule

- **REF-NOMAD-RESTART** — `restart block in the job specification | Nomad`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/nomad/docs/job-specification/restart

- **REF-NOMAD-UPDATE** — `update block in the job specification | Nomad`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/nomad/docs/job-specification/update

- **REF-NUSHELL-CUSTOM-COMPLETIONS** — `Custom Completions`. Retrieved 2026-03-23. URL: https://www.nushell.sh/book/custom_completions.html

- **REF-NUSHELL-PIPELINES** — `Pipelines`. Retrieved 2026-03-22. URL: https://www.nushell.sh/book/pipelines.html

- **REF-OAUTH-RFC6749** — `RFC 6749 - The OAuth 2.0 Authorization Framework`. Retrieved 2026-03-23. URL: https://datatracker.ietf.org/doc/html/rfc6749

- **REF-OPENBSD-PLEDGE** — `pledge(2)`. Retrieved 2026-03-23. URL: https://man.openbsd.org/pledge.2

- **REF-OPENBSD-UNVEIL** — `unveil(2)`. Retrieved 2026-03-22. URL: https://man.openbsd.org/unveil

- **REF-OPENRC-SUPERVISE-DAEMON** — `Using supervise-daemon`. Retrieved 2026-03-21. URL: https://github.com/OpenRC/openrc/blob/master/supervise-daemon-guide.md

- **REF-OSC133-SPEC** — `OSC 133 shell integration sequence`. Retrieved 2026-03-21. URL: https://contour-terminal.org/vt-extensions/osc-133-shell-integration/

- **REF-PLAN9-PLUMBING** — `Plumbing and Other Utilities`. Retrieved 2026-03-22. URL: https://9p.io/sys/doc/plumb.html

- **REF-POSIX-TCSETPGRP** — `tcsetpgrp`. Retrieved 2026-03-23. URL: https://pubs.opengroup.org/onlinepubs/007904975/functions/tcsetpgrp.html

- **REF-PSREADLINE-PREDICTORS** — `Using predictors in PSReadLine`. Retrieved 2026-03-23. URL: https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/using-predictors?view=powershell-7.6

- **REF-RFC6585** — `RFC 6585: Additional HTTP Status Codes`. Retrieved 2026-03-23. URL: https://www.rfc-editor.org/rfc/rfc6585.html

- **REF-RFC8252-NATIVE-APPS** — `RFC 8252 - OAuth 2.0 for Native Apps`. Retrieved 2026-03-23. URL: https://datatracker.ietf.org/doc/html/rfc8252

- **REF-RFC8693-TOKEN-EXCHANGE** — `RFC 8693: OAuth 2.0 Token Exchange`. Retrieved 2026-03-23. URL: https://www.rfc-editor.org/rfc/rfc8693.html

- **REF-RFC8705-MTLS** — `RFC 8705: OAuth 2.0 Mutual-TLS Client Authentication and Certificate-Bound Access Tokens`. Retrieved 2026-03-23. URL: https://www.rfc-editor.org/rfc/rfc8705.html

- **REF-RFC9449-DPOP** — `RFC 9449: OAuth 2.0 Demonstrating Proof of Possession (DPoP)`. Retrieved 2026-03-23. URL: https://www.rfc-editor.org/rfc/rfc9449.html

- **REF-RFC9700-OAUTH-SECURITY-BCP** — `RFC 9700: Best Current Practice for OAuth 2.0 Security`. Retrieved 2026-03-23. URL: https://www.rfc-editor.org/rfc/rfc9700.html

- **REF-RUNIT-OVERVIEW** — `runit overview`. Retrieved 2026-03-21. URL: https://smarden.org/runit/

- **REF-S6-NOTIFYONCHECK** — `The s6-notifyoncheck program`. Retrieved 2026-03-22. URL: https://skarnet.org/software/s6/s6-notifyoncheck.html

- **REF-S6-RC-OVERVIEW** — `An overview of s6-rc`. Retrieved 2026-03-22. URL: https://skarnet.org/software/s6-rc/overview.html

- **REF-S6-RC-TRANSITIONS** — `The s6-rc program`. Retrieved 2026-03-21. URL: https://skarnet.org/software/s6-rc/s6-rc.html

- **REF-S6-RC-UPDATE** — `The s6-rc-update program`. Retrieved 2026-03-23. URL: https://skarnet.org/software/s6-rc/s6-rc-update.html

- **REF-S6-RC-WHY** — `Why s6-rc`. Retrieved 2026-03-21. URL: https://skarnet.org/software/s6-rc/why.html

- **REF-S6-READY** — `Service startup notifications`. Retrieved 2026-03-21. URL: https://skarnet.org/software/s6/notifywhenup.html

- **REF-S6-SERVICEDIR** — `s6: service directories`. Retrieved 2026-03-22. URL: https://skarnet.org/software/s6/servicedir.html

- **REF-S6-SHALLOW-READINESS** — `The s6-svscan program`. Retrieved 2026-03-21. URL: https://skarnet.org/software/s6/s6-svscan.html

- **REF-S6-SUPERVISE** — `The s6-supervise program`. Retrieved 2026-03-22. URL: https://skarnet.org/software/s6/s6-supervise.html

- **REF-SD-LISTEN-FDS-WITH-NAMES** — `sd_listen_fds_with_names(3)`. Retrieved 2026-03-22. URL: https://www.freedesktop.org/software/systemd/man/259/sd_listen_fds_with_names.html

- **REF-SD-NOTIFY** — `sd_notify() and related APIs`. Retrieved 2026-03-23. URL: https://www.freedesktop.org/software/systemd/man/latest/sd_pid_notify_with_fds.html

- **REF-SD-WATCHDOG-ENABLED** — `sd_watchdog_enabled(3)`. Retrieved 2026-03-23. URL: https://www.freedesktop.org/software/systemd/man/sd_watchdog_enabled.html

- **REF-SMF-MAINTENANCE** — `SMF Best Practices and Troubleshooting`. Retrieved 2026-03-22. URL: https://docs.oracle.com/cd/E36784_01/html/E36820/ecdps.html

- **REF-SOLARIS-PROCESS-CONTRACTS** — `Supported File Systems / CTFS process contracts`. Retrieved 2026-03-23. URL: https://docs.oracle.com/cd/E53394_01/html/E54785/gqyrl.html

- **REF-SOLARIS-SMF-CONTRACT-SERVICE** — `SMF Concepts and Components`. Retrieved 2026-03-23. URL: https://docs.oracle.com/cd/E37838_01/html/E60998/dzhid.html

- **REF-SOLARIS-SMF-RESTARTER** — `Service Restarters`. Retrieved 2026-03-21. URL: https://docs.oracle.com/cd/E36784_01/html/E36820/dzhna.html

- **REF-SYSTEMCTL** — `systemctl(1) - Linux manual page`. Retrieved 2026-03-23. URL: https://man7.org/linux/man-pages/man1/systemctl.1.html

- **REF-SYSTEMD-DAEMON** — `daemon(7)`. Retrieved 2026-03-22. URL: https://www.freedesktop.org/software/systemd/man/daemon.html

- **REF-SYSTEMD-EXEC** — `systemd.exec(5)`. Retrieved 2026-03-21. URL: https://www.freedesktop.org/software/systemd/man/systemd.exec.html

- **REF-SYSTEMD-FDSTORE** — `The File Descriptor Store`. Retrieved 2026-03-23. URL: https://systemd.io/FILE_DESCRIPTOR_STORE/

- **REF-SYSTEMD-INHIBIT-MAN** — `systemd-inhibit(1)`. Retrieved 2026-03-22. URL: https://www.freedesktop.org/software/systemd/man/systemd-inhibit.html

- **REF-SYSTEMD-INHIBITOR-LOCKS** — `Inhibitor Locks`. Retrieved 2026-03-22. URL: https://www.freedesktop.org/wiki/Software/systemd/inhibit/

- **REF-SYSTEMD-MEMORY-PRESSURE** — `Memory Pressure Handling`. Retrieved 2026-03-23. URL: https://systemd.io/MEMORY_PRESSURE/

- **REF-SYSTEMD-RUN** — `systemd-run(1)`. Retrieved 2026-03-21. URL: https://www.freedesktop.org/software/systemd/man/systemd-run.html

- **REF-SYSTEMD-SD-LISTEN-FDS** — `sd_listen_fds(3)`. Retrieved 2026-03-21. URL: https://www.freedesktop.org/software/systemd/man/sd_listen_fds.html

- **REF-SYSTEMD-SERVICE** — `systemd.service(5)`. Retrieved 2026-03-23. URL: https://www.freedesktop.org/software/systemd/man/systemd.service.html

- **REF-SYSTEMD-SOCKET-ACTIVATION** — `systemd.socket(5)`. Retrieved 2026-03-21. URL: https://www.freedesktop.org/software/systemd/man/systemd.socket.html

- **REF-SYSTEMD-UNIT** — `systemd.unit(5)`. Retrieved 2026-03-22. URL: https://www.freedesktop.org/software/systemd/man/systemd.unit.html

- **REF-TERRAFORM-APPLY** — `terraform apply command reference`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/terraform/cli/commands/apply

- **REF-TERRAFORM-PLAN** — `terraform plan command reference`. Retrieved 2026-03-23. URL: https://developer.hashicorp.com/terraform/cli/commands/plan

- **REF-TMUX-CHANGES** — `tmux CHANGES`. Retrieved 2026-03-21. URL: https://github.com/tmux/tmux/blob/master/CHANGES

- **REF-TMUX-CONTROL-MODE** — `tmux control mode`. Retrieved 2026-03-21. URL: https://man7.org/linux/man-pages/man1/tmux.1.html

- **REF-VSCODE-AGENT-PLANNING** — `Planning with agents in VS Code`. Retrieved 2026-03-23. URL: https://code.visualstudio.com/docs/copilot/agents/planning

- **REF-VSCODE-AGENT-TOOLS** — `Use tools with agents`. Retrieved 2026-03-23. URL: https://code.visualstudio.com/docs/copilot/agents/agent-tools

- **REF-VSCODE-AI-SETTINGS** — `Manage AI settings in enterprise environments`. Retrieved 2026-03-23. URL: https://code.visualstudio.com/docs/enterprise/ai-settings

- **REF-VSCODE-INLINE-CHAT** — `Inline chat`. Retrieved 2026-03-23. URL: https://code.visualstudio.com/docs/copilot/chat/inline-chat

- **REF-VSCODE-SHELL-INTEGRATION** — `Terminal Shell Integration`. Retrieved 2026-03-21. URL: https://code.visualstudio.com/docs/terminal/shell-integration

- **REF-VSCODE-SHELL-TRUST** — `VS Code API shellIntegrationNonce and trusted command reporting`. Retrieved 2026-03-21. URL: https://code.visualstudio.com/api/references/vscode-api

- **REF-VSCODE-TERMINAL-ADVANCED** — `Terminal Advanced`. Retrieved 2026-03-22. URL: https://code.visualstudio.com/docs/terminal/advanced

- **REF-VSCODE-TERMINAL-BASICS** — `Terminal Basics`. Retrieved 2026-03-23. URL: https://code.visualstudio.com/docs/terminal/basics

- **REF-VSCODE-TERMINAL-LINK-PROVIDER** — `VS Code API / TerminalLinkProvider`. Retrieved 2026-03-23. URL: https://code.visualstudio.com/api/references/vscode-api

- **REF-VSCODE-TERMINAL-PROFILES** — `Terminal Profiles`. Retrieved 2026-03-22. URL: https://code.visualstudio.com/docs/terminal/profiles

- **REF-VSCODE-UPDATE-1066** — `March 2022 (version 1.66)`. Retrieved 2026-03-22. URL: https://code.visualstudio.com/updates/v1_66

- **REF-VSCODE-UPDATE-1072** — `September 2022 (version 1.72)`. Retrieved 2026-03-22. URL: https://code.visualstudio.com/updates/v1_72

- **REF-VSCODE-UPDATE-1099** — `March 2025 (version 1.99)`. Retrieved 2026-03-23. URL: https://code.visualstudio.com/updates/v1_99

- **REF-VSCODE-UPDATE-1102** — `June 2025 (version 1.102)`. Retrieved 2026-03-22. URL: https://code.visualstudio.com/updates/v1_102

- **REF-VSCODE-UPDATE-1103** — `July 2025 (version 1.103)`. Retrieved 2026-03-22. URL: https://code.visualstudio.com/updates/v1_103

- **REF-VSCODE-UPDATE-1104** — `August 2025 (version 1.104)`. Retrieved 2026-03-22. URL: https://code.visualstudio.com/updates/v1_104

- **REF-VSCODE-UPDATE-1106** — `October 2025 (version 1.106)`. Retrieved 2026-03-21. URL: https://code.visualstudio.com/updates/v1_106

- **REF-VSCODE-UPDATE-1107** — `November 2025 (version 1.107)`. Retrieved 2026-03-21. URL: https://code.visualstudio.com/updates/v1_107

- **REF-VSCODE-UPDATE-1108** — `December 2025 (version 1.108)`. Retrieved 2026-03-22. URL: https://code.visualstudio.com/updates/v1_108

- **REF-VSCODE-UPDATE-1109** — `January 2026 (version 1.109)`. Retrieved 2026-03-22. URL: https://code.visualstudio.com/updates/v1_109

- **REF-VSCODE-UPDATE-1110** — `February 2026 (version 1.110)`. Retrieved 2026-03-21. URL: https://code.visualstudio.com/updates/v1_110

- **REF-VSCODE-UPDATE-1111** — `Visual Studio Code 1.111`. Retrieved 2026-03-23. URL: https://code.visualstudio.com/updates/v1_111

- **REF-WARP-AGENT-MODALITY** — `Agent Modality | Agents | Warp`. Retrieved 2026-03-23. URL: https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality

- **REF-WARP-AGENT-PROFILES** — `Profiles & Permissions | Agents | Warp`. Retrieved 2026-03-23. URL: https://docs.warp.dev/agent-platform/capabilities/agent-profiles-permissions

- **REF-WARP-BLOCKS** — `Warp Blocks`. Retrieved 2026-03-21. URL: https://docs.warp.dev/terminal/blocks

- **REF-WARP-COMMAND-SEARCH** — `Command Search`. Retrieved 2026-03-22. URL: https://docs.warp.dev/terminal/entry/command-search

- **REF-WARP-ENV-VARS** — `Environment Variables | Warp`. Retrieved 2026-03-22. URL: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/environment-variables

- **REF-WARP-FULL-TERMINAL-USE** — `Full Terminal Use | Agents | Warp`. Retrieved 2026-03-23. URL: https://docs.warp.dev/agent-platform/capabilities/full-terminal-use

- **REF-WARP-NOTEBOOKS** — `Notebooks | Warp`. Retrieved 2026-03-23. URL: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/notebooks

- **REF-WARP-SSH** — `SSH | Warp`. Retrieved 2026-03-22. URL: https://docs.warp.dev/terminal/warpify/ssh

- **REF-WARP-WORKFLOWS** — `Workflows | Warp`. Retrieved 2026-03-23. URL: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows

- **REF-WEZTERM-AUGMENT-COMMAND-PALETTE** — `augment-command-palette`. Retrieved 2026-03-22. URL: https://wezterm.org/config/lua/window-events/augment-command-palette.html

- **REF-WEZTERM-CLI** — `Command Line`. Retrieved 2026-03-22. URL: https://wezterm.org/cli/general.html

- **REF-WEZTERM-FORMAT-TAB-TITLE** — `format-tab-title`. Retrieved 2026-03-23. URL: https://wezterm.org/config/lua/window-events/format-tab-title.html

- **REF-WEZTERM-HYPERLINKS** — `Hyperlinks`. Retrieved 2026-03-23. URL: https://wezterm.org/hyperlinks.html

- **REF-WEZTERM-IMGCAT** — `iTerm Image Protocol`. Retrieved 2026-03-23. URL: https://wezterm.org/imgcat.html

- **REF-WEZTERM-KEYBOARD-CONCEPTS** — `Keyboard Concepts`. Retrieved 2026-03-23. URL: https://wezterm.org/config/keyboard-concepts.html

- **REF-WEZTERM-KEYBOARD-ENCODING** — `Keyboard Encoding`. Retrieved 2026-03-23. URL: https://wezterm.org/config/key-encoding.html

- **REF-WEZTERM-LAUNCH-MENU** — `launch_menu`. Retrieved 2026-03-22. URL: https://wezterm.org/config/lua/config/launch_menu.html

- **REF-WEZTERM-LAUNCHING-PROGRAMS** — `Launching Programs`. Retrieved 2026-03-22. URL: https://wezterm.org/config/launch.html

- **REF-WEZTERM-MULTIPLEXING** — `Multiplexing`. Retrieved 2026-03-22. URL: https://wezterm.org/multiplexing.html

- **REF-WEZTERM-NOTIFICATION-HANDLING** — `notification_handling`. Retrieved 2026-03-21. URL: https://wezterm.org/config/lua/config/notification_handling.html

- **REF-WEZTERM-OPEN-URI** — `open-uri`. Retrieved 2026-03-23. URL: https://wezterm.org/config/lua/window-events/open-uri.html

- **REF-WEZTERM-PANE-INFORMATION** — `PaneInformation`. Retrieved 2026-03-22. URL: https://wezterm.org/config/lua/PaneInformation.html

- **REF-WEZTERM-PANE-USER-VARS** — `Passing Data from a pane to Lua`. Retrieved 2026-03-23. URL: https://wezterm.org/recipes/passing-data.html

- **REF-WEZTERM-RIGHT-STATUS** — `window:set_right_status(string)`. Retrieved 2026-03-21. URL: https://wezterm.org/config/lua/window/set_right_status.html

- **REF-WEZTERM-SCROLL-TO-PROMPT** — `ScrollToPrompt`. Retrieved 2026-03-22. URL: https://wezterm.org/config/lua/keyassignment/ScrollToPrompt.html

- **REF-WEZTERM-SEMANTIC-ZONE-AT** — `get_semantic_zone_at`. Retrieved 2026-03-23. URL: https://wezterm.org/config/lua/pane/get_semantic_zone_at.html

- **REF-WEZTERM-SEMANTIC-ZONES** — `get_semantic_zones`. Retrieved 2026-03-23. URL: https://wezterm.org/config/lua/pane/get_semantic_zones.html

- **REF-WEZTERM-SHELL-INTEGRATION** — `WezTerm shell integration`. Retrieved 2026-03-23. URL: https://wezterm.org/shell-integration.html

- **REF-WEZTERM-SPAWNCOMMAND** — `SpawnCommand`. Retrieved 2026-03-22. URL: https://wezterm.org/config/lua/SpawnCommand.html

- **REF-WEZTERM-SYNC-RENDER** — `WezTerm escape sequences / synchronized rendering`. Retrieved 2026-03-21. URL: https://wezterm.org/escape-sequences.html

- **REF-WHATWG-SSE** — `HTML Living Standard — Server-sent events`. Retrieved 2026-03-23. URL: https://html.spec.whatwg.org/dev/server-sent-events.html

- **REF-WINDOWS-JOB-OBJECTS** — `Job Objects - Win32 apps`. Retrieved 2026-03-23. URL: https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects

- **REF-WINDOWS-TERMINAL-ACTIONS** — `Windows Terminal Actions`. Retrieved 2026-03-22. URL: https://learn.microsoft.com/en-us/windows/terminal/customize-settings/actions

- **REF-WINDOWS-TERMINAL-ADVANCED-PROFILE** — `Windows Terminal Advanced Profile Settings`. Retrieved 2026-03-22. URL: https://learn.microsoft.com/en-us/windows/terminal/customize-settings/profile-advanced

- **REF-WINDOWS-TERMINAL-COMMAND-PALETTE** — `How to use the command palette in Windows Terminal`. Retrieved 2026-03-22. URL: https://learn.microsoft.com/en-us/windows/terminal/command-palette

- **REF-WINDOWS-TERMINAL-INTERACTION** — `Windows Terminal Interaction Settings`. Retrieved 2026-03-22. URL: https://learn.microsoft.com/en-us/windows/terminal/customize-settings/interaction

- **REF-WINDOWS-TERMINAL-PROGRESS** — `Tutorial: Set the progress bar in the Windows Terminal`. Retrieved 2026-03-21. URL: https://learn.microsoft.com/en-us/windows/terminal/tutorials/progress-bar-sequences

- **REF-WINDOWS-TERMINAL-SAME-DIRECTORY** — `Opening a tab/pane in the same directory`. Retrieved 2026-03-22. URL: https://learn.microsoft.com/en-us/windows/terminal/tutorials/new-tab-same-directory

- **REF-WINDOWS-TERMINAL-SHELL-INTEGRATION** — `Shell integration in the Windows Terminal`. Retrieved 2026-03-22. URL: https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration

- **REF-WINDOWS-TERMINAL-STARTUP** — `Windows Terminal Startup Settings`. Retrieved 2026-03-22. URL: https://learn.microsoft.com/en-us/windows/terminal/customize-settings/startup

- **REF-WINDOWS-TERMINAL-TAB-TITLE** — `Windows Terminal Tab Title Setup`. Retrieved 2026-03-23. URL: https://learn.microsoft.com/en-us/windows/terminal/tutorials/tab-title

- **REF-WINDOWS-TERMINAL-TIPS** — `Windows Terminal tips and tricks`. Retrieved 2026-03-21. URL: https://learn.microsoft.com/en-us/windows/terminal/tips-and-tricks

- **REF-WINDOWS-TERMINATE-JOB-OBJECT** — `TerminateJobObject function (jobapi2.h)`. Retrieved 2026-03-23. URL: https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-terminatejobobject

- **REF-XDG-ACTIVATION-V1** — `XDG activation protocol`. Retrieved 2026-03-23. URL: https://wayland.app/protocols/xdg_activation_v1

- **REF-XDG-PORTAL-GLOBALSHORTCUTS** — `Global Shortcuts`. Retrieved 2026-03-22. URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.GlobalShortcuts.html

- **REF-XDG-PORTAL-INHIBIT** — `Inhibit - XDG Desktop Portal documentation`. Retrieved 2026-03-22. URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Inhibit.html

- **REF-XDG-PORTAL-INPUTCAPTURE** — `Input Capture`. Retrieved 2026-03-22. URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.InputCapture.html

- **REF-XDG-PORTAL-OPENURI** — `OpenURI - XDG Desktop Portal documentation`. Retrieved 2026-03-23. URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.OpenURI.html

- **REF-XDG-PORTAL-REMOTE-DESKTOP** — `Remote Desktop - XDG Desktop Portal documentation`. Retrieved 2026-03-23. URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.RemoteDesktop.html

- **REF-XDG-PORTAL-REQUEST** — `Request - XDG Desktop Portal documentation`. Retrieved 2026-03-23. URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Request.html

- **REF-XDG-PORTAL-SESSION** — `Session - XDG Desktop Portal documentation`. Retrieved 2026-03-23. URL: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.impl.portal.Session.html

- **REF-XPC-TRANSACTION-BEGIN** — `xpc_transaction_begin()`. Retrieved 2026-03-21. URL: https://developer.apple.com/documentation/xpc/xpc_transaction_begin%28%29?language=objc

- **REF-XPC-TRANSACTION-END** — `xpc_transaction_end()`. Retrieved 2026-03-21. URL: https://developer.apple.com/documentation/xpc/xpc_transaction_end%28%29?language=objc

- **REF-XTERM-BRACKETED-PASTE** — `xterm bracketed paste`. Retrieved 2026-03-22. URL: https://invisible-island.net/xterm/xterm-paste64.html

- **REF-XTERM-CTLSEQS** — `Xterm Control Sequences`. Retrieved 2026-03-23. URL: https://www.xfree86.org/current/ctlseqs.html

- **REF-XTERM-FAQ** — `XTerm FAQ`. Retrieved 2026-03-21. URL: https://invisible-island.net/xterm/xterm.faq.html

- **REF-XTERM-MANPAGE** — `xterm(1)`. Retrieved 2026-03-21. URL: https://invisible-island.net/xterm/manpage/xterm.html

- **REF-XTERM-MODIFIED-KEYS** — `XTerm – “Other” Modified Keys`. Retrieved 2026-03-23. URL: https://invisible-island.net/xterm/modified-keys.html

- **REF-ZELLIJ-FEATURES** — `Zellij Features - Terminal Superpowers at your Fingertips`. Retrieved 2026-03-22. URL: https://zellij.dev/features/

- **REF-ZELLIJ-FILEPICKER** — `The Zellij Filepicker`. Retrieved 2026-03-22. URL: https://zellij.dev/tutorials/filepicker/

- **REF-ZELLIJ-PLUGIN-PIPES** — `Pipes for Communicating with and Between plugins`. Retrieved 2026-03-22. URL: https://zellij.dev/documentation/plugin-pipes.html

- **REF-ZELLIJ-PLUGINS** — `Plugins - Zellij User Guide`. Retrieved 2026-03-22. URL: https://zellij.dev/documentation/plugins.html

- **REF-ZELLIJ-RELEASE-044** — `Zellij 0.44.0: Remote Sessions, Windows Support, CLI Automation`. Retrieved 2026-03-23. URL: https://zellij.dev/news/remote-sessions-windows-cli/

- **REF-ZELLIJ-SESSION-RESURRECTION** — `Session Resurrection - Zellij User Guide`. Retrieved 2026-03-23. URL: https://zellij.dev/documentation/session-resurrection.html

- **REF-ZOOKEEPER-PROGRAMMER** — `ZooKeeper Programmer's Guide`. Retrieved 2026-03-23. URL: https://zookeeper.apache.org/doc/r3.8.5/zookeeperProgrammers.html
