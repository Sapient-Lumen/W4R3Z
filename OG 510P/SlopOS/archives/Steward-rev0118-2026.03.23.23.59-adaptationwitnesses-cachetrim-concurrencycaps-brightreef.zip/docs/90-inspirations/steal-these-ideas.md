# Steal these ideas

## Ideas worth stealing almost directly
- **Foreground supervision discipline**: managed services should stay directly accountable to the supervisor rather than daemonizing away.
- **Manager-owned activation handles**: keep the public listener/end-point identity system-owned.
- **Name-keyed activation lookups**: D-Bus system activation is a good reminder that a privileged helper can accept a validated name instead of a mutable path-and-environment blob.
- **Bounded continuity escrow**: allowlisted, same-component continuity only.
- **Explicit child specifications and ordered shutdown**: OTP’s “start in order, stop in reverse order” is still a great small idea.
- **Restart intensity + period thinking**: make crash-loop tolerance explicit and bounded instead of purely heuristic.
- **Offline planning when possible**: s6-rc's argument for precompiled dependency analysis is compelling even if Steward later adopts only a small version of it.
- **Explicit startup/readiness/liveness split**: Kubernetes got the vocabulary right even if the surrounding platform is much larger than Steward.
- **Shallow-vs-deep readiness naming**: keep “control/status path is up” distinct from “component can do declared work.”
- **Restarters/runners as explicit seams**: do not make every runtime launch path part of one giant core.
- **Exact reviewed launch envelopes**: copy the spirit of SlopOS's execution-pack discipline so restartable services do not depend on ambient shell/session baggage.
- **Dynamic conditions are not dependency facts**: network, peer, or session availability should usually surface as live readiness/status truth rather than a fake static ordering promise.
- **Status channels separate from logs**: explicit ready/stopping/status notifications are much easier to reason about than “grep the logs and squint.”
- **Opaque per-runtime-cycle witnesses**: keep one small piece of data that says “this exact run” without pretending PIDs or process trees are the portable truth.
- **Accountable oneshot transitions**: let transition helpers run under the lifecycle fabric’s accountability model rather than as floating admin children.
- **Idle / transaction hints**: where components can meaningfully say “I am idle” or “I have in-flight work,” that can unlock bounded stop/escrow behavior.
- **Optional stale-holder fences**: Hazelcast's monotonic fencing tokens and etcd's current-owner proofs show how reassignable live claims can reject delayed old holders without pretending one giant distributed-lock service should be the architecture.
- **Explicit begin/end keepalive brackets**: XPC-style transaction boundaries are a compelling small model for “don’t stop me yet” without a giant scheduler contract.
- **Transient services for shell-launched work**: Shepherd's `spawn transient` idea and systemd-run both show a useful accountability pattern for long-running commands.
- **Structured shell output hooks**: Nushell shows the value of structured pipeline results even in an interactive shell.
- **Plan 9 style plumbing**: route meaningful objects and intents instead of only raw text.
- **Prompt / command / output markers**: OSC 133 style markers are small, practical, and already useful.
- **Working-directory side channels**: OSC 7 style cwd reporting pays for itself quickly.
- **Explicit hyperlinks**: OSC 8 style hyperlinks are a great fit for receipt pointers, digests, docs, and error locations.
- **Short-lived exact-target anchors**: let high-value shell/terminal affordances bind to concrete frames, receipts, transcript spans, or runs instead of re-parsing visible text.
- **Per-host/per-pane state memory**: recent directories, command history, and small user variables keyed by host/pane are powerful shell ergonomics.
- **Reviewed spawn palettes**: launcher menus and command palettes should expand reviewed recipes, carry icons/labels as presentation only, and show visible denial reasons when trust or policy trims what can run.
- **Marker trust and confidence**: explicit nonce-bound shell reports are safer than re-parsing scrollback and hoping the result is right.
- **Per-field confidence badges**: command text, cwd, remote-path hints, and action targets should be allowed to carry their own precision/trust annotations instead of inheriting one pane-wide myth.
- **Precision fences across hops and fallbacks**: when a layer downgrades exact cwd/command/trust knowledge, leave a visible fence instead of pretending certainty survived.
- **Optional synchronized rendering**: use redraw batching when a terminal supports it so prompt/frame/status refresh feels atomic without making the feature mandatory.
- **Capability honesty**: treat TERM names and past success as weak hints, then prefer fresh feature use and safe ignore behavior over compatibility folklore.
- **Tiny capability handshakes**: a compact feature-reporting layer for prompt markers, cwd refresh, richer input, hyperlinks, and redraw hints can keep semantic UX grounded in observed support.
- **Per-hop capability ledgers**: SSH hops, multiplexers, and nested shells should be able to say what semantic features they preserved, dropped, or only partially trust.
- **Feature truth should be live, not remembered**: same-directory spawn, exact-frame actions, and prompt-local niceties should key off the current pane/hop ledger, not one old successful handshake or a nice-looking `TERM` string.
- **Small mode baselines with explicit repair**: prompt markers, cwd freshness, cursor shape, bracketed paste, and focus-reporting should be allowed to reassert at a fresh prompt or admit that repair is needed.
- **Light resync versus hard reset**: a custom shell+terminal should clearly separate semantic resync, baseline reassertion, and full emergency reset instead of relying on one folklore hammer.
- **Semantic epochs for freshness**: when a shell restarts, a hop lands, or a resync happens, old command frames and actions should still exist but should no longer pretend to be current.
- **Control-ready versus service-ready vocabulary**: Dinit's distinction is exactly the kind of observational honesty Steward should copy.
- **Machine-friendly side protocols**: tmux control mode is a compelling reminder that parseable, asynchronous text protocols can coexist with terminal rendering.
- **Subscriptions for observational state**: a tiny subscription path for pane or component observations can beat polling without becoming an admin bus.
- **Opaque observation cursors**: snapshot-plus-change views should be able to say what point they are synced through and when that continuity was lost, instead of teaching clients that silence means everything is current.
- **Reconnect with the last opaque cursor**: simple text transports should be able to reconnect with the last synced cursor and hear either `resumed` or `refresh required`, instead of inventing sticky local optimism.
- **Input-side explicitness**: bracketed paste and richer keyboard/click reporting are worth stealing just as much as prompt markers.
- **Focus-aware command notifications**: once command boundaries exist, command-finished notifications become cheap and high-value.
- **Notification callbacks that stay explicit**: kitty's SSH-capable notification flow is a neat precedent for “focus/reveal this exact frame” without a hidden authority bus.
- **Predictive local echo on bad links**: Mosh demonstrates that latency-hiding and visibly provisional local echo are worth studying for a custom remote shell stack.
- **Provisional badges with later confirmation**: prompt-local shell metadata can be tentatively useful before it is confirmed, as long as the UI can later mark it confirmed, revised, or withdrawn.
- **Non-transcript chrome lanes**: badges, status bars, sticky headers, tab titles, and progress rings are a better home for live context than polluting prompts or command output.
- **Observational session variables**: small shell- or terminal-published variables are a great way to feed chrome, filtering, and remembered context so long as they stay freshness-scoped and non-authoritative.
- **Explicit activity brackets**: begin/end hints for in-flight work are a healthier small seam than sticky keepalive folklore.

## Ideas to steal, but only after narrowing them
- **Pane-scoped user vars / metadata**: useful for showing remote identity, active component, or receipt digests, but dangerous if they silently become policy truth.
- **Marks and decorations**: great for navigation and failure visibility, but they should remain observational.
- **Remote-aware cwd propagation**: excellent ergonomics, but it needs explicit transport boundaries and failure modes.
- **Idle-stop behavior**: compelling for some runtimes; dangerous as a universal assumption.
- **Open command output in pager / select exact output**: a big UX win, but it needs stable command-frame boundaries.
- **Lifecycle state/status chips in the terminal**: promising, but only if backed by explicit current-state channels and receipt provenance.
- **Chrome should stay copy-safe**: exporting transcript text should not silently smuggle badge/status/title ornament that was only meant for glanceable UI chrome.
- **Selection-to-anchor promotion**: very promising for “copy exact output”, “open transcript for this frame”, and “act on the same concrete run”, but it needs bounded lifetime and safe downgrade rules.
- **Shell-originated prompt/cwd markers**: fish and Ghostty suggest the shell should participate directly in semantic reporting instead of leaving it all to the terminal.
- **Exact command reporting with trusted nonce support**: VS Code’s `OSC 633` model is a strong precedent for exact command lines plus a separate trust bit.
- **Post-finish confidence upgrades**: command metadata that begins approximate should be allowed to become more exact after completion, receipt arrival, or prompt refresh.
- **Prompt-local click/URL metadata**: fish’s `click_events` and `cmdline_url` style extensions hint at lightweight ways to make prompts and command frames more navigable.
- **Paste safety as a first-class UX feature**: bracketed paste is only the floor; modern terminals are also learning that pasted control characters need visible, explicit handling rather than blind trust.
- **Transient promotion from command frames**: strong idea, but the boundary between a plain command, a transient service, and a background lease still needs care.
- **Per-cycle end-cause chips**: showing compact “requested stop / clean exit / timeout / resource kill” results next to a command frame or receipt feels high value, but only if the data is explicit and not scraped from logs.
- **Semantic fences across hops**: shells, SSH hops, and multiplexers should be able to mark where cwd/command/trust precision degraded instead of silently carrying stale certainty forward.
- **Roaming session resilience**: shell transport that survives sleep, IP changes, or spotty links could be wonderful, but it should not be mistaken for lifecycle continuity of the remote component.

## Things to admire without importing wholesale
- systemd's breadth;
- Kubernetes' orchestration ambition;
- terminal-specific remote-control protocols;
- giant service-unit grammars.

The useful pattern is to steal the small clear seam, not the whole worldview around it.

## Fresh ideas from this pass
- **Witness-fenced action chips**: command frames, receipts, and status lines could surface tiny actions such as “open transcript”, “inspect component”, or “stop same run”, but only when they carry explicit target refs and expected cycle witnesses.
- **Palette entries from terminal semantics**: Ghostty's command-palette direction hints at a lovely future where terminal programs can expose explicit actions to the palette. Steward should steal the idea cautiously: tiny descriptor, user-invoked only, no ambient mutation.
- **Hyperlink/open-action rules for receipts and digests**: kitty-style open-action routing is a great precedent for making digests, transcript refs, and docs clickable/plumbable without forcing the terminal to parse prose heuristically.
- **Minimal terminal extension posture**: kitty's “small and unobtrusive” protocol stance is a design lesson in its own right. Steward's terminal semantics should win by adding a few sharp capabilities, not by redesigning the universe.

## Subscription-backed views instead of polling
Steward should explore a tiny subscription model that starts with a bounded snapshot and then emits compact change notices for status/lifecycle views. tmux control mode subscriptions and D-Bus `PropertiesChanged` / `ObjectManager` patterns suggest a good shape: explicit watched objects, coalesced changes, and an honest resync path when the client falls behind.
References: REF-TMUX-CONTROL-MODE, REF-TMUX-CHANGES, REF-DBUS-API-DESIGN.

## Another fresh idea from this pass
A tiny terminal capability handshake could mirror Steward's broader design instinct: separate *requested UX* from *live proven support*. That feels culturally aligned with SlopOS, because it refuses to let a convenience label such as `TERM=xterm-256color` masquerade as current truth.
References: REF-ITERM2-FEATURE-REPORTING, REF-XTERM-FAQ, REF-FISH-TERMINAL-COMPAT.

## Fresh ideas from this pass
- **Remote-aware path chips**: a shell/terminal stack that can show current host, cwd authority, tmux/SSH preservation, and confidence in one compact strip would make remote work feel first-class without hidden control.
- **Same-host same-directory spawn**: kitty's SSH path is a strong precedent for opening a new pane/window already on the same remote host and directory when the path semantics were explicit.
- **Per-hop histories**: command history, recent directories, and recent Steward objects should be keyed by the actual hop path, not just by a flat local terminal identity.
- **Hop-aware action fences**: explicit actions like “inspect component” or “open transcript” can be safer if they remember not just a component/cycle target but also the expected host/path context.

## Another fresh idea from this pass
A tiny hop-lineage descriptor fits Steward's overall design stance well: it separates **where this semantic context came through** from **what authority the user currently has**. That feels much closer to SlopOS than pretending a remote-aware terminal should infer host/path truth from scrollback or ambient session ancestry.
References: REF-WEZTERM-SHELL-INTEGRATION, REF-WEZTERM-PANE-USER-VARS, REF-KITTY-SSH, REF-GHOSTTY-RELEASE-120.

## Another fresh idea from this pass
A tiny provisional-state descriptor feels like a very SlopOS-compatible steal: it separates **what the UI is optimistically showing right now** from **what has actually been confirmed by the shell/runtime path**. That keeps remote shell UX fast without letting tentative markers or action targets harden into authority-bearing truth.
References: REF-MOSH, REF-MOSH-PAPER, REF-VSCODE-SHELL-TRUST.

## Fresh steals from this pass
- **watch-this-command attention flow**: let the user explicitly watch one command frame and choose bell, toast, badge, or silent completion based on focus state and duration rather than a blanket terminal policy.
- **capability-gated progress chrome**: if the live terminal handshake says progress is supported, allow a tiny ring/bar in tab or taskbar chrome for long-running work; otherwise fall back cleanly.
- **filterable notification classes**: copy kitty's idea that notification sources/types should be classifiable so users can suppress noisy classes without disabling everything.

References: REF-KITTY-DESKTOP-NOTIFICATIONS, REF-GHOSTTY-RELEASE-130, REF-WEZTERM-NOTIFICATION-HANDLING, REF-WINDOWS-TERMINAL-PROGRESS, REF-ITERM2-FEATURE-REPORTING.

## Another fresh idea from this pass
A tiny target-anchor seam fits Steward's overall design stance well: it separates **what exact object an affordance refers to** from **what authority the current user or client has to act on it**. That feels much closer to SlopOS than treating whichever text happens to be on screen as the real API.
References: REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-HYPERLINKS, REF-KITTY-OPEN-ACTIONS, REF-VSCODE-TERMINAL-BASICS, REF-TMUX-CONTROL-MODE.

## Fresh ideas from the mode-baseline pass
- **self-healing prompt ownership**: let the shell explicitly reclaim prompt-local cursor shape, cwd freshness, and marker state when it returns, instead of expecting every program to clean up perfectly.
- **repair badges, not silent lies**: when the semantic path is confused, show a tiny “needs resync” or “baseline repaired” badge rather than pretending the current prompt state is unquestionably exact.
- **mode repair should stay local**: a user-invoked emergency reset is valuable, but it should repair the terminal path, not masquerade as component lifecycle control.

References: REF-XTERM-MANPAGE, REF-ITERM2-TMUX-INTEGRATION, REF-GHOSTTY-RESET-ACTION, REF-KITTY-CONF, REF-FISH-OSC-MARKERS.

## Fresh ideas from the chrome pass
- **Transcript truth, chrome glanceability**: make the durable record live in frames/receipts/transcripts, then let badges, sticky headers, and tab chrome summarize it for fast navigation.
- **Sticky command headers with exact anchors**: if a command is partially scrolled away, a sticky header should carry the exact frame anchor and confidence bits rather than a guessed text summary.
- **Remote-aware titles without prompt pollution**: current host, cwd summary, or active component should prefer badge/tab/status surfaces over adding more mutable text to the prompt itself.
- **Exportable chrome snapshots only by request**: if users want the current badge/status/title state preserved, capture it explicitly as a receipt/transcript annotation instead of mixing it into ordinary copy.

References: REF-ITERM2-STATUS-BAR, REF-ITERM2-BADGES, REF-WEZTERM-RIGHT-STATUS, REF-WINDOWS-TERMINAL-TIPS, REF-VSCODE-UPDATE-1106.

## Fresh ideas from the context-handoff pass
- **Attach exact command bundles, not loose paste**: make “share the last failed command” produce a bounded bundle with command text, exact output, exit code, duration, cwd, confidence, witnesses, and receipt refs instead of dumping the whole pane.
- **Collapsed frames should preserve exact reveal**: summary cards or collapsed command sections are great for scanability as long as the exact frame/output/receipt record stays one click away.
- **Share flows should be target-anchor first**: handoff should resolve through exact frame anchors and transcript spans when possible, then degrade visibly to plain text only when that precision is unavailable.

References: REF-VSCODE-UPDATE-1106, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1110, REF-ITERM2-COMMAND-SELECTION, REF-WEZTERM-SHELL-INTEGRATION.

## Fresh steals from the spawn-palette pass
- **Iterated launch entries from explicit sets**: Windows Terminal's iterable/nested commands are a sharp reminder that dynamic menu expansion can still stay explicit and reviewable when the source set is named.
- **Unsafe-profile fences**: VS Code's unsafe profile warnings are exactly the kind of small trust gate Steward should steal for helper-shell and launch-recipe discovery.
- **Action discovery should not equal arbitrary authority**: Ghostty and kitty show that command palettes are fantastic discoverability surfaces, but Steward should only map them onto reviewed actions and selectors.
- **Spawn receipts after convenience launches**: WezTerm's launch menu being backed by SpawnCommand objects is the right instinct — convenience entries should still bottom out in exact launch objects, not host folklore.

References: REF-WINDOWS-TERMINAL-COMMAND-PALETTE, REF-VSCODE-TERMINAL-PROFILES, REF-GHOSTTY-RELEASE-120, REF-KITTY-ACTIONS, REF-WEZTERM-LAUNCH-MENU.

## Fresh steals from the repair-gate pass
- **repair bundle, not mystery silence**: when repeated failures quiet a component, make “explain why retries stopped” and “attach the last failure bundle” first-class affordances.
- **clear is a named action**: copy the best historical lesson from SMF and systemd — leaving a failed/repair-required state should be explicit enough that the user knows whether they cleared history, retried once, or actually changed the configuration.
- **successful-run reset should be visible**: if a healthy run resets recent-failure pressure, show that as an explicit state transition rather than letting users think the system forgot its own history magically.

References: REF-SMF-MAINTENANCE, REF-SYSTEMD-UNIT, REF-K8S-POD-LIFECYCLE, REF-ERLANG-OTP-SUPERVISOR.

## Fresh steals from the lifecycle-fabric pass
- **Barriered status commits**: let component-originated status updates optionally ask for an acknowledgement/barrier so the shell or lifecycle view can know whether a ready/stopping/degraded update is merely emitted or actually attributed.
- **Leaf-plus-cleanup supervision shape**: copy the s6 instinct that the supervised leaf is long-lived and the cleanup hook is short-lived, visible, and not confused with the main runtime.
- **Continuity escrow with object granularity**: steal the idea that continuity should preserve exact listeners/handles/state capsules only when they are explicitly allowlisted, instead of implying a mystical half-resurrected process.
- **Maintenance beats mystery silence**: when restart pressure is exhausted or a repair gate closes, surface an explicit maintenance/repair-required state with recent evidence rather than a dead pane and implied folklore.
- **Manager-mediated introductions**: activation surfaces should be able to hand out a reviewed name/endpoint/capability and let the manager mediate the introduction, instead of asking the caller to reassemble the world from path, env, and cwd baggage.
- **Paste as reviewed intent**: paste should have preview/fence/filter affordances of its own, not just piggyback on keyboard input semantics.

References: REF-SD-NOTIFY, REF-S6-SUPERVISE, REF-SYSTEMD-FDSTORE, REF-SMF-MAINTENANCE, REF-FUCHSIA-RUNNER, REF-GHOSTTY-RELEASE-130.

## Fresh ideas from the dynamic-condition pass
- **Waiting is a real state, not a failed dependency graph**: let components say “running but waiting on peer/network/lease/user” instead of treating every missing condition as a boot-order puzzle.
- **Exact leaf correlation**: keep the supervised leaf small and nameable so restart pressure, quieted retries, and repair-required explainers can point at one concrete run rather than wrapper folklore.
- **Remote comfort without remote mythology**: same-cwd spawn, prompt jumps, and last-output paging are great, but they should remain explicit current-path conveniences rather than proof that authority or precision survived every hop.

References: REF-LAUNCHD-JOBS, REF-K8S-PROBES, REF-S6-SERVICEDIR, REF-KITTY-SHELL-INTEGRATION, REF-KITTY-SSH, REF-KITTY-NOTIFY.


## Fresh steals from the transition-helper pass
- **Transition bundles with exact helper evidence**: if a prepare/drain/cleanup helper mattered, make its outcome attachable as bounded evidence instead of hiding it in logs.
- **Ordered helper choreography without a hook empire**: borrow OTP and s6-rc's sense that some steps are ordered, but keep the portable vocabulary tiny and explicit.
- **Control-ready is still a named partial truth**: copy Dinit's honesty that a manager/control path may be up before the service's real work is ready.
- **Scoped shell memory**: per-host or per-hop command memory is great UX as long as the UI keeps saying “this is remembered context,” not “this is current authority.”
- **Paste firewall modes**: normal paste, literal-only paste, strip-controls paste, and preview-before-send should be explicit user choices rather than terminal folklore.

References: REF-S6-RC-OVERVIEW, REF-ERLANG-OTP-SUPERVISOR, REF-DINIT-SERVICE, REF-ITERM2-ONE-PAGE, REF-GHOSTTY-RELEASE-130.

## Fresh steals from the descriptor-hygiene pass
- **child-spawn descriptor receipts**: let the shell or manager record the reviewed inherited-handle set for a launch when users need to explain why a child could talk to something surprising.
- **semantic-zone powered selection**: steal WezTerm-style prompt jumps and exact output selection so “copy the last command output” does not depend on text scraping.
- **palette actions from exact targets only**: Ghostty's command-palette direction is great, but Steward should only surface actions when the current frame/receipt/component binding is explicit and fresh.
- **descriptor leak tests as hygiene, not heroics**: treat leaked control pipes, debug sockets, or notification channels as regressions with evidence, not as a class of bugs rediscovered by accident.

References: REF-GHOSTTY-RELEASE-110, REF-GHOSTTY-RELEASE-130, REF-WEZTERM-SCROLL-TO-PROMPT, REF-APPLE-INHERITING-FDS, REF-SD-NOTIFY.


## Fresh steals from the activation-checkpoint pass
- **Tiny named checkpoints, not a giant phase graph**: let the lifecycle fabric surface a few attributable moments such as activation material delivered, control-ready, serve-ready, draining, and stopped without turning them into a giant dependency calculus.
- **Exact delivery over ambient inheritance**: launchd's `launch_activate_socket` pattern is a good reminder that delivered listeners should be retrieved by exact reviewed name instead of discovered by ambient descriptor folklore.
- **Checkpoint chrome, transcript truth**: semantic terminal marks can make lifecycle progression feel fantastic if the UI shows checkpoint badges, jump targets, and explainers anchored to exact frames while keeping the underlying transcript/receipt record canonical.
- **Session-scoped observational variables**: iTerm2-style user/session variables are a nifty model for shell chrome that remembers current branch, remote hop, or component id without pretending that remembered chrome is authority.

References: REF-LAUNCH-ACTIVATE-SOCKET, REF-SD-NOTIFY, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-ITERM2-VARIABLES, REF-GHOSTTY-RELEASE-130.

## Fresh steals from the activity-bracket pass
- **Balanced work brackets**: steal XPC-style begin/end work scopes for runtimes that can support them, but keep them descriptive and local instead of turning them into a generic lease plane.
- **Stale-bracket explainers**: when busy state outlives the leaf, crashes mid-flight, or loses its matching end, surface that as explicit lifecycle evidence rather than magical immortality.
- **Frame-local busy chrome**: let exact command frames or component panes carry a tiny busy/draining badge when the runtime actually reported bracket state, and clear it when the bracket ends.
- **Cut-through stop semantics**: make it explicit that stronger policy such as operator stop, repair-required, or timeout can end the waiting story even if a runtime forgot to close a bracket.

References: REF-XPC-TRANSACTION-BEGIN, REF-XPC-TRANSACTION-END, REF-LAUNCHD-SOCKETS, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-GHOSTTY-RELEASE-130.

## Fresh steals from the stop-deferral pass
- **Live deferral handles**: if Steward ever grants a short stop-delay window, steal the handle-scoped model where exit, disconnect, or explicit close ends the privilege automatically.
- **Delay-by-default semantics**: keep app-facing stop deferral as bounded grace rather than indefinite veto, with stronger cut-through policy staying explicit.
- **Countdown-aware busy chrome**: when a runtime can honestly report remaining delay budget, show a tiny exact countdown on the frame or pane instead of a mysterious forever-busy spinner.
- **Deferral explainers with exact anchors**: make it easy to answer "what is this waiting for, and until when?" from the exact frame, cycle witness, and current grace token.

References: REF-SYSTEMD-INHIBIT-MAN, REF-SYSTEMD-INHIBITOR-LOCKS, REF-XDG-PORTAL-INHIBIT, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-ITERM2-STATUS-BAR.

## Fresh steals from the freshness-decay pass
- **Live-until timestamp on chrome**: busy chips, stop-delay countdowns, and waiting badges should carry a visible freshness horizon so the UI can degrade to last-known instead of silently lingering.
- **Remembered-versus-live labels**: recent cwd, recent component, and remote-context chips should explicitly say remembered, publisher-reported, or current so shell comfort does not masquerade as authority.
- **Renew-or-clear progress**: pane progress bars and status text should either be renewed by a real publisher or visibly expire.
- **Resync affordance next to stale state**: when a badge or frame says stale, offer refresh/resubscribe/reveal-latest actions rather than preserving false confidence.

References: REF-SD-WATCHDOG-ENABLED, REF-SYSTEMD-SERVICE, REF-WEZTERM-PANE-INFORMATION, REF-WINDOWS-TERMINAL-PROGRESS, REF-ITERM2-STATUS-BAR.

## Fresh steals from the trust-and-targeting pass
- **Shortcut authority should be earned**: make rerun, escalate, or attach-context affordances depend on trusted frame provenance instead of assuming every semantic marker deserves action power.
- **Named activation material receipts**: after start or restart, show the exact reviewed listeners, names, or delivery classes that were handed in, so the operator can explain a run without memorizing launch folklore.
- **Open-actions as routing, not heuristics**: copy the idea that links, files, receipts, and explainers can carry an explicit target class so the terminal opens the right thing on purpose.
- **Prediction with visible humility**: steal Mosh's latency-hiding instinct, but keep the UI honest that predictive echo and optimistic shell state are provisional until confirmed.
- **Remembered context labels**: when a pane inherits cwd/host/component comfort from semantic shell reports, label it as remembered, reported, or current so comfort never masquerades as authority.

References: REF-VSCODE-SHELL-TRUST, REF-LAUNCH-ACTIVATE-SOCKET, REF-DBUS-SYSTEM-ACTIVATION, REF-KITTY-OPEN-ACTIONS, REF-ITERM2-COMMAND-SELECTION, REF-MOSH-PAPER, REF-WEZTERM-PANE-USER-VARS.

## Fresh steals from the named-activation and semantic-history pass
- **Named activation lookup everywhere**: activation receipts should record the reviewed keys for delivered listeners, names, or escrowed items, and services should bind those keys explicitly instead of depending on descriptor position.
- **Kill-first honesty in lifecycle receipts**: when a component stops, the receipt should be able to say whether Steward asked politely first, escalated later, or had to kill immediately; otherwise graceful-stop folklore will quietly become assumed truth.
- **Per-line routing, not pane-wide guessing**: open/edit/explain actions should be able to use the cwd and target data for the exact clicked line or command frame instead of a guessed pane cwd.
- **Semantic-zone inspector mode**: give the terminal a debug overlay that shows prompt/input/output spans, active anchors, and precision fences so shell integration bugs can be diagnosed without packet-capture heroics.
- **Context inheritance as a per-action choice**: tabs, splits, new panes, and remote reruns should be allowed to inherit cwd or hop context independently, with the UI visibly labeling whether that context is current, reported, or remembered.

References: REF-SD-LISTEN-FDS-WITH-NAMES, REF-LAUNCH-ACTIVATE-SOCKET, REF-FUCHSIA-COMPONENT-RUNNER, REF-ITERM2-SEMANTIC-HISTORY, REF-GHOSTTY-RELEASE-130.



## Fresh ideas from the escrow and command-guide pass
- **Single-current escrow, not a continuity attic**: if Steward ever lets a component preserve narrow restart continuity, prefer one reviewed current escrow payload per concrete run or key, with replacement semantics and explicit redelivery, instead of a generic inventory of old continuation junk.
- **Activation delivery plus acknowledgement barrier**: when a component starts with named listeners, service names, or escrowed continuity, the lifecycle receipt should be able to say both *what* was delivered and *when* the manager considers that delivery acknowledged, borrowing the spirit of `sd_notify_barrier()` without cloning systemd's whole mechanism.
- **Command-guide rail and sticky frame header**: once command frames are semantic, show a subtle rail beside the frame and a sticky header when its output scrolls out of view so users always know what output belongs to what command.
- **Open target first, focus token second**: keep routed actions about exact files, receipts, explainers, or URLs separate from any platform activation token or focus request that may accompany the action.
- **Escrowed/remembered/live truth labels**: when the shell shows continuity-related context — current run, remembered run, last escrow owner, or revived endpoint — label whether that context is live, manager-redelivered, or merely remembered convenience.
References: REF-FUCHSIA-PROCESS-LIFECYCLE, REF-FUCHSIA-STOP-IDLE, REF-SD-NOTIFY, REF-VSCODE-SHELL-INTEGRATION, REF-DESKTOP-ENTRY-DBUS-ACTIVATION.


## Fresh ideas from the activation-receipt and exact-command-details pass
- **Exact-run activation receipts**: record what startup material was delivered to a concrete run, what reviewed keys named it, and whether Steward observed acknowledgement, but stop far short of a generic startup broker.
- **Frame-first command details**: make the command frame the unit that owns cwd, host/hop lineage, start time, duration, exit code, attached output, and reveal-latest actions.
- **Focus token as a trailing capability**: when an action needs to foreground a window, carry the activation token beside the exact target rather than inside it.
- **Burst-aware repair summaries**: present restart trouble in language like “3 failures in 10s; cooling down” or “repair required after repeated crash burst” instead of a hidden retry policy maze.
- **Guide rail actions for compare-with-current-run**: if a frame launched an older run, let the rail compare its receipt and witness against the newest live cycle rather than silently acting on stale memory.
References: REF-SD-LISTEN-FDS-WITH-NAMES, REF-SD-NOTIFY, REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-DESKTOP-NOTIFICATIONS-SPEC, REF-ERLANG-OTP-SUPERVISOR, REF-VSCODE-UPDATE-1109.

## Fresh ideas from the context-inheritance pass
- **Per-action inheritance toggles**: let tabs, splits, reruns, and palette launches choose cwd inheritance, domain inheritance, and profile inheritance separately instead of one vague “same context” checkbox.
- **Spawn card with quality labels**: before or after a launch, show whether inherited cwd/domain context was current, reported, remembered, or downgraded to default.
- **Line-local “open a shell here”**: use the exact frame or clicked line's cwd and hop lineage when available instead of a pane-wide guess.
- **Honest fallback breadcrumbs**: when inheritance fails, say “opened in local default context” or “cwd unresolved, used home” rather than silently degrading.
- **Explicit spawn selectors**: prefer reviewed profile/domain selectors over `$SHELL`, `COMSPEC`, or other ambient launch folklore.
References: REF-GHOSTTY-RELEASE-130, REF-WEZTERM-SPAWNCOMMAND, REF-WEZTERM-LAUNCHING-PROGRAMS, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-ITERM2-SEMANTIC-HISTORY.

## Fresh ideas from the command-guide and prompt-click pass
- **One exact command-guide seam**: make rails, sticky headers, scrollbar marks, and hover cards all resolve through the same exact frame anchor rather than inventing a separate heuristic for every widget.
- **Noise-aware guide filtering**: let low-value or structurally weird commands such as `clear`, pagers, and agent-in-buffer flows opt out of persistent guide chrome.
- **Guide diagnostics**: every guide widget should be able to reveal why it exists, what shell/terminal capability produced it, and whether the target is trusted, approximate, or stale.
- **Dotted auto marks for fallback mode**: if the terminal guessed prompt boundaries from Enter presses, show a visibly weaker guide style and gate risky actions harder.
- **Prompt-local click editing**: when the shell reports a live prompt/input zone, clicking inside it to move the cursor should feel like a real text field.
- **Frame card from sticky header**: a sticky guide header should open a compact command card with cwd, hop lineage, duration, exit/result, receipt refs, and repair/explain affordances.

- **Spawn palette with source-class badges**: let launch actions say `clean`, `current-frame cwd`, `last-reported cwd`, `root cwd`, `same domain`, or `default domain` explicitly instead of hiding everything behind “new tab here”.
- **Explain-this-launch receipts**: after a split/tab/helper-shell action, make it easy to inspect which program/profile/domain/cwd recipe actually ran and which parts were downgraded by policy or stale context.
- **Trust-aware helper shells**: convenience launches from untrusted workspaces or weakly anchored frames should visibly downgrade to safer recipes instead of pretending exact same-context spawn is always fine.

## Fresh steals from the remembered-shelf pass
- **One remembered-shelf seam**: keep recent commands, directories, and Steward objects under one explicit anti-folklore rule instead of many accidental per-widget memories.
- **Truth labels on history entries**: every shelf entry should be able to say remembered, reported, or current so recent context never masquerades as live truth.
- **Reveal-first history actions**: for weakly anchored entries, favor reveal/copy/paste/open-details over riskier same-run lifecycle actions.
- **Context-scoped pins and frecency**: stars, pins, and frecency should be scoped to explicit host/hop context and stay presentation-only, not authority.
- **Current-command object surfaces**: right-click menus, hover cards, and sticky headers should resolve to the current exact command or exact output when semantics are live.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1106, REF-ITERM2-ONE-PAGE, REF-WINDOWS-TERMINAL-ADVANCED-PROFILE.


## Fresh steals from the transcript-landmark pass
- **Landmark palette over exact anchors**: one searchable surface should list command marks, failure marks, user annotations, receipt landmarks, and pinned output spans without flattening them into generic pane history.
- **Annotate this exact output span**: let users attach a local note to a precise command frame or selected output slice so debugging insights stick to the evidence they came from.
- **Watch this exact command**: bind a focus-aware alert or toast to a concrete mark or command frame instead of a whole terminal tab; completion, failure, or fresh output can all fan out from the same exact landmark.
- **Visible provenance badges on landmarks**: show whether a mark came from the shell, Steward, the user, or a terminal fallback guess before offering higher-value actions.
- **Jump/compare/reveal from one landmark card**: every landmark should be able to reveal its frame card, select exact output, jump to the nearest receipt, or compare with the latest run when those anchors exist.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1066, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-WINDOWS-TERMINAL-ACTIONS, REF-ITERM2-MENU-ITEMS, REF-ITERM2-FEATURES.

## Fresh steals from the workspace-snapshot pass
- **Workspace snapshot cards**: treat a saved layout as an explicit object that can describe panes, selectors, domains, cwd source classes, and landmark shelves without claiming those things are live.
- **Restore truth matrix**: every restored pane should be able to say reconnected, revived, layout-only, content-only, downgraded, or failed.
- **Reopen this troubleshooting cohort**: let users save the exact cluster of log tail, helper shell, failing command frame, and component detail view they were using, then reopen it through reviewed selectors later.
- **Partial-restore receipts**: after a restore, make it easy to inspect which selectors ran, which cwd/domain fields were remembered, and what had to fall back.
- **Default arrangement without default folklore**: startup layouts can be delightful as long as they are remembered recipes and not hidden promises about live shell state.
References: REF-VSCODE-TERMINAL-ADVANCED, REF-WINDOWS-TERMINAL-STARTUP, REF-ITERM2-SESSION-RESTORATION, REF-ITERM2-ONE-PAGE, REF-WEZTERM-MULTIPLEXING.



## Fresh ideas from the replay-gate pass
- **Replay review cards**: when a remembered or restored command is about to run, show a compact card with command text, cwd source class, domain/hop lineage, provenance, freshness, and why this replay exists.
- **Pending command panes**: let users keep a build, test, migration, or helper command visible as a suspended pane/card that can be launched deliberately later.
- **Force-run as an explicit override**: if users want resurrection or restore to run immediately, expose that as an explicit selector or one-shot override instead of the ambient default.
- **Replay receipts**: after approval, emit a fresh launch receipt that points to the new frame and new runtime witness so old remembered context and the new run never blur together.
- **Inspector panes as first-class workspace objects**: take the Zellij plugin/command-pane lesson seriously and let exact receipts, repair summaries, and command explainers live as panes/cards, not just as prose in scrollback.
References: REF-ZELLIJ-FEATURES, REF-ZELLIJ-SESSION-RESURRECTION, REF-ZELLIJ-PLUGINS, REF-VSCODE-UPDATE-1109, REF-WEZTERM-LAUNCH-MENU.


## Fresh steals from the chooser-surface pass
- **Target-first chooser returns**: let file pickers and visible-output selectors return a target anchor, doc handle, or reviewed selector when possible, with a visible downgrade badge when the chooser only has raw matched text.
- **Chooser actions instead of chooser paste only**: after selecting a file or output object, offer explicit actions like `open`, `open terminal here`, `attach as context`, `reveal receipt`, or `launch helper` instead of forcing every chooser through shell insertion.
- **Ephemeral-by-default selection**: ordinary choosing should not silently mint remembered grants or durable favorites; persisting a result deserves an explicit follow-on step.
- **Composable chooser pipes**: Zellij-style picker outputs and kitty-style selection UI suggest a lovely Steward move where chooser surfaces can feed exact follow-on actions through declared payloads instead of clipboard or command-substitution folklore.
- **Modal chooser rails**: key-table UI indicators and catch-all ignore behavior are worth stealing so chooser modes feel safe and discoverable instead of input-leaky.
References: REF-KITTY-HINTS, REF-KITTY-CHOOSE-FILES, REF-ZELLIJ-FILEPICKER, REF-ZELLIJ-PLUGIN-PIPES, REF-GHOSTTY-RELEASE-130.

## Fresh steals from the assist-surface pass
- **Frame-local lightbulbs**: put quick fixes and explainers on the exact failed command frame or output slice, not somewhere generic in pane chrome.
- **Assist receipts**: every suggestion should be able to answer "why is this here?" with provenance, freshness, and the exact anchor or selector it intends to act on.
- **Reviewable repair cards**: for common failures like port collisions, missing upstream configuration, stale replay context, or denied launch policy, surface a reviewed repair card before any rerun.
- **Typed assist lanes**: keep current-line completions, recent-command suggestions, and post-command repair cards visibly distinct so the user can trust what sort of help they are about to accept.
- **Modal assist mode with dead-key safety**: Ghostty-style key tables plus a `catch_all` ignore path are a great pattern for chooser/help modes that should never leak accidental keystrokes into the live prompt.
- **Extensible but synchronous palettes**: WezTerm's command-palette augmentation hook is a neat reminder that palette growth can stay explicit and bounded instead of becoming a hidden async plugin side channel.

References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1102, REF-WINDOWS-TERMINAL-ACTIONS, REF-WEZTERM-AUGMENT-COMMAND-PALETTE, REF-GHOSTTY-RELEASE-130.



## Fresh steals from the surface-diagnostics pass
- **Show Details for every semantic affordance**: copy VS Code's instinct that shell-integration quality, detected shell, cwd, and richer diagnostics should be a visible expandable surface instead of tribal knowledge.
- **Feature-report plus shell-version receipts**: steal iTerm2's combination of terminal feature reporting and shell integration version/current-dir reporting so Steward can explain both terminal support and shell-side freshness in one exact place.
- **Inspector overlays over exact semantic zones**: Ghostty's OSC 133 inspector is the right kind of debug power — it reveals real semantic regions instead of inventing a separate fake model.
- **Unavailable actions that still teach**: instead of hiding replay, prompt-click, or exact-open actions when support is weak, show them disabled with the missing capability, freshness, or policy reason attached.
References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1103, REF-ITERM2-FEATURE-REPORTING, REF-ITERM2-ESCAPE-CODES, REF-GHOSTTY-RELEASE-130.


## Fresh steals from the session-injection pass
- **Review-before-load env cards**: when a user loads a variable bundle, show the exact names, scope (`session`, `subshell`, `workflow launch`), provenance, and clear/replace affordances before mutation happens.
- **History-aware helper commands**: let replay cards, quick fixes, and tool-originated launches declare whether they should be hidden from ordinary shell history, recorded in a separate Steward shelf, or promoted into durable recipes.
- **Subshell by default for risky convenience state**: copy Warp's instinct that temporary environment overlays are often safest in an explicit child shell.
- **Explicit remote-helper consent receipts**: if richer SSH or multiplexer UX needs tmux, wrapper commands, or rcfile hooks, make that setup visible, consented, and reviewable instead of magical.
- **Observational pane vars, not hidden control**: steal WezTerm's pane-user-var pattern for status, palette filtering, and receipts while refusing to treat those vars as privileged mutation authority.
References: REF-VSCODE-UPDATE-1108, REF-WARP-ENV-VARS, REF-WARP-SSH, REF-WEZTERM-SHELL-INTEGRATION.

## Fresh steals from the clipboard-surface pass
- **Exact copy rail**: from any live frame or landmark, offer `copy command`, `copy output`, `copy command + output`, `copy selector`, and `copy plain text` as visibly distinct actions.
- **Paste-as-staged-block**: for multiline or policy-sensitive content, paste should be able to land in a reviewed staging lane or editable block instead of always going straight to the live prompt.
- **Remote clipboard receipt**: if OSC 52 or another helper path moved data between the terminal and a remote program, show a tiny receipt or diagnostics card so the user knows what path was actually used.
- **Structured clip shelf**: let users pin an exact command frame, output slice, or reviewed selector as a clipboard-adjacent object without flattening it immediately into anonymous bytes.
- **Visible copy-mode toggle**: copy-on-select, command-aware selection, and raw drag selection should be easy to switch and easy to explain.
References: REF-KITTY-CLIPBOARD, REF-GHOSTTY-OSC52, REF-WINDOWS-TERMINAL-INTERACTION, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-VSCODE-SHELL-INTEGRATION, REF-ITERM2-ONE-PAGE.

## Fresh steals from the transfer-surface pass
- **User-approved transfer sessions**: copy kitty's rule that richer terminal-native file transfer is a reviewable session, not ambient permission for any program with PTY access.
- **Exact remote-file action split**: steal kitty/iTerm2's instinct that `edit`, `open`, `download`, and `upload` are different actions with different UX and policy fences.
- **Line-local destination strength**: steal iTerm2's line-scoped upload target idea so dropped or chosen files can bind to an exact reported cwd/anchor rather than pane folklore.
- **Path insertion as visible downgrade**: copy VS Code's shell-escaped path drop as the weaker fallback, not the gold standard.
- **Transfer-aware chooser composition**: let choosers resolve to exact transfer targets and then feed a transfer card/rail, rather than forcing every file-oriented action back through raw prompt text.
References: REF-KITTY-TRANSFER, REF-KITTY-FILE-TRANSFER-PROTOCOL, REF-KITTY-REMOTE-FILES, REF-ITERM2-SHELL-INTEGRATION, REF-ITERM2-INLINE-IMAGES, REF-VSCODE-TERMINAL-BASICS, REF-WINDOWS-TERMINAL-TIPS, REF-ZELLIJ-FILEPICKER.


## Fresh steals from the automation-surface pass
- **Action-class passwords or grants**: steal kitty's idea that one automation credential can be allowed to do only a narrow family of actions instead of everything.
- **Exact-target automation cards**: every scripted action should be reviewable as “act on this pane/tab/frame/receipt” rather than “do something to the current terminal somehow”.
- **Async request ids with visible cancel**: long-running choose/select/transfer/control actions should have compact ids, visible in-flight state, and explicit cancel paths instead of spinner folklore.
- **Control-path disclosure**: show whether a command hit a GUI instance, mux server, pane-local helper, or remote helper path before and after it runs.
- **Hook surfaces with stable names**: steal iTerm2's idea that extension points can have stable identifiers and user-facing names while still staying bounded.
References: REF-KITTY-REMOTE-CONTROL, REF-KITTY-RC-PROTOCOL, REF-WEZTERM-CLI, REF-ITERM2-RPCS, REF-ITERM2-HOOKS, REF-TMUX-CONTROL-MODE.


## Fresh steals from the notification-surface pass
- **user-armed alert on exact completion**: steal iTerm2's “alert on next mark” spirit, but bind it to an exact command frame or receipt anchor rather than a generic session.
- **unfocused-and-long-enough defaults**: steal Ghostty/WezTerm's focus-aware and duration-aware delivery instead of making command-finished notifications a binary global preference.
- **target selector first, activation token second**: keep exact reveal/open target identity separate from foreground/raise requests, following the desktop activation split.
- **transient toast, durable anchor**: every notification should point back to a durable frame/receipt/landmark so the user can recover the event after the popup disappears.
References: REF-ITERM2-SHELL-INTEGRATION, REF-GHOSTTY-RELEASE-130, REF-WEZTERM-NOTIFICATION-HANDLING, REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-DESKTOP-NOTIFICATIONS-SPEC.


## Fresh steals from the input-surface pass
- **Visible leader/key-table indicators**: modal key workflows should advertise when they are active, what exit path exists, and whether unknown keys are ignored, passed through, or terminate the mode.
- **Input provenance chips**: when bytes arrive through paste, replay, helper injection, or exact key-event reporting, keep enough provenance around to explain what really happened.
- **Read-only and mouse-capture toggles with receipts**: a local “selection beats application capture right now” switch is a great terminal affordance when it is explicit and inspectable.
- **IME/dead-key-safe bindings**: keyboard customization should acknowledge composed text and physical-vs-mapped key differences instead of assuming US-layout folklore.
- **Application-aware yielding**: terminal shortcuts should be able to yield based on explicit context such as focused editor state or active prompt zone rather than winning every key conflict forever.

References: REF-WEZTERM-KEYBOARD-CONCEPTS, REF-WEZTERM-KEYBOARD-ENCODING, REF-KITTY-MAPPING, REF-KITTY-KEYBOARD-PROTOCOL, REF-GHOSTTY-RELEASE-130, REF-GHOSTTY-KEYBIND-ACTIONS.


## Fresh steals from the media-surface pass
- **Display vs download split**: steal iTerm2's clear separation between rendering something inline and downloading it as a file.
- **Anchor-backed previews**: steal kitty's instinct that rich graphics can live in the terminal while still being tied to exact producer intent rather than OCR-style guesswork.
- **Mux honesty banners**: steal WezTerm's willingness to say when richer media is not fully handled by the current multiplexer path.
- **Render-budget diagnostics**: steal Ghostty's honesty that background and graphics features have real memory/rendering costs instead of treating them as free eye candy.
- **Thumbnail/placeholder downgrade rails**: when the exact bytes or protocol support are gone, keep the anchor and visible downgrade reason instead of silently deleting all trace of the media.

References: REF-KITTY-GRAPHICS-PROTOCOL, REF-WEZTERM-IMGCAT, REF-GHOSTTY-FEATURES, REF-GHOSTTY-RELEASE-120, REF-ITERM2-INLINE-IMAGES, REF-ITERM2-ONE-PAGE.


## Fresh steals from the link-surface pass
- **Target-class chips on hover/click**: label clickable things as `detected`, `declared`, `semantic-file`, or `exact-object` so the user knows how much trust they are getting.
- **Review-before-open rails**: keep a tiny optional rail for `open externally`, `reveal object`, `copy canonical target`, `copy visible text`, or `stage in shell` instead of one ambient default.
- **Per-line file routing**: steal semantic-history style line-local cwd and file-fragment routing when exact object identity is not available yet.
- **Keyboard link palette over typed selectors**: searchable link/open pickers should prefer typed targets and downgraded classes over blind text scraping.
- **Invocation receipts**: after opening something, keep a compact receipt that says what target class was used and whether the action downgraded.

References: REF-WEZTERM-HYPERLINKS, REF-WEZTERM-OPEN-URI, REF-KITTY-CONF, REF-KITTY-OPEN-ACTIONS, REF-ITERM2-SEMANTIC-HISTORY, REF-ITERM2-ESCAPE-CODES, REF-VSCODE-TERMINAL-BASICS, REF-VSCODE-TERMINAL-LINK-PROVIDER.


## Fresh steals from the label-surface pass
- **Pin / follow / template label modes**: let a pane or tab explicitly say “pinned by user”, “follow shell-reported context”, or “render from reviewed template” instead of one silent precedence rule.
- **Per-channel provenance chips**: make it easy to inspect whether current label chrome came from a user rename, a workspace snapshot, shell integration, an escape sequence, or a terminal-local template.
- **Label receipts, not just visual change**: after a rename or override, keep a tiny explanation card saying what channel changed and whether it displaced a weaker source.
- **Security-gated label queries**: copy Ghostty's instinct that title reporting is dangerous enough to deserve an explicit gate and diagnostics path.
- **Chrome summaries from exact fields**: steal WezTerm/kitty/iTerm2's idea that labels can summarize cwd, host, activity, or progress, but only as chrome over stronger underlying anchors.
References: REF-XTERM-CTLSEQS, REF-WINDOWS-TERMINAL-TAB-TITLE, REF-WINDOWS-TERMINAL-TIPS, REF-WEZTERM-FORMAT-TAB-TITLE, REF-WEZTERM-RIGHT-STATUS, REF-ITERM2-BADGES, REF-GHOSTTY-CONFIG-REFERENCE, REF-KITTY-CONF, REF-KITTY-REMOTE-CONTROL.

## Fresh steals from the capability-bound and activation-contract pass
- **Lockable authority narrowing**: steal the idea that reviewed launch baselines can narrow authority after setup and then explicitly lock, with visible diagnostics about whether narrowing is still provisional.
- **Send-to-name activation**: prefer an exact first request that can both activate the component and carry meaningful work over a separate pre-start ritual.
- **Trust-graded command chapters**: carry a visible ladder such as guessed, marker-derived, shell-reported, nonce-trusted, or manager-attested so the shell does not pretend every semantic clue has equal authority.
- **Startup-footing witness**: let every pane explain whether its semantic goodness comes from builtin support, an explicit addon, compatibility injection, degraded fallback, or unknown footing.
- **Paste firewall modes**: distinguish typed input from paste strongly enough to preview, literalize, stage, or downgrade suspicious multiline/control-heavy payloads.
- **Authority-ledger rails**: give shell chrome one tiny place to show host lineage, cwd source, capability support, trust grade, and freshness without pretending the rail itself is lifecycle truth.
References: REF-DBUS-SPECIFICATION, REF-OPENBSD-UNVEIL, REF-FREEBSD-CAPSICUM, REF-VSCODE-SHELL-TRUST, REF-WINDOWS-TERMINAL-SHELL-INTEGRATION, REF-KITTY-SHELL-INTEGRATION, REF-XTERM-BRACKETED-PASTE.

## Fresh steals from the authority-narrowing and reviewed-remote-session pass
- **Lock-state witness**: a helper shell, component, or reviewed action should be able to say whether authority narrowing is still configuring, already locked, degraded, or unavailable.
- **Authority rails, not ambient myths**: keep one tiny shell chrome lane for cwd source, host lineage, trust grade, narrowing state, and freshness instead of making users reverse-engineer current posture from prompt text.
- **Remote actions as reviewed sessions**: treat `open`, `edit`, `download`, and `upload` for remote targets as explicit reviewed sessions with exact targets and downgrade labels.
- **First real request activation**: when possible, let the first meaningful delivery both activate the component and carry work instead of growing a separate pre-start ceremony.
References: REF-OPENBSD-UNVEIL, REF-KITTY-REMOTE-FILES, REF-KITTY-TRANSFER, REF-DBUS-SPECIFICATION.


## Fresh steals from the request-activation pass
- **Request-carries-work activation**: let an exact first request wake the component and still carry useful work instead of hardening a separate pre-start ritual.
- **Activation target separate from focus hint**: if a launch/open path carries startup or activation-token style data, keep that visibly separate from component identity, readiness, and receipts.
- **Narrow replay envelope**: preserve only the compact reviewed first request needed to survive activation; do not grow a generic durable job queue by accident.
- **Single reviewed name beats arbitrary startup bundles**: prefer service names, exact selectors, or typed request objects over caller-controlled paths or shell strings at activation time.
References: REF-DBUS-SYSTEM-ACTIVATION, REF-DBUS-SPECIFICATION, REF-DESKTOP-ENTRY-DBUS-ACTIVATION.

## Fresh ideas from the exact-run observation and advisory-foreground pass
- **Opaque same-run fences backed by exact local handles**: let actions carry component id plus expected runtime-cycle witness, while local adapters quietly use pidfds or similar non-reused handles when available.
- **Foreground token as trailing capability**: keep open/reveal target identity separate from the compositor or desktop token that *might* help bring the handler forward.
- **Confidence ladders on command chapters**: treat `guessed`, `marker-derived`, `shell-reported`, `nonce-trusted`, and `manager-attested` as distinct grades with different allowed actions.
- **Lease-shaped stop deferral**: when work asks for a little more time, hand back one live closeable deferral handle instead of a sticky boolean that outlives the work.
- **Activation cards with exact cause**: show `first-request activation`, `manual start`, `restart after failure`, or `wake on readable escrow` as distinct causes rather than one vague `started` event.
References: REF-LINUX-PIDFD-OPEN, REF-LINUX-WAITID-PIDFD, REF-XDG-ACTIVATION-V1, REF-VSCODE-SHELL-TRUST, REF-XDG-PORTAL-INHIBIT, REF-FUCHSIA-STOP-IDLE.


## Fresh ideas from the monotonic-authority and activation-token pass
- **Monotonic authority narrowing**: once a component has entered its narrowed baseline, the healthy default is “stay equally narrow or narrower until exit”; widening should read as restart, relaunch, or an explicit reviewed handoff, not ambient rollback.
- **One-shot advisory activation tokens**: let request-carried activation optionally carry startup/focus tokens, but treat them as freshness-scoped hints that may be ignored and must never become proof of lifecycle success or later mutation authority.
- **Semantic-zone actions**: let the terminal ask exactly which prompt/input/output zone is under a cell and bind copy/open/explain/reveal actions to that zone instead of pane-wide prompt scraping.

References: REF-OPENBSD-UNVEIL, REF-FREEBSD-CAP-ENTER, REF-FREEBSD-CAP-RIGHTS-LIMIT, REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-XDG-ACTIVATION-V1, REF-XDG-PORTAL-OPENURI, REF-WEZTERM-SEMANTIC-ZONES, REF-WEZTERM-SEMANTIC-ZONE-AT.

## Fresh ideas from the stackable-narrowing and request-handle pass
- **Stackable narrowing beats one giant sandbox grammar**: if a host can add another deny layer later without widening authority, let adapters steal that trick under the membrane.
- **Sealed startup capsules under the membrane**: when a runtime needs more than a tiny selector, prefer an immutable local object with a digestable identity over env-var bales or shell-string folklore.
- **Pending request handles for mediated detours**: chooser/open/reveal flows that leave the terminal should come back as exact pending objects with response/cancel/expiry, not as spooky modal side effects.
- **Small request chips in shell chrome**: if a command launched a chooser, portal, or approval sheet, the shell should show one exact pending chip the user can inspect, cancel, or revisit.


## Fresh ideas from the request-budget and input-capture pass
- **Pending request chips with budgets**: when a command launches a chooser, approval, or activation-carrying request, show one tiny chip with `waiting`, `deadline`, `cancel`, and later `responded` / `expired` / `cancelled` truth.
- **Budget propagation for helper work**: let follow-on work inherit remaining time/cancel context instead of quietly running forever because the original requester disappeared.
- **Armed versus active capture rails**: modal input or richer keyboard capture should show `armed`, `active`, `released`, or `denied` instead of one vague “capture mode” blob.
- **Shortcut sessions, not ambient hotkeys**: out-of-focus actions should bind to exact revocable sessions with clear owner and activation/deactivation signals.
- **Under-the-membrane fd scrubbing**: steal bulk descriptor cleanup tricks like `close_range()` locally so reviewed launch baselines do not depend on accidental inherited handles.

References: REF-GRPC-DEADLINES, REF-GRPC-CANCELLATION, REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-INPUTCAPTURE, REF-XDG-PORTAL-GLOBALSHORTCUTS, REF-LINUX-CLOSE-RANGE.

- **Exact workload groups under the membrane**: use job objects, process contracts, cgroup trees, or equivalent host group objects so one reviewed component run maps to one bounded workload even when many processes are involved.
- **One-way promise floors for helpers**: after setup, helpers should be able to drop into a narrower promise set that only shrinks thereafter.
- **Transport optimism in its own lane**: steal Mosh-style local echo and roaming resilience, but keep stop/restart/inspect actions fenced to confirmed Steward truth rather than provisional transport state.

References: REF-WINDOWS-JOB-OBJECTS, REF-WINDOWS-TERMINATE-JOB-OBJECT, REF-SOLARIS-PROCESS-CONTRACTS, REF-LINUX-CGROUP-V2, REF-OPENBSD-PLEDGE, REF-MOSH, REF-MOSH-PAPER.



## New small seams worth stealing
- **Closeable grant handles for transient powers.** Pending requests, stop deferral, capture sessions, and shortcut bundles should prefer one exact handle with close/revoke semantics instead of sticky booleans or guessed ownership. References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-SESSION, REF-XDG-PORTAL-INHIBIT, REF-XDG-PORTAL-GLOBALSHORTCUTS.
- **Fail-closed owner-loss cleanup under the membrane.** Job-object kill-on-close and similar mechanisms are great local implementation tricks for making ephemeral authority die when its owner really disappears. References: REF-WINDOWS-JOB-OBJECTS.
- **Subreaper-style orphan adoption for weaker hosts.** Where a host lacks a stronger execution-group object, child-subreaper semantics are still better than pretending one PID names the whole workload forever. References: REF-LINUX-CHILD-SUBREAPER.


A good next refinement for Steward's observation path is to let snapshots, bookmark-like progress markers, and later change notices optionally carry one exact opaque cursor. Kubernetes' watch `resourceVersion` and `BOOKMARK` event, etcd's monotonic revisions plus compaction, and tmux control mode's explicit subscription/flow-control signals all suggest the same healthy pattern: resume when you can, say overflow or compaction plainly when you cannot, and do not fake a giant forever-log to get there.

References: REF-K8S-API-CONCEPTS, REF-ETCD-DATA-MODEL, REF-ETCD-MAINTENANCE, REF-TMUX-CONTROL-MODE.

## New stealable idea: server-clamped renewal windows
Let live claims request a budget, but let the manager choose the real renewal window and surface the resulting `renewed through` or `expires at` state explicitly. etcd leases, Kubernetes Lease renewals, and systemd watchdog/timeout extension hooks all point to the same small seam: bounded live claims are healthier when renewal is explicit, missable, and clearly separate from broader service health or authority widening.
References: REF-K8S-LEASES, REF-ETCD-LEASES, REF-SD-WATCHDOG-ENABLED, REF-SD-NOTIFY.

- **Consumable exact actions**: some launch, reveal, or approval affordances should intentionally be one-shot or use-bounded so old frames cannot silently spend them twice.

## Fresh stealable idea: narrow effect keys for retry-safe mutations
- **Exact effect keys for non-commutative actions**: when a start, stop, reveal, or grant-affecting action might be retried after transport uncertainty, let it carry one optional effect key instead of gambling on blind replay.
- **Mismatch should be a first-class denial**: reusing the same key with materially different target or payload should produce a visible mismatch outcome, not a quiet second mutation.
- **Duplicate-suppressed is useful truth**: when the retry really is equivalent, returning the prior outcome or receipt anchor is healthier than pretending the second attempt never existed.
- **Bounded dedupe windows, not forever ledgers**: managers may forget old effect keys after a documented retention window; the honest answer after that is `dedupe window expired`, not fake exactly-once certainty forever.
References: REF-GOOGLE-AIP-155, REF-AWS-EC2-IDEMPOTENCY, REF-AWS-ECS-IDEMPOTENCY, REF-IETF-IDEMPOTENCY-KEY.

- **Exact precondition witnesses**: let restart/stop/reveal/promote actions optionally carry one exact veto-only basis such as runtime-cycle witness, semantic epoch, cursor, or target-anchor digest, and surface `wrong cycle`, `stale anchor`, or `precondition failed` instead of auto-retargeting.


## Fresh steals from the attenuated-grant pass
- **Downscoped helper grants**: when a shell detour, chooser, reveal path, or follow-on helper needs less power than the current holder, derive a narrower child grant instead of handing the broad parent through environment or shell folklore.
- **Parent-versus-child rails**: action cards should be able to show the parent grant, the derived child scope, and the exact narrowing facts so users can explain why a helper could do one thing but not another.
- **Tiny caveat surface**: exact target, audience, action subset, expiry, and use budget are already plenty; do not let this seam smuggle in a giant policy language.
- **History proves issuance, not current authority**: old receipts or frames may explain that a child grant once existed, but they must not recreate it or imply the parent is still live.

References: REF-RFC8693-TOKEN-EXCHANGE, REF-GOOGLE-CREDENTIAL-ACCESS-BOUNDARY, REF-AWS-STS-ASSUMEROLE, REF-MACAROONS.

## Fresh steals from the holder-bound-grant pass
- **Holder-bound live grants for replay-sensitive powers**: when a grant is too dangerous to behave like copied bearer material, require proof from the current presenter instead of trusting stale history or detached helper state.
- **Holder-versus-bearer rails**: shell chrome should make `holder-proof-required`, `proof-valid`, `wrong-holder`, and `bearer-only` visibly different states.
- **Target narrowing still matters**: holder proof is not a substitute for exact target or audience narrowing; use both when the action is valuable.
- **History explains, current holder spends**: old receipts and transcript cards may explain a prior grant, but current live use should still require fresh holder proof.
References: REF-RFC9449-DPOP, REF-RFC8705-MTLS, REF-RFC9700-OAUTH-SECURITY-BCP.

## Fresh ideas from the fresh-intent pass
- **Fresh-intent chips for risky actions**: let higher-risk or foreground-sensitive chips say `fresh intent required`, `fresh`, `consumed`, `expired`, or `wrong context` instead of pretending old history is enough.
- **Current shortcut activations may refresh intent; old shelves may not**: a live shortcut or menu pick can mint fresh local evidence, but a remembered frame should have to ask again.
- **Keep attention hints separate from intent evidence**: one exact interaction may yield both a fresh-intent witness and an advisory activation/attention token, but those should stay visibly different currencies.
- **Fail closed on remote fakery**: scripts, remote control, or helpers should not be able to fake local fresh intent without a separately reviewed local mediation path.

References: REF-HTML-USER-ACTIVATION, REF-XDG-ACTIVATION-V1, REF-XDG-PORTAL-GLOBALSHORTCUTS, REF-XDG-PORTAL-OPENURI.

## Fresh steals from the retry-advice pass
- **Not-before chips, not guessed cooldowns**: when a denial or delay path knows an earliest sensible follow-up time, let the receipt and shell show `retry after 12s` or `try again at 14:03:12` explicitly instead of making users reverse-engineer hidden cooldown policy.
- **Cause and timing as separate truths**: keep `still processing`, `cooling down`, `rate limited`, and `manual clear required` separate from any optional retry hint so the UI can explain both *why* it is blocked and *when* a follow-up may make sense.
- **Advisory, not promissory**: a retry hint should guide the next attempt, not promise eventual success or silently become a cached grant.
References: REF-HTTP-RFC9110, REF-GRPC-HEDGING, REF-K8S-POD-LIFECYCLE, REF-K8S-KUBELET-CONFIG.

## Fresh steals from the weak-edge and binder pass
- **Weak helper edges**: optional helper capabilities should be allowed to exist without turning into shutdown-order facts, cycle facts, or fake availability promises.
- **Pull-first activation**: prefer capabilities and first requests that can be pulled on demand over pushed prewarming or giant start-everything rituals.
- **Binder-style wake channels**: let one exact request or connection wake a component and optionally carry a stop-notify/control lane, without turning that lane into the component's public identity.
- **Dry-run live-state switches**: if Steward later grows activation-set or policy-set transitions, make them computed, inspectable, and willing to fail instead of relying on manager vibes.
References: REF-FUCHSIA-CAPABILITIES, REF-FUCHSIA-SYS2, REF-FUCHSIA-API-RUBRIC, REF-S6-RC-UPDATE.


## Fresh steals from the execution-ground and suggestion-source pass
- **Execution-ground cards**: give each pane or command frame one compact ground summary for cwd root, hop lineage, component id, runtime-cycle witness, launch basis, and truth grade.
- **Foreground baton as a pill, not a worldview**: when the host can say who currently owns the foreground terminal turn, show it as `foreground now`, `interactive attach`, `observe only`, or `history only` rather than turning it into a portable job-control API.
- **Prediction source labels**: inline or list suggestions should be able to say `history`, `plugin`, `context completer`, or `heuristic` so helpfulness does not masquerade as certainty.
- **Accept-by-word and inspect-without-insert**: steal the nicer editor moves from PSReadLine and custom-completion shells so a suggestion can be partially accepted or examined before it becomes command text.
- **Context-aware completion rails**: completions that already know prior arguments or current cursor position are a good precedent for Steward's future command guides and chooser detours, as long as they stay advisory until compiled against the current pane.
References: REF-POSIX-TCSETPGRP, REF-PSREADLINE-PREDICTORS, REF-NUSHELL-CUSTOM-COMPLETIONS.

## Fresh steals from the launch-boundary and crash-only pass
- **Launch-shutter cards**: let shell chrome say `held here`, `eligible`, `selected for child`, `manager-redelivered`, `launch-shuttered`, or `receipt only` instead of one vague inherited-context story.
- **Boundary-first helper launch**: new pane here, rerun here, or open helper here should reuse reviewed crossing choices rather than silently dragging every current handle or env quirk across the boundary.
- **Crash-only as leaf discipline, not manager worldview**: keep ordinary components cheap to kill and quick to recover, while still preserving explicit stop/quiesce/repair semantics at the fabric layer.
- **Capability-shaped exact-run handles under the membrane**: pidfds, process descriptors, job objects, or similar host tricks are worth stealing for exact observation and cleanup without letting them become the public nouns.
References: REF-CRASH-ONLY-SOFTWARE, REF-APPLE-INHERITING-FDS, REF-LAUNCH-ACTIVATE-SOCKET, REF-FREEBSD-PROCDESC, REF-LINUX-PIDFD-OPEN, REF-WINDOWS-JOB-OBJECTS.

## Fresh steals from the activation-cause pass
- **Activation cards with exact cause**: show `manual start`, `first request`, `repair relaunch`, `restore replay`, or `scheduled wake` as distinct chips instead of one vague `started` badge.
- **Cause stays smaller than a graph**: explain why one cycle started without promising a universal causal DAG, dependency planner, or actor chain.
- **Start reason stays separate from launch basis**: let receipts show both *why* the cycle started and *what* was delivered across the launch boundary, without flattening them into one story.
- **Foreground is not the start cause**: focus/attention hints may accompany activation, but lifecycle cards should keep them clearly separate from the reason the run began.
References: REF-LAUNCHD-JOBS, REF-SYSTEMD-SD-LISTEN-FDS, REF-DBUS-SPECIFICATION, REF-DESKTOP-ENTRY-DBUS-ACTIVATION, REF-FUCHSIA-SYS2.

- **Observed-generation status stamps**: when status/readiness belongs to generation N while reviewed intent is already generation N+1, say so explicitly instead of letting one stale `ready` bit impersonate current truth.

## Fresh steals from the restart-budget pass
- **Admission budgets, not mystical retry moods**: keep one tiny public answer for how many automatic restart admissions remain inside one trailing window.
- **First start should not silently spend retry budget**: separate fresh launch from automatic restart pressure so shell/status chrome can explain what actually happened.
- **Aging beats ritual reset**: let restart pressure decay by admissions leaving the trailing window instead of by hidden success/reset folklore.
- **Budget exhaustion should upgrade explanation, not hide behind silence**: when the next automatic retry would exceed budget, surface `budget exhausted` or move into explicit repair-gate flows instead of pretending the component is merely still booting.
References: REF-ERLANG-OTP-SUPERVISOR, REF-SYSTEMD-UNIT, REF-K8S-POD-LIFECYCLE, REF-SMF-MAINTENANCE.



## Fresh ideas from the progress-window pass
- **Progress chips instead of one blind spinner**: let status rows and ground cards say `starting`, `progress seen`, `extended`, `held`, `stalled`, or `unknown` rather than hiding all pre-ready time inside one vague waiting state.
- **Explicit extension handshake**: if a runtime can honestly say “still making progress, extend this horizon”, preserve that as a named event instead of silent extra patience.
- **Pause is not stall**: deliberate operator hold or policy pause should show as `held`, not as mysterious no-progress failure.
- **Checkpoint-fed progress**: treat later explicit checkpoints as legitimate evidence that the current activation/reload attempt is moving, and record them in receipts/history instead of flattening them into one happy start timestamp.

References: REF-K8S-DEPLOYMENT, REF-NOMAD-UPDATE, REF-SD-NOTIFY, REF-SYSTEMD-SERVICE.

## Fresh steals from the liveness-evidence pass
- **Pulse truth without fake diagnosis**: let adapters report compact evidence such as `watchdog current`, `last pulse 8s ago`, `liveness stale`, or `liveness unknown` without pretending those states explain root cause.
- **Startup shields for later pulses**: steal Kubernetes' discipline that startup shielding can disable later liveness expectations until the component has actually crossed its startup boundary.
- **Evidence kind matters**: a watchdog ping, a probe success, and a reviewed local checkpoint are all useful, but they are different classes of evidence and should stay labelable.
- **Missed pulse first, restart later**: preserve one direct observation that liveness evidence went stale before policy turns that into restart, repair gate, or operator escalation.

References: REF-K8S-PROBES, REF-K8S-POD-LIFECYCLE, REF-SD-WATCHDOG-ENABLED, REF-SD-NOTIFY, REF-SYSTEMD-SERVICE.


## Fresh steal: escrow chips instead of mystical restart continuity
- **One current escrow lane, not a continuity attic**: if a component preserves reviewed continuity, prefer one current payload or named object per lane with replacement semantics rather than a growing collection of stale capsules.
- **Redelivery should be visible**: exact frames, launch receipts, or ground cards should be able to say `redelivered` or `escrow current` instead of making users infer continuity from a quiet port or lucky reconnection.
- **Do not confuse escrow with takeover**: public continuity may survive and a new leaf may receive escrowed material long before Steward can honestly say `takeover proven`.

## Tiny idea to steal next: published presence chips
Steward should probably grow one exact advertise/withdraw/expire story for reviewed discovery presence. The nice part is that the portable contract can stay tiny: `advertised`, `withheld`, `withdrawn`, `expired`, `critical`, and a receipt explaining which lane proved that.
References: REF-ETCD-LEASE-API, REF-CONSUL-AGENT-CHECK, REF-ZOOKEEPER-PROGRAMMER, REF-K8S-LEASES.

## Fresh steals from the current shell+terminal pass
- **projection surfaces**: treat sticky headers, command-guide rails, command selection, status chips, and receipt shelves as host-owned projection surfaces bound to exact frames instead of as a second hidden shell.
- **observe / attach / control / debug ladder**: make read-only following, interactive attach, typed control, and injected debug exec visibly different moves so the custom terminal stays powerful without laundering authority.
- **execution-ground packet**: give every strong frame a compact cwd/env/activation/hop witness so rerun, split, quick-open, and repair cards can say what ground they really stand on.
- **armed-versus-active shell powers**: model shortcut sessions, input capture, and stronger shell control lanes with an explicit `armed` state that stays weaker than `active`.
- **hop-scoped capability ledger**: keep a tiny per-pane/per-hop ledger for features such as prompt marks, cwd truth, keyboard richness, open-uri routing, and remote comfort preservation so luxuries key off observed support instead of terminal folklore.
- **withdrawal / attenuation chips**: when a published presence, helper grant, or discovery handle is narrowed, withdrawn, or allowed to expire, show a compact typed chip instead of letting absence masquerade as readiness or runtime failure.

References: REF-VSCODE-SHELL-INTEGRATION, REF-VSCODE-UPDATE-1109, REF-ITERM2-COMMAND-SELECTION, REF-XDG-PORTAL-INPUTCAPTURE, REF-XDG-PORTAL-GLOBALSHORTCUTS, REF-WEZTERM-PANE-USER-VARS, REF-WEZTERM-OPEN-URI, REF-GHOSTTY-SHELL-INTEGRATION, REF-KITTY-SSH.

## Fresh ideas from the lifecycle-helper and terminal-witness pass
- **Restart-versus-relocate split**: local restart budgets and any later placement move should stay visibly different decisions.
- **Helper phases without ontology bloat**: prestart/poststart/poststop are handy patterns for accountable helpers, but keep them as recipe language or adapter internals before making them public Steward roles.
- **Read-only witness mode**: Zellij's read-only session sharing is a great precedent for “observe without steering,” especially for support, demos, and cross-machine witness flows.
- **Terminal attach over explicit remote channels**: terminal-to-terminal attach over HTTPS is a reminder that attach can be an explicit reviewed transport, not only a local mux trick.
- **Approval-graded terminal automation**: per-command, per-session, and deny-by-default automation widening is a healthier model than ambient terminal control.
- **Chooser plugins over typed pipes**: Zellij's filepicker and pipes suggest a nice pattern for reviewed chooser surfaces that can return exact selected objects to another tool without screen scraping.
References: REF-NOMAD-RESTART, REF-NOMAD-LIFECYCLE, REF-ZELLIJ-RELEASE-044, REF-ZELLIJ-PLUGIN-PIPES, REF-ZELLIJ-FILEPICKER, REF-VSCODE-UPDATE-1104, REF-VSCODE-UPDATE-1107, REF-VSCODE-UPDATE-1108.



## Fresh steals from the restart-relocation and witness-mode pass
- **Revive as pending, not auto-run**: resurrection should usually reopen a remembered layout, command, or session as a reviewed pending object first; immediate execution should remain an explicit override.
- **Observe-only attach should be glorious**: read-only attach needs its own chrome, tokens, and transport truth instead of feeling like a crippled control session.
- **Prompt-local edit leases**: prompt-click and cursor-move luxuries should bind to the current live prompt lease, while historical prompts stay clearly read-only.
- **Relocation receipts, not vague recovery stories**: if a component moved because restart attempts were exhausted, the shell should be able to show that as a different event from local restart or fresh launch.
- **Helper recipes before helper roles**: keep `prestart`, `cleanup`, and `companion` as recipe labels or adapter-local patterns until repeated cross-runtime pressure proves they deserve public Steward nouns.
References: REF-ZELLIJ-SESSION-RESURRECTION, REF-ZELLIJ-RELEASE-044, REF-GHOSTTY-RELEASE-130, REF-KITTY-SHELL-INTEGRATION, REF-NOMAD-LIFECYCLE, REF-NOMAD-RESCHEDULE.


## Fresh steals from the attach-lane pass
- **Lane pills, not one attached badge**: show `observe`, `attach`, `control`, or `debug` explicitly in chrome.
- **Control upgrades with receipts**: when a session requests or gains stronger control, make that transition explicit, attributable, and reviewable instead of ambient.
- **Transport is a fact, not the authority**: keep `browser`, `mux`, `ssh-like hop`, or `terminal-to-terminal` separate from the current lane.
- **Read-only can still be excellent**: exact frame navigation, receipt reveal, export, and semantic search should all remain available in witness mode.
References: REF-ZELLIJ-RELEASE-044, REF-XDG-PORTAL-INPUTCAPTURE, REF-XDG-ACTIVATION-V1.


- **Attach continuity cards with exact state names.** Let a shell or pane show `reconnecting`, `resumed-witness`, `control expired`, `runtime replaced`, or `refresh required` instead of one vague attached badge. References: REF-NOMAD-DISCONNECT, REF-ZELLIJ-RELEASE-044, REF-XDG-PORTAL-REQUEST.
- **Resume to witness, not to power.** After a dropped path, come back read-only first and require an explicit reviewed step to regain typing or control lanes. References: REF-ZELLIJ-RELEASE-044, REF-XDG-PORTAL-INPUTCAPTURE, REF-XDG-PORTAL-GLOBALSHORTCUTS.
- **Closeable request/session handles for mediated attach.** When an attach flow opens a chooser, approval sheet, or remote session ticket, keep one exact handle with close/cancel/expiry semantics rather than sticky booleans. References: REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-SESSION.


## Fresh steals from the proposal-lane pass
- **Insert-before-run as the default proposal landing.** VS Code terminal inline chat and Warp notebooks both reinforce that a suggestion is often healthiest when it lands in editable input first instead of running immediately. References: REF-VSCODE-INLINE-CHAT, REF-WARP-NOTEBOOKS.
- **Conversation lane separate from terminal lane.** Keep agent/help turns, terminal history, and lifecycle transcript visibly distinct so one flattering UI does not blur proposal with execution. References: REF-WARP-AGENT-MODALITY, REF-VSCODE-INLINE-CHAT.
- **Session-scoped approval widening, not ambient YOLO mode.** If the user wants repeated approvals inside one exact proposal lane, make that widening explicit, local, and easy to revoke instead of global shell magic. References: REF-WARP-FULL-TERMINAL-USE, REF-VSCODE-UPDATE-1110.
- **Attach exact frames as proposal context.** Let the user hand one command frame, output slice, or notebook block into the proposal lane rather than smuggling whole panes or whole sessions as ambient context. References: REF-WARP-AGENT-MODALITY, REF-WARP-NOTEBOOKS, REF-VSCODE-INLINE-CHAT.
- **Proposal transcript stays weaker than lifecycle transcript.** Agent attempts, plan notes, and helper conversation are worth keeping, but they should not silently overwrite the exact command/run history. References: REF-WARP-FULL-TERMINAL-USE, REF-WARP-AGENT-MODALITY.


## Fresh steals from detour-return research

- **Single-use return tickets**: when a browser/auth/chooser detour needs to come back to the terminal, route it through one exact expiring ticket and mark it `returned`, `consumed`, or `rebind required` rather than guessing from focus history.
- **Witness-first return**: when a detour comes back after the original pane or runtime changed, reopen as `result available` or `observe first` before offering stronger control again.
- **Guide-ignore lists**: copy VS Code's selective sticky-scroll ignoring so agentic CLIs, `clear`, or other noisy helper commands can stay in the transcript without monopolizing command chrome.
- **External-browser honesty for auth**: for login and approval flows, prefer true external browser detours with exact local return state over embedded fake-browser panes that quietly own too much privilege.
References: REF-XDG-ACTIVATION-V1, REF-XDG-PORTAL-REQUEST, REF-XDG-PORTAL-REMOTE-DESKTOP, REF-RFC8252-NATIVE-APPS, REF-VSCODE-UPDATE-1109.


## Fresh steals from the history-lane pass
- **One remembered search, many labeled lanes.** Search can span command history, workflows, notebook blocks, prompts, and proposal memory, but every result should wear a provenance badge. References: REF-WARP-COMMAND-SEARCH, REF-WARP-AGENT-MODALITY.
- **Lane-appropriate default actions.** History often means `insert again`; workflows and notebooks often mean `insert and edit`; receipts often mean `open exact frame`; proposals often mean `open plan` or `rerun as pending`. References: REF-WARP-WORKFLOWS, REF-WARP-NOTEBOOKS, REF-VSCODE-INLINE-CHAT.
- **Separate shell-history policy from remembered availability.** A tool-run command may stay out of ordinary shell history while still living in a Steward-side remembered lane with clear provenance. References: REF-VSCODE-UPDATE-1108.
- **Conversation memory must not overwrite execution truth.** Proposal turns and agent memory can be searchable and useful, but they should never silently become the canonical lifecycle transcript. References: REF-WARP-COMMAND-SEARCH, REF-WARP-AGENT-MODALITY.


## Fresh stealable ideas from the approval-rung pass
- **Visible approval rungs, not one smart-terminal bit.** Keep `proposal`, `ask`, `allow this lane`, and `run until completion` as visibly stronger modes instead of flattening them into one ambient automation toggle. References: REF-VSCODE-UPDATE-1111, REF-WARP-AGENT-PROFILES.
- **Policy floors over convenience ceilings.** Let per-tool, per-command, or per-transport denylists outrank user-selected convenience rungs so higher autonomy never silently trumps hard safety bounds. References: REF-VSCODE-AI-SETTINGS, REF-WARP-AGENT-PROFILES.
- **Sandbox-paired higher autonomy.** When users really want faster autonomous work, pair the stronger rung with a worktree, container, disposable pane, or similar narrowed footing instead of widening power in place. References: REF-VSCODE-AGENT-TOOLS, REF-VSCODE-AI-SETTINGS.


## Fresh stealable ideas from the preflight-lane pass
- **One visible preflight lane.** Keep `explain`, `diff`, `speculative preview`, `saved reviewed plan`, and `apply` as adjacent but visibly different actions instead of one vague dry-run story. References: REF-TERRAFORM-PLAN, REF-TERRAFORM-APPLY.
- **Saved plan inspection before apply.** A reviewed plan artifact is a useful bridge to automation if it stays inspectable, exact-targeted, and willing to fail when footing drifted. References: REF-TERRAFORM-APPLY.
- **Preview can still hit policy floors.** Dry-run should be allowed to say `preview denied` or `needs wider authority` instead of pretending all previews are side-effect-free from an authorization perspective. References: REF-K8S-DECLARATIVE-CONFIG.
- **Read-only planning modes are a real product shape.** VS Code's Plan agent and Claude Code's `plan` permission mode are good reminders that research/planning can be a first-class lane instead of merely a weaker execution toggle. References: REF-VSCODE-AGENT-PLANNING, REF-CLAUDE-CODE-PERMISSIONS.


## Fresh ideas from the revision-settlement pass
- **Triple revision truth**: keep one tiny desired / observed / settled triple so shells, receipts, and action cards can explain “requested r14, observed r13, settled r12” instead of one flattering updated badge.
- **Rollback points should name the last settled basis**: when a newer revision fails or stalls, the terminal should be able to point at the last settled/stable revision rather than asking the operator to remember which attempt was trustworthy.
- **Pending promotion should stay visible**: canary success, manual promotion, and explicit operator confirmation are useful patterns, but they should remain honest pending states rather than silently collapsing into ready or done.

References: REF-K8S-PODS-OBSERVED-GENERATION, REF-K8S-DEPLOYMENT, REF-NOMAD-DEPLOYMENT-STATUS, REF-NOMAD-UPDATE, REF-SD-NOTIFY.

## Fresh ideas from the headroom-witness pass
- **Headroom chips, not just permission chips**: show `restart 2/5 in 60s`, `quota 3 pods remaining`, `rate 41/5000 until 14:00`, or `secondary limit unknown` instead of one vague denied/busy badge.
- **Spendability class should be explicit**: when something is blocked, say whether the limiter is restart budget, quota room, seat count, primary rate window, or a manual-clear requirement.
- **Primary and secondary ceilings should not collapse**: if one ceiling is observable and another is partly hidden, preserve that honesty instead of fabricating a single neat counter.
- **Reset, replenish, and manual clear need different affordances**: `wait until reset`, `age out of trailing window`, and `operator clear required` should be visibly different next steps.

References: REF-K8S-RESOURCE-QUOTAS, REF-NOMAD-QUOTA, REF-GITHUB-RATE-LIMITS, REF-SYSTEMD-UNIT, REF-SYSTEMCTL.


## Fresh ideas from the hold-state pass
- **Hold chips should name the mode**: prefer `paused`, `draining`, `frozen`, `masked`, or `start prevented` over one vague `blocked` state.
- **Resume rails should match the hold**: `resume`, `undrain`, `thaw`, and `unmask` should remain different visible affordances rather than one mythology button.
- **Current work vs new work needs separate chrome**: a draining component can be healthy for current work while closed to new admissions; a paused rollout can keep serving while refusing reconciliation.
- **Inspection holds deserve honesty**: if something is intentionally held for maintenance or inspection, say so directly instead of pretending the system is simply still busy.
References: REF-K8S-ROLLOUT-PAUSE, REF-K8S-ROLLOUT-RESUME, REF-K8S-DEPLOYMENT, REF-NOMAD-NODE-DRAIN, REF-SYSTEMCTL, REF-SYSTEMD-UNIT.


## Fresh ideas from the exception-witness pass
- **Exception chips should name the unsatisfied gate**: prefer `PDB bypassed`, `approval bypassed`, `under waiver`, or `exception expired` over one vague `forced` badge.
- **Bypass should look weaker than pass**: keep `gate satisfied` and `proceeded under exception` as visibly different truths in cards, receipts, and status strips.
- **Exceptions should be scoped and attributable**: when possible, show who requested it, who approved it, what scope it covered, and when it expires instead of leaving break-glass as invisible folklore.
- **Policy floors should be allowed to forbid bypass**: the terminal should be able to say `no bypass path here` instead of implying every blocker has an override.

References: REF-KUBECTL-DRAIN, REF-VSCODE-AGENT-TOOLS, REF-VSCODE-UPDATE-1111, REF-GITHUB-PUSH-PROTECTION-BYPASS, REF-GITHUB-PROTECTED-BRANCHES.


## Fresh ideas from the serve-state pass
- **Serve-mode chips instead of one cheerful ready lamp**: show `serving`, `draining`, `maintenance`, `degraded`, or `not serving` directly on frames and receipts when the substrate can really prove it.
- **`serving+terminating` as a first-class truth**: Kubernetes EndpointSlices and termination flow are a good reminder that something can still be serving while actively on the way out.
- **Serve-state separate from discoverability**: published/discoverable presence should not silently imply a component is currently admitting new work.
- **Exact drain language on the shell rail**: HAProxy and Envoy both show that drain is operationally meaningful enough to deserve its own tiny chip and its own nearby actions.
References: REF-K8S-ENDPOINTSLICES, REF-K8S-POD-LIFECYCLE, REF-ENVOY-HEALTHCHECKING, REF-HAPROXY-MANAGEMENT.

## Fresh steals from the pressure-witness pass
- **Pressure chips, not mystery slowness.** Show `memory: warning`, `cpu stall: some`, `io pressure: full`, or `scope: service cgroup` explicitly instead of making users infer scarcity from lag and retries. References: REF-LINUX-PSI, REF-SYSTEMD-MEMORY-PRESSURE.
- **Adapt before eviction.** Prefer early cache trim, optional-work shedding, or fresh-admission slowdown while pressure is rising rather than waiting for kill-or-fail states to teach the operator what happened. References: REF-SYSTEMD-MEMORY-PRESSURE, REF-K8S-NODE-PRESSURE-EVICTION, REF-FUCHSIA-MEMORY-RECLAMATION.
- **Scope labels on pressure truth.** Keep host-wide, cgroup-wide, service-local, or node-local pressure visibly different so one scary chip does not masquerade as global system truth. References: REF-LINUX-PSI, REF-K8S-NODE-PRESSURE-EVICTION.
- **Pressure stays observational.** Let pressure explain why something is adapting or shedding work, but never let it silently become approval, authority, or a portable kill/migrate grammar. References: REF-SYSTEMD-MEMORY-PRESSURE, REF-FUCHSIA-MEMORY-RECLAMATION.
## Fresh steals from the backpressure pass
- **Admission-throttle chips**: keep `queued`, `retry after`, `shed`, and `stop accepting` as distinct small states instead of one generic `busy` badge. References: REF-ENVOY-OVERLOAD-MANAGER, REF-K8S-APF, REF-RFC6585.
- **Fairness-aware scope labels**: if the substrate knows one queue class or priority lane is being throttled, keep that exact scope visible instead of pretending all callers are treated alike. References: REF-K8S-APF.
- **Pushback-not-permission law**: server pushback and retry-after hints should explain present overload posture without becoming a durable reservation or approval cache. References: REF-GRPC-RETRY, REF-RFC6585.
- **Exhaustion-is-not-permission-denied law**: where a substrate can distinguish resource exhaustion from auth/policy denial, Steward should preserve that truth directly. Reference: REF-GRPC-STATUS-CODES.

## Fresh steals from the adaptation-witness pass
- **Protective-response chips**: keep `cache trimmed`, `concurrency capped`, `optional work deferred`, `narrowed mode`, and `adaptation active` visibly different instead of flattening them into one vague `degraded` badge.
- **Response truth should not impersonate cause truth**: preserve both `memory warning` and `cache trimmed` when you know both, instead of letting one erase the other.
- **Survival posture deserves dignity**: deliberate reduction in luxury or concurrency is often a healthy response, not an embarrassing half-failure, and the shell should present it that way.
- **Cause links are useful but optional**: show exact cause when it is real, but prefer honest `adaptation active` over counterfeit causal certainty.
References: REF-SYSTEMD-MEMORY-PRESSURE, REF-FUCHSIA-MEMORY-RECLAMATION, REF-K8S-NODE-PRESSURE-EVICTION, REF-ENVOY-OVERLOAD-MANAGER, REF-ENVOY-ADAPTIVE-CONCURRENCY.
