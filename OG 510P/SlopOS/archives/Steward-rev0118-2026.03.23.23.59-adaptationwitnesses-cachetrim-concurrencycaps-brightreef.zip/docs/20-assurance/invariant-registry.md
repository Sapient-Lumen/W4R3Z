# Invariant registry

| ID | Invariant |
| --- | --- |
| I-SUPV-1 | Supervision targets explicit component roots, not ambient PIDs, jobs, or process trees. |
| I-SUPV-2 | Supervised lifecycle roots remain directly accountable to Steward; daemonizing escape patterns are not part of the portable contract. |
| I-ACT-1 | Activation handles are delivered under supervisor ownership; restart must not widen the public route set. |
| I-READY-1 | Successful spawn is not sufficient evidence of readiness. |
| I-QUIESCE-1 | Quiesce gates new externally triggered work but does not itself become a force-kill API. |
| I-SHELL-1 | Semantic shell/terminal metadata is observational and ergonomic; it is not lifecycle authority by itself. |
