# Claim registry

| ID | Claim |
| --- | --- |
| C-001 | Steward can define portable lifecycle meaning without adopting raw PID/process-tree control as its public model. |
| C-002 | Steward can support restart continuity while keeping activation supervisor-owned and bounded. |
| C-003 | Steward can separate startup, readiness, liveness, and quiesce enough to avoid common orchestration races. |
| C-004 | Steward can make shell/terminal UX substantially better without letting terminal integration become hidden lifecycle authority. |
| C-005 | Steward can keep supervised services directly accountable by rejecting daemonizing escape patterns and bounding restart behavior. |
