# Proof obligation registry

| ID | Obligation |
| --- | --- |
| PO-SUPV-NOAMP | Show that supervision remains component-rooted and does not depend on inherited process-tree semantics. |
| PO-SUPV-FOREGROUND | Show that supervised services cannot escape Steward accountability through daemonizing or double-fork folklore. |
| PO-ACT-ALLOWLIST | Show that restart continuity is bounded by manifest allowlists and cannot smuggle widened authority. |
| PO-READY-NORACE | Show that readiness signaling cannot be confused with mere process spawn success. |
| PO-QUIESCE-BOUNDED | Show that quiesce remains a bounded control handshake, not a hidden scheduler or retry queue. |
| PO-SHELL-SEMANTIC | Show that shell/terminal semantic channels cannot silently mutate lifecycle authority. |
