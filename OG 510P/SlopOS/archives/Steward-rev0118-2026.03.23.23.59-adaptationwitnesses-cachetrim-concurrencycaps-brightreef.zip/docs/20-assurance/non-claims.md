# Non-claims

Steward revision 1 does **not** claim:
- a full systemd replacement;
- a final dependency language;
- a generic fd/object escrow broker;
- a final external admin API;
- a final shell language or terminal protocol;
- that all host service-manager ideas are bad.

The claim is narrower: Steward can be designed coherently by freezing only a few lifecycle seams and learning aggressively from prior systems.
