# Traceability

- `supervision-posture-v0.md` supports C-001, I-SUPV-1, PO-SUPV-NOAMP.
- `activation-posture-v0.md` supports C-002, I-ACT-1, PO-ACT-ALLOWLIST.
- `readiness-posture-v0.md` supports C-003, I-READY-1, PO-READY-NORACE.
- `quiesce-posture-v0.md` supports C-003, I-QUIESCE-1, PO-QUIESCE-BOUNDED.
- `shell-terminal-integration-posture-v0.md` supports C-004, I-SHELL-1, PO-SHELL-SEMANTIC.
- research docs in `docs/90-inspirations/` supply the REF-backed rationale for why these seams were chosen first.
