# Assumption registry

| ID | Assumption |
| --- | --- |
| A-001 | SlopOS remains design-phase, so Steward must tolerate changing adjacent seams. |
| A-002 | A small user-space lifecycle manager is feasible even if host-specific primitives differ. |
| A-003 | Host facilities like signals, pidfds, job objects, sockets, and timers may exist but are not automatically Steward semantics. |
| A-004 | Some services will need restart continuity, but most do not need full process resurrection. |
| A-005 | Shell and terminal can cooperate over explicit semantic channels rather than only raw PTY parsing. |
| A-006 | The archive itself must remain smaller and easier to reason about than the parent SlopOS archive at this stage. |
