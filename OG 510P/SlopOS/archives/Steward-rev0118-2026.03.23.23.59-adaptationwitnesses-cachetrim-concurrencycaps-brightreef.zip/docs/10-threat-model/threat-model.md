# Threat model

Steward is threatened less by classical memory corruption in this archive phase and more by **semantic drift**.

## Primary semantic threats
- ambient process ancestry becoming the true lifecycle model;
- restart silently widening authority or reintroducing init-only handles;
- “spawned” being misread as “ready”;
- long-lived background work turning into hidden daemons or retry loops;
- shell/terminal UX features becoming hidden control authority;
- imported host-manager semantics being mislabeled as native Steward guarantees.

## Security / reliability consequences
- operator reasoning becomes false;
- audit trails stop matching real runtime meaning;
- policy boundaries become unenforceable;
- later proofs and validators attach to the wrong object model.

## Phase-1 response
- keep component identity explicit;
- keep activation and continuity bounded;
- keep readiness and quiesce explicit;
- refuse process-tree, job-control, and environment inheritance as portable meaning;
- preserve research traceability through REF locks and evidence indices.
