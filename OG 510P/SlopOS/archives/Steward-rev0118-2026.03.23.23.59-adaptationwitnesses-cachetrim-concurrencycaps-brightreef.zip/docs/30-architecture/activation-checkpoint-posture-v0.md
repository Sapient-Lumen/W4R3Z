# Activation checkpoint posture v0

Purpose: keep lifecycle bring-up and stop progression explicit, attributable, and small.

This seam is intentionally narrow. It does **not** invent a giant lifecycle state machine, a dependency planner, a hook grammar, or a universal workflow engine. It only says that if Steward exposes transition progress at all, that progress should be **named, ordered, and attributable** instead of reconstructed from sleeps, pidfiles, wrapper scripts, or hopeful log scraping.

## Posture
1. **Checkpoint truth is explicit, not inferred**
   - If a component exposes bring-up or stop progress beyond raw `starting` / `stopping`, those steps should be emitted as explicit checkpoints rather than guessed from spawn success, elapsed time, or log text.
2. **Control-ready and serve-ready stay distinct**
   - A checkpoint that means “the manager/control path can now exchange commands or status” must not be mislabeled as “the component can now serve declared work.”
3. **Activation delivery should have a visible seam**
   - If activation material or stable inbound endpoints are delivered at startup, the archive should preserve a place to say that delivery happened instead of treating it as ambient descriptor inheritance folklore.
4. **Checkpoint attribution must stay visible**
   - Each checkpoint should be attributable to Steward, a runtime adapter, a transition helper, or the component itself.
   - If a checkpoint crosses the manager boundary from component code, a small acknowledgement or barrier path is healthier than sleep-and-hope polling.
5. **Transition helpers may advance checkpoints, but must not impersonate the leaf**
   - Prepare / drain / cleanup helpers may contribute explicit checkpoint evidence, but their success must not silently become proof that the long-lived supervised leaf is serve-ready.
6. **Dynamic conditions can change after a checkpoint**
   - A component that once reached serve-ready may later become waiting or degraded because external conditions changed. Checkpoints do not turn dynamic conditions into permanent dependency facts.
7. **Checkpoint history is explanatory, not a hidden control plane**
   - Users and tools may inspect checkpoint progression to explain why a component is waiting, draining, or not yet ready, but that explanatory surface must not silently widen mutation authority.
8. **Phase 1 keeps the portable vocabulary tiny**
   - Steward should prefer a few portable checkpoint distinctions and explicit non-goals over freezing a giant multi-phase graph before real operating pressure exists.

## Phase-1 non-goals
- a universal lifecycle phase graph for every component kind;
- a hook or callback language for arbitrary checkpoint transitions;
- dependency edges inferred automatically from observed checkpoints;
- log scraping as the official checkpoint transport;
- any claim that reaching a checkpoint means conditions cannot later degrade.

## Adjacent docs
- `activation-posture-v0.md`
- `dynamic-condition-posture-v0.md`
- `readiness-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `status-channel-posture-v0.md`
- `supervision-posture-v0.md`
- `transition-helper-posture-v0.md`

## References
- REF-SD-NOTIFY
- REF-SYSTEMD-SERVICE
- REF-DINIT-SERVICE
- REF-LAUNCHD-JOBS
- REF-LAUNCH-ACTIVATE-SOCKET
- REF-FUCHSIA-COMPONENT-RUNNER
