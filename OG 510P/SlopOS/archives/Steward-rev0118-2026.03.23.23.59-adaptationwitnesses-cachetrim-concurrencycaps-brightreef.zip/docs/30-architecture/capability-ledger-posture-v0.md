# Capability-ledger posture v0

Purpose: define a **tiny pane/hop-scoped capability-ledger seam** so Steward can record which shell/terminal semantics are actually proven on the current path without turning `TERM`, remembered success, or desired UX into current truth.

## Posture
1. **Ledger entries record live proven support, not wished-for UX**
   - A pane may want exact command frames, cwd refresh, hyperlinks, click-to-move, prompt zones, or richer input.
   - The ledger should record only what the current pane/hop path has actually proven, preserved, or freshly re-reported.
2. **Capability scope belongs to one pane, one hop lineage, and one semantic epoch**
   - Support may differ after SSH hops, tmux-like layers, shell replacement, or explicit resync.
   - A ledger entry should therefore be scoped to the actual path and be allowed to expire or reset when that path changes.
3. **Field-by-field truth beats one compatibility badge**
   - The current path may preserve cwd refresh and prompt zones while dropping exact command reporting or click semantics.
   - Steward should prefer compact per-feature truth such as `present`, `preserved`, `degraded`, `stale`, `unsupported`, or `unknown` over one pane-wide green check.
4. **Provenance matters inside the ledger**
   - The same capability may be terminal-reported, shell-reported, mux-passed-through, locally inferred, or merely remembered from an older epoch.
   - Ledger entries should be allowed to carry that provenance so richer affordances can rank evidence honestly.
5. **Refresh beats inherited certainty**
   - A fresh capability report, new prompt, or explicit resync should be allowed to supersede older ledger state.
   - Steward should not quietly treat one past successful handshake as proof that the current semantic path still supports the same affordances.
6. **The ledger gates ergonomics, not authority**
   - Capability truth is valuable for enabling prompt-local click editing, same-context spawn, exact output copy, or richer command guides.
   - It must not quietly become permission to mutate components, bypass policy, or infer lifecycle authority.
7. **Partial preservation is healthy and should be visible**
   - Remote-aware comfort often survives in pieces: cwd may carry, user vars may pass through, or semantic zones may survive while richer input does not.
   - Steward should preserve that partial truth instead of collapsing everything into `works` or `broken`.
8. **Ledger-backed comfort is worth stealing**
   - Same-directory spawn, exact frame actions, and smarter chrome should key off the ledger when the current path proves them.
   - That keeps delightful shell UX aligned with current support rather than ambient folklore.
9. **Surface diagnostics should bottom out in the ledger**
   - When a feature is missing, stale, or downgraded, the explain-why path should be able to point at the relevant ledger row or field.
   - One tiny shared ledger is healthier than widget-local guesswork.
10. **Older ledger snapshots may remain inspectable, but not live**
   - Remembered support from a prior epoch can still help debugging or explain a downgrade.
   - It should stay clearly historical once the current pane/hop path moved on.

## Phase-1 non-goals
- inventing a giant universal shell/terminal feature ontology;
- requiring every hop or multiplexer to preserve every semantic feature;
- treating a capability ledger as a security model or lifecycle-control plane;
- freezing one final wire format for every feature bit or provenance value;
- turning remembered past support into a forever compatibility promise.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `precision-fence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `context-inheritance-posture-v0.md`
- `spawn-selector-posture-v0.md`

## References
- REF-ITERM2-FEATURE-REPORTING
- REF-WEZTERM-SHELL-INTEGRATION
- REF-WEZTERM-PANE-USER-VARS
- REF-WEZTERM-SEMANTIC-ZONES
- REF-KITTY-SHELL-INTEGRATION
- REF-KITTY-SSH
- REF-GHOSTTY-RELEASE-130
- REF-FISH-TERMINAL-COMPAT
