# History-lane posture v0

Purpose: define a **tiny history-lane seam** so typed shell history, reviewed inserts, workflows, notebook blocks, and proposal memory can be searched together without collapsing into one flattering canonical execution record.

## Posture
1. **Unified search should not flatten remembered classes**
   - A shell can become dramatically better when one remembered search surface spans ordinary command history, saved workflows, notebook blocks, proposal turns, and other small reusable artifacts.
   - Steward should allow that convenience while keeping each remembered lane visibly labeled instead of pretending every hit is “the same kind of command”.
2. **Typed execution, reviewed insertion, and proposal memory are different truths**
   - A command the user typed and executed, a workflow that pastes into the prompt, a notebook block that inserts editable text, and a proposal card that never ran all deserve different provenance.
   - Steward should not let remembered search quietly promote the weaker objects into canonical shell or lifecycle history.
3. **Default landing should follow lane provenance**
   - Ordinary command history may sensibly land as `insert again` or `open exact frame`.
   - Workflows, notebooks, prompts, and proposal artifacts should more often land as `insert`, `open as reviewed card`, `attach as context`, or `promote to recipe` instead of `run now`.
4. **Shell-history policy is explicit, not accidental**
   - Some tool-run or assistant-mediated commands may belong in ordinary shell history; others may be hidden from shell history while still remaining visible in a Steward-side remembered lane.
   - Steward should keep that choice explicit instead of letting wrapper tricks, leading spaces, or shell-specific hacks silently decide what became durable history.
5. **Conversation memory and lifecycle transcript stay separate**
   - Proposal turns, agent conversation history, plan notes, and notebook-local comments can be useful to search later.
   - They should stay weaker than the exact command frames, receipts, and runtime-cycle evidence that make up canonical execution truth.
6. **Retention and sync should vary by lane**
   - Some remembered classes may be session-local, some local-on-disk, some synced, and some team-shared.
   - Steward should keep those retention choices visible instead of pretending that one search box implies one universal persistence or sharing policy.
7. **Search results should expose lane-appropriate actions**
   - A remembered hit should be able to offer `insert`, `open conversation`, `view receipt`, `copy exact output`, `rerun as pending`, or `forget` based on what it actually is.
   - That is healthier than one giant `enter = execute` habit that ignores provenance, freshness, and policy.
8. **One small history-lane seam beats many ad hoc remembered loopholes**
   - Search panels, up-arrow helpers, workflow choosers, notebook galleries, and assistant memory views all want the same anti-folklore discipline.
   - Steward should prefer one compact history-lane posture over a pile of product-shaped exceptions.

## Phase-1 non-goals
- a universal synced memory or cloud-search family;
- forcing one storage backend or index across every remembered class;
- silently promoting proposal or notebook memory into canonical shell history;
- auto-running remembered items merely because they were selected from search;
- a giant portable notebook / workflow / conversation schema inside Steward.

## Adjacent docs
- `remembered-shelf-posture-v0.md`
- `session-injection-posture-v0.md`
- `proposal-lane-posture-v0.md`
- `replay-gate-posture-v0.md`
- `command-frame-posture-v0.md`
- `context-handoff-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `retention-surface-posture-v0.md`

## References
- REF-VSCODE-UPDATE-1108
- REF-WARP-COMMAND-SEARCH
- REF-WARP-NOTEBOOKS
- REF-WARP-WORKFLOWS
- REF-WARP-AGENT-MODALITY
