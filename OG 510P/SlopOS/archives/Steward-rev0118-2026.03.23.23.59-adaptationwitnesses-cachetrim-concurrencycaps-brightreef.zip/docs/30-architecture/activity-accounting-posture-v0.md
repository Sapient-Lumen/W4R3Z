# Activity accounting posture v0

Purpose: name the smallest useful semantics for **in-flight work, idleness, and keepalive hints** without pretending every runtime shares one universal idle model.

## Posture
1. **Lifecycle state and activity state are different things**
   - A component may be `started` yet currently idle.
   - A component may also be healthy and `ready` while still draining in-flight work during quiesce.
2. **Steward may accept narrow keepalive / in-flight-work hints**
   - Some runtimes can say “do not stop or idle-stop me yet; work is in flight”.
   - Where a runtime can express balanced begin/end work scopes cleanly, that narrower seam should stay explicit in `activity-bracket-posture-v0.md`.
3. **Activity accounting is local and descriptive first**
   - Phase 1 should treat activity reports as current descriptive truth used for local lifecycle policy.
   - They should not silently become a distributed transaction system.
4. **No universal request-count contract in v0**
   - Some components can count requests; others can only expose coarser busy/idle or transaction scopes.
   - Steward should allow adapter-local precision instead of freezing fake universality.
5. **Idle is not guessed from CPU, silence, or lack of logs**
   - Explicit activity and drain hints are healthier than heuristics based on low resource usage or quiet stdout.
6. **Activity hints interact with quiesce**
   - Quiesce should be able to stop new work while allowing declared in-flight work to drain when the runtime can express that honestly.
7. **Activity hints are not control authority**
   - Reporting “busy”, “idle”, or “draining” does not grant permission to mutate the component.
8. **Continuity and activity are separate stories**
   - Preserving escrowed handles or persistent state across restart does not imply that in-flight work survived unchanged.
   - If any activity continuity exists, it should be explicit and narrowly allowlisted.
9. **Transient shell work may eventually use this seam**
   - A future transient-command or background-promotion path may reuse the same descriptive activity vocabulary.
   - That public contract should remain unfrozen until jobs/background and shell ergonomics settle.

## Phase-1 non-goals
- a universal cross-runtime request counter;
- inferring idleness from CPU usage, network quiet, or log silence;
- a generic distributed transaction protocol;
- forcing every component to implement the same drain semantics;
- turning activity hints into an ambient keepalive loophole.

## Adjacent docs
- `design-principles-v0.md`
- `non-decisions-v0.md`
- `readiness-posture-v0.md`
- `activity-bracket-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `quiesce-posture-v0.md`

## References
- REF-XPC-TRANSACTION-BEGIN
- REF-XPC-TRANSACTION-END
- REF-FUCHSIA-IDLE-STOP
- REF-FUCHSIA-LIFECYCLE
- REF-GNU-SHEPHERD-TRANSIENT-MAKER
