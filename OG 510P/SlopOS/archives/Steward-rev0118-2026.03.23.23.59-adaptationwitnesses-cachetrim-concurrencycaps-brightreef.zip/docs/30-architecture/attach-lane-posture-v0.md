# Attach-lane posture v0

Purpose: define a **tiny explicit attach-lane seam** so shell/terminal sharing, follow mode, interactive attach, and debug entry stay policy-bounded and legible without turning terminal attachment into ambient lifecycle control.

## Posture
1. **Attach is not one thing**
   - Steward should keep at least four visibly different lanes when a person or tool engages an existing pane, shell, workspace, or lifecycle-backed console: `observe`, `attach`, `control`, and `debug`.
   - The point is not to freeze a giant RBAC ladder; it is to stop one vague word like "attached" from laundering very different powers.

2. **`observe` / witness mode is first-class**
   - A lane may permit frame inspection, transcript navigation, receipt viewing, bounded context export, and similar read-only affordances without granting typing, resizing, control actions, or debug entry.
   - Read-only attach should feel like a complete supported mode, not a broken control session.

3. **Interactive attach is stronger than observe, but still smaller than control**
   - `attach` may allow ordinary interactive shell input inside the current foreground interaction without thereby granting lifecycle mutation, approval bypass, automation widening, or arbitrary helper launch.
   - Steward should keep ordinary terminal presence distinct from lifecycle-control authority.

4. **Lifecycle control should be its own explicit lane**
   - `control` is where stop, restart, quiesce, repair, request-activation, or comparable Steward actions live.
   - Reaching that lane should require explicit current policy/grant truth, not the mere fact that a user is viewing or typing in the pane.

5. **Debug entry is different again**
   - `debug` may include injected helpers, stronger inspection, or temporary widened observation/control paths.
   - Because that lane can be materially different from normal interaction, Steward should label it explicitly and let policy trim it separately from ordinary attach/control.

6. **Upgrades between lanes must be explicit and reviewable**
   - Moving from `observe` to `attach`, from `attach` to `control`, or from `control` to `debug` should be an explicit reviewed transition with a fresh reason, current denial path, and visible resulting lane.
   - Silent ambient upgrades based on transport coincidence, shell state, or host-local folklore should be refused.

7. **Armed is not active**
   - A session may hold a current possibility to gain a stronger lane later without already being in that lane.
   - Steward should preserve the same honesty seen in activation-token and input-capture designs: `requested`, `armed`, `active`, `denied`, `expired`, or equivalent truths are healthier than a sticky boolean that pretends requested control already exists.

8. **Lane truth attaches to exact current context**
   - The current lane should be able to bind to exact frame/pane/workspace/runtime-cycle context and semantic epoch where that matters.
   - A remembered shelf entry, stale transport token, or copied transcript should not later impersonate a live control-capable attachment.

9. **Transport and lane are separate facts**
   - Local PTY presence, tmux-like multiplexing, browser/web attach, terminal-to-terminal attach, or another explicit transport may all carry attach lanes.
   - Steward should name the current lane and the current transport separately instead of assuming one transport automatically implies one authority profile.

10. **Copy/export affordances may remain available when stronger lanes are absent**
   - Exact copy, attach-to-chat, reveal-frame, or export-bounded-context actions are often safe in `observe` even when interactive or control lanes are denied.
   - That lets read-only attach remain genuinely useful.

11. **Foreground baton truth is observational, not a hidden lane upgrade**
   - Hosts may sometimes report who currently owns the foreground terminal turn.
   - Steward may show that as a compact current fact, but it should not silently turn `observe` into `attach` or `attach` into `control`.

12. **Phase 1 keeps the public vocabulary tiny**
   - The portable seam is the lane distinction plus explicit upgrade/denial truth.
   - Phase 1 does **not** standardize multiplayer editing, cursor-sharing semantics, a collaboration protocol, shared clipboard rules, or a universal remote-session transport.

## Phase 1 non-goals (explicitly deferred)
- A giant collaboration / shared-session protocol.
- A universal participant-role or ACL language.
- Standardized cursor-sharing / co-edit semantics.
- A portable browser/session transport protocol.
- A universal approval-cache or control-delegation family.

## Wiring
- Primary shell/terminal surfaces:
  - `shell-terminal-integration-posture-v0.md`
  - `command-frame-posture-v0.md`
  - `execution-ground-posture-v0.md`
  - `action-surface-posture-v0.md`
  - `input-surface-posture-v0.md`
  - `fresh-intent-posture-v0.md`
  - `target-anchor-posture-v0.md`
  - `context-handoff-posture-v0.md`
  - `semantic-epoch-posture-v0.md`
- Guardrail / refusal surfaces:
  - `non-decisions-v0.md`
  - `surface-diagnostics-posture-v0.md`
  - `descriptor-hygiene-posture-v0.md`
- Inspirations and research notes:
  - `docs/90-inspirations/lessons-from-the-past.md`
  - `docs/90-inspirations/steal-these-ideas.md`
  - `docs/90-inspirations/shell-terminal-ideas.md`
  - `docs/90-inspirations/slopos-datacube-evaluation.md`

## References
- REF-ZELLIJ-RELEASE-044.
- REF-XDG-PORTAL-INPUTCAPTURE.
- REF-XDG-PORTAL-GLOBALSHORTCUTS.
- REF-XDG-ACTIVATION-V1.
