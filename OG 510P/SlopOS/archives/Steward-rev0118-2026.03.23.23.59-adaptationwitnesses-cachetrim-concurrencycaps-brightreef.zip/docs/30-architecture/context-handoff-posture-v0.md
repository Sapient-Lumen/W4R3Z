# Context-handoff posture v0

Purpose: define a **tiny bounded evidence-handoff seam** so shell/terminal work can be exported as exact, explicit context instead of scraped scrollback.

## Posture
1. **Handoffs are explicit and user-invoked**
   - Exporting a command frame, exact output slice, or lifecycle interaction into chat, docs, bug reports, approvals, or other tools should be an explicit user action.
   - Steward should resist ambient “the whole terminal is always the context” folklore.
2. **Prefer exact bounded objects over scrollback dumps**
   - A handoff should resolve through explicit command frames, target anchors, transcript spans, receipt refs, or concrete runtime-cycle witnesses when available.
   - Visible text scraping is a fallback, not the design center.
3. **Phase-1 handoff bundles should stay small and obvious**
   - A useful minimal bundle may include: command line, selected output or exact output slice, exit code, start/end time or duration, cwd, hop lineage, semantic epoch, confidence/trust, optional component id, optional cycle witness, and optional receipt/transcript refs.
   - Avoid freezing a giant export schema before the real sharing use-cases settle.
4. **Human-usable and machine-usable forms should coexist**
   - A handoff should preserve a copy-safe human view and, when available, a structured bounded descriptor for tools.
   - This keeps shared context useful without forcing every consumer to scrape prose.
5. **Freshness and staleness must stay visible**
   - Handoff bundles belong to a semantic epoch, hop lineage, and confidence context.
   - The UI should be allowed to say “approximate”, “stale”, or “older run” instead of silently implying the export is still exact.
6. **Receipts and transcripts should be referenced, not replaced**
   - A handoff may point at receipts, transcript spans, or exact frame ids.
   - It should not pretend a pasted summary or command decoration has become the canonical lifecycle record.
7. **Secrets and ambient context must not leak by default**
   - Handoffs should avoid ambient export of whole scrollback, shell history, environment, or unrelated pane state.
   - When richer context is useful, Steward should prefer explicit inclusion and redaction surfaces over “share everything nearby”.
8. **Remote and multiplexer truth should remain descriptive**
   - If a handoff refers to remote work, it should carry enough host/path lineage to stay honest about where the context came from.
   - This remains descriptive path truth, not a hidden remote-control channel.
9. **Actionability should scale with binding strength**
   - Low-risk handoffs such as copy, quote, or attach-to-chat can survive weaker precision.
   - Higher-risk follow-ups such as rerun-same-command, stop-same-run, or inspect-same-component should require fresher exact anchors, witnesses, or explicit confirmation.
10. **Steward should prefer one bounded handoff lane over many ad hoc exporters**
   - Command decorations, “attach last failure”, “copy exact output”, “open transcript for this run”, and “escalate to approval/chat” all want the same discipline.
   - One small explicit handoff posture is healthier than every UI inventing its own half-structured scrape.

## Phase-1 non-goals
- exporting whole panes or full shell history by default;
- inventing a giant stable interchange schema for every possible consumer;
- treating copied text or chat attachments as the canonical transcript;
- letting handoff bundles smuggle raw authority-bearing capabilities;
- hiding automatic external sharing behind ordinary shell execution.

## Adjacent docs
- `command-frame-posture-v0.md`
- `target-anchor-posture-v0.md`
- `action-surface-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `chrome-lane-posture-v0.md`
- `transient-promotion-posture-v0.md`
- `chooser-surface-posture-v0.md`

## References
- REF-VSCODE-UPDATE-1106
- REF-VSCODE-UPDATE-1107
- REF-VSCODE-UPDATE-1110
- REF-ITERM2-COMMAND-SELECTION
- REF-WEZTERM-SHELL-INTEGRATION
