# Stability-window posture v0

Purpose: keep **first readiness** separate from **stable availability** when a component has only just become ready and policy wants a short dwell before treating it as safely admitted.

This seam stays intentionally small. It does **not** invent a deployment controller, a dependency planner, a full health-check grammar, or a rollout scheduler. It only says that if Steward or an adapter wants to distinguish “ready now” from “ready long enough to trust for admission / rollout / replacement decisions”, that distinction should be explicit.

## Posture
1. **Ready and stable-available stay separate**
   - A component may become ready before it is considered stably available.
   - The portable lesson is that “can serve right now” and “has remained healthy long enough to rely on for the next step” are different meanings.
2. **The dwell starts from explicit ready/healthy observation, not from spawn time**
   - A stability window should begin when the relevant ready/healthy signal is observed, not when the process started or when the manager guessed warmup finished.
3. **Losing readiness resets or voids the dwell**
   - If the component crashes, reloads incompatibly, drops readiness, or otherwise leaves the relevant healthy state, the previous dwell should not silently count as if nothing happened.
4. **Stable availability belongs to a concrete run and observed generation**
   - If Steward tracks a runtime-cycle witness or readiness generation, a completed stability window should remain attributable to those facts.
   - New runtime cycles or newer observed generations should be allowed to require a fresh dwell.
5. **This seam is about admission confidence, not mutation authority**
   - Saying `warming`, `ready but not yet stable`, or `stable-available` can guide rollout, replacement, or operator understanding.
   - It does not itself grant restart, stop, or reconfiguration rights.
6. **Tiny shell/status chips are worth stealing**
   - Ground cards, receipts, and status rows may show compact states such as `ready`, `warming 12s/30s`, `stable`, or `stability unknown`.
   - Those labels should remain explanatory rather than becoming a hidden orchestration API.
7. **Policy should be allowed to care about dwell without freezing one universal grammar**
   - Some components may not need any post-ready dwell at all.
   - Others may benefit from a small buffer because state transfer, external routing propagation, or warm caches lag behind the first ready signal.
8. **Stable availability should stay smaller than a rollout engine**
   - Steward may use this seam to explain why replacement or promotion has not advanced yet.
   - It should not thereby freeze canary math, surge policy, or a universal deployment workflow.
9. **Unknown is healthier than fake precision**
   - Some runtimes may expose an exact stable-after window.
   - Others may only say `ready now` with no stronger stability claim. Steward should preserve that honesty.
10. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional distinction among `ready`, `warming toward stable`, `stable`, and `unknown`, plus optional remaining/target duration when the adapter can prove it.

## Phase-1 non-goals
- a universal rollout or canary controller;
- one cross-runtime definition of every healthy/available condition;
- deriving dependency order automatically from elapsed warmup time;
- pretending elapsed time alone proves correctness or safety;
- a mandatory deadline/timeout grammar for every adapter.

## Adjacent docs
- `readiness-posture-v0.md`
- `readiness-generation-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `restart-budget-posture-v0.md`
- `repair-gate-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `execution-ground-posture-v0.md`
- `status-channel-posture-v0.md`

## References
- REF-K8S-DEPLOYMENT
- REF-K8S-STATEFULSET
- REF-NOMAD-UPDATE
