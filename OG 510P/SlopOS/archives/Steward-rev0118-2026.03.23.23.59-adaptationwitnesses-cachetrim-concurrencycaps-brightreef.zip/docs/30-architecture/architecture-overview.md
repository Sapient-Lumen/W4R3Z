# Architecture overview

Steward is the **component lifecycle and activation fabric** for SlopOS.

The current compression of the architecture is in [`design-principles-v0.md`](design-principles-v0.md). Those principles intentionally stop short of freezing a giant service-manager worldview while SlopOS itself is still moving.

The matching refusal set is in [`non-decisions-v0.md`](non-decisions-v0.md). That file exists to keep “not decided yet” explicit instead of letting accidental defaults harden into architecture.

## What Steward probably owns
- component identity and lifecycle roots;
- component start / stop / restart policy;
- foreground lifecycle accountability;
- explicit non-ambient launch context so component entry and restart do not depend on login-shell or session folklore;
- explicit authority narrowing and lock-state honesty so reviewed allowlists or delivered capabilities can reduce ambient authority without freezing a giant sandbox language;
- explicit descriptor hygiene so inherited handles, stdio attachment, and side channels do not become accidental contract;
- optional exact execution-group machinery under the membrane so one component run may map to one reviewed multi-process workload without turning process trees, cgroup paths, or job handles into public meaning;
- explicit attributable short-lived transition helpers that stay separate from the supervised long-lived leaf;
- supervisor-owned activation delivery plus compact activation receipts for exact-run startup material and acknowledgement;
- exact request-carried activation where the first meaningful delivery may wake the component without freezing a giant bus or focus-steering control plane;
- tiny exact request-context semantics so activation, chooser detours, and automation can carry optional deadlines and explicit cancellation without a giant RPC metadata plane;
- optional exact effect-key semantics so reviewed non-commutative actions can collapse duplicate retries, reject mismatched reuse, and stay smaller than a durable exactly-once ledger;
- optional compact retry-advice semantics so denials, cooldowns, or explicit pushback can carry earliest-follow-up hints without freezing a quota or giant retry-policy family;
- optional exact precondition-witness semantics so reviewed actions can stale-fence themselves against runtime-cycle, cursor, epoch, or anchor drift without ambient latest-lookups;
- exact closeable grant handles for pending requests, stop deferral, capture, and similar transient powers so they do not dissolve into sticky mode bits;
- optional compact consumable-grant semantics so some transient powers can be spent by use and become visibly consumed instead of replayable from stale history;
- optional compact attenuated-grant semantics so an exact live grant may derive a narrower helper or follow-on grant without exposing the parent raw or freezing a generic token-exchange / delegation plane;
- optional compact holder-bound-grant semantics so some exact live grants can require current holder proof instead of behaving like replayable bearer material;
- optional compact fresh-intent witnesses so some high-risk or foreground-sensitive actions can require recent local one-shot intent evidence instead of replayable transcript history or ambient automation;
- optional compact renewal windows so live claims can expire, renew, or admit staleness honestly without freezing a giant lease or watchdog plane;
- optional exact fence tokens or current-owner witnesses so reassignable live claims can reject stale holders without freezing a distributed lock, leader-election, or global sequencer plane;
- optional exact-run observation tricks under the membrane so runtime-cycle witnesses can be backed by non-reused host handles where available without turning those handles into portable meaning;
- lifecycle observation vocabulary, compact status reporting, freshness-decay rules, bounded observation subscriptions, and optional exact observation cursors so views can resume or admit continuity loss honestly;
- explicit provisional-state semantics so lag-hiding shell/terminal UX stays visibly tentative until confirmation;
- explicit attention hints so command-finished, needs-input, warning, and progress-like shell/terminal cues stay user-filterable, freshness-scoped, and non-authoritative;
- explicit notification surfaces so OS toasts, mark-alert style wakeups, and similar escalation cues stay exact-anchor-bound, focus-aware, and action-bounded instead of becoming a hidden approval path;
- optional runtime-cycle witnesses for correlating concrete runs;
- compact start-of-cycle activation observations for explaining why a concrete run began without freezing a giant causal graph;
- compact end-of-cycle cause / termination observations for explaining why a concrete run ended;
- bounded repeated-failure cooldown and optional repair-gate semantics so crash loops become explicit evidence instead of hidden retry folklore;
- bounded continuity escrow;
- an optional tiny continuity-escrow truth so `escrow current`, `redelivered`, or `flushed` can stay separate from runtime identity, serving/drain role, and proven takeover;
- an optional tiny presence-advertisement seam so `advertised`, `withheld`, `withdrawn`, `expired`, or `critical` can stay separate from readiness, serving truth, and runtime-cycle identity;
- readiness, optional tiny readiness-generation witnesses for stale-fencing mid-run config/reload drift, optional tiny progress windows so warming/reload work can be distinguished from stalled bring-up, an explicit tiny hold-state seam so `paused`, `draining`, `frozen`, or `start-prevented` truth stays separate from stall/failure/off, activity accounting, explicit activity brackets for runtimes that can support them, bounded stop deferral, and quiesce semantics;
- optional tiny liveness-evidence semantics so watchdog/probe/check-in truth can stay separate from readiness, useful work progress, and later repair policy;
- lifecycle transcripts / receipts;
- shell/terminal semantic integration for lifecycle-aware UX;
- command-frame observations and receipt-friendly terminal ergonomics;
- an explicit attach-lane seam so observe-only witness mode, interactive attach, lifecycle control, and debug entry stay visibly different moves instead of one vague attached state;
- an explicit attach-continuity seam so reconnecting, resumed witness, expired, replaced, and lost terminal presence stay separate from runtime-cycle or service-lifecycle truth;
- an explicit proposal-lane seam so agent/chat/notebook suggestion work stays visibly separate from exact shell input, reviewed execution, and canonical lifecycle transcripts;
- an explicit approval-rung seam so proposal-only help, ask-before-run, scoped auto-approval, and run-until-completion stay visibly different powers with policy floors and honest downgrade;
- an explicit exception-witness seam so bypass-under-review, waived-under-expiry, and satisfied-gate truth stay visibly different without freezing a giant waiver or break-glass family;
- an explicit headroom-witness seam so allowed, approved, and ready stay visibly separate from currently spendable restart / quota / rate-window headroom;
- an explicit serve-state-witness seam so `serving`, `serving+terminating`, `draining`, `maintenance`, `degraded`, and `not serving` stay visibly separate from mere process liveness, readiness folklore, and discoverability;
- an explicit pressure-witness seam so scoped `ok` / `some` / `full` / `warning` / `critical` pressure truth stays visibly separate from serving mode, headroom, and failure;
- an explicit backpressure-witness seam so `queued`, `retry-after`, `shed`, and `stop-accepting` truth stays visibly separate from pressure, headroom, and failure;
- an explicit adaptation-witness seam so cache trim, reduced concurrency, optional-work deferral, and other protective responses stay visibly separate from pressure, backpressure, and vague degraded folklore;
- an explicit preflight-lane seam so explain, diff, speculative preview, reviewed saved plan, and apply stay visibly different moves with exact footing and honest stale/denied outcomes;
- an explicit revision-settlement seam so reviewed desired revision, observed revision, and last settled/stable revision stay visibly different without freezing a giant rollout controller;
- an explicit return-ticket seam so browser/auth/chooser detours can come back as exact expiring local hints without turning callback or focus folklore into lifecycle meaning;
- an explicit execution-ground seam so panes, command frames, and receipt cards can show cwd root, hop lineage, runtime-cycle witness, launch basis, and truth labels without pretending chrome is authority;
- explicit shell/terminal attention-hint surfaces for focus-aware alerts, badges, and progress-ish cues without hidden control;
- an explicit notification-surface seam for OS toasts, alert-on-mark wakeups, and exact reveal actions that remain compact, focus-aware, and clearly separate from durable truth;
- an optional shell/terminal chrome lane for status bars, sticky headers, tab titles, and other non-transcript presentation surfaces that remain observational and freshness-scoped;
- an explicit command-guide seam for exact-frame guide rails, sticky headers, and similar visible command boundaries that stay filterable and distinct from transcript truth;
- an explicit transcript-landmark seam for marks, annotations, alerts, and exact jump targets that stay anchor-bound, provenance-labeled, and clearly separate from transcript truth or ambient control;
- an explicit context-inheritance seam for tabs, splits, reruns, and action-launched shells so same-cwd or same-domain comfort stays per-action, labelable, and policy-bounded;
- an explicit spawn-selector seam so tabs, splits, reruns, and helper shells can choose reviewed program/profile/domain/cwd recipes instead of ambient `$SHELL`, profile, or pane folklore;
- an explicit spawn-palette seam so launcher menus and command palettes expose reviewed recipes, visible downgrades, and exact launch explanations instead of acting as an ad hoc command hole;
- an explicit surface-diagnostics seam so shell/terminal affordances can explain capability, freshness, provenance, and policy reasons instead of behaving like magic;
- an explicit remembered-shelf seam so recent commands, directories, and Steward objects can stay keyed to host/hop context, freshness-labeled, and clearly non-authoritative;
- an explicit history-lane seam so unified remembered search can span typed history, reviewed inserts, workflows, notebook blocks, and proposal memory without flattening them into one canonical execution record;
- an explicit retention-surface seam so persisted command, directory, paste, and host/user breadcrumbs stay scopeable, erasable, and clearly remembered instead of becoming ambient retained authority;
- an explicit replay-gate seam so remembered, restored, or suspended commands can reopen as reviewed pending actions instead of silently rerunning from stale shell folklore;
- an explicit chooser-surface seam so file pickers, visible-text selectors, and context pickers can return exact targets or reviewed selectors instead of pasted-text folklore;
- optional small pending-request handles for chooser/open/reveal detours so mediated UI interactions can stay attributable instead of becoming modal side effects;
- an explicit assist-surface seam so quick fixes, suggestion menus, and current-input help stay anchored, reviewable, and clearly advisory instead of becoming an ambient second shell;
- an explicit automation-surface seam so scripts, hooks, remote-control APIs, and helper CLIs stay exact-targeted, permissioned, and inspectable instead of becoming an ambient second control plane;
- compact confidence / provenance / trust annotations for shell/terminal observations and action gating;
- explicit user-invoked action surfaces for hyperlinks, chips, and palette affordances tied to explicit Steward targets;
- explicit target anchors so higher-value shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs instead of visible-text scraping;
- explicit bounded context handoff so exact command frames, output slices, receipts, and concrete runs can be attached or exported without ambient whole-scrollback sharing;
- explicit precision fences for shell/terminal trust and capability drift across hops or fallback paths;
- an explicit shell/terminal mode baseline and repair seam so prompt-critical markers, cursor modes, paste handling, and other UX-critical state can be freshly reasserted instead of left to folklore;
- explicit capability handshakes so richer shell/terminal semantics can be enabled from fresh observed support instead of compatibility folklore;
- explicit pane/hop-scoped capability ledgers so rich shell/terminal affordances can key off what the current path actually preserved, degraded, or re-reported;
- explicit semantic epochs so stale shell/terminal certainty can be fenced after hops, resync, or shell reset;
- explicit shell/terminal hop lineage so remote-aware context, histories, and action targets stay scoped to the actual path rather than a flat PTY fiction;
- explicit promotion of selected shell-launched long-running work into transient accountable objects.

## What Steward probably does not own
- generic deferred work scheduling (that stays adjacent to jobs/background seams);
- a generic global timer language;
- a monolithic logging system;
- a generic process inventory API;
- a portable exactly-once mutation or dedupe-ledger plane;
- a general-purpose host service-manager compatibility layer as native meaning;
- every shell/runtime semantic in SlopOS;
- a universal trusted-UI, consent-cache, biometric, or passkey family;
- a universal shared-session / collaboration / remote-attach transport family;
- a universal reconnect-roaming / silent-retarget attach family;
- a universal unified remembered-search / synced-history / cross-lane memory family;
- a universal startup-timeout / progress-deadline / extend-timeout DSL.
- a universal maintenance-window / disable-policy / drain-planner / inhibit-hold family.
- a universal liveness-probe / watchdog / degraded-health DSL.
- a universal service-registry / discovery-lease / balancer-membership DSL.
- a universal overload / fair-queuing / retry-budget / traffic-shaping family;
- a universal brownout / autoscaling / remediation-policy / adaptive-tuning family.

## Design stance
Steward should cover the **responsibility areas** people expect from a competent modern service fabric, but not inherit the integrated, ambient, host-global worldview of a traditional Unix service manager.

That means:
- narrow public semantics,
- foreground, directly accountable lifecycle roots,
- host-specific implementation freedom under the membrane,
- visible non-decisions while SlopOS itself is still converging,
- open questions kept visible until pressure justifies freezing them,
- observational/state protocols and bounded subscription views hardening before giant mutation/control surfaces;
- repeated-failure quieting becoming explainable before any giant retry-policy language hardens;
- optional liveness evidence staying narrow and observational before any broader health-check or degraded-mode family is considered;
- optional presence-advertisement truth staying narrow and reviewable before any broader discovery-registry, lease, or balancer-membership family is considered;
- optional backpressure truth staying narrow and reviewable before any broader overload, fair-queuing, or traffic-shaping family is considered;
- optional adaptation truth staying narrow and reviewable before any broader brownout, autoscaling, or remediation-policy family is considered;
- retry-safe action keys staying explicit and narrow before any broader transaction or exactly-once plane is considered;
- bounded continuity escrow staying explicit and reviewable before any broader checkpoint/restore or generic state-broker family is considered;
- attenuation-only derived grants staying explicit and narrow before any broader delegation, impersonation, or token-exchange plane is considered;
- stale-fenced conditional actions staying explicit before any broader compare-and-swap, lock, or query language is considered;
- stale-holder fences staying explicit before any broader lock, leadership, or sequencer family is considered.
- holder-proof seams staying optional and exact before any broader proof-of-possession, key-lifecycle, or token-introspection family is considered.
