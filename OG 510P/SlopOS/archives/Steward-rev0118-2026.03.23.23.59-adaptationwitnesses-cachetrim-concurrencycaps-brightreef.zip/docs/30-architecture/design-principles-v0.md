# Design principles v0

Purpose: compress the current Steward research into the **smallest stable set of guardrails** while SlopOS itself is still in design.

This document is intentionally lighter than a full architecture spec. It is meant to keep future revisions coherent without forcing early decisions that the archive has not yet earned.

## Principles

1. **Keep lifecycle authority explicit**
   - If Steward owns a lifecycle action, the target component and the authority to act on it should be explicit and reviewable.
   - Steward should not depend on ambient session, process-tree, or terminal folklore for its portable meaning.

2. **Keep lifecycle roots component-shaped, not PID-shaped**
   - Steward should supervise explicit component identities and lifecycle roots, not arbitrary host processes.
   - Process trees may exist underneath an implementation, but they are not the portable product contract.

3. **Keep supervised services foreground, accountable, and non-ambient at launch**
   - A supervised service should present one directly accountable runtime root to Steward.
   - Self-daemonizing, double-fork, and “the real process escaped somewhere else” patterns are exactly the kind of folklore Steward should avoid.
   - Restart should replay explicit reviewed launch meaning, not ambient login-shell, `PATH`, terminal-session, or manager-global environment baggage.

4. **Keep the stable public face manager-owned**
   - Activation, listener identity, and public continuity should belong to the system fabric and be handed to component instances.
   - Restart should not mean “the process gets to recreate the whole outside world however it likes.”

5. **Keep supervision smaller than orchestration**
   - Supervision, planning, activation, readiness, quiesce, and runtime-specific launching are related, but they are not all one thing.
   - Steward should prefer visible seams over one giant manager that silently accumulates every policy in the system.

6. **Keep health vocabulary split on purpose**
   - Startup, control-ready, readiness, liveness, crash, quiesce, idle, and stopping are different states with different operational consequences.
   - Steward should not guess readiness from spawn success or hide overload/recovery state behind generic “running” language.

7. **Keep continuity bounded and allowlisted**
   - Continuity across restart should be an explicit escrow story for specifically allowed handles or state.
   - Steward should resist promising full-process resurrection or generic hidden state preservation.

8. **Keep evidence close to lifecycle actions**
   - Lifecycle operations should be receipt-capable and transcript-friendly.
   - Steward should prefer compact evidence and bounded summaries over log scraping and folklore reconstruction.

9. **Keep shell and terminal semantics explicit**
   - Prompt boundaries, command frames, marks, working directory, hyperlinks, and lifecycle receipts should travel on explicit semantic channels when available.
   - Semantic markers should carry provenance or trust signals when practical instead of being treated as automatically authoritative.
   - PTY bytes remain useful, but they are not the only truth.

10. **Standardize observations before mutations**
   - It is healthier to freeze small observational/status protocols before freezing broad mutation/control planes.
   - Lifecycle observation vocabulary, readiness/status channels, shell/terminal integrations, and receipts can harden earlier than giant admin buses, timer DSLs, or orchestration grammars.

11. **Delay generic control languages until pressure is real**
   - Giant global unit DSLs, generic timer languages, broad admin buses, and process-inventory surfaces should only appear if they become truly necessary.
   - Until then, narrow posture docs, explicit non-decisions, and visible open questions are healthier than speculative frameworks.

12. **Keep activity accounting explicit and local**
   - In-flight work, drain state, busy/idle hints, and keepalive claims should be explicit when they exist.
   - Steward should not guess idleness from low CPU, quiet logs, or silence on the wire, and it should not freeze a fake universal request-count model.

13. **Keep authority narrowing explicit, reviewable, and lockable**
   - When an implementation can narrow filesystem/process authority, it should do so through explicit reviewed allowlists or delivered capabilities rather than ambient search paths, cwd assumptions, or inherited namespaces.
   - Steward should learn from capability systems and path-allowlist designs without freezing a giant portable sandbox DSL before real pressure exists.

14. **Prefer exact request-carried activation over split-phase start rituals**
   - When a component can be activated by the first meaningful request, Steward should prefer that exact delivery over a separate “start now, work later” ceremony.
   - Foregrounding, focus, or desktop activation hints may travel alongside that request, but they should remain separate from lifecycle truth, scoped to the triggering interaction, and safe to ignore.

15. **Prefer monotonic authority narrowing within one runtime cycle**
   - When a launch or helper narrows authority, that narrowing should generally only stay the same or tighten further until the cycle ends.
   - Widening should look like an explicit new lifecycle decision such as a restart, relaunch, or separately reviewed capability handoff, not a quiet ambient rollback.

16. **Prefer exact-run observation handles under the membrane**
   - Where a host offers non-reused observation handles for a concrete run, Steward implementations should prefer them over plain numeric IDs when correlating wait, stop, and stale-action fences.
   - The public contract should still stay at the opaque runtime-cycle witness rather than freezing a portable pidfd/job-handle API.

17. **Keep request budgets explicit when work is no longer worth waiting for**
   - Exact request ids, optional deadlines, and explicit cancellation are often enough to keep activation, chooser, and automation work bounded.
   - Steward should prefer those small request-budget facts over ambient infinite waiting, hidden retries, or a giant universal RPC context grammar.

18. **Prefer exact closeable grant handles for transient powers**
   - If a request, capture session, stop-deferral window, or shortcut bundle stays live, Steward should prefer one exact handle with close/release semantics over sticky booleans or hidden mode flips.
   - When implementations can detect owner loss or last-handle close, they should fail closed beneath the membrane instead of letting transient authority drift.

19. **Prefer renewable windows over sticky liveness folklore**
   - When a live claim truly needs a deadline or keepalive story, Steward should prefer one compact renew-or-expire window over hidden permanence.
   - Renewing a claim should confirm continuity of that exact claim, not silently widen authority or pretend broader health truth than the source can honestly support.

20. **Prefer consumable grants when stale reuse would be unsafe**
   - When one reviewed interaction or high-value action should happen once or a very small number of times, Steward should prefer explicit use-bounded grants over replayable ambient affordances.
   - Consumed, expired, revoked, and denied should remain visibly different outcomes rather than collapsing into vague 'not available'.

21. **Prefer narrow effect keys over blind duplicate mutation**
   - When a reviewed non-commutative action might be retried after transport uncertainty, Steward should prefer one explicit effect key plus a reviewed fingerprint over hoping the action is magically safe to replay.
   - Duplicate-suppressed, still-processing, mismatch, and dedupe-window-expired should remain visibly different outcomes rather than collapsing into fake exactly-once certainty.

22. **Prefer exact local precondition witnesses over ambient latest-lookups**
   - When an action should only apply if the exact observed basis is still current, Steward should prefer one compact veto-only witness fence over stale-shell optimism or hidden refresh logic.
   - Wrong-cycle, stale-anchor, moved-epoch, and precondition-failed should remain visibly different outcomes rather than collapsing into silent retargeting.

23. **Prefer stale-holder fences over hoping revoked owners stop in time**
   - When a renewable or reassignable live claim can migrate between holders, Steward should prefer one optional fence token or current-owner witness over assuming the old holder noticed expiry or revocation immediately.
   - Current, renewed, superseded, and stale-holder-rejected should remain visibly different outcomes rather than collapsing into vague lease loss.

24. **Prefer attenuation-only derived grants over raw helper inheritance**
   - When a helper, detour, or follow-on action needs less power than the current live grant already carries, Steward should prefer deriving one narrower child grant over handing the broad parent through ambient environment, shell state, or descriptor folklore.
   - Derived, parent-expired, parent-consumed, and derivation-policy-denied should remain visibly different outcomes rather than collapsing into one vague authorization failure.

25. **Prefer holder-bound live grants over replayable bearer history when stakes are high**
   - When a live grant controls a replay-sensitive action or detour, Steward should prefer requiring current holder proof over assuming copied raw values, old chips, or detached helper state are still safe to spend.
   - Proof-valid, proof-missing, wrong-holder, holder-rotated, and bearer-only should remain visibly different outcomes rather than collapsing into vague authorization failure.

26. **Prefer fresh local intent witnesses over replayed action history for high-risk local actions**
   - When a foreground-sensitive or higher-risk shell action really needs proof of current human intent, Steward should prefer one fresh, local, optionally consuming witness over stale transcript history, ambient automation, or long-lived approval folklore.
   - Intent evidence should stay bound to one reviewed action summary and current session context instead of quietly turning into a reusable grant or identity token.

## Phase-1 non-goals
- a final dependency-planner DSL;
- a generic timer/schedule language;
- a generic process inventory or adoption API;
- a promise that all SlopOS runtimes share one execution model;
- a giant shell/terminal RPC fabric before a small semantic channel is proven useful.

## Adjacent docs
- `architecture-overview.md`
- `non-decisions-v0.md`
- `supervision-posture-v0.md`
- `launch-context-posture-v0.md`
- `authority-narrowing-posture-v0.md`
- `activation-posture-v0.md`
- `request-activation-posture-v0.md`
- `request-context-posture-v0.md`
- `grant-handle-posture-v0.md`
- `consumable-grant-posture-v0.md`
- `attenuated-grant-posture-v0.md`
- `holder-bound-grant-posture-v0.md`
- `fresh-intent-posture-v0.md`
- `effect-key-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `renewal-window-posture-v0.md`
- `fence-token-posture-v0.md`
- `readiness-posture-v0.md`
- `activity-accounting-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `quiesce-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-SYSTEMD-DAEMON
- REF-SYSTEMD-EXEC
- REF-LAUNCHD-JOBS
- REF-DAEMONTOOLS-SUPERVISE
- REF-ERLANG-OTP-SUPERVISOR
- REF-S6-RC-WHY
- REF-SD-NOTIFY
- REF-K8S-PROBES
- REF-FUCHSIA-RUNNER
- REF-FUCHSIA-IDLE-STOP
- REF-FUCHSIA-LIFECYCLE
- REF-XPC-TRANSACTION-END
- REF-GNU-SHEPHERD-TRANSIENT-MAKER
- REF-WEZTERM-SHELL-INTEGRATION
- REF-OSC133-SPEC
- REF-VSCODE-SHELL-TRUST
- REF-PLAN9-PLUMBING
- REF-OPENBSD-UNVEIL
- REF-FREEBSD-CAPSICUM
- REF-DBUS-SPECIFICATION
- REF-DESKTOP-ENTRY-DBUS-ACTIVATION
- REF-XDG-ACTIVATION-V1
- REF-XDG-PORTAL-OPENURI
- REF-LINUX-PIDFD-OPEN
- REF-LINUX-WAITID-PIDFD
- REF-FREEBSD-CAP-ENTER
- REF-FREEBSD-CAP-RIGHTS-LIMIT
- REF-GRPC-DEADLINES
- REF-OAUTH-RFC6749
- REF-GRPC-CANCELLATION
- REF-GOOGLE-AIP-155
- REF-AWS-EC2-IDEMPOTENCY
- REF-AWS-ECS-IDEMPOTENCY
- REF-IETF-IDEMPOTENCY-KEY
- REF-HTTP-RFC9110
- REF-ETCD-API-TXN
- REF-AWS-S3-CONDITIONAL-WRITES
- REF-XDG-PORTAL-REQUEST
- REF-XDG-PORTAL-SESSION
- REF-WINDOWS-JOB-OBJECTS
- REF-SD-WATCHDOG-ENABLED
- REF-K8S-LEASES
- REF-ETCD-LEASES
- REF-RFC8693-TOKEN-EXCHANGE
- REF-RFC9449-DPOP
- REF-RFC8705-MTLS
- REF-RFC9700-OAUTH-SECURITY-BCP
- REF-HTML-USER-ACTIVATION
- REF-XDG-PORTAL-GLOBALSHORTCUTS
- REF-GOOGLE-CREDENTIAL-ACCESS-BOUNDARY
- REF-AWS-STS-ASSUMEROLE
- REF-MACAROONS
