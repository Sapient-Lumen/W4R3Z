# Adaptation-witness posture v0

Purpose: define a **tiny adaptation-witness seam** so deliberate protective responses such as `trim-cache`, `reduce-concurrency`, `defer-optional-work`, `narrow-service`, or similar response truth can stay visibly separate from **pressure**, **backpressure**, **serve-state**, and **failure**.

This seam stays intentionally small. It does **not** invent a portable autoscaler, brownout policy engine, concurrency-tuning DSL, cache-management API, or generic remediation grammar. It only says that when a substrate can honestly report that a component or manager deliberately changed operating posture in response to strain, Steward should preserve that truth instead of flattening it into vague `degraded`, `busy`, or `self-healed` folklore.

## Posture
1. **Adaptation is response truth, not cause truth**
   - Pressure, headroom, or policy may explain *why* a response happened.
   - The adaptation witness says *what protective response is now in effect*, not what exact hidden algorithm decided it.
2. **Adaptation is not the same as pressure or backpressure**
   - Pressure describes strain, and backpressure describes admission posture.
   - A system may trim caches, cap concurrency, or defer optional work before any visible shed or refusal occurs, so Steward should keep those truths separate.
3. **Protective response is healthier than mystery degradation**
   - `cache trimmed`, `optional work deferred`, or `concurrency capped` often explain present behavior much better than one vague `degraded` badge.
   - Steward should preserve those narrower truths when the adapter can prove them.
4. **Keep the portable vocabulary coarse and honest**
   - Some adapters may only know `adaptation active`; others may name a compact class such as `trim-cache`, `reduce-concurrency`, `defer-optional-work`, or `narrow-mode`.
   - Steward should keep whatever exactness is proven and refuse fake precision.
5. **Adaptation may intentionally trade luxury for survival**
   - Good systems may shrink caches, lower concurrency, shorten idle timeouts, stop memory-intensive work, or switch to a reduced serving mode before they start killing work.
   - Steward should keep that as explicit survival posture, not as an invisible side effect.
6. **Adaptation is not authority or approval**
   - A protective response may explain why fresh work is slower, narrower, or unavailable.
   - It must not silently widen authority, bypass gates, or become permission for unrelated mutation.
7. **Shell and terminal chrome should make adaptation legible**
   - Execution-ground cards, command frames, and receipts may show compact truth such as `cache trimmed`, `concurrency capped`, `optional work deferred`, `read-only under pressure`, or `adaptation active`.
   - These labels explain current operating posture; they do not become a portable autoscaling or brownout control plane.
8. **Cause links are useful but optional**
   - When an adapter can prove a nearby cause such as `memory warning`, `cpu saturation`, or `policy floor`, Steward should be able to show that link.
   - If not, `adaptation active` with exact scope is healthier than counterfeit causal certainty.
9. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional `adaptation_class`, exact scope label, and whichever of `cause_ref`, `since_ms`, `source_class`, or `reason` the adapter can really prove.
   - Richer knob-tuning, policy scripting, and response choreography remain intentionally undecided.

## Phase-1 non-goals
- a portable brownout or degraded-feature policy engine;
- a universal autoscaler, concurrency-controller, or cache-management API;
- writable adaptation knobs or a cross-runtime remediation grammar;
- pretending every reduced mode or protective response is globally comparable;
- laundering adaptation receipts into proof that pressure, approval, or settlement disappeared.

## Adjacent docs
- `pressure-witness-posture-v0.md`
- `backpressure-witness-posture-v0.md`
- `serve-state-witness-posture-v0.md`
- `headroom-witness-posture-v0.md`
- `execution-ground-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMD-MEMORY-PRESSURE
- REF-FUCHSIA-MEMORY-RECLAMATION
- REF-K8S-NODE-PRESSURE-EVICTION
- REF-ENVOY-OVERLOAD-MANAGER
- REF-ENVOY-ADAPTIVE-CONCURRENCY
