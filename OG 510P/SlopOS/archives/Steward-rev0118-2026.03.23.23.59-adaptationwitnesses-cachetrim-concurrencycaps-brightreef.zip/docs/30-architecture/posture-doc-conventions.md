# Posture document conventions

Each posture doc should:
1. say what seam it is pinning;
2. say what phase-1 meaning is in scope;
3. say what it explicitly refuses;
4. list adjacent docs and REF IDs.

The goal is to make each seam small enough to survive design churn.
