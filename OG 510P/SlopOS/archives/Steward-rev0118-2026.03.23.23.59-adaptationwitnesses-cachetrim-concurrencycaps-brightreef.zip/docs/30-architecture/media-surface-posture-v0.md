# Media-surface posture v0

Purpose: define a **tiny rendered-media seam** so inline images, plots, doc previews, background media, and similar terminal rendering stay exact-targeted, budgeted, and policy-bounded instead of collapsing into scrollback, transfer, or open-action folklore.

## Posture
1. **Rendered media is not text**
   - Inline graphics or document previews may share a viewport with text, but they are not equivalent to typed bytes, transcript truth, or command output slices.
   - Steward should treat media as an explicit surface with its own anchors, actions, and downgrade rules.
2. **Display, download, open, attach, and set-background are different actions**
   - Showing an image inline, downloading a file, opening it in a host app, attaching it as context, or using it as chrome/background all have different consequences.
   - Steward should preserve that distinction instead of letting "there is media here" silently imply one default action.
3. **Exact anchors should beat visible-pixel folklore**
   - A preview backed by an exact frame, receipt, selector, or reviewed object is stronger than a blob of pixels that happened to be visible in scrollback.
   - Steward should prefer exact-object-backed media surfaces and label plain screenshot/text fallbacks as downgrades.
4. **Capability and transport boundaries should stay visible**
   - Rich media often depends on terminal-specific protocols, helper tools, shell integration, or host-local rendering paths.
   - Steward should disclose which path made a preview possible and degrade honestly when multiplexers, remote hops, or older terminals weaken fidelity.
5. **Render budgets are policy, not implementation trivia**
   - Inline graphics, animated media, and background images consume GPU, memory, bandwidth, or redraw budget.
   - Steward should keep those costs inspectable and fenceable instead of treating them as invisible chrome overhead.
6. **Rendered media should remain observational until explicitly promoted**
   - An inline image, plot, or PDF preview may be extremely useful, but it is still a viewing surface until the user chooses a stronger action such as open, download, attach, or persist.
   - Steward should keep that boundary explicit so previews do not quietly become ambient file-transfer or reopen authority.
7. **Restore and replay should preserve truth labels, not fake fidelity**
   - A restored pane may remember that media once rendered there without still having the exact bytes, protocol support, or live backing object.
   - Steward should allow placeholders, thumbnails, or exact-anchor receipts while clearly labeling when the rich rendering itself is gone or downgraded.
8. **One media seam beats many ad hoc image exceptions**
   - Inline plot widgets, doc thumbnails, image previews, rendered receipts, and background media all want the same anti-folklore rules.
   - Steward should prefer one small media-surface posture over a pile of host-specific preview tricks.

## Phase-1 non-goals
- a universal graphics or document-preview protocol for every terminal and host platform;
- guaranteeing identical media fidelity across multiplexers, SSH hops, and restored sessions;
- embedding arbitrary active web content inside the terminal transcript;
- treating media preview support as proof that file transfer or local-open authority is also available;
- freezing one portable background-image or animation policy for all future implementations.

## Adjacent docs
- `transfer-surface-posture-v0.md`
- `clipboard-surface-posture-v0.md`
- `target-anchor-posture-v0.md`
- `workspace-snapshot-posture-v0.md`
- `precision-fence-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-KITTY-GRAPHICS-PROTOCOL
- REF-WEZTERM-IMGCAT
- REF-GHOSTTY-FEATURES
- REF-GHOSTTY-RELEASE-120
- REF-ITERM2-INLINE-IMAGES
- REF-ITERM2-ONE-PAGE
