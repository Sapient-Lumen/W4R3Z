# Hop lineage posture v0

Purpose: make shell/terminal remote and multiplexer boundaries explicit enough that Steward can scope command frames, histories, capabilities, and actions to the **actual semantic path** instead of pretending every pane is one flat local session.

## Posture
1. **Shell/terminal observations may carry compact hop lineage**
   - A pane, prompt, command frame, or action target may optionally carry a tiny description of the semantic path that produced it: for example local terminal -> multiplexer -> SSH-like hop -> remote shell.
   - The portable goal is scoped context, not exhaustive topology.
2. **Hop lineage is observational, not authority**
   - Hop/path information is useful for status strips, recent-directory memory, action targeting, and visible downgrade.
   - It must not silently grant permission or become an ambient trust token.
3. **Lineage should stay freshness-scoped**
   - Hop information is only as good as the current shell/terminal semantic world.
   - New hops, shell resets, or resync should be allowed to establish fresh lineage state or a fresh semantic epoch rather than mutating stale certainty in place.
4. **Capability and precision should be scoped to the actual path**
   - A feature that works locally may be missing after tmux, SSH, or a nested shell.
   - Steward should allow capability handshakes and precision fences to attach to the current hop path rather than to a fantasy machine-wide truth.
5. **Remote-aware UX should key off explicit path hints**
   - Same-host same-directory spawn, per-host history, recent directories, pane titles, and safe explicit actions are much healthier when they key off explicit hop/host hints instead of prompt scraping.
6. **Hop boundaries should be allowed to admit partial preservation**
   - A layer may preserve cwd and prompt markers but drop richer command, input, or action semantics.
   - Steward should let the path say what survived and what degraded instead of pretending the hop was transparent.
7. **Keep the portable representation tiny**
   - Phase 1 likely needs only compact hop descriptors or pane-local path hints such as current host, current cwd authority, multiplexer-preserved markers, and maybe a short lineage token.
   - Avoid freezing a universal transport graph before operating pressure exists.
8. **Lineage should help fence actions and histories**
   - A command frame, hyperlink, or palette action may carry expected hop/path hints so the UI can notice “that target belonged to another host/path” before acting.
   - Recent-command and recent-directory memory should also be allowed to key off the path instead of bleeding across unrelated local and remote contexts.
9. **Fallback to a plain terminal stream must remain valid**
   - Steward should get better when hop lineage is available.
   - It must not require lineage metadata for basic shell usability.

## Phase-1 non-goals
- authenticated network identity or host attestation through terminal metadata;
- replacing SSH, tmux, or remote transports with a giant Steward-specific protocol;
- a universal graph of every intermediary process and transport hop;
- making hop lineage the sole truth for security-sensitive decisions;
- forcing every shell, multiplexer, and terminal to implement rich path reporting before remote-aware UX becomes useful.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `precision-fence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `action-surface-posture-v0.md`
- `observation-subscription-posture-v0.md`

## References
- REF-WEZTERM-SHELL-INTEGRATION
- REF-WEZTERM-PANE-USER-VARS
- REF-KITTY-SHELL-INTEGRATION
- REF-KITTY-SSH
- REF-GHOSTTY-RELEASE-120
- REF-VSCODE-SHELL-INTEGRATION
- REF-TMUX-CONTROL-MODE
