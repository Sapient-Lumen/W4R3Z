# Fresh-intent posture v0

Purpose: define a **tiny fresh-intent witness seam** so some high-risk or foreground-sensitive shell/terminal actions can require **recent local human intent evidence** without turning Steward into a trusted-UI platform, consent cache, biometric identity system, or generic approval-token family.

## Posture
1. **Fresh intent is evidence, not ambient authority**
   - A fresh-intent witness says “a recent local interaction approved this exact action summary in this exact UI/session context”.
   - It does not replace a grant handle, effect key, holder proof, or target anchor, and it must not silently become a reusable bearer right.
2. **One gesture, one reviewed action summary**
   - A Phase-1 witness should bind to one exact action, target, or reviewed summary digest.
   - Steward should not widen one click, shortcut, or menu gesture into “this whole class of future actions is approved now”.
3. **Local and current-session scoped**
   - Fresh-intent witnesses are about current local interaction with the present shell/terminal surface or an equivalent trusted local UI path.
   - They should not claim cross-host, restore-after-reboot, or cross-session replay semantics.
4. **Freshness and consumption stay visible**
   - `fresh`, `consumed`, `expired`, `missing`, `wrong-context`, and `ignored` are not synonyms.
   - When the host can distinguish them, Steward should keep those outcomes visible instead of collapsing them into vague denial.
5. **Foreground/attention hints stay separate from intent evidence**
   - A fresh local interaction may produce or accompany an activation/attention token, but that token remains advisory and separately ignorable.
   - “The user recently interacted here” is not the same thing as “the compositor focused the target” or “the action succeeded”.
6. **Shortcuts and chooser detours may refresh intent, history must not**
   - Current shortcut activations, current menu picks, and current chooser responses may mint fresh intent evidence when policy allows.
   - Old transcript frames, copied chips, remembered shelves, and stale notifications must not recreate it.
7. **Automation and remote control stay separate by default**
   - Scripts, remote-control APIs, and helper CLIs should not be able to fake fresh local intent unless a separately reviewed local mediation path explicitly says so.
   - Steward should fail closed rather than pretend a remote caller has the same standing as a current local user gesture.
8. **Keep the public seam smaller than a trusted-UI family**
   - Under the membrane, hosts may realize this with platform-specific activation serials, transient user-activation state, or trusted local prompts.
   - Publicly, Steward should freeze only the tiny meaning that some actions may require fresh, local, optionally consuming intent evidence.
9. **Shell chrome should make freshness obvious**
   - High-risk chips and actions should be able to say `fresh intent required`, `fresh`, `consumed`, `expired`, `ignored`, or `wrong context`.
   - That honesty is healthier than silently reusing stale transcript history or cached approval folklore.

## Phase-1 non-goals
- a universal consent or trusted-UI framework;
- a portable biometric or passkey identity plane;
- a reusable approval cache or wildcard approval family;
- export/import semantics for intent evidence;
- treating remote automation as equivalent to current local human interaction.

## Adjacent docs
- `action-surface-posture-v0.md`
- `attention-hint-posture-v0.md`
- `request-activation-posture-v0.md`
- `grant-handle-posture-v0.md`
- `consumable-grant-posture-v0.md`
- `holder-bound-grant-posture-v0.md`
- `replay-gate-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-HTML-USER-ACTIVATION
- REF-XDG-ACTIVATION-V1
- REF-XDG-PORTAL-GLOBALSHORTCUTS
- REF-XDG-PORTAL-OPENURI
