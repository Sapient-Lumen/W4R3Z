# Semantic epoch posture v0

Purpose: define a tiny, explicitly observational way to say that shell/terminal semantic state now belongs to a **new freshness epoch** after a hop, restart, resync, or capability change, so stale actions and stale certainty can be fenced cleanly.

## Posture
1. **Semantic observations should be epoch-scoped**
   - Command frames, cwd confidence, capability snapshots, action descriptors, and similar shell/terminal semantics should be allowed to say which semantic epoch they belong to.
   - The point is not chronology; the point is stale-vs-current distinction.
2. **Epoch change should be explicit when precision may have shifted**
   - A shell restart, SSH-like hop, multiplexer boundary, capability-resync, or forced semantic refresh should be allowed to mint a new semantic epoch.
   - That makes “the world may have changed here” visible instead of leaving the terminal to preserve stale trust.
3. **Epochs are freshness fences, not component identity**
   - A semantic epoch does not identify a component, a runtime cycle, or a transport session.
   - It only helps answer whether a shell/terminal observation still belongs to the same semantic world the UI thinks it is acting on.
4. **Actions and subscriptions may carry expected epochs**
   - A future explain/retry/open action or observation subscription may optionally carry an expected semantic epoch.
   - If the shell/terminal path has since moved to a different epoch, Steward-aware clients should be allowed to downgrade or refuse exact actions instead of silently acting on stale targets.
5. **Epoch bumps should not erase raw terminal history**
   - The terminal should still preserve pane bytes and old command frames.
   - The new epoch simply makes it honest that older markers, cwd, capability, or trust assumptions may no longer be current.
6. **Resync should mint fresh state instead of mutating stale certainty in place**
   - When a shell emits fresh prompt markers, cwd, or capability information after confusion, the preferred move is to establish a fresh epoch.
   - That is often simpler and safer than pretending partial old state is still exact.
7. **Capability and trust are only current within an epoch**
   - Capability handshakes, nonce-bound command data, and exact target descriptors are strongest when they are fresh.
   - Steward should be willing to say “high confidence, but only for the current semantic epoch.”
8. **Keep the portable contract tiny**
   - Phase 1 likely needs only an opaque epoch token plus optional equality / stale-fence use.
   - Avoid freezing lineage graphs, wall-clock meaning, or mandatory history queries before real pressure exists.
9. **Epochs complement precision fences instead of replacing them**
   - Precision fences explain *how* certainty changed.
   - Semantic epochs answer *whether* an observation/action still belongs to the same current semantic world.

## Phase-1 non-goals
- a global session identifier for every shell or remote hop;
- guaranteed transport continuity or roaming semantics;
- replacing runtime-cycle witnesses, component identity, or receipts;
- forcing every terminal and shell to implement rich epoch history before semantic UX works;
- turning epoch tokens into a hidden control plane.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `precision-fence-posture-v0.md`
- `action-surface-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-SHELL-TRUST
- REF-ITERM2-FEATURE-REPORTING
- REF-TMUX-CONTROL-MODE
- REF-GHOSTTY-CONFIG-REFERENCE
