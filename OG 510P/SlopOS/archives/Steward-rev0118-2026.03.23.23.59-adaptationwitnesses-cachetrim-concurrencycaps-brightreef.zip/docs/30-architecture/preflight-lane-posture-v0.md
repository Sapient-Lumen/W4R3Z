# Preflight-lane posture v0

Purpose: define a **tiny preflight lane seam** so explain, diff, speculative preview, reviewed saved plan, and apply stay visibly different moves instead of collapsing into one flattering “go do it” path.

## Posture
1. **Preflight is not apply**
   - A useful system should be able to explain what it *would* target, *would* change, or *would* require before anything mutates.
   - Steward should keep that preview lane visibly weaker than execution instead of treating every explanation as a hidden dry-run apply.
2. **Speculative preview and reviewed saved plan are different objects**
   - An ephemeral preview, a diff card, and a reviewed plan artifact each answer a different question.
   - Steward should not flatten “I saw a preview once” into “this exact later apply is already approved.”
3. **Preflight may still require real footing and real permissions**
   - Some preview paths must talk to the real manager, cluster, or runtime to compute an honest answer.
   - Steward should therefore allow `preview denied`, `needs wider read`, or `policy floor hit` outcomes instead of pretending preview is always free of authority or side conditions.
4. **Preflight must bind to exact target and execution ground**
   - A preview should say which exact target selector, current footing, cwd/domain/hop context, component generation, or reviewed request basis it used.
   - If any of that footing drifts, Steward should be willing to mark the preview stale rather than silently reusing it.
5. **Explain, diff, and apply should stay distinct from proposal lanes**
   - Proposal/help lanes may suggest a command or workflow, but a preflight lane should answer the narrower question “what would this exact reviewed action do now?”
   - Steward should keep proposal, preflight, and apply as adjacent but visibly different lanes.
6. **Saved reviewed plans should stay narrow and inspectable**
   - A saved plan artifact can be a powerful bridge from human review to later automation.
   - Steward should keep any such artifact exact-targeted, inspectable, and willing to fail if footing or policy no longer match, rather than turning it into a generic approval cache or replay token.
7. **No-change, differences-found, and preview-failed should stay separate outcomes**
   - A healthy preflight lane should be able to say `no changes`, `differences found`, `preview stale`, `preview denied`, or `preview failed` without flattening them into one vague spinner or boolean.
   - That keeps shell chrome, automation, and later review cards honest.
8. **One compact preflight seam beats many ad hoc dry-run loopholes**
   - Lifecycle control cards, spawn selectors, replay gates, helper CLIs, and terminal agents all want the same anti-folklore discipline.
   - Steward should prefer one small preflight lane over scattered `--dry-run` habits with inconsistent review and stale-footing stories.

## Phase-1 non-goals
- a universal diff or plan-file schema for every runtime and control path;
- a promise that every preview can be applied later without drift or revalidation;
- a giant workflow/planner engine inside Steward itself;
- treating preview artifacts as durable approvals, delegation tokens, or policy bypasses;
- forcing every action surface to grow a full speculative planner before the small seam earns it.

## Adjacent docs
- `proposal-lane-posture-v0.md`
- `approval-rung-posture-v0.md`
- `replay-gate-posture-v0.md`
- `action-surface-posture-v0.md`
- `session-injection-posture-v0.md`
- `request-context-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `execution-ground-posture-v0.md`
- `precision-fence-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-TERRAFORM-PLAN
- REF-TERRAFORM-APPLY
- REF-KUBECTL-DIFF
- REF-K8S-DECLARATIVE-CONFIG
- REF-VSCODE-AGENT-PLANNING
- REF-CLAUDE-CODE-PERMISSIONS
