# Observation-cursor posture v0

Purpose: define a **tiny observation-cursor seam** so snapshot-plus-change views can resume from an exact point, admit continuity loss honestly, and stay smaller than a giant event-bus protocol.

## Posture
1. **Snapshot-plus-change views may carry one exact cursor**
   - A bounded observation snapshot or watch stream should be allowed to expose one opaque cursor that means “caught up through here” for that exact view.
   - The cursor is for resuming, stale-fencing, and explainable continuity; it is not itself a mutation right.
2. **Cursor continuity belongs to one view, not the whole world**
   - A cursor should normally be scoped to one concrete object set or view such as one component status view, one receipt stream, or one exact shell/terminal observation lane.
   - Steward should avoid implying that one cursor globally orders every fact in the system.
3. **Resume should be explicit, and failure to resume should be explicit too**
   - A client should be allowed to say “resume from this cursor” on a later subscription or refresh.
   - If Steward cannot honor that cursor because history expired, continuity was compacted away, or the client fell too far behind, it should say so explicitly rather than pretending the stream was continuous.
4. **Progress markers are useful even when no payload changed**
   - A watch or subscription may benefit from a lightweight marker that says “you are now synced through cursor X” even if nothing interesting changed for that client.
   - That is healthier than teaching clients to infer liveness or completeness from silence.
5. **Overflow, compaction, and restart are different loss stories**
   - `overflow`, `history-compacted`, `cursor-expired`, `publisher-restarted`, and `view-reconfigured` are not the same explanation.
   - Steward should keep continuity-loss reasons compact but distinguishable where the host can observe them.
6. **Shell and chrome can use cursors without becoming a control bus**
   - Badges, command-watch chips, sticky headers, or shell-side status shelves should be allowed to say “current through cursor X” or “stale since cursor Y was lost”.
   - That is still observational; it does not grant action authority by itself.
7. **Cursors and epochs answer different questions**
   - A semantic epoch answers whether shell/terminal semantics still belong to the same freshness world.
   - An observation cursor answers whether a snapshot-plus-change view remained continuous within that world.
8. **Simple reconnecting transports should be able to echo the last cursor**
   - A text stream, reconnecting shell watch, or lightweight UI channel should be allowed to present one last-known cursor when re-establishing the same exact view.
   - That keeps resume friendly to SSH-like or EventSource-like transports without freezing cursor syntax into public protocol folklore.
9. **Portable meaning should stay tiny**
   - Phase 1 likely needs only an opaque cursor plus resume / continuity-lost / synced-through use.
   - Steward should not freeze a globally sortable sequence, retention guarantee, or distributed watch algebra too early.

## Phase-1 non-goals
- a universal event-log retention promise;
- a globally ordered sequence number across all objects and hosts;
- lossless replay forever for every subscriber;
- turning cursor tokens into hidden mutation capability;
- forcing all adapters to retain identical watch history.

## Adjacent docs
- `observation-subscription-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `status-channel-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-API-CONCEPTS
- REF-ETCD-DATA-MODEL
- REF-ETCD-MAINTENANCE
- REF-WHATWG-SSE
- REF-TMUX-CONTROL-MODE
