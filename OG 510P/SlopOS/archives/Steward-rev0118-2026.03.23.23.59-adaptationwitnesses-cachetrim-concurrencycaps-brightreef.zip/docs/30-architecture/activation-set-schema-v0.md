# CH-ACTSET v0 (activation set manifest, informal)

Purpose: describe what Steward delivered to a component when it started.

## Shape (v0)
An activation set contains:
- `schema = "CH-ACTSET v0"`
- `cid`
- `instance_nonce`
- `stable`: bounded list of supervisor-owned delivered activation handles
- `escrowed`: bounded list of restored continuity items

Each entry contains:
- `key`: bounded label
- `kind`: closed-world enum
- `rights`: bounded summary
- `origin`: one of `{ stable_export, escrow }`

## Constraints
- CH-ACTSET carries **descriptions**, not bearer handles;
- no inventory/list/watch semantics are implied;
- unknown keys and variants reject;
- duplicate `(origin,key)` pairs reject.

## Logging guidance
The digest of CH-ACTSET is the portable logging/export surface, not raw capability material.
