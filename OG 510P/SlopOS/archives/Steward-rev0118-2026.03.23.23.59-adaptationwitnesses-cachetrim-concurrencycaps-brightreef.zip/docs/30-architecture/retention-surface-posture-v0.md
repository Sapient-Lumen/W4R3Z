# Retention-surface posture v0

Purpose: define a **tiny remembered-data retention seam** so persisted command history, directory history, paste history, host/user breadcrumbs, and similar shell/terminal memory stay useful without becoming ambient authority, surprise sync, or quiet privacy debt.

## Posture
1. **Retention class should be explicit**
   - Command history, directory history, paste history, host/user breadcrumbs, receipt refs, and remembered object selectors are not one undifferentiated blob.
   - Steward should be able to name which class is being retained so policy and explanation stay precise.
2. **Session-local and persisted memory are different facts**
   - An in-memory recent shelf and an on-disk retained shelf may feel similar in the UI, but they have different privacy, lifetime, and portability consequences.
   - Steward should label whether remembered data is session-local, persisted locally, imported, or synced from elsewhere.
3. **Search may unify remembered classes without redefining them**
   - A single picker or search surface can span commands, directories, prompts, receipts, and other remembered objects.
   - That unified search should still return entries with exact class, provenance, and freshness labels instead of pretending every hit is the same kind of truth.
4. **Retention scope should be partitionable and reviewable**
   - Host, hop lineage, user, workspace, profile, and similar explicit context hints are healthy scope boundaries for retained memory.
   - That is better than one flat persistent memory where unrelated sessions leak into one another by accident.
5. **Retention should be erasable and fenceable**
   - Users should be able to clear one class, one scope, or all retained shell/terminal memory without inventing a forensic cleanup ritual.
   - Sensitive classes should be omittable, redacted, or downgraded to session-local memory when policy requires it.
6. **Persistence and sync are different policy surfaces**
   - Keeping remembered data across local restarts is not the same decision as syncing it across machines or sharing it with collaborators.
   - Steward should treat sync/share as a stronger explicit choice, not an automatic extension of local persistence.
7. **Retained entries stay remembered, not authoritative**
   - A persisted command, directory, hostname, or object ref may remain convenient long after the originating shell, hop path, or run is gone.
   - Stronger actions should still resolve through replay gates, spawn selectors, anchors, or other fresh exactness instead of trusting retention alone.
8. **One retention seam beats many ad hoc “save history” toggles**
   - Recent-command persistence, paste-history persistence, remote-host breadcrumbs, and unified remembered-object search all want the same anti-folklore discipline.
   - Steward should prefer one small retention-surface posture over many unrelated retention knobs with hidden semantics.

## Phase-1 non-goals
- a universal cross-device command-history service;
- syncing retained shell memory by default;
- pretending persisted history is proof that the referenced host, cwd, or authority is still live;
- freezing one mandatory retention duration or ranking algorithm;
- turning retained search/index state into an ambient control plane.

## Adjacent docs
- `remembered-shelf-posture-v0.md`
- `session-injection-posture-v0.md`
- `workspace-snapshot-posture-v0.md`
- `replay-gate-posture-v0.md`
- `clipboard-surface-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `context-handoff-posture-v0.md`
- `surface-diagnostics-posture-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-ITERM2-SHELL-INTEGRATION
- REF-ITERM2-PREFERENCES-GENERAL
- REF-WARP-COMMAND-SEARCH
