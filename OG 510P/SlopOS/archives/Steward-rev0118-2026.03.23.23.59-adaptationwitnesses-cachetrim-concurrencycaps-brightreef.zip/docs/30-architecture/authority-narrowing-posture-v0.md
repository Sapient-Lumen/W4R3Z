# Authority-narrowing posture v0

Purpose: define a **tiny explicit authority-narrowing seam** so launch-time or early-runtime reduction of ambient filesystem/process/network visibility stays reviewable, lockable, and diagnosable instead of hiding inside wrapper folklore, cwd/search-path assumptions, or host-specific sandbox magic.

This seam is intentionally narrow. It does **not** design a giant portable sandbox DSL, a universal policy compiler, or a generic capability broker.

## Posture
1. **Narrowing is explicit, not ambient**
   - If a component or helper runs with reduced authority, that reduction should come from reviewed allowlists, delivered capabilities, or an explicit launcher/runner policy choice.
   - "It happened to start in a restricted namespace" is not a good portable explanation.
2. **Keep the portable story smaller than the host mechanisms**
   - Different hosts may use path allowlists, capability mode, namespace tricks, or other confinement tools beneath the membrane.
   - Steward should freeze only the portable meaning it can explain well: authority was narrowed in specific ways, or it was not.
3. **Configuring and locked are different truths**
   - A narrowing story may have an early configuring phase while reviewed allowlists or handles are being established.
   - Once the narrowed baseline is locked, later widening should require an explicit new lifecycle decision such as restart, relaunch, or a separately reviewed authority handoff.
4. **Narrowing should be monotonic within one runtime cycle**
   - Phase 1 should prefer authority stories that only tighten or stay the same once the component has entered its narrowed baseline.
   - Host tricks that support irreversible mode entry, one-way rights reduction, or promises that can only shrink are especially good fits under the membrane.
5. **Additional narrowing layers may stack if they only reduce authority**
   - A helper, plugin, or late phase may apply an extra narrowing layer on top of the reviewed baseline when the net effect is strictly less authority, not more.
   - Steward should treat stackable host mechanisms as implementation freedom under the membrane rather than as a promise of a portable layer algebra.
6. **Narrowing must fail honest**
   - If a compat layer cannot guarantee the reviewed narrowing baseline, Steward should prefer explicit downgrade or fail-closed behavior over silent best-effort claims.
   - Users should be able to tell whether the current baseline is exact, degraded, provisional, or unavailable.
7. **Convenience context is not authority**
   - cwd, prompt labels, remote host hints, remembered history, and startup profiles can improve ergonomics.
   - They must not masquerade as proof that filesystem/process/network authority was actually narrowed or locked.
8. **Restart replays declared narrowing only**
   - Restart should replay the reviewed launch baseline and any explicit narrowing posture; it must not depend on ambient shell/session baggage or old process accidents.
9. **Reviewable diagnostics are part of the seam**
   - A component, helper shell, or reviewed action should be allowed to surface compact diagnostics such as `narrowed`, `configuring`, `locked`, `degraded`, or `unsupported`.
   - That chrome remains observational, but hiding the state entirely would invite folklore.
10. **No generic authority minting through the narrowing seam**
   - This seam is about reducing or fencing authority, not about quietly acquiring new paths, exporting hidden handles, or running a capability wallet.

## Phase-1 non-goals
- a universal cross-host sandbox grammar;
- guaranteeing that every runtime can expose the same fine-grained narrowing proof;
- a generic late-widening API for ambient authority recovery;
- treating cwd/search-path/session state as proof of confinement;
- inventing a broad policy-family machine before narrower lifecycle seams demand it.

## Adjacent docs
- `design-principles-v0.md`
- `non-decisions-v0.md`
- `launch-context-posture-v0.md`
- `descriptor-hygiene-posture-v0.md`
- `supervision-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `surface-diagnostics-posture-v0.md`

## References
- REF-OPENBSD-UNVEIL
- REF-FREEBSD-CAPSICUM
- REF-FREEBSD-CAP-ENTER
- REF-FREEBSD-CAP-RIGHTS-LIMIT
- REF-LANDLOCK-USERSPACE
- REF-OPENBSD-PLEDGE
- REF-SYSTEMD-EXEC
- REF-LAUNCHD-JOBS
