# CH-COMP v0 (component manifest, informal)

Purpose: pin the minimum reviewable unit for Steward-managed lifecycle without inventing a giant unit language.

## Shape (v0)
A manifest contains:
- `schema = "CH-COMP v0"`
- `cid`: bounded component id
- `image_digest`: exact code/artifact identity
- `entry`: bounded entrypoint selector (reviewed selector, not shell command text)
- `critical`: bool
- `restart`: optional object:
  - `policy`: `{ never, on_failure, always }`
  - `window_ms`
  - `max_restarts`
  - `backoff_ms`
- `readiness`: optional object:
  - `required`: bool
  - `startup_timeout_ms`
  - `ready_timeout_ms`
- `activation`: optional object:
  - `stable_exports`: bounded list of allowlisted activation keys
  - `escrow`: optional object:
    - `enabled`: bool
    - `key_allowlist`: bounded list
    - `max_items`: bounded count
- `imports`: bounded list of declared lifecycle-relevant dependencies or capability kinds
- `notes_tag`: optional bounded operator-only tag

## Constraints
- deterministic decode and canonical bytes;
- closed set of keys and enum variants;
- bounded identifiers and list sizes;
- no ambient discovery fields;
- no embedded scripts, process-tree selectors, or host-manager-specific control fields;
- no ambient shell-command-string or `PATH`-search meaning hidden behind `entry`.

## Notes
This deliberately avoids:
- a full unit/dependency DSL,
- shell command strings,
- generic timer semantics,
- raw PID targeting,
- arbitrary descriptor inheritance.
