# Spawn-selector posture v0

Purpose: define a **tiny reviewed spawn-recipe seam** so tabs, splits, reruns, helper shells, and similar actions can choose *what to launch* explicitly instead of inheriting `$SHELL`, profile defaults, or pane folklore by accident.

## Posture
1. **A spawn selector is an explicit recipe, not ambient guesswork**
   - Opening a tab, split, rerun, or helper shell should be allowed to name a reviewed launch recipe instead of silently accepting whatever shell/program/profile the terminal currently happens to favor.
   - Steward should resist “new shell” meaning “whatever the host, pane, or environment accidentally resolves right now.”
2. **Selector dimensions should stay separately nameable**
   - Useful selector dimensions include program/argv image, profile or appearance preset, local/remote execution domain, cwd source, and whether the launch should be clean or inherit some reviewed context.
   - Do not collapse all of that into one vague “same shell” or “duplicate tab” knob.
3. **Cwd source classes should be explicit when they matter**
   - Helpful source classes include default cwd, exact current-frame cwd, last shell-reported cwd, root/origin cwd, and explicitly provided cwd.
   - Steward should be free to label those classes instead of pretending every “same directory” request means the same thing.
4. **Domain selection and cwd selection are adjacent but different**
   - “Run on the same remote/local execution path” and “start in the same directory” often travel together, but they are not the same choice.
   - Spawn selectors should be able to keep those decisions separate.
5. **Environment carryover should stay explicit and freshness-scoped**
   - A selector may ask for a clean launch, a reviewed env subset, or a known snapshot.
   - Steward should not pretend that copying a remembered environment is the same thing as knowing the live foreground process environment now.
6. **Untrusted or policy-bounded contexts may trim the selector**
   - Workspace trust, remote-domain policy, or reviewed launch rules may deny some selector choices, drop inheritance, or force a safer fallback recipe.
   - Denial or downgrade should stay visible instead of being silently “helpful.”
7. **Selectors should resolve through exact anchors when launched from shell UX**
   - “Open a helper shell here” should prefer the clicked frame/line anchor and its attached cwd/hop lineage over pane-wide remembered state.
   - The launch recipe should be able to say what exact source it used.
8. **Selectors deserve receipts and explainability**
   - After a launch, Steward should be able to answer which recipe ran: selected program/profile, cwd source class, domain choice, trust downgrades, and any fallbacks.
   - That matters for rerun, debugging, and policy review.
9. **One spawn-selector seam beats many ad hoc launch toggles**
   - Tabs, splits, reruns, palette entries, and exact-frame helper actions all want the same discipline.
   - Steward should prefer one small spawn-selector posture rather than a pile of launcher-specific folklore.

## Phase-1 non-goals
- a giant portable terminal-profile schema;
- automatic cloning of arbitrary shell state, login-session baggage, or live process environment;
- guaranteeing that every terminal host exposes identical profile/domain concepts;
- treating remembered cwd or environment as proof that the live target still exists unchanged;
- freezing one global default recipe that every launch action must obey.

## Adjacent docs
- `context-inheritance-posture-v0.md`
- `launch-context-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `target-anchor-posture-v0.md`
- `precision-fence-posture-v0.md`
- `transient-promotion-posture-v0.md`

## References
- REF-WEZTERM-SPAWNCOMMAND
- REF-WEZTERM-LAUNCHING-PROGRAMS
- REF-KITTY-LAUNCH
- REF-WINDOWS-TERMINAL-SAME-DIRECTORY
- REF-GHOSTTY-RELEASE-130
- REF-ITERM2-ONE-PAGE
- REF-VSCODE-UPDATE-1109
