# Transition-helper posture v0

Purpose: keep short-lived lifecycle helpers explicit, attributable, and policy-bounded without confusing them with the supervised long-lived service leaf.

## Posture
1. **Long-lived leaf and short-lived helper stay distinct**
   - A supervised component may have short-lived helper phases such as prepare, activate-side setup, drain-prep, or cleanup.
   - Those helpers must not be mistaken for the long-lived runtime root that Steward actually supervises over time.
2. **Helper runs are still lifecycle fabric work, not floating admin children**
   - If Steward relies on a helper to complete a lifecycle transition, that helper should remain attributable to the component, transition kind, and concrete runtime cycle where relevant.
   - Phase 1 should avoid “someone ran a script somewhere” folklore.
3. **Helper success is not serve-readiness by itself**
   - A successful start helper may mean the transition phase completed, not that the long-lived leaf is ready to accept declared work.
   - Readiness and helper completion must stay separately nameable.
4. **Helper execution is bounded and restart-safe**
   - Transition helpers should have bounded execution and visible timeout/failure outcomes.
   - A restart may replay reviewed helper phases when required, but helpers must not become an unbounded hidden retry channel.
5. **Ordered transition choreography may exist without a giant phase language**
   - Steward can admit that some transitions involve ordered short-lived steps before or after the long-lived leaf changes state.
   - Phase 1 still refuses to freeze an everything-about-hooks orchestration grammar.
   - Helper names such as `prepare`, `prestart`, `cleanup`, or `poststop` should initially read as reviewed adapter patterns or recipe labels, not as the settled portable ontology of Steward.
6. **Transition evidence should stay explainable**
   - If a helper blocks, fails, times out, or requests repair, Steward should be able to surface that fact in compact lifecycle/status truth and receipts.
   - Users should not need log archaeology just to answer “what transition step failed?”
7. **Helpers do not widen ambient authority**
   - Helper phases may consume explicit reviewed launch context and activation material, but they must not smuggle in ambient shell/session/process inheritance as the real contract.
8. **Cleanup helpers remain visibly cleanup**
   - Finalizers, drain-completion helpers, and teardown hooks may exist, but they stay separate from the accountable long-lived leaf and must not become a loophole for daemonized escape or hidden successor handoff.

## Phase-1 non-goals
- a giant portable pre-start/post-start/pre-stop/post-stop hook taxonomy;
- arbitrary user shell scripts as the portable lifecycle contract;
- treating helper completion as interchangeable with component readiness or successful service of work;
- backgrounding transition work into orphaned admin children;
- importing a full host service-manager phase grammar before narrower seams are proven;
- treating sidecar/helper names as permanent public Steward roles before repeated cross-runtime pressure proves they deserve that status.

## Adjacent docs
- `design-principles-v0.md`
- `non-decisions-v0.md`
- `supervision-posture-v0.md`
- `launch-context-posture-v0.md`
- `activation-posture-v0.md`
- `readiness-posture-v0.md`
- `status-channel-posture-v0.md`
- `termination-cause-posture-v0.md`
- `repair-gate-posture-v0.md`

## References
- REF-S6-RC-OVERVIEW
- REF-ERLANG-OTP-SUPERVISOR
- REF-GNU-SHEPHERD-TRANSIENT-MAKER
- REF-DINIT-SERVICE
