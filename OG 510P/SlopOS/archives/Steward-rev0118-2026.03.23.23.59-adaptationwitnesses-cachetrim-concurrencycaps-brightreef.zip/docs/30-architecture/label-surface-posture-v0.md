# Label-surface posture v0

Purpose: define a **tiny chrome-label seam** so window titles, tab titles, badges, status text, subtitles, and similar glanceable labels stay provenance-labeled, override-scoped, and clearly separate from transcript, target, or policy truth.

## Posture
1. **Titles, badges, subtitles, and status text are different label channels**
   - A window title, tab title, badge, subtitle, and right-status cell can all help navigation.
   - Steward should keep those channels distinct instead of flattening them into one generic “the terminal label” authority level.
2. **User-pinned, manager-owned, shell-reported, and process-declared labels are different evidence classes**
   - A user rename, a reviewed workspace label, a shell-integration report, and an OSC title escape sequence are not equally trustworthy or equally durable.
   - Steward should preserve who set a label and by what path instead of treating all visible chrome text as the same kind of truth.
3. **Chrome labels are presentation, not object identity**
   - A nice tab title can summarize the current host, cwd, task, or component.
   - It should not silently become the canonical selector for replay, open, attach, or policy decisions when stronger anchors or receipts exist.
4. **Override and fallback rules should stay visible**
   - Users often want to pin a title, let a shell update it, or fall back to a template or profile default.
   - Steward should make those precedence choices inspectable instead of leaving “why did this title change?” to folklore.
5. **Label queries are a security boundary**
   - Some terminals let programs set labels; some also let them query labels back.
   - Steward should treat label reporting as opt-in, diagnosable, and separately policy-bounded rather than assuming that visible chrome text is harmless to reflect back into the session.
6. **Exact fields should beat prompt scraping**
   - Host, cwd, activity, progress, or current command can make excellent labels when the supporting data is explicit.
   - Steward should prefer exact fields, receipts, or shell-reported side channels over scraping prompt text and hoping the inferred title still means the same thing.
7. **Labels should export and restore honestly**
   - Saved layouts or transcript exports may remember that a label existed without proving it is still current.
   - Steward should restore remembered labels with freshness/provenance markers and avoid silently mixing chrome text into canonical transcript exports.
8. **One label seam beats ad hoc title tricks**
   - Window titles, tab chrome, badges, status bars, remote-host chips, and progress labels all want the same anti-folklore rules.
   - Steward should prefer one small label-surface posture over scattered host-specific title magic.

## Phase-1 non-goals
- a universal portable title/badge protocol for every terminal, shell, and window manager;
- treating a visible title or badge as a stable object handle for replay, open, or policy;
- freezing one global precedence order for every future label source beyond basic inspectability;
- synchronizing every label surface across every host, multiplexer, and restored session with perfect fidelity;
- using chrome labels as a covert command or approval path.

## Adjacent docs
- `chrome-lane-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `workspace-snapshot-posture-v0.md`
- `notification-surface-posture-v0.md`
- `target-anchor-posture-v0.md`
- `precision-fence-posture-v0.md`

## References
- REF-XTERM-CTLSEQS
- REF-WINDOWS-TERMINAL-TAB-TITLE
- REF-WINDOWS-TERMINAL-TIPS
- REF-WEZTERM-FORMAT-TAB-TITLE
- REF-WEZTERM-RIGHT-STATUS
- REF-ITERM2-BADGES
- REF-ITERM2-ESCAPE-CODES
- REF-GHOSTTY-CONFIG-REFERENCE
- REF-KITTY-CONF
- REF-KITTY-REMOTE-CONTROL
