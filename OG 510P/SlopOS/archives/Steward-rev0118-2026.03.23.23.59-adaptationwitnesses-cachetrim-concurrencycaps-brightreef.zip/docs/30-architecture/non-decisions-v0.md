# Non-decisions posture v0

Purpose: make Steward's **intentional non-decisions** explicit while SlopOS itself is still in design.

This file is not a lack of rigor. It is a guardrail against freezing giant semantics before Steward has earned them.

## Posture
1. **No portable global unit language in v0**
   - Steward does not yet freeze a full dependency/unit/timer/orchestration grammar.
   - Local start-order constraints may exist, but a host-global declarative empire is intentionally deferred.
2. **No portable process inventory or adopt-arbitrary-process API**
   - Steward supervises declared component roots, not “anything with a PID.”
3. **No final runner taxonomy yet**
   - The seam between supervision and runtime-specific launch should stay visible, but Steward does not yet freeze the complete universe of runner kinds or plugin contracts.
4. **No final restart-budget grammar yet**
   - Bounded restart intent matters, but the exact public tuning vocabulary should stay small until real operating experience accumulates.
5. **No generic timer language yet**
   - SlopOS already has adjacent jobs/background design pressure; Steward should not preemptively absorb it.
6. **No broad remote admin/control bus yet**
   - Status/receipt and explicit local control matter sooner than a big ambient management plane.
7. **No commitment yet on service-package shape**
   - A service-as-directory or bundle discipline might be useful, but packaging should not become accidental lifecycle meaning too early.
8. **No universal shell/terminal protocol contract yet**
   - OSC 7, OSC 8, OSC 133, pane-scoped user variables, and receipts are promising building blocks, but Steward should keep the baseline negotiable and observational first.
9. **No assumption that one idle model fits all runtimes**
   - Some components will have strong idle/transaction boundaries; others will not. Steward should not pretend otherwise by freezing fake precision.
10. **No final transient-command-to-service seam yet**
    - Long-running shell-launched work may eventually have a first-class transient-service story, but Steward should not freeze that public contract before jobs/background and shell ergonomics settle.
11. **No final portable activity-accounting grammar yet**
    - Steward should make room for busy/idle and in-flight-work hints without freezing one fake universal request-count or keepalive model.
12. **No final health-check contract yet**
    - Local adapters may use health checks, but Steward should not let them become the only portable truth about liveness or readiness.
13. **No final terminal input protocol choice yet**
    - Enhanced keyboard, paste, click, and mouse reporting are promising, but Steward should not overcommit to one protocol family too early.
14. **No final universal heartbeat / freshness-budget contract yet**
    - Some runtimes can renew live progress or watchdog state; others cannot. Steward should not freeze one fake portable pulse model too early.
15. **No promise that the terminal is a control authority**
    - The shell+terminal can become unusually good at navigation, explanation, and explicit actions without becoming an ambient lifecycle control plane.
16. **No final portable sandbox / capability-narrowing grammar yet**
    - Implementations may use capability-style confinement, path allowlists, or other narrowing tools, but Steward should not freeze one universal sandbox DSL while SlopOS itself is still deciding adjacent capability families.
17. **No universal activation bus or portable foreground-control plane yet**
    - Request-carried activation is promising, but Steward should not pretend that every host needs one big message bus or a portable focus/raise API.
18. **No final stable-availability / warmup grammar yet**
    - A tiny stability-window seam is promising for distinguishing `ready now` from `stable enough to admit`, but Steward should not yet freeze one global rollout, canary, or health-deadline family while SlopOS itself is still moving.
19. **No final portable progress-window / extend-timeout grammar yet**
    - A tiny progress-window seam is promising for distinguishing “still making progress” from “stalled”, and some adapters can honestly extend a start/reload horizon.
    - Steward should not yet freeze a universal startup-timeout DSL, progress-pulse protocol, or giant stall-diagnosis grammar before repeated lifecycle pressure exists.
20. **No portable exact-run host-handle grammar yet**
    - Implementations may use pidfds, job/process handles, or similar exact-run observation primitives behind the membrane, but Steward should not freeze those host objects as portable public semantics.
21. **No portable sealed-startup-capsule contract yet**
    - Implementations may use immutable local objects such as sealed anonymous files to carry startup material, but Steward should not freeze one host-shaped startup capsule as public meaning.
22. **No giant pending-request or portal-handle family yet**
    - Choosers and mediated UI detours may benefit from explicit pending handles, but Steward should keep that seam tiny instead of cloning an entire desktop request object universe.
23. **No giant portable request-context metadata grammar yet**
    - Exact request ids, optional deadlines, and explicit cancellation are promising, but Steward should not freeze a broad tracing / metadata / policy plane before real pressure exists.
24. **No giant portable grant/session algebra yet**
    - Exact closeable handles for transient powers are promising, but Steward should not clone a full portal object model, lease protocol, or delegation graph while SlopOS itself is still deciding adjacent families.
25. **No final portable renewal / watchdog / leader-election family yet**
    - Compact renew-or-expire windows are useful, but Steward should not freeze one universal heartbeat cadence, distributed lease fabric, or leader-election protocol before that pressure is real.
26. **No final portable spend-quota / token-wallet family yet**
    - A few one-shot or use-bounded grants are promising, but Steward should not freeze a portable token wallet, quota algebra, or broad spend-policy plane before real pressure exists.
27. **No giant portable exactly-once / transaction ledger family yet**
    - Effect keys and duplicate suppression are promising for some reviewed mutations, but Steward should not freeze a universal transaction protocol, durable request ledger, or broad exactly-once claim before real pressure exists.
28. **No giant portable compare-and-swap / query language yet**
    - Exact veto-only precondition witnesses are promising for stale-fenced actions, but Steward should not freeze a universal conditional-mutation DSL, ambient latest-lookup service, or distributed lock family before real pressure exists.
29. **No giant portable fencing / leadership / sequencer family yet**
    - Optional fence tokens and current-owner proofs are promising for reassignable live claims, but Steward should not freeze a universal distributed lock service, leader-election API, or global monotonic sequencer before real pressure exists.
30. **No giant portable token-exchange / delegation family yet**
    - Attenuation-only derived grants are promising for helpers and follow-on actions, but Steward should not freeze a universal STS, impersonation grammar, caveat DSL, or cross-domain delegation plane before real pressure exists.
31. **No giant portable holder-proof / token-binding family yet**
    - Optional holder-bound grants are promising for replay-sensitive live powers, but Steward should not freeze a universal DPoP, mTLS, token-introspection, revocation-list, or key-lifecycle plane before real pressure exists.
32. **No giant portable trusted-UI / consent / gesture-proof family yet**
    - Optional fresh local intent witnesses are promising for higher-risk shell actions, but Steward should not freeze a universal trusted-UI, biometric, passkey, approval-cache, or wildcard consent plane before real pressure exists.
33. **No giant portable quota / retry-throttling / Retry-After family yet**
    - Optional retry-advice hints are promising for denials, cooldowns, and pushback, but Steward should not freeze a universal RateLimit header family, token-bucket plane, retry-throttling ledger, or giant exponential-backoff grammar before real pressure exists.
34. **No giant portable spendability / headroom family yet**
    - Tiny headroom witnesses are promising for keeping allowed, approved, and ready separate from restart, quota, seat, or rate-window exhaustion.
    - Steward should not yet freeze a universal wallet, pricing model, fairness algebra, capacity planner, or cross-runtime quota dashboard before repeated lifecycle and shell pressure makes that worth standardizing.
35. **No final portable dependency-strength / optional-edge algebra yet**
    - Optional helper capabilities, weak shutdown-order hints, and lazy pull-first activation are promising.
    - Steward should not freeze a universal strong/weak/soft dependency grammar or helper-edge calculus before repeated lifecycle pressure exists.
36. **No giant portable checkpoint / restore or generic escrow broker yet**
   - Bounded continuity escrow is promising for allowlisted listeners, handles, or small state capsules that a reviewed component may receive again on restart.
   - Steward should not freeze a CRIU-like process snapshot contract, multi-payload continuity attic, cross-component transfer family, or generic descriptor/state broker before repeated pressure makes any of that worth standardizing.
37. **No final portable launch-basis taxonomy yet**
    - Launch-boundary crossing matters, and exact exec objects, startup credentials, cwd roots, activation material, and child-local slots are useful classes to keep visible.
    - Steward should not freeze a universal exec-object/script-input/startup-credential/runner/closure algebra before repeated lifecycle pressure exists.

38. **No giant portable readiness-version / rollout-generation algebra yet**
    - Optional readiness-generation witnesses are promising for stale-fencing and honest shell/status UX when one live run may lag a newer reviewed generation.
    - Steward should not freeze a universal reconcile-loop, rollout-controller, condition-graph, or version-vector family before that pressure is real.
39. **No giant portable restart-intensity / burst-sharing algebra yet**
    - Tiny automatic restart-admission budgets are promising for keeping repeated failure explicit and bounded.
    - Steward should not freeze a supervisor-tree restart calculus, cause-weighted spending grammar, shared burst pools, or portable countdown/timer choreography before repeated pressure makes those distinctions worth standardizing.
40. **No giant portable liveness-evidence / degraded-health family yet**
    - Optional liveness-evidence observations are promising for showing watchdog, probe, or check-in truth without conflating them with readiness or useful work progress.
    - Steward should not yet freeze a universal health-check DSL, degraded-mode taxonomy, probe-cadence grammar, or watchdog-management family before repeated lifecycle pressure makes those distinctions worth standardizing.

41. **No giant portable discovery-registry / advertisement-lease family yet**
    - Tiny advertisement truth is promising for saying whether a reviewed component is currently published, withheld, withdrawn, or expired in one discovery lane.
    - Steward should not yet freeze a universal service registry, balancer-membership grammar, DNS/control-plane API, or distributed discovery-lease family before repeated lifecycle pressure makes those distinctions worth standardizing.


42. **No final portable lifecycle-hook / sidecar taxonomy yet**
    - Prestart/poststart/poststop helpers, sidecars, and cleanup companions are useful patterns, but Steward should not yet freeze a universal role grammar for lifecycle helpers while SlopOS itself is still deciding adjacent jobs, background, and service seams.
43. **No giant portable terminal-automation approval family yet**
    - Scoped approval rails are useful, but Steward should not yet freeze a universal auto-approve policy matrix, trust-cache family, or cross-session automation consent plane before real shell operating pressure exists.
44. **No final portable relocate / reschedule grammar yet**
    - Restart admission, restart exhaustion, node loss, drain, relocation, and later placement policy are usefully different pressures.
    - Steward should keep the restart-versus-relocate split visible, but it should not yet freeze a Nomad-like reschedule grammar, migration timer family, or placement-policy algebra while SlopOS itself is still moving.
45. **No giant portable shared-session / collaboration family yet**
    - Observe-only witness mode, interactive attach, and explicit control upgrades are useful, but Steward should not yet freeze a universal remote-session transport, shared-cursor protocol, participant-role algebra, or multiplayer collaboration plane before repeated shell operating pressure makes that worth standardizing.
46. **No final portable reconnect-resume / silent-retarget attach family yet**
    - Reconnecting, resumed witness, expiry, and replacement truth are useful, but Steward should not yet freeze a universal roaming-session protocol, reconnect-authentication family, silent retargeting rule set, or browser/terminal attach-transport algebra before repeated shell operating pressure makes that worth standardizing.
47. **No giant portable agent/chat/notebook proposal family yet**
    - Proposal lanes are useful for keeping helper conversations, plans, and command suggestions separate from exact shell execution, but Steward should not yet freeze a universal chat transcript protocol, notebook runtime family, agent-plug-in marketplace, or cross-session proposal memory plane before repeated shell operating pressure makes that worth standardizing.
48. **No giant portable callback / detour-return / wake-broker family yet**
    - Exact local return tickets are useful for browser/auth/chooser detours, but Steward should not yet freeze a universal callback URL contract, loopback redirect broker, browser-session roaming plane, or generic background wakeup family before repeated shell operating pressure makes that worth standardizing.

49. **No giant portable unified remembered-search / synced-history family yet**
    - Unified remembered search across command history, workflows, notebooks, prompts, and proposal memory is useful, but Steward should not yet freeze a universal sync backend, ranking algebra, shared team-memory plane, or cross-product search schema before repeated shell operating pressure makes that worth standardizing.
50. **No giant portable autonomy-profile / approval-matrix family yet**
    - Visible approval rungs are useful for keeping proposal-only help, ask-before-run, scoped auto-approval, and run-until-completion distinct, but Steward should not yet freeze a universal profile marketplace, cross-session trust cache, per-tool algebra, or enterprise-policy family before repeated shell operating pressure makes that worth standardizing.

51. **No giant portable preflight-plan / saved-diff family yet**
    - Explicit preflight lanes are useful for keeping explain, diff, speculative preview, reviewed saved plan, and apply visibly distinct.
    - Steward should not yet freeze a universal diff format, approval-carrying plan artifact, cross-runtime plan cache, or full planner/workflow engine before repeated shell and lifecycle pressure makes that worth standardizing.
52. **No giant portable revision-settlement / rollout-controller family yet**
    - Tiny desired / observed / settled revision truth is useful for explaining pending promotion, stale status, and rollback-to-last-settled guidance.
    - Steward should not yet freeze a universal reconcile loop, rollout planner, canary grammar, stable-version wallet, or cross-runtime rollback-policy algebra before repeated lifecycle pressure makes that worth standardizing.

53. **No giant portable waiver / exception / break-glass family yet**
    - Tiny exception witnesses are useful for keeping bypass-under-review, waived-under-expiry, and satisfied-gate truth visibly separate.
    - Steward should not yet freeze a universal waiver workflow engine, exception ticket taxonomy, reviewer-service plane, cross-session break-glass cache, or enterprise policy-approval family before repeated lifecycle and shell pressure makes that worth standardizing.

54. **No giant portable service-traffic / balancing family yet**
    - Tiny serve-state witnesses are useful for keeping `serving`, `serving+terminating`, `draining`, `maintenance`, `degraded`, and `not serving` visibly separate from mere process liveness or discoverability.
    - Steward should not yet freeze a universal load balancer API, endpoint weighting grammar, service-mesh policy plane, or cross-runtime traffic-family contract before repeated lifecycle pressure makes that worth standardizing.

55. **No giant pressure / autoscaling / reclaim-action family yet**
    - A tiny pressure-witness seam is promising for exposing scoped stall or warning/critical pressure without flattening it into failure or serving folklore.
    - Steward should not yet freeze a universal PSI watch protocol, autoscaler feedback API, reclaim-action grammar, scheduler-pressure plane, or writable threshold-registration family before repeated lifecycle pressure makes those distinctions worth standardizing.

56. **No giant overload / fair-queuing / traffic-shaping family yet**
    - A tiny backpressure-witness seam is promising for exposing `queued`, `retry-after`, `shed`, or `stop-accepting` truth without flattening it into pressure, headroom, or failure folklore.
    - Steward should not yet freeze a universal fair-queuing service, retry-budget ledger, traffic-shaping API, or cross-runtime overload-controller family before repeated lifecycle pressure makes those distinctions worth standardizing.

57. **No giant brownout / autoscaling / remediation-policy family yet**
    - A tiny adaptation-witness seam is promising for exposing cache trim, reduced concurrency, optional-work deferral, or other protective responses without flattening them into pressure, backpressure, or vague degraded folklore.
    - Steward should not yet freeze a universal brownout controller, autoscaler feedback plane, adaptive-tuning DSL, or cross-runtime remediation-policy family before repeated lifecycle pressure makes those distinctions worth standardizing.
