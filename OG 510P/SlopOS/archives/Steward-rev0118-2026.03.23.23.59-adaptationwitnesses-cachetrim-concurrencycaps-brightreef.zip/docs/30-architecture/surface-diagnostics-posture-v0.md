# Surface-diagnostics posture v0

Purpose: define a **tiny explanation seam** so shell/terminal affordances can say why they are enabled, degraded, blocked, or stale instead of acting like magic.

## Posture
1. **Every richer affordance should have an explain-why path**
   - Command guides, marks, quick fixes, exact-target actions, same-directory spawning, prompt-click editing, and command-finished notifications all depend on some mix of semantic support, trust, freshness, and policy.
   - Steward should let the user ask why one of those surfaces exists or why it is unavailable.
2. **Diagnostics should stay per-affordance and per-field when needed**
   - A pane can have working-directory support, weak command-frame boundaries, stale remote identity, and disabled replay authority all at once.
   - Steward should avoid one pane-wide “good” or “bad” myth when different fields have different truth.
3. **Capability, provenance, policy, and freshness are different answers**
   - “The terminal supports this sequence,” “the shell reported this field,” “policy allows this action,” and “the anchor is still fresh” are not interchangeable.
   - A good diagnostic surface should be able to separate those reasons instead of compressing them into one opaque status word.
4. **Show downgrade and denial explicitly**
   - If a feature fell back from trusted shell metadata to marker-assisted parsing, if a hop stripped support, or if policy blocks a mutating action, the surface should say so.
   - Silent disappearance is just another ambient-folklore failure mode.
5. **Prefer exact source details over generic failure folklore**
   - Useful explanation can include the shell type, shell-integration quality, reported cwd source, semantic-epoch freshness, target-anchor type, or missing capability bit.
   - Steward should prefer concrete reviewable details over vague messages like “feature unavailable.”
6. **Diagnostics are observational and explanatory, not a second control plane**
   - An inspector may reveal why a richer action is available, but it should not quietly become permission to bypass normal review or authorization.
   - Explanations help users and developers reason; they do not create authority.
7. **Debug overlays are allowed, but they should map back to exact seams**
   - Showing prompt zones, OSC 133 regions, anchor ids, freshness fences, or target provenance can be excellent debugging UX.
   - Those overlays should still describe the same underlying exact objects and fields the rest of Steward uses.
8. **Cached diagnostics should decay honestly**
   - A remembered shell type, past feature-report success, or old cwd report may still be useful context.
   - It should stay visibly remembered once the semantic world changed or the anchor went stale.
9. **One small diagnostics seam beats widget-local folklore**
   - Sticky headers, quick fixes, chooser surfaces, replay cards, and context-inheritance menus all need the same sort of explanation honesty.
   - Steward should prefer one tiny surface-diagnostics posture over a pile of ad hoc “why did this happen?” exceptions.

## Phase-1 non-goals
- a universal terminal-debugger protocol;
- requiring every affordance to expose every internal detail by default;
- inventing a giant machine-scored UX health number;
- turning diagnostics into a hidden automation or permission API;
- pretending remembered diagnostics remain live truth forever.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-guide-posture-v0.md`
- `assist-surface-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `capability-ledger-posture-v0.md`
- `precision-fence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `target-anchor-posture-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-UPDATE-1103
- REF-GHOSTTY-RELEASE-130
- REF-ITERM2-FEATURE-REPORTING
- REF-ITERM2-ESCAPE-CODES
