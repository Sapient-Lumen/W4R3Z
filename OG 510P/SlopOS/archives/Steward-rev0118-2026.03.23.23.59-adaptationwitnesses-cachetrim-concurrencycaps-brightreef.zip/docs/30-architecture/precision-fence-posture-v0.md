# Precision-fence posture v0

Purpose: define how Steward's shell/terminal semantics stay **honest about precision** when hops, multiplexers, fallback paths, or downgraded capabilities mean the UI no longer knows cwd, command boundaries, or target identity exactly.

## Posture
1. **Precision is explicit metadata, not hidden optimism**
   - Shell/terminal observations should be allowed to say whether cwd, command line, command boundaries, and target identity are exact, shell-reported but unverified, inferred, stale, or unknown.
   - Avoid pretending every pane always has exact semantic truth.
2. **Fences should mark semantic downgrade points**
   - SSH-like hops, tmux-like layers, shell restarts, capability loss, or failed resync should be allowed to insert an explicit precision fence.
   - A fence says “precision changed here”; it should not silently preserve stale certainty.
3. **Precision fences are observational, not authority**
   - A fence is a warning about what the UI knows, not permission to mutate anything.
   - Steward actions should still flow through explicit operations and authorization.
4. **Feature use should follow progressive enhancement**
   - Small optional terminal features should be negotiated or detected and ignored safely when unsupported.
   - Steward should prefer “feature available, use it” over “assume a giant baseline terminal contract”.
5. **Capability names are not sufficient truth**
   - TERM strings, terminal folklore, or one previous successful marker do not prove current precision.
   - Steward should prefer explicit fresh markers and fresh prompt reports over inherited guesses.
6. **Trusted shell reports should outrank terminal inference**
   - Exact shell-reported command lines, cwd, and boundaries with provenance signals should rank above scrollback reconstruction.
   - When provenance degrades, the UI should degrade its affordances too.
7. **Resync beats silent drift**
   - If a layer suspects markers were lost or pane state drifted, it should prefer an explicit resync or fresh-prompt refresh path.
   - Guessing from old state is exactly the kind of ambient folklore Steward is trying to avoid.
8. **Render batching is a hint worth using, not a semantic dependency**
   - When a terminal supports synchronized rendering or equivalent batching, Steward-aware shell redraws and frame/status updates should be able to use it to reduce visual tearing.
   - The semantic model must still work when such hints are unavailable.
9. **Precision should gate action surfaces**
   - High-precision, fresh, provenance-backed targets may justify inspect/open/explain and, when separately authorized, mutating actions.
   - Lower-precision targets should fall back to safer actions or require re-selection.
10. **Visible downgrade is better than fake compatibility**
    - A pane that only has raw PTY bytes should still be usable.
    - But it should not masquerade as if it still has exact cwd, exact command lines, or safe stale-fenced actions.

## Phase-1 non-goals
- a universal numeric precision score frozen too early;
- requiring every shell, terminal, and multiplexer to preserve full semantic fidelity;
- turning capability negotiation into a giant terminal standards project;
- making synchronized rendering or advanced keyboard protocols mandatory for correctness;
- silently upgrading low-confidence observations into mutating power.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `action-surface-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-FISH-TERMINAL-COMPAT
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-SHELL-TRUST
- REF-TMUX-CONTROL-MODE
- REF-KITTY-KEYBOARD-PROTOCOL
- REF-KITTY-PROTOCOL-EXTENSIONS
- REF-WEZTERM-SYNC-RENDER
- REF-NCURSES-FAQ
- REF-XTERM-FAQ
