# Termination-cause posture v0

Purpose: define the smallest useful **end-of-cycle outcome / termination-cause vocabulary** so Steward can explain why a concrete runtime cycle ended without falling back to PID folklore, log archaeology, or a giant host-specific failure API.

## Posture
1. **Cycle outcome belongs to the concrete runtime cycle**
   - “Why did it stop?” attaches most naturally to one concrete runtime cycle, not only to the long-lived component identity.
   - Runtime-cycle witness plus termination-cause is a promising minimal pair for receipts, explainers, and stale-action diagnosis.
2. **Keep the portable cause vocabulary small**
   - A useful phase-1 portable set likely looks close to:
     - requested stop,
     - clean self-exit / completed,
     - abnormal exit / crash,
     - timeout / watchdog-style failure,
     - policy or resource kill,
     - unknown / implementation-lost detail.
   - Implementations may carry richer native detail underneath.
3. **Cause and restart policy stay separate**
   - A crash may be followed by restart.
   - A requested stop may also be followed by restart due to later activation.
   - The observed cause of one cycle ending should not be conflated with Steward’s next policy decision.
4. **Portable cause should separate actor from detail when possible**
   - “requested stop by Steward”, “self-exited cleanly”, and “killed by policy/resource pressure” answer importantly different questions.
   - Rich native details such as signal numbers, exit codes, or host-local reason strings may ride alongside the compact portable cause.
5. **Not every component will receive a graceful stop callback**
   - Components may fail to observe impending termination under crash, resource exhaustion, or power-loss conditions.
   - Steward should preserve the distinction between “component was asked to stop” and “component definitely observed / acknowledged that request.”
6. **Termination cause should be receipt- and status-friendly**
   - End-of-cycle receipts, explainers, and recent-history views should be able to carry a compact cause plus optional native detail.
   - The current status channel may also surface the last-known cycle-end cause when it helps explain cooldown, restart delay, or degraded state.
7. **Do not pretend every runtime exposes identical fidelity**
   - Some hosts can report exit code, signal, watchdog, or OOM detail.
   - Others may only know that the component stopped or disappeared.
   - Steward should preserve honesty about precision rather than fabricate a false universal matrix.
8. **Shell and terminal affordances should show cause, not synthesize it**
   - Command frames, command-finished notifications, and lifecycle explainers may display termination cause.
   - They should source that from explicit Steward state/receipts when available, not from output scraping.
9. **Unknown is a real outcome, not a failure of dignity**
   - If the host cannot distinguish crash from power loss, or if detail was lost, Steward should say so explicitly instead of smuggling certainty into the UI.

## Phase-1 non-goals
- a universal cross-platform enumeration of every signal, exit code, watchdog subtype, and kernel kill reason;
- promising that every stop maps cleanly onto one closed reason code with perfect precision;
- making termination cause the same thing as fault attribution, blame, or restart policy;
- freezing a giant event/audit protocol before the compact vocabulary proves useful.

## Adjacent docs
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `readiness-posture-v0.md`
- `transient-promotion-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SYSTEMD-SERVICE
- REF-SYSTEMD-EXEC
- REF-FUCHSIA-LIFECYCLE
- REF-FUCHSIA-COMPONENT-RUNNER
- REF-SOLARIS-SMF-RESTARTER
