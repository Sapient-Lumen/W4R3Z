# Attach-continuity posture v0

Purpose: define a **tiny attach-continuity seam** so dropped terminals, reconnect grace, resumed witness views, and runtime replacement stay explicit without turning transport survival into service-lifecycle folklore.

## Posture
1. **Attach continuity is not component continuity**
   - A viewer or terminal may reconnect to a prior attach path while the underlying runtime-cycle truth has changed, expired, or been replaced.
   - Steward should name those as separate facts instead of letting transport continuity impersonate service continuity.

2. **Reconnect, resumed, expired, replaced, and lost should stay visibly different**
   - Phase 1 should have room for compact truths such as `connecting`, `reconnecting`, `resumed`, `expired`, `replaced`, `lost`, or `unknown` when a transport or attach handle changes state.
   - `Unknown` is especially important when the transport story is temporarily incomplete; it is healthier than optimistic guesswork.

3. **Resume should bias toward witness first**
   - After reconnect or resume, the safe default is `observe` / witness continuity first.
   - Stronger lanes such as interactive input, control, or debug may require explicit re-upgrade even when the display surface looks familiar.

4. **Runtime replacement ends the old attach story unless explicitly rebound**
   - If a component was restarted, relocated, or replaced, Steward should be willing to say `old attach expired; new runtime available` rather than silently retargeting a live control path.
   - Any explicit rebind should surface the new runtime-cycle witness and resulting lane truth.

5. **Exact request/session handles beat sticky booleans**
   - Long-lived or mediated attach flows should prefer exact closeable request/session handles with explicit completion, cancellation, expiry, and close semantics.
   - That keeps attach continuity attributable instead of hiding in ambient transport state.

6. **Transport and authority must be reported separately**
   - The shell/terminal may show that a transport was re-established while also admitting that current authority is still witness-only, pending re-approval, or gone.
   - One should never imply the other by folklore.

7. **Prompt-local luxuries need live prompt truth**
   - Prompt-click editing, current-command extraction, or command-local widgets are excellent ergonomics when the active prompt or command frame is still exactly known.
   - After reconnect, replay, or stale prompt markers, Steward should degrade those luxuries honestly instead of pretending the old prompt is still live.

8. **Phase 1 keeps the seam smaller than a transport family**
   - Steward should not freeze a universal remote-session transport, session roaming protocol, or multiplayer cursor model here.
   - The portable seam is attach continuity truth plus explicit re-upgrade or refresh paths.

## Phase 1 non-goals
- a portable browser/PTY/WebSocket attach transport;
- a generic reconnect-authentication or roaming-session family;
- silent retargeting from one runtime-cycle witness to another;
- turning remembered tabs or transcript shelves into proof of live attach continuity.

## Wiring
- `attach-lane-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `command-frame-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `context-handoff-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-NOMAD-DISCONNECT
- REF-XDG-PORTAL-REQUEST
- REF-XDG-PORTAL-SESSION
- REF-ZELLIJ-RELEASE-044
- REF-GHOSTTY-RELEASE-130
