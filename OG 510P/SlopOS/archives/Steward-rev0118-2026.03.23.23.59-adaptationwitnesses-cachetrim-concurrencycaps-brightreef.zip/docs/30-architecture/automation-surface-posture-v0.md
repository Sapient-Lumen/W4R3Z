# Automation-surface posture v0

Purpose: define a **tiny automation/control seam** so scripts, hooks, remote-control APIs, and helper CLIs stay exact-targeted, permissioned, and inspectable instead of becoming an ambient second control plane.

## Posture
1. **Automation transport should stay separate from the rendered transcript**
   - Rendered shell output is for humans first, even when it carries semantic hints.
   - Steward should prefer explicit automation channels, selectors, or receipts over screen-scraping or prompt-text folklore when a tool wants to act.
2. **Automation should target exact objects, not ambient panes**
   - A script may want to act on one window, tab, pane, command frame, receipt, workspace snapshot, or reviewed selector.
   - Steward should keep those targets explicit instead of assuming “current pane” or visible text is always the real authority.
3. **Authority should be partitionable by action class**
   - Opening a chooser, querying state, focusing a tab, injecting bytes, spawning a shell, or changing colors are not equivalent powers.
   - Steward should support policy and review at least at the level of action families instead of one flat “automation on/off” switch.
4. **Connection path should be visible**
   - A helper CLI might be talking to the GUI instance, a mux server, one pane-local helper, or a remote terminal path.
   - Steward should expose which control path was used so automation never feels like ambient magic.
5. **Async/streaming automation should stay attributable and cancelable**
   - Some actions wait for user choice, long-running transfer, or incremental output.
   - Steward should keep request identity, optional deadline, progress, completion, and cancellation explicit instead of forcing clients to guess from timing or screen changes.
6. **Hooks and extensibility should remain scoped surfaces**
   - Hooks, title providers, status providers, plugin callbacks, and similar extension points are useful.
   - Steward should keep them as named bounded surfaces rather than letting them quietly inherit universal authority over the shell or lifecycle fabric.
7. **Automation should report what it actually did**
   - A successful automated action should be able to yield a compact receipt describing target, action class, downgrade, and any policy fence that applied.
   - That is healthier than leaving users to infer success from changed scrollback or a moved cursor.
8. **Denied or degraded automation should be first-class**
   - Policy, stale selectors, missing capabilities, or downgraded helper paths are normal facts in a rich terminal.
   - Steward should surface denial and downgrade explicitly instead of silently pretending the action never existed.
9. **One automation seam beats many hidden script loopholes**
   - Remote control, hooks, menu callbacks, helper CLIs, and plugin pipes all want the same anti-folklore discipline.
   - Steward should prefer one small automation-surface posture over many special-purpose side doors.

## Phase-1 non-goals
- a universal cross-terminal RPC standard;
- freezing one plugin architecture for every future Steward UI surface;
- granting shell/session mutation just because a script can reach a pane;
- treating automation authorization as a replacement for normal user-visible action review;
- inventing a giant terminal-governance family before more than one closely related seam really exists.

## Adjacent docs
- `action-surface-posture-v0.md`
- `assist-surface-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `session-injection-posture-v0.md`
- `spawn-palette-posture-v0.md`
- `target-anchor-posture-v0.md`
- `context-handoff-posture-v0.md`
- `precision-fence-posture-v0.md`
- `request-context-posture-v0.md`

## References
- REF-TMUX-CONTROL-MODE
- REF-KITTY-REMOTE-CONTROL
- REF-KITTY-RC-PROTOCOL
- REF-WEZTERM-CLI
- REF-ITERM2-RPCS
- REF-ITERM2-HOOKS
- REF-ITERM2-VARIABLES
- REF-GRPC-CANCELLATION
