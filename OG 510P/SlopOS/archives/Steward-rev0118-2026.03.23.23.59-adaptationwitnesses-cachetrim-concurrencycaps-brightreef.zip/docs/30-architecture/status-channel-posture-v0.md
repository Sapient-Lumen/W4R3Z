# Status channel posture v0

Purpose: keep Steward's **current-state/status reporting** compact, attributable, and separate from logs, metrics, and transcripts.

## Posture
1. **Status is its own channel**
   - Steward should have a compact status path for lifecycle state, short current-status text, and bounded reason codes instead of forcing operators to reconstruct live truth from logs.
2. **Status is current truth, not archival history**
   - Receipts and transcripts explain what happened.
   - Status explains what is true now.
3. **Keep the core payload small**
   - The portable shape should stay close to:
     - lifecycle observation token,
     - optional short reason/status code,
     - optional short human-readable status line,
     - optional most-recent termination cause when it materially explains current state,
     - provenance / runtime-cycle witness data sufficient to avoid attribution races.
4. **Status provenance must be visible**
   - A status update should be attributable to Steward, a runner/adapter, or the component itself.
5. **Status must not silently widen control authority**
   - Reporting `ready`, `stopping`, `waiting`, or `degraded` does not grant mutation rights.
6. **Compact status beats clever log scraping**
   - A short explicit status channel is healthier than regex archaeology over stdout/stderr.
7. **Free-form text is optional and subordinate**
   - Human-readable lines are useful, but phase/state meaning should not depend entirely on prose.
8. **Status should compose with shell receipts and terminal marks**
   - The shell and terminal may surface compact status and reason text, but they should not become the only source of truth.
9. **Attribution and ordering need an honest story**
   - If status may originate from the component side of the runtime boundary, Steward should preserve enough provenance and optional synchronization to distinguish “status was emitted” from “status is definitely attributed and current.”
10. **Compact acknowledgements beat folklore polling**
   - A small acknowledgement or barrier path is healthier than teaching clients to sleep-and-hope after a ready/stopping/degraded update.

## Phase-1 non-goals
- a giant logging protocol;
- a metrics or tracing subsystem;
- streaming arbitrary blobs through the status path;
- turning status into a hidden orchestration bus.

## Adjacent docs
- `observation-subscription-posture-v0.md`
- `design-principles-v0.md`
- `lifecycle-observation-posture-v0.md`
- `readiness-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `termination-cause-posture-v0.md`

## References
- REF-SD-NOTIFY
- REF-S6-READY
- REF-FUCHSIA-LIFECYCLE
- REF-VSCODE-SHELL-TRUST
- REF-SYSTEMD-EXEC

