# Execution-ground posture v0

Purpose: define a **tiny observational ground seam** for panes and command frames so Steward can show the user what context a command is standing on without pretending that chrome or remembered context is lifecycle authority.

## Posture
1. **Ground is a summary, not a proof object**
   - A pane, command frame, or receipt card may summarize cwd root, hop lineage, component id, runtime-cycle witness, launch basis, and confidence.
   - That summary is there to orient the user, not to replace the underlying receipt, anchor, or status path.
2. **Current, reported, manager-redelivered, and remembered facts must stay distinguishable**
   - A ground card should be able to say whether a field is current-shell-reported, terminal-inferred, manager-attested, activation-redelivered, or merely remembered convenience.
   - Flattening those classes into one cheerful badge would recreate the exact folklore Steward is trying to avoid.
3. **Ground belongs to one semantic epoch and one hop lineage**
   - The same cwd text or component label can mean different things after SSH hops, terminal resync, shell replacement, or restart.
   - Ground should visibly clear, downgrade, or restamp itself when that ancestry changes.
4. **Lifecycle identity and stream attachment stay separate inside ground**
   - A component id, runtime-cycle witness, request id, attach lane, and any foreground baton hint are different classes of fact.
   - The UI may place them near each other, but the contract should not blur them into “this pane owns the service”.
5. **Foreground baton truth is observational only**
   - When the host or shell can say who currently owns the foreground terminal turn, Steward may surface that as an exact current fact.
   - It should not freeze a portable terminal-control plane, process-group API, or job-control worldview around that observation.
6. **Ground cards should bottom out in exact anchors and receipts**
   - Expanding a summary should reveal the exact frame, receipt, witness, or launch explanation it came from whenever possible.
   - That keeps glanceable chrome from becoming an unauditable myth layer.
7. **Missing or partial fields are healthy**
   - A good ground seam must be able to say “unknown”, “stale”, “older epoch”, “remote path only”, or “remembered”.
   - Completeness should not be a precondition for honesty.
8. **One small shared seam beats many ad hoc badges**
   - Prompt chips, status rails, sticky headers, receipt cards, and command gutters all want the same orientation fields.
   - Steward should prefer one tiny shared ground vocabulary instead of every surface inventing its own half-truths.
9. **Ground should compose with shell guidance**
   - Completion rows, predictive suggestions, replay gates, and rerun affordances should be able to reuse the same ground summary and truth labels.
   - That keeps convenience features aligned with the same current-versus-remembered discipline.
10. **Copy/export should default to the underlying record, not the ornament**
   - Ground summaries are excellent for glanceability.
   - They should only travel in exports through explicit transcript annotations, receipts, or handoff bundles.

## Phase-1 non-goals
- freezing a final wire format for every field shown in a ground card or HUD;
- defining a portable process-group or job-control API for “foreground ownership”;
- requiring every shell or hop layer to expose the same context fields;
- treating chrome summaries as proof of current authority or replay eligibility;
- turning orientation chrome into a second hidden control plane.

## Adjacent docs
- `command-frame-posture-v0.md`
- `chrome-lane-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `launch-context-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `remembered-shelf-posture-v0.md`
- `target-anchor-posture-v0.md`
- `context-handoff-posture-v0.md`

## References
- REF-POSIX-TCSETPGRP
- REF-VSCODE-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WEZTERM-SHELL-INTEGRATION
- REF-ITERM2-SHELL-INTEGRATION
- REF-ITERM2-STATUS-BAR
- REF-WEZTERM-RIGHT-STATUS
- REF-PSREADLINE-PREDICTORS
- REF-NUSHELL-CUSTOM-COMPLETIONS
