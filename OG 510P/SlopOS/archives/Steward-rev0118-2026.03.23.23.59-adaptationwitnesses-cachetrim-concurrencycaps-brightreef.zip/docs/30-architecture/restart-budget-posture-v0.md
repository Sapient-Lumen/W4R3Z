# Restart-budget posture v0

Purpose: define a **tiny automatic-restart admission-budget seam** so Steward can keep repeated-failure handling explicit, bounded, and explainable without freezing a portable timer API, tree-wide restart algebra, or hidden host-supervisor folklore.

This seam stays smaller than repair gates, retry advice, and termination cause. It answers one narrower question: **while automatic restart remains allowed, what exactly is being counted, over what trailing window, and what happens when that budget is exhausted?**

## Posture
1. **Restart budget is an automatic-admission budget, not a second health model**
   - The budget governs automatic re-entry after failure or failed bring-up.
   - It does not replace readiness, liveness, diagnostics, or operator judgment.
2. **Fresh launch and automatic restart admission stay different**
   - The initial reviewed launch of a component runtime cycle should not silently count as a spent automatic restart admission.
   - Steward should preserve the difference between first start and later automatic retry pressure.
3. **The budget is evaluated over a trailing window, not by mystical reset events**
   - When a budget uses a bounded window, prior automatic restart admissions should age out by leaving that trailing window.
   - Successful occupancy may reduce pressure indirectly by letting old admissions age out; it should not require a hidden side reset ritual.
4. **Budget exhaustion is a lifecycle fact, not a hidden manager mood**
   - If the next automatic restart would exceed budget, Steward should surface that explicitly through status/receipts/repair-gate explanation rather than silently sleeping forever or pretending the component is merely still starting.
5. **Restart budget and repair gate stay separate**
   - A budget says how much automatic retry pressure is tolerated inside one trailing window.
   - A repair gate says the system has intentionally stopped auto-retrying until explicit repair/clear/policy change or another narrow release condition occurs.
   - One may lead to the other, but they are not the same seam.
6. **Portable semantics stop before timer choreography**
   - Phase 1 should not standardize exponential curves, jitter policy, exact next-retry timestamps, or host-runtime-specific start-limit machinery.
   - Local adapters may pick internal delay policy as long as the public story remains bounded and explainable.
7. **Budget pressure should remain local to the supervised leaf unless explicitly widened elsewhere**
   - Steward should not quietly turn one component's restart pressure into a whole supervision-tree score, host-global failure mood, or ambient dependency penalty.
   - Broader tree/pool semantics require their own explicit seam if they are ever needed.
8. **Disabled automatic restart should be exact**
   - If a manifest/policy disables automatic restart, the honest result is immediate non-retryable failure or a direct handoff into explicit repair/clear paths.
   - Steward should not hide one latent retry queue behind that disabled form.
9. **Shell chrome should expose pressure, not fake diagnosis**
   - Good compact chips include `restart budget 2/5 in 60s`, `auto-restart disabled`, `budget exhausted`, or `cooling down`.
   - They should orient the user without pretending to summarize root cause.
10. **Phase 1 keeps the public shape tiny**
   - The manifest may carry only a bounded window plus max automatic restart admissions.
   - Richer pool/tree budgets, cause-weighted spending, and portable restart ledgers remain intentionally undecided.

## Phase-1 non-goals
- a portable exponential-backoff or jitter DSL;
- a tree-wide restart-intensity calculus;
- portable next-retry timestamps or mandatory countdown surfaces;
- weighting restart spending by failure cause or exit status;
- exposing host-native service-manager start-limit knobs as Steward's public contract.

## Adjacent docs
- `component-manifest-schema-v0.md`
- `supervision-posture-v0.md`
- `repair-gate-posture-v0.md`
- `retry-advice-posture-v0.md`
- `termination-cause-posture-v0.md`
- `activation-cause-posture-v0.md`
- `readiness-posture-v0.md`
- `status-channel-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-ERLANG-OTP-SUPERVISOR
- REF-SYSTEMD-UNIT
- REF-SYSTEMD-SERVICE
- REF-K8S-POD-LIFECYCLE
- REF-SMF-MAINTENANCE
- REF-GNU-SHEPHERD-MANUAL
