# Spawn-palette posture v0

Purpose: define a **tiny reviewed launch-discovery seam** so command palettes, launcher menus, and similar UI can expose *reviewed spawn recipes* without becoming a back door for arbitrary shell folklore.

## Posture
1. **A spawn palette surfaces reviewed recipes, not freeform command text**
   - Palette entries should resolve to reviewed spawn selectors or other already-reviewed launch recipes.
   - Steward should resist palettes that quietly smuggle `sh -c`, ad hoc profile names, or whatever program path the host currently guesses.
2. **Labels, icons, and descriptions are presentation, not launch authority**
   - An entry may have a friendly label, icon, shortcut hint, or grouped category.
   - The real launch meaning still belongs to the reviewed selector underneath, not to its human-facing decoration.
3. **Dynamic expansion is fine when the source set is explicit**
   - It can be useful to expand “new tab with profile …” or “connect to domain …” from a reviewed current set.
   - Steward should allow that only when the expansion source is explicit and explainable, instead of letting discovery logic invent hidden launch semantics.
4. **Current context may filter or sort, but should not redefine the recipe**
   - The current frame, cwd source class, trust state, domain, or hop lineage may make some entries more relevant.
   - That should influence ordering, defaults, or disabled states, not silently rewrite what the entry fundamentally means.
5. **Disabled-with-reason beats silent disappearance**
   - If a launch recipe is unavailable because trust is low, the current hop lacks a needed capability, or policy forbids it, the palette should prefer a visible disabled entry with an exact reason.
   - Hidden denial quickly turns back into folklore.
6. **Unsafe or policy-sensitive recipes deserve an extra fence**
   - Some recipes may point at unsafe profile paths, helper shells with broader ambient reach, or remote domains with stronger policy consequences.
   - Those entries may need a warning, trust gate, or explicit confirm step before they run.
7. **Palette launches should emit a receipt or explanation trail**
   - After a palette action, Steward should be able to say which reviewed selector ran, which context fields were inherited, what was denied or downgraded, and which target/frame asked for it.
   - That keeps convenience discoverable without losing accountability.
8. **One launch-discovery seam beats many ad hoc menus**
   - New-tab menus, split menus, helper-shell menus, and command palettes all want the same anti-folklore discipline.
   - Steward should prefer one small spawn-palette posture rather than many launcher-specific exceptions.

## Phase-1 non-goals
- a giant cross-terminal command-palette extension protocol;
- letting arbitrary terminal applications publish ambient privileged actions into the palette by default;
- hiding policy denials as if the action never existed;
- freezing one universal menu structure across every host terminal;
- turning palette presentation metadata into authority.

## Adjacent docs
- `spawn-selector-posture-v0.md`
- `context-inheritance-posture-v0.md`
- `action-surface-posture-v0.md`
- `target-anchor-posture-v0.md`
- `precision-fence-posture-v0.md`
- `chooser-surface-posture-v0.md`

## References
- REF-WEZTERM-LAUNCH-MENU
- REF-VSCODE-TERMINAL-PROFILES
- REF-WINDOWS-TERMINAL-COMMAND-PALETTE
- REF-GHOSTTY-RELEASE-120
- REF-KITTY-ACTIONS
- REF-KITTY-LAUNCH
