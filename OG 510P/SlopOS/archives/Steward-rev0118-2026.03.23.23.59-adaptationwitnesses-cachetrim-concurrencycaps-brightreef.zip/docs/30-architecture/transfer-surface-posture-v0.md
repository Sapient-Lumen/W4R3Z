# Transfer-surface posture v0

Purpose: define a **tiny file/object transfer seam** so uploads, downloads, remote-file actions, drag/drop handoff, and similar shell/terminal transfers stay exact, direction-labeled, and policy-bounded instead of becoming ambient path or prompt folklore.

## Posture
1. **Transfer is an authority crossing, not neutral convenience**
   - Moving a file, directory, receipt attachment, or other object between local UI, terminal session, remote host, helper process, or editor crosses trust and persistence boundaries.
   - Steward should treat those flows as explicit user-facing transfers, not as invisible PTY trivia.
2. **Direction and action should stay explicit**
   - Upload, download, open locally, edit locally-and-sync, attach as context, and paste path text are different actions with different consequences.
   - Steward should preserve that distinction instead of collapsing them into one vague “send the thing”.
3. **Exact target/destination beats ambient cwd folklore**
   - A line-local cwd, exact transcript anchor, reviewed selector, or explicit destination root is meaningfully stronger than “whatever directory the pane probably means right now”.
   - Steward should prefer exact anchored destinations and visible source classes over pane-wide cwd guessing.
4. **Approval and policy should be first-class**
   - Rich transfer paths can expose local filesystems to remote programs, remote files to local handlers, or downloaded bytes to local editors.
   - Steward should keep those transfers reviewable, denyable, and diagnosable instead of ambient for every shell process.
5. **Helper paths should remain visible**
   - Some transfer UX depends on shell integration, hyperlink support, helper scripts, or terminal-specific protocols.
   - Steward should surface which helper path made the transfer possible and when a weaker fallback path was used.
6. **Object-preserving transfer should be stronger than path/text insertion**
   - Choosing a remote file to edit, downloading an exact object, or attaching a reviewed selector preserves more meaning than pasting an escaped pathname into a shell.
   - Steward should prefer exact-object transfer surfaces when it has them, while keeping text insertion available as a visible downgrade.
7. **Nested-hop and remote ambiguity should degrade honestly**
   - Some terminal features work across nested SSH or serial paths; others only know about the first remote host or require a special helper.
   - Steward should label those boundaries clearly instead of pretending every remote path is equally exact.
8. **One transfer seam beats many magical upload/download exceptions**
   - Drag/drop open, remote-file click actions, object attachment, chooser exports, and terminal-native file transfer all want the same anti-folklore discipline.
   - Steward should prefer one small transfer-surface posture over a pile of host-specific transfer tricks.

## Phase-1 non-goals
- a universal binary/object transfer protocol for every terminal and host platform;
- guaranteeing transparent nested-hop fidelity for every transfer helper;
- ambient filesystem authority for every shell process just because the terminal can transfer files;
- silently synchronizing arbitrary local and remote directories;
- freezing one universal GUI drag/drop API.

## Adjacent docs
- `clipboard-surface-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `target-anchor-posture-v0.md`
- `context-handoff-posture-v0.md`
- `precision-fence-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-KITTY-TRANSFER
- REF-KITTY-FILE-TRANSFER-PROTOCOL
- REF-KITTY-REMOTE-FILES
- REF-ITERM2-SHELL-INTEGRATION
- REF-ITERM2-INLINE-IMAGES
- REF-VSCODE-TERMINAL-BASICS
- REF-WINDOWS-TERMINAL-TIPS
- REF-ZELLIJ-FILEPICKER
