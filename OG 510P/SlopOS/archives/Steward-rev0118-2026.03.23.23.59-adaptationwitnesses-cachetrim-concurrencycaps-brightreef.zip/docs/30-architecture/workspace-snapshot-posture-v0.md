# Workspace-snapshot posture v0

Purpose: define a **tiny saved-layout / restore seam** so Steward can reopen windows, tabs, panes, helper shells, and nearby shell context without pretending remembered arrangements are live process truth.

## Posture
1. **A workspace snapshot remembers layout and reviewed recipes, not liveness**
   - A snapshot may remember window, tab, pane, selector, cwd-source, domain, or chrome choices that were useful when the user saved it.
   - Steward should treat that as remembered structure unless a fresher live anchor, reconnection, or new receipt proves more.
2. **Layout restore, process reconnection, process revive, and content-only restore are different promises**
   - Reconnecting to a still-running process, relaunching a process from a reviewed recipe, restoring only transcript content, and reopening only the layout are not the same thing.
   - Steward should keep those outcomes visibly distinct instead of collapsing them into one vague “session restored” folklore.
3. **Restore should resolve through reviewed selectors and policy**
   - Reopened panes or helper shells should flow through reviewed spawn selectors, context-inheritance rules, and current policy gates.
   - A snapshot is not permission to smuggle stale `$SHELL`, mutated environment, or hidden remote state back into the architecture.
4. **Restored surfaces need explicit truth banners**
   - The UI should be able to say reconnected, revived, content-only, layout-only, downgraded, or failed for each restored thing.
   - That is healthier than letting the user infer truth from whether a pane happens to look familiar.
5. **Snapshot scope and persistence should stay explicit**
   - Saving a one-off debugging workspace, a default startup arrangement, or a crash-recovery layout can all be useful.
   - Steward should keep storage scope, retention, and optional persistence explicit rather than assuming every layout wants durable cross-device life.
6. **Remembered attachments stay remembered**
   - Transcript landmarks, notes, shelves, and nearby command context may be worth reopening with a snapshot.
   - They should still carry freshness and provenance labels instead of inheriting live authority from the restore act.
7. **Partial restore should explain itself**
   - Some panes may reconnect, some may relaunch cleanly, and others may fail because a domain, cwd, profile, or policy path is no longer available.
   - Steward should prefer exact downgrade or failure reasons over silent omission.
8. **One tiny snapshot seam beats many ad hoc restore stories**
   - Crash recovery, startup layouts, recent workspaces, and “reopen this troubleshooting cohort” all want the same anti-folklore discipline.
   - Steward should prefer one small workspace-snapshot posture instead of many inconsistent restore widgets.

## Phase-1 non-goals
- freezing a universal terminal checkpoint / migration format;
- pretending layout restore proves the old processes or remote domains are still alive;
- silently replaying arbitrary mutated shell environments as if they were reviewed launch truth;
- mandatory cloud sync for workspaces, layouts, or shelves;
- turning restored transcript content into a portable evidence or authority export plane.

## Adjacent docs
- `remembered-shelf-posture-v0.md`
- `context-inheritance-posture-v0.md`
- `spawn-selector-posture-v0.md`
- `spawn-palette-posture-v0.md`
- `context-handoff-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `transcript-landmark-posture-v0.md`
- `precision-fence-posture-v0.md`
- `chooser-surface-posture-v0.md`

## References
- REF-VSCODE-TERMINAL-ADVANCED
- REF-WINDOWS-TERMINAL-STARTUP
- REF-ITERM2-SESSION-RESTORATION
- REF-ITERM2-ONE-PAGE
- REF-WEZTERM-MULTIPLEXING
