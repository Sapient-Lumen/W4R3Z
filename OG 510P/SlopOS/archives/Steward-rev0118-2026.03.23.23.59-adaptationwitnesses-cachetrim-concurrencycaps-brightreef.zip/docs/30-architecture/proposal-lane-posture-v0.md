# Proposal-lane posture v0

Purpose: define a **tiny proposal/help lane seam** so agent/chat/notebook suggestions stay visibly separate from exact shell input and reviewed execution instead of becoming an ambient second shell.

## Posture
1. **Proposal lane is not the shell prompt**
   - Chat turns, plan cards, notebook command blocks, and agent suggestions may live beside a terminal session and remain deeply useful.
   - Steward should keep them as a named weaker lane instead of pretending they are just another form of typed shell input.
2. **Generated commands begin as proposals, not effects**
   - A proposal may suggest one command, a short sequence, a spawn selector, or a reviewed helper recipe.
   - The default public meaning should stay `proposed`, not `already running`.
3. **Insert or stage should usually beat silent execution**
   - The healthiest default is often “insert into the active prompt”, “open as a reviewed pending card”, or “fork into a fresh reviewed pane”.
   - Immediate execution can still exist, but it should be a stronger explicit move with clearer review and policy.
4. **Proposal context should bind to exact bounded objects**
   - Good proposals often need context from one command frame, output slice, receipt, target anchor, or selected notebook block.
   - Steward should avoid whole-pane or whole-session folklore where every nearby line silently becomes agent context.
5. **Proposal transcript and terminal transcript should stay visibly different**
   - Conversation turns, plan notes, and agent-local command attempts can be useful records.
   - They should not silently become canonical shell history or the lifecycle transcript for the component/session they discussed.
6. **Approvals and widening should be lane-scoped and explicit**
   - A proposal lane may ask to run one command, enable repeated approval within one conversation/session, or remain read-only.
   - Steward should resist one flat ambient `auto-run the assistant` switch that outlives the exact lane and moment that earned it.
7. **Attach and control upgrades should remain explicit**
   - A proposal lane may observe a live terminal session, tag into a running command, or suggest next moves inside an interactive program.
   - Observation, proposal, typing control, and stronger lifecycle control must still stay visibly distinct lanes.
8. **The lane should degrade honestly**
   - If exact context is gone, if only low-confidence text remains, or if policy forbids execution, the lane should still help by quoting, inserting, or explaining.
   - Silent fallback from exact proposal to ambient execution is precisely the folklore Steward is trying to avoid.
9. **One small proposal lane beats many half-hidden smart-terminal exceptions**
   - Inline terminal chat, notebook command blocks, plan panels, slash-command helpers, and agent conversations all want the same anti-folklore discipline.
   - Steward should prefer one compact proposal-lane posture over a pile of host-specific “AI terminal” loopholes.

## Phase-1 non-goals
- a universal chat or agent conversation protocol;
- a final autonomous-agent policy matrix for every tool and transport;
- silently merging proposal history into shell history or lifecycle transcripts;
- auto-running generated commands merely because a suggestion exists;
- a giant notebook/workflow/document family inside Steward itself.

## Adjacent docs
- `assist-surface-posture-v0.md`
- `automation-surface-posture-v0.md`
- `session-injection-posture-v0.md`
- `attach-lane-posture-v0.md`
- `attach-continuity-posture-v0.md`
- `command-frame-posture-v0.md`
- `context-handoff-posture-v0.md`
- `action-surface-posture-v0.md`
- `precision-fence-posture-v0.md`

## References
- REF-VSCODE-INLINE-CHAT
- REF-VSCODE-UPDATE-1110
- REF-WARP-FULL-TERMINAL-USE
- REF-WARP-AGENT-MODALITY
- REF-WARP-NOTEBOOKS
- REF-WARP-BLOCKS
