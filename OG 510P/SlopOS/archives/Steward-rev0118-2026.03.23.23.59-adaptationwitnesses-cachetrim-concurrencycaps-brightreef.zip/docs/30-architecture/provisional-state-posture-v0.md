# Provisional-state posture v0

Purpose: define how Steward's shell/terminal stack may show **tentative local state**—such as predictive echo, guessed frame boundaries, or pending finish cues—without letting speculation masquerade as confirmed lifecycle truth.

## Posture
1. **Provisional state is allowed, but it must be visibly provisional**
   - Steward should allow latency-hiding or incomplete shell/terminal UX when it materially improves interactivity.
   - The UI must be able to say “this is tentative” rather than quietly presenting prediction as fact.
2. **Prediction must reconcile to confirmed state**
   - Provisional command text, prompt position, finish cues, or frame metadata should either confirm, refine, or roll back when better information arrives.
   - Silent divergence is worse than a visible correction.
3. **Tentative data is observational, not authority**
   - Provisional markers may improve responsiveness and navigation.
   - They must not by themselves authorize lifecycle mutations, reruns, or evidence claims.
4. **Fresh shell reports outrank local guesses**
   - Explicit shell-reported command lines, cwd, exit status, and finish markers should replace earlier tentative inferences.
   - Steward should prefer late exactness over preserving an early optimistic guess as truth.
5. **Provisionality should be scoped to the current semantic world**
   - Hops, shell resets, semantic-epoch changes, or resync should be allowed to invalidate outstanding provisional observations.
   - A tentative target from an older semantic world should not survive as if nothing changed.
6. **Visible rollback beats hidden correction**
   - If a prediction was wrong, the UI should be allowed to show that it was revised or withdrawn.
   - Steward should prefer honest correction over quietly rewriting history.
7. **Interactive responsiveness may outrank exact streaming, but not honesty**
   - For weak links or busy paths, local editing feel may improve when the terminal gives prompt-local feedback early.
   - That does not justify pretending remote acknowledgment already happened.
8. **Later refinement is a feature, not an embarrassment**
   - Some shell/terminal observations naturally become more exact only after command finish, receipt arrival, or a fresh prompt.
   - Steward should let metadata improve over time without claiming it was exact all along.
9. **Fallback must remain usable**
   - Plain byte-stream terminals without provisional semantics should still work.
   - Provisional-state support is an optional ergonomic layer, not a correctness dependency.
10. **Keep the portable vocabulary tiny at first**
   - Phase 1 likely needs only a compact distinction such as confirmed / provisional / revised / withdrawn plus optional confidence/trust tags.
   - Avoid freezing a richer speculative-state machine too early.

## Phase-1 non-goals
- speculative execution of lifecycle mutations;
- hiding corrections so the transcript looks cleaner than reality;
- requiring every shell or transport to support prediction;
- treating provisional terminal metadata as durable evidence;
- inventing a giant synchronization protocol before narrow ergonomic pressure exists.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `precision-fence-posture-v0.md`
- `action-surface-posture-v0.md`
- `transient-promotion-posture-v0.md`

## References
- REF-MOSH
- REF-MOSH-PAPER
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-SHELL-TRUST
- REF-GHOSTTY-RELEASE-130
