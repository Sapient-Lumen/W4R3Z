# Schema registry

| ID | Meaning | Spec |
| --- | --- | --- |
| CH-COMP v0 | component manifest | `component-manifest-schema-v0.md` |
| CH-ACTSET v0 | activation set manifest | `activation-set-schema-v0.md` |
