# Readiness posture v0

Purpose: keep bring-up semantics honest.

## Posture
1. **Spawn success is not readiness**
   - The fact that a process started is not enough to claim the component can serve.
2. **Startup, control-ready, readiness, and liveness stay distinct**
   - `startup` covers initial bring-up,
   - `control-ready` means Steward or a runtime adapter can exchange lifecycle/status signals,
   - `ready` means the component can accept its declared work,
   - `live` means it continues making forward progress.
3. **Phase 1 prefers explicit readiness signals**
   - Ready should be component-declared or activation-mediated, not guessed from sleeps, parent assumptions, or log scraping.
4. **Slow start is not failure by default**
   - Startup budgets and readiness budgets should be separate.
5. **Shallow readiness should be named honestly**
   - If a layer can only prove “control/status path is up” or “supervisor can accept commands,” that should not be mislabeled as serve-readiness.
6. **Readiness is not authority**
   - Observing readiness does not grant control over the component.

## Phase-1 non-goals
- a giant health-check DSL;
- scraping arbitrary logs as the official readiness contract;
- automatic dependency ordering based only on spawn events.

## Adjacent docs
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `supervision-posture-v0.md`
- `component-manifest-schema-v0.md`
- `quiesce-posture-v0.md`

## References
- REF-S6-READY
- REF-S6-SHALLOW-READINESS
- REF-K8S-PROBES
