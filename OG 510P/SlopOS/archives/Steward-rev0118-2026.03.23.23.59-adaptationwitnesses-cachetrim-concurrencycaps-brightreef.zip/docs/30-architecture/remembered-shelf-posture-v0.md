# Remembered-shelf posture v0

Purpose: define a **tiny remembered-context seam** for recent commands, recent directories, recent Steward objects, and similar shell/terminal shelves so convenience memory stays powerful without masquerading as live state or ambient authority.

## Posture
1. **A shelf entry is remembered context, not current truth**
   - A recent command, directory, frame, component id, or object ref may be valuable even after the originating pane, run, or hop is gone.
   - Steward should treat that as remembered convenience unless a fresher exact anchor or report re-confirms it.
2. **Shelves should key off explicit context classes**
   - user, host, hop lineage, domain, and similar explicit context hints are healthy partition keys for recent shelves.
   - That is better than one flat global history where unrelated contexts bleed together by accident.
3. **Entries should carry freshness and provenance labels**
   - A shelf entry should be able to say whether it is current, shell-reported, manager-reported, or merely remembered.
   - Stronger actions should require fresher evidence than weaker actions such as copy, paste, or open-as-text.
4. **Shelf actions should resolve through explicit selectors or anchors**
   - Re-run, `cd`, “open a shell here”, reveal frame, open receipt, or inspect object should resolve through a reviewed spawn selector, target anchor, or other explicit target.
   - A shelf is not permission to act on whatever the terminal hopes is still nearby.
5. **Ranking and pinning are presentation, not truth**
   - Frecency, stars, pins, recency boosts, and search ranking are excellent ergonomics.
   - They should affect ordering and visibility, not redefine what an entry fundamentally means.
6. **Cross-run persistence is optional and should stay explicit**
   - Persisting shelves across terminal restarts can be great, but it should remain a deliberate local storage choice.
   - Persisted entries should stay visibly remembered and should not silently inherit stronger trust than session-local data.
7. **Sensitive shelves deserve scope and storage caution**
   - Command text, working directories, and object refs may themselves be sensitive.
   - Steward should be able to scope, omit, redact, or locally fence shelf persistence instead of assuming all convenience memory is harmless.
8. **One shelf seam beats many ad hoc recent lists**
   - Recent commands, recent directories, recent frames, and recent Steward objects all want the same anti-folklore discipline.
   - Steward should prefer one tiny remembered-shelf posture over many accidental per-widget memories.

## Phase-1 non-goals
- a universal command-history database for every shell and host;
- synchronizing remembered shelves across devices by default;
- treating remembered entries as proof that the referenced run, host, cwd, or authority is still live;
- freezing one mandatory frecency or ranking algorithm;
- turning recent-history UI into an ambient control plane.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `session-variable-posture-v0.md`
- `context-inheritance-posture-v0.md`
- `spawn-selector-posture-v0.md`
- `spawn-palette-posture-v0.md`
- `target-anchor-posture-v0.md`
- `precision-fence-posture-v0.md`
- `chooser-surface-posture-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-ITERM2-ONE-PAGE
- REF-ITERM2-SEMANTIC-HISTORY
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
