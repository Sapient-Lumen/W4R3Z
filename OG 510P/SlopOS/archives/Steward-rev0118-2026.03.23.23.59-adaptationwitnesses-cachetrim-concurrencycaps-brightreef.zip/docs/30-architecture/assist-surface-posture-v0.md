# Assist-surface posture v0

Purpose: define a **tiny assist seam** so quick fixes, recent-command suggestions, current-input help, and similar shell/terminal guidance remain explicit, reviewable, and anchored instead of becoming an ambient second shell.

## Posture
1. **Assist surfaces suggest; they do not silently execute**
   - A terminal may notice a likely next step, such as a missing upstream flag, a port conflict, a known launch recipe, or a likely completion for the current command line.
   - Steward should keep those as explicit user-invoked suggestions, not hidden auto-repair or invisible shell mutation.
2. **Suggestions should bind to exact current context**
   - Input-time assistance belongs to the current editable command line, while post-command quick fixes belong to an exact command frame, output slice, receipt, or replay gate.
   - Steward should resist pane-wide or scrollback-wide folklore where any nearby text can accidentally become the target.
3. **Repair suggestions should prefer reviewed selectors or recipes over synthesized shell text**
   - A helpful action might resolve to a reviewed spawn selector, a replay-gated command card, a known helper recipe, or an exact open/reveal target.
   - Freehand shell text can still exist as a downgrade, but it should stay visibly weaker than exact reviewed action payloads.
4. **Confidence, provenance, and freshness should stay visible**
   - Shell-reported context, manager-known lifecycle state, terminal-local heuristics, extension-provided completions, and regex fallback are not equivalent.
   - Steward should be able to say why a suggestion exists, how fresh it is, and when it has decayed or become stale.
5. **Input-time assist and post-command assist are different seams**
   - Completion/documentation while typing, a recent-command suggestion list, and a repair card after a failed run are all useful.
   - They should stay distinguishable so "help me finish this line" never quietly becomes "rerun this old thing".
6. **Assist UIs may be modal, but should not leak stray keystrokes into the shell**
   - Menus, palettes, quick-picks, or transient key-table modes can be great ways to browse or accept suggestions.
   - The assist surface should trap or ignore unrelated keys while active instead of letting accidental input fall through to the underlying prompt.
7. **Denial and downgrade should be part of the surface**
   - If policy blocks the suggested repair, if the input moved on, or if only a lower-confidence text suggestion remains, the surface should say so explicitly.
   - Silent disappearance or silent fallback is just another form of folklore.
8. **One assist seam beats a pile of mini-wizards**
   - Quick fixes, suggestion menus, command-detail actions, and current-line helpers all want the same anti-folklore discipline.
   - Steward should prefer one small assist-surface posture over many host-specific "smart terminal" exceptions.

## Phase-1 non-goals
- auto-executing repairs or "AI shell" behavior by default;
- a universal package-manager or toolchain diagnosis grammar;
- pretending every completion or quick-fix provider has the same trust level;
- freezing one universal assist UI layout;
- turning suggestion history into ambient authority.

## Adjacent docs
- `action-surface-posture-v0.md`
- `command-frame-posture-v0.md`
- `command-guide-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `replay-gate-posture-v0.md`
- `repair-gate-posture-v0.md`
- `spawn-selector-posture-v0.md`
- `target-anchor-posture-v0.md`
- `precision-fence-posture-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-UPDATE-1072
- REF-VSCODE-UPDATE-1102
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WINDOWS-TERMINAL-ACTIONS
- REF-WEZTERM-AUGMENT-COMMAND-PALETTE
- REF-GHOSTTY-RELEASE-130
