# Precondition-witness posture v0

Purpose: define a **tiny veto-only precondition seam** so reviewed Steward actions can say "apply this only if the exact basis I saw is still true" without turning Steward into an ambient query language, stale control plane, or hidden policy VM.

## Posture
1. **Preconditions are veto-only guards**
   - A precondition witness may only narrow or deny an action.
   - It must not grant authority, widen scope, substitute for reviewed target identity, or become a second approval channel.
2. **The bound basis must be exact and already named**
   - A precondition may bind to exact material already carried or already locally available to the validator, such as a runtime-cycle witness, semantic epoch, observation cursor, target-anchor digest, readiness generation, or comparable explicit local witness.
   - Human prose, mutable UI text, prompt guesses, remote heads, or ambient `latest` lookups are not valid basis.
3. **Evaluation stays local and non-ambient**
   - Steward should not perform remote fetches, filesystem walks, connector discovery, search queries, or hidden cache refresh merely because a precondition was present.
   - Missing basis should fail closed rather than silently broadening the action.
4. **Mismatch must stay visible as its own outcome**
   - If the bound witness no longer matches, the system should surface `precondition-failed`, `stale-anchor`, `wrong-cycle`, `epoch-moved`, or another equally explicit outcome.
   - That is healthier than silently acting on a newer object, auto-refreshing into a different basis, or mutating based on stale shell comfort.
5. **Preconditions are smaller than a query language**
   - Phase 1 should admit only compact mechanically checkable predicates such as equality, inequality, existence, bounded enum membership, or small generation/revision comparisons.
   - Steward should not freeze a general predicate VM, regex/filter language, or embedded policy engine under this seam.
6. **Preconditions complement effect keys rather than replacing them**
   - An effect key answers “is this retry-equivalent to an earlier reviewed effect?”
   - A precondition witness answers “is the exact world this action was fenced against still the one I mean?”
   - The two ideas are related but should stay separate.
7. **Shell and terminal actions should use stale fences honestly**
   - High-value actions such as restart-this-run, stop-this-frame, reveal-the-current-object, or promote-this-observed-command should be allowed to carry exact precondition witnesses.
   - Old chips, receipts, or frames should visibly fail when their basis has moved instead of silently retargeting to whatever looks closest now.
8. **Keep the seam smaller than optimistic-concurrency folklore**
   - One optional witness bundle plus explicit mismatch outcomes is enough for Phase 1.
   - Steward should not freeze a giant compare-and-swap language, distributed lock family, or universal conditional mutation API through this seam.

## Phase-1 non-goals
- a general policy language or predicate VM;
- remote freshness queries triggered by precondition evaluation;
- silently refreshing a stale target to a newer target and proceeding anyway;
- using preconditions as a replacement for reviewed target identity or authority checks;
- a giant cross-host transaction or lock protocol.

## Adjacent docs
- `request-context-posture-v0.md`
- `effect-key-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `target-anchor-posture-v0.md`
- `action-surface-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-HTTP-RFC9110
- REF-K8S-API-CONCEPTS
- REF-ETCD-API-TXN
- REF-AWS-S3-CONDITIONAL-WRITES
