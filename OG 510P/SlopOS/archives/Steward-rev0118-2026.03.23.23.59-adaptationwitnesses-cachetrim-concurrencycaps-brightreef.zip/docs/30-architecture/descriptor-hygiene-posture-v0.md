# Descriptor-hygiene posture v0

Purpose: keep inherited handles, stdio attachments, and shell/terminal control channels explicit so launch and restart do not depend on descriptor accidents or ambient Unix folklore.

## Posture
1. **Inherited handles are authority and must be treated that way**
   - If a child receives a file descriptor, socket, pipe, pseudo-terminal endpoint, or equivalent handle, that is an authority handoff whether or not anyone wrote it down.
   - Steward should treat inherited handles as reviewed launch material, not harmless process trivia.
2. **Phase 1 prefers explicit allowlists over ambient inheritance**
   - Launch should inherit only the descriptors/handles required for stdio roles, declared activation material, or other explicit reviewed channels.
   - “Whatever happened to be open” must not become the normal contract.
3. **Activation-delivered public handles stay distinct from incidental process baggage**
   - Stable inbound handles and bounded continuity material belong to the activation seam, not to a fuzzy bucket of inherited descriptors.
   - Descriptor numbers or host-specific table layout must not become the portable identity story.
4. **Control and notification channels should not leak sideways**
   - Shell/terminal control pipes, manager notification sockets, helper rendezvous channels, and debug/service-owner backchannels should remain scoped to the intended participants.
   - Child processes should not quietly inherit those channels and gain surprising ways to spoof status, observe private traffic, or retain ambient influence.
5. **Restart replays explicit handle meaning only**
   - A restarted component may receive reviewed stdio/activation/continuity material again, but it must not depend on accidental leftovers from a parent shell, terminal, or previous runtime cycle.
6. **Host-local bulk cleanup tricks are implementation detail, not portable meaning**
   - Some hosts can aggressively close or mark descriptor ranges under the membrane before `exec`, which is excellent hygiene.
   - Steward should steal that discipline locally without freezing one host-specific syscall or numeric descriptor story into the public contract.
7. **Descriptor hygiene failures should be testable and explainable**
   - Leak tests, launch-audit checks, and regression evidence are healthier than folklore such as “we set CLOEXEC somewhere, probably.”
   - Phase 1 should prefer explicit reviewable launch evidence over hopes about host defaults.
8. **Shell/terminal comfort must not widen hidden authority**
   - Remote comfort, command palettes, prompt markers, and semantic side channels are valuable, but they should not smuggle extra inherited handles or covert control paths into launched work.

## Phase-1 non-goals
- a giant portable file-descriptor table schema;
- promising identical numeric fd/handle assignments across hosts or runtimes;
- letting arbitrary parent-shell, terminal, or helper descriptors leak into the reviewed component contract;
- treating terminal attachment or manager notification sockets as an implicit lifecycle control API;
- a generic export/search/watch broker for inherited descriptors outside explicit activation seams.

## Adjacent docs
- `launch-context-posture-v0.md`
- `activation-posture-v0.md`
- `status-channel-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `context-handoff-posture-v0.md`
- `capability-handshake-posture-v0.md`

## References
- REF-SYSTEMD-DAEMON
- REF-SYSTEMD-SD-LISTEN-FDS
- REF-SD-NOTIFY
- REF-APPLE-INHERITING-FDS
- REF-GHOSTTY-RELEASE-110
- REF-LINUX-CLOSE-RANGE
