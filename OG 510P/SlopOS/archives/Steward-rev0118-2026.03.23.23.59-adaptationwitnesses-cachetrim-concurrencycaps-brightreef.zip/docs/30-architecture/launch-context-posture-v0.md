# Launch context posture v0

Purpose: keep restart and activation honest by making component launch context explicit instead of letting ambient shell/session state become the product contract.

## Posture
1. **Entrypoints are reviewed selectors, not shell command folklore**
   - A Steward-managed component launches from a reviewed `entry` selector tied to the component artifact, not from ad hoc shell command strings, alias expansion, rc-file behavior, or ambient `PATH` tricks.
2. **Restart replays explicit launch context only**
   - A restart may replay the component manifest, explicit Steward-owned launch context, and delivered activation/continuity material.
   - A restart must not quietly depend on mutable login-shell, terminal-session, or host-manager ambient state that was never part of the reviewed component contract.
3. **Phase 1 keeps the portable launch baseline intentionally small**
   - Environment shaping, cwd rules, stdio topology, terminal/session attachment, resource tuning, and similar launch details remain implementation detail unless Steward later gives them an explicit narrow seam.
   - Until then, those details must not silently become portable meaning or restart-critical folklore.
4. **Runtime adapters and runners stay visible as a seam**
   - A runtime adapter may translate Steward launch intent into host-specific spawn mechanisms, but it must not widen the portable contract by inheriting arbitrary ambient process/session baggage.
5. **Fresh launch beats resurrection mythology**
   - Activation and continuity escrow may preserve bounded allowlisted continuity, but they do not erase that a restarted component is a fresh runtime cycle with fresh accountability.
6. **Manager-wide mutable environment is not the constitution**
   - Host managers may offer global or ambient execution-environment knobs, but Steward should keep its portable semantics tied to explicit component-owned launch meaning rather than mutable manager-global baggage.
7. **Phase 1 refuses a giant launch-profile grammar**
   - Steward should learn from SlopOS's no-ambient launch discipline, but it should not prematurely clone the parent archive's many launch-boundary adjuncts.
   - If pressure later proves that one launch detail needs portable semantics, add one explicit narrow seam rather than a giant everything-about-spawn language.

## Phase-1 non-goals
- a generic shell-command-string launch contract;
- portable `PATH` search rules as component identity;
- a giant env/cwd/stdio/tty/rlimit/credential launch-profile DSL;
- adopting arbitrary login-shell or user-session state as the normal restart baseline;
- pretending continuity escrow means whole-process resurrection.

## Adjacent docs
- `design-principles-v0.md`
- `non-decisions-v0.md`
- `component-manifest-schema-v0.md`
- `supervision-posture-v0.md`
- `activation-posture-v0.md`
- `descriptor-hygiene-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`

## References
- REF-SYSTEMD-DAEMON
- REF-SYSTEMD-EXEC
- REF-LAUNCHD-JOBS
- REF-FUCHSIA-RUNNER
- REF-FUCHSIA-LIFECYCLE
