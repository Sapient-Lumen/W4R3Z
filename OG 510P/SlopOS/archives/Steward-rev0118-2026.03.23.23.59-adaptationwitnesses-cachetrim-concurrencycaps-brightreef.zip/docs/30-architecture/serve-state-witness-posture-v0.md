# Serve-state witness posture v0

Purpose: define a **tiny serve-state witness seam** so `serving`, `serving+terminating`, `draining`, `maintenance`, `degraded`, or `not serving` truth can stay visibly separate from mere process liveness, readiness folklore, and discoverability.

This seam stays intentionally small. It does **not** invent a load balancer API, service-mesh policy plane, traffic-weight grammar, or giant health algebra. It only says that when a runtime or adapter can honestly report how a component is handling *new work right now*, Steward should preserve that truth instead of flattening everything into one `ready` bit.

## Posture
1. **Serving truth is not process liveness or publication truth**
   - A component may still be alive while intentionally refusing new work, and it may still be discoverable while no longer suitable for ordinary traffic.
   - Steward should keep serve-state separate from runtime-cycle identity, readiness evidence, and presence advertisement.
2. **New-work admission and current-work continuation are different questions**
   - A component may stop admitting new work while still finishing current sessions or draining long-lived connections.
   - `draining` therefore means something usefully different from both `serving` and `stopped`.
3. **Terminating-but-still-serving is a real state when the substrate can prove it**
   - Some runtimes can honestly say that a target is terminating yet still serving responses for active drain or last-endpoint safety.
   - Steward should preserve that truth instead of forcing every terminating path to look simply `not ready`.
4. **Degraded or limited serving should not be smuggled into a boolean**
   - `degraded`, `maintenance`, `read-only`, or similar limited-service truths are healthier than teaching users to infer everything from one green badge.
   - If an adapter can only prove `serving` or `not serving`, Steward may say that, but it should not fabricate a richer story.
5. **Serve-state must stay scoped and attributable**
   - A serve-state witness should say what exact component, endpoint group, pane-bound target, or reviewed subject it applies to.
   - Optional reason, message, or provider/source notes are healthier than silent transitions.
6. **Serve-state should stay smaller than health or rollout policy**
   - Steward may reuse one tiny serve-state shape across listeners, service endpoints, or shell-visible receipts.
   - It should not thereby freeze a universal traffic-engineering, service-discovery, or rollout-weight family.
7. **Shell and terminal chrome should make serve-state legible**
   - Execution-ground cards, command guides, and receipts may show compact truth such as `serving`, `serving+terminating`, `draining`, `maintenance`, `degraded`, or `not serving`.
   - These labels explain present admission posture; they do not become a portable traffic-control plane.
8. **Unknown is healthier than false precision**
   - Some substrates can distinguish `serving+terminating`, `draining`, and `maintenance` precisely.
   - Others may only know `serving`, `not serving`, or `unknown`. Steward should preserve that honesty.
9. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional `serve_state` label, exact scope, and optional `reason` or `source_class` when the adapter can prove them.
   - Richer balancing, weighting, and failover choreography remain intentionally undecided.

## Phase-1 non-goals
- a portable load balancer, proxy, or service-mesh API;
- a universal weighting / canary / endpoint-selection grammar;
- treating `serving` as proof of settlement, promotion, or headroom;
- requiring every runtime to distinguish degraded, draining, and maintenance separately;
- silently inferring serve-state from logs, retries, or ordinary process existence.

## Adjacent docs
- `readiness-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `presence-advertisement-posture-v0.md`
- `hold-state-posture-v0.md`
- `revision-settlement-posture-v0.md`
- `execution-ground-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-POD-LIFECYCLE
- REF-K8S-ENDPOINTSLICES
- REF-ENVOY-HEALTHCHECKING
- REF-HAPROXY-MANAGEMENT
- REF-SYSTEMCTL
