# Clipboard-surface posture v0

Purpose: define a **tiny clipboard / transfer seam** so copy, paste, and remote clipboard flows stay exact, provenance-labeled, and policy-bounded instead of becoming ambient terminal folklore.

## Posture
1. **Clipboard flows are authority crossings, not neutral convenience**
   - Copying from a terminal or pasting into one may move data between processes, hosts, windows, helper layers, or remote sessions.
   - Steward should treat those flows as explicit user-facing transfers, not as invisible PTY trivia.
2. **Exact object copy should be stronger than scraped text copy**
   - Copying the current command, exact output for one frame, a reviewed selector, or a receipt reference is meaningfully safer than drag-selecting nearby bytes and hoping the structure survives.
   - Steward should prefer exact object-backed copy surfaces when it has them, while still allowing raw text as a visible downgrade.
3. **Paste mode matters**
   - Typed input, pasted text, staged command blocks, and reviewed selector insertion are different actions.
   - Steward should keep those modes distinct and preserve bracketed-paste style safety instead of collapsing everything into “characters arrived somehow”.
4. **Remote clipboard is a policy surface**
   - OSC 52 and richer clipboard protocols are useful, especially across SSH or multiplexer hops.
   - Steward should keep remote clipboard access explicit, denyable, and inspectable instead of assuming every shell or remote program gets ambient clipboard authority.
5. **Auto-copy and selection behavior are modes, not defaults of nature**
   - Copy-on-select, rectangular selection trimming, or command-aware right-click selection can all be delightful.
   - Steward should treat them as explicit UI policy with visible diagnostics, not as silent facts users are expected to infer.
6. **Typed or rich clipboard payloads should preserve provenance**
   - A clipboard payload might be plain text, a structured selector, a command card, an exact output slice, or a richer document format.
   - Steward should preserve which kind of thing was copied and what exact anchor it came from instead of flattening every transfer into anonymous bytes too early.
7. **Clipboard downgrade should be honest**
   - Sometimes only raw text will survive across a host boundary, app boundary, or older terminal.
   - Steward should label that downgrade clearly and avoid pretending the receiving side still has exact object identity.
8. **One clipboard seam beats many accidental copy/paste exceptions**
   - Copy current command/output, chooser exports, remote clipboard helpers, paste previews, and shell staging all want the same anti-folklore discipline.
   - Steward should prefer one small clipboard-surface posture over a pile of host-specific exceptions.

## Phase-1 non-goals
- a universal rich-content clipboard schema for every host app;
- treating clipboard permissions as a complete security boundary by themselves;
- automatic paste sanitization that silently rewrites commands without explanation;
- guaranteeing lossless round-trips for every structured clipboard payload across every terminal;
- making remote clipboard access ambient for all shells or helper programs.

## Adjacent docs
- `chooser-surface-posture-v0.md`
- `session-injection-posture-v0.md`
- `command-frame-posture-v0.md`
- `context-handoff-posture-v0.md`
- `target-anchor-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `precision-fence-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-KITTY-CLIPBOARD
- REF-GHOSTTY-OSC52
- REF-WINDOWS-TERMINAL-INTERACTION
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-VSCODE-SHELL-INTEGRATION
- REF-XTERM-BRACKETED-PASTE
- REF-BASH-READLINE-INIT
