# Holder-bound-grant posture v0

Purpose: define a **tiny holder-proof seam** so some exact live grants can require proof from the current presenter or holder instead of behaving like replayable bearer material, without turning Steward into a portable proof-of-possession, token-binding, or key-management platform.

## Posture
1. **Bearer and holder-bound grants stay visibly distinct**
   - A holder-bound grant says “this exact live grant is only usable when the presenter can prove it is the intended current holder”.
   - Steward should not blur that into ordinary bearer semantics where copied raw material alone is enough.
2. **Holder proof complements, but does not replace, other exact witnesses**
   - Grant handles answer “which exact transient claim object is this?”
   - Renewal windows answer “is this exact claim still being refreshed?”
   - Fence tokens answer “has this claim lineage moved to a newer holder?”
   - Precondition witnesses answer “is the world I meant still the world I saw?”
   - Holder proof answers “is the thing presenting this grant still the expected holder?”
3. **Binding scope stays narrow**
   - Binding should be specific to one issuer-local grant lineage and one reviewed holder context such as a pane/session, helper, peer, key, or equivalent proof-bearing presenter.
   - Steward should not imply one global key registry or one universal cross-host presenter identity.
4. **Copied history must not recreate live authority**
   - Old receipts, transcript frames, copied raw values, or stale shell variables should not be enough to use a holder-bound grant later.
   - Historical material may explain that a grant once existed, but current live use still requires current holder proof.
5. **Failure should be exact and fail closed**
   - Missing proof, wrong-holder proof, expired proof, or holder-rotated outcomes should remain visibly different instead of collapsing into one vague denial.
   - If the platform cannot verify the expected holder proof, Steward should fail closed or downgrade only through an explicit separately reviewed path.
6. **Rotation or rebind must be explicit**
   - If a grant needs a different holder, Steward should mint or derive a new reviewed grant instance or explicit rebind outcome.
   - Silent in-place mutation from one holder to another is worse hygiene than a fresh issuance with clear lineage.
7. **Target and audience narrowing still matter**
   - Holder binding is not a substitute for exact target selection, audience narrowing, attenuation, or use/time budgets.
   - It only reduces replay by the wrong presenter; it does not solve overbroad rights on its own.
8. **Keep the public seam smaller than a proof-of-possession platform**
   - Steward may allow adapters to use cryptographic sender-constrained or holder-bound machinery under the membrane.
   - The public posture should stay tiny: exact live grants may optionally require current holder proof, without freezing a portable DPoP, mTLS, token-introspection, or key-lifecycle family.
9. **Shell chrome should make holder state obvious**
   - `holder-proof-required`, `proof-valid`, `proof-missing`, `wrong-holder`, `holder-rotated`, and `bearer-only` should remain visibly different affordances.
   - That honesty is healthier than letting old chips, copied env, or detached helpers look replay-safe when they are not.

## Phase-1 non-goals
- a portable public-key or certificate-management plane;
- a universal proof-of-possession protocol;
- a portable token-introspection or token-revocation service;
- mandatory holder-binding for all grants or all actions;
- a global presenter identity or cross-host key registry.

## Adjacent docs
- `grant-handle-posture-v0.md`
- `consumable-grant-posture-v0.md`
- `attenuated-grant-posture-v0.md`
- `renewal-window-posture-v0.md`
- `fence-token-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `request-context-posture-v0.md`
- `action-surface-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-RFC9449-DPOP
- REF-RFC8705-MTLS
- REF-RFC9700-OAUTH-SECURITY-BCP
