# Request-context posture v0

Purpose: define a **tiny request-context seam** so activation, chooser detours, automation, and other mediated operations can carry exact identity, optional deadline, and explicit cancellation without turning Steward into a giant RPC framework.

## Posture
1. **Request identity should stay explicit and local to the work**
   - A lifecycle-affecting request should be able to carry one exact request id or anchor that the shell, manager, and receipts can all point at.
   - That identity is not the same thing as the target component, the current runtime cycle, or a durable job queue entry.
2. **Deadlines should be allowed, not assumed**
   - Some activation or mediated UI flows benefit from a caller saying how long it is still willing to wait.
   - Steward should allow compact deadline or timeout hints without requiring every request to carry one or pretending every runtime enforces them identically.
3. **Cancellation should be explicit and attributable**
   - If the requester is no longer interested, the system should be able to say so with one exact cancel action and one visible outcome such as `cancelled`, `completed-before-cancel`, or `deadline-expired`.
   - Cancellation should not require log archaeology or shell folklore like “the window probably closed”.
4. **Derived work should be able to inherit the request budget**
   - If one exact request activates a component, opens a chooser, or fans out to helper work, the child work should be able to inherit remaining deadline/cancellation context when that meaning is useful.
   - Steward should prefer this over spawning unbounded background work that forgets why it was started.
5. **Request context should stay smaller than a generic RPC metadata plane**
   - Exact request id, optional deadline, optional cancellation handle, and a tiny cause chain are enough for Phase 1.
   - If a reviewed mutation also wants retry-safe duplicate suppression, that should stay a separate effect-key seam instead of quietly turning request ids into a universal transaction ledger.
   - Steward should not freeze a giant portable metadata bag, tracing system, or universal error taxonomy through this seam.
6. **Expiry and cancellation are not the same as failure**
   - A timed-out chooser, a user-cancelled approval sheet, and a component crash are different facts.
   - Steward should keep request outcomes separate from runtime health and lifecycle state.
7. **Live mediated requests may grow one exact closeable handle**
   - If a chooser, approval sheet, or similar detour stays open, the requester should be able to receive one exact handle for that live interaction and later close or revisit it.
   - Steward should prefer this over vague modal state or implicit ownership by whichever window happens to still be focused.
8. **The shell should be able to point at in-flight requests honestly**
   - If a command launched a mediated request, the transcript and chrome should be able to show one small pending object with current state, budget, and exact cancel/revisit affordances.
   - That is healthier than letting asynchronous work dissolve into cursor motion and modal side effects.
9. **Local implementations may be richer than the portable contract**
   - Some hosts may propagate deadlines automatically, attach richer opaque context, or expose stronger request objects.
   - Steward should steal those ideas locally while keeping the public contract tiny and exact.

## Phase-1 non-goals
- a universal RPC context or tracing standard;
- a giant portable error-code taxonomy for every request class;
- durable queueing or retry semantics for arbitrary request objects;
- forcing every request to become a long-lived handle object;
- requiring every request to carry a deadline;
- confusing request expiry/cancel with lifecycle failure or health truth.

## Adjacent docs
- `request-activation-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `automation-surface-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `attention-hint-posture-v0.md`
- `grant-handle-posture-v0.md`
- `effect-key-posture-v0.md`
- `stop-deferral-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-GRPC-DEADLINES
- REF-GRPC-CANCELLATION
- REF-XDG-PORTAL-REQUEST
- REF-XDG-PORTAL-SESSION
- REF-DBUS-SYSTEM-ACTIVATION
