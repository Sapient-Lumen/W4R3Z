# Replay-gate posture v0

Purpose: define a **tiny reviewed replay seam** so remembered, restored, or suspended commands can reopen as explicit pending actions instead of silently re-executing from stale shell folklore.

## Posture
1. **Remembered or restored commands are recipes, not current truth**
   - A command recovered from a workspace snapshot, remembered shelf, transcript landmark, or command pane is a remembered recipe plus whatever exact context fields survived.
   - Steward should not pretend that remembered command text, cwd, domain, environment, or remote hop state is still live merely because it can be displayed.
2. **Replay should default to pending review, not immediate execution**
   - When a higher-value command is reopened from remembered state, Steward should be able to surface it as a pending action with exact context labels instead of running it immediately.
   - A tiny gate is healthier than ambient “resume means rerun” folklore.
3. **Pending replay should show the best exact context Steward actually has**
   - Good replay cards can show command text, cwd source class, domain or hop lineage, provenance, freshness, receipt refs, and why the replay exists (restore, remembered shelf, helper pane, repair follow-up, and so on).
   - Missing fields should stay visibly missing or downgraded instead of being filled in from comfort assumptions.
4. **Replay still resolves through current selectors and policy**
   - Approving a replay should flow through current spawn selectors, context-inheritance rules, repair gates, and policy fences.
   - The remembered command is not permission to smuggle stale `$SHELL`, mutated environment, hidden descriptors, or old trust state back into the architecture.
5. **Force-run or auto-run should stay explicit and rare**
   - Some workflows may deliberately skip the review gate, but that should be an explicit selector, policy choice, or one-shot override.
   - It should not become the invisible default for restore or history surfaces.
6. **Suspended command surfaces can be first-class workspace objects**
   - It is useful to keep a build, test, migration, or helper command visible in a workspace before it runs.
   - Steward should allow pending command surfaces to remain explicit objects instead of reducing them to prose notes or hidden palette recipes.
7. **Replay results need their own receipts and truth labels**
   - Once the command actually runs, the resulting frame, receipts, witnesses, and output belong to the new execution.
   - The UI should be able to say pending, launched, downgraded, denied, or failed-to-launch instead of smearing old and new runs together.
8. **A replay gate is smaller than a generic task queue**
   - The point is a narrow anti-folklore seam for remembered shell work, not a universal scheduler or workflow engine.
   - Steward should keep this surface small and composable with existing shelves, snapshots, palettes, and anchors.

## Phase-1 non-goals
- freezing a universal serialized-command format for every shell/runtime edge case;
- automatically rerunning restored or remembered commands by default;
- pretending remembered environment or cwd fields are always exact live launch truth;
- turning replay cards into a generic durable job queue or workflow language.

## Adjacent docs
- `workspace-snapshot-posture-v0.md`
- `remembered-shelf-posture-v0.md`
- `spawn-selector-posture-v0.md`
- `spawn-palette-posture-v0.md`
- `command-frame-posture-v0.md`
- `precision-fence-posture-v0.md`
- `repair-gate-posture-v0.md`
- `context-handoff-posture-v0.md`

## References
- REF-ZELLIJ-FEATURES
- REF-ZELLIJ-SESSION-RESURRECTION
- REF-VSCODE-UPDATE-1109
- REF-VSCODE-TERMINAL-ADVANCED
- REF-WEZTERM-LAUNCH-MENU
