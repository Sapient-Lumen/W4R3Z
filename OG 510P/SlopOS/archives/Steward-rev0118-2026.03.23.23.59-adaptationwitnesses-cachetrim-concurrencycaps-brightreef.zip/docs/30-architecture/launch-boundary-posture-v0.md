# Launch-boundary posture v0

Purpose: keep **current possession**, **launch eligibility**, **selected-for-child delivery**, and **receipt/history** separate so services stay explicit and restartable without ambient inheritance folklore.

## Posture
1. **Held here is the default truth**
   - A shell, helper, or supervisor may currently hold a handle, activation kit, cwd root, or other launch-relevant object.
   - That must not imply that the next child automatically receives it.
2. **Crossing the launch boundary is a reviewed act**
   - Delivering something to a child is an authority handoff, not a background implementation detail.
   - Steward should be able to say `held here only`, `eligible`, `selected for child`, or `receipt only` instead of collapsing everything into “it was inherited”.
3. **Eligibility stays separate from actual selection**
   - Some objects may be allowed to cross a launch boundary in principle while still not being chosen for this concrete run.
   - Steward should keep that distinction visible because it matters for review, debugging, and stale-history honesty.
4. **Launch crossing is not durability and not delegation**
   - One reviewed child delivery does not by itself create a durable reopen story, a reusable grant, or a broader delegation right.
   - Receipts may remember the crossing without reviving it later.
5. **Child-local names stay separate from the thing that crossed**
   - A child-local slot, activation key, stdio role, or other binding name is not the same thing as the underlying object identity.
   - Steward should avoid folklore such as “fd 3 always means X”.
6. **Restarts replay explicit crossing meaning only**
   - If a restart receives reviewed launch material again, that is because Steward or a runtime adapter explicitly redelivered it.
   - A restart must not depend on accidental parent-shell baggage or leftover inheritable state.
7. **Shell chrome should be able to describe boundary state honestly**
   - Ground cards, frame details, or launch receipts should be able to say `held here`, `launch-shuttered`, `selected for child`, `manager-redelivered`, or `receipt only`.
   - That helps the custom shell feel brilliant without turning chrome into lifecycle authority.
8. **Host-local shutter mechanics stay under the membrane**
   - Hosts may use close-on-exec flags, explicit spawn actions, manager-owned reconstruction, or other tricks to keep the launch boundary tight.
   - Steward should steal the hygiene while refusing to freeze one host-specific mechanism into the public contract.
9. **Current possession and launch basis are related but not identical**
   - Exact exec objects, cwd roots, startup credentials, stdio attachments, and activation material are all launch-basis classes.
   - Steward should keep room to describe those classes without prematurely freezing a giant launch-basis taxonomy.
10. **Review beats folklore for helper shells too**
   - “Open helper here” or “rerun here” should reuse explicit context selectors and reviewed crossing state.
   - They should not smuggle ambient handles, mutable environment, or hidden launch baggage across the boundary.

## Phase-1 non-goals
- a giant portable child-slot or descriptor-table schema;
- a final public taxonomy for every possible launch-basis class;
- treating one launch crossing as durable delegation or reopen authority;
- standardizing one host-specific shutter mechanism such as `FD_CLOEXEC` or spawn-file-action details;
- a portable process-inventory or adopt-arbitrary-process story.

## Adjacent docs
- `launch-context-posture-v0.md`
- `descriptor-hygiene-posture-v0.md`
- `activation-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `execution-ground-posture-v0.md`
- `spawn-selector-posture-v0.md`
- `context-inheritance-posture-v0.md`
- `replay-gate-posture-v0.md`

## References
- REF-APPLE-INHERITING-FDS
- REF-LAUNCH-ACTIVATE-SOCKET
- REF-LAUNCHD-JOBS
- REF-SYSTEMD-SD-LISTEN-FDS
- REF-SYSTEMD-DAEMON
- REF-LINUX-CLOSE-RANGE
