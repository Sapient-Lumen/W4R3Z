# Hold-state posture v0

Purpose: define a **tiny hold-state seam** so deliberate `paused`, `draining`, `frozen`, `masked`, or other exact start-prevented states stay visibly separate from `stalled`, `failed`, `repair required`, or ordinary `off` truth.

This seam stays intentionally small. It does **not** invent a universal maintenance scheduler, inhibit protocol, rollout controller, or host-global enable/disable grammar. It only says that when progress or lifecycle movement is intentionally being constrained, Steward should be able to say *which kind of hold is happening*, what that means for current work versus new work, and how the hold might end.

## Posture
1. **Deliberate hold is not stall or failure**
   - A reviewed or policy-imposed hold should not masquerade as mysterious no-progress state.
   - Steward should keep `held`, `stalled`, `failed`, `repair required`, and `off` visibly different instead of laundering operator intent into fake diagnosis.
2. **Hold mode must stay explicit when knowable**
   - `paused`, `draining`, `frozen`, and `start prevented` are materially different truths.
   - If an adapter can only prove `held`, Steward may say that, but it should not silently collapse richer local truth into one vague badge.
3. **Current work and new work are different questions**
   - A paused resource may keep current service state functioning while reconciliation or rollout is withheld.
   - A draining resource may stop new admissions while allowing migration, completion, or explicit quiesce of current work.
   - A frozen resource suspends execution itself.
   - A masked or otherwise start-prevented resource blocks future activation even if no work is currently running.
4. **Resume paths should stay mode-specific**
   - `resume`, `undrain`, `thaw`, and `unmask` are not interchangeable even when they all feel like “make it go again”.
   - Steward should keep those paths distinguishable instead of teaching users one mythical `unhold` button that hides what is really changing.
5. **Hold truth must stay scoped and attributable**
   - A hold witness should say what exact component, node, pane, or activation slot it applies to.
   - When the footing can prove it, optional reason, message, deadline, or requested-by notes are healthier than silent suspension.
6. **Hold state should not silently widen into authority**
   - Observing that something is paused, draining, or frozen does not itself grant resume, thaw, force-stop, or bypass rights.
   - Shell chrome may explain the hold, but action still belongs to explicit reviewed lanes.
7. **Shell and terminal chrome should make holds legible**
   - Execution-ground cards, command guides, and receipts may show compact truth such as `paused`, `draining`, `frozen`, `masked`, `ineligible`, `held until 14:00`, or `resume required`.
   - Those labels explain the operational posture; they do not become a portable control plane.
8. **This seam is smaller than a maintenance family**
   - Steward may reuse one tiny hold-state shape across rollout pause, drain, freeze, or start-prevented situations.
   - It should not thereby freeze a universal maintenance calendar, inhibit protocol, disable-policy algebra, or evacuation planner.
9. **Unknown is healthier than false precision**
   - Some adapters can distinguish `paused` from `draining` or `masked` precisely.
   - Others may only know `held` or `start prevented`. Steward should preserve that honesty.
10. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional `hold_state` label, exact scope, and optional `reason`, `until`, or `resume_hint` when the adapter can prove them.
   - Richer maintenance choreography remains intentionally undecided.

## Phase-1 non-goals
- a universal maintenance-window scheduler;
- a portable disable/enable/mask policy algebra;
- a generic drain/evacuation planner or migration grammar;
- treating hold labels as proof of failure or operator approval;
- forcing every runtime to distinguish pause, drain, freeze, and mask separately.

## Adjacent docs
- `progress-window-posture-v0.md`
- `quiesce-posture-v0.md`
- `stop-deferral-posture-v0.md`
- `restart-budget-posture-v0.md`
- `repair-gate-posture-v0.md`
- `headroom-witness-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-ROLLOUT-PAUSE
- REF-K8S-ROLLOUT-RESUME
- REF-K8S-DEPLOYMENT
- REF-NOMAD-NODE-DRAIN
- REF-SYSTEMCTL
- REF-SYSTEMD-UNIT
