# Dynamic-condition posture v0

Purpose: keep Steward lifecycle and activation semantics honest when components depend on changing external conditions such as network reachability, peer availability, human presence, lease state, or attached-terminal context.

## Posture
1. **Dynamic conditions are observations, not boot-order facts**
   - Conditions that can appear, disappear, or degrade at runtime should not harden into ambient “start after X and you are fine forever” folklore.
2. **Waiting on a condition belongs in explicit status/readiness, not hidden dependency magic**
   - A component may be running yet honestly report `waiting`, `degraded`, or `ready=false` because some external condition is absent.
   - Steward should prefer explicit current-state reporting over static dependency mythology.
3. **Activation and restart remain explicit even when conditions are absent**
   - Steward may activate or restart a component into a state where it still waits for a dynamic condition.
   - Successful spawn or activation delivery must not be treated as proof that the surrounding world is currently usable.
4. **Condition loss after startup stays part of the truth**
   - If a network, peer, token, mount, or user-presence condition later disappears, the component must be able to return to an explicit waiting/degraded story rather than pretending dependencies mattered only at boot.
5. **Phase 1 declines a giant portable dependency planner**
   - Steward does not yet freeze a universal graph language for every external condition, target, timer, or policy gate.
   - Where a narrow ordering rule is eventually needed, it should arrive as one explicit seam instead of a hidden dependency cosmology.
6. **Adapters may shape local policy, but portable meaning stays narrow**
   - Host adapters may use local backoff, watch APIs, or orchestration hints to avoid noisy retries.
   - Those implementation details must not silently widen Steward's portable contract.
7. **Condition truth should compose with repair and quiesce, not bypass them**
   - A component that is cooling down, draining, or repair-required can also be waiting on a dynamic condition; these explanations should remain explicit instead of collapsing into one opaque state bit.

## Phase-1 non-goals
- a universal “network-online” or “peer-ready” dependency target language;
- a generic watch bus for all dynamic external conditions;
- freezing ambient start-order folklore as the portable meaning of readiness;
- treating successful activation as proof that dynamic dependencies are stable;
- importing a giant orchestration/dependency DSL before the smaller lifecycle seams are proven.

## Adjacent docs
- `design-principles-v0.md`
- `non-decisions-v0.md`
- `supervision-posture-v0.md`
- `activation-posture-v0.md`
- `readiness-posture-v0.md`
- `activity-accounting-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `repair-gate-posture-v0.md`

## References
- REF-LAUNCHD-JOBS
- REF-K8S-PROBES
- REF-DINIT-SERVICE
