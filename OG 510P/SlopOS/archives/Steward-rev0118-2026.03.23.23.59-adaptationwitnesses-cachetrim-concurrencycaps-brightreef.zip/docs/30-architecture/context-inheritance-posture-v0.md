# Context-inheritance posture v0

Purpose: define a **tiny explicit spawn-context seam** for tabs, splits, windows, reruns, and other shell-launched actions so cwd, domain, and hop-context inheritance stay policy-bounded and reviewable instead of becoming pane folklore.

## Posture
1. **Inheritance is an explicit action choice, not ambient truth**
   - Opening a new tab, split, window, rerun, or helper shell may request inheritance of context from an exact frame or pane.
   - Steward should resist a worldview where every spawn silently clones whatever the current terminal happened to remember.
2. **Keep inherited fields few and nameable**
   - Useful inherited fields include cwd, spawn domain or remote hop lineage, and maybe a reviewed profile selector.
   - Phase 1 should avoid ambient inheritance of arbitrary environment, login-session baggage, or shell-local side effects.
3. **Cwd inheritance and domain inheritance are different choices**
   - “Start in the same directory” and “start in the same local/remote execution domain” are related but not identical.
   - Steward should be free to expose them separately instead of collapsing both into one vague “same context” switch.
4. **Bind inheritance to exact anchors when possible**
   - A frame-local action should prefer the cwd, hop lineage, or target data attached to that exact frame or clicked line.
   - Pane-wide remembered state is a fallback, not the design center.
5. **Current, reported, and remembered context should stay distinguishable**
   - If a spawn inherits context that is fresh and exact, the UI can say so.
   - If the context is merely shell-reported, terminal-reconstructed, or remembered from an older frame, Steward should label that honestly.
6. **Policy may deny, trim, or downgrade inheritance**
   - Untrusted, unresolved, or policy-disallowed context may force Steward to drop inherited cwd, refuse remote-domain carryover, or fall back to a safer default profile.
   - Denial should be explicit rather than hidden.
7. **Fallbacks should fail honest**
   - If same-cwd or same-domain inheritance cannot be resolved, Steward should be allowed to fall back to default local domain, default cwd, or home directory.
   - The UI should prefer “opened in default context” over pretending exact inheritance succeeded.
8. **Inheritance should not smuggle authority**
   - Remembered cwd, remote host labels, and semantic frame hints can improve ergonomics.
   - They must not become proof that policy, credentials, or lifecycle authority survived every hop.
9. **One small inheritance seam beats many ad hoc spawn toggles**
   - Tabs, splits, reruns, “open a shell here”, and palette-driven launches all want the same discipline.
   - Steward should prefer one small context-inheritance posture rather than bespoke folklore for each launcher.

## Phase-1 non-goals
- a giant spawn-profile or environment-cloning DSL;
- guaranteeing that every shell, terminal, or hop layer can report inheritable cwd/domain state equally well;
- silently inheriting workspace-local shell config, login-session baggage, or raw authority-bearing capabilities;
- pretending remembered context is current authority;
- freezing one global default that every spawn action must follow.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `session-variable-posture-v0.md`
- `action-surface-posture-v0.md`
- `target-anchor-posture-v0.md`
- `launch-context-posture-v0.md`
- `precision-fence-posture-v0.md`

## References
- REF-GHOSTTY-RELEASE-130
- REF-WEZTERM-SPAWNCOMMAND
- REF-WEZTERM-LAUNCHING-PROGRAMS
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-ITERM2-SEMANTIC-HISTORY
- REF-VSCODE-UPDATE-1109
