# Chrome-lane posture v0

Purpose: define a **tiny presentation seam** for shell/terminal chrome that stays separate from the durable transcript and from lifecycle authority.

## Posture
1. **Chrome is presentation, not the canonical transcript**
   - Badges, tab titles, sticky headers, overview markers, side status cells, and progress chrome may summarize live state.
   - They must not silently become the only durable record of what happened.
2. **Chrome should prefer explicit semantic inputs**
   - Status bars and decorations should consume explicit command frames, cwd reports, confidence signals, anchors, cycle witnesses, and status updates when available.
   - Avoid building important UX on top of prompt scraping, title churn, or BEL folklore.
3. **Freshness must stay visible**
   - Chrome belongs to a semantic epoch / hop lineage / confidence context.
   - When a hop changes, a shell resync happens, or a target goes stale, the chrome should refresh, clear, or visibly downgrade instead of preserving old certainty.
4. **Chrome must stay outside copy/export by default**
   - Copying terminal text or exporting a transcript should preserve the underlying command/output record, not silently inject tab-bar or badge ornament.
   - If chrome is exported, it should do so through an explicit receipt, snapshot, or transcript annotation path.
5. **Low-risk actions may live near chrome; authority must not**
   - A badge, tab chip, or sticky header may focus a pane, reveal a frame, or open a transcript when explicitly bound.
   - It must not become a hidden place where lifecycle mutation happens without the same target binding and stale fencing required elsewhere.
6. **Prompt pollution is a fallback, not the goal**
   - If a terminal lacks richer chrome, a shell may still render compact textual hints.
   - But the design target should prefer status bars, badges, decorations, or other non-transcript surfaces when the path explicitly supports them.
7. **Chrome should stay compact and glanceable**
   - The best uses are tiny: current remote host, cwd summary, active component, recent receipt/cycle badge, command-finished status, warning, or progress-like state.
   - Do not turn the terminal into a dashboard framework before the semantics are earned.
8. **Capability-gated chrome should degrade cleanly**
   - Progress rings, right-status cells, command decorations, or sticky overlays should appear only when live capability says they are supported.
   - Unsupported layers should fall back to simpler observation paths without pretending equivalent precision.
9. **Chrome should compose with anchors and confidence**
   - A tab badge or sticky command header may carry an explicit anchor, confidence badge, or provenance hint.
   - The UI should be allowed to say “approximate”, “stale”, or “older epoch” rather than flattening everything into one pane-wide myth.
10. **Steward should prefer one observational chrome lane over many ad hoc hacks**
   - Status bars, badges, decorations, sticky-scroll-like affordances, and command-finished summary chips all want similar inputs.
   - A tiny shared chrome lane is healthier than every feature inventing its own side channel.

## Phase-1 non-goals
- inventing a giant dashboard/widget framework inside the terminal;
- guaranteeing identical chrome across all terminals or hops;
- treating titles, badges, or decorations as lifecycle truth in their own right;
- forcing copied/exported transcript text to preserve every piece of ornament;
- hiding privileged mutation behind visual chrome.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `status-channel-posture-v0.md`
- `attention-hint-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `target-anchor-posture-v0.md`
- `precision-fence-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`

## References
- REF-ITERM2-STATUS-BAR
- REF-ITERM2-BADGES
- REF-WEZTERM-RIGHT-STATUS
- REF-VSCODE-TERMINAL-BASICS
- REF-VSCODE-UPDATE-1106
- REF-WINDOWS-TERMINAL-TIPS
- REF-WINDOWS-TERMINAL-PROGRESS
