# Session-variable posture v0

Purpose: define a **tiny observational session-variable seam** for shell and terminal context without turning remembered UI state into launch, policy, or lifecycle authority.

## Posture
1. **Session variables are observational context, not authority**
   - They may summarize current cwd, host label, active component, branch, command summary, or similar shell-facing state.
   - They must not silently become reviewed launch input, policy truth, or a substitute for explicit receipts and anchors.
2. **Scope must stay explicit**
   - A variable belongs to a concrete pane / hop path / semantic epoch / publisher scope.
   - Phase 1 should refuse a giant ambient global key-value universe.
3. **Small bounded values beat a giant object store**
   - Favor short strings, enums, compact digests, and tiny labels.
   - If larger structured data is useful later, it should arrive through explicit receipts, anchors, or plumbable objects instead of hiding inside session variables.
4. **Publisher and freshness should be visible**
   - A shell-originated variable should stay distinguishable from terminal-owned, adapter-owned, or reconstructed values.
   - Freshness, semantic epoch, and hop lineage should be allowed to clear, stale-fence, or downgrade values instead of preserving old certainty.
5. **Cross-hop values remain path-scoped**
   - Remote host, username, cwd, and active-context hints are useful, but they must stay attached to the actual hop lineage that reported them.
   - Steward should not flatten remote comfort into a fake single-host truth.
6. **Chrome and palette use is good; hidden control use is not**
   - Session variables are a healthy input for badges, sticky headers, palette filtering, quick titles, or recent-context shelves.
   - They should not become a hidden side door for privileged lifecycle mutation.
7. **Unknown variables should degrade by safe omission**
   - Unsupported or unrecognized names should be ignored or hidden, not treated as corruption.
   - Richer variable-driven UX should be capability-gated and optional.
8. **Copy/export should stay explicit**
   - Ordinary transcript copy should preserve the underlying command/output truth, not silently smuggle session-variable ornament.
   - If variables are exported, they should travel through an explicit context-handoff or chrome snapshot path.
9. **Remembered context is allowed, but it stays remembered context**
   - Recent directories, recent component ids, or host-scoped command shelves can make the shell feel brilliant.
   - They should remain visibly remembered context rather than proof that the current pane still has the same authority or exact working state.
10. **Session variables should compose with anchors and confidence**
   - High-value actions should still bind to exact frames, receipts, transcript spans, or run witnesses.
   - A variable may help find or label the target, but it should not replace exact target binding.

## Phase-1 non-goals
- a giant terminal-side key-value database;
- turning session variables into reviewed launch input or policy truth;
- assuming every terminal or shell supports the same variable mechanism;
- exporting session-variable ornament in every transcript/copy path;
- using remembered context as proof of current authority.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `chrome-lane-posture-v0.md`
- `command-frame-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `target-anchor-posture-v0.md`
- `context-handoff-posture-v0.md`
- `capability-handshake-posture-v0.md`

## References
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WEZTERM-SHELL-INTEGRATION
- REF-WEZTERM-PANE-USER-VARS
- REF-ITERM2-SHELL-INTEGRATION
- REF-ITERM2-VARIABLES
- REF-ITERM2-STATUS-BAR
