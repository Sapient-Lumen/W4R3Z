# Return-ticket posture v0

Purpose: define a **tiny return-ticket seam** so browser/auth/chooser/editor detours can come back to the originating Steward shell surface as an exact, expiring local resume hint instead of callback folklore or “whatever window was active last”.

## Posture
1. **Return is not callback protocol**
   - A command or proposal may open a browser, chooser, approval sheet, editor, or other mediated detour and later receive some local indication that the detour completed, was canceled, or expired.
   - Steward should keep that as a small shell-side return hint rather than smuggling a portable callback URL, loopback rendezvous, or deep-link bus into generic lifecycle meaning.
2. **Exact tickets beat ambient “go back to whatever was active” behavior**
   - If Steward wants to reconnect a detour with the pane, command frame, proposal card, or pending request that launched it, it should use an exact bounded ticket or handle.
   - Guessing from most-recent focus, window titles, or current cwd is terminal folklore, not durable activation truth.
3. **Tickets should usually be single-use or explicitly reissued**
   - A return ticket that lands one browser result, one chooser result, or one attention wake should generally be consumed when used.
   - Reusable return power should be explicit and rare instead of silently surviving in clipboard, history, or stale chrome.
4. **Return should separate attention from stronger authority**
   - A detour may legitimately return attention to the originating shell surface, reveal a result chip, or re-arm a pending proposal card.
   - That should not silently recreate typing control, lifecycle control, or fresh local intent that has since expired.
5. **Pending and completed detours should stay object-shaped**
   - The shell should be able to show small states such as `pending`, `returned`, `canceled`, `expired`, `stale`, or `consumed` for one exact detour.
   - That is healthier than one vague “auth succeeded somewhere” or “chooser closed” story with no attributable object.
6. **Provider-local activation mechanics stay provider-local**
   - Browsers, compositors, and portal backends may use activation tokens, request handles, restore tokens, or platform-specific focus policy under the membrane.
   - Steward may surface the resulting truth, but it should not pretend those local mechanics are one portable callback or focus-control contract.
7. **Detours should degrade honestly when return cannot rebind**
   - If the original pane is gone, the runtime changed, or the proposal/command frame no longer matches, Steward should still be able to show `result available`, `rebind required`, or `open in witness`.
   - Silent retargeting to some convenient new shell surface would recreate the exact ambient folklore Steward is trying to avoid.
8. **Phase 1 keeps the seam smaller than a workflow family**
   - Steward should not freeze a universal browser callback broker, OAuth helper plane, or general background wakeup system here.
   - The portable seam is only exact local return tickets plus explicit shell-visible outcomes.

## Phase-1 non-goals
- a portable callback URL or loopback redirect contract;
- a generic browser/session roaming protocol;
- silent focus stealing or silent control reacquisition on return;
- durable background wakeup semantics that outlive the reviewed originating surface;
- a universal auth broker or workflow continuation family.

## Adjacent docs
- `proposal-lane-posture-v0.md`
- `attach-continuity-posture-v0.md`
- `request-activation-posture-v0.md`
- `attention-hint-posture-v0.md`
- `context-handoff-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `grant-handle-posture-v0.md`
- `notification-surface-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-XDG-ACTIVATION-V1
- REF-XDG-PORTAL-REQUEST
- REF-XDG-PORTAL-SESSION
- REF-XDG-PORTAL-OPENURI
- REF-XDG-PORTAL-REMOTE-DESKTOP
- REF-RFC8252-NATIVE-APPS
