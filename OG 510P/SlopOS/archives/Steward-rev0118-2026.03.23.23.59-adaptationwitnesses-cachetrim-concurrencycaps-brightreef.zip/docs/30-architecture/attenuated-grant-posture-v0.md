# Attenuated-grant posture v0

Purpose: define a **tiny downscoped-subgrant seam** so an exact currently held grant may produce a narrower descendant grant for one helper, detour, or follow-on action without exposing the parent grant raw or turning Steward into a generic delegation / token-exchange platform.

## Posture
1. **Derived grants may only attenuate**
   - A derived grant may narrow target set, action set, audience, use budget, expiry window, or other reviewed caveats.
   - It must not add rights the parent grant did not already have.
2. **Parent identity and child identity stay distinct**
   - The parent grant, derived grant, request context, and target anchor should remain separately nameable.
   - A child grant is evidence of reviewed derivation, not proof that the parent itself was handed out raw.
3. **Derivation should stay exact and reviewable**
   - If Steward allows derivation at all, the derivation should name the parent lineage, the narrowing facts applied, and the resulting child scope.
   - A shell card or receipt should be able to explain “derived for this helper / this target / this use window” without reconstructing the story from logs.
4. **Parent expiry, revocation, or consumption should still matter**
   - A child grant should not silently outlive parent constraints unless a separately reviewed issuance explicitly says so.
   - Expired, revoked, or already-consumed parent state should fail closed for new derivations.
5. **Target and audience narrowing are first-class**
   - It is often enough to derive a child grant for one exact downstream helper, peer, or resource rather than for every place the parent could reach.
   - Steward should prefer that exact narrowing over ambient helper inheritance.
6. **Time and use budgets may narrow together**
   - A derived grant may carry both a shorter expiry window and a tighter use budget than its parent.
   - That is healthier than copying one broad live grant into a helper and hoping policy somewhere else will trim it later.
7. **Derived grants are not raw-capability export by stealth**
   - This seam exists so helpers can receive less power than the current holder, not the same power with nicer packaging.
   - Historical descriptors or receipts about a derived grant do not by themselves reconstitute current live authority.
8. **Keep the caveat surface tiny in Phase 1**
   - Exact target, audience, action subset, expiry, and use budget are enough for now.
   - Steward should avoid freezing a giant general caveat DSL, claim algebra, or policy language through this seam.
9. **Visible outcomes matter**
   - `derived`, `denied-not-attenuable`, `parent-expired`, `parent-consumed`, `parent-revoked`, and `derivation-policy-denied` should remain visibly different outcomes.
10. **Keep the seam smaller than token exchange or generic delegation**
   - One optional attenuation-only subgrant story is enough for Phase 1.
   - Steward should not freeze a general STS, impersonation/delegation framework, token-wallet family, or cross-domain delegation protocol through this seam.

## Phase-1 non-goals
- a portable token-exchange API;
- a general delegation or impersonation grammar;
- arbitrary user-authored caveat expressions;
- raw parent-grant export or serialization by default;
- a global token wallet, refresh family, or cross-domain trust fabric.

## Adjacent docs
- `grant-handle-posture-v0.md`
- `consumable-grant-posture-v0.md`
- `renewal-window-posture-v0.md`
- `request-context-posture-v0.md`
- `effect-key-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `fence-token-posture-v0.md`
- `authority-narrowing-posture-v0.md`
- `context-handoff-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-RFC8693-TOKEN-EXCHANGE
- REF-GOOGLE-CREDENTIAL-ACCESS-BOUNDARY
- REF-AWS-STS-ASSUMEROLE
- REF-MACAROONS
