# Activity-bracket posture v0

Purpose: pin one **tiny explicit begin/end seam** for runtimes that can honestly say “do not stop or idle-stop me yet; this concrete unit of work is still in flight” without turning Steward into a scheduler, lease fabric, or ambient keepalive system.

## Posture
1. **Activity brackets are descriptive work scopes, not authority**
   - A bracket says a concrete runtime currently has attributable work in flight.
   - It does not grant permission to mutate policy, suppress repair gates forever, or bypass explicit stop authority.
2. **Begin and end should both be explicit when the runtime can express them**
   - If a runtime supports a start-of-work hint, it should also support a matching end-of-work hint or equivalent completion signal.
   - Steward should prefer balanced explicitness over sticky “still busy somehow” folklore.
3. **Brackets are local to one concrete runtime cycle**
   - A bracket belongs to an exact supervised leaf / runtime-cycle witness, not to a timeless component fiction.
   - Restart or replacement ends the old bracket story unless a later seam explicitly carries forward reviewed continuity evidence.
4. **Brackets are narrow stop-deferral hints, not a generic lease system**
   - Their Phase-1 job is to help local quiesce / pressured-exit / idle-stop decisions stay honest.
   - They should not silently become a portable distributed lock, queue reservation, or workflow lease plane.
5. **Unbalanced brackets must fail safe and stay explainable**
   - Lost end signals, crashes, or aborted helpers should not leave a component immortal by accident.
   - Steward should allow timeout, stale-bracket, or runtime-exit explainers without pretending every runtime exposes the same precision.
6. **Nested or counted precision is optional and adapter-local**
   - Some runtimes expose transaction counts; others only expose coarse busy/idle transitions.
   - Phase 1 should not force a universal nesting or reference-count contract.
7. **Brackets compose with quiesce and repair gates**
   - Quiesce may stop new work while honoring honest in-flight brackets for bounded drain.
   - Repair-required or explicit operator stop should still have a visible way to cut through stale or runaway brackets.
8. **Shell/terminal UX may reflect brackets, but only as observational chrome**
   - Busy/draining badges, frame-local explainers, and command-finish suppression are good uses.
   - A badge must not become the durable truth of whether work completed; receipts and lifecycle/status surfaces remain canonical.
9. **Unknown support degrades by omission**
   - Runtimes that cannot express brackets remain valid.
   - Steward should not invent fake activity brackets from CPU, log quiet, or terminal silence.

## Phase-1 non-goals
- a portable distributed transaction protocol;
- a universal nested activity-counter model;
- indefinite keepalive by forgotten busy hints;
- turning brackets into workflow leases or scheduling reservations;
- inferring begin/end scopes from logs, CPU, or terminal chatter.

## Adjacent docs
- `activity-accounting-posture-v0.md`
- `activation-checkpoint-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `termination-cause-posture-v0.md`
- `repair-gate-posture-v0.md`
- `quiesce-posture-v0.md`
- `chrome-lane-posture-v0.md`

## References
- REF-XPC-TRANSACTION-BEGIN
- REF-XPC-TRANSACTION-END
- REF-LAUNCHD-SOCKETS
- REF-FUCHSIA-IDLE-STOP
- REF-SD-NOTIFY
