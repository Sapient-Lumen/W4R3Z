# Liveness-evidence posture v0

Purpose: keep **still-responsive / still-being-watched** separate from **readiness**, **stable availability**, and **making useful work progress** so Steward can say `watchdog current`, `liveness stale`, or `liveness unknown` without freezing a giant health-check DSL, universal probe protocol, or degraded-mode algebra.

This seam is intentionally narrow. It answers one smaller question: **when an adapter or component can provide recurring evidence that the current runtime cycle is still responsive enough to keep, how should Steward expose that evidence without pretending it proves readiness, correctness, or meaningful work progress?**

## Posture
1. **Liveness evidence is not readiness**
   - A component may be ready to serve while its later liveness evidence is absent, stale, or unsupported.
   - A component may also emit liveness evidence before it is ready to accept declared work.
2. **Liveness evidence is not useful work progress**
   - A watchdog pulse, successful liveness probe, or loop tick can show that the runtime is still responsive enough to check in.
   - It does not by itself prove that the component is making forward progress on useful work, that dependencies are healthy, or that users should trust current results.
3. **Startup shielding and later liveness should stay separate**
   - Some runtimes should not be judged by later liveness expectations until startup has completed or an explicit startup shield is lifted.
   - Steward should preserve that split instead of killing slow starters because a later watchdog/probe expectation was applied too early.
4. **Evidence should come from explicit adapter or component signals, not manager vibes**
   - Good evidence includes watchdog renewals, successful liveness probes, event-loop keepalive checkpoints, or another reviewed adapter signal.
   - Quiet logs, lack of stderr, or a process that merely still exists are weaker and should not silently upgrade into exact liveness truth.
5. **Missing evidence is a fact before it becomes a policy action**
   - `liveness stale`, `pulse missed`, or `evidence unknown` should be exposable as direct observations.
   - A restart, kill, repair gate, or operator escalation may follow, but those are later policy moves, not the same seam.
6. **Unknown is healthier than fake precision**
   - Some adapters can report last-good pulse time or a due-by horizon.
   - Others can only say `unsupported` or `unknown`. Steward should preserve that honesty.
7. **Shell chrome should expose pulse truth compactly**
   - Good compact chips include `watchdog current`, `last pulse 8s ago`, `liveness stale`, `startup shielded`, or `liveness unknown`.
   - These stay explanatory and target-bound; they do not become an ambient control plane.
8. **Phase 1 keeps the public shape tiny**
   - Phase 1 likely needs no more than an optional current liveness-evidence state, optional last-evidence / due-by timestamps when the adapter can prove them, and optional evidence kind such as watchdog/probe/checkpoint.

## Phase-1 non-goals
- a universal cross-runtime health-check DSL;
- requiring every component to emit periodic pulses;
- treating liveness evidence as proof of useful work or end-user correctness;
- freezing a giant degraded-mode taxonomy;
- a portable watchdog cadence or leader-election family.

## Adjacent docs
- `readiness-posture-v0.md`
- `progress-window-posture-v0.md`
- `stability-window-posture-v0.md`
- `renewal-window-posture-v0.md`
- `restart-budget-posture-v0.md`
- `repair-gate-posture-v0.md`
- `status-channel-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-PROBES
- REF-K8S-POD-LIFECYCLE
- REF-SD-WATCHDOG-ENABLED
- REF-SD-NOTIFY
- REF-SYSTEMD-SERVICE
