# Execution-group posture v0

Purpose: define a **tiny under-the-membrane execution-group seam** so one Steward component run may be observed, accounted, quiesced, and force-terminated as one reviewed multi-process unit without turning PID trees, shell jobs, cgroup paths, or host job objects into public Steward semantics.

## Posture
1. **The public unit stays the component run, not the host process tree**
   - Steward should keep talking about one component identity and, when useful, one runtime-cycle witness.
   - Host process trees, process groups, cgroup paths, job handles, and contract ids are implementation detail under the membrane.
2. **Hosts may use an exact execution-group object when they have one**
   - If a platform offers one object that can account for, wait on, or terminate the reviewed set of processes for a component run, adapters should feel free to use it.
   - Job objects, service contracts, and control-group style containers are exactly the sort of local trick worth stealing.
3. **Stop and kill target the reviewed execution group, not guessed descendants**
   - Cooperative stop, quiesce, grace windows, and forced termination should apply to the reviewed workload for that run.
   - Steward should prefer exact group semantics over best-effort descendant walks, shell jobspec folklore, or PID-race tree scraping.
4. **Breakaway or escape must be explicit if it exists at all**
   - If a host supports child breakaway, detached descendants, or multiple nested execution groups, adapters should treat that as a visible design choice or a downgrade, not as invisible normal behavior.
   - “The real worker escaped the thing we supervise” is exactly the folklore this seam exists to resist.
5. **Execution-group state is useful, but remains observational**
   - Aggregate accounting, signaled-on-empty semantics, pressure counters, or whole-group kill outcomes are excellent implementation facts.
   - Steward should surface only the compact meanings it can explain portably instead of freezing every host's group-control API.
6. **A fresh run should normally imply a fresh execution group**
   - Restart, explicit relaunch, or crash-recovery should normally produce a fresh host-side execution-group object even if the component identity is unchanged.
   - Preserved escrow or restarted continuity does not make it the same concrete execution group.
7. **Runtime-cycle witnesses may be backed by execution-group handles locally**
   - Behind the membrane, a runtime-cycle witness may be correlated with one exact job handle, contract id, or cgroup-ish object.
   - Publicly, the witness stays opaque and the execution-group machinery stays hidden.
8. **Hosts without strong group objects may still degrade honestly**
   - Some adapters will only have weaker child tracking or pidfd/process-table techniques such as subreaper adoption.
   - Steward should allow that downgrade while clearly refusing to pretend that every host can provide identical whole-group control.
9. **Shell and terminal affordances should target reviewed runs, not shell folklore**
   - “stop”, “inspect”, “show descendants”, or “promote this work” actions should bind to the concrete Steward run and its reviewed execution group when available.
   - They should not silently fall back to the user's current shell jobs table or random process-tree heuristics.
10. **Keep the portable promise smaller than the implementation freedom**
   - Phase 1 needs the discipline more than the API surface.
   - Steward should freeze the cultural rule—whole reviewed workload, not PID folklore—before it freezes a rich execution-group protocol.

## Phase-1 non-goals
- a portable process-tree browsing API;
- exposing cgroup paths, job handles, or contract ids as public Steward identity;
- promising identical descendant semantics across hosts;
- supporting invisible process breakaway as normal lifecycle behavior;
- freezing a giant process-accounting or resource-controller language.

## Adjacent docs
- `supervision-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `termination-cause-posture-v0.md`
- `quiesce-posture-v0.md`
- `repair-gate-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-WINDOWS-JOB-OBJECTS
- REF-WINDOWS-TERMINATE-JOB-OBJECT
- REF-SOLARIS-PROCESS-CONTRACTS
- REF-SOLARIS-SMF-CONTRACT-SERVICE
- REF-LINUX-CGROUP-V2
- REF-LINUX-CHILD-SUBREAPER
