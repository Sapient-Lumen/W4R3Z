# Exception-witness posture v0

Purpose: define a **tiny exception-witness seam** so `bypass under review`, `waived until`, `force used`, or other exact exception truth stays visibly separate from **satisfied gates**, ordinary approval, and settled healthy state.

This seam stays intentionally small. It does **not** invent a universal waiver service, policy language, enterprise exception workflow, or cross-runtime bypass algebra. It only says that when a system proceeds *despite* an unsatisfied gate, Steward should be able to say that explicitly, keep it scoped and attributable, and avoid laundering it into fake success or ambient permission.

## Posture
1. **Exception is not satisfaction**
   - A reviewed bypass or waiver means the system moved forward under exception; it does not mean the underlying gate was actually satisfied.
   - Steward should keep `gate satisfied`, `exception used`, `policy denied`, and `settled healthy` visibly different instead of flattering a bypass into success.
2. **The unsatisfied gate should stay nameable when knowable**
   - `PDB bypassed`, `manual approval bypassed`, `secret push blocked but exception granted`, or similar concrete truth is healthier than one vague `forced` badge.
   - If an adapter can only prove `exception used`, Steward may say that, but it should not fabricate a richer local story.
3. **Exceptions must stay scoped and attributable**
   - An exception witness should say what exact subject, action class, lane, or revision it applied to.
   - When footing can prove it, optional `requested_by`, `approved_by`, `reason`, `ticket`, or `expires_at` notes are healthier than silent override.
4. **Bypass paths should stay weaker than durable approval**
   - A one-off exception for this drain, push, or terminal session should not silently become lasting permission for later work.
   - Steward should prefer explicit per-action or per-session exception truth over ambient widening.
5. **Expiry, revocation, and manual clear are different truths**
   - Some exceptions expire automatically, some are single-use, some are session-scoped, and some require explicit operator withdrawal.
   - Steward should preserve whichever of those are real instead of teaching one mythical `exception active` story.
6. **Policy floors may still forbid bypass entirely**
   - Some environments allow designated reviewers or specific roles to grant exceptions; others intentionally disable bypass for a class of gates.
   - Steward should be willing to say `bypass forbidden here` instead of pretending every blocker has a break-glass path.
7. **Shell and terminal chrome should make exception footing legible**
   - Execution-ground cards, command frames, and receipts may show compact truth such as `under exception`, `PDB bypassed`, `manual approval bypassed`, `waived until 14:00`, or `exception expired`.
   - Those labels explain the footing; they do not themselves widen authority.
8. **Exception witnesses should compose with settlement and headroom without replacing them**
   - A change may be under exception and still be unsettled, unhealthy, or out of headroom.
   - Steward should let those truths stack instead of letting one bypass badge masquerade as readiness, stability, or current spendability.
9. **Unknown is healthier than false precision**
   - Some adapters can prove an exact bypass cause and reviewer chain.
   - Others may only know that normal gates were overridden. Steward should preserve that honesty.
10. **Phase 1 keeps the portable shape tiny**
   - Phase 1 likely needs no more than an optional `exception_class`, exact scope label, and whichever of `gate_class`, `reason`, `requested_by`, `approved_by`, `expires_at`, `single_use`, or `manual_clear_required` the adapter can prove.
   - Richer approval workflows remain intentionally undecided.

## Phase-1 non-goals
- a universal waiver / exception workflow engine;
- a portable policy-justification language or ticket taxonomy;
- a cross-runtime break-glass approval cache or shared reviewer service;
- pretending exception use proves the underlying rule passed;
- flattening one-off force operations, temporary waivers, and lasting permissions into one state bit.

## Adjacent docs
- `approval-rung-posture-v0.md`
- `preflight-lane-posture-v0.md`
- `headroom-witness-posture-v0.md`
- `revision-settlement-posture-v0.md`
- `hold-state-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-KUBECTL-DRAIN
- REF-VSCODE-AGENT-TOOLS
- REF-VSCODE-UPDATE-1111
- REF-GITHUB-PUSH-PROTECTION-BYPASS
- REF-GITHUB-PROTECTED-BRANCHES
