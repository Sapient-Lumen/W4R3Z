# Lifecycle observation posture v0

Purpose: freeze the **smallest useful observational vocabulary** before Steward invents broader mutation or orchestration surfaces.

This is deliberately a posture note, not a final state-machine spec.

## Posture
1. **Observation hardens before large control planes**
   - Steward should standardize a small lifecycle-observation vocabulary before it standardizes a giant admin bus, dependency DSL, or orchestration language.
2. **Keep `starting`, `control-ready`, and `ready` distinct when the distinction matters**
   - `starting` means the lifecycle root is being brought up.
   - `control-ready` means Steward or a runtime adapter can talk to the lifecycle root or activation membrane.
   - `ready` means the component can accept its declared work.
3. **Shallow readiness is useful, but must not masquerade as serve-readiness**
   - Some runtime layers can honestly say “I am ready to receive control or report status” before the component is truly ready to serve.
   - Steward should preserve that distinction instead of collapsing everything into `running`.
4. **Quiescing, stopped, failed, and cooldown are observationally different**
   - A component that is draining work, fully stopped, crash-failed, or intentionally waiting out restart policy should not all look the same from the outside.
   - When possible, Steward should also keep a compact end-of-cycle cause so “stopped” does not erase why the previous cycle ended.
5. **Degraded / overloaded truth should not be smuggled into a boolean**
   - “Ready but impaired”, “ready but overloaded”, or “waiting on an external dependency” deserve a compact status story rather than magical interpretation of one state bit.
6. **Observation provenance matters**
   - Steward should know whether a lifecycle observation came from the supervisor, a runtime adapter, an activation membrane, or the component itself.
7. **The vocabulary should remain smaller than the full host implementation state machine**
   - Portable semantics should stay compact even if an implementation internally tracks many more substates.

## Phase-1 non-goals
- a final public finite-state-machine API;
- exposing every host or runtime-specific substate as portable Steward meaning;
- inferring serve-readiness from spawn success or log text;
- pretending that all runtimes can report the same degree of precision.

## Adjacent docs
- `observation-subscription-posture-v0.md`
- `design-principles-v0.md`
- `readiness-posture-v0.md`
- `quiesce-posture-v0.md`
- `status-channel-posture-v0.md`
- `termination-cause-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-FUCHSIA-LIFECYCLE
- REF-S6-SHALLOW-READINESS
- REF-S6-READY
- REF-K8S-PROBES
- REF-SD-NOTIFY
