# Attention-hint posture v0

Purpose: define a **tiny observational seam** for shell/terminal cues that ask for user attention without turning terminal UX into hidden lifecycle control.

## Posture
1. **Attention hints are observations, not authority**
   - A command-finished alert, progress ring, badge, or “needs attention” cue must not itself grant permission to stop, restart, or mutate a component.
   - These hints only help the shell/terminal stack decide how loudly to surface already-observed state.
2. **The phase-1 vocabulary should stay tiny**
   - Start with a narrow set such as:
     - `command-finished`,
     - `needs-input`,
     - `warning`,
     - `error`,
     - optional `progress` with compact state/value when supported.
   - Avoid a giant generic notification taxonomy.
3. **Delivery should be user-filterable and focus-aware**
   - Whether a hint becomes a bell, toast, badge, palette pulse, or nothing at all should be shaped by user policy and current focus state.
   - A pane that is already focused may deserve a subtler hint than a background pane or hidden tab.
4. **Hints should attach to explicit semantic objects when possible**
   - Command-finished and progress cues should prefer explicit command frames, receipts, runtime-cycle witnesses, or status updates over pattern matching on terminal text.
5. **Hint freshness must stay scoped**
   - An attention hint belongs to a concrete semantic epoch / hop lineage / frame context.
   - After resync, restart, or hop change, stale hints should be clearable or visibly stale rather than silently treated as current truth.
6. **Foreground-request tokens stay advisory and expendable**
   - If a host uses startup ids, activation tokens, or similar focus-steering hints, Steward should treat them as advisory, freshness-scoped, and separately deniable by local policy.
   - A spent or stale token should not quietly authorize later focus or lifecycle mutation.
7. **Explicit reports should outrank terminal folklore**
   - If a shell or runtime adapter can explicitly say “that frame finished”, “this command now waits for input”, or “progress is 60%”, Steward should prefer that over inferring attention from BELs, title churn, or output heuristics.
8. **Progress should stay advisory and capability-scoped**
   - Progress bars, rings, or taskbar indicators are nice when live capability says they are supported.
   - Unsupported terminals should degrade cleanly to no progress ornament or a simpler attention cue.
9. **Users should be able to suppress noisy classes**
   - A useful design should allow filtering by source or kind so low-value chatter does not train users to ignore the system.
10. **Click-through actions must stay explicit and bounded**
   - If a notification, badge, or chip can focus a pane or reveal a frame, that target binding should be explicit.
   - Arbitrary application-defined code execution or hidden terminal-side mutation should stay out of scope.
11. **Attention hints should compose with confidence and provisional state**
   - A hint may be exact, approximate, provisional, or later withdrawn.
   - Steward should allow “this might be finished” or “progress value is stale after hop” to remain visible instead of forcing false certainty.

## Phase-1 non-goals
- a universal desktop-notification protocol for all apps;
- guaranteeing OS-level notification delivery;
- allowing terminal hints to bypass authorization for lifecycle mutations;
- treating a bell or title change as portable proof of command completion;
- freezing a giant progress/attention ontology before real pressure exists.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `command-frame-posture-v0.md`
- `status-channel-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `provisional-state-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `action-surface-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `chrome-lane-posture-v0.md`
- `notification-surface-posture-v0.md`

## References
- REF-GHOSTTY-RELEASE-130
- REF-GHOSTTY-CONFIG-REFERENCE
- REF-ITERM2-SHELL-INTEGRATION
- REF-ITERM2-FEATURE-REPORTING
- REF-KITTY-DESKTOP-NOTIFICATIONS
- REF-WEZTERM-NOTIFICATION-HANDLING
- REF-WINDOWS-TERMINAL-PROGRESS
- REF-XDG-ACTIVATION-V1
- REF-DESKTOP-ENTRY-DBUS-ACTIVATION
