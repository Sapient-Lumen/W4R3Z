# Mode-baseline posture v0

Purpose: define a **tiny shell/terminal mode seam** so prompt-aware UX can rely on a small explicit baseline and a bounded repair path instead of ambient terminal folklore.

## Posture
1. **Mode baseline is live path truth, not remembered policy**
   - Steward may care about a small set of terminal/shell modes only when they materially affect prompt, input, command-frame, or affordance semantics.
   - The baseline should describe what the current pane / hop path has freshly established, not what some earlier session hoped would still be true.
2. **Phase-1 baseline should stay very small**
   - Likely examples: prompt markers, prompt-end markers, cwd freshness, bracketed paste, focus-reporting, prompt-local cursor shape, and other shell-integration-relevant modes.
   - Avoid freezing a giant inventory of every TTY knob before there is real pressure for it.
3. **Fresh prompt reassertion beats stale modal residue**
   - When the shell regains control at a fresh prompt, it should be allowed to restate the current semantic baseline instead of assuming intermediate programs left the terminal in a good state.
   - This is especially important after SSH hops, tmux-like layers, or programs that changed cursor or paste behavior.
4. **Repair paths should be explicit and scoped**
   - There should be a visible distinction between a light semantic resync, a baseline reassertion, and a heavier terminal reset.
   - Do not hide a giant “maybe this fixes it” ritual behind normal lifecycle semantics.
5. **User-invoked emergency reset is still valuable**
   - A custom shell+terminal should keep a clear emergency path for “the terminal is wedged or semantically broken.”
   - That path should be explicit and local, not confused with component lifecycle control.
6. **Baseline deviations are normal while programs run**
   - Full-screen TUIs and other interactive programs may temporarily own cursor shape, mouse handling, focus reporting, or screen layout.
   - The important thing is that the path can return to a known shell/prompt baseline afterward or visibly admit that repair is needed.
7. **Remote and multiplexer layers must not flatten baseline truth**
   - A local terminal, multiplexer, remote shell, or helper may each preserve or drop different semantics.
   - Steward should prefer visible downgrade over pretending the outermost baseline survived unchanged.
8. **Repair should prefer reassertion over transcript pollution**
   - Shell/terminal recovery should mostly happen via explicit semantic channels or well-scoped reset paths, not by stuffing more explanatory junk into the prompt or transcript.
9. **Baseline state should compose with confidence, epochs, and hop lineage**
   - A mode claim may be exact, downgraded, stale, or tied to an older semantic epoch.
   - The system should be allowed to say that plainly instead of maintaining one pane-wide myth.
10. **Keep mode semantics descriptive, not authority-bearing**
   - Knowing that bracketed paste, focus-reporting, or a prompt cursor shape is active should not itself grant lifecycle authority.
   - This seam exists to keep UX honest and repairable, not to smuggle control through the terminal.

## Phase-1 non-goals
- a universal portable schema for every terminal private mode;
- guaranteeing that all terminals, multiplexers, and hops preserve the same shell semantics;
- replacing ordinary shell/tool discipline with hidden automatic resets after every command;
- turning terminal repair into a new privileged control path;
- assuming that a reset-capable UI means transcript or receipt truth changed.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `precision-fence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `attention-hint-posture-v0.md`
- `chrome-lane-posture-v0.md`

## References
- REF-XTERM-MANPAGE
- REF-ITERM2-TMUX-INTEGRATION
- REF-GHOSTTY-RESET-ACTION
- REF-KITTY-CONF
- REF-FISH-OSC-MARKERS
