# Request-activation posture v0

Purpose: pin a **tiny request-carried activation seam** so the first meaningful request may activate a component without forcing Steward into a giant bus, dependency, or desktop-app activation grammar.

This seam is intentionally narrow. It does **not** design a universal message bus, a desktop-foreground policy API, or a generic dependency planner. It only says that split-phase "start it, then maybe send the real work later" is often the wrong default.

## Posture
1. **The first meaningful request may activate the component**
   - When practical, Steward should allow an exact request to a manager-owned activation name, target, or key to both wake the component and carry useful work.
   - Phase 1 should prefer this over a ceremonial pre-start step followed by a second best-effort action.
2. **Target identity must stay exact**
   - Request-triggered activation should bind to an explicit component identity and reviewed activation target.
   - Ambient process discovery, mutable path lookup, or wrapper-script folklore are not good portable activation semantics.
3. **Activation input should stay narrow and reviewable**
   - Small exact names, selectors, keys, or request objects are healthy.
   - Arbitrary caller-controlled paths, shell strings, or privilege-bearing startup bundles are not.
4. **Delivery and acknowledgement remain distinct truths**
   - Steward should be able to say that it accepted a request, delivered startup material, and later observed acknowledgement or readiness.
   - Request-triggered activation does not collapse those observations into one magical state bit.
5. **Foreground and attention hints stay separate from lifecycle truth**
   - A desktop or shell may carry startup notification data, focus hints, or activation tokens next to the initial request.
   - Those hints are not the same thing as component identity, activation success, or readiness, and they should not quietly become a portable focus-steering control plane.
6. **Attention tokens should stay freshness-scoped and non-authoritative**
   - If a local platform uses activation tokens, startup ids, or similar attention hints, Steward should treat them as optional proof-of-interaction material for that one launch moment.
   - Reuse, replay, or later lifecycle mutation must not quietly inherit authority from an old token.
7. **Replay must stay bounded by request budget and truth**
   - If the first request is retained long enough to survive activation, that retained work should stay compact, attributable, and reviewable.
   - Steward should not quietly become a generic durable mailbox or job queue through this seam.
8. **Bulky startup material should prefer immutable local capsules under the membrane**
   - When a host needs more than a tiny selector or request object, adapters may use immutable anonymous objects or similarly sealed local capsules to carry reviewed startup payloads.
   - The portable story should still stay at exact names, digests, and receipts rather than becoming a public env/argv/shared-memory contract.
9. **The portable promise stays smaller than local mechanisms**
   - Some hosts may realize this with service names, sockets, buses, or desktop activation glue.
   - Steward should freeze the narrow product meaning—exact request may wake the component and carry work—without cloning every local API family.
10. **Unsupported runtimes may fail honest**
   - Some components will still need explicit start and separate follow-up actions.
   - Steward should allow that downgrade rather than pretending every runtime supports request-carried activation equally.

## Phase-1 non-goals
- a universal cross-host activation bus;
- a portable desktop foreground/focus control API;
- a generic dependency planner hidden inside request activation;
- durable queueing or store-and-forward semantics for arbitrary work;
- treating request-triggered activation as proof of readiness or health.

## Adjacent docs
- `activation-posture-v0.md`
- `activation-receipt-posture-v0.md`
- `readiness-posture-v0.md`
- `dynamic-condition-posture-v0.md`
- `attention-hint-posture-v0.md`
- `request-context-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`

## References
- REF-DBUS-SYSTEM-ACTIVATION
- REF-DBUS-SPECIFICATION
- REF-DESKTOP-ENTRY-DBUS-ACTIVATION
- REF-XDG-ACTIVATION-V1
- REF-XDG-PORTAL-OPENURI
- REF-LAUNCH-ACTIVATE-SOCKET
- REF-SD-LISTEN-FDS-WITH-NAMES
- REF-LINUX-MEMFD-CREATE
- REF-LINUX-F-ADD-SEALS
- REF-GRPC-DEADLINES
