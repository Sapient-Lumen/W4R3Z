# Decision map

Guiding compression: `design-principles-v0.md`.
Refusal / freeze-late companion: `non-decisions-v0.md`.

## D-SUPV
How component-rooted supervision works; see `supervision-posture-v0.md`.

## D-ACTIVATE
How activation handles and continuity escrow work; see `activation-posture-v0.md`.
How bounded continuity escrow itself stays explicit, redelivered, and separate from runtime-cycle identity or takeover proof; see `continuity-escrow-posture-v0.md`.

## D-REQACT
How an exact first request may activate a component without hardening a giant bus or focus-control plane; see `request-activation-posture-v0.md`.

## D-PRESENCE
How reviewed discoverable presence can be published, renewed, withdrawn, or allowed to expire without collapsing into readiness, serving truth, or a giant registry plane; see `presence-advertisement-posture-v0.md`.

## D-LAUNCHCTX
How reviewed component entry and restart baseline stay explicit instead of inheriting ambient shell/session folklore; see `launch-context-posture-v0.md`.

## D-LAUNCHBOUNDARY
How current possession, launch eligibility, selected-for-child delivery, and receipt-only history stay separate instead of collapsing into inheritance folklore; see `launch-boundary-posture-v0.md`.

## D-REQCTX
How exact request ids, optional deadlines, and explicit cancellation stay small and attributable without freezing a giant RPC metadata plane; see `request-context-posture-v0.md`.

## D-GRANTHANDLE
How pending requests, stop deferrals, capture sessions, and similar transient powers stay exact, closeable, and fail-closed instead of dissolving into sticky mode bits; see `grant-handle-posture-v0.md`.

## D-CONSUME
How some transient powers may be one-shot or use-bounded so stale chips, old receipts, or replay affordances cannot quietly spend them twice; see `consumable-grant-posture-v0.md`.

## D-EFFECTKEY
How reviewed non-commutative actions may collapse duplicate retries, reject mismatched key reuse, and stay smaller than a durable exactly-once plane; see `effect-key-posture-v0.md`.

## D-RETRYADVICE
How denials, cooldowns, or explicit pushback may carry an exact earliest-follow-up hint without hardening into a quota, retry-throttling, or giant retry-policy plane; see `retry-advice-posture-v0.md`.

## D-PRECOND
How reviewed actions may carry exact veto-only stale fences against runtime cycles, observation cursors, semantic epochs, or other explicit local witnesses without freezing a query language; see `precondition-witness-posture-v0.md`.

## D-RENEWAL
How live claims can carry compact renew-or-expire budgets without hardening into a generic lease, watchdog, or leader-election plane; see `renewal-window-posture-v0.md`.

## D-ATTENGRANT
How an exact live grant may derive a narrower helper or follow-on grant without exposing the parent raw or hardening into a generic token-exchange / delegation plane; see `attenuated-grant-posture-v0.md`.

## D-FENCETOKEN
How reassignable live claims can carry an optional stale-holder fence or current-owner witness without hardening into a distributed lock, leadership, or sequencer plane; see `fence-token-posture-v0.md`.

## D-HOLDERBIND
How some exact live grants can require current holder proof instead of behaving like replayable bearer material, without hardening into a portable proof-of-possession or key-management plane; see `holder-bound-grant-posture-v0.md`.

## D-FRESHINTENT
How some higher-risk or foreground-sensitive shell actions can require fresh local one-shot intent evidence without hardening into a trusted-UI, biometric, or wildcard-consent plane; see `fresh-intent-posture-v0.md`.

## D-DESCHYGIENE
How inherited handles, stdio, and control channels stay explicit instead of becoming the real contract through descriptor accidents; see `descriptor-hygiene-posture-v0.md`.

## D-EXGROUP
How one component run may map to one reviewed multi-process workload under the membrane without freezing PID trees, cgroup paths, or job handles into public meaning; see `execution-group-posture-v0.md`.

## D-AUTHNARROW
How reviewed authority reduction and lock-state honesty stay explicit without freezing a giant portable sandbox grammar; see `authority-narrowing-posture-v0.md`.

## D-TRANSITIONHELPERS
How short-lived lifecycle helpers stay attributable, bounded, and separate from the supervised long-lived leaf; see `transition-helper-posture-v0.md`.

## D-READY
How startup, readiness, and liveness stay distinct; see `readiness-posture-v0.md`.
How optional liveness evidence can stay separate from readiness, useful work progress, and watchdog policy; see `liveness-evidence-posture-v0.md`.

## D-PROGRESS
How Steward distinguishes active bring-up/reload progress from stalled intermediate state without freezing a giant timeout or rollout grammar; see `progress-window-posture-v0.md`.

## D-HOLDSTATE
How deliberate `paused`, `draining`, `frozen`, or `start-prevented` truth stays separate from `stalled`, `failed`, or ordinary `off` without freezing a giant maintenance or inhibit family; see `hold-state-posture-v0.md`.

## D-ACTIVITY
How in-flight work, idle hints, and drain accounting stay explicit without pretending every runtime fits one idle model; see `activity-accounting-posture-v0.md`.

## D-ACTBRACKET
How explicit begin/end in-flight-work brackets stay attributable, bounded, and revocable without turning into a generic keepalive or lease plane; see `activity-bracket-posture-v0.md`.

## D-STOPDEFERRAL
How short stop or quiesce grace windows stay live, attributable, and cuttable without becoming a generic inhibit plane; see `stop-deferral-posture-v0.md`.

## D-LIFECYCLEOBS
How Steward names and surfaces minimal lifecycle observations; see `lifecycle-observation-posture-v0.md`.

## D-STATUS
How compact current-state reporting stays separate from logs and receipts; see `status-channel-posture-v0.md`.

## D-FRESHNESS
How live observations, status hints, and shell chrome visibly decay when their anchors or renewals go stale; see `freshness-decay-posture-v0.md`.

## D-SUBSCRIBE
How bounded observation subscriptions can provide snapshot-plus-change views without polling or a hidden control bus; see `observation-subscription-posture-v0.md`.

## D-OBSCURSOR
How snapshot-plus-change views can resume from an exact opaque cursor or admit continuity loss honestly without freezing a giant event-log contract; see `observation-cursor-posture-v0.md`.

## D-PROVISIONAL
How shell/terminal UX may surface tentative local state and later confirmation without turning prediction into lifecycle truth; see `provisional-state-posture-v0.md`.

## D-ATTENTION
How shell/terminal attention hints stay focus-aware, freshness-scoped, and non-authoritative instead of devolving into bell/title folklore; see `attention-hint-posture-v0.md`.

## D-NOTIFY
How shell/terminal notifications, toast wakeups, and mark-alert style escalations stay exact-anchor-bound, focus-aware, and action-bounded instead of becoming a hidden approval path; see `notification-surface-posture-v0.md`.

## D-CHROME
How shell/terminal status bars, badges, sticky headers, titles, and progress chrome stay observational, freshness-scoped, and separate from the canonical transcript; see `chrome-lane-posture-v0.md`.

## D-CMDGUIDE
How visible shell/terminal command guides, sticky headers, and scrollbar-mark style rails stay exact-frame-bound, filterable, and separate from transcript truth; see `command-guide-posture-v0.md`.

## D-LANDMARKS
How marks, annotations, alerts, and exact jump targets stay anchor-bound, provenance-labeled, and separate from transcript truth or ambient control; see `transcript-landmark-posture-v0.md`.

## D-CTXINHERIT
How tabs, splits, reruns, and action-launched shells inherit cwd or domain context only as explicit per-action choices instead of pane folklore; see `context-inheritance-posture-v0.md`.

## D-SPAWNSELECT
How tabs, splits, reruns, and helper shells choose reviewed program/profile/domain/cwd recipes instead of ambient `$SHELL`, profile, or pane folklore; see `spawn-selector-posture-v0.md`.

## D-SPAWNPALETTE
How command palettes and launcher menus expose reviewed spawn recipes, visible denials, and exact launch explanations without becoming an ambient command hole; see `spawn-palette-posture-v0.md`.

## D-SHELVES
How recent commands, directories, and Steward objects stay context-scoped, freshness-labeled, and non-authoritative instead of hardening remembered convenience into live truth; see `remembered-shelf-posture-v0.md`.

## D-WORKSNAP
How saved layouts, restored panes, reconnected processes, revived processes, and content-only restores stay visibly distinct and reviewable instead of collapsing into session folklore; see `workspace-snapshot-posture-v0.md`.

## D-REPLAY
How remembered, restored, and suspended commands can reopen as reviewed pending actions instead of silently rerunning from stale shell folklore; see `replay-gate-posture-v0.md`.

## D-ASSIST
How quick fixes, suggestion menus, and current-input help stay anchored, reviewable, and advisory instead of becoming an ambient second shell; see `assist-surface-posture-v0.md`.

## D-SURFDIAG
How shell/terminal affordances explain why they are enabled, degraded, denied, or stale instead of behaving like magic; see `surface-diagnostics-posture-v0.md`.

## D-AUTOMATION
How scripts, hooks, remote-control APIs, and helper CLIs stay exact-targeted, permissioned, and inspectable instead of becoming an ambient second control plane; see `automation-surface-posture-v0.md`.

## D-SESSIONINJECT
How UI-originated commands, environment bundles, and similar session changes stay explicit, staged, history-aware, and policy-bounded instead of becoming ambient shell folklore; see `session-injection-posture-v0.md`.

## D-INPUTSURF
How keyboard encodings, composed text, modal key tables, prompt-local input affordances, and injected bytes stay explicit and policy-bounded instead of collapsing into terminal folklore; see `input-surface-posture-v0.md`.

## D-CLIPBOARD
How copy, paste, and remote clipboard flows stay exact, provenance-labeled, and policy-bounded instead of becoming ambient terminal folklore; see `clipboard-surface-posture-v0.md`.

## D-TRANSFER
How uploads, downloads, remote-file actions, and drag/drop handoff stay exact, direction-labeled, and policy-bounded instead of becoming ambient path folklore; see `transfer-surface-posture-v0.md`.

## D-MEDIASURF
How inline images, plots, doc previews, and background media stay exact-targeted, budgeted, and clearly separate from transfer/open folklore; see `media-surface-posture-v0.md`.

## D-LINKSURF
How detected text, declared hyperlinks, semantic file links, and exact object opens stay provenance-labeled, action-bounded, and clearly separate from generic open folklore; see `link-surface-posture-v0.md`.

## D-RETENTION
How persisted command, directory, paste, and host/user memory stays scopeable, erasable, and clearly remembered instead of becoming ambient retained authority; see `retention-surface-posture-v0.md`.

## D-CYCLE
How concrete runtime cycles may carry an opaque witness for attribution and stale-action fences; see `runtime-cycle-witness-posture-v0.md`.

## D-ACTCAUSE
How Steward observes and explains why one concrete runtime cycle began without freezing a giant causal graph or dependency algebra; see `activation-cause-posture-v0.md`.

## D-TERMCAUSE
How Steward observes and explains why one concrete runtime cycle ended without freezing a giant fault taxonomy; see `termination-cause-posture-v0.md`.

## D-REPAIR
How repeated-failure cooldown and repair-required quieting stay explicit without freezing a giant retry-policy language; see `repair-gate-posture-v0.md`.

## D-RESTARTBUDGET
How automatic restart admissions stay bounded, windowed, and separate from repair-gate state, root-cause diagnosis, and timer folklore; see `restart-budget-posture-v0.md`.

## D-QUIESCE
How cooperative drain/gating works; see `quiesce-posture-v0.md`.

## D-SHELLTERM
How shell and terminal exchange semantic lifecycle metadata; see `shell-terminal-integration-posture-v0.md`.

## D-CMDFRAME
How explicit command-frame observations stay useful without becoming a control bus; see `command-frame-posture-v0.md`.

## D-CONFIDENCE
How shell/terminal observations carry compact confidence, provenance, and trusted-ness without pretending every marker is equally exact; see `observation-confidence-posture-v0.md`.

## D-GROUND
How panes and command frames may show tiny truthful ground summaries without turning chrome, remembered context, or foreground ownership into lifecycle authority; see `execution-ground-posture-v0.md`.

## D-ATTACHLANES
How observe-only witness mode, interactive attach, lifecycle control, and debug entry stay visibly different lanes instead of one vague attached state; see `attach-lane-posture-v0.md`.

## D-ATTACHCONTINUITY
How reconnecting, resumed witness, expired, replaced, and lost attach truth stay separate from service lifecycle and silent retargeting; see `attach-continuity-posture-v0.md`.

## D-PROPOSALLANE
How agent/chat/notebook proposal work stays visibly weaker than exact shell input, reviewed execution, and canonical lifecycle transcripts; see `proposal-lane-posture-v0.md`.

## D-APPROVALRUNGS
How proposal-only help, ask-before-run, scoped auto-approval, and run-until-completion stay visibly different powers with policy floors and honest downgrade; see `approval-rung-posture-v0.md`.

## D-EXCEPTIONWITNESS
How bypass-under-review, waived-under-expiry, and satisfied-gate truth stay visibly different without hardening into a giant waiver, break-glass, or policy-workflow family; see `exception-witness-posture-v0.md`.

## D-HEADROOM
How allowed, approved, and ready stay visibly separate from currently spendable restart / quota / rate-window headroom without hardening into a giant quota or wallet family; see `headroom-witness-posture-v0.md`.

## D-HISTORYLANE
How unified remembered search can span typed history, reviewed inserts, workflows, notebook blocks, and proposal memory without flattening them into one canonical execution record; see `history-lane-posture-v0.md`.

## D-PREFLIGHT
How explain, diff, speculative preview, reviewed saved plan, and apply stay visibly different moves with exact footing and honest stale/denied outcomes; see `preflight-lane-posture-v0.md`.

## D-RETURNTICKET
How browser/auth/chooser detours return to the shell as exact expiring local hints without turning callback or focus folklore into lifecycle truth; see `return-ticket-posture-v0.md`.

## D-REVISIONSETTLEMENT
How reviewed desired revision, current observed revision, and last settled/stable revision stay visibly different without freezing a giant rollout controller; see `revision-settlement-posture-v0.md`.

## D-STABILITY
How `ready now` and `stable enough to admit or advance` stay distinct without freezing a rollout planner or health algebra; see `stability-window-posture-v0.md`.

## D-ACTIONS
How explicit shell/terminal action surfaces stay user-invoked, target-bound, and stale-fenced instead of becoming hidden ambient control; see `action-surface-posture-v0.md`.

## D-ANCHORS
How explicit shell/terminal affordances can bind to exact frames, receipts, transcript spans, and concrete runs without visible-text scraping or raw-capability leakage; see `target-anchor-posture-v0.md`.

## D-HANDOFF
How explicit command/context handoff stays bounded, exact when possible, and separate from ambient whole-scrollback sharing; see `context-handoff-posture-v0.md`.

## D-EPOCH
How shell/terminal observations and affordances admit “that belonged to an older semantic world” after hops, restarts, or resync; see `semantic-epoch-posture-v0.md`.

## D-HOPLINEAGE
How shell/terminal semantics can stay explicitly scoped to the actual remote/multiplexer path instead of a flat PTY fiction; see `hop-lineage-posture-v0.md`.

## D-CAPLEDGER
How pane/hop-scoped semantic support stays recorded, refreshable, and distinct from desired UX or remembered folklore; see `capability-ledger-posture-v0.md`.

## D-FENCES
How shell/terminal layers admit precision loss, capability drift, and resync boundaries instead of silently preserving stale certainty; see `precision-fence-posture-v0.md`.

## D-MODEBASE
How shell/terminal prompt-critical modes can return to a small known baseline or surface visible repair needs instead of relying on folklore and manual `reset` rituals; see `mode-baseline-posture-v0.md`.

## D-TRANSIENT
How long-running shell work may be promoted into transient Steward-tracked objects without freezing a giant transient-unit language; see `transient-promotion-posture-v0.md`.

## D-SERVESTATE
How `serving`, `serving+terminating`, `draining`, `maintenance`, `degraded`, and `not serving` stay visibly separate from process liveness, readiness folklore, and discoverability without hardening into a giant traffic or service-mesh family; see `serve-state-witness-posture-v0.md`.

## D-PRESSURE
How scoped `ok` / `some` / `full` / `warning` / `critical` pressure truth stays visibly separate from serving mode, headroom, and failure without hardening into a giant autoscaling, scheduler, or reclaim-policy family; see `pressure-witness-posture-v0.md`.

## D-BACKPRESSURE
How `queued`, `retry-after`, `shed`, and `stop-accepting` truth stays visibly separate from pressure, headroom, and failure without hardening into a giant overload, fair-queuing, or traffic-shaping family; see `backpressure-witness-posture-v0.md`.

## D-ADAPTATION
How cache trim, reduced concurrency, optional-work deferral, and other protective response truth stays visibly separate from pressure, backpressure, and vague degraded folklore without hardening into a giant brownout, autoscaling, or remediation-policy family; see `adaptation-witness-posture-v0.md`.

## D-FREEZELATE
What Steward should intentionally leave unfrozen while SlopOS is still moving; see `non-decisions-v0.md`.

## Open questions
- OQ-0001 through OQ-0069 in `docs/00-meta/trajectory-map.md`.
