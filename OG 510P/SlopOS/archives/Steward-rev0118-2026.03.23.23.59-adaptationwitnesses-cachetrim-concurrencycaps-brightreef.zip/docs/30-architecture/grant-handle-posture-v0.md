# Grant-handle posture v0

Purpose: define a **tiny exact grant-handle seam** so ephemeral powers such as pending requests, input capture, shortcut sessions, stop deferral, or similar mediated authority can stay closeable, revocable, and attributable without turning Steward into a generic capability wallet, lease fabric, or desktop portal clone.

## Posture
1. **Ephemeral powers should prefer one exact live handle over sticky mode bits**
   - If a request, session, deferral, or mediated grant stays live beyond one immediate reply, Steward should prefer one exact handle or anchor for that live thing.
   - “Some modal state is probably still on” is exactly the folklore this seam exists to resist.
2. **Close or release should be first-class**
   - A live grant should usually have one exact close, revoke, release, or cancel path.
   - Letting permissions linger until timeout when the holder already knows it is done is worse hygiene than a closeable object.
3. **Completion, expiry, revocation, and denial are different facts**
   - `completed`, `released`, `expired`, `revoked`, `denied`, and `owner-lost` are not synonyms.
   - Steward should keep those outcomes separate anywhere the distinction is observable.
4. **Widening should require a fresh object, not silent mutation**
   - If scope, duration, or power needs to grow, the healthy default is a fresh reviewed request and a fresh handle.
   - A live handle should not quietly widen from “background hint” to “foreground control”, from “armed” to “always active”, or from “delay stop briefly” to “veto stop forever”.
5. **Owner loss should fail closed when the host can attribute it**
   - If the requestor exits, disconnects, drops the last controlling handle, or otherwise loses its claim, implementations should prefer fail-closed cleanup where the host supports that meaning.
   - When a host cannot prove owner loss cleanly, Steward should degrade honestly instead of pretending the grant is still well-owned.
6. **Host objects may back the handle under the membrane**
   - Portal object paths, request/session handles, job handles, or similar local objects are fair game for implementations.
   - Publicly, Steward should expose only one small exact grant handle plus compact state, not the host object model itself.
7. **Shell and chrome should show live grant handles as objects**
   - Pending chooser detours, active capture sessions, stop-deferral leases, or shortcut bundles should be able to appear as small chips/cards with current state and one exact close/revoke affordance.
   - They should not dissolve into badges with no object behind them.
8. **Keep the seam smaller than a generic grant algebra**
   - One exact handle, one owner story, one compact state vocabulary, and one close path are enough for Phase 1.
   - Steward should not freeze a distributed lease protocol, portable delegation graph, or giant session-object family through this seam.

## Phase-1 non-goals
- a generic capability wallet or delegation language;
- a distributed lease or lock replication protocol;
- promising that every host can detect owner loss equally well;
- turning every temporary UI state into a durable grant record;
- cloning the full desktop-portal request/session object universe.

## Adjacent docs
- `request-context-posture-v0.md`
- `stop-deferral-posture-v0.md`
- `input-surface-posture-v0.md`
- `attention-hint-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `execution-group-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-XDG-PORTAL-REQUEST
- REF-XDG-PORTAL-SESSION
- REF-XDG-PORTAL-INHIBIT
- REF-XDG-PORTAL-GLOBALSHORTCUTS
- REF-XDG-PORTAL-INPUTCAPTURE
- REF-WINDOWS-JOB-OBJECTS
