# Link-surface posture v0

Purpose: define a **tiny link/object invocation seam** so detected text, declared hyperlinks, semantic file links, and exact object targets stay provenance-labeled, action-bounded, and clearly separate from generic shell injection or ambient open folklore.

## Posture
1. **Detected text, declared hyperlinks, semantic file links, and exact object targets are different evidence classes**
   - A regex-detected URL, an OSC 8 hyperlink, a per-line semantic file link, and a reviewed exact object selector can all be useful.
   - Steward should keep those classes distinct instead of flattening them into one generic “clickable thing” authority level.
2. **Open target selection should stay separate from focus or foreground requests**
   - Choosing what object or URI a click refers to is one concern; asking the host to foreground a window, reuse an app, or raise focus is another.
   - Steward should keep exact target identity separate from any activation/focus request.
3. **File/path invocation should prefer exact objects or reviewed selectors over cwd folklore**
   - Line-local cwd, file fragments, and semantic-history helpers are better than pane-wide guessing.
   - Steward should still treat them as weaker than exact reviewed object handles or receipts when stronger identity exists.
4. **Invocation should remain user-invoked and policy-bounded**
   - Opening a browser URL, revealing a local file, editing a text file, or launching a helper app are not equivalent actions.
   - Steward should support visible policy fences and review paths for risky schemes, downgraded targets, or helper-controlled routes.
5. **Providers may enrich links, but they should not smuggle authority**
   - Extension- or plugin-supplied link handlers can improve UX.
   - Steward should prefer typed selectors, anchors, or exact targets over handler code that pastes guessed text back into the shell and hopes for the best.
6. **Downgrade should be explicit when only raw text survives**
   - Hops, multiplexers, copied transcripts, or unsupported terminals may leave only visible text or a guessed word link.
   - Steward should preserve that fallback as useful, but label it as detected-text or downgraded invocation rather than exact target truth.
7. **Invocation receipts should say what happened**
   - After a link/object invocation, it should be possible to explain what target class was used, which helper path handled it, and whether the action degraded from exact object to guessed text or plain URI open.
   - That is healthier than cursor movement or window focus alone serving as the only evidence that something happened.
8. **One invocation seam beats scattered click magic**
   - Hyperlinks, semantic file opens, quick-pick link palettes, and provider-enriched object opens all want the same anti-folklore rules.
   - Steward should prefer one small link-surface posture over many host-specific click exceptions.

## Phase-1 non-goals
- a universal hyperlink grammar for every terminal and application;
- auto-opening links without a user action;
- freezing one portable browser/profile/session-selection family;
- treating `file://` or raw path text as proof that a durable local object handle already exists;
- promising identical link detection, semantic file routing, or open behavior across every hop, multiplexer, and host shell.

## Adjacent docs
- `action-surface-posture-v0.md`
- `target-anchor-posture-v0.md`
- `chooser-surface-posture-v0.md`
- `transfer-surface-posture-v0.md`
- `media-surface-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `precision-fence-posture-v0.md`

## References
- REF-WEZTERM-HYPERLINKS
- REF-WEZTERM-OPEN-URI
- REF-KITTY-CONF
- REF-KITTY-OPEN-ACTIONS
- REF-ITERM2-SEMANTIC-HISTORY
- REF-ITERM2-ESCAPE-CODES
- REF-VSCODE-TERMINAL-BASICS
- REF-VSCODE-TERMINAL-LINK-PROVIDER
