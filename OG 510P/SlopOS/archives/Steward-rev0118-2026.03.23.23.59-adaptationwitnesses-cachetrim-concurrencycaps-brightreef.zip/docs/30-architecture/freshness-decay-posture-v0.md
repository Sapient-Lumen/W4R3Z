# Freshness-decay posture v0

Purpose: pin a **tiny explicit freshness-decay seam** so lifecycle truth, activity hints, and shell chrome do not linger as sticky folklore after the concrete evidence that supported them has gone stale.

This doc is intentionally narrow. It does **not** design a universal heartbeat protocol, a portable health-check language, or a giant lease/watchdog framework.

## Posture
1. **Observed truth ages unless the seam says otherwise**
   - Steward should treat status, busy/draining hints, progress chrome, and stop-deferral state as observations with a freshness story, not timeless facts.
   - If the supporting anchor, witness, handle, or renewal path goes stale, the system should visibly downgrade rather than preserve old certainty.
2. **Different signals may decay differently**
   - A one-time checkpoint such as `serve-ready` may remain the latest known checkpoint until contradicted.
   - A live hint such as busy, delaying stop, progress %, or waiting-on-X needs a shorter freshness horizon or an explicit renewal/ownership story.
3. **Live ownership beats remembered booleans**
   - Where possible, freshness should come from a live handle, balanced begin/end scope, current runtime-cycle witness, or explicit renewal message.
   - Steward should prefer revocable evidence over sticky booleans or shell-local remembered state.
4. **Decay should fail safe and stay explainable**
   - On disconnect, runtime exit, semantic-epoch reset, or renewal timeout, Steward should be allowed to say stale, unknown, or last-known rather than lying.
   - The explanation should point to the thing that expired: old frame anchor, old witness, old handle, or missing renewal.
5. **No fake universal heartbeat contract in phase 1**
   - Some runtimes can honestly emit progress or watchdog renewals; others cannot.
   - Steward should leave that asymmetry visible instead of pretending every component owes the same liveness pulse.
6. **Shell/terminal chrome must decay too**
   - Status strips, badges, remembered variables, busy chips, and countdowns should show publisher and freshness when they matter.
   - Once the exact anchor or renewal path is gone, chrome should clear, grey out, or label itself remembered/stale.
7. **Freshness is observational, not authority**
   - A fresh observation may justify better UX, stronger explainers, or safer exact actions.
   - It does not by itself grant mutation rights or replace explicit policy decisions.
8. **Subscriptions and snapshots should admit staleness honestly**
   - Snapshot-plus-change views should be able to report that continuity was lost, that a resync happened, or that the client is looking at last-known data.
   - Polling clients should not be taught to assume that silence means stability.
9. **Grace extensions and stop deferrals need renewal boundaries**
   - If a component asks for more startup, runtime, or shutdown time, that extension should stay bounded by explicit expiry or renewal, not ambient hope.
10. **Terminal comfort should inherit the same rule**
   - Remote-aware shell comfort is great, but hop-scoped status, remembered cwd, and pane metadata should admit when they are snapshots rather than live truth.

## Phase-1 non-goals
- a universal watchdog or health-check protocol;
- guaranteeing identical freshness budgets across all runtimes;
- treating stale remembered shell state as evidence of current component truth;
- turning status decay into a hidden kill policy;
- inventing a giant metrics/telemetry subsystem to support one badge.

## Adjacent docs
- `status-channel-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `activity-accounting-posture-v0.md`
- `activity-bracket-posture-v0.md`
- `stop-deferral-posture-v0.md`
- `chrome-lane-posture-v0.md`
- `session-variable-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`

## References
- REF-SD-NOTIFY
- REF-SD-WATCHDOG-ENABLED
- REF-SYSTEMD-SERVICE
- REF-S6-NOTIFYONCHECK
- REF-DINIT-OVERVIEW
- REF-WEZTERM-PANE-INFORMATION
- REF-WINDOWS-TERMINAL-PROGRESS
- REF-ITERM2-STATUS-BAR
