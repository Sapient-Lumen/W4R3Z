# Presence-advertisement posture v0

Purpose: keep **discoverable published presence**, **runtime-cycle identity**, **readiness/serving truth**, and **continuity escrow** separate so Steward can say `advertised`, `withheld`, `withdrawn`, `expired`, `critical`, or `unknown` without freezing a generic service-registry plane, lease fabric, or leader-election family.

This seam stays intentionally small. It answers one narrower question: **has this reviewed component published a current discoverable presence somewhere, how can that presence age out or be withdrawn, and what should that fact not be mistaken for?**

## Posture
1. **Advertisement is not the same as readiness or current serving truth**
   - A component may publish identity, location, or discoverable presence before it is ready for work, and it may withdraw traffic-serving truth before its publication fully disappears.
   - Steward should therefore keep advertisement separate from readiness, serving-state, and shutdown-horizon truth.
2. **Published presence should be explicit and reviewed**
   - The healthy default is one reviewed advertisement lane per component or adapter, with a named target such as a registry entry, lease, or discovery record.
   - Steward should resist ambient “whoever is listening on this port must be the service” folklore.
3. **Publish, renew, withdraw, and expiry should stay attributable**
   - If a component becomes discoverable, the archive should preserve a place to say whether that happened by explicit publish, explicit renew, explicit withdraw, or timeout/critical expiry.
   - Ground cards, receipts, or status chips should be able to say `advertised`, `withheld`, `withdrawn`, `expired`, or `critical` instead of forcing users to infer discovery truth from traffic or gossip.
4. **Renewal confirms one exact advertisement claim, not whole-system health**
   - Lease keepalives, TTL passes, or session-bound ephemerals can confirm that one discoverable presence is still being maintained.
   - They should not be mistaken for proof that the component is ready, healthy, or the only rightful owner of a larger capability surface.
5. **Expiry and deliberate hold are different outcomes**
   - A published presence may age out because its lease/session/check renewal stopped, or it may stay deliberately withheld because policy or admission gates say not to publish yet.
   - Steward should keep `withheld` and `expired` separate instead of treating every absent advertisement as failure.
6. **Discovery continuity is not runtime continuity**
   - A fresh runtime cycle may republish the same discoverable name, or a manager may help preserve continuity, without that implying unchanged runtime identity.
   - Steward should therefore keep advertisement truth separate from continuity-escrow and runtime-cycle witnesses.
7. **Shell chrome should expose advertisement truth compactly**
   - Useful chips include `advertised`, `withheld`, `withdrawn`, `expired`, `critical`, or `unknown`.
   - Useful exact actions include `show advertise receipt`, `show publish basis`, or `show withdraw cause` when policy allows.
8. **Phase 1 keeps the portable vocabulary tiny**
   - Phase 1 likely needs no more than optional `advertised` / `withheld` / `withdrawn` / `expired` / `critical` / `unknown` observations plus evidence anchors when an adapter can prove them.
   - Steward should resist freezing a generic registry API, cross-cluster service-discovery grammar, or leader-election plane through this seam.

## Phase-1 non-goals
- a portable service-registry or DNS-control protocol;
- a distributed lease, lock, or leadership family;
- automatic cross-component discovery topology management;
- implying that published presence proves readiness, stable serving, or takeover;
- a generic balancer, health-check, or mesh membership grammar.

## Adjacent docs
- `activation-posture-v0.md`
- `continuity-escrow-posture-v0.md`
- `readiness-posture-v0.md`
- `liveness-evidence-posture-v0.md`
- `shutdown-horizon-posture-v0.md`
- `execution-ground-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-K8S-LEASES
- REF-K8S-POD-LIFECYCLE
- REF-ETCD-LEASE-API
- REF-CONSUL-AGENT-CHECK
- REF-ZOOKEEPER-PROGRAMMER
