# Command-frame posture v0

Purpose: define the smallest useful **observational command-frame contract** between the SlopOS shell and terminal without turning terminal history into hidden authority.

## Posture
1. **A command interaction may have an explicit frame**
   - A frame may cover prompt, submitted command text, produced output, and completion state for one command interaction.
2. **Frames are observational first**
   - A frame helps navigation, copying exact output, bookmarking, receipt attachment, and explanation.
   - A frame does not by itself grant permission to rerun, kill, restart, or inspect a component.
3. **Small fields beat giant schemas in phase 1**
   - The smallest portable frame shape is likely close to:
     - local frame id,
     - boundary markers,
     - optional cwd / remote identity,
     - optional command line,
     - optional exit code,
     - optional receipt or transcript pointer,
     - optional component id / runtime-cycle witness,
     - trust / confidence / provenance.
4. **Trust and confidence must be first-class**
   - A frame reported explicitly by the shell is stronger than one reconstructed from buffer markers.
   - Nonce-bound or equivalent trusted reports should stay visibly distinct from low-confidence guesses.
   - A useful phase-1 model is low / medium / high confidence plus an explicit trusted bit for rerun-sensitive actions.
5. **Exact output should attach to a frame, not a regex guess**
   - Selecting “the output of the last command” or exporting a transcript slice should use explicit frame boundaries when present.
6. **Frames must degrade gracefully across hops and multiplexers**
   - SSH-like hops, tmux-like layers, or shell changes may reduce precision.
   - The contract should prefer explicit downgraded confidence over pretending precision survived.
7. **Display bytes and semantic metadata stay distinct**
   - The terminal should still preserve raw pane bytes.
   - Semantic frame metadata rides alongside rendering rather than replacing it.
8. **Remote-aware context is worth carrying when available**
   - cwd, remote identity, and pane-local notes are valuable, but they remain auxiliary observations unless backed by explicit Steward receipts or state paths.
9. **Frames should admit semantic fences**
   - A frame may need to say that a hop, multiplexer, or fallback parser lowered confidence or severed exact ancestry.
   - That is better than silently pretending exact command/cwd/trust continuity survived every layer boundary.
10. **Frame-local actions should be explicit metadata, not guesswork**
   - If a frame offers actions such as open receipt, inspect component, or stop same-run work, those should be explicit metadata tied to concrete targets.
   - High-risk actions should prefer witness/digest fences over whatever the pane currently appears to show.

## Phase-1 non-goals
- a final stable wire format for every frame field;
- perfect parsing of every shell grammar or multiline construct;
- assuming all shells can report exact command lines with equal precision;
- making command frames the canonical control bus for lifecycle operations.

## Adjacent docs
- `shell-terminal-integration-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `non-decisions-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `termination-cause-posture-v0.md`
- `action-surface-posture-v0.md`
- `context-handoff-posture-v0.md`
- `precision-fence-posture-v0.md`

## References
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-SHELL-TRUST
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-GHOSTTY-SHELL-INTEGRATION
- REF-TMUX-CONTROL-MODE
- REF-OSC133-SPEC
- REF-WARP-BLOCKS
- REF-FISH-OSC-MARKERS
