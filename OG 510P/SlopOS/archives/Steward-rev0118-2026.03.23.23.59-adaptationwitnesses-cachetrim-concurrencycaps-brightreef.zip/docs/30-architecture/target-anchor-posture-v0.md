# Target-anchor posture v0

Purpose: define a **tiny observational/action-binding seam** for explicit, bounded anchors that let shell/terminal affordances point at the *right exact object* without scraping rendered text or smuggling raw capability through the terminal stream.

## Posture
1. **Anchors name concrete objects, not ambient authority**
   - A target anchor should identify a concrete Steward-relevant object such as a command frame, exact output slice, receipt, transcript span, runtime-cycle witness, component, or doc/error location.
   - Possessing an anchor must not itself grant permission to stop, restart, mutate, or otherwise exercise ambient authority.
2. **Phase-1 anchors should stay opaque and bounded**
   - Prefer short opaque tokens or tightly scoped descriptors over human-reconstructed text selectors.
   - Avoid freezing a giant globally stable naming system before there is real pressure for it.
3. **Freshness and staleness must stay explicit**
   - Anchors belong to a semantic epoch / hop lineage / confidence context.
   - After resync, restart, hop change, or target disappearance, the UI should be able to say “stale”, “moved”, or “no longer exact” instead of guessing.
4. **Exact anchors should outrank heuristic links**
   - If Steward or the shell can supply an explicit target anchor, the shell/terminal stack should prefer it over regex link detection, path scraping, or search-by-visible-text fallbacks.
5. **Riskier actions require stronger binding**
   - Low-risk actions such as copy/open/reveal can work with weaker anchors or downgraded precision.
   - Higher-risk actions such as inspect-same-run, stop-same-run, or open-transcript-for-this-frame should require fresher exact anchors, expected cycle witnesses, or other explicit stale fences.
6. **Anchors should compose with hyperlinks, chips, marks, and notifications**
   - A hyperlink, action chip, palette entry, command-finished notification, or selection affordance should be able to carry or resolve through an explicit target anchor.
   - The terminal should not need to infer intent from surrounding prose once a target anchor exists.
7. **Selections should be promotable to explicit anchors when possible**
   - If a user selects a command frame or exact output zone, Steward should prefer promoting that selection to an anchor-bound object rather than preserving only a brittle text range.
8. **Remote and multiplexer paths must stay visible**
   - Anchors that refer to remote files, remote frames, or hop-scoped objects should carry enough path context to remain honest about where the target lives.
   - This should remain descriptive path truth, not a hidden transport-control channel.
9. **Copy/share behavior should degrade safely**
   - Copying or exporting an anchor-backed affordance should preserve a human-usable fallback such as text or URL when possible.
   - Raw privileged handles or implementation-only secrets should not leak merely because a terminal widget was copied.
10. **Unsupported layers should fail soft**
   - A layer that cannot preserve exact anchors should be allowed to degrade to plain hyperlink/text behavior while surfacing the precision loss.
   - The system should prefer visible downgrade over magical “best effort” retargeting.

## Phase-1 non-goals
- a universal globally stable object-addressing scheme for all Steward state;
- embedding raw authority-bearing capabilities in terminal-visible text;
- forcing every terminal or hop layer to understand exact anchors;
- guaranteeing that copied/exported anchors stay valid forever;
- inventing a giant remote-control protocol merely to support clickable shell affordances.

## Adjacent docs
- `action-surface-posture-v0.md`
- `command-frame-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `precision-fence-posture-v0.md`
- `attention-hint-posture-v0.md`
- `context-handoff-posture-v0.md`
- `transient-promotion-posture-v0.md`

## References
- REF-ITERM2-COMMAND-SELECTION
- REF-WEZTERM-HYPERLINKS
- REF-KITTY-OPEN-ACTIONS
- REF-VSCODE-TERMINAL-BASICS
- REF-TMUX-CONTROL-MODE
