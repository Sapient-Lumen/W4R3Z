# Consumable-grant posture v0

Purpose: define a **tiny use-bounded grant seam** so some transient powers can be **spent by use** rather than living only by timeout, without turning Steward into a generic quota wallet, delegation calculus, or approval-token platform.

## Posture
1. **Some transient grants should be use-bounded, not only time-bounded**
   - A one-shot activation hint, one-use reveal/open override, or similarly narrow transient power may be safer when it is consumed by successful use.
   - Time-based expiry remains useful, but it is not the only healthy bound.
2. **Consumption is an explicit state change**
   - `fresh`, `consumed`, `expired`, `revoked`, `denied`, `invalid`, and `unknown` are not synonyms.
   - Steward should keep those outcomes distinct anywhere the host can observe them.
3. **Use budget should only attenuate**
   - A consumable grant may start with `1` or a small reviewed remaining-use budget.
   - Additional uses require a fresh reviewed grant, not silent mutation of the old one.
4. **Consumption should bind to one reviewed target or action family**
   - A use-bounded grant should stay tied to one exact target, selector, action family, or request context.
   - “This one-time thing can now be reused for nearby-but-different actions” is exactly the folklore this seam exists to resist.
5. **History and receipts do not recreate spendable authority**
   - Seeing an old chip, receipt, descriptor, or transcript marker must not recreate the underlying live use budget.
   - Historical evidence may explain what was issued or consumed, but it does not prove current spendable power.
6. **Under the membrane, hosts may realize this with single-use tokens or limited-use proxies**
   - One-shot activation tokens, approval codes, or local proxy objects with remaining-use counters are all fair game for implementations.
   - Publicly, Steward should freeze only the small meaning that a reviewed transient grant may be consumed by use.
7. **Shell and terminal surfaces should show use-bounded truth honestly**
   - A chip, card, or action rail may say `one use left`, `consumed`, `expired`, or `already spent`.
   - Exact actions should prefer denial or downgrade once the underlying use budget is gone instead of replaying from stale scrollback.
8. **Keep the seam smaller than a generic delegation or quota family**
   - Optional remaining-use count, optional target binding, explicit consumed/expired outcomes, and one exact fresh-grant path are enough for Phase 1.
   - Steward should not freeze a portable token wallet, generic metering plane, or rich spend-policy algebra through this seam.

## Phase-1 non-goals
- a generic delegation-token platform;
- a portable spend-quota or rate-limit accounting family;
- guaranteeing that every host can surface identical consumed-versus-invalid detail;
- turning every approval or chooser into a use-bounded object by default;
- treating historical descriptors or receipts as current spendable authority.

## Adjacent docs
- `grant-handle-posture-v0.md`
- `request-activation-posture-v0.md`
- `request-context-posture-v0.md`
- `attention-hint-posture-v0.md`
- `action-surface-posture-v0.md`
- `replay-gate-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-XDG-ACTIVATION-V1
- REF-XDG-PORTAL-OPENURI
- REF-OAUTH-RFC6749
