# Renewal-window posture v0

Purpose: define a **tiny exact renewal-window seam** so live claims can expire, renew, and degrade honestly without turning Steward into a generic lease fabric, watchdog plane, or distributed lock service.

This doc is intentionally narrow. It does **not** design a universal heartbeat protocol, leader-election family, or portable keepalive algebra.

## Posture
1. **Live claims may carry one exact renew-or-expire story**
   - A grant handle, stop-deferral window, activity hint, or other live observational claim may carry one compact expiry / renew-by budget when that meaning is useful.
   - Steward should prefer this over sticky “probably still active” folklore.
2. **Renewal confirms continuity of the same claim, not broader truth**
   - Renewing a watchdog, lease, or grace window says “this exact live thing is still asserted through here”.
   - It does not by itself prove full service health, grant new authority, or silently widen scope.
3. **The holder may request a budget, but the manager chooses the real window**
   - A requester may ask for a deadline, TTL, or grace duration.
   - The runtime or manager may clamp, shorten, or otherwise choose the actual renewal window it is willing to honor.
4. **Missing renewal should fail stale or closed, not drift into ambient persistence**
   - If the expected renewal does not arrive in time, Steward should prefer outcomes such as `expired`, `stale`, `revoked`, or `needs-refresh`.
   - Silence should not quietly turn into forever-valid state.
5. **Renewal and widening are different moves**
   - Renewing an existing live claim should keep the same basic scope and kind.
   - If duration, scope, or power must grow materially, the healthy default is a fresh reviewed request or handle rather than silent mutation.
6. **Close, revoke, expire, and timeout remain distinct facts**
   - An explicit release, a policy revocation, a missed renewal, and a hard timeout should remain distinguishable where the host can observe them.
   - Steward should not flatten all endings into one vague “it stopped” bucket.
7. **Shell and chrome should surface renewal budgets honestly**
   - Countdown chips, “renewed through T”, “last renewal from X”, or “expired waiting for renewal” cues can be excellent UX when tied to an exact handle or view.
   - That chrome stays observational; it does not itself grant lifecycle authority.
8. **Keep the portable contract smaller than a generic lease system**
   - One compact expiry / remaining / renew action story is enough for Phase 1.
   - Steward should not freeze a distributed lock service, leader-election protocol, or giant keepalive vocabulary through this seam.

## Phase-1 non-goals
- a universal heartbeat cadence for every runtime;
- portable leader election, distributed locks, or consensus semantics;
- guaranteeing that every host supports renewable windows equally well;
- turning every activity hint into a renewable lease;
- pretending a renewed claim implies broad service health or correctness.

## Adjacent docs
- `grant-handle-posture-v0.md`
- `request-context-posture-v0.md`
- `freshness-decay-posture-v0.md`
- `activity-accounting-posture-v0.md`
- `stop-deferral-posture-v0.md`
- `observation-cursor-posture-v0.md`
- `shell-terminal-integration-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-SD-WATCHDOG-ENABLED
- REF-SD-NOTIFY
- REF-K8S-LEASES
- REF-ETCD-LEASES
- REF-GO-CONTEXT
