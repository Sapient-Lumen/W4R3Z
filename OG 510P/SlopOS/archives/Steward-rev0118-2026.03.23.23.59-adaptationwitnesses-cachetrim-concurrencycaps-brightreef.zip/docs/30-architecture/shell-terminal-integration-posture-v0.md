# Shell + terminal integration posture v0

Purpose: identify how Steward can make the custom SlopOS shell+terminal unusually good without letting PTY folklore become lifecycle semantics.

## Posture
1. **Use an explicit semantic side channel**
   - Prompt boundaries, command start/finish, working directory, hyperlinks, marks, and structured receipts should travel on an explicit shell/terminal channel, not be inferred from raw text alone.
2. **Expose prompt / input / output / command-frame boundaries**
   - Prompt, input, and output zones should be inspectable and navigable.
   - The shell and terminal may also treat a full command interaction as one semantic frame/block for navigation, copy, bookmarking, and receipt attachment.
3. **Zone-addressable actions are worth stealing**
   - When semantic zones exist, the terminal should be able to ask “what exact prompt/input/output zone is under this cell?” and bind copy/open/explain actions to that answer.
   - This is healthier than pane-wide cwd guesses or regex archaeology over visible text.
4. **Keep stdout/stderr as program output**
   - Semantic metadata should not require rewriting ordinary command output.
5. **Prefer a parseable side channel over buffer archaeology**
   - A machine-friendly companion channel for marks, frame boundaries, or pane state is healthier than re-parsing rendered bytes and hoping for the best.
   - tmux control mode is a good reminder that a text protocol can stay parseable and SSH-friendly without replacing the terminal stream.
6. **Prefer small interoperable marker sets first**
   - Phase 1 should happily reuse small building blocks such as working-directory markers, prompt/output markers, marks, and hyperlinks where they fit.
   - A giant custom RPC is a later option, not the starting point.
7. **Command receipts beat log scraping**
   - When lifecycle-aware commands run, the shell should be able to attach a compact receipt or sidecar summary rather than forcing the terminal to guess what happened.
8. **Runtime-cycle witnesses and component ids are good plumbing material**
   - When a command starts, inspects, or promotes a component, the shell/terminal stack should be able to carry component identity and optional runtime-cycle witness information alongside the frame.
   - That makes “is this still the same run?” and “what did that command actually act on?” much less guessy.
9. **Fresh cwd and prompt metadata should win over stale guesses**
   - The shell should be willing to report cwd on each fresh prompt and provide prompt-end / command-start markers when available so terminals do not preserve stale remote context after hops or subprocesses.
10. **Remote-aware semantic transport matters**
   - Shell integration should survive SSH-like hops well enough to preserve cwd, prompt marks, command-frame boundaries, and selected pane state when possible.
11. **Hop lineage should stay explicit where remote-aware UX matters**
   - Remote host, multiplexer, and preserved-semantic path hints are worth carrying explicitly when available.
   - That helps keep cwd, histories, actions, and titles scoped to the actual path instead of a flat PTY fiction.
12. **Pane-scoped state is promising, but should stay observational first**
   - Extra shell state such as remote identity, active component, or last receipt digest may be useful as pane-scoped metadata.
   - That metadata must not silently widen authority or become the only truth.
13. **Marker provenance and confidence matter**
   - Explicit shell-reported command data is better than blind terminal scraping.
   - When a shell/terminal pair can bind semantic markers to a session nonce or equivalent trust signal, replay and rerun UX can become safer.
   - Buffer-derived guesses should remain visibly lower-confidence and non-authoritative.
14. **Confidence should be allowed to refine over time**
   - Fresh prompt resync, command completion, or receipt arrival may let the shell/terminal pair upgrade an earlier guess.
   - Steward should allow later exactness to replace earlier approximation without rewriting history about how the first guess was obtained.
15. **Plumbing is a first-class opportunity**
   - File names, digests, URLs, component ids, error locations, and receipt pointers should be plumbable through rules, not only copied by hand.
16. **Keyboard, paste, and click semantics deserve explicit handling**
   - Bracketed paste and enhanced key/click reporting are the same kind of win as prompt markers: they reduce ambiguity without silently changing authority.
   - Steward should steal the lesson of explicit input-side semantics before inventing shell-local hacks.
17. **Layer boundaries should have explicit semantic fences**
   - SSH-like hops, tmux-like layers, or shell restarts should be able to declare “semantic precision may have dropped here.”
   - That is better than silently preserving stale cwd, command, or trust assumptions across layers.
18. **Fresh resync should be first-class**
   - When a shell, hop layer, or terminal gets confused, the preferred recovery is to emit fresh prompt/cwd/capability state and establish a new semantic epoch.
   - That is healthier than mutating stale certainty in place.
19. **Capability handshakes should beat compatibility folklore**
   - `TERM`, terminfo, or remembered success are useful hints but not proof of exact support.
   - Where richer semantics matter, the shell/terminal stack should prefer fresh explicit capability signals and keep them scoped to the actual pane/hop path.
20. **Progressive enhancement should beat giant mandatory baselines**
   - Small optional features such as richer keyboard input, synchronized rendering, prompt markers, and cwd reporting should be treated as capabilities that can be used when present and ignored safely when absent.
   - Steward should not require every shell, terminal, and multiplexer to agree on a giant perfect baseline before semantic UX becomes useful.
21. **Command-finish UX should prefer explicit finish data**
   - Notifications, marks, and “show me the last finished command” affordances should attach to explicit command-frame completion and Steward receipts when available.
   - They should not guess command completion from arbitrary output patterns.
22. **Attention cues should stay explicit, focus-aware, and user-filterable**
   - Bells, badges, progress rings, and command-finished notifications are genuinely useful once command frames are explicit.
   - They should remain bounded hints tied to fresh semantic state rather than a hidden automation or notification bus.
23. **Attach lanes should stay explicit**
   - Observe-only witness mode, interactive attach, lifecycle control, and debug entry should remain visibly different lanes even when they share one transport or one visible pane.
   - Terminal presence must not silently widen into lifecycle authority.
24. **Action surfaces should stay explicit and user-invoked**
   - Hyperlinks, frame-local chips, context menus, and command-palette entries are promising, but they should bind to explicit Steward targets and remain user-invoked.
   - They must not become a hidden ambient mutation bus.
25. **Terminal UX is not lifecycle authority**
   - Marks, alerts, semantic zones, hyperlinks, and command blocks are observational and ergonomic; they must not become implicit permission to kill/restart/reconfigure components.
26. **Paste should remain a distinct intent path**
   - Bracketed paste is only a baseline. Steward's shell+terminal should be free to preview, fence, or downgrade suspicious pasted control sequences or multiline payloads instead of pretending paste is identical to keypresses.
27. **Richer terminal semantics must degrade by safe omission**
   - Valid but unsupported Steward escape sequences or semantic hints should be safely ignorable so mixed hops, multiplexers, and older terminals lose enhancement rather than corrupting interaction.
28. **Remote-aware comfort must stay observational**
   - Same-host same-directory spawn, copied terminfo, carried markers, or frame-local notifications are excellent ergonomics, but they must remain visible transport facts rather than ambient proof that authority or precision survived every hop.
29. **Line-local targets should beat pane-wide guesses**
   - Open/edit/explain affordances should prefer exact frame or line-local target data such as per-line cwd, explicit file:line capture, and anchor ids rather than guessing from the pane's current cwd or visible text neighborhood.
30. **Semantic inspectors are worth having**
   - When semantic framing goes wrong, the terminal should be able to reveal prompt/input/output zones, provenance, and precision fences directly instead of forcing users to debug escape traffic by folklore.
31. **Context inheritance should stay explicit per action**
   - New tabs, splits, windows, and remote reruns may inherit cwd or hop context only when that inheritance was explicitly reported and remains policy-allowed; the UI should be able to say whether the result is current, reported, or merely remembered.
32. **Terminal-synthesized marks are fallback, not equal truth**
   - Auto-inserted prompt marks or Enter-based scroll markers can be useful scaffolding when shell integration is absent or partial.
   - They should remain visibly lower-confidence than shell-reported boundaries and should not inherit trusted-shell action shortcuts.
33. **Visible command guides should be filterable and exact-object-backed**
   - Guide rails, sticky headers, and similar command chrome are most useful when they can ignore noisy commands, bind to exact frame anchors, and expose diagnostics about semantic quality.
   - Steward should prefer one small guide seam over ad hoc per-widget heuristics.
34. **Spawn/context inheritance should stay explicit per action**
   - Tabs, splits, reruns, and “open a shell here” actions should be able to inherit cwd or domain context deliberately from an exact frame or pane.
   - Same-context comfort is great, but it should remain labelable, policy-bounded, and distinct from ambient authority.
35. **Remembered shelves should stay obviously remembered**
   - Recent commands, recent directories, and recent Steward objects can make the custom shell feel brilliant when they are scoped to explicit host or hop context.
   - Those shelves should stay freshness-labeled convenience and should resolve through explicit selectors or anchors before doing anything riskier than reveal, copy, or paste.
36. **Transcript landmarks should stay exact-object-backed and provenance-labeled**
   - Marks, annotations, alerts, and jump targets are most useful when they bind to exact frames, transcript spans, or receipt refs with clear shell, manager, user, or guessed provenance.
   - Steward should prefer one tiny landmark seam over ad hoc per-widget marks hidden in scrollback or history UI.
37. **Affordance diagnostics should be one click away**
   - If a command guide, quick fix, same-directory launch, replay card, or prompt-click feature is enabled, degraded, blocked, or stale, the shell/terminal should be able to explain why in terms of exact support, provenance, freshness, and policy.
   - Steward should prefer explicit per-affordance explanation over folklore like “this terminal feature is flaky sometimes.”
38. **Remembered-data retention should be explicit and erasable**
   - Persisted command history, directory history, paste history, and host breadcrumbs can make the shell brilliant, but they should declare whether they are session-local, local-on-disk, imported, or synced.
   - Search can unify remembered classes, but retained data should stay class-labeled, scopeable, and clearly separate from replay authority or live-state truth.
39. **Activation hints should not smuggle focus authority**
   - A command frame may carry startup notification or activation-token style hints next to an exact launch/open request.
   - Those hints should stay visibly separate from lifecycle receipts, target identity, and readiness so the shell does not grow an ambient foreground-control myth.
40. **Same-run shell actions should ride witnesses, not displayed process ids**
   - UI affordances like `stop same run`, `compare with current`, or `explain why this ended` should fence on component id plus runtime-cycle witness rather than any rendered PID or guessed process-tree text.
   - Under the membrane, implementations may use pidfds or similar exact-run handles, but the shell should present opaque same-run truth rather than leaking host-specific control folklore.
41. **Mediated UI detours should stay handle-shaped in the shell**
   - If a prompt action opens a chooser, portal, approval sheet, or similar mediated UI, the shell should keep a small pending-request anchor with eventual response, cancel, expiry, and optional deadline outcome.
   - That is healthier than a modal side effect with no attributable object back in the transcript or chrome.
42. **Input capture should distinguish armed from active**
   - Rich keyboard or pointer capture may be requested before it is actually flowing.
   - The shell+terminal should be able to show `armed`, `active`, `released`, or `denied` rather than pretending “capture requested” and “capture delivering” are the same truth.
43. **Shortcut sessions should be inspectable and revocable**
   - Out-of-focus or global shortcut bundles can be delightful when they are exact sessions with activation/deactivation signals, clear owners, and one revoke path.
   - They should not become a hidden always-on ambient control layer.
44. **Live grant handles should appear as exact shell objects**
   - Pending requests, stop-deferral leases, capture sessions, and similar transient powers should be able to appear as small exact chips or cards with state such as `pending`, `active`, `released`, `revoked`, or `expired`.
   - Closing or revoking them should target the exact handle rather than relying on focus, cursor position, or invisible ambient mode flips.
45. **Return tickets should stay exact and expiring**
   - Browser/auth/chooser detours may need to bring a result, reveal cue, or local wake back to the originating shell surface.
   - Steward should bind those returns to one exact ticket or pending object, prefer single-use semantics, and degrade to visible `result available` or `rebind required` truth instead of guessing from last focus.
46. **Unified remembered search should keep lane labels and lane-appropriate actions**
   - One search surface may legitimately span command history, workflows, notebook blocks, prompts, and proposal memory when the shell is trying to help the user find something quickly.
   - The shell+terminal should still say what lane a hit came from and default to lane-appropriate actions such as `insert`, `open conversation`, `view receipt`, or `rerun as pending` instead of flattening everything into `execute`.
47. **Approval and autonomy should stay visibly runged**
   - Proposal-only help, ask-before-run, scoped auto-approval, and run-until-completion are different powers and should surface as such in shell chrome, receipts, and reconnect behavior.
   - Higher rungs should be loud, stoppable, and willing to degrade back to witness or ask-again when footing, policy, or containment changes.
48. **Protective adaptation should be shell-visible when exact**
   - If the runtime or manager deliberately trims caches, caps concurrency, defers optional work, or narrows mode, the shell should be able to show that as explicit response truth instead of forcing users to reverse-engineer vague degraded behavior.
   - Those chips explain operating posture; they do not become a portable autoscaling or brownout control plane.

## Phase-1 non-goals
- parsing every shell language feature;
- letting the terminal issue lifecycle mutations without explicit user action and authorization;
- inventing a giant shell/terminal RPC protocol before small semantic channels are tried;
- making command blocks or semantic frames the only representation of terminal history;
- treating replayable shell markers as trusted control input without provenance.

## Adjacent docs
- `design-principles-v0.md`
- `non-decisions-v0.md`
- `supervision-posture-v0.md`
- `activation-posture-v0.md`
- `readiness-posture-v0.md`
- `lifecycle-observation-posture-v0.md`
- `status-channel-posture-v0.md`
- `command-frame-posture-v0.md`
- `observation-confidence-posture-v0.md`
- `capability-handshake-posture-v0.md`
- `capability-ledger-posture-v0.md`
- `semantic-epoch-posture-v0.md`
- `hop-lineage-posture-v0.md`
- `observation-subscription-posture-v0.md`
- `provisional-state-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `termination-cause-posture-v0.md`
- `action-surface-posture-v0.md`
- `attach-lane-posture-v0.md`
- `attach-continuity-posture-v0.md`
- `precision-fence-posture-v0.md`
- `attention-hint-posture-v0.md`
- `grant-handle-posture-v0.md`
- `chrome-lane-posture-v0.md`
- `command-guide-posture-v0.md`
- `transcript-landmark-posture-v0.md`
- `context-inheritance-posture-v0.md`
- `remembered-shelf-posture-v0.md`
- `mode-baseline-posture-v0.md`
- `surface-diagnostics-posture-v0.md`
- `retention-surface-posture-v0.md`
- `proposal-lane-posture-v0.md`
- `preflight-lane-posture-v0.md`
- `history-lane-posture-v0.md`
- `request-activation-posture-v0.md`
- `request-context-posture-v0.md`
- `return-ticket-posture-v0.md`
- `adaptation-witness-posture-v0.md`

## References
- REF-NUSHELL-PIPELINES
- REF-PLAN9-PLUMBING
- REF-VSCODE-SHELL-INTEGRATION
- REF-VSCODE-SHELL-TRUST
- REF-WINDOWS-TERMINAL-SHELL-INTEGRATION
- REF-WEZTERM-SHELL-INTEGRATION
- REF-KITTY-SHELL-INTEGRATION
- REF-ITERM2-SHELL-INTEGRATION
- REF-ITERM2-ESCAPE-CODES
- REF-OSC133-SPEC
- REF-WARP-BLOCKS
- REF-TMUX-CONTROL-MODE
- REF-GHOSTTY-SHELL-INTEGRATION
- REF-KITTY-KEYBOARD-PROTOCOL
- REF-XTERM-BRACKETED-PASTE
- REF-FISH-OSC-MARKERS
- REF-FISH-TERMINAL-COMPAT
- REF-GHOSTTY-RELEASE-130
- REF-WEZTERM-SYNC-RENDER
- REF-ITERM2-FEATURE-REPORTING
- REF-WEZTERM-PANE-USER-VARS
- REF-KITTY-SSH
- REF-NCURSES-FAQ
- REF-XTERM-FAQ
- REF-ITERM2-SEMANTIC-HISTORY
- REF-VSCODE-UPDATE-1103
- REF-VSCODE-UPDATE-1104
- REF-VSCODE-UPDATE-1109
- REF-WINDOWS-TERMINAL-ADVANCED-PROFILE
- REF-WINDOWS-TERMINAL-ACTIONS
- REF-ITERM2-MENU-ITEMS
- REF-XDG-PORTAL-REQUEST
- REF-ITERM2-FEATURES
- REF-ITERM2-PREFERENCES-GENERAL
- REF-WARP-COMMAND-SEARCH
- REF-VSCODE-UPDATE-1066
- REF-WEZTERM-SPAWNCOMMAND
- REF-WEZTERM-LAUNCHING-PROGRAMS
- REF-LINUX-PIDFD-OPEN
- REF-XDG-ACTIVATION-V1
- REF-DESKTOP-ENTRY-DBUS-ACTIVATION
- REF-GRPC-DEADLINES
- REF-XDG-PORTAL-INPUTCAPTURE
- REF-XDG-PORTAL-GLOBALSHORTCUTS
- REF-XDG-PORTAL-REMOTE-DESKTOP
- REF-RFC8252-NATIVE-APPS
