# Fence-token posture v0

Purpose: define a **tiny stale-holder rejection seam** so some reassignable live claims can carry a current-issuance fence token or equivalent ownership witness without turning Steward into a distributed lock service, leader-election plane, or global monotonic sequencer.

## Posture
1. **Fence tokens name current live issuance, not request identity or broad health**
   - A fence token says “this live claim instance supersedes older claim instances for the same issuer/subject lineage”.
   - It is not the same thing as the request id, effect key, runtime-cycle witness, or current readiness proof for the whole component.
2. **Reassignment or supersession must advance the fence story**
   - If a live claim moves to a new holder, a fresh issuance should receive a newer fence token or equally exact current-owner witness.
   - An old holder must not keep acting merely because it has not yet noticed revocation, expiry, or ownership loss.
3. **Simple renewal should not pretend to be supersession**
   - Renewing the same still-current claim may extend its window without minting a newer token.
   - Steward should keep “same holder renewed” distinct from “new holder superseded the old one”.
4. **Fence tokens exist to reject stale holders at effect time**
   - Where delayed, paused, partitioned, or otherwise stale holders could still reach an external resource or helper path, that path should be free to compare the carried fence token or current-owner witness and reject older claim instances.
   - This is healthier than trusting lease timeout folklore or hoping the old actor stops in time.
5. **Comparison scope stays narrow and issuer-local**
   - Any ordering or equality semantics only make sense within one reviewed issuer/claim lineage.
   - Steward should not imply one cross-host, cross-family total order of all fence tokens.
6. **Fence tokens complement grant handles, renewals, and preconditions**
   - Grant handles answer “which exact transient claim object do I hold?”
   - Renewal windows answer “is this exact claim still being refreshed?”
   - Precondition witnesses answer “is the world I observed still the one I meant?”
   - Fence tokens answer “has this claim lineage moved on to a newer holder or issuance?”
7. **Visible outcomes matter**
   - `current`, `renewed`, `superseded`, `stale-holder-rejected`, and `ownership-moved` should remain visibly different outcomes instead of collapsing into one vague denial or timeout bucket.
8. **Not every seam needs a fence token**
   - Many read-only, non-reassignable, or strictly local actions do not benefit from this extra witness.
   - Steward should reserve it for reassignable live claims and external side effects where stale-holder confusion is a real risk.
9. **Keep the seam smaller than a generic distributed-lock family**
   - One optional issuer-scoped fence token or current-owner witness is enough for Phase 1.
   - Steward should not freeze a universal lock RPC, leader-election API, or global monotonic sequencer through this seam.

## Phase-1 non-goals
- a portable distributed lock service;
- a portable leader-election protocol;
- a global ordering relation across unrelated components or claim families;
- requiring every grant, activation, or action to carry a fence token;
- treating a fence token as a general capability or current health proof.

## Adjacent docs
- `grant-handle-posture-v0.md`
- `renewal-window-posture-v0.md`
- `consumable-grant-posture-v0.md`
- `precondition-witness-posture-v0.md`
- `runtime-cycle-witness-posture-v0.md`
- `request-context-posture-v0.md`
- `effect-key-posture-v0.md`
- `action-surface-posture-v0.md`
- `non-decisions-v0.md`

## References
- REF-HAZELCAST-FENCEDLOCK
- REF-ETCD-CONCURRENCY-LOCK
