# ADR-0001: archive hygiene and release discipline

- Status: accepted
- Date: 2026-03-21

## Context

Steward is being designed while its parent system, SlopOS, is still in design. The main risk in that situation is not only bad architecture; it is **archive drift**:
- new ideas appear without stable placement,
- external sources get re-imported inconsistently,
- revisions become hard to hand off,
- later passes cannot tell what was newly added versus long-standing posture.

## Decision

The Steward repo will adopt, from revision 1 onward:
- explicit `CHANGELOG.md` top-entry revision numbering;
- a generated `out/context_pack.md`;
- `make lint`;
- self-verifying packaged handoff zips with embedded `RELEASE-MANIFEST.json`;
- explicit REF/EVID/claim/invariant/proof-obligation registries even in small form.

## Consequences

Good:
- revisions become easier to package, verify, and continue;
- early research stays reviewable;
- architecture docs can stay small without losing continuity.

Cost:
- a little more ceremony in a still-early project;
- contributors must wire docs and refresh the context pack.

## Links

- `README.md`
- `docs/00-meta/archive-policy.md`
- `docs/00-meta/llm-runbook.md`
- `tools/package_release.py`
- `tools/verify_release_bundle.py`
