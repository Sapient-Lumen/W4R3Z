# ADRs

Architectural decisions belong here once Steward is ready to freeze a seam.

At revision 1, the repo intentionally avoids major architecture ADRs. The only fixed decision is repo/release hygiene.
