# Contributing

This repository is a living archive, not a scratchpad dump.

Before large edits:
1. refresh the must-read set in `docs/00-meta/llm-runbook.md`;
2. run `make context-pack`;
3. make changes;
4. run `make lint`;
5. regenerate the context pack if the top `CHANGELOG.md` entry changed.

Rules:
- prefer editing existing docs over spawning new ones;
- attach important new statements to at least one of `{A, C, I, PO, ADR, EVID, REF}`;
- keep raw URLs out of ordinary prose; put them in `docs/00-meta/bibliography.md` and `docs/00-meta/external-source-locks.json`;
- if a new document introduces a new stable seam, wire it through `docs/README.md`, `docs/30-architecture/posture-index.md`, `docs/00-meta/llm-runbook.md`, and `docs/00-meta/trajectory-map.md` in the same revision.
