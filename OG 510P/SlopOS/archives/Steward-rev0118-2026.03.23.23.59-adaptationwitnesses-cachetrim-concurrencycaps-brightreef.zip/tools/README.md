# Tools

- `run_lint_suite.py` — repo hygiene checks
- `gen_context_pack.py` — compact continuation pack
- `gen_external_source_review_queue.py` — render the review queue from source locks
- `package_release.py` — canonical Steward zip packaging with embedded manifest
- `verify_release_bundle.py` — verify a packaged zip against its manifest
