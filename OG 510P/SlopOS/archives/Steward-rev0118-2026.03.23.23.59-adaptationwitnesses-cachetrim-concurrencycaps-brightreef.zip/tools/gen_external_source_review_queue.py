#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCKS = ROOT / 'docs/00-meta/external-source-locks.json'
OUT = ROOT / 'docs/00-meta/external-source-review-queue.md'


def main() -> int:
    rows = json.loads(LOCKS.read_text(encoding='utf-8'))
    lines = [
        '# External source review queue',
        '',
        'Generated from `external-source-locks.json`.',
        '',
        '| reference ID | Retrieved | Review by | Reason |',
        '| --- | --- | --- | --- |',
    ]
    for row in rows:
        lines.append(f"| {row['ref_id']} | {row['retrieved_on']} | {row['review_by']} | {row['notes']} |")
    OUT.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(OUT)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
