#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from verify_release_bundle import verify_bundle

ROOT = Path(__file__).resolve().parents[1]
MANIFEST_NAME = 'RELEASE-MANIFEST.json'
RE_TOP = re.compile(r'^##\s+Revised(\d+)\s+\((\d{4})-(\d{2})-(\d{2})\)\s*$')
RE_CTX_HDR = re.compile(r'^#\s+Context pack\s+—\s+(Revised\d+)\s+\((\d{4}-\d{2}-\d{2})\)\s*$')
RE_BULLET = re.compile(r'^\-\s+(.+?)\s*$')
RE_STAMP = re.compile(r'^(\d{4})\.(\d{2})\.(\d{2})\.(\d{2})\.(\d{2})$')
RE_SLUG = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')
CANONICAL_MODE = 0o100644

def fail(msg: str) -> None:
    raise SystemExit(msg)

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def parse_top_changelog() -> tuple[int, str, list[str]]:
    lines = (ROOT / 'CHANGELOG.md').read_text(encoding='utf-8').splitlines()
    for i, ln in enumerate(lines):
        m = RE_TOP.match(ln.strip())
        if not m:
            continue
        rev = int(m.group(1))
        date = f'{m.group(2)}-{m.group(3)}-{m.group(4)}'
        bullets = []
        for rest in lines[i+1:]:
            if rest.startswith('## '):
                break
            m2 = RE_BULLET.match(rest)
            if m2:
                bullets.append(f'- {m2.group(1).strip()}')
        return rev, date, bullets
    fail('CHANGELOG top entry missing or malformed')

def require_fresh_context_pack(revision: int, date: str, bullets: list[str]) -> None:
    ctx = ROOT / 'out/context_pack.md'
    if not ctx.exists():
        fail('missing out/context_pack.md; run make context-pack')
    lines = ctx.read_text(encoding='utf-8').splitlines()
    if not lines:
        fail('empty out/context_pack.md')
    m = RE_CTX_HDR.match(lines[0].strip())
    if not m:
        fail('bad context pack header')
    if m.group(1) != f'Revised{revision}' or m.group(2) != date:
        fail('stale context pack header')
    seen = []
    inside = False
    for ln in lines:
        if ln.strip() == '## New in latest revision':
            inside = True
            continue
        if inside and ln.startswith('## '):
            break
        if inside:
            m2 = RE_BULLET.match(ln.strip())
            if m2:
                seen.append(f'- {m2.group(1).strip()}')
    if seen != bullets:
        fail('stale context pack bullets')

def iter_files() -> list[Path]:
    out = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in sorted(dirnames) if d not in {'.git', '__pycache__'}]
        for name in sorted(filenames):
            p = Path(dirpath) / name
            rel = p.relative_to(ROOT)
            if name.endswith(('.pyc', '.pyo', '.zip')):
                continue
            if rel.as_posix() == MANIFEST_NAME:
                continue
            if rel.parts and rel.parts[0] == 'out' and rel.as_posix() != 'out/context_pack.md':
                continue
            out.append(rel)
    return sorted(out, key=lambda p: p.as_posix())

def zipinfo_for(name: str, dt: tuple[int, int, int, int, int, int]) -> ZipInfo:
    zi = ZipInfo(name)
    zi.date_time = dt
    zi.compress_type = ZIP_DEFLATED
    zi.external_attr = CANONICAL_MODE << 16
    zi.create_system = 3
    return zi

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--timestamp', required=True)
    ap.add_argument('--slug', required=True)
    ap.add_argument('--outdir', default='/mnt/data')
    args = ap.parse_args()

    m = RE_STAMP.match(args.timestamp)
    if not m:
        fail('timestamp must be YYYY.MM.DD.HH.MM')
    if not RE_SLUG.match(args.slug):
        fail('slug must be lowercase dash-separated')

    rev, date, bullets = parse_top_changelog()
    require_fresh_context_pack(rev, date, bullets)
    dt = (int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4)), int(m.group(5)), 0)

    name = f'Steward-rev{rev:04d}-{args.timestamp}-{args.slug}.zip'
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    bundle = outdir / name

    files = iter_files()
    rows = []
    for rel in files:
        data = (ROOT / rel).read_bytes()
        rows.append({'path': rel.as_posix(), 'size': len(data), 'sha256': sha256_bytes(data)})
    manifest = {
        'manifest_version': 1,
        'archive_name': name,
        'revision': f'rev{rev:04d}',
        'revision_date': date,
        'packaging_timestamp': args.timestamp,
        'slug': args.slug,
        'context_pack_path': 'out/context_pack.md',
        'files': rows,
    }
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode('utf-8')

    with ZipFile(bundle, 'w', compression=ZIP_DEFLATED) as zf:
        for rel in files:
            data = (ROOT / rel).read_bytes()
            zf.writestr(zipinfo_for(rel.as_posix(), dt), data)
        zf.writestr(zipinfo_for(MANIFEST_NAME, dt), manifest_bytes)

    verify_bundle(bundle)
    print(bundle)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
