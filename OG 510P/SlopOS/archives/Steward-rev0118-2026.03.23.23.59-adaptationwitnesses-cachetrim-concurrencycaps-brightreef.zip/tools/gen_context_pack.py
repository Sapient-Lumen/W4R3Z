#!/usr/bin/env python3
from __future__ import annotations
import argparse
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(p: str) -> str:
    return (ROOT / p).read_text(encoding='utf-8')

def parse_top_changelog() -> tuple[str, str, list[str]]:
    lines = read('CHANGELOG.md').splitlines()
    rev = '(unknown)'
    date = '(unknown)'
    bullets: list[str] = []
    start = None
    for i, ln in enumerate(lines):
        m = re.match(r'^##\s+(Revised\d+)\s+\((\d{4}-\d{2}-\d{2})\)', ln.strip())
        if m:
            rev, date = m.group(1), m.group(2)
            start = i + 1
            break
    if start is None:
        return rev, date, bullets
    for ln in lines[start:]:
        if ln.startswith('## '):
            break
        m = re.match(r'^\-\s+(.+?)\s*$', ln)
        if m:
            bullets.append(f'- {m.group(1).strip()}')
    return rev, date, bullets

def parse_numbered_section(md: str, heading: str) -> list[str]:
    lines = md.splitlines()
    out = []
    inside = False
    for ln in lines:
        if ln.strip() == heading:
            inside = True
            continue
        if inside and ln.startswith('## '):
            break
        if not inside:
            continue
        m = re.match(r'^\d+\.\s+(.+?)\s*$', ln.strip())
        if m:
            out.append(m.group(1).strip())
    return out

def parse_bullet_section(md: str, heading: str) -> list[str]:
    lines = md.splitlines()
    out = []
    inside = False
    for ln in lines:
        if ln.strip() == heading:
            inside = True
            continue
        if inside and ln.startswith('## '):
            break
        if not inside:
            continue
        m = re.match(r'^\-\s+(.+?)\s*$', ln.strip())
        if m:
            out.append(m.group(1).strip())
    return out

def parse_must_read(md: str) -> list[str]:
    return re.findall(r'^\-\s+`([^`]+)`\s*$', md, re.M)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default='out/context_pack.md')
    args = ap.parse_args()

    rb = read('docs/00-meta/llm-runbook.md')
    tm = read('docs/00-meta/trajectory-map.md')
    rev, date, bullets = parse_top_changelog()

    nonneg = parse_numbered_section(rb, '## Non-negotiables')
    must_read = parse_must_read(rb)
    open_qs = parse_bullet_section(tm, '## Open questions (tracked as decision surfaces)')
    resolved = parse_bullet_section(tm, '## Recently resolved (keep short)')

    out = Path(ROOT / args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    body = []
    body.append(f'# Context pack — {rev} ({date})')
    body.append('')
    body.append('## New in latest revision')
    body.extend(bullets or ['- none'])
    body.append('')
    body.append('## Non-negotiables')
    body.extend([f'- {x}' for x in nonneg] or ['- none'])
    body.append('')
    body.append('## Must-read set')
    body.extend([f'- `{x}`' for x in must_read] or ['- none'])
    body.append('')
    body.append('## Open questions')
    body.extend([f'- {x}' for x in open_qs] or ['- none'])
    body.append('')
    body.append('## Recently resolved')
    body.extend([f'- {x}' for x in resolved] or ['- none'])
    body.append('')
    out.write_text('\n'.join(body) + '\n', encoding='utf-8')
    print(out)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
