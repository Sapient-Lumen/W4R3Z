#!/usr/bin/env python3
from __future__ import annotations
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALLOW_URL_FILES = {
    'docs/00-meta/bibliography.md',
    'docs/00-meta/external-source-locks.json',
    'RELEASE-MANIFEST.json',
}
MD_LINK_RE = re.compile(r'\[[^\]]+\]\(([^)]+)\)')
REF_DEF_RE = re.compile(r'\*\*(REF-[A-Z0-9-]+)\*\*')
RAW_URL_RE = re.compile(r'https?://[^\s)>\]]+')
TOP_RE = re.compile(r'^##\s+Revised(\d+)\s+\((\d{4})-(\d{2})-(\d{2})\)\s*$')
BIB_RE = re.compile(r'^- \*\*(REF-[A-Z0-9-]+)\*\* .* URL: (https?://\S+)\s*$', re.M)


def fail(msg: str) -> None:
    raise SystemExit(f'[lint] FAIL: {msg}')


def check_changelog() -> None:
    text = (ROOT / 'CHANGELOG.md').read_text(encoding='utf-8').splitlines()
    tops = [ln for ln in text if ln.startswith('## ')]
    if not tops:
        fail('CHANGELOG.md missing revision entries')
    if not TOP_RE.match(tops[0].strip()):
        fail('top CHANGELOG entry must match ## RevisedN (YYYY-MM-DD)')


def check_links() -> None:
    for p in ROOT.rglob('*.md'):
        rel = p.relative_to(ROOT).as_posix()
        text = p.read_text(encoding='utf-8')
        for m in MD_LINK_RE.finditer(text):
            target = m.group(1)
            if target.startswith(('http://', 'https://', '#', 'mailto:')):
                continue
            target_path = (p.parent / target).resolve()
            if not target_path.exists():
                fail(f'{rel}: broken relative link -> {target}')


def check_raw_urls() -> None:
    for p in ROOT.rglob('*'):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT).as_posix()
        if rel in ALLOW_URL_FILES:
            continue
        if p.suffix not in {'.md', '.json'}:
            continue
        text = p.read_text(encoding='utf-8')
        if RAW_URL_RE.search(text):
            fail(f'{rel}: raw URL found outside allowed files')


def check_bibliography_refs() -> None:
    bib = (ROOT / 'docs/00-meta/bibliography.md').read_text(encoding='utf-8')
    refs = set(REF_DEF_RE.findall(bib))
    if not refs:
        fail('bibliography missing REF IDs')
    for p in ROOT.rglob('*.md'):
        rel = p.relative_to(ROOT).as_posix()
        if rel == 'docs/00-meta/bibliography.md':
            continue
        text = p.read_text(encoding='utf-8')
        for ref in set(re.findall(r'REF-[A-Z0-9-]+', text)):
            if ref not in refs:
                fail(f'{rel}: unknown REF {ref}')


def check_bibliography_lock_sync() -> None:
    bib_text = (ROOT / 'docs/00-meta/bibliography.md').read_text(encoding='utf-8')
    bib_rows = BIB_RE.findall(bib_text)
    if not bib_rows:
        fail('bibliography missing parseable entries')
    bib_map = {ref: url for ref, url in bib_rows}
    locks = json.loads((ROOT / 'docs/00-meta/external-source-locks.json').read_text(encoding='utf-8'))
    lock_ids = [row['ref_id'] for row in locks]
    lock_map = {row['ref_id']: row['url'] for row in locks}
    bib_ids = [ref for ref, _ in bib_rows]
    if bib_ids != lock_ids:
        fail('bibliography REF order/content does not match external-source-locks.json')
    for ref, url in bib_map.items():
        if lock_map.get(ref) != url:
            fail(f'bibliography URL mismatch for {ref}')




def check_head_register_sync() -> None:
    locks = json.loads((ROOT / 'docs/00-meta/external-source-locks.json').read_text(encoding='utf-8'))
    lock_ids = {row['ref_id'] for row in locks}
    head_text = (ROOT / 'docs/00-meta/external-source-head-register.md').read_text(encoding='utf-8')
    head_ids = set(re.findall(r'REF-[A-Z0-9-]+', head_text))
    if head_ids != lock_ids:
        missing_in_head = sorted(lock_ids - head_ids)
        missing_in_locks = sorted(head_ids - lock_ids)
        fail(f'head register mismatch; missing_in_head={missing_in_head}, missing_in_locks={missing_in_locks}')

def check_runbook_paths() -> None:
    rb = (ROOT / 'docs/00-meta/llm-runbook.md').read_text(encoding='utf-8')
    paths = re.findall(r'^-\s+`([^`]+)`\s*$', rb, re.M)
    for rel in paths:
        if not (ROOT / rel).exists():
            fail(f'llm-runbook missing path target: {rel}')


def check_source_review_queue() -> None:
    locks = json.loads((ROOT / 'docs/00-meta/external-source-locks.json').read_text(encoding='utf-8'))
    queue_path = ROOT / 'docs/00-meta/external-source-review-queue.md'
    if not queue_path.exists():
        fail('missing docs/00-meta/external-source-review-queue.md')
    lines = queue_path.read_text(encoding='utf-8').splitlines()
    expected = [
        '# External source review queue',
        '',
        'Generated from `external-source-locks.json`.',
        '',
        '| reference ID | Retrieved | Review by | Reason |',
        '| --- | --- | --- | --- |',
    ]
    for row in locks:
        expected.append(f"| {row['ref_id']} | {row['retrieved_on']} | {row['review_by']} | {row['notes']} |")
    if lines != expected:
        fail('external-source-review-queue.md is stale; run make source-review-queue')


def main() -> int:
    check_changelog()
    check_links()
    check_raw_urls()
    check_bibliography_refs()
    check_bibliography_lock_sync()
    check_head_register_sync()
    check_runbook_paths()
    check_source_review_queue()
    print('[lint] OK')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
