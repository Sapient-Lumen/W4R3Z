#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path
from zipfile import ZipFile

MANIFEST_NAME = 'RELEASE-MANIFEST.json'
RE_BUNDLE = re.compile(r'^Steward-(rev\d{4})-(\d{4}\.\d{2}\.\d{2}\.\d{2}\.\d{2})-([a-z0-9]+(?:-[a-z0-9]+)*)\.zip$')
CANONICAL_MODE = 0o100644

def fail(msg: str) -> None:
    raise SystemExit(msg)

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def canonical_dt(stamp: str) -> tuple[int, int, int, int, int, int]:
    y, mo, d, hh, mm = [int(x) for x in stamp.split('.')]
    return (y, mo, d, hh, mm, 0)

def verify_bundle(bundle: Path) -> None:
    bundle = bundle.resolve()
    m = RE_BUNDLE.match(bundle.name)
    if not m:
        fail('bundle filename must match Steward-rev####-YYYY.MM.DD.HH.MM-<slug>.zip')
    rev, stamp, slug = m.groups()
    dt = canonical_dt(stamp)
    with ZipFile(bundle, 'r') as zf:
        infos = zf.infolist()
        names = [zi.filename for zi in infos]
        if len(names) != len(set(names)):
            fail('duplicate zip member names found')
        for zi in infos:
            if zi.date_time != dt:
                fail(f'{zi.filename}: non-canonical zip timestamp')
            mode = (zi.external_attr >> 16) & 0o177777
            if mode != CANONICAL_MODE:
                fail(f'{zi.filename}: non-canonical mode {oct(mode)}')
            if zi.create_system != 3:
                fail(f'{zi.filename}: non-canonical create_system')
        if MANIFEST_NAME not in names:
            fail('missing RELEASE-MANIFEST.json')
        manifest = json.loads(zf.read(MANIFEST_NAME).decode('utf-8'))
        if manifest['archive_name'] != bundle.name:
            fail('manifest archive_name mismatch')
        if manifest['revision'] != rev:
            fail('manifest revision mismatch')
        if manifest['packaging_timestamp'] != stamp:
            fail('manifest timestamp mismatch')
        if manifest['slug'] != slug:
            fail('manifest slug mismatch')
        rows = manifest['files']
        expected_names = [row['path'] for row in rows] + [MANIFEST_NAME]
        if names != expected_names:
            fail('zip member list/order does not match manifest')
        for row in rows:
            data = zf.read(row['path'])
            if len(data) != row['size']:
                fail(f"{row['path']}: size mismatch")
            if sha256_bytes(data) != row['sha256']:
                fail(f"{row['path']}: sha256 mismatch")

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--bundle', required=True)
    args = ap.parse_args()
    verify_bundle(Path(args.bundle))
    print(f'[verify-release] OK: {args.bundle}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
