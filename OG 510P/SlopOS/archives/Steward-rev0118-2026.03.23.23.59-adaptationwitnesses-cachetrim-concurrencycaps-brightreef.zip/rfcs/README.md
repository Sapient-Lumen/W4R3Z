# RFCs

Use RFCs for architecture proposals that are not ready to become ADRs.

At revision 1 this directory is intentionally empty except for this process note.
