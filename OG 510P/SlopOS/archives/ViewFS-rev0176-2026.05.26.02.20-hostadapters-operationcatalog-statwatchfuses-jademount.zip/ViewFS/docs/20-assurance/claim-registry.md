# Claim registry

| ID | Claim |
|---|---|
| C-VIEWFS-1 | ViewFS core semantics do not require an ambient machine-global filesystem namespace. |
| C-VIEWFS-2 | Path compatibility can be constrained to authority already present in explicit handles/views. |
| C-VIEWFS-3 | Portal-mediated imports/exports can provide explicit, inspectable authority transitions. |
| C-VIEWFS-4 | A simple immutable-first object store is sufficient for the first useful ViewFS slice. |
| C-VIEWFS-5 | ViewFS can align with existing SlopOS seams for views, document handles, plumb-style messages, and transcripted execution rather than inventing parallel abstractions. |
| C-VIEWFS-6 | A first-class shell/terminal can materially improve safety by exposing view identity, authority previews, receipts, and semantic command/output boundaries. |
| C-VIEWFS-7 | ViewFS can remain useful while treating immutable identity, naming, mutable current state, and durable reopen authority as distinct surfaces rather than one overloaded filesystem primitive. |
| C-VIEWFS-8 | ViewFS can use host-side bridges and defense-in-depth backstops during bring-up while still keeping handles, views, portals, and receipts as the user-facing explanation of authority. |
| C-VIEWFS-9 | ViewFS can keep workspace/tree binds, durable reopen, transfer handoff, and URI launch as related but distinct authority classes instead of collapsing them into one generic “open” action. |
| C-VIEWFS-10 | ViewFS can give users convenient recent-item, reopen, and reveal workflows while still keeping immutable identity, workspace binding, and route behavior as distinct seams. |
| C-VIEWFS-11 | ViewFS can make shell history, recents, and workflow transcripts useful while still distinguishing live handles, durable refs, and receipt artifacts. |
| C-VIEWFS-12 | ViewFS can make journals, notebooks, workflows, and pane/session restore highly useful while still keeping saved session state distinct from live authority. |
| C-VIEWFS-13 | ViewFS can offer search, recents, smart selectors, and palette-driven navigation while still keeping those registries advisory rather than identity- or authority-bearing. |
| C-VIEWFS-14 | ViewFS can separate workspace/tree access from permission to execute workspace-defined automation, allowing a useful restricted project-opening mode without ambient startup behavior. |
| C-VIEWFS-15 | ViewFS can offer live watch panes, auto-refreshing queries, and notification UX while still keeping watch registrations and event feeds advisory, scoped, and rebuild-friendly rather than authority-bearing truth. |
| C-VIEWFS-16 | ViewFS can make clickable links, aliases, breadcrumbs, and shortcuts highly productive while still distinguishing live handles, local names, durable reopen refs, route objects, and receipt links. |

| C-VIEWFS-17 | ViewFS can make origin/quarantine UX highly legible while still distinguishing origin evidence, risk state, safe-open lanes, explicit trust receipts, and live authority. |
| C-VIEWFS-18 | ViewFS can offer cheap checkpoints, writable forks/worktrees, replication/export receipts, and publish/activation workflows while still keeping those classes visibly distinct in both the object model and the shell. |
| C-VIEWFS-19 | ViewFS can coordinate concurrent edits and automation honestly while keeping expected-old guards, short leases, ownership hints, conflict artifacts, and explicit takeovers as separate classes rather than one universal lock primitive. |
| C-VIEWFS-20 | ViewFS can offer shell-owned smart folders, snapshot result sets, and optional live query feeds while keeping query recipes, current results, feed health, and live authority as distinct user-visible classes. |
| C-VIEWFS-21 | ViewFS can offer prefetch, cache warmth, hydration, pinning, mirror workflows, and offline-readiness UX while still keeping those classes distinct from durable authority, publication, or activation semantics. |
| C-VIEWFS-22 | ViewFS can give users reusable authority kits and per-process namespace recipes while still keeping grouped authority, live binds, launch assembly, and receipt history as distinct user-visible classes. |
| C-VIEWFS-23 | ViewFS can make mediated chooser/import workflows delightful while still keeping request state, chooser-owned candidate sets, selected outcomes, minted grants/refs, live binds, and receipt history as distinct user-visible classes. |
| C-VIEWFS-24 | ViewFS can make route/action planning highly visible and interactive while still keeping intent, exact approval basis, committed execution, and result receipts as distinct user-visible classes. |
| C-VIEWFS-25 | ViewFS can make suggested automation, promoted user-owned workflows, notebook/runbook cells, and replay highly productive while still keeping suggestion provenance, prepared plans, committed runs, and history receipts as distinct user-visible classes. |
| C-VIEWFS-26 | ViewFS can support temporary authority sharing and renewal flows while still distinguishing live borrowed handles, durable delegated refs, issuer-side recall powers, and loan-end receipts. |
| C-VIEWFS-27 | ViewFS can make replay, reopen, and renewal highly productive while still keeping reuse candidates, exact basis records, current drift checks, fresh reconsent checkpoints, renewed artifacts, and history receipts as distinct user-visible classes. |
| C-VIEWFS-28 | ViewFS can make replay/import/run explanations highly legible while still keeping admissible witness material, caveat sets, freshness evidence, why-records, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-29 | ViewFS can make policy-aware shelling highly productive while still keeping validation/schema material, authoritative policy/caveat material, shell advice rails, decision diagnostics, and durable logs/receipts as distinct user-visible classes. |
| C-VIEWFS-30 | ViewFS can make policy-family selection, fallback, and repair UX highly productive while still keeping policy-family/catalog choice, exact authoritative cuts/consistency posture, fallback candidates, repair proposals, and durable selection receipts as distinct user-visible classes. |
| C-VIEWFS-31 | ViewFS can surface workspace/profile/org/history/helper proposals richly while still keeping proposal provenance, requested scope, explicit adoption, and durable adoption history as distinct user-visible classes. |
| C-VIEWFS-32 | ViewFS can surface deny ceilings and narrowing choices richly while still keeping authoritative ceilings, scope eligibility, narrowing transforms, escalation attempts, and durable adoption history as distinct user-visible classes. |
| C-VIEWFS-33 | ViewFS can make source-aware shell ergonomics highly productive while still keeping owner/org policy sources, trust-state gates, user/profile preferences, workspace/imported helper material, and effective active state as distinct user-visible classes. |
| C-VIEWFS-34 | ViewFS can make trusted carriers and rich discovery surfaces highly productive while still keeping policy author classes, carrier/container classes, trust gates, advisory-only sources, and effective active state as distinct user-visible classes. |
| C-VIEWFS-35 | ViewFS can make lower-trust helper material highly productive while still keeping protected-authorable state, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-36 | ViewFS can make helper lifecycle UX highly legible while still keeping publisher trust, installed helper packages, configured helper definitions, enabled state, start approvals, live sessions, request-scoped selections, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-37 | ViewFS can make helper feature catalogs highly productive while still keeping resources, prompts, tools, interactive app surfaces, completion suggestions, request-bound attachments, live invocation/results, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-38 | ViewFS can make deferred helper/automation work highly productive while still keeping immediate requests, accepted task wrappers, live progress/status, input-required checkpoints, deferred final results, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-39 | ViewFS can make deferred stop/retry control highly productive while still keeping close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-40 | ViewFS can make live-session shell UX highly productive while still keeping read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable transcripts as distinct user-visible classes. |

| C-VIEWFS-41 | ViewFS can make explicit sharing/handoff highly productive while still keeping transfer offers, accepted representations, live copied handles, later revival designators, receiver-local adopted binds, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-42 | ViewFS can make attenuation/delegation UX highly productive while still keeping declared caveat sets, enforced membrane/lease proxies, live attenuated handles, later revival designators, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-43 | ViewFS can make permission-state and repair UX highly productive while still keeping permission outlook, revival designators, current live handles, explicit death-state verdicts, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-44 | ViewFS can make provenance claims, endorsement inputs, local admit/deny verdicts, current live handles, and durable receipts highly visible while keeping those classes distinct in shell UX. |
| C-VIEWFS-45 | ViewFS can make request ledgers, session cards, portal-state lenses, and repair rails highly productive while still keeping request rows, session/transfer objects, portal-owned live state, local adopted binds/live handles, and durable receipts as distinct user-visible classes. |
| C-VIEWFS-46 | ViewFS can make smart queries and smart folders highly productive while still keeping saved query recipes, current/frozen hit sets, live query feeds, materialized local collections, current binds, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-47 | ViewFS can make completion and replay UX highly productive while still keeping advisory candidates, accepted insertions, compiled command packets, prepared actions, trusted rerun affordances, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-48 | ViewFS can make place cards, verb ledgers, and affordance lenses highly productive while still keeping object identity, current placement, current handle-rights posture, advertised operations, and durable receipts as distinct user-visible classes. |

| C-VIEWFS-49 | ViewFS design notes preserve a distinct seam between current handle inventory, custody chain, outflow gate, redacted flow snapshot/diff, leak verdict, live export/proxy/borrow, and durable receipt/history. | `rfcs/0126-viewfs-keep-handle-inventories-custody-chains-outflow-gates-flow-snapshots-leak-verdicts-live-exports-and-receipts-separate.md` | draft |

| C-VIEWFS-58 | ViewFS can make durable roots, restore, rollback, and activation useful without letting stored root commits, epoch fences, restore intents, resurrection gates, activation targets, live handle sets, and receipts collapse into one magical saved filesystem. |

| C-VIEWFS-52 | ViewFS can make object-store retention and garbage collection legible without collapsing durable roots, live handles, pins/holds/leases, sweep analysis, finalizers, collected ash, current live facets, and receipts into one vague existence state. |

| C-VIEWFS-53 | ViewFS can make risky imported content usable without letting origin evidence, quarantine marks, safe-open capsules, viewer residue, derived artifacts, trust clearances, live opens, and receipts collapse into one hidden trusted-file state. | `rfcs/0129-viewfs-keep-origin-evidence-quarantine-marks-safe-open-capsules-viewer-residue-derived-artifacts-trust-clearances-live-opens-and-receipts-separate.md` | draft |

| C-VIEWFS-59 | ViewFS design notes preserve a distinct seam between container envelopes, member claims, extraction plans, sterile materialization roots, extracted member capsules, namespace commits, current live opens/mounts, and durable receipts/history. | `rfcs/0130-viewfs-keep-container-envelopes-member-claims-extraction-plans-materialization-roots-namespace-commits-live-opens-and-receipts-separate.md` | draft |

| C-VIEWFS-60 | ViewFS design notes preserve a distinct seam between artifact envelopes, inventory/SBOM claims, locator aliases, vulnerability/advisory/VEX statements, verification evidence packs, local admission verdicts, activation targets, current live facets, and durable receipts/history. | `rfcs/0131-viewfs-keep-artifact-envelopes-inventory-claims-locator-aliases-vulnerability-statements-admission-verdicts-activation-targets-live-facets-and-receipts-separate.md` | draft |

| C-VIEWFS-61 | ViewFS design notes preserve a distinct seam between secret descriptors, acquisition prompts, delivery slots/projections, environment shadows, redaction lenses, renewal/rotation leases, live-use handles, residue markers, and durable receipts/history. | `rfcs/0132-viewfs-keep-secret-descriptors-acquisition-prompts-delivery-slots-env-shadows-redaction-lenses-renewal-leases-live-use-handles-and-receipts-separate.md` | draft |

| C-VIEWFS-62 | ViewFS design notes preserve a distinct seam between delegation intents, attenuation/caveat envelopes, membrane leases/proxies, delegated handles/imported stubs, revocation requests, revocation wavefronts/checkpoints, stale-handle brakes/death verdicts, renewal/redelegation controls, current live authority, and durable receipts/history. | `rfcs/0133-viewfs-keep-delegation-intents-attenuation-envelopes-membrane-leases-revocation-wavefronts-stale-brakes-live-authority-and-receipts-separate.md` | draft |

| C-VIEWFS-63 | ViewFS can make diagnostics and support-bundle UX powerful without collapsing inspection intents, target locators, namespace snapshots, fd/slot peeks, memory/core captures, trace probes, debug-control lanes, redaction/export cuts, current live inspection authority, and receipts into one hidden **debug access** bit. |

| C-VIEWFS-64 | Network access in ViewFS can be made capability-honest by keeping network intents, destination designators, resolution witnesses, lease/admission cuts, live network authority, stream state, local exposures, egress/import cuts, and receipts separate. | RFC 0135; network authority architecture note; shell net-lease UX note; SlopOS D-NETLEASE evaluation. | draft |
| C-VIEWFS-65 | ViewFS can make service discovery and service binding useful without collapsing service intent, designator, catalog authority, discovery snapshots, readiness/identity evidence, binding cuts, activation targets, live service handles, advertisements, and receipts into one hidden endpoint plane. |
| C-VIEWFS-66 | ViewFS can make secure-transport identity legible while still keeping reference identifiers, presented evidence, verifier profiles, trust-anchor inputs, channel bindings, resumption state, current live secure channels, and durable receipts as distinct user-visible classes. |


| C-VIEWFS-67 | ViewFS can use content-addressed storage and deduplication safely only if content addresses, equality/comparison witnesses, dedup eligibility hints, convergence/privacy domains, cache/membership observations, proof-of-possession checks, materialization decisions, current live facets, and receipts remain distinct. | RFC 0138; content-address/dedup architecture note; digest-shade shell note; SlopOS fresh-identity / verified-blob / memory-dedup evaluation. | draft |


| C-VIEWFS-68 | ViewFS can make semantic search, OCR, summaries, embeddings, smart folders, and answer cards useful without collapsing semantic extraction intents, source input capsules, extractor/model profiles, derived artifacts, index/store membership, query scopes, result projections, answer cards, live authority, and receipts into one hidden memory or search-authority plane. | RFC 0139; semantic derivation architecture note; semantic shell UX note; SlopOS quarantined content-index/derived-attribute/result-preview evaluation. | draft |

| C-VIEWFS-69 | ViewFS can make AI-assisted search, planning, tool calls, and workspace instructions useful without collapsing instruction source records, trust/priority labels, context frames, proposal text, typed action plans, tool invocation candidates, approval cuts, live authority, result observations, and receipts into one hidden prompt-authority plane. | RFC 0140; instruction hygiene architecture note; shell instruction rails/toolcall fuse note; SlopOS D-LLM/MCP/tool-UI evaluation. | draft |

| C-VIEWFS-70 | ViewFS can support high-risk human consent without treating clicks, focus, prompt replies, helper widgets, volition witnesses, or old receipts as current authority, provided approval cuts bind exact canonical summaries to current live authority slots. | Consent-card and volition-token prototypes should demonstrate summary mismatch, stale receipt, remote/captured surface, and multi-use gesture denial. | draft |

| C-VIEWFS-71 | ViewFS can now make its anti-collapse claims executable by grounding core authority, path, portal, semantic, consent, and receipt distinctions in a compact schema, proof-obligation index, and checked fixture corpus. | `docs/30-architecture/core-schema-v0.md`; `docs/40-verification/proof-obligations-v0.md`; `fixtures/viewfs-core-v0/`; `tools/check_viewfs_core_fixtures.py` | draft |

## Revision 156 executable-lifecycle claims

| ID | Claim |
|---|---|
| C-VIEWFS-72 | ViewFS can make handle attenuation useful while proving that a child/narrowed handle never widens rights beyond its source. |
| C-VIEWFS-73 | ViewFS can support writable work sessions without letting journals, stale observed bases, repair plans, or commit receipts become committed object identity. |
| C-VIEWFS-74 | ViewFS can make revocation and stale-brake UX visible while preserving historical receipts as non-authority evidence. |
| C-VIEWFS-75 | ViewFS can explain object retention and sweep rehearsals without letting receipts, derived-only indexes, semantic answer cards, or spent portal grants silently become retention roots. |
| C-VIEWFS-76 | ViewFS can host agentic tool workflows while keeping prompt text/model proposals separate from typed action plans, approval cuts, live authority slots, and receipts. |
| C-VIEWFS-77 | ViewFS can prevent proof-obligation drift by requiring fixtures to name the obligations they cover and by linting coverage during `make lint`. |

| C-VIEWFS-78 | ViewFS can harden compatibility pathwalking with typed resolver denial receipts for escape, symlink, magic/synthetic, mount/provider, missing-bind, and missing-right cases without treating host paths as authority. | `rfcs/0145-viewfs-resolver-delegation-shell-and-derived-cleanup-fixture-hardening.md` | draft |
| C-VIEWFS-79 | ViewFS can support delegated custody while preserving the distinction between source handle, attenuation envelope, delegated child handle, membrane lease, revocation wavefront, and receipt history. | `rfcs/0145-viewfs-resolver-delegation-shell-and-derived-cleanup-fixture-hardening.md` | draft |
| C-VIEWFS-80 | ViewFS shell cards can make authority and retention posture legible without letting cards, receipts, or badges become authority or retention roots. | `rfcs/0145-viewfs-resolver-delegation-shell-and-derived-cleanup-fixture-hardening.md` | draft |
| C-VIEWFS-81 | ViewFS can make source forgetting/minimization claims only after local derived artifacts and copy inventories are accounted for, while remaining honest about external copies outside local control. | `rfcs/0145-viewfs-resolver-delegation-shell-and-derived-cleanup-fixture-hardening.md` | draft |

## Revision 158 quarantine / export / conformance claims

| ID | Claim |
|---|---|
| C-VIEWFS-82 | ViewFS can make foreign-origin import usable without collapsing origin evidence, quarantine marks, safe-viewer handles, trust transitions, live opens, and receipts into a single trusted-file bit. |
| C-VIEWFS-83 | ViewFS can make shell authority changes legible by requiring authority diffs to account for every right gained or lost, including visibly badged widening. |
| C-VIEWFS-84 | ViewFS can support export workflows without letting old receipts, generic share labels, or quarantined sources substitute for typed export plans, approval cuts, sink bindings, live export handles, and quarantine clearance. |
| C-VIEWFS-85 | ViewFS can keep its executable assurance surface reviewable by generating a conformance report from fixtures and proof obligations rather than hand-maintaining coverage prose. |

## Revision 159 policy / witness / replay / override claims

| ID | Claim |
|---|---|
| C-VIEWFS-86 | ViewFS can make policy decisions explainable and enforceable without letting policy verdicts, advisory results, stale bundles, or decision logs become live object authority. |
| C-VIEWFS-87 | ViewFS can make witness bundles useful for audit and replay while keeping witnesses distinct from approvals, handles, receipts, and effect replay tokens. |
| C-VIEWFS-88 | ViewFS can make conformance scenarios replayable only when they include witnessed positive and negative steps rather than happy-path-only demonstrations. |
| C-VIEWFS-89 | ViewFS can support breakglass or override operations without hidden administrator bits by requiring verified steward warrants, exact scope, expiry, audit sinks, and live authority. |
| C-VIEWFS-90 | ViewFS can expose `why allowed?` and `why denied?` policy trace surfaces without turning explanations, cards, logs, or CI summaries into grants. |


## Revision 160 freshness / distributed-state claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-91 | ViewFS can renew leases safely only when lease epoch, expiry, renewal cut, revocation posture, and live authority are current. | RFC 0148; fixtures 055-058 | draft |
| C-VIEWFS-92 | ViewFS can support offline branches without letting local commits or old branch receipts publish over a moved remote head. | RFC 0148; fixtures 059-061 | draft |
| C-VIEWFS-93 | ViewFS can reconcile merges while keeping conflict rows, resolution cuts, witnesses, write authority, and receipts distinct. | RFC 0148; fixtures 062-065 | draft |
| C-VIEWFS-94 | ViewFS can use remote attestations as evidence without letting signatures, CIDs, status rows, or attestations become object authority. | RFC 0148; fixtures 066-069 | draft |
| C-VIEWFS-95 | ViewFS can expose freshness fences and uncertainty lamps without pretending raw timestamps are currentness. | RFC 0148; fixtures 070-073 | draft |
| C-VIEWFS-96 | ViewFS can checkpoint journaled work while keeping journal commit, flush proof, materialized object, finalizer authority, and receipts separate. | RFC 0148; fixtures 074-076 | draft |

## Revision 161 disclosure / observation claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-97 | ViewFS can make redacted views useful without letting redaction labels or field filters substitute for live read/export/subject-access authority. | `rfcs/0149-viewfs-disclosure-observation-redaction-subscription-and-subject-access-gates.md`; fixtures 077-079 | draft |
| C-VIEWFS-98 | ViewFS can render audit projections without collapsing redacted audit cards, raw audit access, authority badges, event receipts, and underlying object authority. | RFC 0149; fixtures 080-083 | draft |
| C-VIEWFS-99 | ViewFS can support disclosure packages while preserving the distinction between prepared package, approved cut, exact source/sink scope, redaction posture, live export authority, and disclosure receipt. | RFC 0149; fixtures 084-088 | draft |
| C-VIEWFS-100 | ViewFS can deliver notifications and subscription events without making event envelopes into object-open authority or leaking full payload fields through observation surfaces. | RFC 0149; fixtures 089-093 | draft |
| C-VIEWFS-101 | ViewFS can model subject-access exports as explicit reviewed disclosure lanes rather than generic downloads, while keeping subject identity, scope, redaction, package readiness, live authority, and receipts separate. | RFC 0149; fixtures 094-098 | draft |
## Revision 163 GC / archive / deletion claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-102 | ViewFS can make GC sweep eligibility explainable without treating tombstones, receipts, or hidden copy inventories as proof of global deletion. | RFC 0151; fixtures 122-130 | draft |
| C-VIEWFS-103 | ViewFS can model snapshot pins and archive/legal holds as retention blockers without letting them become read authority or generic administrator overrides. | RFC 0151; fixtures 124-137 | draft |
| C-VIEWFS-104 | ViewFS can support backup and restore while keeping backup manifests, verified backup sets, approved restore plans, and live restore/write authority separate. | RFC 0151; fixtures 138-141 | draft |
| C-VIEWFS-105 | ViewFS can render deletion and sanitization evidence as an auditable ladder without claiming secure erasure when proof is missing, too weak, or contradicted by retained copies. | RFC 0151; fixtures 142-146 | draft |

## Revision 165 resource / side-effect claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-106 | ViewFS can make resource budgets useful without letting quota cards, budget summaries, or metering rows become spend authority. | RFC 0153; fixtures 173-177 | draft |
| C-VIEWFS-107 | ViewFS can model spend reservations as explicit bounded resource holds while keeping them separate from object authority and later metering settlement. | RFC 0153; fixtures 173, 175, 177, 182, 186, 196-198 | draft |
| C-VIEWFS-108 | ViewFS can expose rate-limit state without allowing exhausted windows, stale windows, or old receipts to mint new invocation capacity. | RFC 0153; fixtures 178-181 | draft |
| C-VIEWFS-109 | ViewFS can run background work only after revalidating queue lease, budget, rate, approval, and live authority at start time. | RFC 0153; fixtures 182-186 | draft |
| C-VIEWFS-110 | ViewFS can use cache residency and hydration safely without making cache entries into read authority or stale bytes into current state. | RFC 0153; fixtures 187-191 | draft |
| C-VIEWFS-111 | ViewFS can surface capacity pressure while treating exact/per-object/per-principal capacity as a side-channel disclosure risk. | RFC 0153; fixtures 192-195 | draft |
| C-VIEWFS-112 | ViewFS can settle metered work without letting metering receipts replay spend, charge beyond a reservation, or substitute for live charge authority. | RFC 0153; fixtures 196-198 | draft |


## Revision 168 transform / lineage / interpretation claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-113 | ViewFS can materialize transform outputs without letting transform recipes, transform receipts, or transformed objects inherit source authority. | RFC 0156; fixtures 252-255 | draft |
| C-VIEWFS-114 | ViewFS can decode or preview typed media only through pinned codec profiles and live source authority, while denying active-content and handler-profile laundering. | RFC 0156; fixtures 256-259 | draft |
| C-VIEWFS-115 | ViewFS can perform schema migration while keeping source schema, target schema, current validator, loss disclosure, result identity, and migration receipts separate. | RFC 0156; fixtures 260-263 | draft |
| C-VIEWFS-116 | ViewFS can apply patch sets only against the current observed base and deny stale bases, patch summaries, and authority-expanding diffs. | RFC 0156; fixtures 264-267 | draft |
| C-VIEWFS-117 | ViewFS can attach annotations without promoting comments, tags, selectors, or badges into policy labels or authority classes. | RFC 0156; fixtures 268-271 | draft |
| C-VIEWFS-118 | ViewFS can verify lineage as assessment evidence without letting provenance rows, old receipts, or ambiguous transform chains become access authority or equality proof. | RFC 0156; fixtures 272-275 | draft |
| C-VIEWFS-119 | ViewFS can render previews through redaction lenses while preventing preview caches from becoming source objects or raw disclosure authority. | RFC 0156; fixtures 276-278 | draft |
| C-VIEWFS-120 | ViewFS can admit bounded canonicalization/equivalence claims while keeping normalized bytes, confusable names, and canonicalized digests distinct from original-byte identity. | RFC 0156; fixtures 279-281 | draft |

## Revision 169 classification / licensing / jurisdiction / purpose / release claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-121 | ViewFS can account for classification marks without converting labels, classifier output, public/safe badges, or stale classifier rows into object or disclosure authority. | RFC 0157; fixtures 282-286 | draft |
| C-VIEWFS-122 | ViewFS can evaluate license terms while keeping license identifiers, SPDX strings, permissions, prohibitions, obligations, accepted terms, and live use authority separate. | RFC 0157; fixtures 287-291 | draft |
| C-VIEWFS-123 | ViewFS can gate jurisdictional egress without treating region, residency, export-control, or routing labels as clearance. | RFC 0157; fixtures 292-295 | draft |
| C-VIEWFS-124 | ViewFS can require compliance obligations such as attribution, notice, and destination statements without letting old receipts or checklists discharge current obligations. | RFC 0157; fixtures 296-299 | draft |
| C-VIEWFS-125 | ViewFS can model public-release review as a bounded cut requiring redaction, obligations, current review epoch, and live publish/export authority. | RFC 0157; fixtures 300-304 | draft |
| C-VIEWFS-126 | ViewFS can bind purpose-limited uses while preventing purpose statements, secondary-use claims, and missing retention budgets from becoming processing authority. | RFC 0157; fixtures 305-308 | draft |
| C-VIEWFS-127 | ViewFS can render compliance cards honestly without letting shell summaries claim live authority, clear-to-export posture, or blocked-field access without backing evidence. | RFC 0157; fixtures 309-312 | draft |

## Revision 170 query / planning / evaluation claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-128 | ViewFS can admit queries without letting query text, saved-query rows, result cards, stale indexes, or widened scopes become read/search authority. | RFC 0158; fixtures 313-316 | draft |
| C-VIEWFS-129 | ViewFS can record planner traces without letting model proposals, trace summaries, hidden effects, or rights-widening plans execute effects. | RFC 0158; fixtures 317-320 | draft |
| C-VIEWFS-130 | ViewFS can render search and retrieval results while requiring a fresh result set and a live backing handle before any result member opens. | RFC 0158; fixtures 321-324 | draft |
| C-VIEWFS-131 | ViewFS can expose aggregate views without leaking raw rows, exact membership, or singleton cohorts through dashboard surfaces. | RFC 0158; fixtures 325-328 | draft |
| C-VIEWFS-132 | ViewFS can use evaluation sets as bounded assessment inputs while denying contamination, missing license/purpose clearance, and production-authority laundering. | RFC 0158; fixtures 329-332 | draft |
| C-VIEWFS-133 | ViewFS can record benchmark runs without turning scores, leaderboards, stale runs, or unreproducible runs into deployment authority. | RFC 0158; fixtures 333-336 | draft |
| C-VIEWFS-134 | ViewFS can apply scoring rubrics without converting metric names, uncalibrated rubrics, or gamed metrics into policy authority. | RFC 0158; fixtures 337-340 | draft |
| C-VIEWFS-135 | ViewFS can render model-selection cards honestly without hiding tradeoffs or claiming production/deploy readiness without backing approval and authority. | RFC 0158; fixtures 341-344 | draft |


## Revision 171 incident / forensic / remediation claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-136 | ViewFS can admit alerts without letting detector output, severity, correlation ids, or active alert rows become access, containment, or proof-of-compromise authority. | RFC 0159; fixtures 349-352 | draft |
| C-VIEWFS-137 | ViewFS can open incident cases while keeping active alert context, case status, handler authority, remediation authority, and disclosure authority separate. | RFC 0159; fixtures 353-356 | draft |
| C-VIEWFS-138 | ViewFS can apply triage verdicts without converting classifications, confidence scores, or recommendations into execution cuts. | RFC 0159; fixtures 357-360 | draft |
| C-VIEWFS-139 | ViewFS can preserve forensic snapshots as sealed evidence without making them live opens, raw disclosure packages, or global truth. | RFC 0159; fixtures 361-364 | draft |
| C-VIEWFS-140 | ViewFS can verify evidence chains without letting tamper evidence, digest matches, or chain completeness prove causality or grant access. | RFC 0159; fixtures 365-368 | draft |
| C-VIEWFS-141 | ViewFS can approve containment only through explicit scope, blast-radius review, approval, and live containment authority. | RFC 0159; fixtures 369-372 | draft |
| C-VIEWFS-142 | ViewFS can execute remediation only when approval, preconditions, and live remediation authority pass, while denying receipt replay and closure claims. | RFC 0159; fixtures 373-376 | draft |
| C-VIEWFS-143 | ViewFS can execute recovery rollback only over current epochs and without claiming evidence/history erasure. | RFC 0159; fixtures 377-380 | draft |
| C-VIEWFS-144 | ViewFS can render postmortems honestly without claiming live authority, no recurrence, closure, or unredacted/public release without backing cuts. | RFC 0159; fixtures 381-384 | draft |

## Revision 172 governance / change-management claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-145 | ViewFS can admit change proposals without letting proposal text, ADR labels, or stale basis records become execution authority. | RFC 0160; fixtures 385-388 | draft |
| C-VIEWFS-146 | ViewFS can record governance decisions while binding them to exact proposal digests and denying decision-as-execution laundering. | RFC 0160; fixtures 389-392 | draft |
| C-VIEWFS-147 | ViewFS can verify approval quorums without letting quorum rows become authority or hiding missing steward/threshold facts. | RFC 0160; fixtures 393-396 | draft |
| C-VIEWFS-148 | ViewFS can start staged rollouts only when approval, guardrails, ring admission, blast-radius review, and live rollout authority pass. | RFC 0160; fixtures 397-400 | draft |
| C-VIEWFS-149 | ViewFS can evaluate feature flags as scoped configuration facts without turning flag membership into object/tool/use authority. | RFC 0160; fixtures 401-404 | draft |
| C-VIEWFS-150 | ViewFS can enforce deprecation notices only when windows, migration paths, and live deprecation authority pass, without treating notices as removal proof. | RFC 0160; fixtures 405-408 | draft |
| C-VIEWFS-151 | ViewFS can check compatibility contracts without turning version promises or support labels into compatibility proof. | RFC 0160; fixtures 409-412 | draft |
| C-VIEWFS-152 | ViewFS can execute migration runs only over current source schemas with prechecks, rollback plans, approval cuts, and live migration authority. | RFC 0160; fixtures 413-416 | draft |
| C-VIEWFS-153 | ViewFS can render governance cards honestly without claiming live authority, leaking private votes, or overstating unanimity. | RFC 0160; fixtures 417-420 | draft |
| C-VIEWFS-154 | ViewFS can keep the executable fixture corpus auditable through contiguous numbering, mode suffixes, unique names, and generated catalog reporting. | `tools/check_fixture_catalog.py`; `out/fixture_catalog_report.md` | draft |


## Revision 173 workflow / automation custody claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-155 | ViewFS can admit event envelopes without converting event ids, source metadata, or delivery records into authority. | RFC 0161; fixtures 421-424 | draft |
| C-VIEWFS-156 | ViewFS can evaluate trigger rules while keeping rule matches, event occurrence, and workflow authority separate. | RFC 0161; fixtures 425-428 | draft |
| C-VIEWFS-157 | ViewFS can fire schedule windows only when time bounds, approval cuts, and live schedule authority pass. | RFC 0161; fixtures 429-432 | draft |
| C-VIEWFS-158 | ViewFS can start workflow runs without letting queued rows or run state serialize live authority. | RFC 0161; fixtures 433-436 | draft |
| C-VIEWFS-159 | ViewFS can execute workflow steps only with active run state, approval, target handle rights, and live step authority. | RFC 0161; fixtures 437-440 | draft |
| C-VIEWFS-160 | ViewFS can use idempotency keys as replay guards without letting them replay or authorize effects. | RFC 0161; fixtures 441-444 | draft |
| C-VIEWFS-161 | ViewFS can apply retry policies while enforcing attempt, backoff, budget, and authority gates. | RFC 0161; fixtures 445-448 | draft |
| C-VIEWFS-162 | ViewFS can execute compensation plans without claiming history/evidence erasure or receipt replay. | RFC 0161; fixtures 449-452 | draft |
| C-VIEWFS-163 | ViewFS can complete human tasks only through trusted-path, assignee, approval-cut, and live-authority checks. | RFC 0161; fixtures 453-456 | draft |
| C-VIEWFS-164 | ViewFS can render workflow cards honestly without claiming live authority, leaking hidden steps, or overstating completion. | RFC 0161; fixtures 457-460 | draft |
| C-VIEWFS-165 | ViewFS can keep trace-report generation auditable through one registry of builders and outputs. | `tools/report_registry.py`; `tools/check_report_registry.py`; `tools/build_all_trace_reports.py` | draft |

## Revision 174 personalization / convenience claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-166 | ViewFS can bind user-profile personalization to current identity/session/policy context without making profile rows identity proof or object authority. | RFC 0162; fixtures 461-464 | draft |
| C-VIEWFS-167 | ViewFS can apply preferences only inside allowed scopes without treating preferences as policy, consent, or tool authority. | RFC 0162; fixtures 465-468 | draft |
| C-VIEWFS-168 | ViewFS can admit personalization models only with purpose and minimization evidence while denying model-as-authority laundering. | RFC 0162; fixtures 469-472 | draft |
| C-VIEWFS-169 | ViewFS can render recommendations as scoped candidates while preventing private-feature leakage and recommendation-as-open authority. | RFC 0162; fixtures 473-476 | draft |
| C-VIEWFS-170 | ViewFS can execute shortcuts only with approval, target rights, and live shortcut authority. | RFC 0162; fixtures 477-480 | draft |
| C-VIEWFS-171 | ViewFS can accept autofill suggestions only with approval, redaction posture, target rights, and live autofill authority. | RFC 0162; fixtures 481-484 | draft |
| C-VIEWFS-172 | ViewFS can apply experiment assignments as bounded cohorts without allowing policy or compatibility override. | RFC 0162; fixtures 485-488 | draft |
| C-VIEWFS-173 | ViewFS can record feedback under allowed purposes without converting feedback into training consent or retention authority. | RFC 0162; fixtures 489-492 | draft |
| C-VIEWFS-174 | ViewFS can render personalization cards honestly without claiming live authority, sensitive-feature access, or deterministic user truth. | RFC 0162; fixtures 493-496 | draft |
| C-VIEWFS-175 | ViewFS can keep top-level lint metadata auditable through a manifest and manifest checker. | `tools/lint_manifest.py`; `tools/check_lint_manifest.py` | draft |

## Revision 175 schema / ontology / reference / crosswalk claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-176 | ViewFS can bind namespace contexts without letting prefixes, contexts, or expanded names become object authority or policy. | RFC 0163; fixtures 497-500 | draft |
| C-VIEWFS-177 | ViewFS can resolve external references while keeping URI/IRI identity separate from possession, live handles, and disclosure authority. | RFC 0163; fixtures 501-504 | draft |
| C-VIEWFS-178 | ViewFS can admit vocabulary terms inside active namespaces without treating terms as policy, classification authority, consent, or rights. | RFC 0163; fixtures 505-508 | draft |
| C-VIEWFS-179 | ViewFS can apply crosswalk mappings with review and confidence gates while denying exact-equivalence and authority-inheritance laundering. | RFC 0163; fixtures 509-512 | draft |
| C-VIEWFS-180 | ViewFS can validate shape constraints without converting validation results into approval, safety, or object authority. | RFC 0163; fixtures 513-516 | draft |
| C-VIEWFS-181 | ViewFS can verify ontology alignments as reviewed semantic evidence without conferring policy or live authority through inference. | RFC 0163; fixtures 517-520 | draft |
| C-VIEWFS-182 | ViewFS can publish catalog entries only with release review, redaction, source disclosure rights, and live catalog authority. | RFC 0163; fixtures 521-524 | draft |
| C-VIEWFS-183 | ViewFS can render interop cards honestly without claiming live authority, overstating equivalence, or leaking hidden identifiers. | RFC 0163; fixtures 525-528 | draft |
| C-VIEWFS-184 | ViewFS can keep record-family growth auditable with a generated report and a lint gate that requires non-empty fixture evidence for every family. | `tools/check_record_family_catalog.py`; `out/record_family_report.md` | draft |


## Revision 176 host-adapter compatibility claims

| ID | Claim | Evidence | Status |
|---|---|---|---|
| C-VIEWFS-185 | ViewFS can admit host adapter mounts without converting projection roots, provider names, or mount labels into ambient/root authority. | RFC 0164; fixtures 529-532 | draft |
| C-VIEWFS-186 | ViewFS can render stat-like metadata without allowing metadata projections to become read authority, hidden disclosure, or complete object truth. | RFC 0164; fixtures 533-536 | draft |
| C-VIEWFS-187 | ViewFS can resolve inode-like aliases while preventing alias numbers, collisions, and stale epochs from becoming object identity. | RFC 0164; fixtures 537-540 | draft |
| C-VIEWFS-188 | ViewFS can expose bounded xattr parcels without treating xattrs as policy, classification, or disclosure authority. | RFC 0164; fixtures 541-544 | draft |
| C-VIEWFS-189 | ViewFS can deliver watcher events without turning file notifications into opens, authority refreshes, or standing subscriptions beyond their cursor. | RFC 0164; fixtures 545-548 | draft |
| C-VIEWFS-190 | ViewFS can use advisory lock tokens as coordination state without granting write authority or hiding range conflicts. | RFC 0164; fixtures 549-552 | draft |
| C-VIEWFS-191 | ViewFS can execute rename plans only with approval, source write, target-parent write, and boundary checks, without treating plans as completion proof. | RFC 0164; fixtures 553-556 | draft |
| C-VIEWFS-192 | ViewFS can promote staged tempfiles only after flush proof, approval, target write, and live authority, without treating temp leases as committed objects. | RFC 0164; fixtures 557-560 | draft |
| C-VIEWFS-193 | ViewFS can hydrate placeholders only through current, verified, live-authorized tickets without making hydration receipts into read authority. | RFC 0164; fixtures 561-564 | draft |
| C-VIEWFS-194 | ViewFS can hand off content to external apps through scoped redacted portal approvals without creating persistent grants. | RFC 0164; fixtures 565-568 | draft |
| C-VIEWFS-195 | ViewFS can keep operation/evaluator growth auditable with an operation catalog and lint gate. | `tools/check_operation_catalog.py`; `out/operation_catalog_report.md` | draft |
