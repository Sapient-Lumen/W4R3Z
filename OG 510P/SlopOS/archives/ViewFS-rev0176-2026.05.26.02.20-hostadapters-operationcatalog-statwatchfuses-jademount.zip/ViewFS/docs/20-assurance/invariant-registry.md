# Invariant registry

| ID | Invariant |
|---|---|
| I-VIEWFS-1 | A process view root is explicit; it is never silently replaced by ambient host `/`. |
| I-VIEWFS-2 | Handle rights can only stay the same or attenuate across duplication/binding unless a separate reviewed grant path exists. |
| I-VIEWFS-3 | Path-compat resolution cannot escape the bound view root; ambiguous implementations fail closed. |
| I-VIEWFS-4 | Portal imports/exports produce receipts or logs sufficient to reconstruct the authority step. |
| I-VIEWFS-5 | Immutable object IDs name content, not mutable current state. |
| I-VIEWFS-6 | Grant receipts and APIs must distinguish at least ephemeral versus durable authority; durability is never silently implied. |
| I-VIEWFS-7 | Any use of ambient host authority or host-path fallback in bring-up/compat flows must remain explicitly visible as debt rather than silently normalized into ordinary ViewFS behavior. |
| I-VIEWFS-8 | Receipts must preserve the distinction between at least open/import, transfer, save/export, and durable reopen classes even if the final schema evolves. |
| I-VIEWFS-9 | Checkpoints, writable forks/worktrees, backup/replication receipts, publish candidates, and activation targets must remain distinguishable in APIs and receipts even if a future implementation shares storage underneath them. |
| I-VIEWFS-10 | Preconditions, short leases/reservations, ownership hints, conflict receipts, and explicit takeover acts must remain distinguishable in APIs and receipts even if a future implementation shares storage or metadata underneath them. |
| I-VIEWFS-11 | Query manifests, result snapshots, live query feeds, and smart-folder UI surfaces must remain distinguishable in APIs and receipts even if a future implementation shares storage, indexes, or subscriptions underneath them. |
| I-VIEWFS-12 | Bundles/dictionaries, view fragments/templates, live view binds, child launch kits, and receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares storage or UI cards underneath them. |
| I-VIEWFS-13 | A child process cannot widen its own namespace except through an explicit higher-authority bind/grant path that is receipt-visible. |
| I-VIEWFS-14 | Request objects, candidate/designation surfaces, selected outcomes, minted grants/refs, live binds, and receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares UI cards or storage underneath them. |
| I-VIEWFS-15 | Intent records, prepared plans, approval checkpoints, committed executions, and result/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares UI cards or storage underneath them. |
| I-VIEWFS-16 | Suggested automation artifacts, promotion receipts, user-owned workflows, prepared run plans, committed runs, and history/receipt artifacts must remain distinguishable in APIs and receipts even if a future implementation shares notebook cells, block cards, or storage underneath them. |
| I-VIEWFS-17 | Lend requests, live borrowed authority, durable delegated refs, issuer-side recall/expiry controls, and loan-end/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares UI cards, timers, or storage underneath them. |
| I-VIEWFS-18 | Reuse candidates, exact basis records, current drift checks, reconsent checkpoints, renewed artifacts, and history/receipt artifacts must remain distinguishable in APIs and receipts even if a future implementation shares UI cards, storage, or replay helpers underneath them. |
| I-VIEWFS-19 | Witness packs, caveat sets, freshness/consistency witnesses, why-records, and receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares cards, storage, or replay helpers underneath them. |
| I-VIEWFS-20 | Validation/schema material, authoritative policy/caveat material, shell advice rails, decision diagnostics, and durable log/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares overlays, storage, or replay helpers underneath them. |
| I-VIEWFS-21 | Policy-family/catalog choice, exact authoritative cuts/consistency posture, fallback candidates, repair proposals, and selection/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares pickers, drawers, or storage underneath them. |
| I-VIEWFS-22 | Proposal origins/sources, proposal lanes/scopes, escalation requests, authoritative adoptions, and adoption/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares badges, drawers, or storage underneath them. |
| I-VIEWFS-23 | Deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and adoption/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares badges, drawers, or policy storage underneath them. |
| I-VIEWFS-24 | Owner/org policy sources, trust-state gates, user/profile preference layers, workspace/imported proposal sources, effective active state, and durable receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares badges, drawers, or policy storage underneath them. |
| I-VIEWFS-25 | Policy author classes, carrier/container classes, trust gates, advisory-only sources, effective active state, and durable receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares badges, drawers, or policy storage underneath them. |
| I-VIEWFS-26 | Protected-authorable state classes, carrier/discovery presence, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares badges, drawers, or policy storage underneath them. |

| I-VIEWFS-27 | Publisher trust, installed helper packages, configured helper/server definitions, enabled state, start approvals, live brokered sessions, request-scoped tool selections, and durable receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares badges, drawers, or catalog storage underneath them. |
| I-VIEWFS-28 | Resource descriptors, prompt templates, tool descriptors, app surfaces, completion suggestions, request-bound attachments/selections, live invocation/result artifacts, and durable receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares catalogs, shelves, or helper-session storage underneath them. |
| I-VIEWFS-29 | Immediate requests, accepted task wrappers, live progress/status streams, input-required checkpoints, deferred final-result artifacts, and durable receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares badges, queues, lockers, or helper-session storage underneath them. |
| I-VIEWFS-30 | Close/cancel acts, force termination acts, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares drawers, lockers, queues, or helper-session storage underneath them. |
| I-VIEWFS-31 | Read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable transcript/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares panes, sockets, queues, or helper-session storage underneath them. |
| I-VIEWFS-32 | Query manifests, result snapshots, live query feeds, materialized local collections, current binds, and durable receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares indexes, set storage, or shell cards underneath them. |

| I-VIEWFS-33 | Exact object identity, current placement in a view, current handle-rights posture, advertised operations, and durable receipt/history artifacts must remain distinguishable in APIs and receipts even if a future implementation shares cards, menus, or storage underneath them. |

| I-VIEWFS-34 | A receipt, capability-flow snapshot, capability-flow diff, custody badge, wallet summary, or leak verdict MUST NOT by itself grant current ViewFS authority. | `rfcs/0126-viewfs-keep-handle-inventories-custody-chains-outflow-gates-flow-snapshots-leak-verdicts-live-exports-and-receipts-separate.md` | draft |

| I-VIEWFS-58 | A durable root commit, wallet row, cap graph, old receipt, or dormant descriptor must not by itself install current live authority; a fresh restore/activation path must produce explicit live binds/handles. | Root-ledger and restore-ticket demos should prove stored state is not authority. |

| I-VIEWFS-59 | Receipts, indexes, cache rows, previews, listing snapshots, and stale namespace rows must not keep stored material alive unless an explicit reachability root, pin/hold/lease, live-handle root, or finalizer says so. | GC-halo and sweep-rehearsal demos should prove history and cache are not roots by default. |

| I-VIEWFS-60 | Safe-open success, viewer residue, content-derived indexes, derived artifacts, same-digest cache hits, and old receipts must not silently clear source quarantine or grant current live-open/execution authority. | Quarantine-capsule, residue-lamp, and trust-receipt demos should prove selected/imported/previewed/indexed/derived/cleared/live-open are separate. |

| I-VIEWFS-61 | Archive/container member names, link targets, device/metadata claims, whiteouts, extraction plans, sterile materialization roots, and old unpack receipts MUST NOT by themselves create namespace authority, trust clearance, retention roots, or current live opens. | `rfcs/0130-viewfs-keep-container-envelopes-member-claims-extraction-plans-materialization-roots-namespace-commits-live-opens-and-receipts-separate.md` | draft |

| I-VIEWFS-62 | SBOM rows, component locator aliases, vulnerability/advisory/VEX statements, signatures, transparency entries, update metadata, admission receipts, and old verification outputs MUST NOT by themselves create trust clearance, namespace mutation, install/activation authority, vulnerability suppression, retention roots, or current live handles. | `rfcs/0131-viewfs-keep-artifact-envelopes-inventory-claims-locator-aliases-vulnerability-statements-admission-verdicts-activation-targets-live-facets-and-receipts-separate.md` | draft |

| I-VIEWFS-63 | Secret descriptors, prompt receipts, environment variables, config strings, redaction masks, renewal hints, use receipts, and cleanup receipts MUST NOT by themselves create current secret-bearing authority, renew credentials, prove containment, clear residue, or authorize wider replay. | `rfcs/0132-viewfs-keep-secret-descriptors-acquisition-prompts-delivery-slots-env-shadows-redaction-lenses-renewal-leases-live-use-handles-and-receipts-separate.md` | draft |

| I-VIEWFS-64 | Delegation intents, caveat/attenuation labels, lease descriptors, wallet rows, revocation requests, provider responses, wavefront snapshots, stale-handle receipts, and old share cards MUST NOT by themselves create current authority, prove global revocation, undo prior effects, authorize redelegation, or reacquire bearer material. | `rfcs/0133-viewfs-keep-delegation-intents-attenuation-envelopes-membrane-leases-revocation-wavefronts-stale-brakes-live-authority-and-receipts-separate.md` | draft |

| I-VIEWFS-65 | Inspection intents, target locators, namespace snapshots, fd/slot inventory rows, trace samples, redaction masks, dump metadata, support-bundle manifests, and old inspection receipts MUST NOT by themselves create current inspection/debug authority, duplicate handles, enter namespaces, export raw captures, or prove containment. | `rfcs/0134-viewfs-keep-inspection-lenses-namespace-snapshots-fd-peeks-memory-captures-trace-probes-debug-controls-redaction-policy-live-authority-and-receipts-separate.md` | draft |

| I-VIEWFS-66 | A network receipt, resolution witness, destination designator, stream telemetry row, or old lease descriptor must not by itself create current resolver, dialer, listener, stream, local-exposure, or egress authority. | RFC 0135 | Needed so history and diagnostics cannot reconnect or exfiltrate. |
| I-VIEWFS-67 | A service designator, catalog row, discovery snapshot, readiness/health claim, identity match, binding receipt, activation plan, advertisement row, or call receipt must not impersonate current live service authority. |
| I-VIEWFS-68 | A verified secure channel, certificate chain, transparency/status artifact, known-host row, channel-binding proof, or resumption ticket MUST NOT by itself grant service invocation, object import, secret release, namespace mutation, or future reconnect authority. |


| I-VIEWFS-69 | A content address, CID, Merkle root, closure hash, dedup hit, cache row, convergence-domain label, proof receipt, or shared-backing observation MUST NOT by itself grant read/import/export/publish/execute authority, prove ownership, clear quarantine/trust, create a retention root, or answer cross-principal membership. | `rfcs/0138-viewfs-keep-content-addresses-equality-witnesses-dedup-hints-convergence-domains-cache-hits-materializations-live-facets-and-receipts-separate.md` | draft |


| I-VIEWFS-70 | A semantic index row, embedding vector, summary, OCR text, thumbnail, result projection, answer card, retrieved context, or old semantic receipt MUST NOT by itself grant read/open/export/mutate/execute authority, clear origin/quarantine/trust, seed future agent memory, or prove deletion/unlearning. | `rfcs/0139-viewfs-keep-semantic-extraction-intents-derived-artifacts-embedding-stores-query-scopes-result-projections-answer-cards-live-authority-and-receipts-separate.md` | draft |

| I-VIEWFS-71 | Instruction-like text, retrieved context, workspace instruction files, tool descriptions/annotations, tool results, model output, answer cards, and old prompt receipts MUST NOT by themselves grant policy, approval, current fact, live authority, future memory, or rerun rights. | `rfcs/0140-viewfs-keep-instruction-sources-context-frames-proposal-text-action-plans-tool-invocations-approvals-live-authority-and-receipts-separate.md` | draft |

| I-VIEWFS-72 | A click, focus state, notification action, prompt reply, presentation surface, gesture witness, volition token, authenticator presence/verification event, consent summary, approval receipt, or old authority-diff card MUST NOT by itself grant current approval, live authority, future rerun rights, secret release, namespace mutation, export, publication, or delegation. | `rfcs/0141-viewfs-keep-consent-summaries-presentation-surfaces-gesture-evidence-volition-tokens-approval-cuts-live-authority-and-receipts-separate.md` | draft |

| I-VIEWFS-73 | In the executable ViewFS core fixtures, only live handles or live facets with matching rights may authorize object effects; object refs, digests, path text, receipts, semantic cards, prompt text, gesture evidence, and old approval records must remain non-authoritative unless explicitly converted by a current portal/approval operation. | `fixtures/viewfs-core-v0/`; `tools/check_viewfs_core_fixtures.py` | draft |

## Revision 156 executable-lifecycle invariants

| ID | Invariant |
|---|---|
| I-VIEWFS-74 | A handle attenuation result must target the same object as its source and its rights must be a subset of the source handle rights. |
| I-VIEWFS-75 | A mutable commit cut may publish a new object only when its observed base equals the session's current head and a live write handle is present. |
| I-VIEWFS-76 | A stale observed base must deny commit even if the local journal and write handle still exist. |
| I-VIEWFS-77 | A restore token under a death verdict or stale brake must not reacquire a live handle. |
| I-VIEWFS-78 | A revoked handle may remain inspectable but must not authorize reads, writes, exports, executes, or tool invocations. |
| I-VIEWFS-79 | A receipt alone must not retain the source object it describes. |
| I-VIEWFS-80 | A prompt string or model proposal must not invoke an effectful tool without a typed action plan, approval cut, and matching live authority slot. |
| I-VIEWFS-81 | Every fixture-coverable proof obligation must have at least one fixture, and every fixture must cite known proof-obligation IDs. |

| I-VIEWFS-82 | A compatibility pathwalk denied for symlink, magic/synthetic, or mount/provider crossing must not be retried through host ambient root or collapsed into a generic success path. | `021-compat-symlink-crossing-denied.json`; `022-compat-magic-link-crossing-denied.json`; `023-compat-mount-crossing-denied.json` |
| I-VIEWFS-83 | A delegated child handle must target the same object as its source and its rights must be a subset of both the source rights and the attenuation envelope while the delegation lease is live. | `024-delegation-narrow-handle-allow.json`; `025-delegation-widen-handle-denied.json` |
| I-VIEWFS-84 | A revoked delegation may retain recall receipts but must not leave the delegated child authority usable through the delegation lane. | `026-delegation-revoked-wavefront-denied.json` |
| I-VIEWFS-85 | A shell card that displays live authority must have a backing live authority slot; receipt-history cards without such backing must be labeled inert. | `027-shell-card-receipt-inert-honest-allow.json`; `028-shell-card-receipt-claims-live-denied.json` |
| I-VIEWFS-86 | A source forget-complete claim is denied while local derived artifacts for the source remain live or unaccounted for, and may proceed only when cleanup states are explicit. | `029-forget-source-derived-live-denied.json`; `030-forget-source-derived-minimized-allow.json` |

## Revision 158 quarantine / export / conformance invariants

| ID | Invariant |
|---|---|
| I-VIEWFS-87 | A quarantined source must not be directly opened or exported unless a safe-viewer lane or explicit trust transition admits the exact requested right. |
| I-VIEWFS-88 | A safe-viewer handle for quarantined content must be constrained to read/inspect-only authority and must not carry export, execute, publish, or write effects. |
| I-VIEWFS-89 | A trust transition must not release content when its origin evidence is merely a summary, receipt, unverified locator, or claim-only record. |
| I-VIEWFS-90 | An authority diff must deny hidden widening and must account for every declared added and removed right before a shell surface may render it as honest. |
| I-VIEWFS-91 | An export plan must require a typed plan, approved cut, explicit sink, live export authority, and quarantine clearance for quarantined or foreign-origin sources. |
| I-VIEWFS-92 | An old export receipt must remain history only and must not be replayable as current export authority. |
| I-VIEWFS-93 | The generated conformance report must be derived from the fixture corpus and proof-obligation table so coverage drift is visible during lint. |

## Revision 159 policy / witness / replay / override invariants

| ID | Invariant |
|---|---|
| I-VIEWFS-94 | A policy allow decision must not authorize an effect unless the referenced policy bundle is active, the policy digest matches, the decision is enforced, the resource scope matches, and a live handle carries the requested right. |
| I-VIEWFS-95 | Advisory policy results, stale policy bundles, deny verdicts, digest mismatches, and policy decision logs must remain non-authoritative even when they are rendered in shell or conformance views. |
| I-VIEWFS-96 | A witness bundle must bind decision id, policy bundle, policy digest, input digest, subject, evaluator, and required facts before it may be used as explanation evidence. |
| I-VIEWFS-97 | A complete witness bundle must not replay the original effect or substitute for a fresh approval cut or live handle. |
| I-VIEWFS-98 | A replay scenario that omits denial evidence or missing witnesses must not count as conformance evidence. |
| I-VIEWFS-99 | A breakglass override must require verified stewardship, exact object scope, unexpired bound, audit sink, and live authority; an emergency label alone must deny. |


## Revision 160 freshness / distributed-state invariants

| ID | Invariant | Evidence |
|---|---|---|
| I-VIEWFS-100 | A lease renewal must deny when the lease is expired, revoked, epoch-mismatched, missing a renewal cut, or lacking live authority. | fixtures 055-058 |
| I-VIEWFS-101 | An offline branch publish must deny when the remote head moved or the caller presents only a local commit/receipt. | fixtures 059-061 |
| I-VIEWFS-102 | A conflicted merge must deny until an approved resolution cut and resolution witness exist. | fixtures 063-064 |
| I-VIEWFS-103 | A merge receipt must not replay reconciliation or publish a new object state. | fixture 065 |
| I-VIEWFS-104 | A remote attestation must bind issuer, subject, statement digest, signature verification, revocation status, and expiry before it counts as evidence; it remains non-authority. | fixtures 066-069 |
| I-VIEWFS-105 | A freshness fence must deny when expired, epoch-mismatched, or still uncertain for a linearized operation. | fixtures 070-073 |
| I-VIEWFS-106 | A journal checkpoint must deny without verified flush proof, materialized target object, and live finalizer authority; receipts cannot replay checkpoint effects. | fixtures 074-076 |

## Revision 161 disclosure / observation invariants

| ID | Invariant | Evidence |
|---|---|---|
| I-VIEWFS-107 | A redaction view must deny blocked fields and must not authorize output without a live backing handle. | fixtures 077-079 |
| I-VIEWFS-108 | An audit projection must deny raw rendering without raw-audit authority and must deny any live-authority badge not backed by a live slot. | fixtures 080-083 |
| I-VIEWFS-109 | A disclosure package must deny when replayed from receipt, missing redaction, missing raw-export authority, or source/sink scope mismatch. | fixtures 084-088 |
| I-VIEWFS-110 | A subscription notification must deny when the cursor is expired, observe authority is missing, full payload redaction leaks, or the notification is used as object authority. | fixtures 089-093 |
| I-VIEWFS-111 | A subject-access export must deny when unapproved, scope-mismatched, receipt-replayed, or leaking third-party/internal redacted fields. | fixtures 094-098 |
## Revision 163 GC / archive / deletion invariants

| ID | Invariant | Evidence |
|---|---|---|
| I-VIEWFS-112 | A GC candidate must deny when a live handle, retention root, snapshot pin, archive hold, protected backup set, or live derived copy remains. | fixtures 123-128 |
| I-VIEWFS-113 | A snapshot pin may be pruned only by an approved cut with live prune/GC authority and must deny receipt replay or protected-backup retention. | fixtures 131-133 |
| I-VIEWFS-114 | An archive hold may be released only by a stewarded cut with live release authority; compliance retention before expiry must deny. | fixtures 134-137 |
| I-VIEWFS-115 | Restore from backup requires a verified backup set, approved restore plan, exact object membership, and live restore/write authority. | fixtures 138-141 |
| I-VIEWFS-116 | A deletion claim must deny when proof is missing, when known retained copies contradict it, when sanitization level is weaker than claimed, or when used as open authority. | fixtures 142-146 |

## Revision 165 resource / side-effect invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-117 | A budget, quota card, or metering row must not reserve spend unless a live payer/spend handle is present and remaining capacity is sufficient. | fixtures 173-177 | draft |
| I-VIEWFS-118 | A spend reservation must remain amount-, scope-, and status-bounded and cannot itself grant object authority. | fixtures 173, 182, 186, 196-198 | draft |
| I-VIEWFS-119 | Rate-limit windows must deny when exhausted, stale, or replayed from a receipt. | fixtures 178-181 | draft |
| I-VIEWFS-120 | A background job must revalidate queue lease, reservation, rate, typed plan, approval cut, and live authority at start. | fixtures 182-186 | draft |
| I-VIEWFS-121 | A cache entry must not hydrate when used as authority, evicted, source-stale, or above pressure limit without a pin. | fixtures 187-191 | draft |
| I-VIEWFS-122 | Capacity signals must be coarse, approved, identifier-free, and backed by observe-capacity authority unless a later stronger disclosure lane exists. | fixtures 192-195 | draft |
| I-VIEWFS-123 | Metering receipts must settle only against live reservations and must deny replay or overcharge. | fixtures 196-198 | draft |


## Revision 168 transform / lineage / interpretation invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-124 | A transform output must not claim source authority, and a lossy transform must deny unless loss/degradation is explicitly disclosed. | fixtures 252-255 | draft |
| I-VIEWFS-125 | A codec profile must deny unpinned handlers, active content in a safe-preview lane, and decode attempts without live source authority. | fixtures 256-259 | draft |
| I-VIEWFS-126 | A schema migration must deny old validators, undisclosed lossy migration, missing source authority, and migration receipt replay. | fixtures 260-263 | draft |
| I-VIEWFS-127 | A patch set must deny if its observed base is stale, if it is summary-only, or if it attempts to expand authority. | fixtures 264-267 | draft |
| I-VIEWFS-128 | Annotation labels and selectors must not become policy labels, authority classes, or secret-bearing selectors unless separate lanes explicitly admit them. | fixtures 268-271 | draft |
| I-VIEWFS-129 | Lineage verification must deny incomplete source hashes, ambiguous transform steps, receipt replay, and claims that lineage itself grants authority. | fixtures 272-275 | draft |
| I-VIEWFS-130 | Preview artifacts must pass redaction checks for rendered fields and must deny any claim that the preview is the source object or source authority. | fixtures 276-278 | draft |
| I-VIEWFS-131 | Canonicalization must deny confusable collisions and any claim that a canonicalized digest is the original-byte digest. | fixtures 279-281 | draft |

## Revision 169 compliance-label / release-gate invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-132 | Classification labels must deny when used as authority, when classifier state is stale, when subject binding mismatches, or when conflicts remain unresolved. | fixtures 282-286 | draft |
| I-VIEWFS-133 | License use must deny when the intended use is prohibited, not permitted, missing obligations, missing accepted terms, or missing live use authority. | fixtures 287-291 | draft |
| I-VIEWFS-134 | Jurisdiction fences must deny region-label shortcuts, disallowed destinations, stale routes, missing export-license posture, and missing egress authority. | fixtures 292-295 | draft |
| I-VIEWFS-135 | Compliance obligations must be discharged by current artifacts and live effect authority; old receipts and checklist rows are not discharge authority. | fixtures 296-299 | draft |
| I-VIEWFS-136 | Public release must deny public-label shortcuts, stale reviews, redaction leaks, missing obligations, missing verified reviewers, and receipt replay. | fixtures 300-304 | draft |
| I-VIEWFS-137 | Purpose-bound use must deny purpose-statement authority, purpose mismatch, unapproved secondary use, inactive retention budget, and missing live use authority. | fixtures 305-308 | draft |
| I-VIEWFS-138 | Compliance cards must not claim live authority, clear-to-export status, or blocked-field visibility unless the underlying evidence and handle slots exist. | fixtures 309-312 | draft |

## Revision 170 query / planning / evaluation invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-139 | A query admission must deny saved-query/text shortcuts, source or field widening, missing live authority, and stale index epochs. | fixtures 313-316 | draft |
| I-VIEWFS-140 | A planner trace must deny when it is proposal-only, unapproved, unverified, hidden-effect-bearing, or rights-widening. | fixtures 317-320 | draft |
| I-VIEWFS-141 | A result-set member may open only when the result set is fresh, not summary-only, and the selected member has a live backing handle. | fixtures 321-324 | draft |
| I-VIEWFS-142 | Aggregation views must deny below-threshold cohorts, raw-row exposure, and exact-membership/membership-oracle claims. | fixtures 325-328 | draft |
| I-VIEWFS-143 | Evaluation sets must deny contamination, unsealed holdouts, missing license/purpose clearance, and label-as-production-authority attempts. | fixtures 329-332 | draft |
| I-VIEWFS-144 | Benchmark runs must deny score-as-deploy shortcuts, stale epochs, unreproducible runs, and unadmitted eval/rubric inputs. | fixtures 333-336 | draft |
| I-VIEWFS-145 | Scoring rubrics must deny rubric-text-as-policy, inactive or uncalibrated rubrics, stale rubric epochs, and detected metric gaming. | fixtures 337-340 | draft |
| I-VIEWFS-146 | Model-selection cards must deny unbacked deploy claims, production-ready claims without approval cuts, hidden tradeoffs, and single-score-only laundering. | fixtures 341-344 | draft |


## Revision 171 incident / forensic / remediation invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-147 | Alert admission must deny stale alerts, authority-claiming alerts, subject mismatch, and missing observe/security authority. | fixtures 349-352 | draft |
| I-VIEWFS-148 | Incident case opening must deny missing active alert context, remediation-authority claims, closed cases, and missing case authority. | fixtures 353-356 | draft |
| I-VIEWFS-149 | Triage must deny execution claims, low confidence, stale verdicts, and missing triage authority. | fixtures 357-360 | draft |
| I-VIEWFS-150 | Forensic snapshot capture must deny live-access claims, redaction leaks, unsealed captures, and missing capture authority. | fixtures 361-364 | draft |
| I-VIEWFS-151 | Evidence-chain verification must deny digest mismatch, incomplete chains, causality/truth claims, and missing verification authority. | fixtures 365-368 | draft |
| I-VIEWFS-152 | Containment approval must deny unapproved plans, scope widening, missing blast-radius review, and missing containment authority. | fixtures 369-372 | draft |
| I-VIEWFS-153 | Remediation execution must deny receipt replay, missing preconditions, closure claims, unapproved plans, and missing remediation authority. | fixtures 373-376 | draft |
| I-VIEWFS-154 | Recovery rollback must deny unapproved plans, stale base epochs, history-erasure claims, and missing rollback authority. | fixtures 377-380 | draft |
| I-VIEWFS-155 | Postmortem rendering must deny live-authority claims, closure/no-recurrence claims, redaction leaks, and unbacked public-release claims. | fixtures 381-384 | draft |

## Revision 172 governance / change-management invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-156 | Change proposal admission must deny proposal-as-authority, stale basis epochs, scope widening without review, and missing governance authority. | fixtures 385-388 | draft |
| I-VIEWFS-157 | Decision records must bind exact proposal digests and deny execution claims, digest mismatch, missing proposals, and missing decision authority. | fixtures 389-392 | draft |
| I-VIEWFS-158 | Approval quorums must deny quorum-as-authority, insufficient thresholds, missing required steward, stale quorum rows, and missing approval authority. | fixtures 393-396 | draft |
| I-VIEWFS-159 | Rollout starts must deny completion claims, failed guardrails, unadmitted rings, missing blast-radius review, and missing rollout authority. | fixtures 397-400 | draft |
| I-VIEWFS-160 | Feature flags must deny flag-as-authority, out-of-scope cohorts, stale policy epochs, inactive flags, and missing feature authority. | fixtures 401-404 | draft |
| I-VIEWFS-161 | Deprecation enforcement must deny removal claims, early windows, missing migration paths, inactive notices, and missing deprecation authority. | fixtures 405-408 | draft |
| I-VIEWFS-162 | Compatibility contracts must deny compatibility-as-proof claims, version mismatches, unwaived breaking changes, inactive contracts, and missing compatibility authority. | fixtures 409-412 | draft |
| I-VIEWFS-163 | Migration runs must deny success claims, stale source schemas, missing prechecks, missing rollback plans, unapproved runs, and missing migration authority. | fixtures 413-416 | draft |
| I-VIEWFS-164 | Governance cards must deny live-authority claims, private-vote leaks, false unanimity, unsealed cards, and unbacked effect posture. | fixtures 417-420 | draft |
| I-VIEWFS-165 | Fixture catalog checks must fail on numbering gaps, duplicate names, mismatched mode suffixes, missing operations, or missing proof-obligation links. | `tools/check_fixture_catalog.py`; `out/fixture_catalog_report.md` | draft |


## Revision 173 workflow / automation custody invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-166 | Event admission must deny untrusted sources, invalid schemas, subject mismatches, authority-claiming events, and missing observe/event authority. | fixtures 421-424 | draft |
| I-VIEWFS-167 | Trigger evaluation must deny stale rules, event-type mismatches, inactive rules, authority-claiming rules, and missing trigger authority. | fixtures 425-428 | draft |
| I-VIEWFS-168 | Schedule firing must deny early or expired windows, missing approval cuts, authority-claiming schedules, and missing schedule authority. | fixtures 429-432 | draft |
| I-VIEWFS-169 | Workflow start must deny queued-row authority, invalid leases, stale bases, missing approval cuts, non-ready runs, and missing workflow authority. | fixtures 433-436 | draft |
| I-VIEWFS-170 | Workflow steps must deny completion claims, inactive runs, missing approval cuts, missing target rights, and missing step authority. | fixtures 437-440 | draft |
| I-VIEWFS-171 | Idempotency keys must deny effect claims, spent-key replay, fingerprint mismatch, unusable key states, and missing dedupe authority. | fixtures 441-444 | draft |
| I-VIEWFS-172 | Retry policies must deny authority claims, exceeded attempts, unreached backoff, missing budget, inactive policies, and missing retry authority. | fixtures 445-448 | draft |
| I-VIEWFS-173 | Compensation must deny receipt replay, non-reversible effects, erasure claims, unapproved plans, and missing compensation authority. | fixtures 449-452 | draft |
| I-VIEWFS-174 | Human tasks must deny task-row authority claims, untrusted paths, assignee mismatch, missing approval cuts, non-ready tasks, and missing human authority. | fixtures 453-456 | draft |
| I-VIEWFS-175 | Workflow cards must deny live-authority claims, hidden-step leaks, unsealed cards, and completion claims not backed by a complete run. | fixtures 457-460 | draft |
| I-VIEWFS-176 | Trace-report registry checks must fail when builders, outputs, or labels are missing or duplicated. | `tools/check_report_registry.py` | draft |

## Revision 174 personalization / convenience invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-177 | User-profile verification must deny authority-claiming profiles, stale policy epochs, subject/session mismatches, and missing live profile authority. | fixtures 461-464 | draft |
| I-VIEWFS-178 | Preference application must deny policy/consent claims, stale epochs, scope widening, and missing live preference authority. | fixtures 465-468 | draft |
| I-VIEWFS-179 | Personalization model admission must deny authority claims, stale model epochs, missing purpose basis, unminimized sources, and missing live personalization authority. | fixtures 469-472 | draft |
| I-VIEWFS-180 | Recommendation rendering must deny authority claims, private-feature leakage, inactive source models, unscoped sets, and missing recommendation authority. | fixtures 473-476 | draft |
| I-VIEWFS-181 | Shortcut execution must deny shortcut-as-authority, missing approval cuts, missing target rights, inactive bindings, and missing shortcut authority. | fixtures 477-480 | draft |
| I-VIEWFS-182 | Autofill acceptance must deny write-authority claims, missing approval cuts, secret leaks, missing target rights, and missing autofill authority. | fixtures 481-484 | draft |
| I-VIEWFS-183 | Experiment assignment must deny policy overrides, stale epochs, scope widening, inactive assignments, and missing experiment authority. | fixtures 485-488 | draft |
| I-VIEWFS-184 | Feedback recording must deny training-consent claims, unauthorized purposes, training reuse without consent, and missing feedback authority. | fixtures 489-492 | draft |
| I-VIEWFS-185 | Personalization cards must deny live-authority claims, sensitive-feature leaks, non-renderable states, and deterministic-user-truth claims. | fixtures 493-496 | draft |
| I-VIEWFS-186 | Lint manifest checks must fail on duplicate entries, missing files, missing lint-tool `main()` functions, or trace-report registry/report output drift. | `tools/check_lint_manifest.py` | draft |

## Revision 175 schema / ontology / reference / crosswalk invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-187 | Namespace binding must deny authority-claiming contexts, stale policy epochs, prefix collisions, digest mismatches, and missing namespace authority. | fixtures 497-500 | draft |
| I-VIEWFS-188 | External-reference resolution must deny authority-claiming references, unallowed schemes, stale resolver epochs, target-digest mismatch, and missing reference authority. | fixtures 501-504 | draft |
| I-VIEWFS-189 | Vocabulary-term admission must deny policy-claiming terms, deprecated/inactive terms, missing namespace bindings, and missing vocabulary authority. | fixtures 505-508 | draft |
| I-VIEWFS-190 | Crosswalk mapping must deny exact-equivalence claims, missing review, low confidence, inactive terms, and missing crosswalk authority. | fixtures 509-512 | draft |
| I-VIEWFS-191 | Shape validation must deny validation-as-authority, stale/inactive shapes, failed validation, missing target read authority, and missing shape authority. | fixtures 513-516 | draft |
| I-VIEWFS-192 | Ontology alignment must deny inferred-authority claims, stale alignments, unreviewed equivalence, low confidence, and missing ontology authority. | fixtures 517-520 | draft |
| I-VIEWFS-193 | Catalog publication must deny disclosure-authority claims, stale catalog epochs, missing release review, missing redaction, missing source disclosure rights, and missing catalog authority. | fixtures 521-524 | draft |
| I-VIEWFS-194 | Interop cards must deny live-authority claims, overstated equivalence, hidden-identifier leaks, and non-renderable states. | fixtures 525-528 | draft |
| I-VIEWFS-195 | Record-family catalog checks must fail on unsorted/duplicate family names, invalid family names, duplicate row ids, or families with no non-empty fixture evidence. | `tools/check_record_family_catalog.py`; `out/record_family_report.md` | draft |


## Revision 176 host-adapter compatibility invariants

| ID | Invariant | Evidence | Status |
|---|---|---|---|
| I-VIEWFS-196 | Adapter mount admission must deny root-authority claims, stale policy epochs, sandbox mismatch, inactive mounts, and missing live mount authority. | fixtures 529-532 | draft |
| I-VIEWFS-197 | Stat projection rendering must deny read-authority claims, hidden-field leaks, non-renderable rows, missing source read, and missing stat authority. | fixtures 533-536 | draft |
| I-VIEWFS-198 | Inode alias resolution must deny object-identity claims, collisions, stale epochs, inactive aliases, non-live targets, and missing alias authority. | fixtures 537-540 | draft |
| I-VIEWFS-199 | Xattr parcel reads must deny policy-authority claims, unallowed names, sensitive unredacted names, inactive parcels, non-live sources, and missing xattr authority. | fixtures 541-544 | draft |
| I-VIEWFS-200 | Watcher delivery must deny open-authority claims, stale cursors/epochs, unallowed event types, inactive subscriptions, and missing watch authority. | fixtures 545-548 | draft |
| I-VIEWFS-201 | Lock acquisition must deny write-authority claims, unavailable tokens, range conflicts, missing target rights, and missing lock authority. | fixtures 549-552 | draft |
| I-VIEWFS-202 | Rename execution must deny completion claims, unapproved plans, cross-mount movement without explicit allowance, missing source write, missing target-parent write, and missing rename authority. | fixtures 553-556 | draft |
| I-VIEWFS-203 | Tempfile promotion must deny committed-state claims, missing flush proof, missing approval cut, missing target write, and missing tempfile authority. | fixtures 557-560 | draft |
| I-VIEWFS-204 | Placeholder hydration must deny read-authority claims, stale placeholder epochs, unverified network/source state, missing source/result read handles, and missing hydrate authority. | fixtures 561-564 | draft |
| I-VIEWFS-205 | External-app handoff must deny persistent-grant claims, missing portal approval, unredacted payloads, missing target read, and missing handoff authority. | fixtures 565-568 | draft |
| I-VIEWFS-206 | Operation catalog checks must fail when evaluator names, fixture operations, proof coverage, or positive/negative specimens drift. | `tools/check_operation_catalog.py`; `out/operation_catalog_report.md` | draft |
