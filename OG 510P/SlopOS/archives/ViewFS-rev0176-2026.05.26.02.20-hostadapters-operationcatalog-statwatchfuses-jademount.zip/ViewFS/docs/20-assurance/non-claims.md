# Non-claims

Revision 002 deliberately does **not** claim:
- full POSIX fidelity,
- global path stability across views,
- general live revocation,
- distributed transparency,
- a final on-disk format,
- a final hash algorithm,
- that content addressing alone solves mutable namespace integrity,
- that all shell pipelines should become typed by force,
- that portal persistence semantics are already final,
- that grouped capability bundles/dictionaries are already designed,
- that mutable work-state semantics are already chosen,
- that terminal workflows/notebooks require cloud sync or AI assistance.
- that durable reopen necessarily implies strong live revocation,
- that object identity, path/name stability, mutable current head, and grant persistence are already unified semantics,
- that the shell-to-terminal metadata protocol is already final.
- that the final host-side backstop strategy is already chosen,
- that grant-class and receipt-state names are already a final protocol schema,
- that route sheets or object palettes are already part of the final shell UX.
- that workspace/tree grants, durable recents, transfer receipts, and URI launch/reveal are already one unified primitive,
- that completion/palette metadata or stale-grant states are already a final shell protocol schema.
- that recent items, reopen handles, object refs, and reveal routes are already one primitive.
- that object-link rendering or mark/hyperlink metadata are already a final shell protocol schema.
- that live handles, durable refs, and transcript receipts already share one final encoding or interchange story.
- that session manifests, notebook sidecars, or workflow descriptors are already a final export or interchange format.
- that pane/session restore will ever silently rehydrate old authority by default.

- that selector registries or recent-item databases are already part of the final authority model.
- that a final index engine, ranking model, or selector-row schema has already been chosen.
- that a final workspace trust-record schema, trusted-location policy, or automation-class taxonomy has already been chosen.
- that a final watch protocol, event taxonomy, or watch-health enum has already been chosen.
- that live watch feeds will ever count as complete ambient inventory or bearer authority.

- that a final alias/symlink/reopen/shortcut object schema has already been chosen.
- that clickable shell links or breadcrumbs will ever count as bearer authority by themselves.
- that a final quarantine/origin taxonomy, trust-clear policy, or safe-open session model has already been chosen.
- that recents, palettes, or workspace binds will ever count as implicit trust-clearing actions.
- that a final checkpoint/snapshot format, fork/worktree schema, or branch/head model has already been chosen.
- that every checkpoint will count as a backup, a publish candidate, or an activation target.
- that any future time-travel UI will silently restore live external authority or workspace trust.

- that a final lock/lease/field-ownership model has already been chosen.
- that every mutable seam in ViewFS will require a reservation or hard lock.
- that conflict receipts, takeover receipts, or merge artifacts are already a final interchange format.
- that a final QueryManifest schema, result-snapshot serialization, or live query feed protocol has already been chosen.
- that a shell smart folder will ever silently collapse saved criteria, current results, and standing background subscriptions into one primitive.
- that import, open-in-place, save/export, move, transfer, share/delegate, and promised-file materialization are already one final protocol family or one final receipt schema.
- that promised outputs or transfer offers will ever count as already-materialized live authority by default.
- that a final cache-eviction policy, hydration-closure policy, pin/root schema, or mirror-topology model has already been chosen.
- that `cached`, `hydrated`, `pinned`, `mirrored`, or `offline-bundled` will ever count as interchangeable statuses.
- that offline readiness will ever silently imply publication, activation, workspace trust, or broader durable authority.
- that a final bundle/dictionary, view-fragment, or launch-kit schema has already been chosen.
- that current-pane state and child-launch state will ever be the same default object by definition.
- that saved workflows, notebooks, or launch recipes will ever silently serialize live authority by default.
- that a final request/candidate/selection/import-result schema or staging-tray UX has already been chosen.
- that chooser-owned candidate surfaces will ever count as generic machine inventory or current live authority by default.
- that a final intent/plan/approval/result schema or prepare-versus-commit shell UX has already been chosen.
- that historical result receipts will ever count as standing approval or current live authority by default.
- that a final suggestion-source, promotion-receipt, or user-workflow schema has already been chosen.
- that workspace-suggested or receipt-derived automation will ever silently become user-owned workflow truth by default.
- that a final loan-request, borrowed-handle, delegated-ref, recall-control, or expiry schema has already been chosen.
- that any future borrowed-authority flow will silently persist into durable reopen or session-wide trust by default.
- that a final basis-record/drift-check/reconsent/reuse-receipt schema has already been chosen.
- that a past success receipt, durable reopen ref, or prior approval will ever silently follow a newer mutable basis by default.
- that a final validation/policy/advice/diagnostic/log schema or policy-aware shell protocol has already been chosen.
- that shell advice rails, diagnostic cards, or audit traces will ever count as current policy authority by default.
- that a final policy-family catalog, cut-token, fallback-rail, repair-proposal, or selection-receipt schema has already been chosen.
- that fallback candidates, repair prompts, or old selection receipts will ever silently choose the current authoritative policy family/cut by default.
- that a final proposal-origin taxonomy, scope lattice, escalation protocol, or adoption-receipt schema has already been chosen.
- that workspace/profile/org/history/helper proposals will ever silently become authoritative adoption by default.
- that a final deny-ceiling vocabulary, scope-eligibility matrix, narrowing-transform schema, or scope-fuse protocol has already been chosen.
- that helper advice, history, or queued steering will ever silently bypass authoritative deny ceilings or widen a proposal source by default.
- that a final owner/org/device-vs-user-vs-workspace source-precedence lattice, trust-shutter state machine, or import-tray schema has already been chosen.
- that imported helper material, workspace values, or history receipts will ever silently become effective state by default.
- that a final author-class taxonomy, carrier/container taxonomy, advisory-only-rail protocol, or trust-tunnel warning schema has already been chosen.
- that trusted carriers, parent-repo discovery, plugin-installed helpers, or history rows will ever silently become policy authors by default.
- that a final protected-state taxonomy, source-class × state-class authorability matrix, latched-invoke protocol, or invoke/adopt receipt schema has already been chosen.
- that workspace, parent-repo, plugin, or history-carried helper material will ever silently become protected or always-on state by default.
- that a final publisher-trust, install/config, enablement, start-approval, live-session, request-selection, or lifecycle-receipt schema has already been chosen.
- that installed packages, configured helpers, enabled toggles, or past live sessions will ever silently count as current live authority by default.

- that a final resource/prompt/tool/app/completion, request-binding, invocation/result, or durable-receipt schema has already been chosen.
- that a visible helper catalog item, completion suggestion, or old invocation receipt will ever count as current request authority by default.
- that a final close/cancel, terminate, detach/delete, retry-fresh, reset/fork/attach, or durable-receipt schema has already been chosen.
- that stop, forget, retry, attach, and fork will ever silently collapse into one generic deferred-control verb by default.
- that a final observe/query/follow, interactive attach, control-message, exec/debug, sideband-tunnel, or durable-transcript schema has already been chosen.
- that a live follow pane, read-only attach, control pane, debug shell, tunnel badge, or old transcript will ever silently count as the same current authority by default.

- that a final transfer-offer, handoff-choice, live-copy, revival-designator, or adoption-receipt schema has already been chosen.
- that cross-pane/process/app sharing will ever silently imply receiver-local bind/adoption or durable reopen by default.

- that a displayed caveat card, expiry badge, or old delegation receipt will ever count as proof of currently enforced authority by default.

- that a visible `granted`, `prompt`, `denied`, `revalidate needed`, or similar preflight badge will ever count as proof that the pane already holds current live authority by default.
- that a final dead-state/tombstone taxonomy or universal repair-ladder schema has already been chosen.
- that `stale` will remain an acceptable all-purpose explanation once reason-rich revocation/expiry/change/unavailable verdicts are available.

- that a final provenance/attestation schema, endorsement-bundle format, transparency-witness model, or universal admit/deny taxonomy has already been chosen.
- that a signed claim, threshold endorsement, transparency-log witness, or past admit receipt will ever count as current live authority by default.
- that a final request-ledger schema, session-lifecycle enum, transfer-key format, or generic live-portal-state API has already been chosen.
- that one successful request row, one portal-side `active` label, or one old session receipt will ever count as current local authority by default.
- that a final smart-query schema, live-query feed protocol, materialized-set object model, or basket/bind receipt taxonomy has already been chosen.
- that a saved query, a frozen hit list, or an old search receipt will ever silently count as one current local collection object by default.

- that a final completion-candidate schema, focused-detail schema, command-packet format, or trust-grade vocabulary has already been chosen.
- that a highlighted suggestion, accepted insertion, or heuristically observed transcript line will ever count as a prepared action or trusted replay packet by default.

- that a final placement-record schema, rights-summary vocabulary, affordance-discovery ABI, or action-availability taxonomy has already been chosen.
- that one path-shaped placement, one provider-advertised verb list, or one old receipt will ever count as proof of current authority by default.

## Revision 154 non-claims

Revision 154 does not claim ViewFS has a final trusted UI root, a final volition-token schema, a final secure attention gesture, or a final accessibility/remote/headless approval model. It only claims that consent summary, presentation, gesture, volition, approval, live authority, and receipt lanes should not collapse while those designs are still open.


## Revision 173 non-claims

Revision 173 does not claim that ViewFS has selected Temporal, CloudEvents, OpenFeature, ActivityPub, cron, a durable queue, or any other workflow runtime. It does not claim exactly-once execution, distributed transaction semantics, or final compensation semantics. It only claims that workflow-adjacent artifacts must remain separate from authority: event delivery, trigger match, schedule eligibility, queued run state, step row, idempotency key, retry policy, compensation recipe, human task, and workflow card are not live object authority by default.

## Revision 174 non-claims

Revision 174 does not claim that ViewFS has selected a final user-profile schema, recommender architecture, shortcut/autofill UX, experiment service, feedback/telemetry pipeline, or preference-sync protocol. It does not claim that feedback is training consent or that preference signals replace policy. It only claims that personalization and convenience artifacts must remain separate from identity proof, consent, policy, authority, write effects, training permission, and deterministic user truth.

## Revision 175 non-claims

Revision 175 does not claim that ViewFS has selected RDF, JSON-LD, OWL, SKOS, SHACL, DCAT, Schema.org, URI templates, or any other interoperability standard as its internal object model. It does not claim ontology inference is policy, that shape validation is approval, that crosswalks prove exact equivalence, or that catalog entries are disclosure authority. It only claims that schema/ontology/reference artifacts must remain separate from live authority, policy, release cuts, and canonical truth.


## Revision 176 non-claims

Revision 176 does not claim that ViewFS has chosen FUSE, Windows ProjFS, Apple File Provider, WebDAV, 9P, inotify, kqueue, FSEvents, POSIX rename, POSIX advisory locks, or any specific xattr namespace as its final host adapter API. It does not claim host inode numbers are stable object identities, that stat metadata is a complete truth surface, that watcher events refresh authority, that advisory locks enforce policy, or that open-with handoff grants persistent access. It only claims that these compatibility artifacts must remain separate from live handles, policy, disclosure approval, write authority, commit proof, and durable delegation.
