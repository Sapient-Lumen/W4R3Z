# Live room bindings, projected bases, local upper overlays, and merged room presentations

Purpose: keep **live room bindings**, **projected base stacks**, **writable local upper overlays**, **merged room presentations**, **publish/commit/adopt results**, and **receipts** on different seams while SlopOS is still settling how much clone/overlay/store structure it will eventually standardize.

## Why this split matters
A lot of editable-import confusion comes from letting one displayed path or tree answer every question at once.
ViewFS should instead let the shell answer, separately:
- what exact thing is bound here now?
- what base or ordered base stack is being projected here?
- what writable local shadow exists here, if any?
- what merged presentation is this room actually traversing?
- did a separate act publish or commit something durable from that state?
- or do we only have history explaining that one of those things used to be true?

That makes the future shell more honest and keeps the object-store design open longer.

## Distinct classes
- **live room binding** — exact thing bound here now
- **projected base stack** — provider, portal, generated, or ordered lower layers
- **local upper overlay** — writable local shadow for adds/replacements/hides
- **merged room presentation** — what traversal/open sees now
- **publish / commit / adopt result** — later deliberate durable outcome
- **receipt** — durable explanation of what happened before

## Lessons worth stealing
### Base, upper, and merged are not the same thing
OverlayFS keeps `lowerdir`, `upperdir`, and `workdir` separate, merges name lists, reports many metadata/xattr truths from the upper side, and uses whiteouts/opaque directories for hide semantics instead of mutating the lower tree.
That is a very strong precedent for keeping `base`, `upper`, `merged`, and `hide` visibly distinct.

### Ordered union membership deserves visible ordering
Plan 9 union directories are ordered lists with head/tail/replace control, lookup follows list order, and creation goes to the first creatable member.
That is exactly the kind of explicitness ViewFS should preserve for room-local merge views.

### Multi-source merged presentation is a convenience surface
Kubernetes projected volumes map several existing sources into the same directory.
That is a useful reminder that the merged presentation is not proof that the sources became one durable local object.

### Placeholder/materialize/evict ladders are useful honesty
Apple File Provider draws a sharp line between placeholder items, later provision of the actual file on disk, and later eviction.
Nix `realise` similarly reminds us that explicit realization/fetch/build should stay a separate act.
Those are both excellent precedents for ViewFS `materialize/commit/publish` ladders.

## Shell pressure this unlocks
- **shadow-stack ledgers** that show `base`, `upper`, `merged`, `whiteout`, `opaque`, `published`, or `receipt only`
- **whiteout ghosts** that explain `hidden below` without pretending the lower object vanished from reality
- **creation-target pips** that show where a newly-created item would actually land
- **commit ladders** that keep `keep shadow only`, `seal upper`, `publish merged view`, `make local object`, and `push back` as separate acts
- **upper/lower diff drawers** that compare the local shadow and the base instead of one flattering merged tree

## Non-decisions preserved
Do not freeze yet:
- one final overlay/worktree ABI;
- one final hide/whiteout/opaque representation;
- whether projected bases are always provider-backed or sometimes generated from room metadata;
- whether publish/commit/adopt results always create local objects, room aliases, or provider mutations;
- whether multiple uppers or nested overlays are admitted in Phase 1.
