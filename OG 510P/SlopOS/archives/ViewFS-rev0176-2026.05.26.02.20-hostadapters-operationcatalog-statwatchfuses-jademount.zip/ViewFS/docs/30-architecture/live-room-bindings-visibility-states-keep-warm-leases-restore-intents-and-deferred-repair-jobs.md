# Live room bindings, visibility states, keep-warm leases, restore intents, and deferred repair jobs

Purpose: keep **live room bindings**, **foreground/background visibility state**, **keep-warm/background-presence grants**, **restore/autostart intents**, **deferred repair jobs**, and **receipts** on different seams while SlopOS is still settling its background/job/portal surfaces.

## Why this split matters
The easiest way to over-design warm continuity is to let one `room is still around` story silently absorb five different questions:
- what is bound here now,
- whether it is visible now,
- whether it may stay warm while hidden,
- whether it may come back on login or restart,
- and whether a deferred job may do repair work later.

Those are different product truths and different authority shapes.

## Distinct classes
- **live room binding** — exact thing bound in the room namespace now
- **visibility state** — foreground / hidden / serving / draining / history only
- **keep-warm lease** — reviewed authority to remain warm or renew while not foreground-visible
- **restore intent** — reviewed permission or shell-owned intent to re-create later
- **deferred repair job** — queued repair/rebind/revalidate work with its own task lifecycle
- **receipt** — durable explanation of what happened before

## Lessons worth stealing
### XDG Background gives us the right nouns
The Background portal keeps `run in the background` and `start automatically when the user logs in` separate. That is exactly the sort of low-regret seam ViewFS should copy for room continuity and imported-helper life.

### Background status should be product chrome, not live identity
A user-visible status message is helpful, but it is not the same thing as the exact live bind or exact task instance.
ViewFS should likewise let room chrome say `warming`, `restoring later`, or `queued for repair` without pretending those are the same object.

### Mobile platforms teach discipline
Android and Apple background APIs are full of constraints, but the deep lesson is useful: long-running foreground-noticeable work, short-lived hidden work, and deferred maintenance are different classes, and the platform wants the user-visible story to stay honest.

### Kubernetes teaches richer lifecycle lamps
Lease holder/renew fields and EndpointSlice `ready`/`serving`/`terminating` conditions are great evidence against one flat availability bit.
ViewFS should feel free to expose `foreground`, `background-serving`, `warming`, `draining`, `restore-intent only`, and `receipt only` as distinct room states.

## Shell pressure this unlocks
- **warmth rails** that show `foreground`, `warming`, `background-serving`, `draining`, or `history only`
- **keep-warm badges** that say whether hidden continuity is allowed, clamped, expiring, or absent
- **login lanterns** that say whether restore-on-login is allowed, proposed, denied, or receipt only
- **defer drawers** that show when repair is queued as a job instead of being kept live
- **status strips** that explain “alive now” versus “will try later” versus “only happened before”

## Non-decisions preserved
Do not freeze yet:
- one final keep-warm lease carrier,
- one final restore-intent store,
- whether room restore and helper autostart share one substrate,
- whether deferred repair jobs are shell-local, portal-local, or supervisor-local,
- or one final lifecycle enum for room chrome.
