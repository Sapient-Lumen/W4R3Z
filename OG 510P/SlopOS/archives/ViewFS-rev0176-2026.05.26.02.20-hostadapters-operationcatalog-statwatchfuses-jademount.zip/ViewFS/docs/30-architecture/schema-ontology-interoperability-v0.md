# Schema, ontology, reference, and crosswalk interoperability v0

Revision 175 adds an interoperability lane for ViewFS. This lane is deliberately narrower than a full linked-data, ontology, or catalog system. Its purpose is to keep schema-adjacent artifacts useful without letting them become authority.

## Problem

ViewFS now has many artifact families: policies, classifications, labels, cards, reports, datasets, provenance rows, recommendations, workflow records, and release surfaces. The next failure mode is not missing metadata. It is metadata that becomes too powerful.

Interoperability tools are especially dangerous because they look universal. A namespace context can make a string look global. A URI can look like object identity. A vocabulary term can look like a policy category. A crosswalk can look like exact equivalence. A shape validation can look like approval. A catalog entry can look like public-release permission. An interop card can make all of those look safely understood.

ViewFS v0 therefore treats interoperability artifacts as explanatory and validation evidence only.

## Record families

| Family | Role | Must not become |
|---|---|---|
| `namespace_bindings` | Binds a local prefix/context digest to a reviewable namespace posture. | Object authority, policy, global truth. |
| `external_references` | Represents an external URI/IRI/reference after scheme, freshness, and digest checks. | A live handle, possession proof, or disclosure authority. |
| `vocabulary_terms` | Admits a term inside an active namespace. | Classification, policy, consent, or executable rights. |
| `crosswalk_mappings` | Maps one admitted term to another with review and confidence posture. | Exact equivalence unless a separate reviewed exact-equivalence cut exists. |
| `shape_constraints` | Records validation of data against a current shape. | Approval, object authority, or semantic truth. |
| `ontology_alignments` | Represents reviewed semantic relation evidence between vocabularies. | Inferred authority or automatic policy inheritance. |
| `catalog_entries` | Publishes redacted/reviewed metadata about objects or datasets. | Raw disclosure authority or public-release approval by itself. |
| `interop_cards` | Shell explanation cards over namespaces, references, terms, crosswalks, shapes, and catalogs. | Live authority, hidden identifiers, or equivalence proof. |

## Checked operations

| Operation | Admission condition |
|---|---|
| `bind_namespace_context` | active binding, current policy epoch, digest match, no blocked prefix, live `namespace` authority. |
| `resolve_external_reference` | active reference, allowed scheme, fresh resolver epoch, target digest match, live `reference` authority. |
| `admit_vocabulary_term` | active term, active namespace binding, non-deprecated state, live `vocabulary` authority. |
| `apply_crosswalk_mapping` | active source/target terms, review, confidence floor, exact-equivalence review when needed, live `crosswalk` authority. |
| `validate_shape_constraint` | current active shape, passing validation, target read authority, live `shape` authority. |
| `verify_ontology_alignment` | active/fresh alignment, confidence floor, equivalence review when applicable, live `ontology` authority. |
| `publish_catalog_entry` | ready entry, current catalog epoch, redaction, public-release approval, source disclosure right, live `catalog` authority. |
| `render_interop_card` | renderable card with no live-authority claim, hidden identifier leak, or overstated equivalence. |

## Anti-collapse rules

1. A URI identifies; it does not open.
2. A context expands; it does not authorize.
3. A term classifies; it does not grant.
4. A crosswalk translates; it does not prove equality.
5. A shape validates structure; it does not approve use.
6. An ontology alignment informs reasoning; it does not inherit authority.
7. A catalog entry advertises metadata; it does not disclose payloads.
8. An interop card explains; it does not certify safety.

## Companion pressure

Foundry already treats classification pins and crosswalk witnesses as first-class drift surfaces. Schell warns that derived labels, catalogs, and references can persist after source minimization. Harbor contributes stale public-surface pressure. SlopOS contributes the authority principle: none of these rows should be executable without a typed plan, approval cut where needed, and a current live authority carrier.
