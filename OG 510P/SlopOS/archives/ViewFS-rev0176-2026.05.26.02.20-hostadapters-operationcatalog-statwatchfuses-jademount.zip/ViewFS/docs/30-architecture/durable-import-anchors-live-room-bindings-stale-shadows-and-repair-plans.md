# Durable import anchors, live room bindings, stale shadows, and repair plans

This note protects one more high-value seam while ViewFS and SlopOS are both still moving.

Revision 0100 already split namespace plans, live room bindings, portal import sessions, local overlays, and receipts.
This note adds another discipline on top:

**the durable designator that may help reopen something later, the current live room bind now, the weaker stale-or-repairable shadow that may remain after currentness is lost, the repair/rebind plan, and the receipt explaining what happened are different classes.**

## The split

### 1. Durable import anchor
A durable import anchor is the reviewable answer to:
- what persisted, non-bearer, reopen/reimport designator exists for this object or provider relation?

It may be saveable, listable, pruneable, and inspectable.
It is not current room authority.

### 2. Live room binding
A live room binding is the current answer to:
- what exact object, projection, or import is this room actually holding right now?

This should tell the truth about current binds and current use.
It should not pretend to describe durable reopen state or stale-but-repairable shadow state.

### 3. Stale shadow
A stale shadow is the current answer to:
- what remains when the durable anchor still exists but current live truth no longer does?

Good state labels:
- `live`
- `stale-needs-resolve`
- `needs-user-step`
- `provider-changed`
- `continuity-uncertain`
- `receipt-only`

This helps ViewFS stay honest about partial continuity.

### 4. Repair / rebind plan
A repair plan is the current answer to:
- what exact next workflow could restore current truth, and what would it ask the user/system to do?

Good state labels:
- `retry-resolve`
- `ask-portal-again`
- `rebind-here`
- `import-fresh`
- `discard-anchor`
- `keep-receipt-only`

This is reviewable future action.
It is not proof that current truth already returned.

### 5. Receipt/history
Receipts preserve explanation of:
- initial import
- persistence choice
- stale verdicts
- repair attempts
- successful rebinding
- discards and pruning

They should not silently reactivate live authority.

## Product consequences

### Durable-access racks
The shell should be able to show a compact rack with separate rows for:
- `durable anchor`
- `live now`
- `stale shadow`
- `repair plan`
- `receipt only`

### Stale shadows
A room should be able to show `live`, `stale`, `prompt needed`, `provider changed`, `continuity uncertain`, or `receipt only` without flattening them into one fake `open` badge.

### Repair ladders
A room or object inspector should be able to offer:
- `rebind current room`
- `repair with consent`
- `import fresh and compare`
- `drop anchor`
- `keep history only`

The key is not magic repair.
The key is **truthful repair choices**.

### Rebind receipts
If a repair succeeds, the receipt should say:
- what durable anchor it started from,
- whether identity continuity was exact or only inferred,
- whether local overlays survived,
- whether any rights narrowed or widened,
- and whether the old live bind died or was replaced in place.

## Why this fits current SlopOS work
Current SlopOS already leans toward:
- explicit document handles and portal mediation,
- optional explicit persistence rather than ambient durability,
- capability-safe shell posture,
- descriptive wallets rather than silent bearer smuggling,
- typed plumb/intents rather than string folklore.

That gives ViewFS permission to protect this seam **without** deciding the final durable-store object model.

## Good questions to keep open
- Should a durable import anchor always be provider-local, or can some later become native ViewFS durable objects?
- When should a stale shadow become `continuity uncertain` instead of merely `needs rebind`?
- Can a repair plan survive as a reusable recipe without impersonating live authority?
- Which room resets kill only live binds versus durable anchors versus local overlays?
- How should receipt-first restore behave when the durable anchor survives but the live bind does not?
