# Live room bindings, summon beacons, activation batons, foreground turns, and secure entry

Purpose: keep **live room bindings**, **summon/surface-me cues**, **activation/raise eligibility**, **actual foreground turns**, **secure-entry/trusted-input posture**, and **receipts** on different seams while SlopOS is still settling attention, trusted UI, and display-surface meaning.

## Why this split matters
The easiest way to over-design shell visibility is to let one vague `front / alert / activate` object silently absorb five different questions:
- what is live here now,
- whether it wants to be surfaced,
- whether it may try to raise/focus,
- whether it actually has the foreground turn now,
- and whether the user is in a trusted-entry path.

Those are different product truths and different authority shapes.

## Distinct classes
- **live room binding** — exact thing bound in the room namespace now
- **summon beacon** — transient `surface me` cue for a room/helper/result card
- **activation baton** — narrow proof/privilege that may let a client request foreground
- **foreground turn** — actual frontmost/focused truth now
- **secure-entry gate** — separately trusted input/approval mode
- **receipt** — durable explanation of what happened before

## Lessons worth stealing
### Wayland activation gives us the right humility
An activation token can be minted, forwarded, found invalid, or still declined by the compositor.
That is the right posture for ViewFS too: asking to be surfaced is not the same thing as being surfaced.

### Windows keeps delegated foreground narrow
Foreground privilege can be passed across processes, but it remains time-scoped and does not itself activate the window.
That is a great precedent for ViewFS activation batons: stronger than a cue, weaker than actual focus.

### SlopOS keeps host-owned display separate from trusted entry
Current SlopOS display-surface posture explicitly refuses to let fullscreen/modal/show-more-room requests quietly become focus/foreground/trusted-entry authority.
That is a very valuable seam for ViewFS.

### Focus events are great chrome, not trust proofs
Focus-in/focus-out terminal signals are useful for better shell polish and quieter prompts.
They are not, by themselves, a proof that a room owns the foreground or that the user is in a trusted-entry path.

## Shell pressure this unlocks
- **summon beacons** that say `surface me`, `glance me`, `result ready`, or `review wants front`
- **front latches** that say `frontmost`, `requested`, `declined`, `stolen back`, or `receipt only`
- **secure-entry shutters** that explain `trusted path active`, `host-local only`, `policy denied`, or `not a secure surface`
- **activation baton chips** that say `fresh`, `forwarded`, `consumed`, `expired`, or `invalid`
- **quality badges** that say whether the shell knows all of this richly, partially, or approximately

## Non-decisions preserved
Do not freeze yet:
- one final secure-entry gate carrier,
- one final host/terminal/shell split for foreground truth,
- whether summon beacons are room-local or workspace-local,
- whether activation batons can cross helper/runtime boundaries,
- or one final focus/raise policy language.
