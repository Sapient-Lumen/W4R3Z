# Instruction sources, context frames, proposal text, action plans, tool invocations, approvals, live authority, and receipts

Revision 153 adds a design note for instruction hygiene in a ViewFS world that will almost certainly grow semantic search, answer cards, agents, MCP-like helpers, prompt files, workspace instructions, and tool calls.

The point is not to design the final AI subsystem. The point is to prevent a subtle regression: replacing ambient filesystem authority with **ambient prompt authority**.

## The trap

A capability-oriented object store can still lose if it lets a model loop reassemble authority from prose:

```text
source says "ignore policy" -> RAG includes it -> model plans a tool call -> tool metadata claims read-only -> action receives current handles -> receipt looks approved
```

Every arrow in that chain crosses a boundary:

- source content versus instruction;
- instruction source versus local priority/trust;
- context inclusion versus authority exposure;
- model output versus typed plan;
- tool metadata versus tool permission;
- tool result versus validator truth;
- user message versus approval cut;
- receipt/history versus fresh authority.

Keep those boundaries visible before choosing formats.

## Lane inventory

### Instruction source record

Records where instruction-like material came from:

```text
source_kind: system_policy | developer_policy | user_speech | org_policy | profile_pref |
             workspace_file | parent_repo_file | package_prompt | retrieved_text |
             tool_description | tool_result | model_output | memory_row | transcript_receipt
origin: object/ref/portal/tool/provider/room
quarantine: none | risky | safe-open-only | redacted | omitted
scope: global | profile | org | workspace | repo | folder | room | request | result | history-only
```

This record is descriptive. It is not an instruction by itself and not authority.

### Trust / priority label

A local classification says how the planner may treat the source:

```text
authoritative-policy
user-intent
advisory-preference
workspace-proposal
imported-template
untrusted-content
quarantined-content
generated-proposal
receipt-only
```

This is a local cut, not something the text gets to declare for itself.

### Context frame / input capsule

The model receives a capsule, not the whole world:

```text
context frame
roots: current room + selected portal import
included: 4 snippets, 2 tool manifests, 1 user request
omitted: secret slots, quarantine raw text, history-only receipts
redaction: emails masked; tokens omitted
instruction sources: source ladder digest
available tools: manifest T-17, not ambient
```

A context frame is a disclosure/selection artifact. It should not grant the model live source handles by implication.

### Model/prompt execution profile

The profile explains how proposal text was produced:

- model/provider/sampler;
- message layout and prompt template;
- instruction hierarchy or priority policy;
- available tool manifest;
- retrieval profile;
- redaction lens;
- memory shutter;
- network/secret/file authority visible to the model;
- deterministic/non-deterministic knobs.

The profile is not a grant. It supports debugging and drift review.

### Proposal text

Model output, completion text, answer text, command suggestions, and plan narratives stay proposal-only. A proposal may be beautiful. It still needs compilation.

### Action plan / compiled packet

An effectful proposal becomes useful only after it is compiled into a typed packet:

```text
action plan
subject: room R / process P
operation: export-object
source: live handle slot H7
sink: network lease candidate N3
arguments: object O, redaction policy Z
preconditions: currentness witness W, source not quarantined for export
payer: budget lease B2
approval required: user high-friction
```

This is where ViewFS can apply policy, invariants, currentness, payer, and authority checks.

### Tool invocation candidate

A tool call is an execution candidate, not model prose:

```text
tool call candidate
tool: helper.build/pr.create
arguments_digest: ...
claimed hints: readOnly=false, openWorld=true, destructive=possible
required slots: file read H2, network send N1
exfiltration posture: object bytes + generated text
validator: pass with approval
```

Tool descriptions and annotations may help the UI. They do not approve the call.

### Approval / adoption cut

The approval cut names what was approved:

- exact plan digest;
- exact inputs and output classes;
- exact authority slots;
- freshness/currentness witnesses;
- risks, omitted facts, and redactions;
- whether user, policy, org, or workflow approved it;
- whether it may be retried, remembered, or promoted.

Approving “the answer looked good” is not the same as approving “send these exact bytes to this exact destination using this exact lease.”

### Current live authority

Only current handles, leases, secret slots, service proxies, namespace roots, live borrows, and portals can actually authorize effects. The model never holds authority because text mentions it.

### Results and observations

Tool results, stdout/stderr, structured JSON, UI-only metadata, screenshots, model-visible result text, progress, trace rows, and logs are observations. They can be imported or adopted through separate lanes; they are not validator truth by default.

### Receipts

Receipts explain what happened:

```text
receipt
context digest: C
proposal digest: P
plan digest: A
approval basis: user + policy cut
live authority used: H7, N1, B2
result: committed, redacted transcript
rerun posture: needs fresh context + approval
```

A receipt cannot rerun itself.

## Lessons from SlopOS

SlopOS gives ViewFS a strong local precedent without forcing a schema:

- `llm-operations-posture-v0.md` says text is proposal-only and D-LLM does not add a second agent-runtime execution path.
- MCP prompt/resource/root/completion/sampling/task/logging boundaries keep imported provider material from becoming file grants, workflow truth, prompt authority, durable conversation, or scheduler truth.
- Tool UI boundaries keep rendered components presentation-local: no hidden approval, browser session, file materialization, model-memory, follow-up-message, or tool-call plane.
- ACP/action validation material says effectful steps should flow through explicit schemas, validators, and bindings.

For ViewFS, this means an agentic shell can be delightful only if it is relentlessly source-labeled and plan-compiled.

## Wider prior-art pressure

### Prompt injection and indirect prompt injection

OWASP names prompt injection as a top LLM risk. OpenAI frames third-party context misleading an AI agent as prompt injection and emphasizes that robustness remains a hard, evolving challenge. Microsoft and Google both describe indirect prompt injection as a risk arising from untrusted content incorporated into AI workflows.

ViewFS should assume prompt injection exists and design for containment, not perfect detection.

### MCP tools/resources/prompts

MCP usefully separates resources, prompts, tools, sampling, roots, and elicitation. Its security language is also the warning: tools can be arbitrary code/effects, users should understand and consent to operations, and tool annotations/descriptions are untrusted unless the server path is trusted.

ViewFS should steal the catalog shape, not the assumption that model-visible descriptions are policy.

### Workspace/custom instruction systems

VS Code and similar tools now make project instructions, prompt files, agents, skills, hooks, MCP servers, and parent-repo discovery productive. This is a great product direction and a danger signal. Instruction sources need origin, scope, trust, freshness, and activation posture.

A parent `AGENTS.md`-style file is not a capability to control a child room unless ViewFS explicitly adopts it.

### Instruction hierarchy

Instruction hierarchy helps models ignore lower-priority instructions. ViewFS should expose source/priority labels so the model can benefit from them. But the validator must still live outside the model.

## Design rules

1. Never treat a model-readable string as policy unless an explicit local policy/adoption lane says so.
2. Never treat a model output as a validated action plan.
3. Never call a tool because its description claims it is safe.
4. Never infer user approval from an answer card, old chat message, or clicked suggestion without showing compiled effect arguments.
5. Never let retrieved text install or enable tools, hooks, memory, instructions, or namespace roots.
6. Never let tool results smuggle new approvals, hidden action parameters, or validator facts.
7. Never let parent-repo/workspace instruction discovery bypass workspace trust and scope gates.
8. Never let old prompt/context receipts seed future agent memory without a memory/adoption shutter.

## Shell vocabulary

Revision 153 should prototype vocabulary, not schema:

- **instruction ladders** — where every instruction-like row came from;
- **context shutters** — what was included/omitted/redacted;
- **inert-text rails** — imperative retrieved content is content;
- **proposal badges** — model output is proposal-only;
- **plan compiler cards** — text became typed plan A, or failed;
- **toolcall fuses** — exact tool + arguments + authority slots + risk posture;
- **approval basis drawers** — who/what approved exact effect;
- **result quarantine** — result content remains observation;
- **memory promotion shutters** — whether this row can persist;
- **receipt ghosts** — useful history, no rerun authority.

## Non-decisions

Still open:

- prompt schema and role names;
- instruction priority lattice;
- AI provider/model selection;
- local versus remote model execution;
- plan language;
- validation engine;
- prompt-injection detector;
- MCP adapter ABI;
- memory store format;
- exact UI friction for approvals;
- how much chain-of-thought-like material is stored or suppressed.

Stable for now: **data can suggest, text can propose, plans can be validated, approvals can authorize, live handles can act, and receipts can explain. Those are not the same thing.**
