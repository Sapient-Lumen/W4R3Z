# Live room bindings, local edit shadows, intent keys, accepted requests, provider operations, and adopted results

This note sharpens one more low-regret ViewFS separation:
**live room binding**, **editable local shadow**, **intent key / sameness witness**, **accepted request/admission**, **provider operation or completion ticket**, **completion verdict**, **locally adopted result**, and **durable receipt/history** are different truths.

Relevant precedents:
- **REF-HTTPAPI-IDEMPOTENCY-KEY**: the current HTTP Idempotency-Key draft makes non-idempotent requests fault-tolerant, requires servers to publish key-expiry policy, and distinguishes first-seen, duplicate-after-completion, and concurrent-duplicate handling.
- **REF-AWS-EC2-IDEMPOTENCY**: the same client token with the same parameters replays safely, but the same token with different parameters fails with `IdempotentParameterMismatch`.
- **REF-STRIPE-IDEMPOTENT-REQUESTS** and **REF-STRIPE-ADVANCED-ERROR-HANDLING**: first-result replay, parameter comparison, pruning windows, and explicit retry advice are separate from final object identity.
- **REF-GCLOUD-LRO**: once a request is admitted, a later operation resource is still a different seam from the original sameness claim.
- **SlopOS**: `network-request-idempotency-boundary-v0.md` and `background-request-state-posture-v0.md` reinforce the same discipline: request-key sameness should not masquerade as current provider state or mutable upsert authority.

## Why the split matters
The future custom shell is going to host provider-backed imports, pushbacks, publishes, and retryable delayed actions.
That only stays honest if it can answer at least seven different questions:
- what is bound here now?
- what local draft/shadow am I editing?
- what sameness witness says this retry is supposed to be the same request?
- was the request merely admitted?
- is there a provider-owned operation or status monitor?
- what later settlement became true, if any?
- what did this room adopt locally afterward?

Those questions differ because the consequences differ.
A live room bind can grant present authority now.
A local shadow can be rich and editable but still private.
An intent key can say `treat this as the same request` without granting anything.
An accepted request can be real without promising completion.
An operation ticket can be useful follow-up state without being object identity.
A completion verdict can say what upstream settled without dictating local adoption.
A receipt can explain all of that while authorizing nothing now.

## Working posture

### Live room binds should stay current-state truth
The shell should answer exactly what this room is bound to now.
That must remain separate from any replay or dedupe key.

### Local shadows should stay draft-first
A local shadow or sealed candidate should remain inspectable, diffable, and preservable even after retries.
That keeps editing and replay-safe provider work decoupled.

### Intent keys should stay sameness truth
A room should be able to say:
- `fresh key`
- `same-intent retry`
- `same key, payload changed`
- `key pruned`
- `no sameness witness`

That is better shell truth than one flattering `retrying...` spinner.

### Accepted requests should stay admission truth
A room should be able to say:
- `rejected now`
- `accepted and queued`
- `accepted with operation handle`
- `duplicate replayed from prior result`
- `accepted but follow-up unknown`

That is better shell truth than one flattering `saving...` spinner.

### Provider operations should stay follow-up truth
An operation monitor should say:
- `poll here`
- `provider-owned job`
- `watch only`
- `expired handle`
- `no follow-up lane`

That is useful without pretending the operation handle *is* the dedupe witness or committed result.

### Completion verdict should stay settlement truth
The shell should be able to say:
- `settled: applied`
- `settled: duplicate replay`
- `settled: conflict`
- `settled: pending`
- `settled: concurrent duplicate`
- `settled: unknown`

That is more honest than one universal green checkmark.

### Local adoption should stay explicit
After replay or settlement, the room should still choose its local consequence explicitly:
- keep draft,
- fast-forward local state,
- fork local state,
- attach receipt only,
- or start a fresh intent lineage.

That prevents provider sameness handling from silently rewriting the user's current footing.

## Shell and terminal payoffs
A truthful shell can turn this split into product leverage:
- **intent lamps** that distinguish `fresh`, `same-intent retry`, `mismatch`, `pruned`, and `unknown`;
- **retry braids** that group attempts under one sameness witness without pretending they were all the same provider run;
- **sameness chips** that compare the current canonical payload to the original request basis before resubmission;
- **operation beads** that show provider-owned follow-up without pretending they are the same thing as the intent key;
- **not-the-same-request shutters** when an edit would require a fresh key instead of a replay.

## Classification worth standardizing early
A useful posture-oriented classification for shell UX and protocol spikes is:
- `no_intent_key`
- `fresh_intent_key`
- `same_intent_retry`
- `intent_key_payload_mismatch`
- `intent_key_pruned`
- `accepted_no_ticket`
- `accepted_with_ticket`
- `concurrent_duplicate`
- `settled_replayed`
- `settled_applied`
- `settled_unknown`
- `adopt_keep_local`
- `adopt_fast_forward`
- `adopt_fork_local`
- `receipt_only`

This is intentionally posture-oriented.
It does **not** decide one final provider mutation ABI, one final fingerprint algorithm, or one final dedupe retention model.

## What not to freeze yet
Do **not** freeze yet:
- one universal `Idempotency-Key`-style header or field for all ViewFS families,
- whether the shell or provider computes canonical-request fingerprints,
- one mandatory mismatch/verdict vocabulary across all providers,
- whether every provider can replay first results,
- or one permanent answer to how rooms auto-adopt after replay or settlement.

The separation is worth freezing now.
The key schema, fingerprint algorithm, and retention windows are not.
