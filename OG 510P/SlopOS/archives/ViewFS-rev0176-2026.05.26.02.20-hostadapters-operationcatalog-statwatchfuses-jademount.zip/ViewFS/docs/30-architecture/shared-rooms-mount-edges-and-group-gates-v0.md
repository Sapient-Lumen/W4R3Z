# Shared rooms, mount edges, and group gates v0

Revision 162 adds executable pressure around the first real multi-principal namespace seam in ViewFS. A shared room, collaboration workspace, mounted projection, ACL row, or group membership can help decide whether authority is eligible to be composed, but none of those records is a live object handle.

The v0 lane deliberately separates:

```text
SharedRoom
  -> MountEdge
  -> GroupMembership
  -> live Handle
  -> composed ViewRoot / Bind
  -> Receipt
```

## Record families

- `SharedRoom` — a room/workspace/collaboration surface with participants, roles, status, and state epoch.
- `MountEdge` — a candidate projection from a source view/handle into a target room path.
- `GroupMembership` — a current directory or group-membership fact set with epoch, members, optional denied members, scope, and authority handle.

## Anti-collapse rules

1. A room id, room name, invite, presence advert, or collaborator badge is not authority.
2. A mount edge must be live, target the named room, and be backed by a live source handle.
3. Mount edge rights must be a subset of the source handle rights.
4. Shared/peer propagation needs an explicit propagation gate. It cannot happen just because the mount edge exists.
5. A stale room epoch denies before path or mount authority is considered.
6. Group membership can participate in authorization only at a current epoch, for an exact principal, within exact scope, and with a live handle.
7. A group label, directory card, or pretty team name is not a group-bound capability.

## Current fixtures

- `099-shared-room-mount-edge-allow.json`
- `100-shared-room-non-member-denied.json`
- `101-mount-edge-widening-denied.json`
- `102-mount-propagation-without-gate-denied.json`
- `103-shared-room-stale-epoch-denied.json`
- `104-group-membership-live-handle-allow.json`
- `105-group-membership-without-handle-denied.json`
- `106-group-membership-stale-epoch-denied.json`
- `107-group-principal-not-member-denied.json`
- `108-group-label-as-authority-denied.json`

## Shell posture

The shell should show a collaboration space as a composition of facts, not as a single magic share bit:

- room participants and role epoch;
- mount edge source handle, target path, rights subset, and propagation gate;
- group membership epoch and exact principal match;
- current live handle slot used for the effect;
- authority diff between source handle and composed room-visible rights.

A green room chip may mean “this room currently includes you.” It does not mean “every object visible in this room is yours to read/export/write.”

## Non-goals

This v0 lane is not a full ACL system, CRDT authorization model, federated-room protocol, or mount namespace implementation. It only makes the first collaboration collapses executable: membership is not authority, mount projection is not authority, propagation is not approval, and group labels are not handles.
