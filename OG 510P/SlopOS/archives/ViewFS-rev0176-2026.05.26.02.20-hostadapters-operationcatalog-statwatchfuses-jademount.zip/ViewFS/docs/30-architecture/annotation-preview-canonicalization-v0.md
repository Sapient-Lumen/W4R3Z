# Annotation, preview, and canonicalization lanes v0

Annotation, preview, and canonicalization surfaces are easy places for ViewFS to lie to itself. A tag can look like policy. A cached preview can look like the source file. OCR text can look like the original page. A normalized string can look byte-identical. A selector can reveal the private content it points at.

## Annotation layers

`AnnotationLayer` records bind an annotation body, target object, selector posture, currentness, sensitivity, and authority handle. ViewFS permits annotation only when the selector still targets the current subject and the caller has live annotate authority.

Annotation labels are never policy labels by default. Promotion from annotation label to classification/policy label must pass through the policy/label overlay lanes, not the annotation lane.

## Preview artifacts

`PreviewArtifact` records bind source object, rendered fields, redaction requirements, redaction view, and source handle. A preview is a presentation surface and cache artifact. It may be rendered through a redaction lens, but it cannot claim source-object authority.

Preview cards must display source identity, transform/codec lineage, field set, and redaction status. Raw preview fields deny unless the current redaction view admits them.

## Canonicalization profiles

`CanonicalizationProfile` records bind the normalization/canonicalization profile, confusable/spoofing posture, equivalence witness, and digest claim. Canonicalization is allowed only as a bounded equivalence statement.

Canonicalized bytes are not the original bytes. The digest of canonicalized or normalized bytes must not be rendered as the digest of the original object. Confusable collisions deny by default until a human/policy lane chooses a narrower exception.

## Shell implications

Cards should show three separate identities:

1. original object identity;
2. rendered/preview identity;
3. normalized/canonical identity.

The UI should never collapse them into one badge. Any card that claims “same file” must say which equality relation is being asserted: byte equality, semantic equivalence, rendered equivalence, schema equivalence, or lineage-derived equivalence.
