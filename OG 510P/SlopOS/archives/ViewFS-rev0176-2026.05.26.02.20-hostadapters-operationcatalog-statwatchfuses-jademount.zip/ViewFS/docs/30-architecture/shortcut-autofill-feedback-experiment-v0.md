# Shortcuts, autofill, feedback, and experiment custody v0

Revision 174 also adds the convenience surfaces that most often smuggle effects into companion apps: shortcuts, autofill, experiments, and feedback.

## Core split

| Surface | Can do | Cannot do |
|---|---|---|
| `ShortcutBinding` | connect a named convenience action to an exact target handle and approval cut | execute effects without target rights or become macro authority |
| `AutofillProposal` | suggest values for a specific target field under redaction and approval | write data, reveal secrets, or inject credentials by itself |
| `ExperimentAssignment` | select a UI or behavior variant within a bounded scope and current policy epoch | override policy, compatibility, or authority checks |
| `FeedbackSignal` | record bounded product feedback under allowed purposes | become training consent, retention root, or policy vote |

## Anti-collapse rule

Convenience is not consent. A shortcut, autofill row, cohort badge, or thumbs-up event is an input to a later cut, not the cut itself. Effectful work must still name live target authority, approval posture, purpose binding, and policy epoch.

This lane intentionally overlaps with Schell and SlopOS: Schell pressures minimization/forgetting for feedback and model features, while SlopOS pressures action authority and approval cuts for shortcut/autofill execution.
