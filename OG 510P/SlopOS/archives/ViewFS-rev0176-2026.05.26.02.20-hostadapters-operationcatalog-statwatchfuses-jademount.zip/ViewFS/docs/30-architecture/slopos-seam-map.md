## Revision 155 seam

ViewFS now packages the uploaded SlopOS `rev0720` snapshot instead of the older embedded `rev0655`. The immediate lesson is not to copy SlopOS portal.net internals into ViewFS, but to import the proof posture: accepted-only state transitions, replayable logs, restart/recovery images, checkpoint/lineage/append evidence, and tamper cases.

Net effect: ViewFS portal grants, view binds, compatibility pathwalks, semantic projections, consent chains, and receipts now have a tiny checked fixture lane. The next SlopOS-aligned jump should be a portal-grant replay corpus modeled after SlopOS's recent `portal.net.request` recovery and linearization evidence. See `docs/30-architecture/companion-seam-intake.md`.

## Revision 114 seam
- SlopOS `network-request-idempotency-boundary-v0.md`, `background-request-state-posture-v0.md`, and `acp-acceptance-completion-posture-v0.md` reinforce the next crucial ViewFS split: local editable shadows, retry-safe intent keys, accepted requests, provider-owned operation/status handles, later completion verdicts, and locally adopted results should not collapse into one flattering `retry/save` story.
- The strongest specific lesson is fail-closed mismatch handling: reusing the same sameness witness with a materially changed request should reject before effect instead of acting like mutable upsert semantics under one key.
- Net effect: ViewFS should treat `draft now`, `same-intent retry`, `payload changed`, `accepted`, `ticket`, `settled`, `adopt locally`, and `receipt only` as different truths while SlopOS is still design-stage.

## Revision 113 seam
- SlopOS `acp-acceptance-completion-posture-v0.md`, `acp-outcome-receipt-schema-v0.md`, and `background-request-state-posture-v0.md` reinforce the next crucial ViewFS split: local editable shadows, accepted requests, provider-owned operation/status handles, later completion verdicts, and locally adopted results should not collapse into one flattering `save is done` story.
- `capstore-commit-schema-v0.md` adds pressure to keep durable settlement truth and current room adoption separate even when a provider eventually accepts a mutation.
- Net effect: ViewFS should treat `draft now`, `accepted`, `ticket`, `settled`, `adopt locally`, and `receipt only` as different truths while SlopOS is still design-stage.

## Revision 112 seam
- SlopOS `acp-precondition-witness-posture-v0.md` and `capstore-commit-schema-v0.md` reinforce a crucial ViewFS split: local editable shadows, exact pushback witness/precondition basis, provider-side verdicts, and locally adopted results should not collapse into one flattering `save` story.
- `conflict-key-schema-v0.md` and `conflict-key-family-registry.md` add pressure to keep provider conflict scope and local adoption/merge behavior separate.
- Net effect: ViewFS should treat `draft now`, `expected old`, `provider verdict`, `adopt locally`, and `receipt only` as different truths while SlopOS is still design-stage.

# SlopOS seam map for ViewFS

Purpose: keep ViewFS aligned with the existing SlopOS datacube instead of inventing a second filesystem language that would later need translation.

## Guiding rule
When SlopOS already has a credible seam for the concept, ViewFS should usually **specialize it**, not replace it.

## Seam map

### 0c. ViewFS should keep secure-transport identity evidence separate from service authority
Use:
- `network-lease-tls-verifier-boundary-v0.md`
- `network-lease-client-cert-boundary-v0.md`
- `network-lease-session-resumption-boundary-v0.md`
- `certificate-identity-evidence-boundary-v0.md`
- `certificate-path-input-boundary-v0.md`
- `certificate-status-evidence-boundary-v0.md`
- `namecert-trust-root-boundary-v0.md`

Implication:
- SlopOS already warns that a network lease is not a portable verifier, client-certificate seam, resumption store, or trust-root plane;
- ViewFS should keep reference identities, presented evidence, verifier profiles, trust-anchor inputs, channel bindings, resumption state, live secure channels, and receipts separate from service binding and object authority;
- shell chrome should say `reference id`, `presented evidence`, `verifier profile`, `matched`, `exception`, `channel-bound`, `resumed`, `live`, or `receipt only` instead of one flattering `trusted` badge;
- final WebPKI/DANE/SPIFFE/SSH/mTLS policy remains a future seam, not a hidden property of D-NETLEASE.


### 0. ViewFS should copy SlopOS's optional persistence posture, not prematurely copy its whole future persistence surface
Use:
- `rfcs/0065-orthogonal-persistence-and-capstore.md`
- `capstore-commit-schema-v0.md`
- `capshell-handle-table-posture-v0.md`

Implication:
- immutable object identity, durable root commits, and durable reopen/receipt stories should stay visibly different classes;
- ViewFS can borrow the **optional, explicit, non-ambient** persistence stance without freezing a broad durable capability-graph story yet;
- if persistent authority shows up later, it should arrive as an explicit seam with rollback/resurrection discipline instead of being smuggled in through ordinary object use.


### 0a. ViewFS should keep narrow continuity / escrow separate from durable persistence
Use:
- `capshell-handle-table-posture-v0.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- a reconnectable conversation, queued follow-up, portal request still in flight, or resumable launch artifact should stay a narrower class than durable reopen or persistent root state;
- ViewFS can borrow SlopOS's explicit-handle posture for continuity without committing to a broad persistent capability graph;
- a supervisor-owned locker for exact handles or exact resumable lane artifacts is a promising middle seam between live-only state and broad persistence;
- shell chrome should show continuity/escrow artifacts as typed resumable lanes with expiry and scope, not as magical “saved session” folklore.

### 0b. ViewFS should keep transient staging capsules separate from committed objects and durable refs
Use:
- `rfcs/0094-transfer-portal-and-typed-payload-leases.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `capshell-handle-table-posture-v0.md`

Implication:
- ViewFS can benefit from an exact-byte staging capsule for preview/export/editor-return paths without treating that capsule as the object-store truth;
- explicit local handle transfer is a better fit than path reopen when the goal is “this exact staged payload”;
- shell chrome should badge capsule state like `draft`, `sealed`, `couriered`, `committed`, or `discarded` instead of hiding staging behind temp-file folklore.

### 1. ViewFS namespaces should ride the existing SlopOS view model
Use:
- `view-namespace-posture-v0.md`
- `capshell-cwd-root-posture-v0.md`
- `capshell-filesystem-posture-v0.md`

Implication:
- ViewFS should talk in terms of **explicit views, slot bindings, and local synthetic roots**.
- Avoid inventing a separate “mount table” worldview for Phase 1.

### 1a. ViewFS should keep detached view fragments separate from live binds and current placement
Use:
- `view-namespace-posture-v0.md`
- `capshell-cwd-root-posture-v0.md`
- `capshell-filesystem-posture-v0.md`

Implication:
- SlopOS already suggests a creator-populated view model strong enough that ViewFS can admit a **detached fragment / prepared subtree** class without collapsing it into a live bind or a durable path story;
- a prepared fragment should be attachable into a concrete process namespace only through an explicit attach/bind act that can be receipted and inspected;
- pre-attach posture and post-attach placement should stay separate truths, so shell chrome can distinguish `prepared`, `attached here`, and `receipt only`;
- ViewFS should resist letting “it was attached once” turn into ambient rediscovery or durable reopen folklore.


### 1b. ViewFS should keep unnamed objects separate from namespace publication and later receipts
Use:
- `rfcs/0033-functional-build-graphs-and-store.md`
- `rfcs/0038-persistent-object-store-and-snapshots.md`
- `rfcs/0032-view-namespace-semantics-v1.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`

Implication:
- SlopOS already hints that object creation/storage and namespace exposure need not be the same act, so ViewFS can admit an **unnamed object / publish-later** seam without inventing temp-path folklore;
- a fully formed object should be publishable into one explicit parent/view only through an explicit namespace-publication act that can choose collision posture and be receipted;
- shell chrome should distinguish `draft object`, `candidate publication anchor`, `published name here`, and `history only` instead of flattening them into one `saved file` story;
- ViewFS should resist letting temporary staging names become ambient authority just because an object is not yet published.

### 2. ViewFS handles should align with existing handle-table and exec-pack surfaces
Use:
- `capshell-handle-table-posture-v0.md`
- `fdset-schema-v0.md`
- `capshell-exec-pack-schema-v2.md`

Implication:
- launch-time filesystem authority should appear as explicit child bindings, not as inherited process folklore.
- if grouped capability bundles become necessary later, they should pay for an explicit seam rather than hiding inside exec defaults.

### 3. ViewFS portal imports should align with document-handle and portal surfaces
Use:
- `document-portal-posture-v0.md`
- `document-handle-schema-v0.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`

Implication:
- durable file/directory grants should look like SlopOS-style document references and portal receipts.
- exact selected objects should carry explicit affordance/operation truth so route sheets and shell menus are driven by granted reality instead of path guesses.
- ViewFS should not invent a parallel reopen token model.

### 3a. ViewFS should keep borrowed foreign-backed usability separate from projected locality and true local realization
Use:
- `document-portal-posture-v0.md`
- `document-handle-schema-v0.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `import-to-docref-boundary-v0.md`

Implication:
- SlopOS already gives ViewFS permission to treat mediator/provider-backed usefulness as a first-class current state instead of pretending every successful open/import is already local ownership;
- projected document views and document-handle grants are promising local usability seams, but they still should stay weaker than explicit localization into the local object store;
- shell chrome should be able to say `borrowed`, `projected here`, `materialized here`, `localized here`, or `history only` instead of flattening everything into one `opened file` story;
- ViewFS should resist turning one wrapper, relay, or projected path into ambient local truth just because it made the object usable in one pane.

### 3b. ViewFS should keep durable import anchors, current live room binds, stale shadows, and repair plans on distinct SlopOS-adjacent seams
Use:
- `rfcs/0065-orthogonal-persistence-and-capstore.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `docs/30-architecture/document-handle-schema-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already gives ViewFS enough explicit persistence/document/shell posture that ViewFS can keep `durable anchor`, `live bind now`, `stale shadow`, `repair plan`, and `receipt only` as separate truths without inventing a second file-token mythology;
- a durable anchor can remain explicit and inspectable without pretending it is a current room bind or a general ambient reopen power;
- shell chrome should be able to say `live`, `durable anchor only`, `stale-needs-repair`, `consent needed`, or `receipt only` instead of flattening them into one flattering `recent file` story;
- ViewFS should resist turning provider-backed repair potential into hidden automatic continuity just because a durable docref/bookmark-like object exists.

### 3c. ViewFS should keep live room bindings, renewal windows, retry advice, and repair gates on distinct SlopOS-adjacent seams
Use:
- `document-portal-posture-v0.md`
- `document-handle-schema-v0.md`
- `capability-lease-posture-v0.md`
- `background-lease-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already gives ViewFS enough explicit expiry/revocation and lease-shaped posture that ViewFS can keep `live bind now`, `currentness witness`, `renewal window`, `retry advice`, `repair gate`, and `receipt only` as separate truths without inventing a second hidden liveness myth;
- one reviewed renewal or keepalive lane should stay narrower than fresh authority grant or durable reopen;
- shell chrome should be able to say `renewed through`, `retry after`, `cooling down`, `manual clear required`, or `receipt only` instead of one vague `still available` badge;
- ViewFS should resist turning provider currentness, wait timing, and repeated-failure quieting into one generic retry loop just because the same object/import is involved.

### 4. ViewFS transfer and cross-app handoff should align with transfer portal + plumbing surfaces
Use:
- `transfer-portal-posture-v0.md`
- `rfcs/0094-transfer-portal-and-typed-payload-leases.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`

Implication:
- drag/drop, copy/paste, and shell-to-app handoff should be treated as mediated transfer sessions, not as an ambient loophole.
- ViewFS terminal UX should reuse plumb/receipt concepts instead of inventing a second ad-hoc dispatch channel.

### 5. ViewFS query / smart-folder ideas should align with D-ATTRFS
Use:
- `attrfs-posture-v0.md`
- `attribute-query-schema-v0.md`

Implication:
- query results should be handles within an explicit view, not raw paths or count-only ambient probes.
- smart folders should stay shell-owned manifests until stronger evidence appears.

### 6. ViewFS shell ergonomics should align with capability-safe shell surfaces
Use:
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `capshell-pipeline-posture-v0.md`
- `capshell-output-normal-form-v0.md`

Implication:
- shell/terminal affordances should improve visibility and routing, not smuggle in ambient authority.
- prompts, transcripts, and workflows should stay explainable in terms of existing handles, receipts, views, and portals.

### 6a. ViewFS should keep room identity, current room-local view, inheritance posture, and child spawn/import truth on distinct SlopOS-adjacent seams
Use:
- `docs/30-architecture/view-namespace-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0116-capability-wallets.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`

Implication:
- SlopOS already gives ViewFS enough explicit-view, descriptive-wallet, typed-plumb, and portal/document-handle posture that ViewFS can keep `room`, `current view`, `inheritance posture`, `prepared spawn recipe`, `child-received imports`, and `receipt only` as separate truths without inventing a second launch language;
- room identity can stay shell/terminal chrome truth while current live imports stay view/document/portal truth;
- reviewed child-room recipes can stay descriptive and inspectable without becoming current authority merely because they are saveable or searchable;
- child import trays should report what actually landed after portal/provider mediation instead of pretending one parent room or one saved recipe already settled the outcome.

## Near-term recommendation
For ViewFS Phase 1, prefer the following mapping language:
- **object identity** → immutable blobs/manifests/aref-like references
- **authority** → handles with explicit rights
- **namespace** → SlopOS view bindings
- **durable user grant** → SlopOS document-handle / portal semantics
- **workflow handoff** → explicit receipts, object refs, or plumb-like messages
- **query result** → handle sets inside a bound view
- **interactive shell ergonomics** → visible metadata over the same underlying seams


### 6. ViewFS mediated import workflows should align with SlopOS powerbox/document-handle/view seams
Use:
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `rfcs/0032-view-namespace-semantics-v1.md`

Implication:
- chooser/request state, candidate/designation surfaces, selected outcomes, minted grants/refs, and concrete view binds should stay visibly distinct.
- chooser-owned candidate sets are a better fit than generic app-visible filesystem inventory.
- a selected result should not silently count as a live pane bind, and a live bind should not silently count as a durable reopen grant.

### 33. ViewFS should keep owner/org policy, trust gates, user preferences, workspace/imported helper material, and effective state on distinct seams
Use:
- `rfcs/0028-veto-only-policy-bundles-for-automation.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0116-capability-wallets.md`

Implication:
- SlopOS already has enough authority, mediation, and descriptive-wallet seams that ViewFS does not need a hidden “settings blob becomes truth” plane;
- owner/org ceilings, trust-state withholding, user/profile preferences, workspace/imported helper proposals, and effective state can stay visibly distinct without inventing a second policy language;
- shell UX should explain source precedence and trust shutters, not silently flatten them.

### 34. ViewFS should keep policy authors, trusted carriers, and advisory-only sources on distinct SlopOS seams
Use:
- `rfcs/0028-veto-only-policy-bundles-for-automation.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `authagent-provider-role-boundary-v0.md`
- `verification-policy-selection-boundary-v0.md`

Implication:
- SlopOS already distinguishes authority-bearing policy from helper/agent roles, so ViewFS does not need a hidden “trusted carrier becomes policy author” tunnel;
- a plugin/package/workspace/parent-repo/history carrier may surface material, but authoring ceilings or trust gates should stay a separately inspectable question;
- shell UX should explain author, carrier, gate, and advisory-only status separately instead of laundering all of them into “this looked trusted enough.”

## Anti-drift rules
- Do not introduce a parallel host-path-centered permission model.
- Do not invent a second durable file-token type if CH-DOCREF is close enough.
- Do not let shell ergonomics bypass the handle/view/portal story.
- Do not add grouped authority containers casually; they need an explicit seam and threat review.

### 7. ViewFS should keep identity, naming, mutation, and grant persistence on distinct seams
Use:
- `document-handle-schema-v0.md`
- `view-namespace-posture-v0.md`
- `capshell-cwd-root-posture-v0.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`

Implication:
- a document reference, a bound name in a view, an immutable object ID, and a mutable workspace head should not be treated as one undifferentiated thing.
- SlopOS already has enough distinct seams that ViewFS does not need to compress them into “the path is the truth.”


### 8. ViewFS typed routing and URI-ish actions should align with OpenURI / D-PLUMB surfaces
Use:
- `openuri-portal-posture-v0.md`
- `openuri-showitem-exactness-boundary-v0.md`
- `openuri-recent-items-boundary-v0.md`

Implication:
- route sheets, object-open actions, and terminal click handlers should not collapse local-object actions into a generic `xdg-open` story.
- local file/document reveal belongs on explicit file/document seams; external URI launch belongs on OpenURI; recent-items semantics should remain separate from durable document grants.


### 9. ViewFS workspace/tree binds should stay distinct from recents and OpenURI launch
Use:
- `document-portal-posture-v0.md`
- `openuri-portal-posture-v0.md`
- `openuri-recent-items-boundary-v0.md`
- `transfer-portal-posture-v0.md`
- `view-namespace-posture-v0.md`

Implication:
- “bind this folder/tree into my working view” should land on a document/view seam with an explicit binding receipt, not on generic recent-items or external-launch semantics.
- OpenURI/reveal flows should stay route/launch-only unless another explicit seam mints local-object authority.
- transfer-to-workspace promotion, if it exists later, should be explicit and transcript-visible.

### 10. ViewFS should keep immutable object identity, durable reopen, and reveal routing on distinct seams
Use:
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `openuri-recent-items-boundary-v0.md`
- `openuri-showitem-exactness-boundary-v0.md`
- `view-namespace-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- immutable object refs are not the same thing as recent-item hints, route targets, or workspace binds;
- shell clicks and palette entries should preserve whether the action is inspect/rebind/reopen/reveal/launch rather than laundering everything into a generic open-token story.

### 11. ViewFS should keep live handles, durable refs, and transcript receipts on different seams
Use:
- `document-handle-schema-v0.md`
- `capshell-exec-pack-schema-v2.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `acp-outcome-receipt-schema-v0.md`

Implication:
- active object/view authority should stay in live bindings/handles;
- durable reopen should go through non-bearer descriptor seams such as CH-DOCREF-like references;
- transcript/audit artifacts should stay receipts and route sheets rather than becoming hidden bearer tokens.

### 12. ViewFS should keep session-state memory separate from live authority
Use:
- `explain-posture-v0.md`
- `acp-outcome-receipt-schema-v0.md`
- `attention-durable-status-boundary-v0.md`
- `openuri-recent-items-boundary-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- shell journals, notebooks, workflows, pane restore, and palette memory should point to receipts/refs/notes explicitly rather than silently reviving old grants;
- saved session state may help rebind or reopen, but it should not become a disguised bearer-capability export channel.

### 13. ViewFS indexes, recents, and selector registries should stay advisory on existing SlopOS seams
Use:
- `attrfs-posture-v0.md`
- `attribute-query-schema-v0.md`
- `openuri-recent-items-boundary-v0.md`
- `document-handle-schema-v0.md`
- `explain-posture-v0.md`

Implication:
- search hits, smart folders, recent-item rows, and palette entries should remain typed advisory surfaces rather than hidden bearer-authority channels;
- a row may lead to rebind/reopen/reveal/inspect, but SlopOS already has enough seams that ViewFS does not need “found in a registry” to count as access by itself.


### 14. ViewFS should keep workspace binding separate from workspace automation trust
Use:
- `view-namespace-posture-v0.md`
- `capshell-command-string-posture-v0.md`
- `capshell-word-expansion-posture-v0.md`
- `capshell-exec-pack-schema-v2.md`
- `document-portal-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- binding a workspace tree into a view should not itself authorize workspace-defined tasks, env hooks, debug launchers, notebooks, or agents;
- SlopOS already has distinct seams for visibility, command execution, expansion, and document access, so ViewFS can preserve a browse-first / trust-later opening story without inventing a second security model.


### 15. ViewFS preview/extraction surfaces should stay on explicit observation seams
Use:
- `openuri-preview-metadata-boundary-v0.md`
- `openuri-content-extraction-boundary-v0.md`
- `attrfs-posture-v0.md`
- `capshell-output-normal-form-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- preview panes, extracted text, preview cards, and compare renders should remain observation products, not hidden bearer-authority channels;
- SlopOS already distinguishes launch, extraction, query, and transcript surfaces, so ViewFS does not need “peek” to smuggle in open/trust/index semantics.


### 16. ViewFS watch/update surfaces should align with existing SlopOS background and status seams
Use:
- `background-request-state-posture-v0.md`
- `notification-request-state-posture-v0.md`
- `attention-durable-status-boundary-v0.md`
- `attrfs-posture-v0.md`
- `capshell-output-normal-form-v0.md`

Implication:
- watch registrations, live query refresh, and shell-visible update pulses should remain explicit background/status surfaces rather than ambient omniscient inventory;
- degraded states such as overflow/recrawl/rebuild should be transcript-visible and scoped to the bound view/query/workspace instead of hiding behind a fake “always fresh” story.


### 17. ViewFS link-like objects should align with SlopOS docref / reveal / safe-open seams instead of inventing a magical shortcut plane
Use:
- `document-handle-schema-v0.md`
- `openuri-showitem-exactness-boundary-v0.md`
- `openuri-portal-posture-v0.md`
- `import-to-docref-fresh-identity-boundary-v0.md`
- `open-untrusted-materialization-boundary-v0.md`

Implication:
- durable reopen references should look like SlopOS document references, not like hidden bearer aliases;
- reveal/launch shortcuts should stay routing objects, not become canonical object identity;
- any compat or shell-facing aliasing should respect resolve-once / exactness boundaries instead of quietly creating live alias/write-through semantics.


### 18. ViewFS should keep origin/quarantine/safe-open/trust transitions aligned with SlopOS instead of inventing a second trust model
Use:
- `rfcs/0053-origin-quarantine-and-safe-open.md`
- `open-untrusted-posture-v0.md`
- `quarantined-execution-boundary-v0.md`
- `quarantined-code-input-boundary-v0.md`
- `rfcs/0069-capability-diffs-for-consent-and-receipts.md`

Implication:
- origin evidence, quarantine state, safe-open lanes, and explicit clear/trust decisions should stay distinct in ViewFS just as SlopOS is already trying to keep them distinct;
- shell recents, palettes, workspace binds, and preview panes should preserve those states rather than laundering them into a generic open bit;
- broad trusted-path or trusted-workspace shortcuts should be treated as design debt, not as the primary model.


### 19. ViewFS delete/trash/recovery/retention flows should stay on explicit receipt and status seams
Use:
- `document-handle-schema-v0.md`
- `acp-outcome-receipt-schema-v0.md`
- `background-request-state-posture-v0.md`
- `attention-durable-status-boundary-v0.md`
- `explain-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- removing a name from a view, moving something to a recoverable trash, retaining it because of an explicit root, and actually purging collectible storage should stay classed as different actions;
- SlopOS already has enough seams for receipts, durable status, background operations, and explain surfaces that ViewFS does not need one magical `delete` primitive;
- shell recovery UX should render restore plans, root explanations, and purge previews as explicit receipts/status cards rather than as hidden path folklore.

### 20. ViewFS checkpoints/forks/publication should align with SlopOS snapshot, update, and activation seams instead of inventing one giant “history” plane
Use:
- `rfcs/0038-persistent-object-store-and-snapshots.md`
- `view-namespace-posture-v0.md`
- `disposable-domain-posture-v0.md`
- `init-snapshot-posture-v0.md`
- `activation-posture-v0.md`
- `update-posture-v0.md`
- `update-manifest-schema-v0.md`
- `boot-manifest-schema-v0.md`

Implication:
- a local checkpoint or view-scoped snapshot should stay different from a fresh disposable fork/worktree, a replicated/exported stream, and a promoted deployable artifact;
- SlopOS already distinguishes snapshot acceleration, activation choice, and update/deploy artifacts well enough that ViewFS does not need one magical “snapshot = backup = release = rollback” primitive;
- shell time-travel UX should preserve those class differences instead of flattening them into a vague history browser.


### 18. ViewFS concurrent-write coordination should align with SlopOS conflict-key and lease boundaries
Use:
- `conflict-key-schema-v0.md`
- `conflict-key-family-registry.md`
- `lease-descriptor-state-boundary-v0.md`
- `capability-lease-posture-v0.md`
- `acp-outcome-receipt-schema-v0.md`
- `commutativity-and-interface-scalability.md`

Implication:
- ViewFS should avoid inventing one monolithic `lock` primitive when SlopOS already distinguishes conflict scope, bounded lease descriptors, receipts, and commutativity reasoning;
- optimistic write guards, short reservations, and conflict receipts should stay visibly different seams;
- any future takeover/override path should be transcript-visible and should not let a lease token or receipt masquerade as general write authority.


### 20. ViewFS should keep query manifests, result snapshots, and live feeds aligned with D-ATTRFS
Use:
- `attrfs-posture-v0.md`
- `attribute-query-schema-v0.md`
- `openuri-recent-items-boundary-v0.md`
- `capshell-output-normal-form-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already wants saved queries to stay shell-owned manifests and live-query behavior to stay optional, bounded, and explicitly tied to a view; ViewFS should preserve that split instead of introducing one magical smart-folder object.
- Query recipes, frozen result sets, live feeds, and smart-folder UI pins should stay visibly distinct, so the shell can support freeze/thaw/diff/match-lens workflows without turning search surfaces into hidden authority or daemon ownership.


### 21. ViewFS import/export/transfer/share/promised-file lanes should align with SlopOS D-PLUMB and docref boundaries instead of becoming one giant “file operation”
Use:
- `document-portal-posture-v0.md`
- `transfer-portal-posture-v0.md`
- `import-to-docref-fresh-identity-boundary-v0.md`
- `intent-kind-registry.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0094-transfer-portal-and-typed-payload-leases.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- ViewFS should keep **import/copy-in**, **open-in-place**, **save/export**, **move/rehome**, **transfer**, **share/delegate**, and **promised-file materialization** on distinct seams rather than flattening them into generic path copy/open verbs;
- SlopOS already distinguishes manual document workflows, one-shot transfer workflows, fresh-identity import boundaries, and non-authoritative intent kinds, so ViewFS can preserve honest lane-specific receipts without inventing a second security model;
- shell drag/drop, paste, export, and notebook/file-promise UX should stay typed and transcript-visible instead of quietly laundering transfer offers into durable authority or broad directory rights.


### 22. ViewFS pins/caches/prefetch/hydration should align with SlopOS artifact-resolution and safe-open materialization seams
Use:
- `artifact-resolution-posture-v0.md`
- `open-untrusted-materialization-boundary-v0.md`
- `openuri-materialization-boundary-v0.md`
- `capshell-code-closure-posture-v0.md`
- `attestation-endorsement-boundary-v0.md`
- `cache-topology-authority-boundary-v0.md`

Implication:
- SlopOS already separates locator hints from actual artifact bytes and keeps safe-open materialization request-local instead of a live alias; ViewFS should preserve the same split when talking about prefetch, cache warmth, and hydration.
- Prefetch or mirror metadata should stay advisory/transport-like rather than turning into authority or publication semantics, just as SlopOS keeps cache-topology facts and replicated metadata from quietly widening authority.
- Offline bundles, hydrated closures, cached objects, and retained pins should remain visibly different classes, so the shell can explain `hint-only`, `cached`, `hydrated`, `pinned`, `mirrored`, or `offline-bundled` truthfully instead of collapsing everything into a hidden download cache.


### 23. ViewFS should keep bundles, view fragments, live binds, and launch kits aligned with SlopOS view mutations and capshell exec packs
Use:
- `view-namespace-posture-v0.md`
- `rfcs/0032-view-namespace-semantics-v1.md`
- `capshell-handle-table-posture-v0.md`
- `capshell-exec-pack-schema-v2.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `document-portal-posture-v0.md`

Implication:
- SlopOS already distinguishes view mutation from child exec-pack construction, so ViewFS should not collapse a reusable bundle, a namespace fragment, a live bind, and a launch assembly into one object.
- A child namespace should stay creator-populated and transcript-visible; children should not widen their own visible roots by reinterpretation or helper folklore.
- Shell launch rehearsals, kit cards, and rebind flows should therefore explain how existing binds, fragments, receipts, and last-mile attenuation contributed to the child launch kit instead of pretending the current pane state is automatically the child state.


### 24. ViewFS should keep intents, plans, approvals, and results aligned with SlopOS action/explain seams
Use:
- `intent-kind-registry.md`
- `approval-basis-posture-v0.md`
- `acp-precondition-witness-posture-v0.md`
- `explain-posture-v0.md`
- `acp-outcome-receipt-schema-v0.md`
- `denial-receipt-schema-v0.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`

Implication:
- SlopOS already distinguishes non-authoritative intent kinds, exact action-basis approval, explanation/diff surfaces, denial receipts, and outcome receipts, so ViewFS should not flatten those into one magical shell action.
- A prepared route/action plan should stay separate from both the user intent that motivated it and the receipt/history that survives after it runs.
- Approval should bind one exact plan/action digest rather than a floating mutable target, and replay should begin from fresh planning against current state instead of pretending old outcome receipts are live authority.


### 25. ViewFS should keep suggested automation, promoted workflows, and run history aligned with SlopOS workflow-plumbing and capshell seams
Use:
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `approval-basis-posture-v0.md`
- `capshell-learnmode-posture-v0.md`

Implication:
- SlopOS already distinguishes non-authoritative workflow intents/messages, exact action-basis approval, and transcript-visible run outcomes, so ViewFS should not flatten workspace-suggested recipes, promoted user workflows, prepared run plans, and receipts into one saved-command object.
- A suggestion should remain inspectable and provenance-rich before it becomes a user-owned workflow, and promotion should be a visible copy/adopt act rather than silent inheritance.
- Replaying or reusing a workflow should begin from fresh planning against current state and current trust posture instead of treating a past successful run as current standing authority.


### 26. ViewFS borrowed-authority seams should align with SlopOS lease, portal, and capshell boundaries
Use:
- `capability-lease-posture-v0.md`
- `lease-descriptor-state-boundary-v0.md`
- `document-portal-posture-v0.md`
- `approval-basis-posture-v0.md`
- `capshell-handle-table-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already distinguishes bounded lease state, exact child handle tables, portal-mediated issuance, and transcript-visible approval/outcome surfaces, so ViewFS should not flatten lend requests, live borrowed handles, durable delegated refs, issuer recall power, and loan-end receipts into one shared-handle story.
- Temporary cross-pane or child-launch sharing should default to bounded borrowed authority rather than silently durable persistence, matching SlopOS’s general portal/lease posture.
- Shell UX should make `lend for this run`, renewal, promotion to durable reopen, and recall/expiry outcomes visibly distinct instead of letting one successful open/run mutate into standing ambient access.


### 27. ViewFS replay and renewal seams should align with SlopOS exact-basis approval posture
Use:
- `approval-basis-posture-v0.md`
- `acp-precondition-witness-posture-v0.md`
- `document-portal-posture-v0.md`
- `capability-lease-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`

Implication:
- SlopOS already rejects sticky mutable-basis approvals, so ViewFS should not let old receipts, reopen refs, or successful runs silently follow a newer head/revision/provider state.
- Reuse should begin from an exact recorded basis plus a current drift check, and any risky renewal should route through fresh reconsent rather than pretending history is current live authority.
- Shell UX should make `reuse exact`, `reuse narrowed`, `fresh chooser`, `fresh lend`, `fresh temp view`, and `receipt only` visibly distinct instead of letting “rerun” hide basis drift and approval reuse.

### 20. ViewFS witness material and explanations should align with SlopOS approval-basis / precondition-witness / receipt seams
Use:
- `approval-basis-posture-v0.md`
- `acp-precondition-witness-posture-v0.md`
- `acp-denial-precedence-posture-v0.md`
- `consent-receipt-schema-v0.md`
- `denial-receipt-schema-v0.md`

Implication:
- exact basis material, narrowing caveats, freshness/consistency witnesses, current why-records, and durable receipts should stay visibly distinct;
- ViewFS should borrow SlopOS’s exact local witness discipline rather than inventing a fuzzy “latest approved basis” plane;
- explanation artifacts should stay transcript-valuable without becoming hidden authority caches.

### 20. ViewFS policy-aware shelling should align with SlopOS approval-basis and explain seams instead of inventing a softer helper plane
Use:
- `approval-basis-posture-v0.md`
- `explain-posture-v0.md`
- `auth-mediation-boundary-index.md`

Implication:
- schema/validation material, authoritative policy/caveat material, shell advice/ranking, per-decision diagnostics, and durable logs/receipts should stay visibly distinct.
- a shell suggestion, palette repair hint, or replay recommendation should not count as policy truth by itself.
- historical audit/debug records should remain explanation artifacts rather than standing authorization or sticky approval caches.


### 30. ViewFS policy-family selection and fallback UX should align with SlopOS explicit policy-selection boundaries
Use:
- `verification-policy-selection-boundary-v0.md`
- `approval-basis-posture-v0.md`
- `explain-posture-v0.md`
- `auth-mediation-boundary-index.md`

Implication:
- SlopOS already insists that evidence and requests do not choose their own judge, so ViewFS should keep policy-family/catalog choice, exact authoritative cuts, fallback candidates, repair proposals, and durable selection receipts visibly distinct.
- A shell cut picker or repair prompt may be delightful, but it should remain an explicit local selection surface rather than a hidden auto-switch or artifact-driven policy lookup.
- Historical selection receipts should stay transcript-useful without silently reselecting a newer family/cut for current work.


### 17. ViewFS should keep proposal sources, escalation lanes, and authoritative adoption on distinct SlopOS seams
Use:
- `verification-policy-selection-boundary-v0.md`
- `approval-basis-posture-v0.md`
- `authagent-provider-role-boundary-v0.md`
- `explain-posture-v0.md`

Implication:
- workspace/profile/history/helper proposals should remain typed suggestion surfaces instead of hidden policy selection or standing automation truth;
- a shell proposal surface may help gather review or escalate, but it should stay role-distinct from the authoritative adoption act itself;
- durable receipts should explain who proposed, who adopted, and at what scope instead of laundering those differences away.


### 32. ViewFS deny ceilings and scope eligibility should align with SlopOS veto-only policy and deny-code seams
Use:
- `rfcs/0028-veto-only-policy-bundles-for-automation.md`
- `deny-code-registry.md`
- `verification-policy-selection-boundary-v0.md`
- `authagent-provider-role-boundary-v0.md`
- `uicap-scope-posture-v0.md`

Implication:
- SlopOS already treats veto-style policy and stable deny surfaces as real seams, so ViewFS should keep deny ceilings and scope-eligibility rules authoritative and distinct from shell ranking or helper folklore.
- A shell narrowing preview may suggest `once`, `session`, `read-only`, or `receipt only`, but it should not act like a hidden authority override or a silent scope widen.
- Some proposal origins or product shapes may be categorically non-widenable without stronger trust or a different authority lane, and receipts should record both requested scope and effective narrowed scope instead of laundering that difference away.


### 35. ViewFS protected-authorability and invoke-only lanes should align with SlopOS veto-only policy and role-boundary seams
Use:
- `rfcs/0028-veto-only-policy-bundles-for-automation.md`
- `approval-basis-posture-v0.md`
- `verification-policy-selection-boundary-v0.md`
- `authagent-provider-role-boundary-v0.md`
- `uicap-scope-posture-v0.md`

Implication:
- SlopOS already points toward exact current judges and veto-only policy bundles, so ViewFS should keep protected-authorable state classes distinct from lower-trust helper material that is only invokeable or adoptable after review.
- A workspace, parent-repo, plugin, or receipt lane may still be very useful without being allowed to author always-on or protected state.
- Shell UX should make `invoke once`, `adopt after review`, `withheld by protected scope`, and `forbidden from authoring` visibly distinct instead of laundering them into a single inactive bit.



### 36. ViewFS helper lifecycle seams should align with SlopOS powerbox, capshell, and role-boundary posture
Use:
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `docs/30-architecture/authagent-provider-role-boundary-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `docs/30-architecture/capshell-startup-profile-posture-v0.md`
- `docs/30-architecture/powerbox-posture-v0.md`

Implication:
- SlopOS already keeps startup authority explicit-only and refuses generic approval inventories, so ViewFS should keep publisher trust, installed helper packages, configured definitions, enablement, start approvals, live sessions, and request-scoped selections as different classes.
- A trusted publisher or installed helper may still be useful without meaning the helper is live now or selected for the current action.
- Shell UX should make `installed`, `enabled`, `approved to start`, `live now`, `selected for this request`, and `history only` visibly distinct instead of laundering them into one “available” bit.


### 37. ViewFS helper feature catalogs should align with SlopOS capshell, plumb, and mediator seams
Use:
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `docs/30-architecture/authagent-provider-role-boundary-v0.md`
- `docs/30-architecture/powerbox-posture-v0.md`

Implication:
- SlopOS already treats workflow glue, request envelopes, and mediated issuance as different seams, so ViewFS should keep resource descriptors, prompt templates, tool descriptors, app surfaces, completion suggestions, request bindings, live invocations, and durable receipts visibly distinct.
- A live helper catalog may still be extremely useful without meaning every visible feature is attached, approved, or safe to replay now.
- Shell UX should make `browse resource`, `fill prompt arg`, `enable tool for this request`, `launch app surface`, `invoke now`, and `history only` visibly distinct instead of laundering them into one generic helper item.

## Deferred work and exact completion posture
- SlopOS already keeps mediated request/response and effect-completion language narrow in `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`, `rfcs/0115-capability-safe-shell-and-automation.md`, and `rfcs/0117-plumb-messages-and-cli-intents.md`.
- ViewFS should align with that by keeping immediate requests, accepted task wrappers, live progress/status, input-required checkpoints, deferred final results, and durable receipts as separate seams rather than inventing one magical job object.
- That preserves transcript honesty: “accepted”, “still running”, “needs input”, and “final result retrieved” stay different truths.


### 39. ViewFS deferred control should align with SlopOS acceptance/completion, background-state, and attention seams
Use:
- `acp-acceptance-completion-posture-v0.md`
- `background-request-state-posture-v0.md`
- `background-lease-posture-v0.md`
- `attention-durable-status-boundary-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`

Implication:
- SlopOS already keeps acceptance, completion, durable status, and active attention on different seams, so ViewFS should keep close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipts visibly distinct.
- A shell should be able to say “stopped watching”, “requested cancel”, “confirmed cancelled”, “force terminated”, and “forked from prior basis” as different truths instead of one vague stop result.
- Deferred control should stay transcript-valuable without letting local cleanup, result expiry, or helper-specific stop verbs masquerade as current remote state.


### 40. ViewFS live-session lanes should align with SlopOS capshell, caprpc, and attention seams
Use:
- `capshell-job-control-posture-v0.md`
- `capshell-local-ipc-posture-v0.md`
- `caprpc-session-posture-v0.md`
- `attention-durable-status-boundary-v0.md`
- `background-request-state-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`

Implication:
- SlopOS already keeps live sessions, control channels, durable status, and execution requests on different seams, so ViewFS should keep observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnels, and durable transcripts visibly distinct.
- A shell should be able to say `observed only`, `attached read-only`, `attached interactive`, `sent control`, `spawned debug exec`, and `opened sideband tunnel` as different truths instead of one generic connected-session result.
- Transcript history should stay replay-valuable without masquerading as a still-live control handle or session continuation token.


### 41. ViewFS startup delivery should align with SlopOS explicit launch assembly and handle-table seams
Use:
- `capshell-exec-pack-schema-v2.md`
- `capshell-handle-table-posture-v0.md`
- `capshell-cwd-root-posture-v0.md`
- `capshell-startup-profile-posture-v0.md`

Implication:
- SlopOS already treats launch assembly and handle-table population as explicit authored acts, so ViewFS should keep activation slots, live handle copies, issuer-visible badge/lineage tags, immutable object refs, and transcript receipts visibly distinct.
- A child may receive already-open resources at startup, but the carrier name/slot should not masquerade as a durable path, stable identity, or future rediscovery promise.
- Shell UX should make `activation slot`, `live now`, `issuer-badged copy`, `object ref`, and `receipt only` visibly distinct instead of laundering them into one generic open story.


### 42. ViewFS courier provenance and structured command packets should align with SlopOS handle-table, local-IPC, and plumb seams
Use:
- `capshell-handle-table-posture-v0.md`
- `capshell-local-ipc-posture-v0.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `explain-posture-v0.md`

Implication:
- SlopOS already treats handle assembly, local IPC, and plumb/routing messages as explicit typed lanes, so ViewFS should keep peer/courier witness, transferred live handle, structured command packet, plain transcript text, and durable receipt visibly distinct.
- A command/result packet may be extremely useful for helper escalation, review, or route sheets, but it should be an explicit promoted object rather than whatever text happened to be highlighted in the terminal.
- Shell UX should make `peer witness`, `live transferred handle`, `command packet`, `receipt only`, and `plain transcript` visibly distinct instead of laundering them into one generic open/replay story.


### 43. ViewFS running-command objects should align with SlopOS exec-pack, job-control, and peer-inspection seams
Use:
- `capshell-exec-pack-schema-v2.md`
- `capshell-job-control-posture-v0.md`
- `capshell-peer-inspection-posture-v0.md`
- `capshell-handle-table-posture-v0.md`
- `capshell-local-ipc-posture-v0.md`

Implication:
- SlopOS already distinguishes exact launch packs, shell/job-control posture, peer-inspection posture, and explicit handle-table population, so ViewFS should keep promoted command packets, live process handles, lifecycle-control rights, deeper inspect/debug powers, and durable transcript/history visibly distinct.
- A running command card may be extremely useful, but it should not silently imply debugger attachability, namespace-follow power, or another process's fd duplication just because it names the same current child.
- Shell UX should make `command packet`, `running now`, `wait/stop allowed`, `deep inspect available`, and `history only` visibly distinct instead of laundering them into one generic process row.

### 44. ViewFS exact-launch meaning should align with SlopOS exec-object, script-entry, argv/env, and app-secret seams
Use:
- `capshell-exec-object-posture-v0.md`
- `capshell-script-entry-posture-v0.md`
- `capshell-argv0-posture-v0.md`
- `capshell-env-baseline-posture-v0.md`
- `capshell-env-startup-posture-v0.md`
- `app-secret-posture-v0.md`
- `appsecret-secret-ingress-boundary-v0.md`

Implication:
- SlopOS already treats exact executable-object binding, script/interpreter entry, argv/env shaping, and app-secret ingress as different authored seams, so ViewFS should keep exec objects, script input, argv/env basis, startup credential slots, and launch/history artifacts visibly distinct.
- A reviewed launch target should not be reopened through ambient PATH, mutable document names, or helper folklore at the last minute just because the host runtime makes that convenient.
- Startup credentials should remain a narrower activation-time lane than environment variables, ordinary namespace binds, or durable reopen; shell UX should make `exec object`, `script input`, `argv/env basis`, `credential slot`, `launch receipt`, and `history only` visibly distinct instead of laundering them into one generic run action.


### 45. ViewFS startup code closure should align with SlopOS code-closure, startup-profile, and late-import boundaries
Use:
- `capshell-code-closure-posture-v0.md`
- `capshell-startup-profile-posture-v0.md`
- `capshell-env-baseline-posture-v0.md`
- `capshell-local-ipc-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already treats exact executable-object binding, startup native-code closure, startup profile/env posture, and later helper/import lanes as different authored seams, so ViewFS should keep exec objects, startup code closure, loader policy/search posture, late plugin/import requests, and launch/history artifacts visibly distinct.
- One reviewed executable object should not quietly expand into `whatever shared libraries, DLLs, modules, or plugins the host later found by current-directory, PATH, LD_LIBRARY_PATH, DLL search order, or other ambient search folklore`.
- Shell UX should make `exec exact`, `startup closure exact`, `loader debt`, `late import lane`, `launch receipt`, and `history only` visibly distinct instead of laundering them into one generic run story.


### 46. ViewFS clipboard/selection lanes should align with SlopOS transfer-portal and document-portal seams
Use:
- `rfcs/0094-transfer-portal-and-typed-payload-leases.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`

Implication:
- SlopOS already keeps typed transfer payload leases and durable document handles on different seams, so ViewFS should keep current selection owner/source, offered representations, accepted transfer payloads, pasted prompt input, imported objects, and durable reopen artifacts visibly distinct.
- `copy` or `offer` should not quietly become a durable grant, and `paste` should not quietly become an imported object or live bind just because the payload looked like a path.
- Shell UX should make `owner/source`, `offer`, `accepted representation`, `pasted into prompt`, `imported locally`, and `receipt/history only` visibly distinct instead of laundering them into one generic clipboard/open story.


### 46b. ViewFS clipboard-manager ghosts and paste capsules should stay separate from current offers and local imports
Use:
- `rfcs/0094-transfer-portal-and-typed-payload-leases.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0046-workflow-plumbing-and-portals.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already keeps transfer sessions, document handles, and shell input on distinct seams, so ViewFS should keep current selection/source, current transfer offer, manager-retained history ghost, prompt-local paste capsule, materialized local import/adopted bind, and durable receipt visibly distinct.
- A clipboard manager or history helper may retain a ghost of an old offer, but that does not mean the old source is still live or that this pane currently holds one imported object.
- Shell UX should make `offer now`, `history ghost`, `prompt bytes only`, `materialized locally`, `adopted here`, and `receipt only` visibly distinct instead of laundering them into one flattering clipboard/open story.


### 47. ViewFS foreground-shell truth should align with SlopOS job-control, exec-pack, and local-IPC seams
Use:
- `capshell-job-control-posture-v0.md`
- `capshell-exec-pack-schema-v2.md`
- `capshell-local-ipc-posture-v0.md`
- `capshell-peer-inspection-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already treats exec-pack identity, job-control posture, and local control/inspection lanes as authored seams, so ViewFS should keep live process handles, terminal stream lanes, controlling-terminal posture, current foreground turns, and durable history visibly distinct.
- A pane can be showing output from one running command without currently owning the controlling TTY or the interrupt baton, and a foreground turn can change without changing the underlying process identity.
- Shell UX should make `running now`, `stdout mirrored`, `stdin live`, `controlling tty`, `foreground now`, `backgrounded`, and `history only` visibly distinct instead of laundering them into one generic attached terminal story.


### 48. ViewFS launch hosting should align with SlopOS exec-pack, startup-profile, and live-session seams
Use:
- `capshell-exec-pack-schema-v2.md`
- `capshell-exec-object-posture-v0.md`
- `capshell-startup-profile-posture-v0.md`
- `capshell-command-string-posture-v0.md`
- `capshell-job-control-posture-v0.md`
- `capshell-launcher-lifetime-posture-v0.md`

Implication:
- SlopOS already treats exact exec-pack identity, startup-profile posture, and resulting live-session objects as authored seams, so ViewFS should keep exec objects, runner/runtime choice, bootstrap posture, live sessions, and durable history visibly distinct.
- An interactive command, a detached helper, and a receipt-only history row should not silently collapse together just because they came from one launch review.
- Shell UX should make `exec exact`, `runner kind`, `bootstrap clean/debt`, `interactive live`, `detached helper`, and `history only` visibly distinct instead of laundering them into one generic run story.


### 49. ViewFS handle topology should align with SlopOS handle-table and fdset seams
Use:
- `capshell-handle-table-posture-v0.md`
- `fdset-schema-v0.md`
- `capshell-exec-pack-schema-v2.md`
- `capshell-local-ipc-posture-v0.md`
- `rfcs/0081-activation-handoff-and-handle-stores.md`

Implication:
- SlopOS already insists that child handle tables are populated **exactly** rather than by ambient inheritance, but that still does not decide whether two reviewed bindings are independent reopens or aliases of one live open-state/cursor/lock group.
- ViewFS should therefore keep slot/local binding, live handle copy, shared open state, fresh reopen, and durable history visibly distinct.
- Shell UX should make `slot only`, `same live cursor`, `shared lock/lease`, `fresh reopen`, and `history only` visibly distinct instead of laundering them into one generic handle row.

### 50. ViewFS handle classes should align with SlopOS cwd-root, handle-table, and fdset seams
Use:
- `capshell-cwd-root-posture-v0.md`
- `capshell-handle-table-posture-v0.md`
- `fdset-schema-v0.md`
- `capshell-local-ipc-posture-v0.md`
- `rfcs/0081-activation-handoff-and-handle-stores.md`

Implication:
- SlopOS already insists that child roots and handle tables are populated **exactly** rather than by ambient host fallback, but that still does not decide whether one reviewed binding is only a locator/root handle or already a live byte-I/O handle.
- ViewFS should therefore keep locator/metadata handles, live byte-I/O handles, explicit reopen/escalation acts, and durable history visibly distinct.
- Shell UX should make `locate`, `walk`, `metadata`, `read now`, `write now`, `needs reopen`, and `history only` visibly distinct instead of laundering them into one generic open story.

### 51. ViewFS launch inheritance should align with SlopOS activation, exec-pack, and handle-table seams
Use:
- `activation-posture-v0.md`
- `capshell-exec-pack-schema-v2.md`
- `capshell-handle-table-posture-v0.md`
- `capshell-pipeline-posture-v0.md`
- `fdset-schema-v0.md`

Implication:
- SlopOS already insists that launch delivery is explicit and that child descriptor/handle state is exact CH-STDIO + CH-FDSET rather than ambient parent-process inheritance, but that still does not decide whether a handle currently held in one pane/process is eligible to cross one reviewed launch boundary.
- ViewFS should therefore keep current handle possession, launch-boundary inheritance posture, exact child-slot delivery, and durable launch history visibly distinct.
- Shell UX should make `held here`, `launch-shuttered`, `selected for child slot`, `child received`, and `history only` visibly distinct instead of laundering them into one generic inherited handle story.

### 52. ViewFS namespace mutation should align with SlopOS exact roots, docrefs, and handle-table seams
Use:
- `capshell-cwd-root-posture-v0.md`
- `capshell-handle-table-posture-v0.md`
- `document-portal-posture-v0.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0065-orthogonal-persistence-and-capstore.md`

Implication:
- SlopOS already treats roots, docrefs, and child handle tables as explicit authored seams, but that still does not decide whether a reviewed `move` or `rename` is acting on the object itself, the source parent namespace anchor, the destination parent namespace anchor, or only a durable receipt about a past namespace edit.
- ViewFS should therefore keep object identity, source parent anchor, destination parent anchor, namespace-mutation act, and durable mutation history visibly distinct.
- Shell UX should make `same object`, `source parent`, `destination parent`, `create new only`, `replace target`, `exchange`, and `history only` visibly distinct instead of laundering them into one generic move/open story.


### 53. ViewFS bind propagation should align with SlopOS explicit view and replication seams
Use:
- `view-namespace-posture-v0.md`
- `view-replication-boundary-v0.md`
- `capshell-cwd-root-posture-v0.md`
- `capshell-handle-table-posture-v0.md`

Implication:
- SlopOS already treats active view bindings as explicit local namespace state and treats replicated view information as read-only, non-activating metadata, but that still does not decide whether one current bind is `local only`, `shared to peers`, `receive from upstream only`, or `not cloneable`.
- ViewFS should therefore keep live binds, propagation posture, peer/upstream relationships, and durable history visibly distinct instead of laundering them into one generic bound-root story.
- Shell UX should make `attached here`, `local only`, `shared to peers`, `receives upstream`, `not cloneable`, and `history only` visibly distinct instead of pretending every current bind has the same blast radius.


### 54. ViewFS object descriptors should align with SlopOS artifact refs, document handles, and CapStore seams
Use:
- `artifact-reference-schema-v0.md`
- `rfcs/0030-artifact-references-and-content-addressed-evidence.md`
- `document-portal-posture-v0.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0065-orthogonal-persistence-and-capstore.md`

Implication:
- SlopOS already leans toward digest-authoritative references with locator hints and keeps document handles on a different seam, but that still does not decide whether one reviewed object reference is only a descriptor, already backed by local bytes, currently bound into one namespace, or only remembered in history.
- ViewFS should therefore keep content descriptors, descriptor hints, live handles/binds, and durable receipts visibly distinct.
- Shell UX should make `descriptor only`, `local bytes present`, `live handle now`, `published here`, and `history only` visibly distinct instead of laundering them into one generic file/object row.


### 55. ViewFS import localization should align with SlopOS document-portal and import-to-docref seams
Use:
- `document-portal-posture-v0.md`
- `powerbox-posture-v0.md`
- `import-to-docref-boundary-v0.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `artifact-reference-schema-v0.md`

Implication:
- SlopOS already insists that durable document-style reopen should begin only after an explicit materialization boundary has created a fresh local object and provider-local docref, but that still does not decide whether ViewFS imports always copy immediately, fetch lazily, publish into one namespace, or mint one live handle on the same turn.
- ViewFS should therefore keep imported source refs, explicit materialization acts, fresh local objects, local docrefs, live handles/binds, and durable receipts visibly distinct.
- Shell UX should make `source ref`, `materializing`, `local object`, `local docref`, `bound here`, and `history only` visibly distinct instead of laundering them into one generic imported-file story.


## 1s. Remembered reopen and exact restart continuity should stay narrower than live authority
Another especially useful seam is **remembered designator versus explicit revalidation versus exact continuity locker versus revived live handle versus durable receipt/history**.

The best lesson here is not “copy Apple bookmarks” or “turn CapStore on by default.”
It is the smaller observation that a system can:
- remember one designator for possible future reopen,
- separately revalidate or resolve that designator later,
- separately preserve one already-live handle across a narrow restart boundary,
- separately mint or revive one current live handle only when authority is needed now,
- and separately record stale / moved / revoked outcomes in history.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right **optional durable profile**, **inbound-only activation continuity**, and **non-bearer document-handle** instincts in `rfcs/0065-orthogonal-persistence-and-capstore.md`, `rfcs/0081-activation-handoff-and-handle-stores.md`, and `rfcs/0089-document-portal-and-durable-file-handles.md`, but those seams do **not** by themselves settle whether ViewFS should expose remembered designators in Phase 1, support exact continuity lockers broadly, or treat restart continuity as general persistent authority.

What to steal:
- keep `remembered`, `revalidating`, `exact locker available`, `revived live handle`, `stale`, and `history only` visibly distinct;
- treat exact continuity lockers as a narrow optional lane, not proof that general durable authority graphs are a good default;
- make receipts explicit about whether they recorded remember, resolve, revive, fail, or drop acts;
- let shell chrome say `needs revalidate` or `grant needed` instead of laundering every failure into path-not-found folklore.

What not to freeze yet:
- whether ViewFS Phase 1 has any user-visible remembered designator objects;
- whether exact continuity lockers are manager-owned, provider-owned, or absent;
- whether remembered designators ever point at more than local docref-like objects in early phases;
- whether future persistent profiles look anything like SlopOS CapStore at all;
- any assumption that remembered designation should silently revive current authority.



### 56. ViewFS transfer adoption should align with SlopOS capshell pipeline, CAPX, and import-to-docref seams
Use:
- `capshell-pipeline-posture-v0.md`
- `capshell-handle-table-posture-v0.md`
- `capx-posture-v0.md`
- `import-to-docref-boundary-v0.md`
- `activation-posture-v0.md`

Implication:
- SlopOS already treats peer-stage raw-handle passing as suspicious, keeps remote delegation import explicit, and keeps routine document-style reopen on a fresh-local-object/provider-local-docref seam, but that still does not decide whether ViewFS should show a transfer offer, a live copied handle, a stored revival designator, or a current local adopted bind as the same user-visible class.
- ViewFS should therefore keep transfer/courier offers, accepted representation choice, live copied or attenuated handles, later revival designators, receiver-local adopted binds, and durable receipts visibly distinct.
- Shell UX should make `offer only`, `accepted as bytes`, `live copy`, `attenuated copy`, `stored designator`, `adopted here`, and `history only` visibly distinct instead of laundering them into one generic shared/opened story.


## 1t. Explicit handoff and local adoption should stay narrower than durable authority
Another especially useful seam is **transfer offer versus live copied authority versus revival designator versus receiver-local adoption versus durable receipt/history**.

The best lesson here is not “copy UNIX sockets” or “make every share a sturdy capability.”
It is the smaller observation that a system can:
- surface an offer/courier event,
- explicitly choose a representation or handoff mode,
- transport one live copied or attenuated handle when policy allows,
- separately store a later revival designator,
- separately adopt something into the receiver's local namespace/view only when needed,
- and separately record history about all of that.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right **no-hidden-peer-handoff**, **explicit delegation-import**, **fresh-local-object-first**, and **continuity-is-narrow** instincts in `capshell-pipeline-posture-v0.md`, `capx-posture-v0.md`, `import-to-docref-boundary-v0.md`, and `activation-posture-v0.md`, but those seams do **not** by themselves settle whether ViewFS should expose live handoff, durable revival designators, cross-pane adoption, or byte-only transfer as a default in Phase 1.

What to steal:
- keep `offer only`, `representation chosen`, `live copy`, `attenuated copy`, `stored for later`, `adopted here`, and `history only` visibly distinct;
- make issuer/courier witness visible without laundering it into object identity or current authority;
- treat receiver-local adoption/binding as a separate step rather than a side effect of delivery;
- keep exact continuity and durable revival narrower than ordinary sharing folklore.

What not to freeze yet:
- whether ViewFS Phase 1 supports live cross-pane/process handle copying;
- whether stored revival designators ever cross machine/user boundaries;
- whether adoption happens in the shell, provider, launcher, or another broker;
- whether every transfer-capable handle family also supports durable revival;
- any assumption that `shared once` should silently imply `reopen forever`.

### 12. ViewFS should keep designation-only labels, authority-bearing tickets, local aliases, and live handles on distinct seams
Use:
- `rfcs/0065-orthogonal-persistence-and-capstore.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0116-capability-wallets.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`

Implication:
- SlopOS already has enough draft surface to avoid one overloaded “bookmark/open token” class;
- wallet descriptors are explicitly non-authoritative, plumb envelopes are request/intent carriers, document handles are mediator-shaped, and optional CapStore/sturdyref persistence stays powerful enough to remain explicit;
- ViewFS should therefore keep note-friendly designators, authority-bearing tickets, local aliases/binds, current live handles, and durable receipts visibly separate;
- shell UX should never need to guess whether a pasted token is inert designation, a revival ticket, or a current live bind.


### 13. ViewFS should keep caveat sets, membrane leases, live handles, and receipts on distinct seams
Use:
- `capability-lease-posture-v0.md`
- `capability-lease-schema-v0.md`
- `capability-export-schema-v0.md`
- `capability-semantics.md`
- `capx-posture-v0.md`

Implication:
- SlopOS already has a valuable split between declared export/caveat material, proxy-first import, membrane-style lease enforcement, and transcript evidence;
- `D-LEASE` says the **lease proxy is the authority**, while `CH-CAPLEASE` is evidence and UX/audit material only;
- `CH-CAPX` explicitly avoids standardizing one portable caveat/policy VM in the core seam, which is a strong reminder not to freeze ViewFS export semantics too early;
- ViewFS should therefore keep caveat sets, current enforcement locus, live delegated handles, later revival designators, and durable receipts visibly separate;
- shell UX should be able to say `caveat declared`, `proxy enforced`, `live local handle`, `needs revalidation`, or `history only` without guessing.

What not to freeze yet:
- whether ViewFS attenuation is mostly proxy-shaped, token-shaped, or mixed in Phase 1;
- whether any authority-bearing export is ever user-copyable by default;
- whether expiry and revocation are verifier-side, proxy-side, issuer-side, or all of the above for every family;
- whether caveat-bearing delegated artifacts are local-only or portable across machines.

Caution from the past:
- caveat-bearing bearer artifacts are useful, but capability folklore shows that once the UI stops distinguishing declared constraints from actual enforcement, ordinary copy/paste, journaling, or notebook sharing starts becoming covert delegation.

### 14. ViewFS should keep permission outlooks, revival designators, live handles, and death-state verdicts on distinct seams
Use:
- `document-portal-posture-v0.md`
- `document-handle-schema-v0.md`
- `powerbox-posture-v0.md`
- `capability-lease-posture-v0.md`
- `namecert-time-boundary-v0.md`

Implication:
- SlopOS already has enough draft surface to avoid one overloaded `reopenable or not` bit: chooser/portal mediation, document-handle durability, capability-lease lifecycle, and admission-only freshness are already different seams;
- ViewFS should therefore keep preflight permission outlook (`granted`, `prompt`, `denied`, `revalidate needed`, `policy blocked`), revival designators, current live handles, explicit death-state verdicts, and durable receipts visibly distinct;
- shell UX should preserve reason-rich negative states such as `revoked`, `expired`, `target changed`, `issuer unavailable`, and `history only` instead of flattening them into one vague `stale` badge;
- repair should stay explicit: `request`, `revalidate`, `rebind`, or `import fresh` rather than magical reopen folklore.

## 1u. Permission outlook and dead-state truth should stay narrower than current authority
Another especially useful seam is **permission outlook versus current authority versus explicit death-state verdicts**.

The best lesson here is not “copy the browser permissions model” or “copy one portal revocation API.”
It is the smaller observation that a system can:
- show whether an action looks grantable or likely blocked,
- separately remember one designator that may help ask again later,
- separately hold one live handle now,
- separately explain when and why that lane died,
- and separately keep history about all of that.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right instincts in `document-portal-posture-v0.md`, `powerbox-posture-v0.md`, `capability-lease-posture-v0.md`, and `namecert-time-boundary-v0.md`: explicit mediation, no ambient remembered-grant oracle, explicit lease lifecycle, and admission-only freshness. Those seams do **not** by themselves settle whether ViewFS should expose a universal permission-state API or a universal revocation/tombstone object in Phase 1.

What to steal:
- keep `granted`, `prompt`, `denied`, `revalidate needed`, `live now`, `revoked`, `expired`, `target changed`, `issuer unavailable`, and `history only` visibly distinct;
- let reason-rich negative states drive repair ladders rather than vague reopen failures;
- keep current authority separate from preflight outlook and separate again from history;
- make shell chrome precise about whether the next honest step is `request`, `revalidate`, `rebind`, `import fresh`, or `none`.

What not to freeze yet:
- whether ViewFS exposes one universal permission-state vocabulary across all capability families;
- whether every dead-state verdict is durable/history-visible;
- whether the shell can subscribe to live permission-state changes in early phases;
- whether revival designators are always provider-local or sometimes portable.

### 15. ViewFS should keep provenance attestations, endorsement bundles, local admission verdicts, and live handles on distinct seams
Use:
- `attestation-endorsement-boundary-v0.md`
- `attestation-pack-schema-v0.md`
- `verification-verdict-boundary-v0.md`
- `document-portal-posture-v0.md`
- `rfcs/0065-orthogonal-persistence-and-capstore.md`

Implication:
- SlopOS already keeps actual evidence, endorsement/reference inputs, and verifier-local appraisal meaning separate instead of pretending one attester-exported bundle is the same thing as the verifier's final decision;
- ViewFS should therefore keep provenance/import/build/review claims, endorsement or trust-root bundles, local admit/deny verdicts, current live handles, and durable history visibly distinct;
- shell UX should make `described`, `endorsed`, `safe-open only`, `admit runnable`, `deny`, `live now`, and `history only` visibly distinct instead of laundering them into one generic trusted/open story.

## 1v. Provenance and endorsement should stay narrower than local admission and current authority
Another especially useful seam is **provenance claim versus endorsement input versus local admission verdict versus live handle versus durable receipt/history**.

The best lesson here is not “copy software supply-chain tooling” or “turn every object into an attested build.”
It is the smaller observation that a system can:
- preserve one claim about where bytes came from or how they were produced,
- separately preserve who is allowed to endorse what and under which trust roots or reference values,
- separately make one local verdict such as `preview only`, `safe-open only`, `admit runnable`, or `deny`,
- separately hold a live handle now,
- and separately keep history about all of that.

That is a perfect low-regret lesson for ViewFS because SlopOS already has the right instincts in `attestation-endorsement-boundary-v0.md`, `attestation-pack-schema-v0.md`, `verification-verdict-boundary-v0.md`, and `document-portal-posture-v0.md`: endorsement/reference material stays verifier-local, exporter-side evidence packaging stays bounded, verdict meaning stays local, and mediated open/import remains explicit. Those seams do **not** by themselves settle whether ViewFS should require attestations for every object, expose transparency-log witnesses in Phase 1, or standardize one universal admit/deny taxonomy.

What to steal:
- keep `claim only`, `endorsed input`, `admit preview`, `admit document`, `admit runnable`, `deny`, `live now`, and `history only` visibly distinct;
- keep threshold/delegation and trust-root choices inspectable rather than hidden in one green badge;
- let local admit/deny cards explain which claim and which endorsement stack mattered without treating them as current authority;
- keep guarded-open and runnable-open as different product states instead of one vague trust transition.

What not to freeze yet:
- whether Phase 1 requires provenance/attestation on every imported or built object;
- whether endorsement bundles are fetched, mirrored, user-chosen, or entirely local in early phases;
- whether transparency-log style witnesses appear in the transcript by default;
- whether ViewFS exposes one universal admit/deny vocabulary or several family-specific ones;
- any assumption that a signed claim or threshold endorsement automatically implies a live handle or namespace bind here.

## 1w. Request identity and portal-owned live state should stay narrower than local current authority

The current SlopOS drafts already show a strong instinct here. `background-request-state-posture-v0.md` keeps requester-chosen `req_id` separate from portal-owned current background/autostart grant state, and several portal/capshell surfaces keep receipt-like outcomes separate from current capability truth.

That is exactly the seam ViewFS should steal next.

### What to preserve
- **request identity** should mean one interaction submission or dedupe/review key.
- **session / transfer identity** should mean one longer-lived portal-owned interaction object.
- **portal-owned current state** should mean one current mediator-side truth such as `open`, `allowed`, `bound`, `active`, `ending`, or `closed`.
- **local adopted bind / live handle** should remain the current-authority truth for one pane/process.
- **history/receipt** should stay descriptive.

### Why this matters
If ViewFS collapses those classes:
- old request success will start masquerading as current permission or current authority,
- portal-owned state will start masquerading as one locally adopted bind,
- and repair UX will not be able to tell users whether they need to retry, rejoin, retrieve, or adopt.

### Shell consequence
The shell should be able to show `request only`, `session active`, `portal says closed`, `adopted here`, and `receipt only` as visibly different truth states.

### 16. ViewFS should keep completion candidates, accepted insertions, compiled command packets, and prepared actions on distinct seams
Use:
- `docs/30-architecture/mcp-completion-import-boundary-v0.md`
- `docs/30-architecture/mcp-prompt-import-boundary-v0.md`
- `docs/30-architecture/mcp-resource-import-boundary-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`

Implication:
- SlopOS already has the crucial instinct here: provider-local completion suggestions are not selector/default/workflow truth;
- ViewFS should sharpen that further inside the custom shell by keeping completion candidates, focused detail, accepted insertions, compiled pane-local command packets, prepared actions, and receipts visibly distinct;
- shell UX should never have to guess whether one row is only advice, already inserted into the mutable prompt, already bound against current pane objects, or actually ready to run.

What not to freeze yet:
- whether packet compilation is shell-owned, terminal-assisted, or helper-assisted in Phase 1;
- whether trusted packet grades are shell-native, nonce-mediated, or both;
- whether all accepted insertions are stored as first-class transcript artifacts.

### 17. ViewFS should keep selected transcript regions, extracted entities, and routed actions on distinct seams
Use:
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `capshell-output-normal-form-v0.md`

Implication:
- SlopOS already has the right instinct in its plumb/intents work: typed routing envelopes are their own class and must not become a side door for capability transfer.
- ViewFS should sharpen that shell-side by keeping selected regions, extracted entity candidates, resolved targets/details, route envelopes, prepared actions, and receipts visibly distinct.
- terminal hyperlinks, selection hints, and transcript clicks should not collapse into blind `open` or silent authority.

### 18. ViewFS should steal lazy link resolution, but only as an inspectable middle seam
Use:
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0094-transfer-portal-and-typed-payload-leases.md`

Implication:
- ViewFS can benefit from a middle seam where one highlighted span becomes one typed candidate and only later resolves into one routeable target, instead of pretending every selection already knows its final destination.
- this is a good fit for shell-native `inspect / reveal / import / compose packet` flows because it preserves optionality while keeping transcript clicks honest.

### 19. ViewFS should keep gesture evidence, activation batons, armed portal state, and active control on distinct seams
Use:
- `capture-portal-posture-v0.md`
- `capture-session-schema-v0.md`
- `attention-lease-posture-v0.md`
- `background-request-state-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already has the right instinct that transient attention, prepared request/session state, and durable consequence truth are different lanes;
- ViewFS should sharpen that further by keeping fresh interaction proof, transferable activation/focus batons, `armed` / `enabled` portal state, current active control, and durable receipts visibly distinct;
- shell UX should be able to say `fresh gesture`, `baton passed`, `armed`, `active now`, `foreground denied`, or `history only` instead of flattening those truths into one generic open/click story.

## 1w. Gesture proof and current active control are worth stealing, but only as narrow interaction seams
Another especially useful seam is **recent user-action proof versus activation baton versus active control**.

The best lesson here is not “copy browser user-activation APIs” or “copy desktop focus policy wholesale.”
It is the smaller observation that a system can:
- record one fresh interaction witness,
- pass a short-lived baton/token to another component,
- arm or enable one interaction lane,
- and still leave the final move into active control to the compositor/portal/runtime.

What to steal:
- keep fresh gesture proof visibly consumable/expiring rather than ambient;
- keep `enabled` / `armed` visibly weaker than `active now`;
- keep current active control visibly narrower than durable authority or durable reopen;
- make shell chrome precise about whether the next honest step is `consume baton`, `wait for activation`, `active now`, `focus refused`, or `none/history`.

What not to freeze yet:
- one universal baton schema for all ViewFS/SlopOS interactions;
- whether every portal/request family can receive the same activation witness shape;
- whether activation/focus transfer is shell-owned, portal-owned, compositor-owned, or mixed for every platform;
- whether gesture receipts persist by default.


### 20. ViewFS should keep object identity, current placement, handle rights, and advertised affordances on distinct seams
Use:
- `rfcs/0032-view-namespace-semantics-v1.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0010-ambient-authority-and-capability-mode.md`
- `rfcs/0065-orthogonal-persistence-and-capstore.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already has the right instinct that one object, one bind in one view, and one current capability should not silently collapse into one path-shaped truth;
- ViewFS should sharpen that further by keeping exact object identity, one current placement in one explicit view, one current handle-rights posture, advertised operations, and durable receipts visibly distinct;
- shell action menus should be driven by exact affordance truth rather than filename folklore or hidden resolver preferences.

What to steal:
- **place cards** so one pane can show `same object, different placement here/there` without pretending placement is identity;
- **verb ledgers** so one row can say `supported by provider`, `not with this handle`, `not valid at this placement`, or `history only`;
- **why-not drawers** so the shell explains whether the next missing step is `get a wider handle`, `switch placement`, `ask provider`, or `stop`.

What not to freeze yet:
- one universal affordance-discovery ABI for all providers;
- one final right-summary vocabulary;
- whether placements are parent/name pairs, alias objects, or higher-level bind records.


### 21. ViewFS should keep type claims, derived classifications, handler associations, chosen openers, and live open state on distinct seams
Use:
- `30-architecture/openuri-content-type-boundary-v0.md`
- `30-architecture/openuri-handler-selection-boundary-v0.md`
- `30-architecture/openuri-preview-metadata-boundary-v0.md`
- `30-architecture/open-untrusted-posture-v0.md`
- `rfcs/0094-transfer-portal-and-typed-payload-leases.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`

Implication:
- SlopOS already has the right instinct that generic URI launch should not become a portable content-type/sniffing seam and that concrete handler selection should stay shell-owned rather than requester-visible truth;
- ViewFS should sharpen that shell-side by keeping declared type hints, derived/computed type evidence, associated/default handlers, act-local chosen opener, live preview/editor state, and durable receipts visibly distinct;
- shell routing and open-with UX should be driven by explicit type/handler truth rather than suffix folklore or stale opener history.

What to steal:
- **type lenses** so the shell can show `declared`, `derived`, `virtual representation`, and `disagrees` without pretending any one field is final identity;
- **handler racks** so one row can say `associated`, `default`, `chosen now`, `safe preview`, or `unavailable here`;
- **open-state badges** so one pane can say `previewing`, `editing`, `external`, `portal-owned`, or `history only`.

What not to freeze yet:
- one universal type schema for all object families;
- one final priority order between declared and derived classification;
- one final owner for opener choice across shell, portal, helper, and provider.


### 22. ViewFS should keep annotations, selector labels, policy labels, and trusted badge chrome on distinct seams
Use:
- `30-architecture/attrfs-posture-v0.md`
- `30-architecture/attestation-badge-surfaces-v0.md`
- `30-architecture/open-untrusted-posture-v0.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- Steward `label-surface-posture-v0.md`
- Helm trusted-chrome notes

Implication:
- SlopOS already has the right instinct that metadata-rich systems and trusted UX chrome need explicit provenance and explicit boundaries;
- ViewFS should sharpen that further by keeping freeform annotations, selector-safe labels, policy-bearing labels, shell-owned trusted badges, and receipts visibly distinct;
- shell-visible chips should never force us to decide early whether metadata lives on objects, placements, indexes, or provider-local surfaces.

What to steal:
- **selector rails** so only compact query-safe labels power smart baskets and saved filters;
- **trusted badge shutters** so stronger handling or review labels live in shell-owned chrome instead of decorative chip clouds;
- **label ledgers** so the shell can say `annotation`, `selector`, `policy`, `badge`, or `history only`.

What not to freeze yet:
- one final label schema for SlopOS/ViewFS objects;
- whether policy-bearing labels are imported, local-only, or provider-owned in Phase 1;
- whether trusted badges are terminal-native, shell-native, or helper-native on every platform.



### 23. ViewFS should keep continuation cursors, sync watermarks, live subscriptions, rebuilt snapshots, and gap verdicts on distinct seams
Use:
- `docs/30-architecture/attrfs-posture-v0.md`
- `docs/30-architecture/observation-export-posture-v0.md`
- `docs/30-architecture/portal-session-posture-v0.md`
- `docs/30-architecture/mcp-progress-import-boundary-v0.md`
- `docs/30-architecture/notification-request-state-posture-v0.md`
- `rfcs/0119-ordering-streams-and-tokens.md`

Implication:
- SlopOS already has the right instinct that provider-owned current mutable state should not silently collapse into requester-owned request ids or transcript truth;
- ViewFS should sharpen that further by keeping provider continuation cursors, processed-through watermarks, current live follow state, rebuilt snapshots, gap/reset verdicts, and receipts visibly distinct;
- shell query/follow panes should be driven by explicit sync truth instead of one opaque token or one vague stale badge.

What to steal:
- **waterline cards** so one pane can show `snapshot through X`, `following from X`, `cursor expired`, or `history only` without pretending any one row is the whole story;
- **gap badges** so one row can say `resource version too old`, `provider reset`, `must rescan`, `remote-risk`, or `receipt only`;
- **resync ladders** so the shell can offer `continue`, `wait`, `relist`, `rebuild`, or `freeze rows` instead of a generic refresh button.

What not to freeze yet:
- one universal cursor or watermark schema across SlopOS/ViewFS providers;
- one final normalized reset taxonomy;
- whether rebuilt snapshots are shell-owned caches, materialized objects, or provider-owned cuts in Phase 1.

### 24. ViewFS should keep observed validators, writable sessions, write holds, commit preconditions, committed versions, and receipts on distinct seams
Use:
- `docs/30-architecture/acp-precondition-witness-posture-v0.md`
- `docs/30-architecture/capstore-commit-schema-v0.md`
- `docs/30-architecture/capability-lease-posture-v0.md`
- `docs/30-architecture/lease-descriptor-state-boundary-v0.md`
- `docs/30-architecture/background-request-state-posture-v0.md`
- `rfcs/0065-orthogonal-persistence-and-capstore.md`

Implication:
- SlopOS already has the right instinct that exact local witness material, live lease/coordination state, and durable commit meaning must stay separate;
- ViewFS should sharpen that further by keeping observed validators/bases, private writable sessions, live holds, one-shot commit predicates, winning committed versions, and receipts visibly distinct;
- shell editing and external-tool round-trips should be driven by explicit basis/commit truth instead of one vague save or reopen story.

What to steal:
- **stale-base lamps** so one pane can show `based on X`, `target now Y`, or `history only` without pretending basis is authority;
- **draft gutters** so one pane can say `private draft`, `sealed`, `diverged`, or `receipt only`;
- **commit shutters** so the shell can offer `commit if base still matches`, `create if absent`, `commit under hold`, `rebase`, or `fork instead` instead of one magical save button.

What not to freeze yet:
- one universal validator vocabulary across all SlopOS/ViewFS providers;
- whether write holds are mandatory, advisory, or absent in Phase 1;
- whether draft sessions are shell-owned, provider-owned, or runtime-owned in every backend.

### 25. ViewFS should keep partial residency, chunk layout, whole-object proof, live range-fill state, and receipts on distinct seams
Use:
- `docs/30-architecture/layer-lazy-materialization-boundary-v0.md`
- `docs/30-architecture/capstore-blob-descriptor-schema-v0.md`
- `docs/30-architecture/transfer-portal-posture-v0.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `rfcs/0038-persistent-object-store-and-snapshots.md`
- `rfcs/0107-io-submission-queues-and-completions.md`

Implication:
- SlopOS already has the right instinct that exact blob descriptors, staged exact bytes, and later materialization acts should stay explicit instead of dissolving into one fake file-open story;
- ViewFS should sharpen that further by keeping current sparse coverage, partition/layout metadata, whole-object proofs, live lazy-fill state, and receipts visibly distinct;
- shell/object cards should be able to say `descriptor known`, `partial local`, `range-fillable`, `whole proof present`, or `history only` without forcing one final sparse-store substrate.

What to steal:
- **hole maps** so one object card can show `prefix only`, `holes present`, `all chunks local`, `proof missing`, or `history only` instead of one generic downloaded light;
- **range panels** so shell chrome can keep `coverage`, `layout`, `proof`, `remote fill`, and `receipt` in one honest drawer;
- **whole-proof ladders** so the shell can offer `fetch missing`, `verify complete`, `seal local copy`, or `stay sparse` instead of one magical hydrate button.

What not to freeze yet:
- one canonical sparse coverage schema across SlopOS/ViewFS providers;
- whether coverage is tracked as byte ranges, chunk ids, file extents, or provider-specific shards;
- whether full whole-object proof is mandatory for every launch/publish/import pathway in Phase 1.


### 26. ViewFS should keep delta recipes, exact bases, apply sessions, reconstructed targets, and receipts on distinct seams
Use:
- `docs/30-architecture/capstore-blob-descriptor-schema-v0.md`
- `docs/30-architecture/capstore-commit-schema-v0.md`
- `docs/30-architecture/layer-lazy-materialization-boundary-v0.md`
- `docs/30-architecture/import-to-docref-boundary-v0.md`
- `rfcs/0038-persistent-object-store-and-snapshots.md`
- `rfcs/0065-orthogonal-persistence-and-capstore.md`

Implication:
- SlopOS already has the right instinct that exact blob descriptors, exact commit meaning, and explicit materialization acts should stay separate instead of dissolving into one fake reopen/update story;
- ViewFS should sharpen that further by keeping delta recipes, exact basis requirements, current apply sessions, reconstructed targets, and receipts visibly distinct;
- shell/object cards should be able to say `recipe present`, `needs base X`, `basis missing`, `reconstructed locally`, `full fetch fallback`, or `history only` without forcing one final delta substrate.

What to steal:
- **basis cards** so one object/update card can show `from X`, `base local`, `base mismatch`, or `history only`;
- **delta peels** so shell chrome can keep `recipe`, `basis`, `apply`, `fallback`, `result`, and `receipt` in one honest drawer;
- **apply ladders** so the shell can offer `apply in scratch`, `verify result`, `materialize fresh object`, `fetch whole target`, or `discard recipe` instead of one magical update button.

What not to freeze yet:
- one canonical delta format across SlopOS/ViewFS providers;
- whether basis requirements are commit ids, descriptors, validators, or provider-local windows in each backend;
- whether apply sessions are shell-owned, helper-owned, runtime-owned, or provider-owned in Phase 1.

## Revision 082: ViewFS should align with SlopOS's explicit launch assembly without overcommitting continuity

SlopOS is still in design, which is precisely why ViewFS should freeze the seam instead of the mechanism.
The useful common posture across the current SlopOS material is:
- launch assembly is explicit,
- handle-table population is explicit,
- namespace/view construction is explicit,
- and portal/document-handle style reacquire lanes are narrower than ambient rediscovery.

That means ViewFS can safely align on the following now:
- treat startup delivery as **activation-sheet** truth rather than path rediscovery;
- treat a handed-in capability as a **live handle copy** rather than a durable identity claim;
- treat issuer badge / courier witness as **copy-lineage explanation** rather than trust or identity;
- treat receiver-local bind names as **local ergonomics** rather than global truth;
- treat any restart continuity story as a separate explicit lane.

What this still does **not** settle:
- whether durable continuity lands first as a document-handle lane, continuity locker, fresh portal reacquire, or multiple lanes;
- whether a child-local slot vocabulary should be `fd`, symbolic slot names, structured object slots, or a hybrid;
- how much exact object identity can be surfaced for every imported/transferred live thing;
- whether handoff sheets are shell-owned, supervisor-owned, or protocol-native first.



### 27. ViewFS should keep store membership, synthetic views, live handles, and published names on distinct seams

Why this matters:
- SlopOS `view-namespace-posture-v0.md` already pins the crucial low-regret move: namespaces are explicit views, not a global resolver, and components consume/publish namespace content through explicit assembly rather than ambient discovery.
- SlopOS `document-portal-posture-v0.md` already leans toward restricted mediated document access rather than raw host-path folklore.
- Fuchsia sharpens the publication lesson further: components consume namespaces they are given and may separately publish objects through an outgoing directory to other components.
- XDG Documents sharpens the mediated-view lesson: a selected file can become reachable through a restricted synthetic document view without implying broad native publication.

What ViewFS should steal:
- keep **in store**, **reachable through restricted projection**, **live handle now**, **published here now**, and **receipt only** as different truths;
- make local publication into a pane/process namespace an explicit act instead of a silent side effect of import or selection;
- keep portal/request state distinct from local bind/current-handle truth;
- let the shell explain when the same object is visible through several publication/projection sites instead of pretending one path label is its identity.

What ViewFS should not freeze yet:
- whether synthetic restricted views are shell-owned, service-owned, launcher-owned, or lower-level runtime objects;
- whether publication ledgers are shell-only chrome, queryable objects, or both;
- whether later overlay/search semantics ever sit on top of the same publication vocabulary.

### 35. ViewFS should keep explicit-handle opens, rooted compat pathwalks, portal grants, ambient escapes, and receipts on distinct seams
Use:
- `capshell-filesystem-posture-v0.md`
- `capshell-cwd-root-posture-v0.md`
- `view-namespace-posture-v0.md`
- `document-portal-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already rejects an ambient host-filesystem baseline and already prefers creator-populated roots/views, explicit child tables, and explicit document/portal mediation.
- That is enough evidence for ViewFS to freeze a new low-regret split now: direct current-handle opens, rooted compat walkers inside already-held roots/views, mediator-minted grants/projections, and truly ambient host escapes should not be flattened into one `open(path)` story.
- A rooted compat walker may still be useful during bring-up or legacy-tool support, but it should remain a narrow membrane with explicit no-escape posture and loud debt labels.
- Any truly ambient host escape should be policy-gated, transcript-visible, and easy to replace with a cleaner bind/grant/handle lane later.
- Shell/transcript UX should explain which lane won: `handle`, `rooted`, `portal`, `ambient`, or `history only`.


## SlopOS seams that reinforce discoverability vs authority
The current SlopOS material keeps pointing in the right direction for one more low-regret ViewFS split:
- `mcp-completion-import-boundary-v0.md` says provider-suggested values are suggestion mechanics only, not selector/default/workflow truth.
- `mcp-roots-import-boundary-v0.md` and `mcp-resource-import-boundary-v0.md` keep imported roots/resources from quietly becoming filesystem grants or current-resource oracles.
- `namecert-search-boundary-v0.md` says search stays closed-world over explicit bundles rather than ambient distributed discovery.
- `view-namespace-posture-v0.md` and `capmode-posture-v0.md` reinforce that a component lives within explicitly assembled views instead of ambient global browsing.

That means ViewFS can safely freeze a smaller discipline right now:
- showing a candidate is not the same thing as granting browse authority;
- browse authority is not the same thing as exact-name reachability;
- exact-name reachability is not the same thing as already-held handle truth;
- and receipts/history should say which one actually occurred.

What to steal:
- **dark-directory posture** for `exact name works, browse is gated`;
- **known-name chips** so exact-name success is visible in transcript history;
- **fit sheets** so helper/provider suggestions explain scope and quality without claiming authority;
- **search-result dimmers** so history and helper candidates do not masquerade as current local truth.

What not to freeze yet:
- one universal browse/search API for all providers;
- one universal metadata-disclosure lattice;
- whether indexes are shell-owned, service-owned, or portal-owned;
- whether exact-name reachability should be app-visible or mostly a compat/runtime seam.

## SlopOS seams that reinforce advertised presence vs readiness vs authority
The current SlopOS material keeps pointing in the right direction for one more low-regret ViewFS split:
- `mcp-roots-import-boundary-v0.md`, `mcp-resource-import-boundary-v0.md`, `mcp-prompt-import-boundary-v0.md`, and `mcp-completion-import-boundary-v0.md` already refuse to let imported catalogs/suggestions turn into filesystem grants, current-state oracles, or workflow truth.
- `connector-tool-policy-boundary-v0.md` already refuses to treat visible tool catalogs as portable connector-admin or enabled-tool truth.
- `view-namespace-posture-v0.md` and `capshell-filesystem-posture-v0.md` still reinforce that current local authority comes from explicit assembly and explicit grants, not from ambient catalog presence.
- Steward’s current trajectory around **presence advertisements**, **freshness decay**, and **attention/status chrome** is a strong sibling reminder that `advertised`, `ready`, `held`, and `history only` are different user-facing truths.

That means ViewFS can safely freeze one smaller discipline right now:
- something being advertised by a provider/helper is not the same thing as it being ready now;
- something being ready now is not the same thing as the actor already holding direct current authority;
- a visible `grant needed` step is useful truth, but it is still weaker than `handle held` truth;
- and receipts/history should say which of those actually happened.

What to steal:
- **presence halos** for `advertised`, `ready`, `grant needed`, `withheld`, `withdrawn`, and `history only`;
- **readiness lamps** that decay from `ready now` to `last known` to `history only` instead of flattering themselves into current truth;
- **withdrawn ghosts** so helper/provider affordances can disappear honestly without erasing useful context;
- **advert ledgers** so shell chrome can answer who advertised something, when, and under what freshness caveat.

What not to freeze yet:
- one universal advert/watch protocol across all SlopOS/ViewFS providers;
- one canonical readiness state machine for every helper or object surface;
- whether advert freshness comes from pushes, pulls, query snapshots, or provider-local heuristics in each backend;
- whether some providers skip readiness entirely and expose only direct-handle or direct-request lanes.


### 35. ViewFS should keep provider-ready, reacquire-needed, and local-realized truth on distinct SlopOS seams
Use:
- `activation-set-schema-v0.md`
- `caprpc-session-posture-v0.md`
- `caprpc-proxy-replication-boundary-v0.md`
- `capmode-posture-v0.md`

Implication:
- SlopOS already resists the idea that live-session references, restore/import surfaces, and current authority are one thing; ViewFS should extend that honesty to `provider-ready` versus `local realized` truth too.
- a helper/provider saying it can supply or restore something later should not silently count as local object-store residence right now.
- shell UX should be free to expose `provider-ready`, `repair owed`, `make local`, and `bound here` as separate product states instead of one vague `available` badge.

## Revision 088 seam: redeemable versus holder-bound versus passable authority

The parent SlopOS archive is already culturally aligned with **binding discipline over portable bearer folklore**.
Its MCP PKCE and DPoP import-boundary work keeps verifier/proof material provider-local instead of widening it into a generic portable signer or continuation plane.
That means ViewFS can safely steal the *shape* of the separation now:
- redeemable claim artifacts,
- holder-bound live grants,
- passable live handles,
- and spent/expired receipts
should remain different nouns.

Steward strengthens the same conclusion from another angle by explicitly exploring **consumable-grant** and **holder-bound-grant** posture.
The cross-cube lesson is that anti-replay semantics, sender-constraining, and current-holder proof are all worth surfacing in UI vocabulary before the backend settles.


### 36. ViewFS should keep current possession, freshness/step-up posture, local presence, and current invocability on distinct SlopOS seams
Use:
- `mcp-step-up-auth-import-boundary-v0.md`
- `cryptosvc-interactive-auth-boundary-v0.md`
- `auth-mediation-boundary-index.md`
- `capability-lease-posture-v0.md`

Implication:
- SlopOS already resists the idea that imported `acr_values`, `max_age`, `auth_time`, `amr`, or local unlock/presence mechanics should silently become one portable generic `authorized now` plane.
- ViewFS should extend that honesty to shell-visible action truth: `held here`, `fresh enough`, `step-up needed`, `presence needed`, `invokable now`, and `history only` should remain different classes.
- shell UX should be free to expose step-up ladders, recency shutters, presence pins, and why-not-now drawers instead of one vague `permission denied` story.


### 37. ViewFS should keep live possession, watch/status carriers, local holds, successor refresh, and post-watch invocability on distinct SlopOS-adjacent seams
Use:
- `attention-durable-status-boundary-v0.md`
- `mcp-step-up-auth-import-boundary-v0.md`
- `authagent-provider-role-boundary-v0.md`
- Ward’s `trust-consequences-and-spendable-grants.md`
- Ward’s `specimen-flow-13-status-carrier-suspension-rail-and-refresh-notice.md`
- Ward’s `specimen-flow-17-attenuation-event-receiver-stance-and-subject-drift.md`
- Harbor’s `routing-admission-and-outcome-classes.md`

Implication:
- SlopOS already resists the idea that one later status cue, one transient attention surface, one imported provider hint, or one prior success should silently become durable portable truth.
- ViewFS should extend that honesty to standing-watch state: `held here`, `later status arrived`, `local stance`, `hold active`, `refresh/successor needed`, `invokable now`, and `history only` should remain different classes.
- shell UX should be free to expose watch braids, hold rails, successor lanterns, stale-watch fog, and quarantine shutters instead of one fake timeless validity bit.


### 38. ViewFS should keep current possession, local duplication, live lends, and representation exports on distinct SlopOS seams
Use:
- `transfer-portal-posture-v0.md`
- `document-portal-posture-v0.md`
- `seal-posture-v0.md`
- `capshell-handle-table-posture-v0.md`

Implication:
- SlopOS already resists the idea that clipboard/drag-drop transfer, document export, and current local handle possession are one thing.
- SlopOS also keeps attenuation one-way and explicit, which is a strong reminder that `duplicate`, `lend narrowed`, and `export weaker representation` should stay different classes.
- ViewFS should extend that honesty to sender-side share posture: `held here`, `duplicate locally`, `lend live`, `bytes/doc export only`, and `history only` should remain different nouns.
- shell UX should be free to expose lend ladders, lane-fit badges, bytes-only fallback chips, share sheets, and same-object-versus-new-representation drawers instead of one fake universal share button.


### 39. ViewFS should keep route capsules, authority sidecars, sink acceptance, and receipts on distinct SlopOS seams
Use:
- `rfcs/0117-plumb-messages-and-cli-intents.md`
- `rfcs/0116-capability-wallets.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0094-transfer-portal-and-typed-payload-leases.md`

Implication:
- SlopOS already keeps CH-PLUMBMSG non-authoritative, keeps CH-WALLET descriptive rather than capability-bearing, and keeps request-local portal objects separate from final document/transfer grants.
- ViewFS should extend that honesty to shell-visible route work: a typed route capsule, any wallet/URI-grant/representation sidecar, the sink’s actual acceptance, and the durable receipt should remain different nouns.
- shell UX should be free to expose route slips, sidecar chips, sink trays, and copy-safe designation-only pills instead of one flattering `open` or `share` verb.

### 40. ViewFS should keep privilege brackets, borrowed authority, call-chain contexts, deny-only hints, and receipts on distinct SlopOS seams
Use:
- `rfcs/0118-privilege-bracketing-and-call-chain-contexts.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0031-powerbox-consent-mediators-and-capability-ux.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`

Implication:
- SlopOS already gives ViewFS permission to treat bounded helper execution, explicit borrowed capability use, and non-authoritative caller/context metadata as different classes.
- ViewFS should extend that honesty into shell-visible helper/plugin/automation work: one bracket, one borrowed-authority set, one caller chain, one deny-only veto, and one receipt should remain different nouns.
- shell UX should be free to expose bracket rails, caller badges, who-asked drawers, borrowed-authority drawers, deputy-fog warnings, and deny-only shutters instead of one fake `helper did it` line.

### 41. ViewFS should keep native attaches, adapted attaches, coerced representations, local realizations, and receipts on distinct SlopOS seams
Use:
- `view-namespace-posture-v0.md`
- `document-portal-posture-v0.md`
- `import-to-docref-boundary-v0.md`
- `tool-annotation-semantics-boundary-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`

Implication:
- SlopOS already gives ViewFS permission to treat receiver-local fit, explicit compatibility glue, and translated/preview surfaces as different classes instead of one global `opened` story.
- ViewFS should extend that honesty into shell-visible attach truth: `native here`, `adapter here`, `relay here`, `coerced representation`, `make local for native`, and `history only` should remain different nouns.
- shell UX should be free to expose attach-mode badges, adapter veils, virtuality lamps, same-object-versus-translated drawers, and make-local-for-native ladders instead of one fake universal open path.



### 86. ViewFS shell baseline should align with SlopOS capshell startup-profile posture without importing ambient shell folklore
Relevant SlopOS sources:
- `docs/30-architecture/capshell-startup-profile-posture-v0.md`
- `docs/30-architecture/capshell-env-startup-posture-v0.md`
- `docs/30-architecture/capshell-command-string-posture-v0.md`
- `docs/30-architecture/capshell-launcher-lifetime-posture-v0.md`

What carries over cleanly:
- SlopOS already treats built-in capshell behavior, explicit reviewed startup/customization surfaces, ambient host startup files, and project-local activation hooks as different authored seams.
- SlopOS already refuses prompt/cwd-triggered code loading inside the reviewed baseline, which is exactly the right pressure for ViewFS while the custom shell is still fluid.
- SlopOS therefore gives ViewFS permission to make shell delight ambitious **and** keep startup truth explicit.

What ViewFS should keep separate:
- built-in shell affordances,
- explicit reviewed customization bundles,
- ambient host/user startup files or profiles,
- project-local activation hooks,
- and durable receipts/history.

What this does **not** settle yet:
- one final customization-bundle schema,
- whether any legacy rc/profile import story exists at all,
- or the exact scope lattice for project-hook approvals.


### 87. ViewFS should keep built-in verbs, lexical expansions, command layers, key actions, and external launches on distinct SlopOS-adjacent seams
Relevant SlopOS sources:
- `docs/30-architecture/capshell-startup-profile-posture-v0.md`
- `docs/30-architecture/capshell-command-string-posture-v0.md`
- `docs/30-architecture/capshell-handle-table-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- Foundry's config-layer / overlay-gate pressure

What carries over cleanly:
- SlopOS already resists ambient shell folklore and keeps launch meaning structured instead of stringly magical.
- The uploaded sibling material keeps pushing toward explicit config/overlay layers rather than one hidden active soup.
- ViewFS therefore has permission to make a future shell say `built-in`, `expanded`, `overlay`, `widget`, `external`, or `history only` as different truths.

What ViewFS should keep separate:
- built-in shell verbs,
- typed lexical expansions,
- activated semantic command layers,
- keybound widgets or palette-only actions,
- exact external launches,
- and durable receipts/history.

What this does **not** settle yet:
- one final alias/abbreviation model,
- one final overlay/module schema,
- whether every key action can ever promote into one typed verb,
- or one universal command-palette protocol.


### 88. ViewFS should keep editable buffers, parsed structure, diagnostics, compiled packets, and prepared actions on distinct SlopOS-adjacent seams
Relevant SlopOS sources:
- `docs/30-architecture/capshell-command-string-posture-v0.md`
- `docs/30-architecture/capshell-startup-profile-posture-v0.md`
- `docs/30-architecture/mcp-prompt-template-posture-v0.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- Schell's outcome/signal pressure and Steward's context-aware completion pressure

What carries over cleanly:
- SlopOS already resists treating one command string as the whole truth about what will run.
- The sibling cubes keep pressuring the shell toward explicit staged truth: observed text, context-aware suggestions, current outcome evidence, and current authority are not one thing.
- ViewFS therefore has permission to make a future shell say `buffer`, `parsed`, `diagnostic`, `compiled`, `prepared`, or `history only` as different truths.

What ViewFS should keep separate:
- current editable buffer text/fragments,
- current parse/highlight structure,
- advisory syntax/lint/hint rails,
- pane-local compiled command packets,
- prepared actions ready for review/launch,
- and durable receipts/history.

What this does **not** settle yet:
- one final shell parser or grammar,
- one final diagnostic engine,
- one universal token/highlight taxonomy,
- or whether packet compilation is shell-owned, helper-assisted, or terminal-assisted.

### 6b. ViewFS should keep namespace plans, live room bindings, portal sessions, local overlays, and reset/death truth on separate SlopOS-adjacent seams
Use:
- `docs/30-architecture/view-namespace-posture-v0.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `docs/30-architecture/wallet-posture-v0.md`
- `rfcs/0032-view-namespace-semantics-v1.md`
- `rfcs/0089-document-portal-and-durable-file-handles.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0116-capability-wallets.md`
- `rfcs/0117-plumb-messages-and-cli-intents.md`

Implication:
- SlopOS already provides enough explicit namespace, mediated import, descriptive-wallet, and typed-intent posture that ViewFS does not need one flattened `room object` carrying plan/live/session/local/history all at once;
- namespace plans can stay reviewable and searchable without becoming current live authority;
- portal request/session truth can stay explicit instead of dissolving into current binds or history only;
- local overlays can stay shell-local/device-local/activity-local convenience residue instead of silently becoming portable core truth;
- reset/death cards can explain why old continuity vanished without pretending the source failed or silently repairing to latest.

### 89. ViewFS should keep activation kits, restart lockers, namespace pins, and live room binds on distinct SlopOS-adjacent seams
Relevant SlopOS sources:
- `rfcs/0065-orthogonal-persistence-and-capstore.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `rfcs/0116-capability-wallets.md`
- `docs/30-architecture/capshell-filesystem-posture-v0.md`
- `docs/30-architecture/capshell-handle-table-posture-v0.md`

What carries over cleanly:
- SlopOS already makes persistence explicit instead of ambient, which gives ViewFS room to define a narrower restart seam without pretending everything is durable.
- SlopOS already keeps process launch/import posture explicit, which makes startup-delivered kits feel culturally aligned.
- SlopOS descriptive wallets support the idea that a restart locker or pin can be inspectable without being live authority by itself.

What ViewFS should keep separate:
- startup-delivered activation kits,
- manager-held restart lockers,
- namespace/view pins,
- current live room bindings,
- durable import anchors,
- and durable receipts/history.

What this does **not** settle yet:
- one final restart-locker carrier,
- whether namespace pins are shell objects, supervisor objects, or lower-level runtime facts,
- whether any locker survives reboot or only controlled restart,
- or one final room-manager split for warm-start continuity.


### 40. ViewFS should keep live room binds, currentness witnesses, semantic epochs, and repair offers on distinct SlopOS-adjacent seams

Relevant current SlopOS surfaces:
- `docs/30-architecture/document-handle-schema-v0.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `docs/30-architecture/activation-set-schema-v0.md`
- `docs/30-architecture/capability-wallet-schema-v0.md`
- `docs/30-architecture/capshell-handle-table-posture-v0.md`
- `docs/30-architecture/capshell-filesystem-posture-v0.md`

Why the seam is justified now:
- SlopOS docrefs already separate durable descriptor shape from live authority and carry explicit expiry plus optional `rev_epoch`;
- SlopOS document-portal posture already says revoked/expired/replaced reopen should fail closed rather than flattering stale access;
- SlopOS wallets are descriptive and non-authoritative, which is exactly the right precedent for keeping `what we can explain` separate from `what is current now`;
- SlopOS activation sets already separate activation-delivered continuity from generic persistence or ambient inventory;
- Steward sibling work is already making semantic epoch, hop lineage, precision fences, and target anchors first-class shell truths.

Therefore ViewFS should keep:
- **live room bind now**,
- **provider/issuer currentness witness**,
- **shell semantic epoch / hop scope**,
- **bounded repair offer**,
- and **receipt/history**

visibly distinct instead of collapsing them into one `still valid import` myth.

Shell pressure this unlocks:
- epoch lamps for `same epoch`, `older epoch`, or `hop changed`;
- currentness drawers for `current`, `refresh needed`, `successor available`, `revoked`, or `unknown`;
- repair-offer cards for `refresh`, `revalidate`, `reconsent`, `rebind`, `make local`, or `rerun clean`;
- stale-anchor honesty when an affordance is still visible but no longer exact enough for control.


### 40b. ViewFS should keep live room binds, visibility states, keep-warm leases, restore intents, and deferred repair jobs on distinct SlopOS-adjacent seams

Relevant current SlopOS surfaces:
- `docs/30-architecture/background-lease-posture-v0.md`
- `docs/30-architecture/background-request-state-posture-v0.md`
- `docs/30-architecture/capability-lease-posture-v0.md`
- `docs/30-architecture/document-portal-posture-v0.md`
- `rfcs/0096-job-portal-and-constraint-based-background-work.md`
- `rfcs/0103-background-execution-and-autostart-leases.md`

Why the seam is justified now:
- SlopOS already says `background` and `autostart` are distinct grant bits;
- SlopOS already says request identity is not current portal-owned grant state;
- SlopOS background posture explicitly prefers jobs for deferred sync/retry/maintenance instead of laundering them into continuous presence;
- capability leases already keep explicit renewal authority separate from mere keepalive signals.

Therefore ViewFS should keep:
- **live room bind now**,
- **visibility / serving state**,
- **keep-warm / background-presence grant**,
- **restore / autostart intent**,
- **deferred repair job**,
- and **receipt/history**

visibly distinct instead of collapsing them into one `room is still around` myth.

Shell pressure this unlocks:
- warmth rails for `foreground`, `warming`, `background serving`, `draining`, or `history only`;
- keep-warm badges for `allowed`, `clamped`, `expiring`, or `denied`;
- login lanterns for `restore allowed`, `restore proposed`, `restore denied`, or `reconsent needed`;
- defer drawers that say the truth when the system switched from live continuity to deferred repair work.

### 6c. ViewFS should keep live room bindings, attention cues, interrupt grades, quiet windows, and durable follow-up on distinct SlopOS-adjacent seams
Use:
- `attention-lease-posture-v0.md`
- `attention-durable-status-boundary-v0.md`
- `background-lease-posture-v0.md`
- `background-request-state-posture-v0.md`
- `capshell-job-control-posture-v0.md`

Implication:
- SlopOS already gives ViewFS permission to keep `live now`, `wants attention now`, `may interrupt strongly`, `currently hushed`, and `durable follow-up needed` as different truths without inventing a second notification mythology;
- transient attention chrome should stay weaker than durable consequence truth and weaker again than current room authority;
- stronger interruption should remain its own review/governance seam rather than a flattering `urgent` bit on any live room;
- shell chrome should be able to say `activity`, `bell`, `silence`, `quieted`, `urgent clamped`, `follow-up unread`, or `receipt only` instead of flattening everything into one vague alert badge.

### 6d. ViewFS should keep live room bindings, summon beacons, activation batons, foreground turns, and secure-entry truth on distinct SlopOS-adjacent seams
Use:
- `attention-lease-posture-v0.md`
- `tool-ui-display-surface-boundary-v0.md`
- `uicap-scope-posture-v0.md`
- `capshell-job-control-posture-v0.md`
- `openuri-activation-control-boundary-v0.md`

Implication:
- SlopOS already gives ViewFS enough explicit attention, display-surface, trusted-UI, and job-control posture that ViewFS can keep `live bind now`, `surface-me cue`, `activation baton`, `frontmost/focused turn`, `secure-entry gate`, and `receipt only` as separate truths without inventing a second window-manager mythology;
- a summon beacon can remain explicit and useful without pretending it already owns focus or trusted entry;
- host-owned fullscreen/modal/display choreography should stay weaker than foreground authority and much weaker than secure-entry or trusted chooser truth;
- shell chrome should be able to say `glance me`, `may try to raise`, `front now`, `trusted path active`, or `receipt only` instead of one flattering `active` badge.


### 6e. ViewFS should keep live room bindings, observe mirrors, automation leases, synthetic input lanes, and secure-entry exclusions on distinct SlopOS-adjacent seams
Use:
- `rfcs/0080-capability-mediated-ui-compositor-and-secure-attention.md`
- `rfcs/0099-accessibility-and-automation-leases.md`
- `rfcs/0115-capability-safe-shell-and-automation.md`
- `tool-ui-display-surface-boundary-v0.md`
- `uicap-scope-posture-v0.md`

Implication:
- SlopOS already gives ViewFS enough explicit accessibility/automation/trusted-UI posture that ViewFS can keep `live room binding`, `observe mirror`, `automation lease`, `synthetic input lane`, `secure-entry exclusion`, and `receipt only` on different seams without inventing a fake general automation object;
- observe-only posture should stay a smaller class than injection/control, and both should stay weaker than secure-entry/trusted-path truth;
- secure-entry clamps should be allowed to redact mirrors and block injection without pretending the room itself disappeared;
- shell chrome should be able to say `semantic mirror`, `observe only`, `inject allowed`, `mirror redacted`, `input blocked`, or `history only` instead of one vague `automation active` badge.

## Revision 110 pressure: projection sites versus room aliases versus localization
SlopOS already has the right instincts in `document-portal-posture-v0.md`, `import-to-docref-boundary-v0.md`, `view-namespace-posture-v0.md`, and `capshell-cwd-root-posture-v0.md`: a mediated/provider-backed view is not yet one native local publication act, and a published local site is not yet one final local object-store truth.

That means ViewFS should keep `provider projection`, `published room alias`, `live room bind`, `localized here`, and `receipt only` visibly distinct.

Shell UX should make `provider-owned`, `portal view`, `published here`, `localized replica`, `local object`, and `history only` different states instead of laundering them into one fake `opened file` story.

### 13f. Projected bases, local uppers, merged presentations, and publish results
- is this thing one current live room binding, one separate projected/provider/generated base stack, one separate writable local upper shadow, one separate merged room presentation, one later publish/commit/adopt result, or only durable receipt/history material?

Keep separate because:
- SlopOS explicitly wants per-component namespaces that are cheap to clone and overlay, which is permission to model layered views, not permission to flatten them;
- a projected base can stay provider-owned or generated while the upper shadow is purely local and writable;
- the merged room presentation is a convenience traversal surface and should not impersonate durable object-store truth;
- whiteout/hide posture and later publish/commit acts need their own reason-rich receipts.

Do not freeze yet:
- one final overlay substrate for ViewFS or SlopOS;
- whether upper overlays are shell-owned, room-owned, or supervisor-owned;
- whether publish/commit/adopt results target room aliases, local objects, provider mutations, or several result families;
- whether SlopOS eventually standardizes one portable overlay family at all.

### L79. Caller request contexts, detached roots, deadlines, and cancellation should stay separate
- SlopOS RFC-0105 explicitly says work that intentionally outlives its caller should mint a **fresh root context** on the owning seam rather than rely on portable detach/shield semantics.
- That gives ViewFS permission to keep caller-bound request context, detached continuation root, deadline intent, live cancellation state, provider operation ticket, and durable receipt/history on distinct seams.
- Go `context`, Go `WithoutCancel`, gRPC deadlines, Kotlin cancellation / `NonCancellable`, Temporal disconnected cleanup, and Cap'n Proto call-context logistics all point the same way: propagation, detachment, cutoff, cancellation acknowledgement, and later follow-up are not one blob.
- A shell should be able to say `caller child`, `cleanup root`, `provider continuation`, `deadline fired`, `cancel requested`, `cancel acknowledged`, `provider still settling`, and `history only` as different truths instead of one vague background badge.

## More ideas worth stealing
- **cutoff lamps** for inherited versus narrowed versus absent versus expired caller patience budgets.
- **detach-root cards** that tell the truth about `caller child`, `cleanup root`, `provider continuation root`, or `watch only`.
- **continue-without-me ladders** that keep `cancel with me`, `let cleanup finish`, `let provider continue`, and `stop watching only` visibly distinct.
- **cancellation braids** and **cause drawers** that explain how far the stop signal actually propagated.

### L80. Action authority, payer roots, budget leases, spend reservations, and charge verdicts should stay separate
- SlopOS `budget-payer-semantics-v0.md` is admirably blunt: no ambient current payer, no hidden session sponsorship plane, no portable rule that cgroup/job/container/subtree identity equals payer, and no silent sponsor rebinding.
- `budget-lease-schema-v0.md` keeps sponsorship bounded and transcript-visible instead of laundering it into raw capability use.
- `background-lease-posture-v0.md` reinforces that long-running permission does not imply silent forever-funding.
- External systems rhyme with the same lesson: S3 and Cloud Storage Requester Pays separate permission from billing posture; Kubernetes keeps RBAC separate from ResourceQuota; seL4 MCS keeps scheduling budget separate from threads; Genode treats resource donation as an explicit session property; cgroup v2 is resource-control machinery, not portable payer truth.
- A shell should be able to say `authorized`, `requester pays`, `server budget`, `reserved`, `charged`, `charge rejected`, or `history only` as different truths.

Do not freeze yet:
- one universal payer-root schema for all ViewFS families;
- one final budget lease format;
- whether spend reservations and final charge verdicts share IDs or only receipts/history links;
- whether payer selection belongs to the caller, the provider, or one reviewed negotiation seam.

## More ideas worth stealing
- **payer chips** for `requester`, `owner`, `server budget`, `unknown`, or `history only`.
- **spend rails** for `budget present`, `reserved`, `partially spent`, `charged`, `rejected`, or `history only`.
- **switch-payer ladders** so `preview cost`, `reserve`, `commit`, `retry same sponsor`, and `switch payer` stay visibly different.
- **charge ghosts** that preserve cost history without reviving live sponsor authority.

## Revision 118 pressure: object-home rooms versus attached tools versus imported binds versus retention roots
SlopOS now gives ViewFS another honesty warning adjacent to namespace seeding, portal imports, and capstore work: a room's home object set, the currently attached tool/session, later imported capabilities, local published names, and explicit retention roots are different truths even when the user experiences them as `I opened the thing`.

That strongly suggests ViewFS should keep **object-home room seeds**, **attached tool/editor sessions**, **later imported binds**, **published local names**, **retention roots/ledgers**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Sandstorm grains show the value of object-centered work contexts with platform-enforced sharing instead of one broad app workspace;
- the Sandstorm powerbox asks `which object should this app use?` rather than granting one giant yes/no app permission;
- Fuchsia namespaces remind us names belong to one namespace/container rather than to the object itself;
- Nix GC roots remind us survivability is an explicit root set rather than a side effect of current attachment or current open state.

That means ViewFS can be ambitious about grain-style object homes, tool docks, import ladders, published-name ledgers, and root-ledger badges **without** freezing one universal room model, one universal app model, or one final retention substrate.


## Revision 119 pressure: object identity versus capability facets versus grouped kits versus published names
SlopOS now gives ViewFS another honesty warning adjacent to capshell handle-table work, document portals, and capstore caution: the underlying object, the capability facet currently held over it, the grouped kit that may transport several facets together, the live room bind, and the published name are different truths even when the user experiences them as `I have the thing`.

That strongly suggests ViewFS should keep **underlying object identity**, **chosen capability facets**, **explicit grouped kits**, **live room binds**, **published names**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Sandstorm Powerbox requests ask for one API/type and let the user choose the resource, rather than asking for one giant app permission;
- Sandstorm can export multiple permission levels or APIs from the same grain, which is a strong `same object, different facet` reminder;
- Fuchsia capabilities combine a resource with rights, while dictionaries group capabilities without turning grouping into publication;
- Capsicum rights reduction is monotonic, so a narrower facet is not just a comment on a broad one;
- CHERIoT sealing reminds us that some handles should stay opaque typed tokens instead of becoming stringly rediscovery bait.

That means ViewFS can be ambitious about facet chips, kit cards, bind-one-facet-here ladders, and published-name ledgers **without** freezing one universal facet taxonomy, one universal kit schema, or one final handle encoding too early.


## Revision 120 pressure: descriptor-proof rows versus verify facets versus live read/write/publish authority
SlopOS now gives ViewFS another honesty warning adjacent to CapStore descriptors, descriptive wallets, document handles, and lease enforcement: a descriptor/proof row, a verify-only check surface, a live read facet, a live edit/publish facet, and a current room bind are different truths even when the user experiences them as `I still have the object`.

That strongly suggests ViewFS should keep **descriptor/proof rows**, **verify-only facets**, **live read facets**, **live edit/publish facets**, **live room binds**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Tahoe-LAFS capability URIs distinguish read, write, and verify capability flavors rather than one generic object token;
- Linux `O_PATH` shows that designation/descriptor-level operations can be useful while ordinary byte I/O still fails;
- CHERIoT sealing reminds us that an opaque returnable token can be legitimate without becoming a path-like rediscovery surface.

That means ViewFS can be ambitious about verify chips, proof cards, read rails, publish rails, and opaque return tokens **without** freezing one universal verification facet, one universal descriptor family, or one final seal/unseal ABI.


## Revision 121 pressure: grant outlooks versus issued bounds versus restore tokens versus live binds versus death verdicts
SlopOS now gives ViewFS another honesty warning adjacent to wallets, temporal descriptors, portal sessions, and lease enforcement: one preflight outlook, one issuance-bounded descriptor, one restore/reactivation aid, one current live bind, and one death-state verdict are different truths even when the user experiences them as `can I still use it?`.

That strongly suggests ViewFS should keep **grant outlooks**, **issued-bounds cards**, **restore/reactivation material**, **live room binds**, **death-state verdicts**, and **receipts** on different seams.

The broader ecosystem points the same way:
- W3C Permissions and File System Access keep query and request posture explicit;
- Android SAF plus `UriPermission` keep selected scope and persisted-grant bookkeeping explicit;
- XDG Request and Session keep interaction and session lifetimes explicit;
- XDG RemoteDesktop separates persistence mode, single-use restore token, and current session truth.

That means ViewFS can be ambitious about grant gauges, restore beads, death cards, and repair ladders **without** freezing one universal grant-status API, one universal restore token family, or one final death-verdict carrier.

## Revision 122 pressure: semantic object cores versus byte proofs versus structured addresses
SlopOS now gives ViewFS another honesty warning adjacent to artifact references, verified blobs, named-root commits, and descriptive wallets: one semantic object, one exact byte proof, one structured/chunked/store address, one published designation, and one current live facet are different truths even when the user experiences them as `the same thing`.

That strongly suggests ViewFS should keep **semantic object cores**, **exact byte proofs**, **structured addresses / shape hashes**, **designations / published names**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- OCI descriptors are exact raw-content descriptor envelopes with digest, media type, and size rather than semantic-object identities;
- RFC 6920 `ni:` names are hash-based names for digital objects rather than live authority or human naming;
- IPFS CIDs can include codec and DAG/root-block shape and therefore are not always plain file checksums;
- Nix content-addressed store paths deliberately include file graph, references, name, and store-directory context rather than only raw bytes.

That means ViewFS can be ambitious about object-core badges, byte-proof lamps, shape-hash drawers, and facet rails **without** freezing one universal object-id family, one universal canonicalization rule, or one final chunk/address family.

## Revision 123 pressure: stable authority-core stamps versus descriptive envelopes
SlopOS now gives ViewFS another honesty warning adjacent to wallets, graph/diff explainability, and lease-state boundaries: one stable **authority-core stamp**, one richer **descriptive review envelope**, one or more **explain sidecars**, one **current live bind**, and one **receipt/history row** are different truths even when the user experiences them as `the capability card`.

That strongly suggests ViewFS should keep **authority-core stamps**, **descriptive review envelopes**, **graph/diff/provenance sidecars**, **live binds**, and **receipts** on different seams.

That means ViewFS can be ambitious about stamp badges, envelope drawers, sidecar lamps, and live rails **without** freezing one universal wallet schema, one universal review digest family, or one final explain-sidecar ABI.


## Revision 124 pressure: strong proofs versus weak validators versus comparison profiles
SlopOS now gives ViewFS another honesty warning adjacent to wallet-core digests, exact artifact references, commit digests, and live/openability posture: one exact strong proof, one weaker stable validator, one declared comparison profile, one current live facet, and one receipt/history row are different truths even when the user experiences them as `same enough`.

That strongly suggests ViewFS should keep **strong proofs**, **weak validators**, **comparison profiles**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- HTTP entity-tag semantics explicitly distinguish weak and strong validators and reserve strong comparison for cut-sensitive flows;
- Amazon S3 explicitly warns that ETag may or may not be an MD5 digest of object data and keeps checksum lanes separate;
- Git patch-id is intentionally a stable-enough patch-shaped key rather than the full commit object;
- SlopOS already rhymes with the same lesson through `wallet_core_digest` versus CH-AREF / commit digests.

That means ViewFS can be ambitious about strong-lock badges, weak lamps, compare-profile drawers, and facet rails **without** freezing one universal digest family, one universal validator taxonomy, or one final comparison-profile ABI.


## Revision 125 pressure: object cores versus designations versus revision tokens versus order scopes versus supersession rows
SlopOS now gives ViewFS another honesty warning adjacent to conflict-key families, ordering tokens, commit schemas, and lease/current-state posture: one semantic object core, one current designation, one current head/revision token, one order scope, one supersession row, and one current live facet are different truths even when the user experiences them as `the version of the thing I have open`.

That strongly suggests ViewFS should keep **object cores**, **designations**, **revision tokens**, **order scopes**, **supersession rows**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Kubernetes keeps names, UIDs, `resourceVersion`, watch watermarks, and limited history windows on different seams;
- etcd keeps key identity, key-local version counters, create/mod revisions, and cluster revision on different seams;
- S3 keeps key names, opaque version IDs, current delete-marker posture, and noncurrent versions on different seams;
- Git keeps refs, object IDs, and reflogs on different seams;
- Schell and Ward keep superseded and resolution-shaped rows visibly weaker than current live truth.

That means ViewFS can be ambitious about head badges, order pips, supersession ladders, and facet rails **without** freezing one universal version token family, one universal global clock, or one final tombstone/supersession schema.

## Revision 126 pressure: semantic records versus canonical payloads versus wrappers versus wire copies
SlopOS now gives ViewFS another honesty warning adjacent to canonical encoding policy, wallet-core digests, artifact references, and future signed descriptors: one semantic record, one canonical payload, one signed/authenticated wrapper, one concrete wire/storage copy, and one current live facet are different truths even when the user experiences them as `the signed object`.

That strongly suggests ViewFS should keep **semantic records**, **canonical payloads**, **signed wrappers**, **wire copies**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- JCS explicitly allows canonicalized cryptographic inputs while original JSON stays on the wire;
- RFC 8949 requires deterministic-encoding choices to be explicit when multiple encodings could express the same semantics;
- COSE allows detached payloads and makes unchanged detached transport an application responsibility;
- in-toto keeps Statement and Envelope layers separate and requires signed payload type.

That means ViewFS can be ambitious about record cards, payload chips, wrapper seals, wire ghosts, and live rails **without** freezing one universal canonicalization family, one universal signature envelope, or one final export/import blob format.



## Revision 127 pressure: fresh object identities versus shared backing versus copy lineage
SlopOS now gives ViewFS another honesty warning adjacent to import-to-docref fresh identity, explicit safe-open export lineage, artifact references, and provider-local object posture: one fresh logical object, one shared-backing optimization, one copy/clone lineage relation, and one current live facet are different truths even when the user experiences them as `the copy I made`.

That strongly suggests ViewFS should keep **fresh object identities**, **shared backing**, **copy lineage**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Linux reflink explicitly shares underlying storage while later writes stay private to the written file;
- Btrfs reflink explicitly says shared blocks do not stop the files from being independent;
- OpenZFS clone concepts keep snapshot origin dependency and clone promotion explicit instead of magical;
- APFS clones make cheap local copies first-class without pretending they are hard links.

That means ViewFS can be ambitious about birth badges, backing ghosts, lineage ladders, and live rails **without** freezing one universal clone ABI, one universal lineage graph, or one final deep-copy/unshare policy.

## Revision 128 pressure: upload sessions versus part coverage versus completion manifests versus committed objects
SlopOS now gives ViewFS another honesty warning adjacent to D-PERSIST, CapStore, CH-AREF, fresh-identity imports, and jobs posture: one upload/resume session, one part/offset progress row, one completion manifest, one committed durable object, one abort/expiry verdict, and one current live facet are different truths even when the user experiences them as `the object is on its way in`.

That strongly suggests ViewFS should keep **upload sessions**, **part coverage**, **completion manifests**, **committed objects**, **abort verdicts**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Amazon S3 multipart upload keeps upload IDs, per-part progress, complete-with-part-list, and abort on different seams;
- tus keeps resumable URLs and offsets on session/progress seams;
- OCI Distribution keeps chunked blob upload explicitly phased;
- Google Cloud Storage keeps resumable session URIs explicit, expiring, and security-sensitive.

That means ViewFS can be ambitious about session beads, part gauges, seal ladders, abort ash, and live rails **without** freezing one universal upload protocol, one universal completion-manifest schema, or one final cleanup model.


## Revision 129 pressure: assembly recipe versus member descriptor versus aggregate object versus realized work surface
Current SlopOS material now makes another seam hard to ignore: one **component/assembly manifest**, one **member/artifact descriptor set**, one **durable assembled object**, one **realized work surface**, one **current live facet**, and one **history row** are different truths.

Useful pressure points:
- `rfcs/0009-component-manifests-and-capability-routing.md` keeps composition intent explicit and reviewable.
- `docs/30-architecture/activation-posture-v0.md` keeps CH-ACTSET descriptive and non-authoritative.
- `rfcs/0038-persistent-object-store-and-snapshots.md` and `rfcs/0065-orthogonal-persistence-and-capstore.md` keep durable store membership and named roots explicit.
- `docs/30-architecture/artifact-reference-schema-v0.md` keeps exact artifact identity separate from retrieval folklore.
- `docs/30-architecture/attestation-pack-schema-v0.md` keeps normalized summary bytes and provider-native evidence separate in one pack.

So ViewFS should keep **assembly recipes**, **member descriptors**, **aggregate objects**, **realized work surfaces**, **live facets**, and **receipts** on different seams while SlopOS itself is still in design.


## Revision 130 pressure: transient staging capsules versus seal states versus courier handoffs versus committed objects
Current SlopOS material now makes another seam hard to ignore: one **transient exact-byte staging capsule**, one **freeze/seal posture**, one **explicit local courier handoff**, one **durable committed object**, one **current live facet**, and one **history row** are different truths.

Useful pressure points:
- `import-to-docref-boundary-v0.md` keeps explicit materialization distinct from bearer restore/import and routine document reopen.
- `import-to-docref-fresh-identity-boundary-v0.md` keeps fresh local identity distinct from same-byte aliasing.
- `artifact-reference-schema-v0.md` keeps exact artifact identity distinct from locator folklore.
- `capstore-commit-schema-v0.md` keeps durable commit meaning explicit instead of ambient.
- Linux staging precedents keep showing that exact bytes, freeze posture, local couriering, and later publication are different classes.

So ViewFS should keep **transient staging capsules**, **seal states**, **courier handoffs**, **committed objects**, **live facets**, and **receipts** on different seams while SlopOS itself is still in design.

## Revision 131 pressure: committed objects versus retention clocks versus hold states versus purge verdicts
SlopOS still does not settle a full retention/immutability family, but its orthogonal-persistence, verified-blob, and receipt-boundary posture already warns ViewFS not to collapse `durably exists`, `kept until later`, `held for some other reason`, `purge blocked or pending`, and `usable now` into one flattering object row.

So ViewFS should keep **committed objects**, **retention clocks**, **hold states**, **purge verdicts**, **live facets**, and **receipts** on different seams while SlopOS itself is still in design.

## Revision 132 pressure: sealed objects versus recipient wraps versus rewrap plans versus unwrap handles
Current SlopOS material now makes another seam hard to ignore: one **sealed object**, one **recipient-wrap roster**, one **rewrap / key-rotation act**, one **provider-bound unwrap handle**, one **current clear facet**, and one **history row** are different truths.

Useful pressure points:
- `rfcs/0067-capability-crypto-services-and-key-handles.md` keeps key use routed through explicit keyrefs and handles instead of ambient secret material.
- `cryptosvc-key-material-boundary-v0.md` keeps ordinary key use separate from secret-bearing key import/export and rewrap folklore.
- `vault-posture-v0.md` keeps provider-owned secret objects explicit instead of ambient.
- `auth-proof-export-boundary-v0.md` keeps local auth ceremonies from silently becoming portable challenge-signing or proof-export folklore.
- JWE, WebCrypto, and Cloud KMS keep sealed payloads, recipient wraps, re-encryption, and current clear authority on different layers.

So ViewFS should keep **sealed objects**, **recipient wraps**, **rewrap plans/receipts**, **unwrap handles**, **clear facets**, and **receipts** on different seams while SlopOS itself is still in design.



## Revision 133 pressure: committed objects versus durability profiles versus redundancy layouts versus repair verdicts
Current SlopOS material now makes another seam hard to ignore: one **committed object**, one **durability profile**, one **redundancy layout**, one **repair verdict**, one **availability state**, one **current live facet**, and one **history row** are different truths.

Useful pressure points:
- `artifact-reference-schema-v0.md` keeps digest identity authoritative while treating locators as non-authoritative hints.
- `capstore-commit-schema-v0.md` keeps durable commit meaning explicit instead of ambient.
- Ceph keeps logical object identity separate from placement and ongoing repair work.
- Tahoe-LAFS keeps k-of-n share thresholds separate from access-control and placement questions.
- Amazon S3 keeps replication posture explicit through asynchronous status rows instead of flattening it into object identity.

So ViewFS should keep **committed objects**, **durability profiles**, **redundancy layouts**, **repair verdicts**, **availability states**, **live facets**, and **receipts** on different seams while SlopOS itself is still in design.

## Revision 134 pressure: committed objects versus archive tiers versus thaw jobs versus thawed copies
Current SlopOS material now makes another seam hard to ignore: one **committed object**, one **archive tier or offline posture**, one **thaw / rehydrate job**, one **temporary or rehydrated readable copy**, one **current live facet**, and one **history row** are different truths.

Useful pressure points:
- `import-to-docref-boundary-v0.md` keeps durable local object birth separate from later routine reopen semantics.
- `import-to-docref-fresh-identity-boundary-v0.md` keeps fresh local object identity separate from same-byte alias folklore.
- `capstore-commit-schema-v0.md` keeps durable commit meaning explicit instead of ambient.
- `lease-descriptor-state-boundary-v0.md` keeps issued evidence weaker than current live/openability truth.
- The broader object-store ecosystem keeps showing that archived/offline posture, thaw progress, temporary readability, and current live authority are different classes.

So ViewFS should keep **committed objects**, **archive tiers**, **thaw jobs**, **thawed copies**, **live facets**, and **receipts** on different seams while SlopOS itself is still in design.


## Revision 135 pressure: committed objects versus residency profiles versus placement realms versus route endpoints versus egress gates
Current SlopOS material now makes another seam hard to ignore: one **committed object**, one **residency profile**, one **placement realm**, one **route endpoint**, one **egress gate**, one **current live facet**, and one **history row** are different truths.

Useful pressure points:
- `cluster-map-schema-v0.md` keeps cluster partition and locality description explicit, derived, and non-authoritative.
- ADR-0006 replication contracts keep cross-cluster ownership and replication class explicit instead of ambient.
- `artifact-reference-schema-v0.md` keeps exact artifact identity separate from locator folklore.
- `capstore-commit-schema-v0.md` keeps durable commit meaning explicit instead of ambient.
- The broader object-store ecosystem keeps showing that residency policy, actual placement, request routing, and egress posture are different classes.

So ViewFS should keep **committed objects**, **residency profiles**, **placement realms**, **route endpoints**, **egress gates**, **live facets**, and **receipts** on different seams while SlopOS itself is still in design.

## Revision 136 pressure: committed objects versus access propagation versus public cache copies versus cache trails
Current SlopOS material now makes another seam hard to ignore: one **committed object**, one **access-propagation state**, one **public cache visibility story**, one **cache trail**, one **current live facet**, and one **history row** are different truths.

Why this lines up with current SlopOS direction:
- `artifact-reference-schema-v0.md` already keeps exact artifact identity separate from retrieval/runtime folklore.
- `approval-basis-posture-v0.md` already refuses to turn one approval into a portable permission cache.
- multiple auth/export boundary notes already refuse to let provider-local cached state turn into platform truth.
- `cache-topology-authority-boundary-v0.md` is already blunt that cache facts are hints, not authority.

So ViewFS should keep **committed objects**, **access propagation**, **public cache copies**, **cache trails**, **live facets**, and **receipts** on different seams while SlopOS itself is still in design.


## Revision 137 pressure: committed objects versus prefix projections versus folder resources versus listing snapshots
Current SlopOS material now makes another seam hard to ignore: one **committed object**, one **prefix/folder projection**, one **provider folder resource**, one **listing snapshot**, one **published name / room bind**, one **current live facet**, and one **history row** are different truths.

Why this lines up with current SlopOS direction:
- `capshell-cwd-root-posture-v0.md` already treats process-local roots as explicit setup, not as folklore inherited from provider naming.
- `capshell-handle-table-posture-v0.md` already treats live authority tables as explicit runtime state rather than ambient browse results.
- `attrfs-posture-v0.md` already points toward shell/view-owned query and collection surfaces instead of pretending every browse grouping is a durable object.
- `document-portal-posture-v0.md` and `import-to-docref-boundary-v0.md` already keep mediated import/localization separate from routine naming and reopen.
- The broader object-store ecosystem keeps showing that flat prefixes, simulated folders, managed folders, and room-local bindings are different classes.

So ViewFS should keep **committed objects**, **prefix projections**, **provider folder resources**, **listing snapshots**, **published names / binds**, **live facets**, and **receipts** on different seams while SlopOS itself is still in design.

## Revision 138 seam: launch view plan / bound root / handle slot table / portal import ticket / live bind / receipt

Current SlopOS material already gives ViewFS strong negative guidance for this seam:

- `capshell-handle-table-posture-v0.md` says the child table is exact and does not inherit ambient parent descriptor state by default.
- `capshell-cwd-root-posture-v0.md` says CH-CWD selects bound root authority instead of an advisory host path string.
- `capshell-filesystem-posture-v0.md` says capshell launch has no hidden reviewed `open(path)` / host filesystem authority surface.
- `portal-design-playbook.md` says portal grants return capability handles, while request/session/control state and receipts stay separate.

ViewFS should therefore treat a future SlopOS process namespace as an explicit assembly of bound roots and slots, not a prettier name for host `/`, parent fd inheritance, or portal-session folklore. The corresponding ViewFS docs are `rfcs/0125-viewfs-keep-launch-view-plans-bound-roots-handle-slots-portal-import-tickets-live-binds-and-receipts-separate.md`, `docs/30-architecture/launch-view-plans-bound-roots-handle-slots-portal-import-tickets-live-binds-and-receipts.md`, and `docs/70-shell/slot-maps-root-badges-import-tickets-and-live-bind-rails.md`.

## Revision 139: capability-flow/custody seam

Fresh read of the supplied SlopOS materials, especially the separate SlopOS rev0695 archive, suggests another ViewFS seam:

**current handle inventory versus custody chain versus outflow gate versus redacted flow snapshot/diff versus leak verdict versus live export/proxy/borrow versus durable receipt/history.**

SlopOS sources to align with:

- `docs/30-architecture/capability-graph-schema-v0.md` — bounded, redacted graph snapshots for debug/audit/leak investigation;
- `docs/30-architecture/capability-diff-schema-v0.md` — bounded, redacted authority-change diffs;
- `docs/30-architecture/capability-export-schema-v0.md` — explicit export descriptors and proxy-first posture;
- `docs/30-architecture/capability-wallet-schema-v0.md` — non-authoritative wallet summaries;
- `docs/60-engineering/portal-design-playbook.md` — handles-not-paths, default-deny, no-amplification, transcriptable grants;
- `docs/30-architecture/capshell-handle-table-posture-v0.md` and related capshell posture notes — shell-visible handle tables rather than process folklore.

What ViewFS should steal:

- bounded/redacted authority snapshots for debugging and consent;
- authority diffs before/after launch/import/export;
- explicit proxy/borrow/direct/materialize distinctions;
- wallet/receipt summaries that cannot be exercised as authority;
- leak verdicts that test behavior without becoming enforcement themselves.

What ViewFS should not freeze yet:

- SlopOS's exact graph/diff/export/wallet schema names as the final ViewFS object-store ABI;
- one universal passability rule for every handle family;
- one final provider-token or portable-capability format;
- one visual flow graph that implies authority transfer by dragging/copying;
- any habit of treating receipts, paths, or permission rows as live handles.


### 64. ViewFS should treat SlopOS CapStore as durable-root pressure, not as a final restore ABI

Current SlopOS material gives ViewFS a strong new seam: `capstore-commit-schema-v0.md` records root updates, parents, epochs, artifact refs, signatures, and durable capability entries, while `view-namespace-posture-v0.md`, `capshell-cwd-root-posture-v0.md`, `capability-wallet-schema-v0.md`, `keyref-schema-v0.md`, and `secretref-schema-v0.md` keep live namespace authority, cwd/root binding, wallet explanation, and secret/key references on different surfaces.

ViewFS should preserve that split by treating:

- durable root commits,
- epoch fences / root-tip witnesses,
- restore intents,
- resurrection gates,
- activation targets,
- current live binds / handle sets,
- and receipts

as different classes.

What to steal from SlopOS:
- durable authority is explicit and optional;
- root commits are content/evidence objects, not ambient handles;
- root epochs make rollback visible;
- durable refs are typed descriptors, not raw live handle bytes;
- wallets and cap graphs explain authority but do not carry it;
- cwd/root posture is handle-first and non-escaping.

What not to freeze yet:
- one universal ViewFS CapStore schema;
- one universal persistence profile;
- one universal resurrection gate;
- one final relationship among CapStore, D-NS, portals, and ViewFS object roots.

## Revision 141 seam: GC roots, live-handle roots, pins/holds/leases, sweep candidates, finalizers, collected ash, live facets, and receipts

Current SlopOS pressure:

- `rfcs/0065-orthogonal-persistence-and-capstore.md` makes persistence explicit authority and names GC-root representation versus privacy/accountability as an open problem.
- `docs/30-architecture/capstore-commit-schema-v0.md` keeps durable root commits, parents, epochs, artifacts, and durable caps explicit.
- `docs/30-architecture/capability-lease-posture-v0.md` keeps temporary proxy authority bounded and transcriptable.
- `docs/30-architecture/lease-descriptor-state-boundary-v0.md` keeps historical lease descriptors weaker than current provider-owned live state.
- `rfcs/0038-persistent-object-store-and-snapshots.md` keeps snapshot/clone/persistent-object-store options open and user-space.

ViewFS import:

- keep retention roots separate from current live authority;
- keep runtime liveness roots separate from durable roots;
- keep pins/holds/leases explicit and releasable;
- keep sweep dry-runs weaker than deletion;
- keep finalizers as cleanup barriers rather than secret roots;
- keep ash/tombstone receipts from resurrecting bytes or handles.

Non-import:

- do not adopt CH-CAPSTORE as the final ViewFS root/GC schema yet;
- do not require one universal GC root database;
- do not make receipts, wallet rows, capability graphs, search indexes, or cache trails roots by default;
- do not let a provider-local currentness/lease state become a portable ViewFS status oracle without a later seam.

## Revision 142 seam: D-QUAR, safe-open capsules, residue, derived artifacts, and trust clearances

The current SlopOS archive has unusually strong posture around risky imported content. ViewFS should steal the **anti-laundering seam**, not a final schema.

SlopOS signals worth carrying forward:

- `quarantine-posture-v0.md` pins quarantine as monotonic, object-local, manual-only to clear, and not mutated by safe-open success;
- `import-to-docref-boundary-v0.md` and `import-to-docref-fresh-identity-boundary-v0.md` keep explicit bearer/import handoffs from becoming trusted docrefs or same-hash trust reuse;
- `open-untrusted-materialization-boundary-v0.md` keeps safe-open as resolve-once stable materialization, not a live source alias;
- `open-untrusted-active-content-boundary-v0.md` keeps document-embedded active content inert by default;
- `open-untrusted-viewer-residue-boundary-v0.md` keeps MRU, thumbnails, autosave, crash recovery, and similar residue outside durable host state unless explicitly exported;
- `quarantined-content-index-boundary-v0.md`, `quarantined-derived-attribute-boundary-v0.md`, `quarantined-derived-match-boundary-v0.md`, and `quarantined-result-preview-boundary-v0.md` keep content-derived semantics from laundering the source through search, summaries, embeddings, or preview snippets.

ViewFS consequence: origin evidence, quarantine marks, safe-open capsules, viewer residue, derived artifacts, trust clearances, live opens, and receipts should be rendered as distinct truths in both object-store state and shell UX.

## Revision 143 seam: container envelopes versus member claims versus extraction plans versus namespace commits

The included SlopOS archive gives ViewFS a nearby warning even without freezing a ViewFS archive ABI:

- `quarantine-posture-v0.md` keeps risky origin state object-local and monotonic;
- `open-untrusted-materialization-boundary-v0.md` keeps safe-open materialization stable and request-local;
- `open-untrusted-viewer-residue-boundary-v0.md` keeps residue disposable-local unless exported;
- `quarantined-content-index-boundary-v0.md` blocks ambient indexing/extraction from quarantined bytes;
- `capshell-cwd-root-posture-v0.md` explicitly rejects `..`, absolute paths, and symlink escapes against an ambient root for compat path resolution;
- `artifact-reference-schema-v0.md` keeps artifact references and digest evidence separate from retrieval/runtime authority.

ViewFS should import that posture into archive/container handling: **container envelope**, **member claim**, **extraction plan**, **sterile materialization root**, **extracted member capsule**, **namespace commit**, **live open/mount**, and **receipt/history** are different truths. This is especially important because archive member names, symlink targets, hardlinks, device nodes, platform metadata, whiteouts, and duplicate entries all look like filesystem facts but arrive as untrusted container claims.

What to steal:
- safe-open/materialization remains request-local until adopted;
- quarantine follows extracted members unless a distinct trust decision clears it;
- path escape and link escape are explicit verdicts;
- object birth is fresh and receipted;
- namespace publication is a second act.

What not to freeze yet:
- a universal ViewFS archive format or parser ABI;
- one universal treatment of symlinks/hardlinks/devices/xattrs/whiteouts;
- one final OCI/package/bundle story;
- one final lazy-mount versus eager-extract decision;
- one final unpack receipt schema.

## Revision 144 seam: supply-chain evidence versus admission versus live authority

SlopOS already contains a rich cluster around this problem: `sbom-posture-v0.md`, `vex-posture-v0.md`, `artifact-reference-schema-v0.md`, `artifact-resolution-posture-v0.md`, `sbom-vex-evidence-set-boundary-v0.md`, `verification-material-discovery-boundary-v0.md`, `verification-policy-selection-boundary-v0.md`, `verification-verdict-boundary-v0.md`, and the attestation boundary notes.

The lesson for ViewFS is not **copy the whole supply-chain subsystem now**. It is narrower and more important: keep digest-bound evidence, imported locator fields, vulnerability statements, verifier policy selection, verifier-local matching, local verdicts, activation, live authority, and receipts as separate seams.

Mapping to ViewFS:

- SlopOS CH-AREF digest binding maps to ViewFS artifact envelopes and evidence packs.
- SlopOS CH-SBOM/CH-VEX maps to ViewFS inventory/advisory claim sets, not to namespace authority.
- SlopOS artifact-resolution posture maps to ViewFS portal-mediated fetch/import, not ambient URL or file dereference.
- SlopOS verification verdict boundaries map to ViewFS local admission cuts, not global trust.
- SlopOS document-supersession and evidence-set boundaries warn ViewFS not to make adjacency, latest-wins, or bundle membership mean applicability closure.

## Revision 145 seam: D-APPSECRET / capshell credential posture into ViewFS secret slots

The included SlopOS archive gives ViewFS unusually direct pressure here:

- `app-secret-posture-v0.md` says D-APPSECRET is a minimal app-scoped seed seam, not a vault or named secret inventory;
- `app-secret-descriptor-schema-v0.md` keeps a redaction-safe descriptor separate from authority;
- `appsecret-secret-ingress-boundary-v0.md` blocks caller-supplied password/API-key/OAuth-token import from becoming `portal.secret`;
- `capshell-env-baseline-posture-v0.md` and `capshell-env-startup-posture-v0.md` keep child environments exact rather than host-injected;
- `capshell-credential-baseline-posture-v0.md` prevents ambient caller identity or group/token inheritance from becoming workflow meaning;
- auth-export boundaries keep authorization context, auth proof, auth result, identity claim, account binding, login state, and teardown control separate.

ViewFS consequence: secret descriptors, prompts, delivery slots, environment shadows, redaction lenses, renewal leases, live-use handles, residue markers, and receipts should render as distinct truths. The custom shell can be delightful about secrets only if it refuses to call env strings, masked logs, old prompts, or receipts `current access`.

What to steal:

- minimal descriptor-first secret requests;
- handle/file/slot delivery before env-string compatibility;
- exact launch environments rather than hidden baseline injection;
- no portable auth-result/account/identity export by adjacency;
- transcript-visible rotation/renewal/reacquire lanes;
- secret-derived residue as an explicit cleanup/audit problem.

What not to freeze yet:

- one ViewFS vault API;
- one token broker;
- one password-manager story;
- one env projection policy;
- one terminal redaction metadata protocol;
- one answer for how secret-derived semantic artifacts participate in object-store GC.

## Revision 146 seam: SlopOS D-LEASE / revocation epochs into ViewFS delegation wavefronts

SlopOS gives ViewFS unusually direct guidance here:

- `capability-lease-posture-v0.md` says a lease proxy is the authority, not a hint; CH-CAPLEASE-like descriptors are evidence, not authority; raw-cap export is forbidden in v0; renewal needs explicit renewal authority; time is not ambient authority.
- `rfcs/0019-revocation-epochs-and-indirection.md` keeps epoch/generation checks and revocable forwarders separate, and explicitly warns that revocation is not free.
- `rfcs/0007-membranes-sealers-and-auth-agents.md` keeps membranes/revocable forwarders as user-space ecosystem primitives rather than privileged-core magic.
- `sturdyref-posture-v0.md`, `capability-export-schema-v0.md`, and wallet posture keep bearer restore/export material out of routine receipts and summaries.
- Recent OAuth/MCP token exchange and revocation boundaries keep provider-local token-shaping/revocation from becoming portable delegation, impersonation, connected-account, or disconnect truth.

ViewFS consequence: delegation intents, attenuation envelopes, membrane leases, delegated handles, revocation requests, revocation wavefronts, stale brakes, renewal controls, live authority, and receipts should render as different truths. The custom shell can say `share`, `revoke`, and `who still can?` only if it refuses to overclaim global knowledge or undo effects that already happened.

Steal carefully:

- proxy-as-authority lamps;
- epoch/generation mismatch stale brakes;
- descriptor-is-evidence badges;
- explicit renewal authority;
- bearer-material redaction and digest-only wallet surfaces;
- provider-local revocation humility.

Do not steal yet:

- a global derivation tree as ViewFS's only answer;
- OAuth revocation as a universal disconnect ledger;
- UCAN/macaroon caveats as the final policy language;
- one recipient inventory graph that leaks more than users intended.

## Revision 147 seam: SlopOS observation / inspect / trace / peer-inspection posture into ViewFS inspection lenses

The included SlopOS archive gives ViewFS unusually direct diagnostic pressure:

- `capshell-peer-inspection-posture-v0.md` rejects ambient same-principal dumpability/debug attach as a launch baseline.
- `inspect-snapshot-schema-v0.md` keeps structured diagnostics bounded, canonical, and redaction-aware.
- `observation-export-policy-schema-v0.md` and `observation-export-posture-v0.md` keep observation export policy-owned and minimized.
- `tracepoint-descriptor-schema-v0.md` and `trace-processing-schema-v1.md` separate tracepoint descriptors, field redaction classes, predicates, processors, bounds, and output discipline.
- `microvm-debug-introspection-posture-v0.md` refuses to make host-side debug sockets, guest memory dumps, or vmcore export a portable Phase 1 contract.

ViewFS consequence: inspection intents, target locators, namespace snapshots, handle/fd peeks, memory/core captures, trace probes, debug controls, redaction/export cuts, live inspection authority, and receipts should render as different truths.

What to steal:

- bounded, canonical, redaction-aware snapshots;
- no ambient same-principal peer inspection by launch inheritance;
- trace descriptors with field-level redaction;
- sandboxed/limited trace processing rather than privileged in-kernel or in-provider scripts by default;
- explicit observation export policy;
- microvm/host debug non-portability as a warning label.

What not to freeze yet:

- CH-INSPECT or CH-TRACE as the final ViewFS ABI;
- a portable debugger attach surface;
- a portable core/vmcore export contract;
- one support-bundle schema;
- one rule for how much process/handle graph structure ordinary users can see.

## Revision 148: borrow SlopOS D-NETLEASE caution without freezing its schema

The included SlopOS datacube already has unusually detailed D-NETLEASE material: CH-NETREQ / CH-NETLEASE, resolver binding, request identity, local-egress, proxy, DNS-query, name-context, name-normalization, service-binding, address-selection, TLS verifier, client cert, application protocol, server-name, session-resumption, and transport-profile boundaries.

ViewFS should steal the organizing lesson: **network requests, name/designator interpretation, resolver witnesses, lease descriptors, portal-owned live state, connection/stream state, local exposures, egress/import cuts, and receipts are separate seams**.

ViewFS should not yet import the exact SlopOS schemas, ACP conflict keys, or Phase 1 network stack assumptions. SlopOS is still in design, and ViewFS has its own object-store/import/shell pressures. The low-regret shared vocabulary is enough for now.
## Revision 149: borrow SlopOS service-binding caution without freezing a service substrate

The included SlopOS archive already warns ViewFS about this seam from several directions: D-NETLEASE service-binding and name-context boundaries, DNS-query/resolver boundaries, DID service-entry import boundaries, MCP resource/tool catalog posture, artifact-reference locator boundaries, and capshell launch/env exactness.

ViewFS should steal the organizing lesson: **service designators, discovery authority, discovery snapshots, readiness evidence, binding cuts, activation targets, live service handles, advertisement/publication rows, and receipts are separate seams**.

Mapping to ViewFS:

- SlopOS service-binding/name-context pressure maps to ViewFS service designators and discovery snapshots, not live authority.
- SlopOS D-NETLEASE maps to possible network-backed discovery/bind routes, not a final ViewFS service ABI.
- SlopOS DID service import boundaries map to ViewFS imported service metadata remaining resolver/provider-local evidence.
- SlopOS MCP/resource/tool catalog pressure maps to ViewFS catalog rows and candidate sets, not automatic tool invocation.
- SlopOS capshell exact launch posture maps to ViewFS avoiding hidden service directories in child namespaces.

What not to freeze yet:

- CH-NETREQ/CH-NETLEASE as the native ViewFS service schema;
- DID/MCP/Kubernetes/xDS/DNS-SD as the native discovery substrate;
- one service identity or readiness vocabulary;
- one route-warming or socket-activation protocol;
- one rule that service discovery belongs under networking rather than portals, object store, launch, or a future service-capability family.


## Revision 151 seam: content addresses, equality witnesses, dedup hints, convergence domains, cache hits, materialization, live facets, and receipts

ViewFS should treat SlopOS's current storage and isolation posture as a warning against a global digest myth.

Useful sibling-cube pressure:
- `import-to-docref-fresh-identity-boundary-v0.md` refuses to let same bytes/dedup collapse a fresh local object identity.
- `open-untrusted-export-lineage-boundary-v0.md` insists on explicit immediate parent/origin linkage instead of inferring lineage from path or byte equality.
- `verified-blob-descriptor-schema-v0.md` keeps Merkle verification descriptors non-authoritative: audit/binding/debug material, not access or mount authority.
- `artifact-reference-schema-v0.md` makes locators hints and content identity exact for that artifact-reference lane, not universal ViewFS identity.
- `microvm-memory-dedup-posture-v0.md` refuses a portable `mem-merge` / KSM plane because content-based merging is density/isolation/side-channel sensitive.
- `quarantined-content-index-boundary-v0.md` refuses ambient content-derived extraction from quarantined bytes.

Low-regret ViewFS takeaway: storage reuse may happen below the object boundary, but the shell/API must keep content addresses, equality profiles, dedup eligibility, convergence/privacy domain, cache/membership observation, proof-of-possession, materialization, live facet, and receipt/history separate.


## Revision 152 semantic derivation / retrieval-store seam

SlopOS contributes direct pressure here through `quarantined-content-index-boundary-v0.md`, `quarantined-derived-attribute-boundary-v0.md`, and `quarantined-result-preview-boundary-v0.md`: risky bytes do not enter ambient OCR/full-text/embedding/summary extraction, explicit analysis yields separate derived artifacts, and result rendering stays metadata-safe until an explicit open/review step.

ViewFS should generalize the lesson beyond quarantine: semantic extraction intent, source input capsule, model/extractor profile, derived artifact, index/store row, query scope, result projection, answer/suggestion card, live authority, and receipt/history remain separate even for cleared material.
## Revision 153 instruction / context / toolcall seam

SlopOS's D-LLM and MCP boundary family gives ViewFS a strong sibling-cube warning: text is proposal-only. MCP prompts/resources/tools/completions/sampling/tasks/logging/roots can help import context and capabilities, but SlopOS keeps them provider-local unless explicit validators, portals, or policy seams admit them.

ViewFS should map that pressure into a shell-visible split:
- instruction source records;
- trust/priority labels;
- context frames;
- model/prompt execution profiles;
- proposal text;
- typed action plans;
- tool invocation candidates;
- approval/adoption cuts;
- current live authority;
- result/observation lanes;
- receipts/history.

Do not copy a final CH-ACP or D-LLM ABI into ViewFS yet. Steal the anti-collapse rule and the evidence vocabulary.

### 0d. ViewFS should keep volition evidence separate from approval and live authority

Use:
- `rfcs/0039-volition-tokens-and-trusted-ui-path.md`
- `docs/30-architecture/volition-posture-v0.md`
- `docs/30-architecture/powerbox-posture-v0.md`
- `docs/30-architecture/tool-ui-authority-boundary-v0.md`
- `docs/30-architecture/llm-elicitation-boundary-v0.md`
- consent / explain / receipt boundary docs in the included SlopOS archive

Implication:
- SlopOS already treats CH-VOL-like material as fresh local one-shot evidence, not a portable grant;
- ViewFS should keep consent candidates, canonical summaries, presentation surfaces, trusted-path posture, gesture evidence, volition witnesses, approval cuts, live authority, outcomes, and receipts separate;
- shell chrome should say `shown`, `trusted-path`, `gesture`, `volition`, `approved`, `live`, `denied`, or `receipt only` instead of one generic `user approved` badge;
- final UI-root, token, signature, accessibility, and headless approval profiles remain future seams.
