# Authority-core stamps, descriptive review envelopes, explain sidecars, live binds, and receipts

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports.
That combination gets easier to evolve if we keep one more seam sharp early:
**the stable review stamp we gate on**, **the richer descriptive review envelope**, **one or more explain sidecars**, **the current live bind**, and **the durable receipt/history row** are not the same truth.

This matters because design-phase systems often drift toward one flattering wallet/card/import-record object that tries to do everything:
- stable review key,
- rich human-readable context,
- graph/diff/provenance explanation,
- current power,
- and historical memory.

That collapse feels convenient at first and then makes drift, reconsent, audit, repair, and UI honesty much harder.

## Keep these classes separate
- **authority-core stamp** — the smallest stable digest or comparison key used for review, drift checks, and reconsent posture
- **descriptive review envelope** — a richer human-facing record that may contain labels, issuance time, source route, issuer notes, or volatile context
- **explain sidecar** — graph/diff/basis/provenance material that helps explain why the review envelope looks the way it does
- **live bind** — the current actual room/session/process authority surface that exists here now
- **receipt/history row** — durable evidence that something was reviewed, issued, rebound, denied, repaired, or retired

Do **not** let the descriptive envelope or the explain sidecar impersonate the live bind.
Do **not** let one full rich envelope digest pretend to be the smallest stable review key.

## Why this is a low-regret lesson
Several ecosystems reward a smaller stable core plus richer descriptive envelope:
- Git patch-id gives one reasonably stable patch-shaped key without pretending it is the whole commit object.
- OCI descriptors keep exact content truth in a compact required core while annotations and URLs stay optional/descriptive.
- in-toto statements keep subject digest truth distinct from contextual names and the broader predicate.
- SLSA provenance is useful explanatory/verifiable metadata, but it is not the artifact or the live authority.

That is exactly the pattern ViewFS wants while it is still deciding its object families, handle carriers, and shell protocol.

## SlopOS alignment
This fits current SlopOS especially well:
- `wallet-posture-v0.md` makes `wallet_core_digest` the only stable binding key.
- `capability-wallet-schema-v0.md` keeps wallets descriptive/review-oriented rather than live authority.
- `capability-graph-schema-v0.md` and `capability-diff-schema-v0.md` give graph/diff explainability their own digests.
- `lease-descriptor-state-boundary-v0.md` keeps issued evidence distinct from current live state.

So ViewFS does **not** need to decide now whether every family has one stable review stamp, whether all sidecars share one schema, or whether envelopes are stored centrally.
It only needs to keep stable review keys, rich review envelopes, explain sidecars, live binds, and receipts from collapsing together.

## What to steal
- **authority-core stamps** for `same reviewed core`, `core changed`, `correlation only`, or `unknown`
- **envelope drawers** that show volatile fields without letting them churn the stable gate key
- **sidecar lamps** for `graph attached`, `diff attached`, `basis attached`, `provenance attached`, or `none`
- **live rails** that say `bound here`, `bound elsewhere`, `not bound`, `history only`
- **repair ladders** that keep `accept same core`, `re-review envelope`, `open diff sidecar`, and `rebind live` visibly different

## What not to freeze yet
- one universal authority-core digest family
- one universal descriptive-envelope schema
- one universal explain-sidecar taxonomy
- whether live binds always point to one envelope row or may be independently materialized
- whether stable review stamps live inside the object store, a wallet family, receipt rows, or multiple adjacent carriers
