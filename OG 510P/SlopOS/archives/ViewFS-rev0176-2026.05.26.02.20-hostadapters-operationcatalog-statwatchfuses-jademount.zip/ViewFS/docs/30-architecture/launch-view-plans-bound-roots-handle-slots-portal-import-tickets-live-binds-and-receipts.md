# Launch view plans, bound roots, handle slots, portal import tickets, live binds, and receipts

Revision: rev0138  
Date: 2026-05-13

## Purpose

This note keeps the ViewFS/SlopOS datacube design phase disciplined around one seam that can otherwise collapse too early: launching a process or importing an outside object into an explicit namespace.

The safe move is not to choose the final object-store ABI, handle encoding, namespace language, or portal protocol yet. The safe move is to preserve separations that past systems repeatedly prove are load-bearing.

## Why this belongs in ViewFS

ViewFS wants folder-like pleasantness over an object-store/datacube substrate, but folder-like pleasantness is not enough. The user-facing shell will eventually need to answer questions such as:

- What did I plan to give this helper?
- What did the helper actually receive?
- Which root is its `/`?
- Which live handles are in its slot table?
- Which portal import is merely pending or granted-but-not-bound?
- Which object is committed, staged, or only listed?
- Which receipt explains history but no longer confers power?

Those answers must not be recovered from folklore. They should be first-class, separately rendered truths.

## The six-way split

| Class | What it means | What it is not |
|---|---|---|
| Launch view plan | Reviewable proposed shape for a subject before launch/import completion. | Not live authority. |
| Bound root / namespace | Actual root-like authority installed for one subject. | Not a machine-global filesystem root. |
| Handle slot table | Exact live handles/descriptors/resources delivered to the subject. | Not stable object identity by itself. |
| Portal import ticket | Mediator-owned request/session/control state around a chooser/import. | Not imported object identity or durable reopen authority by default. |
| Live bind / live facet | Current usable authority here and now. | Not a plan, listing row, ticket, or receipt. |
| Receipt / history | Durable explanatory record of plan/grant/bind/deny/revoke/failure. | Not authority resurrection. |

## SlopOS pressure already visible

The included SlopOS design archive is especially useful because it already refuses several dangerous defaults:

- **Exact child handle tables:** CH-STDIO and CH-FDSET describe the child table; ambient parent descriptors are not the baseline.
- **Bound cwd roots:** CH-CWD names bound authority; it is not a host path hint.
- **No hidden host filesystem promise:** capshell launch does not mint a reviewed `open(path)` authority surface.
- **Portal grants return handles:** request/session/control state does not itself become durable authority.

ViewFS should align with those choices without copying SlopOS-internal names as a final ABI. The key is the split, not the spelling.

## External lessons worth stealing

### Fuchsia: root is per subject

Fuchsia-style component namespaces are the strongest clean example for ViewFS: a namespace is assembled for a component and backed by handles/capabilities, rather than assumed to be one global `/`. The steal is not the exact routing syntax. The steal is the habit of treating each process's view as an explicit assembled object.

ViewFS idea: every launch gets a **root badge** saying whether it is synthetic, empty/sealed, provider-backed, object-store-backed, compat-backed, or history-only.

### Capsicum and WASI: slots/preopens are authority

Capsicum and WASI both pressure ViewFS toward exact live resource sets. A child process should have the descriptors/preopens/resources it was intentionally given. Rights should narrow authority; borrowed/owned/leased posture should be visible; a string is not the grant.

ViewFS idea: render a **slot map** with rights chips, lease chips, own/borrow chips, provider chips, and receipt links.

### XDG Documents: portal stores are mediation layers

The Documents portal is a useful analogy precisely because a document-store ID, FUSE-visible path, app permission, host path, and deletion/revocation behavior are not the same class. ViewFS should copy the separation, not the exact desktop implementation.

ViewFS idea: an **import ticket tray** with `pending`, `needs-user`, `granted-not-bound`, `adopted`, `denied`, `expired`, and `revoked` states.

### Tahoe-LAFS and Cap'n Proto: capability flavors and tables are powerful

Tahoe-LAFS shows that read/write/verify capability flavors can be explicit and useful. Cap'n Proto shows that a message or connection can carry a separate capability table rather than flattening references into raw values. ViewFS should steal the clarity of capability classes and tables while avoiding one universal stringly capability mythology.

ViewFS idea: live facets should say `inspect`, `verify`, `read`, `edit`, `publish`, `delegate`, or `history only`; slot tables can carry local references whose meanings are interpreted in the subject's launch context.

### EROS: persistence changes everything

EROS is a brilliant warning as much as inspiration. Persistent capabilities and single-level stores are powerful, but recovering, checkpointing, revoking, and stabilizing an authority graph are not small details. ViewFS should resist accidentally persisting the whole live capability graph while the datacube is still exploratory.

ViewFS idea: receipts can persist widely; live authority persistence should require an explicit persist/adopt/reopen design, not fall out of serialization.

### Cloud object stores and etcd: currentness witnesses matter

GCS preconditions, Azure ETag/If-Match flows, and etcd transactions show that object mutation needs explicit witnesses. ViewFS should keep generation/revision/currentness facts next to mutation and adoption flows, not hide them behind path strings, import tickets, or old receipts.

ViewFS idea: any `bind adopted object here` action can show the witnessed generation/revision/hash/facet class and whether a compare-before-bind was used.

### S3/GCS/Azure: folder-like is not one thing

S3 prefixes, GCS flat folders/managed folders/HNS folders, and Azure virtual/native directory distinctions all warn that a row that looks like a folder may be a prefix projection, provider folder resource, listing snapshot, published name, or live bind.

ViewFS idea: reuse Revision 137 prefix badges/folder ghosts/list lanterns in launch/import UI so a portal import of a folder-like surface does not become a magical directory by accident.

## Low-regret ViewFS vocabulary

Use these words until a better vocabulary proves itself:

- **view plan**: intended launch/import view;
- **root badge**: what kind of root was actually bound;
- **slot map**: exact live handle/resource table;
- **import ticket**: portal-owned request/session/control object;
- **adoption**: the act of turning a ticket/result into a local bind/staging object/committed object;
- **live rail**: current authority visible in the shell;
- **receipt card**: durable audit/debug record that does not confer power.

## Guardrails

- Do not let a launch plan impersonate actual child authority.
- Do not let a host path string impersonate a handle.
- Do not let a portal request/session impersonate a durable reopen grant.
- Do not let a receipt impersonate a live facet.
- Do not let a slot number impersonate global object identity.
- Do not let a listing row impersonate a current namespace bind.
- Do not let compatibility layers silently rebuild host-global `/`.
- Do not force all objects, folders, imports, and facets into one universal handle kind yet.

## Non-decisions preserved

Revision 138 deliberately leaves open:

- object ID / manifest shape;
- handle-slot encoding;
- rights taxonomy;
- portal-ticket persistence;
- facet granularity;
- import staging layout;
- object-store pack/GC design;
- whether namespace plans are stored as datacube objects, capability descriptors, execution-pack descriptors, or receipts;
- what SlopOS eventually calls the corresponding CapStore/D-NS/D-POWERBOX seams.

## Suggested near-term tests

1. A launch rehearsal can be rendered, but cannot be used to read anything.
2. A launched helper's rendered slot map exactly matches the reviewed plan or the launch fails closed.
3. A portal ticket can expire without leaving a live bind behind.
4. A receipt can be exported and replayed for explanation without reopening authority.
5. A folder-like import can say `prefix projection only` without becoming a native directory.
6. A compatibility helper that asks for host `/` gets a root badge showing the explicit compat membrane, not invisible ambient success.
