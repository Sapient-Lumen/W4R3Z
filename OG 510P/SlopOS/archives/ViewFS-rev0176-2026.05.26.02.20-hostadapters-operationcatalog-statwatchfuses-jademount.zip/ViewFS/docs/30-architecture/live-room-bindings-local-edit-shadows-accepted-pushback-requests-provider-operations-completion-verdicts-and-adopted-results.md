# Live room bindings, local edit shadows, accepted pushback requests, provider operations, completion verdicts, and adopted results

This note sharpens one more low-regret ViewFS separation:
**live room binding**, **editable local shadow**, **accepted request/admission**, **provider operation or completion ticket**, **completion verdict**, **locally adopted result**, and **durable receipt/history** are different truths.

Relevant precedents:
- **REF-RFC9110-202**: `202 Accepted` is intentionally noncommittal and can only point toward later status, not final success.
- **REF-XDG-REQUEST**: a portal request object has its own lifetime and later response path.
- **REF-GCLOUD-LRO**, **REF-GDRIVE-LRO**, and **REF-AIP151-LRO**: long-running work can return an operation resource, and that resource is useful precisely because it stays distinct from final results.
- **REF-AZURE-ASYNC-REQREPLY**: an initial accept, a poll/status endpoint, and a later resulting resource are different seams.
- **SlopOS**: `acp-acceptance-completion-posture-v0.md`, `acp-outcome-receipt-schema-v0.md`, and `background-request-state-posture-v0.md` all reinforce the same discipline: exact request acceptance, current provider-owned live state, and later completion truth must not collapse.

## Why the split matters
The future custom shell is going to host provider-backed edits, queued writes, portal-mediated imports, remote realization work, and delayed publish/sync lanes.
That only stays honest if it can answer at least six different questions:
- what is bound here now?
- what local draft/shadow am I editing?
- was the request merely admitted?
- is there a provider-owned operation or status monitor?
- what later settlement became true, if any?
- what did this room adopt locally afterward?

Those questions differ because the consequences differ.
A live room bind can grant present authority now.
A local shadow can be rich and editable but still private.
An accepted request can be real without promising completion.
An operation ticket can be useful follow-up state without being object identity.
A completion verdict can say what upstream settled without dictating local adoption.
A receipt can explain all of that while authorizing nothing now.

## Working posture

### Live room binds should stay current-state truth
The shell should answer exactly what this room is bound to now.
That must remain separate from any submitted or completed request.

### Local shadows should stay draft-first
A local shadow or sealed candidate should remain inspectable, diffable, and preservable even after a request is accepted or while an operation is pending.
That keeps editing and deferred provider work decoupled.

### Accepted requests should stay admission truth
A room should be able to say:
- `rejected now`
- `accepted and queued`
- `accepted with operation handle`
- `accepted but follow-up unknown`

That is better shell truth than one flattering `saving...` spinner.

### Provider operations should stay follow-up truth
An operation monitor should say:
- `poll here`
- `provider-owned job`
- `watch only`
- `expired handle`
- `no follow-up lane`

That is useful without pretending the operation handle *is* the committed result.

### Completion verdict should stay settlement truth
The shell should be able to say:
- `settled: applied`
- `settled: conflict`
- `settled: superseded`
- `pending`
- `expired`
- `completion unknown`

That is more honest than one universal green checkmark.

### Local adoption should stay explicit
After later settlement, the room should still choose its local consequence explicitly:
- keep draft,
- fast-forward local state,
- fork local state,
- attach receipt only,
- or adopt successor object.

That prevents provider completion from silently rewriting the user's current footing.

## Shell and terminal payoffs
A truthful shell can turn this split into product leverage:
- **accept slips** that distinguish `submitted`, `admitted`, and `rejected now`;
- **operation beads** that show pollable provider follow-up without pretending it is final truth;
- **settle rails** that compare pending, settled, expired, and unknown completion states;
- **adopt rails** that keep local post-settlement choices explicit;
- **expiry lanterns** and **history-only ghosts** when old operation/status references no longer answer current questions.

## Classification worth standardizing early
A useful posture-oriented classification for shell UX and protocol spikes is:
- `draft_only`
- `accepted_no_ticket`
- `accepted_with_ticket`
- `pending_followup`
- `settled_applied`
- `settled_conflict`
- `settled_unknown`
- `adopt_keep_local`
- `adopt_fast_forward`
- `adopt_fork_local`
- `receipt_only`

This is intentionally posture-oriented.
It does **not** decide one final async provider ABI, one final operation-ticket schema, or one final progress-watcher family.

## What not to freeze yet
Do **not** freeze yet:
- one universal `status endpoint` contract,
- whether all providers expose explicit operation IDs,
- whether pending operations are shell-owned or provider-owned objects,
- whether settlement receipts embed final provider metadata or only reference it,
- or one permanent answer to how rooms auto-adopt after later settlement.

The separation is worth freezing now.
The operation protocol and auto-adoption rules are not.

