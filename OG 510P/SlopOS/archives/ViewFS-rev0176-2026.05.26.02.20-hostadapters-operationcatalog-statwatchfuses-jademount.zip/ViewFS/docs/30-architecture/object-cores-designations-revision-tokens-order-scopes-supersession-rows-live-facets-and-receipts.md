# Object cores, designations, revision tokens, order scopes, supersession rows, live facets, and receipts

Purpose: keep **semantic object cores**, **human-facing designations**, **mutable head / revision tokens**, **ordered conflict scopes**, **supersession evidence**, **current live facets**, and **durable receipts/history** on distinct seams.

## The split
- **object core** — the semantic object or lineage we mean to talk about.
- **designation** — the name, alias, path-like publication, docref-like selector, or local label that lets someone point at it.
- **revision token** — one provider/store-local token that says what head/change point was observed or updated.
- **order scope** — the stream or conflict family inside which ordering matters.
- **supersession row** — a durable row saying one head, version, or delete marker displaced another.
- **live facet** — currently usable inspect/read/edit/publish authority.
- **receipt/history** — durable memory of creation, replacement, deletion, and repair.

## Why this must stay split
A modern object store can easily lie by accident:
- one old head token gets mistaken for object identity,
- one current name gets mistaken for the whole version history,
- one supersession row gets mistaken for current power,
- or one ordering token gets mistaken for universal time.

That is exactly the kind of collapse ViewFS should avoid while SlopOS is still in design and while ViewFS itself is still collecting ideas instead of freezing one substrate.

## Lessons worth stealing
### Kubernetes
Kubernetes separates name, UID, `resourceVersion`, watch bookmarks, and limited history windows.
That is a strong reminder that:
- human designation,
- stable object identity,
- current observed head,
- incremental sync position,
- and repair/reset posture
are different truths.

### etcd
etcd goes even further and separates:
- key identity,
- key-local `version`,
- `create_revision`,
- `mod_revision`,
- the cluster-wide revision,
- and lease attachment.

That is a powerful warning not to pick one universal `version` story too early.

### S3 versioning
S3 keeps:
- bucket/key designation,
- opaque version IDs,
- current-version selection,
- delete-marker posture,
- and noncurrent-version retrieval
separate.

That is exactly the shape ViewFS should remember when someone asks for one magical `head handle`.

### Git refs and reflogs
Git keeps:
- object IDs,
- refs that currently name them,
- and reflogs that remember how those refs moved
separate.

That is a fantastic product lesson: current naming and durable history can both be first-class without becoming the same class.

## Design guidance
1. A **designation** should be allowed to stay stable while the winning **revision token** changes.
2. A **revision token** should be allowed to advance while the semantic **object core** stays `same object, newer head`.
3. An **order scope** should be allowed to be narrower or different from object identity.
4. A **supersession row** should be inspectable without being mistaken for current authority.
5. A **live facet** should be visibly stronger than every historical row.

## Shell implications
The shell should be able to render:
- **head badges** (`current`, `noncurrent`, `superseded`, `delete marker`, `history only`),
- **order pips** (`same order scope`, `parallel scope`, `unknown order`),
- **supersession ladders** (`replaced by`, `restored from`, `tombstoned by`),
- **facet rails** (`inspect now`, `read now`, `edit now`, `publish now`, `history only`).

## Non-decisions to preserve
Do not decide yet:
- one universal revision-token carrier,
- one universal order-scope family,
- one universal delete-marker or tombstone form,
- whether supersession rows are provider-owned, shell-owned, or store-owned,
- whether order scopes are always durable or can sometimes be ephemeral review witnesses.
