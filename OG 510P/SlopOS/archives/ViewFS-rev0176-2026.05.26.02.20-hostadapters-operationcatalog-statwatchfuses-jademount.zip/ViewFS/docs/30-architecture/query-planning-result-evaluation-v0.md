# Query, planning, result, evaluation, and scoring v0

Revision 170 adds a query/evaluation slice to the executable ViewFS core. The slice covers retrieval and assessment artifacts that are easy to over-trust in agentic interfaces: saved queries, planner traces, result sets, aggregate cells, evaluation sets, benchmark runs, scoring rubrics, and model-selection cards.

The rule is deliberately narrow:

> Query and evaluation artifacts may select, rank, summarize, measure, and explain. They do not become object authority, raw disclosure authority, deployment authority, or production-readiness authority.

## Record families

| Record family | Purpose | Non-authority warning |
|---|---|---|
| `QuerySpec` | Bounded query request over admitted sources and fields, with optional index-currentness requirements. | A query string, saved query, or result card is not read/search authority. |
| `PlannerTrace` | Evidence about a model/planner-proposed action plan, its proposed rights, approval cut, and hidden-effect posture. | Model proposals and trace summaries do not execute effects. |
| `ResultSet` | Ranked retrieval/search result set with per-member backing-handle information. | Ranked hits, snippets, result ids, and answer cards are not object authority. |
| `AggregationView` | Computed aggregate over a cohort with threshold, raw-row, and membership-oracle posture. | Aggregate cells are not raw rows, object authority, or exact-membership proof. |
| `EvaluationSet` | Assessment input set with holdout, contamination, license, purpose, and authority posture. | Eval-set labels and benchmark names are not production authority. |
| `BenchmarkRun` | Reproducible evaluation record binding run epoch, admitted eval set, rubric, score, and authority. | Scores and leaderboards are not deployment cuts. |
| `ScoringRubric` | Active/current/calibrated scoring scheme with metric-gaming posture. | Rubric text and metric names are not policy authority. |
| `ModelSelectionCard` | Shell/dashboard projection of model tradeoffs, benchmark posture, and deployment warnings. | Cards must not claim deploy authority or production readiness without backing evidence. |

## Checked operations

`admit_query_scope` checks that requested sources and fields remain within admitted bounds, that required index epochs are current, and that a live query/read/search handle exists.

`admit_planner_trace` checks that a planner trace is verified, approved, non-widening, hidden-effect-free, and backed by live planning/invocation authority.

`open_result_member` opens a search result member only through the selected member's backing live handle. Ranked hit rows, ids, snippets, and stale result sets deny.

`render_aggregation_view` renders only when aggregate authority exists, cohort thresholds pass, raw rows are not exposed, and exact membership is not implied.

`admit_evaluation_set` admits an evaluation set only when holdout state, contamination posture, license/purpose clearance, and live evaluation authority pass.

`record_benchmark_run` records a benchmark run only when the run is complete, current, reproducible, and its evaluation/rubric inputs are admitted.

`apply_scoring_rubric` applies only active, current, calibrated rubrics without detected metric gaming.

`render_model_selection_card` renders a model-selection dashboard only when it does not hide tradeoffs or claim deploy/production authority without backing evidence.

## Anti-collapse rule

A query/eval surface is a selector or assessment lens. It can make work faster and reviewable, but it must not smuggle authority through convenience. Future query languages, vector indexes, planner UIs, benchmark dashboards, and model-routing cards must preserve the negative fixtures before adding expressiveness.
