# Classification, license, and purpose bindings v0

Revision 169 adds a compliance-facing slice to the executable ViewFS core. The slice is intentionally small: it does not try to become a legal engine, export-control classifier, or universal policy language. It only prevents common shell and agent mistakes where labels, licenses, purpose statements, and compliance cards are treated as authority.

## Record families

| Record family | Purpose | Non-authority warning |
|---|---|---|
| `ClassificationMark` | A verified mark about an object subject, classifier epoch, conflict state, and classification authority. | A label such as confidential, public, safe, or export-controlled is not read, disclose, export, or release authority. |
| `LicenseTerm` | Machine-readable permissions, prohibitions, obligations, accepted terms, and required live right for an intended use. | A license identifier, SPDX string, or license text does not grant object possession or tool authority by itself. |
| `ComplianceObligation` | Required notice, attribution, audit, watermark, destination statement, or similar artifact that must be produced for a use. | A past receipt or checklist row does not discharge a current obligation unless the checked lane says so. |
| `PurposeBinding` | Allowed purpose, secondary-use posture, retention-budget posture, and live authority needed for a use. | A stated purpose does not authorize processing, training, publication, or export. |

## Checked operations

`evaluate_classification_mark` admits a verified current classification mark only as accounted evidence. It denies label-as-authority attempts, stale classifier epochs, unresolved conflicts, and subject mismatch.

`authorize_license_use` evaluates an intended use against active license terms, prohibitions, accepted terms, required obligations, exact object subject, and live authority.

`enforce_compliance_obligation` checks that required compliance artifacts are present and that the effect has live authority. It denies receipt-only discharge.

`bind_purpose_use` binds a requested use to an allowed purpose, secondary-use approval, active retention budget, and live authority.

## Anti-collapse rule

Classification, license, obligation, and purpose rows are brakes and explainers. They may narrow, require review, force redaction, block use, or explain why a use is allowed. They must not mint authority. A release, training run, export, disclosure, or publication still needs the relevant live handle, approval cut, redaction posture, jurisdiction fence, and current policy decision.

## Specimen pressure

The v0 fixtures intentionally include positive and negative examples for label laundering, SPDX/license-id laundering, missing obligations, prohibited uses, live-authority absence, purpose-statement laundering, secondary-use denial, and retention-budget absence. Any future richer compliance model should preserve these negative cases before adding new expressive power.
