# Quarantine capsules and trust transitions v0

Revision 158 makes foreign-origin content executable in the fixture corpus without treating import as trust. This note covers the first narrow lane only: an object has arrived from outside the current ViewFS trust boundary, and the shell/runtime needs to decide whether it may be opened, viewed, released, or exported.

## Non-collapse rule

Do not collapse these objects:

1. origin locator or origin story;
2. origin evidence;
3. quarantine mark;
4. safe-viewer capsule;
5. scanner/admission verdict;
6. policy cut;
7. trust transition;
8. live handle;
9. export plan;
10. receipt.

The common bug is to let any one of these stand in for the rest. A download receipt is not origin evidence. A URL is not a signature. A clean scan is not a policy cut. A quarantine mark is not a permanent deny. A safe preview is not execute/export authority. A trust badge is not a live handle.

## Minimal records

```text
OriginEvidence(id, source, evidence_class, status, locator?, signature?)
QuarantineCapsule(id, source, origin_evidence, status, safe_viewer_handle?, result_handle?)
TrustTransition(id, capsule, origin_evidence, scanner_verdict, policy_cut, result_handle?)
ExportPlan(id, typed, source, sink, authority_handle, approval_cut, quarantine_clearance?)
Receipt(id, event, subject, outcome, time, basis?)
```

The v0 fixture model deliberately permits two escape hatches and denies the rest:

- a quarantined object may be viewed through a read/inspect-only safe viewer handle;
- a quarantined object may be released only through a trust transition that names verifying origin evidence, clean/admitted verdict, approved policy cut, and a live result handle.

Everything else is blocked until a later profile says otherwise.

## Direct open rule

A direct open of a quarantined object is denied even when the object exists and even when a safe viewer handle exists. The safe viewer handle has a different purpose: it lets the user inspect without collapsing inspection into possession. The fixture `031-quarantine-direct-open-denied.json` makes this denial explicit.

## Safe viewer rule

A safe viewer handle must be read/inspect-only. If the viewer carries write, export, execute, publish, or tool-call effects, it is too powerful to be a quarantine viewer. The v0 checker enforces only the simplest rights subset, but the posture is stricter: safe viewers should also carry residue cleanup, no-script/no-network defaults, and shell-visible virtuality lamps.

The fixture `032-quarantine-safe-viewer-open-allow.json` is a positive specimen for the narrow lane.

## Trust transition rule

A trust transition is a cut, not a vibe. It requires:

- verifying origin evidence, not a summary or receipt;
- clean/admitted scanner verdict;
- approved policy cut;
- live result handle with the requested right.

The positive fixture is `033-trust-transition-release-allow.json`. The negative fixture `034-trust-transition-summary-only-denied.json` blocks a subtle collapse: a summary of origin evidence or old download receipt cannot be treated as verifying origin evidence.

## Export interaction

Quarantine affects export because export is egress. A plan can have a live export handle and still be denied while the source remains quarantined. Fixture `038-export-plan-quarantined-source-denied.json` captures the rule. Fixture `039-export-plan-cleared-source-allow.json` admits export only after clearance, live export authority, sink, and approval cut are all present.

## Shell posture

The shell should render at least five states separately:

| State | Shell label | User meaning |
|---|---|---|
| `quarantined` | foreign / isolated | content exists but normal open/export is blocked |
| `safe-viewer` | inspect-only | can view through a constrained lane |
| `reviewed` | awaiting cut | checks may exist but release is not yet approved |
| `cleared` | admitted | normal live handle may be issued under policy |
| `receipt-only` | history | something happened; no authority follows |

The UI danger is a single green “safe” badge. ViewFS should instead show a chain: origin evidence, scan/admission verdict, policy cut, authority diff, and current live handle.

## Open choices

- Evidence profiles: detached signature, transparency entry, package provenance, notarization ticket, local steward assertion, and bare URL should be separate evidence classes.
- Scanner verdicts: clean, suspicious, policy-denied, unsupported, timeout, and stale should not collapse into one boolean.
- Safe viewer residue: thumbnails, extracted text, temporary render outputs, and derived embeddings need copy-inventory cleanup.
- Multi-party trust transitions: some profiles may need Steward/Ward quorum or organizational policy cuts.
- Offline behavior: stale cached verdicts should degrade to reviewed/quarantined, not silently stay cleared.
