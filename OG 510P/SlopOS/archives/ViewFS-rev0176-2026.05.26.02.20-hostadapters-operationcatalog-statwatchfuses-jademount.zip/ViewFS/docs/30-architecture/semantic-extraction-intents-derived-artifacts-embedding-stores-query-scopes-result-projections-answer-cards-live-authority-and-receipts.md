# Semantic extraction intents, derived artifacts, embedding stores, query scopes, result projections, answer cards, live authority, and receipts

Revision 152 records a new cautionary seam for ViewFS: **semantic derivation is not authority**.

The point is not to block semantic search. The point is to keep it honest enough that a capability-native object store can safely grow rich search, OCR, thumbnails, summaries, embeddings, smart folders, and agent retrieval without rebuilding a host-global file index with better icons.

## Why this belongs in ViewFS now

ViewFS has already separated imports, quarantine, safe-open, archive extraction, supply-chain evidence, secret delivery, revocation, diagnostics, networking, service binding, secure transport, and content-address/dedup hygiene. The next natural pressure is semantic search:

- users want to ask `where was that diagram?`;
- agents want retrieval context;
- shells want smart folders and command suggestions;
- providers want thumbnails, OCR layers, vector embeddings, summaries, and labels;
- object-store implementers want indexes to make immutable objects usable.

The danger is that the semantic layer quietly becomes a second filesystem:

```text
index says hit -> shell displays content -> agent uses content -> user assumes source authority and trust are settled
```

That is exactly the opposite of ViewFS. A search layer should be a scoped derived-view subsystem over explicit handles and explicit imported material, not a hidden authority root.

## The separation to preserve

### Semantic extraction intent

An intent names the requested derivation:

- parse text;
- OCR images/pages;
- create thumbnail;
- summarize;
- classify;
- tag;
- embed;
- chunk;
- transcribe;
- build answer-support bundle;
- add to a project retrieval store.

It should carry purpose, initiator, allowed source handles, trust posture, export posture, budget, and whether outputs may persist.

No background daemon should be able to say `I derived this because the object existed` without some policy lane making that default visible.

### Source snapshot / input capsule

Semantic output must say what it came from:

- source object identity;
- revision/currentness witness;
- byte/range/page/chunk selection;
- representation chosen;
- origin/quarantine/trust state;
- redaction input;
- handle rights at derivation time;
- parent import/extraction/materialization receipt, when relevant.

This keeps `summary of current document`, `summary of old revision`, `summary of quarantined copied snapshot`, and `summary of provider-local resource` from becoming the same artifact.

### Extractor/model profile

The profile names the interpretation machinery:

- parser or format handler;
- OCR engine;
- embedding model and dimension/profile;
- chunker/window/overlap/tokenizer;
- prompt/template/system instruction, if any;
- redaction lens;
- network posture;
- secret/materialization posture;
- deterministic/non-deterministic settings;
- provider or local runtime identity.

A future shell result should be able to say `this match was under model/profile P, before redaction lens R changed` instead of pretending semantic hits are timeless.

### Derived artifact

Durable derived output should be represented separately from the source:

- recognized text;
- thumbnail or preview image;
- transcript;
- summary;
- classifier result;
- entity set;
- tag set;
- embedding vector;
- sparse vector / term row;
- answer-support bundle;
- provenance/citation bundle.

The derived artifact inherits or references risk state. It is not a trust upgrade and not a source-object mutation by default.

### Index/store membership

Membership in an index is a query/storage fact:

- local full-text index;
- project vector store;
- provider-private feature store;
- assistant memory shard;
- thumbnail cache;
- answer cache;
- tenant shard;
- global/public retrieval corpus;
- disposable safe-open-local store.

The membership row should name retention, privacy domain, scope, TTL, cross-principal visibility, and whether hit/miss observations are exposed. It should never be enough to read the source.

### Query scope / authority gate

A query is not simply a string. It has a scope:

- current room/root;
- live handle set;
- selected project/workspace;
- explicit portal-import collection;
- one quarantined derived artifact;
- cleared local objects only;
- provider-local resource set;
- public corpus;
- history-only receipts.

ViewFS should prefer `query within authority I currently hold` over `ask global index then filter`. Metadata filters are useful, but the first question is always authority scope.

### Result projection / ranking evidence

A result projection is what the shell is allowed to show:

- object name and safe metadata;
- match score;
- derived artifact identity;
- snippet/highlight;
- thumbnail;
- page preview;
- answer support quote;
- omitted-content marker;
- redaction decision;
- freshness/model-profile stamp.

Projection is content exposure. It needs its own redaction/rendering posture. It is not a live source handle.

### Answer/suggestion card

Answer cards and suggestions compose material:

- an answer paragraph;
- a proposed command/action;
- a smart-folder summary;
- a citation bundle;
- an agent context pack;
- a `maybe related` recommendation.

The card should be visibly weaker than source authority. It can support a plan; it cannot mutate, open, export, run, or share on its own.

### Current live authority

Actual current authority is still a live ViewFS handle, portal ticket, borrow, proxy, service handle, or explicit source/derived artifact open. If a result card wants to open or export the source, that action crosses back to the authority lane.

### Receipts / history

Receipts record:

- derivation accepted;
- extraction profile used;
- vector row written;
- result displayed;
- answer composed;
- row deleted/unindexed;
- source deleted while derived rows remain pending cleanup;
- projection redacted;
- agent context used.

Receipts are not current memory, not current index membership, and not current source authority.

## Prior-art pressure

- Desktop search reminds us that indexing is a service, not storage itself. Spotlight has user-visible search privacy exclusions; GNOME LocalSearch separates indexer, extractor, control, and writeback services and notes sandbox-friendly segmentation.
- Vector stores remind us that isolation is an explicit design dimension. Pinecone's documentation presents one namespace per tenant for secure tenant isolation; Weaviate stores each tenant on a separate shard for data isolation. Those are not the same as a late metadata filter over a global hit list.
- Embedding research reminds us that vectors can leak content. Treat embeddings as derived sensitive material, not as hashes.
- OWASP's vector/embedding risk category reminds us that retrieval stores can leak sensitive data, be poisoned, or manipulate model outputs.
- SlopOS already has direct boundaries for quarantined content: no ambient full-text/OCR/embedding/summary extraction; no semantic back-write onto risky source objects; no ambient result previews.

## Nifty ideas to steal

- **Semantic derivation cards** that show intent, source snapshot, extractor/model profile, and output class.
- **Embedding vaults** with scope labels: `room-local`, `project`, `tenant`, `provider-opaque`, `disposable`, `public`, `history-only`.
- **Scope gates** that show exactly which live handles, roots, or imported collections were searched.
- **Model-profile chips** for embedding model, chunker, OCR engine, redaction lens, and version freshness.
- **Result shades** for `metadata-only`, `snippet`, `thumbnail`, `quote`, `derived-artifact-only`, `answer-only`, `open-required`.
- **Answer receipts** that say which result projections fed the answer and whether the answer has any live source handle.
- **Unindex ladders** that distinguish `remove vector row`, `delete derived artifact`, `clear answer cache`, `delete source`, and `prove cleanup`.
- **Instruction quarantine rails** that mark retrieved instructions as inert content until a separate action plan adopts anything.
- **Memory shutters** for `do not persist`, `receipt-only`, `room-local`, `project-local`, `provider memory`, and `explicitly exportable`.

## Non-decisions

Still open:

- native versus adapter-owned vector storage;
- one or many embedding profiles;
- model/provider selection;
- exact derived-artifact schema;
- whether embeddings are encrypted, differentially private, local-only, or provider-local;
- how to prove unindex/forget across providers;
- how to handle approximate nearest-neighbor nondeterminism in receipts;
- how much result scoring detail belongs in ordinary shell UI;
- whether answer cards are objects, receipts, notebook cells, or transient panes.

The stable thing is the anti-collapse rule: **semantic derivation should make content more findable and explainable without granting authority, laundering trust, hiding memory, or pretending model output is source truth.**

## Compatibility posture

Legacy file managers, OS indexers, IDEs, AI assistants, and vector DB clients often assume ambient reads over a tree or a global index. A ViewFS compat adapter can support those only through explicit scoped projections:

- no ambient scan outside the process namespace/root;
- no background extraction of quarantined/secret objects unless an explicit lane permits it;
- no provider-global vector query without a scope gate;
- no result preview for content that the current subject cannot open under ViewFS rules;
- no writeback of derived tags/semantic labels onto source metadata by default;
- no hidden agent memory seeded from result cards or old receipts.

## Cross-cube pressure

The included SlopOS archive is the strongest pressure: D-QUAR / D-ATTRFS already identifies background content-derived indexing as a laundering route. The sibling cubes add supporting hints:

- Foundry's semantic-spine style says semantic structure is useful but needs pinned cuts and expiry posture.
- Harbor's cache-epoch posture says cached discovery or schema knowledge is not current admission truth.
- Schell's change-digest cards warn that compact explanations are glance artifacts, not raw streams or authority.
- Helm's surface-core digest posture says portable cores and landing envelopes differ.
- Ward's resolution bindings and correction lineage say repeated answers need provenance and correction posture.

Together they suggest a ViewFS semantic layer that is rich, scoped, lineage-aware, and memory-honest.
