# Object-store posture v0 (immutable first, boring on purpose)

Purpose: keep the backing store small, comprehensible, and decoupled from premature namespace cleverness.

## Posture
1. Phase 1 should prefer **immutable blobs and manifests** over a fully general mutable inode model.
2. Object IDs should name **content** or stable manifest structure, not mutable current state.
3. The store should begin with a **small object vocabulary** and a simple pack/index story.
4. Snapshot roots are welcome; a grand mutable transaction model is not required for Phase 1.
5. Retention should prefer **explicit roots/ledgers** over piggybacking on current room occupancy, current tool attachment, or current published names.
6. Capability persistence should be treated as a higher-risk topic than blob persistence.
7. If early mutable work state is required, prefer an **explicit sidecar/journal/root-pointer model** over making in-place mutation the foundation.
8. The store should not force one universal handle noun; the same underlying object may later be surfaced through multiple **capability facets** with different rights and affordances.
9. Grouped authority kits should remain explicit transport/launch objects rather than becoming the object-store explanation of what the object `is`.
10. Descriptor-only or verify-only object surfaces should stay visibly weaker than read/edit/publish authority; safe proof cards are useful, but they should not silently become byte-I/O or mutation handles.

## Why this cut is worth making
- REF-VENTI and REF-GIT-OBJECTS show how far a small immutable object core can go.
- REF-NIX-CA suggests immutable closures are especially valuable for application/runtime roots.
- REF-NIX-GCROOTS is a useful reminder that survivability should hang off explicit roots rather than current attachment folklore.
- REF-EROS and REF-KEYKOS warn that persistent authority edges complicate stabilization quickly.
- REF-IPFS-MFS and REF-SQLITE-SESSION suggest a promising split between immutable base objects and explicit mutable overlays or journals.

## Open questions
- hash algorithm choice
- pack/index layout
- metadata normalization format
- garbage collection / retention policy
- manifest granularity
- whether mutable work state wants tree-level changesets, journaled root updates, or something else entirely
- whether Phase 1 exposes retention roots directly to users, shells, or only to adjacent services
- whether facet handles are minted as distinct first-class objects, derived wrappers over one base handle, or a mix
- whether some facets should be opaque/sealed by construction rather than stringly recoverable
- whether any object families want a first-class verify-only or proof-only surface, or whether descriptor-only cards are enough in Phase 1
