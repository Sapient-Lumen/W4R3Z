# Strong proofs, weak validators, comparison profiles, live facets, and receipts

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports.
That combination gets easier to evolve if we keep one more seam sharp early:
**the exact proof we can trust for cut-sensitive work**, **the weaker validator we may use for sameness hints**, **the declared comparison profile**, **the current live facet**, and **the durable receipt/history row** are not the same truth.

This matters because systems drift toward one flattering digest story:
- one weak validator gets treated like a whole-object proof,
- one stable review stamp gets treated like the exact bytes,
- one object-store checksum gets treated like semantic sameness,
- one comparison result gets treated like current authority,
- and one old receipt gets treated like a fresh live bind.

That collapse feels tidy until range repair, conditional mutation, dedupe, review drift, and UX honesty all start disagreeing.

## Keep these classes separate
- **strong proof** — exact witness suitable for integrity, exact basis checks, and other cut-sensitive operations
- **weak validator** — a weaker sameness token or comparison witness that is useful for cache/drift/review hints but does not promise exactness
- **comparison profile** — the explicit rule for what kind of sameness is being claimed (`exact bytes`, `stable patch`, `authority core`, `representation`, `provider revision`, and so on)
- **live facet** — the current actual room/session/process authority surface that exists here now
- **receipt/history row** — durable evidence that something was compared, reviewed, rebound, denied, or retired

Do **not** let the weak validator impersonate the strong proof.
Do **not** let the comparison profile stay implicit.
Do **not** let any comparison result impersonate the live facet.

## Why this is a low-regret lesson
Several ecosystems reward different comparison strengths for different jobs:
- HTTP explicitly distinguishes weak and strong entity-tag validators, and uses strong comparison for mutation/range-sensitive cases.
- Amazon S3 explicitly warns that an object ETag may or may not be an MD5 digest of the object data, while separate checksum fields/checksum modes exist.
- Git patch-id is intentionally only a reasonably stable patch-shaped key rather than the whole commit object.
- SlopOS already gives a local version of the pattern: `wallet_core_digest` is a stable review key, while CH-AREF and commit digests stay on the exact artifact lane.

That is exactly the pattern ViewFS wants while it is still deciding its object families, handle carriers, and shell protocol.

## SlopOS alignment
This fits current SlopOS especially well:
- `capability-wallet-schema-v0.md` keeps `wallet_core_digest` stable by dropping volatile fields and normalizing the comparison set.
- `artifact-reference-schema-v0.md` keeps exact artifact identity on digest-bearing CH-AREF rows.
- `capstore-commit-schema-v0.md` keeps commit identity and parent/epoch truth explicit rather than inferred from one stable summary.
- `document-handle-schema-v0.md` and `lease-descriptor-state-boundary-v0.md` keep live/openability truth separate from old descriptor evidence.

So ViewFS does **not** need to decide now whether every family exposes both weak and strong lanes, or whether every profile uses one digest family.
It only needs to keep strong proof, weak validator, compare profile, live facet, and receipt/history from collapsing together.

## What to steal
- **strong-lock badges** for `exact proof`, `range-safe`, `commit-safe`, `unknown`, or `history only`
- **weak lamps** for `same enough under profile`, `changed under profile`, `cannot compare`, or `heuristic only`
- **compare-profile drawers** that say exactly which sameness rule is in play
- **facet rails** that keep proof/validator cards from impersonating current inspect/read/edit/publish authority
- **repair ladders** that keep `use strong proof`, `review weak drift`, `switch compare profile`, and `ask for fresh bind` visibly different

## What not to freeze yet
- one universal strong-proof digest family
- one universal weak-validator carrier
- one universal comparison-profile registry
- whether compare-profile declarations live in receipts, cards, route plans, or multiple adjacent carriers
- whether a family may have several weak-validator lanes at once
