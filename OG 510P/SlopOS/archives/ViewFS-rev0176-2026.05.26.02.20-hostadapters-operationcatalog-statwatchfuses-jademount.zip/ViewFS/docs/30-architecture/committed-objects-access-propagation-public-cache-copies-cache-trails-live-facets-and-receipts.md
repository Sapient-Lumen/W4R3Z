# Committed objects, access propagation, public cache copies, cache trails, live facets, and receipts

Purpose: keep **committed objects**, **access propagation**, **public cache copies**, **cache trails**, **live facets**, and **receipts/history** on separate seams.

Object stores and capability systems make it very tempting to collapse these into one vague story of `the latest thing is published`.
The precedents say otherwise.
A durable object can exist, origin reads can be strongly consistent, access changes can still be propagating, publicly cacheable copies can still be stale, and one request can still carry a cache trail that is only about response handling rather than authority.

## Useful precedents
- **REF-AWS-S3-CONSISTENCY**: S3 now documents strong read-after-write and list consistency for object operations.
- **REF-GCS-CONSISTENCY**: Cloud Storage documents strong object/list consistency, separately documents eventual consistency for granting/revoking access, and separately warns that cacheable publicly readable objects might not show strong consistency.
- **REF-RFC9111-CACHING**: HTTP caching is its own standards layer with cache-control, freshness, validation, and stored-response semantics.
- **REF-RFC9211-CACHE-STATUS**: `Cache-Status` is standardized precisely so cache handling can be debugged explicitly instead of guessed.
- SlopOS already has adjacent pressure here: `artifact-reference-schema-v0.md`, `approval-basis-posture-v0.md`, `auth-result-export-boundary-v0.md`, `cache-topology-authority-boundary-v0.md`, and a wide spread of boundary notes that warn against hidden cached provider state becoming portable truth.

## Distinctions worth preserving

### 1. Committed object truth is not the same thing as access-change propagation
An object may durably exist and be strongly readable at the origin while one grant, revoke, or configuration change is still taking time to propagate everywhere that matters.

### 2. Access propagation is not the same thing as public-cache visibility
Even if origin permissions or object state changed, a cacheable publicly readable representation can persist in shared caches until cache lifetime or invalidation work says otherwise.

### 3. Public cache visibility is not the same thing as current live authority
A stale public/shared cache response is not proof that this process still holds a live read/publish facet, and a live facet here is not proof that every public cache is fresh.

### 4. Cache trail is not object or permission truth
`hit`, `miss`, `forwarded`, `stored`, and similar cache-handling facts explain the request path.
They do not, by themselves, settle durable object existence or current permission truth.

### 5. Receipt/history is not current cache or authority truth
A past receipt saying `revocation requested`, `cache hit`, or `purge asked` is evidence that something happened.
It is not proof that shared caches are empty now or that one live facet still exists here now.

## Shape that feels promising
ViewFS probably wants different object/receipt families such as:
- **AccessPropagationState** — pending / settled / provider-hidden / history-only
- **PublicCacheState** — cacheable / stale-possible / bypassed / purged / unknown / history-only
- **CacheTrail** — standardized hit/miss/forward/stored details
- **PublicationReceipt** — durable evidence that one object state or propagation step once happened

The exact schemas can wait.
The class separation should not.

## Nifty ideas worth stealing
- **Truth badges**: `origin-current`, `history only`, `deleted at origin`, `unknown here`.
- **Propagation echoes**: `grant pending`, `revoke settling`, `config propagating`, `provider hidden`, `history only`.
- **Cache ghosts**: `publicly cacheable`, `stale maybe`, `purge asked`, `cache bypassed`, `history only`.
- **Trail drawers**: cache-path panels that show `hit`, `miss`, `forward`, `ttl`, or `stored` details without pretending those are authority.
- **Contrast drawers**: inspect `origin says`, `policy says`, `cache says`, and `live rail says` in one honest panel.

## What not to decide yet
- one final shared/public-cache object model,
- whether cache trails are always exposed or only in debug/receipt mode,
- one universal revocation or invalidation protocol,
- whether publication/cache semantics differ by object family,
- whether access propagation is object-local, container-local, or store-local.

## Near-term recommendation
For ViewFS Phase 1 and nearby spikes:
1. keep **object existence**, **access-propagation state**, **public-cache visibility**, **cache-trail evidence**, and **live authority** as explicit vocabulary,
2. make public-cache visibility visibly weaker than committed-object truth,
3. make revoke/protect/delete UX visibly weaker than universal cache disappearance,
4. keep cache-debug facts transcript-visible rather than folklore-driven,
5. and refuse to let history receipts silently stand in for current cache or authority state.
