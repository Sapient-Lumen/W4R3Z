## Revision 155 anti-collapse: schema names are not proof

A future ViewFS implementation may be tempted to treat the existence of a named seam as evidence that the seam is safe. Revision 155 rejects that. A noun is provisional until it has a positive specimen, a negative specimen, a checker or proof obligation, and a shell representation.

Keep these open until evidence demands coupling:

- whether the v0 JSON fixture shape becomes JSON Schema, CUE, SlopOS-native schema material, or a proof-assistant model;
- whether handle attenuation, portal replay, semantic-index lifecycle, and consent chains become separate state-machine corpora;
- whether shell cards are checked as render-only views over the same fixtures;
- how much fixture detail should be redacted when specimens involve secrets, private object graphs, or provider-owned grants;
- whether registry IDs and RFC numbers should become content-addressed or signed records later.

The new spine is `docs/30-architecture/core-schema-v0.md`, `docs/40-verification/proof-obligations-v0.md`, `fixtures/viewfs-core-v0/`, and `tools/check_viewfs_core_fixtures.py`.

## Revision 154 anti-collapse: approval is not one bit

A future ViewFS shell may have chat buttons, answer cards, notifications, tool widgets, remote sessions, terminal blocks, secure-entry overlays, and portal sheets. Do not let those all collapse into `approved`.

Keep these open until evidence demands coupling:

- whether ViewFS has a single UI root or multiple profile-specific consent issuers;
- whether volition evidence is signed, kernel-mediated, compositor-mediated, authenticator-mediated, or portal-local;
- whether high-risk approval requires secure attention, local display/input, hardware touch, quorum, or policy-only issuer kinds;
- how accessibility and remote/headless profiles honestly express consent without faking local trusted-path evidence;
- how much consent-summary material is durable, redacted, or forgotten;
- whether notifications and answer-card buttons can ever approve more than low-risk plan requests;
- how old approval receipts participate in reconsent without becoming replay tokens.

The new design note is `docs/30-architecture/consent-summaries-presentation-surfaces-gesture-evidence-volition-tokens-approval-cuts-live-authority-and-receipts.md` and the RFC is `rfcs/0141-viewfs-keep-consent-summaries-presentation-surfaces-gesture-evidence-volition-tokens-approval-cuts-live-authority-and-receipts-separate.md`.

# Design splits and non-decisions

Purpose: prevent ViewFS from collapsing several distinct questions into one overloaded “filesystem object” too early.

This note is intentionally conservative. SlopOS is still in design, and so is ViewFS. The safest move is to keep the big questions **separate until evidence forces a coupling**.


## Revision 151 anti-collapse: content address is not object authority

A future ViewFS object store may use digests, CIDs, Merkle roots, closure hashes, verified-blob descriptors, dedup tables, caches, shared extents, or encrypted-dedup domains. None of those should silently answer object authority, trust, publication, membership, retention, or live-handle questions.

Keep these open until evidence demands coupling:
- whether ViewFS has one or many content-address profiles;
- whether any dedup domain crosses users, projects, tenants, providers, or quarantine boundaries;
- whether encrypted dedup exists, and if so whether convergence domains are per-user, per-project, tenant-wide, public/global, provider-opaque, or server-aided;
- whether proof-of-possession is local, provider-owned, portal-owned, interactive, or deliberately avoided;
- how much cache/dedup hit/miss telemetry can be safely shown in the shell;
- how storage savings interact with payer/budget lanes.

The new design note is `docs/30-architecture/content-addresses-equality-witnesses-dedup-hints-convergence-domains-cache-hits-materializations-live-facets-and-receipts.md` and the RFC is `rfcs/0138-viewfs-keep-content-addresses-equality-witnesses-dedup-hints-convergence-domains-cache-hits-materializations-live-facets-and-receipts-separate.md`.

## The four questions we should not collapse

### 1. Object identity
Question:
- what exact object is this?

Good answers tend to look like:
- immutable digest/object ID
- manifest ID
- exact closure reference

Why keep it separate:
- content identity is stable even when names, mutable heads, or grants change.
- provenance and caching stay legible.

### 2. Namespace naming
Question:
- what names can I currently walk from this view?

Good answers tend to look like:
- explicit view bindings
- directory handles
- synthetic local roots

Why keep it separate:
- the same object may appear in multiple views with different names.
- a name is a presentation/membership fact, not the object’s ultimate identity.

### 3. Mutable current state
Question:
- if this thing is editable, what is the “current head” and how does it advance?

Good answers might look like:
- root-pointer updates
- journals / changesets
- stable mutable anchors
- stable mutable slots

Why keep it separate:
- mutation semantics are where crash consistency, merge, undo, and attribution become expensive.
- the best answer may differ by workload.

### 4. Grant persistence
Question:
- how does previously granted access survive restart, handoff, or reopen?

Good answers might look like:
- ephemeral session grants
- durable reopen receipts
- explicit document references
- revalidated stable IDs with inspectable failure

Why keep it separate:
- “I can reopen it later” is not the same as “I know exactly which bytes this is” or “I can still find it by the same path.”
- durable grants are a major security surface.

## Another question we should not collapse

### 5. Retry-safe sameness versus provider follow-up
Question:
- if I retry this provider-backed action, am I proving it is the same action as before, asking the provider to admit it now, following a provider-owned operation later, or adopting one settled result locally?

Good answers might look like:
- requester-chosen intent keys
- canonical-request fingerprints
- accepted-request rows
- provider-owned operation tickets
- later completion verdicts
- explicit local adoption choices

Why keep it separate:
- same-intent retry is smaller than mutable upsert authority.
- dedupe windows and key expiry are not the same thing as final provider truth.
- the same key with changed payload should usually fail closed instead of silently retargeting one old request.

## Yet another question we should not collapse

### 6. Durable existence versus cold/offline posture
Question:
- does this object durably exist, is it currently archived/offline, is a thaw happening, is a temporary readable copy present, or is there a live facet here now?

Good answers might look like:
- committed object rows
- archive-tier / hot-cold posture rows
- explicit thaw jobs
- temporary thawed-copy rows with expiry
- explicit live facets

Why keep it separate:
- a durable object can exist without being ordinarily readable right now.
- a thaw request is not the same thing as a finished readable copy.
- a temporary thawed copy is not the same thing as permanent hot placement or current authority.

## Historical lesson
Many systems become harder to reason about when they overload one primitive with too many meanings:
- a path tries to be identity, discovery, and authority,
- a mutable file handle tries to be both content identity and current head,
- a reopen token tries to be both user intent and permanent authority.

ViewFS should resist that compression.

## ViewFS-friendly decomposition
For the first useful slice, prefer this split:
- **identity** -> immutable object / manifest reference
- **authority** -> explicit handle with rights
- **naming** -> view-local bindings and directory lookup
- **editable head** -> separate mutable-work mechanism
- **reopen / persistence** -> explicit receipt or document reference
- **retry sameness** -> explicit intent key / fingerprint / mismatch gate
- **cold/archive posture** -> explicit storage tier / thaw job / temporary-readable-copy lanes

## What this means in practice

### Paths stay secondary
A compat path may help users or legacy tools, but it should not become the only carrier of:
- identity,
- authority,
- or durable reopen semantics.

### Stable IDs need narrow semantics
If a stable mutable ID appears later, it should mean one thing well.
For example:
- “this mutable slot exists”
- not simultaneously “this path is still valid”, “this content is unchanged”, and “all prior grants still apply”.

### Receipts should say what kind of stability they provide
A receipt should be able to distinguish:
- exact immutable object reference,
- mutable workspace head reference,
- ephemeral transfer grant,
- durable reopen grant,
- and failed revalidation.

### Shell UX should expose the split
The shell/terminal should help users see:
- exact object IDs,
- current view-local names,
- mutable workspace heads,
- and grant durability state,
without pretending they are the same thing.

## Concrete anti-coupling rules
- Do not make one path string the sole source of identity.
- Do not let a durable reopen token silently imply permanent path stability.
- Do not let mutable current-state handles masquerade as immutable content IDs.
- Do not let portal receipts hide whether they are ephemeral, durable, or already revalidated.
- Do not force one universal mutable mechanism before the first few spikes run.

## Questions still intentionally open
- whether mutable current state is primarily root-pointer, journal, anchor, or slot based
- whether durable reopen uses document-handle semantics, receipt chaining, or something else
- whether path compatibility lives in libc, shell helpers, runtime shims, or all three
- whether capability bundles are launch-only, stored objects, or both


## Another question we should not collapse

### 5. Cross-boundary object workflow lane
Question:
- is this action importing bytes, opening in place, selecting a destination, moving/rehomeing, publishing a transfer offer, delegating to another handler, or only promising later materialization?

Why keep it separate:
- these lanes move different things across boundaries. Some copy bytes, some delegate access, some only publish an offer or promise.
- shell UX becomes much more honest when it can say which lane is active.
- receipts and audit trails get much easier to trust.

Good answers might look like:
- import receipts
- destination grants
- transfer offers and delivery receipts
- move outcome receipts
- promise materialization receipts

## Yet another question we should not collapse

### 6. Warm-state and offline lane
Question:
- is this action only hinting/prefetching, opportunistically caching, hydrating exact bytes, pinning retention, mirroring a corpus, or producing a self-contained offline bundle?

Why keep it separate:
- these classes make different promises about discardability, retention, offline truth, and transport.
- shell UX becomes much more honest when it can distinguish `hint-only`, `cached`, `hydrated`, `pinned`, `mirrored`, and `offline-bundled`.
- GC/cleanup and offline readiness become inspectable instead of folkloric.

Good answers might look like:
- prefetch plans
- cache entries
- hydration receipts
- pin receipts
- mirror receipts
- offline bundle receipts

## One more question we should not collapse

### 7. Grouped authority, view fragments, live binds, and launch kits
Question:
- is this object grouping authority for transport/inspection, describing a namespace fragment that could be bound, mutating a concrete view right now, constructing a child launch environment, or only recording that one of those happened?

Why keep it separate:
- creator-populated namespace systems work because child launch state is assembled explicitly rather than rediscovered ambiently.
- the same bundle may feed several different child launches or live binds.
- the same fragment may be rebound into several views over time.
- receipts/history should stay useful without becoming bearer authority.

Good answers might look like:
- capability bundle / dictionary
- view fragment / template
- view bind receipt
- launch kit / exec pack
- launch receipt



## One last question we should not collapse

### 8. Mediated designation and import state
Question:
- is this thing a request object, a chooser-owned candidate surface, the selected designation, the minted grant/ref, a concrete live bind into this pane, or only a receipt/history artifact?

Why keep it separate:
- candidate enumeration and selected outcome are different security surfaces.
- persistence should be explicit instead of leaking out of ordinary open/import flows.
- shell UX gets much more honest when it can say `pending`, `selected`, `granted`, `bound here`, `reopenable`, or `receipt only`.

Good answers might look like:
- request objects / request chips
- candidate descriptors
- selection records
- ephemeral import grants
- durable reopen refs
- bind receipts and import receipts



## And another question we should not collapse

### 9. Intent, prepared plan, approval, and result
Question:
- is this thing merely an intent, one exact prepared route/action plan, an approval checkpoint tied to that exact plan, a live committed execution, or only a result/history artifact?

Why keep it separate:
- the shell becomes much more truthful when `prepare` is not yet `commit`.
- approvals should bind exact action basis rather than floating mutable targets.
- restricted / inspect-only modes become productively legible instead of looking like generic failures.
- replay gets safer when it starts from a fresh plan instead of an old receipt pretending to be live authority.

Good answers might look like:
- intent records
- route-plan cards
- approval checkpoints
- execution records
- result receipts


## And one more question we should not collapse

### 10. Activation carriers, live handle copies, issuer badges, and object identity
Question:
- is this thing the reviewed activation/launch slot, the live handle copy currently installed in a process, a minted issuer-visible badge or witness attached to that copy, the underlying immutable object identity, or only a launch/history artifact?

Why keep it separate:
- startup delivery and steady-state naming are different truths.
- a badge on a copied handle describes the copy or its issuer lane, not necessarily the object's identity.
- shell UX can become much more honest when it can say `activation slot`, `live handle`, `issuer badge`, `object ref`, or `receipt only` instead of flattening them into one fuzzy open event.

Good answers might look like:
- launch-kit / activation-slot entries
- live handle-table entries
- issuer-visible badge / witness fields
- immutable object refs
- launch receipts

## One more question we should not collapse

### 10. Suggested automation, promoted workflows, and run history
Question:
- is this thing only a suggestion sourced from a workspace/receipt/notebook, a promoted user-owned workflow, one exact prepared run plan, a committed run, or only a receipt/history artifact?

Why keep it separate:
- a repository or shared playbook should not silently rewrite the user’s workflow vocabulary.
- source drift should become `reinspect` / `re-promote`, not silent mutation.
- replay gets safer when it starts from a fresh plan instead of treating an old successful run as current truth.

Good answers might look like:
- suggestion trays
- promotion receipts
- user-owned workflows
- prepared run plans
- run receipts


## Two more questions we should not collapse

### 11. Immutable storage, durable roots, and durable reopen
Question:
- is this thing exact immutable storage, an optional durable-root/update story, or only a durable reopen/ref story?

Why keep it separate:
- persisting bytes is easier than persisting authority.
- rollback, resurrection, and device-state mismatch show up the moment durable authority graphs get ambitious.
- a reopen descriptor should not silently count as a broad durable authority graph.

Good answers might look like:
- immutable object IDs
- optional root commits / epoch-bound root updates
- narrow durable reopen refs and receipts

### 12. View-scoped query, live feed, and global inventory
Question:
- is this thing a snapshot query inside one view, a bounded live feed, a shell-owned saved-query manifest, or a provider-global inventory surface?

Why keep it separate:
- query becomes a second authority plane the moment it turns into generic existence/count/inventory probing.
- saved-query UX is useful long before app-visible background indexing deserves to exist.
- a live feed is not the same thing as a current result snapshot.

Good answers might look like:
- snapshot-first query results
- bounded live update feeds
- shell-owned smart-folder manifests
- explicit refusal to expose ambient global inventory in Phase 1

## One more question we should not collapse

### 13. Narrow continuity, durable reopen, and persistent authority
A resumed conversation, a reconnectable endpoint, a queued follow-up, a portal request still in flight, a durable reopen ref, and a persistent authority root are not the same thing.

Why this matters:
- the product wants continuity because humans hate losing context;
- the security model wants narrowness because durable authority is where rollback, resurrection, and stale-state bugs get scary;
- shell UX gets much better when “resume this exact lane” does not silently mean “restore everything you once touched.”

Working posture:
- continuity/escrow artifacts should be typed, scoped, and expiry-friendly;
- durable reopen should remain a separate, inspectable seam even if continuity exists;
- persistent authority should remain optional and scary rather than becoming the default explanation for every convenience feature;
- queued steering/follow-up controls should stay attached to live or resumable requests rather than being confused with saved workflows or durable grants.

## One more question we should not collapse

### 14. Stable identity, current placement, currently held rights, and advertised operations
An exact object ID, the names/binds by which the object is currently reachable here, the rights currently attached to a handle, and the operations the provider is prepared to support are not the same thing.

Why this matters:
- the same object may appear in multiple directories or views at once;
- a shell that guesses verbs from path shape will lie the moment a provider has tighter rules;
- route sheets and action menus become much more trustworthy when they are driven by exact affordance truth instead of filename folklore.

Working posture:
- identity should remain stable even when placement changes;
- rights summaries should remain separate from shell convenience guesses;
- advertised operations should be explicit enough to drive chooser follow-ups, context menus, and route sheets;
- unsupported actions should downgrade or explain themselves instead of surviving as generic buttons.
- this seam is now formalized further in `docs/30-architecture/identity-placement-rights-and-affordances.md` and `rfcs/0068-viewfs-keep-object-identity-view-placement-current-handle-rights-advertised-operations-and-receipts-separate.md`.

## Recommendation
Treat “object identity”, “name in a view”, “current mutable head”, and “durable reopen authority” as four separate design axes until a specific interoperability or UX problem proves otherwise. Treat immutable storage, optional durable roots, and durable reopen descriptors as separate questions too, rather than calling all persistence “the object”. Treat warm-state and offline lanes as a separate question too, rather than smuggling them into one vague cache feature. Treat view-scoped query, bounded live feeds, shell-owned saved-query manifests, and global inventory surfaces as separate questions too, rather than calling all of them “search”. Treat mediated request state, chooser-owned candidate surfaces, selected outcomes, minted grants/refs, and live binds as separate questions too, rather than calling all of them “the opened object”. Treat intent, prepared plan, approval, committed execution, and result/history as separate questions too, rather than calling all of them “the action”. Treat suggested automation, promoted user-owned workflows, prepared run plans, committed runs, and history/receipts as separate questions too, rather than calling all of them “the saved workflow”. Treat stable identity, current placement, current rights, advertised operations, provider/catalog presence, freshness-scoped readiness, grant-needed posture, and history/receipt truth as separate questions too, rather than letting one path-shaped string or one soft presence badge decide which actions appear.

## One more question we should not collapse

### 15. Transient staging bytes, committed objects, transferred live handles, and durable reopen refs
A draft byte capsule, a sealed staging capsule, a couriered live handle, a committed object-store object, a durable reopen ref, and a history receipt are not the same thing.

Why this matters:
- preview/import/export/editor-return flows often need exact bytes before anyone should promise durable storage or durable reopen;
- explicit local transfer is safer and more truthful when it moves an exact live staging object instead of asking another process to rediscover a path;
- shell UX gets much better when `draft`, `sealed`, `commit last`, and `discard` are visible states rather than temp-file folklore.

Working posture:
- ViewFS should allow explicit transient staging artifacts without treating them as the object-store truth model;
- commit-to-object-store should remain a visibly later act than stage-for-review or courier-to-peer;
- a live transferred handle should remain distinct from any durable reopen or durable authority story;
- history/receipt surfaces should describe staged capsules honestly instead of laundering them into ordinary files.

## One more question we should not collapse

### 16. Courier peer witness, transferred live handle, structured command packet, and transcript row
A peer-credential or courier witness, a transferred live handle, a structured command packet, a durable receipt, and a plain transcript row are not the same thing.

Why this matters:
- exact local transfer gets safer and more explainable when the shell can say **who** couriered something without pretending that witness is the object's immutable identity;
- a future custom shell will want to escalate or route exact command context without copy-pasting fragile transcript text;
- replay/reopen/reroute actions become much more trustworthy when they target explicit packets or explicit live handles rather than arbitrary highlighted strings.

Working posture:
- a courier witness should describe the sender lane/peer/copy provenance, not the underlying object identity;
- a transferred live handle should remain distinct from any witness metadata and distinct from later durable receipts/history;
- a structured command packet should require explicit promotion from a strong-truth block rather than being silently inferred from selected text;
- transcript text should stay useful for humans even when no packet/handle/witness object exists.


## Another question we should not collapse

### 19. Live binds, propagation posture, peer groups, and receipts
A current bind into one explicit process view, that bind's propagation posture, any peer/master-group relationship or blast radius, and a durable receipt are not the same thing.

Why this matters:
- explicit per-process namespace design gets much safer when `attached here` does not quietly imply `local only` or `shared to peers`;
- detached fragments can already exist before attachment, so it is useful to keep `attach now` separate from `how later namespace changes flow`;
- shell UX gets much better when it can say `local only`, `shared`, `receives upstream`, `not cloneable`, or `receipt only` as different truths.

Working posture:
- ViewFS should treat live bind state and propagation posture as separate reviewed facts;
- propagation / blast-radius posture should be explicit on attach/rebind review and on later inspect surfaces;
- peer/upstream relationships should describe current propagation shape, not durable object identity;
- receipt/history surfaces should record propagation posture honestly without reviving live propagation behavior later.

## Low-regret moves we can freeze even while SlopOS is still moving
See also: `docs/90-inspirations/slopos-datacube-evaluation.md`.

These are not mechanism decisions. They are anti-confusion guardrails.

Freeze these separations now:
- immutable object identity is not the same thing as a current name in a view;
- a current name in a view is not the same thing as a mutable editable head;
- a mutable editable head is not the same thing as a durable reopen/ref story;
- immutable storage is not the same thing as optional durable-root state or durable reopen state;
- a request object is not the same thing as a chooser-owned candidate set, a selected result, a minted grant, or a live bind;
- a live handle is not the same thing as a receipt, notebook entry, history row, or pane-restore artifact;
- an observe lane is not the same thing as attach, control, exec/debug, or sideband access;
- a query snapshot is not the same thing as a live feed, saved smart-folder manifest, or global inventory surface;
- a narrow continuity / escrow artifact is not the same thing as a durable reopen ref or persistent root state;
- a transient staging capsule is not the same thing as a committed object, a couriered live handle, or a durable reopen ref;
- a courier peer witness is not the same thing as transferred authority, object identity, or a durable receipt;
- a structured command packet is not the same thing as plain transcript text or a rerun approval;
- a transient selection owner or clipboard offer is not the same thing as pasted prompt bytes, an imported object, or a durable reopen artifact;
- a live bind is not the same thing as its propagation posture, peer/upstream relationship, blast radius, or durable receipt;
- an exact object ID is not the same thing as its current placement, currently held rights, or currently advertised operations;
- browse-first workspace visibility is not the same thing as trusting workspace-defined automation.

Prefer these working postures now:
- per-process namespaces should be creator-populated instead of rediscovered from ambient globals;
- attenuation should be common and widening should require a visibly new act;
- compat/path membranes may exist during bring-up, but they should stay loud debt instead of becoming the conceptual center;
- shell/terminal affordances should preserve whether something is a ref, receipt, route sheet, live bind, propagation-scoped bind, resumable lane, staged capsule, peer-witnessed courier artifact, command packet, history-only artifact, or exact-action menu source.

Continue postponing these choices:
- whether mutable work state is best modeled as journals, root-pointer updates, stable mutable slots, ordered claims, or something else;
- whether grouped capability kits are only launch/import transport, durable stored objects, or both;
- how much durable reopen should promise beyond explicit, inspectable, failure-friendly receipts;
- exact shell protocol details beyond the minimum semantic-zone, typed-link, and receipt-truth experiments.


## Another question we should not collapse

### 11. Command packets, live process handles, lifecycle control, and deep inspection
Question:
- is this thing only a prepared command packet, one exact live running-process handle, a lifecycle-control right, a deeper inspect/debug right, or only a transcript/history artifact?

Why keep it separate:
- running-command identity is useful, but it is not the same thing as a reusable command packet or a transcript row;
- some process handles only support wait/poll/signal, while stronger ones can expose debugger attach, namespace-follow, or descriptor duplication power;
- shell UX becomes much more honest when it can say `running now`, `waitable`, `stoppable`, `deep inspect available`, or `history only` instead of one vague process row.

Good answers might look like:
- command packets
- live process descriptors / supervisor-local process refs
- lifecycle-control handles
- deep-inspection / debugger handles
- exit receipts and history rows


### 10. Detached namespace fragment, pre-attach posture, and live bind
Question:
- is this thing an unattached fragment that could be bound somewhere later, a prepared pre-attach posture for that fragment, one concrete live bind into this process view, or only a receipt/history artifact?

Why keep it separate:
- a prepared fragment can be a useful object long before it is visible at any current path.
- the same fragment may be attached into different process views over time, or never attached at all.
- shell UX becomes much more honest when it can say `prepared`, `attached here`, `detached again`, or `receipt only` instead of pretending a fragment was always just “that directory.”

Good answers might look like:
- detached view-fragment descriptors
- pre-attach posture descriptors
- attach/bind plans
- live bind handles
- attach receipts

## Another question we should not collapse

### 12. Exact exec object, launch basis, startup credentials, and launch receipt
Question:
- is this thing the exact executable object, the explicit interpreter/script-entry arrangement, the argv/env/cwd launch basis, the activation-time credential set, or only a launch/history artifact?

Why keep it separate:
- execution by held handle or exact staged bytes is not the same thing as reopening whatever mutable name happens to point somewhere now;
- script/interpreter entry is a separate seam from executable-object identity;
- startup credentials are not morally the same thing as environment variables, ordinary view binds, or later durable authority;
- shell UX becomes much more honest when it can say `exec object`, `script input`, `argv/env basis`, `credential slot`, `launched`, or `history only` instead of one vague command row.

Good answers might look like:
- executable-object handles / exact-byte staged exec objects
- explicit interpreter-plus-script-entry descriptors
- argv/env/cwd launch-basis records
- activation-time credential slot descriptors
- launch receipts and history rows


## Yet another launch question we should not collapse

### 8. Exact exec object, startup code closure, loader policy, and late imports
Question:
- did we bind one exact executable object, preserve one exact startup code closure, run under one explicit loader/resolver posture, or merely allow later dynamic imports/plugins under some broader runtime lane?

Why keep it separate:
- exact exec-object identity is not the same thing as exact startup shared-library / interpreter closure.
- loader search policy is an ambient-risk surface in its own right and should not hide inside launch folklore.
- plugin/module loading after startup is a materially different lane from the initial reviewed launch.
- shell UX becomes much more honest when it can say `exec exact`, `startup closure exact`, `loader debt`, or `late import requested`.

Good answers might look like:
- exact exec-object handles
- startup-closure manifests
- loader-policy receipts
- explicit late-import / plugin receipts


## Yet another transfer question we should not collapse

### 9. Selection owner/source, offered representation, pasted input, and imported object
Question:
- is this thing only the current owner/source of a clipboard or selection offer, the representations that offer advertised, one accepted transfer/result payload, prompt input that happened to arrive by paste, a later imported/materialized object, or only a durable receipt/history artifact?

Why keep it separate:
- selection ownership is usually transient and replaceable; it is not the same thing as a stored object identity.
- offered MIME/type sets are not the same thing as the one representation the receiver actually accepted.
- prompt-local pasted bytes can be useful and even review-worthy without automatically becoming imported objects or live binds.
- clipboard history/manager behavior is a privileged optional helper lane, not a baseline truth of every pane.

Good answers might look like:
- selection-owner / offer-source descriptors
- offered-representation descriptors
- accepted-transfer / received-payload descriptors
- prompt input capsules
- explicit import/materialization/bind receipts
- durable history rows


## Yet another live-session question we should not collapse

### 13. Live process handle, terminal stream lane, controlling TTY, and foreground turn
Question:
- is this thing the running command/session object, one stdio or PTY stream lane, a controlling-terminal relationship, the current foreground-turn / interrupt-target state, or only a durable receipt/history artifact?

Why keep it separate:
- a running process can exist without any current controlling terminal at all;
- mirrored output or a PTY byte stream is not the same thing as owning terminal-generated signals or interactive input;
- foreground ownership is revocable current posture, not durable identity;
- shell UX becomes much more honest when it can say `running`, `stdout mirrored`, `stdin live`, `controlling tty`, `foreground now`, `backgrounded`, or `history only` instead of one vague attached bit.

Good answers might look like:
- live process descriptors / supervisor-local process refs
- stream-lane descriptors
- PTY / controlling-terminal posture descriptors
- foreground-turn / signal-target metadata
- attach/detach/stop receipts and history rows


## Yet another launch/session question we should not collapse

### 14. Exact exec object, runner/runtime, bootstrap posture, and live session
Question:
- is this thing the exact executable/script-input object, the runner/runtime family that gets to host it, the startup/bootstrap posture around it, the resulting live session, or only a durable receipt/history artifact?

Why keep it separate:
- one exact executable object does not by itself answer which runner/runtime will interpret or host it;
- a runner/runtime choice can carry its own lifecycle controller and sandbox envelope without changing object identity;
- startup/bootstrap posture (clean start, explicit customization bundle, or compat/startup-hook debt) is another lane again;
- shell UX becomes much more honest when it can say `exec exact`, `runner=native`, `runner=wasi`, `bootstrap clean`, `interactive live`, or `history only` instead of one vague run row.

Good answers might look like:
- exact exec-object handles / staged-byte objects
- explicit runner/runtime descriptors
- bootstrap/startup-profile posture descriptors
- live session handles/cards
- launch/lifecycle receipts and history rows


### 14b. Built-in shell baseline, reviewed customization bundle, startup file, and project hook
Question:
- is this thing the shipped built-in shell baseline, one explicit reviewed customization bundle, one ambient host/user startup file, one project-local activation hook, or only a durable receipt/history artifact?

Why keep it separate:
- delightful shell affordances do not require ambient rc/profile execution to explain themselves;
- one reviewed customization bundle is smaller, more inspectable, and more portable than arbitrary host startup files;
- project-local activation hooks are stronger than browsing and stronger than general shell personalization;
- shell UX gets much more honest when it can say `built-in only`, `bundle active`, `profile active`, `project hook pending`, or `history only` instead of one vague personalized startup row.

Good answers might look like:
- built-in shell-feature descriptors
- explicit customization-bundle objects
- startup-profile / startup-file posture descriptors
- project-hook review / approval / denial objects
- durable startup/history receipts


### 15. Handle slot, live handle copy, shared open state, and independent reopen
Question:
- is this thing only a current slot/local binding, another live handle copy to the same current open state, the shared mutable open-state group itself (cursor/status/lock/lease), a fresh independent reopen to the same object, or only a durable receipt/history artifact?

Why keep it separate:
- exact child-table population does not by itself say whether two current slots alias one mutable cursor/state or hold independent reopens;
- old UNIX semantics already show that duplication and cross-process passing often preserve one shared open file description with shared offset/status/lock state;
- a fresh reopen can point at the same object while intentionally *not* sharing the same live cursor/append/lease posture;
- shell UX becomes much more honest when it can say `slot=7`, `same live cursor as slot=4`, `fresh reopen`, or `history only` instead of one vague handle row.

Good answers might look like:
- current slot/binding descriptors
- explicit live-alias / duplicate-handle descriptors
- local shared-open-state witness/group metadata
- explicit independent reopen acts/receipts
- durable history rows describing past sharing or reopening decisions

## Another question we should not collapse

### 16. Locator/metadata handles, live byte-I/O handles, and durable refs
Question:
- is this thing only a current locator/metadata handle, a live read/write/append-capable handle, an explicit reopen/escalation act, or only a durable ref/history artifact?

Why keep it separate:
- a per-process namespace can be assembled around roots and object designations that do **not** automatically imply byte-I/O.
- inspect-first portal flows get much more honest when `selected` or `bound root` does not silently mean `readable now`.
- shell UX gets much more truthful when it can say `locate`, `metadata`, `read`, `write`, `needs reopen`, or `receipt only` as different states.

Good answers might look like:
- locator/root handles
- metadata-only inspection handles
- live read or write handles
- explicit `open for read` / `reopen for write` actions
- durable refs and receipts

## Another question we should not collapse

### 17. Current handle possession, launch inheritance posture, and exact child slot delivery
Question:
- is this thing only a live handle currently held in one pane/process, a policy posture about whether it may cross a launch boundary, the exact child-local slot/name that will receive a reviewed copy, or only a durable launch receipt/history artifact?

Why keep it separate:
- current possession of a live handle does not by itself mean any child should inherit it;
- classic `exec` semantics show that inheritance across launch is its own lane, and host defaults have historically been easy to get wrong;
- even when a handle is intentionally passed across launch, the exact child-local slot/name it lands in is another truth again;
- shell UX gets much more honest when it can say `held here`, `launch-shuttered`, `selected for child`, `child slot fd=7`, or `receipt only` instead of one vague passed-to-child story.

Good answers might look like:
- current-handle possession descriptors
- launch-boundary inheritance shutters / eligibility metadata
- explicit child-slot maps inside reviewed launch kits
- exact launch receipts naming what crossed the boundary
- durable history rows that describe but do not revive inherited handles

## Another question we should not collapse

### 17b. Room identity, current room-local view, context inheritance, child spawn recipes, and child-received bindings
Question:
- is this thing the room/pane/tab identity a human is working in, the current explicit view bound to that room right now, the posture for what may cross into a child, one prepared spawn/import recipe, the bindings/imports a child actually received, or only a durable receipt/history artifact?

Why keep it separate:
- a human-friendly room label is not the same thing as the room's current namespace, because rooms may switch views without becoming different rooms;
- a room's current view is not the same thing as its child-inheritance posture, because `what is live here now` and `what a child may get` are different questions;
- a reviewed spawn recipe is not the same thing as a committed child or a child-local bind map;
- portal/import flows get much more honest when the shell can say `requested for child`, `granted to child`, `bound in child`, or `receipt only` instead of one vague clone/split/open story;
- room restore gets much more truthful when layout/identity/recipes can come back before any fresh authority is rebound.

Good answers might look like:
- stable room identities / room badges
- explicit current-view descriptors per room
- inheritance posture shutters like `inherit none` or `inherit named bindings only`
- reviewed child spawn/import recipes and context diffs
- child-local bind/import trays
- restore receipts that explain prior room state without reviving it automatically

## Another question we should not collapse

### 18. Object identity, parent anchors, namespace mutations, and receipts
Question:
- is this thing the object itself, the source parent anchor, the destination parent anchor, the reviewed namespace mutation, or only a durable mutation receipt/history artifact?

Why keep it separate:
- holding an object or byte handle does not by itself answer whether the caller may remove one current name or create another;
- rename/link/unlink and replace/exchange operations act on namespace anchors and collision posture, not only on object bytes;
- multi-path operations are a classic source of accidental collapse because one nice `move` story hides at least two parent authorities and one mutation mode;
- shell UX gets much more honest when it can say `source parent missing`, `destination parent missing`, `rename only`, `replace target`, `exchange`, or `receipt only` instead of one vague move action.

Good answers might look like:
- object identity refs
- source-parent anchors
- destination-parent anchors
- explicit namespace-mutation plans (`rename`, `link`, `unlink`, `replace`, `exchange`)
- durable mutation receipts/history


## Yet another question we should not collapse

### 10. Unnamed objects, namespace publication, and later receipts
Question:
- is this thing an unpublished object/draft payload, a candidate publication anchor, one reviewed publication act, a currently visible bound name, or only a durable receipt/history artifact?

Why keep it separate:
- an object can be fully formed before it has a public name.
- publication can deserve its own review, collision posture, and parent-anchor selection.
- history should remember publication without becoming bearer authority.
- shell UX gets much more honest when it can say `draft object`, `publish here`, `published name`, or `receipt only`.

Good answers might look like:
- draft object handles
- publish sheets / parent-anchor cards
- publication receipts
- visible namespace binds
- durable history rows


## Another seam we should not collapse

### 11. Content descriptors, live handles, and receipts
Question:
- is this thing only a descriptor for exact content/object identity, a set of non-authoritative hints about that content, one current live handle/bind carrying authority, or only a durable receipt/history artifact?

Why keep it separate:
- a digest/object descriptor can stay useful even when no current live authority exists.
- locator hints, media type, and byte size are great shell/portal metadata, but they should not silently become bearer authority.
- portal/import UX gets much more honest when it can say `descriptor only`, `bind here`, `hydrate`, `publish`, or `receipt only` as different states.
- keeping descriptors separate preserves freedom about fetch, hydration, storage, and publication mechanisms while SlopOS is still moving.

Good answers might look like:
- immutable content descriptors
- descriptor sidecars / hint records
- live handles or live binds
- hydration receipts
- publication receipts
- transfer/import receipts


## Another seam we should not collapse

### 12. Imported source refs, materialized local objects, local docrefs, and receipts
Question:
- is this thing only an imported source ref/offer, one explicit materialization act, one fresh local object with local identity, one local durable docref/reopen designator, one current live handle/bind, or only a durable receipt/history artifact?

Why keep it separate:
- an imported source ref can be useful before any local bytes or local object exist.
- materialization is a reviewable act with copy/fetch/locality consequences of its own.
- a fresh local object is not the same thing as a durable docref for later reopen, and neither is the same thing as a live handle right now.
- shell UX gets much more honest when it can say `source ref only`, `materializing`, `fresh local object`, `local docref`, `live handle now`, or `receipt only` instead of one vague imported file story.

Good answers might look like:
- source-ref cards / import offers
- explicit materialization plans
- local object descriptors
- local docrefs / durable reopen designators
- live handles or live binds
- import/materialization/publication receipts/history


## Another seam we should not collapse

### 13. Remembered designators, continuity lockers, revived live handles, and receipts
Question:
- is this thing only a remembered designator for later reopen, one explicit revalidation/resolution act, one narrow exact-handle continuity locker, one revived live handle/bind carrying authority now, or only a durable receipt/history artifact?

Why keep it separate:
- remembered designation is useful even when no current live handle exists.
- system-level continuity lockers can preserve one exact live handle across restart without becoming a universal durable-authority substrate.
- stale / moved / revoked outcomes are valuable truths, not generic failures to be papered over.
- shell UX gets much more honest when it can say `remembered`, `needs revalidate`, `locker available`, `live again`, `stale`, or `receipt only`.

Good answers might look like:
- remembered docrefs / bookmark-like designators
- explicit resolve / revalidate acts
- manager-held exact continuity lockers
- revived live handles or binds
- stale-target / grant-needed outcomes
- durable continuity receipts/history

## Another seam we should not collapse

### 13b. Durable import anchors, live room binds, stale shadows, repair plans, and receipts
Question:
- is this thing only a durable reopen/import anchor, one live room bind carrying authority now, one stale-or-repairable shadow, one prepared repair/rebind plan, or only a durable receipt/history artifact?

Why keep it separate:
- a durable anchor is useful even when the room has no current live bind.
- stale / moved / revoked / consent-needed outcomes are valuable truths, not generic failures to be papered over.
- repair plans are productively reviewable without pretending the repair already happened.
- shell UX gets much more honest when it can say `durable anchor`, `live`, `stale`, `repair needed`, or `receipt only`.

Good answers might look like:
- portal-minted docrefs or bookmark-like durable anchors
- room-local live binds carrying authority now
- stale-shadow / grant-needed / continuity-uncertain outcomes
- explicit repair/rebind ladders
- rebind / discard / prune receipts

## Another seam we should not collapse

### 14. Transfer offers, live handle copies, revival designators, adopted binds, and receipts
Question:
- is this thing only a transfer/courier offer, one accepted representation choice, one live copied handle carrying authority now, one stored revival designator for later reconnect/reopen, one adopted local bind/slot in this pane/process, or only a durable receipt/history artifact?

Why keep it separate:
- an offer can be useful before the receiver has accepted anything.
- a live handle copy is not the same thing as a durable revival designator, and neither is the same thing as a receiver-local adopted bind.
- issuer/courier witness is useful truth but should not redefine object identity or current authority.
- shell UX gets much more honest when it can say `offer only`, `accepted as bytes`, `live alias`, `attenuated copy`, `stored for later`, `adopted here`, or `receipt only` instead of one vague shared/opened story.

Good answers might look like:
- transfer offers / courier events
- explicit representation-choice sheets
- live copied or attenuated handles
- revival designators / later reconnect records
- local adopted binds or slots
- transfer/adoption receipts/history

## Another question we should not collapse

### 20. Non-authoritative designators, authority-bearing tickets, local aliases, live handles, and receipts
A title, digest card, search hit, route target, recent-item row, or note-friendly designator is not the same thing as a bearer-ish reopen/recontact ticket; neither is the same thing as one current local alias in a pane, one live handle held now, or a durable receipt/history row.

Why this matters:
- once a user-copyable token mixes designation and authority, ordinary shell actions like paste, note-taking, sharing, and route selection start becoming covert delegation events;
- desktop history shows that persistent reopen artifacts can become security-critical once they can recover access after restart;
- shell UX gets much better when `designation only` and `authority-bearing ticket` are visibly different classes.

Working posture:
- ordinary designators should be cheap to inspect, search, sort, and share without reviving authority;
- authority-bearing tickets should be explicitly typed, visibly dangerous, and policy-killable;
- local aliases/binds should describe current placement inside one current view, not durable reopen power;
- receipts/history should describe which class was involved without becoming bearer authority by mere inspection.


## Another question we should not collapse

### 21. Caveat sets, membrane leases, live handles, and receipts
Question:
- is this thing only one declared set of caveats/attenuation terms, one current membrane or lease proxy that actually enforces them, one live delegated handle usable now, one revival designator for later revalidation, or only a durable receipt/history artifact?

Why keep it separate:
- a caveat list can be descriptive and still fail to say where enforcement really lives.
- a live membrane/proxy is not the same thing as one local handle copied into the receiver, and neither is the same thing as a later revival designator.
- past desktop and distributed-capability history both show that bearer-ish delegated artifacts become dangerous when the UI cannot distinguish declared bounds from enforced bounds.
- shell UX gets much more honest when it can say `caveat declared`, `proxy enforced`, `live handle now`, `revalidate later`, or `receipt only` instead of one vague delegated/opened story.

Working posture:
- keep declared caveat terms inspectable and monotonic;
- keep enforcement locus visible (`proxy`, `verifier`, `local handle`, or `none/currently stale`);
- keep renewal/revalidation explicit rather than implied by continued possession of a past descriptor;
- keep receipts/history descriptive, not authority-bearing.

Good answers might look like:
- caveat/constraint descriptors
- local membrane or lease-proxy objects
- live attenuated handles
- revival/revalidation designators
- durable delegation / renewal / revocation receipts

## Another question we should not collapse

### 22. Permission outlooks, revival designators, live handles, death-state verdicts, and receipts
Question:
- is this thing only one preflight permission/liveness outlook, one stored revival designator for later request/revalidate, one live handle/bind usable now, one explicit death-state verdict about why authority is gone, or only a durable receipt/history artifact?

Why keep it separate:
- `granted`, `prompt`, `denied`, `grantable_here`, or `revalidate_needed` are useful predictive truths, but they are still not live authority.
- a revival designator is useful even when no current live handle exists.
- explicit death-state verdicts like `revoked`, `expired`, `target changed`, `issuer unavailable`, or `policy denied` are much more repairable than one vague `stale` bucket.
- shell UX gets much more honest when it can say `permission looks good`, `designator only`, `live now`, `dead for this reason`, or `receipt only`.

Working posture:
- permission outlook should remain advisory/preflight, not authority.
- live handles should remain the current-authority truth.
- death-state verdicts should preserve reason class, not collapse into generic failure folklore.
- receipts/history should preserve what happened without reviving authority by inspection.

Good answers might look like:
- permission-state descriptors
- revival/recontact designators
- live local handles or binds
- revocation/expiry/deletion/change tombstones
- request/revalidation/repair receipts/history

## Another question we should not collapse

### 23. Provenance attestations, endorsement bundles, local admission verdicts, live handles, and receipts
Question:
- is this thing one provenance/production/import/review claim, one endorsement or trust-root input, one local admit/deny verdict, one live handle/bind usable now, or only a durable receipt/history artifact?

Why keep it separate:
- a structured or signed claim about where bytes came from is still not one local decision that the object may run here.
- endorsement bundles, threshold signatures, trust delegations, transparency-log witnesses, and reference values are appraisal inputs, not universal truth.
- a local verdict like `preview only`, `safe-open only`, `admit runnable`, or `deny` is still not proof that the pane already holds a live handle.
- shell UX gets much more honest when it can say `well-described`, `well-endorsed`, `admitted here`, `live now`, or `receipt only` instead of one vague trusted/opened story.

Working posture:
- provenance claims should remain inspectable even when admission is undecided or negative.
- endorsement bundles and trust-root choices should remain visible without outrunning local policy.
- local admission should remain explainable and revocable without pretending it is current handle possession.
- receipts/history should preserve how one verdict was reached without reviving standing approval by inspection.

Good answers might look like:
- provenance / attestation envelopes
- endorsement / threshold / trust-root bundles
- local admit / deny / safe-open verdict cards
- live local handles or binds
- audit / admit / deny receipts/history

## And one more question we should not collapse

### 11. Request rows, session/transfer objects, portal-owned live state, and local adopted binds
Question:
- is this thing one interaction request, one longer-lived session or transfer object, the portal's current view of that object's state, one local adopted bind/live handle, or only history?

Why keep it separate:
- portal-heavy systems routinely create one short-lived request seam and one longer-lived session seam.
- the portal may know that a session is `open`, `ending`, `closed`, `allowed`, or `bound` without that being proof that this pane still has one live adopted bind.
- shell UX gets much more honest when it can say `request only`, `session active`, `portal says closed`, `adopted here`, or `receipt only` instead of flattening them into one fuzzy open row.

Good answers might look like:
- request chips / request IDs
- session handles / transfer keys
- portal-state rows or monitors
- local adopted binds / live handles
- request/session receipts

## Another question we should not collapse

### 22. Completion candidates, accepted insertions, compiled command packets, prepared actions, and receipts
Question:
- is this thing only one completion candidate or ghost suggestion, one focused-candidate detail drawer, one accepted insertion in the mutable prompt buffer, one compiled command packet for this pane, one prepared action/route plan, or only one durable receipt/history artifact?

Why keep it separate:
- ranked suggestions and lazy detail are useful even when nothing has been accepted yet.
- accepted prompt text is still editable user state, not one current action plan.
- one compiled packet is stronger than text because it binds against current pane state, but it still is not the same thing as approval or launch.
- heuristically observed command text should stay visibly weaker than shell-reported or nonce-verified packets.
- shell UX gets much more honest when it can say `candidate only`, `detail loaded`, `inserted`, `compiled`, `approval needed`, `ready`, or `receipt only`.

Good answers might look like:
- completion/ghost rows
- focus-triggered detail drawers
- accepted word/fragment/full-line insertions
- compiled command packets with trust grade
- prepared route plans / action packets
- insertion/compile/run receipts/history

## Another question we should not collapse

### 24. Selected regions, extracted entity candidates, route envelopes, prepared actions, and receipts
Question:
- is this thing only one selected transcript/screen region, one extracted entity candidate, one lazily resolved target/detail set, one typed route envelope, one prepared action, or only one durable receipt/history artifact?

Why keep it separate:
- selected bytes or cells are still only a surface, not final semantics.
- one extracted entity candidate may still be heuristic or partial and may not survive focus/resolve checks.
- one resolved target/detail set is stronger than a candidate, but still not one route choice or approval.
- a typed route envelope is stronger than a hyperlink or selection, but it still is not one approved side effect.
- shell UX gets much more honest when it can say `selected`, `candidate`, `resolved`, `route slip`, `approval needed`, `ready`, or `receipt only`.

Good answers might look like:
- selected-region descriptors
- extracted entity candidates with confidence/source
- lazy-resolve target/detail drawers
- typed plumb/route envelopes
- prepared route cards / action packets
- selection/route receipts/history

## Another question we should not collapse

### 25. Gesture evidence, activation tokens, armed state, active control, and receipts
Question:
- is this thing only one fresh user-action witness, one transferable activation baton/token, one armed-or-enabled interaction lane, one current active-control / foreground state, or only one durable receipt/history artifact?

Why keep it separate:
- a recent click, keypress, shortcut, or notification action is still not one durable capability.
- a transferable activation token may let another component ask for activation, but it still is not one live handle or one guaranteed foreground turn.
- `armed` or `enabled` is stronger than `idle`, but weaker than `active now`.
- a current foreground/control turn is usually narrow and ephemeral; it should not masquerade as durable reopen or standing authority.
- shell UX gets much more honest when it can say `fresh gesture`, `activation baton`, `armed`, `active now`, or `receipt only` instead of one fuzzy interacted/opened story.

Good answers might look like:
- user-action serials or transient-activation witnesses
- transferable activation / focus-request tokens
- enabled capture or prepared chooser/session state
- active control / current foreground turn markers
- gesture / activation / control receipts/history


## New anti-collapse pressure from Revision 076
Another very low-regret seam to freeze while ViewFS and SlopOS are still fluid is **declared type / derived type / handler association / chosen opener / live open state / receipt**.

Why this matters:
- a claimed MIME/UTType or extension hint is not the same thing as a local derived classification;
- a type classification is not the same thing as a list of associated handlers;
- an associated/default handler is not the same thing as the opener actually chosen for one act;
- one chosen opener is not the same thing as one current live preview/editor session;
- and none of those are the same thing as history.

What to postpone:
- one universal type taxonomy,
- one universal handler registry ABI,
- one final priority rule between declared and derived type,
- and one final owner for opener choice across shell, portal, helper, and provider.

Freeze the separation first.


## New anti-collapse pressure from Revision 077
Another very low-regret seam to freeze while ViewFS and SlopOS are still fluid is **advisory annotation / selector label / policy-bearing label / trusted badge / receipt**.

Why this matters:
- a freeform or imported note is not the same thing as a compact grouping key that queries may rely on;
- a selector-safe grouping key is not the same thing as a policy-bearing label that affects handling or export posture;
- a policy-bearing label is not the same thing as shell-owned trusted chrome;
- a trusted badge is not the same thing as canonical object metadata;
- and none of those are the same thing as history.

What to postpone:
- one universal label taxonomy,
- whether selector labels live on objects, placements, or side indexes,
- whether policy-bearing labels are local-only or provider-visible,
- and one universal terminal/shell badge protocol.

Freeze the separation first.


## Revision 078: continuation cursors, sync watermarks, live subscriptions, rebuilt snapshots, and gap verdicts

Another especially useful seam is **resume token versus current truth**.
Kubernetes, Dropbox, Watchman, and FSEvents all point the same way:
- a continuation cursor or clockspec can help resume incremental work,
- a watermark can say what point the client has definitely processed through,
- a live watch/longpoll can wait for more changes,
- a rebuilt snapshot can re-establish current visible truth,
- and a reset/overflow/root-change verdict can tell the user why continuity broke.

Those should stay visibly distinct in ViewFS.
That gives us room to make smart folders, watch panes, and portal-backed result feeds feel excellent without deciding one universal cursor ABI or pretending provider tokens are durable object refs.

Do not decide yet:
- one universal cross-provider cursor/watermark schema;
- one final gap/reset taxonomy;
- whether rebuilt snapshots are stored objects, shell caches, or provider-owned cuts;
- whether live subscriptions are shell-owned, provider-owned, or terminal-owned for every backend.

## Revision 079: observed validators, writable sessions, write holds, commit preconditions, and committed versions

Another especially useful seam is **observed base versus durable winner**.
HTTP conditional requests, Cloud Storage preconditions, etcd compare-and-swap, WebDAV locking, and browser writable-session APIs all point the same way:
- the exact basis you observed is not the same thing as one local writable session,
- one writable session is not the same thing as one live hold or lock token,
- one hold is not the same thing as the exact commit precondition,
- and the committed version that actually won is not the same thing as draft-local close/flush folklore.

Those should stay visibly distinct in ViewFS.
That gives us room to make editing, import repair, external-editor round-trips, and shell commit UX feel excellent without deciding one final transaction or locking model too early.

Do not decide yet:
- one universal validator field across all providers and object families;
- whether ViewFS normalizes on digest, generation, epoch, mod-revision, or several of them;
- whether write holds are mandatory anywhere in Phase 1;
- whether writable sessions are shell-owned, provider-owned, or runtime-owned for every backend.

## Revision 080: partial residency, chunk layouts, and whole-object proofs

Another especially useful seam is **partial local residency versus whole-object truth**.
HTTP range transfers, HTTP incomplete-response caching, lazy-pulled OCI layers, multipart object checksums, and chunked array stores all point the same way:
- some local bytes are not the same thing as full local completeness,
- chunk/shard layout metadata is not the same thing as current local coverage,
- a live lazy-fill path is not the same thing as offline readiness,
- and composite/per-part identifiers are not the same thing as one whole-object proof.

Those should stay visibly distinct in ViewFS.
That gives us room to make sparse/lazy imports, previews, and large-object workflows feel excellent without deciding one final sparse-store schema or one final whole-proof policy too early.

Do not decide yet:
- one universal sparse coverage representation across all object families;
- whether ViewFS normalizes on byte ranges, chunks, shards, file extents, or provider-specific hybrids;
- whether full proof is mandatory for every publish/launch/export act;
- whether live range fill is shell-owned, portal-owned, helper-owned, or provider-owned for every backend.


### 26. Delta recipes, exact bases, apply sessions, reconstructed objects, and receipts
A delta or patch artifact is not the same thing as the target object it can help reconstruct.
An exact basis requirement is not proof that the basis is local or still exact now.
A current reconstruction/apply session is not the same thing as a durable committed object.
A reconstructed target is not the same thing as live-handle continuity or same-path continuity.
A fallback full fetch is its own lane.
And a receipt is only history.

This split matters because HTTP delta/range work, VCDIFF, OSTree static deltas, and zsync/rsync-style reuse all point to the same lesson: transport/update efficiency should not collapse into identity, continuity, or current authority truth.

Consequences:
- ViewFS should keep delta artifacts, exact basis witnesses, current apply state, reconstructed target objects, and fallback full-fetch decisions visibly distinct.
- The shell should be able to show `needs base X`, `base missing`, `apply in scratch`, `full fetch fallback`, and `rebuilt from X + R` as different truths.
- Receipts/history should explain when delta reconstruction happened before without silently reviving present reconstructability.

Non-decisions:
- one universal delta format,
- one universal basis vocabulary,
- one final owner for apply sessions,
- whether delta artifacts are provider-local only or portable first-class objects.

## Revision 082: activation carriers, copy lineage, and object truth

Another especially useful seam is **activation carrier versus current live handle copy versus issuer-visible badge/witness versus object identity**.
Plan 9 namespaces, Fuchsia capability-routed namespaces, systemd socket activation/fd-store practice, UNIX descriptor passing, and seL4 badge discipline all point the same way:
- the way authority arrives at startup or handoff time is not the same thing as the current live copy;
- the current live copy is not the same thing as immutable object identity;
- issuer/courier witness is not the same thing as trust verdict;
- a receiver-local bind is not the same thing as the launch slot that delivered it;
- and any later reopen/revival lane is not the same thing as the current open copy.

Those should stay visibly distinct in ViewFS.
That gives us room to make object-store/import/handoff flows excellent without deciding one final durable-handle substrate too early.

Do not decide yet:
- one universal startup-slot primitive across all runtimes and platforms;
- one universal durable continuity/revival mechanism;
- whether restart continuity is shell-owned, supervisor-owned, portal-owned, or split;
- whether every arriving live handle can reveal one exact immutable object ref;
- one final portal/import/courier taxonomy beyond the requirement that all lanes tell the same split truths.



### 27. Store membership, synthetic views, live handles, published names, and receipts
- is this thing merely a local object-store fact, one restricted synthetic portal/provider view, one current live handle, one current publication site in this process view, or only one durable receipt/history artifact?
- a current published name is not the same thing as local object-store existence, and neither is the same thing as current live authority.
- a restricted synthetic view should stay visibly different from native local publication here.
- portal request/session state is not proof that this pane still has one live handle or one current bind.
- path-like labels should therefore describe one current publication site, not object essence.

What to avoid collapsing:
- local object-store membership or descriptor truth
- mediated synthetic views / portal projections
- live current handles
- local published names / binds
- durable receipts and remembered designators

What not to decide yet:
- whether early synthetic views are shell-owned, service-owned, or lower-level runtime objects;
- whether publication is always single-slot in Phase 1 or later admits overlays/search lists;
- whether the main durable reopen story is local-only, mediator-held, provider-held, or mostly deferred.

## Explicit-handle opens, rooted compat pathwalks, and ambient escapes are different questions

One more low-regret split is worth pinning while SlopOS is still in design:
- `I already hold a live handle and opened through it`;
- `I walked a path inside an already-held root/view/designator`;
- `a portal/powerbox/mediator minted or projected access for me`;
- `I used an ambient host escape hatch`;
- and `I only have a receipt/history row`.

Those are not interchangeable truths.
A rooted compat pathwalk may be a perfectly pragmatic bring-up move, but it should still remain narrower and louder than either direct-handle authority or portal-mediated grants.
An ambient host escape should remain louder still.

Low-regret commitments now:
- prefer explicit handle opens whenever they are available;
- keep rooted compat walkers rooted in already-held authority and explicit no-escape policy;
- keep portal mediation transcript-visible instead of laundering it into a fake native path;
- make ambient escape hatches searchable debt instead of silent convenience;
- and keep published-name/locality truth separate from all of the above.

What not to freeze yet:
- the final rooted-walker API surface;
- the final portal/import wire protocol;
- whether early ambient escapes are blocked, policy-gated, or developer-mode only;
- whether compat walkers belong in libc, shell helpers, runtime glue, or service helpers.


## Discoverability, enumeration, exact-name opens, and fit notes are different questions
Do not freeze one flattened answer to `can the actor see it?` yet.
Important splits:
- direct current authority versus exact-name reachability inside a held root/view;
- exact-name reachability versus full enumeration/listability of a container;
- browse/list truth versus search/index/provider suggestion truth;
- match quality / fit explanation versus current openability;
- and durable receipts/history versus any of the above.

Low-regret posture now:
- allow narrower exact-name opens without assuming list rights;
- treat enumeration as a separately reviewable metadata-disclosure surface;
- keep suggestions and completion-like candidates advisory;
- receipt what truth actually held;
- and keep published-name/locality truth separate from all of the above.

## Another question we should not collapse

### 17. Presence adverts, readiness, grant-needed posture, and current authority
A provider advert, a freshness-scoped readiness claim, a `grant needed` next step, an already-held live handle, and a durable receipt are not the same thing.

Why this matters:
- discovery/presence UI is useful long before current authority exists;
- a stale ready bit can lie just as badly as a stale path string;
- shell UX gets much better when `shown`, `ready`, `grantable`, `held`, and `history only` are different truths.

Working posture:
- provider/catalog presence should stay visibly weaker than current live authority;
- readiness should stay freshness-scoped and decay-aware rather than turning into a timeless badge;
- `grant needed` should be a first-class shell truth instead of a generic failure later;
- receipts/history should remember adverts and ready states without claiming they still hold now.


## Another question we should not collapse

### 10. Provider-ready, reacquire-needed, and local-realized truth
Question:
- is this thing merely advertised, satisfiable from a provider/substituter/promisor source, still waiting on one repair/rebind/reauth step, already realized locally, actively held now, or only remembered in history?

Why keep it separate:
- provider-ready is a useful promise, but it is still not local residence.
- restored or remembered work often needs one more explicit repair step before stronger claims become true.
- offline UX becomes far more honest when `reacquirable later` does not masquerade as `local now`.
- shell actions such as `make local`, `bind here`, and `hand to child` become much easier to explain.

Good answers might look like:
- provider-ready claims
- reacquire / repair obligations
- local-realization receipts
- current live handles
- locality / bind receipts
- history-only rows

## Claim tickets versus holder-bound grants versus passable live handles

Another easy overdecision would be to pick one universal `ticket` story too early.
That would blur together at least four different classes:
- a redeemable claim that might mint stronger authority later,
- a holder-bound grant that works only for the current proving holder/session/key,
- a passable live handle that can actually be copied or inherited now,
- and a spent/expired artifact that only records anti-replay or historical truth.

ViewFS should freeze the separation, but not the mechanism.
We do **not** need to decide yet whether holder proof is key-based, issuer-badged, session-local, or something smaller; whether claim tickets live in the object store or only in a mediator; or whether spent tickets compact into thinner receipts later.
We only need the shell and repo vocabulary to stop lying by treating all of those as one thing.


## Possession versus current invocability

Another easy overdecision would be to pick one universal `authorized now` story too early.
That would blur together at least six different classes:
- something is local or held now,
- its prior authentication event is fresh enough,
- it satisfies the stronger assurance class this action wants,
- immediate local presence or user verification has been satisfied,
- the action is invokable here now,
- and the transcript keeps some historical trace of that satisfaction.

ViewFS should freeze the separation, but not the mechanism.
We do **not** need to decide yet whether freshness and step-up are provider-local only, shell-mediated, authagent-mediated, or split; whether one satisfied challenge opens a short reusable window; or whether local presence uses badges, leases, drawers, or one-shot proof receipts.
We only need the shell and repo vocabulary to stop lying by treating current possession as if it always meant current invocability.


## Standing-watch good status versus live possession

Another easy overdecision would be to pick one universal `still valid` story too early.
That would blur together at least six different classes:
- something is still held or local now,
- one later status carrier says something about it,
- the local receiver stance decides how much to believe or act on that signal,
- a reversible hold or quarantine may now be active,
- a refresh or successor may be available or required,
- and the transcript keeps some historical trace of all of this.

ViewFS should freeze the separation, but not the mechanism.
We do **not** need to decide yet whether watch/status material is pushed or pulled; whether successor refresh is portal-owned, shell-owned, or provider-owned; whether all holds are reversible; or whether every provider gets one universal status taxonomy.
We only need the shell and repo vocabulary to stop lying by treating all of those as one timeless `validity` noun.


## Possession, local duplication, live lends, and representation exports

Another easy overdecision would be to pick one universal `share` story too early.
That would blur together at least five different classes:
- something is held here now,
- something can be duplicated locally,
- something can be lent live across one explicit courier lane,
- something can only be exported as a weaker representation,
- and something only survives as a receipt/history row.

ViewFS should freeze the separation, but not the mechanism.
We do **not** need to decide yet whether live lends are kernel-native, runtime-native, portal-mediated, or terminal-mediated; whether weaker export always means byte materialization versus projected-document export; or whether any live lend crosses machine boundaries.
We only need the shell and repo vocabulary to stop lying by treating all of those as one flattering `share` verb.

## Foreign-backed borrows, compat attaches, projected imports, and local realizations are different questions

Questions to keep separate:
- is this thing still fundamentally backed by another provider or mediator?
- did we merely make it usable here through one wrapper, relay, or runtime adapter?
- was it projected into this pane/view as a scoped synthetic local entry?
- was it explicitly localized here as bytes/object state?
- or are we only holding a receipt/history row?

Why this matters:
- borrowed foreign-backed usability is often the most honest current state and should not be treated as a failed approximation of local ownership;
- wrapper/relay attaches are valuable bring-up and compatibility tools, but they should not silently become the ontology of the local object model;
- projected imports are stronger than mere discovery and weaker than local realization, so the shell should be able to say `projected here` without laundering that into `local object`;
- materialized caches/replicas may still be sync/provider-backed rather than canonical local object-store truth;
- a durable receipt that something was attached/projected/localized before should not silently revive current locality or current provider reachability.

Working rule:
- keep `borrow_foreign`, `attach_wrapper`, `project_here`, `localize_here`, and `receipt_only` as visibly distinct shell/transcript classes.
- keep `make here` as an explicit transition rather than an automatic side effect of every open/import path.

Do not decide yet:
- one universal wrapper/relay ABI,
- one final projected-import taxonomy,
- whether local realization always means exact byte copy versus local replica versus local object-store commit,
- whether provider-backed borrows are expected to survive relaunch/offline by default.



## Route envelopes, authority sidecars, sink bindings, and receipts are different questions

Ask explicitly:
- is this thing only one typed route/plumb envelope?
- is it one optional sidecar that narrows or explains the route?
- did a sink actually accept a representation, projected bind, live bind, or localized import?
- or is it only one durable receipt/history artifact?

Why keep these separate:
- a route envelope is useful because it can be copyable and inspectable without acting like current authority;
- a sidecar may help fit, narrowing, or audit without becoming a capability container;
- sink acceptance is where actual local consequence begins and should say exactly what happened;
- a receipt can preserve exact consequence without silently reviving it as current routeability or current sink-held authority.

Working rule:
- keep `route_only`, `route_plus_sidecar`, `sink_accept_representation`, `sink_accept_bind`, `sink_accept_projection`, `sink_accept_localization`, and `receipt_only` as visibly distinct shell/transcript classes.
- keep designation-only route slips cheap and safe to share, and keep sink-side consequence explicit.

Do not decide yet:
- one universal route-envelope schema across all families,
- one universal sidecar taxonomy,
- whether any sidecar can ever carry narrowly live authority,
- whether replay may auto-represent prior sidecars,
- whether every sink bind/import/localize outcome shares one final result schema.

## Privilege brackets, borrowed authority, call-chain contexts, deny-only hints, and receipts are different questions

Ask explicitly:
- is this helper currently inside one bounded privilege bracket?
- what exact authority is being borrowed inside that bracket?
- what caller/plugin/pane context merely explains who asked?
- is there only one deny-only provenance hint or veto?
- or is this only one durable receipt/history artifact?

Why keep these separate:
- one bracket is execution posture, not a process-wide mode bit;
- borrowed authority is real current capability and should not dissolve into provenance;
- call-chain context is explanatory and should not become a silent grant;
- deny-only hints can safely narrow or veto without widening;
- a receipt can preserve exact explanation without reviving bracket or caller state.

Working rule:
- keep `bracket_active`, `borrowed_authority_active`, `call_context_only`, `deny_only_hint_present`, `deny_only_veto_fired`, and `receipt_only` as visibly distinct shell/transcript classes.
- keep `who asked?` visible while refusing to let caller provenance impersonate authority.

Do not decide yet:
- one final call-chain frame taxonomy,
- one final privilege-bracket carrier/API,
- whether any call context crosses machine or user boundaries,
- one final deny-only rule vocabulary,
- whether borrowed-authority drawers always name exact handles versus capability classes.

## Native attaches, adapted attaches, coerced representations, and local realizations are different questions

Ask explicitly:
- is the receiver currently talking to a directly native lane for this pane/process/tool?
- is one wrapper, relay, or compatibility membrane making it usable here?
- is the receiver only getting one alternate representation, preview stream, or translated surface?
- was there an explicit make-local step to gain stronger native/local semantics?
- or is this only one receipt/history row?

Why keep these separate:
- direct native fit is valuable truth and should not be hidden behind one generic `opened` bit;
- adapted attaches are often the right answer, but they should stay inspectable instead of becoming ontology by accident;
- coerced representations are useful because preview/import/render lanes are often real success states even when same-object attach is unavailable;
- local realization should remain an explicit fidelity/locality transition rather than one silent repair step;
- a durable receipt that a lane once worked should not silently revive current attach fit.

Working rule:
- keep `attach_native`, `attach_adapter`, `attach_relay`, `representation_coerced`, `localize_for_native`, and `receipt_only` as visibly distinct shell/transcript classes.
- keep `same object` versus `translated representation` inspectable at the sink.

Do not decide yet:
- one universal wrapper/relay ABI,
- one final alternate-representation taxonomy,
- whether some lanes can skip directly from coerced representation to durable local objecthood,
- whether native attach is mandatory for any Phase 1 surface,
- whether every adapter path deserves one standard UX label.



## Revision 097: command-surface layers, key actions, and external launches

Another especially useful seam is **built-in verb versus lexical expansion versus semantic command layer versus key action versus external launch versus receipt/history**.

What to keep separate:
- built-in product-native shell verbs
- typed lexical expansions such as abbreviations or snippet-like rewrites
- explicit overlay/module/custom-command layers
- keybound widgets / palette-only actions / key-table modes
- exact external executable or script launches
- durable receipts and transcript history

Why it matters:
- shell UX gets much better when the user can ask `what exactly won?`;
- command palettes and key tables become easier to trust when they do not silently pollute transcript command truth;
- abbreviation preview can stay helpful without impersonating semantic resolution;
- overlay activation can stay powerful without pretending product baseline changed;
- external launches can remain exact and capability-safe without flattening into built-in semantics.

Do not freeze yet:
- one final alias/abbreviation/snippet object model,
- one universal overlay/module schema,
- whether every key action can ever promote into one typed verb,
- or one universal palette protocol across host shells and terminals.


## Revision 098: editable buffers, parsed structure, diagnostics, and prepared actions

Another especially useful seam is **editable buffer versus parsed/highlighted structure versus advisory diagnostics versus compiled packet versus prepared action versus receipt/history**.

What to keep separate:
- current mutable prompt/buffer text or fragments
- current best parse/highlight structure, including recovery state
- advisory syntax/lint/hint output
- pane-local compiled command packets bound against current handles/receipts
- prepared actions that are actually reviewable/launchable
- durable receipts/history

Why it matters:
- a colorful buffer should not impersonate current authority or readiness;
- parser recovery is useful, but it is not exact intent;
- diagnostics can explain without becoming enforcement;
- compiled packets can differ across panes even when the visible text matches;
- history should stay descriptive instead of silently reviving old compile truth.

Do not freeze yet:
- one final shell parser or grammar;
- one final highlight token taxonomy;
- one final diagnostic engine;
- one final packet object model;
- or whether analyzers are shell-native, helper-provided, or terminal-mediated.

### 10. Namespace plans, live room bindings, portal sessions, local overlays, and reset receipts
Question:
- is this thing a saved switch/import plan, the room's current live binding, a portal/request session still in flight, a local-only overlay around the room, or only a receipt explaining what changed before?

Why keep it separate:
- a room-oriented shell gets much more honest when `planned`, `live now`, `pending session`, `local-only`, `expired`, and `receipt only` are different truths;
- local convenience state should be cheap to discard/rebuild and should not silently ride along with portable receipts or exported artifacts;
- reset/expiry/death events become more diagnosable when old anchors do not silently repair to `latest`.

Good answers might look like:
- namespace plans / switch targets
- live room-local bindings
- request/session rows
- local overlay records
- anchor-death / reset-scope receipts

### 10b. Activation kits, restart lockers, namespace pins, live room binds, and receipts
Question:
- is this thing the exact kit delivered at startup, one exact locker a manager still holds for restart, one namespace/view pin, the room's current live bind now, or only one receipt explaining what happened before?

Why keep it separate:
- startup truth should not impersonate durable persistence;
- manager-held restart continuity is narrower than both durable reopen and current live authority;
- namespace lifetime and namespace membership are different truths;
- warm exact, warm partial, cold repair, and cold fresh starts should not collapse into one fake `restored` bit.

Good answers might look like:
- activation/wake kits
- restart lockers
- namespace pins
- live room-local binds
- warm/cold receipts


### 13c. Live room binds, currentness witnesses, semantic epochs, repair offers, and receipts

- is this thing one current live room binding, one separate witness about whether that bind is still current/revoked/replaced/expired, one shell semantic-epoch fence, one bounded repair offer, or only durable receipt/history material?

Keep separate because:
- a current bind is not the same thing as the witness that says whether it is still current enough for the next verb;
- provider currentness and shell semantic footing can drift for different reasons and should not be flattened;
- a repair offer is a reviewed next move, not proof that the bind is current now and not a giant automatic repair plane;
- receipts should explain old witness checks or epoch shifts without reviving current authority.

Do not freeze yet:
- one universal currentness-witness schema;
- whether currentness is epoch-shaped, status-object-shaped, challenge-shaped, or layered;
- whether semantic epochs are room-, pane-, hop-, or anchor-local;
- whether repair offers are provider-authored, shell-authored, or mixed;
- which higher-risk verbs require stronger revalidation than low-risk open/reveal.


### 13d. Live room binds, currentness witnesses, renewal windows, retry advice, repair gates, and receipts

- is this thing one current live room binding, one separate witness about whether that bind is still current/revoked/replaced/expired, one renewal window that keeps the same live claim alive, one retry-advice hint, one repair gate that quiets automatic help, or only durable receipt/history material?

Keep separate because:
- a current bind is not the same thing as the witness that says whether it is still current enough for the next verb;
- renewing the same claim is not the same thing as granting fresh authority or promising broad health;
- retry advice is timing guidance, not authority and not proof of repair;
- a repair gate is a repeated-failure / repeated-miss judgment, not the same thing as one failed action;
- receipts should explain old renewals, waits, and gates without reviving current authority.

Do not freeze yet:
- one universal renewal protocol or lease algebra;
- one universal retry-budget grammar or jitter DSL;
- whether renewal windows are provider-authored, manager-authored, or mixed;
- whether repair gates are room-local, issuer-local, or supervisor-local;
- which higher-risk verbs may auto-renew versus requiring explicit review.


### 13e. Live room binds, visibility states, keep-warm leases, restore intents, deferred repair jobs, and receipts
Keep separate:
- what exact thing is bound here now;
- whether the room/process is foreground, hidden-but-serving, draining, or historical only;
- what narrow grant allows it to stay warm in the background;
- what separate restore/autostart intent allows it to come back later;
- what deferred repair/job lane may do work later;
- and what receipts/history merely explain what happened before.

Do not freeze yet:
- one final keep-warm lease protocol;
- one final restore/autostart carrier;
- whether restore intent is shell-owned, portal-owned, or supervisor-owned;
- whether deferred repair jobs share storage with task wrappers or only shell chrome;
- one final lifecycle-status enum for room tabs and headers.

### 13f. Live room binds, attention cues, interrupt grades, quiet windows, ack ledgers, and receipts
Keep separate:
- what exact thing is bound here now;
- what transient cue says it wants attention now;
- what separate interruption class says how strongly it may ask;
- what quiet/suppression posture says how we should currently surface it;
- what durable ack/follow-up row survives after the cue is gone;
- and what receipts/history merely explain what happened before.

Do not freeze yet:
- one final inbox or ack-ledger schema;
- one final interrupt-entitlement or urgent-review lane;
- whether quiet windows are shell-local, workspace-local, or policy-local;
- whether ack rows and receipts share storage;
- one final attention taxonomy for rooms, helpers, and jobs.

### 13g. Live room binds, summon beacons, activation batons, foreground turns, secure-entry gates, and receipts

Question:
- is this thing one current live room binding, one separate cue that it wants to be surfaced, one narrow baton proving it may try to raise/focus, one actual frontmost/focused truth now, one secure-entry/trusted-input gate, or only durable receipt/history material?

Keep separate because:
- wanting attention is weaker than being allowed to raise;
- being allowed to raise is weaker than actually being frontmost now;
- frontmost/focused is weaker than trusted-entry or secure-input mode;
- fullscreen/modal/show-more-room chrome must not silently become approval/login truth;
- receipts should explain prior activation/focus history without reviving it now.

Good answers might look like:
- summon/surface-me beacons
- activation baton artifacts
- frontmost/focused currentness rows
- secure-entry gates
- receipts/history only


### 13h. Live room binds, observe mirrors, automation leases, synthetic input lanes, secure-entry exclusions, and receipts
Questions to keep separate:
- is this thing one current live room binding, one separate semantic/screencast/accessibility mirror, one reviewable automation lease/session, one current synthetic-input lane, one secure-entry redaction/injection clamp, or only durable receipt/history material?
- is this proposal changing what is bound in the room, what is visible about it, what control posture is leased, what control can flow now, or only what history says happened before?

Do not collapse:
- live room binds
- observe/semantic mirrors
- automation lease/session posture
- synthetic input lanes
- secure-entry exclusions / redaction clamps
- receipts/history

Reason:
- observe-only truth, inject-now truth, and secure-entry blocking are all different risk classes, and the shell should be able to say exactly which one it knows.

### 13i. Live room binds, provider-backed projection sites, published room aliases, localizations, and receipts
Keep separate:
- what exact thing is bound here now;
- what separate provider/portal projection site makes it reachable here;
- what separate room-local alias or slot publishes it in this namespace;
- what separate localization/materialization fact says the bytes/object truly live here now;
- and what receipts/history merely explain what happened before.

Do not freeze yet:
- one final projection-site substrate or wrapper ABI;
- one final room-publication ledger or alias schema;
- whether localization means placeholder hydration, replica registration, or object-store commit in Phase 1;
- whether provider-owned versus local-owned halos are shell-authored, provider-authored, or mixed;
- how many simultaneous publication sites one object may carry in early phases.

## D111. Keep projected bases, local uppers, merged presentations, and publish results separate
Ask of every new proposal:
- is it changing the **base stack**,
- the **local writable upper**,
- the **merged presentation** the room traverses,
- the **publish/commit/adopt result**,
- or only **history/receipts**?

Keep separate because:
- a projected/provider/generated base is not the same thing as the local writable shadow above it;
- the merged presentation is a traversal convenience surface, not proof of durable object truth;
- hiding a lower entry locally is not the same thing as deleting it everywhere;
- a later publish/commit/adopt act is not proof that the merged/upper state was already durable.

Do not freeze yet:
- one final overlay/worktree representation;
- one final whiteout/opaque marker family;
- whether multiple ordered lowers or multiple uppers are admitted in Phase 1;
- whether publish results always target room aliases, local objects, provider pushes, or several families.



## And another question we should not collapse

### 10. Local draft, pushback basis, provider verdict, and adopted result
Question:
- is this thing the room's current live bind, a private local editable shadow, the exact expected old state for a pushback, the provider's verdict on that pushback, the locally adopted post-verdict state, or only a receipt/history row?

Why keep it separate:
- one local draft can stay perfectly useful even after its pushback basis goes stale.
- a provider can reject, accept, or conflict a pushback without dictating what the room adopts locally next.
- shell UX becomes much more honest when it can say `draft`, `based on`, `provider rejected`, `fast-forwarded locally`, or `receipt only`.

Good answers might look like:
- local shadow / draft session
- expected old digest / etag / generation
- lease plus expected old state
- provider verdict artifact
- locally adopted result record
- pushback receipt / conflict receipt


### 11. Accepted request, operation ticket, completion verdict, and local adoption
Questions to keep asking:
- is this thing the room's current live bind, a private local editable shadow, one accepted request/admission, one provider operation/status ticket, one later completion verdict, one locally adopted post-settlement state, or only a receipt/history row?

Why this matters:
- one request can be accepted now and still fail, expire, or stay pending later.
- one operation handle can be useful follow-up state without being object identity or durable success.
- one provider can settle a request later without dictating what this room adopts locally next.
- one old receipt can explain that a request was admitted without proving that the provider still has a live current status endpoint now.

Keep these classes separate:
- live room binding
- local edit shadow
- accepted request / admission receipt
- provider operation / status ticket
- completion verdict
- locally adopted result
- durable receipt / history row

Do not freeze yet:
- one universal async mutation protocol
- one final operation-ticket schema
- whether every provider must expose pollable status
- whether local rooms auto-adopt on later settlement or always ask

### 12. Caller request context, detached root, deadline intent, cancellation state, and provider follow-up
Questions to keep asking:
- is this thing the room's current live bind, the caller-bound request context for one attempt, a detached cleanup/continuation root, one current deadline intent, one live cancellation state, one provider operation ticket, or only a receipt/history row?

Why this matters:
- a caller can stop waiting without proving the provider stopped too.
- a detached cleanup root is not the same thing as an ordinary child context.
- a deadline firing is not the same thing as a provider verdict.
- a provider operation ticket can survive after the original caller context is gone.
- one old receipt can explain why work stopped waiting without proving that any current continuation still exists now.

Keep these classes separate:
- live room binding
- caller request context
- detached root / cleanup root / provider continuation root
- deadline intent
- current cancellation state
- provider operation ticket
- durable receipt / history row

Do not freeze yet:
- one universal request-context wire format
- one universal detach-root carrier
- whether detached cleanup and detached long-running follow-up share storage
- whether deadline intent becomes durable object-store state or stays witness/receipt chrome

### 13. Action authority, payer roots, budget leases, spend reservations, and charge verdicts
Questions to keep asking:
- is this thing current action authority, one explicit payer root, one bounded budget lease, one spend reservation/admission, one actual charge verdict, one provider-side effect/local adoption, or only a receipt/history row?

Why this matters:
- `can do this` is not the same as `will pay for this`.
- one budget lease can exist without any charge landing yet.
- one provider can charge a different party than the caller expected if fallback or misconfiguration exists.
- one old charge receipt can explain cost without proving a live sponsor still exists now.

Keep these classes separate:
- action authority
- payer root / sponsor lineage
- budget lease
- spend reservation / admitted spend lane
- charge verdict
- provider-side effect / local adoption
- durable receipt / history row

Do not freeze yet:
- one universal payer-root or meter schema
- one universal budget-lease carrier
- whether reservations and final charges share IDs
- whether any of this becomes ViewFS object-store truth instead of adjacent provider/receipt truth

### 14. Object-home rooms, attached tools, imported binds, published names, and retention roots
Questions to keep asking:
- is this thing one object-home room seed, one currently attached tool/editor/service session, one later imported capability/object, one local published name, one explicit retention root, or only a receipt/history row?

Why this matters:
- one tool can be attached now without proving it owns the whole room model.
- one imported object can be useful without becoming part of the room's original home set.
- one published local name can help navigation without proving store membership or retention.
- one retention root can keep bytes alive without proving there is still a live room or attached tool now.

Keep these classes separate:
- object-home room seed
- attached tool/editor/service session
- imported capability/object bind
- local published name
- explicit retention root / root ledger row
- durable receipt / history row

Do not freeze yet:
- whether every important object gets its own room by default
- one universal room-layout convention per object family
- one final `open with` versus `attach tool` flow
- whether retention roots are shell-owned, service-owned, or mostly hidden behind adjacent products


### 28. Object identity, capability facets, grouped kits, live room binds, and published names
- is this thing the underlying object identity, one chosen capability facet over that object, one grouped authority kit, one current room-local bind of that facet, one current published name, or only one receipt/history artifact?
- the same object may legitimately have an inspect facet, edit facet, publish facet, automation facet, or receipt-only reminder without those collapsing into one noun.
- a grouped kit is not proof that every member is currently bound here, and a published name is not proof that every facet is in scope.
- opaque/sealed handles are often a feature, not a bug, when the alternative is laundering facet choice back into stringly rediscovery.

What to avoid collapsing:
- underlying object identity
- chosen capability facet / rights shape
- grouped authority kits
- current room-local binds
- current published names
- durable receipts/history

What not to decide yet:
- one universal facet taxonomy across all object families;
- whether facets are always separate minted handles, wrappers over a base handle, or mixed;
- whether grouped kits are transient only or sometimes durable;
- whether a published name defaults to inspect, edit, publish, or some tool-shaped facet.


### 29. Descriptor/proof-only rows, verify-only facets, live read/edit/publish facets, and room binds
- is this thing a descriptor/proof row, a verify-only facet, a live read facet, a live edit/publish facet, one current room bind of one facet, or only one receipt/history artifact?
- SlopOS wallets and docrefs already say descriptive rows are not the same thing as current authority, and lease posture says the proxy may be the authority while the descriptor is evidence only.
- Tahoe-LAFS is a useful reminder that one object can legitimately have weaker verify/read forms and stronger write forms without those collapsing into one noun.
- Linux `O_PATH` is a useful reminder that a descriptor can designate and support descriptor-level operations while byte I/O still fails.
- Opaque/sealed token forms are often a feature, not a bug, when the alternative is laundering proof or designation back into ambient rediscovery.

Keep separate:
- descriptor / proof-only card
- verify-only facet (if any)
- live read facet
- live edit or publish facet
- current room-local bind
- durable reopen or receipt/history material

Do not decide yet:
- whether every ViewFS object family needs a verify-only facet;
- whether proof-only rows are derived from descriptors, live handles, or separately minted tickets;
- one universal opaque-token or seal/unseal ABI;
- whether read and verify are distinct on every backend or only on some families.


### 30. Grant outlooks, issued bounds, restore tokens, live binds, and death verdicts
- is this thing a preflight grant outlook, one reviewed issued-bounds descriptor/evidence row, one restore/reactivation token or repair route, one current live bind, one explicit death-state verdict, or only one receipt/history artifact?
- a `granted` outlook is not the same thing as a current live bind, and one old descriptor is not a hidden status oracle.
- a restore token or repair offer is not the same thing as current live authority.
- reason-rich endings such as `revoked`, `expired`, `session closed`, `token spent`, or `target changed` are more repairable than one vague `stale` bucket.

Keep separate:
- grant outlook / preflight posture
- reviewed issued-bounds card
- restore/reactivation material
- current live bind
- explicit death-state verdict
- durable receipt / history row

Do not decide yet:
- whether every ViewFS family gets a queryable grant outlook;
- one universal restore/reactivation token family;
- whether death verdicts are provider-authored, locally inferred, or mixed;
- whether issued-bounds cards live in the object store or stay adjacent descriptors.

### 31. Semantic object cores, exact byte proofs, structured addresses, live facets, and receipts
- is this thing the semantic object core we mean to keep talking about, one exact byte proof, one chunk/codec/reference-sensitive structured address, one designation/name/locator, one current live facet, or only one receipt/history artifact?
- several useful `hash-like` identities can coexist without meaning the same thing.
- one raw-byte proof does not automatically settle semantic sameness, and one structured address does not automatically mean `same exact bytes`.
- a current live facet should never be inferred from one old proof row, name, or receipt.

Keep separate:
- semantic object core
- exact byte proof / canonical-form proof
- structured address / chunk-root / closure/store-path address
- designation / published name / locator hint
- current live facet
- durable receipt / history row

Do not decide yet:
- one universal semantic-object-core family;
- whether every object family gets a semantic core distinct from exact bytes;
- one universal canonicalization rule;
- one universal chunk/shape-address family;
- whether designators are title-first, digest-first, or mixed.

### 18. Stable review stamp versus descriptive envelope versus explain sidecar versus live bind
Question set:
- what smallest stable digest or summary should gate drift/reconsent?
- what richer descriptive envelope helps humans review and compare context?
- what graph/diff/provenance sidecars help explain the review envelope?
- what current live bind actually exists here now?
- what only survives as receipt/history?

Why this must stay split:
- volatile descriptive fields should not churn the stable gate key;
- explainability should not silently become authority;
- current live power should not be inferred from one old review wallet/card;
- one family may need several sidecar kinds without forcing them all into the core stamp.

Non-decision to preserve:
- do **not** pick one universal authority-core digest family yet.
- do **not** require every family to share one envelope or sidecar schema.
- do **not** let `same reviewed core` automatically imply `bound here now`.


### 32. Strong proofs, weak validators, comparison profiles, live facets, and receipts
- is this row one exact strong proof, one weaker sameness validator, one declared comparison profile, one current live facet, or only one receipt/history artifact?
- a weak validator can be extremely useful without being strong enough for exact range or mutation-sensitive acts.
- a stable review stamp or patch-shaped key can be valuable while still being intentionally smaller than the full object/envelope.
- the shell should not hide which comparison profile is being used when it says `same`, `changed`, or `cannot compare`.

Keep separate:
- strong proof / exact witness
- weak validator / sameness hint
- comparison profile / declared equivalence rule
- current live facet
- durable receipt / history row

Do not decide yet:
- one universal strong-proof digest family;
- whether every family has a weak-validator lane;
- one universal comparison-profile registry;
- whether comparison profiles are provider-owned, shell-owned, or shared;
- whether one family may expose several weak-validator lanes at once.


### 33. Object core, designation, revision token, order scope, supersession row, live facet, and receipt
- is this row the semantic object core, one human-facing designation, one current head/revision token, one conflict/order scope, one supersession/tombstone row, one current live facet, or only one receipt/history artifact?
- a designation can remain stable while the current head changes.
- a revision token can advance without proving semantic sameness, exact byte sameness, or current live authority.
- an order scope can be narrower or different from object identity.
- a supersession row can be historically useful without being current truth.

Keep separate:
- semantic object core
- designation / published name / docref-like pointer
- revision token / current head witness
- order scope / conflict stream
- supersession row / tombstone / replaced-by evidence
- current live facet
- durable receipt / history row

Do not decide yet:
- one universal revision-token family;
- one global logical clock;
- whether order scopes are always object-local;
- one universal supersession-row schema;
- whether every family exposes durable supersession rows.

### 34. Semantic record, canonical payload, signed wrapper, wire copy, live facet, and receipt
- is this row the semantic record we mean, one canonical payload under one profile, one signed/authenticated wrapper, one concrete wire/storage copy, one current live facet, or only one receipt/history artifact?
- a semantic record can survive several wrapper or wire forms.
- a canonical payload can stay stable while signatures, signers, timestamps, or wrappers rotate.
- a wrapper can be present while the payload is detached or no longer in hand.
- a wire copy can be useful for logging/export/history without being the canonical proof or the live object.

Keep separate:
- semantic record / review meaning
- canonical payload / normalized bytes
- signed wrapper / authenticated envelope
- wire copy / transport-export-log copy
- current live facet
- durable receipt / history row

Do not decide yet:
- one universal canonicalization family;
- one universal wrapper/signature format;
- whether every family permits detached payloads;
- one universal media-type taxonomy;
- whether wrappers are provider-owned, portal-owned, or shell-owned.



### 35. Fresh object identity, shared backing, copy lineage, live facet, and receipt
- is this row the fresh logical object we created, one shared-backing optimization, one copy/clone lineage relation, one current live facet, or only one receipt/history artifact?
- a fresh object can be real even when storage stays shared for a while.
- shared backing can vanish after divergence without changing the historical fact that the object was born cheaply.
- lineage should be explicit evidence, not inferred from same bytes, same path, or same provider label.
- a current live facet is stronger than every backing/lineage row.

Keep separate:
- fresh object identity / newly materialized working copy
- shared backing / block-extent-store reuse
- copy lineage / parent-origin-rebuilt-from evidence
- current live facet
- durable receipt / history row

Do not decide yet:
- one universal clone/reflink ABI;
- whether every provider exposes backing-sharing visibility;
- one universal lineage schema;
- whether `unshare`, `promote`, or `adopt as primary` are universal verbs;
- whether shell, portal, or provider owns backing-visibility UX.

## Revision 081: upload sessions, part coverage, completion manifests, and committed objects

Another especially useful seam is **upload session versus part coverage versus completion manifest versus committed object versus abort verdict**.
Amazon S3 multipart upload, tus resumable uploads, OCI chunked blob upload, and Google Cloud Storage resumable sessions all point the same way:
- one upload/resume session is not the same thing as the final durable object,
- one part/offset progress row is not proof that finalization succeeded,
- one completion manifest is not the same thing as current live authority,
- one abort verdict is not the same thing as tombstoning the final durable object,
- and one history row is not current upload truth.

Those should stay visibly distinct in ViewFS.
That gives us room to make imports, large-object ingest, portal-mediated transfers, and custom-shell progress UX feel excellent without deciding one final multipart or resumable-upload substrate too early.

Do not decide yet:
- one universal resumable-upload protocol across all providers;
- one universal part/chunk numbering family;
- whether completion manifests are explicit objects or provider-hidden for every backend;
- whether cleanup/abort is synchronous everywhere;
- whether upload sessions are shell-owned, portal-owned, helper-owned, or provider-owned.


### 36. Assembly recipe, member descriptors, aggregate object, realized work surface, live facet, and receipt
- is this row one recipe describing intended assembly, one member descriptor proving ingredients, one durable aggregate object, one realized/unpacked work surface, one current live facet, or only one receipt/history artifact?
- a recipe can exist before any durable aggregate object is born.
- member descriptors can remain valid evidence after source URLs, local paths, or provider-native names disappear.
- an aggregate object can be durably committed while no realized work surface exists in the current room.
- a realized work surface can be evicted and rebuilt without changing the aggregate object.
- a current live facet is stronger than every recipe/member/aggregate/history row.

Keep separate:
- assembly recipe / declarative intent
- member descriptors / exact referenced ingredients
- aggregate object / durable assembled result
- realized work surface / unpacked-mounted-hydrated presentation
- current live facet
- durable receipt / history row

Do not decide yet:
- one universal recipe language;
- one universal descriptor vocabulary across all families;
- whether every aggregate object is reproducible from recipe alone;
- whether every realized work surface is itself a durable object;
- whether shell, portal, provider, or helper owns realization;
- one universal unpack/materialize protocol.

## Revision 082: assembly recipes, member descriptors, aggregate objects, and realized work surfaces
## Revision 083: committed objects, retention clocks, hold states, and purge verdicts
Another especially useful seam is **committed object versus retention clock versus hold state versus purge verdict versus live facet**.

Ask these separately:
- is there one durable committed object or object version here now?
- is there one retain-until or similar deletion/replacement fence?
- is there one temporary, event-driven, legal, or investigation hold?
- is the current purge/delete answer eligible, blocked, pending lifecycle/GC, or already purged?
- is there one current live facet that still allows inspect/read/edit/publish/delete now?
- is this only a receipt/history row?

Do not decide yet:
- one universal retention/hold taxonomy;
- whether retention is object-version-local, anchor-local, aggregate-local, or mixed;
- whether event-based holds, temporary holds, and legal holds all deserve first-class universal lanes;
- whether purge is one user verb, one lifecycle engine, one GC pass, or several distinct families;
- whether retained objects may still allow some metadata/head movement.


Another especially useful seam is **assembly recipe versus member descriptor versus aggregate object versus realized work surface versus live facet**.
Google Cloud Storage composite objects, OCI manifests and image indexes, `git write-tree`, and containerd pull/unpack all point the same way:
- one recipe describing how to assemble is not the same thing as one durable aggregate object,
- one member-descriptor set is not the same thing as a realized local work surface,
- one aggregate object is not proof that anything is unpacked or hydrated in the current room,
- one realized work surface can disappear and later be rebuilt without changing aggregate identity,
- and one history row is not current live authority.

Those should stay visibly distinct in ViewFS.
That gives us room to make imports, bundles, descriptor graphs, mounted work surfaces, and custom-shell assembly UX feel excellent without deciding one final package or aggregate-object substrate too early.

Do not decide yet:
- one universal bundle/aggregate ABI across all providers;
- one universal descriptor taxonomy;
- whether realization is always explicit or can sometimes be implicit;
- whether every aggregate object must support later realization;
- whether realization ownership lives in provider, portal, helper, or shell.


### 37. Transient staging capsule, seal state, courier handoff, committed object, live facet, and receipt
- is this row one private staging capsule, one freeze/seal posture, one local courier hop, one durable committed object, one current live facet, or only one receipt/history artifact?
- one staging capsule can exist before any durable object-store member is born.
- one seal state can say `review this exact payload` without saying anything about durable reopen.
- one local courier handoff can move exact bytes or exact access without publishing anything into a namespace.
- one committed object is a later explicit birth event.
- one current live facet is stronger than every draft/seal/courier/history row.

Keep separate:
- transient staging capsule / exact draft payload
- seal state / current freeze posture
- courier handoff / explicit local transfer
- committed object / durable imported-or-published result
- current live facet
- durable receipt / history row

Do not decide yet:
- one universal staging primitive across all providers;
- one universal seal taxonomy;
- whether handoff is always FD-passing, portal-owned, or runtime-owned;
- whether every capsule can later become a committed object;
- whether any capsule survives restart or machine transfer;
- one universal capsule-to-commit ABI.

## Revision 083: staging capsules, seal states, courier handoffs, and committed objects

Another especially useful seam is **transient staging capsule versus seal state versus courier handoff versus committed object versus live facet**.
Linux `memfd_create()`, file seals, UNIX FD passing, `O_TMPFILE`, and current memfd-preservation caveats all point the same way:
- one exact private draft is not the same thing as one durable object-store member,
- one freeze-for-review bit is not the same thing as publication or durable reopen,
- one local courier handoff is not the same thing as namespace publication or import,
- one continuity story that keeps bytes says less than one durable commit or durable grant story,
- and one history row is not current live authority.

Those should stay visibly distinct in ViewFS.
That gives us room to make helper-edit loops, export-review flows, local exact transfer, and custom-shell draft UX feel excellent without deciding one final staging substrate too early.

Do not decide yet:
- one universal draft-capsule primitive;
- whether shell, portal, provider, or helper owns freeze/commit transitions;
- whether every handoff is explicit local transfer or can be escalated into import;
- whether any continuity path may preserve capsules across restart;
- one universal commit-last protocol.

### 38. Sealed object, recipient wrap, rewrap plan, unwrap handle, clear facet, and receipt
- is this row one durable sealed object, one per-recipient wrap row, one planned or completed rewrap, one current unwrap handle, one current clear facet, or only one receipt/history artifact?
- one sealed object can exist before any process here can clear it.
- one wrap row can say `this recipient or key slot was provisioned` without saying any clear facet is bound now.
- one rewrap can change recipient coverage or key-version posture without proving semantic object rebirth.
- one unwrap handle can exist without exporting secret-bearing key material or yielding cleartext here yet.
- one current clear facet is stronger than every seal/wrap/rewrap/history row.

Keep separate:
- sealed object / durable encrypted package
- recipient wrap / one wrapped DEK or equivalent recipient row
- rewrap plan / rotate-add-drop-recipient act
- unwrap handle / current authority to clear one wrap
- clear facet / currently usable inspect-read-edit-publish power
- durable receipt / history row

Do not decide yet:
- one universal envelope or recipient-wrap format;
- whether wraps are inline, sidecar, or provider-indexed;
- one universal recipient taxonomy;
- whether rewrap is in-place, version-producing, or provider-specific;
- whether clear facets can survive restart or machine transfer;
- one universal unwrap-handle ABI.

## Revision 084: sealed objects, recipient wraps, rewrap plans, and unwrap handles
Another especially useful seam is **sealed object versus recipient wrap versus rewrap plan versus unwrap handle versus clear facet**.
JWE multi-recipient envelopes, WebCrypto opaque key references, and Google Cloud KMS envelope-encryption / re-encryption guidance all point the same way:
- one sealed object is not the same thing as one wrap roster,
- one wrap roster is not the same thing as a current clear facet,
- one key rotation or rewrap act is not the same thing as semantic object rebirth,
- one unwrap handle is not the same thing as exported secret-bearing key material,
- and one history row is not current clear authority.

Those should stay visibly distinct in ViewFS.
That gives us room to make sealed imports, rewrap/rotate workflows, encrypted object storage, and custom-shell review UX feel excellent without deciding one final envelope or key-handle substrate too early.

Do not decide yet:
- one universal encrypted-object transport;
- whether rewrap belongs to shell, portal, provider, or helper UX;
- whether clear facets may be cached or escrowed across sessions;
- whether recipient rows are portable, provider-local, or mixed;
- one universal unwrap-via-mediator flow.



## Revision 085: durability profiles, redundancy layouts, repair verdicts, and availability states
Another especially useful seam is **committed object versus durability profile versus redundancy layout versus repair verdict versus availability state versus live facet**.

Keep asking:
- is this row the durable object itself, the intended protection target, the concrete share/replica layout, the current repair answer, the current availability answer, the live facet, or only one receipt/history artifact?
- one committed object can exist before every intended replica/share catches up.
- one durability target can exist before the current layout satisfies it.
- one repair receipt can exist without proving current health now.
- one object can be readable now while still degraded.
- one live facet can exist even while redundancy is unhealthy, and redundancy can be healthy without any process here currently holding a live facet.

Non-decisions to preserve:
- committed object / durable object record
- durability profile / survivability target
- redundancy layout / share-placement row / replica-placement row
- repair verdict / scrub result / heal-needed answer
- availability state / retrievability answer
- live facet / current authority
- receipt / history


## Revision 086: residency profiles, placement realms, route endpoints, and egress gates
Another especially useful seam is **committed object versus residency profile versus placement realm versus route endpoint versus egress gate versus live facet**.

Keep asking:
- is this row the durable object itself, the intended data-boundary rule, the current placement realm/site set, the current access route, the current export/egress answer, the live facet, or only one receipt/history artifact?
- one residency profile can exist before every intended copy arrives where policy wants it.
- one route endpoint can be current without proving the object is present there.
- one secondary read lane can exist without implying current write placement or zero lag.
- one egress denial can coexist with a current readable live facet.
- one old placement or route receipt can explain locality without proving current boundary truth now.

Non-decisions to preserve:
- committed object / durable object record
- residency profile / intended realm-or-jurisdiction posture
- placement realm / current site-set or provider-hidden placement summary
- route endpoint / current access path truth
- egress gate / boundary-crossing allow-deny-review answer
- live facet / current authority
- receipt / history

## Revision 136: committed objects, access propagation, public cache copies, and cache trails
Another especially useful seam is **committed object versus access-propagation state versus public-cache copy versus cache trail versus live facet**.

Questions this helps answer:
- is this row the durable object itself, one still-propagating grant/revoke/config change, one shared/public cache visibility story, one cache-path explanation, the live facet, or only one receipt/history artifact?
- did the origin change settle, or is that only true for one cache path?
- does a stale public copy still exist even if the origin or permission changed?

Good nouns to keep separate:
- committed object / durable object or version truth
- access propagation / settled, pending, provider hidden, or history only
- public cache copy / cacheable, stale-possible, bypassed, purged, or unknown
- cache trail / hit-miss-forward-ttl-stored detail
- live facet / inspect-read-edit-publish authority held here now
- receipt/history / what was true then

What not to decide yet:
- one universal cache object model,
- one final revocation/invalidation API,
- whether cache trails are always visible or only in debug/receipt modes,
- whether publication/cache behavior differs by object family or provider.


## Revision 137: committed objects, prefix projections, folder resources, listing snapshots, published names, and live facets
Another especially useful seam is **committed object versus prefix projection versus provider folder resource versus listing snapshot versus published name versus live facet**.

Questions this helps answer:
- is this row the durable object itself, one folder-like projection inferred from names, one provider-native folder resource, one listing snapshot or feed state, one visible published name, the live facet, or only one receipt/history artifact?
- does one prefix prove a folder exists, or only that tools grouped names that way?
- does one folder-looking row prove a current complete listing, or only one cached/snapshotted browse result?
- does one published name prove a current room bind, or only that the object is named there?

Good nouns to keep separate:
- committed object / durable object or version truth
- prefix projection / folder-like browse grouping over names or delimiters
- provider folder resource / managed folder / hierarchical directory when the backing system really has one
- listing snapshot / feed page / cached browse answer
- published name / key / alias / visible placement string
- live facet / inspect-read-edit-publish authority held here now
- receipt/history / what was listed, projected, or bound then

What not to decide yet:
- whether ViewFS Phase 1 exposes provider-native folder resources directly,
- whether flat object stores get one canonical delimiter or several projection modes,
- whether published names and room binds share implementation storage,
- whether listing snapshots are always reproducible or sometimes best-effort only.

## 7. Planned launch/import shape versus current live authority

Revision 138 adds one more non-decision that should stay explicit until the SlopOS datacube has more implementation pressure behind it.

Do not collapse:

- a reviewable launch/import **plan**;
- the **bound root** or local namespace actually installed for a subject;
- the exact **handle slot table** actually delivered;
- a portal-owned **import ticket/request/session**;
- an adopted **live bind/facet** usable now;
- a durable **receipt/history** row.

Useful decisions we can make now:

- every process/helper should be described by explicit roots and slots, not ambient inheritance lore;
- portal tickets should be weaker than live binds and should not become durable reopen authority by default;
- receipts should explain and audit authority transitions without silently restoring them;
- shell UI should render the difference between `planned`, `bound`, `ticket`, `live`, and `history only`.

Decisions we are still deferring:

- exact handle-slot schema;
- exact namespace/launch-plan serialization;
- exact portal-ticket lifetime model;
- exact rights taxonomy;
- exact persistence/reopen semantics for live authority;
- whether these shapes become datacube objects, execution-pack rows, CapStore entries, D-NS rows, D-POWERBOX receipts, or some mix.

## Revision 139 non-decision: capability-flow evidence is not capability authority

Do not decide yet whether ViewFS handles are fd-like, object-ref-like, RPC-reference-like, seL4-slot-like, WIT-resource-like, provider-token-like, or mixed. The current design decision is only to keep these lanes apart:

- live handle inventory;
- custody/derivation story;
- outflow/export gate;
- redacted flow snapshot/diff;
- leak/confinement verdict;
- live export/proxy/borrow;
- durable receipt/history.

Non-decisions to preserve:

- one final capability graph schema;
- one final export-token format;
- one final custody-chain storage model;
- one universal currentness witness;
- one UI for all `share`/`open with`/`attach` actions;
- one answer to whether handles are directly passable, proxy-only, borrow-only, or bytes-only across every boundary.

Design docs should use explicit vocabulary instead of implying that a receipt, graph node, path, permission-store row, or wallet summary is current authority.


### 128. Durable root commits, epoch fences, restore intents, resurrection gates, activation targets, live binds, and receipts
Question:
- is this thing a recorded durable root update, a currentness / anti-rollback witness, a requested restore action, a current revalidation gate for dormant descriptors, a selected activation target, the live handles actually installed now, or only history?

Why keep it separate:
- persistent capability systems are powerful exactly because they design persistence and authority together; bolting persistence onto a handle table after the fact risks rollback and resurrection bugs.
- SlopOS CapStore posture already keeps durable commits, named roots, epochs, artifacts, durable refs, and restore checks explicit; ViewFS should steal the separation without freezing one final store ABI.
- cloud object stores and consensus stores show that currentness witnesses are their own layer; content identity or a root name alone does not prove a safe current tip.
- portal anchors, sturdyrefs, keyrefs, and secretrefs must pass current gates before they become live handles again.

Good answers might look like:
- root commit ledgers;
- epoch fences / root-tip witnesses;
- restore tickets;
- resurrection-gate verdicts;
- activation previews/targets;
- live-after-restore slot maps;
- receipt-only ghosts.

Open decisions:
- whether durable roots are CapStore commits, manifests, append-log rows, provider-native heads, or a mix;
- whether epoch fences are logical counters, transparency proofs, consensus revisions, provider generations, or hardware counters;
- how much persistence belongs in ViewFS versus SlopOS substrate;
- whether rollback becomes an ordinary user lane, a recovery lane, or a developer-only lane;
- whether persistent capabilities are ever transparent or always explicit.

## 10. Retention and collection shape versus current live authority

Revision 141 adds another non-decision that should stay explicit while the ViewFS object store, SlopOS CapStore, portal import, and capability-handle models are still fluid.

Do not collapse:

- durable **reachability roots**;
- runtime **live-handle roots**;
- explicit **pin / hold / lease** records;
- staleable **sweep candidates**;
- **deletion finalizers** and cleanup barriers;
- **collected ash / tombstones**;
- current **live facets**;
- durable **receipts/history**.

Useful decisions we can make now:

- caches, indexes, previews, list snapshots, and old receipts are not roots by default;
- live handles and in-flight jobs can temporarily protect backing material without becoming durable pins;
- collection should have dry-run / why-retained surfaces before it has irreversible power;
- finalizers should be named, owned, inspectable, and releasable rather than mystery `busy` state;
- ash/tombstone receipts should stop accidental resurrection without reintroducing the bytes or authority.

Still deliberately open:

- the final collector algorithm;
- whether roots live in CapStore, ViewFS, provider stores, or all three;
- how runtime live-handle liveness is exposed to the collector;
- how privacy-preserving why-retained explanations work;
- whether tombstones are universal or only used for rollback-sensitive families.

## Revision 142 non-decision: quarantine/safe-open evidence is not trust or authority

Do not decide yet whether quarantine state lives in object metadata, a CH-ATTR layer, a policy service, a root ledger sidecar, provider-local state, or some combination. The current design decision is only to keep these lanes apart:

- origin evidence and import lineage;
- object-local quarantine/risk mark;
- request-local safe-open capsule/materialization;
- viewer residue / content-derived data exhaust;
- derived or sanitized artifact identity;
- explicit trust-clearance / override decision;
- current live open or execution authority;
- receipt/history.

Useful decisions we can make now:

- selected/imported is not trusted;
- same digest is not same trust;
- preview/open success is not clearance;
- content-derived caches, snippets, thumbnails, embeddings, summaries, and MRU rows are not harmless by default;
- sanitized or derived artifacts need their own identity and parent evidence;
- trust for preview/edit/active-content/execution are different scopes;
- old receipts do not restore current live-open authority.

Still deliberately open:

- final quarantine schema and propagation algorithm;
- final safe-open compartment implementation;
- exact content-disarm/sanitizer model;
- whether any trust can ever be reused by content identity alone;
- whether embeddings/summaries are first-class ViewFS objects or provider-local artifacts;
- how much redacted origin should be visible to ordinary users versus developer views.

### 52. Container envelopes, member claims, extraction plans, materialization roots, namespace commits, live opens, and receipts

Question to keep asking:
- is this thing the archive/container envelope, a member claim inside it, a reviewed extraction plan, a sterile materialization root, an extracted member capsule/fresh object, a namespace commit, a current live open/mount, or only a receipt/history artifact?

Low-regret split:
- member names and link targets are claims, not authority;
- extraction planning is a review/checkpoint layer before materialization;
- materialization can happen in a sterile root without publishing into the current view;
- extracted members are fresh objects/projections with parentage and quarantine;
- namespace publication is a separate mutation with currentness/conflict witnesses;
- live opens/mounts stay stronger than every envelope, plan, capsule, and receipt.

Useful future objects:
- container envelopes;
- member claim tables;
- extraction plans and path-guard profiles;
- sterile materialization roots;
- extracted member capsules;
- namespace commit/adoption receipts;
- live materialized facets.

Non-decisions to preserve:
- one final archive/container parser ABI;
- one final representation for symlinks, hardlinks, xattrs, ACLs, device nodes, whiteouts, sparse files, duplicate names, and platform metadata;
- whether archive views are lazy, eager, or both;
- whether OCI-like images are object trees, packages, runnable roots, or separate launch artifacts;
- one final safe-extract sandbox or receipt schema.

## Revision 144 split: supply-chain evidence versus admission versus live authority

Keep artifact envelopes, inventory/SBOM claims, component locator aliases, vulnerability/advisory/VEX statements, provenance/signature/transparency/update evidence, local admission verdicts, activation targets, current live facets, and receipts separate.

The motivating failure mode is **trusted-package folklore**. A user or helper sees a signed bundle with an SBOM, a few VEX `not_affected` statements, a package URL, and a transparency-log entry, then treats that braid as executable authority. ViewFS should instead preserve a reviewable path: exact subject -> evidence -> local policy cut -> activation target -> live facet -> receipt.

Non-decisions retained:

- no preferred SBOM schema;
- no final component matcher;
- no built-in vulnerability database or severity threshold;
- no mandatory signing root, transparency log, timestamp service, or TUF repository;
- no package-manager semantics;
- no global **trusted** bit;
- no rule that old receipts, old VEX statements, or old provenance continue to authorize restored roots.

## Revision 145 non-decision: secret delivery is not one thing

Keep **secret descriptors**, **acquisition prompts**, **delivery slots/projections**, **environment shadows**, **redaction lenses**, **renewal/rotation leases**, **live-use handles**, **residue markers**, and **receipts** separate.

Do not decide yet:

- one vault/keychain/token-broker/app-secret substrate;
- one process carrier for all secrets;
- whether env/argv projection is forbidden, profile-gated, or legacy-only;
- whether ViewFS stores named secrets at all;
- one redaction/taint protocol for terminal transcripts, logs, crash reports, semantic search, and screenshots;
- one renewal/rotation/revocation representation;
- one way to classify secret-derived residue for GC, quarantine, and audit.

Low-regret invariant: a descriptor, prompt receipt, env var, redaction mask, renewal hint, use receipt, or cleanup receipt cannot impersonate a current live secret-use handle.

## Revision 146 non-decision: revocation is not one boolean

Keep **delegation intents**, **attenuation/caveat envelopes**, **membrane leases/proxies**, **delegated handles/imported stubs**, **revocation requests**, **revocation wavefronts/checkpoints**, **stale-handle brakes/death verdicts**, **renewal/redelegation controls**, **current live authority**, and **receipts** separate.

Do not decide yet:

- one revocation substrate: derivation tree, epoch, membrane, broker, verifier, provider, token, or short TTL;
- one global meaning for `revoked`;
- one wavefront schema or recipient-inventory privacy posture;
- one rule for re-delegation, renewal, or promotion to durable reopen;
- one compatibility story for bearer capability URLs, sturdyrefs, or token-shaped delegation.

Low-regret invariant: a revoke request, provider 200, caveat chip, lease descriptor, wallet row, stale-handle receipt, or history entry cannot by itself prove that all future use is impossible, undo prior effects, or create current authority.

## Revision 147 non-decision: diagnostics are not one thing

Keep **inspection intents**, **target locators**, **namespace/process-view snapshots**, **handle/fd/slot peeks**, **memory/core/crash captures**, **trace probes/streams/processors**, **debug-control lanes**, **redaction/export policy cuts**, **current live inspection authority**, and **receipts** separate.

Do not decide yet:

- one universal diagnostics schema;
- one final trace/event vocabulary;
- one final process or task identity model;
- one final mapping to Linux procfs, ptrace, ETW, DTrace, Fuchsia Inspect, eBPF, or SlopOS CH-TRACE/CH-INSPECT;
- whether debugger control is portable, provider-local, developer-only, or absent in early ViewFS;
- whether handle/slot inventories may cross machine/user/support-bundle boundaries;
- how crash captures participate in quarantine, GC, secret-residue, and supply-chain evidence lanes;
- one redaction/taint/export policy language.

Useful decisions we can make now:

- observation is authority and should be explicitly scoped;
- a namespace snapshot is not a live namespace or launch root;
- a slot/fd peek is not a handle duplicate or reopen grant;
- a trace stream is not complete state or debug-control authority;
- a crash/core/memory capture is a quarantined, high-risk object, not ordinary log text;
- redaction masks are not containment proofs;
- support-bundle receipts are history, not future debugger sessions.

Low-regret invariant: process IDs, target locators, namespace snapshots, slot inventory rows, trace samples, redaction masks, dump metadata, support-bundle manifests, and old inspection receipts must not impersonate current live inspection/debug authority.

## Revision 148 non-decision: one network bit is too early and too broad

Do not decide yet whether ViewFS networking is implemented by a SlopOS D-NETLEASE descriptor, a portal-only helper, a microVM gateway, a firewall, a library stack, a provider-owned fetcher, a browser-like network service, or a compatibility socket shim.

Do decide now that proposals must identify which lane they touch:

- network intent;
- destination designator;
- resolution witness;
- admission cut / lease descriptor;
- live resolver/dialer/listener/stream authority;
- stream telemetry;
- local exposure / advertisement / tunnel;
- egress or import materialization cut;
- receipt/history only.

Leaving this undecided is safer than adopting a broad `network=true` launch bit. The broad bit would hide DNS, proxy, local-network, loopback, listener, advertisement, fetch/import, and send/export consequences precisely where ViewFS is trying to make authority visible.
## Revision 149 non-decision: service discovery is not a global endpoint plane

Keep **service intents**, **service designators**, **discovery/catalog authority**, **discovery snapshots/candidate sets**, **readiness/health/identity evidence**, **binding cuts**, **activation targets**, **current live service handles**, **advertisements/publications**, and **receipts** separate.

Do not decide yet:

- one ViewFS service registry, service mesh, discovery API, catalog store, or service-directory substrate;
- one DNS-SD/mDNS/SRV/SVCB/Kubernetes/xDS/Consul-like representation;
- one service identity scheme, trust-domain model, or certificate policy;
- whether services are object-store objects, namespace roots, portal sessions, D-NETLEASE adjuncts, live-room bindings, or a separate capability family;
- one socket-activation/fd-store/route-warming ABI;
- whether service calls use local IPC, network streams, object-capability RPC, provider-owned sessions, or process handles;
- one advertisement/publication scope taxonomy;
- one receipt schema for discovery, bind, activation, invoke, withdrawal, or cleanup.

Do decide now that every proposal must name which lane it affects. The failure mode to avoid is a hidden global endpoint plane where `service://name`, DNS-SD browse rows, EndpointSlice rows, xDS resources, health checks, identity matches, or old receipts silently become current invocation authority.


## Revision 152 semantic derivation split

Treat semantic extraction, source snapshot choice, extractor/model profile, derived artifact storage, index membership, query authority scope, result projection, answer card composition, live source/derived authority, and receipts as separate questions. Do not call all of them `search`, `memory`, `RAG`, or `smart folder`.

Keep open: exact vector database, embedding model, chunker, redaction profile, derived-artifact schema, answer-card format, agent-memory policy, and unindex/unlearn proof protocol. Prototype first: scope-gated semantic search, embedding vault labels, model-profile chips, result shades, answer receipts, instruction-quarantine rails, memory shutters, and unindex ladders.
## Revision 153 instruction and prompt authority split

A future ViewFS shell will likely ingest user prompts, project instructions, retrieved documents, tool descriptions, tool results, memory rows, and model output. The stable design rule is that none of those text surfaces should become authority by themselves.

Keep open until evidence demands coupling:
- exact prompt/message schema;
- one instruction-priority lattice;
- one MCP adapter shape;
- one plan language;
- one validator implementation;
- one approval UI;
- one model-memory substrate;
- one prompt-injection detector.

Stable split: instruction source record, local trust/priority label, context frame, model/prompt profile, proposal text, typed action plan, tool invocation candidate, approval cut, current live authority, result observation, and receipt/history.
