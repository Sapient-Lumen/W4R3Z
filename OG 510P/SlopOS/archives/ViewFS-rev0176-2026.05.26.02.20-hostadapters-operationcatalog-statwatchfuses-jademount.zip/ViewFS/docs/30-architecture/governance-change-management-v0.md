# Governance, change-management, rollout, and migration lane v0

Revision 172 adds an executable governance/change-management lane. The goal is not to turn ViewFS into a project-management system. The goal is to prevent governance artifacts from being confused with authority.

A proposal, ADR, quorum row, decision record, rollout plan, feature flag, deprecation notice, compatibility contract, migration run, or governance dashboard can be extremely important. None of them is a live ViewFS handle. None of them can read, write, export, deploy, migrate, remove, or disclose by being visible in a shell.

## New record families

| Record family | Minimal fixture fields | Anti-collapse rule |
|---|---|---|
| `ChangeProposal` | `id`, `status`, `subject`, `digest`, `basis_epoch`, `current_epoch`, `authority`, optional `scope_widened`, optional `widening_review` | A proposal describes a candidate change. It is not implementation authority, migration authority, or consent. |
| `DecisionRecord` | `id`, `status`, `proposal`, `proposal_digest`, `decision`, `authority` | A decision records governance outcome and rationale. It does not execute the chosen effect. |
| `ApprovalQuorum` | `id`, `status`, `required`, `approvals`, optional `eligible`, optional `steward_required`, optional `steward_present`, `authority` | Quorum facts show threshold posture; they are not live approval authority by themselves. |
| `RolloutPlan` | `id`, `status`, `approval_cut`, `guardrails_ok`, `blast_radius_reviewed`, `allowed_rings`, `authority` | A rollout plan stages change but does not prove completion or safety. |
| `FeatureFlag` | `id`, `status`, `allowed_scopes`, `policy_epoch`, `current_epoch`, `authority` | A flag is a scoped selector/configuration fact, not authority to use the underlying capability. |
| `DeprecationNotice` | `id`, `status`, `effective_after`, `now`, `migration_path`, `authority` | A deprecation notice warns or gates; it is not proof of removal and not object-authority revocation by itself. |
| `CompatibilityContract` | `id`, `status`, `from_version`, `to_version`, `breaking_change`, optional `waiver`, `authority` | Compatibility promises are claims under review, not compatibility proof or execution authority. |
| `MigrationRun` | `id`, `status`, `approval_cut`, `source_schema`, `target_schema`, `current_schema`, `precheck_ok`, `rollback_plan`, `authority` | A migration run must be executed under live authority and may not claim success before effects are verified. |
| `GovernanceCard` | `id`, `status`, `subject`, `quorum`, `claims_live_authority`, `exposes_private_votes`, `claims_unanimity` | A shell card may summarize governance posture but must not claim live authority or overstate private/threshold facts. |

## Checked operations

| Operation | Admits only when | Denial pressure |
|---|---|---|
| `admit_change_proposal` | proposal basis is current, status is ready/proposed, widening has review if present, and a live governance/change handle exists | proposal-as-authority, stale basis, scope widening, missing authority |
| `record_decision` | decision is recorded, binds exact proposal digest, has valid verdict, and a live decision/governance handle exists | decision-as-execution, digest mismatch, missing proposal, missing authority |
| `verify_approval_quorum` | quorum is current, threshold is met, required steward is present, and live approval authority exists | quorum-as-authority, insufficient threshold, missing steward, missing authority |
| `start_rollout_plan` | rollout is approved, guardrails and blast-radius review pass, ring is admitted, and live rollout/deploy authority exists | rollout-as-completion, failed guardrails, unadmitted ring, missing authority |
| `evaluate_feature_flag` | flag is active, scope is allowed, policy epoch is current, and live feature/configuration authority exists | flag-as-authority, scope widening, stale policy, missing authority |
| `enforce_deprecation_notice` | notice is active, effective window has arrived, migration path exists, and live deprecation/governance authority exists | notice-as-removal, early enforcement, missing migration path, missing authority |
| `check_compatibility_contract` | contract is active, versions match, breaking changes have waiver, and live compatibility-review authority exists | promise-as-proof, breaking change, version mismatch, missing authority |
| `execute_migration_run` | run is approved, source schema is current, precheck and rollback plan exist, and live migration/write authority exists | migration-as-success, stale source schema, missing precheck, missing authority |
| `render_governance_card` | card is sealed, privacy-safe, and honest about authority/unanimity | card-as-authority, private vote leak, false unanimity, unsealed card |

## Design posture

Governance records are allowed to be durable and highly visible. They should be searchable, reviewable, and citeable in shells. But ViewFS must keep two lanes separate:

1. **Decision/evidence lane**: proposal text, ADR, quorum, decision, rollout dashboard, flag state, compatibility note, migration transcript.
2. **Authority/effect lane**: current handle, approval cut, policy check, bounded scope, live executor, effect receipt.

The user-facing shell can join those lanes in one card, but the fixture checker must keep them distinct. A card saying “approved” can help a human understand why a button is enabled; it cannot itself enable the button.

## Open questions

- Whether governance records should have their own immutable object family or live entirely as typed records over ordinary ViewFS objects.
- How much quorum logic belongs in ViewFS versus SlopOS/Ward stewardship lanes.
- Whether feature flags should be modeled as view overlays, policy facts, or rollout artifacts in later revisions.
- How to present compatibility promises without making users think ViewFS has proved semantic equivalence.
