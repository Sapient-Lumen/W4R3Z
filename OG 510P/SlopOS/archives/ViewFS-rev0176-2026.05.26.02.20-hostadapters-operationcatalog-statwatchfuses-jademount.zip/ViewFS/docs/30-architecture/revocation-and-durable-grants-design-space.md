# Revocation and durable grants design space

Purpose: keep ViewFS realistic about reopen and revocation without overpromising them in Phase 1.

This note records the useful lessons from portals, SAF-style document access, and capability systems that treat rights attenuation as normal but full revocation as costly.

## First lesson: persistence and revocation are different problems
A grant can be:
- ephemeral but not revocable in the strong live-disconnect sense,
- durable but revalidated only on next use,
- durable and revocable through an explicit broker,
- or intentionally non-durable and transcript-only.

ViewFS should not pretend these are the same feature.

## A safer default posture
- ephemeral by default
- durable only by explicit user or policy intent
- revalidate on reopen
- make failure obvious and inspectable
- treat strong live revocation as a higher-cost feature, not the baseline promise

## Distinct grant classes worth naming early

### G1. Ephemeral open grant
- created by chooser/import/open
- valid for the current process, session, or transfer scope
- may die when the session or lease ends

### G2. Ephemeral transfer grant
- created by drag/drop, copy/paste, or shell-to-app handoff
- designed to move a bounded object set between participants
- intentionally not durable by default

### G3. Durable reopen grant
- created only with explicit persistence intent
- stores enough information to attempt future reopen
- must still survive revalidation checks on use

### G4. Brokered live grant
- a service or broker stays in the loop
- can terminate future use more strongly than passive receipt invalidation
- likely too expensive for universal Phase 1 use

## Revalidation questions every durable design must answer
When a durable reopen is used later, the system should be able to say:
- what identity is being revalidated?
- what rights were originally granted?
- what current policy applies?
- what changed if the reopen now fails?

Possible failure reasons should remain visible:
- object deleted
- object moved or replaced
- grant revoked or expired
- requested rights no longer allowed
- current object no longer matches expected identity constraints

## Why strong live revocation is dangerous to promise casually
Strong revocation often implies one of the following:
- all access is brokered through a mediator that can cut off use,
- all handles are indirect and check liveness on each operation,
- or objects are wrapped in revocable proxies with non-trivial performance and failure semantics.

That may be worthwhile later, but it should not be smuggled into Phase 1 as “obvious filesystem behavior.”

## Practical posture for Phase 1
1. Portal grants produce explicit receipts.
2. Receipts say whether the grant is ephemeral or durable.
3. Durable reopen attempts are revalidated on use.
4. Rights attenuation remains available on duplicated handles.
5. Strong live revocation is not promised unless the specific seam says so.

## Good things to steal
- explicit grant classes and document IDs from SAF-style systems
- restricted synthetic views from XDG Documents-style portals
- transfer-session isolation for drag/drop and clipboard handoff
- explicit rights attenuation from capability systems
- transcript-visible failures instead of silent fallback

## Things to avoid
- invisible bookmark magic
- “durable” grants whose failure modes are not inspectable
- assuming delete/move/rename semantics are universal across object kinds
- promising live revocation everywhere before any broker model exists

## Spikes worth running
- R1: reopen receipt over immutable object reference only
- R2: reopen receipt over mutable workspace head with visible revalidation outcome
- R3: transfer-session receipt that intentionally expires at session end
- R4: brokered live-revocation experiment for one narrow tool flow only

## Design bar
Before ViewFS promises a durable grant mechanism, it should be able to answer three user questions in plain language:
1. what exactly was I granted?
2. how long is it supposed to last?
3. why did reopen succeed or fail this time?

## Another lesson worth freezing: permission outlook is not current authority
A durable or semi-durable grant story should keep at least four truths separate:
- **permission outlook** (`granted`, `prompt`, `denied`, `revalidate needed`, `policy blocked`),
- **revival designator** (something that may let the system ask again later),
- **live handle now**, and
- **death-state verdict** (`revoked`, `expired`, `deleted`, `target changed`, `issuer unavailable`, `history only`).

Why this matters:
- browser and app-platform permission systems stay usable precisely because queryable state is explicit and does not pretend the caller already holds the result;
- XDG/SAF-style systems stay repairable because permission grant/revoke/delete/info are visible acts with visible outcomes;
- shell UX gets much better when `permission looks good` and `you currently hold it` are not the same badge.

Low-regret posture:
- treat preflight permission/liveness state as advisory, not authority;
- preserve exact negative reason classes instead of collapsing everything into `stale`;
- bias the shell toward exact repair verbs like `request`, `revalidate`, `rebind`, or `import fresh`;
- keep old receipts/history useful for explanation without letting them masquerade as live authority.

## Revision 146 refinement: add wavefront humility

The durable-grant warning now has a companion shape: a revocation request, provider response, local proxy close, epoch advance, recipient notification, stale-use denial, and receipt are different states. ViewFS should model them as a **revocation wavefront** when useful, not as one boolean.

This keeps durable reopen grants honest. Reopen may fail because the grant was revoked, expired, superseded, denied by current policy, unable to contact the issuer, or only represented by history. Those reasons should stay distinct so the shell can offer the right repair: reacquire, renew, rotate, ask issuer, use read-only, make-local, or show receipt.
