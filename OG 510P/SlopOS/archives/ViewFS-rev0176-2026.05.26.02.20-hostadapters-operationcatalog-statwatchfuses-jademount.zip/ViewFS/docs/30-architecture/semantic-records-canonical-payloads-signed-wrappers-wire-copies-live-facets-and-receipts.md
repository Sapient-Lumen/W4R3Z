# Semantic records, canonical payloads, signed wrappers, wire copies, live facets, and receipts

Purpose: keep **semantic record meaning**, **canonical payload bytes**, **signed/authenticated wrappers**, **storage/transport copies**, **current live facets**, and **durable receipts/history** on distinct seams.

## The split
- **semantic record** — the meaning, review card, or descriptor semantics we intend to discuss.
- **canonical payload** — the exact bytes defined by one deterministic encoding / normalization profile.
- **signed wrapper** — one authenticated/signature-bearing container around that payload (or around a detached-payload reference).
- **wire copy** — one concrete storage/export/import/logging/transport copy.
- **live facet** — currently usable inspect/read/edit/publish authority.
- **receipt/history** — durable memory of issuance, verification, transfer, repair, and rebinding.

## Why this must stay split
A capability-heavy object store can easily lie by accident:
- one wrapper digest gets mistaken for semantic meaning,
- one canonical payload digest gets mistaken for the concrete wire bytes somebody saw,
- one stored export copy gets mistaken for the live object/facet,
- or one old signed blob gets mistaken for current power.

That is exactly the kind of collapse ViewFS should avoid while SlopOS is still in design and while ViewFS itself is still collecting ideas instead of freezing one substrate.

## Lessons worth stealing
### JCS and deterministic encodings
JCS is useful because it says canonicalized bytes can support repeatable cryptographic operations while the original JSON may stay on the wire.
CBOR is useful because RFC 8949 warns that if several encodings share the same semantics, a protocol must be explicit about which representation counts as deterministic.

That means ViewFS should never say `digest` without also knowing **which byte layer** and **which profile** it belongs to.

### COSE and detached payloads
COSE is useful because it keeps the signed structure and the payload conceptually separate, and it explicitly allows detached payloads.
That is a strong reminder that `wrapper present` and `payload currently in hand` are different truths.

### in-toto envelope layering
in-toto is useful because it treats Statement and Envelope as separate layers, requires an authenticated payload type, and refuses to let media type or filename alone stand in for authenticated predicate meaning.
That is a powerful warning against making a single exported blob the only place where semantics, type, and signatures can be understood.

## Design guidance
1. A **semantic record** should be allowed to survive several wrapper or wire forms.
2. A **canonical payload** should be allowed to stay stable while wrappers, timestamps, or signer sets rotate.
3. A **signed wrapper** should be inspectable without being mistaken for the canonical comparison target.
4. A **wire copy** should be allowed to differ from the canonical payload form used for proofing.
5. A **live facet** should be visibly stronger than every historical payload/wrapper/wire row.

## Shell implications
The shell should be able to render:
- **record cards** (`same meaning`, `changed meaning`, `review only`, `unknown`),
- **payload chips** (`same canonical payload`, `different payload`, `profile mismatch`, `not computed`),
- **wrapper seals** (`signed`, `payload type authenticated`, `detached`, `wrapper changed`, `wrapper only`),
- **wire ghosts** (`transport copy`, `logged copy`, `export copy`, `history only`),
- **live rails** (`inspect now`, `read now`, `edit now`, `publish now`, `history only`).

## Non-decisions to preserve
Do not decide yet:
- one universal canonicalization rule;
- one universal wrapper/signature format;
- whether every family gets detached-payload support;
- whether wrappers are provider-owned, shell-owned, or portal-owned;
- one universal mapping from semantic record classes to media types.
