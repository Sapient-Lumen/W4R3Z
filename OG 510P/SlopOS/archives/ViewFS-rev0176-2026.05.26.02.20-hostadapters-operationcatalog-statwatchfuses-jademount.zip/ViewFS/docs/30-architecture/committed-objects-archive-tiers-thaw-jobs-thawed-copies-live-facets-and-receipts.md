# Committed objects, archive tiers, thaw jobs, thawed copies, live facets, and receipts

Purpose: keep **committed objects**, **archive tiers**, **thaw jobs**, **thawed copies**, **current live facets**, and **durable receipts/history** on distinct seams.

## The split
- **committed object** — one durable object record that exists now.
- **archive tier** — one current storage-class or offline/online posture row for that object.
- **thaw job** — one requested or in-progress restore / rehydrate action.
- **thawed copy** — one temporary or rehydrated readable realization produced by a thaw flow.
- **live facet** — currently usable inspect/read/edit/publish authority over that object.
- **receipt/history** — durable memory of archive moves, thaw requests, thaw completions, expiry deadlines, and restore failures.

## Why this must stay split
A capability-heavy object store can easily lie by accident:
- one committed object gets mistaken for `readable right now`,
- one archive-tier row gets mistaken for deletion or loss,
- one thaw request gets mistaken for a finished readable object,
- one temporary restored copy gets mistaken for permanent hot placement,
- one thawed status row gets mistaken for current live authority,
- or one historical restore receipt gets mistaken for a still-valid readable lane.

That is exactly the kind of collapse ViewFS should avoid while SlopOS is still in design and while ViewFS itself is still collecting ideas instead of freezing one storage-tier model, one thaw API, or one restore cache policy.

## Lessons worth stealing
### Durable existence and hot readability are different truths
Amazon S3 is useful because archived objects in Glacier-style classes are not accessible in real time, restore is explicit, and for some storage classes the readable restored copy exists only for a chosen duration.
That is a strong reminder that committed object truth and currently hot/readable truth are different layers.

### Restore status and object identity are different truths
Amazon S3 is also useful because restore requests and restore-status metadata are separate from the object version itself.
That is a strong reminder that one thaw job or restore-status row should not become object identity or current authority.

### Rehydration strategy and object identity are different truths
Azure Blob Storage is useful because archive-tier blobs are offline, and because rehydration can happen either by changing the archived blob's tier or by copying it to a new online blob.
That is a strong reminder that `thawed` is not one universal provider action and that one rehydrated copy can be distinct from the original archived object.

### SlopOS already rhymes with the same lesson
Current SlopOS drafts are useful because import/materialize boundaries, CapStore commit meaning, and lease-descriptor posture already separate durable object birth, present live usability, and historical evidence.
That means ViewFS can steal the separation now even though SlopOS itself has not settled a final archive-tier or thaw-job substrate for the datacube.

## Design guidance
1. A **committed object** should be inspectable without implying that ordinary reads work right now.
2. An **archive tier** should stay visible instead of hiding inside one flattering `stored` or `offline` bit.
3. A **thaw job** should remain weaker than object identity and weaker than current authority.
4. A **thawed copy** should remain visible as its own class instead of being flattened into either object birth or a namespace alias.
5. A **live facet** should stay visibly stronger than every archive/thaw/history row.
6. A **receipt/history** row should remember prior thaw or expiry facts without reviving present authority or pretending hot access still exists now.

## Shell implications
The shell should be able to render:
- **frost badges** (`hot`, `cool`, `cold`, `archived`, `offline`, `history only`),
- **thaw beads** (`none`, `requested`, `pending`, `priority high`, `failed`, `history only`),
- **copy-thaw ladders** (`temporary copy`, `tier changed`, `copy target ready`, `expiry known`, `history only`),
- **expiry lanterns** (`until 2026-…`, `no expiry exposed`, `expired`, `history only`),
- **live rails** (`inspect now`, `read now`, `edit now`, `publish now`, `history only`).

## Non-decisions to preserve
Do not decide yet:
- one universal archive-tier registry across all ViewFS providers and object families;
- whether every provider exposes explicit thaw jobs or expiry dates;
- whether thawed readability is modeled as copy, tier mutation, provider-local cache warmth, or all three;
- one final receipt format for thaw requests, expiries, or restore failures;
- one universal policy for when archive or thaw state should warn, block, or silently continue.
