# ViewFS namespace posture v0 (synthetic local roots, not ambient global `/`)

Purpose: state the central namespace thesis clearly before compatibility work muddies it.

## Posture
1. Every process or component receives an **explicit view root**.
2. View roots are **synthetic and local**; there is no requirement for a machine-global root namespace.
3. Views are assembled from explicit bindings of handles into named slots or prefixes.
4. Paths, when they exist, are interpreted **within a view**, not against a hidden host-global authority plane.
5. Different processes may legitimately observe different `/` trees.
6. A view may be object-home and tool-neutral first; attaching one tool or editor later is a separate act from seeding the room.
7. A view should usually bind one **chosen facet** or one explicit grouped kit, not silently assume that binding one name imports every affordance of the underlying object.

## Why this cut is worth making
- REF-FUCHSIA-NAMESPACE shows the power of per-component composite namespaces.
- REF-PLAN9 shows private namespace assembly is a major usability tool.
- REF-SEL4-CSPACE suggests a useful mental model for slot-oriented handle inventories.
- REF-SANDSTORM-GRAINS is useful pressure toward object-home work contexts rather than assuming one tool owns the whole namespace story.
- REF-SANDSTORM-POWERBOX and REF-FUCHSIA-CAPS are useful pressure toward asking for one shaped capability/API rather than `the object, but somehow everything too`.

## Early convention candidate
A conventional Phase 1 view may expose:
- `/app`
- `/work`
- `/in`
- `/out`
- `/tmp`
- `/state`
- `/svc`

This is a **convention**, not yet a hard ABI.

## Design caution
A seeded room/root, one attached tool session, one later imported object, one chosen bound facet, and one published local name should not collapse into one magical `open` event.
