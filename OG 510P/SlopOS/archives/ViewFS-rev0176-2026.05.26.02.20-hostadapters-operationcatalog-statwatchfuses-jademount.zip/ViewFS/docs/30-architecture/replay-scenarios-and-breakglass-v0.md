# Replay scenarios and breakglass override gates v0

Revision 159 adds two small lanes that put pressure on operational honesty: replay scenarios and override warrants.

## Replay scenarios

A `ScenarioReplay` is a sealed conformance story made of ordered steps. Each step names a result, stable reason, and witness reference. The v0 checker denies a replay when:

- it is not sealed;
- it has no steps;
- any step lacks result/reason shape;
- a required witness is missing;
- negative evidence is required but the story contains only success steps.

The point is cultural as much as technical: ViewFS should not accept a demo that only proves the green path. Every mature lane needs an adversarial row showing how authority laundering fails.

## Breakglass override gates

`OverrideWarrant` records represent exceptional authority only when all of these hold:

- warrant status is approved;
- steward signature is verified;
- scope matches the object behind the live handle;
- requested right is present on the live handle;
- expiry has not passed;
- audit sink is present.

An override is therefore not a magic admin bit. It is a supervised, scoped, time-bounded, auditable path that still uses normal live authority carriers.

## Companion pressure

Ward supplies stewardship/accountability pressure. SlopOS supplies approval/portal/boundary discipline. Schell supplies retention and audit pressure. Foundry supplies the specimen-before-noun rule. Revision 159 imports these pressures without letting steward prose, policy reports, or scenario narratives become object authority.
