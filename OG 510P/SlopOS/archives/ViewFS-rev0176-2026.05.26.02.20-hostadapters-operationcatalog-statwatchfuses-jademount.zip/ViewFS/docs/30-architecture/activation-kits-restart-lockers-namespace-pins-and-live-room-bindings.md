# Activation kits, restart lockers, namespace pins, and live room bindings

This note protects one more high-value seam while ViewFS and SlopOS are both still moving.

Revision 0101 already split durable anchors, live room binds, stale shadows, repair plans, and receipts.
This note adds another discipline on top:

**the exact kit delivered at startup, the exact locker a manager may preserve across a controlled restart, the narrower pin that keeps some namespace/view basis alive, the live room binding now, and the receipt explaining what happened are different classes.**

## The split

### 1. Activation kit
An activation kit is the answer to:
- what exact ready resources did this process receive at start time?

Good examples:
- handed-in sockets or handles,
- startup import slots,
- a ready namespace fragment,
- reviewed child-room bind ingredients.

It is startup truth.
It is not the same as durable reopen, and it is not the same as a locker that may preserve resources for later restart.

### 2. Restart locker
A restart locker is the answer to:
- what exact resources is some manager explicitly preserving for a controlled restart?

Good examples:
- exact descriptors kept in a manager,
- one reviewed room restart kit,
- one resumable request/session lane saved only for restart.

It is narrower than durable persistence.
It may be stronger than a mere receipt, but weaker than a general warm-restore promise.

### 3. Namespace pin
A namespace pin is the answer to:
- what exact thing keeps one namespace/view basis alive even when this process exits?

Good examples:
- a namespace file descriptor,
- a bind-mounted namespace token,
- a provider-held room pin,
- a local keepalive pin during handoff.

It is a liveness-preservation fact.
It is not proof that this room currently inhabits that namespace.

### 4. Live room binding
A live room binding is the answer to:
- what exact object, projection, or import is this room actually holding right now?

This is current truth.
It should not be inferred from activation kits, locker rows, pins, or historical receipts.

### 5. Receipt/history
Receipts preserve explanation of:
- what startup kit was delivered,
- whether a locker was used,
- whether the restart was warm exact, warm partial, or cold,
- whether a pin survived or died,
- and whether the room had to fall back to repair or fresh import.

Receipts should not silently reactivate live authority.

## Product consequences

### Restart shelves
The shell should be able to show a compact shelf with separate rows for:
- `wake kit delivered`
- `restart locker held`
- `namespace pin present`
- `live now`
- `anchor/repair only`
- `receipt only`

### Warm-start lamps
A room header should be able to say:
- `warm exact`
- `warm partial`
- `cold repair`
- `cold fresh`
- `receipt only`

That is much more honest than one flattering `restored` badge.

### Pin badges
A room or inspector should be able to show:
- `fd pinned`
- `bind pinned`
- `provider pinned`
- `pin dropped`
- `pin unknown`

Pin badges are liveness truth, not durable authority truth.

### Cold-start honesty
If a process or room restarted without the old exact kit, the shell should say so.
Good state labels:
- `locker missed`
- `pin gone`
- `fell back to durable anchor`
- `reconsent needed`
- `fresh room`

### Partial wake-kit honesty
Borrowing from Steward's adaptation-witness idea, a warm start should be able to say:
- `wake kit partial`
- `cache trimmed`
- `concurrency capped`
- `overlay dropped`
- `repair ladder follows`

This preserves luxury without lying.

## Why this fits current SlopOS work
Current SlopOS already leans toward:
- explicit process launch/import posture rather than ambient inheritance,
- optional explicit persistence rather than universal durable graphs,
- descriptive wallets and receipts rather than magical session folklore,
- typed workflow/document/import surfaces rather than global path rediscovery.

That gives ViewFS permission to protect this seam **without** deciding the final locker object model, final namespace carrier, or final room restart wire format.

## Good questions to keep open
- Should restart lockers only survive controlled restart, or can some later lane survive a wider stop/start boundary?
- When does a namespace pin remain useful after all live room binds are gone?
- Can one room export a startup kit to another room without silently creating a durable anchor?
- Should a warm-partial restart always show the missing pieces before replay/rerun is offered?
- Which actions require a stronger revalidation fence after a cold fallback than after a warm exact restart?
