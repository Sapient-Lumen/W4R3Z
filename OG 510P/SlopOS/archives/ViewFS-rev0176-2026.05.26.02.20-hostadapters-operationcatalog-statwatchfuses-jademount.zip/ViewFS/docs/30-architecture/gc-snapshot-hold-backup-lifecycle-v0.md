# GC, snapshots, holds, and backup lifecycle v0

Revision 163 extends the executable ViewFS spine into the places where deletion stories usually become dishonest. A ViewFS object can be invisible in a view, removed from a working directory, tombstoned in the local object store, pinned by a snapshot, blocked by an archive/legal hold, retained by a backup set, or contradicted by a live derived copy. Those states are intentionally separate.

## Record families

| Family | Role | Must not become |
|---|---|---|
| `GcCandidate` | Proposed local sweep target with tombstone, approval cut, and collector authority. | Proof that bytes are gone everywhere. |
| `SnapshotPin` | A point-in-time retention edge over an object or manifest. | Live read/open authority or permanent legal hold. |
| `ArchiveHold` | Legal, compliance, stewardship, or records-retention blocker. | A generic administrator override or deletion proof. |
| `BackupSet` | Inventory of protected backup copies and snapshot pins. | Restore authority or proof of current object validity. |
| `CopyInventory` | Local derived/cached/excerpted copy accounting. | Complete knowledge of external copies. |

## Sweep posture

A sweep may proceed only when the candidate is ready, the tombstone is written, the sweep cut is approved, live collector authority exists, and no live handle, explicit retention root, snapshot pin, archive hold, protected backup set, or live derived-copy row blocks collection.

The v0 model deliberately does not claim secure erasure. It only decides whether ViewFS is allowed to collect a local candidate. Deletion, minimization, purge, crypto erase, media sanitization, and remote copy removal remain separate surfaces.

## Snapshot posture

A snapshot pin is a retention edge, not a handle. It can block GC and backup pruning, but it cannot open the object. Pruning a snapshot requires a prune cut and live prune/GC authority. A protected backup set may keep a snapshot pin alive even after the foreground workspace no longer references the object.

## Archive and legal hold posture

An archive hold blocks collection until a stewarded release cut exists. Compliance retention cannot be shortened before expiry in the v0 fixture model. Legal holds may be released only by an approved cut with a steward and live `release_hold` authority.

## Backup posture

A backup set is evidence of retained copies. It can block deletion and snapshot pruning. It does not restore by itself; restore requires a restore plan, verification of the backup set, an approved cut, and live restore/write authority.
