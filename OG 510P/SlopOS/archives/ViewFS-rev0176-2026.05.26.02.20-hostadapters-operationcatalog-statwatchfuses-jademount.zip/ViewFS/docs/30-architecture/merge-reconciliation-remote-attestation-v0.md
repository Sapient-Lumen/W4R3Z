# Merge reconciliation, remote attestations, and checkpoints v0

Revision 160 gives ViewFS a small distributed-state reconciliation vocabulary. It keeps merge plans, conflict rows, resolution cuts, remote attestations, journal checkpoints, and receipts separate from live authority.

## Record families

- `MergePlan` — base, ours, theirs, conflicts, resolution cut, witnesses, and write authority.
- `RemoteAttestation` — issuer, subject, statement digest, signature verification, status/revocation, and expiry.
- `JournalCheckpoint` — committed journal state, target object, flush proof, finalizer authority, and checkpoint receipt.

## Anti-collapse rules

1. A fast-forward merge can reconcile only when it has live write authority.
2. A conflicted merge needs an approved resolution cut and resolution witness.
3. A merge receipt is not effect replay authority.
4. A remote attestation is evidence for a named subject and statement; it is never object authority.
5. Revoked, expired, mismatched, or unverified attestations deny.
6. A journal checkpoint needs verified flush proof, materialized target object, and live finalizer authority.
7. A checkpoint receipt cannot finalize journal state again.

## Current fixtures

- `062-merge-fast-forward-current-base-allow.json`
- `063-merge-conflict-unresolved-denied.json`
- `064-merge-conflict-resolved-allow.json`
- `065-merge-receipt-effect-denied.json`
- `066-remote-attestation-verified-allow.json`
- `067-remote-attestation-revoked-denied.json`
- `068-remote-attestation-effect-denied.json`
- `069-remote-attestation-subject-mismatch-denied.json`
- `074-journal-checkpoint-finalized-allow.json`
- `075-journal-checkpoint-missing-flush-proof-denied.json`
- `076-journal-checkpoint-receipt-replay-denied.json`

## Design pressure

The important shape is not "Git for ViewFS" or "CRDT for ViewFS" yet. The important shape is that every reconciliation artifact has a lane: base observation, proposed result, conflict explanation, resolution witness, live write authority, finalization cut, and receipt/history.
