# Live room bindings, attention cues, interrupt grades, quiet windows, and ack ledgers

Purpose: keep **live room bindings**, **attention adverts**, **interrupt strength**, **quiet/suppression posture**, **durable acknowledgement rows**, and **receipts** on different seams while SlopOS is still settling its attention and background families.

## Why this split matters
The easiest way to over-design shell attention is to let one vague `alert` object silently absorb five different questions:
- what is live here now,
- whether it wants attention now,
- how strongly it may ask,
- whether the current workspace/session should hush it,
- and what durable follow-up remains after the transient cue is gone.

Those are different product truths and different authority shapes.

## Distinct classes
- **live room binding** — exact thing bound in the room namespace now
- **attention cue** — transient activity/bell/silence/follow-me signal
- **interrupt grade** — passive / banner / urgent / separately-governed critical class
- **quiet window** — hush/coalesce/suppress posture for the current workspace/session
- **ack ledger** — durable follow-up or unread row that survives after the transient cue fades
- **receipt** — durable explanation of what happened before

## Lessons worth stealing
### XDG Notification gives us the right humility
The notification portal lets apps send and withdraw notifications, but it does not let the app learn whether the notification was actually presented.
That is the right posture for ViewFS too: asking for attention is not the same thing as knowing attention was received.

### Android channels separate importance from payload
Notification channels make interruption level explicit and user-controlled.
That is a great precedent for ViewFS interrupt grades: stronger interruption should be separately visible and separately governable.

### Apple keeps critical interruption special
Critical alerts are a separately entitled class.
That is useful because it prevents ordinary `urgent` requests from slowly turning into a hidden bypass lane.

### tmux keeps activity, bell, and silence distinct
`tmux` status chrome does not flatten all attention into one generic alert.
It separately monitors activity, bell, and silence and marks them differently.
ViewFS should steal that idea shamelessly.

## Shell pressure this unlocks
- **attention pips** that distinguish activity, bell, silence, unread follow-up, and receipt only
- **interrupt ladders** that say `badge only`, `banner candidate`, `urgent but clamped`, `critical requires separate grant`, or `suppressed`
- **quiet shutters** that explain focus/do-not-disturb/workspace hush posture without pretending the underlying event vanished
- **ack ledgers** that keep unresolved follow-up visible after transient chrome is gone
- **durable-follow-up drawers** that say whether a transient cue became a task row, a rebind offer, a review-needed card, or only history

## Non-decisions preserved
Do not freeze yet:
- one final durable inbox or ack-row schema,
- one final interrupt entitlement or review path,
- whether quiet posture is room-local, workspace-local, or policy-local,
- whether alert rows and receipts share storage,
- or one final attention taxonomy for every ViewFS surface.
