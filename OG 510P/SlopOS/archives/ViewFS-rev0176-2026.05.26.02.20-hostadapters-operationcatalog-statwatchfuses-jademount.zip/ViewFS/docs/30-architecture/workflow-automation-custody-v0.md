# Workflow and automation custody v0

Revision 173 adds a checked lane for automation surfaces that are easy to mistake for authority. ViewFS intentionally separates event envelopes, trigger rules, schedule windows, workflow runs, step invocations, idempotency keys, retry policies, compensation plans, human tasks, and workflow cards.

## Core split

| Surface | Can do | Cannot do |
|---|---|---|
| `EventEnvelope` | carry a typed, sourced occurrence into a ViewFS workflow lane | grant object access, prove source trust by itself, or trigger effects without policy and authority |
| `TriggerRule` | match admitted events against an active rule epoch | become workflow authority or widen event scope |
| `ScheduleWindow` | bound when a prepared action may fire | replace consent, approval, or live schedule/workflow authority |
| `WorkflowRun` | hold current run state, basis epoch, approval cut, and lease posture | serialize live authority or prove the work already happened |
| `StepInvocation` | bind one effectful step to a target handle, approval cut, and run | widen target rights or claim completion |

The first product rule is pessimistic: **automation can queue, explain, and narrow work, but it cannot carry authority by default**. A workflow start must revalidate approval, basis epoch, lease, and live workflow authority. A step must revalidate the run, approval cut, target handle, required right, and live step authority.

## Checked operations

- `admit_event_envelope`
- `evaluate_trigger_rule`
- `fire_schedule_window`
- `start_workflow_run`
- `execute_workflow_step`

These operations turn old automation prose into concrete allow/deny specimens. They also make it possible to test future SlopOS integration without letting event queues, cron rows, or workflow state become an ambient capability channel.

## Anti-collapse rule

A queued workflow, event record, schedule match, or step row is at most a candidate. It becomes an effect only at a checked cut that names current authority, current basis, current policy, and the exact target rights.
