# Live room bindings, selection owners, transfer offers, manager retentions, paste capsules, and materialized imports

Purpose: keep **live room bindings**, **current selection/source truth**, **transfer offers and representation racks**, **clipboard-manager/history retention**, **paste capsules**, **materialized imports/adopted binds**, and **receipts** on different seams while SlopOS is still settling transfer-portal versus document-portal meaning.

## Why this split matters
Transfer-heavy shells always risk telling one flattering story:
- a thing was selected,
- therefore it was copied,
- therefore it is still available,
- therefore this prompt now has it,
- therefore a local object probably exists,
- therefore the same thing can be reopened later.

That story keeps failing on real systems.
The safer and more exciting move is to keep the separate truths visible and make shell chrome delightful around them.

## Distinct classes
- **live room binding** — exact thing bound in the room namespace now
- **selection owner/source** — current owner/source of the active offer when known
- **transfer offer** — advertised representations, keys, promises, and offer metadata
- **manager retention** — clipboard-manager or history-helper retained copy/ghost
- **paste capsule** — prompt-local accepted representation or bracketed-paste bundle
- **materialized import / adopted bind** — later explicit local object creation or bind adoption
- **receipt** — durable explanation of what happened before

## Lessons worth stealing
### Current offers are current, not immortal
Wayland selections are current owner/offer relationships, and the selection-offer validity is narrower than local object lifetime.
That is exactly the humility ViewFS wants.

### Clipboard history is a helper, not baseline reality
Data-control protocols make clipboard management a privileged helper role rather than a property every client naturally has.
That is strong evidence that history retention and current offer truth should not collapse.

### Transfer is a session with retrieval, not an import by magic
XDG FileTransfer explicitly starts a session, adds files, retrieves them with a key, and then usually autostops.
That is a great precedent for keeping `offer now`, `retrieved representation`, and `local import/adoption` on different seams.

### Paste-origin truth is worth product chrome
Bracketed paste is useful because it makes paste origin explicit.
That is exactly the kind of truth-preserving substrate ViewFS should steal for inspect-before-run, quote-before-run, and import-from-paste ladders.

### Typed clipboard reads are safer than folklore
The Clipboard API and kitty both show that richer clipboard exchange can remain typed, permissioned, and inspectable.
That is a good precedent for representation racks and paste capsules.

## Shell pressure this unlocks
- **offer cards** that say `clipboard`, `primary selection`, `drag offer`, `share offer`, or `none`
- **representation racks** that show offered versus accepted representation separately
- **manager halos / history ghosts** that say `retained`, `retained summary only`, `expired`, or `none`
- **paste capsules** that say `bracketed paste`, `quoted`, `prompt text only`, `scratch capsule`, or `receipt only`
- **materialize ladders** that let the user choose `paste only`, `inspect`, `import locally`, `adopt bind`, or `receipt only`
- **quality badges** that admit whether the shell knows owner truth richly, approximately, or not at all

## Non-decisions preserved
Do not freeze yet:
- one final clipboard/history manager substrate,
- one final transfer-offer schema,
- whether manager retention belongs to the terminal, shell, supervisor, or a separate helper,
- whether every materialized import from a transfer creates a fresh object versus optionally adopting a live transferable handle,
- whether promised-file materialization and paste-capsule materialization share one object-store family.
