# Deletion claims, sanitization proofs, and restore plans v0

Revision 163 treats deletion as an evidence bundle, not a boolean. ViewFS should never let a green deleted badge hide a protected backup copy, active snapshot, legal hold, live handle, unminimized index row, or weaker-than-claimed sanitization proof.

## Deletion evidence ladder

The v0 checker recognizes this coarse evidence ladder:

1. `tombstone` — foreground namespace/object-store marker only.
2. `clear` — local logical removal evidence.
3. `crypto_erase` — key disposal evidence for encrypted material.
4. `purge` — stronger media sanitization posture.
5. `destroy` — physical destruction posture.

A deletion claim may be verified only when the sanitization proof is verified, targets the same object, meets or exceeds the claimed level, and is not contradicted by known retained copies.

## Restore posture

Restore is the mirror hazard of deletion. A backup manifest, snapshot label, old restore receipt, or remembered object id cannot recreate authority. A restore must pass through a verified backup set and an approved restore plan with live restore/write authority.

## Shell implication

The shell should avoid one word, `deleted`, unless it is immediately qualified. Better cards are:

- `removed from this view`;
- `local tombstone written`;
- `blocked by snapshot pin`;
- `blocked by legal hold`;
- `retained by backup set`;
- `sanitization proof verified: crypto erase`;
- `external copies unknown`.

This is intentionally compatible with Schell's forgetting-ledger pressure: ViewFS can explain what it locally knows without pretending that unknown copies, third-party exports, or old screenshots have disappeared.
