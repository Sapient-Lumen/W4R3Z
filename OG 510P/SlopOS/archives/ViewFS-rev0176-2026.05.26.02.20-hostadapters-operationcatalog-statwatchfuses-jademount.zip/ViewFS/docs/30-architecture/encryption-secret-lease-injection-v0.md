# Encryption, secret leases, injection, and escrow v0

Revision 166 turns secret custody into executable ViewFS pressure. The purpose is not to become a KMS or vault. The purpose is to prevent secret-adjacent artifacts from laundering into object authority or tool authority.

## Encryption lane

```text
EncryptionEnvelope
  -> KeyVersion
  -> active algorithm / lifecycle posture
  -> live decrypt handle
  -> Clear facet
  -> Receipt
```

Ciphertext, content digest, envelope header, and key id can identify or explain sealed material. They do not authorize cleartext. The checker denies ciphertext-as-authority, revoked key versions, and deprecated algorithms.

## Key rotation lane

```text
KeyRotationPlan
  -> old key / new key
  -> rewrap inventory
  -> approval cut
  -> live key-admin authority
  -> rotation receipt
```

A rotation receipt is history. It cannot rotate again. A new key label is not enough; rewrap accounting must be present so old ciphertext custody remains visible.

## Secret lease and injection lane

```text
SecretLease
  -> SecretInjectionPlan
  -> delivery slot / redaction posture
  -> target fit
  -> live injection authority
  -> use receipt
```

The v0 lane deliberately rejects unredacted environment shadows. Environment injection is treated as a higher-leakage delivery slot because env blocks commonly enter logs, process tables, crash reports, and diagnostic dumps. File/socket delivery can still be unsafe, but it is easier to scope, update, revoke, and render honestly.

## Escrow lane

```text
EscrowRecoveryWarrant
  -> quorum evidence
  -> live subject session
  -> live recovery/decrypt authority
  -> recovery receipt
```

Escrow is not a magic bypass. It is an override-like lane with tighter secret-specific posture. Tickets and labels are inert; current session, quorum, scope, expiry, and live authority are checked.
