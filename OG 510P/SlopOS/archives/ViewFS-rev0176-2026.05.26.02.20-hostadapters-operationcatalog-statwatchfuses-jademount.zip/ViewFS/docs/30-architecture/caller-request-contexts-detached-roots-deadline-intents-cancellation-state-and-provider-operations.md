# Caller request contexts, detached roots, deadline intents, cancellation state, and provider operations

Purpose: keep one more mutable/deferred-work seam narrow while SlopOS and ViewFS are still in design.

ViewFS should keep these truths separate:
**live room binding ≠ caller request context ≠ detached continuation root ≠ deadline intent ≠ current cancellation state ≠ provider operation ticket ≠ durable receipt/history**.

## Why this seam matters
Recent revisions already separated:
- request admission from later completion;
- completion verdict from local adoption;
- retry sameness witnesses from request identity;
- graceful cancel from terminate, detach/delete, and reset/fork.

But one collapse still lurks in shell UX and object-store temptation:
- `the caller gave up`,
- `the deadline fired`,
- `cleanup still runs`,
- `the provider detached the work`,
- `there is still a status ticket`, and
- `all that remains is history`

can easily blur into one vague `pending background thing` story.

SlopOS already resists that.
Its request-context work keeps deadline/cancellation as coordination, not authority, and explicitly says work that must outlive its caller should mint a **fresh root context** on the owning seam instead of using portable detach/shield folklore.

## Lessons worth stealing

### Go context: structure plus cleanup obligations
Go's `context` package is unusually practical:
- contexts carry deadlines, cancellation signals, and request-scoped values across API boundaries;
- derived contexts cancel when their parent cancels;
- `CancelFunc` exists both for cancellation and for resource cleanup;
- causes can be recorded and queried.

That means a caller request context is not mere annotation.
It is live structure with propagation and cleanup semantics.

### Go WithoutCancel: detached does not mean child-with-a-flag
`WithoutCancel` is a wonderful warning label.
It explicitly drops cancellation, deadline, `Err`, and `Done` behavior.
That is exactly the sort of seam ViewFS should keep visible.
A detached root is not just a child context with `detach=true`.

### gRPC deadlines: cutoff intent is not completion truth
Deadlines say how long the caller is willing to wait.
Servers should stop initiated work when the call has been cancelled.
Propagation is about preserving the caller's patience budget across hops, not about rewriting whether later work was admitted, detached, or completed.

### Kotlin cancellation and NonCancellable: shielding is local and sharp-edged
Coroutine cancellation is cooperative.
Parent-child cancellation is real structure.
`NonCancellable` is appropriate for bounded cleanup blocks, but using it to launch regular child work severs the normal relationship.
That is strong evidence that ViewFS should not export one flattering portable `ignore cancel` bit.

### Temporal disconnected cleanup: cleanup roots deserve their own name
Temporal's disconnected context is great evidence that `cleanup after cancel` deserves its own lane.
That is different from ordinary detached long-running work and different again from still-caller-bound work.

## Shape that feels promising
ViewFS likely wants conceptual rows like:
- **CallerRequestContext**
  - what current caller-bound deadline, cancellation, and cause posture governs this attempt?
- **DetachedRoot**
  - did the provider/supervisor mint a fresh root that intentionally outlives the caller?
- **DeadlineIntent**
  - inherited, narrowed, none, expired, or detached-away?
- **CancellationState**
  - requested, propagated, cooperatively acknowledged, cleanup running, ignored, deadline-fired, confirmed stopped, unknown?
- **ProviderOperation**
  - is there still a poll/watch/status handle for the detached or caller-bound work?
- **ContinuationReceipt**
  - what only survives as explanation/history now?

## Shell/product consequences
The custom shell gets much better if it can show:
- **cutoff lamps** — `caller cutoff`, `narrowed`, `none`, `expired`, `unknown`;
- **detach-root cards** — `caller child`, `cleanup root`, `provider root`, `watch-only`, `history only`;
- **continue-without-me ladders** — `cancel with me`, `run cleanup only`, `let provider continue`, `stop watching`;
- **cancellation braids** — `requested`, `propagated`, `acknowledged`, `cleanup still running`, `deadline exceeded`, `provider still settling`;
- **cause drawers** — why did this cancel, and was it local, parent-driven, deadline-driven, or provider-driven?

## What not to decide yet
- one universal request-context descriptor for ViewFS;
- one final detached-root carrier;
- whether detached continuation must always retain a provider operation ticket;
- whether cleanup-only and long-followup detached roots share storage or only shell chrome;
- whether deadline intent ever becomes durable beyond witness/receipt surfaces.
