# Reachability roots, live-handle roots, pin/hold/lease records, sweep candidates, finalizers, collected ash, live facets, and receipts

Revision: 141  
Date: 2026-05-13  
Codename: gchalos-pinleases-sweepguards-moonfern

## Architecture posture

ViewFS should treat object-store liveness as a first-class design seam, not as an incidental property of path reachability or cache presence.

The important anti-collapse rule is:

> retention truth, runtime liveness truth, delete choreography, collection analysis, present authority, and historical evidence are different truths.

That rule matters because ViewFS is intentionally combining:

- immutable-ish object cores;
- mutable durable roots;
- explicit per-process namespaces;
- portal-mediated imports;
- live capability handles;
- time-capsule restore;
- caches, previews, listings, and indexes;
- rich receipts.

A future collector must be able to decide what can be reclaimed without treating every helpful artifact as a root and without missing runtime liveness that is not durable.

## Object-store liveness classes

### Durable reachability roots

Durable roots should be few, inspectable, and intentionally created.

Examples:

- accepted root-ledger tips;
- named workspace roots;
- user-pinned object sets;
- publication roots;
- backup / offline roots;
- retained time-capsule roots;
- policy roots / legal holds;
- provider-retained roots imported as facts.

A durable reachability root can keep bytes alive even when no process can currently open them.

### Runtime live-handle roots

Runtime roots protect work that would be unsafe to collect while live, but they should normally die with the holder.

Examples:

- current handle slots;
- live binds in rooms;
- portal import/adoption sessions;
- upload sessions;
- repair jobs;
- thaw jobs;
- provider proxies;
- borrowed handles;
- materializer leases.

This gives the collector a way to respect current authority without turning every handle into a persistent object-store root.

### Pin / hold / lease records

Pin/hold/lease records are the bridge between short-lived runtime work and longer-lived retention.

Recommended fields for future schemas:

```text
retention_record_id
retention_kind        # pin | hold | lease | finalizer | policy-root | provider-root
target_kind           # object | root | aggregate | chunk-set | namespace | import-session | provider-hidden
target_digest_or_ref
issuer_subject
owner_subject
purpose_code
scope                 # direct | recursive | indirect | graph | provider-hidden
expires_at
renewal_policy
release_policy
privacy_level
current_status
receipt_digest
```

The architecture should leave room for multiple provider-native forms, but the shell should normalize enough to answer: `who is keeping this, why, and until when?`

### Sweep candidates

Sweep candidates are analysis artifacts. They should be immutable snapshots tied to a basis:

```text
sweep_candidate_id
collector_family
basis_root_set_digest
basis_live_handle_epoch
ignored_classes
provider_uncertainty
candidate_count
estimated_bytes
reasons_digest
expires_at
```

They must be invalidated by root changes, live-handle changes, finalizer changes, provider witness changes, or enough time.

### Finalizers

Finalizers should model deletion barriers, not retention ownership.

A finalizer might block final deletion until:

- a provider delete settles;
- exported proxies are revoked;
- dependent aggregates are updated;
- index rows are removed;
- cache purge has been attempted or explicitly abandoned;
- a human approves destruction of a surprising last root;
- a tombstone is recorded for rollback protection.

Finalizers need owners, timeouts, failure states, and audit receipts.

### Collected ash and tombstones

A collected state needs more nuance than `not found`.

Candidate states:

- `cache evicted`;
- `unreachable collected`;
- `purged under retention policy`;
- `delete marker active`;
- `tombstone retained`;
- `secure erase requested`;
- `provider hidden / local unknown`;
- `receipt only`.

Collected ash should be enough to stop accidental resurrection where needed, but not enough to re-create bytes or authority.

### Current live facets

Current live facets remain authority truth.

Important combinations:

| State | Meaning |
|---|---|
| live + durable | usable now and retained by explicit roots |
| live + unpinned | usable now, may disappear after close unless committed/rooted |
| durable + not live | retained but needs open/import/restore to use |
| cached + not pinned | bytes present, no retention promise |
| finalizing | delete requested, cleanup barriers remain |
| collected + receipt | gone or locally unavailable, history remains |

This matrix should be visible in debugging UI and eventually in the shell.

## SlopOS pressure

The included SlopOS archive is already pushing in the right direction:

- CapStore makes durable roots explicit and treats persistence as authority;
- the CapStore RFC explicitly calls out GC-root representation versus privacy/accountability as an open question;
- capability leases keep temporary proxy authority bounded;
- lease descriptor state boundaries warn that old descriptors are issuance evidence, not current live state;
- background leases and jobs keep future work distinct from ambient keep-running assumptions;
- receipt replication boundaries keep history from reviving present truth.

ViewFS should therefore borrow the discipline, not a final schema.

## Prior-art pressure mapped to ViewFS

- Nix: explicit GC roots and live closures are inspectable retention truth.
- IPFS: cache presence, direct pins, recursive pins, indirect pins, and MFS protection are different states.
- Git: unreachable objects can survive grace periods and reflogs, but recoverability windows are not durable roots.
- containerd: leases protect content/snapshots that may be used after a client operation, and callers own lease lifecycles.
- Kubernetes: owner references and finalizers model dependent cleanup and deletion barriers.
- OpenZFS: holds are named no-destroy references with release operations.

## Failure modes to test later

- A search index row keeps an otherwise deleted object alive by accident.
- A receipt is misread as a retention root.
- A live handle is collected because it was not represented to the collector.
- A portal import materializer loses bytes because its lease expired too early.
- A finalizer becomes unreleasable mystery state.
- A sweep dry-run is executed after its root basis is stale.
- A collected tombstone leaks sensitive object names.
- A restore flow resurrects an object from ash without passing the durable-root and resurrection gates.

## Minimal prototype posture

A useful prototype could start with:

- one explicit root ledger root;
- one live-handle liveness table;
- one expiring materializer lease class;
- one dry-run sweep report;
- one finalizer row shape;
- one receipt-only ash row;
- one `why retained?` CLI command.

That is enough to test the seam without choosing a universal object-store GC algorithm.
