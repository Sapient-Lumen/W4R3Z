# Secret descriptors, acquisition prompts, delivery slots, environment shadows, redaction lenses, renewal leases, live-use handles, and receipts

Revision 145 follows the supply-chain admission work into the runtime secret lane. The goal is not to choose a vault or token-broker substrate. The goal is to keep secret-bearing launch/import/use flows explicit enough that ViewFS does not reintroduce ambient authority through environment variables, shell history, config interpolation, or transcript masking.

## Why this split matters

Secret handling is where otherwise careful capability designs often smuggle the old world back in. A package may be admitted only for safe test execution, but then receives a broad cloud token through an inherited environment. A portal may mediate file import, but the helper reads a host keyring through a compatibility side channel. A terminal may mask a value in its transcript, but the same value sits in process environment snapshots, child processes, crash dumps, screenshots, or copied config files.

SlopOS is especially useful here because its D-APPSECRET posture says `minimal app-scoped seed; not a vault`, its capshell environment baseline says child environments are exact rather than host-injected, and its credential/auth-export boundaries keep login results, proof exports, identity claims, account binding, authorization context, and teardown separate. ViewFS should mirror that hygiene without importing a final SlopOS secret API.

## Classes that must not collapse

### Secret descriptor

A redaction-safe description of a needed or issued secret-bearing resource. It may say purpose, scope, provider family, audience, account/tenant class, carrier preference, rotation epoch, and non-exportability. It must not contain bearer bytes, passwords, private keys, raw refresh tokens, or enough provider identifiers to become a tracking leak.

### Acquisition prompt / consent act

A mediated act that may unlock or issue material: user approval, local-auth prompt, policy gate, hardware presence, vault unlock, federated login continuation, or provider callback. A successful prompt can produce a slot or handle, but the prompt result itself is not a reusable credential.

### Delivery slot / projection

The actual lane into one subject: handle slot, credential directory entry, file projection, memfd-like carrier, provider session, IPC endpoint, or compatibility environment/config projection. The slot is current and local. It is not object identity, a global name, or a future reopen promise.

### Environment shadow

Any string or string-adjacent representation: environment variable, argv field, config interpolation, `$FOO_FILE` pointer, shell variable, command history row, task output, or notebook cell. Some legacy tools need these. ViewFS should support them honestly, but mark them as leak-prone shadows, not as the preferred secret authority surface.

### Redaction lens

A display/transcript/search/log/crash/screenshot mask. This is valuable UX and safety plumbing, but it is not a kernel access check, vault lock, process isolation boundary, or proof that no copies exist. Redaction is a lens, not authority.

### Renewal / rotation lease

A scoped ability or evidence basis to refresh, renew, rotate, revoke, or reacquire. It should name audience, scope, expiry, prompt requirements, provider currentness, and denial modes. It is not the current token/key/seed, and it is not as weak as a receipt.

### Live-use handle

The present authority: a bearer token in memory, a signer/decryptor handle, a provider-bound secret session, a live file descriptor, a short-lived credential set, or an app-seed use capability. This is the class that can act now, subject to caveats.

### Residue marker

Secret-derived leftovers: copied config, initialized database state, cached token, child environment, process snapshot, crash dump, terminal output, shell history, thumbnail, OCR, embedding, summary, exported file, remote login session, or provider-side state. Residue is not necessarily live authority, but it is not nothing.

### Receipt/history

Durable explanation of request, prompt, issue, projection, use, renewal, rotation, revocation, redaction, residue, or cleanup. A receipt must not revive material, renew a token, hide a warning, or prove cleanup by assertion alone.

## Lessons worth stealing

### Activation-time file credentials beat magical env inheritance

Systemd service credentials are acquired at service activation, released on deactivation, immutable during runtime, exposed via a credentials directory, and explicitly called out as unlike environment variables because data is not propagated down the process tree. ViewFS should steal the shape: activation-time, slot-like, file/handle-like, non-propagating by default.

### Kubernetes and Docker show projection is useful, but projection is not trust

Kubernetes Secrets are intentionally separate objects and projected volumes can combine secret, downward API, config map, service account token, trust bundle, and pod certificate sources into a directory. Docker Swarm secrets mount decrypted material into a service task filesystem and tear it down when the task stops. Both are useful precedents for projection, but also warnings: default datastore encryption, namespace admission, subPath update behavior, platform differences, and app-level copies remain important.

### Secret stores are live and promptful

The desktop Secret Service API exposes collections/items/attributes and explicitly requires clients to handle lock/unlock races and prompts. This is a reminder that `known item exists`, `collection unlocked`, `secret retrieved`, and `still usable now` are different states.

### Environment variables are compatibility, not a safe secret plane

Linux exposes the initial process environment through `/proc/<pid>/environ` under the platform's access rules, and many tools put credentials in env for convenience. ViewFS should support legacy env only as an env-shadow lane with warnings, redaction, and child-inheritance accounting.

### Masking logs is not the same as controlling secrets

GitHub Actions' `add-mask` style is useful because it demonstrates a redaction lens that can protect logs after a value is marked. But it also sharpens the distinction: masking is display hygiene; it is not a delivery slot, renewal lease, or live-use boundary.

### Temporary credentials need visible expiry and reacquisition

AWS temporary credentials have bounded lifetimes and expire rather than needing long-term distribution; use requires session tokens and may involve explicit role/session semantics. ViewFS should steal the short-lived, scope/audience/expiry-visible posture without inheriting any one cloud credential chain as the model.

## Design guidance

1. Prefer handle/file/slot projection over raw env/argv whenever possible.
2. When env/argv/config compatibility is needed, surface it as an **environment shadow** with child-inheritance, transcript, and inspection warnings.
3. Redaction should be attached structurally at the descriptor/slot/output boundary, not guessed after the transcript already leaked material.
4. Renewal and rotation should be explicit, not silent background magic tied to a stale receipt.
5. A prompt can unlock/issue a current slot, but prompt history is not authority.
6. Live-use handles should be narrower than vault items and narrower than login/account identity.
7. Residue should have cleanup plans and sweep receipts, but cleanup receipts should not overclaim.
8. Secret-derived semantic artifacts should be marked as derived residue unless separately sanitized and admitted.

## Non-decisions to preserve

Do not decide yet:

- one secret store, keychain, vault, or app-secret provider;
- one token shape, auth protocol, or refresh mechanism;
- one carrier ABI for secrets across all platforms;
- whether ViewFS itself ever stores named secrets;
- whether secret descriptors are objects, receipts, policy packets, or all three;
- how to unify D-APPSECRET, D-VAULT, remote federation, platform key stores, and service-account identities;
- whether compatibility env projection is allowed by default, per profile, per command, or never.

## Shell implications

The shell should be able to render:

- **secret slot cards** (`handle`, `file`, `credential-dir`, `env shadow`, `provider session`, `history only`),
- **scope chips** (`profile`, `workspace`, `artifact`, `service account`, `audience`, `rotation epoch`),
- **prompt beads** (`requested`, `unlocked`, `issued`, `denied`, `dismissed`, `expired`),
- **env-shadow lamps** (`value in env`, `path pointer only`, `argv/config string`, `child inherits`, `procfs/log risk`),
- **redaction lenses** (`transcript`, `logs`, `crash`, `search`, `screenshot`, `not covered`),
- **renewal rails** (`refreshable`, `must reacquire`, `expired`, `revoked`, `requires presence`),
- **residue sweepers** (`config copy`, `db initialized`, `cache`, `child process`, `transcript`, `semantic artifact`),
- **use receipts** (`used for action`, `audience`, `epoch`, `no bearer material stored`).
