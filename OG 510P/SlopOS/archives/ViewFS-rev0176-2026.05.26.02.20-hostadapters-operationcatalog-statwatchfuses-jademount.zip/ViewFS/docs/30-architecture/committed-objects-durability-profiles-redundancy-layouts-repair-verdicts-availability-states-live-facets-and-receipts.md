# Committed objects, durability profiles, redundancy layouts, repair verdicts, availability states, live facets, and receipts

Purpose: keep **committed objects**, **durability profiles**, **redundancy layouts**, **repair verdicts**, **availability states**, **current live facets**, and **durable receipts/history** on distinct seams.

## The split
- **committed object** — one durable object record that exists now.
- **durability profile** — one declared or inferred protection target such as replica count, k-of-n recoverability, or equivalent survivability posture.
- **redundancy layout** — one concrete share / replica / placement / stripe / copy topology row for that object.
- **repair verdict** — one current statement about whether redundancy or integrity is healthy, degraded, being repaired, needs attention, or failed.
- **availability state** — one current answer to whether the object is retrievable here, retrievable with degradation, temporarily unavailable, or unrecoverable.
- **live facet** — currently usable inspect/read/edit/publish authority over that object.
- **receipt/history** — durable memory of commits, replica changes, repair runs, availability transitions, and operator or provider verdicts.

## Why this must stay split
A capability-heavy object store can easily lie by accident:
- one committed object gets mistaken for `fully protected everywhere`,
- one durability profile gets mistaken for proof that the current replica/share layout really matches it,
- one share or placement row gets mistaken for object identity,
- one repair pass or scrub receipt gets mistaken for current healthy retrievability,
- one degraded availability verdict gets mistaken for loss of object identity,
- or one live read/edit facet gets mistaken for a promise that the backing layout is still healthy.

That is exactly the kind of collapse ViewFS should avoid while SlopOS is still in design and while ViewFS itself is still collecting ideas instead of freezing one storage engine, one share format, or one repair policy.

## Lessons worth stealing
### Object identity and placement layout are different truths
Ceph is useful because the object ID is mapped to a placement group and then to OSDs through a layer of indirection, precisely so the cluster can rebalance and grow without making clients believe placement is object identity.
That is a strong reminder that one durable object and one current placement/share layout are different layers.

### Redundancy profile and current repair health are different truths
Ceph is also useful because scrubbing and peering continuously compare replicas and metadata, which means `we have a redundancy strategy` and `the current copies still agree` are different truths.
That is a strong reminder that durability profile, repair verdict, and current availability should not collapse.

### Share encoding and access control are different truths
Tahoe-LAFS is useful because it separates k-of-n share encoding from filecap/access-control questions, and because the immutable decoding story starts from capability values plus enough shares rather than from one flattering `stored file` myth.
That is a strong reminder that share topology, recoverability threshold, and current authority are different truths.

### Replication status and durable object existence are different truths
Amazon S3 replication guidance is useful because replication is asynchronous and because objects expose replication status values such as `PENDING`, `COMPLETED`, `FAILED`, and `REPLICA`.
That is a strong reminder that one object can already exist durably while copy-spread or catch-up posture is still a separate truth.

### SlopOS already rhymes with the same lesson
Current SlopOS drafts are useful because CH-AREF already keeps digest identity separate from non-authoritative location hints, and CH-CAPSTORE keeps durable commit meaning separate from whatever storage engine or replica topology might later back it.
That means ViewFS can steal the separation now even though SlopOS itself has not settled a final datacube storage substrate.

## Design guidance
1. A **committed object** should be inspectable without implying that all intended redundancy is healthy right now.
2. A **durability profile** should stay visible instead of hiding inside one flattering `stored safely` bit.
3. A **redundancy layout** should remain weaker than object identity and weaker than current authority.
4. A **repair verdict** should remain visible as its own class instead of being flattened into object birth, mutation, or deletion.
5. An **availability state** should stay visibly weaker than object identity and stronger than vague operator folklore.
6. A **live facet** should stay visibly stronger than every durability/layout/repair/history row.
7. A **receipt/history** row should remember prior repair or degradation facts without reviving present authority or pretending recovery is impossible forever.

## Shell implications
The shell should be able to render:
- **durability badges** (`replica target`, `k-of-n target`, `single copy`, `unknown`, `history only`),
- **layout ghosts** (`layout hidden`, `shares placed`, `replicas spread`, `placement changed`, `history only`),
- **repair ladders** (`healthy`, `degraded`, `scrubbing`, `repairing`, `failed`, `history only`),
- **availability lamps** (`retrievable`, `retrievable with degradation`, `provider unavailable`, `unrecoverable`, `history only`),
- **live rails** (`inspect now`, `read now`, `edit now`, `publish now`, `history only`).

## Non-decisions to preserve
Do not decide yet:
- one universal durability-profile registry across all ViewFS providers and object families;
- whether every provider exposes concrete share / replica / placement rows;
- whether repair verdicts are provider-native, locally synthesized, or mixed;
- whether availability states are object-local, room-local, provider-local, or all three;
- one final wire format for redundancy layout or repair receipts;
- one universal policy for when degraded availability should warn, block, or silently continue.
