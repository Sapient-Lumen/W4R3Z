# Namespace plans, live room bindings, import sessions, and local overlays

This note protects one more high-value seam while ViewFS and SlopOS are both still moving.

Revision 0091 already split room identity, current view, inheritance posture, child recipes, child-received imports, and receipts.
This note adds a second discipline on top:

**the thing we plan to switch/bind, the thing that is live now, the portal session that may still be in flight, the local-only overlay around the room, and the receipt explaining what changed are different classes.**

## The split

### 1. Namespace plan / switch target
A namespace plan is the reviewable answer to:
- what view/fragment/import set would I like this room or child to use next?

It may be saveable, diffable, and searchable.
It is not current room authority.

### 2. Live room binding
A live room binding is the current answer to:
- what can this room actually resolve/use right now?

This should tell the truth about current imports, current root/cwd posture, and current provider-backed projections.
It should not pretend to describe pending portal sessions or local chrome.

### 3. Portal import session
A portal import session is the current answer to:
- what chooser/request/session/import workflow is still alive and what stage is it in?

Good state labels:
- `request-pending`
- `user-step-needed`
- `granted-not-bound`
- `bound-here`
- `expired`
- `receipt-only`

This helps ViewFS stay honest about mediation.

### 4. Local-only overlay
A local overlay is the room/device/activity-specific convenience delta layered around the stronger portable core:
- local layout
- local sort/filter/inspector posture
- local receiver preference
- local trust/debug lamps
- local palette pins or shortcuts

This state should be derivative and cheap to discard.
It should not silently travel with exported objects or portable receipts.

### 5. Anchor/reset death state
Sometimes an old switch/import/resume anchor dies because:
- the room switched to a newer namespace epoch,
- an import session expired,
- restore only brought back layout,
- or a reset cleared the old exact binding basis.

ViewFS should keep that as explicit death/reset truth rather than silently repairing to `latest` and pretending continuity survived.

### 6. Receipt/history
Receipts preserve explanation of:
- switches
- imports
- refusals
- overlay clears
- reset scopes

They should not silently reactivate live authority or recreate local overlay residue.

## Product consequences

### Namespace switchboards
The shell should be able to show:
- `planned target`
- `live now`
- `portal session`
- `local overlay`
- `receipt only`

as adjacent but distinct rows.

### Overlay racks
The shell should surface local-only deltas explicitly:
- which are activity-local
- which are device-local
- which are safe to clear/rebuild
- which are stale because the live room binding changed

### Import session strips
A room should be able to show `pending`, `needs-user-step`, `granted-not-bound`, `bound-here`, `expired`, or `receipt-only` without flattening them into one `open` badge.

### Anchor death cards and reset-scope chips
If a prior switch/import anchor no longer survives, the shell should leave a tiny death card explaining:
- what died,
- what killed it,
- what weaker residue still survives,
- and the strongest honest next verb.

## Why this fits current SlopOS work
Current SlopOS already leans toward:
- explicit view objects rather than ambient global path truth,
- capability-safe shell posture,
- descriptive wallets,
- typed plumb messages/intents,
- document-portal and durable-handle mediation.

That gives ViewFS permission to protect this seam **without** deciding the final store schema or final shell wire format.

## Good questions to keep open
- Should a namespace plan be room-owned, shell-owned, or a portable store object later?
- Are local overlays purely shell chrome, or can some become small rebuildable helper objects?
- Can an expired portal session still leave a reusable recipe but no live bind?
- Which reset scopes kill only local overlays versus the exact live binding basis itself?
- How should receipt-first restore degrade when layout survives but live imports do not?
