# Semantic object cores, exact byte proofs, structured addresses, live facets, and receipts

ViewFS is converging on an object store + capability handles + explicit per-process namespace + portal-mediated imports.
That combination gets much easier to evolve if we keep one more seam sharp early:
**the semantic object we mean**, **one exact byte proof**, **one structured/chunked/store address**, **one human-facing designation**, **one current live facet**, and **one durable receipt/history row** are not the same truth.

This matters because many systems say they are “content addressed” while actually identifying different layers:
- OCI descriptors identify the digest, media type, and byte size of one exact raw payload.
- RFC 6920 `ni:` names identify a digital object using hash output.
- IPFS CIDs include codec and multihash and can name the root block of a chunked DAG rather than the original file checksum.
- Nix content-addressed store paths deliberately include the file-system graph plus references, store directory, and name.

Those are all useful.
They are just not the same noun.

## Keep these classes separate
- **semantic object core** — the thing the user or workflow means to keep talking about, if ViewFS chooses to model one
- **exact byte proof** — one digest/proof over one exact byte sequence or canonicalized byte envelope
- **structured address / shape hash** — one identifier that bakes in codec, chunking, graph shape, references, or store-path context
- **designation / published name / locator hint** — one non-authoritative way to talk about or rediscover something
- **live facet** — one current inspect/read/edit/publish/automation authority surface
- **receipt/history row** — evidence that one import, hydration, publish, or bind event happened

Do **not** flatten them into one vague story like “the object hash” or “the file ID”.

## Why this is a low-regret lesson
A brand new object store is very likely to need more than one stable handleable truth:
- the shell may want a durable object card even before bytes are local,
- import flows may preserve a proof over imported bytes without committing to one final object-core scheme,
- a provider-backed object may have one semantic identity but several exact encodings or projections,
- one store-family may use a structured closure/hash that intentionally includes references or names,
- and live current authority must still stay separate from all of the above.

If ViewFS keeps those nouns separate now, it can stay ambitious about object cards, proof badges, shape-hash drawers, and facet rails **without** freezing one universal object-id family, one universal canonicalization rule, one universal chunking scheme, or one final handle ABI too early.

## SlopOS alignment
This fits the current SlopOS datacube well:
- `artifact-reference-schema-v0.md` already says the digest is authoritative while locators are only hints.
- `artifact-resolution-posture-v0.md` already refuses ambient locator dereference and requires explicit workflows.
- `verified-blob-descriptor-schema-v0.md` already treats verification posture as its own descriptive seam.
- `release-identity-boundary-v0.md` already warns that labels and version strings are not the same as exact digests.
- `capstore-commit-schema-v0.md` already keeps named roots/commits separate from the underlying referenced artifacts.
- `document-handle-schema-v0.md` and `wallet-posture-v0.md` already keep descriptive handles/wallets non-authoritative.

So ViewFS does **not** need to decide now whether semantic object cores are global, family-specific, optional, or mostly implicit.
It only needs to keep exact byte proof, structured address, designation, live facet, and history from collapsing together.

## What to steal
- **object-core cards** that say `same object core`, `exact bytes proven`, `shape hash only`, `name only`, `live facet here`, or `history only`.
- **byte-proof lamps** that distinguish exact raw-byte proof from a structured-address proof.
- **shape-hash drawers** that explain when chunking/codec/reference-sensitive identity is in play.
- **import receipts** that preserve which proof/address families were known at import time without pretending those are live binds now.
- **facet rails** so inspect/read/edit/publish lanes stay current-authority truths instead of being inferred from old proofs.

## What not to freeze yet
- one universal semantic-object-core identifier family;
- whether every object family gets a semantic core distinct from exact bytes;
- one universal canonicalization/normalization rule for proof generation;
- whether structured addresses are first-class everywhere or only for chunked/closure-backed families;
- whether human-facing designators are mostly local aliases, object cards, docrefs, or publication rows.
