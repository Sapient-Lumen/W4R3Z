# Revision 155 executable-spine note

Revision 155 adds the first checked ViewFS spine. The core schema, proof obligations, and fixture corpus make a small set of non-negotiable claims executable: receipts do not reopen authority, digests do not read, semantic cards do not become source handles, click/gesture evidence does not approve high-risk effects, compatibility paths cannot escape a view root, and derived artifacts are not retention roots by default. See `docs/30-architecture/core-schema-v0.md`, `docs/40-verification/proof-obligations-v0.md`, and `fixtures/viewfs-core-v0/`.

The architectural posture is now: keep growing the taxonomy only when a specimen and checker make the new seam falsifiable. The object store, handle layer, view layer, portal/compat layer, and shell/transcript layer remain the central split, but they now have an executable v0 vocabulary.

# Architecture overview

Revision 153 adds an instruction/prompt/agent hygiene seam: instruction source records, trust/priority labels, context frames, model/prompt profiles, proposal text, typed action plans, tool invocation candidates, approval cuts, current live authority, result/observation lanes, and receipts remain distinct. This keeps semantic retrieval and agentic shell UX useful without letting prompt prose become authority. See `docs/30-architecture/instruction-sources-context-frames-proposal-text-action-plans-tool-invocations-approvals-live-authority-and-receipts.md` and `rfcs/0140-viewfs-keep-instruction-sources-context-frames-proposal-text-action-plans-tool-invocations-approvals-live-authority-and-receipts-separate.md`.

Revision 151 adds a content-address / dedup privacy seam: content addresses, equality witnesses, dedup eligibility hints, convergence/privacy domains, cache-hit observations, proof-of-possession checks, materialization decisions, current live facets, and receipts remain distinct. This keeps the object store ambitious without letting a digest, dedup hit, cache row, or old proof become identity, trust, publication, membership, retention, or live authority.

Revision 150 adds a secure-transport identity seam: transport intents, reference identity sets, presented evidence, verifier profiles, trust-anchor/pin inputs, verification verdicts, channel bindings, session resumption/0-RTT state, current live secure channels, and receipts remain distinct. This continues the object-store/capability-handle discipline by making cryptographic evidence useful without letting it become live service, object, or import authority.

## Core split

Revision 151 adds one more cross-cutting split: content-addressed storage belongs in the object-store substrate, but it must not become a generic membership oracle or a live-handle substitute. See `docs/30-architecture/content-addresses-equality-witnesses-dedup-hints-convergence-domains-cache-hits-materializations-live-facets-and-receipts.md` and `rfcs/0138-viewfs-keep-content-addresses-equality-witnesses-dedup-hints-convergence-domains-cache-hits-materializations-live-facets-and-receipts-separate.md`.

Revision 150 adds one more cross-cutting split: secure-transport identity evidence belongs beside network and service binding, but must not be collapsed into either. See `docs/30-architecture/transport-identities-verifier-profiles-trust-anchor-inputs-transparency-status-evidence-channel-bindings-session-resumption-live-secure-channels-and-receipts.md` and `rfcs/0137-viewfs-keep-transport-identities-verifier-profiles-trust-anchor-inputs-channel-bindings-session-resumption-live-secure-channels-and-receipts-separate.md`.
ViewFS should be decomposed into five layers:
1. **Object store** — immutable blobs, manifests, and compact metadata.
2. **Handle layer** — object references plus rights and attenuation rules.
3. **View layer** — explicit per-process synthetic roots assembled from bindings.
4. **Portal / compat layer** — user-mediated imports/exports and optional path shims.
5. **Shell / transcript layer** — receipts, blocks, workflows, switchboards, overlay racks, and inspection UX over the lower layers.

Host bridges/backstops such as preopen adapters, rooted host path walkers, or Linux sandboxing may be useful during bring-up, but they are implementation scaffolding rather than the semantic center of the design. Another object-store lesson now looks load-bearing too: one **committed object**, one **prefix projection**, one **provider folder resource**, one **listing snapshot**, one **published name**, one **current live facet**, and one **receipt/history row** should stay distinct even when the UI groups them into one friendly folder card. Another low-regret separation now looks load-bearing too: one **authority-core stamp** for review/drift gates, one richer **descriptive review envelope**, one or more **explain sidecars**, one **current live bind**, and one **receipt/history row** should stay distinct even when the UI groups them into one friendly object card. And one more comparison lesson now looks just as load-bearing: one **strong exact proof**, one **weak validator**, one explicit **comparison profile**, one **current live facet**, and one **receipt/history row** should stay distinct even when the UI groups them into one friendly sameness badge. One more storage lesson now looks load-bearing too: one **committed object**, one **archive tier**, one **thaw job**, one **thawed copy**, one **current live facet**, and one **receipt/history row** should stay distinct even when the UI groups them into one friendly restore card. And one more locality lesson now looks just as load-bearing: one **committed object**, one **residency profile**, one **placement realm**, one **route endpoint**, one **egress gate**, one **current live facet**, and one **receipt/history row** should stay distinct even when the UI groups them into one friendly route badge. Keep direct-handle opens, rooted compat pathwalks, portal-mediated grants/projections, ambient host escapes, current published names, discoverability/enumeration/exact-name-open truth, provider/catalog adverts, freshness-scoped readiness, provider-ready/reacquire/local-realized truth, grant-needed posture, current possession, freshness/step-up posture, current invocability, and receipts/history visibly separate too; see `docs/30-architecture/explicit-handle-opens-rooted-compat-pathwalks-and-ambient-escapes.md`, `docs/30-architecture/store-membership-synthetic-views-live-handles-and-published-names.md`, `docs/30-architecture/discoverability-enumeration-exact-name-reachability-and-fit-notes.md`, `docs/30-architecture/presence-adverts-readiness-current-authority-and-receipts.md`, `docs/30-architecture/provider-ready-claims-reacquire-obligations-local-realizations-and-live-handles.md`, `docs/30-architecture/foreign-backed-borrows-compat-attaches-projected-imports-and-local-realizations.md`, and `docs/30-architecture/current-possession-freshness-step-up-and-current-invocability.md`, and `docs/30-architecture/native-attaches-adapted-attaches-coerced-representations-and-local-realizations.md`. See `docs/30-architecture/host-bridge-and-backstop-posture.md`. Keep identity, reopen, reveal, handle/ref/receipt classes, saved session state, advisory registries, workspace-trust seams, preview/observation seams, watch/notification seams, link/alias/shortcut classes, grouped-authority classes, and launch-assembly classes distinct as well; keep exact object identity, current placement in a view, current handle-rights posture, and advertised affordances separate too; origin evidence, quarantine state, safe-open lanes, and trust transitions should stay separate too; delete/trash/recovery/retention/purge classes should stay separate as well; checkpoints, writable forks/worktrees, backup streams, publish candidates, and activation targets should stay separate too; see `docs/30-architecture/object-identity-recents-and-reveal.md`, `docs/30-architecture/handles-refs-and-receipts.md`, `docs/30-architecture/session-state-and-authority.md`, `docs/30-architecture/activation-carriers-badged-handle-copies-and-object-identity.md`, `docs/30-architecture/indexes-recents-and-selectors.md`, `docs/30-architecture/workspace-trust-and-automation-gates.md`, `docs/30-architecture/built-in-shell-affordances-customization-bundles-startup-files-and-project-hooks.md`, `docs/30-architecture/command-surface-layers-key-actions-and-external-launches.md`, `docs/30-architecture/previews-extractors-and-observation-surfaces.md`, `docs/30-architecture/watchers-notifications-and-rebuilds.md`, `docs/30-architecture/links-aliases-and-shortcuts.md`, `docs/30-architecture/identity-placement-rights-and-affordances.md`, `docs/30-architecture/origin-quarantine-and-trust-transitions.md`, `docs/30-architecture/trash-retention-and-purge.md`, `docs/30-architecture/checkpoints-clones-and-publication.md`, `docs/30-architecture/leases-preconditions-and-conflicts.md`, `docs/30-architecture/query-manifests-result-snapshots-and-live-feeds.md`, `docs/30-architecture/pins-caches-prefetch-and-hydration.md`, `docs/30-architecture/bundles-view-fragments-and-launch-kits.md`, `docs/30-architecture/requests-candidates-selections-and-imports.md`, `docs/30-architecture/store-membership-synthetic-views-live-handles-and-published-names.md`, and `docs/30-architecture/committed-objects-residency-profiles-placement-realms-route-endpoints-egress-gates-live-facets-and-receipts.md`; keep user intent, prepared route plans, approval checkpoints, committed execution, and result receipts separate as well; see `docs/30-architecture/intents-route-plans-approvals-and-results.md`; keep suggested automation, promoted user-owned workflows, prepared run plans, committed runs, and history receipts separate too; see `docs/30-architecture/suggestions-recipes-promotions-and-runs.md`; keep lend requests, live borrowed authority, durable delegated refs, issuer-side recall/expiry controls, and loan-end receipts separate as well; see `docs/30-architecture/loans-delegations-recalls-and-expiry.md`; keep reuse candidates, exact basis records, current drift checks, fresh reconsent checkpoints, renewed artifacts, and reuse receipts separate too; see `docs/30-architecture/basis-records-drift-checks-and-reconsent.md`; keep admissible witness packs, caveat sets, freshness/consistency witnesses, why-records, and durable receipts separate as well; see `docs/30-architecture/witness-packs-caveats-freshness-and-why-records.md`. Keep validation/schema material, authoritative policy/caveat material, shell advice rails, decision diagnostics, and durable logs/receipts separate too; see `docs/30-architecture/schemas-policies-advice-diagnostics-and-decision-logs.md`; and keep policy-family/catalog choice, exact authoritative cuts/consistency posture, fallback candidates, repair proposals, and selection receipts/history separate as well; see `docs/30-architecture/policy-families-cuts-fallbacks-and-repair.md`. Keep deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and adoption receipts/history separate as well; see `docs/30-architecture/deny-ceilings-narrowing-and-scope-eligibility.md`. Keep owner/org policy sources, trust-state gates, user/profile preference layers, workspace/imported proposal sources, effective active state, and durable receipts/history separate as well; see `docs/30-architecture/policy-sources-trust-gates-and-precedence.md`. Keep author classes, carrier/container classes, trust gates, advisory-only helper sources, effective active state, and durable receipts/history separate as well; see `docs/30-architecture/policy-authors-carriers-and-advisory-sources.md`. Keep protected-authorable state, carrier/discovery presence, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipts/history separate as well; see `docs/30-architecture/protected-scopes-authorability-and-invocation-lanes.md`. Keep publisher trust, installed helper packages, configured helper/server definitions, enabled state, start approvals, live brokered sessions, request-scoped tool selections, and durable receipts/history separate as well; see `docs/30-architecture/publisher-trust-helper-installs-and-live-sessions.md`. Keep helper-exposed resource descriptors, prompt templates, tool descriptors, app surfaces, completion suggestions, request-bound attachments/selections, live invocations/results, and durable receipts/history separate as well; see `docs/30-architecture/resources-prompts-tools-apps-and-bindings.md`. Keep immediate requests, accepted task wrappers, live progress/status streams, input-required checkpoints, deferred final results, and durable receipts/history separate as well; see `docs/30-architecture/requests-tasks-progress-and-results.md`. Keep transfer/courier offers, accepted representation choices, live copied handles, later revival designators, receiver-local adopted binds, and durable receipts/history separate as well; see `rfcs/0058-viewfs-keep-transfer-offers-live-handle-copies-revival-designators-adopted-binds-and-receipts-separate.md`. Keep room identity, current room-local view, context-inheritance posture, prepared child spawn/import recipes, child-received bindings/imports, and durable receipts/history separate as well; see `docs/30-architecture/room-identities-current-views-context-inheritance-and-child-spawns.md` and `rfcs/0091-viewfs-keep-room-identities-current-views-context-inheritance-child-spawn-recipes-imported-bindings-and-receipts-separate.md`. Keep durable import anchors, current live room bindings, stale-but-repairable shadows, repair/rebind plans, and durable receipts/history separate as well; see `docs/30-architecture/durable-import-anchors-live-room-bindings-stale-shadows-and-repair-plans.md` and `rfcs/0093-viewfs-keep-durable-import-anchors-live-room-bindings-stale-shadows-repair-plans-and-receipts-separate.md`. Keep local editable shadows, exact pushback basis/preconditions, provider verdicts, locally adopted results, and durable receipts/history separate as well; see `docs/30-architecture/live-room-bindings-local-edit-shadows-pushback-bases-provider-verdicts-and-adopted-results.md` and `rfcs/0104-viewfs-keep-live-room-bindings-local-edit-shadows-pushback-bases-provider-verdicts-adopted-results-and-receipts-separate.md`. Keep accepted pushback requests, provider operation/completion tickets, later completion verdicts, locally adopted results, and durable receipts/history separate as well; see `docs/30-architecture/live-room-bindings-local-edit-shadows-accepted-pushback-requests-provider-operations-completion-verdicts-and-adopted-results.md` and `rfcs/0105-viewfs-keep-live-room-bindings-local-edit-shadows-accepted-pushback-requests-provider-operations-completion-verdicts-adopted-results-and-receipts-separate.md`.

## Design pressure
The danger zone is letting layer 4 or 5 quietly redefine layers 1–3. History suggests that once ambient paths, hidden inheritance, or folklore shell state sneak back in, capability systems lose their main benefit.

A second danger zone is premature mutable-state certainty. The object store can be boring now; mutable work state should stay an explicit design space until a few narrow spikes have pressure-tested journals, root-pointer updates, and stable-anchor models.

A third danger zone is semantic overloading. ViewFS should not casually make one thing serve as all of the following at once:
- immutable object identity,
- current name in a view,
- mutable current head,
- workspace/tree binding,
- durable reopen authority,
- recent-item / palette memory,
- and URI route/reveal state.

Those may interact, but they should remain separate questions until evidence proves a coupling is worth the cost. Saved shell/session memory should also stay separate from current authority.

A fourth danger zone is trusting workspace automation just because the workspace tree is visible. Browsing a project, parsing its metadata, and executing its tasks/env hooks/debug launchers/agents should remain distinct approvals.

A fourth-and-a-half danger zone is trusting shell delight just because the prompt looks local and friendly. Built-in shell affordances, explicit reviewed customization bundles, ambient host startup files, project-local activation hooks, and durable receipts/history should remain distinct approvals and truths too. Otherwise prompt rendering, aliases, completions, terminal integration, and per-directory activation quietly regress to ambient dotfile folklore.

A fourth-and-three-quarters danger zone is trusting command resolution just because one familiar token or keypress appears to work. Built-in verbs, lexical expansions, semantic command layers, key actions/widgets, external launches, and durable receipts/history should remain distinct truths too. Otherwise abbreviations, overlays, palette actions, key tables, wrappers, and external executables quietly regress to command-folklore soup.

A fourth-and-seven-eighths danger zone is trusting color, parse recovery, or diagnostics just because the line editor looks smart. Editable buffers, parsed/highlighted structure, advisory diagnostics, compiled command packets, prepared actions, and durable receipts/history should remain distinct truths too. Otherwise syntax color, parser guesses, lint hints, and stale packet chrome quietly regress into fake readiness.

A fourth-and-fifteen-sixteenths danger zone is letting room identity silently collapse into current view, child inheritance, saved rerun plans, or receipts. Tabs and panes are where humans build intuition, so if the shell shows one friendly room label while quietly mutating the bound view, the child-spawn posture, or the current imports, capability truth disappears behind cozy chrome.

A fifth danger zone is letting preview or extraction quietly redefine authority. A shell can have gorgeous peek panes, compare mode, and derived sidecars without pretending that preview equals open, trust, or durable reopen.

A sixth danger zone is treating change feeds as perfect truth. Watchers, recents, palettes, and smart folders can feel alive while still admitting overflow, recrawl, rebuild, and partial coverage states.

A seventh danger zone is letting every clickable link-like thing collapse into one class. Namespace aliasing, durable reopen, launch routes, and transcript receipts can all be useful, but they should not masquerade as the same kind of authority.

An eighth danger zone is letting origin and quarantine quietly collapse into trust. Previewing, rebinding, indexing, or remembering an object should not silently clear or bless it, and broad trusted-location semantics should carry a high burden of proof.

A ninth danger zone is treating all delete-like actions as if they were one thing. Removing a name from a view, moving something to a recoverable trash, keeping local history, holding immutable data live through roots, and actually purging collectible storage are different seams with different proof obligations.

A tenth danger zone is treating every time-travel-ish operation as “just a snapshot.” Cheap checkpoints, writable forks/worktrees, replicated backup streams, publish candidates, and activation/rollback targets have different promises and should stay visibly distinct.

An eleventh danger zone is flattening all concurrent-write behavior into “lock state.” Expected-old guards, create-if-absent semantics, short reservations, field/subtree ownership hints, conflict artifacts, and explicit takeover acts have different costs and should stay separate.

A twelfth danger zone is pretending a smart folder is one thing. The saved query recipe, the current result snapshot, the live update feed, the shell pin/sidebar surface, and the current authority over matches are all different classes and should stay visible as such.

A thirteenth danger zone is flattening import, open-in-place, save/export, move, transfer, share, and promise-later materialization into one generic file operation. Those lanes move different things across boundaries: some copy bytes, some delegate access, some only select a destination, and some only publish a promise to materialize bytes later.

A fourteenth danger zone is treating prefetch, cache warmth, hydration, pinning, mirroring, and offline bundles as one generic “download state”. Those classes make different promises about discardability, retention, locality, transport, and offline truth, and they should stay visibly separate.

A fifteenth danger zone is treating `where this object is allowed to live`, `where copies currently live`, `which endpoint a read currently routes through`, and `whether a boundary-crossing export is allowed` as one friendly locality badge. Residency profiles, placement realms, route endpoints, egress gates, and current live authority have different failure modes and should stay visibly separate too.

A fifteenth danger zone is collapsing grouped authority, namespace templates, live view binds, child launch kits, and historical receipts into one convenience object. Those classes interact heavily, but they answer different questions: what travels together, what could be bound, what is bound now, what a child will launch with, and what only happened in the past.

A sixteenth danger zone is collapsing local object-store existence, synthetic portal/provider projection, current live-handle possession, current publication inside one process namespace, and durable receipt/history into one vague “file” concept. Those classes interact heavily, but they answer different questions: what exists locally, what is reachable through a mediated view, what current authority is held, what is published here now, and what only happened in the past.

A sixteenth danger zone is collapsing mediated interaction state, chooser-owned candidate sets, selected outcomes, minted grants/refs, live binds, and history into one magical “opened object”. Those classes answer different questions: what interaction is pending, what the mediator was willing to show, what the user designated, what authority was actually issued, what is bound into this pane now, and what only happened in the past.

A seventeenth danger zone is collapsing user intent, prepared route/action plans, approval checkpoints, committed execution, and result/history into one magical shell action. Those classes answer different questions too: what is being asked for, how the system would do it, what exact delta was reviewed, what actually ran, and what only happened in the past.

An eighteenth danger zone is collapsing externally suggested automation, promoted user-owned workflows, prepared run plans, committed runs, and history into one magical saved command. Those classes answer different questions too: where the idea came from, whether it is mine yet, how it would run now, what actually ran once, and what only happened in the past.

A nineteenth danger zone is collapsing lend requests, live borrowed handles, durable delegated refs, issuer-side recall/expiry controls, and loan-end history into one magical shared-handle object. Those classes answer different questions too: who is asking, what is live right now, what may be reopened later, who can end or renew the relationship, and what only happened in the past.

A twentieth danger zone is collapsing past success, exact prior basis, current drift, fresh reconsent, renewed authority, and reuse history into one magical replay object. Those classes answer different questions too: what worked before, what exactly was reviewed, what changed now, what must be approved again, what is live or reopenable now, and what only happened in the past.

A twenty-first danger zone is collapsing admissible witness material, caveat sets, freshness/consistency witnesses, why-records, and durable receipts into one magical justification object. Those classes answer different questions too: what facts are allowed to count, what narrowing is in force, what state cut was evaluated, why the system chose its current class, and what only happened in the past.

A twenty-second danger zone is collapsing proposal origins, proposal scopes, escalation requests, authoritative adoptions, and durable adoption receipts into one magical helper lane. Those classes answer different questions too: who suggested the change, how broad it wants to be, whether a higher-scope move is still pending, what exact act made something live, and what only happened in the past.

A twenty-third danger zone is collapsing deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and durable adoption history into one magical permission helper. Those classes answer different questions too: what is categorically forbidden, what combinations are admissible at all, what safer alternative is on offer, what widening step is still pending, and what only happened in the past.

A twenty-fourth danger zone is collapsing author classes, trusted carriers, trust gates, advisory-only rails, and durable history into one hidden trust tunnel. Those classes answer different questions too: who may author active truth at all, what merely transported candidate material here, what still blocks it, what can only advise, and what only happened in the past.

A twenty-fifth danger zone is collapsing helper-exposed resources, prompts, tools, interactive app surfaces, completion suggestions, request bindings, live invocations/results, and durable history into one magical helper item. Those classes answer different questions too: what context/data exists, what workflow template exists, what may be invoked, what interactive surface may be launched, what is only a hint, what is attached now, what actually ran now, and what only happened in the past.

A twenty-sixth danger zone is collapsing transfer offers, accepted representation choice, live copied handles, later revival designators, receiver-local adoption, and durable history into one vague shared/opened object. Those classes answer different questions too: what was offered, what the receiver accepted, what carries authority right now, what can only be revalidated later, what is actually bound here now, and what only happened in the past.

Another danger zone is collapsing foreign-backed usability, wrapper/relay attach posture, projected import posture, local realization, and durable history into one flattering `opened here` story. Those classes answer different questions too: does another provider still back this thing, what glue made it usable here, what scoped view or synthetic name exists locally, what bytes/object state were actually localized here, and what only happened in the past.

Another danger zone is collapsing native receiver fit, adapter/relay-backed usability, coerced alternate representations, local realization, and durable history into one flattering `opened natively` story. Those classes answer different questions too: is this lane directly native for the receiver, what glue is in the path, is the user seeing the same object or one translated surface, what stronger local/native state was explicitly made here, and what only happened in the past.

## Working build order
1. immutable blob + manifest storage
2. directory/object handle API
3. per-process view root construction
4. portal import/export receipt flow
5. path compatibility membrane
6. shell/terminal ergonomics
7. only then: mutable work-state experiments, query/index layers, stored bundle/fragment schemas, stronger revocation models, richer origin/quarantine workflows, final plan/approval/result schemas, final loan/delegation/expiry schemas, final reuse/basis/reconsent schemas, and final witness/caveat/freshness/why-record schemas

## Early object vocabulary (tentative)
- `Blob`
- `Directory`
- `Manifest`
- `View`
- `GrantReceipt`
- `DurableRef`
- maybe later: `ImportRequest`, `SelectionRecord`, `ImportGrant`, `WorkspaceGrant`, `IntentRecord`, `RoutePlan`, `ApprovalCheckpoint`, `ExecutionRecord`, `ResultReceipt`, `SuggestedRecipe`, `PromotionReceipt`, `UserWorkflow`, `PreparedRunPlan`, `RunRecord`, `RunReceipt`, `LoanRequest`, `BorrowedHandleSet`, `DelegatedRef`, `RecallControl`, `LoanEndReceipt`, `BasisRecord`, `DriftCheck`, `ReconsentCheckpoint`, `RenewedArtifact`, `ReuseReceipt`, `WorkJournal`, `SessionManifest`, `CapabilityBundle`, `ViewFragment`, `LaunchKit`, `OriginReceipt`, `QuarantineMark`, `EditLease`, `ConflictReceipt`, or `MutableAnchor`

Everything richer should justify itself with a short experiment or a very strong interoperability need.

A likely future rule: cheap checkpoints are good enough to encourage routine experimentation, but promotion to replicated/published/activatable state should remain a separate seam.

## Three things to keep visibly subordinate
- **Paths**: compatibility syntax over explicit bindings.
- **Bundles**: grouped capabilities for transport or launch ergonomics, not a hidden ambient namespace.
- **Launch kits**: child-process assembly objects derived from explicit inputs, not a synonym for stored bundles or current pane state.
- **Synthetic views**: restricted mediated/provider projections that make something reachable somewhere without implying native publication in every current ViewFS pane/process.
- **Published names**: current path-like attachments inside one concrete process view, not a synonym for object identity or durable reopen.
- **Import requests/results**: chooser interactions, selected outcomes, minted grants, and live binds should stay class-aware instead of collapsing into one “opened object”.
- **Prepared plans and approvals**: exact review/execution aids over explicit handles, views, and portals, not hidden standing grants or floating mutable approvals.
- **Proposal helpers and adoption gates**: source-aware suggestion and escalation aids over explicit handles, views, policies, and receipts, not hidden standing selectors or silent scope widening.
- **Suggested automation and promoted workflows**: source-aware shell aids over explicit handles, views, portals, and receipts, not hidden standing trust or source-following mutation.
- **Borrowed authority**: bounded live sharing over explicit handles/views, not a synonym for durable reopen or hidden session-wide trust.
- **Trusted carriers**: helpful transport and discovery lanes over explicit adoption/gating surfaces, not a synonym for authoring ceilings or active policy.
- **Reuse / renewal**: exact-basis comparison and reconsent aids over explicit handles, refs, views, and receipts, not a synonym for sticky approval or floating current authority.
- **Editable state**: likely a sidecar, journal, or root-pointer layer over immutable content rather than the base storage truth.

## Bring-up rule
During the design phase, host-side bridges and backstops are acceptable **only** if they stay visibly subordinate to handles, views, portals, and receipts. The implementation may lean on `openat2`-style rooted walking, preopen adapters, explicit ambient-authority markers, or Landlock-style host sandboxes, but those tactics must not become the user-facing explanation of why an operation was allowed.

## New anti-collapse pressure from Revision 029
ViewFS should also keep one more seam explicit while policy-aware shelling is still fluid: **validation/schema material, authoritative policy/caveat material, shell advice/ranking, per-decision diagnostics, and durable logs/receipts** should not collapse into one magical “policy helper.” That keeps the shell free to be smart, rank likely repairs, and render great why-panels without letting hints or history become enforcement truth.

## New anti-collapse pressure from Revision 031
ViewFS should also keep one more seam explicit while proposal-heavy shelling is still fluid: **proposal origin/source, proposal lane/scope, escalation requests, authoritative adoptions, and durable adoption receipts** should not collapse into one magical helper lane. That keeps the shell free to surface workspace/profile/org/history suggestions and repair hints without letting helpers or history become judges.

## New anti-collapse pressure from Revision 032
ViewFS should also keep one more seam explicit while scope control and shell escalation are still fluid: **deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and durable adoption receipts** should not collapse into one magical permission helper. That keeps the shell free to recommend safer narrower routes and great receipt-only fallbacks without letting advice, history, or queued actions widen current authority.

ViewFS should also keep one more seam explicit while source-aware shelling is still fluid: **author classes, carrier/container classes, trust gates, advisory-only helper sources, effective active state, and durable receipts/history** should not collapse into one hidden trust tunnel. That keeps the shell free to discover and render helper material aggressively without letting trusted carriers, history, or repair rails silently become the authors of current truth.

ViewFS should also keep one more seam explicit while source-aware shelling is still fluid: **protected-authorable state, carrier/discovery presence, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipts/history** should not collapse into one hidden auto-apply tunnel. That keeps the shell free to show rich lower-trust helpers and one-shot invokes without letting them silently author sticky state.

ViewFS should also keep one more seam explicit while helper-feature shelling is still fluid: **resource descriptors, prompt templates, tool descriptors, interactive app surfaces, completion suggestions, request-bound attachments/selections, live invocations/results, and durable receipts/history** should not collapse into one magical helper item. That keeps the shell free to expose rich helper catalogs and completions without letting visibility or old outcomes quietly become current request authority.

ViewFS should also keep one more seam explicit while custom-shell editing is still fluid: **editable buffers, parsed structures/highlight models, advisory diagnostics, compiled command packets, prepared actions, and durable receipts/history** should not collapse into one magical smart prompt. That keeps the shell free to offer tree-aware editing, syntax color, lint rails, and packet gutters without letting parser guesses or diagnostics impersonate current authority or current readiness.

A twenty-third danger zone is collapsing immediate requests, accepted task wrappers, live progress/status, input-required waits, deferred final results, and durable history into one vague “background job”. Those classes answer different questions: what was asked now, what was accepted for later work, what is merely the latest live status, what extra input is still needed, what final output is retrievable, and what only happened before.


A twenty-fourth danger zone is collapsing close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable history into one vague stop-or-rerun menu. Those classes answer different questions: did we end the interaction, request graceful cancellation, force-stop the run, merely stop watching/delete retained state, start a fresh attempt, branch from old state, attach to an existing run, or only record something that happened before.

## New anti-collapse pressure from Revision 039
ViewFS should also keep one more seam explicit while deferred control and shell stop/retry UX are still fluid: **close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipts/history** should not collapse into one magical stop-or-rerun menu. That keeps the shell free to stop gracefully, kill forcefully, forget locally, or branch deliberately without letting those verbs silently mutate remote work, retained payloads, or current authority.


A twenty-fifth danger zone is collapsing read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable history into one vague connected session. Those classes answer different questions: did we only watch output or state, could we type into the existing session, did we send a control/update message, did we spawn a fresh debug command, did we open a temporary sideband access path, or are we only looking at a transcript of something that already ended?

## New anti-collapse pressure from Revision 040
ViewFS should also keep one more seam explicit while live-session shelling and helper interaction are still fluid: **read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable transcripts/history** should not collapse into one magical connected session. That keeps the shell free to watch, attach, control, debug, or tunnel without letting those verbs silently swap control rights, mutate remote state, or resurrect history as a live channel.


## New anti-collapse pressure from Revision 076
ViewFS should also keep one more seam explicit while type/opening UX is still fluid: **declared type hints, derived/computed type evidence, handler association sets, act-local chosen openers, live open/editor state, and durable receipts/history** should not collapse into one magical `open with` truth. That keeps the shell free to expose great preview/editor choices, disagreement cards, and open-state badges without letting file suffixes, old defaults, or stale receipts silently become present authority.


## New anti-collapse pressure from Revision 078
ViewFS should also keep one more seam explicit while query/follow/live-update UX is still fluid: **continuation cursors, sync watermarks, live subscriptions, rebuilt snapshots, gap/reset verdicts, and durable receipts/history** should not collapse into one magical `live query` helper. That keeps the shell free to follow, relist, rebuild, and explain drift honestly without letting provider tokens, last-seen markers, or old receipts masquerade as current authority or current state.

## New anti-collapse pressure from Revision 079
ViewFS should also keep one more seam explicit while editing/import-repair/external-tool round-trips are still fluid: **observed validators, private writable sessions, live write holds, exact commit preconditions, committed durable versions, and receipts/history** should not collapse into one magical save state. That keeps the shell free to stage locally, guard commits on exact basis material, surface hold state honestly, and show the winning durable version without letting draft-local close/flush folklore become present truth.

A twenty-seventh danger zone is collapsing partial local coverage, partition/layout metadata, whole-object completeness, exact whole-object proofs, live lazy/range-fill reachability, and durable history into one vague `downloaded object` story. Those classes answer different questions too: what bytes are here now, how the object is partitioned, whether the whole thing is present, whether one exact whole-object witness exists, whether missing bytes can be fetched right now, and what was only true before.

## New anti-collapse pressure from Revision 080
ViewFS should also keep one more seam explicit while sparse/lazy object handling is still fluid: **partial residency/coverage maps, chunk-layout knowledge, whole-object completeness verdicts, whole-object proofs, live range-fill sessions, and durable receipts/history** should not collapse into one magical hydration state. That keeps the shell free to show hole maps, lazy-fill reachability, whole-proof ladders, and offline honesty without letting sparse local bytes or composite per-part identifiers silently become full-local truth.


A twenty-eighth danger zone is collapsing delta recipes, exact basis requirements, current apply sessions, reconstructed target objects, fallback full-fetch lanes, and durable history into one vague `updated object` story. Those classes answer different questions too: what transform artifact is available, what exact prior bytes it depends on, what reconstruction is happening now, what target bytes were materialized, whether the system had to abandon delta apply and fetch the whole object, and what only happened before.

## New anti-collapse pressure from Revision 081
ViewFS should also keep one more seam explicit while efficient repair/update/import flows are still fluid: **delta recipes, exact basis requirements, current apply sessions, reconstructed target objects, fallback full-fetch lanes, and durable receipts/history** should not collapse into one magical update helper. That keeps the shell free to show basis cards, apply ladders, fallback honesty, and rebuilt-from lineage without letting patch artifacts, old basis ids, or old receipts silently become current object truth.

## New anti-collapse pressure from Revision 082

## New anti-collapse pressure from Revision 087
ViewFS should also keep one more seam explicit while import/localization/restore UX is still fluid: **provider-ready claims, reacquire or repair obligations, local realizations, current live handles, and durable receipts/history** should not collapse into one magical `available` bit.

A provider may honestly be able to supply something later without that thing existing locally now. A restored or remembered object may still owe one repair step before stronger claims become true. A local realized object may exist here without any process currently holding authority. Keeping those truths split gives the future shell room for make-local ladders, provider-owned badges, repair rails, and offline honesty without forcing one final object-store or fetch mechanism too early.

ViewFS should keep one more seam explicit while SlopOS launch/import/durable-handle posture is still settling: **activation carriers, live handle copies, issuer-visible badges or courier witnesses, immutable object refs, receiver-local binds, later revival designators, and durable receipts/history** should not collapse into one vague `open` story.

A startup slot, portal result, or local courier lane can explain where authority came from now without masquerading as durable path truth or future rediscovery. A badge can explain copy lineage without becoming immutable identity. A receipt can explain what happened before without reviving present authority. That keeps the object-store and shell/terminal design honest while leaving room for SlopOS to settle more of the surrounding runtime and portal machinery first.


## Discoverability and authority should not collapse
ViewFS should also keep one more seam explicit while the custom shell, query panes, and portal-mediated import story are still fluid: **direct current authority, exact-name reachability inside a held root/view, enumeration/listability, advisory suggestions or fit notes, and durable receipts/history** should not collapse into one fake explorer truth. That keeps the shell free to show rich candidates, indexes, helper suggestions, and import options without letting `it appeared in UI` masquerade as `it was openable now`.

## Revision 088: claim tickets, holder proof, and spent traces

ViewFS should now also keep a sharper split *inside* the broad family of authority-bearing artifacts.
A **claim ticket** that may redeem into stronger authority later is not the same thing as a **holder-bound grant** that only works for the current proving holder, which is still not the same thing as a **passable live handle** that may actually be copied or couriered now.
A **spent/expired ticket** is yet another truth again: it should stay visible as anti-replay history without looking reusable.

This is a good low-regret seam for SlopOS-era design work because current SlopOS material already leans hard toward provider-local PKCE/DPoP binding rather than portable bearer folklore, and Steward is now exploring compact consumable-grant and holder-bound-grant posture nearby.
ViewFS can therefore standardize the vocabulary and shell UX around redemption, passability, proof, and spentness now while leaving token format, proof method, CapStore persistence, and redemption ownership open.

## Revision 089: possession is not current invocability

ViewFS should now also keep a sharper split *inside* the broad family of current authority stories.
A thing may be **held here now** or **realized here now** and still not be **invokable here now** for the current action.
Freshness may be too old. Stronger authentication may still be required. Immediate local presence or user verification may still be required. A prior satisfaction may already be spent and should only survive as history.

This is a good low-regret seam for SlopOS-era design work because current SlopOS material already pins imported step-up-authentication semantics as provider-local reauthentication guidance rather than portable recent-login truth, and Harbor is separately exploring proximity and timebound continuation ideas nearby.
ViewFS can therefore standardize the vocabulary and shell UX around possession, recency, step-up, local presence, and current invocability now while leaving assurance taxonomy, proof carrier, and mediator ownership open.


## Revision 090: standing-watch good status is not the same thing as live possession

ViewFS should now also keep a sharper split *inside* the broad family of current-authority and current-invocability stories.
A thing may still be **held here now** or **realized here now** and still not be **in good standing here now** after later watch/status processing.
Later status material may say `inactive`, `suspended`, `refresh`, `unknown`, or `replacement available`.
A local receiver may narrow, quarantine, or defer on that basis without destroying the base object or base handle truth.

This is a good low-regret seam for SlopOS-era design work because current SlopOS material already keeps provider-local status, durable receipt/history, and local authority consequences on distinct seams, and Ward is separately exploring status carriers, suspension rails, refresh notices, attenuation events, and receiver stance nearby.
ViewFS can therefore standardize the vocabulary and shell UX around live possession, watch/status carriers, local holds, successor refresh, and post-watch invocability now while leaving transport, policy ownership, and successor-adoption mechanism open.


## Revision 091: sender-side share truth should not collapse

ViewFS should now also keep a sharper split *inside* the broad family of current-authority and transfer stories.
A thing may be **held here now** and still not be **duplicable here now**.
It may be duplicable locally and still not be **lendable live across this boundary now**.
It may fail live lend and still support one **weaker representation export** such as bytes, a projected document, or a claim artifact.
A receipt that any of those happened is another truth again.

This is a good low-regret seam for SlopOS-era design work because current SlopOS material already treats transfer portals, document lanes, clipboard/drag-drop mediation, and attenuation as explicit seams rather than ambient aftermath.
ViewFS can therefore standardize the vocabulary and shell UX around possession, local duplication, live lends, representation exports, and receipts now while leaving the final courier ABI, export taxonomy, and receiver-adoption model open.


## Route capsules, authority sidecars, sink bindings, and receipts
ViewFS should also keep one more shell/import seam explicit while SlopOS plumb, wallet, and document-transfer posture is still settling: **typed route capsule**, **optional authority sidecar**, **actual sink-side acceptance/bind/import**, and **durable receipt/history** should not collapse into one flattering `open` or `share` story.
A route capsule is allowed to be copyable, inspectable, and harmless precisely because it is not sink-held authority by itself.
A sidecar may narrow, explain, or accompany the route without being the same thing as a live capability container.
And the sink should remain free to accept only one representation, one projected bind, one live bind, one localized copy, or nothing at all.
This is a good low-regret seam for SlopOS-era design work because current SlopOS material already keeps CH-PLUMBMSG non-authoritative, CH-WALLET non-authoritative, portal requests request-local, and document/transfer grants explicit rather than ambient.

## Privilege brackets, borrowed authority, call-chain contexts, deny-only hints, and receipts
ViewFS should also keep one more helper/automation seam explicit while SlopOS privilege-bracketing and sibling helper/origin material are still settling: **privilege bracket**, **borrowed authority**, **call-chain context**, **deny-only routing hint**, and **durable receipt/history** should not collapse into one vague `helper used its powers` story.
A privilege bracket is bounded execution posture.
Borrowed authority is actual current capability.
Call-chain context is explanation.
A deny-only hint can veto or dim one route without becoming an allow path.
And a receipt should remember all of that later without reviving bracket state or caller-local context.
This is a good low-regret seam for SlopOS-era design work because current SlopOS material already leans toward explicit privilege bracketing and bounded non-authoritative call-chain descriptors instead of ambient helper folklore.

## Revision 100 pressure: namespace plans versus live room bindings

A room-oriented shell needs one more honesty seam above the raw layers:
- **namespace plans** and switch targets are reviewable preparation objects,
- **live room bindings** are current explicit namespace truth,
- **portal import/request sessions** are mediated in-flight state,
- **local overlays** are rebuildable room/device/activity-local convenience residue,
- **anchor/reset death state** explains when old continuity points stopped being exact,
- and **receipts/history** remain explanation rather than live authority.

That seam lets ViewFS stay ambitious about shell UX while remaining conservative about the final object-store and protocol decisions. See `docs/30-architecture/namespace-plans-live-room-bindings-import-sessions-and-local-overlays.md`.

## Revision 102 pressure: activation kits versus restart lockers versus namespace pins

The new pressure in this revision is to keep one more continuity seam honest.
A **startup-delivered activation kit**, a **manager-held restart locker**, a **namespace pin that keeps one view basis alive**, and a **current live room binding** should not collapse into one flattering `restored room` object.

Good current working language:
- **activation kit** = what exact ready handles/imports/slots this process received at startup
- **restart locker** = what exact live resources a manager is explicitly preserving for a controlled restart
- **namespace pin** = what exact object keeps one namespace/view basis alive even if no member process remains
- **live room binding** = what this room actually holds now
- **receipt/history** = what explains how a warm or cold restart happened before

Why this matters:
- systemd/launchd-style startup delivery is useful precisely because it is narrower than durable persistence;
- Linux namespace fd semantics are useful precisely because lifetime and current membership are different truths;
- shell UX gets dramatically more honest when it can say `warm exact`, `warm partial`, `cold repair`, or `cold fresh` instead of one vague `restored` badge.


## Revision 103 pressure: live room bindings versus currentness witnesses versus semantic epochs

The new pressure in this revision is to keep one more shell/import seam honest.
A **live room binding now**, one **currentness witness or revocation fence**, one **semantic epoch / hop scope** that says whether old observations still belong to the same semantic world, one **repair offer** surfaced to the user, and one **receipt/history** row should not collapse into one flattering `still valid` badge.

Good current working language:
- **live room binding** = what this room actually holds now
- **currentness witness** = what says whether that bind is still current, replaced, expired, revoked, or unknown
- **semantic epoch / hop scope** = what says whether one command block or anchor still belongs to the same shell world
- **repair offer** = one bounded reviewed next move such as refresh, revalidate, reconsent, rebind, make-local, or rerun-clean
- **receipt/history** = what explains which of those happened before

Why this matters:
- SlopOS already carries expiry/revocation/currentness hints on document/import seams and keeps descriptive wallets separate from live authority;
- XDG request/session/document seams are useful precisely because request lifetime, session lifetime, and resulting accessibility are different truths;
- Steward is already exploring semantic epochs, hop lineage, target anchors, and chrome lanes;
- shell UX gets dramatically more honest when it can say `provider current`, `provider unknown`, `older epoch`, `revalidate first`, or `receipt only` instead of one vague `available` state.


## Revision 104 pressure: renewal windows versus retry advice versus repair gates

A **live room binding now**, one **currentness witness or revocation fence**, one **renewal window** that can keep the same live claim alive, one **retry advice / not-before hint**, one **repair gate** that says automatic help should stop, and one **receipt/history** row should not collapse into one flattering `still working / try again later` badge.

Keep these distinct:
- **live room binding** = what this room actually holds now
- **currentness witness** = what says whether that bind is still current, replaced, expired, revoked, or unknown
- **renewal window** = what keeps the same live claim alive if refreshed in time
- **retry advice** = what says when the next exact follow-up is sensible
- **repair gate** = what says automatic help should cool down or require explicit clear/repair
- **receipt/history** = what explains what happened before without reviving it now

This split is strongly supported by the current source pressure:
- SlopOS already has explicit expiry/revocation and lease-shaped posture rather than one sticky `probably still alive` bit;
- Steward is already exploring renewal windows, retry advice, and repair gates as distinct shell/runtime truths;
- systemd keeps fdstore continuity, watchdog keepalives, and watchdog-triggered failure handling on different seams;
- HTTP keeps `Retry-After` as a small timing hint instead of pretending it is authority or repair completion.

That means ViewFS can be ambitious about visible renewal lamps, retry clocks, and repair-gate cards **without** freezing one final lease protocol, one final retry budget DSL, or one final auto-repair manager.

## Revision 105 pressure: visibility versus keep-warm presence versus restore intent versus deferred repair
SlopOS now gives ViewFS a second continuity warning that is adjacent to—but distinct from—renewal/retry posture: `background` and `autostart` are separate grant bits, request identity is not current grant state, and deferred jobs remain a separate lane from continuous background presence.

That strongly suggests ViewFS should keep **live room bindings**, **visibility/serving state**, **keep-warm/background-presence grants**, **restore/autostart intents**, **deferred repair jobs**, and **receipts** on different seams.

The external world points the same way:
- XDG Background separates `run in the background` from `start automatically when the user logs in`;
- Android distinguishes background limits from user-visible foreground services;
- Apple BackgroundTasks is a deferred-work lane rather than a promise of continuous live presence;
- Kubernetes Leases and EndpointSlice conditions show how much better lifecycle UX gets when `holder/renew`, `ready`, `serving`, and `terminating` are not one bit.

That means ViewFS can be ambitious about warmth rails, login lanterns, and defer drawers **without** freezing one final background lease model, one final restore carrier, or one final job substrate.

## Revision 106 pressure: attention cues versus interrupt grades versus quiet posture versus durable follow-up
SlopOS now gives ViewFS a second honesty warning adjacent to warm continuity: transient attention is not durable truth, urgent interruption is a separately governed class, and a request for attention is not proof that attention was received.

That strongly suggests ViewFS should keep **live room bindings**, **attention cues/adverts**, **interrupt grades**, **quiet/suppression posture**, **durable ack/follow-up rows**, and **receipts** on different seams.

The external world points the same way:
- XDG Notification lets apps send notifications but explicitly does not tell them whether presentation occurred;
- Android channels make interruption level explicit and user-controlled rather than payload-authoritative;
- Apple critical alerts treat stronger interruption as a separately entitled class;
- tmux distinguishes activity, bell, and silence and marks them differently in status chrome.

That means ViewFS can be ambitious about attention pips, interrupt ladders, quiet shutters, and ack ledgers **without** freezing one final inbox/history surface, one final interrupt-entitlement lane, or one final quiet-mode carrier.

## Revision 107 pressure: summon beacons versus activation batons versus foreground turns versus secure entry

SlopOS now gives ViewFS another honesty warning adjacent to attention chrome: host-owned display requests do not become a hidden focus/foreground authority plane, and trusted-entry remains a narrower secure-UI path rather than ordinary fullscreen or frontmost state.

That strongly suggests ViewFS should keep **live room bindings**, **summon/surface-me beacons**, **activation batons**, **actual foreground turns**, **secure-entry gates**, and **receipts** on different seams.

The external world points the same way:
- Wayland xdg-activation keeps activation tokens separate from compositor-decided activation results;
- Windows foreground APIs treat delegated foreground privilege as passable and expiring rather than as guaranteed frontmost control;
- xterm focus-in/focus-out events show that focus signals are useful shell chrome, but still weaker than activation or trusted-entry truth;
- Ghostty and WezTerm keep prompt-aware shell integration explicit enough that focus-aware chrome can be rich without pretending the terminal magically knows everything.

That means ViewFS can be ambitious about summon beacons, activation baton chips, front latches, and secure-entry shutters **without** freezing one final focus manager, one final summon schema, or one final trusted-entry carrier.


## Revision 108 pressure: observe mirrors versus automation leases versus synthetic input versus secure-entry exclusions
SlopOS now has enough explicit material around capability-mediated UI, accessibility/automation leases, trusted UI, and capability-safe shelling that ViewFS can sharpen one more seam without freezing the wrong layer.

That strongly suggests ViewFS should keep **live room bindings**, **observe/semantic mirrors**, **automation lease/session posture**, **actual synthetic-input lanes**, **secure-entry exclusion/redaction state**, and **receipts** on different seams.

The main lessons from the broader ecosystem line up with that split too:
- XDG InputCapture distinguishes `enabled` from `active`, which is exactly the right humility for request/session posture versus actual input delivery;
- XDG RemoteDesktop keeps session truth and the actual EIS input path visibly distinct;
- MediaProjection and screencast systems keep mirrors user-mediated instead of ambient;
- secure-surface controls such as Android `FLAG_SECURE` and Windows secure-desktop/UIAccess policy reinforce that sensitive entry can clamp capture/injection without rewriting the underlying room truth;
- Fuchsia accessibility posture shows that observation, focus truth, highlight state, and injection are powerful enough to deserve explicit trusted-manager seams.

That means ViewFS can be ambitious about mirror strips, rehearsal rails, automation lease chips, and secure-entry curtains **without** freezing one final automation substrate, one final UI mirror object, or one final trusted-entry policy store.


## Revision 109 pressure: selection owners versus transfer offers versus manager retentions versus paste capsules
SlopOS now gives ViewFS another honesty warning adjacent to mirror/automation work: typed transfer lanes, durable document handles, and prompt-local shell input are separate product truths, and clipboard-manager retention is a privileged helper lane rather than baseline room authority.

That strongly suggests ViewFS should keep **live room bindings**, **selection owners/current sources**, **transfer offers/representation racks**, **manager retentions/history ghosts**, **paste capsules**, **materialized imports/adopted binds**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Wayland selections are current owner/offer relationships rather than durable imported objects;
- data-control style clipboard management is a privileged helper role rather than an inherent property of the offer itself;
- XDG FileTransfer keeps transfer start, file registration, retrieval, and close/autostop on different seams;
- bracketed paste proves that prompt-local pasted input deserves its own truth;
- typed clipboard APIs such as the Clipboard API and kitty show that rich clipboard UX can remain permissioned and inspectable instead of magical.

That means ViewFS can be ambitious about offer cards, representation racks, paste capsules, history ghosts, and materialize ladders **without** freezing one final clipboard/history substrate, one final transfer-offer schema, or one final object-store family for transfer residue versus imported local objects.

## Revision 110 pressure: projection sites versus room publication versus localization
SlopOS now gives ViewFS another honesty warning adjacent to transfer/import work: a scoped provider or portal view, a room-local publication site, and a later local realization are different truths even when the user keeps seeing `the same file`.

That strongly suggests ViewFS should keep **live room bindings**, **provider-backed projection sites**, **published room aliases**, **localization/materialization posture**, and **receipts** on different seams.

The broader ecosystem points the same way:
- XDG Documents exposes exported files through a restricted synthetic FUSE tree rather than broad native publication;
- Android SAF keeps a hierarchical document model while allowing the provider to store data however it likes;
- Fuchsia consumes namespace entries and separately publishes outgoing capabilities;
- Cloud Files / file-provider systems keep placeholder, hydrated, and local-policy posture explicit.

That means ViewFS can be ambitious about site ledgers, provider halos, bind-here ladders, and multi-site diffs **without** freezing one final projection substrate, one final publication ledger, or one final localization contract.

## Revision 111 pressure: projected bases versus local uppers versus merged presentation versus publish result
SlopOS now gives ViewFS another honesty warning adjacent to projection/publication/localization work: its roadmap explicitly wants view objects cheap to clone and overlay, but that still does **not** tell us to flatten `base`, `local shadow`, `merged view`, and `publish result` into one object-store class.

That strongly suggests ViewFS should keep **live room bindings**, **projected base stacks**, **local upper overlays**, **merged room presentations**, **publish/commit/adopt results**, and **receipts** on different seams.

The broader ecosystem points the same way:
- OverlayFS keeps lower, upper, workdir, merged traversal, whiteouts, and opaque-directory behavior on distinct truths;
- Plan 9 union directories keep ordering and creation-target rules explicit;
- Kubernetes projected volumes merge several sources into one directory without pretending the sources became one local object;
- Apple File Provider keeps placeholder, actual file materialization, and later eviction distinct;
- Nix treats realization as an explicit fetch/build act rather than a flattering side effect of traversal.

That means ViewFS can be ambitious about stack badges, whiteout ghosts, merge rails, and commit ladders **without** freezing one final overlay substrate, one final hide-marker schema, or one final publish-back contract.

## Revision 115 pressure: caller request contexts versus detached roots versus deadline and cancellation truth
SlopOS now gives ViewFS another honesty warning adjacent to accepted/completed work: caller-bound request context, detached continuation, deadline intent, cancellation state, and later provider follow-up are different truths even when the user experiences them as `one thing still happening`.

That strongly suggests ViewFS should keep **live room bindings**, **caller request contexts**, **detached roots**, **deadline intents**, **current cancellation state**, **provider operation tickets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Go `context` makes cancellation/deadline propagation real structure and warns that forgetting `CancelFunc` leaks children;
- Go `WithoutCancel` shows that `continue after caller is gone` is not just an ordinary derived child;
- gRPC deadlines make the caller's patience budget explicit and ask servers to stop spawned work when cancellation arrives;
- Kotlin cancellation is cooperative and `NonCancellable` is deliberately limited because it can sever parent-child relations if widened carelessly;
- Temporal uses a disconnected context specifically so cleanup can continue after cancellation;
- Cap'n Proto keeps cancellation as explicit RPC logistics on call context rather than ambient task folklore.

That means ViewFS can be ambitious about cutoff lamps, detach-root cards, continue-without-me ladders, and cancellation braids **without** freezing one universal request-context schema, one universal detach ticket, or one final background-execution substrate.

Another danger zone is collapsing `may do this`, `this sponsor would pay`, `budget is reserved`, `provider actually charged someone`, and `history remembers a prior spend` into one flattering success story. Access control, sponsorship, resource ceilings, budget reservations, and charge verdicts have different failure modes and should stay visibly separate.

Another danger zone is collapsing `this object/work item is home here`, `this tool is currently attached`, `this capability arrived later by import`, `this name is published in this view`, `this object is retained by an explicit root`, and `history remembers prior placement` into one flattering workspace myth. Sandstorm grains, Fuchsia namespaces, and Nix GC roots all pressure ViewFS in the same direction: object-home rooms, tool attachment, imported binds, published names, retention roots, and receipts/history should stay visibly separate while SlopOS is still deciding more of its own datacube substrate.

Another danger zone is collapsing `this is the object`, `this is the facet I currently hold`, `this grouped kit arrived for launch/import`, `this facet is bound in this room right now`, and `this name publishes one current view of it` into one flattering handle story. Current SlopOS handle-table and capability-semantics work, Sandstorm's typed Powerbox requests, Fuchsia's resource+rights capabilities and dictionary grouping, Capsicum's monotonic rights reduction, and CHERIoT's opaque sealing all point the same way: ViewFS should be free to surface inspect/edit/publish/automation facets and explicit kits **without** deciding that every object family shares one universal facet taxonomy or one final handle wire format.


Another danger zone is collapsing `descriptor/proof only`, `verify-only`, `read now`, `edit/publish now`, `bound in this room`, and `history remembers a past handle` into one flattering object row. Current SlopOS wallet/docref/lease posture, Tahoe-LAFS capability flavors, Linux `O_PATH`, and CHERIoT sealing all point the same way: ViewFS should be free to surface safe descriptor cards, verify chips, and stronger live read/edit/publish rails **without** deciding that every object family shares one universal verification facet, one universal opaque-token format, or one final proof-carrier ABI.


Another danger zone is collapsing `query says granted`, `descriptor says this was issued`, `a restore token exists`, `authority is bound here now`, and `history remembers prior continuity` into one flattering continuity myth. Current SlopOS lease-descriptor state posture, W3C Permissions and File System Access, Android persisted URI permissions, and XDG portal request/session/restore-token flows all point the same way: ViewFS should be free to surface grant gauges, issued-bounds cards, restore beads, live-now rails, and reason-rich death cards **without** deciding that every object family shares one universal status API, one universal restore token family, or one final death-verdict carrier.

Another danger zone is collapsing `the semantic object we mean`, `one exact byte proof`, `one chunk/codec/reference-sensitive structured address`, `one local name or locator`, `one current live facet`, and `history remembers one prior import` into one flattering `object id` story. OCI descriptors, RFC 6920 `ni:` names, IPFS CIDs, Nix content-addressed store objects, and the current SlopOS artifact/docref/capstore posture all point the same way: ViewFS should be free to surface object-core badges, exact-byte proofs, shape-hash drawers, name-only ghosts, and live facet rails **without** deciding that one universal hash or one universal semantic-id family must do every job at once.

Another danger zone is collapsing `the semantic object`, `the name that currently points at it`, `the latest head token`, `the conflict/order scope`, `the row that says one head superseded another`, and `the facet that is actually live now` into one flattering `versioned handle` story. Kubernetes object names/UIDs/resourceVersions, etcd revision metadata, S3 version IDs/delete markers, Git refs/reflogs, and current SlopOS ordering-token posture all point the same way: ViewFS should keep object cores, designations, revision tokens, order scopes, supersession rows, live facets, and receipts visibly distinct while the object store is still in design.

Another danger zone is collapsing `the semantic record we reviewed`, `the canonical payload bytes one digest/signature profile cares about`, `the signed wrapper that authenticates payload type`, `the concrete wire/export/log copy`, and `the facet that is actually live now` into one flattering `signed object` story. JCS canonicalization, deterministic-CBOR guidance, COSE detached payload rules, in-toto envelope layering, and current SlopOS wallet/encoding posture all point the same way: ViewFS should keep semantic records, canonical payloads, signed wrappers, wire copies, live facets, and receipts visibly distinct while the object store is still in design.

Another danger zone is collapsing `the fresh logical object we just created`, `the shared blocks or snapshot-origin backing underneath`, `the copy/clone lineage`, and `the facet that is actually live now` into one flattering `cheap copy` story. Linux reflink, Btrfs reflink, OpenZFS clone concepts, APFS clones, and current SlopOS fresh-identity / explicit-lineage posture all point the same way: ViewFS should keep fresh object identities, shared backing, copy lineage, live facets, and receipts visibly distinct while the object store is still in design.

## Revision 128 pressure: upload sessions versus part coverage versus completion manifests versus committed objects
SlopOS now gives ViewFS another honesty warning adjacent to D-PERSIST, CapStore, artifact references, fresh-identity imports, and explicit jobs posture: one upload/resume session, one part/offset progress row, one completion manifest, one committed durable object, one abort/expiry verdict, and one current live facet are different truths even when the user experiences them as `the file is uploading`.

That strongly suggests ViewFS should keep **upload sessions**, **part coverage**, **completion manifests**, **committed objects**, **abort verdicts**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Amazon S3 multipart upload keeps upload IDs, part uploads, complete-with-part-list, and abort separate;
- tus keeps resumable URLs and offsets explicit rather than pretending they are final object truth;
- OCI Distribution keeps chunked blob upload in three phases: obtain session URL, upload chunks, close session;
- Google Cloud Storage keeps resumable session URIs explicit, expiring, and security-sensitive instead of calling them object identity.

That means ViewFS can be ambitious about session beads, part gauges, seal ladders, abort ash, and live rails **without** freezing one universal upload protocol, one universal completion-manifest schema, or one final cleanup model.

Another danger zone is collapsing `session open`, `parts uploaded`, `assembly list ready`, `committed object exists`, `session aborted`, and `current live facet` into one flattering `uploading object` story. Amazon S3 multipart upload, tus, OCI Distribution, Google Cloud Storage resumable sessions, and current SlopOS persistence/import/jobs posture all point the same way: ViewFS should keep upload sessions, part coverage, completion manifests, committed objects, abort verdicts, live facets, and receipts visibly distinct while the object store is still in design.


## Revision 129 pressure: assembly recipes versus member descriptors versus aggregate objects versus realized work surfaces
SlopOS now gives ViewFS another honesty warning adjacent to component manifests, activation sets, persistent object-store posture, CapStore roots, and artifact references: one assembly recipe, one exact member-descriptor set, one durable aggregate object, one realized work surface, one current live facet, and one history row are different truths even when the user experiences them as `one assembled object`.

That strongly suggests ViewFS should keep **assembly recipes**, **member descriptors**, **aggregate objects**, **realized work surfaces**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Google Cloud Storage compose creates a new composite object from existing members while the sources remain unaffected;
- OCI manifests and image indexes keep descriptor graphs explicit instead of flattening them into later runtime reality;
- `git write-tree` builds one tree object from explicit staged membership rather than ambient directory walking;
- containerd keeps pulled content, unpacked snapshots, containers, and live tasks on different layers.

That means ViewFS can be ambitious about recipe cards, member rails, aggregate seals, unpack lamps, and live rails **without** freezing one universal bundle ABI, one universal recipe language, or one final materialize/unpack contract.

Another danger zone is collapsing `the recipe we reviewed`, `the exact members referenced`, `the durable aggregate object that got sealed`, `the unpacked or hydrated work surface`, and `the facet that is actually live now` into one flattering `assembled object` story. Google Cloud Storage composite objects, OCI manifests/indexes, `git write-tree`, containerd pull/unpack, and current SlopOS composition/persistence posture all point the same way: ViewFS should keep assembly recipes, member descriptors, aggregate objects, realized work surfaces, live facets, and receipts visibly distinct while the object store is still in design.


## Revision 130: transient staging capsules versus seal states versus courier handoffs
ViewFS should now also keep a sharper split *inside* the broad family of local drafting, helper-edit, import, and commit stories.
A thing may exist as a **transient exact-byte staging capsule** and still not be a **durable committed object**.
It may be **sealed for review** and still not be **published** or **reopenable later**.
It may be **couriered locally** to another process and still not be a published name or a durable import.
A history row about any of those is another truth again.

This is a good low-regret seam for SlopOS-era design work because current SlopOS material already keeps explicit materialization, fresh local identity, artifact identity, and durable CapStore commit meaning on different seams, while Linux staging primitives keep showing that exact bytes, freeze posture, local handoff, and durable publication are different classes.
ViewFS can therefore standardize the vocabulary and shell UX around capsule cards, seal shutters, courier rails, commit lamps, and live rails now while leaving the final staging primitive, handoff carrier, and commit ABI open.

## Revision 131 pressure: committed objects versus retention clocks versus hold states versus purge verdicts
SlopOS still does not settle a final retention/immutability family, and that is exactly why ViewFS should protect the seam now: one durable object, one keep-until rule, one separate hold, one later purge answer, and one current live facet are different truths even when the user experiences them as `this thing is protected`.

That strongly suggests ViewFS should keep **committed objects**, **retention clocks**, **hold states**, **purge verdicts**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Amazon S3 Object Lock keeps retention periods and legal holds separate, both on object versions;
- Google Cloud Storage keeps temporary holds, event-based holds, retain-until posture, lifecycle deletion, and editable metadata on different seams;
- Azure immutable storage keeps legal hold scope, tags/audit logs, and WORM posture separate from ordinary blob existence.

That means ViewFS can be ambitious about hold badges, retention rails, purge lamps, and delete-now rails **without** freezing one universal retention taxonomy, one universal WORM policy carrier, or one final purge subsystem.

## Revision 132 pressure: sealed objects versus recipient wraps versus rewrap plans versus unwrap handles
SlopOS now gives ViewFS another honesty warning adjacent to cryptosvc, vault, wallet, and auth-proof-export posture: one sealed object, one recipient-wrap roster, one rewrap or key-rotation act, one provider-bound unwrap handle, one current clear facet, and one history row are different truths even when the user experiences them as `the encrypted thing`.

That strongly suggests ViewFS should keep **sealed objects**, **recipient wraps**, **rewrap plans/receipts**, **unwrap handles**, **clear facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- JWE keeps shared ciphertext separate from per-recipient `encrypted_key` rows;
- WebCrypto keeps opaque key references and `wrapKey` / `unwrapKey` operations explicit;
- Cloud KMS envelope encryption keeps encrypted data separate from wrapped DEKs;
- Cloud KMS re-encryption guidance keeps key rotation separate from actual re-encryption of stored data.

That means ViewFS can be ambitious about seal badges, wrap rosters, rewrap ladders, unwrap rails, and clear rails **without** freezing one universal envelope format, one universal key-handle ABI, or one final encrypted-object transport.



## Revision 133 pressure: committed objects versus durability profiles versus redundancy layouts versus repair verdicts
SlopOS now gives ViewFS another honesty warning adjacent to artifact references, CapStore commits, and the still-unsettled datacube substrate: one committed object, one intended durability profile, one concrete share/replica layout, one current repair verdict, one current availability answer, one live facet, and one history row are different truths even when the user experiences them as `the stored object`.

That strongly suggests ViewFS should keep **committed objects**, **durability profiles**, **redundancy layouts**, **repair verdicts**, **availability states**, **live facets**, and **receipts** on different seams.

The broader ecosystem points the same way:
- Ceph keeps logical object identity separate from current placement and rebalancing through placement-group indirection;
- Ceph scrubbing and peering keep repair/integrity truth separate from object birth or deletion;
- Tahoe-LAFS keeps k-of-n share encoding and recoverability thresholds separate from filecap/access-control questions;
- Amazon S3 keeps asynchronous replication posture explicit through replication-status rows instead of pretending extra copies are already settled just because the object exists.

That means ViewFS can be ambitious about durability badges, layout ghosts, repair ladders, availability lamps, and live rails **without** freezing one storage engine, one provider exposure level for redundancy layout, or one final repair-verdict protocol.

Another danger zone is collapsing `committed object exists`, `durability target says replica-3 or k-of-n`, `current layout actually matches some placement/share story`, `repair is healthy or degraded`, `availability is retrievable or not`, and `one live read/edit facet is bound here now` into one flattering `healthy stored object` myth. Ceph placement and scrubbing, Tahoe-LAFS share thresholds, Amazon S3 replication status, and current SlopOS artifact/CapStore posture all point the same way: ViewFS should keep committed objects, durability profiles, redundancy layouts, repair verdicts, availability states, live facets, and receipts visibly distinct while the object store is still in design.

Another danger zone is collapsing `committed object exists at origin`, `access change is still propagating`, `public cache may still serve stale`, `cache trail says hit/miss/forward`, and `one live read facet is bound here now` into one flattering `published latest object` myth. Amazon S3 strong consistency, Google Cloud Storage's split between strong object truth and eventual access/cache behavior, and HTTP cache/Cache-Status standards all point the same way: ViewFS should keep committed objects, access propagation, public cache copies, cache trails, live facets, and receipts visibly distinct while publication and portal-mediated import/export are still in design.


## New anti-collapse pressure from Revision 137
ViewFS should also keep one more object-store seam explicit while SlopOS namespace/import posture is still fluid: **committed objects, prefix projections, provider folder resources, listing snapshots, published names, live facets, and receipts/history** should not collapse into one magical `folder entry` story. Flat object stores, later-added managed folders, and room-local binds are different layers. That keeps the shell free to present folder-like views without deciding that the storage core is path-native. See `docs/30-architecture/committed-objects-prefix-projections-folder-resources-listing-snapshots-published-names-live-facets-and-receipts.md`.

## Revision 138 pressure: launch view plans versus bound roots versus handle slots versus portal import tickets

SlopOS now gives ViewFS another honesty warning directly adjacent to the future object store, capability handles, explicit per-process namespaces, and portal-mediated imports: one reviewed launch plan, one actual bound root, one exact handle-slot table, one portal import ticket, one adopted live bind/facet, and one history row are different truths even when the user experiences them as `the thing this helper can see`.

That strongly suggests ViewFS should keep **launch view plans**, **bound roots/namespaces**, **handle slot tables**, **portal import tickets**, **live binds/facets**, and **receipts/history** on different seams.

The broader ecosystem points the same way:
- Fuchsia keeps per-component namespaces and routed capabilities explicit instead of assuming one process-global root;
- Capsicum and WASI push authority into descriptors/preopens/resources rather than ambient path lookup;
- XDG Documents keeps portal/document-store permissions separate enough to grant, revoke, inspect, and delete store entries without treating host paths as the grant;
- Tahoe-LAFS and Cap'n Proto show the power of capability flavors and capability tables without requiring ViewFS to pick one universal cap string now;
- EROS warns that persistent capabilities make authority-graph persistence a deep system problem, not a serialization afterthought;
- GCS/Azure/etcd precondition patterns keep currentness witnesses explicit before mutation.

That means ViewFS can be ambitious about slot maps, root badges, import-ticket trays, adoption ladders, and live-bind rails **without** freezing one universal object handle ABI, one final namespace description language, one final portal-session persistence model, or one final datacube pack/GC design.

Another danger zone is collapsing `what we meant to launch`, `what root was actually bound`, `which handles were delivered`, `what a portal has merely mediated`, `what is live here now`, and `what a receipt records` into one flattering `file opened in the process` story. Current SlopOS capshell/portal posture, Fuchsia namespaces, Capsicum/WASI capability launch patterns, XDG Documents, Tahoe-LAFS, Cap'n Proto, EROS, and object-store precondition discipline all point the same way: ViewFS should keep launch view plans, bound roots, handle slots, portal import tickets, live binds, and receipts visibly distinct while SlopOS and the datacube are still in design.

## Revision 139 pressure: handle inventory versus custody versus outflow versus flow evidence

Revision 139 adds a second-stage authority-flow guardrail after the Revision 138 launch/import split. ViewFS should not let a current handle table, custody explanation, export/outflow policy, redacted capability-flow snapshot, leak verdict, live export/proxy/borrow, and durable receipt collapse into one artifact.

The architecture implication is deliberately conservative:

- a handle inventory says what a subject can exercise now;
- custody explains how that handle arrived;
- an outflow gate says how the handle may leave;
- a flow snapshot/diff explains a bounded redacted state or delta;
- a leak verdict reports an analyzer/test result;
- a live export/proxy/borrow is present authority in another subject;
- a receipt is history and not power.

This keeps SlopOS-style capability graph and diff ideas usable for debugging, consent, receipts, and tests without turning them into serialized authority or a premature object-store ABI.


## Revision 140 pressure: durable roots versus restore and activation

Revision 140 adds a persistence guardrail directly adjacent to the future object store and capability-handle design. ViewFS should not let a durable root commit, epoch/currentness fence, restore intent, resurrection gate, activation target, current live bind/handle set, and receipt collapse into one saved-state object.

That means:

- a durable root commit records stored facts;
- an epoch fence/root-tip witness decides whether the candidate is admissible and not an unsafe rollback;
- a restore intent asks to inspect, resume, repair, roll back, or activate;
- a resurrection gate decides whether dormant refs/portal anchors/sturdyrefs/keyrefs may become live;
- an activation target chooses what should become current for a boot, room, workspace, process, or view;
- a live bind/handle set is the actual present authority;
- a receipt is history and not power.

This keeps SlopOS CapStore inspiration useful without accidentally serializing a live authority graph or making old durable rows magically reopen authority. See `docs/30-architecture/durable-root-commits-epoch-fences-restore-intents-activation-targets-live-binds-and-receipts.md`.

## Revision 141 pressure: reachability roots versus live handles versus collection

Revision 141 adds an object-store liveness guardrail directly after the durable-root/activation work. ViewFS should not let a durable reachability root, runtime live-handle root, pin/hold/lease record, sweep candidate, deletion finalizer, collected ash/tombstone, current live facet, and receipt collapse into one vague `object exists` state.

That means:

- a reachability root keeps stored material alive;
- a live-handle root protects current work while authority is held;
- a pin/hold/lease records who asked for retention or no-destroy and under what bounds;
- a sweep candidate is staleable analysis, not deletion;
- a finalizer blocks final removal until cleanup obligations settle;
- collected ash/tombstones record absence or anti-resurrection facts;
- a live facet is present authority;
- a receipt is history and not retention unless explicitly rooted.

This keeps SlopOS CapStore/lease inspiration useful without turning every receipt, index row, cache hit, preview, namespace listing, or old portal anchor into an accidental GC root. See `docs/30-architecture/reachability-roots-live-handle-roots-pin-holds-leases-sweep-candidates-finalizers-collected-ash-live-facets-and-receipts.md`.

## Revision 142 pressure: origin, quarantine, safe-open, residue, derived artifacts, trust, and live opens

Revision 142 adds an anti-laundering guardrail adjacent to portal imports and the future object store. ViewFS should not let origin evidence, quarantine marks, safe-open capsules, viewer residue, derived artifacts, trust clearances, current live opens, and receipts collapse into one vague `safe file` state.

That means:

- origin evidence explains arrival and lineage but does not grant trust or authority;
- a quarantine mark is a current object-local handling constraint;
- a safe-open capsule is a stable request-local materialization, not a write-through alias and not a clearance;
- viewer residue and semantic extraction need explicit containment/export stories;
- derived or sanitized artifacts get fresh identity, parent evidence, and their own handling state;
- a trust clearance is narrow and scoped;
- current live open/execution authority is the present power;
- receipts explain history without reopening or clearing anything by themselves.

This keeps SlopOS D-QUAR/open-untrusted posture useful while ViewFS still avoids choosing a final malware scanner, notarization verifier, content-index, sanitizer, or quarantine-schema ABI. See `docs/30-architecture/origin-evidence-quarantine-marks-safe-open-capsules-viewer-residue-derived-artifacts-trust-clearances-live-opens-and-receipts.md`.

## Revision 143 pressure: container envelopes versus member claims versus extraction and publication

Revision 143 adds a guardrail where old filesystem vulnerabilities most want to re-enter the design. ViewFS should not let one archive/container envelope, one internal member claim, one extraction plan, one sterile materialization root, one extracted member capsule, one namespace commit/adoption, one current live open, and one receipt collapse into one `unpacked files` story.

That means:

- a container envelope is the aggregate object and its origin/format evidence;
- a member claim is untrusted internal metadata, including name/type/link/permission/xattr/whiteout assertions;
- an extraction plan is the reviewed policy-filtered map from claims to admitted/denied/rewritten actions;
- a sterile root is where materialization happens before publication;
- an extracted member capsule is a fresh local object/projection with lineage and quarantine;
- a namespace commit is a separate ViewFS mutation with currentness/conflict witnesses;
- a live open/mount is present authority;
- a receipt is history and not power.

This keeps safe extraction useful without letting raw member paths, symlink targets, hardlinks, device entries, whiteouts, or old receipts become namespace authority. See `docs/30-architecture/container-envelopes-member-claims-extraction-plans-materialization-roots-namespace-commits-live-opens-and-receipts.md`.

## Revision 145 pressure: secret descriptors versus delivery slots versus live-use handles

Revision 145 adds a runtime secret/credential guardrail directly adjacent to launch, portal import, helper activation, supply-chain admission, and object-store residue. ViewFS should not let a secret descriptor, acquisition prompt, delivery slot/projection, environment shadow, redaction lens, renewal/rotation lease, live-use handle, residue marker, and receipt collapse into one `secret available` state.

That means:

- a secret descriptor is redaction-safe metadata about purpose, scope, audience, provider family, and epoch;
- an acquisition prompt or consent act may unlock/issue material but is not reusable material itself;
- a delivery slot/projection is the current local lane into a subject;
- an environment shadow is a compatibility string carrier and must be marked as leaky;
- a redaction lens hides displays/logs/search but is not a confidentiality boundary;
- a renewal or rotation lease is scoped reacquisition authority/evidence, not the current token/key/seed;
- a live-use handle is the actual present secret-bearing authority;
- residue markers track copies/effects that may outlive the slot;
- a receipt is history and not power.

This keeps SlopOS D-APPSECRET, capshell env/credential, vault/cryptosvc, and auth-export inspiration useful without deciding one vault, keychain, token broker, env-projection rule, or terminal redaction ABI. See `docs/30-architecture/secret-descriptors-acquisition-prompts-delivery-slots-environment-shadows-redaction-lenses-renewal-leases-live-use-handles-and-receipts.md`.

## Revision 146 pressure: delegation and revocation are not one bit

Revision 146 adds a delegation/revocation guardrail next to the handle-slot, flow-map, durable-root, GC, quarantine, extraction, supply-chain, and secret-delivery seams. ViewFS should not let a delegation intent, attenuation envelope, membrane lease, delegated handle, revocation request, wavefront checkpoint, stale-handle brake, renewal/redelegation control, current live authority, and receipt collapse into one `shared` or `revoked` state.

The minimum split:

- a delegation intent says what someone wants to lend/share/export;
- an attenuation envelope says what bounds were declared;
- a membrane lease/proxy is one possible live enforcement surface;
- a delegated handle/imported stub is the recipient's current usable reference;
- a revocation request is an act, not a global fact;
- a revocation wavefront says which observers have seen the epoch/close/revoke;
- a stale-handle brake gives an exact reason for denial;
- renewal and redelegation controls are separate authority;
- a receipt explains without reviving.

This preserves room for SlopOS D-LEASE, D-CAPX, CH-CAPLEASE, CH-SREF, RFC-0019 epochs/indirection, and auth-revocation boundaries without choosing ViewFS's final derivation-tree, token, broker, membrane, or distributed-object model. See `docs/30-architecture/delegation-intents-attenuation-envelopes-membrane-leases-revocation-wavefronts-stale-brakes-live-authority-and-receipts.md`.

## Revision 147: inspection lenses, process-view snapshots, fd peeks, trace fuses, dump guards, and receipts

Revision 147 adds a diagnostics seam for the future object store and capability-handle runtime: **inspection intent**, **target locator**, **namespace/process-view snapshot**, **handle/fd/slot peek**, **memory/core/crash capture**, **trace probe/stream/processor**, **debug-control lane**, **redaction/export policy cut**, **current live inspection authority**, and **inspection receipt/history** are separate.

The low-regret rule is that diagnostics are authority. A snapshot of a process's roots is not a live namespace. A handle inventory row is not a copied handle. A trace stream is not complete state and not a debugger. A core dump is a risky object, not log text. Redaction is not containment. A support-bundle receipt is not future authority.

This matters because ViewFS wants explicit per-process namespace assembly and shell-visible handle slots. The shell will need excellent `why?` surfaces, but those surfaces must not recreate ambient host process folklore: raw `/proc` walks, fd symlink peeks, same-user debug attach, core dumps, or trace streams should not become ordinary ViewFS open/read powers by accident.

Useful prior-art pressure:

- Linux `ptrace` collapses observation and control unless carefully gated.
- Linux procfs, `hidepid`, ptrace access checks, `PR_SET_DUMPABLE`, and `coredump_filter` show that process metadata, fd tables, memory, and crash captures need explicit policy.
- Fuchsia Inspect shows the value of structured runtime diagnostics.
- ETW separates controllers, providers, consumers, and lost-event accounting.
- DTrace separates privileges and destructive-action enablement.
- Kubernetes RBAC subresources keep logs/exec/attach-like APIs separately authorizable.
- macOS privacy gates make observation/control categories user-visible.
- SlopOS already has CH-INSPECT, observation export policy, trace descriptors/processors, capshell peer-inspection posture, and microvm debug-introspection non-portability. ViewFS should steal those seams, not prematurely freeze the final ABI.

## Revision 148 pressure: networking must not become the hidden escape hatch

ViewFS should now keep one more seam explicit while the object store, capability handles, portal imports, and launch namespace model are still fluid: **network intent, destination designator, resolution witness, network admission cut / lease descriptor, current live network authority, stream state, local exposure, egress/import materialization cut, and durable receipt/history** should not collapse into one fuzzy `network allowed` bit.

This is especially important because a process with no file root can still exfiltrate selected bytes if it inherits sockets, resolver state, proxy environment, browser local-network bridges, package-update fetchers, or background upload lanes. Conversely, a fetched byte stream is not trusted import material until origin/quarantine, extraction, supply-chain, object-core, and local admission seams have done their work.

Revision 148 therefore adds the network seam as a guardrail, not a final networking ABI. A URL is not authority. A DNS answer is not a capability. Public internet reach is not local-network or loopback reach. Connect is not listen. Listen is not advertise. Fetch is not trust. Send is not just a socket. A receipt cannot reconnect.
## Revision 149 pressure: service discovery is not service authority

Revision 149 adds the next networking-adjacent guardrail: **service intent, service designator, discovery/catalog authority, discovery snapshot/candidate set, readiness/health/identity evidence, binding cut, activation target, current live service authority, advertisement/publication, and receipt/history** are different classes.

This matters because ViewFS can have a perfectly explicit object namespace and still lose the plot if every process also inherits a global service directory. A string like `printer`, `_ipp._tcp.local`, `db`, `vault`, `indexer`, or `support-upload` is a designator. A catalog row, DNS-SD instance, EndpointSlice endpoint, xDS resource, DID service entry, MCP tool row, or shell suggestion is a candidate. A readiness lamp, health check, identity match, route warmup, or old successful call is evidence. None of those are the live service handle.

The low-regret decision is to make service binding a visible bridge: designator -> catalog root -> snapshot row -> evidence -> local binding cut -> activation target -> live handle slot -> receipt. The exact substrate can remain open: local IPC, object-capability RPC, portal sessions, network streams, socket activation, SlopOS D-NETLEASE, or a future ViewFS service family.

Guardrail: **a service name is not authority, discovery is disclosure, readiness is not trust, binding is not activation, identity is not permission, advertisement is not listen, and a receipt cannot invoke.**


## Revision 152 semantic-derivation note

Semantic search, OCR, thumbnails, embeddings, summaries, smart folders, and answer cards are valuable only if they do not become a hidden second filesystem. ViewFS should therefore keep semantic extraction intents, source snapshots/input capsules, extractor/model profiles, derived artifacts, index/store membership, query scopes/access gates, result projections, answer/suggestion cards, current live authority, and receipts distinct.

The practical rule is: **found is not opened, embedded is not safe, summarized is not cleared, answer-cited is not source authority, and indexed is not a grant.**


## Revision 153 instruction-hygiene note

Semantic search and agentic helpers need an explicit instruction plane. A ViewFS object store should never let retrieved text, workspace instructions, tool descriptions, tool results, model output, or old prompt receipts bypass typed plans, approval cuts, and live-handle checks.

The new companion docs keep source-labeled instruction material, context exposure, proposal text, compiled actions, toolcall candidates, approvals, current live authority, result observations, and receipts separate. This is deliberately narrower than a final AI runtime: it is an anti-collapse rule for future prototypes.

## Revision 154 pressure: consent is not a button, focus state, prompt reply, or receipt

Instruction hygiene makes agentic ViewFS plausible, but it also sharpens the next danger: a shell can accidentally make UI gestures look like capability grants. Revision 154 therefore adds a consent hygiene seam: **consent candidates, canonical summaries, presentation surfaces, trusted-path posture, gesture evidence, volition tokens, approval cuts, live authority, outcomes, and receipts** should remain different truths.

This lets ViewFS borrow from EROS user-volition traceability, HTML user-activation nuance, Wayland activation tokens, Windows trusted-path login, WebAuthn user-presence/user-verification ceremonies, OWASP clickjacking defenses, and SlopOS D-VOLITION without prematurely choosing one final UI root, token format, or consent ceremony.

The stable claim is narrow: a click can request, a gesture can witness, a token can bind, a mediator can approve, a live handle can act, and a receipt can explain. None of those is a synonym for the others.

## Revision 156 pressure: lifecycle seams must become checked lanes

Revision 155 made receipts, digests, pathwalks, semantic answer cards, consent chains, and portal binds executable. Revision 156 extends that discipline to the first deferred hard decisions: handle attenuation, mutable work, revocation, retention, prompt/tool invocation, and portal replay.

The stable pressure is narrow:

- a narrowed handle cannot widen rights;
- a journal is not committed object identity;
- a commit cut over a stale observed base must deny;
- a restore token under a death verdict cannot reacquire authority;
- a revoked handle remains inspectable but inert;
- a receipt is history, not a retention root;
- an explicit retention root is different from derived/index residue;
- prompt text and model proposals are not effectful tool invocations;
- an accepted portal grant is different from a spent/replayed grant;
- proof obligations must point to specimens or admit that they are non-fixture evidence.

The practical result is that ViewFS's architecture now has a small lifecycle-honest authority graph. Richer distributed revocation, mutable directory transactions, agent runtimes, and shell cards are still open, but they should inherit these denial cases rather than weakening them.

## Revision 157 executable-hardening note

Revision 157 extends the v0 fixture spine into adversarial conformance territory. The architecture now treats resolver witnesses, delegation ledgers, shell-card badges, and copy inventories as explicit records because each is a known route for authority laundering.

New records and docs:

- `PathNode` and `docs/30-architecture/resolver-conformance-v0.md` keep symlink, magic/synthetic, mount/provider, escape, missing-bind, and missing-right outcomes distinct.
- `Delegation` and `docs/30-architecture/delegation-chain-and-shell-card-honesty-v0.md` keep delegation intent, source handle, child handle, attenuation envelope, membrane lease, revocation wavefront, and receipts separate.
- `ShellCard` in the same doc keeps human-facing authority/retention badges honest against backing records.
- `CopyInventory` and `docs/30-architecture/derived-artifact-cleanup-ledger-v0.md` keep source forgetting from ignoring live embeddings, summaries, answer caches, excerpts, thumbnails, or other local derived artifacts.

This still does not make ViewFS an implementation. It makes the implementation target harder to accidentally misread.
