# Cache pressure, capacity signals, and metering v0

Revision 165 also adds a small observation/side-effect lane for cache residency, capacity signals, and metering receipts. These surfaces are easy to under-design because they look like metadata. In ViewFS they are authority-adjacent: they can reveal sensitive membership, revive stale bytes, cause background IO, or become an accidental billing/charge token.

## New record families

| Record family | Purpose | Non-authority warning |
|---|---|---|
| `CacheEntry` | A local residency record for a source object, source epoch, pressure state, and source handle. | Cache warmth is not read authority; stale or evicted entries cannot resurrect bytes. |
| `CapacitySignal` | A coarse, approved observation about available capacity or pressure. | Capacity hints must not become membership or load side channels. |
| `MeteringReceipt` | Evidence that a measured effect is ready to settle against a reservation. | A metering receipt is not new spend authority and cannot overcharge a reservation. |

## Checked operations

- `hydrate_cache_entry` allows cache hydration only when the cache entry is usable, the source epoch matches, pressure policy permits residency, and a live source read/hydrate handle is present.
- `emit_capacity_signal` allows capacity reporting only when the signal is sealed/approved, coarse enough for policy, stripped of private identifiers, and backed by live observe-capacity authority.
- `settle_metering_receipt` allows settlement only against a live reservation, matching event digest, amount no greater than the reserved amount, and a live charge/settle authority handle.

## Denial reasons that must stay distinct

| Reason | Meaning |
|---|---|
| `cache-entry-not-authority` | A cache row or cache card was used as object authority. |
| `cache-source-epoch-mismatch` | The cached entry was derived from a stale source epoch. |
| `cache-entry-evicted` | The entry is no longer resident and cannot be revived by metadata. |
| `cache-pressure-without-pin` | Cache pressure is above limit and no explicit pin/root protects the entry. |
| `capacity-signal-not-authority` | A capacity signal was replayed as authority. |
| `capacity-signal-too-precise` | The signal is exact/per-object/per-principal and therefore risks side-channel leakage. |
| `capacity-signal-leaks-private-membership` | The signal carries private object/principal identifiers. |
| `metering-receipt-not-authority` | A charge receipt was replayed as a fresh spend or charge authorization. |
| `metering-overcharge` | The measured amount exceeds the admitted reservation. |

## Anti-collapse rule

ViewFS should be honest that resource observation is itself a disclosure surface:

```text
Cache warmth is not a read grant.
Capacity pressure is not a global load oracle.
Metering evidence is not spend authority.
```

The safest v0 posture is deliberately conservative. If a signal would reveal exact membership, exact capacity, or cross-principal pressure, it must either be denied or pass through a stronger disclosure/authorization lane not modeled in rev0165.

## Shell posture

The shell should render these as separate cards:

- **cache card**: source epoch, pressure posture, pin/root posture, and whether a live source handle exists;
- **capacity lamp**: coarse bucket, policy badge, and side-channel warning;
- **metering card**: reservation, measured amount, event digest, settlement status, and overcharge/receipt-replay denials.

Do not render cache hits, capacity headroom, or billing receipts as green authority. They should be dimmer than handles, approvals, and live tool bindings.

## Open choices

- Exact cache eviction and pin priority semantics are open.
- Cross-principal cache side-channel policy is open.
- Capacity signal quantization and privacy budget accounting are open.
- Chargeback, refunds, and multi-tenant budget reconciliation are open.
- Implementation-specific counters and kernel/runtime telemetry are out of scope for v0.
