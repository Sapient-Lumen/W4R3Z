# Committed objects, retention clocks, hold states, purge verdicts, live facets, and receipts

Purpose: keep **durable committed objects**, **retention clocks/configurations**, **hold states**, **purge verdicts**, **current live facets**, and **durable receipts/history** on distinct seams.

## The split
- **committed object** — one durable object or durable object version that exists now.
- **retention clock** — one retain-until fence or equivalent deletion/replacement rule over that committed object.
- **hold state** — one temporary, event-driven, legal, or similar keep barrier that is not the same thing as the retention clock.
- **purge verdict** — one later deletion/lifecycle/GC outcome or one explicit `still blocked` answer.
- **live facet** — currently usable inspect/read/edit/publish/delete authority over the object.
- **receipt/history** — durable memory of commit, retention changes, hold changes, purge attempts, and purge outcomes.

## Why this must stay split
A capability-heavy object store can easily lie by accident:
- one committed object gets mistaken for `safe to delete now`,
- one retention row gets mistaken for current live authority,
- one hold gets mistaken for durable identity,
- one purge receipt gets mistaken for current absence,
- or one current live bind gets mistaken for proof that policy allows destructive change.

That is exactly the kind of collapse ViewFS should avoid while SlopOS is still in design and while ViewFS itself is still collecting ideas instead of freezing one immutability/retention/purge substrate.

## Lessons worth stealing
### Retention clocks and hold states are different truths
Amazon S3 Object Lock is useful because legal holds are independent from retention periods, can stay in effect until explicitly removed, and apply to individual object versions.
That is a strong reminder that `retain until time` and `someone or something says do not delete this yet` are not the same class.

Google Cloud Storage is useful because temporary holds and event-based holds are both `keep this` signals, but they interact differently with retention timing: releasing an event-based hold can restart retention timing under a bucket retention policy, while releasing a temporary hold does not.
That is a strong reminder that not all holds are interchangeable.

### Retained objects and purge eligibility are different truths
Google Cloud Storage Object Retention Lock is useful because retain-until posture, lock mode, lifecycle deletion, version-currentness, and editable metadata are separate truths.
A retained object can still have editable metadata, a live version can become noncurrent, and lifecycle deletion still waits until retention conditions are satisfied.
That is a strong reminder that `retained` is not the same thing as `frozen in every way`.

### Legal/investigation holds and audit/history are different truths
Azure immutable storage is useful because legal hold scope, tags, and audit logging are separate policy/history surfaces rather than the same thing as blob identity or current use.
That is a strong reminder that investigation/compliance posture should stay explicit and inspectable instead of being smuggled into one overloaded object row.

### SlopOS already rhymes with the same lesson
Current SlopOS drafts are useful because orthogonal persistence, verified blobs, and receipt/evidence boundaries already resist the temptation to let durable existence, proof, and current authority collapse into one thing.
That means ViewFS can steal the separation now even though SlopOS itself has not settled a final retention-family substrate.

## Design guidance
1. A **committed object** should be inspectable without implying anything about current deletion eligibility.
2. A **retention clock** should stay explicit instead of hiding inside object birth or object identity.
3. A **hold state** should remain visible as its own class instead of being flattened into `locked`.
4. A **purge verdict** should explain what happened without pretending it is current live authority.
5. A **live facet** should stay visibly stronger than every retention/hold/history row.
6. A **receipt/history** row should remember prior retention/hold/purge facts without reviving present authority or present absence.

## Shell implications
The shell should be able to render:
- **hold badges** (`none`, `temporary hold`, `event hold`, `legal hold`, `multiple holds`, `history only`),
- **retention rails** (`none`, `retain until`, `policy editable`, `policy locked`, `satisfied`, `history only`),
- **purge lamps** (`eligible`, `blocked by retention`, `blocked by hold`, `lifecycle pending`, `purged`, `history only`),
- **live rails** (`inspect now`, `read now`, `edit now`, `publish now`, `delete now`, `history only`).

## Non-decisions to preserve
Do not decide yet:
- one universal retention/hold taxonomy;
- whether ViewFS needs separate families for legal/investigation, temporary-user, and event-driven holds everywhere;
- whether retention is version-scoped, anchor-scoped, aggregate-scoped, or mixed;
- whether purge is one user action, one lifecycle act, one GC act, or several distinct verbs;
- whether retained objects may still allow some metadata/head movement;
- one final WORM/retention schema or policy carrier.
