# Mutable anchors, work journals, observed-base validators, commit cuts, and receipts

This note narrows the mutable-state question without pretending to solve every directory, sync, or collaboration problem. ViewFS should permit writable work surfaces, but the first executable rule is simple: **mutable work does not become committed object identity until a commit cut validates the observed base against the current head**.

## Minimal lane

```text
ObjCore(base)
  -> MutableSession(base_object, current_head, write_handle, journal)
  -> local edits / parsed buffers / advisory diagnostics
  -> CommitCut(observed_base, new_object, approved)
  -> ObjCore(new) + commit receipt
```

A mutable session is not an object core. A journal is not publication. A parsed buffer is not a commit. A repair suggestion is not approval. A commit receipt is not future write authority.

## Required separations

| Class | Useful role | Must not become |
|---|---|---|
| `base_object` | the object the session started from | current truth after concurrent change |
| `current_head` | validation target at commit time | proof that the user reviewed the diff |
| `write_handle` | live authority slot for write/commit preparation | durable authority after revocation/expiry |
| `journal` | replayable local work log | committed object identity |
| `observed_base` | what the committer believes they are updating | automatic merge approval |
| `commit_cut` | exact publish/adopt checkpoint | a standing permission for future edits |
| `commit receipt` | history of the attempt/result | authority to reopen, rerun, or overwrite |

## First checked behavior

Revision 156 adds two fixtures:

- `011-mutable-commit-current-base-allow.json` — a live write handle plus approved commit cut over the current observed base may publish the new object.
- `012-mutable-commit-stale-base-denied.json` — a commit cut over an old observed base is denied even when the write handle is still live.

These fixtures intentionally ignore richer merge semantics. They are the minimum guardrail against a local journal or old base acting like current truth.

## Later work

Future revisions can add:

- explicit takeover cuts;
- three-way merge plans;
- conflict artifacts;
- provider pushback requests;
- remote currentness witnesses;
- rebase receipts;
- local upper overlays;
- abandoned-work retention budgets.

None of those should bypass the v0 fact that **publishing mutable work requires a current-base or explicitly reviewed merge/takeover cut**.
