# Revocation, stale brakes, retention roots, and sweep honesty

This note compresses three related but different surfaces: revocation, stale-brake presentation, and retention. ViewFS needs all three, but they must not collapse.

## Revocation is not forgetting

A revocation event cuts current or future use. It does not erase history, un-read previously read bytes, or prove that exported copies disappeared. Receipts should remain able to explain that authority existed and was later cut.

Minimum revocation classes:

| Class | Effect | Non-collapse rule |
|---|---|---|
| live lease revocation | current handle/facet stops working | does not delete object identity |
| durable-ref withdrawal | future reopen or restore requires new grant | does not destroy old receipts |
| membrane death | delegated/proxied authority cannot reacquire | does not prove remote copies are gone |
| stale brake | visible “do not use this old thing” guard | not a new approval or repair plan |

Revision 156 checks two behaviors:

- `013-revocation-restore-token-stale-brake-denied.json` denies reacquisition through a restore token after a death verdict.
- `020-revoked-handle-read-denied.json` keeps a revoked handle visible but non-live.

## Retention is not memory by accident

Retention must be rooted by explicit current reasons. Helpful residue is not automatically a root.

| Surface | Retains source by default? | Why |
|---|---:|---|
| live handle | yes, while live | current authority needs target material |
| explicit retention root | yes | policy says so |
| derived-only embedding | no | derived memory should not pin source silently |
| semantic answer card | no | projection/explanation, not custody |
| receipt | no | history can outlive or describe deletion without pinning bytes |
| old portal grant | no | grant lifecycle and storage lifecycle are separate |

Revision 156 checks:

- `014-sweep-explicit-retention-root-allow.json` — active retention root keeps an object.
- `015-sweep-receipt-only-not-root-denied.json` — receipt-only history does not retain the source.

## Shell posture

The shell should show stale/death/retention state as separate lanes:

- **death card**: why future use is blocked;
- **stale brake**: what old affordance was disabled;
- **why retained? drawer**: exact roots keeping an object alive;
- **sweep preview**: what would be collected and what residue would remain;
- **receipt ghost**: old fact, explicitly not current authority.

This is intentionally conservative. A user can ask why something is still retained, why a restore failed, or why an old receipt is visible, and the answer should not require pretending that revocation, deletion, retention, and forgetting are one operation.
