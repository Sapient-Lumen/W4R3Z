# Committed objects, prefix projections, folder resources, listing snapshots, published names, live facets, and receipts

Purpose: keep ViewFS honest about one especially expensive object-store confusion: **the durable object is not the same thing as the folder-like thing users browse to find it**.

## The split
Keep these classes visibly distinct:
- **committed object** — one durable object/version with its own semantic identity and proof surfaces;
- **prefix projection** — one folder-like grouping inferred from names, delimiters, or provider-specific browse conventions;
- **folder resource** — one provider-native folder/managed-folder/directory object when the backing system really has such a resource;
- **listing snapshot** — one current or historical browse result over a prefix/folder/resource boundary;
- **published name** — one object key, alias, path-like designation, or room-local visible name;
- **live facet** — one current read/edit/publish authority held here now;
- **receipt/history** — one durable record that those things were seen, listed, projected, or used before.

## Why this matters
Object stores keep teaching the same lesson in slightly different clothes.
Amazon S3 says buckets and objects are the primary resources, that there is no hierarchy, and that prefixes or delimiters only let tools infer a folder concept.
Google Cloud Storage says flat-namespace buckets have no directories/folders at all, but it also separately introduces managed folders and hierarchical namespace when real folder semantics are wanted.
Azure Blob Storage likewise supports virtual directories via delimiters in blob names, while hierarchical-namespace accounts can also expose actual directory resources.

That combination is a warning, not a nuisance:
- one prefix can be a browse aid without being a durable folder object,
- one provider may later add first-class folder resources without changing object identity,
- one listing row can be a snapshot over many objects without being a namespace commitment,
- and one current room bind can stay explicit even when the storage backing only offers flat keys.

## ViewFS posture
ViewFS should steal the honesty, not the folklore.

### 1. Folder-like browse should usually be a view-level projection
The custom shell should be free to present object-store contents in folder-like ways without pretending that the object store itself is path-native.
A room may bind:
- a real provider folder resource,
- a prefix projection over flat object names,
- a saved query snapshot,
- or a local synthetic grouping.

Those should not be flattened into one generic `directory object` unless a later design actually needs that coupling.

### 2. Prefix projections should stay weaker than object identity
A prefix/projection row may explain how a user got to an object, but it should not become:
- the object's semantic identity,
- proof that a folder resource exists,
- proof that a current listing is complete,
- or proof that the current process holds authority over every listed child.

### 3. Listing snapshots should stay inspectable and fallible
A listing is one snapshot or feed result, not namespace law.
The shell should be able to say:
- `prefix projection`,
- `provider folder`,
- `listing may be partial`,
- `listing from cache/history`,
- `object named here`,
- `bound in this room`,
- or `live facet held now`.

### 4. Published names should stay separate from room bindings
An object key or published name can be shown in many room presentations.
A room bind is a current explicit namespace act by the shell or mediator.
Do not let the existence of one visible name imply:
- one provider folder resource,
- one current complete listing,
- or one current live bind in every process.

## Shell consequences
Good shell chrome here is not decorative. It keeps the object store understandable.
Useful ideas worth stealing:
- **prefix badges** that say `flat-prefix`, `provider folder`, `managed folder`, `query projection`, or `history only`;
- **folder ghosts** that say `simulated`, `provider native`, `provider hidden`, or `not a folder resource`;
- **list lanterns** that say `snapshot`, `live feed`, `partial`, `cached`, `stale possible`, or `history only`;
- **name rails** that keep `published here`, `bound here`, `listed here`, and `live here now` visibly separate.

## What this deliberately does not decide
Do not decide yet:
- whether ViewFS Phase 1 exposes provider-native folder resources directly;
- whether folder resources, when they exist, are first-class object cards or mostly shell/internal rows;
- whether flat object stores get one canonical delimiter or several projection modes;
- whether room binds are always shell-owned or sometimes provider-owned;
- one final listing/feed ABI for every provider family.

## Why this fits SlopOS now
This is a good low-regret seam for the current SlopOS datacube because SlopOS already leans toward:
- exact per-process roots and explicit handle tables in `capshell-cwd-root-posture-v0.md` and `capshell-handle-table-posture-v0.md`,
- shell/view-owned query and attribute surfaces in `attrfs-posture-v0.md`,
- explicit document/import localization in `document-portal-posture-v0.md` and `import-to-docref-boundary-v0.md`.

Those are all strong signals that ViewFS should not let object-store prefix folklore quietly define namespace truth while both projects are still fluid.
