# Container envelopes, member claims, extraction plans, materialization roots, namespace commits, live opens, and receipts

Revision: 143  
Date: 2026-05-14  
Codename: extractplans-membercapsules-pathguards-coralvault

Purpose: keep archive/container extraction honest while the ViewFS object store, capability handles, explicit per-process namespaces, and portal imports are still in design.

## Core split

One user action like `unpack this` can hide at least eight different truths:

1. **Container envelope** — the aggregate object: ZIP, TAR, package, app bundle, OCI image, disk image, backup, or unknown container.
2. **Member claim** — each internal entry's asserted name, type, target, size, permissions, xattrs, timestamps, platform metadata, and duplicate/collision posture.
3. **Extraction plan** — the reviewed policy-filtered mapping from member claims to admitted, denied, rewritten, or budget-limited materialization actions.
4. **Sterile materialization root** — the private scratch/projection root where expansion can occur without touching the live namespace.
5. **Extracted member capsule / fresh object** — the local object/projection born from one admitted claim and one plan.
6. **Namespace commit / adoption** — the separate publication act that binds selected results into one ViewFS view.
7. **Current live open / mount** — the actual present authority over a materialized member/tree/root.
8. **Receipt/history** — durable explanation of what was inspected, denied, materialized, published, cleaned, or opened.

The shell can group these into a friendly archive card, but the substrate should not collapse them.

## Why this matters for ViewFS

A capability-native filesystem should be especially suspicious of archives because archives are path-shaped authority theater. They contain strings that look like paths, entries that look like files, links that look like relationships, and metadata that looks like operating-system state. But all of that comes from the container producer. None of it is automatically a current ViewFS name, object, root, handle, or policy decision.

This seam protects several ViewFS invariants:

- explicit per-process namespaces do not get mutated by raw archive paths;
- portal imports do not turn foreign bundle layout into trusted local placement;
- quarantine propagates through extraction and does not vanish at member birth;
- archive listing/preview remains weaker than live object possession;
- extraction plans can be rehearsed and explained before bytes land;
- receipts remember hazards without becoming authority.

## Design notes

### Container envelope is just the aggregate

The envelope can be strongly identified by digest and still be risky. It can be signed and still contain dangerous member claims. It can be quarantined while individual sanitized derivatives become usable. It can be retained while materialized members are evicted.

Useful envelope facts:

- top-level digest / comparison profile;
- format family and parser identity;
- origin evidence and quarantine mark;
- compressed and expected expanded size;
- member-count and nesting hints;
- signature / manifest / checksum rows;
- whether this is a simple archive, layered container image, install package, app bundle, backup, or unknown aggregate.

### Member claims are not object births

Member claims should be recorded before they are trusted. A member claim can be rendered in a list, used in a dry run, or denied without ever creating a local object.

Special handling lanes:

- absolute names;
- names with `..` or platform-specific escape variants;
- symlink and hardlink targets;
- duplicate names or case/unicode collisions;
- device nodes, FIFOs, sockets, setuid/sticky bits;
- xattrs, ACLs, ownership, timestamps, platform metadata;
- sparse files and decompression/resource multipliers;
- whiteouts and layered deletion semantics;
- nested containers.

### Extraction plan is the authority checkpoint

A plan should be the thing a user, policy, test, or CI harness can inspect. It can say:

```text
archive: vendor-tools.tar.zst @ digest 59d2...
policy: quarantine-inherited / no-links-followed / no-devices / no-setuid
admit: 412 regular files, 38 directories
rewrite: 2 reserved Windows names, 1 duplicate collision
block: 3 absolute paths, 4 symlink escapes, 1 hardlink escape
budget: 490 MiB expanded, 31k inodes, max depth 14
result: sterile root only; no namespace commit yet
```

This makes dangerous members boring and reviewable.

### Sterile roots prevent accidental publication

A sterile root is where expansion can be observed without becoming placement. It is useful for:

- safe preview;
- antivirus/sanitizer/transcode workflows;
- package-manager rehearsal;
- layered-image inspection;
- nested-container exploration;
- deriving one selected artifact.

The root can be deleted, snapshotted, partially adopted, or kept for a session. None of those choices should silently publish raw member names into a room or process namespace.

### Extracted member capsules preserve lineage

Each admitted member should carry:

- envelope digest;
- member claim digest;
- extraction plan digest;
- materialization root id;
- new object id or projection id;
- inherited quarantine and origin;
- denial/rewrite decisions that affected it;
- whether it can be published or is preview-only.

This avoids the tempting lie that `archive/foo.txt` is already the same thing as a ViewFS object named `foo.txt`.

### Namespace commit is a second act

Publishing extracted results should look like a normal ViewFS mutation with currentness witnesses and conflict checks. It can choose a target view, a fresh tree, a package root, a read-only mount, or a single selected file. It should not be the default side effect of listing or previewing the archive.

### Live opens and mounts must remain visibly stronger

A process holding a live handle to a materialized member has current authority. A receipt saying a member was previously extracted does not. A mounted read-only projection is not the same as a writable object tree. An executable entry admitted to a safe-open lane is not cleared for ordinary execution.

## Prior-art lessons mapped

- Python tarfile extraction filters: useful evidence that archive extraction needs named policy modes, and that safer defaults do not eliminate inspection duties.
- Go tar/zip insecure-path settings: compatibility pressure can keep unsafe behavior around for years; ViewFS should make path-guard posture explicit rather than assuming library defaults.
- bsdtar/libarchive posture: refusing `..` and symlink target-directory tricks by default is the kind of sharp guardrail ViewFS should render, not hide.
- Zip Slip: arbitrary overwrite via archive member names is a past lesson ViewFS must not relearn.
- OCI image spec: descriptors, manifests, indexes, layers, configs, and runtime bundles are different surfaces; ViewFS should not flatten aggregate metadata into a live root.

## Non-decisions

Do not decide yet:

- one final archive/container parser ABI;
- whether every archive gets lazy virtual-member handles, eager materialized objects, or both;
- one final policy for xattrs, ACLs, hardlinks, symlinks, devices, whiteouts, sparse files, and duplicate names;
- whether OCI-like images are packages, object trees, runnable roots, or separate launch artifacts;
- one final extraction sandbox profile;
- one final receipt schema for nested containers;
- whether extraction plans are stored objects, policy decisions, receipts, or a mix.

## API posture sketch

Candidate nouns, not a commitment:

```text
ContainerEnvelope
MemberClaim
ExtractionPlan
MaterializationRoot
ExtractedMemberCapsule
NamespaceCommit
LiveMaterializedFacet
ExtractionReceipt
```

Candidate verbs, not a protocol:

```text
inspect_container(envelope)
list_member_claims(envelope)
rehearse_extraction(envelope, policy, destination_mode)
create_sterile_root(plan)
materialize_members(plan, sterile_root)
commit_extracted_tree(root_or_capsules, target_view, currentness_witness)
open_materialized_member(capsule, lane)
write_extraction_receipt(result)
```

## Guardrails for reviews

Ask these before any future ViewFS archive/container API freezes:

1. Which exact layer is being acted on: envelope, member claim, plan, root, capsule, commit, live facet, or receipt?
2. Are raw member names ever interpreted against a live namespace before plan review?
3. What happens to symlinks, hardlinks, devices, xattrs, ACLs, whiteouts, duplicates, and resource bombs?
4. Is quarantine inherited, transformed, or explicitly cleared by a separate trust decision?
5. Can a receipt or list row be mistaken for a reopen handle?
6. Can a sterile root keep objects alive forever without an explicit lease/root?
7. Can a container image become a process root without a launch-view plan and exact handle-slot table?
