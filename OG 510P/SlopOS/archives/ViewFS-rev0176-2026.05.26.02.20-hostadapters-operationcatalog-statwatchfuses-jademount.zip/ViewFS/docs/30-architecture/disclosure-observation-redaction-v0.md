# Disclosure, observation, and redaction v0

Revision 161 adds executable pressure around a seam that was previously mostly implicit: ViewFS can show, notify, audit, package, and export without letting observation records become authority or letting redaction labels become proof of safe disclosure.

The v0 lane deliberately treats the following as distinct:

```text
RedactionView
  -> AuditProjection
  -> DisclosurePackage
  -> SubscriptionCursor / NotificationEnvelope
  -> SubjectAccessRequest
  -> Receipt
```

None of these records is a live object handle. Some can be used with a live handle and approved cut to produce a safe view or disclosure. Others only explain what happened.

## Record families

- `RedactionView` — a field/path/class lens over a source object, with allowed and redacted fields plus status.
- `AuditProjection` — a sealed audit/rendering view that may be redacted or raw, with an observer handle and authority-badge posture.
- `DisclosurePackage` — a prepared egress packet with source, subject, sink, payload class, redaction posture, approval cut, and live authority handle.
- `SubscriptionCursor` — a bounded observation cursor over subject events, with expiry and observe authority.
- `NotificationEnvelope` — an event envelope or payload prepared for delivery; it is not the object it describes.
- `SubjectAccessRequest` — a reviewed request for a subject-facing export, with exact subject, scope objects, redaction view, disclosure package, and authority handle.

## Anti-collapse rules

1. A redaction view is not authority. It can only narrow output through a current read/export/subject-access handle.
2. An audit projection is not raw audit authority. Redacted audit rendering needs observe authority; raw audit rendering needs a stronger raw-audit handle.
3. A disclosure package is not an export receipt. It must name the source, sink, approved cut, redaction posture, and live export/disclosure authority.
4. A notification envelope is not object authority. It may say that an object changed, but it cannot open that object or reveal redacted payload fields.
5. A subscription cursor must be live, unexpired, scoped, and backed by observe authority.
6. A subject-access export is not just a user-facing download. It requires review approval, exact subject/object scope, redaction of third-party/internal fields, and live subject-access/export authority.
7. Receipts remain history. They do not replay disclosure, subject access, notification delivery, or raw audit rendering.

## Current fixtures

- `077-redaction-view-read-allow.json`
- `078-redaction-view-secret-field-denied.json`
- `079-redaction-view-alone-denied.json`
- `080-audit-projection-redacted-allow.json`
- `081-audit-raw-projection-without-raw-handle-denied.json`
- `082-audit-projection-claims-live-denied.json`
- `083-audit-projection-redaction-leak-denied.json`
- `084-disclosure-approved-redacted-allow.json`
- `085-disclosure-receipt-replay-denied.json`
- `086-disclosure-raw-without-raw-export-denied.json`
- `087-disclosure-missing-redaction-denied.json`
- `088-disclosure-scope-mismatch-denied.json`
- `089-subscription-metadata-notification-allow.json`
- `090-subscription-full-payload-redaction-leak-denied.json`
- `091-subscription-expired-cursor-denied.json`
- `092-notification-envelope-open-target-denied.json`
- `093-subscription-without-observe-handle-denied.json`
- `094-subject-access-approved-redacted-allow.json`
- `095-subject-access-unapproved-denied.json`
- `096-subject-access-third-party-redaction-leak-denied.json`
- `097-subject-access-receipt-replay-denied.json`
- `098-subject-access-scope-mismatch-denied.json`

## Shell posture

The shell should render observation and disclosure through explicit cards:

- a redaction drawer showing fields hidden and fields admitted;
- an audit projection card labeled redacted, raw, inert, or authority-backed;
- a disclosure package card showing source, sink, payload class, approval cut, and live authority handle;
- a subscription cursor card with scope, expiry, payload class, and observe authority;
- a subject-access export card showing subject match, scope match, redaction posture, and review cut.

The shell must not make a delivered notification, green audit row, redaction badge, or subject-access receipt look like a live open button unless a current handle is present and the authority diff is honest.

## Non-goals

This v0 lane does not claim legal compliance, final privacy policy semantics, a universal redaction language, or a production audit-log schema. It only makes leak-prone collapses executable: observation is not read authority, redaction is not authority, notification is not object access, and a receipt is not disclosure replay.
