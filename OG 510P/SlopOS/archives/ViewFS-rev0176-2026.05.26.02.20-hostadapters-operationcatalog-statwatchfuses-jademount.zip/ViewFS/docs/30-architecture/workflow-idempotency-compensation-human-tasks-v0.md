# Idempotency, retry, compensation, human tasks, and workflow cards v0

Automation reliability introduces its own laundering risks. Idempotency keys, retry policies, compensation plans, and human-task rows are meant to prevent duplicate effects and guide recovery. They must not silently become the effect, approval, or evidence of success.

## Record posture

| Record family | Minimal fields | Non-authority warning |
|---|---|---|
| `IdempotencyKey` | `status`, `request_fingerprint`, `authority` | dedupe keys suppress duplicates; they do not replay effects |
| `RetryPolicy` | `attempt`, `max_attempts`, `backoff_until`, `budget_ok`, `authority` | retry eligibility is not hidden retry authority |
| `CompensationPlan` | `status`, `approval_cut`, `reversible`, `target_step`, `authority` | compensating action does not erase history |
| `HumanTask` | `assignee`, `trusted_path`, `approval_cut`, `authority` | task rows and clicks are not volition tokens by themselves |
| `WorkflowCard` | `workflow`, `claims_live_authority`, `claims_completion` | cards explain run state; they are not handles or success proof |

## Failure cases captured

- a spent idempotency key cannot replay the original effect;
- a retry row cannot exceed attempts or ignore backoff/budget;
- a compensation plan cannot claim erasure of evidence/history;
- a human-task row must pass trusted-path and assignee checks;
- a workflow card cannot claim live authority or completion unless backed by a complete run.

## Companion pressure

This lane belongs between ViewFS and SlopOS. SlopOS owns broader task/portal/request discipline; ViewFS owns object authority and view effects. The automation lane is the seam where prepared work crosses into object access, so it must be executable and adversarial rather than only shell prose.
