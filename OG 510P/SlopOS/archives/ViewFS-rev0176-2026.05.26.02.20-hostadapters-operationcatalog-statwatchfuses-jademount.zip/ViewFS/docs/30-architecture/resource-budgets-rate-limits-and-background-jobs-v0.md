# Resource budgets, rate limits, and background jobs v0

Revision 165 adds a deliberately small resource-control lane to the executable ViewFS model. The goal is not to design a scheduler, billing engine, or kernel quota API. The goal is to prevent another authority collapse: a quota card, queue row, past admission receipt, or apparently cheap background job must not become permission to read, write, export, execute, hydrate, or keep running.

## New record families

| Record family | Purpose | Non-authority warning |
|---|---|---|
| `ResourceBudget` | A period-bounded account of allowed resource spend for a scope. | A quota display is not payer authority and does not reserve capacity. |
| `SpendReservation` | A pending/reserved slice of a budget for a named effect. | A reservation row is not the object authority needed to perform the effect. |
| `RateLimiter` | A windowed admission state for invocation or scheduled work. | A token count or old rate receipt cannot mint a new invocation. |
| `BackgroundJob` | A queued unit of deferred work with plan, lease, reservation, rate, and live-authority requirements. | A queued job is inert; it cannot run itself after approval/authority/lease drift. |

## Checked operations

- `reserve_budget` admits a spend reservation only when the budget is active, the window is current, the requested amount fits remaining quota, and a live payer/spend handle is present.
- `admit_rate_limit` admits a rate token only when the limiter is active, the window is current, tokens remain, and a live invoke/schedule handle is present.
- `start_background_job` starts deferred work only when the queue lease is current, a spend reservation is already admitted, rate admission is still available, the typed action plan is approved, and a current authority slot still has the requested object right.

## Denial reasons that must stay distinct

| Reason | Meaning |
|---|---|
| `budget-metadata-not-authority` | A quota card, budget summary, metering row, or receipt was used as if it could reserve spend. |
| `budget-exceeded` | The requested reservation exceeds remaining budget after spent and reserved amounts are accounted for. |
| `budget-window-expired` | The period-bounded budget is not current anymore. |
| `reservation-payer-handle-revoked` | Budget facts are valid, but the payer/spend handle is no longer live. |
| `rate-limit-exhausted` | The limiter is current but out of tokens. |
| `rate-limit-window-stale` | The token window is stale and must not be replayed. |
| `queued-job-not-authority` | A queue row, job card, or job receipt tried to execute itself. |
| `job-queue-lease-expired` | Deferred work had an approval/queue lease, but that lease is no longer current. |
| `background-job-lacks-live-authority` | The typed plan exists, but the authority slot has drifted or been revoked. |
| `background-job-lacks-budget-reservation` | Deferred work lacks an admitted spend reservation. |

## Anti-collapse rule

A resource lane may bound or deny an operation, but it is never enough to authorize the operation by itself:

```text
Budget fact + reservation + rate token + queue lease + typed plan
  + approval cut + current live authority
  -> admitted work
```

Removing any one of those fields must have a distinct, reviewable denial. This matters because background work is often where ambient authority re-enters: a job is approved once, sits in a queue, and later runs after handles, scope, rate windows, or budgets have changed.

## Shell posture

The shell should show resource controls as brakes and explainers, not green authority badges:

- quota cards say what remains, not what may be opened;
- reservation cards say what spend is held, not what object effect is authorized;
- queue cards show plan, lease, budget, rate, and authority freshness separately;
- stale queue cards offer recheck/reapprove lanes rather than a hidden retry;
- rate-limit denials expose a bounded retry hint without revealing exact global load unless policy allows it.

## Open choices

- Final resource units are open: bytes, IOs, CPU milliseconds, tokens, requests, egress, storage pressure, or domain-specific work units may all be needed.
- Quota hierarchy and inheritance are open; v0 models only one budget/scope row.
- Payer identity and cross-principal chargeback are open beyond live payer/spend handle checks.
- Scheduler fairness, priority inversion, starvation, and preemption are not yet modeled.
- Distributed budget consensus is open; v0 uses fixed-window fixture times.
