# Live room bindings, currentness witnesses, renewal windows, retry advice, and repair gates

This note protects one more high-value seam while ViewFS and SlopOS are both still moving.

Revision 0101 already split durable anchors, live room binds, stale shadows, repair plans, and receipts.
Revision 0102 already split activation kits, restart lockers, namespace pins, and live room binds.
Revision 0103 already split live binds, currentness witnesses, semantic epochs, repair offers, and receipts.
This note adds another discipline on top:

**the live room binding now, the witness that says whether it is still current, the renewal window that can keep that same live claim alive, the retry advice that says when a follow-up is sensible, the repair gate that says automatic help should stop, and the receipt explaining what happened are different classes.**

## The split

### 1. Live room binding
A live room binding is the answer to:
- what exact object, projection, import, or current handle is this room actually holding right now?

Good examples:
- one current document projection in the room namespace,
- one current local object bind,
- one current imported helper capability,
- one current child-room binding delivered by reviewed spawn/import flow.

This is current authority truth.
It is not the witness that says whether this truth is still current enough for the next action.

### 2. Currentness witness
A currentness witness is the answer to:
- what exact evidence says whether the current bind is still good, replaced, revoked, expired, unknown, or in need of refresh?

Good examples:
- one provider generation or revocation epoch,
- one portal/session freshness token,
- one watch/status carrier,
- one holder-bound proof or step-up result,
- one successor notice that says a fresher bind exists.

This is currentness truth.
It is not the bind itself.

### 3. Renewal window
A renewal window is the answer to:
- what exact renew-or-expire budget keeps this *same* live claim or live conversation current if it is refreshed in time?

Good examples:
- one watchdog/keepalive budget,
- one portal/session renewal deadline,
- one `renew through T` budget on a live import,
- one grace window for a current room-side bind that is still expected to be refreshed.

This is continuity-budget truth.
It is not a new grant, not a broader health proof, and not proof that a follow-up should happen right now.

### 4. Retry advice
Retry advice is the answer to:
- if the next exact follow-up is not sensible now, what is the earliest useful retry moment or the right `not before` hint?

Good examples:
- `retry after 12s`,
- `try again at 14:03`,
- `still processing`,
- `pushback until refresh`,
- `retry advice unavailable`.

This is timing guidance.
It is not authority, not the same as a renewal window, and not a promise that the future retry will succeed.

### 5. Repair gate
A repair gate is the answer to:
- when repeated failure, repeated expiry, or repeated stale follow-up means automatic help should stop, what exact state says `cool down`, `repair required`, or `manual clear required`?

Good examples:
- `cooling down`,
- `repair required`,
- `manual clear required`,
- `healthy run reset recent-failure window`,
- `auto-renew suspended after repeated misses`.

This is quieting/repair truth.
It is not the same thing as one failed action.

### 6. Receipt/history
Receipts preserve explanation of:
- what currentness witness was consulted,
- whether a renewal was missed,
- whether retry advice was issued,
- whether a repair gate was entered or cleared,
- and whether a later refresh/rebind/reconsent succeeded.

Receipts should not silently revive live authority, currentness, renewal windows, retry hints, or closed repair gates.

## Product consequences

### Renewal lamps
The shell should be able to show compact lamps such as:
- `renewed through 14:03`,
- `renewal due soon`,
- `renewal missed`,
- `grace window active`,
- `renewal unsupported`,
- `receipt only`.

That is not just decoration.
It is the shell admitting whether a live claim is being kept warm, coasting toward expiry, or no longer renewable.

### Retry clocks
A room, import row, or command block should be able to say:
- `retry after 12s`,
- `try again at 14:03:12`,
- `still processing`,
- `retry advice missing`,
- `hint expired`,
- `manual clear first`.

That is much better than a dead-looking button or one eager rerun affordance.

### Repair-gate cards
When repeated misses, repeated stale-followups, or repeated crashy repair attempts happen, the shell should surface compact gate cards such as:
- `cooling down`,
- `repair required`,
- `wait for explicit clear`,
- `inspect recent misses`,
- `rerun clean in fresh room`,
- `dismiss to receipt only`.

Gate cards should explain whether the stop came from repeated renewal misses, repeated retry pushback, repeated stale witnesses, or another narrow class.

### Currentness drawers
A current bind or imported object should be able to surface a drawer with rows like:
- `live bind now`,
- `currentness witness`,
- `renewal window`,
- `retry advice`,
- `repair gate`,
- `receipt history`.

That lets the shell explain why something is actionable, dimmed, waiting, or blocked **without** pretending the object disappeared.

### Auto-help should stay reviewable
The shell may be allowed to:
- refresh one witness,
- renew one current claim,
- wait until one retry clock clears,
- or stop helping because one repair gate tripped.

But those are different moves and should leave different receipts.
The luxury move is not invisible automation.
It is visible, exact, bounded automation.

## Why this fits current SlopOS work
Current SlopOS already leans toward:
- explicit document/import/session surfaces rather than ambient path folklore,
- explicit expiry/revocation posture on document-like continuity seams,
- explicit leases and lease-like runtime surfaces rather than sticky `probably still alive` folklore,
- descriptive wallets instead of authority-bearing summaries,
- exact child handle tables and explicit filesystem posture instead of ambient inheritance.

That gives ViewFS permission to protect this seam **without** deciding the final renewal protocol, final retry-hint carrier, final repair-gate object, or final object-store layout.

Sibling pressure also points the same way:
- Steward already has renewal-window, retry-advice, and repair-gate posture docs,
- Schell is already insisting that dead anchors and reset scopes must be rendered honestly,
- and Ghostty/WezTerm/VS Code/fish/Nushell all show that good shell UX comes from visible state classes rather than transcript scraping.

## Good questions to keep open
- Which verbs should be allowed to auto-renew and which should require explicit review?
- When should retry advice suppress eager rerun affordances but still allow inspect/reveal?
- Should repair gates be issuer-owned, room-owned, or supervisor-owned?
- Can a room keep old receipts/history after a gate trips without tempting users into stale exact actions?
- Which renewal windows should be allowed to survive restart via lockers, and which should always cold-expire?
