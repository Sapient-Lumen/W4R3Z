# Authority diffs and export plans v0

Revision 158 adds two executable lanes that pressure shell honesty: authority diffs and export plans. Both exist because users do not perceive raw handles. They perceive cards, buttons, share sheets, prompts, badges, and summaries. Those projections become security surfaces when they can hide rights added or egress created.

## Authority diff

An authority diff is a human-facing and machine-checkable comparison between before-rights and after-rights.

```text
AuthorityDiff(
  subject,
  before_rights,
  after_rights,
  declared_added,
  declared_removed,
  widening_badge
)
```

The v0 rules are:

- actual added rights must equal declared added rights;
- actual removed rights must equal declared removed rights;
- any widening must be visibly badged;
- a diff is a projection, not an authority carrier.

Fixtures:

- `035-authority-diff-narrowing-honest-allow.json` admits honest narrowing;
- `036-authority-diff-hidden-widening-denied.json` denies hidden added write rights;
- `037-authority-diff-visible-widening-allow.json` admits widening only when the added right is declared and badged.

## Why this belongs in ViewFS

ViewFS has many surfaces that can look like authority changes: consent cards, portal grants, shell card badges, launch kits, delegation cards, safe-open ladders, and export trays. If these surfaces do not show deltas, users and reviewers will miss the exact moment an inert artifact turns into a live capability or a read handle becomes an export handle.

The authority diff is not a final UI design. It is the minimum executable claim that a UI cannot hide a rights expansion.

## Export plan

An export plan is a typed, approved egress operation.

```text
ExportPlan(
  typed,
  source,
  sink,
  authority_handle,
  approval_cut,
  quarantine_clearance?
)
```

The v0 rules are:

- the plan must be typed;
- the approval cut must be approved;
- the authority handle must be live and include `export`;
- the sink must be explicit;
- if a source is quarantined, export is blocked unless the plan carries quarantine clearance;
- old export receipts cannot be replayed as current export authority.

Fixtures:

- `038-export-plan-quarantined-source-denied.json` blocks egress from un-cleared foreign content;
- `039-export-plan-cleared-source-allow.json` admits export after clearance and approval;
- `040-export-receipt-replay-denied.json` denies receipt replay.

## Relationship to receipts

Receipts are still essential. They explain who exported what, to which sink, under which approval cut, and from which authority handle. But a receipt is a fossil. It cannot be rerun as a share button, cannot refill a sink, cannot re-open a foreign source, and cannot refresh a stale approval.

## Relationship to companion cubes

- SlopOS pressures the approval/tool boundary and live authority slot discipline.
- Harbor pressures external surface staleness and recheck windows.
- Schell pressures export copies, residue, retention, and forgetting claims.
- Ward pressures delegated/organizational approval when egress has stewardship impact.
- Helm pressures repair after denied or partial export.
- Foundry pressures specimens before new labels become design claims.

## Open choices

- Sink taxonomy: local file, portal promised file, network destination, remote workspace, package registry, clipboard, print, transcript, and model context should not share one sink type forever.
- Budgeting: export volume, count, time, recipient, and sensitivity budgets are not modeled yet.
- Redaction: exporting a redacted projection and exporting source bytes are different plans.
- Recheck: an export plan may need to revalidate quarantine, retention, consent, and recipient state immediately before send.
