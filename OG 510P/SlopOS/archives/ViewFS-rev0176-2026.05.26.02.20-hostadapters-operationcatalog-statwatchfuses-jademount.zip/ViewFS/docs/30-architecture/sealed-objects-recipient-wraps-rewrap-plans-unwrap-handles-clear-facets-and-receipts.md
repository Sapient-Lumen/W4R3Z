# Sealed objects, recipient wraps, rewrap plans, unwrap handles, clear facets, and receipts

Purpose: keep **durable sealed objects**, **recipient-wrap rows**, **rewrap plans/receipts**, **current unwrap handles**, **current clear facets**, and **durable receipts/history** on distinct seams.

## The split
- **sealed object** — one durable encrypted object or encrypted package that exists now.
- **recipient wrap** — one wrapped DEK, recipient stanza, or equivalent per-recipient / per-key-slot row over that sealed object.
- **rewrap plan** — one proposed or completed change to recipient wraps, wrapping-key versions, or equivalent envelope posture.
- **unwrap handle** — one current provider-bound or holder-bound authority that may unwrap one recipient wrap.
- **clear facet** — currently usable inspect/read/edit/publish authority over decrypted or otherwise cleared content.
- **receipt/history** — durable memory of seal, wrap, rewrap, unwrap, and clear-bind events.

## Why this must stay split
A capability-heavy object store can easily lie by accident:
- one sealed object gets mistaken for `someone can open this here now`,
- one recipient-wrap row gets mistaken for current live authority,
- one new primary key version gets mistaken for automatic rewrap truth,
- one unwrap receipt gets mistaken for current clear possession,
- or one current clear bind gets mistaken for permission to export or rewrap secret-bearing key material.

That is exactly the kind of collapse ViewFS should avoid while SlopOS is still in design and while ViewFS itself is still collecting ideas instead of freezing one envelope / KMS / vault substrate.

## Lessons worth stealing
### Sealed payload and recipient roster are different truths
JWE is useful because the JSON serialization can encrypt to multiple recipients while all recipients share the same protected header, IV, ciphertext, and authentication tag, and carry separate per-recipient `encrypted_key` material.
That is a strong reminder that one sealed object and one recipient roster are different layers.

### Recipient wraps and current unwrap authority are different truths
WebCrypto is useful because `CryptoKey` is an opaque reference managed by the user agent, and `wrapKey` / `unwrapKey` are separate operations.
That is a strong reminder that the thing which can unwrap is not the same thing as the sealed object or the wrap row.

### Envelope layers and key rotation / rewrap are different truths
Cloud KMS envelope encryption is useful because the KEK wraps DEKs which encrypt the actual data, and the encrypted data is stored with the wrapped DEK.
Cloud KMS re-encryption guidance is useful because key rotation does not re-encrypt already encrypted data automatically; re-encryption is a separate explicit act.
That is a strong reminder that `new primary key version`, `rewrap complete`, and `same semantic object` are different truths.

### Key-version witness and current decryptability are different truths
Cloud KMS key-state guidance is useful because ciphertext stores which key version encrypted it, only one key version is primary at a time, and enabled non-primary versions can still decrypt.
That is a strong reminder that `which version wrapped or encrypted this`, `what is primary now`, and `what can clear it here now` are different truths.

### SlopOS already rhymes with the same lesson
Current SlopOS drafts are useful because the crypto-service, vault, auth-proof-export, and wallet posture already resist the temptation to let sealed material, proof material, key handles, and current live authority collapse into one thing.
That means ViewFS can steal the separation now even though SlopOS itself has not settled a final envelope / vault / KMS substrate.

## Design guidance
1. A **sealed object** should be inspectable without implying current clear access.
2. A **recipient wrap** should stay explicit instead of hiding inside object identity or one flattering `encrypted` bit.
3. A **rewrap plan** should remain visible as its own class instead of being flattened into object replacement or semantic mutation.
4. An **unwrap handle** should stay visibly stronger than every recipient-wrap or receipt row, but still weaker than a current clear facet.
5. A **clear facet** should stay visibly stronger than every seal/wrap/rewrap/history row.
6. A **receipt/history** row should remember prior wrap or unwrap facts without reviving present clear authority.

## Shell implications
The shell should be able to render:
- **seal badges** (`sealed`, `sealed+typed`, `sealed+signed`, `history only`),
- **wrap rosters** (`1 recipient`, `3 recipients`, `provider hidden`, `mixed roster`, `history only`),
- **rewrap ladders** (`rotate wraps`, `add recipient`, `remove recipient`, `rewrap done`, `rewrap failed`, `history only`),
- **unwrap rails** (`unwrap handle present`, `provider-bound only`, `needs mediator`, `cannot unwrap here`, `history only`),
- **clear rails** (`inspect now`, `read now`, `edit now`, `publish now`, `history only`).

## Non-decisions to preserve
Do not decide yet:
- one universal envelope format or recipient-wrap schema;
- whether wraps are inline, sidecar, or provider-indexed;
- whether clear facets can survive restart or leave the current machine;
- whether rewrap is version-producing, in-place, or mixed;
- one universal key-handle ABI or one universal unwrap-via-portal flow;
- one final export/import rule for encrypted versus clear packages.
