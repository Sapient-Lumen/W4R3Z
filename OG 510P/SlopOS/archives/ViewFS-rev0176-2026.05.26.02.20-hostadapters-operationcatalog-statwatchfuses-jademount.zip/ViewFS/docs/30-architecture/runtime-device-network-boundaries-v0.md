# Runtime, device, network, clipboard, drag/drop, peripheral, and sensor boundaries v0

Revision 167 adds a boundary-reality lane for ViewFS surfaces that are not files but routinely smuggle file authority in companion products: host runtime posture, device attestation, network connectors, clipboard parcels, drag/drop parcels, peripheral grants, and sensor observations.

The design rule is simple:

> Local presence, host posture, installed connector state, visible device descriptors, clipboard contents, drag/drop gestures, and sensor samples may explain context or eligibility, but they are not ViewFS authority.

## Record families

| Record | Carries | Must not become |
|---|---|---|
| `RuntimePosture` | runtime epoch, debug/lock state, attestation status, host/container profile | object handle, tool authority, trusted-path proof |
| `DeviceAttestation` | device class, verification status, revocation posture, descriptor binding | peripheral authority or identity proof by itself |
| `NetworkConnector` | endpoint, active egress policy, DNS/freshness proof, allowed effects | generic network authority or endpoint retargeting right |
| `ClipboardParcel` | source epoch, classification, redaction state, expiry | read authority, paste authority, or secret custody |
| `DragDropParcel` | trusted-path state, gesture status, expiry, overlay suspicion | import authority or consent proof alone |
| `PeripheralGrant` | approved device class, sandbox fit, device attestation link | hardware authority without a live peripheral handle |
| `SensorObservation` | currentness, precision, purpose, consent posture, rate state | identifier, surveillance grant, or object authority |

## Operations

`verify_runtime_posture` accepts a runtime posture only when its epoch matches, its attestation state is verified, debug state is compatible with the requested locked-runtime requirement, and a live runtime inspection/admission handle is present.

`admit_network_connector` requires an admitted connector, active policy, fresh DNS proof, exact endpoint match, allowed effect set, and a live egress/network handle. Connector metadata and endpoint labels are explanatory only.

`redeem_clipboard_parcel` requires a fresh non-secret or redacted parcel, matching source epoch, unexpired lifetime, live clipboard authority, and destination write/paste authority. Clipboard buffers are especially dangerous because they feel local and immediate while often crossing trust, redaction, and secret-custody boundaries.

`redeem_dragdrop_parcel` requires fresh trusted-path drag/drop state, a valid gesture, no overlay suspicion, and a live import/drop handle. A drop gesture without trusted path is not approval.

`bind_peripheral_device` requires an approved peripheral grant, verified non-revoked device attestation, exact device-class match, sandbox fit, and live peripheral authority. A USB/Bluetooth/HID descriptor is never enough.

`observe_sensor_sample` requires a current observation, active consent, coarse non-identifying precision, purpose fit, rate posture, and a live observe-sensor handle. Sensor samples are metadata with privacy consequences, not ambient authority.

## Negative fixture pressure

The fixture corpus now denies:

- runtime posture rows used as authority;
- stale runtime epochs;
- debug-open runtimes presented as locked;
- connector metadata used as egress authority;
- endpoint retargeting and stale DNS proofs;
- clipboard secret leakage and expired clipboard parcels;
- drag/drop overlay and gesture laundering;
- peripheral descriptors, class retargeting, revoked device attestations, and missing live device handles;
- exact sensor observations, sample-only authorization, and stale sensor consent.

## Shell posture

A ViewFS shell should render these as boundary lamps and not as trust badges:

- runtime lamp: locked/debug, epoch, attestation freshness;
- connector card: endpoint, allowed effects, DNS proof age, policy digest;
- clipboard drawer: source epoch, redaction status, secret-risk warning, expiry;
- drag/drop card: trusted-path and overlay posture;
- peripheral card: device class, attestation, revocation, sandbox fit;
- sensor chip: coarse/exact, purpose, consent, rate posture.

The shell must not show “local,” “connected,” “installed,” “copied,” “dropped,” or “seen by sensor” as shorthand for live ViewFS authority.
