# Upload sessions, part coverage, completion manifests, committed objects, abort verdicts, live facets, and receipts

Purpose: keep **live upload sessions**, **part/offset coverage**, **completion manifests**, **durable committed objects**, **abort verdicts**, **current live facets**, and **durable receipts/history** on distinct seams.

## The split
- **upload session** — the live resumable staging lane, upload ID, or session URI that is still accepting or tracking bytes.
- **part coverage** — uploaded parts, persisted offset, chunk coverage, or assembly-ready progress inside that session.
- **completion manifest** — the explicit list, digest, or close instruction that finalization will use.
- **committed object** — the durable object/store member that exists only after successful finalization.
- **abort verdict** — explicit `aborted`, `expired`, `replaced`, `cleanup pending`, or `history only` truth for the session.
- **live facet** — currently usable inspect/read/edit/publish authority over the finished object.
- **receipt/history** — durable memory of session creation, part upload, close/finalize, abort, and later cleanup.

## Why this must stay split
A capability-heavy object store can easily lie by accident:
- one upload session gets mistaken for the finished object,
- one progress row gets mistaken for proof that finalization succeeded,
- one completion manifest gets mistaken for current live authority,
- or one aborted session receipt gets mistaken for a tombstone over the final durable object.

That is exactly the kind of collapse ViewFS should avoid while SlopOS is still in design and while ViewFS itself is still collecting ideas instead of freezing one substrate.

## Lessons worth stealing
### Multipart and resumable uploads are explicit state machines
Amazon S3, OCI Distribution, tus, and Google Cloud Storage are all useful because they keep start/resume/progress/finalize truth explicit instead of pretending `upload in progress` is already `object exists`.
That means ViewFS should never let `session open`, `offset known`, `assembly list ready`, or `close requested` silently mean `durable object committed`.

### Completion data is its own lane
S3 is especially useful because finalization requires the caller to provide a complete part list with part numbers and ETags.
That is a strong reminder that one completion manifest is not just one progress bar; it is explicit assembly intent.

### Session carriers are security-relevant but not object identity
GCS is useful because a resumable-upload session URI acts as an authentication token and can expire.
That is a strong reminder that session carriers are security-sensitive continuity aids, not durable object IDs or live post-commit facets.

### SlopOS already rhymes with the same lesson
Current SlopOS drafts are useful because D-PERSIST and CapStore keep durable object/store truth explicit, CH-AREF keeps large-artifact identity separate from storage plumbing, import-to-docref posture keeps fresh local object birth explicit, and D-BGLEASE says ordinary uploads should prefer jobs rather than ambient persistence widening.
That is almost exactly the object-store/session honesty ViewFS should steal.

## Design guidance
1. An **upload session** should be inspectable without implying that a durable object already exists.
2. **Part coverage** should stay reviewable without becoming object identity or full-object proof.
3. A **completion manifest** should remain a visibly later act than `bytes have arrived`.
4. A **committed object** should be born at finalization time, not smuggled backward into session creation.
5. An **abort verdict** should stay visible even when backend cleanup lags.
6. A **live facet** should stay visibly stronger than every session/progress/abort row.
7. A **receipt/history** row should remember session facts without reviving present authority.

## Shell implications
The shell should be able to render:
- **session beads** (`open`, `resuming`, `sealed`, `committing`, `expired`, `history only`),
- **part gauges** (`0 parts`, `partial`, `offset known`, `assembly list ready`, `unknown`),
- **seal ladders** (`finalize with manifest`, `resume session`, `abort now`, `inspect committed object`),
- **abort ash** (`aborted`, `expired`, `replaced`, `cleanup pending`, `history only`),
- **live rails** (`inspect now`, `read now`, `edit now`, `publish now`, `history only`).

## Non-decisions to preserve
Do not decide yet:
- one universal resumable-upload ABI;
- one universal part/chunk numbering family;
- whether completion manifests are always first-class objects or sometimes provider-hidden;
- whether session cleanup receipts are synchronous or eventually consistent;
- whether shell, portal, helper, or provider owns retry/resume policy in every backend.
