# Distributed freshness, leases, and offline branches v0

Revision 160 adds executable pressure around a ViewFS reality that was previously mostly prose: the object graph can be local, cached, delegated, remote, offline, and later reconciled. A stale row can still look authoritative. The v0 rule is that freshness evidence, lease rows, offline commits, and old receipts explain a proposed operation but do not authorize it alone.

## Record families

- `AuthorityLease` — a current lease on a handle/right with issuer, epoch, expiry, and renewal cut.
- `FreshnessFence` — a bounded statement that a remote head, lease epoch, or attestation status was current within a specific horizon.
- `OfflineBranch` — a local branch from an observed remote head, with local head, revalidation cut, and publish authority.

## Anti-collapse rules

1. A lease renewal needs a live lease, matching epoch, unexpired bound, renewal cut, and a live handle with the requested right.
2. A lease receipt is never a lease authority.
3. An offline branch local commit is not publish authority.
4. Offline publish must revalidate the remote head before publication.
5. A freshness fence is bounded evidence; once expired, mismatched, or still uncertain for a linearized operation, it denies.

## Current fixtures

- `055-lease-renewal-current-allow.json`
- `056-lease-renewal-expired-denied.json`
- `057-lease-renewal-epoch-mismatch-denied.json`
- `058-lease-receipt-replay-denied.json`
- `059-offline-branch-publish-revalidated-allow.json`
- `060-offline-branch-stale-remote-head-denied.json`
- `061-offline-local-commit-publish-denied.json`
- `070-freshness-fence-current-allow.json`
- `071-freshness-fence-expired-denied.json`
- `072-freshness-uncertainty-open-denied.json`
- `073-freshness-epoch-mismatch-denied.json`

## Non-goals

This v0 lane does not choose a final distributed-clock algorithm, CRDT, branch format, or provider sync protocol. It only states the minimum ViewFS safety posture: recency is an object with expiry and uncertainty, not an invisible property of old evidence.
