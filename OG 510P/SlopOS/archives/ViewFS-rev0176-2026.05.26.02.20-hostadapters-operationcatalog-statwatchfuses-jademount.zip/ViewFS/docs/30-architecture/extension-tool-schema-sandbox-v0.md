# Extension manifests, tool schemas, bindings, and sandbox profiles v0

Revision 164 adds a checked plugin/tool lane because ViewFS shells will eventually show installed extensions, palette-visible tools, tool descriptions, and schema cards. Those surfaces are useful and dangerous: they can make a tool look invocable when the system only has metadata.

## Minimal lane

```text
ExtensionManifest
  + ToolSchema
  + ToolBinding
  + SandboxProfile
  + ActionPlan
  + ApprovalCut
  + live target handle
  -> tool invocation
  -> receipt
```

The install/admission cut and the invocation cut are deliberately separate. A package may be admitted without any particular target authority. A tool may be installed and bound without being currently invocable against a workspace object. A schema may describe an effect without granting it.

## Binding rules

A `ToolBinding` is valid only when:

1. the extension manifest is verified and admitted;
2. the manifest schema digest matches the active tool schema digest;
3. the manifest's declared rights are within the install plan's approved rights;
4. the schema's required rights are declared by the manifest;
5. the schema's effects fit the active sandbox profile;
6. the binding operation has a live `bind_tool` handle.

## Invocation rules

A bound tool can be invoked only when:

1. the binding remains live;
2. the schema remains active and digest-matched;
3. the sandbox still admits the schema effects;
4. the action plan is typed;
5. the action plan names the exact tool binding;
6. the approval cut is approved;
7. the approval cut carries a live target handle with the required right.

## Shell non-collapse

The shell may show:

- installed extension badges;
- manifest rights drawers;
- schema/effect cards;
- sandbox effect chips;
- bound-tool palette entries;
- approval-cut and target-authority cards.

Only the final approval-cut + live target authority lane should be rendered as invocable. A visible tool or schema must be visibly inert when it lacks target authority.

## Non-claims

This lane does not define a stable plugin ABI, package registry format, tool argument language, or sandbox implementation. It only makes the authority boundary checkable before a plugin ecosystem grows around ViewFS.
