# Transport identities, verifier profiles, trust-anchor inputs, transparency/status evidence, channel bindings, session resumption, live secure channels, and receipts

Revision 150 adds a conservative secure-transport identity seam for ViewFS. It follows network leases and service-binding work, but it is not merely more network plumbing. Secure transports connect object-store import, service invocation, portal helpers, package updates, support uploads, secrets, mTLS client identity, and audit receipts.

The design goal is simple: **do not let secure-channel evidence become ViewFS authority by accident**.

## Why this matters for ViewFS

ViewFS wants explicit handles, per-process namespaces, portal-mediated imports, and object-store commits. Secure transport can bypass that discipline if the UI says only `verified`, `trusted`, `encrypted`, or `connected`.

A process can receive bytes over TLS without those bytes being safe to import. A helper can authenticate a remote service without having authority to export local object data. A service mesh identity can prove a workload name without authorizing a ViewFS object operation. An SSH known-host row can protect against some MITM attacks while still saying nothing about namespace authority. A certificate transparency SCT can improve auditability while still not proving local admission. A resumed TLS session can be efficient while still unsafe for replay-sensitive mutation.

The important move is to keep the proof/explanation lanes visible without freezing a final transport-auth ABI.

## Main distinctions

### Transport intent

A transport intent names why a secure channel is being requested:

- fetch remote bytes;
- call a service;
- upload/export object material;
- sync or update;
- connect to support/debug endpoint;
- open SSH-like remote shell;
- establish mTLS service-to-service channel;
- bootstrap a portal/helper session;
- retrieve certificate/status/transparency evidence.

The intent decides which later cuts are relevant. It is not a dialer by itself.

### Reference identity set

A reference identity set is what the client meant to authenticate before looking at peer evidence. It can include:

- DNS-ID / URI-ID / SRV-ID / IP-ID;
- SNI name and ALPN expectation;
- SSH host alias or known-host key scope;
- DANE TLSA owner name and usage mode;
- SPIFFE trust domain and workload path;
- project-local service designator plus binding cut;
- portal-owned remote identity rule.

This set should be derived from the reviewed request, service binding, or project policy. It should not be copied from the server certificate.

### Presented identity evidence

Presented evidence can include:

- X.509 chain and leaf SANs;
- raw public key;
- SSH host key;
- SVID;
- stapled OCSP/status object;
- CRL/status evidence bundle;
- CT SCT / inclusion / consistency proof;
- DANE TLSA RRset;
- proxy-presented identity evidence;
- client-auth request details.

These are evidence rows. They do not install trust roots or open objects.

### Verifier profile / policy cut

A verifier profile says which rules were used:

```text
profile: workstation-webpki | project-pinset | portal-local | appliance-strict | omitted
reference ids: digest(...)
path builder: local/verifier profile id
trust anchors: bundle digest / known-host scope / DANE mode / omitted
status: required / optional / explicit-evidence-only / omitted
transparency: required / advisory / omitted
wildcards: allowed under rule / denied / omitted
exception: none / reviewed / denied / redacted
policy epoch: exact
```

The profile is not a universal ViewFS standard yet. It is a named policy cut for explanation and tests.

### Trust-anchor and pin inputs

Trust inputs are local evaluator inputs:

- CA bundles and root-store snapshots;
- enterprise roots;
- DANE trust anchor or end-entity association;
- SSH `known_hosts` entries;
- SPKI pins;
- SPIFFE trust-domain bundles;
- device/MDM policy;
- project-local allowlists;
- explicit exception rows.

Do not infer trust anchors from presented bundles. Do not let a certificate chain install its own root.

### Verification verdict and caveats

Verdicts should be precise and humble:

```text
identity_match: yes/no/unknown
matched_reference: DNS-ID example.test / SPIFFE spiffe://... / redacted
path: accepted/failed/omitted
status: fresh/stale/absent/omitted
transparency: included/not-required/omitted/failed
pin: matched/new/changed/omitted
exception: none/reviewed/unsafe-denied
client_auth: absent/requested/selected/redacted
resumption: fresh/resumed/0rtt/denied
```

A green verdict can enable a channel. It should not imply local object import, secret release, or service authorization.

### Channel binding

Channel binding or TLS exporter material should be treated as a scoped proof hook:

- good for proving an app-layer challenge happened on this channel;
- bad as a user-visible bearer token;
- bad as durable authority after close;
- sensitive enough to redact or summarize by digest.

A useful UI row is `upper auth bound to channel: yes, exporter digest redacted, not reusable`.

### Session resumption and 0-RTT

Resumption state needs its own rail:

- session ticket / PSK identity;
- origin verifier profile that minted it;
- ALPN and SNI carryover;
- expiry and replay posture;
- whether early data was permitted;
- which operation class may ride early data.

Default posture: early data is disabled or read-only unless an explicit replay-safe policy exists.

### Current live secure channel

The live authority is the channel/proxy/handle that can carry bytes now:

- TLS/QUIC stream;
- SSH connection or channel;
- mTLS service stub;
- portal-owned secure session;
- object-capability RPC reference over secure transport;
- listener-side accepted channel.

The channel can close, expire, be revoked, lose rekey, or move to receipt-only state.

### Receipts

Receipts record:

- requested intent and reference identity set;
- verifier profile and redaction class;
- presented evidence summary;
- verdict/caveats;
- exception/pin adoption or denial;
- channel open/close state;
- exported/imported material references;
- resumption/0-RTT use;
- cleanup/residue.

Receipts are not live channels and cannot verify the future.

## Negative tests

- A peer-presented DNS name must not become the reference identity if the reviewed request named something else.
- A certificate chain must not install a trust anchor by being present.
- A CT SCT must not bypass local policy, quarantine, package admission, or service binding.
- A known-host first-contact adoption must not silently become a workspace-wide trust root.
- A channel-binding digest in a transcript must not be replayable as a bearer credential.
- A resumed TLS session must not carry write/mutation/export bytes as 0-RTT without a replay-safe cut.
- A TLS client certificate selection must not silently draw from ambient keychain or proxy state.
- A `verified` receipt must not reconnect or prove current verification.

## SlopOS pressure

The included SlopOS archive is design-stage, but its boundary family is exactly the right warning set:

- `network-lease-tls-verifier-boundary-v0.md` refuses to make a network lease a portable TLS verifier/trust-root/certificate-exception surface.
- `network-lease-client-cert-boundary-v0.md` refuses to make network reachability a portable client-certificate or mTLS identity seam.
- `network-lease-session-resumption-boundary-v0.md` refuses to smuggle tickets, PSKs, or 0-RTT into portable lease meaning.
- `certificate-path-input-boundary-v0.md` and `certificate-status-evidence-boundary-v0.md` keep path/status inputs explicit instead of ambient network/library behavior.
- `certificate-identity-evidence-boundary-v0.md` and `namecert-trust-root-boundary-v0.md` reinforce that identity evidence and trust anchors need local interpretation.

ViewFS should steal the separations, not SlopOS's exact schema.

## Nifty ideas to steal

- **Channel binder cards** for upper-layer auth tied to one live secure channel.
- **Cert braid drawers** showing reference IDs, presented IDs, path/status/CT evidence, and omitted fields as separate rows.
- **Trust-anchor chips** with local scope, source, epoch, and rotation posture.
- **Known-host ladders** for first-contact, unchanged, changed, revoked, and rotated host keys.
- **Transparency panes** that say `logged/auditable` without saying `trusted`.
- **Resumption shades** that dim stale/PSK/0-RTT paths and label replay-sensitive actions.
- **Client-auth shutters** that show whether a local keychain/HSM/SVID/token was selected, redacted, or absent.
- **Secure-channel ghost receipts** that remain useful for debugging but cannot reconnect.

## Non-decisions

Still open:

- whether ViewFS ever standardizes transport verifier profiles;
- whether trust-anchor inputs live in ViewFS, SlopOS, portals, a device policy system, or per-provider runtime policy;
- how much certificate/host-key/SVID detail to store versus redact;
- whether channel binding becomes a first-class object, a hidden proof hook, or both;
- whether session tickets/PSKs are persisted by providers, rooms, or never exposed;
- how to express mTLS client identity without leaking secrets or keyholder inventory;
- how to make browser/WebPKI, SSH, SPIFFE, DANE, QUIC, and capability-RPC identities comparable without flattening them.
