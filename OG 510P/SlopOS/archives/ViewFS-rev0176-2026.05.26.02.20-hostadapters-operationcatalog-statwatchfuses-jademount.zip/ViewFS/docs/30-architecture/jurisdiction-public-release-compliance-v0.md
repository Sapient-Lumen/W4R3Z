# Jurisdiction, public release, and compliance cards v0

ViewFS needs a way to talk about legal and organizational boundaries without pretending that it can decide all legal questions. Revision 169 adds a minimal executable lane for jurisdiction fences, release reviews, and shell compliance cards.

## Record families

| Record family | Purpose | Non-authority warning |
|---|---|---|
| `JurisdictionFence` | Source realm, allowed destinations, route epoch, export-control posture, license requirement, and egress authority. | A region label, local residency badge, or routing hint is not egress authority. |
| `PublicReleaseReview` | Reviewer-verified approval, current epoch, classification posture, redaction view, obligations, and publish/export authority. | A public label or old release receipt is not a release cut. |
| `ComplianceCard` | Shell projection of classification, license, jurisdiction, purpose, and release posture. | Cards are explanatory; they cannot claim live authority or clear-to-export without backing evidence. |

## Checked operations

`check_jurisdiction_fence` denies region-label shortcuts, stale routes, unapproved destinations, source-realm mismatch, missing export license posture, and missing egress authority.

`approve_public_release` denies public-label-only release, receipt replay, stale review epochs, unverified reviewers, blocked classifications, redaction leaks, missing obligations, and missing publish/export authority.

`render_compliance_card` permits honest inert cards but denies cards that claim live authority, unbacked clear-to-export status, or leaked blocked fields.

## Release does not mean forever-safe

A public release review is a bounded cut. It is not a guarantee that future copies, transformed outputs, downstream mirrors, search snippets, backups, or subject-access exports have the same posture. Release receipts must link to copy inventories, disclosure packages, retention roots, and derived-artifact ledgers if later review depends on them.

## Open decisions

ViewFS still does not choose a final legal taxonomy, license ontology, privacy regime, export-control regime, or declassification workflow. The v0 lane only fixes the first safety invariant: labels and compliance explanations can block or explain effects, but cannot create authority or erase the need for exact live handles and explicit cuts.
