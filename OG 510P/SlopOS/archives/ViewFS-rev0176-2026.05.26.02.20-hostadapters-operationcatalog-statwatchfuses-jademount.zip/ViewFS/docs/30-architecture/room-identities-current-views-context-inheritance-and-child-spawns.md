# Room identities, current views, context inheritance, and child spawns

This note keeps one high-value shell/terminal seam explicit while ViewFS and SlopOS are both still moving.

The future shell will almost certainly have things humans think of as **rooms**: tabs, panes, notebooks, runbook cells, detached helpers, restored layouts.
The dangerous mistake is to treat a room as if it automatically were:
- its current namespace,
- its child-inheritance policy,
- its next spawn plan,
- and its durable history row.

Those should stay distinct.

## The split

### 1. Room identity
A room is the durable interaction locus a human can:
- name,
- move,
- split,
- compare,
- search for,
- or restore.

A room may outlive one exact current view binding.
A room may also switch views without becoming a different room.

### 2. Current room-local view
This is the room's current explicit namespace / view truth now.
It answers questions like:
- what synthetic root is active,
- what current imports are bound,
- what provider-backed projections are usable here now.

This should be inspectable, but it should not pretend to describe how the next child room will be launched.

### 3. Context-inheritance posture
This is the room's current answer to:
- if I split, rerun, or spawn a helper from here, what context is even eligible to cross the boundary?

Good candidate posture classes:
- `inherit-none`
- `inherit-cwd-only`
- `inherit-named-bindings`
- `inherit-route-witnesses-not-handles`
- `inherit-reviewed-wallet-fragment`

This is a posture class, not a child yet.

### 4. Prepared spawn/import recipe
This is the reviewed action plan for a specific child/helper:
- which room/view basis it starts from,
- which imports or named bindings it asks for,
- which route/source witnesses it carries,
- what stays behind.

This is a prepared action.
It should be diffable, saveable, and explainable before commit.

### 5. Child-received bindings
After spawn/import, the child may have:
- fewer bindings than requested,
- granted imports but no live binds yet,
- a different view from the parent,
- a subset due to portal/provider refusal,
- or nothing at all plus a receipt.

That current child truth should remain separate from both the parent room and the recipe that proposed it.

### 6. Receipt/history
Receipts should preserve what happened without reviving:
- the room,
- the current view,
- the current inheritance posture,
- or the child bindings.

## Product consequences

### Room badges
Every pane/tab should be able to show:
- room identity,
- current view label,
- inheritance posture badge,
- and whether the current chrome is live or receipt-only.

### Context diffs before split/spawn/rerun
Before the user creates a child room, the shell should show:
- `parent room now`
- `candidate child room`
- `imports requested`
- `imports already live`
- `imports requiring portal/user step`
- `history only` / `receipt only`

### Receipt-first restore
Restoring a room should restore:
1. layout and explanatory chrome,
2. room identity and labels,
3. saved recipe / receipt references,
4. and only then ask for any fresh imports/rebinds.

That avoids fake “everything is live again” behavior.

## Why this fits SlopOS well
Current SlopOS already leans toward:
- explicit views rather than ambient path opens,
- capability-safe shell posture,
- descriptive wallets,
- typed plumb messages,
- and portal/document-handle import seams.

That means ViewFS does **not** need to decide one final shell language or one final object-store schema in order to adopt this split.

## Good questions to keep open
- Can a room have no current view, but still have a saved recipe/receipt context?
- Are room identity and room layout the same thing, or should they be separate later?
- Do helper processes and user-visible child rooms share one recipe class or just one family resemblance?
- Can one recipe mention grouped authority bundles without those bundles being current parent-room authority?
- How should a room badge degrade when the child recipe is still valid but the live imports are gone?
