# Personalization, preferences, and recommendation custody v0

Revision 174 adds a checked lane for ViewFS personalization surfaces. These surfaces are useful because ViewFS should feel personal and adaptive, but they are dangerous because a profile row, preference, score, or suggestion can be mistaken for identity, consent, policy, or authority.

## Core split

| Surface | Can do | Cannot do |
|---|---|---|
| `UserProfile` | bind a subject, identity assertion, session, and policy epoch for UI personalization | prove identity by itself, grant authority, or override session checks |
| `PreferenceSet` | narrow shell behavior inside declared scopes | become policy, consent, or tool/write authority |
| `PersonalizationModel` | support ranking or adaptation when purpose and minimization evidence pass | become access authority, training consent, or source retention root |
| `RecommendationSet` | render scoped candidates and explanations | disclose private features, prove user intent, or open objects |
| `PersonalizationCard` | show why something was suggested or adapted | claim live authority, reveal sensitive features, or present model output as deterministic user truth |

The first product rule is pessimistic: **personalization may narrow and explain, but it must not authorize**. A preference can make a card quieter or a list denser. It cannot approve a tool call, export data, consent to training, or widen a view.

## Checked operations

- `verify_user_profile`
- `apply_preference_set`
- `admit_personalization_model`
- `render_recommendation_set`
- `render_personalization_card`

The fixture lane makes profile/personalization facts pass only when current binding, scope, purpose, minimization, redaction, and live narrow-purpose authority are present. It denies stale profile epochs, model-purpose gaps, private feature leakage, and shell cards that turn personalization into authority.
