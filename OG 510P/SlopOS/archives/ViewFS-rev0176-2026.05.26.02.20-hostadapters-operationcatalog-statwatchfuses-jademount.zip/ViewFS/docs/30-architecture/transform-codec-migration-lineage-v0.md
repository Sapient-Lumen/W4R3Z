# Transform, codec, migration, patch, and lineage lanes v0

ViewFS treats interpretation as a boundary crossing. A converted object, decoded rendering, schema migration, patch application, or lineage statement may be valuable evidence, but it is not the same artifact and not the same authority carrier.

## Records

`TransformPlan` records bind a source object, source handle, transform recipe, approval cut, lossiness posture, output object, and result handle. A plan may materialize a new object, but it does not preserve or mint the source handle unless a separate authority lane does so.

`CodecProfile` records bind media type, handler digest/pin, active-content posture, and safe-preview semantics. A media label is only a selector for a decoder profile; it is not proof the bytes are safe and not permission to execute active content.

`SchemaMigration` records bind source schema, target schema, current validator, loss disclosure, and result handle. A migrated object has its own identity and proof posture. It is not original-byte identity unless canonicalization/equivalence evidence says so.

`PatchSet` records bind observed base, current base, patch payload, authority-expansion posture, and result handle. Patches fail closed on stale bases. Patch summaries and diff explanations remain inert.

`LineageLink` records bind source hashes, transform steps, subject identity, and inspection authority. Lineage may support quality, reliability, and trust assessment; it does not grant source access.

## Operations

The checked operations are:

- `apply_transform_plan`
- `decode_codec_payload`
- `apply_schema_migration`
- `apply_patch_set`
- `verify_lineage_link`

## Non-authority rules

A transform recipe is not a read handle. A decoder profile is not safe execution authority. A migration receipt is not a current migration cut. A patch summary is not a write operation. A lineage receipt is not object access. A transformed output is not the original source unless a separate equivalence lane explicitly proves the statement being made.

## Failure posture

The first fixture set intentionally denies hidden loss, unpinned codecs, active-content previews, old schema validators, migration receipt replay, stale patch bases, patch-driven authority widening, incomplete provenance, ambiguous transform steps, and lineage-as-authority claims.
