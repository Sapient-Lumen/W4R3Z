# Supply-chain package admission v0

Revision 164 turns package installation into a checked anti-collapse lane. The aim is not to build a package manager. The aim is to prevent ViewFS from treating package names, SBOM rows, signed bytes, provenance statements, transparency entries, dependency ranges, or old receipts as if they were install authority.

## Minimal lane

```text
PackageEnvelope
  + DependencyPin[]
  + ProvenanceAttestation
  + TransparencyEntry
  + VerifierRoot
  + SandboxProfile
  + InstallPlan
  + live install handle
  -> admitted install effect
  -> receipt
```

Every successful install fixture must name the current authority carrier and the non-authority evidence that supported the admission cut. Evidence stays visible after the cut, but it does not become a reusable effect token.

## Required separations

| Surface | What it can do | What it must not become |
|---|---|---|
| Package name / locator | Select candidate metadata. | Install authority. |
| Package digest | Bind exact bytes. | Proof that the bytes are safe or authorized. |
| SBOM / inventory | Describe components. | Runtime authority or admission verdict. |
| Dependency pin | Fix exact source/digest. | Grant to fetch, run, or retain. |
| Provenance attestation | Explain how the subject was built. | Admission, policy allow, or execution authority. |
| Transparency entry | Prove inclusion in an append-only history under a trusted root. | Authority to install, invoke, or trust all transitive effects. |
| Verifier root | Admit a verification key/log root for a purpose and epoch. | Ambient trust over unrelated purposes. |
| Scanner verdict | Support an install-plan cut. | Authority without live install handle. |
| Install plan | Bind evidence, sandbox, approval, and live authority. | Permanent authority after the cut has been spent or revoked. |

## Fixture pressure

The new fixtures require:

- exact package digest match;
- verified package signature;
- provenance subject digest match;
- trusted builder where the plan names trusted builders;
- verified transparency inclusion;
- trusted, unexpired verifier root;
- exact dependency pins;
- clean/admitted package verdict;
- sandbox fit for requested package effects;
- approved install plan with a live install handle.

The denial fixtures intentionally cover common laundering cases:

- SBOM/package metadata used as authority;
- provenance subject mismatch;
- missing transparency entry;
- untrusted or expired verifier root;
- unpinned dependency;
- blocked/malicious dependency advisory;
- postinstall effect without explicit approval;
- malicious package verdict.

## Non-claims

This lane does not prove package safety, malware absence, reproducible builds, universal dependency closure, or supply-chain compliance. It only creates a small executable contract for ViewFS: package-evidence artifacts can support admission, but they cannot install or invoke by themselves.
