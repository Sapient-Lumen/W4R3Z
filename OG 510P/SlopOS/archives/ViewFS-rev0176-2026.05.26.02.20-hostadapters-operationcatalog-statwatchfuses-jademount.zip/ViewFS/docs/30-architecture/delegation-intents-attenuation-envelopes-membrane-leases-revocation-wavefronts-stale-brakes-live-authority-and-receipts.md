# Delegation intents, attenuation envelopes, membrane leases, revocation wavefronts, stale brakes, live authority, and receipts

Revision 146 goes deep on delegation and revocation after the secret-delivery seam. The aim is not to design the final capability export ABI. The aim is to keep the truths apart so ViewFS can later support object-store handles, explicit per-process namespaces, portal-mediated imports, capability loans, short-lived credentials, and durable revalidation without lying about revocation.

## Why this split matters

Delegation looks simple in demos: send a handle, show a share badge, later press revoke. Real systems are uglier.

A raw copied handle may be impossible to recall without tearing down the recipient or rotating the target. A revocable proxy may stop future calls but cannot undo effects already committed through it. A short-lived token may expire cleanly but not offer immediate recall. A provider revocation endpoint may accept the request but propagate slowly or cascade according to provider policy. A local receipt may say a request was made while an offline recipient still holds a stale copy. A caveat list may look narrow in the UI while enforcement actually lives at a broker, verifier, membrane, or use-site epoch check.

ViewFS needs those differences visible early. Otherwise a future object store or shell will accidentally promise global revocation while only implementing expiry, or will display old receipt rows as if they prove nobody can still act.

## The classes

### Delegation intent / share ask

A prepared request: who wants to give what, to whom, for which purpose, by which route, and under which requested bounds. This can be saved, reviewed, denied, compared, or promoted. It is not live authority.

### Attenuation envelope / caveat set

Declared narrowing terms: `read only`, `until 17:00`, `for this object`, `for this provider audience`, `no redelegation`, `three uses`, `same room`, `same user presence`, `quarantine only`, or `safe-open only`. These are critical review material, but not proof that enforcement exists.

### Membrane lease / revocable proxy

A current proxy, broker session, wrapper, or lease gate that actually checks bounds before forwarding. If ViewFS chooses a membrane path for a seam, the membrane is the authority surface. Its descriptor and receipt remain evidence.

### Delegated handle / imported stub

The recipient-facing authority or adopted reference. This may be a local handle, an RPC stub, an object-capability reference, a bearer token, a file-descriptor-like projection, a portal session, or a provider-owned grant. The UI must show which family it is, because revocation and propagation differ.

### Revocation request / recall act

A request to stop future use, invalidate a token, close a membrane, rotate material, deny renewal, remove a grant row, or tell a provider that a token is no longer needed. It is an action, not the final world state.

### Revocation wavefront / checkpoint

A bounded account of what has observed the recall: local membrane closed, provider accepted, broker epoch advanced, recipient notified, capability table slot cleared, stale use denied, offline descendant unknown, propagation pending. Wavefronts are useful precisely because they are partial.

### Stale-handle brake / death verdict

The use-site refusal or degraded state that prevents stale authority from becoming effects: `revoked`, `expired`, `generation mismatch`, `target changed`, `basis drift`, `issuer unavailable`, `policy now denies`, `offline copy cannot be checked`, or `receipt only`. Death verdicts are repair routing, not just errors.

### Renewal / redelegation control

The separate authority or evidence needed to extend, refresh, rotate, reissue, or delegate onward. Do not imply it from ordinary use. A recipient may be able to use a handle but not renew it. An issuer may be able to revoke but not rotate. A broker may be able to renew only with current provider proof.

### Live authority now

The present ability to cause effects. ViewFS should favor explicit current handles/proxies/sessions over strings, descriptors, receipts, and old indexes. A future design may support several live authority families, but each should remain explicit.

### Receipt/history

Receipts explain: issued, attenuated, imported, used, expired, revoked, not found, provider accepted, provider maybe pending, broker closed, stale use denied. They do not contain bearer material and cannot reacquire authority.

## Lessons worth stealing

### seL4: revocation becomes tractable by tracking derivation

seL4 can mint derived capabilities with reduced rights and revoke derived capabilities recursively through its capability derivation machinery. The useful ViewFS lesson is not "copy seL4's kernel data structure." The lesson is that strong revoke claims require derivation knowledge and explicit authority topology; absent that, the shell should not promise subtree revocation.

### SlopOS D-LEASE: proxy authority is different from descriptor evidence

The included SlopOS D-LEASE posture says a lease proxy is the authority, CH-CAPLEASE is evidence, raw cap export is forbidden in v0, renewal needs explicit authority, and time is not ambient authority. ViewFS should mirror that discipline for delegated object-store handles and portal imports: a lease descriptor can be excellent explanation while the proxy remains the only enforcing surface.

### Epochs/indirection: coarse revoke can be useful, but it is not selective magic

SlopOS RFC-0019's epoch/indirection split is a good mental model. Epoch checks can make `all old caps to this object fail` cheap, but are coarse. Membranes can make selective revoke possible, but only when raw authority does not leak around them. ViewFS should preserve both options as design vocabulary without standardizing either globally.

### Macaroons and UCANs: delegation chains need caveat and revocation humility

Macaroons show how bearer credentials can carry contextual caveats that attenuate use. UCANs show public-key verifiable, delegable, local-first capability chains plus explicit revocation work. Both are useful. Both also sharpen a warning: cryptographic delegation evidence is not the same thing as a live local handle, a proxy, or a global knowledge that all copies stopped.

### OAuth and cloud credentials: revocation and expiry are different repair paths

OAuth token revocation gives a provider-local way to tell an authorization server a token is no longer needed; temporary cloud credentials show the value of explicit short lifetimes. ViewFS should steal expiry visibility, targeted teardown, and reacquire flows. It should not import a generic disconnected/account-state truth from one provider's revocation response.

### Capability URLs: bearer strings are useful and dangerous

Capability URLs make designation and authority one string. That can be convenient for one-shot flows, but URLs leak through logs, referrers, screenshots, chat, history, and bookmarks. ViewFS should treat URL-shaped or sturdyref-shaped delegation as high-risk bearer material, not as ordinary names or receipt text.

### CapTP / Workers RPC: received references make authority visible

Object-capability RPC systems keep a simple rule: you can use an object only if you have received a reference/stub to it. That is the right mental posture for ViewFS live handles. The revocation question should stay separate: how was the reference obtained, who can close it, what can be attenuated, and what happens to queued or offline work?

## Design guidance

1. Use **short lifetimes** and **bounded membranes** before promising global revocation.
2. Prefer **attenuation by construction**: mint/narrow/wrap rather than grant broadly and rely on later recall.
3. Make enforcement origin explicit: `raw handle`, `proxy-enforced`, `verifier-checked`, `provider-owned`, `expiry-only`, `descriptor-only`, `history-only`.
4. Preserve wavefront partiality: `accepted by provider` is not `all recipients stopped`; `local proxy closed` is not `bearer copies erased`.
5. Keep old receipts and wallet rows non-authoritative and redacted.
6. Treat revocation as a future-use control; never claim it undoes already committed writes, messages, payments, launches, or exports.
7. Route stale denials to exact repair verbs: `reacquire`, `ask issuer`, `renew`, `rotate`, `make local copy`, `open read-only`, `history only`.
8. Do not let UI summarization erase the difference between expiry, recall, delete, provider denial, policy drift, and object disappearance.
9. Keep re-delegation and promotion to durable reopen explicit, not an accidental side effect of successful use.
10. Assume bearer-material compatibility will exist somewhere; isolate it, label it, redact it, and avoid placing it in logs/indexes by default.

## Non-decisions to preserve

Do not decide yet:

- one revocation data structure;
- one distributed-object protocol;
- one token/caveat language;
- one exact wavefront schema;
- one provider or broker role;
- whether selective live revocation is Phase 1, Phase 2, or profile-specific;
- how much recipient topology can be shown to users;
- whether ordinary object identity embeds revocation epoch, or epochs live beside object state;
- whether replay/retry after revocation is denied, re-consented, or converted to a fresh delegation intent.

## Shell implications

The shell should be able to render:

- **delegation cards**: source, recipient, requested authority, route, attenuation, redelegation posture;
- **caveat chips**: terms as review claims;
- **membrane lamps**: where enforcement actually lives;
- **revocation wave maps**: local/broker/provider/recipient/offline/pending states;
- **stale brakes**: exact reason for failure and one honest repair verb;
- **recall receipts**: attempt, known outcome, unknowns, irreversible effects, residue obligations;
- **rotate/reissue ladders**: fresh authority without replaying old tokens;
- **who-still-can drawers**: redacted known-state views that never expose bearer material.

## Load-bearing guardrail

**Revoked** is not one boolean. It can mean request accepted, proxy closed, epoch advanced, token invalidated, renewal denied, provider propagation pending, stale use denied, object re-keyed, recipient offline, or history only. ViewFS should show which meaning applies or refuse the stronger claim.
