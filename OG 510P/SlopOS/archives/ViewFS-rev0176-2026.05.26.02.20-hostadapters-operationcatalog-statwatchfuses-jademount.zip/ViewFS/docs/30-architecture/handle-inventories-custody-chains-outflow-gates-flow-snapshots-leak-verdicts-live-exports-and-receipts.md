# Handle inventories, custody chains, outflow gates, flow snapshots, leak verdicts, live exports, and receipts

Revision: 139  
Date: 2026-05-13  
Codename: flowmaps-custodybadges-leakalarms-silverloom

## Why this exists

Revision 138 gave ViewFS a careful launch/import split: a process gets a planned view, bound roots, slot table, portal import tickets, live binds, and receipts as separate things.

Revision 139 extends the same discipline past launch. Once a process is alive, authority moves. It gets borrowed, attenuated, proxied, imported, materialized to bytes, exported to helpers, revoked, leaked, audited, and described. The design risk is that ViewFS will discover SlopOS's capability-graph and capability-diff ideas, love them, and accidentally treat an explanatory graph as if it were the authority graph itself.

This document prevents that collapse.

## SlopOS pressure points worth stealing

The separately supplied SlopOS rev0695 archive and the embedded SlopOS subtree both point toward the same useful posture:

- `capability-graph-schema-v0.md` treats capability graphs as bounded, redacted, debug/audit snapshots rather than raw pointer dumps.
- `capability-diff-schema-v0.md` treats authority changes as bounded, deterministic, redacted diffs for consent, receipts, and regression tests.
- `capability-export-schema-v0.md` treats cross-boundary authority export as an explicit canonical object, with proxy-first posture and no raw tokens in logs.
- `capability-wallet-schema-v0.md` treats wallet rows as summaries, not bearer authority.
- `portal-design-playbook.md` insists that portal grants return handles, requests are control state, transcripts are possible, and redaction comes first.
- `capshell-handle-table-posture-v0.md`, `capshell-cwd-root-posture-v0.md`, and `capshell-filesystem-posture-v0.md` keep shell execution posture visible instead of relying on inherited process folklore.

The thing to steal is not one final schema. The thing to steal is the habit of distinguishing **live authority**, **debug explanation**, **delegation/export ceremony**, **human review**, and **durable evidence**.

## Seven lanes

### Lane A — current handle inventory

A current handle inventory is a subject-local truth: which handles can this subject exercise now?

Recommended fields for early diagrams and prototypes:

- subject-local slot id;
- local display label;
- handle family (`object_read`, `object_write`, `folder_projection`, `portal_doc`, `provider_proxy`, `capstore_commit`, etc.);
- rights summary;
- live/dead state;
- currentness witness, when known;
- revocation posture;
- outflow gate reference;
- custody pointer.

Do not include raw provider secrets in the inventory surface. If raw material exists, keep it under a lower layer and expose only a redacted handle label upward.

### Lane B — custody chain

A custody chain explains where the handle came from. Early examples:

| custody kind | meaning |
|---|---|
| `launch_root` | placed into the subject by a launch view plan and root binding |
| `portal_import` | imported through a portal consent/import ceremony |
| `self_created` | created by this subject from authority it already had |
| `attenuated_from` | narrowed from another handle |
| `borrowed_from_parent` | borrowed under parent-controlled lifetime/posture |
| `provider_proxy` | backed by a provider-side proxy rather than raw object authority |
| `reopened_from_descriptor` | restored through an explicit descriptor/reopen mechanism |
| `materialized_from_bytes` | derived from bytes/artifact rather than original authority |

Custody is explanatory and often receiptable. It is still not permission.

### Lane C — outflow gate

Every handle family should have an outflow gate even before the final handle ABI exists. This keeps diagrams honest.

Candidate gate ladder:

| gate | allowed outflow |
|---|---|
| `non_passable` | no export; only local use |
| `same_room_borrow` | borrow within one authority room/session; must return or die with borrower |
| `child_launch` | may be placed in a child launch plan after review |
| `portal_export` | may leave only through a portal-mediated export ceremony |
| `proxy_only` | recipient gets a proxy/facet, not raw authority |
| `bytes_only` | only content bytes or derived artifacts may leave |
| `receipt_only` | only an audit summary may leave |

The point is to avoid a generic `share` verb. ViewFS should ask **what kind of leaving is this?**

### Lane D — flow snapshot and diff

A flow snapshot is a bounded, redacted description of live authority at a moment. A flow diff describes a change between two snapshots or between a planned and realized state.

They are useful for:

- launch review;
- portal consent;
- regression tests;
- leak tests;
- explaining why a process can still touch an object;
- comparing a user's preview with the actual imported handles;
- producing receipts without including raw secrets.

They are dangerous if they become serialized authority. Therefore early ViewFS snapshots should be explicitly marked non-authoritative, redacted, scope-limited, and expiration-shaped when displayed.

### Lane E — confinement and leak verdict

A leak verdict is a judgment over a flow. It should have:

- analyzed scope;
- expected boundary;
- actual observed outflow;
- verdict;
- evidence snapshot/diff digest;
- uncertainty or blind spots;
- remediation hint.

Example verdict vocabulary:

- `ok_no_unexpected_outflow`;
- `unexpected_handle_live_after_exit`;
- `outflow_gate_widened`;
- `receipt_missing_for_live_export`;
- `receipt_exists_but_handle_dead`;
- `path_escape_attempt_blocked`;
- `portal_grant_not_subject_bound`;
- `provider_proxy_unclassified`.

The verdict is a test/result object. It is not the enforcement mechanism.

### Lane F — live export / proxy / borrow

A live export is current authority in another subject. It should be represented separately from the export request and the export receipt.

Early diagrams should distinguish at least:

- direct handle transfer;
- borrowed handle with lifetime boundary;
- revocation-aware proxy;
- attenuated child handle;
- one-shot send right;
- provider-local delegated authority;
- byte materialization with no authority transfer;
- receipt-only notification.

This split is essential because users and developers will otherwise confuse `I shared it once` with `they can still use it now`.

### Lane G — durable receipt/history

Receipts tell a reviewable story. They do not exercise power. They may include:

- operation id;
- actor/subject labels;
- redacted handle summaries;
- custody delta digest;
- outflow gate checked;
- currentness witness checked;
- portal session id or review transcript digest;
- result;
- revocation/expiry hint;
- follow-up leak verdict digest.

Receipts should be rich enough for accountability and weak enough that copying them does not copy authority.

## Past lessons mapped to ViewFS

### Confused deputy

The classic failure is letting one subject wield its own authority for another subject's unchecked designation. ViewFS should therefore avoid path-based APIs that let a less-authorized caller ask a more-authorized service to open `some/path` under the service's authority. A request should carry a handle, import ticket, or explicit designation plus caller/purpose/custody information.

### Capability URLs

Bearer URLs teach a negative lesson. A string that designates and authorizes can leak through logs, screenshots, clipboard, shell history, crash reports, metrics, referrers, and filenames. ViewFS should prefer non-authoritative summaries in visible surfaces and keep bearer material below the visible boundary.

### Per-process namespace systems

Plan 9, Fuchsia, Capsicum, WASI, `unveil`, Landlock, and `openat2` all reinforce the same caution: a program should not inherit an unbounded ambient filesystem just because it is convenient. But even perfect launch-time scoping is incomplete if post-launch handle flow is invisible.

### Capability systems

seL4, Cap'n Proto, WIT, Tahoe-LAFS, and Sandstorm all suggest different but compatible ideas: slots/tables, interface references, owned/borrowed resources, cap flavors, and powerbox-mediated grants. ViewFS should preserve these distinctions while resisting the urge to choose one entire system too early.

### Cloud and transactional stores

S3, GCS, Azure Blob Storage, and etcd all teach that mutation without currentness checks becomes stale-write folklore. For ViewFS, that means flow/adoption/export operations should leave room for generation, etag, revision, lease, epoch, or equivalent witnesses without pretending one provider's witness is universal.

## Low-regret tests to add later

These tests do not require the final ABI:

1. **Receipt is not authority** — copying a receipt file into a process gives no new handle.
2. **Snapshot is not authority** — importing a flow snapshot gives no raw access.
3. **Wallet row is not authority** — wallet summaries cannot be used as bearer handles.
4. **Portal ticket is not live bind** — a request/session object cannot be used as the imported object.
5. **Custody chain cannot widen rights** — changing custody metadata never adds live rights.
6. **Outflow gate survives UI synonyms** — `share`, `send`, `open with`, and `attach` must choose explicit gates.
7. **Dead handle still receipted** — a durable receipt can remain after the handle is revoked/dead.
8. **Live export visible** — if another subject still has authority, some live/export/proxy lane can show it.
9. **Path escape blocked is not object proof** — a blocked path escape proves only that the escape was blocked, not that the intended object was accessed.
10. **Currentness stale is explicit** — stale generation/etag/revision/epoch checks produce named outcomes.

## Design non-decisions

Keep these open:

- whether the canonical ViewFS handle is fd-like, object-ref-like, cap-table-index-like, RPC-reference-like, or mixed;
- whether the shell stores flow snapshots in the object store or in an audit/event channel;
- whether custody chains are linear, DAG-shaped, receipt-linked, or reconstructed;
- whether every handle has one outflow gate or a gate matrix by recipient/action/context;
- whether leak verdicts are produced by SlopOS, ViewFS, providers, a shell harness, or external assurance tooling;
- whether import/export/reopen receipts use one family or many;
- whether remote proxy handles are revocation-first, lease-first, provider-first, or session-first.

## Tiny vocabulary card

Use these words carefully in future docs:

- **slot**: a current subject-local place where a handle is held.
- **handle**: current exercise-able authority, or a handle-shaped reference whose exercise is mediated by another layer.
- **custody**: provenance/explanation, not authority.
- **gate**: policy posture for leaving the subject, not the transfer itself.
- **snapshot**: redacted explanatory state, not a cap table dump.
- **diff**: redacted explanatory change, not the operation.
- **verdict**: analysis result, not enforcement.
- **export**: actual authority crossing, or an explicit non-authority materialization mode.
- **receipt**: history, not current power.
