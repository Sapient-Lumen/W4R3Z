# Durable root commits, epoch fences, restore intents, activation targets, live binds, and receipts

Revision: 140  
Date: 2026-05-13  
Codename: rootledgers-epochfences-restorerails-ironmoss

## Purpose

This note turns RFC 0127 into an architecture guardrail for the ViewFS datacube.

The core warning is simple: **persistence is not reopening**. A stored root, checkpoint, capstore commit, receipt, or durable descriptor is not a live namespace, not a live handle table, and not a promise that old authority may safely come back.

SlopOS is still in design. ViewFS is still in design. That is exactly why this split should be preserved now.

## Why this belongs in ViewFS

ViewFS wants a brand-new object store with capability handles, explicit per-process namespaces, and portal-mediated imports. That combination will eventually need some answer for durable roots:

- users will expect objects to survive restart;
- workspaces will want stable named roots;
- portals will want durable import anchors;
- rooms will want restart and rollback affordances;
- shells will want time-travel and repair previews;
- providers will want currentness and revocation checks;
- SlopOS may offer CapStore-like storage, but the exact boundary is not final.

The dangerous shortcut is to say: `saved root == reopenable namespace == current handles`. That shortcut is where rollback, confused persistence, and capability resurrection bugs live.

## Architecture lanes

### A. Durable root commit lane

This lane records durable facts:

```text
root_commit
  id: digest(canonical record)
  parent: digest | none
  root_updates: [root_name -> object/manifest/ref]
  artifact_refs: [digest, size, profile]
  durable_ref_rows: [typed descriptors only]
  signatures/provenance: optional
  declared_epoch: witness summary
```

Low-regret rule: root commits may reference authority descriptors, but they should not embed live handles, raw bearer strings, or raw secret material.

### B. Epoch fence lane

This lane decides whether a root update is admissible with respect to rollback/currentness:

```text
root_tip_witness
  scope: root | room | provider | issuer | cluster
  expected_old: digest/revision/generation/etag/epoch
  observed_new: digest/revision/generation/etag/epoch
  comparison_profile: exact | provider-validator | monotonic-only | dev-rollback
  verdict: pass | stale | rollback | unknown | profile-unsupported
```

Low-regret rule: object identity and currentness evidence stay separate. A content digest can prove exact bytes but not that this root is the current safe root.

### C. Restore intent lane

This lane records the request to inspect, repair, resume, roll back, or activate:

```text
restore_intent
  actor: local subject / manager / portal / recovery tool
  purpose: inspect | resume | repair | rollback | activate | export
  candidate_root: digest or provider ref
  requested_authority: none | read | edit | publish | launch
  basis: receipt/ref/witness summary
  deadline: optional
```

Low-regret rule: restore intents are plans or requests. They do not carry authority until admitted.

### D. Resurrection gate lane

This lane converts stored descriptors into current authority only when allowed:

```text
resurrection_gate
  descriptor_family: docref | sturdyref | keyref | secretref | portal_anchor | provider_ref
  issuer_currentness: epoch/revision/unknown
  subject_fit: pass | ask_again | deny
  revocation_state: live | revoked | expired | unknown
  provider_match: same | stale | missing | inaccessible
  result: admit | read_only | ask | deny | receipt_only
```

Low-regret rule: dormant authority-shaped material needs a gate, not a JSON parser.

### E. Activation target lane

This lane chooses what should become current:

```text
activation_target
  level: boot | room | workspace | process | view
  candidate: root_commit / namespace_plan / repaired_head
  mode: preview | read_only | live | dev_rollback | quarantine
  required_gates: [gate ids]
  expected_slot_shape: optional
```

Low-regret rule: activation is a currentness/routing choice. It is separate from storage and separate from handle installation.

### F. Live bind / handle-set lane

This lane is the only one that says present power exists:

```text
live_handle_set
  subject: process/room/session local id
  root_slots: [slot -> handle]
  rights: [inspect/read/edit/publish/...]
  custody: restored/activated/portal-gated/provider-proxy
  live_state: usable | borrowed | proxy | dead
```

Low-regret rule: if the shell cannot show a current live slot/bind/proxy, it should not imply current power.

### G. Receipt lane

This lane records what happened without reopening it:

```text
restore_receipt
  root_recorded: yes/no
  fence_verdict: pass/stale/rollback/unknown
  gate_verdicts: [...]
  activation_verdict: not_requested/preview/activated/denied
  live_slots_installed: digest(summary) | none
  limitations: read_only/quarantined/dev_rollback/receipt_only
```

Low-regret rule: a restore receipt can explain an activation. It should not be consumed as a handle.

## SlopOS datacube reading

The current SlopOS material offers excellent pressure:

- `capstore-commit-schema-v0.md` keeps root updates, parent commits, epochs, artifacts, signatures, and durable refs explicit.
- `rfcs/0065-orthogonal-persistence-and-capstore.md` says durable authority is explicit and optional, not ordinary process memory by default.
- `view-namespace-posture-v0.md` says namespaces are explicit view objects, not a privileged global `open(path)` resolver.
- `capshell-cwd-root-posture-v0.md` says cwd is a bound root, not an advisory pathname.
- `capability-wallet-schema-v0.md` says wallet rows are descriptive and non-authoritative.
- `keyref-schema-v0.md` and `secretref-schema-v0.md` keep key/secret persistence reference-shaped rather than raw secret-shaped.

ViewFS should steal the separations, not blindly adopt every schema.

## Historical lessons mapped to ViewFS

### KeyKOS / EROS / CapROS

These systems show that persistent capability systems can be coherent and powerful when persistence, authority, and recovery are one design. They also warn that persistence is a whole-system commitment. ViewFS should not smuggle it in as a file-format convenience.

### Tahoe-LAFS

Tahoe's immutable and mutable capability flavors are useful because they teach that fixed content, mutable slots, read/write power, read-only power, and verify-only evidence are different classes. ViewFS root commits should preserve that distinction and avoid making every durable locator a write-cap.

### Macaroons / zcaps

Caveated delegation is valuable, especially for bounded restore/import flows. But durable, copyable authorization documents and bearer tokens are sensitive. ViewFS should prefer typed descriptors plus current gates, not raw tokens in root commits or logs.

### Object stores and consensus stores

S3, GCS, Azure Blob, and etcd all expose some version of compare-before-mutate. ViewFS should generalize the lesson: any root commit, activation, adoption, or resurrection that depends on currentness should name the expected witness and the mismatch verdict.

### Explicit namespace systems

Fuchsia, Plan 9, Capsicum, WASI, `openat2`, Landlock, and `unveil` help keep launch/runtime authority explicit. But durable restore still needs its own gates: a safe launch namespace assembled from unsafe old roots is still unsafe.

## Recovery modes worth preserving

### Inspect-only recovery

Open the root commit in a quarantine/time-capsule viewer. No writes. No portal rebinds. No provider reconnection unless explicitly requested.

### Read-only restore

Revalidate enough to expose read facets, but do not re-enable edit/publish authority or child-launch exports.

### Repair staging

Let providers/materializers fetch missing artifacts, compare witnesses, and propose a repaired root without making it live.

### Live activation

Only after the fence and resurrection gates pass should the shell install live slots/binds into a real process or room.

### Developer rollback

Allow unsafe rollback only in a visibly labeled dev/test profile. Receipts should carry the warning so later reports do not mistake it for production posture.

## Object-store implications

A future ViewFS object store can remain deliberately under-decided while still preserving these design constraints:

- immutable object identity and root-tip currentness are different;
- root commit parentage and user activation choice are different;
- a portal import anchor and a restored portal live handle are different;
- a key/secret reference and a usable key/secret handle are different;
- GC roots and authority roots are related but not identical;
- read-only recovery surfaces are not edit authority;
- rollback support is a feature only when fenced, previewed, and receipted.

## Invariants to test later

- Durable root commits contain no raw live-handle material.
- A restored process receives a new explicit handle-slot table.
- Rolling back past a revocation epoch fails unless a loud dev profile is active.
- Stored portal anchors require current portal verdicts before live import.
- Secret/key refs are resolved only by current providers through live handles.
- Receipts can be copied freely only if they are non-authoritative and redacted.
- Activation targets that fail gates leave no partial live bind except explicitly labeled staging handles.

## Non-decisions

Still open:

- one final root-commit schema;
- one final epoch/fence family;
- whether durable roots are per-user, per-room, per-workspace, per-object-family, or mixed;
- how much CapStore becomes ViewFS versus SlopOS substrate;
- whether persistent live capabilities are ever supported;
- how restore UI balances safety and power;
- whether rollback is a first-class user feature or mostly a recovery/developer lane;
- whether durable root commits are append-only, tree-shaped, log-shaped, database-shaped, or provider-native.
