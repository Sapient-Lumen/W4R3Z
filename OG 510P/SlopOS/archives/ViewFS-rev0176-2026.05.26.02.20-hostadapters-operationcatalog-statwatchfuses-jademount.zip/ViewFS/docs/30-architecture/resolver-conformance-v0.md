# Resolver conformance v0

Revision 157 promotes compatibility pathwalking from one escape fixture into a small conformance surface. ViewFS still treats paths as compatibility projections over explicit view binds, not as authority. The new change is that denial reasons become typed: escape, symlink crossing, magic/synthetic crossing, mount/device crossing, missing bind, and bound-handle-right failure are separate outcomes.

## Why this exists

A path membrane that only says `not found` or `permission denied` is too easy to launder. It can hide whether the caller tried to leave the rooted view, cross a synthetic host path, follow a symlink, step into a different mounted authority realm, or select a live bind without the requested right.

Linux `openat2` influenced the fixture vocabulary: `RESOLVE_BENEATH`, `RESOLVE_IN_ROOT`, `RESOLVE_NO_MAGICLINKS`, `RESOLVE_NO_SYMLINKS`, and `RESOLVE_NO_XDEV` show that safe path resolution needs explicit resolver policy. WASI filesystem path rules add a second pressure point: relative paths are interpreted under a descriptor, and reaching outside that base is not permitted. ViewFS borrows the shape, not the ABI.

## Record lane

`PathNode` is a resolver witness, not authority.

```text
PathNode(id, view, path, kind, target?)
```

`kind` currently exists only for fixture pressure:

- `symlink` — a symbolic-link-like path node;
- `magic` / `magic_link` — synthetic or host-kernel-like link whose target may escape ordinary namespace expectations;
- `mount` / `xdev` — crossing into another device, provider, mount, or authority realm;
- `blocked` — explicit local policy block.

A `PathNode` cannot read or open. A `Bind` still supplies the handle, and a live handle still supplies authority.

## Fixture lanes

- `021-compat-symlink-crossing-denied.json` refuses symlink crossing when `no_symlinks` is active.
- `022-compat-magic-link-crossing-denied.json` refuses magic/synthetic crossing when `no_magic` is active.
- `023-compat-mount-crossing-denied.json` refuses mount/provider crossing when `no_xdev` is active.

Together with the earlier path escape and path allow fixtures, these fixtures define the first resolver conformance corpus.

## Denial receipts

A future implementation should emit denial receipts with at least:

```text
view
root
requested path
normalized candidate, if safe to disclose
resolver flags
blocking path node, if any
selected bind, if any
selected handle status, if any
stable denial reason
ambient fallback attempted? always explicit
```

The shell may redact `normalized candidate` or `target` for secrecy, but it must not collapse the denial into generic failure when the distinction matters for repair or audit.

## Non-claims

- This is not a POSIX path-resolution ABI.
- This is not a promise to preserve Linux errno names.
- This is not a full symlink model.
- This is not a mount namespace design.
- This does not make host paths authoritative.

The purpose is narrower: keep compatibility path handling falsifiable before a real implementation exists.
