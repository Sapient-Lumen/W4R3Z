# Service designators, discovery snapshots, readiness claims, binding cuts, activation targets, live handles, advertisements, and receipts

Revision 149 adds a conservative service-discovery seam for ViewFS. It follows the network lease work, but it is not just more networking. Service discovery touches namespaces, object-store catalogs, portals, capability RPC, local IPC, mDNS/DNS-SD, Kubernetes-like service abstractions, xDS-like control planes, socket activation, package/admission evidence, and shell suggestions.

The design goal is simple: **do not let discovery metadata become live service authority**.

## Why this matters for ViewFS

ViewFS wants:

- an object store;
- capability handles;
- explicit per-process namespaces;
- portal-mediated imports;
- a shell that explains authority instead of hiding it.

A service-discovery layer can break all four goals if it becomes an ambient lookup plane. A process with no object roots can still act with power if `db`, `printer`, `vault`, `support`, or `indexer` resolves through a global service registry. A safe-open viewer can leak metadata if it browses local services. A workflow can become confused if a health check, identity claim, or old receipt is treated as permission. A launch namespace can look explicit while a hidden service directory recreates `/usr/bin` or `/var/run` folklore.

## Main distinctions

### Service intent

A service intent says what the actor is trying to do:

- discover / browse;
- resolve / select;
- bind / adopt;
- invoke / stream;
- listen / accept;
- advertise / register;
- activate / warm;
- import / materialize returned objects;
- export / send object data;
- subscribe / watch.

The same string `printer` can appear in many intents. The intent is part of the authority story.

### Service designator

A designator can be:

- a friendly name;
- a DNS-SD type or instance;
- a DNS SRV/SVCB/HTTPS service-binding name;
- a Kubernetes Service name or label selector;
- a Consul-like service registration name;
- an xDS resource name;
- a local socket/unit name;
- a DID service entry;
- an MCP resource/tool row;
- an object-store catalog key;
- a project-local alias;
- a package/bundle-declared service claim.

A designator is not a handle. It needs an explicit catalog/discovery authority before even candidate lookup is legitimate.

### Discovery authority / catalog root

The catalog root is the authority to ask:

- this project service directory;
- this portal-owned resolver;
- this local-link discovery surface;
- this object-store catalog handle;
- this service-mesh control plane;
- this Kubernetes API view;
- this provider-specific registry;
- this safe-open viewer's deliberately empty service scope.

Without the catalog root, service designators are inert text.

### Discovery snapshot / candidate set

A candidate set is bounded evidence. It might contain:

- instance names;
- target host/port classes;
- protocols;
- version claims;
- weights/priorities;
- zones/topology;
- readiness states;
- identity evidence digests;
- health-check summaries;
- omitted/private fields;
- policy-denied candidates;
- stale candidates;
- explanation rows.

Candidate sets can be very useful for UI and tests. They are not invokable by themselves.

### Readiness / health / serving evidence

Readiness should be multi-valued and humble:

```text
ready: yes/no/unknown
serving: yes/no/unknown
terminating: yes/no/unknown
last_seen: timestamp/epoch
freshness: current/stale/omitted
identity: matched/mismatch/omitted
policy: candidate/denied/needs-step-up
```

Do not overfit Kubernetes names, but steal the important shape: `ready`, `serving`, and `terminating` are different truths.

### Binding cut / admission decision

A binding cut is where local policy chooses a candidate for a purpose:

```text
subject: room/process/workflow
service: designator digest + catalog root
candidate: snapshot row digest
purpose: index project | print document | call support API
object scope: roots/facets permitted
network scope: public/local/loopback/none
secret scope: absent/slot/projection
policy epoch: exact
budget/ttl: exact
renewal: none/ask/policy
```

The binding cut is a decision record. It is not the actual live service authority.

### Activation target

Activation may involve:

- starting a provider process;
- importing a portal session;
- allocating a socket/listener;
- accepting a manager-passed file descriptor;
- warming a route;
- requesting a service proxy;
- binding object roots into a provider namespace;
- asking another runtime to materialize a service instance.

Activation targets are plans or transitions. The live handle is later and should be visible.

### Current live service authority

This is the authority-bearing object:

- object-capability service reference;
- portal-owned session handle;
- local IPC channel;
- network stream/dialer/listener;
- socket-activation fd;
- service proxy stub;
- request stream;
- capability table entry;
- process slot containing a live service handle.

This is what can actually invoke, accept, or carry requests now.

### Advertisement / publication

Publication is its own authority class:

- catalog registration;
- DNS-SD/mDNS advertisement;
- local service directory entry;
- public endpoint allocation;
- service mesh registration;
- object-store published name;
- route table update;
- shell suggestion row.

A service can be live but unadvertised, advertised but not live, local-only, project-only, public, or stale. Those states should be named.

### Receipts

Receipts record:

- discovery query and scope;
- candidate count and omitted classes;
- stale/denied candidates;
- binding cut;
- activation attempt;
- live handle mint/close;
- advertisement publish/withdraw;
- call result;
- cleanup.

A receipt cannot rediscover or invoke. It can only explain.

## Prior-art lessons

### DNS-SD and mDNS

DNS-SD is useful because it explicitly models service instance discovery using DNS records, with SRV and TXT information describing where/how an instance can be reached. ViewFS should steal the split between browse metadata and connection. It should not let a DNS-SD instance become a live handle.

mDNS is useful because it works on the local link without configured infrastructure. That is exactly why it is sensitive: local-link discovery reveals nearby devices and services. ViewFS local-discovery UX should therefore ride local-network shutters, not ambient lookup.

### Kubernetes Service and EndpointSlice

Kubernetes Services are useful because they decouple clients from dynamic backend Pods. EndpointSlices are useful because endpoint sets scale, update, and carry readiness/serving/terminating conditions. The ViewFS lesson is not to import Kubernetes. The lesson is that logical service identity, changing backend set, readiness signals, routing choice, and invocation are separate.

### xDS / service meshes

xDS is useful because control-plane resources are delivered by typed subscriptions, may be sequenced/warmed, and can carry TTLs. The ViewFS lesson is that configuration freshness and warming are not current user authority. A mesh route can help a portal create a handle; it should not become a hidden service grant.

### Socket activation

Systemd-style socket activation is useful because the service manager can hold/bind sockets and pass file descriptors to services at activation. The ViewFS lesson is handle honesty: a unit name or service label is not the fd; the fd is the live authority, and inherited/fd-store continuity must be explicit.

### SPIFFE / workload identity

SPIFFE is useful because it standardizes strongly attested workload identity across heterogeneous infrastructure. The ViewFS lesson is separation: service identity evidence can feed local binding/admission policy, but identity itself is not permission, not trust clearance, not object-store admission, and not caller authority.

## Anti-patterns

Avoid:

- `service://name` as a portable authority URL;
- hidden global service directories in every process;
- catalog browse permission implied by invocation permission;
- treating health green as safe/trusted/admitted;
- treating identity match as authorization;
- auto-advertising listeners;
- auto-listening from advertised service rows;
- turning old discovery receipts into retry authority;
- letting safe-open viewers browse local network services by default;
- letting package/bundle metadata register executable services without local admission;
- letting service results bypass quarantine/import/admission lanes.

## Negative tests to add later

- A process with a service designator but no catalog root cannot browse or invoke.
- A catalog browse snapshot cannot invoke a candidate.
- A healthy/ready candidate cannot bypass binding/admission.
- A bound service with expired TTL cannot mint a live handle without renewal.
- A live service handle can invoke only within its route/object/network/secret budget.
- A listener does not advertise unless publication authority exists.
- An advertisement row cannot accept traffic unless a live listener/route exists.
- A receipt cannot rediscover, reconnect, rebind, reopen, or invoke.
- A safe-open document cannot trigger mDNS/DNS-SD browse without explicit local-discovery authority.

## Near-term design posture

For now ViewFS should add language, tests, and shell affordances, not a final API. Future proposals should state which lane they touch:

```text
service intent
service designator
discovery/catalog authority
discovery snapshot / candidate set
readiness / health / identity evidence
binding cut / admission decision
activation target / route warming
current live service authority
advertisement / publication
receipt / history
```

That gives SlopOS, ViewFS, and sibling cubes room to evolve without losing the anti-collapse guardrail.
