# Network intents, resolution witnesses, connection leases, stream handles, local exposures, egress cuts, live authority, and receipts

Revision 148 adds a deliberately careful network seam. It does not define ViewFS networking. It prevents one bad future default: treating **network allowed** as a single bit that bypasses the capability store, portal imports, safe-open lanes, secret handling, and object-store evidence.

## The seam

Keep these truths apart:

1. **NetworkIntent** — who wants what kind of network operation, for which purpose and workflow.
2. **DestinationDesignator** — URL, hostname, canonical ASCII label, suffix, service label, IP prefix, loopback/local/public class, port, scheme, or route capsule.
3. **ResolutionWitness** — a bounded explanation of name canonicalization, resolver policy, answer set or selected family, TTL, and omitted facts.
4. **NetworkLeaseDescriptor** — the local policy cut: allowed scope, proto, port range, destination predicate, TTL, budget, renewal, and consent basis.
5. **LiveNetAuthority** — the current dialer, resolver, listener, stream, proxy, or portal handle. This is the thing that can act.
6. **StreamState** — connection attempt, selected address, TLS/QUIC/ALPN/SNI/client-auth status, proxy path, byte counts, close reason, retry advice, and budget use.
7. **LocalExposure** — bind/listen, loopback callback, local-network probe/discovery, advertisement, port forward, tunnel, or public endpoint publication.
8. **EgressImportCut** — the boundary decision for object-store bytes, derived artifacts, diagnostics, logs, secrets, or import material crossing the network.
9. **NetworkReceipt** — durable history of request/grant/deny/connect/listen/fetch/send/upload/download/revoke/expire/cleanup without live power.

## Why ViewFS needs this before it has a final network system

The object-store design wants explicit capability handles and namespace composition. That can be undermined if:

- a safe-open viewer gets broad outbound sockets;
- a helper inherits `$HTTP_PROXY`, PAC, WPAD, DoH, or system resolver state;
- an object-store import worker fetches arbitrary secondary URLs from an archive, package, SBOM, or document;
- a package update helper can reach `*.vendor.example` and thereby also private addresses through DNS drift or service binding;
- a local tool can scan loopback, routers, printers, wallet daemons, Docker sockets, or development servers because **internet** accidentally included **local**;
- a receipt for a prior update, upload, sync, or webhook is treated as a standing grant.

The seam lets ViewFS defer the final network stack while still requiring every design proposal to say which lane it changes.

## Boundary catalog

### Destination designators

These are never authority by themselves:

- URL strings;
- hostnames and suffixes;
- Unicode host input before canonicalization;
- ACE/Punycode names after canonicalization;
- IP prefixes and port ranges;
- service labels like `updates`, `crash-report`, `sync`, `webhook`, `local-printer`, or `loopback-dev`;
- route capsules in shell/history;
- app manifests declaring internet, local-network, or update needs.

### Resolution witnesses

A witness can say:

```text
name: example.test
canonical: example.test.
resolver: portal-owned policy rev 23
query class: address-resolution-only
answers: A/AAAA digest set, redacted
selected: v6 first, v4 fallback allowed
omitted: SVCB/HTTPS not transcript-stable
expires: 2026-05-15T16:42Z
```

It cannot:

- mint a dialer;
- prove future DNS state;
- authorize alternate resolvers;
- silently include DoH/DoT/application-resolver behavior;
- freeze Happy-Eyeballs, SVCB, SRV, proxy, or TLS verifier behavior as portable ViewFS truth.

### Network leases

A descriptor should be boring and explicit:

```text
scope: public-internet | local-network | loopback | explicit-prefix
kind: resolve | connect | listen | fetch | send | sync | update
proto: tcp | udp | tls | quic | http | provider-local
port: numeric or range, never guessed unless future seam says so
ttl: short by default
budget: bytes / connections / time
purpose: user-visible
renewal: none | ask | policy-owned
```

The descriptor is evidence. The live authority is a handle/proxy/lease object.

### Stream state

Stream state can be very useful for the shell:

- connecting / established / closing / closed;
- selected address family and endpoint class;
- TLS/QUIC handshake result class;
- certificate-policy class, not raw secrets;
- ALPN/SNI/ECH/client-auth class, if exposed at all;
- bytes sent/received and budget remaining;
- connection reuse or session-resumption hint;
- retry reason or stale-lease brake.

But stream state should not be a standing grant or an object identity.

### Local exposure

Local exposure deserves its own lane because it changes who can reach the process:

- loopback listener;
- LAN listener;
- multicast / broadcast / mDNS / SSDP discovery;
- service advertisement;
- incoming TCP/UDP accept;
- port-forward or tunnel;
- public endpoint allocation;
- browser/webview local-network bridge.

A connect lease does not imply a listener. A listener does not imply advertisement. Advertisement does not imply public reachability. Public reachability does not imply durable publication.

### Egress and import cuts

Network permission and object permission compose, but neither replaces the other:

- Fetching bytes from the internet does not make them trusted object-store material.
- Uploading an object requires object authority plus egress authority.
- A crash report requires inspection/capture authority plus redaction/export cut plus network send authority.
- A safe-open viewer should not get network by default merely because the file has external references.
- A package admission cut should not imply future updater, telemetry, or plugin-fetch authority.

## Shell implications

The shell can show:

- `net lease: connect tls example.test:443, ttl 10m, 2 MiB budget`;
- `resolver braid: portal DNS, SVCB omitted, v6/v4 raced, expires soon`;
- `local shutter: public internet yes, LAN no, loopback no`;
- `egress cut: sending redacted support bundle, raw dump omitted`;
- `stream meter: 812 KiB sent, 27 KiB received, budget 1.2 MiB left`;
- `receipt only: previous sync cannot reconnect`.

Avoid labels like `online`, `network trusted`, `allowed`, `safe endpoint`, or `same host` without lane detail.

## Concrete examples

### Import a document with external references

Good flow:

1. Portal import returns the document object under quarantine posture.
2. Viewer opens in safe-open mode with no network lease by default.
3. External references are shown as network intents.
4. User grants one fetch lease for one host/path class, or denies.
5. Fetched bytes become derived artifacts with origin evidence and receipts.

Bad flow:

- Viewer inherits broad sockets and downloads images/scripts/resources while the shell only says the document was opened read-only.

### Send a support bundle

Good flow:

1. Inspection lens captures a redacted diagnostic bundle.
2. Export cut says which classes are omitted.
3. Network intent says `send support bundle to vendor endpoint`.
4. Lease grants one TLS connect/send budget.
5. Receipt records bytes, destination class, redaction cut, and cleanup.

Bad flow:

- Old crash-report setting silently uploads raw dump bytes because a previous receipt said `support upload succeeded`.

### Local development callback

Good flow:

1. Tool asks for loopback listener exposure.
2. Shell shows `loopback only`, port, TTL, and callback purpose.
3. Browser or helper gets a separate local-network/loopback connect lease if needed.
4. Receipt expires and cannot reopen the listener.

Bad flow:

- `internet allowed` lets the app bind to all interfaces, advertise by mDNS, and keep the listener across restarts.

## Open questions

- Should network leases be a core ViewFS object family or a portal-owned adjunct borrowed from SlopOS?
- How much of SlopOS CH-NETREQ/CH-NETLEASE should be reused directly?
- Should URL/fetch be a higher-level portal on top of lower-level net leases?
- How do we show DNS and proxy omissions without overwhelming ordinary users?
- Do local-network and loopback grants belong with D-NETLEASE, device leases, safe-open, or a separate local-exposure family?
- How should stream reuse and connection pooling interact with per-workflow receipts?
- What is the minimum compatibility story for POSIX applications that expect ambient sockets and `getaddrinfo`?

## Guardrail summary

**A URL is not authority. A DNS answer is not a capability. A broad network bit is not least privilege. A public-internet grant is not local-network reach. Connect is not listen. Listen is not advertise. Fetch is not import trust. Send is not just a socket. Stream telemetry is not a future lease. A receipt cannot reconnect.**
