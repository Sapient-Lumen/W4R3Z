# Origin evidence, quarantine marks, safe-open capsules, viewer residue, derived artifacts, trust clearances, live opens, and receipts

Revision: 142  
Date: 2026-05-13  
Codename: quarantinecapsules-residuelamps-trustreceipts-amberreed

## Purpose

This note deepens the early ViewFS origin/quarantine work after the recent object-store, capability-flow, durable-root, and GC passes. The new object-store + capability-handle + explicit namespace + portal-import design should treat risky content as a **workflow graph**, not a flag on a file.

The central rule:

> Importing, previewing, indexing, deriving, sanitizing, clearing, opening, executing, and remembering are different operations. A later ViewFS implementation may share storage underneath them, but the datacube must keep their meanings separate.

## Why this belongs next to the datacube

A content-addressed or immutable-first store can make one dangerous mistake especially tempting: `same bytes` can start to feel like `same trust`. That is false. Two equal byte strings may have different arrival stories, consent bases, quarantine states, policy contexts, and current live-open rights.

A portal-mediated import can make another mistake tempting: `the user selected it` can start to feel like `the user trusts it`. That is also false. Selection gives a bounded access story; quarantine and trust-clearance decide handling.

An AI-rich shell creates a third mistake: `we extracted a summary/embedding/thumbnail` can start to feel like `the risky content is now safe enough to search and display`. That is exactly the laundering lane ViewFS should avoid.

## State classes to keep visible

### Origin evidence

Origin evidence should be durable enough to support human explanations and policy decisions, but weak enough not to become authority. It should prefer stable digests and redacted descriptors over raw URLs, raw bearer strings, provider secrets, or hidden account IDs.

Good origin displays:

```text
source: portal import from Mail attachment
parent: archive.zip entry invoices/q2.xlsm
receipt: import #R-8b77
locator: redacted
```

Bad origin displays:

```text
trusted because path is Downloads/invoices/q2.xlsm
trusted because same hash was seen before
trusted because chooser succeeded
trusted because preview rendered
```

### Quarantine mark

A quarantine mark should be object-local. It may reference policy or source evidence, but it should remain a current handling constraint, not a decorative label.

Suggested dimensions:

- `risk_state`: none, quarantined, review-needed, policy-denied, unknown;
- `allowed_default_lane`: metadata-only, peek, safe-open, edit-in-capsule, full-open, execution-denied;
- `blocked_active_classes`: macros, document scripts, helper launches, external fetches, printer/file callbacks, interpreter code input;
- `propagation_policy`: preserve-on-copy, preserve-on-extract, preserve-on-derived-output;
- `clearance_basis`: absent, object-local receipt, policy-local receipt, expired, revoked;
- `source_privacy`: full, redacted, hidden.

### Safe-open capsule

Safe-open should feel like a first-class object. It has a source, a stable input, a compartment, an output lane, and a cleanup story.

Candidate capsule record:

```text
safe_open_capsule_id
source_object_digest
source_quarantine_mark_digest
materialization_digest
materialization_kind       # snapshot | staged-copy | inert-projection | provider-export | sanitized-prepass
viewer_domain              # disposable | low-rights-helper | remote-sandbox | preview-service
active_content_posture     # inert | blocked-with-prompts | denied | explicit-followup-required
egress_policy              # none | export-only | print-portal | copy-text-reviewed | provider-hidden
residue_policy             # disposable-local | explicit-export-only | scrub-on-close
started_at
expires_at
basis_receipt_digest
```

The capsule is **not** a durable grant. It should be visible while live and collapse to a receipt when done.

### Viewer residue ledger

Residue is where old systems quietly fail. ViewFS should deliberately track whether a risky open produced:

- thumbnails / preview images;
- extracted text / OCR;
- embeddings / summaries;
- MRU / recent entries;
- autosaves / recovery files;
- search-within-document indexes;
- unpacked temp children;
- telemetry / crash diagnostics.

Default rule: residue stays inside the disposable or review lane. Persisted residue requires explicit export and should usually become a derived artifact with its own quarantine mark.

### Derived artifacts

Derived artifacts must not inherit clearance just by being useful. A summary of a malicious spreadsheet can still leak sensitive content. A sanitized PDF may be safer than the source, but it is still a new artifact with a parent and a specific sanitation basis.

Useful artifact classes:

- ordinary safe-open kept output: quarantined by default;
- sanitized output: may receive a narrower clearance if the sanitizer workflow says so;
- semantic output: summary/text/embedding attached to the derived artifact, not silently back-written onto the source;
- unpacked child: inherits quarantine from parent/container by default;
- preview export: may be displayable but not equivalent to source trust.

### Trust clearances

Clearance should be explicit and narrow. It should not be path-wide, recursive, or hidden behind `opened successfully`.

Useful axes:

- source object versus derived artifact;
- preview versus edit versus active content versus execution;
- one helper versus all handlers;
- one workspace versus profile-wide;
- one time versus durable;
- human decision versus policy-assisted decision;
- revocable versus irreversible.

### Live opens

Live opens are the strongest truth in this family. They should be shown separately from quarantine state and receipt history.

A source can be:

| State | Meaning |
|---|---|
| quarantined + no live open | blocked or awaiting review |
| quarantined + live safe-open capsule | being inspected through bounded lane |
| cleared for edit + no active content | document may be edited, but macros/helpers remain blocked |
| sanitized derivative live | derivative is usable; source remains risky |
| receipt-only | old open/clear/export happened, no current power |
| execution live | full runnable authority is currently installed |

## SlopOS pressure to import

The included SlopOS archive already has several unusually sharp boundaries that ViewFS should mirror as guardrails:

- `quarantine-posture-v0.md`: quarantine is monotonic by default, manual-only to clear, object-local, safe-open does not mutate trust in place;
- `import-to-docref-boundary-v0.md`: bearer/import material becomes a fresh local object and remains quarantined by default;
- `import-to-docref-fresh-identity-boundary-v0.md`: equal bytes do not collapse onto an already trusted identity;
- `open-untrusted-materialization-boundary-v0.md`: safe-open resolves once into a stable request-local input, not a live alias;
- `open-untrusted-active-content-boundary-v0.md`: admitted documents remain inert by default;
- `open-untrusted-viewer-residue-boundary-v0.md`: MRU, thumbnail, autosave, and crash residue stay disposable-local unless explicitly exported;
- `quarantined-content-index-boundary-v0.md`: quarantined bytes do not feed ambient OCR/full-text/embedding/summary systems;
- `quarantined-derived-attribute-boundary-v0.md` and `quarantined-derived-match-boundary-v0.md`: derived semantics do not get written back onto risky sources or resurface the source by hidden lineage join;
- `quarantined-result-preview-boundary-v0.md`: even search results stay metadata-safe until explicit review/open.

The ViewFS move is to reuse the distinction, not to import every SlopOS schema.

## External lessons mapped

- Apple quarantine/Gatekeeper: origin/risk metadata and first-open checks are valuable, but hidden metadata is brittle unless propagation and user explanations are explicit.
- Windows Mark-of-the-Web / Office / Protected View / Application Guard: one origin marker should produce multiple handling lanes rather than one global trust bit.
- Chrome / Safe Browsing: warning tiers and reputation can be useful inputs, but they are not object identity, durable authority, or proof of safety.
- XDG Documents and Android SAF: mediated user choice gives scoped access, not content trust.

## Design pressure on future object-store API

A future API should leave room for these questions without answering them too early:

- Is quarantine state stored beside object metadata, in an attribute layer, in a policy service, or as receipts plus live verdicts?
- Do derived artifact parent links participate in GC roots, provenance graphs, or only audit?
- Are embeddings first-class objects, encrypted indexes, provider-local views, or disposable-only caches?
- Can a sanitizer issue a stronger clearance, or only a suggestion for human review?
- Does exact content identity ever allow trust reuse, and if so under what issuer, epoch, and purpose?
- Which operations need currentness witnesses before consuming a source object?
- How should redaction hide origin while still proving propagation and residue cleanup?

## Guardrails

- `selected/imported` is not `trusted`.
- `same digest` is not `same trust`.
- `safe-open succeeded` is not `cleared`.
- `thumbnail exists` is not `preview authorized`.
- `embedding exists` is not `source searchable`.
- `sanitized derivative exists` is not `source safe`.
- `clear for preview` is not `clear for macros`.
- `clear for document edit` is not `clear for execution`.
- `old receipt` is not `current live open`.
