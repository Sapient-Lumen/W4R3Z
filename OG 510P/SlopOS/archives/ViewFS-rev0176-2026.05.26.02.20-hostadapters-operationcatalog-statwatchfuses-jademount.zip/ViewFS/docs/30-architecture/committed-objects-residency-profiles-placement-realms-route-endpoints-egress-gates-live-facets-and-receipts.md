# Committed objects, residency profiles, placement realms, route endpoints, egress gates, live facets, and receipts

Purpose: keep **committed objects**, **residency profiles**, **placement realms**, **route endpoints**, **egress gates**, **live facets**, and **receipts/history** on separate seams.

Object stores and capability systems make it very tempting to collapse these into one vague story of `where the object is`.
The precedents say otherwise.
A durable object can exist, a policy can constrain where it may live, current replicas or backing can occupy some site set, reads can be routed through one endpoint, and exports across one boundary can still be denied.

## Useful precedents
- **REF-AWS-S3-REPLICATION**: S3 separates logical object copies from same-region/cross-region replication rules and compliance/latency motivations.
- **REF-AWS-S3-MRAP-ROUTING**: Multi-Region Access Point routing can send a `GET` to the closest bucket even when that bucket does not hold the object, which can yield `404 Not Found` unless replication has already placed a copy there.
- **REF-GCS-BUCKET-LOCATIONS**: dual-region buckets store objects in a paired region set, not one single endpoint.
- **REF-GCS-BUCKET-RPO**: bucket replication policy / RPO is an explicit writable property, separate from storage class and from object identity.
- **REF-AZURE-STORAGE-REDUNDANCY**: geo-redundant storage can have a secondary region that is unreadable unless read-access geo-redundancy is enabled, and asynchronous replication means the secondary may lag.
- **REF-CEPH-CRUSHMAP**: placement policy is a rule layer over topology, not the same thing as logical object identity.
- SlopOS already has adjacent pressure here: `cluster-map-schema-v0.md`, ADR-0006 replication contracts, `artifact-reference-schema-v0.md`, and `capstore-commit-schema-v0.md`.

## Distinctions worth preserving

### 1. Residency policy is not current placement
A residency profile can say:
- keep within one realm,
- keep in a specific pair,
- do not leave this jurisdiction,
- or provider-hidden policy.

That does **not** say where all current copies or authoritative backing sit right now.

### 2. Placement is not the same thing as the route a request uses now
A system may have copies in two or more realms and still route one request through:
- the nearest endpoint,
- the primary endpoint,
- one secondary read endpoint,
- a provider-chosen failover lane,
- or a local proxy that hides the underlying realm.

The current route can change without object identity changing.

### 3. Route endpoint is not proof of object presence there
The sharp S3 warning matters here: a global route can choose a nearby bucket that does not yet hold the object.
`request went here` is not the same thing as `object is present here`.

### 4. Egress permission is not current read authority
A process may be able to read one object through one current route while still being forbidden to:
- export a copy across one residency boundary,
- rebind it into one different realm,
- or publish it into a destination with incompatible policy.

The egress story should stay explicit.

### 5. Receipt/history is not current locality truth
A past receipt saying `replicated to region B`, `secondary read enabled`, or `export denied` is evidence that something happened.
It is not proof that placement, route, or egress posture remain unchanged now.

## Shape that feels promising
ViewFS probably wants different object/receipt families such as:
- **ResidencyProfile** — intended location/jurisdiction rule
- **PlacementRealm** — current realm/site set or provider-hidden placement summary
- **RouteEndpoint** — current read/write path endpoint or route lane
- **EgressVerdict** — can/cannot/must-review for one boundary-crossing act
- **LocalityReceipt** — durable evidence of what was true at one time

The exact schemas can wait.
The class separation should not.

## Nifty ideas worth stealing
- **Realm badges**: `single realm`, `dual realm`, `cross-region`, `provider hidden`, `history only`.
- **Route halos**: `nearest route`, `primary route`, `secondary read`, `failover lane`, `route hidden`, `history only`.
- **Egress shutters**: `local only`, `cross-boundary denied`, `review needed`, `allowed by policy`, `history only`.
- **Placement ghosts**: `present in A+B`, `lagging`, `policy hidden`, `unknown`, `history only`.
- **Residency compare drawers**: inspect `policy says`, `placement says`, `route says`, and `egress says` in one honest panel.

## What not to decide yet
- one final realm/region/jurisdiction taxonomy,
- whether placement is always exact or may stay redacted/provider-hidden,
- whether route details are observable at all backends,
- one universal egress-policy language,
- whether residency profile is object-local, container-local, or store-local.

## Near-term recommendation
For ViewFS Phase 1 and nearby spikes:
1. keep **object existence**, **residency policy**, **placement realm**, **current route**, **egress gate**, and **live authority** as explicit vocabulary,
2. make nearest/global routing visibly weaker than object-presence truth,
3. make secondary-read posture visibly weaker than write/placement truth,
4. keep export/import boundary decisions transcript-visible,
5. and refuse to let history receipts silently stand in for current residency or route state.
