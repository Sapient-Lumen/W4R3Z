# Loans, delegations, recalls, and expiry

Purpose: keep **lend/borrow requests**, **live borrowed authority**, **durable delegated refs**, **issuer-held recall/expiry controls**, and **history receipts** on distinct seams.

ViewFS will almost certainly need ways to let one pane, process, or user-approved action *lend* narrow authority to another without pretending that a durable transfer, a saved workflow, and a live borrowed handle are all the same thing.
That matters even more because SlopOS itself is still design-phase. We should freeze the class boundaries early and leave the exact transport/schema choices late.

## Useful precedents
- **REF-SEL4-CSPACE**: capabilities can be copied or moved, minted with reduced rights, and revoked through the derivation tree; the parent/issuer relationship stays meaningful.
- **REF-FUCHSIA-SANDBOXING** and **REF-FUCHSIA-NAMESPACE**: a more-authoritative creator assembles the child namespace; the child does not self-grant later.
- **REF-FUCHSIA-DICTCAP** and **REF-FUCHSIA-DICT-RFC**: grouped capabilities can stay explicit, nestable, and inspectable instead of becoming hidden inheritance.
- **REF-XDG-DOCUMENTS**: document-store entries can be session-only or persistent, permissions can be granted/revoked separately, and deleting a document-store entry is not the same thing as deleting the file.
- **REF-APPLE-SECBOOKMARK**, **REF-APPLE-SECWITHSCOPE**, and **REF-APPLE-SECSTART**: a durable security-scoped bookmark is not already-live access; it is explicit typed persistence followed by explicit live access start/stop discipline.
- **REF-DENO-PERMISSIONS**: a system can default-deny, prompt narrowly, and keep explicit deny precedence without becoming unusable.
- **REF-DIRENV-REQUIREALLOWED**: changed upstream inputs should invalidate prior comfort and force re-authorization rather than silently widening what a past approval now means.
- SlopOS already leans this way via capability leases, approval-basis discipline, capshell exact-handle-table posture, and workflow/portal seams.

## Distinctions worth preserving

### 1. A request to lend is not a live loan
A **lend request** or **borrow request** says:
- who is asking,
- for what class of object,
- for what operation class,
- for how long or under what end condition,
- and whether durability or re-delegation is being asked for.

A **live loan** means a borrower now holds usable current authority.

Why this matters:
- prompts, route cards, and notebook cells should be able to stay inspectable before a loan exists,
- and denial/retry should not mutate into “maybe they already have access somehow”.

### 2. A live borrowed handle is not a durable delegated ref
A **borrowed handle** is current usable authority, likely scoped to a process, pane, or task.
A **durable delegated ref** is a descriptor that may later be re-resolved or re-consented, but is not itself already-live access.

Why this matters:
- Apple’s security-scoped bookmark flow is a useful warning here: durable scope-bearing reference and current started access are separate acts.
- ViewFS should not let “I can reopen this later” silently turn into “this process currently has the authority”.

### 3. Issuer-held recall power is not the same thing as borrower-held access
A lender or parent may retain the power to:
- revoke,
- shorten,
- expire,
- or refuse renewal of a loan.

That power should not be confused with the borrower’s handle.

Why this matters:
- seL4’s mint/revoke discipline is a good mental model: a derived capability lineage and the issuer’s ability to recall it are first-class facts.
- ViewFS should keep borrower-visible capability values separate from issuer-side recall controls and ledger state.

### 4. Expiry is not deletion, and recall is not object death
A loan can end because:
- the borrower relinquished it,
- the lender recalled it,
- a timer or condition expired,
- the source object changed class,
- the approval basis drifted,
- or the object really disappeared.

Why this matters:
- the shell needs to explain *which* thing happened.
- “stale because expired” is a very different repair path from “stale because object deleted”.

### 5. Pane-scoped or run-scoped borrowing is not standing session authority
A good default loan class may be:
- this command only,
- until this pane closes,
- until this child exits,
- until this timer elapses,
- or until this exact route plan completes.

Why this matters:
- borrowed authority should feel bounded and local, not like it instantly became ambient session folklore.
- this aligns with the custom shell ambition: powerful lanes, loud state.

### 6. Promotion from loan to durable delegation should be explicit
A user may reasonably want to turn:
- a one-run loan,
- a pane-scoped borrow,
- or a child-launch borrow

into a more durable reopen/delegation record.

Why this matters:
- that should be a visible **promote/persist** act with provenance and possibly new review,
- not an automatic consequence of “it worked once”.

### 7. Approval escrow is not active authority
A plan may have:
- an approved basis digest,
- a prepared launch kit,
- a saved permission choice,
- or a pending-but-not-yet-started loan.

Why this matters:
- exact approval basis, exact current live access, and historical evidence should stay separate.
- otherwise the shell will eventually lie about whether a capability is usable now or merely pre-cleared for some future action.

### 8. Loan lineage should stay inspectable
A future ViewFS loan should ideally answer:
- who lent it,
- from what source object or bundle,
- under what attenuation,
- whether re-delegation is allowed,
- what ends it,
- whether it is renewable,
- and what receipt survives when it ends.

Why this matters:
- grouped authority is only safe when the group still carries reviewable class truth.

## Shape that feels promising
ViewFS probably wants distinct conceptual objects such as:
- **LoanRequest** — a request or prepared ask to borrow authority
- **BorrowedHandleSet** — live attenuated authority currently usable by a process/pane/run
- **DelegatedRef** — durable or semi-durable descriptor that can later reopen or re-consent
- **RecallControl** — issuer-side power to shorten, revoke, or deny renewal
- **LoanEndReceipt** — history artifact explaining borrower release / issuer recall / expiry / denial / disappearance

The names can change later. The split should stay.

## Shell consequences
A custom shell+terminal gets much better if it can offer:
- `lend for this run`, `lend until pane closes`, `lend read-only`, and `lend stripped` as first-class moves,
- borrower-visible badges like `borrowed`, `expires soon`, `re-delegate forbidden`, or `recallable`,
- explicit `promote to durable reopen` or `persist this loan class` flows,
- and end-of-loan receipts that say `relinquished`, `recalled`, `expired`, `basis drift`, or `missing source`.

That would make borrowing feel powerful *and* truthful.

## What not to decide yet
- the final schema for `BorrowedHandleSet`, `DelegatedRef`, or `RecallControl`,
- whether all loans are implemented through one primitive or several substrate-specific ones,
- exact renewal/extension rules,
- whether borrower-visible countdowns are exact or bucketed,
- or whether issuer-side recall is universal, optional, or profile-dependent in Phase 1.

## Near-term recommendation
For Phase 1 and nearby spikes:
1. default cross-pane and child-launch authority sharing to **bounded loans** rather than durable persistence,
2. keep **request**, **live borrow**, **durable delegated ref**, **issuer recall/expiry control**, and **loan-end receipt** as explicit vocabulary,
3. require an explicit promotion step from ephemeral borrowed authority to anything durable,
4. transcript the reason a loan ended,
5. and prototype one killer flow: `lend for this run` plus visible expiry/recall badges in the shell.

## Revision 146 refinement

The earlier loan/delegation split remains, but Revision 146 adds a sharper warning: `recall` and `revoked` are not one boolean. A bounded loan may end because a membrane closed, a TTL expired, a provider accepted token revocation, an epoch advanced, a stale handle hit a use-site brake, renewal was denied, or only a local receipt was written.

Future loan UX should therefore pair borrowed-handle badges with revocation wavefronts and exact stale reasons. A `LoanEndReceipt` should explain the end cause without implying global erasure or undoing effects already made through the loan.
