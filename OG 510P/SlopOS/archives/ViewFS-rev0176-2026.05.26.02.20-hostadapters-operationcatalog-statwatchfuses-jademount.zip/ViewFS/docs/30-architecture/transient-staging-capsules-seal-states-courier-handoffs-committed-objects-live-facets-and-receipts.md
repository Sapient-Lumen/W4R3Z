# Transient staging capsules, seal states, courier handoffs, committed objects, live facets, and receipts

Purpose: keep **transient exact-byte staging capsules**, **seal/freeze states**, **local courier handoffs**, **durable committed objects**, **current live facets**, and **durable receipts/history** on distinct seams.

## The split
- **staging capsule** — one unnamed or otherwise private exact-byte draft object that exists for local assembly, review, preview, edit return, or transfer.
- **seal state** — whether that capsule is still writable, frozen for review, frozen against some classes of mutation, or intentionally discarded.
- **courier handoff** — one explicit local send/receive act that passes the capsule or one handle to another process without publishing it into a global namespace.
- **committed object** — the durable object/store member or published local object that exists only after explicit import/commit/publication.
- **live facet** — currently usable inspect/read/edit/publish authority over the committed object or over the still-live capsule.
- **receipt/history** — durable memory of draft creation, seal changes, courier hops, commit/publish, and later discard.

## Why this must stay split
A capability-heavy object store can easily lie by accident:
- one temporary draft capsule gets mistaken for a durable object-store member,
- one seal bit gets mistaken for durable identity or future reopen ability,
- one local courier hop gets mistaken for publication or import,
- or one history row gets mistaken for current live authority.

That is exactly the kind of collapse ViewFS should avoid while SlopOS is still in design and while ViewFS itself is still collecting ideas instead of freezing one local-edit or import ABI.

## Lessons worth stealing
### Exact draft bytes can exist before any durable object is born
Linux `memfd_create()` is useful because it creates an anonymous file descriptor that behaves like a regular file and can be passed to another process, while `O_TMPFILE` is useful because an unnamed inode can exist in the target filesystem before any public name is attached.
That means ViewFS does not need to decide yet that `draft exists`, `user can inspect`, `other helper can receive`, `durable object committed`, and `published name exists` are one mechanism.

### Freeze-for-review is its own truth
Linux file seals are useful because seals constrain which operations may still succeed, are enforced immediately, and can only be added, not removed.
That is a strong reminder that `review freeze` or `commit-last` posture is different from object identity, publication, or durable reopen.

### Courier handoff is not publication
UNIX domain sockets are useful because they can pass file descriptors explicitly to another local process.
That is a strong reminder that exact local transfer can stay explicit and path-free without becoming a durable publish/import story.

### Continuity caveat: transient capsules are not durable by default
Current Linux memfd preservation docs are useful because they say file contents and size may be preserved across the documented kexec preservation path, but seals are not preserved and must be re-established after restore.
That is a strong reminder that any future continuity/restart story for staging capsules must stay visibly weaker than durable object-store identity or durable grant semantics.

### SlopOS already rhymes with the same lesson
Current SlopOS drafts are useful because `import-to-docref-boundary-v0.md` keeps explicit materialization and fresh local object birth separate from bearer restore/import, `import-to-docref-fresh-identity-boundary-v0.md` refuses same-byte alias laundering, `artifact-reference-schema-v0.md` keeps digest identity separate from locator folklore, and `capstore-commit-schema-v0.md` keeps durable commit meaning explicit instead of ambient.
That is almost exactly the staging/commit honesty ViewFS should steal.

## Design guidance
1. A **staging capsule** should be inspectable without implying that a durable object-store member already exists.
2. A **seal state** should stay reviewable without becoming immutable object identity or durable reopen.
3. A **courier handoff** should remain explicit local transfer, not namespace publication or import by implication.
4. A **committed object** should be born only at explicit import/commit/publication time.
5. A **live facet** should stay visibly stronger than every draft/seal/courier/history row.
6. A **receipt/history** row should remember draft and handoff facts without reviving present authority.

## Shell implications
The shell should be able to render:
- **capsule cards** (`draft`, `sealed for review`, `sealed against writes`, `discarded`, `history only`),
- **seal shutters** (`open`, `frozen`, `future-writes blocked`, `locked`, `unknown`),
- **courier rails** (`offered locally`, `received locally`, `not published`, `history only`),
- **commit lamps** (`not committed`, `committed here`, `published now`, `discarded`, `history only`),
- **live rails** (`inspect now`, `read now`, `edit now`, `publish now`, `history only`).

## Non-decisions to preserve
Do not decide yet:
- one universal staging-capsule primitive;
- whether every capsule is memfd-like, `O_TMPFILE`-like, provider-owned, shell-owned, or helper-owned;
- whether every freeze state uses kernel seals, provider-local flags, or shell-only discipline;
- whether every courier hop is FD-passing, portal-owned, or runtime-owned;
- whether continuity lockers may ever preserve capsules across restart;
- one final capsule-to-commit import ABI.
