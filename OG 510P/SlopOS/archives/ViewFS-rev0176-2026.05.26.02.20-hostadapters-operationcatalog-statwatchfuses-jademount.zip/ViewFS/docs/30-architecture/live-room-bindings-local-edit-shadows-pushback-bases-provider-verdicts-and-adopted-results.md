# Live room bindings, local edit shadows, pushback bases, provider verdicts, and adopted results

This note sharpens one more low-regret ViewFS separation:
**live room binding**, **editable local shadow**, **exact pushback basis/preconditions**, **provider-side verdict**, **locally adopted result**, and **durable receipt/history** are different truths.

Relevant precedents:
- **REF-RFC9110-PRECONDITIONS**, **REF-S3-CONDITIONAL-WRITES**, **REF-GCS-PRECONDITIONS**, and **REF-AZURE-BLOB-CONCURRENCY**: optimistic mutation gates should name exact expected state.
- **REF-GIT-FORCE-WITH-LEASE** and **REF-GIT-UPDATE-REF**: compare-and-swap / replace-if-still-equal can become excellent product verbs.
- **REF-WEBDAV-LOCKING** and **REF-ETCD-TXN**: coordination tokens and conditional transactions are useful, but they are still not the same thing as durable winning state.
- **REF-MDN-CREATEWRITABLE**: a writable session can stay private/staged and still be useful without pretending to already be committed truth.
- **SlopOS**: `acp-precondition-witness-posture-v0.md`, `capstore-commit-schema-v0.md`, `conflict-key-schema-v0.md`, and `conflict-key-family-registry.md` all push toward exact local witnesses, explicit outcomes, and named conflict scope instead of magical floating latest-state writes.

## Why the split matters
The future custom shell is going to host editors, merge tools, provider-backed views, projected imports, and pushback actions.
That only stays honest if it can answer at least five different questions:
- what is bound here now?
- what local draft/shadow am I editing?
- what exact old state am I claiming for pushback?
- what did the provider actually say?
- what local state did this room adopt afterward?

Those questions differ because the consequences differ.
A live room bind can grant present access now.
A local shadow can be rich and editable but still private.
A pushback basis can become stale without changing the local draft bytes.
A provider verdict can reject the push while still leaving the draft intact.
A locally adopted result may keep the draft, fast-forward to a new provider version, or fork a new local object.
A receipt can explain all of that while authorizing nothing now.

## Working posture

### Live room binds should stay current-state truth
The shell should answer exactly what this room is bound to now.
That must remain separate from whether a draft exists.

### Local shadows should stay draft-first
A local shadow or writable session should be inspectable, diffable, and preservable without pretending it already changed provider state.
That keeps editing and pushback decoupled.

### Pushback basis should stay exact and copyable
A pushback basis should say things like:
- `etag == abc123`
- `generation == 77`
- `ref old == deadbeef`
- `create-if-absent`
- `lease + expected old`

That is better shell truth than one vague `sync` or `save` story.

### Provider verdict should stay upstream-only truth
The receiver/provider should be able to say exactly what happened:
- `accepted`
- `accepted -> generation 78`
- `rejected precondition`
- `rejected lease`
- `rejected conflict key`
- `transport lost / verdict unknown`

That is much more honest than one universal `saved` verb.

### Local adoption should stay explicit
After a verdict, the shell should still have to decide what to do locally:
- keep draft untouched,
- adopt provider-returned head,
- fork local copy,
- open conflict view,
- or store receipt only.

That keeps provider outcome and local room consequence visibly separate.

## Shell and terminal payoffs
A truthful shell can turn this split into product leverage:
- **basis lamps** that show `based on etag`, `generation`, `lease`, or `unknown`;
- **verdict cards** that say exactly what the provider accepted or rejected;
- **adopt rails** that separate `keep draft`, `fast-forward local`, `fork local`, `receipt only`;
- **force-with-lease ladders** instead of one generic `retry force` button;
- **provider drift drawers** that compare local draft basis with current upstream state.

## Classification worth standardizing early
A useful posture-oriented classification for shell UX and protocol experiments is:
- `draft_only`
- `draft_with_basis`
- `push_attempt_pending`
- `provider_accept`
- `provider_reject_precondition`
- `provider_reject_conflict`
- `provider_verdict_unknown`
- `local_adopt_fast_forward`
- `local_adopt_keep_draft`
- `local_adopt_fork`
- `receipt_only`

This is intentionally posture-oriented.
It does **not** decide one final provider ABI, one final witness format, or one final mutable-store transaction family.

## What not to freeze yet
Do **not** freeze yet:
- one universal validator vocabulary,
- whether pushback basis is always provider-native versus sometimes ViewFS-native witness packs,
- whether local adoption can happen automatically for any verdict class,
- whether one room can keep several alternative draft branches around one provider basis,
- or one final retry/merge/takeover protocol.

The separation is worth freezing now.
The provider ABI and mutation substrate are not.
