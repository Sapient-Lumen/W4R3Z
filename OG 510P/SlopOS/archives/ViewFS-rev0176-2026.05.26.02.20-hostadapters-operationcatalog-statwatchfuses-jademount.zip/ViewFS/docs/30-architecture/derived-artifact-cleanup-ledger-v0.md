# Derived artifact cleanup ledger v0

Revision 157 adds the first cleanup/minimization lane for semantic indexes, summaries, embeddings, answer cards, thumbnails, excerpts, and other derived artifacts. The point is not to promise perfect unlearning. The point is to stop ViewFS from claiming source forgetting while derived rows remain live and unaccounted for.

## Why this exists

Schell pressure is central: retention, minimization, forgetting, transcript residue, and copy inventories are different operations. In ViewFS, semantic search and agent memory are especially risky because they can become a shadow filesystem. A source object may be gone while its embedding, OCR text, summary, cached answer, thumbnail, or quoted excerpt still leaks facts.

## Record lane

`DerivedArtifact` already records the existence of derived material:

```text
DerivedArtifact(id, source, artifact_class, scope, retention, cleanup_state?)
```

Revision 157 adds `CopyInventory` as cleanup accounting:

```text
CopyInventory(
  id,
  source,
  entries: [
    { artifact, cleanup_state }
  ]
)
```

Accepted cleanup states in the v0 fixture lane are deliberately few:

- `deleted`;
- `minimized`;
- `tombstoned`;
- `not-materialized`.

States such as `live`, `unknown`, `cached`, `exported`, or missing are blockers for a successful forget claim.

## Fixture lanes

- `029-forget-source-derived-live-denied.json` denies forgetting when an embedding row remains live.
- `030-forget-source-derived-minimized-allow.json` allows the source-forget claim after derived rows are minimized/deleted in the inventory.

## The honest claim

A ViewFS shell should distinguish:

```text
source object removed
source no longer retained by ViewFS
derived rows minimized
derived rows deleted
exported copies unknown
provider copies outside ViewFS control
receipts retained as history
```

Only some of these are local facts. Some are negative facts. Some are outside-world uncertainty.

## Future pressure

The next likely fixtures should cover:

- stale answer card after source deletion;
- vector-store membership oracle after source deletion;
- exported excerpt outside local cleanup control;
- retention root promoted by legal hold;
- user-visible `forget --dry-run` explaining exact blockers;
- Harbor-style public surface recheck window after external publication.

## Non-claims

- This is not a cryptographic erasure guarantee.
- This is not a vector unlearning algorithm.
- This does not claim external recipients delete their copies.
- This does not delete receipts by default.

The v0 rule is smaller and stricter: **do not claim forgetting is complete until every local derived artifact has an explicit cleanup state.**
