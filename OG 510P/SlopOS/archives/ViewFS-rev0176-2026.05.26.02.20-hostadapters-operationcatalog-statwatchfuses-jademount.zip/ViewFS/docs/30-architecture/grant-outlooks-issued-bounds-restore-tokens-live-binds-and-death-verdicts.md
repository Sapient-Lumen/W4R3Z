# Grant outlooks, issued bounds, restore tokens, live binds, and death verdicts

Purpose: keep **preflight permission outlook**, **reviewed issued-bounds evidence**, **reactivation / restore material**, **current live bind**, **explicit death-state verdict**, and **durable receipt/history** on distinct seams.

This is a low-regret split for ViewFS while the object store, capability-handle families, portal-mediated imports, and per-process namespace rules are all still moving.
The mistake to avoid is easy to make: one UI ends up saying `still allowed`, `can reopen`, or `session is back`, and suddenly a permission query, an old descriptor, a one-shot restore token, and a current live bind all start impersonating each other.

## Why this seam matters

Several nearby systems already keep these truths apart:
- **SlopOS** is now explicit that lease/grant descriptors prove exact issued bounds, but do not by themselves prove that the corresponding provider-owned grant or session is still active now.
- **W3C Permissions** and **File System Access** keep preflight permission state and permission-request steps explicit instead of pretending a stored handle is automatically live authority.
- **Android SAF / UriPermission** keeps user-selected scope and persisted-permission bookkeeping explicit instead of treating a persisted record as identical to current successful use.
- **XDG portals** keep request objects, long-lived sessions, persistence modes, restore tokens, and explicit close signals on different seams.
- **Fuchsia** keeps discoverable routed capability presence in a namespace separate from any descriptive artifact about it.

That is exactly the shape ViewFS should steal.

## Keep these classes separate

### 1. Grant outlook
Preflight truth such as:
- `prompt`
- `granted`
- `denied`
- `persistable`
- `reconsent needed`
- `unknown`

This is useful, but it is not a live handle.

### 2. Issued-bounds card
A descriptor/proof row saying:
- what exact rights or bounds were reviewed/issued,
- when or under what policy family they were issued,
- which family/provider owns current enforcement,
- and which digest or witness identifies that reviewed shape.

This is evidence of one reviewed grant shape, not a hidden status oracle.

### 3. Restore or reactivation material
A narrower class saying:
- there is a way to ask for continuity,
- it may be single-use,
- it may need revalidation or reconsent,
- it may expire or be superseded.

This is not the same thing as the issued-bounds card, and it is definitely not the same thing as a current live bind.

### 4. Current live bind
One current room/process/session actually holds usable authority now.
This is the only class that should drive strong `use now`, `edit now`, `publish now`, `observe now`, or `inject now` claims.

### 5. Death-state verdict
Reason-rich end-of-life truth such as:
- `revoked`
- `expired`
- `session closed`
- `token spent`
- `target changed`
- `provider unavailable`
- `history only`

This should stay more precise than one vague `stale` bucket.

### 6. Durable receipt/history row
Receipts explain what used to be true without reviving it.
History can remember reviewed bounds, restore attempts, reconsent outcomes, and death verdicts, but it should not silently reanimate current authority.

## What ViewFS should do with this

ViewFS should be free to:
- show **grant gauges** before action,
- show **issued-bounds cards** that are safe for notebooks/history/review,
- show **restore beads** or **repair ladders** for continuity attempts,
- separately show one **live bind now** state,
- and separately show **death cards** when continuity really ended.

That lets the shell say:
- `prompt`
- `granted`
- `issued bounds known`
- `restore token present`
- `bound here now`
- `revoked`
- `expired`
- `history only`

without needing to freeze one universal reopen protocol or one universal grant-status API.

## What this does not decide

This note intentionally does **not** decide:
- whether restore/reactivation material is mediator-held, shell-held, wallet-held, or provider-held;
- whether every object family gets a queryable permission outlook;
- whether death verdicts are always provider-signed, locally inferred, or mixed;
- whether one future ViewFS object-store family carries issued-bounds cards, or whether those remain adjacent descriptors;
- whether restore material is always single-use, sometimes renewable, or family-specific.

## Lessons we should steal

- **Permission lights** from web permission APIs so preflight state is visible without pretending it is a live bind.
- **Persisted-time / issued-time chips** so one old durable artifact is visibly old evidence rather than current truth.
- **Single-use restore beads** from portal restore-token posture so continuity attempts can be explicit and limited.
- **Death cards** with reason-rich endings instead of flattening everything into `stale`.
- **Reconsent ladders** that preserve dignity: `ask again`, `repair`, `rebind`, or `keep receipt only`.

## Why this is especially timely for SlopOS-aligned ViewFS

SlopOS is still actively designing the datacube, which is exactly why ViewFS should freeze the **separation of truths** earlier than it freezes any universal carrier format.
If SlopOS later changes wallet details, session families, temporal capability descriptors, document handles, or portal restore shapes, ViewFS still benefits from already knowing that:
- outlook is not issuance,
- issuance is not reactivation material,
- reactivation material is not current live bind,
- and historical evidence is not current authority.
