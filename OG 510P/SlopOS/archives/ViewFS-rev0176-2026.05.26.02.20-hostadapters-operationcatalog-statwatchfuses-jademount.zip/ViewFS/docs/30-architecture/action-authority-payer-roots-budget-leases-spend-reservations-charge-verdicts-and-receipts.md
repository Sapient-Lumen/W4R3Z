# Action authority, payer roots, budget leases, spend reservations, charge verdicts, and receipts

Purpose: keep sponsorship/cost truth narrow and explicit while SlopOS and ViewFS are still in design.

ViewFS should keep these truths separate:
**action authority ≠ payer root ≠ budget lease ≠ spend reservation/admission ≠ charge verdict ≠ provider effect/local adoption ≠ durable receipt/history**.

## Why this seam matters
The shell will eventually mediate:
- provider-backed imports and exports,
- hydration or localization work,
- preview pipelines,
- expensive searches or renderers,
- long-running sync or publication helpers.

If ViewFS does not keep sponsorship separate, the future shell will quickly blur:
- `you are allowed to do this`,
- `this sponsor would be charged`,
- `budget has been reserved`,
- `provider actually charged someone`, and
- `history merely remembers a past spend`.

SlopOS already resists that collapse.
Its budget work keeps explicit payer selection, attenuation-only budget delegation, and transcript-visible sponsorship separate from execution subject and request context.

## Lessons worth stealing

### Requester Pays: access and billing stay separate
Amazon S3 and Google Cloud Storage both keep requester-paid access explicit.
That means:
- permission to act remains separate from who is billed;
- the requester must explicitly accept or specify billing posture;
- storage cost and access cost can still land on different principals.

### ResourceQuota versus RBAC: can ask is not can consume
Kubernetes cleanly separates authorization from aggregate resource ceilings.
That is exactly the right product instinct for ViewFS too.
An authority-bearing handle or route plan should not silently double as one spending entitlement.

### seL4 MCS: the budget object can travel separately
Scheduling contexts are distinct from threads and can be donated over RPC-style calls.
That is great evidence that `the thing that runs` and `the thing whose budget is consumed` can be separate lanes.

### Genode sessions: sponsorship can be an explicit session property
Genode's resource donation posture is a useful reminder that sponsorship can be shaped explicitly at the session seam.
That is a better story than hidden thread-local payer defaults.

### cgroup v2: control hierarchies are not payer truth
Hierarchical resource control is useful implementation machinery, but it is not portable proof of who sponsored one action.
ViewFS should not let `current subtree` quietly become `current payer`.

## Shape that feels promising
ViewFS likely wants conceptual rows like:
- **ActionAuthority**
  - what current bind/handle/policy posture makes the act legal?
- **PayerRoot**
  - what sponsor/meter/account lineage would cover the action?
- **BudgetLease**
  - what exact bounded spend ticket exists now?
- **SpendReservation**
  - has some cost lane been reserved or admitted already?
- **ChargeVerdict**
  - requester-paid, owner-paid, server-paid, rejected, partial, expired, unknown?
- **EffectOrAdoption**
  - what provider-side effect happened and what local state adopted it?
- **ChargeReceipt**
  - what only survives as explanation/history now?

## Shell/product consequences
The custom shell gets much better if it can show:
- **payer chips** — `requester`, `owner`, `server budget`, `unknown`, `no spend lane`;
- **spend rails** — `unreserved`, `reserved`, `partially spent`, `charged`, `charge rejected`, `history only`;
- **sponsored-by drawers** — which sponsor/meter/lease covered the action and why;
- **charge ghosts** — what earlier charges happened without reviving a live sponsor;
- **switch-payer ladders** — preview cost with one payer, then explicitly change payer before commit.

## What not to decide yet
- one final payer-root or meter schema;
- one final budget unit vocabulary;
- whether spend reservations and final charge verdicts share the same carrier;
- whether costs always settle synchronously with provider effects;
- whether any of this becomes core object-store data instead of adjacent receipts and provider-owned state.
