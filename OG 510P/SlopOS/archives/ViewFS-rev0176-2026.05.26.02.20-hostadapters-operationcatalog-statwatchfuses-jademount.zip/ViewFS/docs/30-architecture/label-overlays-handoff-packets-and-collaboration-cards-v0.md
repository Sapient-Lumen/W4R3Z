# Label overlays, handoff packets, and collaboration cards v0

Revision 162 also adds shell-facing collaboration honesty checks. ViewFS can render labels, handoff packets, and collaborator cards, but those surfaces are projections. They must not hide role mismatches, unresolved labels, widened delegated rights, or absent live authority.

The v0 lane separates:

```text
LabelOverlay
  -> HandoffPacket
  -> Delegation / Child Handle
  -> CollaborationCard
  -> Receipt
```

## Record families

- `LabelOverlay` — classification, sharing, and policy labels over an object, including conflict status and optional backing authority handle.
- `HandoffPacket` — a target-principal handoff of delegated authority with acceptance cut and child handle binding.
- `CollaborationCard` — a shell card that summarizes room, role, visible rights, labels, and live/inert authority badge.

## Anti-collapse rules

1. Labels are not policy verdicts and not handles.
2. Unresolved label conflicts deny before a label can be presented as settled state.
3. A live label badge requires a live handle scoped to the labeled object.
4. Handoff proposals are not accepted handoffs.
5. Handoff receipts cannot replay a transfer.
6. Accepted handoffs still need a valid delegation: live lease, source handle, child handle, attenuation envelope, and no right widening.
7. Collaboration cards must show roles and rights truthfully. A hidden write right, fake owner role, or live badge without backing slot is a denial specimen.

## Current fixtures

- `109-label-overlay-render-inert-allow.json`
- `110-label-overlay-conflict-unresolved-denied.json`
- `111-label-overlay-claims-live-denied.json`
- `112-label-overlay-live-badge-backed-allow.json`
- `113-handoff-accepted-delegation-allow.json`
- `114-handoff-missing-acceptance-denied.json`
- `115-handoff-target-mismatch-denied.json`
- `116-handoff-receipt-replay-denied.json`
- `117-handoff-widened-delegation-denied.json`
- `118-collaboration-card-honest-allow.json`
- `119-collaboration-card-live-badge-lie-denied.json`
- `120-collaboration-card-role-lie-denied.json`
- `121-collaboration-card-hidden-rights-denied.json`

## Shell posture

The shell should render these as cards with honest fuses:

- label overlay card: labels, conflict set, resolution cut, live/inert badge;
- handoff card: source principal, target principal, delegated child handle, acceptance cut, expiry/lease state;
- collaboration card: room, role, visible rights, backing authority slot, hidden-rights alarm.

The central UX rule is: **collaboration UI may guide attention, but only checked live authority may open, write, export, or delegate.**

## Non-goals

This v0 lane does not settle label ontology, enterprise directory semantics, workflow assignment, document comments, review ownership, or federated collaboration. It only adds executable checks for collaboration laundering.
