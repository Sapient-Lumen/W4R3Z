# Identity sessions and credential custody v0

Identity is not authority in ViewFS. This document fixes the narrow v0 lane added in Revision 166 so login state, credential ids, and external tokens cannot be mistaken for ViewFS object rights.

## Record lane

```text
IdentityAssertion
  -> SessionBinding
  -> CredentialToken
  -> Policy / plan cut
  -> Live authority handle
  -> Receipt
```

`IdentityAssertion` says an issuer made a subject claim at an assurance level. `SessionBinding` says that claim is currently bound to a subject and has not expired. `CredentialToken` says an external credential may be usable for a scoped external operation when the token is live, sender-constrained, and accompanied by the expected proof.

None of these rows is a ViewFS handle. They are facts consumed by policy and shell explanation.

## Denial posture

The checker denies:

- login badge as authority;
- expired session;
- assertion/session subject mismatch;
- bearer token without proof-of-possession posture;
- credential scope mismatch;
- refresh receipt replay.

## Shell posture

The shell may show account, authenticator, session, and credential posture, but every live badge must name the authority slot that backs the next effect. A credential card should answer "why this external call is eligible" without becoming the call.

## Open questions

- Whether ViewFS should model device-bound, authenticator-bound, workload-bound, and human-session-bound credentials as separate subfamilies.
- How much assurance vocabulary should be imported from identity standards versus left as policy-specific labels.
- Whether credential use should always go through the action-plan lane, or whether some low-risk read-only credentials may have a narrower fast path.
