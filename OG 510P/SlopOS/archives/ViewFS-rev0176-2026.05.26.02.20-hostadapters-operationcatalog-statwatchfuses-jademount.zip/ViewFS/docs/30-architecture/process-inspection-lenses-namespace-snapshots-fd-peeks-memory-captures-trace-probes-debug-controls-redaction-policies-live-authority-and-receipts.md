# Inspection lenses, process-view snapshots, fd peeks, memory captures, trace probes, debug controls, redaction policies, live authority, and receipts

Revision 147 adds an intentionally narrow but deep guardrail: **diagnostics are not free metadata**. ViewFS should make inspection delightful, but it should not smuggle process, namespace, handle, memory, trace, or debug authority through pretty panels.

## The seam

Keep these truths apart:

1. **Inspection intent** — who is asking to inspect what, why, under which local policy cut.
2. **Target locator** — the selected live process, room, worker, provider operation, child namespace, task, or object-store actor.
3. **Process-view / namespace snapshot** — a point-in-time statement of the target's visible roots, bound roots, imports, overlays, slot names, and provider badges.
4. **Handle/fd/slot peek** — a bounded row saying a slot exists and giving safe class metadata, not the handle itself.
5. **Memory/core/crash capture** — sensitive captured state that should be quarantined, redacted, retained, and exported as a risky object family.
6. **Trace probe / stream / processor** — live or recorded observation flow with schemas, filters, sampling, drops, and redaction state.
7. **Debug-control lane** — pause, resume, single-step, inject, register/memory read-write, fd duplication, namespace entry, or debug shell launch.
8. **Redaction / export policy** — the local cut deciding what leaves the target boundary, shell, support bundle, transcript, notebook, or repository.
9. **Current live inspection authority** — the actual handle, lease, membrane, or provider grant that can do one of the above now.
10. **Inspection receipts** — durable history and support-bundle explanation that does not carry current authority.

## Why this matters for ViewFS specifically

ViewFS wants explicit per-process namespaces and capability handles. That means diagnostic surfaces will be unusually tempting:

- `show me this process's namespace` can become a secret root leak;
- `show open handles` can become a confused duplicate-handle operation;
- `capture crash` can copy secret slots, app credentials, imported documents, and active user input into a durable object;
- `follow trace` can reveal object IDs, tenant IDs, content digests, path hints, or activity timing;
- `debug` can become full process control;
- `support bundle` can launder quarantined content, secrets, and capability graph structure into a zip.

The ViewFS answer should be powerful diagnostics with explicit lanes, not blanket opacity.

## Prior-art pressure

### Linux process interfaces
`ptrace` can observe and control another process, inspect and modify memory/registers, and operates per tracee thread. That is the core warning: the line between inspect and control is easy to blur.

Linux procfs gives more nuance:

- `hidepid` can limit visibility into other users' `/proc/<pid>` directories;
- `/proc/<pid>/fd` readlink/dereference checks are governed by ptrace access mode;
- `/proc/<pid>/mem` is direct process-memory access under stronger ptrace checks;
- `PR_SET_DUMPABLE` controls whether core dumps are produced and whether ordinary `PTRACE_ATTACH` is possible;
- `coredump_filter` controls which memory mappings go into a core file.

ViewFS should steal the underlying lesson, not the exact Linux knobs: process metadata, fd tables, memory, and crash dumps need named policy surfaces.

### Fuchsia Inspect and diagnostics
Fuchsia Inspect exposes structured hierarchical runtime state, and the Archivist ingests Inspect/log data through diagnostics protocols. That is a good model for typed diagnostics. ViewFS should pair it with the stricter rule that a structured snapshot is still only a redacted observation artifact, not a live handle table, namespace root, or support-bundle export right.

### ETW, DTrace, and tracing systems
ETW separates controllers, providers, and consumers and accounts for lost events. DTrace separates user/kernel/process privileges and requires explicit opt-in for destructive actions. ViewFS should steal both ideas:

- trace installation is not trace consumption;
- provider-side event schemas are not export permission;
- a trace processor is not privileged code;
- lost/dropped/sample-only state must be visible;
- destructive debug/control is a separate gate.

### Kubernetes subresources
Kubernetes RBAC treats pod logs as a subresource and also has separate subresources for things like exec/attach/port-forward. That maps cleanly onto ViewFS shell lanes: `follow logs`, `inspect state`, `attach terminal`, `debug exec`, and `open sideband` should not collapse.

### macOS privacy gates
macOS names separate privacy categories such as Full Disk Access, Accessibility, Automation, Input Monitoring, Screen & System Audio Recording, and Remote Desktop. The important lesson is not the exact categories; it is that observation and control are user-visible powers.

### SlopOS sibling-cube material
The included SlopOS archive has several directly relevant seams:

- `capshell-peer-inspection-posture-v0.md` already rejects ambient same-principal inspectability and dumpability inheritance as a launch baseline.
- `inspect-snapshot-schema-v0.md` treats diagnostic snapshots as bounded, canonical, redaction-aware exports.
- `observation-export-policy-schema-v0.md` and `observation-export-posture-v0.md` keep exported observations policy-owned and minimized.
- `tracepoint-descriptor-schema-v0.md` and `trace-processing-schema-v1.md` separate event schemas, trace records, predicate/filter material, processors, bounds, and output discipline.
- `microvm-debug-introspection-posture-v0.md` declines portable host-side guest-debug or memory-dump contracts in Phase 1.

ViewFS should steal the caution: support diagnostics without prematurely turning SlopOS CH-INSPECT/CH-TRACE into the final ViewFS diagnostic ABI.

## Suggested object vocabulary, still provisional

These names are intentionally tentative:

- **InspectionIntent** — reviewed diagnostic/debug request with target, purpose, scope, and export posture.
- **ProcessViewLocator** — non-authoritative pointer to the current live target; can die or become stale.
- **NamespaceSnapshot** — bounded, redacted, point-in-time description of roots, imports, slots, and live binds.
- **SlotPeek** — class metadata for a live handle/fd/slot without duplication or dereference authority.
- **TraceProbeDescriptor** — schema for trace fields and redaction classes.
- **TraceFuse** — an installed trace/feed/subscription bounded by target, probes, TTL, buffer, and export policy.
- **CrashCapture** — captured memory/register/core state as a quarantined object with redaction and retention posture.
- **DebugRail** — explicit pause/step/inject/attach/control lane, not a subtype of watch or inspect.
- **ObservationExportCut** — policy decision saying what leaves the local boundary.
- **InspectionReceipt** — redacted, durable record of diagnostic action, denial, export, cleanup, or destruction.

## Non-authority classes

These must not be treated as current live authority:

- process IDs, task IDs, worker names, or pane IDs;
- namespace snapshots;
- slot/handle inventory rows;
- trace descriptors;
- trace samples or counters;
- redaction masks;
- support-bundle manifests;
- crash dump metadata;
- old debugger receipts;
- UI badges saying `inspectable`, `captured`, `redacted`, `exported`, or `history only`.

## Redaction and support bundle posture

A ViewFS support bundle should prefer:

- digest-bound references rather than raw handles;
- redacted subject/issuer/recipient hints;
- class and scope badges rather than raw object IDs when possible;
- explicit `raw omitted`, `sampled`, `dropped`, `hash only`, and `needs local re-run` marks;
- quarantine inheritance for memory/core/crash captures;
- export receipts that name the redaction policy and destination class.

It should avoid:

- raw capability handles or provider tokens;
- `/proc/<pid>/fd` path strings that can act as confused designators;
- unredacted environment values, secret projections, command lines, app data, screenshots, or input snippets;
- raw memory unless a separate guarded lane is deliberately chosen;
- stable cross-support-bundle IDs that enable long-term tracking by accident.

## Shell implications

The shell can show:

- `inspect lens: redacted snapshot only`;
- `slot peek: class metadata, no duplicate`;
- `trace fuse: live, sampled, dropped, or sealed`;
- `dump guard: quarantined / redaction pending / export denied`;
- `debug rail: armed / attached / stopped / control ended`;
- `support bundle: local only / export cut passed / receipt only`.

Those labels matter. They are how users learn that an inert inspection panel is not a debugger and a crash dump is not ordinary log text.

## Concrete examples

### Show a child process's ViewFS roots

Good flow:

1. User asks for an inspection lens.
2. Policy checks whether the shell has observation authority for that child.
3. Provider returns a bounded namespace snapshot with root badges and slot classes.
4. Shell shows redaction badges and `no duplicate handles`.
5. Receipt records target class, policy digest, and snapshot digest.

Bad flow:

- Shell scrapes host `/proc`, shows raw paths, exposes fd symlinks, and lets the user click them as ordinary ViewFS handles.

### Capture a crash for support

Good flow:

1. Crash-capture policy decides whether dumpable/capture is allowed.
2. Capture becomes a quarantined object with retention and redaction state.
3. Redaction/export cut produces a smaller support bundle.
4. Original capture remains local, time-bounded, and sweepable unless pinned.
5. Receipt says what was exported and what was omitted.

Bad flow:

- Core dump silently enters search, semantic summaries, or a shared bug-report zip with secrets and handle-like identifiers intact.

### Follow an object-store trace

Good flow:

1. Trace fuse installs only named probes for one target/view/operation.
2. Field descriptor marks object IDs, tenant hints, cap IDs, and addresses by redaction class.
3. Processor emits counters or summaries under bounds.
4. Drops/overflows/sampling are visible.
5. Trace receipt cannot replay the subscription.

Bad flow:

- Trace stream is treated as complete object-store truth or as permission to attach/debug the provider.

## Open questions

- Should ViewFS expose a generic diagnostics object family, or keep provider-specific families connected by shell chrome?
- How much of SlopOS CH-INSPECT/CH-TRACE should be re-used versus mirrored with ViewFS-specific concepts?
- Can slot peeks be privacy-preserving enough for ordinary users, or should they be developer-only?
- Should crash captures participate in the same quarantine/GC/supply-chain evidence lanes as imported artifacts?
- How do we show enough provenance to debug authority flow without exposing the entire capability graph?
- What should be the default stance for terminal transcripts that include redacted diagnostic panels?

## Guardrail summary

**Inspect intent is not live authority. A namespace snapshot is not a namespace. A slot peek is not a handle. A trace stream is not state truth. A crash capture is not a log. A redaction lens is not containment. A debug rail is not observe-only. A receipt is not a future debugger.**
