# Assembly recipes, member descriptors, aggregate objects, realized work surfaces, live facets, and receipts

Purpose: keep a likely future ViewFS object-store seam honest while SlopOS and ViewFS are both still in design.

## The split
When a system says “here is the object”, that may hide several layers:
1. one **assembly recipe** saying which members and transforms were intended,
2. one set of **member descriptors** saying what exact ingredients were referenced,
3. one durable **aggregate object** minted after successful assembly,
4. one **realized work surface** produced by unpack / mount / hydrate / project steps,
5. one **current live facet** over either the aggregate or its realized surface,
6. and one **receipt/history row** describing how we got here.

Those are not the same thing.

## Why the split matters
- A recipe can be reviewed, diffed, signed, cached, or denied before anything is assembled.
- Member descriptors can remain mechanically useful after source URLs, local filenames, or provider-native names disappear.
- An aggregate object can be durably committed while no realized work surface currently exists.
- A realized work surface can be evicted and later rebuilt without changing the aggregate object.
- A live facet is still stronger than the recipe, member descriptors, aggregate seal, or receipt row.

## Lessons worth stealing
- **compose without folklore**: object stores should be able to say “new aggregate created from these members” without pretending the source names or source authority came along for free.
- **descriptor graphs without overclaiming**: descriptor/index layers are useful even when they are not themselves the final working surface.
- **realize explicitly**: unpacking, mounting, hydrating, or expanding should be explicit transitions, not magical side effects of lookup.
- **history without resurrection**: receipts and realized-history rows should stay informative without becoming live power.

## Decision-light posture
ViewFS should preserve freedom on:
- whether recipe objects are immutable first-class objects or descriptive sidecars,
- whether member descriptors are always content-addressed,
- whether aggregate objects are tree-like, package-like, closure-like, or family-specific,
- whether realization creates fresh local objects, reversible projections, ephemeral snapshots, or provider-owned workspaces,
- which layer is directly visible to legacy path compatibility shims.

## Vocabulary worth prototyping in the shell
- **recipe cards** — recipe exists, reviewed, stale, denied, history only
- **member rails** — member set complete, missing, hidden by provider, stale, replaced
- **aggregate seals** — aggregate committed, rejected, partial, superseded, history only
- **unpack lamps** — not realized, realized here, realized elsewhere, evicted, rebuildable
- **live rails** — inspect now, read now, edit now, publish now, history only
