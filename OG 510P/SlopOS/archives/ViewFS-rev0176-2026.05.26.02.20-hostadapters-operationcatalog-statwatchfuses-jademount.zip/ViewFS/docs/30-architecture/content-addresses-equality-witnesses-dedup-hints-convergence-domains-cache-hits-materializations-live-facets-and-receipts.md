# Content addresses, equality witnesses, dedup hints, convergence domains, cache hits, materializations, live facets, and receipts

Revision 151 adds an object-store privacy seam: **content-addressed storage is storage truth, not current authority and not a safe membership oracle**.

The previous object-store notes already separated semantic object cores, byte proofs, shape hashes, strong proofs, weak validators, fresh object identities, shared backing, lineage, partial residency, GC roots, quarantine, extraction, supply-chain evidence, and live facets. This note sharpens the remaining trap: a future ViewFS storage engine will want to reuse bytes. It must not accidentally leak who has what, prove ownership from a hash, clear quarantine, collapse fresh identity, create a retention root, or mint authority from a cache row.

## Prior-art pressure

### Venti and Foundation
Venti is the good dream: blocks named by content hashes, write-once archival storage, and coalescing duplicate data. Foundation shows how such scores can back cheap snapshots and disk images. The lesson is not `make every ViewFS object a Venti block`. It is: content addressing is a wonderful low-level storage property when it stays honest about what it names.

### IPFS CIDs
IPFS CIDs are self-describing content identifiers; they encode multihash/multicodec/multibase choices and can name a DAG root. That is useful because it avoids a naked `hash` myth. It is also a warning: the address profile matters. A CID, a whole-file digest, a chunk hash, and a semantic-object id may all disagree without any of them being wrong.

### Nix content addressing
Nix keeps useful distinctions between input-addressed and content-addressed store objects. A content-addressed store path is not just a raw file checksum; it carries store-object context, method, references, and name. ViewFS should likewise avoid a universal content-address story that pretends packages, documents, blobs, semantic records, and directories all share one identity profile.

### Deduplicated encryption and Tahoe-LAFS
Convergent or message-locked encryption turns equality into storage savings, but equality can leak. Tahoe-LAFS's convergence-secret discussion is the right instinct: there must be a domain story, and the tradeoff is real. A per-user secret reduces cross-user equality leakage and gives up cross-user dedup. A global convergent domain gains dedup and leaks more.

### Proofs of ownership
Client-side dedup can turn `I know a hash` into `the service thinks I own the file`. Proof-of-ownership research exists because that shortcut is dangerous. ViewFS should treat a content address as an input to proof, not as proof by itself.

### ZFS and KSM
ZFS dedup shows that dedup has resource cost and operational coupling. KSM and SlopOS's microVM memory-dedup posture show the isolation side: content-based merging can expose timing/membership facts. Storage dedup is not just economics; it is a policy and side-channel seam.

## Classes to keep separate

### Content address / byte proof
A digest, CID, Merkle root, closure hash, store path, verified-blob descriptor, or canonical-payload proof under a named profile.

Questions it can answer:
- Did this byte sequence / chunk graph / canonical payload match the stated proof?
- Which algorithm/profile produced the proof?

Questions it must not answer alone:
- Who can read it?
- Is it trusted or quarantined?
- Is it local now?
- Does anyone else have it?
- May it be executed, imported, published, or retained?

### Equality witness / comparison profile
A declaration of the kind of sameness:

- exact raw bytes;
- canonical payload;
- chunk-DAG root;
- file-system closure;
- semantic object core;
- weak validator;
- provider revision;
- quarantine-equivalent derived artifact;
- application-specific normalized view.

A witness should name its profile before it says `same`.

### Dedup eligibility hint
A policy hint such as:

- no dedup;
- intra-object only;
- same object family;
- same owner;
- same project/workspace;
- same tenant;
- public/global;
- provider-private/opaque;
- encrypted-dedup domain.

Eligibility is not itself proof that sharing happened.

### Convergence / privacy domain
The domain that determines whether equal plaintext can produce equal stored material:

- random per-object key: no equality across objects;
- per-user convergence secret;
- per-project convergence secret;
- tenant-wide convergence secret;
- public/global convergence;
- server-aided/message-locked protocol;
- provider-local opaque dedup;
- no encrypted dedup.

This should be a loud security/privacy setting, not a hidden optimization knob.

### Cache-hit / membership observation
An observation such as `already had chunk`, `remote provider says present`, `CID cached`, `dedup table hit`, `shared extent reused`, or `range already materialized`.

Default posture: expose only within the same authorized object/materialization workflow, redact across principals, and never make hit/miss a general query API.

### Proof of possession / ownership
A stronger check that a subject actually has bytes or authorized access. This could later be:

- local full-byte availability under a handle;
- range challenge over bytes;
- Merkle proof challenge;
- provider-owned proof-of-ownership;
- portal-mediated import proof;
- a policy decision to avoid client-side dedup entirely.

The point is not to choose one. The point is to avoid treating a digest string as enough.

### Materialization / storage decision
The actual choice:

- store new bytes;
- reuse local backing;
- share extents;
- hydrate ranges;
- deep-copy now;
- unshare now;
- keep sparse;
- seal verified copy;
- refuse cross-domain dedup;
- emit only a receipt.

This is where fresh object identity, quarantine, origin, lineage, and live binds must be preserved.

### Live facet
The current authority: inspect/read/edit/export/import/publish/execute/sync capability held by a process/room/session now. It is stronger than every content-address card.

### Receipts
History about proof checks, equality comparisons, dedup decisions, cache observations, materialization, unshare, import, export, and cleanup. Receipts must be useful for audit and useless as current membership probes or handles.

## Design consequences

1. **Do not expose a generic `hasDigest?` API.** Exact membership queries are capability-sensitive and often privacy-sensitive.
2. **Do not let content-address URLs become capabilities.** A public digest can be a locator or proof, not a read grant.
3. **Do not dedupe away origin/quarantine.** A same-byte import can still be newly risky.
4. **Do not let dedup clear SBOM/admission work.** Package evidence and local admission still bind to this activation target.
5. **Do not let dedup create retention roots.** Storage reuse is below object liveness unless explicitly rooted.
6. **Do not let dedup decide quota/charge rights.** Accounting needs its own payer/budget lane.
7. **Do not let cache hit become offline readiness.** A chunk hit and complete sealed local object are different truths.
8. **Do not let provider-private dedup leak into shell truth.** `maybe reused by provider` may be the only safe UI.
9. **Do not let convergence-domain changes silently reinterpret old receipts.** Old receipts record old posture.
10. **Do not let equality profile default to `obvious`.** There is no obvious sameness across blobs, DAGs, directories, packages, semantic records, and live objects.

## SlopOS pressure

The included SlopOS archive remains design-stage, but the pressure is useful:

- `import-to-docref-fresh-identity-boundary-v0.md` refuses to collapse fresh identity just because bytes match.
- `open-untrusted-export-lineage-boundary-v0.md` keeps lineage explicit rather than inferred from paths or same bytes.
- `verified-blob-descriptor-schema-v0.md` treats Merkle verification descriptors as non-authoritative audit/binding/debug material.
- `artifact-reference-schema-v0.md` makes locators hints while digest is content identity for that artifact reference.
- `microvm-memory-dedup-posture-v0.md` refuses a portable `mem-merge` / KSM plane because merging is isolation-sensitive.
- `quarantined-content-index-boundary-v0.md` refuses ambient content-derived extraction from quarantined bytes.

ViewFS should steal the separations, not the exact schemas.

## Nifty ideas to steal

- **Digest shades** for `raw-byte`, `canonical-payload`, `CID/DAG`, `closure/store`, `verified-blob`, `weak`, `private`, `public`, `unknown`.
- **Equality rails** that say `same under exact bytes`, `same under canonical payload`, `same under semantic core`, `same under weak validator`, or `not comparable`.
- **Dedup shutters** for `off`, `local-only`, `same-owner`, `project`, `tenant`, `public/global`, `provider-opaque`, `encrypted-domain`.
- **Convergence lamps** for `random-key`, `per-user secret`, `project secret`, `tenant secret`, `global convergent`, `server-aided`, `none`.
- **Cache ghosts** that say `hit here`, `miss here`, `hidden cross-principal`, `provider opaque`, `receipt-only`.
- **Possession challenge cards** that distinguish `knows digest` from `proved bytes`.
- **Leakage budget meters** for cross-domain dedup, public locator publication, and side-channel exposure.
- **Unshare/deep-copy ladders** when privacy, deletion, export, or provenance needs a fresh backing decision.
- **Membership-safe receipts** that explain dedup decisions without becoming `who has this?` APIs.

## Non-decisions

Still open:

- whether ViewFS has one or many content-address profiles;
- whether CIDs, Nix-like store paths, OCI descriptors, CH-VBLOB-like descriptors, or local Merkle proofs become native or adapter-owned;
- whether encrypted dedup exists at all;
- whether any dedup may cross users, projects, tenants, or providers;
- whether proof-of-possession should be a portal protocol, provider protocol, or never exposed;
- how much dedup/cache telemetry is safe for ordinary shells;
- whether content addresses are safe to put in transcripts by default;
- how storage savings interact with payer/budget lanes.

The durable principle: **reuse backing when it is useful, but never let reuse become identity, trust, authority, membership, retention, or privacy policy by accident.**

## Other included datacube pressure

The sibling archives sharpen the same seam without requiring ViewFS to inherit their schemas:

- **Foundry** already names pending duplicate, dedupe horizon, and expiry gate as different retry truths. That is useful for ViewFS because a duplicate-safe replay horizon is not an eternal content-membership proof.
- **Ward** keeps identity witness, dedupe posture, correction lineage, raw append history, current winners, and tombstone-aware history apart. That maps directly to ViewFS equality witnesses and dedup posture.
- **Helm** uses a surface-core digest as a portable carried-core identity, not as the whole landing envelope. That is the right shape for ViewFS semantic cores: digest the intended subset and still keep overlays, residue, fit, and adoption separate.
- **Schell** warns that change digests and unread cards are glance artifacts, not raw streams, currentness, or authority. That same humility should apply to ViewFS digest cards and cache ghosts.
- **Harbor** keeps cache epochs and admission truth separate. That warns ViewFS not to let cached locator or schema rows become current materialization or import permission.

The cross-cube lesson is narrow and durable: dedupe/comparison aids should carry their identity rule, horizon, correction posture, and cache epoch; they should not become timeless equality or authority claims.
