# Incident, forensic, containment, remediation, rollback, and postmortem v0

Revision 171 adds an incident-response slice to the executable ViewFS core. The slice covers operational evidence and response artifacts that are easy to over-trust in a companion shell: alert signals, incident cases, triage verdicts, forensic snapshots, evidence chains, containment plans, remediation plans, recovery rollbacks, and postmortem records.

The rule is deliberately narrow:

> Incident-response artifacts may detect, correlate, explain, preserve, constrain, and review. They do not become object authority, disclosure authority, remediation authority, proof of closure, or proof that recurrence is impossible.

## Record families

| Record family | Purpose | Non-authority warning |
|---|---|---|
| `AlertSignal` | Detector output with subject binding, severity, source, active/stale state, and observation authority. | An alert is not read authority, containment authority, or proof of compromise. |
| `IncidentCase` | Case wrapper binding active alert context, subject, status, and case-handling authority. | Case status is not remediation, disclosure, or write authority. |
| `TriageVerdict` | Current human/tool verdict with confidence, classification, and triage authority. | Triage recommendations do not execute containment or repair effects. |
| `ForensicSnapshot` | Sealed capture/observation artifact with capture authority and redaction posture. | A snapshot is not a live open, raw disclosure right, or global truth. |
| `EvidenceChain` | Tamper-evident bundle linking incident evidence, snapshots, and digests. | Evidence integrity does not prove causality or grant access. |
| `ContainmentPlan` | Approved, blast-radius-reviewed plan for bounded containment effects. | The plan is not broad authority and cannot widen effects at execution time. |
| `RemediationPlan` | Approved repair/remediation plan with preconditions and live remediation authority. | Remediation receipts and checklists do not replay repair or close the incident. |
| `RecoveryRollback` | Approved rollback/recovery plan over a current epoch. | Rollback does not erase incident history, retained evidence, or postmortem duties. |
| `PostmortemRecord` | Redacted shell/review record of timeline, lessons, and residual duties. | Postmortems do not prove no recurrence and must not reveal blocked fields or claim live authority. |

## Checked operations

`admit_alert_signal` admits an alert only when it is active, subject-bound, not claiming authority, and backed by observe/security/incident-intake authority.

`open_incident_case` admits a case only when it is open/investigating, bound to an active alert, not claiming remediation authority, and backed by case/incident authority.

`apply_triage_verdict` admits a triage verdict only when it is current, sufficiently confident, non-executing, and backed by triage/incident authority.

`capture_forensic_snapshot` admits a sealed forensic capture only when redaction checks pass, no live-access claim is made, and capture/snapshot authority is current.

`verify_evidence_chain` verifies only complete, tamper-evident chains with matching digest and evidence verification authority; claims of causal truth deny.

`approve_containment_plan` admits only approved, blast-radius-reviewed, non-widening containment plans backed by containment authority.

`execute_remediation_plan` admits only approved remediation with preconditions met and live remediation authority; old receipts and closure claims deny.

`execute_recovery_rollback` admits only approved rollback over the current epoch with rollback authority; stale bases and “erases incident” claims deny.

`render_postmortem_record` renders only honest, redacted postmortem records that do not claim live authority, public release, or no-recurrence without backing authority.

## Anti-collapse rule

Incident response needs strong narrative surfaces, but narrative is not authority. Future incident dashboards, AI responders, forensic previews, ticketing connectors, and repair assistants must keep detection, case management, evidence preservation, containment, remediation, recovery, disclosure, and learning as separate lanes.
