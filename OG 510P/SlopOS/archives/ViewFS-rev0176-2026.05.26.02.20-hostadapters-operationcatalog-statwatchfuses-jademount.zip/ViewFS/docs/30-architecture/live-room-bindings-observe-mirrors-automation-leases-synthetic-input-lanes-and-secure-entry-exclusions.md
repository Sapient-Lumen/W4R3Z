# Live room bindings, observe mirrors, automation leases, synthetic input lanes, and secure-entry exclusions

Purpose: keep **live room bindings**, **observe/semantic mirrors**, **automation lease posture**, **actual synthetic-input lanes**, **secure-entry redaction/exclusion state**, and **receipts** on different seams while SlopOS is still settling accessibility, automation, and trusted-UI meaning.

## Why this split matters
The easiest way to over-design shell automation is to let one vague `automation` object silently absorb five different questions:
- what is live here now,
- what mirror of that state is visible,
- what lease/session says observation or control is allowed,
- whether synthetic input can actually flow now,
- and whether secure entry currently clamps those lanes.

Those are different product truths and different authority shapes.

## Distinct classes
- **live room binding** — exact thing bound in the room namespace now
- **observe mirror** — semantic tree, screencast, focus/highlight mirror, or redacted inspect strip
- **automation lease** — reviewable session posture with scope/TTL/policy note
- **synthetic input lane** — actual currently usable injection/control path
- **secure-entry exclusion** — current redaction or no-injection clamp for sensitive entry
- **receipt** — durable explanation of what happened before

## Lessons worth stealing
### InputCapture gives us the right humility
A client can enable capture, but the compositor decides when capture becomes active and which devices are captured.
That is exactly the posture ViewFS should steal: request/session truth is weaker than current delivery truth.

### Remote-control sessions should stay explicit
RemoteDesktop keeps the session and the eventual EIS path explicit enough that once that path exists, input must use it.
That is a strong precedent for an explicit input lane rather than a generic automation bit.

### Screen mirrors are not room identity
ScreenCast and MediaProjection both make capture explicit and user-mediated.
That is the right humility for ViewFS: `I can mirror this now` is not `this room object is mine`.

### Secure surfaces deserve their own clamp state
Android `FLAG_SECURE`, Windows secure-desktop/UIAccess policy, and SlopOS secure-attention posture all reinforce the same product rule: sensitive entry can block capture/injection without rewriting room identity or history.

### Accessibility is powerful enough to deserve shell honesty
Fuchsia accessibility posture makes it plain that assistive tooling can intercept gestures, inject input, and manage accessibility focus/highlights.
That is exactly why ViewFS should surface assistive/automation lanes as visible leased posture instead of helper folklore.

## Shell pressure this unlocks
- **mirror strips** that say `semantic mirror`, `screen mirror`, `redacted`, `delayed`, or `receipt only`
- **lease chips** that say `observe only`, `rehearse only`, `inject allowed`, `revoked`, or `expired`
- **rehearsal rails** that let the shell preview where automation would act before actual injection exists
- **secure-entry curtains** that explain `mirror redacted`, `input blocked`, `secure field`, or `trusted chooser active`
- **quality badges** that admit whether the shell knows room/UI truth richly, partially, or approximately

## Non-decisions preserved
Do not freeze yet:
- one final mirror schema,
- one final split between assistive and test automation,
- whether observe mirrors are shell-owned, terminal-owned, or compositor-owned,
- whether secure-entry exclusions and secure-entry gates share a common carrier,
- whether remote-support and local assistive tooling share one automation-lease taxonomy.
