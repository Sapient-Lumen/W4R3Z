# Live room bindings, currentness witnesses, semantic epochs, and repair offers

This note protects one more high-value seam while ViewFS and SlopOS are both still moving.

Revision 0101 already split durable anchors, live room binds, stale shadows, repair plans, and receipts.
Revision 0102 already split activation kits, restart lockers, namespace pins, and live room binds.
This note adds another discipline on top:

**the live room binding now, the witness that says whether it is still current, the semantic epoch/hop scope that says whether the shell still has exact footing, the repair offer surfaced to the user, and the receipt explaining what happened are different classes.**

## The split

### 1. Live room binding
A live room binding is the answer to:
- what exact object, projection, import, or current handle is this room actually holding right now?

Good examples:
- one current document projection in the room namespace,
- one current local object bind,
- one current imported helper capability,
- one current child-room binding delivered by reviewed spawn/import flow.

This is current authority truth.
It is not the witness that says whether this truth is still current enough for the next action.

### 2. Currentness witness
A currentness witness is the answer to:
- what exact evidence says whether the current bind is still good, replaced, revoked, expired, unknown, or in need of refresh?

Good examples:
- one provider generation or revocation epoch,
- one portal/session freshness token,
- one watch/status carrier,
- one holder-bound proof or step-up result,
- one successor notice that says a fresher bind exists.

This is currentness truth.
It is not the bind itself.

### 3. Semantic epoch / hop scope
A semantic epoch is the answer to:
- does this command frame, target anchor, cwd belief, or affordance still belong to the same semantic world and hop path the shell thinks it is in?

Good examples:
- one pane-local semantic epoch after shell resync,
- one hop-lineage token after multiplexer or remote change,
- one target anchor that expected the previous epoch,
- one precision fence that says semantic footing degraded.

This is shell-observational truth.
It is not provider-side revocation truth.

### 4. Repair offer
A repair offer is the answer to:
- what bounded next move is worth surfacing now that bind truth, currentness truth, and semantic footing no longer line up well enough?

Good examples:
- `refresh witness`,
- `revalidate now`,
- `reconsent via portal`,
- `rebind from anchor`,
- `make local instead`,
- `rerun clean`,
- `inspect stale shadow first`.

A repair offer is deliberately smaller than a giant automatic repair plane.
It is one reviewed next-step proposal, not hidden magic.

### 5. Receipt/history
Receipts preserve explanation of:
- what currentness witness was consulted,
- whether semantic epoch shifted,
- whether a stale action was refused,
- whether a repair offer was accepted or dismissed,
- and whether a revalidation/rebind/reconsent succeeded.

Receipts should not silently revive live authority or restore old semantic footing.

## Product consequences

### Epoch lamps
The shell should be able to show compact lamps such as:
- `same epoch`,
- `epoch shifted`,
- `hop changed`,
- `semantic footing downgraded`,
- `anchor from older epoch`.

This is not just decoration.
It is the shell admitting what semantic world it thinks it is acting in.

### Currentness drawers
A room or object card should be able to say:
- `current as of witness 54`,
- `successor available`,
- `expired`,
- `revoked`,
- `refresh required`,
- `currentness unknown`.

That is better than one flattering `available` bit.

### Repair-offer cards
When currentness and semantic footing drift apart, the shell should surface compact offer cards such as:
- `refresh witness only`,
- `rebind here`,
- `reconsent`,
- `make local`,
- `rerun clean`,
- `dismiss and keep receipt only`.

Offer cards should explain what class of move they are about to take and what they will not do.

### Hop badges
A room or pane should be able to show small badges such as:
- `local`,
- `tmux`,
- `ssh`,
- `nested shell`,
- `remote cwd exact`,
- `remote cwd approximate`.

That keeps room-local namespace truth and shell-semantic truth from melting into one pane myth.

### Anchor stale fences
A target anchor, route chip, or command-finished affordance should be able to say:
- `same target, older epoch`,
- `exact anchor stale`,
- `revalidate before stop`,
- `receipt only now`.

That is exactly the kind of honesty old systems usually lacked.

## Why this fits current SlopOS work
Current SlopOS already leans toward:
- explicit document/import/session surfaces rather than ambient path folklore,
- explicit optional persistence with expiry/revocation hooks,
- descriptive wallets instead of authority-bearing summaries,
- exact child handle tables and explicit filesystem posture instead of ambient inheritance,
- typed activation continuity rather than one vague restore story.

That gives ViewFS permission to protect this seam **without** deciding the final witness schema, final semantic-epoch carrier, final repair-offer encoding, or final object-store layout.

## Good questions to keep open
- When should provider currentness and shell semantic epoch be allowed to disagree without blocking low-risk actions?
- Which verbs should require a fresher currentness witness than ordinary open/reveal?
- Should some repair offers consume one-time proofs or one-time portal sessions?
- Can a room keep old receipts/history after the semantic epoch changes without tempting users into stale exact actions?
- Which currentness witnesses are provider-owned versus manager-owned versus shell-local summaries?
