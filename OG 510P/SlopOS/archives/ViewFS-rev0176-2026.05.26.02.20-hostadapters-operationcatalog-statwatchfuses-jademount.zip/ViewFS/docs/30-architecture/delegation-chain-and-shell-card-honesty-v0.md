# Delegation chain and shell-card honesty v0

Revision 157 adds two pressure lanes that should evolve together: delegated authority chains and shell-card honesty. Delegations are how authority moves. Shell cards are how people see that movement. The machine must not confuse either one with the other.

## Delegation lane

A delegation record is a membrane event, not just a copied handle.

```text
Delegation(
  id,
  source_handle,
  child_handle,
  attenuation_envelope,
  lease,
  status
)
```

The first executable rule is intentionally small:

```text
source handle live
AND child handle live
AND same object
AND lease live
AND delegation issued/live
AND envelope rights subset of source rights
AND child rights subset of envelope rights
```

Only then may the child handle be used through the delegation lane.

## Why not just handle attenuation?

Handle attenuation proves a local no-widen property. Delegation adds custody pressure:

- who intended the handoff;
- which membrane/lease carried it;
- which child handle resulted;
- which revocation wavefront or recall later cut it off;
- which receipt remains visible after the delegated handle dies.

Ward pressure matters here: delegation is accountable stewardship, not just an object-capability copy.

## Delegation fixtures

- `024-delegation-narrow-handle-allow.json` allows a read-only delegated child handle within a live lease envelope.
- `025-delegation-widen-handle-denied.json` denies a child handle that widens rights beyond the source/envelope.
- `026-delegation-revoked-wavefront-denied.json` denies a recalled delegation while keeping the recall receipt as history.

## Shell-card lane

A shell card is a human-facing projection over backing records. It can show a receipt, a handle, a view bind, a consent chain, a retention root, or a delegation. It cannot create any of those.

Minimum shell-card fields for the fixture lane:

```text
ShellCard(
  id,
  subject,
  subject_class,
  authority_badge,
  authority_slot?,
  retention_badge?
)
```

A card claiming `authority_badge = live` must name a live backing authority slot. A card for receipt history should normally say `inert`. If a card says a source is retained, that needs a live handle or active retention root behind it.

## Shell-card fixtures

- `027-shell-card-receipt-inert-honest-allow.json` allows a receipt-history card labeled inert.
- `028-shell-card-receipt-claims-live-denied.json` denies a card that claims a receipt is live authority.

## Shell affordance rule

For every shell affordance, ask two questions:

1. What backing record makes this badge true?
2. What operation would fail if the badge were lying?

If the second question has no executable answer, the badge is decorative and should be downgraded to advisory UI.

## Non-claims

- This does not define the final ViewFS shell-card grammar.
- This does not define a visual design system.
- This does not make receipts useless; it makes them honest.
- This does not decide distributed delegation semantics.

The v0 rule is only: delegated authority must not widen, and shell renderings must not launder inert history into live authority.
