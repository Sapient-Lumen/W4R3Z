# Prompt text, typed action plans, tool invocations, approval cuts, and live authority

ViewFS can host agentic shell workflows, but the v0 rule is severe: **prompt text is not an action**. A model may propose. Retrieved text may suggest. Tool descriptions may advertise. Only a typed action plan with an approval cut and current live authority can invoke an effectful operation.

## Minimal lane

```text
InstructionFrame / prompt / retrieved text
  -> proposal text
  -> typed ActionPlan(effect, target, authority slots)
  -> approval cut over exact summary
  -> tool invocation with current live handle
  -> result + receipt
```

## Required separations

| Class | Useful role | Must not become |
|---|---|---|
| prompt text | user request or ambient instruction source | tool invocation authority |
| retrieved text | context for model reasoning | policy or approval |
| model proposal | candidate operation | committed action |
| typed action plan | structured effect proposal | approval by itself |
| approval cut | human/policy adoption of exact plan | standing authority outside named slots |
| live handle | current effect authority | explanation or receipt |
| receipt | result history | permission to rerun |

## First checked behavior

Revision 156 adds:

- `016-prompt-text-tool-invocation-denied.json` — prompt text saying “write the report” is denied.
- `017-approved-action-plan-tool-invocation-allow.json` — typed action plan plus approval cut plus live write handle is allowed.

This lane is deliberately compatible with MCP-like tool surfaces but stricter than many current agent stacks: tool catalogs, prompts, and model outputs are treated as inputs to planning, not as authority.

## Later work

Future revisions should add:

- tool-output injection fixtures;
- hidden tool-call/covert invocation denial fixtures;
- parent-workspace instruction discovery fixtures;
- model-memory replay fixtures;
- multi-step budget and cancellation fixtures;
- approval expiry and summary-mismatch fixtures;
- shell-card render fixtures for toolcall fuses.

The target is not to eliminate automation. The target is to make automation inspectable and bounded: who proposed, who approved, which authority slot was spent, and what receipt remains.
