# Live room bindings, provider projection sites, published room aliases, and localizations

Purpose: keep **live room bindings**, **provider-backed projection sites**, **published room aliases/slots**, **localization/materialization facts**, and **receipts** on different seams while SlopOS is still settling what its datacube/store/portal layers will finally own.

## Why this split matters
A lot of import/open confusion comes from letting one visible path or tab title answer every question at once.
ViewFS should instead let the shell answer, separately:
- is there a live binding here now?
- is this only reachable through a provider/portal projection site?
- did this room choose to publish a local alias/slot for it?
- do the bytes or object state actually live here now?
- or do we only have history explaining that one of those things used to be true?

That makes the future shell more honest and keeps the object-store design open longer.

## Distinct classes
- **live room binding** — exact thing bound here now
- **provider projection site** — synthetic/provider-backed/portal-backed reachability site
- **published room alias** — room-chosen local slot/name for this thing here
- **localization / local realization** — placeholder, hydrated copy, replica, or true local object-store fact
- **receipt** — durable explanation of what happened before

## Lessons worth stealing
### A projected namespace site is weaker than local publication
XDG Documents exposes exported files through a restricted synthetic FUSE tree keyed by document IDs and per-app permissions.
That is a very strong precedent for keeping `projection site` separate from `published here` and from `lives here`.

### Provider-managed trees can be truthful without pretending to be local storage
Android SAF says the provider data model is a traditional hierarchy while explicitly allowing the provider to store the data however it likes.
That is exactly why ViewFS should not let one pretty path silently decide locality.

### Namespace population and outgoing publication are different acts
Fuchsia components consume objects from the namespace they are given and separately publish objects through the outgoing directory to others.
That is a powerful reminder that visibility, routing, and underlying object truth are not the same class.

### Placeholder and hydration posture deserve their own chrome
Cloud Files hydration and placeholder conversion are useful because they make `placeholder only`, `hydrated now`, and `fully local policy` different states.
That is the right shell posture for ViewFS too.

## Shell pressure this unlocks
- **site ledgers** that show `portal projection`, `provider projection`, `published here`, `published to child`, `localized here`, or `receipt only`
- **provider halos** that distinguish `provider-owned`, `placeholder`, `hydrated`, `replica`, `local object`, or `history only`
- **bind-here ladders** that make `inspect`, `keep projected`, `publish alias`, `localize`, and `receipt only` separate next steps
- **same-object multi-site diffs** that compare provider site, room alias, bind state, and localization state without pretending one path string is essence
- **quality badges** that admit whether path/site/locality truth is `rich`, `partial`, `provider-reported`, or `history only`

## Non-decisions preserved
Do not freeze yet:
- one final projection-site ABI;
- one final alias/publication ledger schema;
- whether room aliases are always explicit binds or later admit overlays/search slots;
- whether localization always implies byte copy, replica registration, or object-store commit;
- whether placeholder/hydration states are mostly provider-authored, kernel-authored, or shell-authored.
