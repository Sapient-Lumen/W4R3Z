# Consent summaries, presentation surfaces, gesture evidence, volition tokens, approval cuts, live authority, and receipts

Revision 154 adds a human-consent hygiene seam for ViewFS. It follows directly from instruction hygiene: once prose becomes typed plans and toolcall fuses, the next danger is letting a **button click** or **pretty consent card** become the hidden capability.

## The anti-collapse rule

Keep these objects distinct:

```text
consent candidate / authority diff
-> canonical consent summary
-> presentation surface record
-> trusted-path posture
-> gesture evidence
-> volition token / ceremony witness
-> approval cut / authorization grant
-> execution arm / live authority
-> outcome / cleanup
-> receipt/history
```

A future implementation may store some of these together. The API and receipts should still name them separately.

## Why this matters for ViewFS

ViewFS wants portal-mediated imports, explicit per-process namespaces, object-store handles, safe-open flows, AI-assisted planning, network/service handles, secret slots, package activation, semantic memory, and delegated authority. Each of those can become risky in a different way if consent is flattened:

- a model-generated answer button could look like a user approval;
- a helper-rendered widget could ask for more authority than the shell shows;
- a remote/captured session could replay a visible click without a local trusted path;
- a notification click could trigger a stronger action than the notification described;
- a stale approval receipt could be reused after source objects, secrets, network endpoints, or policies changed;
- a focus/activation token could be treated like a capability.

The fix is not one more modal dialog. The fix is typed consent material.

## Lane definitions

### Consent candidate / authority diff

The candidate is a typed action plan plus the authority delta. It names:

- subject/requester;
- operation;
- target object/service/namespace/root;
- exact handles, borrows, secret slots, network leases, budget/payer roots, or portal sessions requested;
- preconditions/currentness witnesses;
- destructive/export/publication/delegation posture;
- what is explicitly *not* included.

A consent candidate is still just a proposal.

### Canonical consent summary

The summary is deterministic material derived from the plan and policy profile. It should be digestible so a later volition witness or approval receipt can say exactly what was shown.

It should avoid letting the requester provide the decisive prose. Helpful helper text can be a sidecar; the canonical summary comes from the validator/shell/portal path.

### Presentation surface record

The surface record says where and how the summary appeared:

- shell-owned local pane;
- portal-owned sheet;
- secure-attention mode;
- terminal block;
- notification;
- app/helper widget;
- web iframe;
- model-rendered card;
- remote desktop/screen share;
- accessibility mediation;
- headless/non-human issuer path.

The record is evidence, not approval.

### Trusted-path posture

The trusted-path posture answers whether the user had a trustworthy path to the summary and gesture capture. Suggested early labels:

```text
shell-local
portal-local
secure-attention
ordinary-focused
notification-only
app-rendered
model-rendered
web-embedded
remote-captured
accessibility-mediated
headless-policy
unknown/degraded
```

These labels are not a global security lattice. They are honesty labels.

### Gesture evidence

Gesture evidence includes recent interaction facts:

- keypress / pointer / touch;
- hold-to-approve;
- hardware button;
- authenticator touch;
- secure attention sequence;
- notification action;
- shortcut;
- remote operator event;
- accessibility-confirmed event.

Gesture evidence can be fresh, expired, consumed, refused, remote, synthetic, or unavailable. It is not an approval.

### Volition token / ceremony witness

A volition token is an optional witness produced by a UI root, portal, authenticator, or other profile-defined ceremony component. For Phase 1, keep it narrow:

```text
volition token binds:
  action_digest
  summary_digest
  surface_identity
  gesture_kind
  nonce / time window
  seat/user/profile/issuer
  one-shot use posture
```

The token is evidence for a consent mediator. It should not be passed around as a portable capability.

### Approval cut / authorization grant

The approval cut is the actual decision. It should cite:

- policy family/cut;
- issuer kind: user, local policy, org, quorum, automation, hardware, delegated admin;
- volition requirement result if applicable;
- approved live authority slots;
- denied/omitted authority;
- retry/reuse posture;
- expiry and revocation posture.

### Execution arm / live authority

Only after approval may the executor hold or spend current ViewFS authority. The approved authority might still be unavailable, stale, revoked, expired, or narrower than requested.

### Outcome / cleanup

Execution can run, partially run, fail, be canceled, require repair, or produce cleanup obligations. Outcome is separate from consent. A successful approval does not imply a successful effect.

### Receipts / history

Receipts support audit and explanation. They should carry enough hashes and labels to debug consent, but no raw secret, replayable volition token, or reusable live authority by default.

## Worked example: export selected object to a network service

```text
candidate: export O-19 to service github.upload using network lease N3
canonical summary: S-44 digest H(S-44)
presentation: portal-local consent sheet P7
trusted path: portal-local, not remote, not model-rendered
gesture: hold-to-approve, fresh, consumed
volition: V-8 binds action A-31 + summary S-44, one-shot
approval: user + policy cut C2 approves H7 read + N3 send, denies secret.read
execution: exporter receives H7/N3 only
outcome: sent object bundle B-6, receipt R-77
future: receipt cannot resend; needs fresh plan + approval
```

## Failure examples

### Model-rendered confirmation

```text
assistant card says: "Approved, uploading now"
state: proposal text / app-rendered presentation
approval cut: absent
live authority: absent
valid effect: none
```

### Notification click

```text
notification action: "Open report"
compiled plan asks: "export report to public URL"
summary digest: mismatch
volition: invalid for plan
result: denied before effect
```

### Remote support session

```text
surface: remote-captured
user gesture: remote pointer click
policy: high-risk secret release requires shell-local or hardware volition
result: request alternative issuer path or deny
```

### Stale receipt

```text
old receipt: user approved export of O-19 rev 4 to endpoint E1
current plan: O-19 rev 7 to endpoint E2
receipt posture: explanation only
result: needs fresh summary and approval
```

## SlopOS alignment

The included SlopOS archive already has the right shape:

- `rfcs/0039-volition-tokens-and-trusted-ui-path.md` proposes fresh local one-shot CH-VOL evidence bound to action and summary digests;
- `volition-posture-v0.md` pins local-only non-exportable semantics for phase 1;
- `powerbox-posture-v0.md` treats mediated user designation as a separate authority-widening seam;
- `tool-ui-authority-boundary-v0.md` keeps rendered helper UI from becoming approval or file-selection authority;
- `llm-elicitation-boundary-v0.md` requires local mediation for login/OAuth/payment/secret-entry proposals;
- consent/receipt/explain seams bind high-risk changes to exact summaries and authority diffs.

ViewFS should specialize this, not copy the whole schema. The stable lesson is the split, not `CH-VOL` as a final wire artifact.

## Prior-art pressure

- EROS EWS makes the window system a small mediator capable of tracing user volition.
- HTML user activation distinguishes sticky, transient, activation-consuming, and history-action activation.
- Wayland xdg-activation uses compositor-issued activation tokens and warns that tokens can be refused or ineffective.
- Microsoft Secure Attention Sequence is a classic trusted-path gesture for credential entry.
- WebAuthn separates user presence, user verification, scoped relying parties, and consent ceremonies.
- OWASP clickjacking guidance treats UI redress as a presentation-layer attack requiring framing/cookie/script defenses.

The common lesson: **recent interaction, true display, user identity, consent text, and authority grant are different facts.**

## Non-decisions

Still open:

- exact token format;
- canonical summary syntax;
- consent profile taxonomy;
- trusted UI root implementation;
- operating-system integration;
- accessibility issuer model;
- remote/headless approval model;
- hardware-attestation use;
- local-only versus multi-device user ceremonies;
- how much consent material enters long-term receipts.

Stable for now: **do not let UI charm become hidden authority.**
