# Policy decisions and witness bundles v0

Revision 159 adds a deliberately small policy/witness lane to the executable ViewFS core. The goal is not to pick a final policy language. The goal is to prevent policy-looking artifacts from becoming authority by accident.

## Split

```text
structured request facts
  -> PolicyBundle(active rule/data package)
  -> PolicyDecision(verdict over exact facts)
  -> WitnessBundle(bound explanation)
  -> Shell why-panel / conformance report
```

A policy decision can make a request eligible. It cannot read, write, export, execute, mutate, retain, or publish by itself. A witness bundle can explain which bundle, input digest, evaluator, subject, and authority facts were used. It cannot replay the effect.

## Minimum records

`PolicyBundle` records carry issuer, status, digest, and optional version. The v0 checker only trusts `status: active`. Stale bundles deny even when their verdict would otherwise allow.

`PolicyDecision` records carry bundle id, policy digest, class, effect, principal, action, resource, optional required right, and optional authority handle. The v0 checker permits only `decision_class: enforced` and `effect: allow`, then still requires a matching live handle with the requested right.

`WitnessBundle` records carry decision id, policy bundle id, policy digest, input digest, subject, evidence digest, evaluator, status, and an `includes` list. The `includes` list is intentionally explicit so a witness that omits `live_authority` or `approval_cut` cannot be treated as full evidence.

## Denial reasons

Stable denial reasons added in revision 159:

- `policy-bundle-not-active`
- `policy-digest-mismatch`
- `policy-decision-not-enforcing`
- `policy-decision-denies`
- `policy-decision-not-authority`
- `policy-resource-handle-mismatch`
- `witness-bundle-not-complete`
- `witness-policy-digest-mismatch`
- `witness-required-facts-missing`
- `witness-not-effect-authority`

## Non-collapse rules

A policy allow is not a handle.

An advisory decision is not an enforced decision.

A stale bundle is not a current policy basis.

A decision log is not current authority.

A witness bundle is not a replay token.

A shell why-panel is not an approval cut.

## Future work

The checker intentionally does not choose between Rego, Cedar-style entity policies, custom SlopOS policy records, or another policy language. A later implementation can translate from those languages into this small decision/witness envelope. The envelope should stay boring enough that shell cards, CI reports, and incident review tools can compare decisions without knowing the source policy language.
