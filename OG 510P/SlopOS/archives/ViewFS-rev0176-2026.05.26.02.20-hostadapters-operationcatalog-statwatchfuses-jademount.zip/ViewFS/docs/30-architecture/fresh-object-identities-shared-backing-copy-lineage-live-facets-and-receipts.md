# Fresh object identities, shared backing, copy lineage, live facets, and receipts

Purpose: keep **fresh logical object identity**, **shared-backing optimization**, **copy lineage**, **current live facets**, and **durable receipts/history** on distinct seams.

## The split
- **fresh object identity** — the new logical object or working copy created for one import/clone/materialization event.
- **shared backing** — reused extents/blocks/store payloads below the object layer.
- **copy lineage** — explicit `derived from`, `reflinked from`, `snapshot origin`, `rebuilt from`, or `parent digest` truth.
- **live facet** — currently usable inspect/read/edit/publish authority.
- **receipt/history** — durable memory of create/import/clone/promotion/rebinding events.

## Why this must stay split
A capability-heavy object store can easily lie by accident:
- one cheap reflink gets mistaken for same object identity,
- one shared-backing optimization gets mistaken for current trust/approval continuity,
- one lineage row gets mistaken for current authority,
- or one old clone receipt gets mistaken for a still-live bind.

That is exactly the kind of collapse ViewFS should avoid while SlopOS is still in design and while ViewFS itself is still collecting ideas instead of freezing one substrate.

## Lessons worth stealing
### Reflinks and block sharing
Linux reflink/FICLONE and Btrfs are useful because they are explicit: files can share physical storage while later writes remain private and the files stay independently mutable.
That means ViewFS should never let `shares backing` silently mean `same object`, `same trust state`, or `same live handle`.

### Snapshot-derived clones and promotion
OpenZFS is useful because clones start from snapshots, keep an explicit origin dependency, and need a separate `promote` operation if you want to reverse the parent-child relationship.
That is a strong reminder that lineage, dependency, and adoption/promote actions are separate truths.

### SlopOS fresh identity and explicit lineage
Current SlopOS drafts are useful because `import-to-docref-fresh-identity-boundary-v0.md` refuses to let same bytes or dedupe collapse fresh object identity, and `open-untrusted-export-lineage-boundary-v0.md` insists on explicit parent linkage instead of path folklore.
That is almost exactly the object-store honesty ViewFS should steal.

## Design guidance
1. A **fresh object identity** should remain fresh even if the implementation reuses backing below the object layer.
2. A **shared backing** row should be allowed to disappear after divergence without rewriting history.
3. A **copy lineage** row should be explicit evidence, not inferred from same bytes, same path, or same provider label.
4. A **live facet** should be visibly stronger than every lineage or backing row.
5. A **receipt/history** row should remember clone/import/promotion facts without reviving present authority.

## Shell implications
The shell should be able to render:
- **birth badges** (`fresh object`, `derived object`, `rebuilt object`, `history only`),
- **backing ghosts** (`shares backing`, `backing diverged`, `deep copy`, `unknown`),
- **lineage ladders** (`reflinked from`, `snapshot origin`, `explicit parent`, `rebuilt from`, `history only`),
- **live rails** (`inspect now`, `read now`, `edit now`, `publish now`, `history only`).

## Non-decisions to preserve
Do not decide yet:
- one universal clone/reflink/profile family;
- whether every provider exposes backing-sharing visibility;
- one universal lineage graph schema;
- whether `unshare`/`promote`/`adopt as primary` are universal verbs;
- whether shell, portal, or provider owns the backing-visibility story.
