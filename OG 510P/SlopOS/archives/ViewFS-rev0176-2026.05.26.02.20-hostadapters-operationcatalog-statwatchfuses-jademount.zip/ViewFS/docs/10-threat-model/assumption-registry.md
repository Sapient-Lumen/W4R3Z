# Assumption registry

| ID | Assumption | Why it exists |
|---|---|---|
| A-VIEWFS-1 | Phase 1 can require explicit launch-time view construction rather than ambient host namespace inheritance. | Core authority model depends on it. |
| A-VIEWFS-2 | Early ViewFS may rely on immutable objects and snapshot roots before it has a fully general mutable transaction system. | Reduces consistency complexity. |
| A-VIEWFS-3 | Legacy software support can be layered through a killable compatibility membrane. | Prevents compatibility from becoming the truth model. |
| A-VIEWFS-4 | Portal-mediated imports/exports can be made transcript-visible and user-comprehensible. | Necessary for explicit authority UX. |
| A-VIEWFS-5 | The first shell/terminal can exploit structured data and metadata, not only raw byte streams. | Needed to differentiate the user experience. |
| A-VIEWFS-6 | ViewFS should reuse SlopOS view/docref/plumb-style seams where possible instead of creating parallel authority surfaces. | Keeps the datacube coherent and reduces semantic duplication. |
| A-VIEWFS-7 | Early mutable working state can be prototyped as explicit journals, root-pointer updates, or sidecars over immutable objects rather than as the system’s foundational truth model. | Avoids premature commitment to inode-style mutation semantics. |
| A-VIEWFS-8 | Terminal integration can expose prompt/input/output boundaries and current-view state through explicit shell-to-terminal metadata. | Makes receipts, workflows, and authority previews practical in the UI. |
| A-VIEWFS-9 | ViewFS can keep object identity, namespace membership, mutable current-state semantics, and durable grant persistence as separate design axes for a meaningful first release. | Lets us defer risky coupling without stalling the project. |
| A-VIEWFS-10 | Early ViewFS prototypes can use host-side bridge/backstop tactics such as rooted compat walkers or sandboxing without letting those tactics become the semantic center of the design. | Lets design-phase bring-up stay practical while preserving conceptual clarity. |
| A-VIEWFS-11 | The shell can present completions, autosuggestions, and palettes that remain helpful even when they must admit that authority is stale, needs rebinding, or requires portal consent. | Keeps UX improvements aligned with capability truthfulness. |
| A-VIEWFS-12 | ViewFS can keep recent-item UX helpful without turning recency or clickability into implicit durable authority. | Needed for a shell/terminal that is both delightful and truthful. |
| A-VIEWFS-13 | ViewFS can keep live handles, durable reopen refs, and transcript receipts as different user-visible classes without making the shell confusing or cumbersome. | Needed so history/replay/sharing can stay useful without serializing live authority. |
| A-VIEWFS-14 | ViewFS shell UX can preserve enough structured memory about past work to make replay, notebooks, and restore valuable without needing that memory to silently serialize live authority. | Needed for a delightful but capability-honest terminal. |
| A-VIEWFS-15 | ViewFS can keep search indexes, recent-item registries, and selector palettes highly useful while still treating them as advisory discovery surfaces rather than identity or authority. | Needed so attrfs, recents, and palette UX do not recreate ambient inventory or access. |
| A-VIEWFS-16 | ViewFS can make workspaces useful in a browse-first restricted state before the user permits workspace-defined tasks, env hooks, debug launchers, notebooks, or agents. | Needed so project onboarding does not collapse access and execution into one ambient step. |
| A-VIEWFS-17 | ViewFS can make watcher-driven live panes and smart-folder refresh highly useful while still treating event feeds as scoped, lossy, rebuild-friendly hints rather than perfect truth. | Needed so the shell can feel alive without recreating ambient inventory or hidden authority. |
| A-VIEWFS-18 | ViewFS can offer rich clickable link UX while still keeping local aliasing, durable reopen, launch routing, and transcript rendering as separate classes rather than one hidden shortcut authority plane. | Needed so shell delight does not quietly recreate ambient path semantics. |

| A-VIEWFS-19 | ViewFS can preserve useful origin and quarantine state across previews, recents, palettes, and workspace binds without turning that metadata into silent trust or durable bearer authority. | Needed so risky-object UX stays helpful without laundering danger away. |
| A-VIEWFS-20 | ViewFS can make checkpoints and writable forks/worktrees cheap enough to encourage everyday use without needing those local conveniences to double as backup, publication, or activation semantics. | Needed so time-travel UX can be ambitious without collapsing transport/release/deploy promises into one primitive. |
| A-VIEWFS-21 | ViewFS can make guarded writes, bounded reservations, and conflict receipts highly usable without requiring a giant mandatory lock manager or silent last-writer-wins behavior. | Needed so mutable seams can stay narrow and truthful during the design phase. |
| A-VIEWFS-22 | ViewFS can make saved queries, frozen result sets, and live query feeds all highly useful without needing any one of them to count as canonical identity or bearer authority. | Needed so attrfs/smart-folder UX can be ambitious without recreating ambient inventory or access. |
| A-VIEWFS-23 | ViewFS can make warm-up, offline use, and retention highly legible without collapsing prefetch hints, caches, hydrated closures, pins, mirrors, and offline bundles into one hidden download state. | Needed so object-store convenience does not quietly become identity or authority folklore. |
| A-VIEWFS-24 | ViewFS can make grouped authority highly usable without collapsing bundles, view fragments, live binds, child launch kits, and historical receipts into one hidden convenience object. | Needed so per-process namespace assembly can stay explicit and inspectable instead of regressing to ambient inheritance. |
| A-VIEWFS-25 | ViewFS can make mediated chooser/import flows pleasant without collapsing request objects, chooser-owned candidate sets, selections, minted grants/refs, live binds, and receipts into one hidden “opened object”. | Needed so portal-heavy workflows stay inspectable and capability-honest instead of recreating ambient inventory or magical persistence. |
| A-VIEWFS-26 | ViewFS can make prepare-versus-commit workflows highly usable without collapsing intent, prepared plan, approval checkpoint, execution, and result/history into one hidden shell action. | Needed so shell ambition can grow without turning route sheets, prompts, and receipts into magical authority. |
| A-VIEWFS-27 | ViewFS can make suggested automation from workspaces, receipts, and notebooks highly useful without collapsing source suggestions, promoted user-owned workflows, prepared run plans, and run history into one hidden saved-command object. | Needed so shell automation can grow more powerful without letting shared or workspace content silently rewrite the user’s authority story. |
| A-VIEWFS-28 | ViewFS can make temporary borrowed authority powerful and ergonomic without collapsing lend requests, live borrowed handles, durable delegated refs, issuer-side recall/expiry controls, and loan-end history into one hidden shared-handle object. | Needed so shell ambition around cross-pane and child-launch sharing does not silently reintroduce ambient session authority. |
| A-VIEWFS-29 | ViewFS can make replay, reopen, and renewal flows highly usable without letting past success, exact prior basis, current drift, fresh reconsent, and renewed authority collapse into one hidden replay object. | Needed so shell delight around reuse does not quietly recreate sticky approval or floating current authority. |
| A-VIEWFS-30 | ViewFS can make policy-aware shell UX highly helpful without letting schema validation, authoritative policy, shell advice, diagnostics, and durable audit/history collapse into one hidden helper plane. | Needed so policy-aware shells can stay ambitious without turning hints, overlays, or logs into enforcement truth. |
| A-VIEWFS-31 | ViewFS can make policy-family switches and recovery suggestions highly usable without letting fallback rails, repair prompts, or old selection receipts silently change which policy family/cut is authoritative now. | Needed so a clever shell can help recover from invalid/stale policy state without becoming a hidden policy negotiator. |
| A-VIEWFS-32 | ViewFS can make narrowing and deny-ceiling UX highly usable without letting helper advice, session state, or history silently bypass authoritative scope ceilings. | Needed so ambitious shell ergonomics do not recreate ambient widening through convenience. |
| A-VIEWFS-33 | ViewFS can show owner/org policy, trust-state withholding, user/profile preferences, workspace/imported helper material, and effective active state as distinct source classes without making shell UX too confusing. | Needed so source-aware shell ergonomics do not recreate a hidden settings blob or policy folklore. |
| A-VIEWFS-34 | ViewFS can make protected-only state classes, invoke-only helper material, and trust-gated adoption lanes highly legible without making the shell feel bureaucratic or magical. | Needed so source-aware shell ergonomics do not let lower-trust material quietly become always-on truth. |
| A-VIEWFS-35 | ViewFS can make deferred stop/retry control highly legible without letting close/cancel, terminate, detach/delete, retry-fresh, reset/fork/attach, and result-retention expiry collapse into one magical stop menu. | Needed so shell ergonomics do not recreate ambiguous background-control folklore. |
| A-VIEWFS-36 | ViewFS can make live-session UX highly legible without letting observe/query/follow, interactive attach, control messages, debug exec, sideband tunnels, and transcript history collapse into one magical connected-session model. | Needed so shell ergonomics can get ambitious without recreating ambient control or history-resurrection folklore. |

| A-VIEWFS-37 | ViewFS can make cross-pane/process/app handoff highly usable without collapsing transfer offers, live copied handles, later revival designators, receiver-local adoption, and durable history into one hidden shared/opened object. | Needed so shell delight around sharing does not recreate ambient authority or opaque bookmark folklore. |

| A-VIEWFS-38 | ViewFS can make caveat-heavy delegation UX highly legible without letting displayed caveats, expiry hints, or history rows masquerade as proof of current enforced authority. | Needed so shell/terminal ambition around delegation does not quietly recreate bookmark/token folklore. |

| A-VIEWFS-39 | ViewFS can make permission-state and liveness UI highly legible without letting preflight hints, denial reasons, or old receipts masquerade as current authority. | Needed so shell delight around repair and reopen does not recreate fake possession or generic stale folklore. |

| A-VIEWFS-40 | ViewFS can make provenance, endorsement, and local admit/deny state highly legible without turning signed claims, transparency witnesses, or prior verdict receipts into silent current authority. | Needed so attestation/provenance UX can improve trustworthiness without recreating magical trust or ambient handles. |
| A-VIEWFS-41 | ViewFS can make portal-heavy request/session UX highly legible without letting old request success, portal-side live-state labels, or history rows masquerade as current local authority. | Needed so imports, transfers, and repair flows can stay honest without forcing a giant portal-state subsystem up front. |
| A-VIEWFS-42 | ViewFS can make saved smart queries and frozen/member-set workflows highly usable without letting a recipe, live feed, or old receipt masquerade as one current local collection object. | Needed so search/smart-folder delight does not quietly turn the query layer into the object store or namespace truth. |

| A-VIEWFS-47 | ViewFS can make completion ghosts, accept-word ladders, and trusted rerun affordances highly useful without collapsing candidate suggestions, accepted insertions, compiled packets, prepared actions, and history into one magical command surface. | Needed so shell delight does not quietly turn helpful text suggestions or transcript scraping into authority. |

| A-VIEWFS-48 | ViewFS can make action menus, context drawers, and route sheets highly useful without collapsing object identity, current placement, current handle rights, advertised operations, and receipts into one path-shaped fiction. | Needed so a super-powerful shell does not recreate filename folklore or fake authority. |

| A-VIEWFS-49 | Capability-flow explanations will be useful and frequent, but they can be bounded/redacted/non-authoritative without blocking early ViewFS exploration. | medium | Revisit if developers need raw authority graphs for debugging, because that would create a much sharper secrecy and tracking problem. |

| A-VIEWFS-50 | ViewFS can make durable-root restore and rollback legible enough that users understand the difference between recorded roots, restore candidates, gated revival, activation, live slots, and receipt-only history. | medium | Revisit if users treat time-capsule previews or old receipts as current access. |

| A-VIEWFS-51 | ViewFS can expose enough `why retained?` and sweep-rehearsal explanation to make GC safe and understandable without leaking sensitive object-graph relationships. | medium | Revisit if privacy pressure forces provider-hidden root reasons to dominate ordinary debugging. |

| A-VIEWFS-52 | ViewFS can make quarantine/safe-open UX legible enough that users accept metadata-safe search, safe-open capsules, explicit derived artifacts, and narrow trust receipts instead of disabling guardrails. | medium | Revisit if users route around quarantine because safe-open/export workflows feel too heavy or if semantic indexing pressure demands broader defaults. |

| A-VIEWFS-53 | ViewFS can make safe extraction legible enough that users accept rehearsal cards, path-guard badges, sterile roots, member capsules, and explicit namespace commits instead of demanding ambient `extract here` behavior. | medium | Revisit if users or compatibility shims route around safe-extract because archive workflows feel too heavy, or if package/container use cases demand stronger defaults. |

| A-VIEWFS-54 | ViewFS can make supply-chain evidence useful and legible without collapsing SBOMs, locators, VEX/advisory statements, signatures, transparency entries, local admission, activation, live authority, and receipts into one **trusted package** bit. | medium | Revisit if users or automation demand one-click package trust, or if supply-chain evidence indexes leak sensitive dependency/vulnerability inventory. |

| A-VIEWFS-55 | ViewFS can make secret delivery usable and legible without collapsing descriptors, prompts, projections, env shadows, redaction, renewal, live-use handles, residue, and receipts into one hidden **secret available** bit. | medium | Revisit if compatibility tools demand broad env-token inheritance, or if users treat transcript masking as proof that no secret leaked. |

| A-VIEWFS-56 | ViewFS can make delegation and revocation legible without collapsing intents, caveats, membranes, handles, revocation requests, wavefronts, stale brakes, renewal controls, live authority, and receipts into one misleading **shared/revoked** bit. | medium | Revisit if compatibility requires raw bearer sharing by default, if users expect revoke to undo effects, or if recipient/wavefront visibility creates unacceptable privacy leakage. |

| A-VIEWFS-57 | ViewFS can make inspection, tracing, crash capture, debug, and support export legible enough that users accept redacted snapshots, no-dup slot peeks, trace fuses, dump guards, explicit debug rails, and export receipts instead of relying on ambient host `/proc` / debugger folklore. | medium | Revisit if users or support workflows demand raw dumps, raw fd paths, or same-principal debug attach by default. |

| A-VIEWFS-58 | ViewFS can make network capability UX usable without collapsing intents, destinations, resolution witnesses, leases, live dialers/listeners/streams, local exposure, egress/import cuts, and receipts into one hidden **network allowed** bit. | medium | Revisit if compatibility requires ambient sockets/getaddrinfo/proxy env by default, if local-network prompts become unusable, or if users treat fetch success as import trust. |
| A-VIEWFS-59 | ViewFS can make service discovery and binding legible without users or compatibility shims demanding a global service directory where service names, health checks, identity matches, and old receipts behave like live invocation authority. | medium | Revisit if POSIX compatibility, local developer tools, service meshes, or MCP/tool catalogs require ambient lookup by default. |
| A-VIEWFS-60 | ViewFS can make secure-transport identity useful and legible without users or compatibility shims demanding one green padlock that collapses reference identity, certificate/path/status evidence, trust anchors, channel bindings, resumption, live channel authority, and receipts. | medium | Revisit if users expect TLS success, mTLS identity, SSH known-host state, or CT logging to imply service/object authorization or durable reconnect. |


| A-VIEWFS-61 | ViewFS can make content-address and dedup UX useful without users or compatibility shims demanding a global `has this digest?` oracle, one universal object hash, or cross-principal dedup hit/miss visibility. | medium | Revisit if storage economics push toward global dedup, if encrypted dedup becomes required, or if public content locators become common UI artifacts. |


| A-VIEWFS-62 | ViewFS can make semantic derivation UX useful without users or compatibility shims demanding a global always-on index, one ambient vector store, metadata filters as the only access-control layer, or old answer cards as future agent memory. | medium | Revisit if search latency, AI assistant pressure, or compatibility with IDE/desktop indexers pushes toward broad background extraction or provider-global retrieval stores. |

| A-VIEWFS-63 | ViewFS can make agentic instruction/context/tool UX useful without users or compatibility shims demanding one merged prompt blob, hidden workspace instructions, tool-description-as-policy, or old prompt receipts as future memory. | medium | Revisit if AI assistant workflows become unusable without broader ambient context, or if users cannot understand source ladders and toolcall fuses. |

| A-VIEWFS-64 | Human approval can be spoofed, replayed, or confused unless the shell distinguishes the rendered summary, presentation surface, gesture evidence, volition witness, approval cut, live authority, and receipt. | Revision 154 consent/trusted-path seam | draft |

| A-VIEWFS-65 | A compact JSON fixture corpus is sufficient to keep the first ViewFS authority semantics honest before a real filesystem exists, provided every fixture states the expected authority carrier, non-authority decoys, and failure reason. | Revision 155 executable-spine seam | draft |

## Revision 156 executable-lifecycle assumptions

| ID | Assumption |
|---|---|
| A-VIEWFS-66 | The v0 fixture checker is a deliberately small model; passing it does not imply implementation conformance, only that named anti-collapse cases remain represented. |
| A-VIEWFS-67 | Mutable-session fixtures model a single-head validation path and do not yet specify distributed merge, provider pushback, or collaborative directory transaction semantics. |
| A-VIEWFS-68 | Revocation fixtures can block future use and restore attempts, but they do not claim that previously exported bytes or external copies can be clawed back. |
| A-VIEWFS-69 | Retention-root fixtures distinguish roots from residue, but they do not yet implement byte erasure, derived-index compaction, unlearning, or secure deletion guarantees. |
| A-VIEWFS-70 | Action-plan fixtures assume an external approval-cut issuer; they do not yet define a final trusted-path UI, MCP ABI, or multi-step agent budget model. |

| A-VIEWFS-71 | ViewFS assumes compatibility path attackers may supply paths that try symlink, magic-link, mount/provider, and `..` escapes; resolver denial reasons therefore need typed receipts. |
| A-VIEWFS-72 | ViewFS assumes delegated authority chains may be inspected by humans and replay tools after revocation; history must remain explainable without keeping child authority live. |
| A-VIEWFS-73 | ViewFS assumes shell cards and badges are attack surfaces: misleading projections can launder receipts, search hits, or stale handles into apparent authority unless checked. |
| A-VIEWFS-74 | ViewFS assumes local source forgetting is incomplete when derived embeddings, summaries, answer caches, excerpts, or thumbnails remain live without explicit cleanup accounting. |

## Revision 158 quarantine / export / conformance assumptions

| ID | Assumption | Confidence | Revisit trigger |
|---|---|---|---|
| A-VIEWFS-75 | Users and automation can tolerate a foreign-origin quarantine lane that allows constrained safe viewing before full trust release. | medium | Revisit if compatibility pressure forces direct open of foreign content or if safe viewers become too weak for ordinary inspection. |
| A-VIEWFS-76 | Origin evidence, scanner/admission verdicts, policy cuts, and transparency/provenance sidecars can be made legible enough that ViewFS does not need a single trusted-file bit. | medium | Revisit if evidence piles become incomprehensible or if organizations require a coarse local trust decision for usability. |
| A-VIEWFS-77 | Authority-diff cards can make rights widening visible enough to prevent shell projections from laundering expanded authority. | medium | Revisit if users ignore diff cards or if too many low-risk changes create alert fatigue. |
| A-VIEWFS-78 | Export plans can require sink, approval cut, live export handle, and quarantine clearance without making ordinary sharing unusably heavy. | medium | Revisit if users route around ViewFS via screenshots, copy/paste, raw host paths, or unmanaged sync folders. |
| A-VIEWFS-79 | A generated conformance report is a useful E1 review artifact even before an implementation runner exists. | high | Revisit when prototype runners appear; the report should then compare model versus implementation outcomes. |

## Revision 159 policy / witness / replay / override assumptions

| ID | Assumption |
|---|---|
| A-VIEWFS-80 | Policy engines may be external, versioned, or replaced later, so the ViewFS v0 policy envelope assumes only structured decisions and explicit witness facts rather than a final policy language. |
| A-VIEWFS-81 | Reviewers may treat green dashboards as proof unless denial rows are visible, so replay scenarios assume negative specimens are required for meaningful conformance. |
| A-VIEWFS-82 | Emergency operations sometimes need a breakglass lane, but the lane is assumed unsafe unless it carries verified stewardship, scope, expiry, audit, and normal live authority. |


## Revision 160 freshness / distributed-state assumptions

| ID | Assumption | Confidence | Revisit trigger |
|---|---|---|---|
| A-VIEWFS-83 | ViewFS can make lease expiry and epoch mismatch understandable enough that users do not expect old handles or receipts to keep working after partition or recall. | medium | Revisit if compatibility requires transparent lease reacquisition with weaker shell evidence. |
| A-VIEWFS-84 | ViewFS can support offline branches with explicit revalidation rather than ambient sync-folder publication. | medium | Revisit if local-first workflows become unusable without broader automatic publish. |
| A-VIEWFS-85 | Merge conflict rows and resolution witnesses will be acceptable shell concepts for non-programmer datacube work. | medium | Revisit if users cannot interpret base/ours/theirs/conflict cards. |
| A-VIEWFS-86 | Remote attestations can be rendered as evidence-only cards without users interpreting a verified signature as a live-open grant. | medium | Revisit if supply-chain workflows require direct activation from attestation surfaces. |
| A-VIEWFS-87 | A bounded freshness fence is enough for the v0 executable model even though final implementations may need stronger consensus, clock, vector-clock, or provider-specific freshness proofs. | low | Revisit when a real provider sync protocol is chosen. |
| A-VIEWFS-88 | Journal checkpointing can be modeled separately from mutable commit cuts before ViewFS chooses a final storage-engine implementation. | medium | Revisit once implementation storage semantics exist. |

## Revision 161 disclosure / observation assumptions

| ID | Assumption | Confidence | Revisit trigger |
|---|---|---|---|
| A-VIEWFS-89 | Users can understand redaction views as narrowing lenses rather than as proof that disclosure is safe or authorized. | medium | Revisit if redaction drawers become too complex or if users treat a redaction badge as a green release signal. |
| A-VIEWFS-90 | Audit projections can be useful while still making raw-audit access and underlying object authority visibly separate. | medium | Revisit if support/debug workflows require raw audit by default or if redacted audit cards hide necessary incident context. |
| A-VIEWFS-91 | Disclosure packages can require exact source/sink scope, approval cut, redaction posture, and live authority without making ordinary sharing unusable. | medium | Revisit if users route around packages with screenshots, unmanaged sync folders, or raw host-path copies. |
| A-VIEWFS-92 | Subscription and notification surfaces can remain metadata-first and scoped without becoming an attractive side channel for object payloads. | medium | Revisit if event-driven workflows demand full payload delivery by default. |
| A-VIEWFS-93 | Subject-access exports can be represented as reviewed disclosure lanes without claiming legal compliance or hiding third-party/internal redaction tradeoffs. | low | Revisit when ViewFS chooses a real compliance, policy, or organizational review model. |
## Revision 163 GC / archive / deletion assumptions

| ID | Assumption | Confidence | Revisit trigger |
|---|---|---|---|
| A-VIEWFS-94 | Users can tolerate deletion cards that say `removed from view`, `tombstoned`, `retained by snapshot`, `retained by backup`, or `sanitization proof verified` rather than one green deleted state. | medium | Revisit if shell UX pressure demands a simpler but less honest state. |
| A-VIEWFS-95 | The v0 GC/archive model can distinguish local collection eligibility from secure erasure before ViewFS chooses a real storage engine or backup adapter. | medium | Revisit when storage, encryption, compaction, and backup protocols are selected. |
| A-VIEWFS-96 | ViewFS can expose backup/restore affordances without letting backup manifests or old restore receipts become ambient restore authority. | medium | Revisit if disaster-recovery usability requires broader emergency restore lanes. |
| A-VIEWFS-97 | Legal/compliance holds can be represented as blockers with stewarded release cuts without claiming ViewFS itself supplies legal compliance. | low | Revisit when organizational policy engines or jurisdiction-specific retention requirements are chosen. |

## Revision 165 resource / side-effect assumptions

| ID | Assumption | Confidence | Revisit trigger |
|---|---|---|---|
| A-VIEWFS-98 | Users can tolerate resource cards that distinguish budget, reservation, rate, queue lease, cache, capacity, and metering instead of one simplified `ready` badge. | medium | Revisit if shell complexity causes users to bypass ViewFS for unmanaged jobs or sync folders. |
| A-VIEWFS-99 | The v0 model can use fixed-window budget and rate-limit checks before choosing a distributed resource-accounting protocol. | low | Revisit when ViewFS chooses a real scheduler, provider, or multi-tenant accounting system. |
| A-VIEWFS-100 | Capacity signals should default to coarse and identifier-free because exact resource pressure can leak object membership or hidden activity. | medium | Revisit if policy or implementation supplies stronger privacy-budget and disclosure controls. |
| A-VIEWFS-101 | Metering receipts can be useful evidence without becoming billing, spend, or retry authority. | medium | Revisit when real chargeback, refunds, and external provider invoices are integrated. |



## Revision 173 workflow / automation assumptions

| ID | Assumption | Confidence | Revisit trigger |
|---|---|---|---|
| A-VIEWFS-102 | Users can tolerate automation cards that distinguish event, trigger, schedule, run, step, retry, compensation, and human-task states instead of one `will run` badge. | medium | Revisit if shell complexity causes users to bypass ViewFS automation. |
| A-VIEWFS-103 | A fixture-level workflow custody model is enough before ViewFS chooses a real orchestration engine. | medium | Revisit when SlopOS/ViewFS select an implementation workflow runtime or queue. |
| A-VIEWFS-104 | Idempotency and retry can be modeled as anti-replay/admission facts without becoming a full distributed transaction protocol. | low | Revisit when remote providers, payment-like effects, or exactly-once semantics are integrated. |
| A-VIEWFS-105 | Human task rows can be represented without deciding a final trusted-path or secure-attention implementation. | low | Revisit when accessibility, remote-control, or headless approval policies are selected. |

## Revision 174 personalization / convenience assumptions

| ID | Assumption | Confidence | Revisit trigger |
|---|---|---|---|
| A-VIEWFS-106 | Users can tolerate personalization cards that distinguish profile, preference, model, recommendation, shortcut, autofill, experiment, and feedback state instead of one opaque `personalized` badge. | medium | Revisit if shell complexity causes users to disable or bypass ViewFS personalization. |
| A-VIEWFS-107 | A fixture-level personalization model is enough before ViewFS chooses a real recommender, preference-sync, or experiment service. | medium | Revisit when implementation adapters need persisted model stores or cross-device personalization sync. |
| A-VIEWFS-108 | Feedback can be useful while remaining purpose-bounded and separate from training consent. | medium | Revisit when training, telemetry, or Schell forgetting ledgers are integrated. |
| A-VIEWFS-109 | A lint manifest is sufficient to keep top-level lint surfaces from drifting before ViewFS adopts a larger build-system manifest. | high | Revisit if required-file or tool ordering becomes conditional by profile, platform, or package. |

## Revision 175 schema / ontology / reference / crosswalk assumptions

| ID | Assumption | Confidence | Revisit trigger |
|---|---|---|---|
| A-VIEWFS-110 | Users and tool authors can tolerate interop cards that say `related`, `mapped`, `validated`, or `cataloged` instead of collapsing those states into one `safe/usable` badge. | medium | Revisit if schema-heavy workflows demand simpler but less honest status summaries. |
| A-VIEWFS-111 | A fixture-level namespace/reference/crosswalk model is enough before ViewFS chooses any external linked-data serialization or catalog adapter. | medium | Revisit when RDF/JSON-LD/DCAT/SKOS/OWL/SHACL import or export becomes an implementation target. |
| A-VIEWFS-112 | Crosswalk confidence and review fields can catch the highest-risk equivalence laundering before a full ontology reasoner exists. | low | Revisit when automated ontology alignment, inference, or mapping tools are introduced. |
| A-VIEWFS-113 | A record-family catalog report is sufficient to keep schema accretion visible before ViewFS adopts a richer schema registry generator. | high | Revisit if record families become profile-specific, optional, or versioned independently. |
