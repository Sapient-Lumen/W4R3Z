# Supply-chain extension cards and tool fuses

Revision 164 adds a shell posture for packages and plugins.

## Cards

- **Package card**: digest, version, source, signature state, requested effects, scanner/admission verdict.
- **Dependency pin drawer**: exact source, version, pinned digest, resolved digest, advisory state.
- **Provenance braid**: subject digest, builder, predicate digest, verifier result.
- **Transparency chip**: log root, inclusion proof, subject digest match, root freshness.
- **Verifier-root card**: purpose, status, expiry, rotation threshold, signatures.
- **Extension manifest card**: declared rights, schema digest, admitted install plan, sandbox profile.
- **Tool schema card**: effect class, required rights, schema status, digest.
- **Tool binding fuse**: binding state, schema match, sandbox fit, bind authority.
- **Invoke fuse**: action plan, approval cut, target authority, required right.

## Rendering rule

The shell should never render an installed extension, palette-visible tool, package provenance row, or transparency inclusion chip as a live action button unless the invocation lane has a typed action plan, approval cut, sandbox fit, and live target authority.

## Failure labels

Stable denial labels should be surfaced directly:

- `package-metadata-not-install-authority`;
- `provenance-subject-mismatch`;
- `transparency-entry-not-authority`;
- `verifier-root-expired`;
- `dependency-range-not-pin`;
- `extension-manifest-not-tool-authority`;
- `tool-schema-digest-mismatch`;
- `sandbox-profile-blocks-effect`;
- `tool-metadata-not-invocation-authority`;
- `tool-invocation-lacks-live-authority`.
