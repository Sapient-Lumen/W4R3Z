# Flow maps, custody badges, outflow gates, leak sirens, and audit drawers

Revision: 139  
Date: 2026-05-13  
Codename: flowmaps-custodybadges-leakalarms-silverloom

## Shell goal

The shell should make handle flow boringly visible. Users and developers should not have to infer authority from path strings, process ancestry, or remembered portal popups.

This note sketches UI affordances for RFC 0126. It is not a final UI spec.

## The five visible rails

### 1. Flow map

A flow map is a bounded graph of current authority and recent deltas:

```text
editor.exe
  slot 0  root:/project            launch_root       non_passable
  slot 1  obj:proposal.md#read     portal_import     portal_export
  slot 2  obj:proposal.md#write    attenuated        child_launch

preview-helper
  slot 0  obj:proposal.md#read     borrowed          same_room_borrow
```

The graph should be explicitly marked `redacted` and `non-authoritative`. It explains; it does not grant.

### 2. Custody badge

Every live handle row should get a short custody badge:

- `launch-root`
- `portal-grant`
- `borrowed`
- `attenuated`
- `provider-proxy`
- `self-created`
- `reopened`
- `bytes-derived`

The badge should open a drawer explaining the custody chain and the receipts supporting it. It should not contain raw token material.

### 3. Outflow gate

Every `open with`, `share`, `send`, `attach`, `spawn`, and `export` affordance should route through an outflow gate display. The shell should avoid a universal share icon for all handle classes.

Candidate display labels:

| gate | visible phrase |
|---|---|
| `non_passable` | “cannot leave this process” |
| `same_room_borrow` | “borrow inside this session” |
| `child_launch` | “may be placed in a child process” |
| `portal_export` | “requires portal export” |
| `proxy_only` | “recipient gets proxy only” |
| `bytes_only` | “send bytes, not authority” |
| `receipt_only` | “send audit note only” |

### 4. Leak siren

A leak siren appears when expected closed authority remains live or when a diff violates the intended boundary.

Examples:

- “Preview helper still holds read handle after close.”
- “Export widened from bytes-only to proxy-only.”
- “Receipt says portal grant succeeded, but no live handle is visible.”
- “Live handle exists without matching import/export receipt.”

Leak sirens should include an uncertainty state. A partial analyzer should be allowed to say `unknown/provider-uninspected` rather than lying.

### 5. Audit drawer

An audit drawer shows receipts and diffs after the fact. It should be visually weaker than live authority surfaces.

Good drawer headings:

- `requested`
- `reviewed`
- `granted`
- `bound`
- `exported`
- `revoked`
- `expired`
- `dead but receipted`
- `live now`

The dangerous ambiguity to avoid is making old receipts look like still-usable access.

## Nifty moves to steal

### Preview before grant

Before a portal import or helper launch, show a diff:

```text
Will add:
  + slot 3  obj:dataset.csv#read   custody=portal_import   gate=portal_export
Will not add:
  - write authority
  - parent folder traversal
  - raw provider token
```

### Redaction stripe

Any graph/diff copied to clipboard, logs, or bug reports should show a redaction stripe:

```text
cap-flow snapshot: redacted=true, non-authoritative=true, secrets=0, stable-provider-ids=0
```

### Borrow countdown

Borrowed handles should have a visible lifetime rail:

```text
preview-helper borrowed read handle from editor.exe
lifetime: until helper exit or parent revoke
```

### Gate mismatch warning

If a UI verb would imply a stronger outflow than the handle allows, explain the mismatch:

```text
Cannot attach live project folder to remote chat.
Allowed alternatives: send selected bytes, create receipt, or request portal-mediated export.
```

### Dead-handle receipt mode

After revocation, keep history but remove live chrome:

```text
proposal.md write handle
state: dead
receipt: portal grant existed 14:03–14:19
current power: none
```

## Protocol hints, not a protocol

Future terminal/shell events could reserve names like:

- `viewfs.capflow.snapshot`
- `viewfs.capflow.diff`
- `viewfs.capflow.gate_check`
- `viewfs.capflow.export_live`
- `viewfs.capflow.borrow_start`
- `viewfs.capflow.borrow_end`
- `viewfs.capflow.leak_verdict`
- `viewfs.capflow.receipt_link`

Suggested fields:

```text
subject_id_local
slot_id_local
handle_family
rights_summary
custody_kind
outflow_gate
live_state
snapshot_digest
diff_digest
receipt_digest
redaction_level
provider_currentness_witness_summary
verdict
uncertainty
```

Do not expose raw bearer secrets or stable provider pointers through these events.

## Good demo scenarios

1. Launch a text editor with a project root and show the exact slot map.
2. Import one file through a portal; show the request ticket, live handle, and receipt as separate rows.
3. Spawn a preview helper with a borrowed read handle; show the borrow countdown and parent-owned revocation.
4. Attempt to attach a live folder handle to a remote service; show the outflow-gate mismatch and bytes-only alternative.
5. Close a helper and show the leak siren if any handle remains live.
6. Copy an audit receipt to another process and prove it conveys no authority.

## Warnings for future UI work

- Do not make a graph node draggable if dragging would imply authority transfer without an explicit gate.
- Do not put raw cap strings in tooltips.
- Do not call every delegation `share`.
- Do not let a path breadcrumb stand in for handle custody.
- Do not display old receipts in the same visual weight as live handles.
- Do not pretend a provider proxy is equivalent to a local raw handle.
