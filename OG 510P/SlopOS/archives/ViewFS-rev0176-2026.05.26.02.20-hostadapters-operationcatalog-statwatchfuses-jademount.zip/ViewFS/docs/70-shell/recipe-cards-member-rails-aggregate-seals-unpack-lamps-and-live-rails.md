# Recipe cards, member rails, aggregate seals, unpack lamps, and live rails

Steal from current SlopOS composition/persistence posture plus Google Cloud Storage composite objects, OCI manifests and image indexes, `git write-tree`, and containerd pull/unpack behavior.

Whenever the shell renders one assembly/import/package/work-surface row, it should be able to show:
- whether it is talking about one **assembly recipe** or one finished **aggregate object**,
- whether the **member descriptors** are known, incomplete, hidden, or stale,
- whether one **aggregate seal** exists yet,
- whether one **realized work surface** exists here, elsewhere, or only in history,
- whether a **live facet** is actually present now.

Why this is great:
- descriptor graphs stop pretending they are already a mounted working tree;
- aggregate objects stop pretending they are already hydrated into the current room;
- unpack/materialize/evict flows become explainable instead of spooky;
- the shell can stay luxurious while telling the truth about recipe intent, member evidence, durable assembly, realization, and current authority.

Guardrail:
- never let one old recipe card, member list, aggregate seal, or unpack receipt impersonate a current live facet.
