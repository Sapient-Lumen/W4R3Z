# Realm badges, route halos, egress shutters, and live rails

This note collects shell/terminal ideas for storage locality and data-boundary truth that stay honest.

## The split the shell must preserve
Whenever the shell renders one object/site/history row, it should be able to show:
- whether it is talking about one **committed object** or only one **history row**,
- whether one **realm badge** says `single realm`, `dual realm`, `cross-region`, `provider hidden`, or `history only`,
- whether one **placement ghost** says `present in A`, `present in A+B`, `lagging`, `unknown`, or `history only`,
- whether one **route halo** says `nearest route`, `primary route`, `secondary read`, `failover lane`, `route hidden`, or `history only`,
- whether one **egress shutter** says `local only`, `cross-boundary denied`, `review needed`, `allowed by policy`, or `history only`,
- whether a **live rail** is actually present now.

## Why this is great
- the shell can feel luxurious about locality and compliance without lying;
- nearest/global endpoints stop masquerading as actual object placement;
- export/import boundaries become reviewable instead of spooky provider folklore;
- object-store UX gets better without freezing one provider-specific region taxonomy.

## Shell moves worth stealing
- **realm badges** on object cards and result rows.
- **route halos** that explain how the current read path was chosen.
- **egress shutters** that appear before copy/export/move acts that cross one policy boundary.
- **residency compare drawers** that line up `policy`, `placement`, `route`, and `egress` truth.
- **lag ghosts** for `copy exists elsewhere but not yet current here`.

## Guardrail
Never let one route halo, nearest-endpoint label, or old replication receipt impersonate:
- semantic object identity,
- current placement truth,
- export permission,
- or current live authority.
