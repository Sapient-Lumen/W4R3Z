# Record cards, payload chips, wrapper seals, wire ghosts, and live rails

Steal from current SlopOS encoding/wallet posture plus RFC 8785 JCS, RFC 8949 deterministic CBOR, RFC 9052 COSE detached payloads, and in-toto envelope layering.

Whenever the shell renders one descriptor / receipt / review card, it should be able to show:
- whether the row is talking about the **semantic record** or only one derived byte layer,
- whether one **canonical payload** is present and under which profile,
- whether one **signed wrapper** authenticates payload type and signer set,
- whether the row is only one **wire/storage copy**,
- whether one **live facet** is actually present now.

Why this is great:
- `same reviewed thing` stops pretending to mean `same wrapper bytes`;
- wrapper rotation and detached-payload handling become explainable instead of spooky;
- transport/export copies stop impersonating the proof or the live object;
- the shell can stay luxurious while telling the truth about meaning, proof layer, wrapper layer, and live authority.

Guardrail:
- never let one old wrapper blob, detached payload receipt, or export copy impersonate a current live facet.
