# Collaboration room, mount, label, and handoff cards

Revision 162 adds shell pressure for collaboration surfaces. The goal is to let a user understand shared work without letting the shell imply authority that is not present.

## Cards

### Room card

Shows:

- room id/name;
- participant set and membership epoch;
- role map;
- stale/current lamp;
- whether the room itself carries no object authority.

### Mount-edge card

Shows:

- source view / source handle;
- target room and target path;
- rights subset being projected;
- propagation mode;
- propagation gate state;
- denied widening if target rights exceed source rights.

### Group gate card

Shows:

- group id;
- principal match;
- membership epoch;
- denied-members override;
- exact object scope;
- live handle slot, if any.

### Label overlay card

Shows:

- advisory labels;
- authority-backed labels;
- unresolved conflicts;
- conflict resolution cut;
- whether a live badge is backed by a handle.

### Handoff card

Shows:

- source principal;
- target principal;
- delegated child handle;
- attenuation envelope;
- lease state;
- acceptance cut;
- receipt history as inert.

### Collaboration card

Shows the compact user-facing summary, but it must be generated from the other cards. A collaboration card should never be the first source of truth for authority.

## Bad states that must be visible

- “You are in the room” but no live object handle.
- “Shared mount” but propagation gate absent.
- “Team editor” label but stale membership epoch.
- “Owner” badge contradicts room state.
- “Read-only” card hides a live write slot.
- “Accepted handoff” card is only a receipt replay.

## Shell command sketch

```text
viewfs room inspect room:alpha
viewfs room compose --room room:alpha --edge me:alpha-project --as subj:bob
viewfs group why --group grp:editors --principal subj:alice --object obj:team-v1
viewfs label explain --overlay lo:doc-labels
viewfs handoff inspect hp:bob-read
viewfs card verify cc:doc-bob
```

These commands should show explanations and denial reasons, not silently retry with ambient user authority.
