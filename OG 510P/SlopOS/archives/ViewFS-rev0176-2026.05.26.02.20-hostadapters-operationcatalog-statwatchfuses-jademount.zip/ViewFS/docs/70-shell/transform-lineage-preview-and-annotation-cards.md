# Transform, lineage, preview, and annotation shell cards

The shell should make interpretation visible.

## Transform card

A transform card shows source object, transform recipe id, source handle status, approval cut, lossiness badge, output object, and result handle. It must not show the output as “the original” unless a separate equivalence proof is selected.

## Codec card

A codec card shows media type, handler pin, active-content posture, safe-preview status, sandbox profile if available, and decoded fields. Handler name alone is not enough.

## Migration card

A migration card shows source schema, target schema, current validator, loss disclosure, and result identity. It should warn when old validators or old migration receipts are being viewed.

## Annotation card

An annotation card shows target object, selector state, selector sensitivity, annotation label, and whether the label is merely commentary or promoted through a policy lane. Secret selectors must be redacted or summarized.

## Lineage card

A lineage card shows source hashes, transform steps, subject identity, completeness, ambiguous-step warnings, and inspection authority. It must not expose source content or claim live source authority.

## Preview and canonicalization card

Preview and canonicalization cards must display original identity, preview identity, canonical identity, redaction view, and equality relation. Byte equality, schema equivalence, rendered equivalence, and normalized equivalence are separate badges.
