# Boundary reality cards

A ViewFS shell should show device, runtime, network, clipboard, drag/drop, and sensor state as explicit boundary cards, not as implicit trust.

## Card vocabulary

| Card | Show | Never imply |
|---|---|---|
| Runtime posture | epoch, debug/locked state, attestation status, verification time | file authority or tool authority |
| Network connector | endpoint, allowed effects, DNS proof, policy state | generic network access or endpoint retargeting |
| Clipboard parcel | source epoch, expiry, redaction, classification | read/paste authority or secret clearance |
| Drag/drop parcel | trusted-path lamp, gesture validity, overlay posture, expiry | import approval by itself |
| Peripheral grant | device class, attestation, revocation, sandbox fit | hardware access without live handle |
| Sensor observation | precision, purpose, consent, rate posture | identity, surveillance authority, or raw access |

## Honest labels

Preferred labels:

- `boundary fact`;
- `fresh but inert`;
- `requires live handle`;
- `requires trusted path`;
- `redacted parcel`;
- `exact sensor data blocked`;
- `endpoint pinned`;
- `debug runtime not trusted for this effect`.

Forbidden labels:

- `trusted because local`;
- `authorized because connected`;
- `approved because dropped`;
- `safe because copied`;
- `verified device = usable device`;
- `sensor observed = allowed to disclose`.
