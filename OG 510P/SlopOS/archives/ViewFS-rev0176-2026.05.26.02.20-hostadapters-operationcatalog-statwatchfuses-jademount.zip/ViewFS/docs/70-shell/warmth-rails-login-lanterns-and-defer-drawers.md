# Warmth rails, login lanterns, and defer drawers

The future custom shell can feel luxurious here **without** lying.
The trick is to make `alive now`, `allowed to stay warm`, `allowed to come back later`, and `repair queued for later` visibly different.

## Great moves
### 1. Warmth rails
Every room tab or sticky header gets a compact rail that can say:
- `foreground`
- `warming`
- `background serving`
- `draining`
- `restore intent only`
- `receipt only`

That is much better than one vague green dot.

### 2. Keep-warm badges
A compact badge should explain whether hidden continuity is:
- `allowed`
- `clamped`
- `expiring soon`
- `denied`
- `unknown`

Opening the badge should explain whether the truth came from a lease, a reviewed room policy, a portal grant, or only a receipt.

### 3. Login lanterns
When a room or helper may come back later, use a dedicated lantern/card that says:
- `restore on login allowed`
- `restore proposed`
- `restore denied by policy`
- `restore requires fresh consent`
- `restore failed last time`

This should feel glamorous, not folkloric.

### 4. Defer drawers
When the right next move is not to keep something live but to let a job repair it later, the shell should say so directly.
Great states:
- `repair queued`
- `waiting for network / policy / user step`
- `repair running in background`
- `repair finished; rebind ready`
- `repair failed; foreground review required`

### 5. Rich shell-integration quality chips
Steal the idea of quality ladders from modern terminals/editors.
A chip like `rich`, `basic`, `none`, or `approximate` can tell the user how trustworthy cwd / prompt / command-block / room-state chrome currently is.
That keeps the shell delightful **and** honest.

## Guardrail
Warmth rails, keep-warm badges, login lanterns, and defer drawers are explanation and control chrome.
They are not themselves authority, and they must not silently widen a room into hidden background presence or autostart.
