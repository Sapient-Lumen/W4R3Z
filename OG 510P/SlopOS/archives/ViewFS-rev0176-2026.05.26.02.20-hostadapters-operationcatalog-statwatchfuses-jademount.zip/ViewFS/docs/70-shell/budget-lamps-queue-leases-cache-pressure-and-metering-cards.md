# Budget lamps, queue leases, cache pressure, and metering cards

Revision 165 shell guidance: resource indicators should feel useful but not authoritative. They are brakes, lamps, and receipts; they are not handles.

## Cards

| Card | Shows | Must not imply |
|---|---|---|
| Budget lamp | budget scope, period, remaining amount, reserved amount, payer-handle freshness | permission to open/write/export/execute |
| Reservation card | effect, amount, scope, status, budget, payer handle | object authority or future retry authority |
| Rate-limit chip | window, token posture, retry hint, schedule authority freshness | global load, exact capacity, or invocation authority |
| Queue lease card | job plan, lease expiry, budget reservation, rate posture, authority slot freshness | that queued work will definitely run later |
| Cache pressure card | source epoch, residency, pin posture, pressure state, source handle freshness | that cached bytes are current or authorized to read |
| Capacity signal card | coarse bucket, policy, side-channel warning, observe-capacity authority | per-object membership or exact utilization |
| Metering card | reservation, event digest, measured amount, settlement status | a new charge, spend, or retry grant |

## Required badging

- `queued` means inert.
- `reserved` means budget held, not object authorized.
- `rate admitted` means window/token accepted, not effect authorized.
- `cache warm` means bytes may exist locally, not that they may be read.
- `coarse capacity` means intentionally lossy.
- `metered` means evidence recorded, not settled authority.

## Dangerous shortcuts

Do not add a single green `ready` badge that merges resource readiness, policy allow, user approval, and live authority. The shell may summarize, but the drawer must expose at least these fields separately:

```text
plan approved?  yes/no
live authority? yes/no
budget reserved? yes/no
rate admitted? yes/no
queue lease current? yes/no
cache source epoch current? yes/no
capacity signal coarse? yes/no
metering within reservation? yes/no
```

If the answer to any required row is `no`, the card should show the exact denial reason rather than an opaque failure.
