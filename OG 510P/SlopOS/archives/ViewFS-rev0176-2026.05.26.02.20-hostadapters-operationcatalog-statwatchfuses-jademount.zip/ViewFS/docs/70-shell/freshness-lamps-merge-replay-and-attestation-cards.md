# Freshness lamps, merge replay cards, and attestation cards

Revision 160 adds shell-facing posture for distributed state.

## Freshness lamp

A freshness lamp shows:

- subject being claimed current;
- observed epoch/head;
- observed time;
- valid-until horizon;
- uncertainty state;
- whether the requested operation requires linearized freshness.

Expired, mismatched, or uncertain fences render as denial cards, not stale green badges.

## Lease card

A lease card shows the handle/right, epoch, issuer, expiry, renewal cut, revocation state, and whether a receipt is merely historical. A renewal receipt must be visibly inert.

## Offline branch card

An offline branch card shows base, local head, last observed remote head, current remote head, revalidation cut, and publish authority. If the remote head moved, the card must lead to merge/rebase/review rather than publish.

## Merge replay card

A merge replay card shows base/ours/theirs, conflict rows, resolution cut, resolution witnesses, write authority, and result receipt. Happy-path merge replay without conflict evidence is not conformance.

## Remote attestation card

A remote attestation card shows issuer, subject, statement digest, signature verification, revocation/status check, expiry, and explicit "evidence only" labeling. It must not show a live-open affordance unless a separate live handle exists.

## Checkpoint card

A checkpoint card shows journal status, flush proof, target object, finalizer handle, and old checkpoint receipts. The shell must distinguish committed-to-journal, checkpointed-to-object, and receipt-history states.
