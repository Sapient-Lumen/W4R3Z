# Core stamps, envelope drawers, sidecar lamps, and live rails

Purpose: make review posture rich without lying about current authority.

The future custom shell should be able to say five different things clearly:
1. **this is the same reviewed core as before**
2. **the descriptive envelope changed**
3. **one graph/diff/provenance sidecar is attached**
4. **live authority is or is not bound here now**
5. **all that remains is receipt/history**

Those are not the same truth and should not share one vague `capability card` badge.

## Great moves

### Authority-core stamps
Every review/import/rebind card should be able to show:
- `same reviewed core`
- `core changed`
- `correlation only`
- `cannot compare`
- `history only`

Clicking the stamp should reveal which fields actually participate in sameness and which do not.

### Envelope drawers
The shell should let users open a small drawer that shows:
- issuer / source / route
- labels and display names
- issued-at / observed-at / refreshed-at timestamps
- human notes or context
- redactions or withheld fields

This is exactly where volatile or decorative context belongs.
Not in the stable gate digest.

### Sidecar lamps
Whenever explainability exists, the shell should be able to show:
- `graph attached`
- `diff attached`
- `basis attached`
- `provenance attached`
- `mixed sidecars`
- `none`

A sidecar lamp should never imply that the attached object is usable right now.

### Live rails
The shell should make current power visibly separate:
- `bound here now`
- `bound elsewhere`
- `not bound`
- `bind narrower than reviewed envelope`
- `bind wider than reviewed envelope`
- `history only`

This is much better than letting people infer current power from old cards.

### Re-review ladders
Whenever drift or reconsent is needed, the shell should offer visibly different acts:
- `accept same core`
- `inspect envelope changes`
- `open diff sidecar`
- `ask for fresh bind`
- `keep receipt only`

That is the luxury version of honest drift/reconsent UX.

## Why this would feel super awesome
This is the kind of shell chrome that feels expensive in the best way:
- it keeps stable review gates calm even when descriptive context churns;
- it makes explainability rich without turning it into power;
- it tells the truth about current live authority instead of making users infer it;
- and it leaves plenty of room for different object families later.

## Guardrails
- never let one descriptive envelope digest impersonate the stable gate stamp.
- never let a graph/diff/provenance sidecar impersonate live power.
- never let one old review card silently imply `bound here now`.
- never let `same object story` erase whether current live authority actually exists.
