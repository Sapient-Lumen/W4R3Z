# Inspect lenses, proc shades, fd peek cards, trace fuses, dump guards, and export receipts

Revision 147 adds shell ideas for diagnostics that are powerful without being spooky. The custom shell should make process/namespace/handle/trace inspection feel first-class while still showing the exact authority lane in use.

## Big shell promise

A user should be able to ask **what is going on?** and get a truthful answer without accidentally granting **control it**, **dump it**, **duplicate its handles**, **export its secrets**, or **revive that old debugger**.

## UI pieces worth stealing

### Inspect lens cards

A card that says:

- target: process / task / room / provider op / child namespace;
- mode: `snapshot`, `follow`, `trace`, `dump`, `debug`, `receipt`;
- scope: which view/root/process family is covered;
- export: `local only`, `redacted`, `bundle-ready`, `blocked`;
- live state: `current`, `stale`, `target exited`, `revoked`, `history only`.

The card should never say just `debug enabled`.

### Proc shades

A **proc shade** covers process-local facts that are useful but sensitive:

- argv/env shadows;
- cwd/root hints;
- namespace roots;
- fd/handle slot classes;
- memory-map summaries;
- child process tree;
- crash/dumpability posture.

The shade should show whether each row is hidden, redacted, local-only, exportable, or unavailable.

### FD / handle peek cards

For each slot, show safe metadata:

```text
slot 7  document-read facet  issuer redacted  caveat digest  no-dup
slot 8  portal import session  expires 14m     no-export
slot 9  secret projection file  transcript-risk  no-peek
```

A peek card must not be clickable as an open handle unless a separate authority rail is present.

### Trace fuses

A trace fuse is a visible installed observation stream:

- target;
- probe family;
- field descriptor digest;
- filter/predicate;
- rate and buffer bounds;
- redaction class;
- dropped/overflow/sampling state;
- TTL and stop button.

The metaphor matters: a fuse can blow, expire, be cut, or be replaced. It is not a permanent sensor and not a debugger.

### Dump guards

Crash/core/memory captures deserve scary-but-useful chrome:

- `contains memory`;
- `may contain secrets`;
- `quarantined`;
- `not indexed`;
- `redaction pending`;
- `retention clock`;
- `export requires cut`;
- `sweep after support ticket closes`.

Dump guards should plug directly into GC halos, quarantine capsules, secret residue sweepers, and supply-chain/evidence drawers when relevant.

### Redaction coverage lenses

A coverage lens should say exactly which surfaces are covered:

```text
transcript rows: covered
trace stream: sampled and redacted
crash capture: local only
screenshots: not covered
semantic summaries: disabled
support zip: pending export cut
```

The shell should prefer **gap detected** over a false green shield.

### Debug rails

A debug rail is deliberately louder than inspect:

- `pause target`;
- `attach read-only debugger`;
- `step`;
- `inject command`;
- `read memory`;
- `write memory`;
- `duplicate slot`;
- `enter namespace`.

Each rung should show whether it is absent, denied, armed, active, or ended. It should not share icons with observe-only lenses.

### Export receipts

Support-bundle export should end with a receipt that says:

- what target was inspected;
- what policy/redaction cut was used;
- what classes were included or omitted;
- whether raw memory, raw env, raw fd names, cap IDs, screenshots, or user input were excluded;
- where the bundle went;
- whether the original capture remains local and when it will be swept.

The receipt is history, not a re-export grant.

## Command sketches

Do not freeze these, but keep the shape:

```text
viewfs inspect lens <target> --snapshot --redacted
viewfs inspect slots <target> --classes-only
viewfs inspect namespace <target> --no-raw-handles
viewfs trace fuse <target> --probe objectstore.commit --ttl 10m --summaries
viewfs dump capture <target> --quarantine --no-export
viewfs support bundle <capture> --redaction default --explain-omissions
viewfs debug rail <target> --request attach-readonly
```

## Status vocabulary

Prefer specific statuses:

```text
snapshot-only
classes-only
no-dup
raw-denied
local-only
quarantined
not-indexed
redaction-gap
sampled
overflow
target-exited
revoked
debug-armed
debug-active
control-ended
receipt-only
```

Avoid ambiguous labels:

```text
safe
trusted
available
debuggable
open
attached
clean
shared
```

## Super-awesome moments

- **Why can't I click this fd?** drawer explaining that a slot row is metadata, not a copied handle.
- **What would support see?** preview that renders the support bundle after redaction before export.
- **Secret residue sweep** after a crash capture that offers to clear dumps, traces, summaries, screenshots, and terminal scrollback entries.
- **Trace fuse timeline** that shows install, samples, overflows, filter changes, dropped buffers, and cut/export receipts.
- **Namespace x-ray** that displays roots and imports as badges, with stale/receipt-only ghosts after the process exits.
- **Debug brightline** that changes color/chrome when moving from observation to active process control.

## Guardrail

A process ID is not authority. A namespace snapshot is not a launch root. A slot row is not a handle. A trace is not truth. A dump is not a log. Redaction is not containment. A support receipt is not a debugger.
