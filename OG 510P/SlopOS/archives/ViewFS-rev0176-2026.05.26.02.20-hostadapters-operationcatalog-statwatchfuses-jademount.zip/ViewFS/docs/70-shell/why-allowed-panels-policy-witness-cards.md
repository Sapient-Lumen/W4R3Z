# Why-allowed panels and policy witness cards

ViewFS shell surfaces should make policy decisions explainable without making policy artifacts look like live authority.

## Card posture

A why-allowed panel should show:

- request principal/action/resource;
- live handle slot used for the effect;
- policy bundle id and digest;
- policy decision id and effect;
- witness bundle completeness;
- required facts present or missing;
- stale/advisory/override warnings;
- receipt/history links marked inert.

## Badge rules

`Enforced allow` is only green when backed by a live handle.

`Advisory allow` is advisory-colored, not authority-colored.

`Stale bundle` is a denial badge.

`Witness complete` means explainable, not replayable.

`Breakglass` must show steward, scope, expiry, audit sink, and live handle.

`Happy path only` is a conformance warning, not a pass badge.

## First shell moves

- `why allowed?` opens the policy decision and witness bundle side by side.
- `show missing facts` lists absent witness facts such as `live_authority` or `approval_cut`.
- `show denial twin` locates the paired negative scenario fixture if one exists.
- `breakglass details` expands steward signature, expiry, audit sink, and scope.

The card may route the user to request fresh approval or live authority. The card itself never grants it.
