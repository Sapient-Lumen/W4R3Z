# Session beads, part gauges, seal ladders, abort ash, and live rails

Steal from current SlopOS persistence/import/jobs posture plus Amazon S3 multipart upload, tus resumable uploads, OCI chunked blob upload, and Google Cloud Storage resumable sessions.

Whenever the shell renders one import/upload/materialization row, it should be able to show:
- whether the row is talking about one **live upload session** or one **durable committed object**,
- whether **part coverage** is empty, partial, offset-known, assembly-ready, or unknown,
- whether one **completion manifest** or explicit close instruction is present,
- whether one **abort/expiry verdict** is known,
- whether one **live facet** over the finished object is actually present now.

Why this is great:
- resumable imports become delightful without lying about what already exists;
- progress bars stop laundering themselves into committed-object truth;
- finalize/abort actions become reviewable instead of spooky;
- the shell can stay luxurious while telling the truth about staging, assembly, commit, cleanup, and current authority.

Guardrail:
- never let one old session bead, offset row, or aborted-upload receipt impersonate a current live facet over the finished object.
