# Stack badges, whiteout ghosts, and commit ladders

One of the nicest shell moves available to ViewFS is to stop letting one pretty merged tree pretend to be the whole truth.
This note collects shell/terminal ideas for the seam between **base stacks**, **writable upper overlays**, **merged presentations**, **publish/commit acts**, and **history**.

## 1. Stack badges instead of one flattering path chip
For any object card, tree row, or pane title, the shell should be able to open a little stack card like:
- `base: provider projection`
- `base[1]: generated room adjunct`
- `upper: local writable shadow`
- `merge: active in this room`
- `publish result: not yet sealed`
- `receipt only`

This is much more honest than pretending the currently displayed path is the object's essence.

## 2. Whiteout ghosts and opaque shutters
The shell should have explicit chrome for `hidden below` states:
- **whiteout ghosts** for `hidden lower entry still exists below`
- **opaque shutters** for `upper directory hides lower subtree`
- **shadow-only rows** for `exists only in upper`
- **base-only rows** for `exists only in lower`

That keeps `you hid it here` separate from `it was deleted everywhere`.

## 3. Creation-target pips
When a room is traversing an ordered stack, the shell should tell the truth about where a new item would land:
- `create goes to upper`
- `create goes to first writable member`
- `view is read-only`
- `publish required first`

This is much better than discovering the target after the fact.

## 4. Commit ladders
After editing in a shadowed/merged room, the default should be a ladder rather than one fake `save everywhere` button:
- `keep shadow only`
- `seal upper as local object`
- `publish merged presentation to room`
- `push change back to provider`
- `export as new artifact`
- `receipt only`

That preserves traversal, edit shadow, and durable outcome as separate acts.

## 5. Great terminal moves worth stealing
- **stack badges** attached to command blocks so `open/edit/save` results can show `base`, `upper`, and `merged` separately.
- **whiteout ghosts** in tree views and completion trays so hidden-below names stay explainable.
- **merge rails** that tell the truth about `base only`, `shadowed`, `merged`, `opaque`, or `history only`.
- **upper/lower diff drawers** so the terminal can compare the writable shadow to the projected base honestly.
- **commit ladders** that keep `seal`, `publish`, `push back`, and `receipt only` visibly different next steps.

References: REF-OVERLAYFS, REF-PLAN9-UNIONDIRS, REF-K8S-PROJECTED-VOLUMES, REF-APPLE-FILEPROVIDER-PLACEHOLDER, REF-APPLE-FILEPROVIDER-STARTPROVIDING, REF-APPLE-FILEPROVIDER-EVICT, REF-NIX-REALISE.
