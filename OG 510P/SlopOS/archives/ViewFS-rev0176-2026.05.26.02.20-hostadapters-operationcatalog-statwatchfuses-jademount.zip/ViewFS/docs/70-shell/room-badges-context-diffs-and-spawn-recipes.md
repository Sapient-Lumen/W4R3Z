# Room badges, context diffs, and spawn recipes

The future ViewFS shell should make rooms feel powerful **without** making authority mysterious.

The easiest way to lie is to let a tab/pane name stand in for all of these at once:
- current view,
- current live imports,
- child inheritance defaults,
- saved rerun recipe,
- and past receipts.

We should refuse that collapse.

## 1. Room badge
Every pane/tab should have a compact badge row with at least:
- **room identity** — `build room`, `incident drill`, `review queue`, `receipt replay`
- **current view** — `view: /work`, `view: doc/7f2`, `view: projected remote`, `view: none`
- **inheritance posture** — `inherit none`, `inherit cwd`, `inherit reviewed binds`
- **current truth class** — `live`, `partially live`, `portal step needed`, `receipt only`

This is better than overloading the prompt path alone.

## 2. Context diff drawer
Before split / rerun / spawn helper / open notebook child room, the shell should show a drawer like:
- `parent room now`
- `candidate child room`
- `kept`
- `dropped`
- `needs new grant`
- `requested but blocked`
- `history only`

This is the shell-native equivalent of a capability diff.

## 3. Spawn recipe card
A spawn recipe is the prepared action card for a child room or helper.
It should be able to say:
- `prepared`
- `committed`
- `committed with partial imports`
- `blocked before spawn`
- `child created; imports pending`
- `receipt only`

And it should never pretend that a saved recipe is current authority.

## 4. Inherit-none should feel delightful, not punitive
A strong move worth stealing from capability systems is:
- make **small-context child rooms** fast and ergonomic,
- not rare emergency behavior.

Examples:
- `split clean here`
- `rerun in clean room`
- `open object in isolated helper`
- `clone layout, not authority`

Users should learn that clean-room spawning is ordinary and pleasant.

## 5. Child import tray
After spawn/import, the child room should expose a tray like:
- `requested`
- `granted`
- `bound`
- `skipped`
- `stale already`
- `receipt only`

That tray should answer `what actually landed here?` without forcing log archaeology.

## 6. Room restore should restore explanation first
A restored room should come back as:
- room identity,
- layout,
- saved recipe/receipts,
- and explicit badges saying what is no longer live.

Then the user can choose:
- `rebind exact`
- `rebind narrowed`
- `open chooser`
- `restore layout only`
- `receipt only`

## 7. Nifty ideas worth stealing
- **WezTerm semantic zones + cwd metadata** suggest using terminal metadata to keep room chrome and command blocks honest.
- **Ghostty command-palette / split movement / terminal inspector** suggest room-aware palette actions, room rearrangement, and a debug overlay that explains room metadata.
- **fish** suggests delight should be default, not after a week of config.
- **Nushell overlays** suggest explicit activation layers are much easier to reason about than hidden soup.

## 8. Truthful verbs worth prototyping
- `room show`
- `room split --clean`
- `room split --with-bind worktree`
- `room rerun --recipe last`
- `room restore --layout-only`
- `room restore --rebind exact`
- `room diff child`
- `room imports`

The exact syntax can wait.
The visible truths should not.
