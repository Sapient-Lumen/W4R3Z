# Digest shades, equality rails, dedup shutters, convergence lamps, and cache ghosts

Revision 151 adds shell ideas for content-address and dedup hygiene. The shell should make storage reuse delightful without giving users a fake global inventory oracle or a fake `same object` story.

## Big shell promise

A user should be able to answer:

- what kind of address/proof is this?
- what kind of sameness was compared?
- was dedup even eligible, and in what domain?
- did the system reuse backing, copy bytes, hydrate sparse ranges, or keep provider state opaque?
- was any equality/cache hit hidden because it would leak cross-principal state?
- is this a current live facet, a stored object, a cache ghost, or only a receipt?

## UI pieces worth stealing

### Digest shades

A digest badge should not just say `hash`.

```text
digest shade
profile: CID / dag-cbor / sha2-256
means: chunked DAG root
scope: public locator risk
live authority: none
```

Other shades:

```text
raw-byte sha256       exact bytes, not semantic meaning
canonical cbor        same canonical payload, original wrapper may differ
closure/store         includes references/name/store-profile
verified blob         merkle-root proof lane, not read authority
weak validator        cache hint only
private digest        redacted in transcripts
receipt-only          historical proof, no current membership query
```

### Equality rails

Show comparison profile before result:

```text
same? exact bytes: yes
same? canonical payload: no, wrapper changed
same? semantic object core: not computed
same? quarantine-equivalent: no, new origin mark
same? weak validator: maybe
```

A green `same` without a profile should be invalid UI.

### Dedup shutters

A shutter shows where storage reuse is allowed:

```text
dedup shutter: same-owner only
cross-project: hidden
public/global: denied
provider opaque: maybe
reason: imported from quarantined source; preserve fresh identity
```

Shutters can be `off`, `local-object`, `same-owner`, `project`, `tenant`, `public`, `provider-opaque`, or `encrypted-domain`.

### Convergence lamps

For encrypted or privacy-sensitive material:

```text
convergence: per-project secret
cross-user equality: not exposed
storage saving: possible inside project
leakage: equality within project domain
receipt: redacted domain id
```

If a global convergence domain appears, the lamp should be loud.

### Cache ghosts

Cache hits should be ghostly when they are not authority:

```text
cache ghost
hit: local chunk already present
exposed to requester: yes, same object workflow
retention root: no
live facet: no
```

For cross-principal or provider-private paths:

```text
provider cache: opaque
hit/miss: hidden
materialization: fresh object created
receipt: storage reused maybe, no membership signal
```

### Possession challenge cards

When dedup would skip upload or grant restore:

```text
possession check
knows digest: yes
proved bytes: range challenge ok
restore authority: separate live handle required
receipt: proof accepted for this workflow only
```

This makes `hash in hand` visibly weaker than byte possession and weaker than object authority.

### Leak budget meters

For risky reuse:

```text
leakage budget
cross-principal dedup: off
public locator publication: pending review
same-byte quarantine reuse: no trust carryover
cache-hit disclosure: hidden
```

The meter is explanation, not a policy engine.

### Unshare/deep-copy ladders

Sometimes storage sharing should be broken:

```text
backing decision
current: shares backing below object boundary
options: keep shared | deep copy now | unshare on export | unshare on delete | history only
```

This should interlock with GC, retention, lineage, and quarantine UI without collapsing them.

### Membership-safe receipts

Receipts can say:

```text
materialized object O-17
proof profile: raw-byte sha256
comparison: exact bytes matched existing local backing
fresh identity: yes
origin/quarantine: preserved from import
cache membership: not exposed
live facet: read slot R-4
```

They should never say enough to answer `does Alice have this?` unless the recipient already has authority to know.

## Command sketches

Do not freeze syntax, but preserve shape:

```text
viewfs digest explain <object-or-receipt>
viewfs same --profile exact-bytes <a> <b>
viewfs dedup why <object>
viewfs dedup shutter <room> --show
viewfs materialize <source> --fresh-identity --no-cross-principal-hit
viewfs backing unshare <object> --reason export-privacy
viewfs possession prove <digest> --via portal
viewfs cache ghost <receipt> --redacted
```

## Protocol metadata candidates

Future shell/terminal metadata should be lane-specific:

```text
viewfs.digest.profile=raw-byte|cid-dag|canonical-payload|closure|weak|private|unknown
viewfs.equality.profile=exact-bytes|canonical-payload|semantic-core|chunk-dag|closure|weak-validator
viewfs.equality.result=same|different|unknown|not-comparable|history-only
viewfs.dedup.domain=off|local|same-owner|project|tenant|global|provider-opaque|encrypted
viewfs.convergence.domain=random-key|per-user|project|tenant|global|server-aided|none|redacted
viewfs.cache.observation=hit|miss|hidden|opaque|receipt-only
viewfs.possession=not-proved|local-bytes|challenge-ok|portal-ok|provider-owned|omitted
viewfs.materialization=fresh|reused-backing|deep-copy|unshared|sparse|sealed|denied|receipt-only
viewfs.live_facet=slot|absent|receipt-only
```

## Guardrails

- No generic `has digest?` button.
- No cross-principal hit/miss display by default.
- No green `same` badge without a comparison profile.
- No content-address hyperlink that silently opens bytes.
- No dedup hit that clears quarantine, SBOM admission, origin, or trust state.
- No receipt click that re-queries membership or revives authority.
- No global convergent-encryption mode without an explicit leakage warning.
- No transcript of private digests/convergence domains unless redaction policy says it is safe.
