# Authority diff cards and conformance dashboards

Shell projections are security surfaces. Revision 158 adds executable pressure for two projections: authority diff cards and fixture conformance dashboards.

## Authority diff card

A minimal card should show:

```text
Subject: h:report-export
Before: read
After:  read, export
Added:  export  [VISIBLE WIDENING]
Removed: none
Cut:     approval-cut:abc
Receipt: r:authority-diff-rendered
```

The forbidden version is visually harmless:

```text
Subject: h:report-export
Change:  ready to share
```

That hides the fact that `export` appeared. Fixture `036-authority-diff-hidden-widening-denied.json` exists to keep that failure vivid.

## Quarantine card

A quarantine card should not say only “safe” or “unsafe.” It should show:

- origin evidence status;
- quarantine capsule status;
- safe-viewer availability;
- scanner/admission verdict;
- policy cut state;
- authority diff for any release;
- export blockers.

## Export card

An export card should show:

- exact source object or projection;
- exact sink;
- live export handle;
- approval cut;
- quarantine/trust clearance;
- redaction/minimization posture;
- receipt after send.

A prior export receipt should render in the history lane, not as a live “send again” action.

## Conformance dashboard

The generated `out/conformance_report.md` is a shell/dashboard seed. A future shell can show fixture health as badges, but those badges must be sourced from deterministic reports, not from optimistic prose.

Minimum dashboard panes:

- fixture count and positive/negative split;
- operation coverage;
- proof-obligation coverage;
- newly uncovered obligations;
- unstable/stale generated-report marker;
- link from each proof obligation to fixture files and current denial reasons.
