# Birth badges, backing ghosts, lineage ladders, and live rails

Steal from current SlopOS fresh-identity / explicit-lineage posture plus Linux reflink, Btrfs reflink, OpenZFS clone concepts, and APFS clones.

Whenever the shell renders one clone/import/materialization row, it should be able to show:
- whether the row is talking about one **fresh object** or only one shared-backing optimization,
- whether **shared backing** is present, diverged, deep-copied, or unknown,
- whether one explicit **lineage** relation is known,
- whether one **live facet** is actually present now.

Why this is great:
- cheap copies become delightful without hiding object/trust truth;
- same-bytes and shared-backing folklore stop laundering identity;
- lineage becomes reviewable instead of spooky;
- the shell can stay luxurious while telling the truth about fresh object identity, storage reuse, and current authority.

Guardrail:
- never let one backing ghost or old lineage receipt impersonate a current live facet.
