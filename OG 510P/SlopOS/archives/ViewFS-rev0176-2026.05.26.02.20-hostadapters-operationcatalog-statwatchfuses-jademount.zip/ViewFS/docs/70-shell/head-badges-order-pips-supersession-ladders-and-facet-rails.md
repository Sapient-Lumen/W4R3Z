# Head badges, order pips, supersession ladders, and facet rails

Steal from SlopOS ordering-token / conflict-key posture, Kubernetes `resourceVersion` humility, etcd revision metadata, S3 version IDs + delete markers, and Git reflogs.

Whenever the shell renders one mutable object or published name, it should be able to show:
- whether the row names the **object core**, a **designation**, or only a historical row,
- whether one **revision token** is current, stale, incomparable, or provider-local only,
- whether the row belongs to one **order scope** and whether another candidate is ordered with it,
- whether one **supersession row** says `replaced`, `tombstoned`, `restored`, or `history only`,
- whether one **live facet** is actually present now.

Why this is great:
- `same object` stops pretending to mean `same current head`;
- `same name` stops pretending to mean `same version`;
- concurrency and supersession become explainable without one giant lock mythology;
- the shell can stay luxurious while telling the truth about current power versus current head versus durable history.

Guardrail:
- never let one old revision token, one reflog-like row, or one delete marker impersonate a current live facet.
