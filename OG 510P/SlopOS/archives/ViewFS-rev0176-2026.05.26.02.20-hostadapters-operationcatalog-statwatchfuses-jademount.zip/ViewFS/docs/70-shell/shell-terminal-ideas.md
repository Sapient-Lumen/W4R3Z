# Shell and terminal ideas for ViewFS

This file captures ideas worth stealing without prematurely freezing shell syntax.

See also: `docs/70-shell/shell-terminal-protocol-sketch.md` and `docs/70-shell/shell-super-awesome-moves.md`.

## Big opportunities

### 1. Structured pipelines by default
Steal from REF-NUSHELL:
- commands can emit typed records, tables, handles, receipts, and manifests
- text remains available, but not mandatory as the lingua franca
- inspection commands should show both friendly and exact forms

### 2. Capability-aware completion and previews
Steal from REF-FISH:
- completions should understand the active view
- previews should say *what authority this object implies*, not just its name
- dangerous expansions should be visually marked before execution

### 3. Command/output blocks as first-class transcript units
Steal from REF-WARP-BLOCKS and REF-WEZTERM-SHELL-INT:
- every command and its result should form a block
- prompt, input, and output boundaries should be explicit metadata, not guessed by screen scraping
- imports, exports, grant receipts, and errors should attach metadata to the block
- blocks should be bookmarkable and shareable inside the archive

### 4. Clickable semantic receipts in terminal output
Steal from REF-WEZTERM-HYPERLINKS:
- handle IDs, manifest IDs, docs, and receipts should be clickable
- terminal output can link to a local inspector instead of dumping raw identifiers only

### 5. Explicit view domains in tabs/panes
Steal from REF-WEZTERM-DOMAINS:
- every tab/pane should visibly show which view/domain it belongs to
- switching views should feel like changing domains, not like mutating a hidden cwd

### 5b. Room identity and child-context diffs
Steal from REF-WEZTERM-SHELL-INT, REF-GHOSTTY-SHELLINT, and REF-GHOSTTY-CMDPALETTE:
- every pane/tab should visibly show room identity separately from current view/cwd
- split/rerun/helper actions should preview the candidate child context before commit
- room restore should bring back layout/labels/receipts first, then explicitly rebind fresh authority

### 6. Runnable docs and saved workflows inside the terminal
Steal from REF-WARP-NOTEBOOKS, REF-WARP-WORKFLOWS, and REF-WARP-CMDPALETTE:
- repeatable admin flows should be storable as parameterized workflows with descriptions and visible arguments
- shell playbooks should be searchable from one palette, not buried in wiki pages and aliases
- notebooks should be local-first, exportable, and able to embed runnable snippets plus linked receipts

### 7. Plumb-style routing for object-aware actions
Steal from REF-PLAN9-PLUMB:
- clicking or selecting a receipt/object should emit a typed routing message, not just paste text
- editors, object inspectors, viewers, and import/export tools should subscribe to routeable intents
- the shell should be able to say “open this manifest in the inspector” or “send this object to review” without inventing one-off CLI hacks

### 8. Mediated transfer beyond file pickers
Steal from REF-XDG-FILETRANSFER:
- drag/drop and copy/paste of files or directories should go through the same grant/receipt story as chooser open/save
- a terminal should be able to drag a receipt or file reference into another app and have that become a visible portal-mediated transfer
- chooser/open flows should be able to surface request chips, staged selections, and `bind here` versus `receipt only` choices instead of collapsing into a hidden dialog result

## ViewFS-native shell moves
- `grant open` -> chooser flow returning handles + receipt
- `grant save` -> export flow returning receipt + destination binding
- `grant transfer` -> portal-mediated drag/drop or clipboard transfer receipt
- `view ls` -> list explicit roots and bindings
- `view use <name>` -> switch the active pane/tab domain to another explicit view
- `obj inspect` -> metadata / rights / provenance for a handle
- `manifest show` -> exact immutable closure view
- `path explain` -> explain how a compat path maps onto explicit roots
- `route open <receipt>` -> send a typed object-opening intent to the relevant tool
- `workflow run <name>` -> insert or execute a parameterized, transcript-visible command object
- `notebook open <name>` -> show a runnable playbook with embedded receipts and last-run outcomes

## Super-awesome moves worth prototyping

### A. View badge in the prompt
Every prompt should visibly say:
- active view/domain name
- synthetic cwd root
- whether the current command set is sealed or expanded
- whether any ambient-authority escape hatch is being used

### B. One-keystroke authority preview
Before execution, the shell should be able to explain:
- which handles will be passed in
- which portals may be invoked
- which bundle or receipt objects are in play
- whether a command is purely local, read-only, exporting, or delegating

### C. Receipt-aware scrollback
Scrollback should not just be text; blocks should expose:
- imported objects
- created manifests
- save/export receipts
- transfer sessions
- last-known view/domain

### D. “Explain this command” after the fact
A block inspector should answer:
- why this command could access the object it touched
- where that authority came from
- whether the command widened or narrowed any handle rights
- whether any portal grant remains alive afterward

### E. Playbooks that stay local-first
The terminal should support local notebooks/runbooks with:
- runnable commands
- linked receipts/manifests
- saved parameterized workflows
- export to plain Markdown so nothing is trapped in a proprietary UI

### F. Explicit ambient-authority markers
Borrow from REF-CAPSTD:
- if a developer tool falls back to a host path or ambient lookup during bring-up, that should be loud and visible, not hidden
- the shell transcript should mark those moments as debt, not normal behavior

## Protocol-level hints worth keeping in mind
- emit shell->terminal metadata for current view identity and synthetic cwd
- emit prompt/input/output boundaries explicitly
- attach stable IDs to command blocks so receipts can refer back to them
- make command failure states visually distinct without requiring log scraping

- keep author badges, carrier tags, and advisory-only rails visibly distinct so trusted carriers do not silently become policy authors

## Anti-goals
- no fake “normal Unix” prompt if the system is using a synthetic view root
- no silent coercion from handles back to ambient host paths
- no AI-generated shell magic without a visible explanation of resulting authority
- no cloud sync requirement for workflows or notebooks in Phase 1


## More product-y ideas worth prototyping later
- an object palette that searches receipts, manifests, workflows, and saved views
- a receipt tray per pane for reusing recent imports/exports/transfers
- safe replay modes that strip authority before rerunning a block
- a loud ambient-debt badge whenever host fallback occurs during bring-up
- typed route sheets for opening objects/URIs without collapsing them into generic strings


## More ideas to steal carefully
- completions that show when a suggestion is **ready**, **rebind-needed**, or **portal-needed** rather than pretending every historical command is immediately runnable
- workspace-aware “open folder as view” actions that mint explicit bind receipts instead of generic cwd/path mutation
- palette results that preserve whether a thing is a command, workflow, notebook, receipt, workspace slot, object ref, or URI route target
- suggestion surfaces that preserve whether a workflow came from a workspace, a shared notebook, a receipt, or the user’s own promoted library


## Extra direction from recent research
- semantic prompt/block marks should be first-class and inspectable, not just an internal implementation detail;
- object refs and receipts in terminal output should be clickable typed links, not plain pasted strings;
- recent items should advertise whether they are live bindings, reopen handles, or just history.

## New pressure from Revision 009
- journal, notebook, and workflow memory should be class-aware (`live`, `ref`, `receipt`, `note`)
- pane/session restore should restore layout and explanation first, then explicitly rebind authority
- replay should support `strict`, `reopen`, `portal`, and `stripped` modes
- **Browse-first workspace opening**: bind a project tree and surface its automation manifest without auto-trusting tasks, env hooks, notebook execution, or agents.
- **Workspace trust badges**: make every pane/block admit whether workspace automation is blocked, trusted, or needs reapproval.



## Prepare-versus-commit shelling
A ViewFS shell should make `prepare` a normal action: show one exact route/action plan, show the authority delta, show whether approval is needed, and only then commit. That is how a capability-native terminal gets smarter without getting more magical.

## Promote-versus-run shelling
A ViewFS shell should also make `promote` a normal action: inspect one suggested workflow, show what source provenance and debt would carry forward, choose whether to copy/strip/narrow it, and only then save it into the user-owned library. That is how a capability-native terminal gets more reusable without turning shared suggestions into hidden standing trust.


## Borrowed-authority shell moves
- `lend for this run` and `lend until pane closes` should be first-class actions, not overloaded `open`/`share` variants.
- Pane chrome should advertise when current work depends on borrowed live authority versus only durable reopen refs.
- End-of-loan cards should explain `relinquished`, `recalled`, `expired`, `basis drift`, or `missing source` instead of producing generic later failures.


## Renewal / replay honesty
- basis diff drawer before replay, reopen, or renewal
- reconsent ladder with `reuse exact`, `reuse narrowed`, `fresh chooser`, `fresh lend`, `fresh temp view`, and `receipt only`
- watched-input chips that explain why prior comfort no longer applies
- renewal result cards that say `reused exact`, `reused narrowed`, `fresh reconsent`, `source missing`, or `receipt only`


## Witness / caveat / why UX
- witness drawer that shows exact basis facts the current import/run/replay is relying on
- caveat chips in pane chrome and result cards (`read-only`, `no-export`, `pane-local`, `temp-view`, `borrowed`)
- freshness badge distinct from trust badge (`cut exact`, `cut old`, `cut unknown`)
- why panel hotkey that explains allow / narrow / deny / receipt-only
- caveat-preserving replay so the default improvement path is often *less* power, not the same or more

## Policy-aware shell honesty
- policy lens drawer that shows which policy family/cut and validation state the current candidate is using
- advice rails that are loudly marked non-authoritative even when they are helpful and high-confidence
- diagnostic cards for `allowed`, `narrowed`, `denied`, `invalid-policy`, and `receipt-only`
- audit-trace chips that show whether a durable redacted history record exists without implying current permission
- replay defaults that prefer safer narrowed routes over “same power as last time”
- cut picker that shows `explicit`, `bootstrap`, `repair accepted`, `history only`, or `unknown` rather than hiding how the current judge was selected
- fallback rail that offers alternates without pretending they are active yet
- selection receipt chips that preserve past family/cut choices as history only


## Proposal provenance and adoption honesty
- proposer badges should show whether a suggestion came from workspace, profile, org, history, receipt, mediator, or shell-local heuristics
- scope chips should default to the narrowest viable effect (`once`, `pane`, `session`, `workspace`, `profile`)
- escalation ladders should make “adopt more broadly” explicit instead of silently persisting one-shot repairs
- adoption gates should record who proposed, who adopted, and what ceiling or deny rule still constrained the change
- decline receipts should suppress repeated nagging without turning history into hidden authority


## Ceiling / narrowing honesty
- ceiling pills should explain why a proposal cannot widen without dumping raw policy internals into the prompt
- narrowing previews should make `once`, `pane`, `session`, `read-only`, `no-export`, and `receipt only` feel like successful outcomes
- scope fuses should show when a proposal source is categorically non-widenable at the requested lane
- relative object/file links should resolve against the explicit active pane/session state, not guessed host cwd folklore
- queued steering should target the current request/plan object rather than dissolving into anonymous later shell text

- Treat `invoke once` as a first-class narrow success path, distinct from `adopt` or `make always-on`, and surface protected-only/invoke-only state through terminal-native badges rather than hidden settings folklore.
- Treat `installed`, `enabled`, `approved to start`, `live now`, and `selected for this request` as different helper states, and surface them through terminal-native badges/tool racks rather than hidden settings folklore.

- Treat helper-exposed resources, prompts, tools, interactive apps, completion suggestions, request bindings, and invocation receipts as different classes, and surface them through shelves/chips/racks/docks instead of one generic helper palette.

- Treat deferred work as a first-class shell domain: an immediate request, accepted task badge, live progress lane, input-needed drawer, result locker, and task receipt should stay visibly different instead of collapsing into one vague background-job line.

## Deferred-control honesty
- `close interaction`, `cancel gracefully`, `terminate now`, `detach watch`, `forget retained result`, `retry fresh`, and `fork/reset` should be visibly different shell acts.
- Result lockers should be able to degrade to `history only` or `forgot locally` without pretending the remote run changed state.
- Retry drawers should distinguish `use existing`, `retry fresh`, and `fork from checkpoint/history` before Enter commits anything.


## Live-session honesty
- `follow output`, `query live state`, `attach read-only`, `attach interactive`, `send control`, `spawn debug exec`, and `open sideband tunnel` should be visibly different shell acts.
- Tails and status panes should be safe to leave open without implying stdin or mutation authority.
- Sideband tunnels should advertise lifetime and target clearly, and transcripts should degrade to history rather than masquerading as live sessions.

### 16. Designator chips versus ticket chips
Steal from REF-W3C-CAPURL, REF-OCAPN-LOCATORS, and REF-GHOSTTY-SHELLINT:
- the transcript should render **designation-only** references and **authority-bearing tickets** differently
- note-friendly designators should be easy to copy/export/share
- ticket chips should carry loud type badges, expiry/revalidation hints, and explicit `inspect`, `store`, `revalidate`, or `adopt` actions
- live-handle badges should remain distinct again

This is one of the best “super awesome” moves available because it makes capability truth visible in ordinary day-to-day shell behavior rather than in a hidden security panel.


### 17. Caveat laminates versus membrane badges
Steal from REF-MACAROONS-NDSS14, REF-ZCAP-LD, and REF-CAPSICUM-HANDBOOK:
- the transcript should render **declared caveat sets** separately from **enforced membrane/proxy state**
- caveat laminates should be easy to inspect and safe to quote in receipts or notebooks
- membrane badges should carry the enforcement locus, expiry/use-budget truth, and explicit `renew`, `revalidate`, `adopt`, or `drop` actions
- live-handle badges should remain distinct again

This is another “super awesome” move because it turns one of the hardest capability truths into ordinary legible shell chrome.

## Permission lights / death-certificate UX
- **Permission lights** should show `granted`, `prompt`, `denied`, `revalidate needed`, or `policy blocked` as advisory preflight state without implying the pane already holds a live handle.
- **Death certificates** should show `revoked`, `expired`, `target changed`, `issuer unavailable`, `deleted`, or `history only` instead of flattening every failure into `stale`.
- **Repair ladders** should prefer exact next verbs like `request`, `revalidate`, `rebind`, or `import fresh` over generic reopen magic.
- **Preflight gutters** should make it obvious when a command is about to ask for authority versus use authority it already has.
- **Reason-rich recents** should keep old rows useful for explanation without pretending they are still live.


## Provenance ribbons / endorsement stacks / why-runnable drawers
A ViewFS shell should be able to surface three different kinds of truth side by side:
- **provenance ribbons** for where something came from or how it was produced,
- **endorsement stacks** for what signer / threshold / transparency / reference-value inputs were available,
- **verdict shutters** for the local admit/deny result in this shell right now.

That enables a much better `why runnable?` drawer:
- which claim envelope or provenance statement was considered,
- which endorsement or trust-root inputs mattered,
- which local rule or guarded-open lane produced the verdict,
- and whether the current pane actually holds a live handle or only a verdict/history row.

The important thing is that `well-described`, `well-endorsed`, `admitted here`, and `live now` remain visibly different classes.

## Request ledgers / session cards / adoption shutters

The terminal should have a first-class way to distinguish:
- one request that completed once,
- one portal-owned session or transfer object that may still be alive,
- one current portal-side live-state verdict,
- one local adopted bind/handle in this pane,
- and one old receipt.

That makes portal-heavy workflows dramatically less spooky.
It also gives the shell a better place to surface `closed by portal`, `autostopped after retrieval`, `session ending`, `not adopted here`, or `history only` without collapsing everything into `stale`.

### Completion ghosts, packet gutters, and trust-grade replay
One especially good move is to keep the whole completion ladder visible:
- `candidate only`
- `detail loaded`
- `accepted into buffer`
- `compiled packet`
- `ready` / `approval needed` / `portal needed`

That gives the terminal a truthful place to put richer UX:
- accept-one-word / accept-fragment flows,
- rights/provenance detail drawers that load on focus,
- packet gutters that explain what objects or receipts were recognized,
- and replay affordances that only appear when the packet is strong enough.

A command copied from scrollback or heuristically scraped from the terminal should not get the same one-keystroke rerun affordances as a nonce-verified or object-composed packet.


## Place cards and verb ledgers
- focused object chrome should distinguish `identity`, `placement here`, `rights held now`, `advertised verbs`, and `receipt only`.
- action menus should expose reasons such as `supported by provider`, `not with this handle`, `not at this placement`, or `ask first` instead of generic grey buttons.
- the same object appearing in several placements should be renderable as one identity with several place cards rather than several fake copies.


## Type/opening honesty
- type lenses should distinguish declared type from locally derived type instead of trusting one suffix or upstream hint.
- disagreement cards should make `claimed as X, looks like Y` a first-class inspect state.
- handler racks should separate `associated`, `default`, `chosen now`, and `history only`.
- safe-preview rows should remain visibly weaker than full editor/open rows.
- open-state badges should tell `previewing`, `editing`, `external`, `portal-owned`, `detached`, and `closed` apart.
- why-this-opener drawers should explain whether a route came from explicit user choice, current default, policy, or provider suggestion.


## Label surfaces should be semantically split
- label-like UI should distinguish `annotation`, `selector`, `policy`, `trusted badge`, and `history only`
- right-status, title, and badge chrome should be provenance-labeled so copied text or screenshots do not masquerade as object truth
- selector composers should only offer visibly query-safe labels by default
- stronger handling labels such as quarantine/review/sensitive should live in shell-owned trusted chrome rather than decorative chip clouds



## Cursor / watermark / rebuild honesty
- waterline chrome should distinguish `continue token`, `watermark`, `following`, `rebuilt`, and `history only`
- gap badges should prefer exact reasons such as `expired cursor`, `resource version too old`, `must rescan`, `provider reset`, or `remote-risk`
- follow panes should make `waiting for change` visibly different from `caught up through X`
- rebuilt snapshots should say so explicitly instead of silently replacing the previous live set
- copy ladders should separate visible rows, query manifest, watermark, and receipt; raw provider cursors should stay inspect/debug level by default

## Observed bases, draft sessions, and durable winners
Another especially promising shell move is to keep editing truth split into `based on`, `drafting in`, `held by`, `committing with`, and `won as`.
That opens the door to stale-base lamps, hold meters, commit shutters, and winner receipts.
The key product lesson is simple: a local draft should feel fast and powerful without ever quietly claiming that it is already the shared durable truth.

## New pressure from Revision 082
- startup review should open an **activation sheet**, not force users to reverse-engineer launch authority from argv/env/cwd folklore
- post-launch inspection should show a **child-slot map** so inheritance remains visible
- pane-to-pane or tool-to-tool sends should emit a **handoff sheet** rather than a vague `opened elsewhere` line
- per-object inspectors should expose **copy lineage** (`slot`, `issuer`, `witness`, `same object ref?`, `reopen lane?`)
- tiny issuer/courier chips should be skimmable in the prompt or pane HUD without pretending to be trust verdicts



## Fresh ideas from the publication/locality pass
- **Published-name ledger per object**: let one object card show every current publication site separately instead of pretending one path string is the object.
- **Synthetic-view badges**: `portal view`, `provider projection`, `published here`, `stored only`, and `history only` should be distinct shell truths.
- **Publish-here last**: portal/import results should often land in staging first; making them current local namespace truth should be one explicit act.
- **Same-object multi-view diff**: compare store/object ref, restricted projection site, current local publication, and live-handle truth across panes or child launches.
- **Where-is-it-really drawer**: keep object-store existence, current publication, and durable reopen/story artifacts visibly separate so shell delight does not regress to path folklore.

References: REF-PLAN9, REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-DICTCAP, REF-XDG-REQUEST, REF-XDG-FILECHOOSER, REF-XDG-DOCUMENTS.

## Open-route pills and replace-this-debt affordances

The terminal should treat `how this object was reached` as first-class metadata.
Nice moves here include:
- **open-route pills** per command block: `handle`, `rooted`, `portal`, `ambient`, `history`;
- **route provenance drawers** that explain root/view, mediator request, or ambient helper involvement;
- **replace-this-debt buttons** that let a user turn one ambient success into a cleaner bind/grant/kept-handle flow;
- **import fit notes** on chooser sheets that explain why a candidate is in scope and whether it stays mediated or becomes local;
- **semantic gutters** that let users filter past commands by access lane rather than just by exit code.

This is a good example of shell delight doing real security and design work at the same time.


## More shell ideas from the discoverability seam
- explorer panes should be able to render `listable`, `exact-name-only`, `portal-browse`, `suggested`, and `history` as different truths;
- a command that succeeded by exact-name open should emit a **known-name chip** rather than quietly implying the directory was browseable;
- search results should carry **fit sheets** that explain why a result appeared and what stronger step is still needed;
- transcript filters should support `show me ambient escapes`, `show me browse grants`, and `show me exact-name successes`.

## More shell ideas from the advert/readiness seam
- palette/provider rows should be able to render `advertised`, `ready`, `grant needed`, `withheld`, `withdrawn`, and `history` as different truths;
- the shell should keep a tiny **advert ledger** so users can inspect who advertised something, when, and under what freshness caveat;
- **readiness lamps** should decay explicitly instead of keeping stale green state alive forever;
- **withdrawn ghost rows** should preserve recent context without pretending the affordance is still current;
- transcript filters should support `show me ready now`, `show me grant-needed`, and `show me withdrawn` the same way they can support `show me ambient escapes` or `show me browse grants`.


## New ideas from the provider-ready / local-realized seam
- **Make-local ladders**: one explicit ladder for `ask provider`, `repair/reacquire`, `realize locally`, and `bind here`.
- **Provider-owned badges**: visibly mark foreign-backed or borrowed utility so smooth UX does not imply local ownership.
- **Offline fog**: dim remembered/provider-ready rows when they are only satisfiable through network/provider reachability.
- **Repair rails**: explain whether the next truthful step is reauth, rebind, fetch, substitute, or abandon.
- **Locality lamps**: tiny chrome that can say `remote-ready`, `local-now`, or `receipt-only` without opening a big inspector.


## More shell ideas from the possession / invocability seam
- object and action rows should be able to render `held`, `local`, `fresh enough`, `too old for this action`, `step-up needed`, `presence needed`, `invokable now`, and `history only` as different truths;
- a **why-not-now drawer** should explain whether the blocker is missing authority, stale recency, stronger auth, or unsatisfied local presence;
- **recency shutters** should decay from `fresh` to `too old for this action` without pretending the underlying handle disappeared;
- **presence pins** should surface touch/verify/auth-now gates as narrow action-time truth;
- transcript filters should support `show me step-up-needed`, `show me presence-needed`, and `show me recently satisfied`.


## Watch/hold/successor ideas
- transcript rows should be able to attach one later status carrier without pretending it rewrites base object identity
- terminals should render watch freshness and local hold posture as semantic chrome, not as inferred color folklore
- object cards should support `refresh/adopt successor` as a different action class from `open/invoke now`


## More shell ideas from the lend/export seam
- object and action rows should be able to render `held`, `duplicate-local`, `lend-live`, `lend-narrowed`, `projected-doc`, `bytes-only`, `receipt-only`, and `history-only` as different truths;
- a **lane-fit badge** should explain whether the current best route is local duplicate, live lend, portal export, or TTY transfer;
- **same-object versus new-representation drawers** should explain what the receiver will actually get before send/export happens;
- transcript filters should support `show me live lends`, `show me bytes-only exports`, and `show me projected-doc exports`.

## More shell ideas from the borrow/project/localize seam
- object and action rows should be able to render `foreign-backed`, `wrapped-here`, `projected-here`, `materialized-here`, `local-object`, `receipt-only`, and `history-only` as different truths;
- a **borrow rail** should explain whether the current strongest posture is provider-backed use, projected local view, or true local realization;
- **provider-owned halos** and **dataless/materialized lamps** should surface why an item may work now but still depend on another service;
- transcript filters should support `show me borrowed`, `show me projected`, and `show me localized`.



## Route slips and authority sidecars
- Make typed route slips first-class transcript objects that can be copied safely when they are `designation only`.
- Show authority sidecars separately from route slips: wallet digest, URI-grant candidate, representation offers, proof-needed, or portal request.
- Let receiving panes expose sink trays that say exactly what they accepted: representation only, projected bind, live bind, localized copy, or declined.

## Privilege brackets and caller context
- Show **bracket rails** in the transcript gutter when one helper, plugin, or notebook block is inside one current borrowed-authority region.
- Render **caller badges** and **call-frame chips** separately from borrowed-authority drawers so `who asked?` never masquerades as `who can authorize?`.
- Add **deputy-fog warnings** when one helper crosses from explicit borrowed handles into ambient helper globals or task-local ambient state.
- Let result blocks expose **deny-only shutters** for provenance vetoes such as untrusted-plugin-in-chain or preview-pane-origin.

## More shell ideas from the native/adapted/coerced seam
- object and action rows should be able to render `native`, `adapter`, `relay`, `coerced`, `preview-only`, `localized`, `receipt-only`, and `history-only` as different truths;
- an **attach-mode badge** should explain whether the current best lane is same-object native fit, adapter-backed usability, or translated representation only;
- **adapter veils** should surface why a command succeeded only through one wrapper or relay;
- **virtuality lamps** should show when the user is looking at one coerced representation rather than one directly openable object surface;
- transcript filters should support `show me native`, `show me adapted`, and `show me coerced`.



## More ideas from Revision 096
- **Clean-start lamps**: every pane/command block should know whether it ran under built-in-only, reviewed-bundle, host-profile, or project-hook posture.
- **Bundle ledgers**: make prompt themes, alias/function packs, completion packs, and shell-integration helpers explicit reviewed objects instead of ambient dotfile side effects.
- **Hook quarantine gutters**: on `cd` / workspace open, show pending `.envrc` / repo-activation requests as quarantined until explicitly allowed.
- **Prompt provenance cards**: explain whether the current prompt or shell behavior comes from built-in code, a reviewed bundle, a startup file, or a project hook.
- **Replay without hooks**: rerun the last command under built-in-only posture to debug whether startup files or project hooks changed behavior.


- parse lenses that separate editable text from bound packet truth
- recovery fog over guessed structure when the line is incomplete
- diagnostic rails split by source: parser, lint, policy advice, history
- packet gutters that appear only after pane-local bind/compile
- compile diff cards when identical visible text binds differently across panes


## New pressure from Revision 099
- room identity, current view, inheritance posture, prepared child recipe, and child-received imports should be rendered as different shell-visible classes
- clean-room split/rerun should feel normal and fast rather than punitive
- receipts should be able to restore room explanation before any fresh imports are rebound

### 5c. Namespace switchboards, local overlay racks, and anchor death cards
Steal from REF-PLAN9, REF-XDG-REQUEST, REF-XDG-DOCUMENTS, REF-NU-OVERLAYS, and the sibling datacube pressure from Helm and Schell:
- every room should be able to show `planned target`, `live now`, `portal session`, `local overlay`, and `receipt only` as separate classes;
- local overlays should be visibly local-only and cheap to clear/rebuild;
- if an old switch/import/resume anchor died, the terminal should leave a tiny death card instead of silently repairing to latest.

## Summon / front / trusted-entry honesty
- treat `surface this room`, `activation baton available`, `frontmost now`, and `trusted entry` as distinct chrome classes;
- let tabs/panes carry summon beacons and front latches separately;
- use focus events and shell integration for polish, but keep a visible quality badge when the terminal only has hints;
- never let fullscreen/modal/big-pane state masquerade as a trusted approval or login path.


## More shell ideas from the proof-only / verify-only / live-use seam
- object and action rows should be able to render `descriptor only`, `verify only`, `read now`, `publish now`, `bound here`, and `history only` as different truths;
- a **proof card** should be safe to pin in notebooks, receipts, and workflow notes without silently reviving authority;
- **verify chips** should surface when the strongest safe action is check/validate rather than read or mutate;
- transcript filters should support `show me verify-only`, `show me proof cards`, and `show me publish facets`.
## Revision 153 shell idea: instruction ladders and toolcall fuses

The shell should make AI-assisted work feel like a superpower without hiding the instruction boundary. Every agent result should be inspectable through an instruction ladder, context shutter, proposal badge, plan compiler card, toolcall fuse, approval-basis drawer, and receipt ghost.

Especially useful UI moves:
- show workspace and parent-repo instructions as scoped proposals, not invisible policy;
- mark retrieved imperative text as inert content;
- show omitted context as loudly as included context;
- require a compiled action card before tool execution;
- show the exact live handle/secret/network/service slots a toolcall would consume;
- keep tool results as observations until adopted.

## Revision 154 terminal idea: approval blocks should expose consent posture

High-risk terminal actions should render as structured consent blocks, not raw `Are you sure?` prompts:

```text
[consent A-31] export object O-19 rev7
surface: portal-local   trusted-path: yes   gesture: hold-to-approve pending
+ read H7  + send N3  - no secrets  - no future reruns
```

A terminal click, keypress, or slash-command can request the block. The approval block itself should name the trusted-path posture, gesture freshness, summary digest, approval cut, and receipt status.
