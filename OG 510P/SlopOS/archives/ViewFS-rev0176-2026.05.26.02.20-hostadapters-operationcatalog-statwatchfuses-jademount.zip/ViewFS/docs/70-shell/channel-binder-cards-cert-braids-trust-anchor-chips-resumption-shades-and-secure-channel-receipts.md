# Channel binder cards, cert braids, trust-anchor chips, resumption shades, and secure-channel receipts

Revision 150 adds shell ideas for secure transport identity. The shell should make secure channels understandable without flattening everything into one green `trusted` padlock.

## Big shell promise

A user should be able to answer:

- what identity did this process intend to authenticate?
- what identity evidence did the peer present?
- which verifier profile and trust-anchor inputs were used?
- was any certificate exception, TOFU adoption, pin, or known-host change involved?
- is this a fresh channel, resumed channel, or 0-RTT early-data path?
- is upper-layer auth bound to this channel?
- did any client certificate, SVID, keychain item, or token get selected?
- what can the live channel do now, and what is only a receipt?

## UI pieces worth stealing

### Secure-channel cards

A compact card:

```text
secure channel
actor: updater helper
intent: fetch metadata
transport: tls1.3 / alpn h2
reference: DNS-ID updates.example.test
verifier: project-webpki epoch 18
status: matched, ct advisory, ocsp omitted
live: yes, recv 38 KiB
receipt: on close
```

The card should not say only `trusted`.

### Cert braids

A braid shows the whole authentication story without overclaiming:

```text
reference ids: DNS-ID api.example.test, SRV-ID _api.example.test
presented ids: DNS-ID api.example.test, wildcard omitted
path: accepted under bundle digest 4f...9a
status: no explicit status input
transparency: SCT present, inclusion not checked here
exception: none
```

Braids are explanation, not handles.

### Trust-anchor chips

Chips should label source and scope:

```text
root bundle: owner policy v12
enterprise root: absent
known-host: project local, unchanged
DANE: not used
SPIFFE bundle: trust-domain acme.test, digest redacted
```

A chip can be `local`, `project`, `portal`, `device`, `runtime`, `omitted`, or `receipt only`.

### Known-host ladders

SSH-like host key events deserve a ladder:

```text
first contact -> ask/adopt/deny
known unchanged -> connect
known changed -> stop, compare, rotate, or explicit exception
revoked -> deny
receipt only -> cannot reconnect
```

This makes TOFU loud without making it unusable.

### Channel binder cards

For app-layer auth:

```text
channel binding
scope: this live tls channel
upper auth: SCRAM-like challenge
exporter: digest redacted
reusable: no
receipt: proof that binding happened, not a token
```

The shell should never paste raw binder material into transcripts by default.

### Resumption shades

Show continuity as a shade, not a green badge:

```text
resumption: ticket from previous verified channel
0-RTT: disabled for writes
early data: read-only GET class allowed
replay posture: server unknown, client policy conservative
```

If early data carries mutation/export bytes, the UI should demand a named replay-safe cut.

### Client-auth shutters

Separate outbound peer authentication from client identity selection:

```text
client auth requested: yes
selected: project SVID / keychain alias redacted / none
secret lane: secret slot S-17
scope: this service binding only
residue: no exportable key material
```

A channel can be server-authenticated but client-anonymous, or client-authenticated under a separate secret/identity lane.

### Transparency panes

Transparency evidence should say what it says:

```text
certificate transparency
sct: present
inclusion proof: not checked in this flow
consistency proof: omitted
meaning: auditable evidence, not local trust clearance
```

### Secure-channel ghost receipts

After close:

```text
closed tls api.example.test  matched DNS-ID  381 KiB recv  receipt-only
closed ssh buildbox          known-host unchanged  no-live-channel
closed mtls indexer          client SVID redacted  cannot invoke
```

Ghosts should be great for debugging and useless as dialers.

## Command sketches

Do not freeze syntax, but preserve shape:

```text
viewfs net verify --explain service:updates
viewfs channel why-verified <channel>
viewfs channel bind-proof <channel> --for auth-step --redacted
viewfs channel resumption --show-shades
viewfs known-host adopt --scope project --expires 30d
viewfs cert-braid diff <old-receipt> <live-channel>
viewfs client-auth shutter <channel>
```

## Protocol metadata candidates

Terminal events worth prototyping later:

```text
secure_channel_opened {
  channel_id,
  transport_class,
  intent_id,
  reference_identity_digest,
  verifier_profile_id,
  trust_anchor_scope,
  verdict_summary,
  client_auth_state,
  resumption_state
}

secure_channel_receipt {
  channel_id,
  close_state,
  bytes_in,
  bytes_out,
  import_refs,
  export_refs,
  redaction_class,
  no_reconnect: true
}
```

## Guardrails

- No raw private keys, client cert secrets, channel-binding bytes, or session tickets in ordinary transcript attachments.
- No `trusted` badge without saying which verifier profile and reference identity matched.
- No `logged` / `transparent` badge that implies local admission.
- No certificate exception or known-host adoption without scope and receipt.
- No 0-RTT mutation/export without replay-safe policy.
- No receipt click that silently dials again.
