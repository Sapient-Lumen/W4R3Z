# Query/eval cards and benchmark dashboards

The shell should help users query, plan, compare, and evaluate without implying authority that is not present.

## Query cards

A query card should show source scope, field scope, index epoch, redaction posture, and the live handle or authority slot used to run it. It should never imply that a saved query can be replayed after authority or currentness changes.

## Planner cards

A planner card should show proposed effects, requested rights, hidden-effect checks, approval cut status, and the live carrier needed for the next effect. Model text and planner traces should be visibly inert until an approval cut and live authority exist.

## Result cards

A result card may rank and summarize matches, but opening a member must visibly jump to the member's backing live handle. Snippets, ids, embeddings, and result-set receipts should be rendered as selectors, not authority.

## Aggregation cards

Aggregation cards should display cohort thresholds, privacy posture, raw-row suppression, and whether exact membership has been suppressed. Any card that can answer “is this one object/person in the cohort?” should be treated as a membership-oracle risk.

## Evaluation and benchmark cards

Evaluation cards should show holdout sealing, contamination posture, license/purpose clearance, benchmark epoch, reproducibility state, rubric state, and known limitations. A score can recommend review. It cannot deploy.

## Model-selection dashboards

Dashboards must expose tradeoffs, uncertainty, stale runs, missing scenarios, and policy gaps. Single-score rankings and leaderboard badges should never be shown as production-readiness or deployment authority.
