# Strong-locks, weak-lamps, compare-profile drawers, and facet rails

Purpose: make comparison honesty rich without lying about exactness or current authority.

The future custom shell should be able to say five different things clearly:
1. **this row has an exact strong proof**
2. **this row only has a weaker sameness validator**
3. **this is the comparison profile that produced that answer**
4. **live authority is or is not bound here now**
5. **all that remains is receipt/history**

Those are not the same truth and should not share one vague `digest` or `etag` badge.

## Great moves

### Strong-lock badges
Every review/import/rebind card should be able to show:
- `exact proof`
- `range-safe`
- `commit-safe`
- `weaker than exact`
- `unknown`
- `history only`

Clicking the badge should explain why the shell considers the proof strong enough for the current act.

### Weak lamps
The shell should also be able to show:
- `same enough under profile`
- `changed under profile`
- `profile changed`
- `cannot compare`
- `heuristic only`
- `history only`

This is exactly where calm drift/reconsent hints belong.
Not on the exact proof badge.

### Compare-profile drawers
A small drawer should reveal:
- profile name or issuer
- what fields or bytes participate in sameness
- what gets ignored on purpose
- whether the profile is exact, weak, heuristic, or unknown
- whether the shell/provider or a reviewed spec declared it

This is much better than pretending `digest` means one thing everywhere.

### Facet rails
The shell should still make current power visibly separate:
- `bound here now`
- `bound elsewhere`
- `not bound`
- `proof/validator only`
- `history only`

This is the luxury version of honest capability UI.

### Repair ladders
Whenever drift or mismatch appears, the shell should offer visibly different acts:
- `use exact proof only`
- `review weak drift`
- `switch comparison profile`
- `fetch stronger proof`
- `ask for fresh bind`
- `keep receipt only`

That is much more truthful than one vague `refresh` button.

## Why this would feel super awesome
- it keeps review and repair calm even when exact proofs are absent;
- it makes weak sameness useful without overstating it;
- it tells the truth about the comparison rule in play;
- and it still keeps current live authority obviously separate.

## Guardrails
- never let a weak validator impersonate an exact strong proof.
- never let a comparison profile stay hidden when the UI is making a sameness claim.
- never let an old proof/validator card imply `bound here now`.
- never let `same enough` erase the difference between review calm and mutation safety.
