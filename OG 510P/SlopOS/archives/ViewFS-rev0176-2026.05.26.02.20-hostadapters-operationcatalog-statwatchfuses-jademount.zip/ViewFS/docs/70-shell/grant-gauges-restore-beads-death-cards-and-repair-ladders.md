# Grant gauges, restore beads, death cards, and repair ladders

Purpose: make continuity and permission posture luxurious without lying.

The future shell should be able to tell six different truths cleanly:
1. **what the outlook says now**
2. **what exact bounds were once reviewed or issued**
3. **whether any restore/reactivation material exists**
4. **whether a live bind exists here now**
5. **how continuity died, if it died**
6. **what history still remembers without reviving it**

## Great moves

### Grant gauges
Every object or route card should be able to show:
- `prompt`
- `granted`
- `denied`
- `reconsent needed`
- `unknown`
- `history only`

These are preflight honesty badges, not live-handle claims.

### Issued-bounds cards
When a reviewed descriptor or receipt exists, the shell should be able to show:
- what family issued it,
- what bounds it described,
- when it was issued or persisted,
- and whether the current provider is still the one that would have to answer for it.

That should feel more like a review card than a power button.

### Restore beads
Continuity aids deserve their own compact chrome:
- `single-use restore token`
- `renewable restore path`
- `repair offer`
- `rebind recipe`
- `none`

A restore bead should never impersonate a current live bind.

### Live-now rails
If authority really exists here now, say so plainly:
- `bound here now`
- `live in helper`
- `live in child`
- `not live here`

This is the only chrome that should drive strong `open`, `edit`, `publish`, `inject`, or `observe now` posture.

### Death cards
When continuity ends, preserve the reason:
- `revoked`
- `expired`
- `session closed`
- `token spent`
- `target changed`
- `provider unavailable`
- `history only`

One vague `stale` label is not enough.

### Repair ladders
The shell should offer visibly different next steps:
- `ask again`
- `reconsent`
- `rebind here`
- `repair provider link`
- `keep receipt only`

That is much better than one frustrated retry button.

## Why this would feel super awesome

This is the kind of shell chrome that feels genuinely premium:
- continuity gets explainable instead of magical;
- old receipts stay useful without silently becoming authority;
- users learn whether something is blocked by policy, expiry, session death, or target drift;
- and transcripts become safer because they can carry rich continuity memory without reviving live power.

## Guardrails
- never let `granted` impersonate `live now`.
- never let one old descriptor impersonate current provider state.
- never let a restore token impersonate a current bind.
- never let one old success badge hide the real death verdict.
- never let receipt/history rows silently reacquire authority.
