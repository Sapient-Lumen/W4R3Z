# Identity, session, credential, and secret custody cards

The shell should make identity and secret posture visible without leaking or laundering it.

## Card vocabulary

- **Identity card** — subject, issuer, assurance, session expiry, and whether a live authority slot backs the next effect.
- **Credential card** — credential/token scope, sender-constraint posture, expiry, and proof requirement, never the token string.
- **Sealed-object card** — envelope id, key version, algorithm posture, and whether cleartext is currently authorized.
- **Key rotation card** — old/new key versions, rewrap inventory status, and rotation authority slot.
- **Secret lease card** — scope, expiry, delivery eligibility, and safe-use status, never secret material.
- **Injection card** — delivery slot, target, redaction, env-shadow risk, and approval cut.
- **Escrow card** — quorum status, warrant scope, session currentness, and steward/recovery authority.

## Rendering constraints

Secret cards must be sealed and redacted. A card that displays secret material is a bug, not a debugging feature. A live badge is only valid when backed by a current live handle. An old login, old token refresh, old decrypt receipt, or old recovery ticket must render as history.
