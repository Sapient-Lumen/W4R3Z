# Stale shadows, repair ladders, and rebind receipts

The future ViewFS shell should make durable access and room restore feel luxurious **without** lying about what is live now, what is only a durable anchor, what has gone stale, and what still needs user or provider help.

## The three big UI moves

### 1. Stale shadow chips
Every room, object card, or receipt tray should be able to show compact state chips such as:
- `live now`
- `durable anchor only`
- `stale-needs-resolve`
- `prompt needed`
- `provider changed`
- `continuity uncertain`
- `receipt only`

Why this matters:
- users should be able to tell whether something is actually usable now or merely rememberable;
- old imports should stop masquerading as live binds;
- durable-reopen comfort should stop pretending there is no revocation, expiry, or drift.

### 2. Repair ladders
Borrow the best lesson from file pickers, portals, and explicit permission APIs:
- repair is better when the system names the next step.

A ViewFS repair ladder should show the strongest honest next verbs:
- `resolve anchor`
- `ask portal again`
- `rebind here`
- `import fresh and compare`
- `discard anchor`
- `keep receipt only`

Each rung should explain:
- whether user consent is needed,
- whether continuity is exact or only hoped-for,
- whether local overlays survive,
- and what receipt will be minted.

### 3. Rebind receipts
If repair succeeds, the terminal should leave behind a useful rebind receipt.

A rebind receipt should answer:
- what anchor or stale shadow it started from,
- whether identity continuity was exact, repaired, or uncertain,
- whether the live bind replaced a prior bind or created a new one,
- what rights changed,
- and what shell-local residue was preserved or dropped.

## Nifty moves worth stealing

### Durable-access racks
Show separate rows for:
- `durable anchor`
- `live now`
- `stale shadow`
- `repair plan`
- `receipt only`

### Currentness lamps
A room header should be able to say:
- `current`
- `stale`
- `repairable`
- `consent needed`
- `receipt only`

### Rebind-before-replay drawers
Before replaying a saved block or notebook cell, show:
- which refs are currently live,
- which are only durable anchors,
- which are stale shadows,
- and what repair ladder would run first.

### Bounded durable-list hygiene
If the shell keeps durable anchors around, it should also make hygiene visible:
- `unused`
- `stale`
- `repaired recently`
- `drop candidate`
- `pinned intentionally`

### Compare-after-repair cards
If a repair or fresh import succeeds, show whether the result is:
- `same identity`
- `same bytes, new local object`
- `provider says same, local proof weaker`
- `changed object`
- `unknown continuity`

## Anti-lies
- Do not let a durable anchor masquerade as a current live bind.
- Do not let a stale shadow masquerade as a successful repair.
- Do not silently replace `stale` with `current` just because some fallback happened.
- Do not let replay or room restore hide rebind work behind path folklore.
- Do not let durable-access lists become invisible junk drawers.

## Why this is low-regret now
These moves are mostly about **truthful continuity UX**.
They help the future shell+terminal become super awesome without prematurely deciding:
- one durable-anchor schema,
- one repair protocol,
- one rebind carrier,
- or one continuity object model.
