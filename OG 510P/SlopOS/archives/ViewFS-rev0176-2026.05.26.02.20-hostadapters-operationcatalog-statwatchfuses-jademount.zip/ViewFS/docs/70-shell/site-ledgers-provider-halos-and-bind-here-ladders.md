# Site ledgers, provider halos, and bind-here ladders

One of the nicest shell moves available to ViewFS is to stop letting a single displayed path pretend to mean everything.
This note collects shell/terminal ideas for the seam between **provider projection**, **room publication**, **live bind**, **localization**, and **history**.

## 1. Site ledgers instead of one flattering path chip
For any object card, pane title, or import result, the shell should be able to open a small ledger like:
- `provider projection at /run/user/.../doc/123/report`
- `published in this room at /work/report`
- `published to child room at /input/report`
- `localized here as replica`
- `local object-store fact`
- `receipt only`

This is much more honest than pretending the most recent path label is the object's identity.

## 2. Provider halos and locality lamps
A small chrome row can keep reality visible:
- `provider-owned`
- `portal view`
- `placeholder`
- `hydrated`
- `replica`
- `local object`
- `history only`

The exact labels can evolve.
The important move is that projection, publication, and locality stay separately inspectable.

## 3. Bind-here ladders
After a chooser, transfer, or open result, the shell should default to a ladder rather than one fake `open` button:
- `inspect only`
- `keep projected`
- `publish alias in this room`
- `publish alias to child recipe`
- `localize here`
- `receipt only`

That preserves the room/namespace act separately from the locality act.

## 4. Same-object multi-site diffs
When two panes both talk about `the same thing`, the shell should compare:
- same provider projection / different
- same published alias / different
- same live bind / no
- same localization state / different
- same receipt lineage / different

That is better than arguing over which path string looks more canonical.

## 5. Great terminal moves worth stealing
- **site ledgers** attached to command blocks so open/import results can show projection, publication, and localization separately.
- **provider halos** around projected rows and prompt-generated object cards.
- **bind-here last buttons** so the user can inspect or localize before committing a room alias.
- **locality shutters** that explain `projection only`, `hydrated but provider-owned`, `replica`, or `history only`.
- **multi-site compare drawers** so the terminal can show one object through several views without lying.

References: REF-XDG-DOCUMENTS, REF-ANDROID-SAF, REF-ANDROID-FILEPROVIDER, REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-DIR-CAPS, REF-MS-CFREGISTER, REF-MS-CFCONVERT, REF-APPLE-FILEPROVIDER-SYNC.
