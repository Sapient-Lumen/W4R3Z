# Switchboards, overlay racks, and anchor death cards

The future ViewFS shell should make namespace switching and mediated imports feel luxurious **without** lying about what is live, what is only local convenience, and what already died.

## The three big UI moves

### 1. Namespace switchboards
Every room should be able to show a compact switchboard with separate rows for:
- `planned target`
- `live now`
- `portal session`
- `local overlay`
- `receipt only`

Why this matters:
- users should be able to tell whether a room is currently bound, merely staged, waiting on a portal step, or living on history;
- reviewable switch plans should stop pretending they already changed the room;
- expired import sessions should stop masquerading as current live authority.

### 2. Overlay racks
Borrow the best lesson from Nushell overlays and Helm local overlays:
- explicit layers are delightful when they stay explicit.

A ViewFS overlay rack should show which deltas are:
- `device-local`
- `activity-local`
- `workspace-local`
- `stale after switch`
- `safe to clear`
- `receipt only`

Great actions:
- `compare overlay to live room`
- `clear local residue`
- `copy to new activity-local overlay`
- `rebuild from portable core`

### 3. Anchor death cards
Borrow Schell's reset-scope humility.
If a switch/import/resume anchor no longer survives exactly, the terminal should say so.

A tiny death card should answer:
- what exact anchor died,
- what killed it,
- what weaker residue survives,
- and the strongest honest next verb now.

Good death labels:
- `switch target replaced`
- `import session expired`
- `restore bounded`
- `room reset`
- `epoch changed`
- `unknown`

## Nifty moves worth stealing

### Import session strips
Show request/session truth inline:
- `request pending`
- `user step needed`
- `granted not bound`
- `bound here`
- `expired`
- `receipt only`

### Reset-scope chips
When something dies or is cleared, show how much died:
- `overlay only`
- `import session only`
- `room binding changed`
- `whole room reset`
- `layout survived only`

### Compare-before-switch drawers
Before committing a switch, show:
- current live room binding,
- planned target,
- portal/import work still pending,
- local overlay that would survive,
- local overlay that would go stale.

### Receipt-first room restore
On reopen/restore, bring back:
1. room identity and layout,
2. switch/import receipts,
3. local overlay residue clearly marked,
4. then ask whether to repair or rebind live authority.

### Room-aware palette actions
A room-aware command palette should be able to act on:
- rooms,
- namespace plans,
- live binds,
- portal sessions,
- overlays,
- and receipts

as different classes.

## Anti-lies
- Do not let a saved switch plan masquerade as a current room bind.
- Do not let an expired portal session masquerade as a durable live import.
- Do not let local overlay convenience state masquerade as portable core truth.
- Do not silently jump to `latest` if the old switch/import anchor died.
- Do not let room restore fake continuity when only layout survived.

## Why this is low-regret now
These moves are mostly about **truthful UI seams**.
They help the future shell+terminal become super awesome without prematurely deciding:
- one overlay schema,
- one switch protocol,
- one object-store layout,
- or one final import-session carrier.
