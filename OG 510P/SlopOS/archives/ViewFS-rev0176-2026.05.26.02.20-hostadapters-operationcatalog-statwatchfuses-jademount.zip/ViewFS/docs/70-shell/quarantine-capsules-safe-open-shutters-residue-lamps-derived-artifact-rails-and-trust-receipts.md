# Quarantine capsules, safe-open shutters, residue lamps, derived-artifact rails, and trust receipts

Revision: 142  
Date: 2026-05-13  
Codename: quarantinecapsules-residuelamps-trustreceipts-amberreed

## Shell goal

Risky content should feel manageable, not mysterious. The shell should make the safe path obvious while refusing to launder risk through convenience surfaces.

A user should be able to answer:

- where did this object come from?
- why is it quarantined?
- what can I do safely right now?
- did this preview leave residue?
- is this search hit the risky source or a derived artifact?
- what exactly did I clear?
- can this be edited but not run?
- what is only a receipt?

## Six visible moves

### 1. Origin braid

Every risky object can show a compact origin braid:

```text
invoice.xlsm
  origin: mail attachment -> archive entry -> portal import
  parent: archive.zip#invoices/q2.xlsm
  locator: redacted
  state: quarantined / safe-open only
```

The braid should be expandable without exposing raw URLs, bearer tokens, secret provider IDs, or hidden account details by default.

### 2. Quarantine shutter

A shutter says what is currently blocked and what the next safe action is:

```text
report.docm     quarantined
  allowed: peek metadata, open safe
  blocked: macros, helper launch, full edit, execution
  next: Open safe | Export sanitized | Request object-local clear
```

The shutter is not a modal nag. It is live state. Opening it does not clear anything.

### 3. Safe-open capsule card

When the user chooses `open safe`, the shell should show the capsule:

```text
Safe-open capsule #S-44
  source: report.docm @ digest 91fd…
  input: stable snapshot 5e12…
  viewer: disposable doc viewer
  active content: inert
  residue: disposable-local, scrub on close
  export: new artifact only
```

The user should be able to see that the viewer is not holding a live write-through alias to the source.

### 4. Residue lamp

A residue lamp makes side effects visible:

```text
Residue after safe-open
  thumbnail: disposable-local / discarded
  OCR: not run
  embeddings: blocked
  MRU: shell receipt only, non-reopen
  autosave: disposable-local / discarded
```

A bright lamp is especially useful for developer builds and security review. It turns `helpful cache` into an auditable lane.

### 5. Derived-artifact rail

When the user exports, sanitizes, extracts, summarizes, or keeps output, show a rail from source to new artifact:

```text
source: invoice.xlsm       quarantined
  -> sanitized PDF          new object / parent recorded
  -> extracted text         new object / quarantined by default
  -> summary card           derived artifact / source not resurfaced
```

The rail should prevent a common UI lie: showing a derived match but opening the risky source as if it were the matched object.

### 6. Trust receipt

Trust decisions deserve receipt cards:

```text
Trust receipt #T-19
  subject: sanitized-invoice.pdf @ digest a3c1…
  scope: allow document edit
  still blocked: macros, helper launch, execution
  basis: sanitizer workflow + manual review
  expires: workspace session end
```

A good receipt should make the scope smaller than the user feared and clearer than the app expected.

## Commands worth prototyping

```text
viewfs origin <object>
viewfs quarantine why <object>
viewfs open-safe <object>
viewfs capsule inspect <capsule-id>
viewfs residue inspect <capsule-id>
viewfs derive sanitize <object>
viewfs derive summary <object> --as-artifact
viewfs trust request <object> --scope edit
viewfs trust receipts <object>
viewfs search --metadata-safe <query>
```

## Design guardrails for UX

- `Open safe` must not look like `Trust`.
- `Trust for edit` must not look like `Trust for execution`.
- `Derived artifact` must not look like `cleared source`.
- `Same bytes` must not hide different origin/trust stories.
- Search snippets from quarantined bytes should require explicit review, not hover.
- MRU and recents rows should be receipt-like hints, not reopen grants.
- The shell should prefer action ladders over scary all-or-nothing prompts.

## Protocol hints, not a protocol

Future shell events could reserve names like:

- `viewfs.quarantine.origin_evidence`
- `viewfs.quarantine.mark_state`
- `viewfs.safe_open.capsule_started`
- `viewfs.safe_open.residue_state`
- `viewfs.quarantine.derived_artifact`
- `viewfs.trust.clearance_decision`
- `viewfs.live_open.authority_state`
- `viewfs.quarantine.receipt`

Candidate fields:

```text
object_core_digest
origin_receipt_digest
origin_class
parent_digest
quarantine_mark_digest
risk_state
allowed_default_lane
blocked_active_classes
safe_open_capsule_id
materialization_digest
viewer_domain
residue_policy
residue_summary_digest
derived_artifact_digest
derivation_kind
trust_clearance_id
clearance_scope
clearance_basis
clearance_expiry
live_open_facet_id
redaction_level
```

The event stream must not carry raw bearer tokens, raw source locators, raw provider account IDs, or unredacted content snippets by default.

## Demo scenarios

1. Import a document from an archive attachment; show origin braid and inherited quarantine.
2. Safe-open the object; show stable input, inert active content, and disposable-local residue.
3. Generate a summary; prove it becomes a derived artifact and search hits do not silently open the source.
4. Sanitize/export to a new artifact; show parent rail and default quarantine on ordinary output.
5. Clear only the sanitized artifact for document edit; prove macros and execution remain blocked.
6. Restore from a root ledger; prove old safe-open receipts do not recreate live open authority.
