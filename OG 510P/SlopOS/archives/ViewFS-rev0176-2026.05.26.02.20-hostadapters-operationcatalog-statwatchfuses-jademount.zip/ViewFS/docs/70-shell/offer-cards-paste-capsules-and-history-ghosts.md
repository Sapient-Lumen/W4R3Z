# Offer cards, paste capsules, and history ghosts

The future custom shell can be gorgeous here **without** telling lies.
The trick is to make `current offer`, `retained ghost`, `prompt bytes now`, and `materialized local object` visibly different.

## Great moves
### 1. Offer cards
Every pane or room that can currently see a transferable offer should render a compact card that can say:
- `clipboard offer`
- `primary selection`
- `drag offer`
- `share offer`
- `offer gone`

Opening the card should show owner/source witness when known, offered representations, and the one representation the receiver is about to ask for or already accepted.

### 2. Paste capsules
When bytes arrive in the prompt, show a tiny capsule rather than pretending the user typed them:
- `bracketed paste`
- `quoted paste`
- `path-like text only`
- `prompt bytes only`
- `scratch capsule`

That makes inspect-before-run, quote-before-run, and import-from-paste flows much more honest.

### 3. History ghosts
If a privileged helper retained an older offer, the shell should show that as a separate ghost state:
- `retained by helper`
- `summary only`
- `source gone`
- `expired`
- `privacy clamped`

A history ghost should never masquerade as a live offer or a current imported object.

### 4. Representation ladders
A delightful terminal should make it obvious that there may be more than one representation in play:
- `text/plain`
- `text/uri-list`
- `portal filetransfer`
- `image/png`
- `application/vnd.portal.filetransfer`
- `promise only`

One click should show `offered`, `accepted for prompt`, `accepted for import`, `materialized`, or `history only` as different states.

### 5. Materialize ladders
The nicest move here is a truth-preserving ladder:
- `paste only`
- `quote and insert`
- `inspect representation`
- `import locally`
- `adopt bind`
- `receipt only`

That keeps transfer delight high without quietly widening authority.

### 6. Clipboard quality badges
The shell should confess how much clipboard truth it really knows:
- `rich offer truth`
- `owner unknown`
- `history helper only`
- `prompt-local only`
- `none`

That lets the shell feel magical without pretending every backend offers the same visibility.

## Guardrail
Offer cards, paste capsules, history ghosts, and materialize ladders are explanation and control chrome.
They are not themselves authority, and they must not silently widen a room into durable import, manager-retained history, or reopened live binds.
