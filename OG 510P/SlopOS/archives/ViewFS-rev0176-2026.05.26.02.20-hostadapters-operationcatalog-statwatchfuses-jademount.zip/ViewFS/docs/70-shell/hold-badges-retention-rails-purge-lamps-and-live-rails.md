# Hold badges, retention rails, purge lamps, and live rails

Steal from current SlopOS persistence/evidence posture plus Amazon S3 Object Lock, Google Cloud Storage object holds and Object Retention Lock, and Azure immutable storage.

Whenever the shell renders one object/cleanup/history row, it should be able to show:
- whether it is talking about one **durable committed object** or only a **history row**,
- whether one **retention rail** exists and whether it is editable, locked, satisfied, or unknown,
- whether one **hold badge** is temporary, event-driven, legal, multiple, or none,
- whether one **purge lamp** says eligible, blocked by retention, blocked by hold, lifecycle pending, purged, or history only,
- whether a **live facet** is actually present now.

Why this is great:
- object-store cleanup becomes delightful without lying about what policy still blocks;
- `retained`, `held`, and `usable now` stop blurring together;
- purge attempts become explainable instead of spooky;
- the shell can stay luxurious while telling the truth about durable object birth, keep rules, deletion eligibility, and current authority.

Guardrail:
- never let one old hold badge, retention rail, or purge receipt impersonate a current live facet or current absence.
