# Shell super-awesome moves

Purpose: collect unusually good shell/terminal ideas for ViewFS without prematurely freezing shell syntax.

These are product ideas, not protocol commitments. The common rule is: **every delightful feature should still tell the truth about authority.**

## R150. Channel binder cards, cert braids, trust-anchor chips, and resumption shades
Steal from RFC 9525, TLS 1.3, TLS channel binding, Certificate Transparency, OpenSSH known-host checking, SPIFFE X.509-SVID, DANE, and SlopOS D-NETLEASE verifier/resumption boundaries.

The shell should make secure channels explainable without making them magical:
- show which reference identity was intended before peer evidence arrived;
- show presented certificate/host-key/SVID/status/transparency evidence as evidence;
- show verifier profile and trust-anchor inputs as local policy;
- show channel binding as scoped proof material, never as a pasteable token;
- shade resumption and 0-RTT paths so replay-sensitive actions stay obvious;
- leave a ghost receipt after close that cannot reconnect.

Guardrail:
- never let one green `trusted` badge imply object import trust, service authorization, secret release, or durable reconnect authority.

## 0. Room badges, context diffs, and child import trays
Steal from REF-WEZTERM-SHELL-INT, REF-GHOSTTY-SHELLINT, REF-GHOSTTY-CMDPALETTE, REF-FISH, and REF-NU-OVERLAYS.

The shell should treat the thing a human thinks of as a **room** as a first-class object distinct from:
- the room's current view,
- the room's child-inheritance posture,
- the next spawn/import recipe,
- and any old receipt.

Why this is great:
- it makes split/rerun/helper workflows honest without feeling austere;
- it gives the terminal a better organizing unit than raw cwd or raw process id;
- it keeps custom-shell delight compatible with explicit authority.

Guardrail:
- room identity must not silently count as current child authority or durable reopen power.

What the UI should grow:
- **room badges** showing room identity, current view label, and inheritance posture separately;
- **context diff drawers** comparing `this room now` and `candidate child room`;
- **spawn recipe cards** with `prepared`, `committed`, `partial imports`, `blocked`, or `receipt only`;
- **child import trays** showing `requested`, `granted`, `bound`, `skipped`, or `receipt only`;
- **receipt-first room restore** so layout and explanation return before fresh authority does.

## 1. Object palette, not just command palette
Steal from REF-WARP-CMDPALETTE and REF-PLAN9-PLUMB.

One searchable palette should find:
- workflows
- notebooks/runbooks
- recent receipts
- object refs and manifests
- saved views
- routeable actions like `inspect`, `open`, `export`, `send`, `rebind`

Why this is great:
- it turns the shell into an object navigator, not just a text launcher
- it reduces hidden aliases and wiki archaeology

Guardrail:
- palette actions should show whether they are pure inspection, local mutation, transfer, or portal-mediated export before execution

## 2. Authority diff before Enter
Steal from REF-FISH and REF-NUSHELL.

When a command is ready to run, the shell should be able to show a tiny diff-like preview:
- reads from `/work` and `/in`
- writes to `/out` and `/state`
- may invoke `portal.file.open`
- may invoke `portal.xfer`
- contains ambient debt

Why this is great:
- users stop treating authority as invisible folklore
- dangerous surprises become visible before execution

Guardrail:
- this is a preview, not a false proof; uncertain cases should say so

## 3. Receipt tray for the current pane
Steal from REF-WARP-BLOCKS and REF-XDG-FILETRANSFER.

Each pane should have a small receipt tray showing the last few:
- imports
- exports
- transfers
- manifests
- debt receipts

Why this is great:
- receipts become reusable work objects instead of disappearing into scrollback
- drag/drop between tools can become explicit transfer actions

Guardrail:
- expiry and durability state should be visible on each receipt

## 4. Chooser sheets and staging trays
Steal from REF-XDG-REQUEST, REF-XDG-FILECHOOSER, REF-XDG-DOCUMENTS, and REF-ANDROID-SAF.

A mediated import should not just disappear into a dialog result.
The shell should show:
- request chip / chooser sheet,
- selected result,
- provider-supported operations,
- `bind here` / `launch with` / `keep for later` / `receipt only` choices,
- and then the resulting ledger entry.

Why this is great:
- portal-mediated workflows become inspectable and reusable
- “I selected it” stops pretending to mean “this pane already has it live”

Guardrail:
- candidate browsing should not become generic machine inventory, and durable upgrade should stay explicit

## 5. Explain access timeline
Steal from REF-WEZTERM-SHELL-INT plus the existing SlopOS transcript posture.

For any command block, the user should be able to ask:
- what object was touched
- how was it named here
- which grant/receipt made that possible
- did compat/path fallback occur
- did any authority persist afterward

Why this is great:
- it turns debugging and security inspection into the same UX

Guardrail:
- explanations should distinguish immutable object ID, current path name, mutable head, and durable receipt state

## 5. Route sheet instead of “open this string somehow”
Steal from REF-PLAN9-PLUMB, REF-XDG-OPENURI, and REF-PLAN9-ACME.

Selecting an object, receipt, or URI should open a typed route sheet:
- inspect object
- open with viewer/editor
- export
- send via transfer portal
- open URI externally
- reveal containing view binding

Why this is great:
- it makes object actions discoverable and auditable
- it unifies file-ish and URI-ish actions under explicit routing

Guardrail:
- local files should not silently become generic URI opens; route sheets should preserve the right seam

## 6. View-aware panes and split domains
Steal from REF-WEZTERM-DOMAINS and REF-FUCHSIA-NAMESPACE.

Every pane/tab should advertise:
- active view label
- synthetic cwd
- mutation posture
- ambient-debt status

Why this is great:
- panes become different authority domains, not just different scroll regions

Guardrail:
- copying a command from one pane to another should not silently copy its authority

## 7. Local-first runnable notebooks
Steal from REF-WARP-NOTEBOOKS.

Runbooks should support:
- markdown explanation
- runnable commands
- embedded receipts/manifests
- parameter prompts
- last-run outcomes
- plain Markdown export

Why this is great:
- the shell becomes a trustworthy operations notebook
- knowledge stays close to execution

Guardrail:
- notebooks should reference receipts and views explicitly; they should not smuggle hidden durable grants inside the document itself

## 8. Safe replay with stripped authority
This is a ViewFS-native move.

A finished block should offer:
- replay exactly
- replay read-only
- replay without exports
- replay in fresh temp view
- replay with explicit chooser re-consent

Why this is great:
- users can rerun workflows with less authority than the original
- it turns attenuation into a daily tool, not an exotic security feature

Guardrail:
- the replay UI must show which handles/grants were removed or re-requested

## 9. Ambient debt siren
Steal from REF-CAPSTD and REF-LANDLOCK.

If a command uses ambient host authority or a host-path compat escape, the shell should make it loud:
- visible badge in the block
- searchable debt receipt
- optional pane-wide warning until cleared

Why this is great:
- bring-up shortcuts stop masquerading as final design

Guardrail:
- do not make the warning ignorable by default in strict/dev-review modes

## 10. Background output should still be first-class
Steal from REF-WARP-BLOCKS.

If background work emits output, that output should land in explicit blocks with:
- source workflow/job identity
- view/domain
- attached receipts
- whether the job still has active authority

Why this is great:
- long-running work remains inspectable and routable

Guardrail:
- background output must not imply hidden background authority; it still needs an explicit grant story

## 11. Basis lamps and verdict cards for pushback honesty
Steal from REF-GIT-FORCE-WITH-LEASE, REF-RFC9110-PRECONDITIONS, REF-GCS-PRECONDITIONS, and REF-VSCODE-SHELL-INTEGRATION.

Whenever a pane is editing a local shadow over a provider-backed or externally governed object, the shell should be able to show:
- exact pushback basis / expected-old state
- provider drift since basis
- provider verdict on the last push attempt
- local adoption choice after that verdict
- visibility quality of that information (`rich`, `basic`, `heuristic`)

Why this is great:
- users stop confusing `my draft exists` with `the provider accepted it`;
- conflict and retry flows become elegant instead of spooky;
- the shell gets force-with-lease-grade safety without pretending every backend is Git.

Guardrail:
- provider verdict must not silently overwrite or discard the local draft; adoption should stay explicit.

## One narrow prototype to earn all this
The best first shell prototype is probably just:
- visible view badge
- block boundaries
- one-keystroke authority preview
- one receipt tray
- one explain-access inspector
- one loud ambient-debt marker

If that feels magical **and** honest, then the bigger notebook/palette/routing ideas are probably worth the complexity.


## 6. Route-plan card instead of instant side effect
Clicking a typed object, receipt, or route suggestion should normally open a **route-plan card** first.

That card should say:
- what intent is being satisfied,
- which route/provider/target is chosen,
- whether approval is needed,
- what authority delta would happen,
- and what the result card would likely record.

The super-awesome part is not instant execution. The super-awesome part is that the shell becomes fast *and* truthful.


## 11. Basis diff before replay or renewal
Steal from REF-DIRENV-REQUIREALLOWED, REF-APPLE-SECRESOLVE, and REF-DENO-PERMISSIONS.

## 12. Stale shadow chips and repair ladders
Steal from REF-XDG-DOCUMENTS, REF-APPLE-SECSTART, REF-APPLE-SECRESOLVE, REF-ANDROID-SAF, REF-MS-FUTUREACCESSLIST, and REF-WICG-FSACCESS.

A remembered import or durable reopen anchor should not just be either `works` or `broken`.
The shell should expose a middle class:
- `live now`
- `durable anchor only`
- `stale-needs-resolve`
- `consent needed`
- `continuity uncertain`
- `receipt only`

Why this is great:
- repair becomes an explicit workflow instead of path-error archaeology
- durable-access comfort stays honest without feeling punitive

Guardrail:
- a stale shadow is not a live bind, and a repair plan is not a repaired bind.

## 13. Durable-access rack with hygiene cues
Steal from REF-MS-FUTUREACCESSLIST and REF-ANDROID-SAF.

If the shell keeps durable anchors around, it should also show which ones are:
- `pinned intentionally`
- `unused`
- `stale`
- `repairable`
- `drop candidate`

Why this is great:
- long-lived durable access becomes reviewable maintenance instead of invisible junk-drawer state

Guardrail:
- list membership should not imply current authority.

Before rerunning from a receipt, notebook cell, workflow, or durable reopen ref, the shell should be able to show a tiny basis diff:
- what exact basis was recorded before
- what still matches
- what narrowed
- what disappeared
- whether fresh chooser / fresh lend / fresh temp view is required

Why this is great:
- users can move fast without pretending old success is current permission
- replay becomes truthful even when it cannot be exact

Guardrail:
- a basis diff is not itself approval; the UI must keep reconsent and renewed authority visibly separate

## 12. Cut picker before the shell swaps judges
Steal from REF-OPA-DISCOVERY, REF-CEDAR-VALIDATION, REF-SPICEDB-CONSISTENCY, and REF-XDG-REQUEST.

Before switching policy family/cut because of drift, invalid state, or a tempting newer candidate, the shell should be able to show a tiny cut picker:
- what family/cut is authoritative now
- what consistency posture it used
- what fallback candidates exist
- what the shell is only recommending as a repair
- whether the result would be `same family newer cut`, `exact snapshot`, `fresh latest`, `ask mediator`, or `history only`

Why this is great:
- the shell can help recover quickly without becoming a hidden policy negotiator
- users can tell whether a current answer came from explicit choice, repair adoption, or only history

Guardrail:
- a fallback rail or repair prompt is not itself an authoritative policy switch; the UI must keep the exact selected cut visibly separate from advice and history.



## 13. Proposer badge before the shell asks you to widen trust
Steal from REF-GIT-CONFIG-ORIGIN-SCOPE, REF-VSCODE-CHAT-CUSTOM-DIAG, REF-VSCODE-MCP-SERVERS, REF-VSCODE-AGENT-PERMISSIONS, and REF-POLKIT-AUTHORITY.

Before a workspace hint, receipt replay, history row, or shell-local repair becomes live at a broader scope, the shell should show:
- who proposed it
- what scope it is asking for
- whether it is only advice, pending escalation, or ready for adoption
- who is allowed to adopt it
- what receipt will be written if accepted or declined

Why this is great:
- the shell can stay fast and ambitious without becoming a hidden selector
- users can safely accept a narrow one-shot fix without accidentally persisting a wider standing rule

Guardrail:
- proposal surfaces must stay non-authoritative until an explicit adoption gate is crossed, and the gate must not silently widen from `once` to `workspace` or `profile`.


## 14. Ceiling pill before the shell widens anything
Steal from REF-CEDAR-SECURITY, REF-DENO-PERMISSIONS, REF-VSCODE-CONTRIB-SCOPES, REF-VSCODE-WORKSPACE-TRUST-EXT, and REF-VSCODE-AGENT-TOOLS.

Before a proposal tries to grow from `once` to `session`, `workspace`, `profile`, or beyond, the shell should show:
- what deny ceiling applies
- whether this origin/target combination is even admissible at that scope
- what narrower safe choices exist
- whether the result will be adopted, narrowed, blocked, or receipt-only

Why this is great:
- the shell can stay fast without becoming a loophole around owner, org, or trust ceilings
- users can accept the narrowest safe option almost instantly

Guardrail:
- a narrowing preview is not itself an adoption, and a ceiling explanation is not an override surface.


## 15. Origin stack before the shell treats “present” as “active”
Steal from REF-VSCODE-AI-POLICIES, REF-VSCODE-ENTERPRISE-POLICIES, REF-VSCODE-MCP-CONFIG, REF-GIT-CONFIG-ORIGIN-SCOPE, and REF-DENO-PERMISSIONS.

Before a workspace file, imported helper config, or remembered receipt is allowed to matter, the shell should be able to show a tiny origin stack:
- what sources exist
- which one currently wins
- which ones are merely visible but withheld by trust state
- whether an owner/org ceiling is suppressing a lower layer
- whether a source is only imported/history material rather than live truth

Why this is great:
- the shell can be extremely helpful without becoming a hidden policy blender
- users can inspect “why didn’t this take effect?” instantly instead of debugging folklore

Guardrail:
- opening the origin stack, trust shutter, or override ledger must not itself activate or promote anything.


## 12. Author badge + carrier tag + trust-tunnel siren
Steal from REF-GIT-CONFIG-ORIGIN-SCOPE, REF-VSCODE-ENTERPRISE-POLICIES, REF-VSCODE-AGENT-PLUGINS, and REF-VSCODE-WORKSPACE-TRUST.

The shell should be able to show three different facts at once:
- who authored the current active answer,
- what merely carried candidate material here,
- and whether a trust gate still blocks that carrier from becoming active truth.

Why this is great:
- trusted plugins, parent repos, or imported bundles stop turning into invisible policy tunnels;
- users can inspect why something is visible without mistaking that for why it is active.

Guardrail:
- carrier tags and trust-tunnel sirens are explanatory surfaces until the user explicitly enters an adoption or review path.


## 16. Protected chip + matrix drawer + latched invoke
Steal from REF-GIT-PROTECTED-CONFIG, REF-GIT-SAFE-DIRECTORY, REF-VSCODE-PROMPT-FILES, REF-VSCODE-CUSTOM-AGENTS, and REF-DENO-PERM-BROKER.

Before lower-trust helper material is allowed to matter, the shell should be able to show:
- whether the targeted state class is protected-only,
- whether this source class is only invoke-only or adoptable,
- whether a stronger broker/owner/org lane is currently deciding,
- what one-shot narrow path exists right now,
- and what receipt would be written for invoke versus adopt.

Why this is great:
- the shell can stay extremely helpful without turning visible helper material into sticky truth;
- users can take a productive one-shot path instantly without accidentally writing always-on state.

Guardrail:
- a matrix drawer or protected chip is not itself an override surface, and a latched invoke must not silently promote itself into future automatic behavior.


## 13. Tool rack instead of “installed therefore live”
Steal from REF-VSCODE-PUBLISHER-TRUST, REF-VSCODE-MCP-SERVERS-LIVE, REF-VSCODE-PLUGIN-LIFECYCLE, REF-VSCODE-COPILOT-BOUNDARIES, and REF-DENO-PERM-BROKER-LIVE.

A helper-aware terminal should be able to show:
- who vouched for install,
- whether the helper is merely installed or actually enabled,
- whether it still needs a start approval,
- whether it is live right now,
- and which tools/resources/prompts are selected for this request.

Why this is great:
- users can stage many helpers without pretending they are already running,
- “why didn’t that tool run?” becomes debuggable from terminal chrome,
- live helper state becomes visible without flattening everything into hidden settings.

Guardrail:
- do not let installed or enabled state masquerade as current live authority.


## 17. Resource shelf + prompt chip + tool rack + app dock
Steal from REF-MCP-RESOURCES, REF-MCP-PROMPTS, REF-MCP-TOOLS, REF-MCP-COMPLETION, REF-VSCODE-MCP-SERVERS-LIVE, and REF-WEZTERM-SHELL-INT.

A helper-aware terminal should be able to show four different things without flattening them:
- resources you may browse or attach,
- prompts you may fill or expand,
- tools you may enable or invoke,
- apps you may launch or dock.

And it should keep one more thing clearly advisory: completion suggestions for prompt/resource arguments.

Why this is great:
- helper catalogs become rich and fast without pretending every visible item is active now;
- prompt chips and resource shelves make request assembly inspectable;
- app docks make interactive helper surfaces possible without disguising them as files or commands.

Guardrail:
- catalog presence, completions, request binding, live invocation, and durable history must stay visibly different in terminal chrome and receipts.


## 18. Task badge + progress lane + result locker
Steal from REF-XDG-REQUEST, REF-MCP-TASKS, REF-MCP-PROGRESS, REF-GCLOUD-LRO, REF-XDG-BACKGROUND, REF-VSCODE-TASKS-BG, and REF-VSCODE-109-BGAGENTS.

A helper-aware terminal should be able to show:
- the exact request that was submitted now,
- whether it was merely accepted for deferred work,
- a live progress/status lane that is visibly advisory,
- whether more input is required before completion,
- a result locker only after the final output is actually retrievable,
- and what queued follow-ups are waiting behind the still-running task.

Why this is great:
- long-running work can feel native without pretending every request is a blocking call;
- follow-up steering stays honest because the current running task, queued next act, and final result are visibly different classes;
- background sessions become visible without turning “may continue later” into standing authority folklore.

Guardrail:
- acceptance must not imply final result availability, progress must not masquerade as durable success, and old task receipts must not pose as still-running requests.
- Treat `close`, `cancel`, `terminate`, `detach`, `retry fresh`, and `fork/reset` as different terminal-native control moves, and surface them through stop ladders, detach rails, and result-retention lockers instead of one generic stop button.


## 19. Follow tail + attach rail + control pane + sideband badge
Steal from REF-KUBECTL-LOGS, REF-KUBECTL-ATTACH, REF-KUBECTL-PORTFWD, REF-TMUX, REF-TEMPORAL-MESSAGES, REF-XDG-INPUTCAPTURE, and REF-WEZTERM-USERVARS.

A live-session-aware terminal should be able to show:
- whether the current lane is observe-only, read-only attach, interactive attach, control-message, debug exec, or sideband tunnel,
- whether interaction is merely armed or truly active,
- whether stdin is live,
- whether the user is seeing an old transcript or a live surface,
- and whether a tunnel or debug lane ends when the source run ends.

Why this is great:
- watching becomes safe and first-class instead of a crippled attach;
- control actions stop hiding inside log panes;
- debug exec becomes a loud deliberate move rather than a silent side effect;
- sideband access becomes visible and temporary instead of ambient.

Guardrail:
- observe/query lanes, attach lanes, control-message lanes, exec/debug lanes, sideband lanes, and durable transcripts must stay visibly different in pane chrome and receipts.

## 20. Semantic inspector overlay + restricted badge + prompt-local clicks
Steal from REF-WEZTERM-ZONES, REF-WEZTERM-USERVARS, REF-ITERM-SHELLINT, REF-GHOSTTY-OSC133-OVERLAY, REF-VSCODE-WORKSPACE-TRUST, and REF-PLAN9-PLUMB.

A ViewFS-native terminal should be able to show, without guesswork:
- which regions are prompt, input, output, sideband, or history-only transcript material,
- whether the current pane is `trusted`, `restricted`, `receipt only`, or carrying `compat debt`,
- which printed links are refs, receipts, route sheets, or plain text,
- and whether click-to-cursor is only valid inside the active prompt/input zone.

Why this is great:
- the shell can become much more interactive without hiding where live authority begins and ends;
- protocol bugs become debuggable because the terminal can display what semantic regions it believes exist;
- restricted-but-productive panes stop feeling broken because the terminal can explain their posture directly in chrome.

Guardrail:
- semantic overlays, trust badges, and typed links are explanatory surfaces; they must not silently widen access, auto-rebind old authority, or turn history text into live handles.


## 21. Pane vars, not env vars, for terminal truth
Steal from REF-WEZTERM-USERVARS, REF-WEZTERM-SHELL-INT, and REF-ITERM-SHELLINT.

The terminal should know some pane/session facts because the shell tells it deliberately, not because the child process environment happens to leak them.

Good candidates:
- active view label
- synthetic cwd label
- restricted/trusted/receipt-only posture
- current route-plan / task / request badge state
- ambient-debt present/clear

Why this is great:
- terminal chrome can stay truthful without pretending those badges are process authority;
- pane state can survive UX actions like splits, inspectors, and palette navigation without becoming hidden child config.

Guardrail:
- pane vars are explanatory metadata, not child-visible authority and not durable grants.

## 22. Scroll-to-prompt, zone-select, and prompt-local editing
Steal from REF-WEZTERM-ZONES, REF-ITERM-SHELLINT, and REF-GHOSTTY-OSC133-OVERLAY.

Once semantic prompt/input/output zones exist, the shell+terminal should exploit them shamelessly:
- jump to previous/next prompt
- select one command block exactly
- copy only the current output zone
- place the cursor by click only inside the live prompt/input zone

Why this is great:
- huge transcripts stay navigable;
- the interaction model stops pretending old output is editable current input.

Guardrail:
- zone navigation and selection must never silently turn transcript text into live handles or rerun commands on click.

## 23. Semantic history, but with truth labels on every row
Steal from REF-ITERM-SHELLINT, REF-ITERM-SEMHIST, REF-WARP-BLOCKS, and REF-PLAN9-PLUMB.

The shell should have glorious searchable history, but each row should declare what it actually is:
- plain text command
- typed route sheet
- receipt
- durable ref
- stale ref
- heuristic file-like guess

Why this is great:
- users get fast reuse without confusing “I once saw this path-like string” with “I still have authority”.

Guardrail:
- heuristic rows should be visibly heuristic, and replay from history should pass through the same route-plan / rebind / reconsent discipline as anything else.


## 24. Trusted review lanes + collapsible command sections + steering rails
Steal from REF-VSCODE-WORKSPACE-TRUST, REF-VSCODE-109-BGAGENTS, REF-VSCODE-110-TERMSECTIONS, REF-NUSHELL, and REF-PLAN9-PLUMB.

The ViewFS terminal should get more powerful in exactly the places where ordinary terminals get muddy:
- commands with side effects or widened authority should land in a separate trusted review lane instead of ordinary scrollback;
- long-running requests should expose `queue`, `steer`, `stop`, and `fork fresh` controls as structured chrome attached to the active lane;
- each command block should collapse to a compact header that preserves the exact command, scope, authority delta, basis/witness, and result badge;
- structured outputs should be explorable as rows/fields/receipts rather than forcing users to scrape plain text when the shell already knows the object shape.

Why this is great:
- the transcript stays readable even when commands get verbose or multi-step;
- steering a running action becomes an honest control surface instead of a folklore interrupt ritual;
- restricted workspaces and trusted review steps remain productive because the terminal explains why a lane is gated;
- typed route sheets, receipts, and object rows become first-class terminal citizens instead of side-panel exiles.

Guardrail:
- review lanes, collapsible sections, and structured drawers are explanation and approval surfaces; they must not auto-approve, auto-rerun, or silently coerce transcript text into live commands.

## 25. Handle lockers and resumable lanes instead of magical saved terminals
Steal from REF-FUCHSIA-IDLE-STOP, REF-SYSTEMD-FDSTORE, REF-XDG-REQUEST, and REF-XDG-FILETRANSFER.

The terminal should have a compact surface for lanes that can actually resume later:
- a locker card that says whether the thing is a live handle set, a resumable request, a restart-only lane, a durable reopen ref, or history only;
- explicit expiry / discard / preserve controls;
- clear scope labels like `this pane`, `this restart`, `this session`, or `durable reopen required`;
- a stale state that stays useful for explanation without pretending the lane is still live.

Why this is great:
- continuity becomes honest and inspectable instead of a spooky “saved terminal” myth;
- users can tell whether a restart is likely to work before they bet on it;
- shell chrome can surface useful resumable work without confusing it with receipts or durable grants.

Guardrail:
- a locker card must never imply that side effects, outputs, or authority were fully restored unless a stronger seam explicitly says so.

## 26. Action menus from exact affordances, not path folklore
Steal from REF-ANDROID-SAF, REF-ANDROID-DOCPROVIDER, REF-XDG-DOCUMENTS, and REF-PLAN9-PLUMB.

When the user selects or inspects an object, the shell should derive the action menu from exact object truth:
- what rights are on the current handle;
- what operations the provider/document surface says are supported;
- what transfer / reveal / reopen lanes are actually available;
- what is only a shell guess or a text heuristic.

Why this is great:
- menus become trustworthy because unsupported verbs disappear early or explain themselves;
- the same object can appear in several places without each path teaching a different lie;
- route sheets can show why `open`, `edit`, `share`, `reveal`, or `export` are present or absent.

Guardrail:
- a filename, extension, or old transcript row must not outrank explicit object/handle affordance truth when the shell decides which verbs to show.


## 27. Sealed staging capsules and commit-last rails
Steal from REF-MEMFD-CREATE, REF-MEMFD-SEALS, REF-UNIX-SCMRIGHTS, and REF-PLAN9-PLUMB.

The terminal should have a first-class way to hold exact bytes before they become durable objects:
- a **draft capsule** while bytes are still being assembled or returned from an external editor;
- a **sealed capsule** once reviewable bytes are frozen for comparison or transfer;
- an explicit **courier** act when that exact capsule is handed to another local process;
- a later **commit** act if those bytes deserve object-store identity;
- and a visible **discard** path when the capsule should simply vanish.

Why this is great:
- preview/import/export/editor-return flows can stay exact without smuggling path reopen folklore back into the design;
- the shell can show `draft`, `sealed`, `couriered`, `committed`, or `discarded` as truthful state instead of hiding everything behind temp files;
- compare-before-commit becomes natural because the staged bytes are a first-class thing.

Guardrail:
- a sealed capsule is not automatically a committed object, a durable reopen grant, or a standing capability; couriering exact bytes is still a narrower act than binding or persisting authority.



## 14. Activation-kit cards before launch
A launch should be able to open a tiny **activation-kit card** that says what is about to be handed to the child:
- view roots
- cwd/root synthetic bindings
- exact handles
- staged capsules
- continuity lockers
- ambient debt if any

Why this is great:
- startup stops looking like magic rediscovery
- the user can tell which resources are already in hand before the child runs

Guardrail:
- activation-slot names are not object identity, and they should not masquerade as durable reopen promises

## 15. Block truth ladder and action gates
A super-awesome terminal should treat visible command blocks as having a **truth grade**, not one fake universal trust bit.

Useful early ladder:
- visible text only
- marked block
- shell-reported command
- receipt-bound reviewed action object

Why this is great:
- the terminal can stay fast and humane without overclaiming what it knows
- stronger actions like replay, reopen, or route reuse can be gated on stronger truth

Guardrail:
- downgrade paths should keep nearby safe actions available instead of relabeling weaker truth as the stronger one

## 16. Selection packets and a separate primary target
Selections should become small explicit packets with kind, bounds, trust grade, context witness, and allowed action families.
At the same time, the shell should keep one separate **primary target** for strong keyboard actions and live routing.

Why this is great:
- selecting a historical object does not silently steal the role of the live target
- path-like text, receipt cards, prompt input, and reviewed command blocks can each get the right action ladder

Guardrail:
- hover or selection alone should never silently authorize rerun, reopen, or stronger binding

## 17. Badged-handle drawers
When a handle copy is minted or attenuated, the shell should be able to show a compact drawer with:
- issuer/source
- badge or witness tag
- rights delta
- activation slot or route-plan source
- exact object ref when known

Why this is great:
- users can understand where live authority came from without reading a novel
- copied-handle lineage becomes reusable shell truth instead of hidden runtime folklore

Guardrail:
- a badge or witness tag describes the copy/issuer lane, not the object's immutable identity


## 18. Peer-witness courier drawers
Steal from REF-UNIX-SCMRIGHTS, REF-SOCKET-PASSCRED, REF-SEL4-BADGES, and REF-PLAN9-PLUMB.

When a live handle, staging capsule, or routed packet is couriered locally, the shell should be able to open a compact drawer that shows:
- who sent it or what lane it came from
- what witness quality exists (`peer creds`, `issuer badge`, `route sheet`, `shell-only label`)
- what exact live things arrived
- what is still live now versus what is already history-only

Why this is great:
- exact local transfer becomes explainable without lying that the sender witness is the object's immutable identity
- the user can tell the difference between “same object, different copy lineage” and “new object I have never seen before”
- route sheets and review lanes become much more trustworthy because source context stays attached to the courier act

Guardrail:
- a courier witness is not a universal trust bit; it describes the courier lane or peer, not carte-blanche authority over whatever arrived.

## 19. Promote reviewed command blocks into explicit command packets
Steal from REF-VSCODE-106-ATTCMD, REF-VSCODE-SHELLINT, REF-NUSHELL, and the sibling Schell terminal notes.

A future custom shell should let the user promote a strongly-known command block into a **command packet** that can be routed, attached, or reviewed elsewhere.
Good early fields:
- command line / argv-ish text
- exit code or result state
- captured output slice or exact output reference
- cwd / target context when known
- truth grade and nearby witnesses / receipts

Why this is great:
- helper escalation stops depending on copy/paste from raw transcript text
- the terminal can share exactly what happened without pretending the whole session must be exported
- route sheets, review lanes, and later shell tools get a truthful structured object instead of a fragile text blob

Guardrail:
- packet promotion should be explicit, and a command packet is not automatically a rerun approval, durable receipt, or standing authority grant.


## 20. Live process cards with explicit right badges

A future custom shell should let a reviewed command block open a compact **live process card** while the command is still running.

That card should show:
- exact running-versus-history state,
- the current command packet / launch basis,
- whether the shell only has `wait`, `interrupt`, `terminate`, or stronger `inspect/debug` rights,
- and what witness/receipt will remain after exit.

Why this is great:
- the shell stops pretending that a PID in text is the command object;
- users get truthful control affordances without hidden debugger power;
- exit transitions become clean: `running now` can degrade to `history only` without losing context.

Guardrail:
- a live process card must not silently imply namespace entry, fd duplication, or debugger attach just because the shell can still stop or wait on the process.


## 14. Paste should become a visible input-origin lane, not a hidden command trigger
Steal from REF-XTERM-BRACKETED-PASTE.

When the shell is at a live prompt, pasted bytes should arrive as a distinct input-origin class.
The shell can then offer:
- plain paste into the prompt,
- quoted paste,
- paste into a scratch capsule,
- inspect-before-run for multi-line command paste,
- or route selected pasted paths/URIs through a typed route sheet instead of raw execution.

Why this is great:
- pasted text stops pretending to be the same thing as deliberate keystrokes
- multi-line clipboard accidents get a truthful safety rail
- imported snippets can become inspectable objects instead of disappearing into transcript folklore

Guardrail:
- paste origin should not silently authorize execution; the shell must keep `pasted`, `edited after paste`, and `explicitly launched` as different truths.

## 15. High-fidelity key packets can make terminal UX both richer and more honest
Steal from REF-KITTY-KEYBOARD.

When the terminal and shell both support it, key input should be able to arrive as disambiguated key packets instead of lossy legacy byte collisions.
That unlocks:
- shortcut layers that do not collide with transcript text,
- real press/repeat/release handling for TUIs and inspectors,
- prompt-local navigation and selection gestures that stay separate from transcript actions,
- and pane-level command/input widgets that do not rely on guessy escape-sequence folklore.

Why this is great:
- terminal interaction becomes less ambiguous and more inspectable
- richer shell chrome no longer has to steal ordinary text bytes to mean control actions
- custom ViewFS tools can have powerful keyboard UX without pretending every feature is just “characters in the PTY”

Guardrail:
- key packets are transport truth, not authority; richer shortcuts must still honor the same action gates, review lanes, and receipt-writing rules as mouse or palette actions.

## 21. Launch basis cards should expose exact exec meaning before run
Steal from REF-MAN7-FEXECVE, REF-MAN7-EXECVEAT, REF-SYSTEMD-CREDENTIALS, REF-VSCODE-SHELLINT, and the SlopOS Capshell notes.

Before a command executes, one action should open a compact **launch basis card** showing:
- exact exec object identity when known,
- whether launch is by held handle, exact staged bytes, or still carrying path-shaped debt,
- explicit interpreter/script-entry arrangement,
- argv/env/cwd deltas from the current pane baseline,
- and whether startup credential slots are present.

Why this is great:
- users can tell whether they are launching one reviewed object or just hoping a mutable name still points somewhere sensible;
- launch review becomes much more honest without forcing a heavy debugger or package-manager UI;
- restricted/review-first shells stay productive because the user can see what is missing before commit.

Guardrail:
- a launch basis card must not dump secret contents into transcript flow, and a path-shaped fallback should stay loud debt rather than quietly pretending to be exact launch identity.

## 22. Startup credential drawers should be explicit and content-minimizing
Steal from REF-SYSTEMD-CREDENTIALS and the SlopOS app-secret boundary notes.

When a child receives startup credentials, the shell should be able to show a compact drawer with:
- slot/name labels,
- origin lane or issuer,
- whether the credential is activation-only and immutable during the run,
- whether the child saw it as a private file, handle, or another narrow carrier,
- and what receipt or audit row remains after launch.

Why this is great:
- secrets stop leaking into environment folklore and transcript cargo-culting;
- users can review launch posture without ever seeing the secret material itself;
- launch replay and diff UX get much better because `credential slot present` is visible truth.

Guardrail:
- the drawer should reveal presence, origin, and lane quality, not the secret bytes themselves, and it must not imply durable reopen or standing share authority.


## 23. Closure-certainty badges should expose loader risk before run
Steal from REF-LINUX-LDSO, REF-LINUX-DLOPEN, REF-WIN-DLL-SEARCH, REF-WIN-LOADLIBRARY, and the SlopOS Capshell code-closure notes.

Before or just after a launch review, one action should open a compact **closure certainty** drawer showing:
- whether startup code closure is exact, partially known, or still carrying ambient loader debt,
- whether runtime resolution can still consult mutable search roots such as current-directory, PATH-like, or loader-specific search paths,
- whether later plugin/module imports are disabled, review-gated, or unconstrained,
- and what receipt remains if the process later asks for more code.

Why this is great:
- users can finally see the difference between `I launched one exact object` and `I launched one object that can still go shopping for code`;
- loader/search-order risk becomes visible without making the shell pretend to be a package manager or debugger;
- plugin/import review becomes a first-class shell action instead of a mystery hidden behind one green run button.

Guardrail:
- closure-certainty chrome should advertise truth and debt, not promise a final closure model; exact startup closure, compat debt, and later import approvals must remain visibly different classes.


## 23. Clipboard offer cards and paste ladders
Steal from REF-WAYLAND-PRIMARY-SELECTION, REF-X11-ICCCM-SELECTIONS, REF-KITTY-CLIPBOARD, and the existing transfer-lane notes.

A future custom shell should be able to surface a compact **clipboard/selection offer card** that shows:
- current owner/source witness when known,
- offered MIME types / representations,
- the one representation actually accepted,
- whether the result became prompt input, scratch-capsule bytes, or a local imported object,
- and whether some privileged clipboard-history manager retained it.

Why this is great:
- paste stops being a magical side door back to ambient paths or hidden durable grants;
- the user can choose `paste`, `quote`, `inspect`, `import`, `bind here`, or `receipt only` from one truthful ladder;
- rich terminal UX becomes safer because clipboard history and current selection ownership stay visibly different truths.

Guardrail:
- selection ownership or clipboard-manager retention must not masquerade as durable reopen authority or as proof that a local object was imported.

Extra steal: add **history ghosts** and **paste capsules** so the shell can say `offer now`, `history ghost`, `prompt bytes only`, `materialized here`, or `receipt only` as distinct states.


## 24. Foreground baton cards and TTY lease badges
Steal from REF-LINUX-CREDENTIALS-JC, REF-LINUX-SETPGID, REF-GLIBC-LOGINTTY, REF-LINUX-TTY4, REF-VSCODE-SHELLINT, and REF-GHOSTTY-OSC133-OVERLAY.

A future custom shell should be able to surface a compact **foreground baton** card showing:
- the exact running command/process card the pane is currently tied to,
- whether the pane is only mirroring output or also has live stdin,
- whether a PTY/controlling-terminal relationship exists,
- whether terminal-generated signals currently target this foreground job,
- and whether the current state is `foreground`, `backgrounded`, `detached`, or `history only`.

Why this is great:
- Ctrl-C, Ctrl-Z, and prompt-local editing stop feeling magical because the user can see who actually owns the turn;
- observe-only panes can stay useful without pretending they are interactive terminals;
- attach/detach flows become much easier to trust because `stream visible`, `stdin live`, `controlling tty`, and `foreground now` are visibly different truths.

Guardrail:
- a foreground baton card should advertise current interactive posture, not promise broad debugger power, namespace-follow power, or durable reopen.


## 25. Runner badges and bootstrap shutters should explain how launch will actually start
Steal from REF-FUCHSIA-RUNNER, REF-OCI-RUNTIME-CONFIG, REF-OCI-PROCESS-CONFIGGO, and the SlopOS Capshell startup-profile notes.

Before a command executes, one action should open a compact **runner / bootstrap** card showing:
- the selected runner/runtime family when known,
- whether that runner selection is explicit, environment-provided, or still carrying compat debt,
- whether startup is `clean`, `explicit customization bundle`, or `startup-hook / profile debt blocked`,
- whether the resulting session is expected to be `interactive`, `batch`, `detached helper`, or `receipt only`,
- and what lifecycle controller or follow/stop lane will exist after start.

Why this is great:
- users can tell the difference between “I am launching this exact thing” and “some runtime will decide how to host this later”;
- clean-start shells stay honest about startup hooks and profile debt without forcing an all-or-nothing policy UI;
- replay and route-plan diffs get much more useful because runner change and bootstrap change stop masquerading as object change.

Guardrail:
- runner badges and bootstrap shutters should advertise hosting truth and debt, not promise reproducibility or broader authority than the actual launch/session lanes provide.

## 26. Mutable prompt docks should stay separate from scrollback history
Steal from REF-ITERM-CMDSELECT, REF-ITERM-CLEARBUFFER, REF-ITERM-SHELLINT, and the sibling Schell terminal notes.

A future custom shell should treat the **live mutable prompt area** as a first-class object distinct from command blocks and scrollback history, with features like:
- `clear scrollback, keep prompt dock`,
- `zoom or share this command block without touching the live draft`,
- prompt-local notes/scratch text that do not rewrite history,
- and explicit promotion from draft prompt input into a reviewed command packet.

Why this is great:
- the user can clear, filter, or share history without losing unsent work;
- command selection becomes more powerful because selected history and live draft input are visibly different classes;
- review-first shells can keep a trustworthy `draft -> reviewed -> launched -> history` ladder instead of flattening everything into one terminal buffer.

Guardrail:
- the mutable prompt dock is local unsent state, not a durable recipe, not a running session, and not a history row; promotion across those seams should stay explicit and receipted.

## 27. Twin-handle badges and duplicate-versus-reopen ladders
Steal from REF-MAN7-OPEN, REF-MAN7-DUP, REF-UNIX-SCMRIGHTS, REF-LINUX-PIDFD-GETFD, REF-LINUX-FLOCK, and the SlopOS Capshell handle-table notes.

A future custom shell should be able to surface a compact **handle topology** drawer showing:
- the current slot/local binding in this pane or child,
- whether this handle is a live alias to another current handle,
- whether the alias shares cursor/status/lock/lease state,
- whether a `reopen independently` action is available,
- and what receipt/history row remains after a duplicate, lend, or reopen decision.

Why this is great:
- users can finally tell `same object` from `same live cursor` and stop being surprised by cross-pane reads/writes that move together;
- import/transfer UX gets more honest because `lend current live handle` and `mint fresh reopen` stop masquerading as one generic share action;
- review-first shells can offer safe narrower actions such as `reopen independently` instead of pushing users toward accidental live aliasing.

Guardrail:
- a twin-handle badge must advertise current aliasing truth, not promise durability, universal portability, or debugger-grade powers just because two handles currently share one open state.

## 28. Handle-class badges and open-for-more-power ladders
Steal from REF-LINUX-OPATH, REF-LINUX-STATX, REF-LINUX-OPENTREE, and the SlopOS cwd-root / handle-table posture notes.

A future custom shell should be able to surface a compact **handle class** card showing:
- whether the current thing is only a locator/root handle,
- whether it supports metadata-only inspection,
- whether it is readable or writable *right now*,
- whether `open for read` / `reopen for write` / `exec now` would mint a different operational handle,
- and what durable ref or receipt remains after the live handle goes away.

Why this is great:
- portal-mediated imports become much more honest because `selected` or `bound here` no longer quietly means `bytes already readable`;
- per-pane namespace badges can stay useful without pretending every root/object handle is already a data stream;
- review-first shells can offer inspect-first flows and only later escalate to byte I/O when the user actually wants it.

Guardrail:
- a handle-class badge must advertise current operational truth, not promise durability, universal portability, or that every backend exposes exactly the same classes.

## 29. Inheritance shutters, child-slot maps, and authority-leak sirens
Steal from REF-MAN7-OPEN, REF-MAN7-EXEC3P, REF-MAN7-POSIX-SPAWN, REF-MAN7-CLOSE-RANGE, REF-MAN7-FCNTL, REF-OPENBSD-FCNTL, and the SlopOS activation / handle-table posture notes.

A future custom shell should be able to surface a compact **launch-boundary** card showing:
- which live handles are currently held in this pane,
- which of them are shuttered from launch by default,
- which ones are explicitly selected to cross the boundary,
- the exact child-local slot/name each reviewed copy will land in,
- and what launch receipt/history row remains after the child exits.

Why this is great:
- users can finally tell `held here` from `child will receive this`, which is one of the oldest and easiest authority-leak mistakes in process-launch history;
- launch review becomes much more honest because `run this` stops quietly meaning `and also inherit whatever else happened to be open`;
- review-first shells can offer narrow fixes such as `shutter all extras`, `pass only stdio`, or `name this child slot explicitly` instead of making inheritance hygiene guesswork.

Guardrail:
- a launch-boundary card must advertise current inheritance truth, not promise durability, restart continuity, or universal cross-runtime portability just because one reviewed child launch received a copy.

## 30. Two-anchor rename cards, collision-mode ladders, and name-diff receipts
Steal from REF-FUCHSIA-FSARCH, REF-FREEBSD-RIGHTS-LIVE, REF-MAN7-RENAME, and the SlopOS cwd-root / document-portal notes.

A future custom shell should be able to surface a compact **namespace mutation** card showing:
- the object identity being discussed,
- the source parent anchor that currently owns the old name,
- the destination parent anchor that would receive the new name,
- the mutation mode (`rename`, `link`, `unlink`, `replace`, `exchange`),
- the collision posture (`create new only`, `replace if exists`, `exchange names`),
- and what receipt/history row remains after the namespace edit.

Why this is great:
- users can finally tell `same object, new name` from `new object imported` or `new byte handle opened`;
- cross-parent moves stop being magic because the shell can show both anchors explicitly instead of hiding them behind one path string;
- review-first shells can offer narrower actions such as `create new only` or `exchange names` instead of one dangerous overwrite-by-default move button.

Guardrail:
- a namespace-mutation card must advertise current naming/anchor truth, not promise byte-I/O authority, durable reopen, or that every backend supports every collision mode natively.


## 31. Propagation badges, blast-radius previews, and attach-private-first rails
Steal from REF-MAN7-MOUNTNS, REF-LINUX-OPEN-TREE, REF-LINUX-MOUNT-SETATTR, and the SlopOS view / replication posture notes.

A future custom shell should be able to surface a compact **bind propagation** card showing:
- that something is attached *here* right now,
- whether later namespace changes stay local, propagate to peers, or only arrive from an upstream/master lane,
- whether the bind is intentionally not cloneable / unbindable,
- any current peer/upstream relationship the shell knows about,
- and what receipt/history row remains after the attach or rebind act.

Why this is great:
- users can finally tell `bound here` from `bound here and may affect other views`, which is exactly the kind of hidden blast radius that capability-honest namespace UX should make explicit;
- attach/rebind review becomes much more honest because `attach this fragment` stops quietly meaning `and inherit whatever propagation posture happened to exist`;
- review-first shells can offer narrower actions such as `attach privately first` or `receive-only mirror` instead of one generic bind button.

Guardrail:
- a bind-propagation card must advertise current blast-radius truth, not promise durable replication, universal peer IDs, or one portable shared-subtree mechanism across all ViewFS backends.


## 32. Draft-object cards, publish-later ladders, and publication receipts
Steal from REF-LINUX-OTMPFILE, REF-MAN7-LINKAT, and the SlopOS CapStore / view-namespace posture notes.

A future custom shell should be able to surface a compact **publication** card showing:
- that an object already exists even though it has no public name yet,
- the candidate parent anchor or view where it could be published,
- the collision posture (`new only`, `replace`, `exchange`) where supported,
- whether publication would also create a live bind in the current pane or only a durable receipt,
- and what receipt/history row remains after the publication act.

Why this is great:
- users can finally tell `I received or built exact bytes` from `those bytes now have a visible name here`, which is a huge honesty win for imports, saves, exports, and editor-return flows;
- review-first shells can offer `publish later`, `publish privately first`, or `discard draft` instead of forcing every staging flow through temp-name folklore;
- namespace mutation UX gets safer because parent anchors and collision posture become explicit before anything becomes visible.

Guardrail:
- a publication card must advertise current naming/publication truth, not promise durable reopen, universal backend support for every collision mode, or that history rows are bearer authority.


## 33. Descriptor cards, hydrate-later ladders, and object chips that outlive authority
Steal from REF-OCI-DESCRIPTOR, REF-IPFS-CIDS, REF-VSCODE-SHELLINT, and the SlopOS artifact-reference posture notes.

A future custom shell should be able to surface a compact **descriptor card** showing:
- one digest/object ID,
- media type and byte size when known,
- any locator hint or source hint marked as non-authoritative,
- whether the current truth is `descriptor only`, `local bytes present`, `live handle now`, `published here`, or `receipt only`,
- and what receipt/history row remains after hydrate/bind/publish acts.

Why this is great:
- users can finally tell `I know what object this is` from `I can stream bytes right now`, which is exactly the distinction a capability-native object store needs;
- transcript/history can keep useful object chips even after authority expires because the shell is honest about descriptor-versus-handle truth;
- review-first shells can offer narrow follow-on acts such as `hydrate`, `bind here`, `publish here`, or `request portal import` instead of overloading one generic open button.

Guardrail:
- a descriptor card must advertise descriptor truth, not promise current byte-I/O authority, stable naming, durable reopen, or universal backend support for every follow-on act.


### 34. Localize-first import cards and docref ladders
When the user drags, pastes, chooses, routes, or receives one outside object, the shell should not instantly pretend that one durable local file already exists.
Instead it should surface one compact card that can honestly move through states like:
- `source ref only`
- `inspect source`
- `materializing`
- `fresh local object`
- `mint local docref`
- `bind/publish here`
- `receipt only`

Why this is super awesome:
- it makes portal/import boundaries visible instead of magical;
- it gives ViewFS one truthful place to show when local identity exists even before publication;
- it prevents the UI from laundering remote/source-side designation into local durable reopen.

### 35. Remembered, live, and provisional truth labels
The shell should treat truth labels as first-class chrome:
- `live now`
- `remembered`
- `provisional`
- `stale`
- `grant needed`
- `history only`

Why this is super awesome:
- it lets transcript rows and object chips stay useful after authority expires;
- it lets semantic shell integration be ambitious without pretending every parsed signal is equally authoritative;
- it gives operators the kind of confidence/debug posture that normal terminals hide.

### 36. Semantic epoch badges and resync rails
Every semantic side-channel stream should carry a visible epoch or run-local barrier marker so the terminal can say:
- `semantics synced to current shell`
- `late event from previous run`
- `provisional until barrier`
- `resync requested`

Why this is super awesome:
- it keeps command/object chrome honest when shells restart, panes reconnect, or helper plugins lag;
- it gives the custom shell a visible recovery move that is much better than silently hallucinating state;
- it lets advanced users debug shell integration without turning the whole terminal into protocol soup.


### 37. Reopen truth ladders and continuity lockers
When one object is only *remembered* rather than live, the shell should say so plainly.
A future custom shell should be able to render states like:
- `remembered designator`
- `revalidating now`
- `exact locker available`
- `revived live handle`
- `stale or moved`
- `grant needed`
- `history only`

Why this is super awesome:
- it lets restart/reopen UX feel powerful without lying about current authority;
- it gives users a clean mental model for why some objects come back instantly while others need revalidation or user help;
- it makes narrow manager-held continuity lockers useful without letting them silently grow into ambient persistent power.

### 38. Stale-target repair rails and continuity shelves
The shell should have one continuity shelf that can hold remembered-but-not-live objects and show what kind of repair is possible:
- `revalidate same target`
- `ask user again`
- `mint fresh local object`
- `discard remembered designator`
- `keep receipt only`

Why this is super awesome:
- stale or moved targets become explicit product states instead of weird broken-open failures;
- users can repair continuity without losing transcript context or pretending history rows are bearer authority;
- the same UI can cover portal docrefs, bookmark-like reopen, and exact restart lockers while keeping each lane honest.


## Transfer sheets and adoption rails

A future ViewFS shell should make cross-pane, shell-to-app, and app-to-shell exchange brutally honest.

When something is about to cross a boundary, the shell should be able to present a **transfer sheet** with visibly different choices such as:
- `offer only`
- `accept as bytes`
- `accept live copy`
- `accept attenuated live copy`
- `store revival designator`
- `adopt into this pane now`
- `receipt only`

Why this is great:
- it keeps `shared` from silently meaning `bound here with authority now`;
- it lets users pick a weaker/friendlier lane when that is enough;
- it keeps cross-pane and shell-to-app exchange aligned with a capability-native object store instead of recreating ambient clipboard/path folklore.

The terminal should also have compact **issuer/courier witness chips** such as `from pane 3`, `from route plan`, `from app handoff`, or `from reviewed import`, while keeping those chips visibly separate from object identity and separate again from current authority.

And once the receiver does something stronger, the shell should show an **adoption rail**:
`offered` → `received` → `adopted here` → `revalidate later`

That keeps the transcript honest about when something merely arrived, when it became current authority, and when only a later-designator remains.

## 12. Inert designator paste by default
Steal from REF-W3C-CAPURL, REF-OCAPN-LOCATORS, REF-XDG-DOCUMENTS, and REF-MS-SECBOOKMARK-CVE2025.

The shell should distinguish:
- plain designation text,
- typed designator chips,
- authority-bearing tickets,
- and live current handles.

Why this is great:
- users can copy references into notes, tickets, and chats without accidentally delegating authority;
- dangerous bearer-ish artifacts stop masquerading as innocent strings.

Guardrail:
- “reveal authority” should be a later explicit route-sheet action, never the default effect of paste or hover.


## 13. Caveat laminates and membrane badges
Steal from REF-MACAROONS-NDSS14, REF-ZCAP-LD, REF-SEL4-MANUAL-LATEST, REF-CAPSICUM-HANDBOOK, and the SlopOS D-LEASE posture.

The shell should distinguish:
- declared caveat cards,
- enforced membrane / lease badges,
- live local handle badges,
- revival designators for later,
- and receipt-only history rows.

Why this is great:
- users can see whether bounds are merely described or actually enforced now;
- renewal/revalidation becomes a visible ladder instead of spooky delegated magic;
- capability-heavy flows get more humane without lying about where authority lives.

Guardrail:
- every transcript card that shows caveats should also show an **enforcement locus** such as `proxy`, `verifier`, `local handle`, or `none/history`.

### 18. Permission lights versus death certificates
Steal from REF-W3C-PERMISSIONS, REF-WICG-FSACCESS, REF-XDG-DOCUMENTS, and REF-ANDROID-SAF:
- the transcript and side chrome should render **permission outlook** separately from **current live authority** and separately again from **dead-state verdicts**
- permission lights should carry explicit preflight states like `granted`, `prompt`, `denied`, `revalidate`, and `policy blocked`
- death certificates should carry explicit negative states like `revoked`, `expired`, `target changed`, `issuer offline`, `deleted`, and `history only`
- repair ladders should point at exact next verbs like `request`, `revalidate`, `rebind`, or `import fresh`
- live-handle badges should remain distinct again

This is another “super awesome” move because it turns one of the most confusing security/lifecycle truths into ordinary legible shell chrome instead of generic red errors.


### 19. Provenance ribbons, endorsement stacks, and verdict shutters
Steal from REF-RATS-RFC9334, REF-RATS-ENDORSEMENTS-DRAFT, REF-IN-TOTO-ATTESTATION, REF-SLSA-PROVENANCE, REF-TUF-ROLES, REF-SIGSTORE-REKOR, and Helm's trusted-chrome ideas:
- the transcript should render **provenance ribbons** separately from **endorsement stacks** and separately again from **local verdict shutters**
- provenance ribbons should answer `imported from`, `built by`, `derived from`, `reviewed from`, or `unknown` without implying admission
- endorsement stacks should answer `signed`, `threshold met`, `reference matched`, `transparency logged`, or `endorsement missing` without pretending those inputs outrank local policy
- verdict shutters should answer `preview only`, `safe-open only`, `admit document`, `admit runnable`, `needs review`, or `deny` as local shell-owned truth
- live-handle badges should remain distinct again

This is another “super awesome” move because it gives the future shell a way to feel brilliantly informative without turning every signature or attestation into magical current authority.

## 28. Request ledgers, session cards, and adoption shutters

A capability-honest shell should stop flattening portal interactions into one generic `opened` row.
It should keep at least four user-visible things apart:
- the **request row** (`pending`, `succeeded`, `cancelled`, `timed out`),
- the **session or transfer card** (`open`, `active`, `ending`, `closed`, `closed by portal`),
- the **local adoption shutter** (`not adopted here`, `adopted here`, `adoption stale`),
- and the **receipt/history row**.

That would make imports, durable reopen, clipboard/file-transfer, and future portal-heavy shell flows much more honest.
It also makes repair much better because the shell can say `retry request`, `rejoin session`, `retrieve again`, or `adopt locally` instead of guessing.

### Completion ghosts, detail drawers, and packet gutters
The shell should treat completion as a little state machine instead of one vague popup:
- **candidate ghost** — ranked advisory row only
- **detail drawer** — extra docs/provenance/rights hints fetched for one focused row
- **accepted insertion** — now in the mutable prompt buffer, still not a plan
- **compiled packet gutter** — parsed/bound against current pane objects and receipts
- **prepared action chip** — ready / approval needed / portal needed / rebind needed

That buys us several excellent moves:
- fish-style accept-one-word speed without accidentally invoking anything,
- LSP-style lazy detail without changing the insertion meaning underneath the user,
- MCP-style advisory completion without letting suggestions impersonate chooser defaults,
- and VS-Code-style trusted-shell packets without giving heuristic transcript scraping the same power.

A beautiful terminal trick here would be a **rerun safety badge**:
- `history text only`
- `heuristic packet`
- `shell reported`
- `nonce verified`
- `object composed`

Only the stronger grades should be eligible for no-confirmation replay.

## 35. Entity peels and route slips
A future custom shell should be able to treat highlighted transcript text, OSC 8 links, and hint-picked regions as **selection surfaces**, not as already-routed actions.

The delightful move is a tiny two-step ladder:
- first, an **entity peel** that says what the region seems to be (`plain text`, `path-ish`, `line ref`, `receipt ref`, `object ref`, `URI`, `explicit link`);
- second, a **route slip** that promotes one chosen meaning into one typed action basis such as `inspect`, `reveal`, `import here`, `open in tool`, `launch uri`, or `compose packet`.

Why this is super awesome:
- transcript navigation becomes much more capable than ordinary terminal hyperlinks;
- shell routing stays typed and reviewable;
- users can move quickly from output to the next action without letting selection itself become authority.

Guardrail:
- selected bytes, extracted meanings, routed envelopes, and prepared actions must stay visibly different truths.

## 36. Activation batons and arming rails
Steal from REF-HTML-USER-ACTIVATION, REF-XDG-ACTIVATION-V1, REF-XDG-INPUTCAPTURE, REF-MS-ALLOWSETFOREGROUND, and REF-MS-COALLOWSETFOREGROUND.

The shell should make interaction proof visible instead of spooky.
It should distinguish:
- **fresh gesture proof** (`click`, `keypress`, `shortcut`, `notification action`)
- **activation baton** (`may ask to activate`, `may request focus`, `consume once`)
- **armed lane** (`prepared`, `waiting for baton`, `enabled`)
- **active now** (`foreground now`, `capturing now`, `active control`)
- **receipt only**

Why this is super awesome:
- route plans and portal flows can stay fast without pretending every click already committed the stronger act;
- cross-pane/app handoff can say `you may ask to activate` instead of stealing focus or hiding failure;
- the terminal can finally tell the truth about why some actions are currently eligible and others need a fresh gesture.

Guardrail:
- one baton should normally be consume-once, expiring, and visibly weaker than durable authority or durable reopen.


## 37. Place cards, verb ledgers, and affordance lenses
A future custom shell should stop guessing verbs from path shape.
It should instead separate four truths for any focused object:
- **what object is this?**
- **where does it appear here?**
- **what authority do I hold right now?**
- **what operations does the provider currently advertise for this target?**

The delightful moves are:
- **place cards** that show `same object, also appears in …` without pretending those names are the identity;
- **verb ledgers** that show `provider says yes`, `current handle says no`, `policy says ask`, `view says not here`, or `history only`;
- **affordance lenses** that separate identity, placement, rights, verbs, and receipts in one compact drawer;
- **why-not drawers** that answer `rename unsupported here`, `delete supported by provider but not with this handle`, or `thumbnail available` instead of failing late.

Why this is super awesome:
- the shell gets smarter than ordinary file managers without becoming spooky;
- action menus become honest and highly contextual;
- the same object can appear in several places without the shell lying about what is identity versus placement.

Guardrail:
- advertised verbs are not the same thing as current authority, and old receipts are not current affordance truth.


## 38. Type lenses, handler racks, and open-state badges
A future custom shell should stop pretending one suffix or one old default explains everything about opening.
It should instead separate:
- **declared type**
- **derived type**
- **associated handlers**
- **chosen opener for this act**
- **live open state**
- **receipt only**

The delightful moves are:
- **type lenses** that show `declared`, `derived`, `virtual`, `disagrees`, or `unknown`;
- **handler racks** that show `associated`, `default`, `safe preview`, `chosen now`, or `unavailable here`;
- **why-this-opener drawers** that explain whether a route came from explicit user choice, current default, policy, or provider suggestion;
- **open-state badges** that show `previewing`, `editing`, `external`, `portal-owned`, `detached`, `closed`, or `history only`;
- **disagreement cards** with ladders like `inspect as declared`, `inspect as derived`, `safe preview`, `pick representation`, or `stay receipt only`.

Why this is super awesome:
- the shell becomes much smarter than ordinary `Open With…` chrome;
- preview/editor routing gets more legible without becoming spooky;
- and old defaults or old receipts stop masquerading as current openability truth.

Guardrail:
- a type label is not identity, a handler association is not chosen-opener truth, and one chosen opener is not global ambient authority.


## 41. Label ledgers and trusted badge shutters
The shell should be able to render label-like things in a way that never confuses:
- freeform annotations,
- selector-safe labels,
- policy-bearing labels,
- shell-owned trusted badges,
- and history.

What this unlocks:
- smart baskets and filters can rely on visibly query-safe labels instead of arbitrary notes;
- quarantine/review/sensitivity labels can live in stronger trusted chrome;
- copied chips can offer explicit ladders like `copy text`, `copy selector`, or `copy receipt`;
- dynamic title/right-status/badge surfaces can stay awesome without becoming spooky.



## 42. Waterline cards and gap-badge stacks
A future custom shell should treat live follow/query state as a first-class semantic lane instead of one hidden spinner.
That means visibly separating:
- `continue token`
- `caught up through`
- `following now`
- `rebuilt snapshot`
- `gap verdict`
- `history only`

The delightful moves are:
- **waterline cards** that show one visible set plus the watermark it is synced through;
- **gap-badge stacks** such as `expired cursor`, `resource version too old`, `must rescan`, or `provider reset`;
- **resync ladders** like `continue`, `wait`, `relist`, `rebuild`, `freeze rows`, or `open receipt`;
- **snapshot-versus-follow split views** so users can compare a stable set with live deltas instead of watching rows jump under the cursor.

Why this is super awesome:
- live query panes become much less spooky;
- the shell can be fast and honest at the same time;
- and provider-specific sync tokens stop masquerading as durable object truth.

## 43. Draft gutters, hold meters, and commit shutters
A future custom shell should stop pretending one local draft already explains concurrent write truth.
It should instead separate:
- **observed base / validator**
- **private writable session**
- **live write hold**
- **exact commit gate**
- **winning durable version**
- **receipt only**

The delightful moves are:
- **stale-base lamps** that say `based on X`, `target moved to Y`, or `history only`;
- **draft gutters** that say `private draft`, `sealed`, `diverged`, `orphaned`, or `receipt only`;
- **hold meters** that say `exclusive`, `advisory`, `renewable`, `expired`, or `none`;
- **commit shutters** that make `if-match`, `if-absent`, `under hold`, `rebase`, and `fork instead` visibly different acts;
- **winner receipts** that show which durable version actually won after a commit attempt.

Why this is super awesome:
- editing gets safer without turning into giant modal lock UI;
- multi-tab and external-tool round-trips become more honest;
- and local close/flush folklore stops masquerading as durable truth.

## 44. Hole maps, range panels, and whole-proof ladders
A future custom shell should stop pretending every object is simply `downloaded` or `not downloaded`.
It should instead separate:
- **current local coverage**
- **known layout**
- **whole-object completeness**
- **whole-object proof**
- **live remote fill**
- **history only**

The delightful moves are:
- **hole maps** that say `prefix`, `holes`, `all chunks`, `full local`, or `unknown`;
- **range panels** that keep `coverage`, `layout`, `proof`, `remote fill`, and `history` visibly separate;
- **whole-proof ladders** that make `fetch missing`, `verify whole`, `seal local`, `stay sparse`, and `open receipt` different acts;
- **offline honesty lamps** that say `fully local`, `partial local`, `remote-fill only`, `proof missing`, or `history only`;
- **composite-checksum warnings** that explain when a current identifier is multipart/composite rather than one whole-object witness.

Why this is super awesome:
- huge objects and lazy imports become understandable instead of spooky;
- the shell can stay fast without lying about what is local;
- and partial residency stops masquerading as durable offline truth.


## 46. Delta cards, basis lamps, and rebuilt-from lineage

When the shell knows an import, repair, or refresh can be satisfied by a delta recipe rather than a full fetch, it should not hide that behind one vague `update` button.
It should be able to show:
- a **basis card** saying `needs base X`, `base local`, `base mismatched`, or `history only`;
- a **delta peel** showing the recipe, exact basis requirement, current apply posture, fallback full-fetch lane, and result lineage;
- an **apply ladder** with actions like `apply in scratch`, `verify result`, `materialize fresh object`, `fetch full target`, or `discard recipe`;
- and a **rebuilt-from badge** saying `rebuilt from X + R` without pretending that means same live handle or same namespace bind.

That is the kind of move that makes the custom shell feel far more truthful and powerful than ordinary `download/update/open` UX.

## Activation sheets, handoff sheets, and copy-lineage drawers
- **Activation-sheet cards** before launch so a pane can show slot, rights, witness, object-ref truth, and reopen-lane truth in one compact review surface.
- **Child-slot maps** after launch so `held here`, `crosses boundary`, `attenuated on entry`, and `history only` stay visibly different.
- **Handoff sheets** for pane-to-pane, tool-to-tool, or app-to-app transfer so `offered`, `accepted`, `adopted here`, and `receipt only` do not collapse into one vague open event.
- **Copy-lineage drawers** that show duplicate vs attenuated copy, issuer badge/peer witness, same-object-ref known/unknown, and current reopen posture.
- **Issuer/courier chips** that are small enough for pane chrome but honest enough not to masquerade as object identity or trust verdict.



## 47. Published-name ledgers and synthetic-view badges
A future custom shell should stop pretending one visible path label already explains object locality and authority.
It should instead separate:
- **in store**
- **projected through a portal/provider view**
- **live handle here now**
- **published here in this process view**
- **receipt only**

The delightful moves are:
- **published-name ledgers** that show every current publication site for one object instead of only the last visible path;
- **synthetic-view badges** like `portal view`, `provider projection`, `published here`, `launch-only`, `stored only`, or `history only`;
- **publish-here ladders** so chooser/import results land in staging before they become current local binds;
- **same-object multi-view diffs** so panes can compare object ref, projection site, current publication, and current handle truth honestly;
- **where-is-it-really drawers** that separate object ref, store presence, live-handle state, publication sites, and durable receipts.

Why this is super awesome:
- portal/import flows stop feeling spooky;
- explicit per-process namespace assembly becomes visible instead of theoretical;
- and pretty path labels stop masquerading as durable object identity or universal reopen truth.

## Ambient-debt sirens and safe-open ladders

One shell move worth stealing now is a **safe-open ladder** that makes the actual access lane visible instead of pretending every successful open was the same act.
For any path-like click, reveal, import, or command-driven open, the shell should clearly step through:
- `use live handle`,
- `walk under held root`,
- `ask portal / mediator`,
- `ambient escape hatch`.

The winning rung should show up in command chrome, receipts, searchable transcript metadata, and explain drawers.
That is the product move that keeps compatibility useful without letting it quietly become the semantic center of ViewFS.

A matching **ambient-debt siren** should light up whenever a command used a host-global escape.
The important part is not shaming the user.
The important part is giving them an exact `replace this debt` route into a cleaner bind, handle, publication, or portal grant next time.


## Browse gates, dark directories, and known-name chips
A capability-honest shell should stop pretending that `shown in a pane` and `openable now` are the same thing.

Steal-worthy moves:
- **dark directories** that allow exact-name opens without automatic listing;
- **browse gates** that visibly escalate from `exact names only` to `list contents`;
- **known-name chips** that attach to command blocks when something opened by exact child name under a held root;
- **fit sheets** that rank candidates as `preferred`, `acceptable`, `advanced`, or `history only`;
- **search-result dimmers** so helper/index/history hits stay visually weaker than direct live authority.

## Presence halos, readiness lamps, and withdrawn ghosts
A future custom shell should be able to say not just `this exists`, but:
- `advertised`,
- `ready now`,
- `grant needed`,
- `withheld`,
- `withdrawn`,
- `history only`.

The delightful moves are:
- **presence halos** around palette/provider rows so soft presence is visible without masquerading as authority;
- **readiness lamps** that decay from `ready now` to `last known` instead of staying eternally green;
- **withdrawn ghosts** so a vanished affordance leaves a dim honest trace;
- **grant-needed ladders** that offer `ask portal`, `rebind here`, `reacquire`, or `show receipt` as distinct next steps;
- **advert ledgers** that explain who advertised something, when, and under what freshness caveat.

Why this is super awesome:
- helper/provider catalogs become much more useful without lying;
- SlopOS-style mediated imports can stay ambitious without prematurely freezing backend state machines;
- and the shell gets a genuinely new kind of honesty that ordinary path UIs almost never provide.


## More shell ideas from the provider-ready/local-realized seam
- object rows should be able to render `provider-ready`, `repair owed`, `realizing`, `local now`, `held now`, and `history only` as different truths;
- a tiny **provider-owned badge** should explain when current usefulness still depends on someone else backing the thing;
- the shell should keep a **make-local ladder** distinct from `bind here` or `hand to child`;
- remembered rows should support **offline fog** when they are only promisor/substituter backed;
- transcript filters should support `show me made-local`, `show me provider-ready`, and `show me repair-required`.


## Step-up ladders, recency shutters, and why-not-now drawers
A future custom shell should stop pretending that `held now` or `local now` already means `invokable now`.

Steal-worthy moves:
- **why-not-now drawers** that distinguish `missing authority`, `too old for this action`, `step-up needed`, `presence needed`, and `history only`;
- **step-up ladders** that show the repair path from `held` to `invokable` without laundering the gap away;
- **recency shutters** that decay honestly from `fresh enough` to `too old for this action`;
- **presence pins** for touch/verify/device-auth-now posture;
- **satisfaction ghosts** that remember one satisfied or failed challenge without reviving it as timeless authority.

Why this is super awesome:
- imports, opens, decrypts, exports, and cross-tool actions become dramatically easier to explain;
- the shell gets a genuinely new kind of honesty that ordinary path UIs almost never have;
- and SlopOS can keep evolving its auth mediation without forcing ViewFS to lie in the meantime.


## Watch-status honesty
- watch braids that keep `held`, `latest status`, `local stance`, `hold`, and `successor refresh` visibly different
- hold rails that make reversible suspension and quarantine first-class, reviewable shell outcomes
- successor lanterns that show `replacement available` versus `replacement adopted` instead of silently flipping state
- stale-watch fog that decays truth honestly without pretending the base handle vanished


## Lend ladders, lane-fit badges, and bytes-only fallbacks
- a **lend ladder** should let the user choose among `duplicate locally`, `lend live`, `lend narrowed`, `projected doc`, `bytes only`, or `receipt only` instead of one vague `share` action;
- **lane-fit badges** should say whether the strongest working route is `socket lend`, `portal export`, `tty transfer`, `bytes snapshot`, or `none`;
- **bytes-only fallback chips** should make weaker but honest export routes feel successful instead of second-class failures;
- **same-object versus new-representation drawers** should explain whether the receiver gets another live reference or one new exported artifact;
- **share receipts** should preserve exact lane truth so transcript history says what actually crossed the boundary.

## Borrow rails, projection badges, and make-here ladders
- **borrow rails** that let a row say `foreign-backed`, `wrapped here`, `projected here`, `make local`, or `history only` instead of one vague `open/import` verb;
- **projection badges** that distinguish `portal view`, `provider projection`, `compat attach`, `materialized replica`, and `local object`;
- **provider-owned halos** plus **dataless/materialized lamps** so smooth UX does not launder foreign-backed state into local-ownership folklore;
- **make-here ladders** that preserve whether the user chose to keep borrowing, project into a pane, or localize explicitly.



## Route slips + sink trays
- A click or command result should be promotable into a **route slip** rather than an immediate side effect.
- Route slips should show **authority sidecars** explicitly instead of burying them in helper magic.
- Every receiving pane should expose a **sink tray** that says what actually crossed the boundary.

## Bracket rails, caller badges, and deputy fog
- **bracket rails** should show when one helper/plugin/notebook block is inside one explicit borrowed-authority region instead of one vague magic-helper mode;
- **caller badges** and **call-frame chips** should answer `who asked?` without laundering that provenance into authority;
- **borrowed-authority drawers** should keep exact borrowed handles/capability classes separate from helper identity and from caller context;
- **deny-only shutters** should explain provenance vetoes in helper/plugin language instead of one fake `permission denied` blob;
- **deputy fog warnings** should appear when one helper falls back from explicit bracketed authority into ambient singleton / ambient async-local state.

## Attach-mode badges, adapter veils, and virtuality lamps
- **attach-mode badges** should let a row say `native`, `adapter`, `relay`, `coerced`, `localized`, or `history only` instead of one vague `open/import/use` verb;
- **adapter veils** should make fd-wrappers, runtime shims, relay services, and projected filesystem glue inspectable instead of invisible;
- **virtuality lamps** should tell the truth when the strongest working lane is one alternate representation or preview surface rather than same-object attach;
- **same-object versus translated drawers** should explain what kind of edit/send/import fidelity the current lane really offers;
- **make-local-for-native ladders** should preserve the exact transition from translated or adapted use into stronger local/native semantics.



## 26. Clean-start lamps and hook quarantine should make startup truth gorgeous instead of ambient
Steal from the SlopOS Capshell startup-profile notes, REF-DIRENV-ALLOW, REF-DIRENV-REQUIREALLOWED, REF-VSCODE-WORKSPACE-TRUST, REF-GHOSTTY-SHELL-INTEGRATION, and REF-POWERSHELL-PROFILES.

A future custom shell should be able to surface a compact **startup truth** card showing:
- whether the pane is `built-in only`, `reviewed bundle`, `host profile active`, `project hook pending`, `project hook denied`, or `history only`;
- which explicit customization bundles are active;
- whether one host/user startup file ran and where it came from;
- whether one project-local activation hook is pending, stale, or quarantined;
- and whether the user can `allow once`, `allow for workspace`, `deny`, or `promote useful bits`.

Why this is great:
- prompt weirdness, alias drift, and environment surprises become explainable instead of mystical;
- browsing a project can stay useful without quietly becoming execution;
- good ambient customizations can graduate into reviewed bundles instead of locking the product into dotfile folklore.

Guardrail:
- startup truth cards should advertise where behavior came from, not silently widen trust or current authority.


## 97. Verb provenance cards, overlay racks, and which ladders
Steal from REF-FISH-ABBR, REF-NU-OVERLAYS, REF-NU-CUSTOMCOMMANDS, REF-NU-WHICH, REF-ZSH-ZLE, REF-GHOSTTY-KEYTABLES, and REF-GHOSTTY-CMDPALETTE.

The shell should make command-surface truth explicit:
- whether the current winner is one built-in verb, one lexical expansion result, one overlay/custom command, one key action, or one external launch;
- which overlay layers are active and what they shadow;
- whether the current pane is in one modal key table;
- and whether one command-palette action is also available as a typed verb or only as a widget/action.

That would let the shell feel dramatically better than classic terminals without regressing into alias/widget folklore.


## Parse lenses and diagnostic rails

Steal from REF-TREESITTER, REF-LSP-DIAGNOSTICS-317, REF-SHELLCHECK, and REF-FISH-SYNTAX.

A future custom shell should make the difference among **editable buffer**, **parsed structure**, **diagnostic rail**, **compiled packet**, and **prepared action** feel obvious.

Great moves:
- **parse lenses** near the cursor that explain current segment structure without pretending the line is ready;
- **recovery fog** over guessed or incomplete regions;
- **diagnostic rails** with source badges like `parser`, `lint`, `policy advice`, and `history`;
- **packet gutters** that only appear after current pane-local binding/compile has happened;
- **compile-diff cards** when the same visible buffer binds differently because pane-local handles or receipts changed.

This is a very low-regret place to be ambitious, because it freezes UI honesty rather than one parser stack.

## Namespace switchboards, overlay racks, and anchor death cards
Steal from REF-PLAN9, REF-FUCHSIA-DICTCAP, REF-XDG-REQUEST, REF-XDG-DOCUMENTS, REF-NU-OVERLAYS, REF-WICG-FSACCESS, and sibling pressure from Helm local overlays plus Schell anchor-death cards.

A future custom shell should make room switching/import repair feel glamorous **without** flattening everything into one fake `tab state` blob.

Great moves:
- **namespace switchboards** that keep `planned target`, `live now`, `portal session`, `local overlay`, and `receipt only` on separate rows;
- **overlay racks** that show device-local/activity-local/workspace-local residue and whether it is safe to clear or stale after a switch;
- **import session strips** for `request pending`, `user step needed`, `granted not bound`, `bound here`, `expired`, and `receipt only`;
- **anchor death cards** plus **reset-scope chips** whenever old switch/import/resume anchors die instead of silently jumping to latest;
- **compare-before-switch drawers** that show what would actually change and which local overlay pieces would survive.

This is one of the best low-regret places to be ambitious, because it freezes honesty and diagnostics rather than one final object model.

## Restart shelves, wake kits, pin badges, and cold-start honesty
Steal from REF-SYSTEMD-SOCKETACT, REF-SYSTEMD-FDSTORE, REF-LINUX-SETNS, REF-LINUX-NAMESPACES7, REF-APPLE-LAUNCHD-SOCKETS, and sibling pressure from Schell anchor-death cards, Ward revalidation fences, and Steward adaptation witnesses.

A future custom shell should make room restart and session continuity feel luxurious **without** flattening everything into one fake `restored tab` blob.

Great moves:
- **restart shelves** that keep `wake kit delivered`, `restart locker held`, `namespace pin present`, `live now`, `anchor/repair only`, and `receipt only` on separate rows;
- **warm-start lamps** that say `warm exact`, `warm partial`, `cold repair`, `cold fresh`, or `receipt only`;
- **pin badges** that distinguish `fd pinned`, `bind pinned`, `provider pinned`, `pin dropped`, and `pin unknown`;
- **cold-start honesty cards** whenever a hoped-for warm restart falls back to a colder path;
- **partial wake-kit chips** like `overlay dropped`, `cache trimmed`, `concurrency capped`, or `reconsent needed` instead of one vague degraded badge;
- **replay-with-honesty rails** that surface any stronger revalidation fence before rerun/replay after a cold or partial restart.

This is another excellent low-regret place to be ambitious, because it freezes restart truth and shell dignity rather than one final locker object model.


## Epoch lamps, hop badges, and repair-offer cards
Steal from REF-WEZTERM-SHELL-INT, REF-GHOSTTY-130, REF-NU-OVERLAYS, REF-WICG-FSACCESS, REF-XDG-SESSION, and sibling pressure from Steward semantic epochs/hop lineage plus Schell anchor-death honesty.

A future custom shell should make stale footing and repair feel luxurious **without** flattening everything into one fake `still good` badge.

Great moves:
- **epoch lamps** on room tabs, sticky command headers, and command-finished chrome that say `same epoch`, `older epoch`, `hop changed`, or `receipt only`;
- **hop badges** that tell the truth about local/tmux/ssh/nested-shell path and whether cwd/markers are exact or approximate;
- **currentness drawers** for current bind versus currentness witness versus semantic epoch versus receipt history;
- **repair-offer cards** for `refresh witness`, `revalidate before stop`, `reconsent`, `rebind here`, `make local`, `rerun clean`, or `dismiss to receipt only`;
- **stale-anchor shutters** that let old exact controls visibly degrade to explanation/history instead of silently targeting latest;
- **why-not-now drawers** that explain whether the blocker is provider currentness, semantic epoch drift, or both.

This is another excellent low-regret place to be ambitious, because it freezes honesty and shell dignity rather than one final witness schema or provider contract.


## Renewal / retry / gate chrome
Another especially high-value move is to give every room and command block a tiny continuity-control strip:
- **renewal lamps** for `renewed through`, `due soon`, `missed`, or `unsupported`
- **retry clocks** for `retry after`, `still processing`, or `hint expired`
- **repair-gate cards** for `cooling down`, `manual clear required`, or `rerun clean`

This is exactly the kind of luxury move that makes a shell feel super awesome while remaining brutally honest about whether it is helping, waiting, or refusing to keep guessing.


## Warmth rails, login lanterns, and defer drawers
Steal from REF-XDG-BACKGROUND, REF-ANDROID-BG-EXEC-LIMITS, REF-APPLE-BGTASKS, REF-K8S-LEASE, REF-K8S-ENDPOINTSLICE, REF-VSCODE-SHELLINT, REF-VSCODE-199-SHELLINT, REF-WEZTERM-SHELL-INT, REF-GHOSTTY-130, and REF-NU-OVERLAYS.

A future custom shell should make warm/background continuity feel luxurious **without** flattening everything into one fake `still running` or `will restore` badge.

Great moves:
- **warmth rails** that say `foreground`, `warming`, `background serving`, `draining`, `restore intent only`, or `receipt only`;
- **keep-warm badges** for `allowed`, `clamped`, `expiring`, `denied`, or `unknown`;
- **login lanterns** for `restore allowed`, `restore proposed`, `restore denied`, `fresh consent required`, or `restore failed last time`;
- **defer drawers** that make queued repair/rebind/revalidate work explicit instead of pretending the room/import stayed live;
- **quality chips** like `rich`, `basic`, `approximate`, or `none` so the user knows how trustworthy the current shell-integration chrome is.

This is another excellent low-regret place to be ambitious, because it freezes lifecycle honesty and shell dignity rather than one final background-presence substrate.

## Attention pips, interrupt ladders, quiet shutters, and ack ledgers
Steal from REF-XDG-NOTIFICATION, REF-ANDROID-NOTIF-CHANNELS, REF-ANDROID-TIMESENSITIVE, REF-APPLE-CRITICAL-ALERTS, and REF-TMUX-ALERTS.

A future custom shell should make room attention feel luxurious **without** flattening everything into one fake `notification` badge.

Great moves:
- **attention pips** that distinguish `activity`, `bell`, `silence`, `follow-up unread`, or `receipt only`;
- **interrupt ladders** for `badge only`, `banner candidate`, `urgent request`, `urgent but clamped`, `critical requires separate grant`, or `suppressed`;
- **quiet shutters** that explain focus/presentation/workspace hush posture without pretending the underlying event vanished;
- **ack ledgers** that keep unresolved follow-up visible after transient chrome is gone;
- **coalesced-event counters** and **why-this-pip drawers** so the shell can be loud with truth and quiet with noise.

This is another excellent low-regret place to be ambitious, because it freezes attention honesty and shell dignity rather than one final notification-center substrate.

## Summon beacons, activation baton chips, front latches, and secure-entry shutters
Steal from REF-XDG-ACTIVATION-V1, REF-MS-ALLOWSETFOREGROUND, REF-MS-COALLOWSETFOREGROUND, REF-XTERM-FOCUS, REF-WEZTERM-SHELL-INT, and REF-GHOSTTY-130.

A future custom shell should make room surfacing feel luxurious **without** flattening everything into one fake `focus` or `trusted` badge.

Great moves:
- **summon beacons** that distinguish `glance me`, `result ready`, `review wants front`, `helper wants eyes`, or `receipt only`;
- **activation baton chips** for `fresh`, `forwarded`, `consumed`, `expired`, `invalid`, or `none`;
- **front latches** for `frontmost`, `focused`, `raise requested`, `declined`, `stolen back`, or `background only`;
- **secure-entry shutters** that explain `trusted chooser`, `secure review`, `host-secure mode`, `not a trusted surface`, or `policy denied`;
- **quality chips** so the terminal can confess whether focus/foreground truth is `rich`, `approximate`, `prompt-only`, or `none`.

This is another excellent low-regret place to be ambitious, because it freezes visibility honesty and shell dignity rather than one final focus manager or secure-entry substrate.


## Mirror strips, rehearsal rails, and secure-entry curtains
Another excellent low-regret place to be ambitious is shell-visible accessibility/automation truth.

The future shell should be able to show:
- **mirror strips** that distinguish `semantic mirror`, `screen mirror`, `redacted`, `delayed`, or `history only`;
- **lease chips** that distinguish `observe only`, `rehearse only`, `inject allowed`, `remote support`, `expired`, or `revoked`;
- **rehearsal rails** that preview where automation would act before a real injection lane exists;
- **secure-entry curtains** that explain `mirror redacted`, `input blocked`, `secure field`, `trusted chooser`, or `policy denied`;
- **quality chips** like `rich room truth`, `semantic only`, `mirror only`, `prompt-local`, or `none`.

This is another excellent low-regret place to be ambitious, because it freezes automation honesty and shell dignity rather than one final accessibility substrate, one final remote-control session model, or one final secure-entry policy store.

## Site ledgers, provider halos, and bind-here ladders
Steal from REF-XDG-DOCUMENTS, REF-ANDROID-SAF, REF-ANDROID-FILEPROVIDER, REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-DIR-CAPS, REF-MS-CFREGISTER, REF-MS-CFCONVERT, and REF-APPLE-FILEPROVIDER-SYNC.

A future custom shell should make locality feel luxurious **without** flattening projection, publication, and localization into one fake path truth.

Great moves:
- **site ledgers** that distinguish `provider projection`, `published here`, `published to child`, `localized here`, `local object`, or `receipt only`;
- **provider halos** for `provider-owned`, `portal view`, `placeholder`, `hydrated`, `replica`, or `history only`;
- **bind-here ladders** that keep `inspect`, `keep projected`, `publish alias`, `localize`, and `receipt only` as visibly different next steps;
- **same-object multi-site diffs** so one object can be compared across projection sites, room aliases, and localization states honestly;
- **quality chips** that confess whether locality truth is `rich`, `provider-reported`, `partial`, or `history only`.

This is another excellent low-regret place to be ambitious, because it freezes locality honesty and shell dignity rather than one final projection or localization substrate.

## Stack badges, whiteout ghosts, merge rails, and commit ladders
Steal from REF-OVERLAYFS, REF-PLAN9-UNIONDIRS, REF-K8S-PROJECTED-VOLUMES, REF-APPLE-FILEPROVIDER-PLACEHOLDER, REF-APPLE-FILEPROVIDER-STARTPROVIDING, REF-APPLE-FILEPROVIDER-EVICT, and REF-NIX-REALISE.

A future custom shell should make layered editability feel luxurious **without** flattening `base`, `upper shadow`, `merged view`, and `publish result` into one fake local file truth.

Great moves:
- **stack badges** that distinguish `base`, `upper`, `merged`, `whiteout`, `opaque`, `published`, or `receipt only`;
- **whiteout ghosts** and **opaque shutters** so local hides stay explainable;
- **creation-target pips** that tell the truth about where a new item would land;
- **upper/lower diff drawers** so users can compare the local shadow to the base honestly;
- **commit ladders** that keep `keep shadow`, `seal upper`, `publish merged`, `make local`, and `push back` as visibly different next steps.

This is another excellent low-regret place to be ambitious, because it freezes merge/overlay honesty and shell dignity rather than one final overlay or publish-back substrate.



## 12. Accept slips and settle rails for deferred provider truth
Steal from REF-RFC9110-202, REF-XDG-REQUEST, REF-GCLOUD-LRO, REF-GDRIVE-LRO, REF-AZURE-ASYNC-REQREPLY, and SlopOS acceptance/completion posture.

Whenever a pane submits a provider-backed import/pushback/publish action, the shell should be able to show:
- whether the request was merely admitted
- whether there is a provider operation bead / poll handle
- whether completion is still pending, settled, expired, or unknown
- what this room adopted locally afterward
- visibility quality of that information (`rich`, `basic`, `heuristic`)

Why this is great:
- users stop confusing `accepted` with `done`;
- deferred work can feel native without pretending operation handles are object identity;
- the shell gets luxury async chrome without smuggling in a global task manager as the semantic center.

Guardrail:
- never use the same badge for `accepted now` and `settled later`; local adoption should stay explicit after settlement.


## 13. Intent lamps and retry braids for same-request honesty
Steal from REF-HTTPAPI-IDEMPOTENCY-KEY, REF-AWS-EC2-IDEMPOTENCY, REF-STRIPE-IDEMPOTENT-REQUESTS, REF-STRIPE-ADVANCED-ERROR-HANDLING, and SlopOS request-key discipline.

Whenever a pane retries a provider-backed import/pushback/publish action, the shell should be able to show:
- whether the current attempt claims to be the same request as before
- whether the current payload still matches the original canonical basis
- whether the sameness witness is fresh, reused, expired, pruned, or missing
- whether the provider replayed the prior result, rejected a mismatch, or is still processing the first attempt
- visibility quality of that information (`rich`, `basic`, `heuristic`)

Why this is great:
- users stop confusing `retry` with `new request`;
- shells can prevent accidental double-submit or silent retargeting under one old key;
- async/import/publish flows get luxury retry chrome without pretending dedupe keys are object identity.

Guardrail:
- never let one old sameness witness silently carry a materially changed draft.

## 14. Cutoff lamps, detach-root cards, and continue-without-me ladders
Steal from REF-GO-CONTEXT, REF-GO-WITHOUTCANCEL, REF-GRPC-DEADLINES, REF-KOTLIN-CANCEL, REF-KOTLIN-NONCANCELLABLE, REF-TEMPORAL-DISCONNECTEDCTX, and REF-CAPNP-CANCEL.

Whenever a pane kicks off provider-backed work, the shell should be able to show:
- whether the work is still caller-bound
- whether cancellation has been requested, propagated, acknowledged, or ignored
- whether a deadline is inherited, narrowed, absent, or already fired
- whether only cleanup still runs under a detached root
- whether the provider owns a longer continuation now
- visibility quality of that information (`rich`, `basic`, `heuristic`)

Why this is great:
- users stop confusing `I stopped waiting` with `the provider stopped`;
- cleanup and long-running continuation become visible and inspectable instead of spooky hidden background work;
- the shell gets luxury async chrome without pretending every detached thing is the same class.

Guardrail:
- never use the same badge for `deadline fired`, `cancel confirmed`, and `cleanup still running`.

## Budget chips, spend rails, and switch-payer ladders
Steal from REF-AWS-S3-REQUESTER-PAYS, REF-GCS-REQUESTER-PAYS, REF-K8S-RESOURCEQUOTA, REF-SEL4-MCS, and SlopOS budget-payer posture.

The shell should treat:
- `may do this`,
- `this sponsor would pay`,
- `a bounded budget exists`,
- `spend is reserved`,
- `charge landed`, and
- `history remembers a past spend`

as different truths.

Why this is great:
- expensive imports/exports/hydration work become legible before commitment;
- cross-account/provider-backed actions stop feeling like folklore;
- billing/sponsorship mistakes become visible before or right after they happen.

Guardrail:
- never let `authorized` impersonate `funded`, and never let one old charge receipt revive a live sponsor.

What the UI should grow:
- **payer chips** showing `requester`, `owner`, `server budget`, `unknown`, or `history only`;
- **spend rails** showing `unreserved`, `reserved`, `partially spent`, `charged`, `rejected`, or `history only`;
- **switch-payer ladders** for `preview cost`, `reserve`, `commit spend`, `retry with same sponsor`, or `switch payer`;
- **charge ghosts** that preserve past charge truth without reviving a live budget lease.

## Facet chips, kit cards, and bind-one-facet-here ladders
A custom shell+terminal gets much better if it can admit that `the object` and `the facet I currently hold` are not the same truth. Useful moves include:
- **facet chips** that say `inspect`, `edit`, `publish`, `automate`, `kit only`, or `history only`;
- **kit cards** that show grouped handles/facets without claiming they are all live binds in this pane;
- **bind-one-facet-here ladders** so a user can attach one chosen facet into the current room without silently importing every affordance of the underlying object;
- **name-only ghosts** that explain when a published name remains even though the broader kit or stronger facet is no longer here.


## Verify chips, proof cards, and read/publish rails
A custom shell+terminal gets much better if it can admit that `safe to remember`, `safe to verify`, `safe to read`, and `safe to mutate/publish` are not the same truth. Useful moves include:
- **verify chips** that say `descriptor only`, `verify only`, `read now`, `publish now`, or `history only`;
- **proof cards** that can stay in transcripts, notebooks, and wallets without pretending they are current authority;
- **read rails** and **publish rails** so a stronger live facet never arrives disguised as one old descriptor card;
- **opaque return tokens** for especially sensitive flows where later hand-back/validation is safer than stringly replay.

## Object-core badges, byte-proof lamps, and shape-hash drawers
Steal from REF-OCI-DESCRIPTOR, REF-RFC6920, REF-IPFS-CIDS, REF-NIX-CA, and the current SlopOS artifact/capstore posture.

Whenever a pane renders an object-like row, the shell should be able to show:
- whether it claims `same object core`, `related derivative`, or `core unknown`
- whether one exact raw-byte or canonical-form proof is present
- whether one chunk/codec/reference-sensitive shape hash is present instead
- whether the current row is only a designation/name/locator or a current live facet
- visibility quality of that information (`rich`, `basic`, `heuristic`)

Why this is great:
- object-store truth gets richer without one magic `hash means everything` lie;
- imports, proofs, and live capability become easier to inspect at a glance;
- the shell can stay luxurious while admitting when two rows are the same object conversation but not the same proof or address family.

Guardrail:
- never let one old proof row, CID, store path, or published name impersonate a current live facet.

## Core stamps, envelope drawers, sidecar lamps, and live rails
Steal from current SlopOS wallet posture plus Git patch-id / OCI descriptor / in-toto subject layering.

Whenever the shell renders a review/import/rebind card, it should be able to show:
- whether the **authority core** is unchanged, changed, correlation-only, or unknown
- whether a richer **descriptive envelope** is present and what volatile fields it carries
- whether one **graph/diff/provenance sidecar** is attached
- whether **live authority** is actually bound here now
- visibility quality of that information (`rich`, `basic`, `heuristic`)

Why this is great:
- drift/reconsent becomes calm and legible;
- descriptive richness stops churning the stable gate key;
- explainability gets luxurious without turning into power;
- the shell can stay beautiful while telling the truth about what is only review material and what is live authority.

Guardrail:
- never let an envelope or sidecar impersonate a current live bind.


## Strong-lock badges, weak-lamps, compare-profile drawers, and facet rails
Steal from REF-RFC9110-PRECONDITIONS, REF-AWS-S3-OBJECT-ETAG, REF-AWS-S3-INTEGRITY, REF-GIT-PATCH-ID, and current SlopOS wallet/artifact posture.

Whenever a pane renders a sameness/proof row, the shell should be able to show:
- whether one **strong exact proof** is present and safe for cut-sensitive acts
- whether it only has a **weak validator** or review/drift hint
- what **comparison profile** produced the sameness claim
- whether the row is only proof/validator material or a **current live facet**
- visibility quality of that information (`rich`, `basic`, `heuristic`)

Why this is great:
- exactness stops being confused with calm review sameness;
- weak drift hints stay useful without overstating mutation safety;
- comparison rules stop hiding behind one magical digest label;
- the shell can stay luxurious while telling the truth about current authority.

Guardrail:
- never let a weak validator or one old comparison result impersonate a current live facet.


## Head badges, order pips, supersession ladders, and facet rails
Steal from SlopOS ordering-token posture plus Kubernetes resourceVersions, etcd revision metadata, S3 version IDs/delete markers, and Git reflogs.

Whenever the shell renders one mutable object or published name, it should be able to show:
- whether it is talking about the **object core**, one **designation**, or one **historical row**
- whether one **revision token** is current, stale, incomparable, or provider-local only
- whether another candidate shares the same **order scope**
- whether one **supersession row** says `replaced`, `tombstoned`, `restored`, or `history only`
- whether a **live facet** is actually present now

Guardrail:
- never let one old head token, reflog-like row, or delete marker impersonate a current live facet.

## Record cards, payload chips, wrapper seals, wire ghosts, and live rails
Steal from current SlopOS encoding/wallet posture plus RFC 8785 JCS, RFC 8949 deterministic CBOR, RFC 9052 COSE detached payloads, and in-toto envelope layering.

Whenever the shell renders a descriptor / receipt / review row, it should be able to show:
- whether it is talking about the **semantic record** or only one derived byte layer
- whether one **canonical payload** is present and under which profile
- whether one **signed wrapper** authenticates payload type or detached-payload posture
- whether the row is only one **wire/storage copy**
- whether a **live facet** is actually present now

Why this is great:
- `same reviewed thing` stops pretending to mean `same wrapper bytes`;
- detached-payload and rewrapping flows become explainable instead of spooky;
- export/log copies stop impersonating the proof or the live object;
- the shell can stay luxurious while telling the truth about meaning, proof layer, wrapper layer, and live authority.

Guardrail:
- never let one old wrapper blob, detached-payload receipt, or export copy impersonate a current live facet.



## Birth badges, backing ghosts, lineage ladders, and live rails
Steal from current SlopOS fresh-identity / explicit-lineage posture plus Linux reflink, Btrfs reflink, OpenZFS clone concepts, and APFS clones.

Whenever the shell renders one clone/import/materialization row, it should be able to show:
- whether it is talking about one **fresh object** or only one shared-backing optimization,
- whether **shared backing** is present, diverged, deep-copied, or unknown,
- whether one explicit **lineage** relation is known,
- whether a **live facet** is actually present now.

Why this is great:
- cheap copies become delightful without hiding object/trust truth;
- same-bytes and shared-backing folklore stop laundering identity;
- lineage becomes reviewable instead of spooky;
- the shell can stay luxurious while telling the truth about fresh object identity, storage reuse, and current authority.

Guardrail:
- never let one backing ghost or old lineage receipt impersonate a current live facet.

## Session beads, part gauges, seal ladders, abort ash, and live rails
Steal from current SlopOS persistence/import/jobs posture plus Amazon S3 multipart upload, tus resumable uploads, OCI chunked blob upload, and Google Cloud Storage resumable sessions.

Whenever the shell renders one import/upload/materialization row, it should be able to show:
- whether it is talking about one **live upload session** or one **durable committed object**,
- whether **part coverage** is empty, partial, offset-known, assembly-ready, or unknown,
- whether one **completion manifest** or explicit close instruction exists,
- whether one **abort/expiry verdict** is known,
- whether a **live facet** over the finished object is actually present now.

Why this is great:
- resumable imports become delightful without lying about what already exists;
- progress bars stop laundering themselves into committed-object truth;
- finalize/abort actions become reviewable instead of spooky;
- the shell can stay luxurious while telling the truth about staging, assembly, commit, cleanup, and current authority.

Guardrail:
- never let one old session bead, offset row, or aborted-upload receipt impersonate a current live facet over the finished object.


## Recipe cards, member rails, aggregate seals, unpack lamps, and live rails
Steal from current SlopOS composition/persistence posture plus Google Cloud Storage composite objects, OCI manifests/image indexes, `git write-tree`, and containerd pull/unpack.

Whenever the shell renders one recipe/import/package/work-surface row, it should be able to show:
- whether it is talking about one **assembly recipe** or one **durable aggregate object**,
- whether one **member set** is complete, missing, stale, or provider-hidden,
- whether one **aggregate seal** exists,
- whether one **realized work surface** exists here, elsewhere, or only in history,
- whether a **live facet** is actually present now.

Why this is great:
- descriptor graphs become delightful without lying about what is already mounted or hydrated;
- aggregate commits stop pretending they are already a current work surface;
- unpack/materialize/evict flows become reviewable instead of spooky;
- the shell can stay luxurious while telling the truth about recipe intent, member evidence, durable assembly, realization, and current authority.

Guardrail:
- never let one old recipe card, member rail, aggregate seal, or unpack receipt impersonate a current live facet.


## Capsule cards, seal shutters, courier rails, commit lamps, and live rails
Steal from current SlopOS import/materialization/commit posture plus Linux `memfd_create()`, file sealing, UNIX FD passing, and `O_TMPFILE` publish-later behavior.

Whenever the shell renders one draft/import/edit-return row, it should be able to show:
- whether it is talking about one **transient staging capsule** or one **durable committed object**,
- whether one **seal state** is open, frozen for review, frozen against future writes, or locked,
- whether one **courier rail** has only handed the capsule locally,
- whether one **commit lamp** says the object is still draft-only, committed here, published now, discarded, or history only,
- whether a **live facet** is actually present now.

Why this is great:
- helper edits, previews, export-review flows, and import staging become delightful without lying about what is durable already;
- freeze-for-review becomes explainable instead of spooky;
- local handoff stops pretending to be durable publication;
- the shell can stay luxurious while telling the truth about drafting, freezing, local couriering, commit-last, and current authority.

Guardrail:
- never let one old capsule card, seal shutter, courier receipt, or commit lamp impersonate a current live facet.


## Hold badges, retention rails, purge lamps, and live rails
Steal from current SlopOS persistence/evidence posture plus Amazon S3 Object Lock, Google Cloud Storage object holds/Object Retention Lock, and Azure immutable storage.

Whenever the shell renders one object/cleanup/history row, it should be able to show:
- whether it is talking about one **durable committed object** or only a **history row**,
- whether one **retention rail** exists and whether it is editable, locked, satisfied, or unknown,
- whether one **hold badge** is temporary, event-driven, legal, multiple, or none,
- whether one **purge lamp** says eligible, blocked by retention, blocked by hold, lifecycle pending, purged, or history only,
- whether a **live facet** is actually present now.

Why this is great:
- cleanup becomes delightful without lying about what policy still blocks;
- `retained`, `held`, `purged`, and `usable now` stop blurring together;
- purge attempts become explainable instead of spooky.

Guardrail:
- never let one old hold badge, retention rail, or purge receipt impersonate a current live facet or current absence.

## Seal badges, wrap rosters, rewrap ladders, unwrap rails, and clear rails
Steal from current SlopOS cryptosvc/vault posture plus RFC 7516 JWE, WebCrypto, and Google Cloud KMS envelope-encryption / re-encryption guidance.

Whenever the shell renders one encrypted/import/export/history row, it should be able to show:
- whether it is talking about one **sealed object** or only a **history row**,
- whether one **wrap roster** is visible and how many recipient/key-slot rows it carries,
- whether one **rewrap ladder** is pending, completed, failed, or history only,
- whether one **unwrap rail** says `provider-bound`, `needs mediator`, `available here`, or `cannot clear here`,
- whether a **clear rail** is actually present now.

Why this is great:
- encrypted storage becomes delightful without lying about who can actually clear it now;
- recipient changes and key rotation stop masquerading as object rebirth or live access;
- cleartext use becomes explainable instead of spooky.

Guardrail:
- never let one old wrap roster, rewrap receipt, or key-version witness impersonate a current clear facet.



## Durability badges, layout ghosts, repair ladders, availability lamps, and live rails
Steal from current SlopOS artifact/CapStore posture plus Ceph placement+scrubbing, Tahoe-LAFS share thresholds, and Amazon S3 replication-status honesty.

Whenever the shell renders one object/storage/history row, it should be able to show:
- whether it is talking about one **committed object** or only a **history row**,
- whether one **durability badge** says `single copy`, `replica target`, `k-of-n target`, `policy hidden`, or `unknown`,
- whether one **layout ghost** says `shares placed`, `replicas spread`, `placement changed`, `layout hidden`, or `history only`,
- whether one **repair ladder** says `healthy`, `scrubbing`, `degraded`, `repairing`, `failed`, or `history only`,
- whether one **availability lamp** says `retrievable`, `retrievable with degradation`, `provider unavailable`, `unrecoverable`, or `history only`,
- whether a **live rail** is actually present now.

Why this is great:
- the object store can be delightful without lying about current durability health;
- degraded-but-readable states stop masquerading as total failure or perfect safety;
- repair work becomes explainable instead of spooky.

Guardrail:
- never let one old placement snapshot, repair receipt, or replication-status row impersonate object identity or current live authority.

# Frost badges, thaw beads, copy-thaw ladders, expiry lanterns, and live rails

Steal from current SlopOS import/materialize/CapStore posture plus Amazon S3 restore semantics and Azure archive rehydration semantics.

Whenever the shell renders one object/tier/history row, it should be able to show:
- whether it is talking about one **committed object** or only a **history row**,
- whether one **frost badge** says `hot`, `cool`, `cold`, `archived`, `offline`, or `history only`,
- whether one **thaw bead** says `requested`, `pending`, `priority high`, `failed`, `expired`, or `history only`,
- whether one **copy-thaw ladder** says `temporary copy`, `tier changed`, `copy target ready`, `copy target pending`, or `history only`,
- whether one **expiry lantern** says `expires then`, `no expiry exposed`, `expired`, or `history only`,
- whether a **live rail** is actually present now.

Why this is great:
- cold storage becomes delightful without lying about hot readability;
- restore and rehydrate jobs stop masquerading as object identity or current authority;
- temporary readable copies stop pretending to be permanent hot placement;
- the shell can stay luxurious while telling the truth about archive posture, thaw progress, temporary readability, expiry, and current authority.

Guardrail:
- never let one old thaw receipt, restore-status row, or expiry lantern impersonate a current live facet.



# Realm badges, route halos, egress shutters, and live rails

Steal from current SlopOS cluster-map / replication-contract posture plus Amazon S3 replication + Multi-Region Access Point routing, Google Cloud Storage dual-region / bucket-RPO docs, Azure geo-redundancy read-secondary posture, and Ceph CRUSH placement rules.

Whenever the shell renders one object/route/history row, it should be able to show:
- whether it is talking about one **committed object** or only a **history row**,
- whether one **realm badge** says `single realm`, `dual realm`, `cross-region`, `provider hidden`, or `history only`,
- whether one **placement ghost** says `present in A`, `present in A+B`, `lagging`, `unknown`, or `history only`,
- whether one **route halo** says `nearest route`, `primary route`, `secondary read`, `failover lane`, `route hidden`, or `history only`,
- whether one **egress shutter** says `local only`, `cross-boundary denied`, `review needed`, `allowed by policy`, or `history only`,
- whether a **live rail** is actually present now.

Why this is great:
- locality and compliance become inspectable without turning into folklore;
- nearest/global endpoints stop masquerading as actual placement truth;
- cross-boundary export/import decisions become reviewable instead of spooky provider behavior.

Guardrail:
- never let one route halo, nearest-endpoint label, or old replication receipt impersonate current placement, current export permission, or current live authority.

# Truth badges, propagation echoes, cache ghosts, and live rails

Steal from current SlopOS boundary posture plus Amazon S3 strong consistency, Google Cloud Storage consistency, RFC 9111 HTTP caching, and RFC 9211 Cache-Status.

Whenever the shell renders one object/publication/history row, it should be able to show:
- whether it is talking about one **committed object** or only a **history row**,
- whether one **truth badge** says `origin current`, `origin deleted`, `unknown`, or `history only`,
- whether one **propagation echo** says `grant pending`, `revoke settling`, `config propagating`, `provider hidden`, or `history only`,
- whether one **cache ghost** says `publicly cacheable`, `stale maybe`, `purge asked`, `cache bypassed`, or `history only`,
- whether one **trail drawer** can show `hit`, `miss`, `forward`, `ttl`, `stored`, or `detail` facts,
- whether a **live rail** is actually present now.

Why this is great:
- origin truth and cache truth stop impersonating one another;
- revoke/delete UI stops overpromising about public/shared caches;
- publication becomes inspectable without becoming spooky provider folklore.

Guardrail:
- never let one cache hit, purge request, stale public copy, or old revocation receipt impersonate committed-object truth, current permission truth, or current live authority.


## Prefix badges, folder ghosts, and list lanterns
Another shell move worth stealing from the object-store world is calm honesty about folder-looking things. One row may be a flat-name prefix, one provider-native folder resource, one managed folder, one cached list snapshot, or one current room bind. The shell should be able to say which one it is instead of flattening them into one `directory` myth.

# Slot maps, root badges, import tickets, and live-bind rails

Steal from current SlopOS capshell/portal posture plus Fuchsia namespaces, Capsicum/WASI descriptors/preopens, XDG Documents portal mediation, Tahoe-LAFS/Cap'n Proto capability flavors, EROS persistence caution, and object-store precondition witnesses.

Whenever the shell renders one launch/import/object row, it should be able to show:
- whether it is talking about a **launch view plan** or actual installed authority;
- whether one **root badge** says `sealed empty`, `synthetic root`, `object-store root`, `provider projection`, `portal-adopted subtree`, `compat membrane`, or `history only`;
- whether one **slot map** shows exact live handles with rights/lease/provenance chips;
- whether one **import ticket** is only `pending`, `chooser open`, `granted-not-bound`, `adopting`, `denied`, `expired`, or `revoked`;
- whether one **adoption ladder** moved an external result to staging, committed object, published bind, or current live facet;
- whether a **live-bind rail** is actually present now.

Why this is great:
- launch review becomes visible without becoming authority;
- child-process namespaces stop inheriting spooky host-root/parent-fd folklore;
- portal import becomes auditable instead of magical;
- object-store adoption can stay careful about witnesses and currentness;
- the shell can be gorgeous while still making `ticket only`, `receipt only`, and `live now` unmistakably different.

Guardrail:
- never let one launch plan, slot number, host path string, portal ticket, listing row, or receipt impersonate a current live facet.

## Revision 139 move: flow maps, custody badges, outflow gates, leak sirens, and audit drawers

Make handle flow visible without making the explanation authoritative.

Awesome moves:

- show a flow map for the active app/process/session;
- put custody badges on live handle rows (`launch-root`, `portal-grant`, `borrowed`, `attenuated`, `provider-proxy`, `reopened`);
- replace generic `share` with explicit outflow gates (`borrow`, `child launch`, `portal export`, `proxy only`, `bytes only`, `receipt only`);
- show a before/after authority diff before portal import, helper spawn, or export;
- raise leak sirens for handles that remain live after an expected boundary closes;
- keep audit drawers and old receipts visually weaker than live handles;
- provide `send bytes, not authority` as a safe alternative when a live handle cannot leave.

This is a shell superpower because it makes invisible authority behavior inspectable while preserving the design rule that snapshots, diffs, verdicts, badges, and receipts are not themselves capabilities.


## Revision 140: root-ledger and restore superpowers

- **Root ledger cards**: show durable root commits as recorded facts with accepted-tip, rollback-candidate, quarantined, dev-rollback, and receipt-only badges.
- **Epoch fence previews**: before restore/activation, line up expected root tip, observed root tip, comparison profile, and stale/rollback/current verdict.
- **Restore tickets**: make inspect, repair, resume, rollback, read-only preview, and live activation distinct actions instead of one scary `restore` button.
- **Resurrection gate drawers**: show portal anchors, docrefs, sturdyrefs, keyrefs, and secretrefs with `admit`, `ask again`, `read-only`, `deny`, or `receipt only` verdicts.
- **Activation rails**: preview exact live slots that will be installed and exact old powers that will not come back.
- **Time-capsule rooms**: open old roots safely in read-only/quarantine mode before any live namespace or provider reconnection.
- **Rollback honesty cards**: show which roots go backward and which issuer revocation epochs, portal policies, provider states, and receipts do not.

## Revision 141: GC halos, pin badges, sweep rehearsals, finalizer rails, and ash receipts

Make object-store liveness visible without turning every artifact into a root.

Awesome moves:

- **GC halos** on object cards: `durable root`, `live`, `pinned`, `held`, `leased`, `cached only`, `sweep candidate`, `finalizing`, `collected`, `receipt only`.
- **Why-retained drawers** that show durable roots, live handles, pins, holds, leases, policy roots, and provider-hidden reasons separately.
- **Pin badges** with direct/recursive/indirect/expiring/provider/debug/legal/offline meanings.
- **Sweep rehearsal cards** that show dry-run reclaim size, candidates, blockers, grace clocks, and stale basis warnings.
- **Finalizer rails** that show ordered cleanup obligations instead of one unhelpful `busy` error.
- **Ash receipts** that prove cleanup happened without looking like reopen handles.
- **Cache-not-pin ghosts** for objects that are locally present but sweepable.

Guardrail:

- never let a receipt, search index row, listing snapshot, preview cache, old namespace row, or cache hit impersonate a retention root or current live facet.

## 42. Quarantine capsules and residue lamps should make risky content safe to work with without laundering it

One shell move worth stealing from the latest SlopOS quarantine posture is a **safe-open capsule card** that appears when risky content is opened for inspection.

The card should say:

- what exact source object was reviewed;
- what stable materialization entered the disposable/review lane;
- whether active content is inert, blocked, or separately gated;
- what residue is allowed and where it will be destroyed;
- what exports will create new artifacts;
- what trust clearance, if any, exists now.

Super-awesome moves:

- origin braids for downloaded/imported/extracted/pasted/captured objects;
- quarantine shutters with `peek`, `open safe`, `sanitize/export`, and `request clear` ladders;
- residue lamps for MRU/thumbnail/autosave/OCR/embedding/summary side effects;
- derived-artifact rails so search hits and summaries point at the actual derived object, not a secretly reopened risky source;
- tiny trust receipts that say `cleared for edit, macros still blocked` rather than one scary all-or-nothing `trust` button.

Guardrail:

- opening, previewing, indexing, deriving, summarizing, or exporting must not silently clear source quarantine, mint durable reopen authority, or widen preview trust into execution authority.

## 43. Extract-plan cards, member capsules, and path-guard badges

Archives should become delightful without becoming spooky.

Super-awesome moves:

- **container gate cards** that show origin, quarantine, format, member count, and expanded-size estimate;
- **member claim tables** that render raw internal names, symlink/hardlink targets, device claims, xattrs, whiteouts, duplicates, and collisions as claims rather than paths;
- **extract rehearsal cards** that say what will be admitted, blocked, rewritten, budgeted, and materialized before extraction starts;
- **path-guard badges** for no-absolute, no-dotdot, no-link-escape, no-devices, no-setuid, xattrs stripped, ACLs stripped, and quarantine inherited;
- **sterile root capsules** that make `materialized for preview` visibly weaker than `published here`;
- **member capsule rails** that show fresh object birth and parentage for each admitted member;
- **namespace commit shutters** that preview publication into a project/view with currentness checks;
- **unpack receipts** that make history useful without looking like a handle.

Guardrail:

- never let member strings, duplicate entries, symlink/hardlink targets, whiteouts, device nodes, or extraction receipts impersonate current namespace authority.

## Revision 144: supply-chain evidence drawers without a green trust bit

Add an `Evidence` tab to object cards only if it refuses to say bare **trusted**. The tab should show SBOM drawers, locator chips, VEX shutters, provenance stacks, admission cut cards, activation rails, and supply-chain receipts as separate rows.

Super-awesome shell moves:

- `why admitted?` drawer that connects evidence rows to exact policy clauses.
- `why not executable?` ladder that offers safe-open, read-only inspect, test sandbox, or fetch-missing-evidence actions.
- locator ambiguity lens that shows broad CPE and ecosystem-local purl matches without hiding uncertainty.
- VEX diff rail that compares exploitability statements across time without letting latest-wins happen silently.
- restore recheck lamp for durable roots restored under newer advisory or policy epochs.
- **signed, not admitted** / **logged, not approved** badges for provenance stacks.

## Revision 145: secret slot cards and env-shadow lamps

Secrets should be easy to use without becoming invisible ambient authority.

Super-awesome moves:

- **secret slot cards** that show descriptor, scope, provider family, audience, epoch, carrier, and current live-use state without showing bytes;
- **env-shadow lamps** for `env:value`, `env:path`, `argv/config`, `child-inherits`, and `transcript-risk`;
- **redaction lenses** that say which surfaces are covered and which are not;
- **renewal rails** for `refreshable`, `must reacquire`, `requires presence`, `expired`, `revoked`, and `history only`;
- **residue sweepers** for config copies, initialized databases, caches, child processes, crash dumps, logs, screenshots, embeddings, summaries, and exported artifacts;
- **rerun-with-fresh-secret ladders** that reacquire under current policy rather than replaying old env.

Guardrail:

- a masked transcript, prompt success, secret descriptor, env variable, `$FOO_FILE` pointer, old renewal hint, or receipt is not current secret-bearing authority.

## Revision 146: delegation cards, membrane lamps, and revocation waves

Make delegation feel good without making revocation magical.

Steal for ViewFS shelling:

- **delegation cards** that say who is lending what to whom, through which route, with which caveats;
- **caveat chips** that are visibly `declared`, `proxy-enforced`, `verifier-checked`, `provider-owned`, or `unknown`;
- **membrane lamps** that show whether the actual authority is a proxy, raw handle, provider grant, expiry-only token, descriptor, or history;
- **revocation wave maps** that show local close, broker epoch, provider accepted, recipient notified, offline unknown, stale use denied, and propagation pending;
- **stale brakes** that explain `expired`, `recalled`, `epoch mismatch`, `basis drift`, `provider revoked`, or `history only` instead of generic denial;
- **recall receipts** that say what cannot be undone and what remains unknown;
- **rotate/reissue ladders** for bearer tokens, secret-derived authority, or risky exported handles;
- **redacted who-still-can drawers** that help without becoming recipient-graph leaks.

Guardrail: a share card, caveat chip, revoke response, wavefront snapshot, provider 200, or receipt is not current live authority and not proof of global erasure.

## Revision 147: inspect lenses, proc shades, trace fuses, and dump guards

Diagnostics should feel like x-ray vision without secretly becoming a skeleton key.

Super-awesome moves:

- **Inspect lens cards** that name target, mode, scope, redaction, export posture, and whether the target is live, stale, exited, revoked, or history-only.
- **Proc shades** for argv/env/cwd/root/process-tree/memory-map/dumpability posture with local-only/redacted/hidden badges.
- **FD / handle peek cards** that show authority class, issuer/caveat digest, expiry, and `no-dup` status without becoming clickable handles.
- **Trace fuses** that show probe family, descriptor digest, filter, buffer/rate bounds, TTL, sample/drop/overflow state, and stop/export actions.
- **Dump guards** that mark crash/core/memory captures as quarantined, not-indexed, retention-clocked, and export-gated.
- **Redaction coverage lenses** that say which surfaces are covered and which are not: transcript, trace, crash, screenshot, semantic summary, support zip.
- **Debug rails** with louder chrome for pause, attach, step, inject, memory read/write, slot duplicate, and namespace enter.
- **Support-bundle preview** that shows exactly what would leave before export, with omission receipts.

Guardrail:

- never let process IDs, namespace snapshots, fd/slot rows, trace samples, crash metadata, redaction masks, support-bundle manifests, or old inspection receipts impersonate current handle/debug authority.

## Revision 148 shell ideas: make network authority visible without a firewall wall of noise

- **Network x-ray**: per-room/process panel showing public internet, local network, loopback, resolver, proxy, listener, advertisement, tunnel, and send/upload lanes.
- **Resolver braid**: path from typed URL/host through canonical name, portal resolver, omitted SVCB/HTTPS/proxy facts, answer-set digest, selected family, and expiry.
- **Local shutter**: one bright control that makes `public internet allowed` not mean `can scan LAN/loopback`.
- **Egress meter**: show object/log/diagnostic/secret-derived material moving across a network lease, not just bytes on a socket.
- **Fetch-to-object split**: after a download, show `fetched` separately from `quarantined`, `extracted`, `SBOM known`, `admitted`, and `openable`.
- **Listener spotlight**: any listen/advertise/tunnel/public endpoint makes a stronger visual statement than outbound connect.
- **Receipt-only ghosts**: old sync/update/upload rows that look beautiful in history but cannot reconnect.
## Revision 149: service cards and binding braids without endpoint folklore

Service discovery should feel like magic until the exact moment it would hide authority. Then it should become beautifully explicit.

Super-awesome moves:

- **Service cards** that show actor, intent, designator, catalog root, scope, and whether a live handle exists.
- **Discovery drawers** with candidates, stale rows, denied rows, omitted fields, and source/catalog provenance.
- **Readiness lamps** for ready, serving, terminating, warming, stale, identity matched, policy denied, version drift, and health unknown.
- **Binding braids** that render `intent -> designator -> catalog -> snapshot row -> policy cut -> activation -> live slot`.
- **Activation rails** for provider start, socket/fd delivery, route warming, roots attached, secret slots delivered, failed activation, and needs-rebind.
- **Advert shutters** separating no advert, project catalog, process namespace, local-link, mesh/control plane, public endpoint, withdrawn, stale, and receipt-only.
- **Identity evidence lenses** that say matched/mismatch/omitted without saying trusted.
- **Service diffs** for candidate-set changes that do not silently adopt new endpoints.
- **History ghosts** for old calls that cannot invoke until a fresh binding cut creates a live handle.

Guardrail:

- never let a service name, catalog row, discovery snapshot, readiness lamp, identity match, binding receipt, activation rail, advertisement row, or call receipt impersonate current live service authority.


## Revision 151: digest shades, equality rails, dedup shutters, convergence lamps, and cache ghosts

Storage reuse should feel smart without turning the shell into a global inventory oracle.

Super-awesome moves:

- **Digest shades** that label raw-byte, canonical-payload, CID/DAG, closure/store, verified-blob, weak, private, public, unknown, and receipt-only proofs.
- **Equality rails** that put the comparison profile before the result.
- **Dedup shutters** for off, local-only, same-owner, project, tenant, public/global, provider-opaque, and encrypted-domain reuse.
- **Convergence lamps** for random-key, per-user secret, project secret, tenant secret, global convergent, server-aided, none, or redacted domains.
- **Cache ghosts** for hit, miss, hidden, provider-opaque, and receipt-only observations.
- **Possession challenge cards** that separate `knows digest` from `proved bytes` from `has live authority`.
- **Leakage budget meters** for cross-principal dedup, public locator publication, and hit/miss disclosure.
- **Unshare/deep-copy ladders** when deletion, export, privacy, or provenance needs a fresh backing choice.

Guardrail:

- never let a digest, CID, cache hit, dedup table row, convergence-domain label, shared-backing observation, or old materialization receipt impersonate current object authority, trust clearance, publication, retention, membership, or live handle state.


## Revision 152 move: semantic search that tells the authority truth

Add search/AI chrome that makes semantic derivation visible instead of magical:

- semantic derivation cards for intent/source/profile/output;
- embedding vault badges for room/project/tenant/provider/disposable/public scope;
- scope gates before every semantic search;
- model-profile chips for embedding/chunker/OCR/redaction freshness;
- result shades for metadata-only/snippet/thumbnail/quote/answer-only/open-required;
- answer receipts that show projections used and whether live handles were granted;
- instruction-quarantine rails for retrieved imperative text;
- memory shutters for do-not-persist/receipt-only/room/project/provider/public;
- unindex ladders that distinguish vector rows, derived artifacts, answer caches, sources, provider cleanup, and receipts.

The delightful interaction is not `search everything`; it is `search exactly this authority scope, show exactly this projection, and ask before turning a match into an open/action/export`.
## Revision 153 super-awesome move: prompt provenance without bureaucracy

A shell can make agent work safer and cooler by showing prompt provenance as chrome, not paperwork:

- an **instruction ladder** in the side rail;
- a **context shutter** above every answer;
- a **proposal-only badge** on model text;
- a **plan compiler card** when the user wants action;
- a **toolcall fuse** before the call crosses file/secret/network/service boundaries;
- an **approval basis drawer** that says exactly what was authorized;
- a **memory promotion shutter** when a result wants to become future context.

Steal from MCP, VS Code customizations, and SlopOS D-LLM, but keep the core ViewFS stance: model text proposes; validated plans plus live handles act.

## Revision 154 super-awesome move: consent that shows its chain of custody

Make high-risk approval feel exact without making it bureaucratic:

- a **consent card** generated from the typed plan;
- an **authority-diff pane** that shows reads/writes/sends/secrets/budgets/durable grants separately;
- a **trusted-path lamp** that says shell-local, portal-local, secure-attention, ordinary-focused, app-rendered, model-rendered, remote-captured, accessibility-mediated, or headless-policy;
- **gesture chips** for fresh/consumed/expired/remote/synthetic/hardware/secure-attention interaction evidence;
- **volition-token beads** that bind one action digest to one summary digest and then disappear as live authority;
- **clickjacking shields** on helper/web/model UI that is presentation-only;
- **approval-cut drawers** that name exact authority slots and retry posture;
- **receipt ghosts** that explain and cannot reapprove.

Core delight: the user can approve quickly because the shell is brutally precise about what the approval means.
