# Mirror strips, rehearsal rails, and secure-entry curtains

The future custom shell can feel magical here **without** lying.
The trick is to make `live now`, `mirror available`, `lease exists`, `inject actually possible`, and `secure entry blocks this now` visibly different.

## Great moves
### 1. Mirror strips
Every room or helper surface gets a tiny mirror strip that can say:
- `semantic mirror`
- `screen mirror`
- `redacted now`
- `delayed mirror`
- `history only`

That is much better than one vague “automation active” glow.

### 2. Lease chips
A compact chip should explain the current posture:
- `observe only`
- `rehearse only`
- `inject allowed`
- `remote support`
- `expired`
- `revoked`
- `none`

Opening the chip should explain TTL, scope, issuer, and whether secure-entry posture is currently clamping any part of the lease.

### 3. Rehearsal rails
Before real synthetic input is possible, the shell should still be able to show:
- where the action would land,
- what object or node the automation thinks it is targeting,
- what quality that targeting has,
- and what fresh user step would be needed to upgrade from rehearsal to real action.

This is a very good `super awesome` move because it makes automation inspectable rather than spooky.

### 4. Secure-entry curtains
If a mirror or input lane is clamped because the user is in a sensitive path, the shell should say so directly:
- `mirror redacted`
- `input blocked`
- `secure field`
- `trusted chooser`
- `secure review`
- `policy denied`

The curtain should make it hard to confuse `automation used to be available` with `automation is available here right now`.

### 5. Quality-honest accessibility chrome
Steal from semantic shells and focus-aware terminals, but keep quality chips visible:
- `rich room truth`
- `semantic only`
- `mirror only`
- `prompt-local hints`
- `none`

That lets the shell become delightful without pretending to know the entire UI world perfectly.

## Guardrail
Mirror strips, lease chips, rehearsal rails, and secure-entry curtains are explanation and control chrome.
They are not themselves authority, and they must not silently widen a room into global observation or injection power.
