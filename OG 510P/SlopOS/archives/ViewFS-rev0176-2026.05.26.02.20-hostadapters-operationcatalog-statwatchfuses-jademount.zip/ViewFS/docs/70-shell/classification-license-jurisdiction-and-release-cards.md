# Classification, license, jurisdiction, and release cards

The shell should make compliance posture visible without converting it into authority.

## Card lanes

| Card lane | Shows | Must not imply |
|---|---|---|
| Classification card | mark, classifier, epoch, conflict state, scope | read/disclose/export authority |
| License card | permissions, prohibitions, obligations, accepted terms | possession, training right, publication authority |
| Jurisdiction card | source realm, destination, route epoch, export-control posture | egress authority or legal clearance by label |
| Purpose card | requested purpose, allowed purposes, secondary-use posture, retention budget | processing authority |
| Release card | review cut, redaction view, obligations, publish handle | future unrestricted redistribution |
| Compliance card | compact summary of all above | live authority unless backed by visible handle slots |

## UI posture

Cards should use three explicit verbs: **blocks**, **requires**, and **permits-with-authority**. Avoid vague language like “safe,” “approved,” or “public” unless the card also shows the exact cut, current epoch, redaction lens, obligations, and live authority slot behind the claim.

## Bad states to show loudly

- classification conflict unresolved;
- stale classifier or stale release review;
- license permission present but obligations missing;
- export-controlled item with missing license posture;
- purpose mismatch or secondary-use denial;
- compliance card claiming clear-to-export without release review;
- public label presented as release authority.
