# Semantic derivation cards, embedding vaults, scope gates, result shades, and answer receipts

Revision 152 adds shell ideas for semantic derivation and retrieval-store hygiene.

The goal is a magical-feeling search/agent shell that still tells the truth: `found`, `matched`, `embedded`, `summarized`, `answered`, and `opened` are different states.

## Big shell promise

A user should be able to ask any semantic result:

- What source snapshot did you derive from?
- Which parser/OCR/model/chunker/redaction profile did you use?
- Where is the derived artifact stored?
- What authority scope was searched?
- What content is safe to render here?
- Does this answer card carry a live source handle or only a citation/receipt?
- Will this row persist into future agent memory?
- What does `forget` or `unindex` actually remove?

## UI pieces worth stealing

### Semantic derivation cards

A derivation card shows the input and machinery:

```text
semantic derivation
intent: embed + summarize
source: O-42 @ rev 7, pages 3-5
state: quarantined-derived, no source back-write
profile: embed-model E, chunker C, redaction lens R
output: derived artifact D-91 + vector rows V-91.*
live source handle: absent
```

The important rule: the card is not a handle. It explains how a derived artifact was made.

### Embedding vaults

An embedding vault badge says where vectors live and who can query them:

```text
embedding vault
scope: project-local
hit/miss visibility: same-project only
retention: until project close or explicit unindex
cross-principal query: denied
source-open authority: separate
```

Other vault labels:

```text
room-local        disappears with room unless promoted
disposable        safe-open-only, no host persistence
tenant            shard/namespace scoped
provider-opaque   membership hidden
public corpus     publication/export cut required
receipt-only      old derivation proof, not queryable
```

### Scope gates

Before a search runs, show the authority boundary:

```text
semantic search scope
roots: current room + imported bundle B-4
excluded: quarantined bytes, secret slots, history-only receipts
filters: type=pdf, tag=manual
filter role: refinement, not access control
```

If the scope comes from a stale receipt or old smart-folder recipe, show a repair/reconsent rail.

### Model-profile chips

Result cards should say why a match is shaped this way:

```text
profile chips
embedding: text-embed-v5 / 1024d
chunker: paragraph+window-2
oCR: disabled
redaction: emails masked before embed
profile freshness: current
```

If the profile is stale:

```text
profile freshness: stale
reason: redaction lens changed
options: use old result | rederive | hide snippets
```

### Result shades

A result row should show its rendering class:

```text
result shade: metadata-only
reason: source quarantined; derived match exists
open: explicit safe-open required
```

Other shades:

```text
snippet allowed      rendered under redaction lens
thumbnail allowed    derived artifact render, not source open
quote allowed        answer-support quote only
open required        no ambient preview
answer-only          no live source handle
omitted              matching field hidden by policy
```

### Answer receipts

An answer receipt names the support path:

```text
answer receipt
query: Q-88
scope: room root R + portal import I-3
used projections: P-12, P-14, P-19
source handles granted to answer card: none
suggested action: plan-only
retrieved instructions: inert content
```

Clicking the answer should reveal citations and open-request buttons, not secretly open all sources.

### Instruction quarantine rails

Retrieved content often contains imperative text. Make it loud:

```text
retrieved instruction rail
text says: "run this setup script"
status: content, not command
adoption path: prepare action -> review -> approve -> run
```

No RAG hit should jump straight to command execution, secret request, export, or namespace mutation.

### Memory shutters

Every derived artifact/result/answer should show future persistence:

```text
memory shutter: receipt-only
future retrieval: no
agent memory: no
transcript: redacted summary only
```

Other shutters:

```text
do-not-persist
room-local
project-local
provider-memory
explicit-exportable
public
```

### Unindex ladders

Delete/forget UX must be precise:

```text
forget ladder
[ ] hide result card
[ ] remove vector rows
[ ] delete derived artifact
[ ] clear answer cache
[ ] delete source object
[ ] request provider cleanup proof
```

The ladder prevents the fake promise `deleted from search` from meaning `the object is gone everywhere`.

## Command sketches

Do not freeze syntax, but preserve shape:

```text
viewfs derive explain <derived-or-result>
viewfs semantic scope --show
viewfs search --scope current-room --no-history-memory "diagram of leases"
viewfs embed add <object> --vault project --redact emails --receipt
viewfs result shade <result-id>
viewfs answer explain <answer-card>
viewfs memory shutter <answer-card> --receipt-only
viewfs unindex <source-or-derived> --show-ladder
viewfs rederive <source> --because profile-stale
```

## Protocol metadata candidates

Future shell/terminal metadata should keep lanes explicit:

```text
viewfs.semantic.intent=parse|ocr|thumbnail|summarize|classify|tag|embed|chunk|transcribe|answer-support
viewfs.semantic.source_snapshot=current|revision|range|derived|provider-local|history-only|omitted
viewfs.semantic.profile=current|stale|unknown|redacted|provider-opaque
viewfs.semantic.artifact=source|derived-artifact|provider-row|cache-row|answer-card|receipt-only
viewfs.semantic.vault=none|room|project|tenant|provider-opaque|disposable|public|history-only
viewfs.semantic.query_scope=current-handles|room-root|workspace|portal-import|public-corpus|history-only|omitted
viewfs.semantic.filter_role=refinement|ranking|acl-adjunct|unsafe-alone|unknown
viewfs.semantic.result_shade=metadata-only|snippet|thumbnail|quote|answer-only|open-required|omitted
viewfs.semantic.live_authority=source-handle|derived-handle|borrow|proxy|absent|receipt-only
viewfs.semantic.memory=do-not-persist|receipt-only|room|project|provider|exportable|public
```

## Guardrails

- No global semantic search button without a scope gate.
- No vector hit that opens a source.
- No metadata filter treated as the whole security boundary.
- No embedding or summary treated as safe by default.
- No snippet/thumbnail/answer quote rendered without a projection policy.
- No source-object semantic back-write for risky derived content.
- No retrieved instruction executed without a separate plan/approval/action lane.
- No old answer card used as future agent memory unless memory shutter says so.
- No `forget` button without saying which source, derived, index, cache, answer, receipt, or provider rows it affects.
