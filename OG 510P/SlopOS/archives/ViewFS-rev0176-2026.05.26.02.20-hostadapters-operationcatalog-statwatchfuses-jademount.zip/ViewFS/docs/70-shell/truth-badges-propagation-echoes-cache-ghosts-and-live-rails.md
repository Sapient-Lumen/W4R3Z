# Truth badges, propagation echoes, cache ghosts, and live rails

Steal from current SlopOS boundary posture plus Amazon S3 strong-consistency docs, Google Cloud Storage consistency docs, RFC 9111 HTTP caching, and RFC 9211 Cache-Status.

Whenever the shell renders one object/publication/history row, it should be able to show:
- whether it is talking about one **committed object** or only a **history row**,
- whether one **truth badge** says `origin current`, `origin deleted`, `history only`, or `unknown`,
- whether one **propagation echo** says `grant pending`, `revoke settling`, `config propagating`, `provider hidden`, or `history only`,
- whether one **cache ghost** says `publicly cacheable`, `stale maybe`, `purge asked`, `cache bypassed`, or `history only`,
- whether one **trail drawer** can show `hit`, `miss`, `forward`, `ttl`, `stored`, or `detail` facts,
- whether a **live rail** is actually present now.

Why this is great:
- publication and revocation become inspectable without pretending caches obey authority instantly;
- cache hits stop masquerading as object truth or permission truth;
- origin truth, propagation truth, cache truth, and current live authority can all stay honest at once.

Guardrail:
- never let one cache ghost, cache hit, purge request, or old revocation receipt impersonate committed-object truth, current permission truth, or current live authority.
