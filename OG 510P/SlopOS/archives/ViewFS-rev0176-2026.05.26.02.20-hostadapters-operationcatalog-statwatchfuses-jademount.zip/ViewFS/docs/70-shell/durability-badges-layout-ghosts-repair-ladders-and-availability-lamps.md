# Durability badges, layout ghosts, repair ladders, availability lamps, and live rails

Steal from current SlopOS artifact / CapStore posture plus Ceph placement and scrubbing, Tahoe-LAFS share thresholds, and Amazon S3 replication-status honesty.

Whenever the shell renders one object/storage/history row, it should be able to show:
- whether it is talking about one **committed object** or only a **history row**,
- whether one **durability badge** says `single copy`, `replica target`, `k-of-n target`, `policy hidden`, or `unknown`,
- whether one **layout ghost** says `shares placed`, `replicas spread`, `layout hidden`, `placement changed`, or `history only`,
- whether one **repair ladder** says `healthy`, `scrubbing`, `degraded`, `repairing`, `failed`, or `history only`,
- whether one **availability lamp** says `retrievable`, `retrievable with degradation`, `provider unavailable`, `unrecoverable`, or `history only`,
- whether a **live rail** is actually present now.

Why this is great:
- durable storage becomes delightful without lying about whether the current protection target is actually healthy;
- operator/provider repair work becomes explainable instead of spooky;
- degraded-but-still-readable objects stop masquerading as lost objects or perfect objects;
- the shell can stay luxurious while telling the truth about durability intent, physical layout, repair posture, availability now, and current authority.

Guardrail:
- never let one old repair receipt, replication-status row, or placement snapshot impersonate current live authority or durable object identity.
