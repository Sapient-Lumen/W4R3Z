# Intent lamps, retry braids, sameness chips, and not-the-same-request shutters

The future ViewFS shell should make one more retry truth visible:
**a sameness witness is not a provider ticket, a duplicate replay is not a fresh settlement, and a replay-safe retry is not permission to silently retarget a changed draft.**

## Use four separate chrome families

### 1. Intent lamps
Show what the shell knows about sameness posture:
- `fresh intent`
- `same-intent retry`
- `payload changed`
- `key pruned`
- `no key`
- `unknown`

These belong near the initiating command block or route card.
They are sameness chrome, not settlement chrome.

### 2. Retry braids
Group multiple attempts that belong to one sameness witness:
- first attempt
- replay after timeout
- duplicate while first still pending
- replay after later settlement
- fresh attempt with new key

A retry braid should make lineage obvious without implying one provider run or one final result.

### 3. Sameness chips
Before resubmission, open a chip/drawer that says whether the current payload is still the same canonical request:
- `same canonical payload`
- `changed basis only`
- `changed payload`
- `cannot prove sameness`

This is the luxury move.
It lets the shell stop users from accidentally smuggling edits under an old dedupe key.

### 4. Not-the-same-request shutters
When the current draft no longer matches the original intent witness, say so bluntly.
Do not quietly reuse the old key.
Show:
- `fresh key required`
- `retry would mismatch`
- `original key pruned`
- `concurrent duplicate still running`

## Provider follow-up still stays separate
Even with all of that, keep **operation beads**, **settle rails**, and **adopt rails** separate.
A single glyph should never have to mean all of these at once:
- same-intent retry
- accepted request
- provider operation exists
- settled result exists
- local room adopted it

## Why this is super awesome instead of bureaucratic
Because it lets the shell be magical *without lying*.
A luxurious shell can:
- retry safely after a connection glitch,
- keep the current draft visible,
- group attempts under one retry braid,
- warn when the current payload drifted,
- and then show whether the provider replayed the original outcome, rejected the mismatch, or settled something new.

That feels dramatically better than today's mix of ambiguous retry buttons, accidental double-submits, and hidden dedupe folklore.

## Nice shell moves worth stealing
- **intent lamps** from HTTP idempotency-key and SlopOS request-key humility.
- **retry braids** from exact-request lineage rather than vague spinners.
- **sameness chips** from parameter/fingerprint comparison instead of payload guessing.
- **not-the-same-request shutters** from AWS/Stripe fail-closed mismatch behavior.
- **dedupe-afterglow** that says `replayed prior result` instead of pretending a new provider run happened.

## Guardrails
- Do not let an old key masquerade as current object identity.
- Do not let a same-intent retry silently carry a different payload.
- Do not let a duplicate replay masquerade as a fresh successful settlement.
- Do not let receipts revive expired or pruned sameness witnesses.

## One narrow prototype
Prototype just this:
- one command block submits a provider-backed change,
- one intent lamp appears immediately,
- one retry braid can show later attempts,
- one sameness chip compares the current payload to the original,
- one shutter stops old-key reuse when the payload drifted.

If that feels magical and honest, the larger ViewFS import/publish/pushback stories are probably on the right track.
