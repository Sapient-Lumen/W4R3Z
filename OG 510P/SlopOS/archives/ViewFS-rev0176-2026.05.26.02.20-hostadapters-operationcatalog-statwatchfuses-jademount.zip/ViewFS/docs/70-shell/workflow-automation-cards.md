# Workflow automation cards

Workflow cards should make automation state visible without implying authority.

## Card slots

- **Event**: source, type, subject, schema validity, and source trust state.
- **Trigger**: rule id, rule epoch, matched event type, and scope summary.
- **Schedule**: not-before, not-after, approval-cut status, and next revalidation point.
- **Run**: basis epoch, lease state, approval cut, and current step.
- **Step**: target authority delta, required right, and whether target handle is still live.
- **Retry**: attempt count, backoff, budget posture, and duplicate suppression state.
- **Human task**: assignee, trusted-path posture, approval cut, and privacy redactions.
- **Compensation**: reversible/not reversible, approval state, and what remains in history.

## Forbidden badges

- `will run` unless a schedule and all run preconditions are current;
- `approved` when the task only has a row or click without trusted path;
- `completed` when only a step receipt or workflow card says so;
- `safe retry` when idempotency, budget, and target authority have not been rechecked;
- `undo` when the compensation plan only creates a new counter-effect and cannot erase history.
