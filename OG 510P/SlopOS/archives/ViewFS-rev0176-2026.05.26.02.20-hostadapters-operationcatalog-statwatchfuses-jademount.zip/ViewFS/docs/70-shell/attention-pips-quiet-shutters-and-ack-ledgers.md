# Attention pips, quiet shutters, and ack ledgers

The future custom shell can feel luxurious here **without** lying.
The trick is to make `live now`, `wants attention`, `may interrupt strongly`, `currently hushed`, and `still needs follow-up later` visibly different.

## Great moves
### 1. Attention pips
Every room tab or sticky header gets a tiny pip lane that can say:
- `activity`
- `bell`
- `silence`
- `follow-up unread`
- `receipt only`

That is much better than one vague badge.

### 2. Interrupt ladders
A compact ladder or badge should explain the strongest allowed surfacing:
- `badge only`
- `banner candidate`
- `urgent request`
- `urgent but clamped`
- `critical requires separate grant`
- `suppressed`

Opening the ladder should explain whether the truth came from shell policy, workspace quiet posture, portal policy, or only history.

### 3. Quiet shutters
When the current workspace or user posture is hushing alerts, the shell should say so directly:
- `focus quiet`
- `presentation quiet`
- `coalescing until foreground returns`
- `heads-up suppressed; badge kept`
- `quiet expired`

This should feel protective, not mysterious.

### 4. Ack ledgers
If something still matters after the transient cue is gone, it should land on an explicit row:
- `review needed`
- `repair finished; rebind ready`
- `helper asked for foreground`
- `background task wants attention`
- `dismissed to receipt only`

The row should explain whether the underlying room/helper is still live, stale, or gone.

### 5. Activity / bell / silence styling
Steal from tmux and go further:
- different shapes or glyphs for activity, bell, and silence
- separate style for `suppressed` versus `unseen`
- explicit counters for coalesced events instead of one screaming badge
- small `why this pip exists` drawers

## Guardrail
Attention pips, interrupt ladders, quiet shutters, and ack ledgers are explanation and control chrome.
They are not themselves authority, and they must not silently widen a room into stronger interruption or durable background presence.
