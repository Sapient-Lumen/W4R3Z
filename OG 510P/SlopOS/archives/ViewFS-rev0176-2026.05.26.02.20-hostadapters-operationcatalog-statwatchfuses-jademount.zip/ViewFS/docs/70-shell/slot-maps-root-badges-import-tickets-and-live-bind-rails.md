# Slot maps, root badges, import tickets, and live-bind rails

Revision: rev0138  
Date: 2026-05-13

## Why this shell move exists

If ViewFS becomes the user-facing datacube shell for SlopOS, it needs to make authority beautiful without making it spooky. The shell should help users see the difference between a planned launch, an actual bound namespace, a live handle slot, a portal import ticket, an adopted bind, and a receipt.

## Slot maps

A **slot map** is the child's live handle/resource table as rendered by the shell.

Show, where available:

- slot label: `0`, `1`, `2`, `fd:3`, `svc:preview`, `obj:read`, or a better local name;
- class: `stdio`, `directory`, `object`, `facet`, `service`, `ticket`, `lease`, `history`;
- rights: `inspect`, `verify`, `read`, `write`, `append`, `edit`, `publish`, `delegate`, `close`, `renew`;
- posture: `owned`, `borrowed`, `leased`, `sealed`, `provider-hidden`, `compat`;
- provenance: `plan`, `portal`, `object-store`, `provider`, `ambient-denied`, `history-only`;
- receipt link: the row that explains why the slot exists.

Guardrail: a slot map is per subject. Slot `3` in one helper is not global object `3`.

## Root badges

Every root-like thing shown to a process should get a badge such as:

- `sealed empty root`;
- `synthetic ViewFS root`;
- `object-store rooted`;
- `portal-adopted subtree`;
- `provider projection`;
- `compat membrane`;
- `history only`;
- `root denied`.

Guardrail: do not render `/` as if it were machine-global. Render it as `this subject's root`.

## Import ticket tray

Portal/import work needs its own tray because ticket state is not object state.

Good ticket states:

- `request drafted`;
- `chooser open`;
- `needs user`;
- `granted not bound`;
- `adopting`;
- `adopted to staging`;
- `adopted as live bind`;
- `committed object minted`;
- `denied`;
- `expired`;
- `revoked`;
- `history only`.

Guardrail: `granted not bound` must feel visibly weaker than `live here now`.

## Live-bind rails

The rail next to a row should answer: what can this subject do now?

Suggested rail chips:

- `inspect now`;
- `verify now`;
- `read now`;
- `edit now`;
- `publish now`;
- `delegate now`;
- `renew needed`;
- `stale witness`;
- `ticket only`;
- `receipt only`;
- `not authority`.

Guardrail: history can be gorgeous, but current authority must be unmistakable.

## Launch rehearsal card

Before a helper runs, the shell should be able to render a rehearsal card:

```text
Launch plan: thumbnailer
root: sealed empty + /in/image bound read-only
slots: stdio closed, fd:3 read-image, svc:preview-output
portal tickets: none
writes: /out/preview staging capsule
receipts: planned
status: not launched; no authority used yet
```

After launch, the card can become:

```text
Launch result: thumbnailer
root: sealed empty + /in/image bound read-only
slots delivered: exact match
live binds: /out/preview staging capsule writable by helper, readable by shell
receipts: launched, wrote preview, closed
status: completed
```

## Adoption ladder

An import should move through visible states rather than one magic `open file` action:

1. portal ticket requested;
2. user/provider grants or denies;
3. result is inspected as an external/provided thing;
4. result is adopted into a local staging capsule or live bind;
5. optional committed object is minted;
6. optional published name/bind is created;
7. receipt ties the flow together.

The ladder lets ViewFS be delightful while keeping all authority transitions auditable.

## Ambient-debt sirens

The shell should have a gentle but unmistakable warning style for operations that ask for:

- host absolute path access;
- inherited extra descriptors;
- provider session reuse as authority;
- ambient `$HOME` / `/tmp` / `/etc` assumptions;
- path strings that are not backed by a current bound root;
- stale receipts used as reopen handles.

Suggested wording: `ambient debt`, `needs explicit bind`, `not portable authority`, `compat-only`, or `review required`.

## Things we are not deciding yet

- the exact slot table serialization;
- whether the shell calls these cards, rails, chips, drawers, lenses, or badges;
- whether root badges are minted by ViewFS, SlopOS D-NS, capshell, a portal, or a future CapStore;
- whether import tickets are object-store records or provider-owned sessions;
- whether live facets are long-lived capabilities, revocable leases, docrefs, service handles, or a mix.
