# Disclosure lamps, redaction drawers, and observation cards

Revision 161 adds shell concepts for the disclosure/observation lane. These are product sketches, not final UI.

## Redaction drawer

A redaction drawer shows:

- admitted fields;
- blocked fields;
- source object;
- redaction-view status;
- backing handle, if any;
- whether this drawer is only explanatory or can be used with a live action.

The drawer must not say “safe” merely because a redaction view exists. It should say “redaction view active; live authority required for output.”

## Audit projection card

An audit projection card shows:

- redacted versus raw projection class;
- observer authority;
- raw-audit authority, if requested;
- redaction view id;
- sealed status;
- authority badge posture.

If the projection is inert history, the shell should make that obvious. A green audit card must not imply that the user can open the object behind the event.

## Disclosure package card

A disclosure package card shows:

- source;
- sink;
- payload class;
- redaction-applied status;
- approval cut;
- live export/disclosure handle;
- old receipt separation.

The most dangerous collapse is “I see a package, therefore I can send it.” The card should show a locked state when the approval cut, redaction posture, or live handle is missing.

## Subscription and notification cards

A subscription card shows scope, expiry, observe handle, payload class, and redaction posture. A notification card should default to metadata-only. If a notification contains full payload fields, it must show redaction status and should never render a silent open action.

## Subject-access card

A subject-access card shows:

- requester subject;
- matched subject;
- scope objects;
- redaction view;
- review cut;
- disclosure package;
- live subject-access/export handle.

The card should distinguish “request acknowledged,” “review approved,” “package prepared,” “redacted export ready,” and “receipt issued.” Those states are not interchangeable.
