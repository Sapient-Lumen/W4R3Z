# Root ledgers, epoch fences, restore tickets, and activation rails

Revision: 140  
Date: 2026-05-13  
Codename: rootledgers-epochfences-restorerails-ironmoss

## Shell goal

The shell should make persistent state feel powerful without making old state look magically alive.

Users should be able to see:

- this root was recorded;
- this root is the accepted tip;
- this root is only a rollback candidate;
- this durable ref needs revalidation;
- this portal anchor needs reconsent;
- this activation is only a preview;
- these exact live slots were installed now;
- this receipt is history only.

## Five visible rails

### 1. Root ledger

A root ledger shows durable commits without implying live authority:

```text
Workspace root ledger

current accepted tip:  root:workspace@epoch 92  digest b3e2…
previous candidate:    root:workspace@epoch 91  digest 9ac1…
quarantine candidate:  root:workspace@epoch 89  digest 11d0…  rollback warning
```

Rows should have badges such as:

- `recorded`
- `accepted tip`
- `rollback candidate`
- `quarantined`
- `dev rollback`
- `receipt only`

### 2. Epoch fence

An epoch fence explains currentness before activation:

```text
Fence check
  expected tip:  root@epoch 91 / digest 9ac1…
  observed tip:  root@epoch 92 / digest b3e2…
  verdict: stale candidate; preview allowed, live activation denied
```

The shell should avoid vague wording like `cannot restore`. It should say whether the issue is stale basis, unsafe rollback, provider mismatch, revoked issuer epoch, missing artifact, or policy unknown.

### 3. Restore ticket

A restore ticket is the reviewed request, not authority:

```text
Restore ticket #R-184
  actor: Johnny / workspace-manager
  purpose: inspect old room state
  candidate: root@epoch 89
  requested: read-only preview
  status: waiting for resurrection gates
```

Good states:

- `drafted`
- `reviewing`
- `fence passed`
- `stale`
- `needs reconsent`
- `preview ready`
- `activation denied`
- `activated`
- `receipt only`

### 4. Resurrection gate drawer

The gate drawer explains which dormant descriptors may become live:

```text
Dormant descriptor gates

portal-docref: proposal.md
  state: ask again
  reason: old portal grant was durable reference only

provider-object: obj:dataset.csv
  state: admit read-only
  witness: generation matches

secret-ref: api-token
  state: denied
  reason: secret provider epoch advanced
```

This is where old durable references stop pretending to be handles.

### 5. Activation rail

Activation should have a before/after rail:

```text
Before activation
  live slots: none from candidate root
  preview: read-only staging room

Will install if approved
  slot 0: root:/workspace       read/list
  slot 1: obj:proposal.md       read/edit
  slot 2: provider:dataset      read-only proxy

Will not install
  old secret handle
  revoked portal write grant
  child-launch export right
```

After activation, the shell should show the fresh live slot table and link to the receipt. If no live slots were installed, the UI should say that loudly.

## Nifty moves to steal

### Time-capsule preview

Open old roots in a distinct time-capsule room with a read-only border, no inherited ambient cwd, no hidden provider reconnection, and a banner that says whether currentness was checked.

### Resurrection siren

Show a siren when a restore flow would resurrect authority stronger than the candidate's current gates allow:

```text
Resurrection blocked: old root contains portal write anchor, but portal now requires consent.
Choices: ask again, open read-only copy, keep receipt only.
```

### Rollback honesty card

Whenever rollback is requested, show what goes backward and what does not:

```text
Rollback preview
  object root: epoch 92 -> epoch 89
  portal grants: not rolled back
  issuer revocation epochs: not rolled back
  key provider policy: not rolled back
  receipts: preserved
```

### Live-after-restore slot map

A restore operation should end with a slot map, not just a success toast:

```text
Activated root@epoch 92 into room Alpha
  slot 0 root:/workspace      live read/list/edit
  slot 1 obj:notes.md         live read/edit
  slot 2 docref:budget.xlsx   needs reconsent; not live
```

### Receipt-only ghost

Old authority that cannot revive should remain inspectable as a ghost row:

```text
Old write grant to dataset.csv
  state: receipt only
  lived: 2026-05-12 10:14–10:31
  current power: none
  reason: issuer epoch advanced
```

## Protocol hints, not a protocol

Future terminal/shell events could reserve names like:

- `viewfs.root_commit.recorded`
- `viewfs.root_tip.fence_check`
- `viewfs.restore.intent`
- `viewfs.restore.resurrection_gate`
- `viewfs.restore.activation_preview`
- `viewfs.restore.activation_commit`
- `viewfs.restore.live_slot_map`
- `viewfs.restore.receipt`

Candidate fields:

```text
root_scope
root_commit_digest
parent_commit_digest
candidate_epoch
last_seen_epoch
witness_family
witness_summary
restore_intent_id
resurrection_gate_id
activation_target_id
activation_mode
live_slot_digest
live_slot_count
verdict
unsafe_rollback_profile
receipt_digest
redaction_level
```

The event stream must not expose raw capability tokens, raw provider secrets, or stable provider IDs unless a later policy explicitly allows that narrow developer surface.

## Good demo scenarios

1. Record a root commit and prove it does not create a live handle.
2. Try to activate an old root with a stale epoch and show the fence failure.
3. Open a read-only time capsule from an old root.
4. Restore a root that contains a portal docref; ask for fresh consent before installing a write handle.
5. Restore a root whose key/secret reference no longer admits unwrapping; keep a receipt-only ghost.
6. Activate a repaired root and show the exact live slot map.
7. Enable a developer rollback profile and make the warning impossible to miss.

## UI warnings

- Do not show old root commits in the same color/weight as live roots.
- Do not call a restore ticket `access`.
- Do not use `success` unless live slots were actually installed or the exact weaker result is named.
- Do not let a receipt card have an `open` button unless it routes through a fresh restore intent/gate.
- Do not hide stale/rollback/currentness errors under generic provider failure.
- Do not resurrect secret/key handles from stored refs without current provider participation.
- Do not make rollback look like it rolls back issuer revocation, portal consent, or provider policy.
