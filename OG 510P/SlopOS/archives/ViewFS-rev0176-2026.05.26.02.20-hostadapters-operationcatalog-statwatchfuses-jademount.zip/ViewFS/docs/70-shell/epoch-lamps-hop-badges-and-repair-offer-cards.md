# Epoch lamps, hop badges, and repair-offer cards

A future custom shell+terminal can feel incredibly rich here **without** lying.
The trick is to treat current authority, provider currentness, shell semantic footing, and the next suggested repair move as different visible layers.

## Epoch lamps
Every pane or room header should be able to show a tiny epoch lamp:
- `same epoch`
- `epoch shifted`
- `hop changed`
- `semantic footing downgraded`
- `receipt only`

The lamp is not about wall-clock time.
It is about whether the shell still believes that old anchors, cwd claims, completion fit, and command-block affordances belong to the same semantic world.

## Hop badges
A tiny hop strip should tell the truth about the current path:
- `local`
- `tmux`
- `ssh`
- `nested shell`
- `remote cwd exact`
- `remote cwd approximate`
- `markers degraded`

This should feel luxurious, not scary.
The win is that current room truth stops getting confused with one flat PTY fantasy.

## Currentness drawers
A current bind or imported object should be able to surface a drawer with rows like:
- `live bind now`
- `currentness witness`
- `issuer/provider`
- `semantic epoch`
- `repair offer available`
- `receipt history`

That lets the shell explain why something is actionable, dimmed, or blocked **without** pretending the object disappeared.

## Repair-offer cards
Repair offers should be small cards with brutally honest labels such as:
- `refresh witness only`
- `revalidate before stop`
- `reconsent via portal`
- `rebind from durable anchor`
- `make local instead`
- `rerun clean in fresh room`
- `dismiss to receipt only`

Each card should answer:
- what exact class of move this is,
- what it will consume or consult,
- whether it may widen authority,
- whether it changes the semantic epoch,
- and what receipt will be left behind.

## Command blocks should carry epoch truth
Command-finished affordances, scroll-to-prompt actions, sticky headers, and right-status chrome should all know:
- which semantic epoch they belong to,
- which hop path they belong to,
- whether the target anchor is still exact,
- and whether any action now crosses a stronger stale fence.

That means old blocks can gracefully dim into:
- `older epoch`
- `same output, weaker control`
- `receipt only`
- `rerun clean available`

## Offer rails should prefer exact anchors over text scraping
If the shell has an exact target anchor for a room bind, receipt, command block, or stale shadow, it should use that.
Text scraping should be a fallback.
The nicest UX move is not more AI guessing.
It is better exact anchors plus better stale honesty.

## Great pairings to steal
- **Steward semantic epochs + hop lineage** for stale-footing honesty.
- **WezTerm semantic zones** for prompt/input/output structure.
- **Ghostty command-finished + palette ideas** for low-friction action chrome.
- **Nushell overlays** for explicit layer activation.
- **Schell anchor-death cards** so old exact action points die honestly.

## A few especially good luxury moves
- **epoch lamps** in room tabs and sticky command headers
- **hop badges** that travel with command blocks and receipts
- **repair-offer rails** that appear inline next to stale shadows or older-epoch anchors
- **currentness shutters** that tell you whether the block is live/actionable, live-but-revalidate, or receipt only
- **reset-scope chips** whenever shell mode or hop path changed enough that old affordances should downshift
- **why-not-now drawers** that explain whether the block is blocked by provider currentness, semantic epoch drift, or both

This is one of the best low-regret places to be ambitious, because it freezes honesty and delight rather than one final object-store or witness schema.
