# Summon beacons, front latches, and secure-entry shutters

The future custom shell can feel luxurious here **without** lying.
The trick is to make `live now`, `wants surfacing`, `may try to raise`, `actually frontmost`, and `trusted-entry active` visibly different.

## Great moves
### 1. Summon beacons
Every room tab or sticky header gets a tiny beacon lane that can say:
- `glance me`
- `result ready`
- `review wants front`
- `helper wants eyes`
- `receipt only`

That is much better than one vague “active” glow.

### 2. Activation baton chips
A compact chip should explain the current raise/focus eligibility:
- `fresh baton`
- `forwarded`
- `consumed`
- `expired`
- `invalid`
- `none`

Opening the chip should explain whether the truth came from a recent click, a route action, a host handoff, or only history.

### 3. Front latches
When the shell really knows what is frontmost, it should say so directly:
- `frontmost`
- `focused`
- `raise requested`
- `declined`
- `stolen back`
- `background only`

This should feel crisp, not theatrical.

### 4. Secure-entry shutters
If the user is in a higher-trust input path, the shell should say so clearly:
- `trusted chooser`
- `secure review`
- `host-secure mode`
- `not a trusted surface`
- `policy denied`

The shutter should make it hard to confuse large/focused chrome with trusted approval/login semantics.

### 5. Focus-aware but quality-honest polish
Steal from xterm focus events and modern shell integration, but keep quality chips visible:
- `rich focus truth`
- `approximate focus truth`
- `prompt-only focus hints`
- `no focus metadata`

That makes delightful chrome compatible with honesty.

## Guardrail
Summon beacons, activation baton chips, front latches, and secure-entry shutters are explanation and control chrome.
They are not themselves authority, and they must not silently widen a room into stronger foreground or trusted-entry power.
