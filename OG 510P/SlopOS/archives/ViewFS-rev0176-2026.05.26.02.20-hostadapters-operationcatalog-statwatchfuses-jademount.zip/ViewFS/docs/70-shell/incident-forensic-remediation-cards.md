# Incident, forensic, remediation, rollback, and postmortem cards

Incident-response shell cards must make authority posture visible without converting response artifacts into authority.

## Card families

| Card | Must show | Must not claim |
|---|---|---|
| Alert card | detector, subject, active/stale state, severity, evidence pointer, observe authority posture | compromise proven, file readable, containment approved |
| Incident case card | case id, subject, active alert, handler, status, allowed next cuts | remediation authority, disclosure authority, incident closure |
| Triage card | verdict, confidence, evidence chain, uncertainty, recommended lane | execution, deletion, containment, policy truth |
| Forensic snapshot card | sealed state, capture authority, redaction view, fields rendered, chain link | live access, raw disclosure, global truth |
| Evidence chain card | digest, completeness, tamper-evident status, missing facts, verification handle | causal proof, source authority, unredacted evidence access |
| Containment card | approved effects, blast radius, steward, live containment handle | broad authority, hidden effects, future permission |
| Remediation card | preconditions, approval cut, live repair handle, rollback dependency | closure, receipt replay, unchecked repair |
| Rollback card | base/current epoch, approval, rollback handle, evidence retention warning | erasure of history, purge of evidence, stale rollback safety |
| Postmortem card | redacted timeline, lessons, residual risks, owners, recurrence warnings | no recurrence guaranteed, public release authority, live access |

## Shell posture

The UI should render incident response as a sequence of cuts, not as a single magic ticket. An alert can lead to a case; a case can lead to triage; triage can lead to containment; containment can lead to remediation; remediation can lead to recovery and postmortem. Each step needs its own authority, evidence, and stale-brake posture.
