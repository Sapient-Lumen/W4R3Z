# Renewal lamps, retry clocks, and repair gates

A future custom shell+terminal can feel incredibly rich here **without** lying.
The trick is to treat current authority, provider currentness, keepalive/renewal budget, retry timing, and quieting/repair posture as different visible layers.

## Renewal lamps
Every pane or room header should be able to show a tiny renewal lamp:
- `renewed through 14:03`
- `renewal due soon`
- `renewal missed`
- `grace window active`
- `renewal unsupported`
- `receipt only`

The lamp is not about generic uptime.
It is about whether one exact live claim is still being kept warm, is about to cool, or has already fallen out of its renewal story.

## Retry clocks
A tiny retry strip should tell the truth about timing:
- `retry after 12s`
- `try again at 14:03:12`
- `still processing`
- `pushback active`
- `retry advice unavailable`
- `hint expired`

This should feel luxurious, not bureaucratic.
The win is that the shell stops encouraging blind reruns when it already knows the next exact follow-up is premature.

## Repair-gate cards
Repair gates should be small cards with brutally honest labels such as:
- `cooling down`
- `repair required`
- `manual clear required`
- `healthy run reset window`
- `stop auto-renewing`
- `rerun clean in fresh room`
- `dismiss to receipt only`

Each card should answer:
- what exact class of repeated miss or repeated failure triggered it,
- whether the shell is merely waiting or has stopped automatic help,
- what exact clear/repair action is available,
- and what receipt will be left behind.

## Currentness drawers should gain time truth
A current bind or imported object should be able to surface a drawer with rows like:
- `live bind now`
- `currentness witness`
- `renewal window`
- `retry advice`
- `repair gate`
- `receipt history`

That lets the shell explain whether a thing is:
- live and fresh,
- live but due soon,
- live but waiting,
- stale but repairable,
- or receipt only.

## Command blocks should carry retry/gate truth
Command-finished affordances, sticky headers, right-status chrome, and inline rerun buttons should all know:
- whether the block belongs to a current semantic epoch,
- whether the associated bind is still current,
- whether one renewal budget is live,
- whether a retry clock is active,
- and whether a repair gate has downshifted the UX.

That means old blocks can gracefully dim into:
- `wait until 14:03`,
- `renew first`,
- `cooling down`,
- `manual clear required`,
- `receipt only`.

## Exact auto-help beats flattering loops
If the shell has an exact renewal action, exact witness refresh, or exact clear-gate action, it should use that.
Blind rerun loops should be the fallback of last resort.
The nicest UX move is not more guessing.
It is better exact timing truth plus better quieting truth.

## Great pairings to steal
- **Steward renewal windows + retry advice + repair gates** for continuity-control honesty.
- **WezTerm semantic zones** for prompt/input/output structure.
- **VS Code shell-integration quality badges** for visible confidence classes.
- **fish autosuggestions** for suggestions that remain inert until accepted.
- **Nushell overlays** for explicit layer activation/deactivation.
- **Ghostty prompt-local click handling and shell integration** for prompt-aware actions that still stay visible.

## A few especially good luxury moves
- **renewal lamps** in room tabs and sticky command headers
- **retry clocks** inline next to rerun, rebind, or reconsent affordances
- **gate cards** that explain why automatic help stopped
- **cooldown shutters** that tell you whether the thing is waiting, warming, or blocked
- **repair receipts** that explain whether a clear happened, a renewal succeeded, or a retry hint expired
- **why-not-now drawers** that separate provider currentness, retry timing, and repair gates instead of one vague `not available`

This is another excellent low-regret place to be ambitious, because it freezes honesty and delight rather than one final object-store, lease, or automation schema.
