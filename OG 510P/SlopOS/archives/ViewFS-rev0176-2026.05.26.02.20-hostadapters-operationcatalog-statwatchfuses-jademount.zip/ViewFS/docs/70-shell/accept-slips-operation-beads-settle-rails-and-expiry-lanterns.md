# Accept slips, operation beads, settle rails, and expiry lanterns

The future ViewFS shell should make one more continuity truth visible:
**an admitted request is not a finished result, an operation bead is not the object, and a settled provider verdict is still not the same thing as local adoption.**

## Use three separate chrome families

### 1. Accept slips
Show what happened at submission time:
- `rejected now`
- `accepted`
- `accepted + ticket`
- `accepted, follow-up unknown`

These belong near the initiating command block or route card.
They are admission chrome, not completion chrome.

### 2. Operation beads
Show any bounded provider-owned follow-up lane:
- `pollable`
- `queued`
- `provider job`
- `expiring soon`
- `lost handle`

An operation bead should open a drawer with:
- provider/ticket identity (if any)
- last observed state
- freshness age
- next recommended check action
- retention/expiry hints

### 3. Settle rails
Show later settlement truth separately:
- `pending`
- `settled: applied`
- `settled: conflict`
- `settled: superseded`
- `settled: unknown`
- `history only`

This is where the shell should stop flattering the user.
If a provider has not answered yet, say so.
If the status reference expired, say so.
If the operation settled elsewhere but this room has not adopted it, say so.

## Local adoption stays a fourth thing
After settlement, keep a separate **adopt rail**:
- `keep draft`
- `fast-forward here`
- `fork local`
- `adopt successor`
- `receipt only`

That prevents one remote green check from silently trampling local footing.

## Why this is super awesome instead of bureaucratic
Because it lets the shell be magical *without lying*.
A luxurious shell can:
- submit one provider-backed action instantly,
- keep editing locally while the provider works,
- show a tiny operation bead with age/freshness,
- surface a settle rail when the provider answers,
- and let the human choose local adoption with one explicit rail.

That feels dramatically better than today's mix of hidden background work, ambiguous spinners, and vague `saved` toast.

## Nice shell moves worth stealing
- **accept slips** from HTTP-202 / request-object humility.
- **operation beads** from long-running-operation resources and status endpoints.
- **expiry lanterns** from finite retention / expiring operation references.
- **settle rails** that compare `admitted`, `pending`, `settled`, and `history only`.
- **double-green avoidance**: never show the same glyph for `accepted` and `completed`.
- **local-adopt afterglow**: after a settlement, highlight whether the room fast-forwarded, kept a draft, or forked.

## Guardrails
- Do not let an old operation bead masquerade as current completion truth.
- Do not let a settled provider result silently rewrite a current draft.
- Do not treat `accepted` as permission to stop showing uncertainty.
- Do not let receipts revive expired provider-owned state.

## One narrow prototype
Prototype just this:
- one command block submits a provider-backed change,
- one accept slip appears immediately,
- one operation bead can be polled or aged,
- one settle rail appears later,
- one adopt rail chooses what this room becomes.

If that feels magical and honest, the larger ViewFS async/import/publish stories are probably on the right track.

