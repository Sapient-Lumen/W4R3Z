# Payer chips, spend rails, charge ghosts, and burn ladders

Purpose: make sponsorship and cost posture luxurious without lying.

The future custom shell should be able to say six different things clearly:
1. **you may do this**
2. **this sponsor would pay**
3. **a bounded budget lease exists**
4. **spend has or has not been reserved yet**
5. **the provider actually charged someone (or refused)**
6. **all that remains is receipt/history**

Those are not the same truth and should not share one vague `allowed / paid` badge.

## Great moves

### Payer chips
Every provider-backed action card should be able to show:
- `requester pays`
- `owner pays`
- `server budget`
- `explicit sponsor`
- `unknown sponsor`
- `history only`

Clicking the chip should reveal whether the payer came from an explicit user choice, a delegated budget lease, or a provider-owned fallback.

### Spend rails
Actions that may consume metered resources should show:
- `no spend lane`
- `budget present`
- `reserved`
- `partially spent`
- `charged`
- `charge rejected`
- `provider absorbed`
- `history only`

This is much better than one generic `done` checkmark.

### Burn ladders
Whenever the user is about to trigger expensive import/export/hydration work, the shell should offer visibly different acts:
- `preview cost`
- `reserve`
- `commit spend`
- `retry with same sponsor`
- `switch payer`
- `keep receipt only`

That is the luxury version of honest cost UX.

### Charge ghosts
If a past action already charged a sponsor, the shell should keep that as a ghost:
- visible in history and receipts,
- searchable by sponsor/object/action,
- never silently revived as current budget or current authority.

### Sponsored-by drawers
Steal from good billing and job-control UX.
The shell should be able to open a small drawer that says:
- who paid,
- why that sponsor was selected,
- what exact budget lease bounded the action,
- whether the provider actually honored that sponsor choice,
- and whether later retries are still same-sponsor or require a fresh decision.

## Why this would feel super awesome
This is the kind of shell chrome that feels extremely high-end:
- it makes expensive operations legible before commitment;
- it stops `ability` from impersonating `budget`;
- it makes cross-account/provider-backed actions explainable;
- and it keeps receipts useful long after a live budget lease is gone.

## Guardrails
- never let `authorized` impersonate `funded`.
- never let `budget present` impersonate `charge already landed`.
- never let one old charge receipt revive a live sponsor.
- never let provider fallback billing hide behind a generic success badge.
