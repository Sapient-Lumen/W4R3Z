# SBOM drawers, locator chips, VEX shutters, admission cuts, and live rails

Revision 144 adds shell ideas for supply-chain evidence without inventing a magical **trusted package** badge. The shell should make evidence delightful to inspect while preserving the distinction between evidence, local admission, activation, live authority, and receipts.

## Main affordances

### SBOM drawer

A side drawer for inventory evidence:

- subject digest and subject kind;
- source: vendor, build pipeline, local scanner, imported sidecar, synthesized bundle, or unknown;
- format: SPDX, CycloneDX, SlopOS CH-SBOM, scanner-native, or unknown;
- composition/completeness state: complete, incomplete, partial, unknown, redacted, stale, conflicting;
- component count, services count, dependency edges, external references, and omitted/redacted count;
- evidence binding: exact subject digest, container-level, member-level, deployment-level, or ambiguous.

The drawer should say **inventory claim**, not **truth**.

### Locator chip rail

A row of chips under a component or artifact:

```text
[purl: npm/foo@1.2.3 · ecosystem-local]
[CPE: cpe:2.3:a:vendor:foo:* · broad]
[bom-ref: lib-foo · document-local]
[SPDXID: SPDXRef-Package-foo · document-local]
[OSV: npm/foo · advisory-match]
[digest: sha256:... · exact]
```

Chips can be `exact`, `strong`, `ambiguous`, `document-local`, `ecosystem-local`, `broad`, `unmatched`, or `redacted`. They should not be clickable fetch authority unless a separate portal/import action creates a reviewed request.

### VEX shutter

A shutter that separates vulnerability state from local admission:

- `affected`: evidence says the subject/component is affected;
- `not_affected`: scoped VEX statement with justification/impact statement;
- `fixed`: statement names fixed version/build/range;
- `under_investigation`: explicitly not a clearance;
- `no_statement`: no VEX basis;
- `conflict`: multiple statements disagree;
- `expired/stale`: statement freshness policy failed.

The shutter should expose **why this did or did not change the admission verdict**.

### Provenance stack

A vertical stack for evidence layers:

```text
signature verified?        yes/no/unknown
transparency inclusion?    logged/absent/unavailable
provenance predicate?      SLSA/in-toto/unknown
builder identity?          shown/redacted/untrusted
TUF/update freshness?      current/stale/unknown
reproducibility note?      present/absent/unverified
```

Every row says **evidence** or **unverified evidence**, never **authority**.

### Admission cut card

A compact card that names the local policy decision:

```text
Admission cut: profile.dev-tools / epoch 2026-05-15T14:36-04:00
Subject: sha256:...
Request: install helper into workspace tools shelf
Verdict: test sandbox only
Caveats: no network, safe-open docs only, recheck after advisory feed update
Receipt: rec:...
```

This is the first shell object that can say `allow` or `deny`, and it must always name action and target.

### Activation rail

A rail that shows lifecycle without collapse:

```text
artifact selected -> evidence inspected -> admission cut -> activation target -> live facet -> receipt
```

If the user is at `evidence inspected`, the rail must not look like activation already happened. If a live facet dies, the rail must not leave a green state behind.

## Commands to prototype

```text
viewfs supply inspect <object>
viewfs supply inventory <object> --claims
viewfs supply locators <object> --explain-matches
viewfs supply advisories <object> --vex
viewfs supply verify <object> --policy <cut>
viewfs supply admit <object> --mode safe-open|read-only|test-sandbox|install|activate
viewfs supply rehearse <object> --target <target>
viewfs supply activate <object> --verdict <verdict-ref> --target <target>
viewfs supply receipts <object>
```

Possible terminal events:

```text
viewfs.supply.inventory_claims.loaded
viewfs.supply.locator_aliases.normalized
viewfs.supply.advisory_view.updated
viewfs.supply.evidence_pack.verified
viewfs.supply.admission_verdict.issued
viewfs.supply.activation.rehearsed
viewfs.supply.live_facet.created
viewfs.supply.receipt.written
```

## Warning phrases the shell should use

- **Signed, not admitted**
- **Logged, not approved**
- **Inventory present, completeness unknown**
- **VEX says not affected for this scope only**
- **Locator alias is ambiguous**
- **Document-local ID, not object identity**
- **Old receipt, recheck needed**
- **Safe-open only; no execution handle**
- **Activation target differs from admitted target**

## Delight moves

- A **why admitted?** drawer that highlights the exact evidence rows and policy clauses used.
- A **why not executable?** ladder that offers safe-open, read-only inspect, test sandbox, or fetch-missing-evidence actions without granting ambient authority.
- A **locator ambiguity lens** that shows when two ecosystems share a name or when a purl/CPE match is broad.
- A **VEX diff rail** that compares old and new exploitability statements without treating supersession as automatic.
- A **provenance replay bead** that explains build/source/builder claims and which checks are missing.
- A **restore recheck lamp** that lights when a durable root is restored under a new advisory/policy epoch.

## Guardrails

- No shell component may display a single unqualified `trusted` badge for supply-chain material.
- No SBOM drawer row may become a live open, namespace mount, or install target without an admission cut.
- No VEX shutter may suppress future advisories unless a separate policy cut says so with expiry/currentness.
- No locator chip may fetch bytes without a portal/request lane.
- No admission card may omit subject digest, action, target, policy cut, and epoch.
- No receipt may revive or continue live authority.
