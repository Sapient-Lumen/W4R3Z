# Secret slot cards, env-shadow lamps, redaction lenses, renewal rails, and use receipts

Revision 145 adds shell/terminal affordances for secret-bearing launch, import, helper, and object-store workflows. This is not a password-manager UI. It is truth chrome for the places where secrets otherwise sneak through environment variables, history, config, and logs.

## The cards

A **secret slot card** should show:

- what descriptor was requested (`purpose`, `scope`, `audience`, `provider family`, `epoch`);
- what prompt or policy act issued/unlocked it;
- how it was delivered (`handle`, `file projection`, `credential directory`, `provider session`, `env shadow`, `history only`);
- whether renewal/rotation is possible;
- whether current live-use authority exists now;
- what residue markers are known.

It must never show bearer bytes by default.

## Env-shadow lamps

When a workflow uses strings, the shell should say exactly what kind of shadow it is:

- `env:value` — material is in the environment. Loud warning.
- `env:path` — variable points to a secret file/projection. Still a string, but better than putting bytes in env.
- `argv/config` — material or pointer appears in command/config text. Warn about history, process inspection, and copy/paste.
- `child-inherits` — descendants may inherit the shadow unless the launch plan blocks it.
- `transcript-risk` — output/echo/debug may leak unless redaction lenses are attached.

## Redaction lenses

Redaction should render as a lens with coverage:

- `terminal transcript covered`
- `task logs covered`
- `crash report covered`
- `search/index covered`
- `screenshot/display not covered`
- `child output not covered`
- `provider side not covered`

The point is to prevent the common lie that a masked transcript means the secret is safe everywhere.

## Renewal rails

A secret row should be able to show:

- `live until <time or event>`;
- `renewable with current provider session`;
- `must reacquire`;
- `requires user presence`;
- `rotation pending`;
- `revoked`;
- `history only`.

Renewal rails are intentionally separate from live-use handles and receipts.

## Residue sweepers

The shell should be able to render cleanup obligations:

- config files that copied the secret;
- initialized databases that now contain a derived password/hash/session;
- caches and token stores;
- child processes still holding inherited env;
- crash dumps or logs requiring purge/rotation;
- semantic derivatives such as OCR, embeddings, summaries, and snippets;
- exported artifacts that need quarantine or trust re-evaluation.

## Delight without lying

Good future moves:

- `why does this helper need a secret?` drawers connected to exact request/purpose/audience.
- `project as file, not env` one-click repairs for legacy commands.
- `rerun with fresh token` ladders that start from a new acquisition prompt instead of replaying stale env.
- `show all shadows` mode for a process tree.
- `rotate because leaked` button that bundles residue evidence and renewal/rotation plan without pretending cleanup already happened.
- `safe transcript copy` that preserves redaction metadata and strips terminal-only secrets.

## Guardrail

Never let a descriptor, prompt receipt, environment variable, redaction mask, renewal hint, use receipt, or cleanup receipt impersonate current secret-bearing authority. Conversely, never hide a live secret behind a harmless-looking string or history row.
