# Consent cards, trusted-path lamps, volition tokens, clickjacking shields, and approval receipts

Revision 154 adds shell UX ideas for human-consent hygiene.

The shell should make high-risk approval feel calm and exact. The user should not need to understand capability theory to see the difference between:

```text
proposal -> summary -> trusted surface -> gesture -> volition witness -> approval cut -> live authority -> receipt
```

## Consent cards

Every high-risk action gets a card generated from the typed plan, not from helper prose:

```text
consent card
plan: A-31 export-object
requester: assistant plan compiler
source: object O-19, rev 7
send to: service handle candidate github.upload
reads: H7 read-only
writes/sends: network lease N3
secrets: none
payer: budget B2, max 1 operation
not included: shell.exec, secret.read, future reruns
```

The card should show the exact authority delta before any approve button becomes active.

## Trusted-path lamps

A lamp says where the approval UI lives:

```text
trusted path: portal-local
surface: ViewFS consent sheet
screen capture: not active
remote control: no
app-rendered: no
model-rendered: no
```

Other states:

```text
shell-local
secure-attention
ordinary-focused
notification-only
app-rendered
model-rendered
web-embedded
remote-captured
accessibility-mediated
headless-policy
unknown/degraded
```

A degraded lamp should not block all work by itself, but it should be visible and policy-addressable.

## Authority-diff panes

High-risk approval should say what changes:

```text
authority diff
+ read O-19 rev 7 through H7
+ send bundle B-6 through N3
- no namespace write
- no secret slots
- no durable reopen grant
- no memory promotion
```

The summary digest should be visible in receipt details, not in the user's face by default.

## Gesture chips

Show the interaction witness separately:

```text
gesture: hold-to-approve
freshness: 3s window
state: fresh -> consumed
source: local pointer + keyboard seat
synthetic: no
```

Possible chips:

```text
fresh
consumed
expired
transferred
refused
hardware
secure-attention
remote
synthetic
absent
```

## Volition-token beads

When a profile requires volition, show the witness as a bead between gesture and approval:

```text
volition V-8
binds: action A-31 + summary S-44
issuer: shell UI root
use: one-shot local
status: accepted by consent mediator
```

Do not make the bead copyable as a bearer token.

## Clickjacking shields

When untrusted/app/web/model UI contains a button that looks like approval, put a shield on it:

```text
shield: presentation-only
reason: app-rendered widget cannot approve network export
valid step: open ViewFS consent card
```

For web-embedded surfaces:

```text
frame posture: embedded / untrusted origin / no high-risk consent
```

## Notification and answer-card brakes

A notification click or answer-card button can request a plan, not approve it:

```text
button clicked: "Send"
compiled plan: network export + public link
status: needs consent card
```

This keeps delightful one-click UX for low-risk local actions while preventing hidden exfiltration.

## Approval-cut drawers

After approval, show the exact grant:

```text
approval cut
issuer: Johnny via portal-local consent
policy: high-risk export profile C2
volition: V-8 valid, consumed
approved authority: H7 read + N3 send
expires: end of operation or 60s
reuse: no
receipt: R-77
```

The drawer should make it obvious that an old receipt cannot run the action again.

## Remote/headless honesty

Remote support, terminal-only servers, automation, CI, and accessibility flows should display honest issuer kinds:

```text
approval issuer: delegated admin quorum
trusted path: headless-policy
volition: not applicable by profile
```

or:

```text
trusted path: remote-captured
policy: secrets require local hardware confirmation
result: denied / request alternate approval
```

## Shell rule of thumb

Never let a visual affordance carry more authority than its lane.

- A button requests.
- A consent card summarizes.
- A trusted-path lamp classifies the surface.
- A gesture chip witnesses interaction.
- A volition bead binds gesture to summary.
- An approval drawer authorizes exact authority.
- A live slot acts.
- A receipt explains.
