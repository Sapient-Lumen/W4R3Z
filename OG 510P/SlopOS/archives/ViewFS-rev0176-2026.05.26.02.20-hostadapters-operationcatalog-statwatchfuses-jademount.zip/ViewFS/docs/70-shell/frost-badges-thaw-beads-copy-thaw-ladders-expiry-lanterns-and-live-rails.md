# Frost badges, thaw beads, copy-thaw ladders, expiry lanterns, and live rails

Steal from current SlopOS import/materialize/CapStore posture plus Amazon S3 restore semantics and Azure archive rehydration semantics.

Whenever the shell renders one object/tier/history row, it should be able to show:
- whether it is talking about one **committed object** or only a **history row**,
- whether one **frost badge** says `hot`, `cool`, `cold`, `archived`, `offline`, or `history only`,
- whether one **thaw bead** says `requested`, `pending`, `priority high`, `failed`, `expired`, or `history only`,
- whether one **copy-thaw ladder** says `temporary copy`, `tier changed`, `copy target ready`, `copy target pending`, or `history only`,
- whether one **expiry lantern** says `expires then`, `no expiry exposed`, `expired`, or `history only`,
- whether a **live rail** is actually present now.

Why this is great:
- cold storage becomes delightful without lying about hot readability;
- restore and rehydrate jobs stop masquerading as object identity or current authority;
- temporary readable copies stop pretending to be permanent hot placement;
- the shell can stay luxurious while telling the truth about archive posture, thaw progress, temporary readability, expiry, and current authority.

Guardrail:
- never let one old thaw receipt, restore-status row, or expiry lantern impersonate a current live facet.
