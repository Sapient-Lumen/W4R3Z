# Prefix badges, folder ghosts, list lanterns, and live rails

## Why this shell note exists
A custom ViewFS shell will almost certainly want to present object-store content in a folder-like way.
The dangerous shortcut is to let every folder-looking thing imply the same underlying truth.
This note keeps four different truths visible:
- one **prefix projection**,
- one **provider folder resource**,
- one **listing snapshot or feed**,
- and one **current live bind/facet**.

## UI moves worth stealing
### Prefix badges
Rows that look folder-like should say what they really are:
- `flat prefix`
- `provider folder`
- `managed folder`
- `query projection`
- `history only`

### Folder ghosts
When a browse surface is simulated rather than provider-native, say so.
A faint ghost/veil can carry:
- `simulated from names`
- `provider hidden`
- `not a durable folder object`
- `native folder resource`

### List lanterns
One folder-looking row may be backed by a stale snapshot, a current live feed, or a partial cached listing.
Lantern chips should admit:
- `snapshot`
- `live listing`
- `partial`
- `cached`
- `stale possible`
- `history only`

### Name rails and live rails
One object card may show:
- `published under prefix X`
- `listed in snapshot Y`
- `bound in room Z`
- `live read facet here now`

Those rails should stay visibly separate instead of compressing into one vague `in this folder` story.

## Example truth table
A future shell object inspector should be able to say:
- `object exists`
- `shown under flat prefix /docs/2026/`
- `no provider folder resource proven`
- `listing snapshot from 2m ago`
- `bound into current room as reports/`
- `no live edit facet here`

That is much more honest than one flattering `folder entry` row.

## Why this helps product quality
Users can handle this if the chrome is calm.
The payoff is huge:
- fewer fake assumptions that storage prefixes are directories,
- less accidental coupling between browse UI and authority,
- better portal/import repair UX,
- and cleaner room semantics when one provider later adds real folder resources.
