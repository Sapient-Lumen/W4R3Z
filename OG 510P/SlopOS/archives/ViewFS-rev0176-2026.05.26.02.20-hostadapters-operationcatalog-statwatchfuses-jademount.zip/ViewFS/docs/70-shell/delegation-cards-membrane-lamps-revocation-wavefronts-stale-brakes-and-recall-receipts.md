# Delegation cards, membrane lamps, revocation wavefronts, stale brakes, and recall receipts

Revision 146 adds shell/terminal affordances for delegation and revocation hygiene. The goal is to make sharing powerful without turning "share" and "revoke" into misleading one-bit badges.

## Delegation cards

A **delegation card** should show:

- source object/handle/bundle class;
- issuer and recipient subject class;
- route (`local handle copy`, `portal`, `membrane`, `provider grant`, `RPC stub`, `bearer import`, `history only`);
- requested rights and caveats;
- whether re-delegation is allowed;
- whether the result is live, renewal-capable, persistent, or receipt-only.

The card should never contain raw bearer material by default.

## Caveat chips

Render narrowing terms as chips, but label their enforcement status:

- `read only` / `write` / `append` / `observe`;
- `until <time/event>`;
- `audience:<provider/service>`;
- `purpose:<task>`;
- `local-only` / `offline allowed` / `network needed`;
- `no redelegate`;
- `N uses`;
- `safe-open only`;
- `quarantine-preserving`.

Each chip should be able to say `declared only`, `proxy-enforced`, `verifier-checked`, `provider-owned`, or `unknown`.

## Membrane lamps

A **membrane lamp** tells the user where enforcement lives:

- `raw handle` — no local revocation wrapper; use caution.
- `proxy-enforced now` — a live membrane/lease gate mediates calls.
- `verifier-checked` — bearer-ish credential checked at use by a verifier/provider.
- `provider-owned` — remote authorization server/session owns liveness.
- `expiry-only` — no recall path besides waiting or rotating.
- `descriptor only` — explanation exists, no live enforcement lane.
- `history only` — old fact, no authority.

## Revocation wavefronts

A revoke/recall drawer should show a wave, not a checkbox:

- `requested locally`;
- `local proxy closed`;
- `broker epoch advanced`;
- `provider accepted`;
- `provider propagation pending`;
- `recipient notified`;
- `recipient offline/unknown`;
- `stale use denied`;
- `rotation/rekey done`;
- `irreversible effects remain`;
- `history only`.

This gives a truthful middle ground between "nothing happened" and "everything is guaranteed gone".

## Stale brakes

When use fails, the shell should not show a generic `permission denied`. Good reason classes:

- `expired`;
- `recalled by issuer`;
- `provider revoked`;
- `epoch mismatch`;
- `object replaced`;
- `object deleted`;
- `policy now denies`;
- `basis drift`;
- `issuer unavailable`;
- `renewal authority missing`;
- `offline descendant unknown`;
- `history only`.

Each stale brake should offer at most the honest next move: `reacquire`, `ask issuer`, `renew`, `rotate`, `open safe/read-only`, `make fresh copy`, or `show receipt`.

## Recall receipts

Recall receipts should include:

- what was recalled/revoked/rotated;
- who requested it and under what authority;
- what enforcement surface observed it;
- what currentness witness or provider response was seen;
- which effects cannot be undone;
- what residue or bearer material may remain;
- what should be rotated/reissued;
- what is unknown.

They must not contain raw tokens, capability URLs, CH-SREF-like bytes, or enough locator material to reacquire authority.

## Delight without lying

Good future moves:

- `share for this run` with visible expiry and no persistence.
- `share via membrane` that says calls are live-proxied and recallable.
- `share as bearer` that is loud, red, and asks whether a safer route exists.
- `revoke and rotate` ladder for secrets or bearer handles.
- `who still can?` drawer with privacy-preserving known-state, not a global oracle.
- `try again with fresh delegation` instead of replaying old receipts or stale env.
- `show irreversible effects` after a recall request.

## Guardrail

Never let a delegation intent, caveat chip, CH-CAPLEASE-like descriptor, provider response, revocation request, wavefront snapshot, stale-denial receipt, or old share card impersonate current authority. Conversely, never hide a live delegated handle behind a harmless-looking note or URL.
