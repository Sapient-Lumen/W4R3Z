# Capsule cards, seal shutters, courier rails, commit lamps, and live rails

Steal from current SlopOS import/materialization/commit posture plus Linux `memfd_create()`, file sealing, UNIX FD passing, and `O_TMPFILE` publish-later behavior.

Whenever the shell renders one draft/import/edit-return row, it should be able to show:
- whether it is talking about one **transient staging capsule** or one **durable committed object**,
- whether one **seal state** is open, frozen for review, frozen against future writes, or locked,
- whether one **courier rail** has only handed the capsule locally,
- whether one **commit lamp** says the object is still draft-only, committed here, published now, discarded, or history only,
- whether a **live facet** is actually present now.

Why this is great:
- helper edits, previews, export-review flows, and import staging become delightful without lying about what is durable already;
- freeze-for-review becomes explainable instead of spooky;
- local handoff stops pretending to be durable publication;
- the shell can stay luxurious while telling the truth about drafting, freezing, local couriering, commit-last, and current authority.

Guardrail:
- never let one old capsule card, seal shutter, courier receipt, or commit lamp impersonate a current live facet.
