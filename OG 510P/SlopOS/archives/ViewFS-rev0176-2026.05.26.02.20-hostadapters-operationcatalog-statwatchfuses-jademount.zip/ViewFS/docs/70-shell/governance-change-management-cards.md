# Governance and change-management shell cards

The shell should make governance visible without making governance magical.

## Proposal card

A proposal card should show:

- subject and digest;
- basis epoch versus current epoch;
- scope delta and widening review;
- current reviewer/quorum state;
- whether any effect authority is currently present.

The card must not say “can deploy” or “can migrate” merely because a proposal is approved.

## Decision and quorum card

A decision card should show the linked proposal digest and whether the digest still matches. A quorum card should show threshold posture, steward requirements, and whether the quorum row is current. Private votes should not be rendered unless a disclosure lane says they may be rendered.

## Rollout and flag card

A rollout card should distinguish:

- plan approved;
- ring admitted;
- guardrails passed;
- rollout started;
- rollout completed;
- rollback available.

A feature-flag card should show scope and policy epoch. It should not imply that being in a cohort supplies object, tool, disclosure, or migration authority.

## Deprecation, compatibility, and migration card

A deprecation card should state whether the window has arrived and whether a migration path exists. A compatibility card should show exact version pair and any waiver. A migration card should show source schema, current schema, target schema, precheck, rollback plan, and live authority posture.

## Governance dashboard warning

The dashboard is an explainer. It is not an executor. Every effect still goes through typed plans, approval cuts, policy, live handles, resource budgets, and receipts.
