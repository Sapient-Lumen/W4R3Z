# Interop reference, crosswalk, and catalog cards

Interop cards should make translation uncertainty visible.

A ViewFS shell card for schema/ontology surfaces should separate:

- namespace prefix/context digest;
- URI or external reference;
- local vocabulary term;
- crosswalk relation and confidence;
- shape validation result;
- ontology alignment relation;
- catalog/publication posture;
- backing live authority, if an action is being prepared.

The card must never show a single green `interoperable` badge that hides the seam. The safer rendering is a stack of small facts:

```text
Namespace: viewfs → digest sha256:ctx1 · current p9
Reference: https · resolver r2 · digest bound
Term: viewfs:Handle · active · non-deprecated
Crosswalk: closeMatch · reviewed · confidence 0.92
Shape: passed · shape epoch s2
Catalog: ready · redacted · release reviewed
Authority: no live open in this card
```

## Unsafe card claims

A card must be denied or visibly degraded if it claims:

- the URI is an open handle;
- a namespace context is policy;
- a term is a disclosure approval;
- a crosswalk is exact equivalence without review;
- a shape validation is safety approval;
- an ontology alignment confers authority;
- a catalog entry is raw access;
- hidden identifiers can be shown because a card is visible.

## Product posture

Interop cards should invite inspection, not immediate execution. If the user wants to act, the shell should transition into an authority-diff, disclosure, export, or workflow card that revalidates live handles and approval cuts.
