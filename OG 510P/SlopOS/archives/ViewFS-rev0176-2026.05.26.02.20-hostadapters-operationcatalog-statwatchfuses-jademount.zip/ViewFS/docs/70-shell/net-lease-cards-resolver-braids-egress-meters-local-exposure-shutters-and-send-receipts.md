# Net lease cards, resolver braids, egress meters, local-exposure shutters, and send receipts

Revision 148 adds shell ideas for network authority that stay capability-honest. The shell should make networking feel understandable without hiding DNS, local-network, proxy, stream, or egress authority behind a flattering **online** bit.

## Big shell promise

A user should be able to answer:

- who is asking to talk to the network?
- what destination shape was reviewed?
- which resolver/proxy/path facts were used or omitted?
- can this reach the public internet, loopback, LAN, or a specific prefix?
- is it connecting, listening, advertising, fetching, sending, syncing, updating, or only requesting?
- what data can cross the boundary?
- what expires, what can renew, and what is only history?

## UI pieces worth stealing

### Net lease cards

A compact card:

```text
net lease
actor: safe-open viewer / updater / support exporter / helper
kind: connect / listen / resolve / fetch / send / sync
scope: public / local / loopback / explicit-prefix
dest: example.test:443, tls, ttl 10m
budget: 2 MiB, 3 connections
renewal: ask
receipt: on close
```

The card should never say only `network allowed`.

### Resolver braids

A braid shows how a destination string became a connection target:

```text
typed: https://example.test/report
canonical host: example.test.
resolver: portal-owned
answers: redacted set digest
selection: v6 first, v4 fallback allowed
svc binding: omitted from portable receipt
proxy: portal-local policy
expires: 7m
```

Braids are explanation, not handles.

### Local-exposure shutters

Separate shutters for:

- public internet connect;
- local network connect;
- loopback connect;
- DNS/address resolution;
- listen/accept;
- mDNS/SSDP discovery;
- service advertisement;
- port forward / tunnel / public endpoint.

A shutter can be `absent`, `requestable`, `armed`, `live`, `revoked`, `expired`, or `receipt only`.

### Egress meters

Network bytes should be tied to purpose and material:

```text
sending: redacted support bundle
object classes: logs yes, crash memory no, secrets no, fd rows classes-only
budget: 4 MiB
sent: 1.3 MiB
remaining: 2.7 MiB
```

Meters should make background upload/download obvious.

### Import/fetch boundary panels

When network fetch produces object-store material, show both sides:

```text
net: fetched from example.test under lease N
object: quarantined derived artifact
supply chain: no SBOM / no signature / not admitted
open: safe viewer only
```

Do not let successful fetch UI look like trusted import.

### Stream ghost rows

After close or expiry, a stream can leave a ghost row:

```text
closed  tls example.test:443  812 KiB sent  27 KiB recv  receipt-only
expired dns example.test      answer witness stale        no-retry
revoked sync vendor.example   bytes stopped at 2 MiB      needs new cut
```

Ghosts should not be clickable as dialers.

### `What can it reach?` drawers

A drawer that answers:

- public internet: yes/no;
- local network: yes/no;
- loopback: yes/no;
- private IP ranges: yes/no;
- DNS resolver: portal/local/none/omitted;
- proxy: portal-local/none/omitted;
- service binding: included/omitted;
- listen: yes/no;
- advertise: yes/no;
- tunnel: yes/no.

### Send receipts

A send receipt should say:

- actor and workflow;
- destination class and endpoint witness class;
- material sent and material omitted;
- redaction/export policy cut;
- byte count and completion/abort state;
- lease TTL/budget result;
- whether any local copy, residue, or queued retry remains.

The receipt is not a retry grant.

## Command sketches

Do not freeze these, but keep the shape:

```text
viewfs net request --connect https://example.test --purpose update --ttl 10m
viewfs net braid <lease> --show-omissions
viewfs net shutters <process>
viewfs net meter <stream>
viewfs net deny-local <room>
viewfs net listen --loopback --port 0 --ttl 5m --purpose dev-callback
viewfs send bundle <support-bundle> --to vendor-support --redaction default --budget 4MiB
viewfs fetch <url> --quarantine --no-follow-secondary
```

## Status vocabulary

Prefer specific statuses:

```text
no-network
request-only
public-only
local-denied
loopback-only
resolver-portal
resolver-omitted
svc-binding-omitted
proxy-portal-local
connect-live
listen-live
advertise-denied
budget-low
ttl-expired
dns-stale
stream-closed
send-redacted
receipt-only
```

Avoid ambiguous labels:

```text
online
trusted host
safe internet
allowed
same origin
same machine
localhost safe
sync enabled
network ok
```

## Super-awesome moments

- **Network x-ray**: show exactly how a process can leave the room: public, local, loopback, listener, advertisement, proxy, tunnel.
- **Why did this connect?**: expand a stream into intent, lease descriptor, resolver witness, selected address class, and receipt.
- **No local by default**: a one-click room posture that allows public update fetches but blocks LAN/loopback probes.
- **Fetch-to-object split card**: after any download, show `fetched` versus `admitted`, with quarantine and supply-chain drawers adjacent.
- **Background egress siren**: loud card when a background helper sends bytes from object-store, diagnostics, secrets, or derived artifacts.
- **DNS drift lamp**: show when a prior name witness is stale and a retry needs a fresh resolution/admission cut.
- **Listener spotlight**: if a room starts accepting connections, make it visually different from outbound connect.
- **Receipt-only ghosts**: beautiful history rows that cannot be mistaken for standing access.

## Guardrail

A URL is not authority. DNS is not a capability. Public network is not local network. Connect is not listen. Listen is not advertise. Fetch is not trust. Upload is not just a socket. A stream ghost is not a dialer. A send receipt is not a retry grant.
