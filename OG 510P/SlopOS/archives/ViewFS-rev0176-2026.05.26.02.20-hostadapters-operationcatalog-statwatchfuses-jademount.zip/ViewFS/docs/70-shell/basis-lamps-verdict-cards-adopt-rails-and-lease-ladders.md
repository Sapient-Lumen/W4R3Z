# Basis lamps, verdict cards, adopt rails, and lease ladders

One of the nicest shell moves available to ViewFS is to stop letting one cheerful `save` or `sync` button pretend it means everything.
This note collects shell/terminal ideas for the seam between **local edit shadows**, **exact pushback basis**, **provider verdicts**, **local adoption choices**, and **history**.

## 1. Basis lamps instead of one vague dirty bit
For any editor pane, object card, or command block, the shell should be able to open a little basis card like:
- `draft: local shadow`
- `pushback basis: etag abc123`
- `lease: none`
- `provider drift: moved to etag def456`
- `adopt state: keep draft`
- `receipt only`

This is much more honest than one generic `modified` badge.

## 2. Verdict cards that say what the provider actually said
The shell should have explicit chrome for provider outcome:
- **accepted cards** for `accepted -> generation 78`
- **precondition cards** for `expected etag abc123, saw def456`
- **conflict cards** for `ownership / conflict-key mismatch`
- **lease-missing cards** for `renew or retry under hold`
- **unknown-verdict cards** for transport-lost or receipt-lost outcomes

That keeps `push failed` much more useful than a generic error toast.

## 3. Adopt rails instead of one fake post-save state
After a verdict, the shell should tell the truth about what happens locally next:
- `keep draft`
- `fast-forward local room`
- `fork new local object`
- `open merge view`
- `receipt only`

That preserves upstream verdict and local consequence as separate acts.

## 4. Lease ladders and force-with-lease ladders
If the mutation lane supports leases or expected-old replacement, the default should be a ladder rather than one vague `force` button:
- `retry if unchanged`
- `renew hold and retry`
- `compare against current upstream`
- `replace with lease`
- `fork local instead`
- `store receipt only`

That steals the good product lesson from Git without pretending every provider is Git.

## 5. Great terminal moves worth stealing
- **basis lamps** attached to command blocks so `edit/save/push` results can show `draft`, `basis`, `lease`, and `provider drift` separately.
- **verdict cards** in the transcript and pane HUD so provider replies remain inspectable and searchable.
- **adopt rails** that tell the truth about `kept draft`, `fast-forwarded`, `forked`, `merged`, or `history only`.
- **drift drawers** that compare the draft basis with the provider's current state before any dangerous retry.
- **quality chips** inspired by modern shell integration: `rich`, `basic`, or `heuristic` basis/verdict visibility should be explicit instead of guessed.

References: REF-RFC9110-PRECONDITIONS, REF-S3-CONDITIONAL-WRITES, REF-GCS-PRECONDITIONS, REF-GIT-FORCE-WITH-LEASE, REF-GIT-UPDATE-REF, REF-WEBDAV-LOCKING, REF-ETCD-TXN, REF-MDN-CREATEWRITABLE, REF-VSCODE-SHELL-INTEGRATION, REF-WEZTERM-SHELL-INT.
