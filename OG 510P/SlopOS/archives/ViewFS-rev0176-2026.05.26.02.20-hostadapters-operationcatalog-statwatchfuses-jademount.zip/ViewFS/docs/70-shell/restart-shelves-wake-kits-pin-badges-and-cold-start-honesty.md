# Restart shelves, wake kits, pin badges, and cold-start honesty

The future ViewFS shell should make start/restart continuity feel luxurious **without** lying about what really survived.

## The four big UI moves

### 1. Restart shelves
Every room, pane, or inspector should be able to show a compact restart shelf with separate rows for:
- `wake kit delivered`
- `restart locker held`
- `namespace pin present`
- `live now`
- `durable anchor only`
- `receipt only`

Why this matters:
- users should be able to tell whether current authority came from an exact warm restart, from a weaker repair path, or from a fresh cold start;
- manager-held continuity should stop masquerading as durable persistence;
- namespace-liveness facts should stop masquerading as current room occupancy.

### 2. Warm-start lamps
A room header should be able to say:
- `warm exact`
- `warm partial`
- `cold repair`
- `cold fresh`
- `receipt only`

That one move would make restart UX dramatically more honest.

### 3. Pin badges
Inspectors and room chrome should be able to show compact badges such as:
- `fd pinned`
- `bind pinned`
- `provider pinned`
- `pin dropped`
- `pin expired`
- `pin unknown`

Pin badges are useful because they explain why one restart path might still be possible without pretending the room is currently live there.

### 4. Cold-start honesty cards
If the room fell back from one hoped-for warm restart to a colder path, leave a small card behind.
A good card should answer:
- was the locker missing or cleared?
- did a pin die?
- did the shell fall back to one durable anchor / repair ladder?
- did the room come back fresh with only layout/history?
- what reset scope is honestly required now?

## Nifty moves worth stealing

### Partial wake-kit chips
Borrowing from Steward's adaptation-witness pressure, show chips like:
- `wake kit partial`
- `overlay dropped`
- `cache trimmed`
- `concurrency capped`
- `reconsent needed`

### Read-cut / staleness residue
Borrowing from Ward, every restart receipt should say what exact read cut or freshness basis it reflects.
For high-risk verbs, a stronger revalidation fence should appear before replay/rerun if the room came back cold or partially warm.

### Anchor-death compatibility
Borrowing from Schell, if an old exact restart point is dead, say so directly:
- `warm anchor died`
- `pin gone`
- `locker cleared`
- `restart scope reset`

### Compare-after-rewake drawers
If a warm or partial restart succeeded, the drawer should say whether it restored:
- `same live handles`
- `same namespace basis, narrower kit`
- `same room layout, weaker authority`
- `fresh room only`

### Replay-with-honesty rails
Before replaying a command block, notebook cell, or route slip, show:
- which inputs are live now,
- which are only wake-kit residue,
- which require repair,
- and whether replay crosses a stronger revalidation fence because the room is no longer warm exact.

## Anti-lies
- Do not let a restart locker masquerade as a durable anchor.
- Do not let a namespace pin masquerade as a current live room bind.
- Do not let a warm-partial restart masquerade as warm-exact.
- Do not silently replace `cold repair` with `restored` just because a fallback worked.
- Do not let replay/rerun hide when the room came back with weaker authority than before.

## Why this is low-regret now
These moves are mostly about **truthful restart and continuity UX**.
They help the future shell+terminal become super awesome without prematurely deciding:
- one locker object model,
- one exact namespace pin primitive,
- one room-manager split,
- or one final warm-restart carrier.
