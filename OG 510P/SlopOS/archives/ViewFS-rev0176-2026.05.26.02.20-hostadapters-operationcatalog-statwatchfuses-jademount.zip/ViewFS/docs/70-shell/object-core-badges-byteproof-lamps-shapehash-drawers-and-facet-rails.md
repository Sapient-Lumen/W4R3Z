# Object-core badges, byte-proof lamps, shape-hash drawers, and facet rails

A future ViewFS shell gets much more truthful if it can admit that these are different things:
- the semantic object the user means,
- one exact-byte proof,
- one chunk/codec/reference-sensitive structured address,
- one designation/name/locator,
- one current live facet,
- and one historical receipt.

## Useful moves

### Object-core badges
Badges like:
- `same object core`
- `core unknown`
- `related derivative`
- `history only`

These help users see when two rows are meant to be the same object conversation versus merely the same bytes or the same old import story.

### Byte-proof lamps
Lamps like:
- `exact bytes proven`
- `proof stale`
- `proof family differs`
- `proof unavailable`

These keep exact-byte truth visible without pretending it implies current live authority.

### Shape-hash drawers
A drawer that can explain:
- `root-block hash`
- `chunked DAG address`
- `closure/store-path address`
- `raw blob digest`
- `canonical-form digest`

This is where the shell can tell the truth that one hash includes codec/chunking/reference context while another is only raw bytes.

### Facet rails
Rails like:
- `inspect now`
- `read now`
- `edit now`
- `publish now`
- `automation now`
- `proof only`
- `name only`
- `history only`

These prevent old descriptor/proof cards from impersonating current live capability.

## Guardrails
- never label one structured address as if it were automatically a raw-byte proof;
- never label one raw-byte proof as if it automatically settled semantic sameness;
- never let one old published name or import receipt impersonate a current live facet;
- never hide when two rows share one semantic object core but differ in exact representation or proof family.
