# Shell + terminal protocol sketch

Purpose: capture the minimum protocol ideas that make a ViewFS shell feel obviously better than a traditional terminal without freezing shell syntax.

This is **not** a final protocol. It is a sketch of the metadata worth emitting early so the UI can remain capability-native instead of falling back to screen scraping and hidden state.

## Core principle
The shell and terminal should exchange enough structured metadata that the UI can show:
- active view/domain identity,
- synthetic cwd root,
- command block boundaries,
- object/receipt references,
- and authority-relevant warnings,
without guessing from plain text.

## Minimum metadata events worth prototyping

### R150. Secure-channel identity events
Fields worth prototyping later:
- `channel_id`
- `transport_class`
- `intent_id`
- `reference_identity_digest`
- `presented_evidence_digest`
- `verifier_profile_id`
- `trust_anchor_scope`
- `verification_summary`
- `channel_binding_state` in `{absent,bound,redacted,omitted}`
- `resumption_state` in `{fresh,resumed,zero_rtt,disabled,omitted}`
- `client_auth_state` in `{absent,requested,selected,redacted,omitted}`
- `live_state` in `{opening,live,closing,closed,receipt_only}`

Why:
- terminal chrome should be able to say `identity matched under this profile` or `receipt only` without screen-scraping TLS logs or pretending a receipt can reconnect.



### 0. Room identity event
Fields:
- `room_id`
- `room_label`
- `room_class` in `{pane,tab,notebook_cell,helper,other}`
- `restore_basis` in `{fresh,restored,receipt_only,unknown}`

Why:
- the terminal should know which long-lived interaction locus the human is actually in, instead of inferring everything from cwd or process identity.

### 1. View/domain event
Fields:
- `view_id`
- `view_label`
- `cwd_binding`
- `cwd_display`
- `ambient_escape_in_use` (bool)

Why:
- visible prompt badges and pane labels should come from explicit shell state, not heuristics.

### 2. Command block event
Fields:
- `block_id`
- `parent_block_id` (optional)
- `command_text`
- `workflow_id` / `notebook_id` (optional)
- `start_ts`
- `end_ts`
- `exit_status`

Why:
- command+output should be a durable transcript unit.

### 3. Semantic boundary events
Fields:
- `zone_type` in `{prompt,input,output,warning,receipt}`
- `block_id`
- `offset` / stable ordering index

Why:
- the terminal should know where prompts, user input, output, and attached receipts begin and end.

### 4. Object/receipt attachment event
Fields:
- `block_id`
- `attachment_kind` in `{object_ref, manifest_ref, grant_receipt, transfer_receipt, error_receipt}`
- `attachment_id`
- `summary`
- `durability` in `{ephemeral,durable,unknown}`

Why:
- receipts should be clickable, searchable, and explainable after the fact.

### 5. Authority preview event
Fields:
- `block_id`
- `input_handles`
- `portal_actions_may_occur`
- `ambient_escape_in_use`
- `writes_state`
- `exports_data`

Why:
- one-keystroke authority preview becomes possible.

### 5a. Deferred provider operation event
Fields:
- `block_id`
- `request_state` in `{rejected_now,accepted,accepted_with_ticket,unknown}`
- `operation_id` (optional)
- `followup_kind` in `{none,poll_url,provider_job,status_ref,unknown}`
- `settlement_state` in `{pending,settled,expired,unknown}`
- `local_adoption` in `{none,keep_draft,fast_forward,fork,adopt_successor,receipt_only}`

Why:
- the terminal should know when a request was merely admitted, when there is a later follow-up lane, and when local adoption still differs from provider settlement.

### 5b. Sponsorship / budget posture event
Fields:
- `block_id`
- `payer_kind` in `{none,requester,owner,server_budget,explicit_sponsor,unknown}`
- `budget_ref` (optional)
- `reservation_state` in `{none,reserved,partially_spent,spent,rejected,expired,unknown}`
- `charge_state` in `{none,pending,charged,charge_rejected,provider_absorbed,history_only,unknown}`

Why:
- the terminal should know when a command is merely authorized, when a sponsor/budget lane exists, and when cost actually landed.

## UI moves this protocol unlocks
- prompt badge with active view/domain and ambient-debt indicator
- command blocks with explicit input/output/receipt regions
- clickable receipts and object refs
- bookmarkable/importable workflows and notebook cells
- “why could this command access that object?” inspector
- search by view, object ref, receipt, or workflow name

## Fun features that still stay honest
- drag a receipt from one block into another tool as a mediated transfer action
- show a tiny rights summary next to completions and previews
- let panes advertise different views/domains clearly
- save a block as a workflow while preserving attached receipts and authority notes

## Anti-goals
- no hidden shell-state protocol that only one terminal can understand
- no screen-scraped cwd inference as the ground truth
- no UI feature that silently widens authority
- no “AI did something” without a visible block, preview, and resulting receipt trail

## Recommended spike
Build one narrow prototype with:
- visible view badge,
- command blocks,
- prompt/input/output boundaries,
- one clickable receipt type,
- and an “explain authority” inspector for the last command.

If that prototype works, then the shell syntax can remain open longer.


### 6. Route intent event
Fields:
- `block_id`
- `route_kind` in `{inspect,open_object,open_uri,export,transfer,rebind}`
- `subject_kind` in `{object_ref,receipt,uri,manifest_ref}`
- `subject_id`
- `needs_portal` (bool)

Why:
- typed routing should be observable instead of collapsing into pasted strings or ad-hoc click handlers.

### 7. Compatibility debt event
Fields:
- `block_id`
- `debt_kind` in `{ambient_path_open,host_path_walk,legacy_helper_exec}`
- `details`
- `sandbox_backstop` in `{none,landlock,other,unknown}`

Why:
- design-phase escape hatches should stay visible in transcripts, searchable in scrollback, and easy to audit away later.


### 8. Completion / suggestion event
Fields:
- `candidate_text`
- `candidate_kind`
- `source_kind` in `{view,receipt,workflow,history,palette,unknown}`
- `rights_summary`
- `needs_portal` (bool)
- `stale_authority` (bool)

Why:
- smarter completion is only trustworthy if the UI can distinguish “this command is ready” from “this command is remembered but its authority is gone”.

### 9. Mark / hyperlink event
Fields:
- `mark_kind` in `{prompt,block_start,block_end,workspace_change}`
- `link_kind` in `{object_ref,grant_receipt,workspace_bind,workflow,uri}` (optional)
- `route_options`
- `inspect_overlay_hint`

Why:
- prompt marks and typed links should be protocol-visible so terminals can navigate, inspect, and route without guessing from plain text.

### 10. Handle/ref/receipt classification event
Fields:
- `subject_id`
- `subject_class` in `{live_handle,durable_anchor,receipt}`
- `current_state` in `{usable_here,durable_anchor,receipt_only,repair_needed,stale_shadow,unknown}`

Why:
- the shell and terminal should be able to render recents, cards, and inspectors without pretending every remembered thing is current authority.

### 11. Authority HUD summary event
Fields:
- `view_id`
- `workspace_bind_id` (optional)
- `authority_summary`
- `ambient_debt`
- `staleness_state`

Why:
- visible pane chrome and prompt badges should be driven by explicit metadata, not inferred from prompt strings.

## Potential future additions from Revision 009
- `session_state_class[]` for classifying attached items as `live`, `ref`, `receipt`, or `note`
- `restore_hint` to say whether a pane/session restore needs portal/rebind help
- `replay_mode_hint` values that distinguish strict, reopen, portal-assisted, and stripped replay


### 12. View bind / rebind event
Fields:
- `view_id`
- `slot_id`
- `source_kind` in `{object_ref,bundle,view_fragment,selection,grant_ref,receipt,portal_result}`
- `source_id`
- `durability`
- `receipt_id`

Why:
- panes should be able to explain what entered the current view and whether it is live authority now or only remembered history.



### 14. Portal / chooser request event
Fields:
- `request_id`
- `request_kind` in `{open,bind_tree,save_destination,durable_upgrade,other}`
- `request_state` in `{pending,completed,cancelled,timed_out,failed}`
- `candidate_surface` in `{chooser_owned,caller_provided,hidden,unknown}`
- `requester_block_id` (optional)

Why:
- mediated interactions should be visible transcript objects rather than invisible dialog side effects.

### 15. Selection / import result event
Fields:
- `request_id`
- `selection_id`
- `result_class` in `{selection_only,ephemeral_grant,durable_ref,live_bind,receipt_only}`
- `supported_ops[]`
- `bind_target_view_id` (optional)
- `receipt_id`

Why:
- the shell and terminal should be able to render `selected`, `granted`, `bound here`, and `reopenable` as different states.

### 13. Launch rehearsal / kit event
Fields:
- `block_id`
- `launch_kit_id`
- `bundle_ids[]`
- `view_fragment_ids[]`
- `bind_plan[]`
- `stale_members[]`
- `portal_actions_may_occur`
- `ambient_debt`

Why:
- one-keystroke launch rehearsal, authority diffing, and stripped replay all become possible without pretending the current pane state and candidate child launch state are the same thing.


### 16. Prepared route / approval event
Fields:
- `plan_id`
- `intent_kind`
- `subject_id`
- `plan_state` in `{prepared,approval_needed,approved,committed,completed,denied,cancelled,timed_out}`
- `approval_basis_digest` (optional)
- `authority_diff_digest` (optional)
- `result_receipt_id` (optional)

Why:
- the terminal should be able to render prepare-versus-commit workflows, exact approval checkpoints, and result cards without pretending one state is another.


### 17. Reuse / renewal basis event
Fields:
- `reuse_candidate_id`
- `basis_record_id`
- `drift_state` in `{exact,narrowed,drifted,missing_source,unknown}`
- `reconsent_required`
- `renewal_target_class` in `{borrow,bind,durable_ref,prepared_plan,receipt_only}`
- `previous_receipt_id` (optional)
- `new_receipt_id` (optional)

Why:
- the terminal should be able to render basis diffs, reconsent ladders, and renewal result cards without pretending past success is current authority.


### 16. Witness / caveat / why event
Fields:
- `block_id`
- `witness_pack_id` (optional)
- `caveat_set_id` (optional)
- `freshness_token_id` (optional)
- `why_record_id` (optional)
- `decision_class` in `{exact,narrowed,reconsent,receipt_only,denied,unknown}`

Why:
- the terminal should be able to render witness drawers, caveat chips, freshness badges, and why panels without guessing from plain text.

### 16. Policy lens event
Fields:
- `block_id`
- `policy_family`
- `policy_cut`
- `validation_state` in `{valid,invalid,unknown,stale}`
- `decision_state` in `{allow,deny,narrowed,receipt_only,unknown}`

Why:
- the terminal should be able to show what exact policy surface informed the current decision without pretending shell heuristics are policy.

### 17. Advice rail event
Fields:
- `block_id`
- `advice_id`
- `advice_kind` in `{completion,repair,narrowed_alternative,rebind_hint,reconsent_hint}`
- `authoritative` (must be `false`)
- `source_kind` in `{shell_local,workspace,history,receipt,other}`

Why:
- the shell can be very helpful only if the protocol can say “this is advice, not authorization.”

### 18. Decision diagnostic event
Fields:
- `block_id`
- `diagnostic_id`
- `result_class` in `{allowed,denied,narrowed,invalid_policy,receipt_only}`
- `determining_policy_ids[]`
- `error_ids[]`
- `why_summary`

Why:
- compact policy-aware why cards should be protocol-visible instead of hidden in shell-local strings.

### 19. Decision log reference event
Fields:
- `block_id`
- `log_ref`
- `log_scope` in `{local_only,exportable,unknown}`
- `redaction_state` in `{redacted,raw_forbidden,unknown}`
- `authoritative` (must be `false`)

Why:
- durable audit/debug traces should be usable in the terminal without letting them masquerade as current authority.


### 20. Policy selection / cut event
Fields:
- `block_id`
- `policy_family`
- `policy_cut`
- `consistency_posture` in `{exact_snapshot,at_least_as_fresh,latest,unknown}`
- `selection_source` in `{explicit,bootstrap,repair_accepted,history_only,unknown}`

Why:
- the terminal should be able to render which exact judge/cut was authoritative for this action without guessing from plain text.

### 21. Policy fallback / repair event
Fields:
- `block_id`
- `candidate_id`
- `candidate_kind` in `{same_family_newer_cut,same_family_exact_cut,latest_cut,workspace_hint,history_hint,mediated_choice}`
- `authoritative` (must be `false`)
- `proposal_state` in `{available,suggested,accepted,declined,stale}`

Why:
- the terminal should be able to render fallback rails and repair prompts without letting them masquerade as current policy selection.


### 22. Proposal provenance / scope event
Fields:
- `proposal_id`
- `source_kind` in `{workspace,profile,organization,extension,history,receipt,mediator,shell_local,unknown}`
- `target_kind` in `{policy_switch,repair,rebind,workflow_promotion,route_choice,other}`
- `requested_scope` in `{once,pane,session,workspace,profile,organization,unknown}`
- `authoritative` (must be `false`)

Why:
- the terminal should be able to render proposer badges and scope chips without guessing from plain text.

### 23. Escalation / adoption event
Fields:
- `proposal_id`
- `escalation_state` in `{not_needed,pending,accepted,declined,blocked,stale}`
- `adopter_kind` in `{user_explicit,owner_config,mediator,administrator,unknown}`
- `adopted_scope` in `{none,once,pane,session,workspace,profile,organization,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render escalation ladders, adoption gates, and decline/adoption receipts without letting proposal surfaces masquerade as live truth.

- Reserve protocol space for protected-only / invoke-only / adoptable state badges so semantic zones can surface authorability truth without guessing from scrollback.
- Reserve protocol space for helper lifecycle badges (`publisher-trusted`, `installed`, `enabled`, `start-required`, `live`, `selected-for-request`) so semantic zones can surface helper truth without laundering install state into live authority.

### 24. Deferred-work lifecycle event
Fields:
- `request_id`
- `task_id` (optional before acceptance)
- `lifecycle_state` in `{immediate,accepted,queued,working,input_required,completed,failed,cancelled,expired}`
- `progress_token` (optional)
- `result_state` in `{none,pending,retrievable,retrieved,expired}`
- `queue_position` (optional)
- `receipt_id` (optional)

Why:
- the terminal should be able to render task badges, queue rails, progress lanes, and result lockers without guessing from scrollback.

- Reserve protocol space for deferred-work truth so semantic zones can surface `accepted`, `working`, `input-required`, `result retrievable`, and `history only` without laundering one class into another.

### Deferred control metadata
For deferred-work blocks, the shell should be able to emit control metadata such as:
- `control_action` in `{close,cancel,terminate,detach,delete_retained,retry_fresh,attach_existing,reset_from_checkpoint,fork_from_history}`
- `control_target_id` for the request/task/run being acted on
- `retention_state` in `{retained,history_only,forgot_locally,expired}`
- optional `basis_ref` when a reset/fork references prior history or checkpoint material


### 25. Live-session lane event
Fields:
- `session_id`
- `lane_kind` in `{observe,attach_readonly,attach_interactive,control_message,exec_debug,sideband_tunnel}`
- `activity_state` in `{armed,active,detached,ended,history_only}`
- `stdin_state` in `{none,shared,exclusive,unknown}`
- `source_ref` (optional)
- `receipt_id` (optional)

Why:
- the terminal should be able to render watch-only panes, interactive attach rails, control panes, debug drawers, and tunnel badges without guessing from scrollback.


### 26. Prompt input-origin event
Fields:
- `block_id`
- `origin_kind` in `{typed,pasted,dropped,packet_promoted,history_recall,unknown}`
- `byte_count`
- `multiline` (bool)
- `requires_review_hint` (bool)

Why:
- prompt-local editing, paste safety rails, and route-sheet promotion all work better when the terminal and shell know whether bytes were typed, pasted, dropped, or promoted from another packet.

### 27. Key packet capability / event
Fields:
- `encoding_kind` in `{legacy,disambiguated}`
- `event_type` in `{press,repeat,release}`
- `key_identity`
- `modifiers[]`
- `pane_scope`
- `prompt_local` (bool)

Why:
- high-fidelity key input lets the shell and terminal separate prompt-local gestures, pane commands, and transcript actions without overloading ambiguous legacy escape bytes.

### 28. Launch basis / startup credential event
Fields:
- `block_id`
- `exec_identity_kind` in `{object_handle,exact_staged_bytes,interpreter_plus_input,path_debt,unknown}`
- `exec_ref` (optional)
- `argv_basis_ref` (optional)
- `env_basis_ref` (optional)
- `credential_lane` in `{none,activation_slots,private_files,other,unknown}`
- `credential_slot_count`
- `receipt_id` (optional)

Why:
- the terminal should be able to render exact exec meaning, launch-basis diffs, and startup credential presence without guessing from plain text or exposing secret material.


### 29. Clipboard / selection offer event
Fields:
- `offer_id`
- `source_kind` in `{clipboard,primary_selection,drag_offer,share_offer,unknown}`
- `offer_state` in `{live_offer,offer_gone,history_ghost,prompt_local_only,materialized,receipt_only,unknown}`
- `owner_witness_kind` in `{none,local_peer,route_sheet,shell_only,clipboard_manager,unknown}`
- `representations[]`
- `accepted_representation` (optional)
- `retention_kind` in `{none,manager_retained,summary_only,expired,privacy_clamped,unknown}`
- `delivery_kind` in `{none,prompt_input,quoted_prompt_input,scratch_capsule,imported_object,live_bind,receipt_only,unknown}`
- `paste_capsule_id` (optional)
- `receipt_id` (optional)

Why:
- the terminal and shell get much more honest when current offer ownership, retained history ghosts, accepted representation, prompt paste, and imported object creation can render as different truths instead of one generic paste event.

### 30. Runner / bootstrap event
Fields:
- `block_id`
- `runner_kind` in `{native,interpreter,wasi,web,containerish,helper,unknown}`
- `runner_selection_kind` in `{explicit,environment_provided,compat_fallback,unknown}`
- `bootstrap_posture` in `{clean,explicit_bundle,compat_debt,blocked_hook_debt,unknown}`
- `expected_session_kind` in `{interactive,batch,detached_helper,receipt_only,unknown}`
- `lifecycle_lane` in `{none,follow_only,follow_and_stop,follow_and_control,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render how a launch will actually be hosted without guessing from file suffixes, path names, or transcript folklore.

### 31. Mutable prompt area event
Fields:
- `pane_id`
- `draft_id`
- `draft_state` in `{empty,editing,review_pending,promoted,discarded,unknown}`
- `history_separate` (bool)
- `clear_scrollback_preserves_draft` (bool)
- `promotion_target` in `{command_packet,route_sheet,note_only,none,unknown}`

Why:
- the terminal and shell work much better when the live editable prompt area is visibly separate from scrollback history and command-block selection.


### 32. Foreground turn / TTY posture event
Fields:
- `live_subject_id`
- `subject_kind` in `{process_handle,session_handle,unknown}`
- `stream_lane` in `{none,stdout_only,stdin_stdout,pty,shared_tty,unknown}`
- `tty_posture` in `{none,stream_only,controlling_tty,detached,unknown}`
- `foreground_state` in `{foreground,background,observe_only,armed,history_only,unknown}`
- `signal_target` in `{foreground_group,subject_only,none,unknown}`

Why:
- the shell and terminal should be able to tell the truth about whether a pane merely shows bytes, has live stdin, owns a controlling terminal relationship, or currently receives terminal-generated signals.


### 33. Handle topology / shared-open-state event
Fields:
- `subject_id`
- `subject_kind` in `{slot_binding,live_handle,unknown}`
- `slot_label` (optional)
- `alias_kind` in `{none,dup_local,passed_copy,pidfd_copy,launcher_copy,unknown}`
- `open_state_group_id` (optional opaque local identifier)
- `shared_state[]` in `{offset,status_flags,lock,lease,append_posture,unknown}`
- `independence_posture` in `{shared_open_state,fresh_reopen,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render `same live cursor`, `shared lock/lease`, and `fresh reopen` without guessing from descriptor numbers, path text, or transcript folklore.

### 34. Handle-class / escalation event
Fields:
- `subject_id`
- `handle_class` in `{locator,root_walk,metadata,read_stream,append_stream,write_stream,exec_target,durable_ref,receipt,unknown}`
- `upgrade_paths[]`
- `view_id` (optional)
- `receipt_id` (optional)

Why:
- the terminal should be able to render `inspect-only`, `readable now`, `needs reopen`, and `receipt only` as different truths instead of one vague open state.

### 35. Launch-boundary inheritance / child-slot event
Fields:
- `launch_id`
- `source_subject_id`
- `source_subject_kind` in `{current_slot_binding,current_live_handle,activation_carrier,unknown}`
- `inheritance_posture` in `{shuttered,eligible_not_selected,selected_for_child,unknown}`
- `child_slot_kind` in `{stdio,fdset,named_activation_slot,other,none,unknown}`
- `child_slot_label` (optional)
- `delivery_kind` in `{live_copy,fresh_reopen,receipt_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render `held here`, `launch-shuttered`, `selected for child slot fd=7`, and `receipt only` without guessing from transcript folklore or assuming every current handle crosses launch boundaries by default.

### 36. Namespace mutation / parent-anchor event
Fields:
- `mutation_id`
- `object_ref` (optional)
- `source_parent_ref` (optional)
- `destination_parent_ref` (optional)
- `mutation_kind` in `{rename,link,unlink,replace,exchange,create,mkdir,symlink,unknown}`
- `collision_posture` in `{not_applicable,create_new_only,replace_if_exists,exchange_names,unknown}`
- `resolution_basis` in `{explicit_parent_handles,tokenized_cross_parent,local_only,ambient_path_debt,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render two-anchor rename cards, overwrite/exchange ladders, and name-diff receipts without guessing from plain path text or pretending object identity and parent-anchor authority are the same thing.


### 37. Bind propagation / peer-group event
Fields:
- `bind_id`
- `subject_ref` (optional)
- `bind_state` in `{attached_here,detached,receipt_only,unknown}`
- `propagation_posture` in `{private,shared,slave,unbindable,unknown}`
- `peer_group_id` (optional opaque local identifier)
- `master_group_id` (optional opaque local identifier)
- `blast_radius` in `{local_only,propagates_to_peers,receives_from_master,bidirectional_peer,not_cloneable,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render `attached here`, `local only`, `shared to peers`, `receives upstream`, and `history only` without guessing from path text or pretending a live bind and its propagation posture are the same thing.


### 38. Draft-object / namespace-publication event
Fields:
- `draft_object_id`
- `draft_state` in `{unpublished,publish_ready,published,discarded}`
- `parent_anchor_id` (optional)
- `publication_mode` in `{new_only,replace,exchange,unknown}`
- `creates_live_bind` (bool)
- `receipt_id` (optional)

Why:
- the shell and terminal should be able to render `exact object exists`, `not yet named`, `ready to publish here`, and `published with receipt` as different states instead of guessing from temp paths or transcript text.


### 39. Content descriptor / object card event
Fields:
- `descriptor_id`
- `object_ref` (optional digest/object identifier)
- `media_type` (optional)
- `byte_size` (optional)
- `locator_hint` (optional, explicitly non-authoritative)
- `truth_state` in `{descriptor_only,local_bytes_present,live_handle_now,published_here,receipt_only,unknown}`
- `follow_on_acts[]`
- `receipt_id` (optional)

Why:
- the shell and terminal should be able to render `descriptor known`, `bytes here`, `live authority now`, and `history only` as different truths instead of guessing from filenames, temp paths, or transcript folklore.


### 40. Import localization / docref-boundary event
Fields:
- `import_event_id`
- `source_ref_id` (optional)
- `source_ref_kind` in `{chooser_offer,clipboard_offer,remote_ref,descriptor_only,unknown}`
- `materialization_state` in `{not_started,review_pending,in_progress,local_object_created,failed,unknown}`
- `local_object_id` (optional)
- `docref_state` in `{none,pending,minted,revoked,unknown}`
- `docref_id` (optional opaque local identifier)
- `live_handle_state` in `{none,requested,minted,bound_here,unknown}`
- `publication_state` in `{none,pending,published_here,unknown}`
- `receipt_id` (optional)

Why:
- the shell and terminal should be able to render `source ref`, `materializing`, `fresh local object`, `local docref`, `bound here`, and `history only` without guessing from path text or pretending every import has already become one local durable file.

### 41. Semantic epoch / confidence event
Fields:
- `semantic_epoch_id`
- `emitter_id`
- `emitter_kind` in `{shell_plugin,shell_builtin,terminal_helper,portal_bridge,unknown}`
- `epoch_state` in `{booting,provisional,barrier_passed,stale,resyncing,unknown}`
- `confidence` in `{authoritative,confirmed,advisory,heuristic,unknown}`
- `applies_to[]`
- `supersedes_epoch_id` (optional)
- `notes` (optional)

Why:
- the shell and terminal should be able to render `fresh semantics`, `late event from previous run`, `heuristic only`, and `resyncing` instead of pretending every side-channel event has identical trust or exact-run attribution.


### 42. Remembered-reopen / continuity event
Fields:
- `continuity_event_id`
- `remembered_ref_id` (optional)
- `remembered_ref_kind` in `{docref,bookmark,persisted_uri,receipt_pointer,locker_key,unknown}`
- `continuity_lane` in `{reopen_by_designator,exact_handle_locker,none,unknown}`
- `revalidation_state` in `{not_needed,pending,in_progress,succeeded,stale,target_missing,grant_needed,policy_denied,failed,unknown}`
- `live_handle_state` in `{none,locker_available,revived,minted,bound_here,unknown}`
- `target_ref` (optional)
- `receipt_id` (optional)

Why:
- the shell and terminal should be able to render `remembered`, `needs revalidate`, `exact locker available`, `live again`, `stale`, and `history only` without guessing from filenames, path text, or magical reopen folklore.


## Transfer / adoption semantic events

The shell protocol should be able to emit explicit boundary-crossing events rather than forcing the terminal to guess from paste text, child startup, or random log lines.

Useful event classes:
- `transfer-offer` — a thing or representation is available for acceptance
- `transfer-choice` — the receiver chose bytes / live copy / attenuated copy / designator / receipt-only
- `transfer-receive` — delivery completed
- `transfer-adopt` — receiver bound the result into a local slot/view
- `transfer-store-for-later` — receiver kept only a later revival designator
- `transfer-drop` — offer/received item was rejected or discarded

Useful metadata:
- issuer/courier witness (`source_pane`, `source_route`, `source_app`, `peer_badge`)
- result truth (`bytes`, `live-copy`, `attenuated-live-copy`, `designator`, `receipt-only`)
- adoption target (`pane`, `slot`, `bind-anchor`, `none`)
- revalidation needed / stale / grant-needed flags for later use

That gives the terminal enough structure to render `offer-only` versus `adopted-here` as different truths, and it keeps cross-pane/app transfer from collapsing into invisible shell magic.

## Additional event classes worth keeping separate

### 18. Designator / ticket / live-handle classification
The shell protocol should reserve room for classifying surfaced object-ish references as:
- `designation_only`
- `authority_ticket`
- `authority_ticket_stale`
- `local_alias`
- `live_handle_present`
- `receipt_only`

Why:
- OSC-style command boundaries help terminals understand *when* a command ran; ViewFS also needs enough metadata to understand *what class of reference* appeared in that block.
- terminals and transcript tools should be able to render inert-copy defaults for `designation_only` while routing `authority_ticket` through an explicit inspect/revalidate/adopt ladder.
- spoof-resistant command metadata becomes more valuable when the transcript contains capability-adjacent objects.

This should remain descriptive metadata, not a second hidden transfer channel.


### 19. Caveat / enforcement classification
The shell protocol should reserve room for classifying surfaced delegated references as:
- `caveat_declared`
- `membrane_enforced`
- `verifier_checked`
- `live_attenuated_handle`
- `revival_designator`
- `receipt_only`

Useful metadata:
- `enforced_by` (`proxy`, `verifier`, `local-handle`, `issuer`, `none`)
- `caveat_summary` (small human-facing list)
- `budget_kind` (`none`, `time`, `uses`, `policy`)
- `budget_state` (`current`, `stale`, `unknown`)
- `parent_authority_class`
- `renewal_action_available` / `revalidation_required`

That gives the terminal enough structure to render `caveat declared` versus `enforced now` as different truths, and it keeps delegated flows from collapsing into decorative badge soup.

### 20. Permission outlook / death-state classification
The shell protocol should reserve room for classifying surfaced capability-adjacent state as:
- `permission_outlook`
- `revival_designator`
- `live_handle_present`
- `death_state_verdict`
- `receipt_only`

Useful metadata:
- `permission_state` (`granted`, `prompt`, `denied`, `revalidate_needed`, `policy_blocked`, `unknown`)
- `death_state` (`revoked`, `expired`, `target_changed`, `target_missing`, `issuer_unavailable`, `deleted`, `membrane_dropped`, `history_only`, `unknown`)
- `repair_action_available[]`
- `outlook_basis` (`chooser`, `policy`, `cached-query`, `provider-report`, `unknown`)
- `state_changed_at_epoch` (optional)

That gives the terminal enough structure to render `permission looks good` versus `live authority present` versus `dead for this reason` as different truths, and it keeps liveness UI from collapsing into decorative stale badges.

### 21. Provenance / endorsement / admission classification
The shell protocol should reserve room for classifying surfaced object-adjacent trust material as:
- `provenance_claim`
- `endorsement_input`
- `local_admission_verdict`
- `live_handle_present`
- `receipt_only`

Useful metadata:
- `claim_kind` (`import`, `build`, `review`, `derivation`, `unknown`)
- `endorsement_kind[]` (`signature`, `threshold`, `delegation`, `reference_match`, `transparency_log`, `none`)
- `verdict_state` (`preview_only`, `safe_open_only`, `admit_document`, `admit_runnable`, `needs_review`, `deny`, `history_only`, `unknown`)
- `verdict_basis[]` (`local_policy`, `user_review`, `provider_report`, `trust_root_match`, `unknown`)
- `why_inspector_available` (bool)
- `live_handle_ref` (optional)

That gives the terminal enough structure to render `well-described` versus `well-endorsed` versus `admitted here` versus `live now` as different truths, and it keeps signatures/attestations from collapsing into decorative green trust badges.

## Portal request / session / live-state semantic events

If ViewFS gets more serious about portal-heavy workflows, the shell-terminal protocol should probably gain a small family of semantic events that stay visibly separate:
- `portal.request.begin` / `portal.request.finish`
- `portal.session.open` / `portal.session.update` / `portal.session.close`
- `portal.transfer.start` / `portal.transfer.retrieve` / `portal.transfer.close`
- `portal.adoption.state`

The important point is not the exact names.
The important point is that one completed request event should not have to impersonate one still-open session, and one portal-owned current-state update should not have to impersonate one local adopted bind.

## Additional completion / packet metadata worth carrying
A stronger completion-aware shell protocol should probably distinguish:
- `completion_row_state` in `{candidate,detail_loaded,accepted_fragment,accepted_full,withdrawn}`
- `packet_stage` in `{none,parsed,compiled,approval_needed,portal_needed,rebind_needed,ready,history}`
- `packet_truth` in `{heuristic,shell_reported,nonce_verified,object_composed}`
- `accept_mode` in `{word,fragment,full}`

That would let the terminal render one honest ladder from popup hint to trusted rerunnable command packet, instead of flattening everything into “there was a completion and then a command happened.”

## Activation baton / arming / active-control events

A stronger ViewFS shell-terminal protocol should probably carry one narrow family of interaction-truth events so clicks, shortcuts, and portal callbacks do not have to smuggle semantics through invisible UI folklore.

### Activation baton event
Fields:
- `baton_id`
- `source_kind` in `{key,click,shortcut,notification,portal_result,unknown}`
- `evidence_kind` in `{transient_activation,sticky_activation,user_serial,foreground_privilege,activation_token,unknown}`
- `baton_state` in `{fresh,passed,consumed,expired,refused,history}`
- `source_block_id` (optional)
- `receipt_id` (optional)

Why:
- the shell should be able to say `fresh gesture proof`, `transferred baton`, or `expired` without pretending those are live handles or durable refs.

### Armed / enabled lane event
Fields:
- `lane_id`
- `lane_kind` in `{chooser,route_plan,input_capture,focus_transfer,other}`
- `lane_state` in `{prepared,waiting_for_baton,enabled,active,ended,cancelled,history}`
- `baton_id` (optional)
- `subject_id` (optional)
- `receipt_id` (optional)

Why:
- `prepared` / `enabled` must stay visibly distinct from `active now`.

### Active-control event
Fields:
- `control_id`
- `control_kind` in `{foreground_turn,input_capture,shortcut_session,portal_activation,other}`
- `control_state` in `{requested,granted,denied,active,ended,history}`
- `grantor_kind` in `{shell,portal,compositor,os,unknown}`
- `baton_id` (optional)
- `receipt_id` (optional)

Why:
- a narrow current-control truth should be renderable without masquerading as durable authority.


## Identity / placement / rights / affordance events

A stronger ViewFS shell-terminal protocol should probably carry one narrow family of semantic events so action menus are driven by exact truth instead of path folklore.

### Placement event
Fields:
- `object_id`
- `placement_id`
- `view_id`
- `parent_anchor` (optional)
- `display_name` (optional)
- `placement_state` in `{bound_here,also_bound_elsewhere,history_only,unknown}`
- `receipt_id` (optional)

Why:
- one object can have several placements, and the shell should be able to render `same object, different placement` without laundering names into identity.

### Rights summary event
Fields:
- `subject_id`
- `handle_id` (optional)
- `rights_summary[]`
- `rights_state` in `{live,attenuated,locator_only,history_only,unknown}`
- `receipt_id` (optional)

Why:
- current handle rights should stay visibly separate from object identity and from provider-advertised verbs.

### Affordance advertisement event
Fields:
- `subject_id`
- `placement_id` (optional)
- `affordance[]`
- `advertiser_kind` in `{provider,shell_adapter,policy_overlay,mixed,unknown}`
- `affordance_state` in `{current,partial,history_only,unknown}`
- `receipt_id` (optional)

Why:
- supported verbs should be inspectable and dynamically updateable without pretending they are current authority.

### Action availability event
Fields:
- `subject_id`
- `verb`
- `availability` in `{ready,needs_wider_handle,invalid_at_placement,provider_unsupported,policy_prompt,history_only,unknown}`
- `basis[]` in `{placement,rights,provider_affordance,policy,history}`
- `receipt_id` (optional)

Why:
- one future shell should be able to say why a verb is missing or blocked instead of guessing or failing late.



## Cursor / watermark / follow events

A stronger ViewFS shell-terminal protocol should probably carry one narrow family of semantic events so live follow/query panes can tell the truth without leaking provider folklore into transcript text.

### Continuation cursor event
Fields:
- `subject_id`
- `cursor_id`
- `provider_kind`
- `cursor_state` in `{current,expired,reset_required,history_only,hidden}`
- `scope_id` (optional)
- `receipt_id` (optional)

Why:
- provider continuation tokens are useful but should stay visibly distinct from watermarks, object refs, and current rendered state.

### Sync watermark event
Fields:
- `subject_id`
- `watermark_kind` in `{resource_version,event_id,clock_id,opaque_cut,other}`
- `watermark_value`
- `watermark_state` in `{caught_up_through,last_seen,history_only,unknown}`
- `receipt_id` (optional)

Why:
- a processed-through point is one very useful honesty artifact, but it is not the same thing as a live subscription.

### Follow state event
Fields:
- `subject_id`
- `follow_id`
- `follow_kind` in `{watch,longpoll,stream,tail,other}`
- `follow_state` in `{starting,waiting,active,paused,ended,history_only}`
- `watermark_value` (optional)
- `receipt_id` (optional)

Why:
- `waiting for more` should stay visibly distinct from `current snapshot already rebuilt`.

### Gap verdict event
Fields:
- `subject_id`
- `gap_kind` in `{expired_cursor,resource_version_too_old,must_rescan,provider_reset,root_changed,remote_risk,unsupported,unknown}`
- `repair_hint[]`
- `last_good_watermark` (optional)
- `receipt_id` (optional)

Why:
- the shell should be able to render specific repair truth instead of one generic stale badge.

## Validator / draft / commit events

A stronger ViewFS shell-terminal protocol should probably carry one narrow family of semantic events so editing panes can tell the truth without leaking backend folklore into transcript text.

### Observed validator event
Fields:
- `subject_id`
- `validator_kind` in `{etag,generation,metageneration,revision,digest,epoch,other}`
- `validator_strength` in `{strong,weak,profiled,heuristic,unknown}`
- `comparison_profile` (optional)
- `validator_value`
- `validator_state` in `{current_basis,stale_basis,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the exact basis a user/tool observed should stay visibly distinct from draft, hold, and commit outcome state.
- the shell should also know whether the basis is strong, weak, or profile-shaped before it offers repair/commit shortcuts.

### Writable session event
Fields:
- `subject_id`
- `draft_id`
- `draft_state` in `{private,dirty,sealed,rebased,orphaned,history_only}`
- `draft_owner_kind` in `{shell,provider,helper,unknown}`
- `receipt_id` (optional)

Why:
- one local writable session is useful truth, but it is not the committed durable version.

### Write hold event
Fields:
- `subject_id`
- `hold_id`
- `hold_kind` in `{exclusive,advisory,lease,lock,other}`
- `hold_state` in `{current,renewable,expired,uncertain,history_only}`
- `ttl_ms` (optional)
- `receipt_id` (optional)

Why:
- coordination holds should be inspectable without pretending they are the exact commit predicate.

### Commit outcome event
Fields:
- `subject_id`
- `commit_mode` in `{if_match,if_absent,under_hold,unconditional,other}`
- `basis_validator` (optional)
- `winning_validator` (optional)
- `outcome` in `{committed,stale_basis,hold_failed,policy_denied,already_reflected,history_only}`
- `receipt_id` (optional)

Why:
- the shell should be able to say what basis a commit used and what durable version actually won.


## Delta/apply state adjunct (revision-081 sketch)

When a block or object card reflects reconstruction/update work rather than a full fetch, emit a bounded adjunct that can carry:
- `recipe_state` in `{none,present,history_only}`
- `basis_state` in `{unknown,exact_local,local_unverified,missing,mismatched,history_only}`
- `apply_state` in `{none,pending,running,verified,abandoned,history_only}`
- `fallback_state` in `{none,full_fetch_used,full_fetch_required,policy_blocked}`
- optional `result_lineage` text such as `rebuilt_from` or `fetched_whole_target`

This adjunct is explanatory shell truth only.
It is not itself a delta format, not a durable object ref, and not a portable authority ticket.

## Activation/handoff adjunct (revision-082 sketch)

When a launch, courier event, or adoption result needs stronger truth than plain text, emit a bounded adjunct that can carry:
- `carrier_kind` in `{activation_slot,portal_result,courier_offer,route_result,history_only}`
- `carrier_label` (optional)
- `live_class` in `{live_handle,staged_bytes,object_ref,receipt_only,unknown}`
- `issuer_witness_kind` in `{issuer_badge,peer_creds,portal_request,route_sheet,shell_only,unknown}`
- `copy_relation` in `{original_here,duplicate,attenuated,adopted_local,unknown}`
- `object_ref_state` in `{known_exact,known_alias_only,unknown,history_only}`
- `reopen_lane` in `{none,portal,document_handle,continuity_locker,other,unknown}`
- optional `child_slot_id`
- optional `receipt_id`

This adjunct is explanatory shell truth only.
It is not itself a durable authority ticket, not a proof of trust, and not a commitment to one final import/continuity protocol.



## Publication/locality adjunct (revision-083 sketch)

When an object-ish card, chooser result, or pane-local bind needs stronger truth than a plain path string, emit a bounded adjunct that can carry:
- `store_state` in `{not_local,local_object,local_descriptor_only,unknown}`
- `projection_state` in `{none,portal_view,provider_view,launch_only_projection,unknown}`
- `live_handle_state` in `{none,held_here,held_elsewhere_known,unknown}`
- `publication_state` in `{none,published_here,published_elsewhere_known,published_to_child,unknown}`
- `publication_sites[]` (small bounded labels)
- `object_ref_state` in `{known_exact,known_alias_only,unknown}`
- optional `request_or_session_id`
- optional `receipt_id`

This adjunct is explanatory shell truth only.
It is not itself a durable ticket, not a proof that one path is universal, and not a commitment to one final object-store or portal schema.

## Open-route and ambient-debt sideband events

In addition to prompt/input/output and paste markers, the shell/terminal protocol should probably admit a small family of access-lane events:
- `open-route-start`
- `open-route-selected-lane`
- `portal-request-issued`
- `ambient-debt-incurred`
- `publication-created`
- `open-route-receipt`

Useful fields include:
- command/block id,
- lane (`handle`, `rooted`, `portal`, `ambient`),
- root/view or publication id if relevant,
- mediator/request id if relevant,
- resulting handle/publication/receipt ids,
- and a small debt severity bit.

This sideband should stay descriptive rather than normative.
It exists so the shell and terminal can tell the truth about what happened, not to freeze one final backend or import mechanism.


## Protocol hints for discoverability truth
Useful sideband rows to explore:
- `candidate-suggested`
- `fit-quality-declared`
- `browse-gate-requested`
- `browse-gate-granted`
- `exact-name-open-attempted`
- `exact-name-open-succeeded`
- `result-history-only`

These make it possible to build browse/search/open chrome without lying about whether the actor actually held authority or only received advice.

## Protocol hints for advert/readiness truth
Useful sideband rows to explore:
- `presence-advertised`
- `presence-withheld`
- `readiness-declared`
- `readiness-decayed`
- `grant-needed-declared`
- `grant-acquired`
- `presence-withdrawn`
- `presence-history-only`

These make it possible to build chooser/provider/palette chrome without lying about whether the actor merely saw an advert, saw a freshness-scoped ready bit, still needed a mediation step, or already held direct authority.


## Protocol hints for provider-ready / local-realized truth
Useful sideband rows to explore:
- `provider-ready-declared`
- `reacquire-required`
- `reacquire-satisfied`
- `local-realization-started`
- `local-realization-finished`
- `local-realization-failed`
- `provider-owned-utility`
- `offline-fog-declared`

These make it possible to build truthful `make local` and restore/repair chrome without lying about whether something merely could be supplied later versus already exists here now.


## Protocol hints for possession / invocability truth
Useful sideband rows to explore:
- `possession-declared`
- `freshness-declared`
- `freshness-expired-for-action`
- `step-up-required`
- `presence-required`
- `challenge-satisfied`
- `challenge-failed`
- `invokable-now`
- `invocability-history-only`

These make it possible to build truthful `why not now?` chrome without lying about whether something merely exists locally versus is actually usable for the current action.

## Invocability adjunct (revision-089 sketch)

When a block, object card, or action row needs stronger truth than plain text, emit a bounded adjunct that can carry:
- `possession_state` in `{none,claim_only,held_here,held_elsewhere_known,local_realized,unknown}`
- `freshness_state` in `{unknown,fresh_enough,aging,too_old_for_action,history_only}`
- `step_up_state` in `{none,required,satisfied_for_attempt,failed,history_only}`
- `presence_state` in `{none,required,satisfied_for_attempt,failed,history_only}`
- `invocability_state` in `{unknown,not_invokable_yet,invokable_now,spent,history_only}`
- optional `challenge_ref`
- optional `receipt_id`

This adjunct is explanatory shell truth only.
It is not itself an assurance token, not a portable login-state export, and not a commitment to one final auth-mediation substrate.


### 16. Watch / status carrier event
Fields:
- `subject_id`
- `carrier_kind` in `{introspection,status_list,ocsp,watch_event,other}`
- `carrier_source`
- `watch_freshness` in `{current,aging,stale,unknown}`
- `status_purpose` in `{refresh,revocation,suspension,message,other}`
- `receiver_stance` in `{advisory,suspend,quarantine,ignore,unknown}`
- `successor_hint` in `{none,available,required,adopted,unknown}`
- `receipt_id` (optional)

Why:
- standing-watch truth should be protocol-visible so the shell and terminal can show later status, local stance, and successor posture without screen scraping.

### 17. Hold / quarantine event
Fields:
- `subject_id`
- `hold_kind` in `{none,suspend,attenuate,quarantine,withdrawn}`
- `hold_scope` in `{action,pane,session,workspace,unknown}`
- `reason_summary`
- `started_ts`
- `receipt_id` (optional)

Why:
- local narrowing needs to be a first-class transcript truth, not a hidden side effect or one generic denial code.


## Protocol hints for lend/export truth
Useful sideband rows to explore:
- `share-posture-declared`
- `duplicate-local-available`
- `live-lend-available`
- `live-lend-denied`
- `representation-export-available`
- `tty-transfer-available`
- `share-route-selected`
- `share-receipt-issued`

These make it possible to build truthful share/send/export chrome without lying about whether the actor held the thing, could only duplicate it locally, could lend it live, or could only export a weaker representation.

## Lend/export adjunct (revision-091 sketch)

When a block, object card, or action row needs stronger truth than plain text, emit a bounded adjunct that can carry:
- `possession_state` in `{none,held_here,held_elsewhere_known,history_only,unknown}`
- `duplicate_local_state` in `{none,available,narrowed_only,forbidden,unknown}`
- `live_lend_state` in `{none,available,narrowed_only,single_use_only,forbidden,unknown}`
- `representation_export_state` in `{none,projected_doc,bytes_snapshot,claim_export,receipt_only,unknown}`
- `share_lane_fit` in `{local_copy,socket_lend,portal_export,tty_transfer,other,none,unknown}`
- optional `share_receipt_id`
- optional `representation_kind`

This adjunct is explanatory shell truth only.
It is not itself a capability, not a mandatory transport ABI, and not a commitment to one final export taxonomy.

## Protocol hints for borrow/project/localize truth
Useful sideband rows to explore:
- `borrow-posture-declared`
- `wrapper-attach-available`
- `project-here-available`
- `localize-here-available`
- `locality-transition-selected`
- `locality-receipt-issued`

These make it possible to build truthful import/open/localize chrome without lying about whether the actor is still borrowing through another provider, merely attached through a wrapper, projected into one scoped view, or actually localized here.

## Borrow/project/localize adjunct (revision-092 sketch)

When a block, object card, or action row needs stronger truth than plain text, emit a bounded adjunct that can carry:
- `foreign_backing_state` in `{none,provider_backed,portal_backed,service_backed,history_only,unknown}`
- `attach_state` in `{none,wrapper,relay,projected,localized,forbidden,unknown}`
- `projection_state` in `{none,session_view,durable_view,forbidden,unknown}`
- `localization_state` in `{none,copy,replica,object_store,history_only,unknown}`
- optional `locality_receipt_id`
- optional `provider_label`

This adjunct is explanatory shell truth only.
It is not itself a capability, not a mandatory provider ABI, and not a commitment to one final localization taxonomy.



## Route-slip / sidecar / sink-tray semantic marks
- `route-slip` — typed designation-only route envelope suitable for inspect/copy/dry-run.
- `route-sidecar` — adjunct route material such as wallet digest, URI-grant candidate, representation offers, portal request, or proof-needed posture.
- `sink-tray` — receiver-side outcome row that records `representation`, `projection`, `bind`, `localization`, `declined`, or `history-only`.
- `route_posture` in `{designation_only,route_plus_sidecar,route_plus_narrowed_sidecar,unknown}`
- `sink_accept_state` in `{representation,projection,bind,localization,declined,history_only,unknown}`

### 16. Privilege bracket / caller-context event
Fields:
- `block_id`
- `bracket_state` in `{none,active,ended}`
- `borrowed_authority_class[]`
- `caller_frame_class[]`
- `deny_only_state` in `{none,hint_present,veto_fired}`
- `receipt_id` (optional)

Why:
- the shell and terminal should be able to render bracket rails, caller badges, borrowed-authority drawers, and deny-only shutters from explicit metadata instead of helper folklore or prompt heuristics.

## Protocol hints for native/adapted/coerced truth
Useful sideband rows to explore:
- `attach-mode-declared`
- `adapter-required`
- `relay-required`
- `representation-coercion-available`
- `representation-coercion-selected`
- `make-local-for-native-available`
- `attach-fidelity-receipt-issued`

These make it possible to build truthful attach/import/open chrome without lying about whether the actor is using a directly native lane, one adapter/relay, one translated representation, or one explicit local-fidelity upgrade.

## Native/adapted/coerced adjunct (revision-095 sketch)

When a block, object card, or action row needs stronger truth than plain text, emit a bounded adjunct that can carry:
- `attach_mode` in `{none,native,adapter,relay,coerced,localized,history_only,unknown}`
- `semantic_fidelity` in `{same_object,translated_representation,preview_only,local_copy,unknown}`
- `representation_kind` in `{none,mime_variant,preview_render,export_only,other,unknown}`
- `adapter_class` in `{none,fd_wrapper,runtime_shim,relay_service,projected_fs,other,unknown}`
- optional `attach_fidelity_receipt_id`
- optional `provider_label`

This adjunct is explanatory shell truth only.
It is not itself a capability, not a mandatory wrapper ABI, and not a commitment to one final representation taxonomy.



### 53. Startup truth / customization posture event

The shell protocol should be able to emit startup-truth events rather than forcing the terminal to guess from prompt text or environment drift.

Useful fields:
- `startup_truth` in `{built_in_only,reviewed_bundle,host_profile_active,host_profile_blocked,project_hook_pending,project_hook_active,project_hook_denied,history_only,unknown}`
- `custom_bundle_ids` as reviewed bundle identifiers/digests
- `startup_profile_sources` as descriptive non-secret source hints
- `project_hook_state` in `{none,pending,allowed,denied,stale_reapproval,unknown}`
- `prompt_provenance` in `{built_in,bundle,profile,project_hook,mixed,unknown}`

These make it possible to build clean-start lamps, bundle ledgers, hook quarantine gutters, and replay-without-hooks UI without screen scraping or ambient guesses.


### 37. Command-surface resolution event
The shell should be able to emit enough metadata for the terminal to explain command-surface truth without guessing.

Suggested fields:
- `typed_token`
- `lexical_expansion` (optional)
- `winner_kind` (`builtin_verb`, `custom_command`, `overlay_command`, `key_action`, `external_launch`, `ambiguous`, `history_only`)
- `winner_name`
- `overlay_ids` (optional)
- `shadowed_candidates` (optional list)
- `key_table` (optional)
- `receipt_id` (optional)

This is intentionally explanatory. It should not become one mandatory shell-language or palette protocol.


### 41. Parse/diagnostic state event
- `buffer_state` in `{editing,dirty,accepted,history}`
- `parse_state` in `{none,partial,recovered,exact,stale}`
- `diagnostic_kind` in `{none,syntax,lint,hint,policy_advice,history}`
- `diagnostic_source` in `{shell_parser,external_linter,policy_helper,history,unknown}`
- `packet_stage` MAY remain stronger than parse/diagnostic state and should not be inferred solely from it

Notes:
- a parser/highlighter event must stay weaker than a compiled packet event;
- diagnostics are advisory unless some stronger gate event says otherwise;
- history-sourced hints must stay visibly distinct from current-buffer analysis.

### 18. Room context diff / child recipe event
Fields:
- `parent_room_id`
- `candidate_room_id` (optional)
- `recipe_id`
- `inheritance_posture`
- `requested_imports[]`
- `granted_imports[]`
- `bound_imports[]`
- `skipped_imports[]`
- `result_class` in `{prepared,committed,partial,blocked,receipt_only}`

Why:
- split/rerun/helper workflows should be inspectable as parent-room truth versus candidate child-room truth rather than one vague clone/open action.

### 54. Namespace switchboard / overlay / anchor-death event
The shell protocol should be able to emit enough metadata for the terminal to keep switch plans, live binds, in-flight sessions, local overlays, and dead anchors separate.

Useful fields:
- `switch_target_id` (optional)
- `switch_target_state` in `{planned,live,pending_session,granted_not_bound,receipt_only,unknown}`
- `live_room_binding_id` (optional)
- `portal_session_id` (optional)
- `portal_session_state` in `{request_pending,user_step_needed,granted_not_bound,bound_here,expired,closed,unknown}`
- `overlay_scope` in `{device_local,activity_local,workspace_local,session_local,unknown}`
- `overlay_posture` in `{active,stale_after_switch,clearable,receipt_only,unknown}`
- `anchor_survival` in `{exact,approximate,replaced,expired,restore_bounded,reset,unknown}`
- `reset_scope` in `{overlay_only,import_session_only,room_binding,whole_room,layout_only,unknown}`
- `recommended_next_verbs` (optional list)

These fields are intentionally explanatory and diagnostic.
They should not commit ViewFS to one final storage or transport encoding.

### 55. Restart shelf / wake-kit / namespace-pin event
The shell protocol should be able to emit enough metadata for the terminal to keep startup delivery, restart continuity, namespace pins, and live room binds separate.

Useful fields:
- `wake_kit_id` (optional)
- `wake_kit_state` in `{prepared,delivered,partial,stale,discarded,none,unknown}`
- `restart_locker_id` (optional)
- `restart_locker_state` in `{held_by_manager,delivered_this_start,cleared,expired,discarded,none,unknown}`
- `namespace_pin_state` in `{none,fd_pinned,bind_pinned,provider_pinned,pin_dropped,pin_unknown}`
- `continuity_grade` in `{warm_exact,warm_partial,cold_repair,cold_fresh,receipt_only,unknown}`
- `related_anchor_id` (optional)
- `recommended_next_verbs` (optional list)
- `revalidation_fence` in `{none,before_replay,before_write,before_share,before_escalation,unknown}`

These fields are intentionally explanatory and diagnostic.
They should not commit ViewFS to one final locker storage model or one final room-manager split.


### 17. Renewal window event
Fields:
- `subject_id`
- `window_state` in `{active,due_soon,missed,unsupported,unknown}`
- `renewed_through` (optional)
- `renew_action_available` (bool)
- `receipt_id` (optional)

Why:
- the terminal should be able to render `renewed through`, `renew now`, and `missed renewal` without guessing from text or from a generic status line.

### 18. Retry advice event
Fields:
- `subject_id`
- `retry_state` in `{not_before,still_processing,advice_missing,expired,unknown}`
- `retry_after_seconds` (optional)
- `retry_at` (optional)
- `issuer_scope`

Why:
- rerun, rebind, reconsent, and refresh affordances should be able to say when a follow-up is premature instead of either looking dead or encouraging blind retry.

### 19. Repair gate event
Fields:
- `subject_id`
- `gate_state` in `{open,cooling_down,repair_required,manual_clear_required,cleared}`
- `trigger_kind`
- `clear_action_available` (bool)
- `receipt_id` (optional)

Why:
- the shell and terminal should be able to distinguish `waiting`, `stop auto-helping`, and `operator explicitly cleared this` without flattening all three into one stale badge.


### 42. Warmth / restore / deferred-repair event
- `room_id`
- `bind_state` in `{live,receipt_only,unknown}`
- `visibility_state` in `{foreground,warming,background_serving,draining,history_only,unknown}`
- `keep_warm_state` in `{allowed,clamped,expiring,denied,unknown}`
- `restore_state` in `{allowed,proposed,denied,reconsent_needed,failed_last_time,none,unknown}`
- `deferred_repair_state` in `{none,queued,running,waiting_user,waiting_network,completed_ready,failed_review_required,unknown}`
- `quality_state` in `{rich,basic,approximate,none,unknown}`
- `not_before_at` (optional)
- `receipt_id` (optional)

This makes it possible to build warmth rails, login lanterns, defer drawers, and quality chips without screen scraping or one fake `backgrounded` bit.

### 43. Attention / interrupt / ack event
- `room_id`
- `bind_state` in `{live,receipt_only,unknown}`
- `attention_cue` in `{none,activity,bell,silence,follow_up_unread,receipt_only,unknown}`
- `interrupt_grade` in `{none,badge_only,banner_candidate,urgent_request,urgent_clamped,critical_requires_separate_grant,suppressed,unknown}`
- `quiet_state` in `{none,focus_quiet,presentation_quiet,workspace_quiet,coalescing_until_foreground,expired,unknown}`
- `ack_state` in `{none,unread,acknowledged,dismissed_to_receipt,follow_up_row_open,follow_up_row_closed,unknown}`
- `coalesced_count` (optional)
- `receipt_id` (optional)

This makes it possible to build attention pips, interrupt ladders, quiet shutters, and ack ledgers without screen scraping or one fake `alert` bit.

### 44. Summon / activation / foreground / secure-entry event
- `room_id`
- `bind_state` in `{live,receipt_only,unknown}`
- `summon_state` in `{none,glance_me,result_ready,review_wants_front,helper_wants_eyes,receipt_only,unknown}`
- `activation_baton_state` in `{none,fresh,forwarded,consumed,expired,invalid,unknown}`
- `foreground_turn_state` in `{background,raise_requested,frontmost,focused,declined,stolen_back,receipt_only,unknown}`
- `secure_entry_state` in `{none,host_local,requested,entered,exited,policy_denied,not_a_trusted_surface,unknown}`
- `quality_state` in `{rich,approximate,prompt_only,none,unknown}`
- `receipt_id` (optional)

This makes it possible to build summon beacons, activation baton chips, front latches, secure-entry shutters, and quality badges without screen scraping or one fake `focus` bit.


### 45. Observe mirror / automation / secure-entry clamp event
- `room_id`
- `bind_state` in `{live,receipt_only,unknown}`
- `mirror_state` in `{none,semantic,screen,redacted,delayed,history_only,unknown}`
- `automation_lease_state` in `{none,observe_only,rehearse_only,inject_allowed,remote_support,expired,revoked,unknown}`
- `synthetic_input_state` in `{none,enabled_pending,active,rehearsal_only,blocked,expired,unknown}`
- `secure_entry_exclusion_state` in `{none,mirror_redacted,input_blocked,secure_field,trusted_chooser,secure_review,policy_denied,unknown}`
- `quality_state` in `{rich,semantic_only,mirror_only,prompt_local,none,unknown}`
- `receipt_id` (optional)

This makes it possible to build mirror strips, lease chips, rehearsal rails, secure-entry curtains, and quality badges without screen scraping or one fake `automation active` bit.

### 46. Projection / publication / localization event
- `subject_id`
- `room_id`
- `live_bind_state` in `{live,receipt_only,unknown}`
- `projection_site_state` in `{none,provider_projection,portal_projection,placeholder_projection,wrapper_projection,unknown}`
- `published_alias_state` in `{none,published_here,published_to_child,staged_only,history_only,unknown}`
- `locality_state` in `{foreign_backed,placeholder_only,hydrated_provider_owned,replica_local,local_object,history_only,unknown}`
- `quality_state` in `{rich,provider_reported,partial,history_only,unknown}`
- `receipt_id` (optional)

This makes it possible to build site ledgers, provider halos, bind-here ladders, and multi-site locality diffs without guessing from displayed paths.

### 47. Base / upper / merge / publish event
- `subject_id`
- `room_id`
- `live_bind_state` in `{live,receipt_only,unknown}`
- `base_stack_state` in `{none,provider_base,portal_base,generated_base,multi_base,history_only,unknown}`
- `upper_overlay_state` in `{none,ephemeral_upper,persisted_upper,whiteout_only,sealed_upper,history_only,unknown}`
- `merged_presentation_state` in `{none,base_only,upper_only,merged,opaque_filtered,history_only,unknown}`
- `publish_result_state` in `{none,published_alias,sealed_local,pushed_back,exported_new,rejected,history_only,unknown}`
- `quality_state` in `{rich,provider_reported,partial,history_only,unknown}`
- `receipt_id` (optional)

This makes it possible to build stack badges, whiteout ghosts, merge rails, and commit ladders without guessing from one flattering merged path.



### 16. Pushback basis / verdict event
Fields:
- `subject_id`
- `draft_id` (optional)
- `basis_kind` in `{etag,generation,metageneration,expected_old,create_if_absent,lease_plus_expected_old,unknown}`
- `basis_value`
- `provider_verdict` in `{pending,accepted,rejected_precondition,rejected_conflict,rejected_lease,unknown}`
- `provider_new_state` (optional)
- `local_adopt_state` in `{keep_draft,fast_forward_local,fork_local,merge_needed,receipt_only,unknown}`
- `visibility_quality` in `{rich,basic,heuristic}`

Why:
- the terminal should be able to render basis lamps, verdict cards, and adopt rails without guessing from error strings or commit output.


### 56. Intent-key / retry-braid / sameness event
- `subject_id`
- `intent_key_state` in `{none,fresh,reused_same_payload,reused_changed_payload,pruned,expired,unknown}`
- `intent_lineage_id` (optional)
- `canonical_match_state` in `{exact_match,changed_basis_only,payload_mismatch,cannot_prove,unknown}`
- `provider_duplicate_state` in `{none,replayed_prior_result,concurrent_duplicate,rejected_mismatch,unknown}`
- `provider_ticket_state` in `{none,present,lost,expired,unknown}`
- `local_adopt_state` in `{none,keep_draft,fast_forward_local,fork_local,receipt_only,unknown}`
- `visibility_quality` in `{rich,basic,heuristic}`

Why:
- the terminal should be able to render intent lamps, retry braids, sameness chips, and not-the-same-request shutters without guessing from error strings or log text.

## Add one more family of shell-visible truth for future provider work
If ViewFS ever carries richer async/provider metadata, the terminal protocol should be able to annotate blocks with optional fields such as:
- `viewfs.caller_context_state = caller_child | cleanup_root | provider_root | watch_only | history_only`
- `viewfs.cutoff_state = inherited | narrowed | none | expired | unknown`
- `viewfs.cancel_state = active | requested | propagated | acknowledged | cleanup_running | exceeded | unknown`
- `viewfs.provider_followup = none | operation_ticket | settling | settled | expired`

These should stay descriptive.
They should not silently grant background authority or promise that detached continuation exists forever.

### 57. Object facet / kit / published-name event
- `subject_id`
- `object_identity_state` in `{exact_object,derived_projection,unknown}`
- `facet_state` in `{none,inspect,edit,publish,automate,bytes_only,mixed,history_only,unknown}`
- `facet_group_id` (optional opaque local identifier)
- `kit_state` in `{none,single_facet,grouped_kit,kit_bound_partially,history_only,unknown}`
- `live_bind_state` in `{none,bound_here,bound_elsewhere,staged_only,history_only,unknown}`
- `published_name_state` in `{none,published_here,published_elsewhere,name_only,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render facet chips, kit cards, bind-one-facet-here ladders, and name-only ghosts without guessing from tool names or ambient paths.


### 58. Descriptor / verify / live-use facet event
- `subject_id`
- `descriptor_state` in `{none,descriptor_only,descriptor_plus_locator,proof_only,history_only,unknown}`
- `verify_state` in `{none,verify_only,verify_via_live_handle,history_only,unknown}`
- `live_use_state` in `{none,read_now,edit_now,publish_now,mixed,history_only,unknown}`
- `bind_state` in `{none,bound_here,bound_elsewhere,staged_only,history_only,unknown}`
- `opaque_token_state` in `{none,present_returnable,present_sealed,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render proof cards, verify chips, read rails, publish rails, and opaque return-token hints without guessing from filenames, copied strings, or ambient path folklore.

### 59. Object-core / byte-proof / shape-hash / live-facet event
- `subject_id`
- `object_core_state` in `{same_core,related_derivative,core_unknown,history_only,unknown}`
- `byte_proof_state` in `{none,raw_bytes_proven,canonical_form_proven,proof_stale,history_only,unknown}`
- `shape_hash_state` in `{none,root_block_hash,chunked_dag_address,closure_store_address,canonical_shape_hash,history_only,unknown}`
- `designation_state` in `{none,name_only,locator_only,published_name,docref_like,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,automation_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render object-core badges, byte-proof lamps, shape-hash drawers, and facet rails without guessing from filenames, digests, or copied strings.

### 60. Authority-core / review-envelope / explain-sidecar / live-bind event
- `subject_id`
- `authority_core_state` in `{none,stable_core,core_changed,correlation_only,history_only,unknown}`
- `review_envelope_state` in `{none,descriptive_only,volatile_fields_present,redacted,history_only,unknown}`
- `explain_sidecar_state` in `{none,graph_digest,diff_digest,basis_record,provenance_record,mixed,history_only,unknown}`
- `live_bind_state` in `{none,bound_here,bound_elsewhere,live_narrower,live_wider,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render core stamps, envelope drawers, sidecar lamps, and live rails without guessing from one flattering wallet/card object.


### 61. Object-core / designation / head-token / order-scope / supersession / live-facet event
- `subject_id`
- `object_core_state` in `{same_core,related_derivative,core_unknown,history_only,unknown}`
- `designation_state` in `{none,name_only,local_alias,published_name,docref_like,history_only,unknown}`
- `head_token_state` in `{none,current_head,noncurrent_head,stale_head,incomparable_head,history_only,unknown}`
- `order_scope_state` in `{none,same_scope,parallel_scope,scope_mismatch,order_unknown,history_only,unknown}`
- `supersession_state` in `{none,replaced_by,newer_than,restored_from,tombstoned,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render head badges, order pips, supersession ladders, and facet rails without guessing from filenames, paths, or one overloaded version column.

### 62. Semantic-record / payload / wrapper / wire-copy / live-facet event
- `subject_id`
- `record_state` in `{same_meaning,changed_meaning,review_only,unknown}`
- `payload_state` in `{same_payload,different_payload,profile_mismatch,not_computed,unknown}`
- `payload_profile` (optional)
- `wrapper_state` in `{none,signed,payload_type_authenticated,detached_payload,wrapper_changed,wrapper_only,unknown}`
- `wire_copy_state` in `{none,transport_copy,logged_copy,export_copy,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render record cards, payload chips, wrapper seals, wire ghosts, and live rails without guessing from filenames, MIME labels, or one overloaded digest column.



### 63. Fresh-object / shared-backing / lineage / live-facet event
- `subject_id`
- `fresh_object_state` in `{none,fresh_object,derived_object,rebuilt_object,history_only,unknown}`
- `shared_backing_state` in `{none,shares_backing,backing_diverged,deep_copy,provider_hidden,history_only,unknown}`
- `lineage_state` in `{none,reflinked_from,snapshot_origin,explicit_parent,rebuilt_from,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render birth badges, backing ghosts, lineage ladders, and live rails without guessing from filenames, paths, or same-byte folklore.

### 64. Upload-session / part-coverage / completion-manifest / committed-object event
- `subject_id`
- `upload_session_state` in `{none,open,resuming,sealed_for_commit,committing,expired,aborted,history_only,unknown}`
- `part_coverage_state` in `{none,zero_parts,partial,offset_known,assembly_list_ready,cannot_prove,history_only,unknown}`
- `completion_manifest_state` in `{none,present,provider_hidden,submitted,rejected,history_only,unknown}`
- `committed_object_state` in `{none,created_here,replaced_existing,versioned_commit,history_only,unknown}`
- `abort_state` in `{none,requested,aborted,expired,replaced,cleanup_pending,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render session beads, part gauges, seal ladders, abort ash, and live rails without guessing from progress bars, temporary filenames, or provider log strings.


### 65. Assembly-recipe / member-descriptor / aggregate-object / realized-work-surface event
- `subject_id`
- `assembly_recipe_state` in `{none,declared,reviewed,stale,denied,history_only,unknown}`
- `member_descriptor_state` in `{none,complete,missing,provider_hidden,stale,replaced,history_only,unknown}`
- `aggregate_object_state` in `{none,assembled,rejected,superseded,history_only,unknown}`
- `realized_work_surface_state` in `{none,realized_here,realized_elsewhere,evicted,rebuildable,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render recipe cards, member rails, aggregate seals, unpack lamps, and live rails without guessing from filenames, package extensions, or one flattering `bundle` column.


### 66. Staging-capsule / seal-state / courier-handoff / committed-object event
- `subject_id`
- `staging_capsule_state` in `{none,draft,exact_bytes_ready,discarded,history_only,unknown}`
- `seal_state` in `{none,open,sealed_for_review,future_writes_blocked,locked,history_only,unknown}`
- `courier_handoff_state` in `{none,offered_locally,received_locally,not_published,history_only,unknown}`
- `committed_object_state` in `{none,not_committed,committed_here,published_now,discarded,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render capsule cards, seal shutters, courier rails, commit lamps, and live rails without guessing from temp paths, editor folklore, or one flattering `draft` column.

### 67. Committed-object / retention / hold / purge event
- `subject_id`
- `committed_object_state` in `{none,committed_here,current_version,noncurrent_version,history_only,unknown}`
- `retention_state` in `{none,retain_until,policy_editable,policy_locked,satisfied,history_only,unknown}`
- `hold_state` in `{none,temporary_hold,event_hold,legal_hold,multiple_holds,history_only,unknown}`
- `purge_state` in `{none,eligible,blocked_by_retention,blocked_by_hold,lifecycle_pending,purged,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,delete_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render hold badges, retention rails, purge lamps, and live rails without guessing from one flattering `protected` column or one overloaded delete error.

### 68. Sealed-object / wrap-roster / rewrap / unwrap / clear-facet event
- `subject_id`
- `sealed_object_state` in `{none,sealed,typed_sealed,signed_and_sealed,history_only,unknown}`
- `wrap_roster_state` in `{none,one_wrap,multiple_wraps,provider_hidden,mixed_roster,history_only,unknown}`
- `rewrap_state` in `{none,planned,adding_recipient,dropping_recipient,rotating_wraps,done,failed,history_only,unknown}`
- `unwrap_state` in `{none,provider_bound,needs_mediator,unwrapable_here,cannot_unwrap_here,history_only,unknown}`
- `clear_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render seal badges, wrap rosters, rewrap ladders, unwrap rails, and clear rails without guessing from filenames, ciphertext blobs, or one flattering `encrypted` column.



### 69. Committed-object / durability-profile / redundancy-layout / repair / availability event
- `subject_id`
- `committed_object_state` in `{none,committed_here,current_version,noncurrent_version,history_only,unknown}`
- `durability_profile_state` in `{none,single_copy,replica_target,k_of_n_target,policy_hidden,history_only,unknown}`
- `redundancy_layout_state` in `{none,shares_placed,replicas_spread,placement_changed,layout_hidden,history_only,unknown}`
- `repair_state` in `{none,healthy,scrubbing,degraded,repairing,failed,history_only,unknown}`
- `availability_state` in `{none,retrievable,retrievable_with_degradation,provider_unavailable,unrecoverable,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render durability badges, layout ghosts, repair ladders, availability lamps, and live rails without guessing from one flattering `stored` column, provider dashboards, or stale operator folklore.

### 70. Committed-object / archive-tier / thaw-job / thawed-copy / expiry event
- `subject_id`
- `committed_object_state` in `{none,committed_here,current_version,noncurrent_version,history_only,unknown}`
- `archive_tier_state` in `{none,hot,cool,cold,archived,offline,history_only,unknown}`
- `thaw_job_state` in `{none,requested,pending,priority_high,failed,expired,history_only,unknown}`
- `thawed_copy_state` in `{none,temporary_copy,tier_changed,copy_target_ready,copy_target_pending,history_only,unknown}`
- `expiry_state` in `{none,expires_then,no_expiry_exposed,expired,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render frost badges, thaw beads, copy-thaw ladders, expiry lanterns, and live rails without guessing from one flattering `restored` column, stale provider dashboards, or old thaw receipts.


### 71. Committed-object / residency-profile / placement-realm / route-endpoint / egress-gate event
- `subject_id`
- `committed_object_state` in `{none,committed_here,current_version,noncurrent_version,history_only,unknown}`
- `residency_profile_state` in `{none,single_realm,dual_realm,cross_region,provider_hidden,history_only,unknown}`
- `placement_realm_state` in `{none,present_in_one_realm,present_in_multiple_realms,lagging,provider_hidden,history_only,unknown}`
- `route_endpoint_state` in `{none,nearest_route,primary_route,secondary_read,failover_lane,route_hidden,history_only,unknown}`
- `egress_gate_state` in `{none,local_only,cross_boundary_denied,review_needed,allowed_by_policy,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render realm badges, placement ghosts, route halos, egress shutters, and live rails without guessing from region labels, global endpoints, provider dashboards, or one flattering `replicated` column.

### 72. Committed-object / access-propagation / public-cache / cache-trail event
- `subject_id`
- `committed_object_state` in `{none,committed_here,current_version,origin_deleted,history_only,unknown}`
- `access_propagation_state` in `{none,settled,grant_pending,revoke_settling,config_propagating,provider_hidden,history_only,unknown}`
- `public_cache_state` in `{none,publicly_cacheable,stale_possible,purge_asked,cache_bypassed,purged,history_only,unknown}`
- `cache_trail_state` in `{none,hit,miss,forwarded,stored,trail_hidden,history_only,unknown}`
- `live_facet_state` in `{none,inspect_now,read_now,edit_now,publish_now,history_only,unknown}`
- `receipt_id` (optional)

Why:
- the terminal should be able to render truth badges, propagation echoes, cache ghosts, trail drawers, and live rails without guessing from one flattering `published` column, stale CDN folklore, or old revocation receipts.


## Folder-like surfaces need typed provenance
If the shell exposes folder-like rows over object-store backings, protocol metadata should admit at least: `browse.kind = prefix_projection | provider_folder | managed_folder | query_projection`, `listing.state = snapshot | live | partial | cached | stale_possible`, and an independent `bind.state` for whether the current room actually bound that surface. This keeps folder-like UI calm without making storage-prefix folklore the semantic center of ViewFS.

### 73. Launch-plan / bound-root / handle-slot / portal-ticket / live-bind event
- `subject_id`
- `plan_state` in `{none,drafted,reviewed,approved,rejected,launched,history_only,unknown}`
- `bound_root_state` in `{none,sealed_empty,synthetic_root,object_store_root,provider_projection,portal_adopted_subtree,compat_membrane,history_only,unknown}`
- `slot_table_state` in `{none,planned,exact_delivered,delivered_with_diff,failed_closed,history_only,unknown}`
- `portal_ticket_state` in `{none,request_drafted,chooser_open,needs_user,granted_not_bound,adopting,adopted,denied,expired,revoked,history_only,unknown}`
- `adoption_state` in `{none,external_result,staging_capsule,committed_object,published_bind,live_facet,failed,history_only,unknown}`
- `live_bind_state` in `{none,inspect_now,verify_now,read_now,edit_now,publish_now,delegate_now,receipt_only,ticket_only,history_only,unknown}`
- `currentness_witness` (optional digest / generation / ETag / revision / metageneration / provider witness)
- `receipt_id` (optional)

Why:
- the terminal should be able to render launch rehearsal cards, root badges, slot maps, import ticket trays, adoption ladders, and live-bind rails without guessing from path strings, provider sessions, inherited descriptors, or stale receipts.

## Revision 139 sketch: capability-flow semantic events

Reserve event-family names for future experimentation, without freezing a terminal protocol:

- `viewfs.capflow.snapshot`
- `viewfs.capflow.diff`
- `viewfs.capflow.gate_check`
- `viewfs.capflow.export_live`
- `viewfs.capflow.borrow_start`
- `viewfs.capflow.borrow_end`
- `viewfs.capflow.leak_verdict`
- `viewfs.capflow.receipt_link`

Candidate fields:

- `subject_id_local`
- `slot_id_local`
- `handle_family`
- `rights_summary`
- `custody_kind`
- `outflow_gate`
- `live_state`
- `snapshot_digest`
- `diff_digest`
- `receipt_digest`
- `redaction_level`
- `provider_currentness_witness_summary`
- `verdict`
- `uncertainty`

Rules for early prototypes:

- never emit raw bearer secrets;
- mark snapshots/diffs as non-authoritative;
- keep live handle events separate from receipt events;
- distinguish borrow/proxy/direct/materialize/receipt-only outflows;
- allow `unknown` verdicts when a provider or layer is not inspectable.


## Revision 140 restore / activation event sketch

A future terminal protocol should keep durable-root restore events as explanation, not authority. Candidate event names:

- `viewfs.root_commit.recorded`
- `viewfs.root_tip.fence_check`
- `viewfs.restore.intent`
- `viewfs.restore.resurrection_gate`
- `viewfs.restore.activation_preview`
- `viewfs.restore.activation_commit`
- `viewfs.restore.live_slot_map`
- `viewfs.restore.receipt`

Candidate fields:

```text
root_scope
root_commit_digest
parent_commit_digest
candidate_epoch
last_seen_epoch
witness_family
witness_summary
restore_intent_id
resurrection_gate_id
activation_target_id
activation_mode
live_slot_digest
live_slot_count
verdict
unsafe_rollback_profile
receipt_digest
redaction_level
```

Non-goal: exposing raw capability tokens, raw provider identifiers, or raw secret/key material through terminal metadata. These events should help users understand restore and activation without turning scrollback into a durable authority channel.

## Revision 141 GC / retention event sketch

A future terminal protocol should keep retention, runtime liveness, collection analysis, deletion choreography, and receipts as separate semantic events. Candidate event names:

- `viewfs.gc.root_set`
- `viewfs.gc.live_handle_root`
- `viewfs.gc.retention_record`
- `viewfs.gc.sweep_rehearsal`
- `viewfs.gc.finalizer_state`
- `viewfs.gc.collect_commit`
- `viewfs.gc.ash_receipt`

Candidate fields:

```text
object_core_digest
root_set_digest
live_handle_epoch
retention_record_id
retention_kind
retention_scope
issuer_subject_local
purpose_code
expires_at
sweep_candidate_id
collector_family
candidate_state
estimated_bytes
finalizer_id
finalizer_owner
collection_verdict
ash_receipt_digest
redaction_level
provider_uncertainty
```

Non-goal: exposing hidden object names, raw capability tokens, provider secrets, or enough root-graph detail to create a side channel. The protocol should explain why something is retained or gone without turning scrollback into a root database.

### 43. Quarantine / safe-open anti-laundering events

Future shell/terminal integrations may want explicit events for risky-content handling:

- `viewfs.quarantine.origin_evidence`
- `viewfs.quarantine.mark_state`
- `viewfs.safe_open.capsule_started`
- `viewfs.safe_open.residue_state`
- `viewfs.quarantine.derived_artifact`
- `viewfs.trust.clearance_decision`
- `viewfs.live_open.authority_state`
- `viewfs.quarantine.receipt`

Candidate fields:

```text
object_core_digest
origin_receipt_digest
origin_class
parent_digest
quarantine_mark_digest
risk_state
allowed_default_lane
blocked_active_classes
safe_open_capsule_id
materialization_digest
viewer_domain
active_content_posture
residue_policy
residue_summary_digest
derived_artifact_digest
derivation_kind
trust_clearance_id
clearance_scope
clearance_basis
clearance_expiry
live_open_facet_id
redaction_level
```

Guardrails:

- the event stream must not contain raw bearer tokens, raw origin locators, hidden provider account IDs, or unredacted content snippets by default;
- `safe_open.capsule_started` is not a trust-clearance event;
- `derived_artifact` is not a source-clearance event;
- `receipt` is not a durable reopen grant or live-open authority.

### 44. Archive/container extraction events

Future shell/terminal integrations may want explicit events for archive and container handling:

- `viewfs.container.envelope_inspected`
- `viewfs.container.member_claims`
- `viewfs.extract.plan_reviewed`
- `viewfs.extract.materialization_root_started`
- `viewfs.extract.member_capsule_created`
- `viewfs.extract.namespace_commit_requested`
- `viewfs.extract.live_facet_state`
- `viewfs.extract.receipt`

Candidate fields:

```text
container_digest
container_format
origin_receipt_digest
quarantine_mark_digest
member_claim_digest
raw_member_name_redacted
normalized_member_name
member_kind
link_target_redacted
collision_group_digest
path_guard_profile
extraction_plan_digest
plan_verdict
resource_budget_digest
materialization_root_id
member_capsule_id
namespace_commit_id
target_view_digest
live_facet_id
receipt_digest
redaction_level
```

Guardrails:

- terminal metadata must not carry raw bearer tokens, hidden provider paths, secret account ids, unredacted risky snippets, or enough member data to reconstruct quarantined content by default;
- `member_claims` is not a namespace listing;
- `plan_reviewed` is not materialization;
- `materialization_root_started` is not publication;
- `receipt` is not a reopen grant or retention root.

## Revision 144 protocol sketch: supply-chain evidence events

Candidate events for a future terminal protocol:

```text
viewfs.supply.inventory_claims.loaded
viewfs.supply.inventory_claims.redacted
viewfs.supply.locator_aliases.normalized
viewfs.supply.locator_aliases.ambiguous
viewfs.supply.advisory_view.updated
viewfs.supply.vex_statement.scoped
viewfs.supply.evidence_pack.verified
viewfs.supply.evidence_pack.expired
viewfs.supply.admission_verdict.issued
viewfs.supply.activation.rehearsed
viewfs.supply.activation.target_mismatch
viewfs.supply.live_facet.created
viewfs.supply.live_facet.revoked
viewfs.supply.receipt.written
```

Event rule: evidence events may update drawers and warnings; only an admission verdict plus a matching activation action may create a live facet.

## Revision 145 protocol sketch: secret delivery and redaction events

Candidate events for a future terminal protocol:

```text
viewfs.secret.descriptor.requested
viewfs.secret.prompt.started
viewfs.secret.prompt.completed
viewfs.secret.delivery_slot.issued
viewfs.secret.projection.env_shadow_created
viewfs.secret.projection.file_created
viewfs.secret.redaction_lens.attached
viewfs.secret.redaction_lens.gap_detected
viewfs.secret.live_use.started
viewfs.secret.live_use.ended
viewfs.secret.renewal.requested
viewfs.secret.renewal.denied
viewfs.secret.rotation.completed
viewfs.secret.residue.detected
viewfs.secret.residue.cleanup_requested
viewfs.secret.receipt.written
```

Candidate fields:

```text
secret_descriptor_digest
purpose
scope_class
audience_digest
provider_family
rotation_epoch
prompt_id
prompt_verdict
delivery_slot_id
carrier_kind
env_shadow_kind
redaction_lens_id
redaction_coverage
renewal_lease_id
live_use_handle_id
residue_marker_id
receipt_digest
redaction_level
```

Guardrails:

- terminal metadata must not carry raw bearer tokens, passwords, private keys, refresh tokens, provider account IDs, raw tenant identifiers, or enough value hashes to enable offline guessing by default;
- `descriptor.requested` is not prompt success;
- `prompt.completed` is not future authority;
- `redaction_lens.attached` is not containment;
- `renewal.requested` is not current material;
- `receipt.written` is not a secret, token, or live-use handle.

## Revision 146 protocol sketch: delegation and revocation wave events

Candidate events for future terminal metadata experiments:

```text
viewfs.delegation.intent.created
viewfs.delegation.intent.approved
viewfs.delegation.attenuation.declared
viewfs.delegation.membrane.created
viewfs.delegation.handle.issued
viewfs.delegation.handle.imported
viewfs.delegation.redelegation.denied
viewfs.revocation.requested
viewfs.revocation.local_proxy_closed
viewfs.revocation.epoch_advanced
viewfs.revocation.provider_accepted
viewfs.revocation.provider_pending
viewfs.revocation.recipient_notified
viewfs.revocation.offline_unknown
viewfs.revocation.stale_use_denied
viewfs.revocation.rotation_completed
viewfs.delegation.renewal.requested
viewfs.delegation.renewal.denied
viewfs.delegation.receipt.written
```

Suggested payload fields:

```text
subject_hint
issuer_hint
recipient_hint
source_digest
attenuation_digest
enforcement_lane: raw_handle | membrane | verifier | provider | expiry_only | descriptor | history
wavefront_state
stale_reason
renewal_state
redaction_profile
receipt_digest
```

Non-goal: exposing raw tokens, capability URLs, sturdyrefs, provider account ids, recipient graphs, or locator material through terminal metadata. These events explain delegation and recall state; they do not carry authority.

## Revision 147 protocol sketch: inspection, trace, dump, and export events

Candidate events for future terminal metadata experiments:

```text
viewfs.inspect.intent.created
viewfs.inspect.intent.denied
viewfs.inspect.target.selected
viewfs.inspect.namespace_snapshot.created
viewfs.inspect.slot_peek.created
viewfs.inspect.slot_peek.redacted
viewfs.trace.fuse.installed
viewfs.trace.fuse.sampled
viewfs.trace.fuse.overflow
viewfs.trace.fuse.stopped
viewfs.dump.capture.started
viewfs.dump.capture.completed
viewfs.dump.capture.quarantined
viewfs.dump.capture.redaction_pending
viewfs.debug.rail.armed
viewfs.debug.rail.attached
viewfs.debug.rail.control_ended
viewfs.observation.export_cut.issued
viewfs.support_bundle.previewed
viewfs.support_bundle.exported
viewfs.inspect.receipt.written
```

Suggested payload fields:

```text
target_hint
target_class
purpose_hint
snapshot_digest
slot_class
slot_redaction
trace_descriptor_digest
trace_filter_digest
trace_health: live | sampled | overflow | dropped | stopped | history_only
capture_digest
capture_quarantine_state
redaction_policy_digest
export_destination_class
debug_lane: none | observe | pause | attach | step | inject | memory_read | memory_write | slot_dup | namespace_enter
live_authority_state
receipt_digest
```

Non-goals:

- raw process memory;
- raw fd symlink paths;
- raw environment or secret values;
- raw capability IDs/tokens/sturdyrefs;
- provider account identifiers;
- stable cross-target tracking IDs;
- enough object IDs or content hashes to reconstruct a private capability graph.

Event rule: `namespace_snapshot.created`, `slot_peek.created`, and `trace.fuse.sampled` may update diagnostic panels; only an explicit live inspection/debug authority lane may duplicate, attach, dump, enter, or mutate.

## Revision 148 protocol sketch pressure: network badges must name the lane

Future terminal/shell metadata should prefer small lane-specific badges over a global online indicator:

```text
viewfs.net.intent=send-support-bundle
viewfs.net.scope=public|local|loopback|explicit
viewfs.net.kind=resolve|connect|listen|fetch|send|sync
viewfs.net.dest.digest=...
viewfs.net.resolver=portal|omitted|none
viewfs.net.local=denied|requestable|live
viewfs.net.listener=absent|live|receipt-only
viewfs.net.egress.material=redacted-bundle|object-bytes|diagnostic|secret-risk
viewfs.net.receipt=history-only
```

Terminals should not infer current network authority from hyperlinks, prior command success, remote-domain labels, or old receipt rows. If a badge is receipt-only, make it impossible to mistake for a current dialer/listener.
## Revision 149 protocol sketch pressure: service discovery badges must not imply invocation

Future terminal/shell metadata should prefer service-lane badges over a global endpoint indicator:

```text
viewfs.service.intent=discover|bind|activate|invoke|advertise
viewfs.service.designator.digest=...
viewfs.service.catalog=project|portal|local-link|mesh|object-store|omitted
viewfs.service.snapshot=candidate-set-digest|none
viewfs.service.readiness=ready|serving|terminating|warming|stale|unknown
viewfs.service.identity=matched|mismatch|evidence-only|omitted
viewfs.service.binding=cut-digest|absent|expired
viewfs.service.activation=planned|warming|fd-pending|handle-pending|failed|live
viewfs.service.live_handle=slot|absent|receipt-only
viewfs.service.advertisement=none|project|local-link|mesh|public|withdrawn|stale
viewfs.service.receipt=history-only
```

Terminals should not infer current service authority from hyperlinks, service labels, catalog hits, DNS-SD names, EndpointSlice rows, xDS resource names, readiness green dots, identity matches, or old call receipts. Only a live service handle/proxy/channel/listener slot can invoke or accept now.


## Revision 151 protocol sketch pressure: digest/dedup badges must not become membership or authority

Future terminal/shell metadata should prefer profile-specific proof and reuse badges over a naked hash:

```text
viewfs.digest.profile=raw-byte|cid-dag|canonical-payload|closure|verified-blob|weak|private|unknown
viewfs.equality.profile=exact-bytes|canonical-payload|semantic-core|chunk-dag|closure|weak-validator|provider-revision
viewfs.equality.result=same|different|unknown|not-comparable|history-only
viewfs.dedup.domain=off|local|same-owner|project|tenant|global|provider-opaque|encrypted
viewfs.convergence.domain=random-key|per-user|project|tenant|global|server-aided|none|redacted
viewfs.cache.observation=hit|miss|hidden|opaque|receipt-only
viewfs.possession=not-proved|local-bytes|challenge-ok|portal-ok|provider-owned|omitted
viewfs.materialization=fresh|reused-backing|deep-copy|unshared|sparse|sealed|denied|receipt-only
viewfs.live_facet=slot|absent|receipt-only
```

Terminals should not infer current authority from CIDs, SHA strings, previous cache hits, dedup-savings rows, shared-backing ghosts, or old materialization receipts. Cross-principal hit/miss should be hidden unless an explicit authority path says the viewer may know.


## Revision 152 semantic retrieval metadata candidates

Semantic search and agent-result UI should carry lane-specific metadata rather than one `search_result=true` marker. Candidate keys:

```text
viewfs.semantic.intent=parse|ocr|thumbnail|summarize|classify|tag|embed|chunk|transcribe|answer-support
viewfs.semantic.source_snapshot=current|revision|range|derived|provider-local|history-only|omitted
viewfs.semantic.profile=current|stale|unknown|redacted|provider-opaque
viewfs.semantic.artifact=source|derived-artifact|provider-row|cache-row|answer-card|receipt-only
viewfs.semantic.vault=none|room|project|tenant|provider-opaque|disposable|public|history-only
viewfs.semantic.query_scope=current-handles|room-root|workspace|portal-import|public-corpus|history-only|omitted
viewfs.semantic.filter_role=refinement|ranking|acl-adjunct|unsafe-alone|unknown
viewfs.semantic.result_shade=metadata-only|snippet|thumbnail|quote|answer-only|open-required|omitted
viewfs.semantic.live_authority=source-handle|derived-handle|borrow|proxy|absent|receipt-only
viewfs.semantic.memory=do-not-persist|receipt-only|room|project|provider|exportable|public
```

A terminal/shell that receives `answer-only` plus `live_authority=absent` should display an explanation/citation card, not an openable source object.
## Revision 153 protocol sketch pressure: instruction metadata must survive the terminal boundary

Future terminal/shell metadata should avoid one `ai=true` flag. Candidate keys:

```text
viewfs.instr.source=system|developer|user|org|profile|workspace|parent-repo|package|retrieved|tool-desc|tool-result|model|memory|receipt
viewfs.instr.trust=policy|intent|advisory|proposal|untrusted|quarantine|generated|receipt-only
viewfs.context.frame=current|candidate|history-only|omitted|redacted
viewfs.context.exposure=metadata|snippet|projection|full|redacted|none
viewfs.model.profile=current|stale|unknown|provider-opaque|local
viewfs.proposal.state=text-only|compiled|rejected|needs-repair|superseded
viewfs.plan.state=absent|draft|validated|needs-approval|approved|running|settled|denied
viewfs.toolcall.fuse=absent|candidate|blocked|needs-approval|armed|spent|cancelled
viewfs.approval.basis=none|user|policy|workflow|org|dual|history-only
viewfs.result.trust=observation|validated|adopted|quarantined|rejected
viewfs.memory.posture=do-not-persist|receipt-only|room|project|profile|org-candidate|provider|exportable
viewfs.live_authority=slot|borrow|portal|service|secret|network|absent|receipt-only
```

Event rule: `proposal.generated` may update answer panes. Only `plan.approved` plus current live authority may arm a toolcall fuse.

## Revision 154 protocol sketch: consent / volition / trusted-path keys

Candidate keys:

```text
viewfs.consent.candidate=absent|draft|validated|needs-summary|needs-volition|needs-approval|denied|approved|superseded
viewfs.consent.diff=none|read|write|send|secret|network|delegate|delete|publish|durable-grant|mixed
viewfs.consent.summary=absent|canonical|mismatch|stale|redacted|receipt-only
viewfs.presentation.surface=shell|portal|secure-attention|terminal|notification|app|web|model|remote|accessibility|headless|unknown
viewfs.trusted_path=shell-local|portal-local|secure-attention|ordinary-focused|notification-only|app-rendered|model-rendered|web-embedded|remote-captured|accessibility-mediated|headless-policy|degraded
viewfs.gesture.evidence=absent|fresh|consumed|expired|transferred|refused|hardware|remote|synthetic|receipt-only
viewfs.volition.state=not-required|required|pending|valid|invalid|expired|consumed|nonexportable|receipt-only
viewfs.approval.cut=absent|policy|user|org|quorum|delegated-admin|automation|hardware|denied|approved|receipt-only
viewfs.approval.reuse=never|same-plan-only|within-ttl|requires-reconsent|history-only
```

Event rule: `gesture.fresh` alone may never arm high-risk effects. High-risk effects need a validated consent candidate, accepted summary, required volition result if profile demands it, approval cut, and current live authority.
