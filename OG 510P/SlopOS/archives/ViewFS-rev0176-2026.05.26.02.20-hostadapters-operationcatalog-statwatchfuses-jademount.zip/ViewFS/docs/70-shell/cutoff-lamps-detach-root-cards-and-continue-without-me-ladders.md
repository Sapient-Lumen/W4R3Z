# Cutoff lamps, detach-root cards, and continue-without-me ladders

Purpose: make cancellation/deadline/detach truth luxurious without lying.

The future custom shell should be able to say five different things clearly:
1. **this work still lives under the caller**
2. **this work now has a detached cleanup root**
3. **this work now has a provider-owned continuation root**
4. **the caller's patience budget expired, but follow-up still exists somewhere**
5. **all that remains is receipt/history**

Those are not the same truth and should not share one vague `background` badge.

## Great moves

### Cutoff lamps
Every command block or provider-backed mutation card should be able to show:
- `inherits caller cutoff`
- `narrowed cutoff`
- `no cutoff`
- `deadline fired`
- `provider still settling`
- `history only`

Bonus: clicking the lamp should reveal whether the cutoff was parent-derived, locally narrowed, provider-reported, or inferred from settlement history.

### Detach-root cards
If work continues after the caller goes away, the shell should say **how**:
- `caller child`
- `cleanup root`
- `provider continuation root`
- `watch detached locally`
- `unknown bridge`

This is much better than one generic `detached` chip.

### Continue-without-me ladders
Whenever a pane is about to close/cancel while provider-backed work exists, the shell should offer visibly different acts:
- `cancel with me`
- `let cleanup finish`
- `let provider continue`
- `stop watching only`
- `keep receipt only`

That is the luxury version of honest cancellation UX.

### Cancellation braids
For long or nested work, the shell should show the path of the cancel signal:
- `parent requested`
- `transport propagated`
- `provider acknowledged`
- `cleanup still running`
- `deadline exceeded`
- `provider ignored / unknown`

This turns a mysterious failure into inspectable structure.

### Cause drawers
Steal from Go's cancellation causes and structured-concurrency tooling.
The shell should be able to open a small drawer that says:
- who canceled,
- whether it was a deadline or manual cancellation,
- whether the provider minted a fresh root afterward,
- whether cleanup used a shielded/disconnected path,
- and whether any later provider operation ticket survived.

## Why this would feel super awesome
This is the kind of shell chrome that feels incredibly high-end:
- it helps the user predict what will keep running;
- it avoids accidental hidden background work;
- it explains why a block stopped waiting without pretending the provider stopped too;
- and it makes asynchronous/provider-backed work feel first-class without inventing one magical task daemon as the center of reality.

## Guardrails
- never use the same icon for `caller canceled` and `provider finished cleanup`.
- never hide the difference between `cleanup root` and `ordinary detached continuation`.
- never let `stop watching` impersonate `stop work`.
- never let `deadline fired` impersonate `final provider verdict`.
