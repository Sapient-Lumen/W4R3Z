# Seal badges, wrap rosters, rewrap ladders, unwrap rails, and clear rails

Steal from current SlopOS cryptosvc/vault posture plus JWE multi-recipient envelopes, WebCrypto opaque key handles with `wrapKey`/`unwrapKey`, and Cloud KMS envelope-encryption / re-encryption guidance.

Whenever the shell renders one encrypted/import/export/history row, it should be able to show:
- whether it is talking about one **sealed object** or only a **history row**,
- whether one **wrap roster** is visible and how many recipient/key-slot rows it carries,
- whether one **rewrap ladder** is pending, completed, failed, or history only,
- whether one **unwrap rail** says `provider-bound`, `needs mediator`, `available here`, or `cannot clear here`,
- whether a **clear rail** is actually present now.

Why this is great:
- encrypted storage becomes delightful without lying about who can actually clear it now;
- recipient changes and key rotation stop masquerading as object rebirth or live access;
- cleartext use becomes explainable instead of spooky;
- the shell can stay luxurious while telling the truth about sealed payloads, wrap rosters, rewrap acts, unwrap handles, and current authority.

Guardrail:
- never let one old wrap roster, rewrap receipt, or key-version witness impersonate a current clear facet.
