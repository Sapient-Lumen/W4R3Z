# GC halos, pin badges, sweep previews, finalizer rails, and ash receipts

Revision: 141  
Date: 2026-05-13  
Codename: gchalos-pinleases-sweepguards-moonfern

## Shell goal

The shell should make object-store liveness legible without making it scary or magical.

Users should be able to ask:

- why is this still taking space?
- what would be deleted if I sweep now?
- what is keeping this object alive?
- is this live authority or just retained bytes?
- is this cached, pinned, held, leased, finalizing, collected, or receipt-only?
- can I release the root safely?

## Five visible moves

### 1. GC halo

Every object, root, namespace projection, import session, or time-capsule row can carry a small halo:

```text
proposal.md        live read/edit   retained by workspace-root + direct pin
archive.tar        cached only      sweepable after grace clock
old-root@epoch 18  receipt only     collected ash retained
```

Suggested halo states:

- `live`
- `durable root`
- `pinned`
- `held`
- `leased`
- `cached only`
- `sweep candidate`
- `finalizing`
- `collected`
- `receipt only`
- `provider hidden`

### 2. Why-retained drawer

A `why retained?` drawer should show root causes, not folklore:

```text
Why is dataset.parquet retained?

1. workspace root: /research/current
   kind: durable reachability root
   scope: recursive

2. materializer lease: import #I-884
   kind: runtime lease
   expires: 2026-05-13 18:10

3. cache row: preview thumbnail
   kind: cache only; not retention
```

This drawer should be redaction-aware. Sometimes the answer is `retained by policy root; details hidden`.

### 3. Sweep rehearsal

A sweep should be previewable before it is executable:

```text
Sweep rehearsal
  basis roots: digest 0bfe…
  live epoch:  slotmap epoch 44
  candidates: 1,842 objects / 9.3 GiB
  blocked:    12 finalizers / 3 provider-hidden leases
  grace:      30 objects under recovery clock

Will collect:
  cached thumbnails      1.1 GiB
  abandoned upload parts 4.8 GiB
  stale list snapshots   0.3 GiB

Will not collect:
  pinned notebooks       retained by user pin
  live preview chunks    retained by live handle
  old grant receipts     receipt retained; backing gone
```

The shell should show when the rehearsal is stale.

### 4. Finalizer rail

When deletion is blocked, show the rail:

```text
Delete old workspace root
  requested: now
  state: finalizing

Finalizers
  1. revoke exported proxy          owner: portal-manager    pending
  2. drop published alias           owner: namespace-manager done
  3. record rollback tombstone      owner: root-ledger       pending
```

No more mysterious `resource busy` as the only explanation.

### 5. Ash receipt

After collection, keep minimal history without pretending the object can be opened:

```text
old-upload-part-77
  state: collected ash
  collected_at: 2026-05-13 17:21
  reason: upload aborted; grace expired
  current power: none
  resurrectable: no
```

Ash receipts should be safe to share when redacted. They should not contain bearer material, raw provider secrets, or hidden stable IDs unless a developer profile explicitly asks.

## Delightful commands to prototype

```text
viewfs why-retained <object>
viewfs sweep --dry-run --show-finalizers
viewfs sweep --only cached --basis current
viewfs pins list --by-owner
viewfs pins release <pin-id>
viewfs finalizers list <object>
viewfs ash inspect <receipt>
viewfs cache explain <object>
```

## Design guardrails for UX

- `cached` must never look like `pinned`.
- `receipt only` must never look like `retained`.
- `live now` must not imply `will survive close`.
- `retained` must not imply `openable now`.
- `sweepable` must not imply `will be swept without finalizer checks`.
- `finalizing` must not become an uninspectable forever-state.
- `provider hidden` must be honest instead of fake precision.

## Protocol hints, not a protocol

Future terminal/shell events could reserve names like:

- `viewfs.gc.root_set`
- `viewfs.gc.live_handle_root`
- `viewfs.gc.retention_record`
- `viewfs.gc.sweep_rehearsal`
- `viewfs.gc.finalizer_state`
- `viewfs.gc.collect_commit`
- `viewfs.gc.ash_receipt`

Candidate fields:

```text
object_core_digest
root_set_digest
live_handle_epoch
retention_record_id
retention_kind
retention_scope
issuer_subject_local
purpose_code
expires_at
sweep_candidate_id
collector_family
candidate_state
estimated_bytes
finalizer_id
finalizer_owner
collection_verdict
ash_receipt_digest
redaction_level
provider_uncertainty
```

The protocol should never expose raw capability tokens, secret provider IDs, or hidden object names by default. It should be good enough for a human to understand `why not collected?` and `why gone?`.

## Demo scenarios

1. Create an unpinned temporary object, close the only handle, and watch it become sweepable after a grace clock.
2. Pin the same object and show how the sweep rehearsal changes.
3. Start a portal import with a materializer lease; prove collection waits while the lease is live and stops waiting after abort/grace.
4. Delete a published root and show finalizers before ash receipts appear.
5. Share an ash receipt that proves cleanup happened without exposing enough information to reopen or reconstruct the object.
