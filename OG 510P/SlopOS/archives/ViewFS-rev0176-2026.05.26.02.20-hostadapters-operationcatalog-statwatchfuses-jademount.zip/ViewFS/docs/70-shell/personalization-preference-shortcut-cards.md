# Personalization, preference, shortcut, and feedback cards

ViewFS shell cards should render personalization as explanation and bounded convenience, not as authority.

## Card posture

- A profile card should show subject, identity/session binding freshness, and policy epoch without implying that the profile row proves identity.
- A preference card should show exact scope and whether it is advisory, active, or blocked without implying consent or policy authority.
- A recommendation card should expose why a suggestion exists while hiding sensitive features and requiring a live handle before opening anything.
- A shortcut card should show target handle, required right, and approval posture before execution.
- An autofill card should show target field, redaction state, and approval posture without revealing secret values.
- An experiment card should show cohort and scope while saying explicitly that cohort membership is not an override.
- A feedback card should show purpose and retention posture without turning feedback into training consent.

The shell should prefer phrases like `suggested`, `applies to shell layout`, `requires approval`, and `feedback recorded for product improvement` over green authority-like badges such as `approved`, `allowed everywhere`, or `safe to train`.
