# Gone-vs-retained cards

Revision 163 adds a shell obligation: never present one unqualified `gone` state.

Useful cards:

- **Not in this view** — path/view projection no longer binds the object.
- **Tombstone written** — local object-store marker exists.
- **Retained by snapshot** — a point-in-time pin blocks collection.
- **Retained by backup** — a backup set still inventories the object.
- **Archive/legal hold** — release requires stewarded cut or retention expiry.
- **Deletion evidence** — sanitization proof level and subject match are visible.
- **Restore possible** — only if a verified backup and approved restore plan are present.
- **External copies unknown** — local ViewFS cannot assert global disappearance.

The card renderer should keep authority badges separate from evidence badges. A deletion proof does not open an object. A backup manifest does not restore an object. A legal hold does not grant read access. A snapshot pin does not prove current possession.
