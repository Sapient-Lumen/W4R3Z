# Extract-plan cards, member capsules, path-guard badges, and unpack receipts

Revision: 143  
Date: 2026-05-14  
Codename: extractplans-membercapsules-pathguards-coralvault

## Shell goal

Unpacking should be powerful, visual, and safe. The user should see why an archive is dangerous without being forced to reason about path traversal, symlinks, hardlinks, whiteouts, metadata, and decompression bombs from scratch.

The shell should answer:

- what is the aggregate object?
- what did its members claim?
- which claims are blocked, rewritten, or admitted?
- where will materialization happen?
- has anything been published into my namespace yet?
- what is live now?
- what is only a receipt?

## Eight visible moves

### 1. Container gate card

```text
vendor-tools.tar.zst
  origin: download -> portal import
  state: quarantined / safe-extract only
  format: tar+zstd
  members: 451 claimed / 443 likely admissible
  expanded: estimate 490 MiB
  next: Inspect members | Rehearse extract | Open safe
```

The gate card should not show `Extract here` as the default when the source is risky.

### 2. Member claim table

```text
member                              claim             verdict
bin/tool                            regular file       admit, executable blocked
../.ssh/authorized_keys             path escape        block
lib -> /usr/lib                     symlink absolute   block
var/cache                           directory          admit
etc/passwd                          reserved target    rewrite/deny
.wh.deleted                         whiteout claim     inert until layer plan
```

Raw member strings can be shown, but they are displayed as claims, not as already-existing paths.

### 3. Path-guard badges

Badges should summarize policy:

```text
path guards: no-absolute / no-dotdot / no-link-escape / no-devices / no-setuid
metadata: xattrs stripped / ACLs stripped / mtimes inert
duplicates: ask / keep-first / keep-last / deny
quarantine: inherited
```

This makes safe extraction feel like a normal mode, not a hidden library side effect.

### 4. Extract rehearsal card

```text
Rehearsal #E-19
  admit: 443 entries
  block: 8 entries
  rewrite: 3 names
  budget: 490 MiB / 31k entries / depth 14
  destination: sterile root only
  namespace commit: not requested
```

The user can approve materialization after seeing what will and will not happen.

### 5. Sterile root capsule

```text
Sterile root #R-22
  source: vendor-tools.tar.zst @ digest 59d2...
  policy: safe-extract-v0
  live: preview only
  publish: explicit later
  cleanup: on close unless pinned
```

The capsule says that bytes are present somewhere safe, not that the current room has changed.

### 6. Member capsule rails

```text
vendor-tools.tar.zst
  -> R-22/bin/tool        new object / quarantined / executable blocked
  -> R-22/share/readme.md new object / read allowed
  -> R-22/lib            symlink claim blocked
```

Rails make lineage obvious and prevent same-name or same-digest laundering.

### 7. Namespace commit shutter

```text
Publish extracted tree?
  target: project:/third_party/vendor-tools
  currentness: target parent unchanged
  mode: read-only tree
  still blocked: executable launch, symlinks, device nodes
  result: new bind if accepted
```

The user can publish selected results, mount read-only, adopt one file, or discard. The shutter is the first time a namespace mutation is on the table.

### 8. Unpack receipt

```text
Unpack receipt #U-44
  inspected: vendor-tools.tar.zst @ digest 59d2...
  plan: safe-extract-v0 @ digest 7c1a...
  materialized: sterile root #R-22
  published: none
  denied: 8 entries
  live authority: none now
```

Receipts should look like history, not handles.

## Commands worth prototyping

```text
viewfs archive inspect <object>
viewfs archive members <object> --claims
viewfs archive rehearse <object> --policy safe-extract-v0
viewfs archive extract <object> --sterile
viewfs archive capsule inspect <root-or-member-id>
viewfs archive publish <root-or-member-id> --target <view>
viewfs archive receipts <object>
viewfs archive deny-list <object>
```

## Design guardrails for UX

- `List members` must not imply `materialize members`.
- `Materialize in sterile root` must not imply `publish here`.
- Raw archive names must not render as ordinary ViewFS paths until adopted.
- Symlinks/hardlinks must display their target claims and escape verdicts.
- Whiteouts must display as layer claims, not current-view deletes.
- `Same bytes` must not hide different archive parentage or quarantine.
- `Safe-extract` must not silently clear trust.
- `Unpack receipt` must not become a reopen grant.

## Protocol hints, not a protocol

Future shell events could reserve names like:

- `viewfs.container.envelope_inspected`
- `viewfs.container.member_claims`
- `viewfs.extract.plan_reviewed`
- `viewfs.extract.materialization_root_started`
- `viewfs.extract.member_capsule_created`
- `viewfs.extract.namespace_commit_requested`
- `viewfs.extract.live_facet_state`
- `viewfs.extract.receipt`

Candidate fields:

```text
container_digest
container_format
origin_receipt_digest
quarantine_mark_digest
member_claim_digest
raw_member_name_redacted
normalized_member_name
member_kind
link_target_redacted
collision_group_digest
path_guard_profile
extraction_plan_digest
plan_verdict
resource_budget_digest
materialization_root_id
member_capsule_id
namespace_commit_id
target_view_digest
live_facet_id
receipt_digest
redaction_level
```

The event stream must not carry raw bearer tokens, hidden provider paths, secret account ids, unredacted risky snippets, or enough member data to reconstruct quarantined content by default.

## Demo scenarios

1. Import a suspicious ZIP with `../` members; show member claims and blocked path escapes.
2. Open a TAR in a sterile root; show symlink/hardlink/device entries denied and ordinary files materialized as quarantined member capsules.
3. Inspect an OCI-like layered image; show manifest/layer/config as claims and keep whiteouts inert until a layer-specific plan is approved.
4. Publish one safe member into a project view; prove the receipt is history and the live bind is separate.
