# Service cards, discovery drawers, readiness lamps, binding braids, activation rails, advert shutters, and call receipts

Revision 149 adds shell ideas for service discovery and binding. The shell should make service lookup feel powerful while refusing to flatten name, discovery, readiness, binding, activation, live handle, advertisement, and receipt into one fake **endpoint**.

## Big shell promise

A user should be able to answer:

- who is asking for a service?
- what service designator was used?
- which catalog or discovery authority was queried?
- what candidates were found, omitted, stale, or denied?
- what readiness/health/identity evidence was shown?
- which binding cut selected a candidate, for what purpose, and under which policy epoch?
- is a provider merely planned, warming, activating, live, withdrawn, or history-only?
- what can it invoke, listen on, advertise, import, or export?
- what receipt is just history?

## UI pieces worth stealing

### Service cards

```text
service card
intent: bind project indexer
actor: room Alpha / process 42
name: project-indexer
catalog: project service directory
scope: this room only
status: candidates found, no live handle yet
```

A card should never say only `available`.

### Discovery drawers

Drawers show candidates and omissions:

```text
discovery snapshot
catalog: project service directory
query: project-indexer
candidates: 3
- A: v2.1, serving, policy-denied: needs write root
- B: v2.0, ready, candidate
- C: v1.9, stale 18m
omitted: raw endpoint IPs, provider account ids
receipt: snapshot only
```

Snapshots are not handles.

### Readiness lamps

Separate lamps:

- ready;
- serving;
- terminating;
- stale;
- warming;
- identity matched;
- identity omitted;
- policy-denied;
- version drift;
- route not warmed;
- health unknown.

Avoid one green dot.

### Binding braids

A braid connects the selected candidate to the eventual live handle:

```text
binding braid
intent -> designator -> catalog root -> snapshot row -> policy cut -> activation target -> live svc[2]
```

Any missing segment should be visible.

### Activation rails

Rails show:

- provider planned;
- provider starting;
- socket/listener held by manager;
- fd/handle delivered;
- route warming;
- object roots attached;
- secret slots delivered;
- ready for call;
- activation failed;
- needs rebind.

Activation rails should not look like the service is already live.

### Advert shutters

Separate shutters:

- no advertisement;
- project catalog only;
- local process namespace only;
- local link mDNS/DNS-SD;
- LAN service registry;
- service mesh/control plane;
- public endpoint;
- withdrawn;
- stale advertisement;
- receipt only.

Opening a listener should not silently lift an advert shutter.

### Call receipts

Call receipts should show:

- subject and workflow;
- service designator and catalog root digest;
- selected candidate digest;
- binding cut digest;
- live handle class used;
- object/network/secret/export scopes used;
- result class and residues;
- whether follow-up/retry needs a fresh bind.

A call receipt cannot invoke again.

## Command sketches

Do not freeze these, but keep the shape:

```text
viewfs svc discover project-indexer --catalog room --purpose index
viewfs svc candidates <snapshot> --show-denied --show-stale
viewfs svc bind <candidate> --purpose index --ttl 30m
viewfs svc activate <binding> --attach-roots reviewed
viewfs svc handles <process>
viewfs svc advertise --catalog project --type indexer --ttl 10m
viewfs svc withdraw <advert>
viewfs svc receipt <call>
```

## Status vocabulary

Prefer:

```text
designator-only
catalog-absent
discovery-denied
snapshot-only
candidate-stale
candidate-denied
ready-not-serving
serving-terminating
identity-evidence-only
binding-cut-issued
activation-warming
live-handle-slot
advert-project-only
advert-local-link
advert-public
withdrawn
receipt-only
```

Avoid:

```text
available
trusted service
installed endpoint
connected forever
healthy therefore safe
discovered therefore callable
same service
```

## Delight moves

- **Who picked this?** drawer: show whether the user, policy, shell, provider, service mesh, or restored receipt chose the candidate.
- **Why not callable?** ladder: missing catalog root, discovery denied, candidate stale, policy denied, activation failed, lease expired, no live handle.
- **Service diff** rail: compare old and new candidate sets without treating new candidates as automatically adopted.
- **Local-link caution badge**: mDNS/DNS-SD browsing gets visible local-network chrome.
- **Identity evidence lens**: show provider identity match/mismatch/omitted without saying trusted.
- **Advert spotlight**: any public or local-link advertisement gets louder UI than ordinary invocation.
- **History ghost**: beautiful old call cards that cannot invoke without a fresh binding cut.

## Guardrail

Never let a service name, catalog row, discovery snapshot, readiness lamp, identity match, binding receipt, activation rail, advertisement row, or call receipt impersonate current live service authority.
