# Research synthesis — pass CMJ — compliance labels, rights metadata, and release gates

This pass looked at external pressure from information categorization, rights expression, software license metadata, export-control classification, privacy-purpose management, and shell-facing compliance summaries.

- NIST FIPS 199 frames security categorization around confidentiality, integrity, and availability impact. ViewFS borrows only the idea that category is a risk descriptor; it must not become access authority.
- SPDX provides standardized license identifiers and SBOM/license metadata. ViewFS borrows the need for exact license references while refusing to treat a license string as possession, publication, or training authority.
- W3C ODRL models permissions, prohibitions, and obligations. ViewFS borrows that triad for `LicenseTerm` and `ComplianceObligation` fixtures, but keeps enforcement authority separate from policy text.
- Creative Commons ccREL distinguishes permissions, requirements, and prohibitions for works. ViewFS uses this as pressure to keep attribution/notice requirements explicit in the fixture lane.
- BIS/EAR export-control material emphasizes item classification, ECCN, license requirements, and destination controls. ViewFS treats export-control/classification labels as gates that require current egress authority and verified release posture.
- NIST Privacy Framework and privacy-rights regimes such as GDPR push purpose, processing, subject-access, erasure, and portability surfaces. ViewFS already has disclosure/subject-access lanes; rev0169 adds purpose binding so a stated purpose cannot become processing authority.

The resulting ViewFS rule is deliberately narrower than any of those regimes: labels, licenses, obligations, jurisdiction facts, purpose statements, and public-release cards may explain or block effects. They do not mint object authority, disclose raw content, authorize training, clear export, or release public copies by themselves.
