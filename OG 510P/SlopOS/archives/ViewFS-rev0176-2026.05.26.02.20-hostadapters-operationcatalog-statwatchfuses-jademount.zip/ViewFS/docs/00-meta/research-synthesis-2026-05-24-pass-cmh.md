# Research synthesis — pass CMH — boundary reality

Revision 167 borrows pressure from several adjacent systems without importing their authority model wholesale.

Linux `openat2` and prior resolver fixtures already informed path boundaries; this pass extends the same suspicion to non-path boundaries. Web platform APIs such as Clipboard, Drag and Drop, WebUSB/WebHID, Web Bluetooth, Geolocation, and Permissions show that user gestures, permission prompts, device descriptors, and origin-scoped grants must be separated. Mobile and desktop privacy systems such as Android runtime permissions and macOS TCC reinforce that sensor/device consent is purpose and surface specific. Network connector systems, DNS pinning discussions, and egress policy engines reinforce that endpoint metadata is not generic network authority.

The speculative ViewFS stance is that “local” should become an explicitly rendered boundary predicate. Locality is useful evidence, but it is not a right. Connected devices, clipboard buffers, drag/drop gestures, runtime attestation rows, and sensor samples should all be treated as objects that require current authority joins before they can cause file, network, tool, or disclosure effects.
