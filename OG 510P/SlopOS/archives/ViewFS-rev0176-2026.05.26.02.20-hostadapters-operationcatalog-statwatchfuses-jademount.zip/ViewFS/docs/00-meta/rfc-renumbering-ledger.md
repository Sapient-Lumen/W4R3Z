# RFC renumbering ledger

Revision 155 repairs a historical numbering collision without changing the substantive RFC text.

| Revision | Old path | New path | Reason |
|---|---|---|---|
| 155 | `rfcs/0109-viewfs-keep-semantic-object-cores-byte-proofs-structured-addresses-live-facets-and-receipts-separate.md` | `rfcs/0142-viewfs-keep-semantic-object-cores-byte-proofs-structured-addresses-live-facets-and-receipts-separate.md` | The archive already had a different `0109` RFC for grant outlooks / issued bounds / restore tokens. The semantic-object-core RFC is renumbered to restore one-RFC-number/one-file hygiene. |

The original revision history in `CHANGELOG.md` now points at the repaired path. Generated context packs and release manifests should be regenerated after any future renumbering.
