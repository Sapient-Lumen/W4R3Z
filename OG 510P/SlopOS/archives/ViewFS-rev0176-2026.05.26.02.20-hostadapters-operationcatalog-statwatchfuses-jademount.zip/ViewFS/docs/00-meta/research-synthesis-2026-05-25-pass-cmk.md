# Research synthesis 2026-05-25 pass CMK

Revision 170 is shaped by query, evaluation, and benchmark pressure rather than another storage primitive.

- W3C SPARQL shows that query languages can compose graph patterns across diverse data sources; ViewFS therefore treats query text and query plans as selectors over scoped sources, not as source authority.
- NIST AI RMF and the Generative AI Profile emphasize measuring and managing AI risk; ViewFS therefore keeps evaluation sets, benchmark runs, and scoring artifacts as assessment evidence rather than deployment authority.
- OWASP LLM guidance highlights prompt injection, sensitive information disclosure, excessive agency, vector/embedding weakness, and evaluation/supply-chain risk; ViewFS therefore requires planner approval cuts, current authority, contamination checks, and result-member handles.
- HELM/MLCommons-style benchmark pressure argues for broad, transparent, reproducible, multi-metric evaluation; ViewFS therefore denies single-score/leaderboard laundering and makes tradeoff visibility a shell invariant.
- W3C PROV reinforces entity/activity/agent provenance separations; ViewFS therefore records benchmark and planner traces as explainers rather than replayable effects.

Design consequence: query/eval artifacts are review aids. They can select, rank, summarize, and measure. They cannot read, disclose, deploy, or certify production readiness without a separate live authority lane.
