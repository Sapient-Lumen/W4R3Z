# Research synthesis pass CMO: personalization and convenience custody

This pass uses privacy, preference, and recommender-system practice as pressure, not as a design import.

- Privacy preference signals such as Global Privacy Control are useful because they are explicit signals, but ViewFS treats a preference signal as scoped input, not as a universal policy engine or consent replacement.
- Web permissions and user-activation patterns are a reminder that a convenience gesture or setting is not automatically durable authority.
- Recommender and ranking systems create explanation and evaluation pressure, but ViewFS treats recommendations as candidate surfaces rather than proof of user intent.
- A/B or feature-flag systems show that cohort assignment is operationally useful while remaining distinct from policy, compatibility, and authority decisions.
- Privacy engineering guidance reinforces purpose limitation, minimization, and feedback/telemetry separation.

Speculative conclusion: ViewFS should make personalization visible and revocable before making it clever. The shell may adapt, but adaptation must be bounded by profile/session freshness, preference scope, purpose/minimization posture, and live authority at the actual effect cut.
