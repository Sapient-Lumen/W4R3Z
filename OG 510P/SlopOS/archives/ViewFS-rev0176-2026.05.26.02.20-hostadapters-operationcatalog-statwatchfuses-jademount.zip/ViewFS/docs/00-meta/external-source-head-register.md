# External source head register

Purpose: keep moving-head or presentation-layer external sources visible so we do not accidentally treat a mutable docs page as frozen law.

Status for Revision 148: **reviewed, not byte-locked**. We used current primary sources, but this repo has not yet downloaded and hashed exact artifacts for lock rows. That work should happen when a source becomes load-bearing enough to support a hard decision.

| ref_id | source type | volatility | retrieved_on | next_review_by | note |
|---|---|---|---|---|---|
| `REF-PYTHON-TARFILE-FILTERS` | web docs | moving-head | `2026-05-14` | `2026-06-20` | extraction-filter and safer-default precedent; exact Python API is not a ViewFS contract |
| `REF-GO-GODEBUG-ARCHIVE-PATHS` | web docs | moving-head | `2026-05-14` | `2026-06-20` | archive insecure-path compatibility-toggle precedent; do not import GODEBUG defaults as policy |
| `REF-BSDTAR-PATH-GUARDS` | man page mirror | moving-head | `2026-05-14` | `2026-06-20` | path/link refusal precedent; exact bsdtar flags are not a ViewFS CLI promise |
| `REF-ZIPSLIP-SNYK` | research page | moving-head | `2026-05-14` | `2026-06-20` | archive path traversal cautionary source; use as warning, not one full threat model |
| `REF-OCI-IMAGE-SPEC` | GitHub markdown | moving-head | `2026-05-14` | `2026-06-20` | manifest/index/layer/config separation inspiration only; do not freeze OCI as ViewFS aggregate ABI |
| `REF-SLOPOS-ARCHIVE-EXTRACT-SEAM` | included archive | pinned-by-upload | `2026-05-14` | `2026-06-20` | sibling-cube D-QUAR/materialization/cwd-root pressure for safe extraction; not final ViewFS parser schema |
| `REF-APPLE-LSFILEQUARANTINEENABLED` | web docs | moving-head | `2026-05-13` | `2026-06-20` | quarantine-default producer-side setting inspiration only; exact Info.plist key is not a ViewFS contract |
| `REF-MS-ZONEIDENTIFIER` | web docs | moving-head | `2026-05-13` | `2026-06-20` | zone-of-origin sidecar precedent only; exact NTFS ADS details are not a ViewFS portability promise |
| `REF-MS-PROTECTEDVIEW` | web docs | moving-head | `2026-05-13` | `2026-06-20` | constrained document-open precedent; do not overfit Office UI or product policy |
| `REF-GOOGLE-SAFEBROWSING` | web docs | moving-head | `2026-05-13` | `2026-06-20` | warning/reputation precedent only; not a final ViewFS malware or reputation service |
| `REF-CHROME-DANGEROUS-DOWNLOADS` | web docs | moving-head | `2026-05-13` | `2026-06-20` | download warning/action-ladder inspiration only; exact Chrome warning categories may change |
| `REF-SLOPOS-DQUAR` | included archive | pinned-by-upload | `2026-05-13` | `2026-06-20` | sibling-cube anti-laundering posture; useful design pressure, not final ViewFS schema |
| `REF-FUCHSIA-NAMESPACE` | web docs | moving-head | `2026-05-13` | `2026-06-15` | explicit namespace assembly and no-global-root inspiration only; do not overfit exact routing syntax |
| `REF-FUCHSIA-DIR-CAPS` | web docs | moving-head | `2026-03-21` | `2026-05-01` | rights-routing semantics are relevant; exact schema syntax is not load-bearing yet |
| `REF-FUCHSIA-RIGHTS` | web docs | moving-head | `2026-03-21` | `2026-05-01` | good for handle-rights vocabulary |
| `REF-FUCHSIA-DICTCAP` | web docs | moving-head | `2026-03-28` | `2026-05-01` | capability-bundle inspiration for future grouped authority surfaces |
| `REF-FUCHSIA-DICT-RFC` | web docs | moving-head | `2026-03-21` | `2026-05-01` | grouped-capability RFC is inspiration only; do not overfit Fuchsia declarative syntax |
| `REF-FUCHSIA-IDLE-STOP` | web docs | moving-head | `2026-03-22` | `2026-05-01` | handle-escrow / narrow-continuity precedent only; do not overfit framework lifecycle details |
| `REF-FLATPAK-BASICS` | web docs | moving-head | `2026-03-21` | `2026-04-15` | portal posture reference |
| `REF-XDG-FILECHOOSER` | web docs | moving-head | `2026-03-28` | `2026-04-15` | chooser semantics may evolve; re-check before binding protocol details |
| `REF-XDG-DOCUMENTS` | web docs | moving-head | `2026-05-13` | `2026-06-15` | document portal grant/revoke/document-store behavior is inspirational; do not treat doc IDs or FUSE paths as final ViewFS authority |
| `REF-XDG-DOCS-FUSE` | web docs | moving-head | `2026-03-28` | `2026-04-15` | useful for scoped synthetic-view behavior, not for adopting FUSE literally |
| `REF-XDG-FILETRANSFER` | web docs | moving-head | `2026-03-28` | `2026-04-15` | transfer-session semantics are useful for drag/drop and clipboard flows |
| `REF-WASI-CAPS` | GitHub markdown | moving-head | `2026-05-13` | `2026-06-15` | capability/import vocabulary is inspiration only; exact WASI phases and host APIs may drift |
| `REF-WASMTIME-PREOPEN` | GitHub markdown | moving-head | `2026-03-21` | `2026-04-20` | compat-preopen pattern is highly relevant |
| `REF-CAPSICUM-RIGHTS` | man page mirror | moving-head | `2026-05-13` | `2026-06-15` | rights taxonomy inspiration; exact names may be too granular for ViewFS |
| `REF-CHERIOT-CAPS` | web docs | moving-head | `2026-03-28` | `2026-04-20` | typed capability / permission / bounds inspiration only; do not overfit hardware-level representation choices into ViewFS handles |
| `REF-CHERIOT-SEALING` | web docs | moving-head | `2026-03-28` | `2026-04-20` | opaque-token/sealed-handle inspiration only; do not overfit CHERI object-type machinery into a premature ViewFS ABI |
| `REF-CAPSTD` | docs.rs | moving-head | `2026-03-21` | `2026-04-20` | explicit ambient-authority marker inspiration |
| `REF-CAPROS-USERDRIVERS` | web docs | moving-head | `2026-03-22` | `2026-05-15` | persistence/device-state caution for durable-authority design |
| `REF-TREESLS-SOSP23` | paper landing page / ACM | moving-head | `2026-03-22` | `2026-05-15` | modern capability-tree checkpoint inspiration; do not treat as a Phase 1 commitment |
| `REF-ANDROID-SAF` | web docs | moving-head | `2026-03-28` | `2026-04-25` | durable grant, stable identity, and multi-placement precedent only |
| `REF-APPLE-SSB-CVE2025` | NVD entry | moving-head | `2026-03-21` | `2026-04-20` | cautionary source only; do not overfit one vendor bug into the whole design |
| `REF-NIX-CA` | web manual | moving-head | `2026-03-28` | `2026-05-15` | closure/store-address precedent only; do not overfit Nix path semantics or build-model details |
| `REF-IPFS-CIDS` | web docs | moving-head | `2026-03-28` | `2026-05-15` | CID-vs-file-checksum and codec/chunking precedent only; do not overfit IPFS routing or block-layout semantics |
| `REF-IPFS-MFS` | web docs | moving-head | `2026-03-21` | `2026-05-15` | mutable-over-immutable facade inspiration |
| `REF-PERKEEP-PERMANODE` | web docs | moving-head | `2026-03-21` | `2026-06-01` | stable mutable anchor idea; not load-bearing yet |
| `REF-TAHOE-MUTABLE` | readthedocs | moving-head | `2026-03-28` | `2026-05-15` | stable mutable-slot contrast case |
| `REF-TAHOE-URIS` | readthedocs | moving-head | `2026-03-28` | `2026-05-15` | capability-flavor precedent only; do not overfit Tahoe URI strings into a final ViewFS handle ABI |
| `REF-SQLITE-SESSION` | web docs | moving-head | `2026-03-21` | `2026-05-15` | changeset-sidecar inspiration only |
| `REF-NUSHELL` | web docs | moving-head | `2026-03-21` | `2026-05-15` | shell UX inspiration only |
| `REF-FISH` | web docs | moving-head | `2026-03-24` | `2026-05-15` | shell UX inspiration only |
| `REF-WARP-BLOCKS` | web docs | moving-head | `2026-03-21` | `2026-04-15` | terminal-block UX inspiration only |
| `REF-WARP-NOTEBOOKS` | web docs | moving-head | `2026-03-22` | `2026-04-15` | workflow/documentation UX inspiration |
| `REF-WARP-WORKFLOWS` | web docs | moving-head | `2026-03-22` | `2026-04-15` | saved-command UX inspiration |
| `REF-WARP-CMDPALETTE` | web docs | moving-head | `2026-03-21` | `2026-04-15` | searchable command/object palette inspiration |
| `REF-WEZTERM-HYPERLINKS` | web docs | moving-head | `2026-03-21` | `2026-05-15` | terminal hyperlink inspiration |
| `REF-WEZTERM-DOMAINS` | web docs | moving-head | `2026-03-21` | `2026-05-15` | terminal domain UI inspiration |
| `REF-WEZTERM-SHELL-INT` | web docs | moving-head | `2026-03-24` | `2026-04-15` | semantic-zone, cwd, and command-block protocol inspiration |
| `REF-WEZTERM-ZONES` | web docs | moving-head | `2026-03-23` | `2026-04-15` | semantic-zone API is useful for block/receipt UI but should not hard-freeze event naming yet |
| `REF-LANDLOCK` | kernel docs | moving-head | `2026-03-21` | `2026-05-15` | defense-in-depth backstop inspiration, not a ViewFS semantic dependency |
| `REF-FUCHSIA-SECURE` | web docs | moving-head | `2026-03-21` | `2026-05-01` | conceptual no-ambient-authority language; do not overfit exact prose |
| `REF-FUCHSIA-SANDBOXING` | web docs | moving-head | `2026-03-28` | `2026-05-01` | creator-populated namespace and no-self-grant precedent for launch-kit separation |
| `REF-XDG-OPENURI` | web docs | moving-head | `2026-03-21` | `2026-04-15` | URI-launch mediation inspiration only; keep separate from local-object grants |
| `REF-PLAN9-ACME` | web docs | moving-head | `2026-03-21` | `2026-05-15` | text-ui object/control-surface inspiration only |
| `REF-ITERM-SHELLINT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | mark/history/recent-directory and command-navigation UX inspiration only |
| `REF-ITERM-OSC8` | web docs | moving-head | `2026-03-21` | `2026-04-20` | hyperlink substrate inspiration; keep type/routing semantics in ViewFS layer |
| `REF-GHOSTTY-SHELLINT` | web docs | moving-head | `2026-03-24` | `2026-04-20` | shell-integration feature list is inspiration only |
| `REF-GHOSTTY-OSC133-OVERLAY` | release notes | moving-head | `2026-03-22` | `2026-04-20` | overlay idea is useful for inspector/debug tooling and prompt-local interaction debugging, not a protocol dependency |
| `REF-NIX-STORE` | web manual | moving-head | `2026-03-21` | `2026-05-15` | immutable-store framing only; avoid importing Nix build semantics wholesale |
| `REF-XDG-REQUEST` | web docs | moving-head | `2026-03-24` | `2026-04-15` | request handles are useful receipt precedents; do not overfit DBus path syntax |
| `REF-WEZTERM-USERVARS` | web docs | moving-head | `2026-03-22` | `2026-04-15` | explicit pane-state signaling inspiration; keep metadata distinct from authority |
| `REF-ITERM-HISTDISK` | web docs | moving-head | `2026-03-21` | `2026-04-20` | saved shell-state precedent; useful caution for session-memory design |
| `REF-GNOME-TRACKER` | web docs | moving-head | `2026-03-21` | `2026-04-15` | desktop search/index precedent; keep ambient-inventory risk in mind |
| `REF-GNOME-LOCALSEARCH` | web docs | moving-head | `2026-03-21` | `2026-04-15` | extraction/index policy precedent; useful for bounded derived-metadata ideas |
| `REF-GTK-RECENT` | web docs | moving-head | `2026-03-21` | `2026-04-15` | recent-item registry precedent; keep recency distinct from authority |
| `REF-WIN-PREVIEW-HANDLERS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | preview-as-read-only precedent only; do not overfit COM host details |
| `REF-WIN-PREVIEW-GUIDE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | inert-preview checklist inspiration; exact UI guidance is not a ViewFS contract |
| `REF-APPLE-QUICKLOOK-WWDC24` | video transcript | moving-head | `2026-03-22` | `2026-04-20` | preview-session/lifecycle inspiration only |
| `REF-XDG-BACKENDS` | web docs | moving-head | `2026-03-22` | `2026-04-15` | backend/frontend split inspiration; do not overfit DBus/backend packaging |
| `REF-VSCODE-WORKSPACE-TRUST` | web docs | moving-head | `2026-03-22` | `2026-04-20` | restricted-mode workspace-opening precedent only |
| `REF-VSCODE-TASKS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | user-vs-workspace automation split inspiration only |
| `REF-VSCODE-JUPYTER-TRUST` | web docs | moving-head | `2026-03-22` | `2026-04-20` | notebook trust boundary inspiration only |
| `REF-JETBRAINS-PROJSEC` | web docs | moving-head | `2026-03-22` | `2026-04-20` | project-trust prompt/trusted-locations inspiration only |
| `REF-DIRENV-ALLOW` | web docs | moving-head | `2026-03-22` | `2026-04-20` | explicit per-directory allow/deny inspiration only |
| `REF-DIRENV-REQUIREALLOWED` | web docs | moving-head | `2026-03-22` | `2026-04-20` | trust-invalidation-on-file-change inspiration only |
| `REF-WAYLAND-DATADEVICES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | transfer/data-offer precedent only; do not overfit Wayland-specific MIME/device mechanics |

| `REF-INOTIFY` | man page | moving-head | `2026-03-21` | `2026-04-20` | overflow/rebuild wording is useful for watch-health design; exact Linux flags are not a ViewFS protocol commitment |
| `REF-FANOTIFY` | man page | moving-head | `2026-03-21` | `2026-04-20` | access-notification vs object-access contrast case only; do not overfit Linux event taxonomy |
| `REF-APPLE-FSEVENTS` | web docs | moving-head | `2026-03-21` | `2026-04-20` | rescan/root-change lessons are useful; exact Apple flags are not a ViewFS contract |
| `REF-WIN-READDIRCHANGES` | web docs | moving-head | `2026-03-21` | `2026-04-20` | directory-scoped watch analogy only; exact Win32 API shape is not load-bearing |
| `REF-WIN-USN` | web docs | moving-head | `2026-03-21` | `2026-04-20` | persistent change-log / reindex lesson only; do not overfit NTFS-specific details |
| `REF-WATCHMAN-TROUBLE` | web docs | moving-head | `2026-03-21` | `2026-04-20` | explicit recrawl/limit-warning UX inspiration only |
| `REF-WATCHMAN-INSTALL` | web docs | moving-head | `2026-03-21` | `2026-04-20` | remote/distributed watch caveat inspiration only |


| `REF-LINUX-PATHLOOKUP` | kernel docs | moving-head | `2026-03-21` | `2026-04-20` | path-resolution restriction wording is useful; exact Linux naming is not a ViewFS contract |
| `REF-CAPPRIMS-FS` | docs.rs | moving-head | `2026-03-21` | `2026-04-20` | rooted/nofollow helper inspiration only; do not overfit Rust API names |
| `REF-WIN-SHELLLINK` | web docs | moving-head | `2026-03-21` | `2026-04-20` | shortcut/route-object inspiration only; avoid copying COM object details |
| `REF-WIN-HARDLINKS` | web docs | moving-head | `2026-03-21` | `2026-04-20` | link-class contrast case only; do not overfit NTFS implementation details |
| `REF-WIN-REPARSE` | web docs | moving-head | `2026-03-21` | `2026-04-20` | implementation-indirection caution only; not a ViewFS object contract |
| `REF-APPLE-BOOKMARKS` | archived web docs | semi-stable | `2026-03-21` | `2026-04-20` | bookmark-vs-path guidance is useful, but archived wording should not be treated as modern sandbox law |
| `REF-APPLE-SECBOOKMARK` | web docs | moving-head | `2026-03-21` | `2026-04-20` | security-scoped bookmark flow inspiration only |
| `REF-APPLE-SECWITHSCOPE` | web docs | moving-head | `2026-03-21` | `2026-04-20` | scope-typed bookmark creation inspiration only |
| `REF-APPLE-SECSTART` | web docs | moving-head | `2026-03-28` | `2026-04-20` | explicit start-accessing step inspiration only |
| `REF-APPLE-SECRESOLVE` | web docs | moving-head | `2026-03-28` | `2026-04-20` | stale-bookmark-resolution precedent only; do not overfit Apple URL APIs |
| `REF-ITERM-SEMHIST` | web docs | moving-head | `2026-03-21` | `2026-04-20` | semantic-history heuristic UX inspiration only; do not treat cwd-tracked guesses as authority semantics |
| `REF-APPLE-QUARANTINEKEY` | web docs | moving-head | `2026-03-21` | `2026-04-20` | quarantine-property API is useful vocabulary; exact API naming is not a ViewFS contract |
| `REF-APPLE-GATEKEEPER` | web docs | moving-head | `2026-03-21` | `2026-04-20` | guarded-open precedent only; do not overfit Apple-specific signing flow |
| `REF-APPLE-SAFEOPEN` | support doc | moving-head | `2026-03-21` | `2026-04-20` | user-facing explanation precedent only |
| `REF-APPLE-GATEKEEPER-BYPASS` | security content note | moving-head | `2026-03-21` | `2026-04-20` | cautionary bug-history source only; do not overfit one vendor bypass lineage |
| `REF-MS-ATTACHMENTMGR` | web docs | moving-head | `2026-03-21` | `2026-04-20` | zone-of-origin precedent; exact policy knobs are not a ViewFS contract |
| `REF-MS-MOTW-OFFICE` | web docs | moving-head | `2026-03-21` | `2026-04-20` | guarded-document precedent only; do not overfit Office product semantics |
| `REF-MS-APPGUARD` | web docs | moving-head | `2026-03-21` | `2026-04-20` | isolated-open precedent only; exact Hyper-V/container details are not load-bearing |
| `REF-MS-SMARTSCREEN` | web docs | moving-head | `2026-03-21` | `2026-04-20` | reputation-signal precedent only |
| `REF-EDGE-DL-DANGER` | web docs | moving-head | `2026-03-21` | `2026-04-20` | dangerous-file-type ladder inspiration only |


| `REF-FDO-TRASH` | web spec | moving-head | `2026-03-22` | `2026-04-20` | trash metadata / undelete precedent only; do not overfit XDG path layout |
| `REF-APPLE-TRASHITEM` | web docs | moving-head | `2026-03-22` | `2026-04-20` | trash-move / resulting-URL precedent only; exact Foundation API shape is not a ViewFS contract |
| `REF-MS-RECYCLEONDELETE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | recycle-vs-permanent-delete distinction inspiration only |
| `REF-NIX-GCROOTS` | web manual | moving-head | `2026-05-13` | `2026-06-15` | explicit-root retention precedent only; do not import Nix profile semantics wholesale |
| `REF-NIX-GC` | web manual | moving-head | `2026-03-22` | `2026-05-15` | separate purge/GC act precedent only |
| `REF-VSCODE-LOCALHISTORY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | local-history/timeline recovery inspiration only |
| `REF-GIT-REFLOG` | web docs | moving-head | `2026-03-28` | `2026-04-28` | reflog/ref-history precedent only; do not overfit Git ref syntax or storage layout |
| `REF-APPLE-APFS-FEATURES` | web docs | archive docs | `2026-03-22` | `2026-05-15` | APFS feature list is older archive material; use for broad inspiration only |
| `REF-ZFS-SNAPSHOT` | web docs | moving-head | `2026-03-22` | `2026-05-15` | atomic snapshot wording is useful; exact CLI flags are not a ViewFS contract |
| `REF-ZFS-CLONES` | web docs | moving-head | `2026-03-22` | `2026-05-15` | clone/promotion split inspiration only |
| `REF-ZFS-BOOKMARK` | web docs | moving-head | `2026-03-22` | `2026-05-15` | bookmark/send split is useful lineage inspiration; do not overfit ZFS naming |
| `REF-BTRFS-SUBVOLUMES` | web docs | moving-head | `2026-03-22` | `2026-05-15` | snapshot/fork semantics inspiration only |
| `REF-BTRFS-SEND` | web docs | moving-head | `2026-03-22` | `2026-05-15` | replication-stream analogy only; exact stream format is not load-bearing |
| `REF-GIT-WORKTREE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | parallel writable workspace inspiration only |
| `REF-MS-VSS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | backup-coordination / provider split inspiration only |
| `REF-OSTREE-OVERVIEW` | web docs | moving-head | `2026-03-28` | `2026-05-15` | object-store/deployment split inspiration only |
| `REF-OSTREE-MANUAL` | web docs | moving-head | `2026-03-22` | `2026-05-15` | lifecycle-verb separation inspiration only |
| `REF-RESTIC-FORGET` | web docs | moving-head | `2026-03-22` | `2026-04-20` | retention vs prune wording inspiration only |
| `REF-FREEBSD-BECTL` | man page | moving-head | `2026-03-22` | `2026-05-15` | boot-environment activation analogy only |

| `REF-RFC9110-PRECONDITIONS` | RFC / standards text | stable | `2026-03-28` | `2026-06-28` | standards-track source; exact section text is load-bearing for optimistic-precondition wording and weak-vs-strong validator discipline |
| `REF-S3-CONDITIONAL-WRITES` | web docs | moving-head | `2026-03-28` | `2026-04-20` | object-store conditional-write precedent; re-check API list / error wording before stronger commitments |
| `REF-S3-CONDITIONAL-DELETES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | delete-precondition wording may evolve; inspiration only |
| `REF-GIT-FORCE-WITH-LEASE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | ergonomic override precedent only; do not overfit exact CLI syntax |
| `REF-GIT-UPDATE-REF` | web docs | moving-head | `2026-03-28` | `2026-04-20` | compare-and-swap ref update precedent only |
| `REF-WEBDAV-LOCKING` | RFC / standards text | stable | `2026-03-22` | `2026-06-01` | lock-token / timeout / privilege split is load-bearing; exact XML surface is not |
| `REF-ETCD-TXN` | web docs | moving-head | `2026-05-13` | `2026-06-15` | transaction/compare-before-mutate precedent only; do not overfit etcd API shape |
| `REF-ETCD-LEASE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | lease TTL semantics are useful inspiration; exact etcdctl UX is not load-bearing |
| `REF-ETCD-LOCK` | web docs | moving-head | `2026-03-22` | `2026-04-20` | auto-release-on-lease-expiry precedent only |
| `REF-K8S-SSA` | web docs | moving-head | `2026-03-22` | `2026-04-20` | field-manager / conflict wording inspiration only; do not overfit K8s patch semantics |
| `REF-AZURE-BLOB-CONCURRENCY` | web docs | moving-head | `2026-05-13` | `2026-06-15` | optimistic-object-write / ETag precedent only |
| `REF-SQLITE-ISOLATION` | web docs | moving-head | `2026-03-22` | `2026-05-15` | cautionary concurrency-background source |
| `REF-SQLITE-LOCKINGV3` | web docs | moving-head | `2026-03-22` | `2026-05-15` | cautionary low-level locking source |
| `REF-APPLE-NSMETADATAQUERY` | web docs | moving-head | `2026-03-21` | `2026-04-20` | snapshot-vs-live-query wording is useful; do not overfit Cocoa API names |
| `REF-APPLE-SPOTLIGHT-QUERYGUIDE` | archived web docs | semi-stable | `2026-03-21` | `2026-05-15` | historical batching/update guidance is useful, but archived API details are not a ViewFS contract |
| `REF-APPLE-SMARTFOLDERS` | support doc | moving-head | `2026-03-21` | `2026-04-20` | folder-like saved-query UX precedent only; exact Finder UI is not load-bearing |
| `REF-WIN-SEARCH-MS` | web docs | moving-head | `2026-03-21` | `2026-04-20` | saved-search file-format precedent only; do not overfit Windows XML schema |

| `REF-APPLE-DOCPICKER-OPS` | archived web docs | semi-stable | `2026-03-22` | `2026-05-15` | archived but still useful lane-separation source; do not overfit UIKit API names |
| `REF-APPLE-DOCPICKER-ACCESS` | archived web docs | semi-stable | `2026-03-22` | `2026-05-15` | security-scoped open/move guidance is useful; archived details are not a ViewFS contract |
| `REF-ANDROID-CREATE-DOCUMENT` | web docs | moving-head | `2026-03-22` | `2026-04-20` | save-as / create-only wording inspiration only; re-check restrictions before stronger provider claims |
| `REF-WIN-SHELL-CLIPFORMATS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | explicit move/copy outcome-format precedent only; do not overfit COM clipboard APIs |
| `REF-WIN-SHELL-DATASCENARIOS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | delete-on-paste / optimized-move protocol inspiration only |
| `REF-APPLE-FILEPROMISES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | promised-file materialization inspiration only; exact AppKit drag APIs are not load-bearing |
| `REF-IPFS-PERSISTENCE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | retention-vs-gc precedent only; do not import IPFS network economics wholesale |
| `REF-NIX-REALISE` | web manual | moving-head | `2026-03-22` | `2026-05-15` | explicit hydration/realization precedent only |
| `REF-NIX-COPY` | web manual | moving-head | `2026-03-22` | `2026-05-15` | explicit closure-copy / transport precedent only |
| `REF-NIX-PREFETCH-FILE` | web manual | moving-head | `2026-03-22` | `2026-05-15` | prefetch/warm-up precedent only; do not import Nix CLI shape wholesale |
| `REF-OSTREE-REPO-MGMT` | web docs | moving-head | `2026-03-22` | `2026-05-15` | mirror/offline-access precedent only |
| `REF-OSTREE-STATIC-DELTAS` | web docs | moving-head | `2026-03-22` | `2026-05-15` | self-contained offline bundle precedent only |
| `REF-OSTREE-FORMATS` | web docs | moving-head | `2026-03-22` | `2026-05-15` | delta-format optimization precedent only |
| `REF-SVCWORKER-SPEC` | standards spec | moving-head | `2026-03-22` | `2026-06-01` | explicit cache/update/lifetime-state precedent only |
| `REF-MDNPREFETCH` | web docs | moving-head | `2026-03-22` | `2026-04-20` | prefetch-is-hint wording inspiration only; re-check browser caveats before stronger claims |
| `REF-MS-ALWAYSOFFLINE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | offline-cache UX precedent only; do not import Windows sync semantics wholesale |

| `REF-XDG-PORTAL-DESIGN` | web docs | moving-head | `2026-03-22` | `2026-04-15` | portal design/validation/request-shape inspiration only; do not overfit DBus transport details |
| `REF-CAPSICUM-ADOPTION` | web docs | moving-head | `2026-03-24` | `2026-04-20` | adoption/tooling lesson only; do not overfit FreeBSD-specific developer workflow |
| `REF-DENO-PERMISSIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | runtime permission-prompt posture inspiration only; do not overfit Deno module-loader specifics |
| `REF-ANDROID-DOCPROVIDER` | web docs | moving-head | `2026-03-22` | `2026-04-20` | provider-declared operation flags inspiration only; exact Android API names are not a ViewFS contract |
| `REF-MS-FUTUREACCESSLIST` | web docs | moving-head | `2026-03-24` | `2026-04-20` | bounded durable-access-list precedent only; exact UWP list mechanics are not a ViewFS contract |
| `REF-CEDAR-AUTHZ` | web docs | moving-head | `2026-03-22` | `2026-04-20` | determining-policy/error diagnostics are strong inspiration; do not overfit Cedar syntax or effect model |
| `REF-CEDAR-VALIDATION` | web docs | moving-head | `2026-03-22` | `2026-04-20` | validation-vs-authorization split is important; re-check before binding any schema workflow details |
| `REF-OPA-CORE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | policy-engine-vs-enforcement framing is inspiration only; do not import Rego or OPA deployment shape wholesale |
| `REF-OPA-DECISIONLOGS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | audit/redaction lessons are useful; exact log fields are not a ViewFS contract |
| `REF-POLKIT-AUTHORITY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | temporary-authorization caution only; do not overfit desktop DBus packaging or auth-agent APIs |
| `REF-MACAROONS-NDSS14` | paper landing page | moving-head | `2026-03-22` | `2026-04-20` | attenuation-caveat inspiration only; do not overfit token construction details |
| `REF-ZANZIBAR` | paper landing page | moving-head | `2026-03-22` | `2026-04-20` | consistency/freshness-token inspiration only; do not import ACL policy semantics wholesale |
| `REF-OPA-DISCOVERY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | discovery/boot-override wording is inspiration for visible precedence, not a commitment to OPA-style deployment plumbing |
| `REF-SPICEDB-CONSISTENCY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | consistency-mode and ZedToken wording is inspiration for cut/freshness UX, not a commitment to ReBAC semantics |

| `REF-GIT-CONFIG-ORIGIN-SCOPE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | origin/scope inspection precedent only; do not import Git config semantics wholesale |
| `REF-VSCODE-CHAT-CUSTOM-DIAG` | web docs | moving-head | `2026-03-22` | `2026-04-20` | customization-origin diagnostics precedent only |
| `REF-VSCODE-MCP-SERVERS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | workspace-vs-profile config plus trust-prompt precedent only |
| `REF-VSCODE-AGENT-PERMISSIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | session/workspace/future approval-scope precedent only |
| `REF-VSCODE-AUTOPILOT-PERMISSIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | session-scoped autonomy picker precedent only |

| `REF-CEDAR-SECURITY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | explicit deny / forbid-overrides-permit inspiration only; do not overfit Cedar effect syntax wholesale |
| `REF-VSCODE-CONTRIB-SCOPES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | scope-applicability precedent only; do not import VS Code setting taxonomy wholesale |
| `REF-VSCODE-WORKSPACE-TRUST-EXT` | web docs | moving-head | `2026-03-22` | `2026-04-20` | restricted-configuration gating precedent only |
| `REF-VSCODE-AGENT-TOOLS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | session-vs-broader approval-ladder precedent only |
| `REF-VSCODE-CHAT-OVERVIEW` | web docs | moving-head | `2026-03-22` | `2026-04-20` | permissions-picker/current-session autonomy precedent only |
| `REF-VSCODE-112` | web docs | moving-head | `2026-03-22` | `2026-04-20` | steering/queueing and session-state link-resolution precedent only |
| `REF-VSCODE-AGENT-PLUGINS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | trusted-carrier versus workspace-trust contrast inspiration only |
| `REF-VSCODE-CUSTOMIZE-AI` | web docs | moving-head | `2026-03-22` | `2026-04-20` | parent-repo/workspace customization discovery precedent only |
| `REF-VSCODE-COPILOT-SECURITY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | trust-boundary split and scoped approval precedent only |

| `REF-GIT-PROTECTED-CONFIG` | web docs | moving-head | `2026-03-22` | `2026-04-20` | protected-scopes precedent only; do not overfit exact Git scope names into ViewFS policy families |
| `REF-GIT-SAFE-DIRECTORY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | protected-only setting precedent only; exact Git repo-safety semantics are not a ViewFS contract |
| `REF-VSCODE-CUSTOM-INSTRUCTIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | auto-applied guidance precedent only; exact AI product behavior may evolve |
| `REF-VSCODE-PROMPT-FILES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | invoke-only helper precedent only; do not overfit VS Code markdown/frontmatter schema |
| `REF-VSCODE-CUSTOM-AGENTS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | source-inspection / tool-restriction precedent only; exact VS Code agent file layout is not a ViewFS contract |
| `REF-DENO-PERM-BROKER` | web docs | moving-head | `2026-03-22` | `2026-04-20` | central-broker precedent only; exact env-var/socket details are not load-bearing |

| `REF-VSCODE-PUBLISHER-TRUST` | web docs | moving-head | `2026-03-22` | `2026-04-20` | publisher-trust precedent only; do not overfit VS Code extension-marketplace workflows into ViewFS helper installs |
| `REF-VSCODE-MCP-SERVERS-LIVE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | install/start/enable/use lifecycle precedent only; exact MCP UI or JSON fields are not a ViewFS contract |
| `REF-VSCODE-PLUGIN-LIFECYCLE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | plugin-install versus runtime-liveness precedent only; exact plugin packaging is not a ViewFS contract |
| `REF-VSCODE-112-LIFECYCLE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | enablement-scope and update-approval precedent only; exact VS Code toggle names may change |
| `REF-VSCODE-COPILOT-BOUNDARIES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | multiple trust-boundary precedent only; do not import VS Code-specific trust list mechanics wholesale |
| `REF-DENO-PERM-BROKER-LIVE` | web docs | moving-head | `2026-03-22` | `2026-04-20` | live broker lane precedent only; exact broker transport details are not load-bearing |

| `REF-MCP-SPEC-FEATURES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | feature-kind split inspiration only; no commitment to raw MCP protocol adoption |
| `REF-MCP-RESOURCES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | resource-shelf precedent only; no commitment to URI shape or transport |
| `REF-MCP-PROMPTS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | prompt-chip precedent only; no commitment to MCP prompt schema |
| `REF-MCP-TOOLS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | tool-rack precedent only; no commitment to MCP tool-call ABI |
| `REF-MCP-COMPLETION` | web docs | moving-head | `2026-03-22` | `2026-04-20` | completion-popover and disclosure-risk precedent only |

| `REF-MCP-TASKS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | task-wrapper / final-result split inspiration only; no commitment to raw MCP task transport or field names |
| `REF-MCP-PROGRESS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | progress-lane precedent only; no commitment to MCP metadata shape |
| `REF-XDG-REQUEST` | web docs | moving-head | `2026-03-24` | `2026-04-15` | request-handle / later-response precedent only; do not overfit portal DBus object details |
| `REF-XDG-BACKGROUND` | web docs | moving-head | `2026-03-28` | `2026-04-25` | background-permission and status-message precedent only; exact portal options are not a ViewFS contract |
| `REF-HTTPAPI-IDEMPOTENCY-KEY` | web draft | moving-head | `2026-03-24` | `2026-04-24` | idempotency-key / fingerprint / expiry precedent only; final RFC number may change before publication |
| `REF-AWS-EC2-IDEMPOTENCY` | web docs | moving-head | `2026-03-24` | `2026-04-24` | client-token same-request / mismatch precedent only; exact AWS action list is not a ViewFS contract |
| `REF-STRIPE-IDEMPOTENT-REQUESTS` | web docs | moving-head | `2026-03-24` | `2026-04-24` | first-result replay / pruning-window precedent only; exact retention window may drift |
| `REF-STRIPE-ADVANCED-ERROR-HANDLING` | web docs | moving-head | `2026-03-24` | `2026-04-24` | retry-advice / replay-header precedent only; exact header names are not a ViewFS contract |
| `REF-GCLOUD-LRO` | web docs | moving-head | `2026-03-22` | `2026-05-15` | long-running-operation polling/wait precedent only; do not import Google API surface wholesale |
| `REF-VSCODE-TASKS-BG` | web docs | moving-head | `2026-03-22` | `2026-04-20` | background/watch-task completion precedent only; exact task JSON is not a ViewFS contract |
| `REF-VSCODE-109-BGAGENTS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | queued-follow-up and background-session UX precedent only; exact product wording may drift |
| `REF-VSCODE-110-TERMSECTIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | collapsible terminal-section precedent only; exact product chrome may drift |
| `REF-AIP151-LRO` | web docs | moving-head | `2026-03-22` | `2026-05-15` | operation-expiry and parallel-operation guidance inspiration only; do not import Google API surface wholesale |
| `REF-TEMPORAL-INTERRUPT` | web docs | moving-head | `2026-03-22` | `2026-04-20` | cancel-versus-terminate precedent only; exact Temporal control semantics are not a ViewFS contract |
| `REF-TEMPORAL-WFID` | web docs | moving-head | `2026-03-22` | `2026-04-20` | reset/reuse/use-existing precedent only; exact Temporal run-chain semantics are not a ViewFS contract |
| `REF-VSCODE-CHAT-SESSIONS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | fork/session-branch UX precedent only; exact product wording may drift |
| `REF-KUBECTL-ATTACH` | web docs | moving-head | `2026-03-22` | `2026-04-20` | live-session attach precedent only; do not overfit Kubernetes resource syntax |
| `REF-KUBECTL-LOGS` | web docs | moving-head | `2026-03-22` | `2026-04-20` | follow-only output precedent; exact CLI flags are not load-bearing |
| `REF-KUBECTL-PORTFWD` | web docs | moving-head | `2026-03-22` | `2026-04-20` | sideband tunnel lifetime precedent only; do not overfit pod-specific semantics |
| `REF-TMUX` | man page mirror | moving-head | `2026-03-22` | `2026-04-20` | read-only client and control-mode precedent; exact command syntax is not load-bearing |
| `REF-TEMPORAL-MESSAGES` | web docs | moving-head | `2026-03-22` | `2026-04-20` | query/signal/update split is highly relevant; SDK wording may drift |
| `REF-XDG-INPUTCAPTURE` | web docs | moving-head | `2026-03-22` | `2026-04-15` | enabled-versus-active precedent only; do not overfit compositor-specific details |
| `REF-SYSTEMD-FDSTORE` | web docs | moving-head | `2026-03-28` | `2026-04-20` | narrow exact-handle continuity-locker precedent only; do not overfit systemd service mechanics into ViewFS persistence semantics |

| `REF-MEMFD-CREATE` | man page mirror | moving-head | `2026-03-28` | `2026-04-20` | transient exact-byte capsule inspiration only; do not overfit Linux-only staging primitives into ViewFS architecture |
| `REF-MEMFD-SEALS` | man page mirror | moving-head | `2026-03-28` | `2026-04-20` | freeze-for-review / commit-last inspiration only; exact Linux seal flags are not a ViewFS contract |
| `REF-LINUX-MEMFD-PRESERVE` | kernel docs | moving-head | `2026-03-28` | `2026-04-20` | continuity caveat only; do not overfit kexec-specific preservation details into general ViewFS durability semantics |
| `REF-UNIX-SCMRIGHTS` | man page mirror | moving-head | `2026-03-28` | `2026-04-20` | explicit local handle-courier precedent only; do not overfit AF_UNIX transport details into ViewFS transfer semantics |

| `REF-SEL4-BADGES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | badge-on-cap-copy precedent only; do not overfit seL4 IPC or CSpace mechanics into ViewFS handle metadata |
| `REF-SYSTEMD-SOCKETACT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | startup-delivered-handle-kit precedent only; do not overfit systemd unit/socket mechanics into ViewFS launch design |
| `REF-VSCODE-SHELLINT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | command-chrome truth-ladder precedent only; exact escape sequences and product chrome may drift |
| `REF-LINUX-SETNS` | man page | moving-head | `2026-03-24` | `2026-04-20` | namespace-membership-via-handle precedent only; do not overfit Linux namespace taxonomy into ViewFS room semantics |
| `REF-LINUX-NAMESPACES7` | man page | moving-head | `2026-03-24` | `2026-04-20` | namespace-lifetime/pin precedent only; do not overfit Linux namespace lifetime rules into ViewFS storage semantics |
| `REF-APPLE-LAUNCHD-SOCKETS` | web docs | moving-head | `2026-03-24` | `2026-04-20` | launchd startup-socket retrieval precedent only; do not overfit Apple job-plist mechanics into ViewFS launch design |

| `REF-SOCKET-PASSCRED` | man page mirror | moving-head | `2026-03-22` | `2026-04-20` | courier-peer-witness precedent only; exact Linux socket options are not a ViewFS wire contract |
| `REF-VSCODE-106-ATTCMD` | web docs | moving-head | `2026-03-22` | `2026-04-20` | structured-command-packet precedent only; exact VS Code chat/product wording may drift |

| `REF-LINUX-PIDFD` | man page | moving-head | `2026-03-22` | `2026-04-20` | process-handle precedent only; do not overfit Linux-specific right surfaces |
| `REF-LINUX-PIDFD-GETFD` | man page | moving-head | `2026-03-22` | `2026-04-20` | cautionary stronger-process-rights precedent; keep separate from ordinary command cards |
| `REF-FREEBSD-PROCDESC` | man page | moving-head | `2026-03-22` | `2026-05-15` | cross-platform capability-shaped process reference precedent |

| `REF-LINUX-OPEN-TREE` | man page | moving-head | `2026-03-22` | `2026-04-20` | detached-fragment precedent only; do not overfit Linux mount internals into ViewFS namespace design |
| `REF-LINUX-MOVE-MOUNT` | man page | moving-head | `2026-03-22` | `2026-04-20` | attach-as-separate-act precedent only; exact Linux flags are not a ViewFS contract |
| `REF-LINUX-MOUNT-SETATTR` | man page mirror | moving-head | `2026-03-22` | `2026-04-20` | pre-attach posture precedent only; do not overfit Linux ID-mapped mount semantics |
| `REF-W3C-CLIPBOARD` | web spec | moving-head | `2026-03-24` | `2026-04-20` | typed clipboard/permission precedent only; exact browser permission behavior is not a ViewFS contract |
| `REF-WAYLAND-DATA-CONTROL` | web docs | moving-head | `2026-03-24` | `2026-04-20` | clipboard-manager role precedent only; unstable/deprecated protocol details are not load-bearing |
| `REF-XTERM-BRACKETED-PASTE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | input-origin precedent only; exact escape sequences may drift by terminal/app support |
| `REF-KITTY-KEYBOARD` | web docs | moving-head | `2026-03-23` | `2026-04-20` | disambiguated-key-packet precedent only; exact kitty protocol details are not a ViewFS wire contract |

| `REF-MAN7-FEXECVE` | man page | moving-head | `2026-03-22` | `2026-04-20` | exact-exec-object precedent only; do not overfit Linux/GLIBC execution quirks into ViewFS launch design |
| `REF-MAN7-EXECVEAT` | man page | moving-head | `2026-03-22` | `2026-04-20` | fd-based launch precedent only; exact `AT_EMPTY_PATH` and script caveats are not a ViewFS contract |
| `REF-SYSTEMD-CREDENTIALS` | web docs | moving-head | `2026-03-23` | `2026-04-20` | activation-time immutable-credential precedent only; do not overfit systemd credential directories into ViewFS carrier choice |

| `REF-LINUX-LDSO` | man page | moving-head | `2026-03-22` | `2026-04-20` | loader-search / startup-code-closure precedent only; do not overfit ELF/glibc knobs into ViewFS architecture |
| `REF-LINUX-DLOPEN` | man page | moving-head | `2026-03-22` | `2026-04-20` | late dynamic-import precedent only; exact `dlopen` flags are not a ViewFS contract |
| `REF-WIN-DLL-SEARCH` | web docs | moving-head | `2026-03-22` | `2026-04-20` | DLL search-order precedent only; exact Win32 directory order is not a ViewFS contract |
| `REF-WIN-LOADLIBRARY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | late import / name-based rediscovery caution only; exact Win32 API wording may drift |

| `REF-WAYLAND-PRIMARY-SELECTION` | web docs | moving-head | `2026-03-22` | `2026-04-20` | selection-offer precedent only; do not overfit Wayland primary-selection mechanics into ViewFS clipboard design |
| `REF-X11-ICCCM-SELECTIONS` | web docs | semi-stable | `2026-03-22` | `2026-05-15` | historical selection-owner/requestor precedent only; keep X11 property mechanics as cautionary shape, not protocol commitment |
| `REF-KITTY-CLIPBOARD` | web docs | moving-head | `2026-03-22` | `2026-04-20` | typed clipboard / permission-gated-read precedent only; exact kitty escape codes are not a ViewFS wire contract |


| `REF-LINUX-CREDENTIALS-JC` | man page | moving-head | `2026-03-22` | `2026-04-20` | classic job-control layering precedent only; do not overfit POSIX session/process-group internals into ViewFS object models |
| `REF-LINUX-SETPGID` | man page | moving-head | `2026-03-22` | `2026-04-20` | foreground-process-group precedent only; exact `tcsetpgrp` mechanics are not a ViewFS contract |
| `REF-LINUX-SETSID` | man page | moving-head | `2026-03-22` | `2026-04-20` | hangup/session-leader precedent only; do not overfit POSIX session lifecycle into ViewFS continuity design |
| `REF-GLIBC-LOGINTTY` | web docs | moving-head | `2026-03-22` | `2026-04-20` | controlling-terminal adoption precedent only; exact libc helper semantics are not a ViewFS wire contract |
| `REF-LINUX-TTY4` | man page | moving-head | `2026-03-22` | `2026-04-20` | controlling-terminal detach precedent only; `/dev/tty` path details are cautionary shape, not ViewFS naming guidance |

| `REF-FUCHSIA-RUNNER` | web docs | moving-head | `2026-03-22` | `2026-04-20` | runner-capability/environment precedent only; do not overfit Fuchsia component-manager specifics into ViewFS launch design |
| `REF-FUCHSIA-CAPS` | web docs | moving-head | `2026-05-13` | `2026-06-15` | environment-routed capability precedent only; keep Fuchsia routing mechanics as shape, not commitment |
| `REF-OCI-RUNTIME-CONFIG` | GitHub spec doc | moving-head | `2026-03-22` | `2026-04-20` | structured runtime-config precedent only; exact OCI bundle fields are not a ViewFS contract |
| `REF-OCI-PROCESS-CONFIGGO` | GitHub source | moving-head | `2026-03-22` | `2026-04-20` | structured process-bundle precedent only; exact OCI/Linux fields are not a ViewFS contract |
| `REF-ITERM-CMDSELECT` | web docs | moving-head | `2026-03-22` | `2026-04-20` | command-block selection precedent only; exact iTerm2 UI affordances are not a ViewFS wire contract |
| `REF-ITERM-CLEARBUFFER` | web docs | moving-head | `2026-03-22` | `2026-04-20` | mutable-area-vs-scrollback precedent only; exact menu names may drift |

| `REF-MAN7-OPEN` | man page | moving-head | `2026-03-24` | `2026-04-20` | open-file-description precedent only; do not overfit Linux fd semantics into every ViewFS handle family |
| `REF-MAN7-DUP` | man page | moving-head | `2026-03-22` | `2026-04-20` | duplicate-vs-independent-reopen precedent only; exact `FD_CLOEXEC` details are not a ViewFS contract |
| `REF-LINUX-FLOCK` | man page | moving-head | `2026-03-22` | `2026-04-20` | lock-attaches-to-open-state precedent only; exact advisory-lock semantics are not a ViewFS contract |

| `REF-LINUX-OPATH` | man page | moving-head | `2026-03-28` | `2026-04-20` | locator/metadata-handle precedent only; do not overfit Linux `O_PATH` mechanics into every ViewFS handle family |
| `REF-LINUX-STATX` | man page | moving-head | `2026-03-23` | `2026-04-20` | metadata-via-current-handle precedent only; exact `statx` fields are not a ViewFS contract |
| `REF-LINUX-OPENTREE` | man page | moving-head | `2026-03-23` | `2026-04-20` | rooted-designation / detached-fragment precedent only; exact mount-fd mechanics are not a ViewFS contract |

| `REF-MAN7-EXEC3P` | man page | moving-head | `2026-03-23` | `2026-04-20` | launch-boundary inheritance precedent only; do not overfit POSIX exec cleanup details into all ViewFS launch families |
| `REF-MAN7-POSIX-SPAWN` | man page | moving-head | `2026-03-23` | `2026-04-20` | child-slot/file-action precedent only; exact POSIX spawn mechanics are not a ViewFS wire contract |
| `REF-MAN7-CLOSE-RANGE` | man page | moving-head | `2026-03-23` | `2026-04-20` | bulk close-on-exec shutter precedent only; exact Linux range semantics are not a ViewFS contract |
| `REF-MAN7-FCNTL` | man page | moving-head | `2026-03-23` | `2026-04-20` | `FD_CLOFORK` precedent only; Linux support gaps are cautionary shape, not product commitment |
| `REF-OPENBSD-FCNTL` | man page | moving-head | `2026-03-23` | `2026-04-20` | close-on-fork concrete precedent only; exact OpenBSD descriptor-flag behavior is not a ViewFS contract |

| `REF-FUCHSIA-FSARCH` | web docs | moving-head | `2026-05-13` | `2026-06-15` | per-client namespace / arbitrary root-handle precedent only; do not overfit Fuchsia VFS mechanics |
| `REF-FREEBSD-RIGHTS-LIVE` | man page | moving-head | `2026-03-23` | `2026-04-20` | source-vs-destination directory-rights precedent only; exact Capsicum right names are not a ViewFS wire contract |
| `REF-MAN7-RENAME` | man page | moving-head | `2026-03-23` | `2026-04-20` | rename/replace/exchange precedent only; exact `renameat2()` flags are not a universal ViewFS feature set |

| `REF-MAN7-MOUNTNS` | man page | moving-head | `2026-03-23` | `2026-04-20` | bind-propagation / peer-group precedent only; do not overfit Linux shared-subtree mechanics into every ViewFS backend |

| `REF-LINUX-OTMPFILE` | web docs | moving-head | `2026-03-28` | `2026-04-20` | unnamed-object / publish-later precedent only; filesystem support details may drift |
| `REF-MAN7-LINKAT` | web docs | moving-head | `2026-03-28` | `2026-04-20` | namespace-publication precedent only; exact capability requirements may vary by kernel/filesystem |
| `REF-OCI-DESCRIPTOR` | GitHub markdown | moving-head | `2026-03-28` | `2026-04-20` | raw-byte descriptor-envelope precedent only; do not overfit OCI packaging or transport semantics into ViewFS object IDs |

| `REF-FUCHSIA-HANDLES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | explicit handle-rights / duplicate-drop-rights precedent only; do not overfit Zircon object taxonomy into ViewFS handle classes |
| `REF-KITTY-SHELLINT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | shell-integration bootstrap caution only; exact kitty env/overlay details are not a ViewFS wire contract |
| `REF-SD-NOTIFY-BARRIER` | man page | moving-head | `2026-03-23` | `2026-04-20` | exact-run/barrier attribution precedent only; do not overfit systemd notification transport into ViewFS terminal protocol |

| `REF-FUCHSIA-LIFECYCLE` | web docs | moving-head | `2026-03-23` | `2026-05-01` | persistent-state-versus-running-authority precedent only; do not overfit Fuchsia lifecycle details into ViewFS continuity design |
| `REF-CONTOUR-OSC133` | web docs | moving-head | `2026-03-23` | `2026-04-20` | explicit prompt/command/output segmentation precedent only; exact OSC vocabulary is not a ViewFS wire contract |

| `REF-WINDOWS-TERMINAL-SHELLINT` | blog/web docs | moving-head | `2026-03-23` | `2026-04-20` | semantic prompt/output segmentation precedent only; exact Windows Terminal feature names may drift |
| `REF-MS-SECBOOKMARK-CVE2025` | security research blog | moving-head | `2026-03-23` | `2026-04-20` | security-scoped bookmark caution only; exploit details are precedent, not a ViewFS protocol contract |

| `REF-W3C-CAPURL` | web docs | semi-stable | `2026-03-23` | `2026-06-01` | capability-URL leak-risk precedent only; keep W3C web guidance as cautionary shape, not a ViewFS token format |
| `REF-OCAPN-LOCATORS` | GitHub spec doc | moving-head | `2026-03-23` | `2026-04-20` | sturdyref-locator precedent only; do not overfit OCapN URI syntax or swiss-num shape into ViewFS tickets |
| `REF-APPLE-APPSANDBOX-FILES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | security-scoped bookmark posture precedent only; exact Apple entitlement wording may drift |
| `REF-APPLE-SECBOOKMARK-ENABLE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | persistent bookmark opt-in precedent only; exact Apple API text may drift |
| `REF-ZCAP-LD` | web spec | moving-head | `2026-03-23` | `2026-04-20` | delegation/expiry/revocation wording is inspiration only; do not overfit current zcap wire details into ViewFS tickets |
| `REF-SEL4-MANUAL-LATEST` | PDF manual | moving-head | `2026-03-23` | `2026-05-15` | explicit mint/revoke precedent only; do not overfit seL4 CSpace mechanics into every ViewFS provider |
| `REF-CAPSICUM-HANDBOOK` | web docs | moving-head | `2026-05-13` | `2026-06-15` | capability-mode / fd-as-capability precedent only; keep exact FreeBSD workflow as inspiration rather than contract |

| `REF-W3C-PERMISSIONS` | web spec | moving-head | `2026-03-28` | `2026-04-25` | permission-state vocabulary inspiration only; do not overfit browser-origin semantics |
| `REF-WICG-FSACCESS` | web spec | moving-head | `2026-03-28` | `2026-04-25` | permission query/request and repair-ladder inspiration only; do not overfit browser storage model |

| `REF-RATS-RFC9334` | RFC | stable | `2026-03-23` | `2026-06-01` | conceptual-message split precedent only; do not overfit remote-attestation workflow details |
| `REF-RATS-ENDORSEMENTS-DRAFT` | IETF draft | moving-head | `2026-03-23` | `2026-04-20` | endorsement/reference-value precedent only; draft status means wording may shift |
| `REF-IN-TOTO-ATTESTATION` | GitHub spec repo | moving-head | `2026-03-23` | `2026-04-20` | attestation-layering precedent only; exact JSON media types are not a ViewFS contract |
| `REF-SLSA-PROVENANCE` | web spec | moving-head | `2026-03-28` | `2026-04-20` | build-provenance precedent only; do not overfit software-build-only semantics |
| `REF-SLSA-VERIFY-V1` | web spec notes | moving-head | `2026-03-23` | `2026-04-20` | verification-separate-from-production precedent only |
| `REF-TUF-ROLES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | role/delegation precedent only; exact repository-role names are not a ViewFS contract |
| `REF-SIGSTORE-REKOR` | web docs | moving-head | `2026-03-23` | `2026-04-20` | transparency-log precedent only; public-log service details are not a ViewFS requirement |

| `REF-XDG-SESSION` | web docs | moving-head | `2026-03-28` | `2026-04-25` | long-lived session-handle and close-signal precedent only; do not overfit DBus object details |
| `REF-XDG-INHIBIT` | web docs | moving-head | `2026-03-28` | `2026-04-25` | request-vs-session-vs-monitoring-state precedent only; exact portal semantics are not a ViewFS contract |
| `REF-XDG-GLOBALSHORTCUTS` | web docs | moving-head | `2026-03-23` | `2026-04-15` | request-handle / session-handle / active-state split precedent only; exact shortcut taxonomy may evolve |

| `REF-HAIKU-FSMODULES` | web docs | semi-stable | `2026-03-23` | `2026-05-15` | live-query / virtual-query precedent only; do not overfit Haiku FS hook mechanics into ViewFS collection design |
| `REF-GNOME-SERVICES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | index-service / portal-gated-query precedent only; exact GNOME service names may drift |

| `REF-MCP-COMPLETION-20250618` | spec/web doc | moving-head | `2026-03-23` | `2026-04-20` | re-check completion reference/context/security wording before freezing candidate/packet vocabulary |
| `REF-LSP-COMPLETION-317` | spec/web doc | moving-head | `2026-03-23` | `2026-04-20` | re-check lazy resolve and insertion-field wording before freezing candidate-detail semantics |
| `REF-FISH-COMPLETIONS` | product docs | moving-head | `2026-03-23` | `2026-04-20` | re-check completion-condition wording before stronger candidate-shape claims |
| `REF-FISH-INTERACTIVE` | product docs | moving-head | `2026-03-23` | `2026-04-20` | re-check accept-word/autosuggestion wording before freezing insert-ladder UX |
| `REF-VSCODE-TERMINAL-API-TRUST` | product/API docs | moving-head | `2026-03-23` | `2026-04-20` | re-check command confidence/trust wording before freezing rerun-safety or packet-truth claims |
| `REF-PLAN9-PLUMBER4` | web docs | semi-stable | `2026-03-23` | `2026-05-15` | typed route-envelope precedent only; do not overfit Plan 9 port/rule mechanics into ViewFS packet law |
| `REF-OSC8-HYPERLINKS` | web gist/spec note | moving-head | `2026-03-23` | `2026-04-20` | hyperlink-as-cell-attribute precedent only; keep final typed-route semantics in ViewFS layer |
| `REF-LSP-DOCLINK-317` | spec/web doc | moving-head | `2026-03-23` | `2026-04-20` | re-check lazy-target/documentLink resolve wording before freezing entity-peel semantics |
| `REF-KITTY-HINTS` | product docs | moving-head | `2026-03-23` | `2026-04-20` | re-check hint matching/action customization wording before freezing route-slip UX |

| `REF-HTML-USER-ACTIVATION` | web spec | moving-head | `2026-03-23` | `2026-04-20` | user-action/consume-once precedent only; do not overfit HTML API classes into a universal ViewFS baton ABI |
| `REF-XDG-ACTIVATION-V1` | web protocol docs | moving-head | `2026-03-23` | `2026-04-20` | activation-token precedent only; exact token plumbing is compositor/portal-specific |
| `REF-XDG-INPUTCAPTURE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | enabled-vs-active control precedent only; exact trigger mechanics are not a ViewFS contract |
| `REF-MS-ALLOWSETFOREGROUND` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | foreground-transfer precedent only; exact Win32 conditions are inspiration, not ViewFS law |
| `REF-MS-COALLOWSETFOREGROUND` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | delegated foreground-eligibility precedent only; exact COM mechanics are not a ViewFS dependency |
| `REF-WAYLAND-XDGSHELL-USERACTION` | web protocol docs | moving-head | `2026-03-23` | `2026-04-20` | user-action-serial precedent only; keep final gesture-proof semantics in ViewFS layer |

| `REF-FUCHSIA-IO-RIGHTS` | web API docs | moving-head | `2026-03-23` | `2026-04-20` | re-check rights wording before freezing a normalized handle-rights vocabulary |
| `REF-RFC9110-ALLOW` | RFC/web spec | semi-stable | `2026-03-23` | `2026-05-15` | affordance-advertisement precedent only; do not overfit HTTP verb names into a universal ViewFS affordance ABI |

| `REF-MIMESNIFF` | web spec | moving-head | `2026-03-23` | `2026-04-20` | declared/computed MIME distinction precedent only; do not overfit browser fetch/context rules into the whole ViewFS type model |
| `REF-SHARED-MIME-INFO` | web spec | moving-head | `2026-03-23` | `2026-04-20` | desktop type-database precedent only; exact XML/glob/magic merge details may drift |
| `REF-APPLE-UTTYPE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | type-taxonomy/conformance precedent only; JS-rendered symbol details may drift |
| `REF-FDO-MIMEAPPS` | web spec | moving-head | `2026-03-23` | `2026-04-20` | handler-association/default-selection precedent only; desktop-env implementation details may drift |

| `REF-K8S-LABELS` | web docs | moving-head | `2026-03-23` | `2026-04-20` | selector-label precedent only; do not overfit Kubernetes object taxonomy into ViewFS metadata classes |
| `REF-K8S-ANNOTATIONS` | web docs | moving-head | `2026-03-23` | `2026-04-20` | arbitrary-metadata precedent only; do not overfit Kubernetes metadata shapes into ViewFS annotation storage |
| `REF-OCI-ANNOTATIONS` | web spec | moving-head | `2026-03-28` | `2026-04-20` | arbitrary-key/value metadata precedent only; exact OCI key namespaces are not a ViewFS contract |
| `REF-SELINUX-CONTEXTS` | vendor docs | semi-stable | `2026-03-23` | `2026-05-15` | policy-bearing label precedent only; do not overfit SELinux context tuple syntax into ViewFS policy labels |
| `REF-FIRST-TLP20` | standards/web docs | semi-stable | `2026-03-23` | `2026-05-15` | handling-boundary label precedent only; do not overfit TLP colors into ViewFS native label taxonomy |
| `REF-ITERM2-BADGES` | product docs | moving-head | `2026-03-23` | `2026-04-20` | dynamic badge-chrome precedent only; exact escape codes are not a ViewFS protocol contract |
| `REF-ITERM2-STATUSBAR` | product docs | moving-head | `2026-03-23` | `2026-04-20` | dynamic status-bar precedent only; exact widget list is product-specific |
| `REF-WEZTERM-RIGHT-STATUS` | product docs | moving-head | `2026-03-23` | `2026-04-20` | right-status chrome precedent only; exact Lua API details are not a ViewFS wire format |

| `REF-K8S-API-CONCEPTS-WATCH` | web docs | moving-head | `2026-03-28` | `2026-04-28` | watch-bookmark / resourceVersion / 410-reset precedent only; exact Kubernetes API query parameters are not a ViewFS wire contract |
| `REF-DROPBOX-DETECT-CHANGES` | web docs | moving-head | `2026-03-23` | `2026-04-20` | folder-cursor / longpoll / reset precedent only; exact Dropbox endpoint names are provider-specific |
| `REF-WATCHMAN-CLOCKSPEC` | web docs | moving-head | `2026-03-23` | `2026-04-20` | logical-clock precedent only; exact clockspec syntax is not a universal ViewFS token format |
| `REF-APPLE-FSEVENTS-GUIDE` | archived web docs | semi-stable | `2026-03-23` | `2026-05-15` | rescan/root-change/event-id precedent only; archived Apple wording should not be treated as modern API law |

| `REF-RFC7232-CONDITIONAL` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | conditional-write / lost-update wording is load-bearing; exact header set is inspiration, not a ViewFS wire contract |
| `REF-GCS-PRECONDITIONS` | web docs | moving-head | `2026-05-13` | `2026-06-15` | generation/metageneration wording may evolve; object-store precondition precedent only |
| `REF-MDN-CREATEWRITABLE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | browser writer-mode wording may drift; writable-session precedent only |

| `REF-RFC9110-RANGE` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | range/206/recombination wording is load-bearing; exact HTTP header syntax is inspiration, not a ViewFS wire contract |
| `REF-RFC9111-INCOMPLETE` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | incomplete-response caching wording is load-bearing; exact cache directives are inspiration, not a ViewFS sparse-store ABI |
| `REF-STARGZ-OVERVIEW` | project docs | moving-head | `2026-03-23` | `2026-04-20` | lazy-pull / OCI-compat wording may evolve; precedent only |
| `REF-STARGZ-ESTARGZ` | project docs | moving-head | `2026-03-23` | `2026-04-20` | on-demand file/chunk fetch wording may evolve; precedent only |
| `REF-AWS-S3-OBJECT-ETAG` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | ETag/checksum wording may evolve; multipart/composite and weak-versus-strong caution only |
| `REF-AWS-S3-MPU-OVERVIEW` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | multipart/full-checksum wording may evolve; object-store precedent only |
| `REF-AWS-S3-INTEGRITY` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | checksum-mode wording may evolve; integrity-layering precedent only |
| `REF-ZARR-V3-CORE` | web spec | moving-head | `2026-03-23` | `2026-04-20` | chunk-grid / codec wording may evolve; layout-metadata precedent only |


| `REF-RFC9110-IFRANGE` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | exact-basis/fallback wording is load-bearing; exact HTTP header syntax is inspiration, not a ViewFS wire contract |
| `REF-RFC3229-DELTAHTTP` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | delta/base-instance wording is load-bearing; exact 226/IM header syntax is inspiration, not a ViewFS wire contract |
| `REF-RFC3284-VCDIFF` | RFC / standards text | stable | `2026-03-23` | `2026-06-01` | source-window/target-window wording is load-bearing; exact binary format is inspiration, not a ViewFS mandatory codec |
| `REF-OSTREE-STATIC-DELTAS` | project docs | moving-head | `2026-03-23` | `2026-04-20` | exact static-delta wording may evolve; commit-pair and `from NULL` precedent only |
| `REF-ZSYNC-THEORY` | archived project docs | semi-stable | `2026-03-23` | `2026-05-15` | control-file/checksum wording may be brittle; local-byte-reuse precedent only |

| `REF-PLAN9` | paper/web docs | semi-stable | `2026-03-23` | `2026-06-01` | foundational per-process-namespace precedent only; do not overfit 9P/file-server mechanics into ViewFS object law |
| `REF-PLAN9-PLUMB` | web docs | semi-stable | `2026-03-23` | `2026-06-01` | typed routing-rule precedent only; do not overfit Plan 9 plumbing syntax into ViewFS transport law |

| `REF-SANDSTORM-POWERBOX` | Sandstorm docs | moving-head | `2026-03-28` | `2026-04-20` | mediation/candidate-fit wording may evolve; precedent only |
| `REF-SANDSTORM-GRAINS` | Sandstorm web page | moving-head | `2026-03-28` | `2026-04-20` | object-container framing is inspiration only; do not import Sandstorm's whole hosting model wholesale |
| `REF-PLAN9-IMPORT` | plan9port man page | moving-head | `2026-03-23` | `2026-04-20` | imported-fragment precedent only; exact command options are not a ViewFS contract |
| `REF-FOUNDATION-CAS` | paper copy | moving-head | `2026-03-23` | `2026-06-01` | archival CAS precedent is stable, but storage-economics wording should still be re-checked before quoting |
| `REF-LINUX-ACCESS` | man page | moving-head | `2026-03-23` | `2026-04-20` | exact-name reachability/search-permission precedent only; do not overfit POSIX directory semantics wholesale |
| `REF-WASI-P1-RIGHTS` | docs.rs | moving-head | `2026-03-23` | `2026-04-20` | browse-vs-open rights split is inspirational; exact constant names are not a final ViewFS API |

| `REF-FUCHSIA-CONNECT` | web docs | moving-head | `2026-03-23` | `2026-04-20` | outgoing/exposed capability publication precedent only; do not overfit Fuchsia directory shapes |
| `REF-MCP-ROOTS` | web docs | moving-head | `2026-03-23` | `2026-04-20` | scope/catalog precedent only; no commitment to MCP roots transport or URI shape |
| `REF-DNSSD` | RFC/web docs | stable | `2026-03-23` | `2027-03-23` | browse/resolve separation precedent only; no commitment to network service discovery as a ViewFS transport |
| `REF-K8S-ENDPOINTSLICE` | web docs | moving-head | `2026-03-23` | `2026-04-20` | freshness-scoped readiness precedent only; do not overfit Kubernetes endpoint lifecycle fields |

| `REF-GIT-PARTIAL-CLONE` | Git docs | semi-stable | `2026-03-23` | `2026-05-15` | promisor/missing-object precedent only; exact filter/protocol details are not a ViewFS wire contract |
| `REF-NIX-SSH-SUBSTITUTER` | Nix docs | moving-head | `2026-03-23` | `2026-04-20` | substituter/source-ladder precedent only; exact CLI and transport details may evolve |
| `REF-FUCHSIA-AVAILABILITY` | web docs | moving-head | `2026-03-23` | `2026-04-20` | route-expectation precedent only; exact Fuchsia availability taxonomy may evolve |
| `REF-GHOSTTY-CURSORCLICK` | product docs | moving-head | `2026-03-23` | `2026-04-20` | prompt-marking/cursor-move precedent only; exact config fields are product-specific |

| `REF-RFC6749-AUTHCODE` | RFC 6749 section 4.1.2 | stable | `2026-03-23` | `2027-03-23` | single-use, short-lived, client-bound claim precedent only; do not overfit OAuth redirect machinery |
| `REF-RFC9449-DPOP` | RFC 9449 | stable | `2026-03-23` | `2027-03-23` | sender-constraining / holder-bound precedent only; do not overfit OAuth/JWT wire details |
| `REF-ANDROID-PENDINGINTENT-SECURITY` | Android security docs | moving-head | `2026-03-23` | `2026-04-20` | replayable compact-authority artifact precedent only; exact API flags are Android-specific |

| `REF-RFC9470-STEPUP` | RFC / standards text | stable | `2026-03-23` | `2027-03-23` | step-up / recency challenge precedent only; do not overfit OAuth bearer challenge syntax into ViewFS wire contracts |
| `REF-OIDC-CORE-MAXAGE` | standards web spec | semi-stable | `2026-03-23` | `2026-06-01` | `max_age` / `auth_time` / `acr` recency precedent only; exact OIDC claim syntax is not a ViewFS schema |
| `REF-WEBAUTHN-3` | standards web spec | moving-head | `2026-03-23` | `2026-04-20` | user-presence / user-verification precedent only; exact authenticator flag layout may continue to evolve |
| `REF-ANDROID-KEYSTORE-AUTH` | Android security docs | moving-head | `2026-03-23` | `2026-04-20` | locally-held-but-auth-gated precedent only; exact Android API knobs are platform-specific |
| `REF-RFC7662-INTROSPECT` | RFC HTML | effectively stable | `2026-03-23` | `2026-06-01` | token current-state semantics are load-bearing for watch/status separation |
| `REF-RFC7009-REVOKE` | RFC HTML | effectively stable | `2026-03-23` | `2026-06-01` | revocation style trade-offs are precedent only; do not overfit OAuth token styles to ViewFS handles |
| `REF-RFC6960-OCSP` | RFC HTML | effectively stable | `2026-03-23` | `2026-06-01` | good/revoked/unknown plus freshness fields are strong status-carrier precedent |
| `REF-RFC5280-CRL` | RFC HTML | effectively stable | `2026-03-23` | `2026-06-01` | certificateHold/removeFromCRL are useful hold-resume precedent only |
| `REF-VC-BITSTRING-STATUS` | W3C Recommendation | moving-head | `2026-03-23` | `2026-05-15` | typed compact status carrier precedent; re-check if ViewFS ever imports more of the VC lifecycle stack |
| `REF-TUF-METADATA` | web docs | moving-head | `2026-03-23` | `2026-05-15` | metadata expiry/freshness wording is relevant; exact product/docs language may drift |
| `REF-TUF-SPEC` | web spec | moving-head | `2026-03-23` | `2026-05-15` | root-rotation / freeze-attack language is useful precedent; do not overfit the entire TUF role model |

| `REF-MACH-PORT-RIGHTS` | archived vendor docs | semi-stable | `2026-03-23` | `2026-06-01` | port-right-class precedent only; do not overfit Mach IPC object taxonomy into ViewFS object law |
| `REF-SEL4-GRANT` | PDF manual / API docs | semi-stable | `2026-03-23` | `2026-06-01` | live-authority-transfer-right precedent only; do not overfit seL4 endpoint/message ABI into ViewFS courier design |
| `REF-KITTY-FILETRANSFER` | product docs | moving-head | `2026-03-23` | `2026-04-20` | terminal-native transfer-lane precedent only; exact kitty protocol framing is not a mandatory ViewFS wire format |

| `REF-APPLE-FILEPROVIDER-SYNC` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | dataless/materialized locality precedent only; exact Apple sync lifecycle and API names may evolve |
| `REF-FUCHSIA-COMPONENT-NSENTRY` | FIDL reference docs | moving-head | `2026-03-23` | `2026-04-20` | explicit namespace-attach precedent only; exact FIDL/type names are not a ViewFS schema |

| `REF-ANDROID-SHARE-FILE` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | Intent/temporary-grant wording may evolve; route-envelope versus grant precedent only |
| `REF-ANDROID-URIPERMISSION` | vendor docs | moving-head | `2026-03-28` | `2026-04-25` | UriPermission field wording may evolve; grant-object precedent only |
| `REF-ANDROID-GRANTURIPERMISSION` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | manifest/path-subset wording may evolve; scoped-grant precedent only |

| `REF-CONFUSED-DEPUTY-HARDY` | PDF / paper mirror | semi-stable | `2026-03-23` | `2026-06-01` | foundational deputy-warning precedent only; do not overfit access-list-era details into ViewFS wire contracts |
| `REF-JEP506-SCOPEDVALUES` | OpenJDK JEP | moving-head | `2026-03-23` | `2026-04-20` | bounded-dynamic-scope precedent only; exact release/history details may evolve in OpenJDK docs |
| `REF-JAVA-SCOPEDVALUE-API` | vendor API docs | moving-head | `2026-03-23` | `2026-04-20` | bounded-binding/rebinding precedent only; exact Java API surface is not a ViewFS wire contract |
| `REF-PY-CONTEXTVARS` | language docs | moving-head | `2026-03-23` | `2026-04-20` | context-local/reset-token precedent only; exact Python object names are not a ViewFS schema |
| `REF-NODE-ASYNCLOCALSTORAGE` | runtime docs | moving-head | `2026-03-23` | `2026-04-20` | bounded async-context / context-bleed warning precedent only; exact Node API names are not a ViewFS protocol |
| `REF-ASPNET-HTTPCONTEXTACCESSOR` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | ambient-state caution precedent only; exact ASP.NET type names are not a ViewFS schema |

| `REF-ANDROID-VIRTUALFILES` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | virtual-file and alternate-MIME wording may evolve; representation-coercion precedent only |
| `REF-WIT-RESOURCE-HANDLES` | project docs | moving-head | `2026-05-13` | `2026-06-15` | component-model resource-handle wording may evolve; external-handle / owned-vs-borrowed precedent only |

| `REF-GHOSTTY-SHELL-INTEGRATION` | product docs | moving-head | `2026-03-23` | `2026-04-20` | shell-integration/manual-sourcing precedent only; exact Ghostty shell snippets are product-specific |
| `REF-POWERSHELL-PROFILES` | vendor docs | moving-head | `2026-03-23` | `2026-04-20` | startup-profile-as-script precedent only; exact host/profile matrix is PowerShell-specific |

| `REF-VSCODE-PROFILES` | product docs | moving-head | `2026-03-24` | `2026-04-20` | subsetted profile-content precedent only; exact VS Code profile payload classes may evolve |
| `REF-FISH-ABBR` | shell docs | moving-head | `2026-03-24` | `2026-04-20` | typed-only abbreviation precedent only; exact fish flags/functions are product-specific |
| `REF-NU-OVERLAYS` | shell docs | moving-head | `2026-03-24` | `2026-04-20` | explicit overlay-layer precedent only; exact Nushell commands/types are not a ViewFS schema |
| `REF-NU-CUSTOMCOMMANDS` | shell docs | moving-head | `2026-03-24` | `2026-04-20` | first-class custom-command precedent only; exact Nushell language features are not a ViewFS contract |
| `REF-NU-WHICH` | shell docs | moving-head | `2026-03-24` | `2026-04-20` | command-resolution explainability precedent only; exact Nushell output schema is not a ViewFS protocol |
| `REF-ZSH-ZLE` | shell manual | semi-stable | `2026-03-24` | `2026-06-01` | widget/keymap distinction precedent only; exact ZLE names are not a ViewFS schema |
| `REF-GHOSTTY-KEYTABLES` | product release notes | moving-head | `2026-03-24` | `2026-04-20` | explicit modal-key-table precedent only; exact Ghostty keybind syntax may evolve |
| `REF-GHOSTTY-CMDPALETTE` | product docs | moving-head | `2026-03-24` | `2026-04-20` | palette-action precedent only; exact Ghostty UI fields are product-specific |

| `REF-TREESITTER` | web docs | moving-head | `2026-03-24` | `2026-04-21` | incremental parse / error-recovery precedent only; do not overfit one grammar API or tree shape |
| `REF-LSP-DIAGNOSTICS-317` | web docs | semi-stable | `2026-03-24` | `2026-06-01` | diagnostic-channel precedent only; exact field names are not a ViewFS wire contract |
| `REF-SHELLCHECK` | web docs | moving-head | `2026-03-24` | `2026-04-21` | shell-diagnostic precedent only; exact rule catalog is not a ViewFS policy language |
| `REF-FISH-SYNTAX` | web docs | moving-head | `2026-03-24` | `2026-04-21` | inline shell-feedback precedent only; no commitment to fish parser/highlight semantics |

| `REF-FUCHSIA-ORIG-PRINCIPLES` | web docs | moving-head | `2026-03-24` | `2026-04-21` | environment-inheritance ambient-authority warning precedent only; exact Fuchsia environment mechanics may evolve |
| `REF-GHOSTTY-130` | product release notes | moving-head | `2026-03-24` | `2026-04-21` | OSC-133-backed command-finished chrome precedent only; exact Ghostty UI wording may evolve |

| `REF-SD-NOTIFY` | web docs | moving-head | `2026-03-24` | `2026-04-20` | watchdog / timeout-extension semantics are inspiration for renewal-window and repair-gate seams only |
| `REF-HTTP-RFC9110` | RFC text | stable-ish | `2026-03-24` | `2026-06-01` | `Retry-After` is a tiny timing-hint precedent; exact HTTP semantics are not otherwise load-bearing |
| `REF-NUSHELL-OVERLAYS` | web docs | moving-head | `2026-03-24` | `2026-05-15` | overlay activation/deactivation is shell UX inspiration only |
| `REF-VSCODE-SHELL-INTEGRATION` | web docs | moving-head | `2026-03-24` | `2026-04-20` | shell-integration quality badges are terminal UX inspiration only |


| `REF-ANDROID-BG-EXEC-LIMITS` | web docs | moving-head | `2026-03-24` | `2026-04-20` | background-limit precedent only; exact Android class names/time limits are not a ViewFS contract |
| `REF-APPLE-BGTASKS` | web docs | moving-head | `2026-03-24` | `2026-04-20` | deferred-background-work precedent only; exact Apple scheduling heuristics are not a ViewFS contract |
| `REF-K8S-LEASE` | web docs | moving-head | `2026-03-24` | `2026-04-20` | lease-holder/renew-time precedent only; do not overfit Kubernetes object schema into ViewFS continuity |
| `REF-VSCODE-199-SHELLINT` | product release notes | moving-head | `2026-03-24` | `2026-04-20` | shell-integration quality precedent only; exact VS Code UI wording may evolve |

| `REF-XDG-NOTIFICATION` | web docs | moving-head | `2026-03-24` | `2026-04-21` | request/presentation separation precedent only; exact portal method names are not a ViewFS wire contract |
| `REF-ANDROID-NOTIF-CHANNELS` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | interruption-grade/user-control precedent only; exact channel APIs are Android-specific |
| `REF-ANDROID-TIMESENSITIVE` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | urgent-notification/foreground-service precedent only; exact Android policy gates may evolve |
| `REF-APPLE-CRITICAL-ALERTS` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | separate-entitlement interruption precedent only; exact Apple entitlement mechanics are platform-specific |
| `REF-TMUX-ALERTS` | man page / project docs | semi-stable | `2026-03-24` | `2026-06-01` | activity/bell/silence chrome precedent only; exact tmux options are not a ViewFS protocol contract |

| `REF-XTERM-FOCUS` | web docs | moving-head | `2026-03-24` | `2026-04-21` | terminal focus-hint precedent only; exact escape sequences/support are not a ViewFS trust contract |

| `REF-XDG-INPUTCAPTURE` | web docs | moving-head | `2026-03-24` | `2026-04-21` | input-capture enabled-vs-active precedent only; exact portal fields are not a ViewFS wire contract |
| `REF-XDG-REMOTEDESKTOP` | web docs | moving-head | `2026-03-28` | `2026-04-25` | remote-control session / input-lane precedent only; exact EIS transport details are not a ViewFS protocol commitment |
| `REF-ANDROID-MEDIAPROJECTION` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | user-mediated mirror/session precedent only; exact Android token lifecycle may evolve |
| `REF-ANDROID-FLAGSECURE` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | secure-surface redaction precedent only; exact Android window-flag behavior is platform-specific |
| `REF-FUCHSIA-A11Y` | web docs | moving-head | `2026-03-24` | `2026-04-21` | assistive-view / intercept/inject precedent only; exact Fuchsia accessibility APIs may evolve |
| `REF-FUCHSIA-FOCUSCHAIN` | web docs | moving-head | `2026-03-24` | `2026-04-21` | trusted focus-chain / race-humility precedent only; exact Scenic focus APIs are not a ViewFS protocol contract |
| `REF-WIN-UIAUT-SECURITY` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | assistive automation security precedent only; exact Windows UIA details are platform-specific |
| `REF-WIN-UIACCESS-SECUREDESKTOP` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | secure-desktop/UIAccess boundary precedent only; exact Group Policy fields are not a ViewFS schema |

| `REF-ANDROID-FILEPROVIDER` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | content-URI/share-handle precedent only; exact Android manifest/XML details are not a ViewFS schema |
| `REF-MS-CFREGISTER` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | placeholder/hydration-policy precedent only; exact CFAPI flags are platform-specific |
| `REF-MS-CFCONVERT` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | convert-to-placeholder precedent only; exact Cloud Files API semantics are not a ViewFS wire contract |
| `REF-OVERLAYFS` | kernel docs | moving-head | `2026-03-24` | `2026-04-21` | lower/upper/workdir, whiteout, opaque-dir, and merged-readdir posture are inspiration only; exact Linux mount options are not a ViewFS wire contract |
| `REF-PLAN9-UNIONDIRS` | web docs | semi-stable | `2026-03-24` | `2026-06-01` | ordered union-member / create-target precedent only; exact Plan 9 bind flags are not a ViewFS schema |
| `REF-K8S-PROJECTED-VOLUMES` | web docs | moving-head | `2026-03-24` | `2026-04-21` | multi-source merged-directory precedent only; exact Kubernetes volume-source set may evolve |
| `REF-APPLE-FILEPROVIDER-PLACEHOLDER` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | placeholder-only precedent; exact Apple API names may evolve |
| `REF-APPLE-FILEPROVIDER-STARTPROVIDING` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | placeholder-to-materialized-file precedent only; exact Apple API names may evolve |
| `REF-APPLE-FILEPROVIDER-EVICT` | vendor docs | moving-head | `2026-03-24` | `2026-04-21` | explicit evict/dehydrate precedent only; exact Apple API names may evolve |

| `REF-RFC9110-202` | RFC / standards text | stable | `2026-03-24` | `2026-06-01` | acceptance-vs-completion wording is load-bearing; exact status-code wire syntax is inspiration, not a ViewFS contract |
| `REF-GDRIVE-LRO` | product docs | moving-head | `2026-03-24` | `2026-04-21` | operation-resource polling wording may evolve; use only for accepted-vs-operation separation precedent |
| `REF-AZURE-ASYNC-REQREPLY` | architecture docs | moving-head | `2026-03-24` | `2026-04-21` | status-endpoint / redirect pattern is precedent only; do not import Azure headers or exact flow wholesale |

| `REF-GO-CONTEXT` | package docs | moving-head | `2026-03-24` | `2026-04-21` | context propagation/cancel-cause wording is inspiration only; exact Go API names are not a ViewFS wire contract |
| `REF-GO-WITHOUTCANCEL` | package docs / release notes | moving-head | `2026-03-24` | `2026-04-21` | detach-without-parent-cancel precedent only; exact Go function names are not a ViewFS schema |
| `REF-GRPC-DEADLINES` | web docs | moving-head | `2026-03-24` | `2026-04-21` | deadline propagation / `DEADLINE_EXCEEDED` precedent only; exact gRPC status details are not a ViewFS wire contract |
| `REF-KOTLIN-CANCEL` | web docs | moving-head | `2026-03-24` | `2026-04-21` | cooperative-cancellation precedent only; exact Kotlin suspension semantics may evolve |
| `REF-KOTLIN-NONCANCELLABLE` | API docs | moving-head | `2026-03-24` | `2026-04-21` | cleanup-only shielding precedent only; exact coroutine builder behavior is language-specific |
| `REF-TEMPORAL-DISCONNECTEDCTX` | product docs | moving-head | `2026-03-24` | `2026-04-21` | disconnected-cleanup-root precedent only; exact Temporal API shapes are not a ViewFS contract |
| `REF-CAPNP-CANCEL` | web docs / project news | moving-head | `2026-03-24` | `2026-04-21` | RPC-logistics cancellation precedent only; exact Cap'n Proto C++ API details are not a ViewFS schema |
| `REF-AWS-S3-REQUESTER-PAYS` | web docs | moving-head | `2026-03-24` | `2026-04-20` | requester-pays posture is inspiration only; do not overfit S3-specific headers or billing edge cases |
| `REF-GCS-REQUESTER-PAYS` | web docs | moving-head | `2026-03-24` | `2026-04-20` | billing-project semantics may evolve; useful for explicit payer posture, not for freezing request syntax |
| `REF-K8S-RESOURCEQUOTA` | web docs | moving-head | `2026-03-24` | `2026-04-20` | quota/authorization separation is load-bearing; exact admission details are not a ViewFS contract |
| `REF-K8S-RBAC` | web docs | moving-head | `2026-03-24` | `2026-04-20` | authorization contrast source only; do not import Kubernetes role syntax |
| `REF-SEL4-MCS` | web docs | moving-head | `2026-03-24` | `2026-05-15` | scheduling-context donation is inspiration for budget/object separation, not a direct API dependency |
| `REF-GENODE-QUOTA` | web docs | moving-head | `2026-03-24` | `2026-05-15` | session-property donation posture is inspiration only; avoid overfitting Genode session syntax |
| `REF-CGROUPV2` | kernel docs | moving-head | `2026-03-24` | `2026-05-15` | hierarchical resource-control wording is useful, but cgroup paths must not become portable payer identity |

| `REF-RFC6920` | RFC text | stable | `2026-03-28` | `2026-06-01` | hash-name precedent only; exact-byte naming must not be mistaken for semantic sameness or live authority |

| `REF-GIT-PATCH-ID` | web docs | moving-head | `2026-03-28` | `2026-04-28` | stable-subset digest precedent only; do not overfit patch semantics into ViewFS exact-proof or authority taxonomy |
| `REF-IN-TOTO-STATEMENT` | GitHub spec repo | moving-head | `2026-03-28` | `2026-04-20` | subject-digest versus descriptive-envelope precedent only; exact JSON layering is not a ViewFS contract |

| `REF-IN-TOTO-ENVELOPE` | GitHub spec repo | moving-head | `2026-03-28` | `2026-04-20` | envelope-layer / signed-payload-type precedent only; exact field names or media-type strings are not a ViewFS contract |

| `REF-K8S-OBJECT-NAMES` | web docs | moving-head | `2026-03-28` | `2026-04-28` | name-versus-UID precedent only; do not import Kubernetes object taxonomy wholesale |
| `REF-ETCD-API-REVISIONS` | web docs | moving-head | `2026-03-28` | `2026-04-28` | revision/version layering precedent only; do not overfit etcd global-clock semantics into ViewFS |
| `REF-AWS-S3-VERSIONING` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | key/version-id/delete-marker precedent only; exact S3 bucket/versioning behavior is not a ViewFS contract |

| `REF-LINUX-FICLONE` | man page | semi-stable | `2026-03-28` | `2026-05-01` | reflink/shared-backing precedent only; exact ioctl names or kernel limits are not a ViewFS contract |
| `REF-BTRFS-REFLINK` | project docs | moving-head | `2026-03-28` | `2026-04-28` | shallow-copy/shared-blocks precedent only; exact filesystem constraints are not a ViewFS contract |
| `REF-ZFSCONCEPTS-CLONES` | project docs | moving-head | `2026-03-28` | `2026-04-28` | snapshot-origin/promotion precedent only; exact dataset semantics are not a ViewFS contract |
| `REF-APPLE-APFS-ABOUT` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | cheap-clone precedent only; exact APFS APIs or volume constraints are not a ViewFS contract |

| `REF-AWS-S3-CREATEMPU` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | multipart upload-ID / cleanup wording may evolve; upload-session precedent only |
| `REF-AWS-S3-COMPLETEMPU` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | completion part-list wording may evolve; explicit-finalization precedent only |
| `REF-TUS-PROTOCOL` | protocol spec | moving-head | `2026-03-28` | `2026-04-28` | resumable offset/session wording may evolve; session/progress precedent only |
| `REF-OCI-DISTRIBUTION-CHUNKED` | project spec | moving-head | `2026-03-28` | `2026-04-28` | chunked-upload phase wording may evolve; explicit-phasing precedent only |
| `REF-GCS-RESUMABLE-UPLOADS` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | session-URI / expiry wording may evolve; resumable-session precedent only |

| `REF-GCS-COMPOSITE` | web docs | moving-head | `2026-03-28` | `2026-04-28` | compose/composite wording is useful; do not overfit Google metadata quirks like composite ETag/MD5 caveats into the core object model |
| `REF-OCI-MANIFEST` | github spec | moving-head | `2026-03-28` | `2026-04-28` | descriptor-graph precedent only; exact OCI media-type names are not a ViewFS contract |
| `REF-OCI-IMAGE-INDEX` | github spec | moving-head | `2026-03-28` | `2026-04-28` | higher-level index precedent only; do not overfit OCI platform-selection semantics |
| `REF-GIT-WRITE-TREE` | web docs | moving-head | `2026-03-28` | `2026-04-28` | explicit staged-membership precedent only; do not overfit Git index/worktree storage details |
| `REF-CONTAINERD-PULL-UNPACK` | github docs | moving-head | `2026-03-28` | `2026-04-28` | content-store/unpack/task layering inspiration only; do not treat containerd object names as ViewFS taxonomy |

| `REF-AWS-S3-OBJECT-LOCK` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | retention-period / legal-hold independence precedent only; exact S3 permissions and versioning behavior are not a ViewFS contract |
| `REF-GCS-OBJECT-HOLDS` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | temporary-hold versus event-hold precedent only; exact Cloud Storage API details are not a ViewFS contract |
| `REF-GCS-OBJECT-RETENTION-LOCK` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | retain-until / lock-mode / lifecycle contrast precedent only; exact Cloud Storage feature gates are not a ViewFS contract |
| `REF-AZURE-IMMUTABLE-BLOB` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | legal-hold / scope / audit-log precedent only; exact Azure account or container policy mechanics are not a ViewFS contract |

| `REF-RFC7516-JWE` | RFC / standards text | stable | `2026-03-28` | `2026-06-01` | multi-recipient shared-ciphertext / per-recipient-wrap precedent only; exact JOSE field names are not a ViewFS contract |
| `REF-WEBCRYPTO-LEVEL2` | standards / vendor-facing web spec | moving-head | `2026-03-28` | `2026-04-28` | opaque-key-reference / wrapKey-unwrapKey precedent only; exact browser API details are not a ViewFS contract |
| `REF-GCLOUD-KMS-ENVELOPE` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | envelope-encryption / wrapped-DEK precedent only; exact Google helper APIs are not a ViewFS contract |
| `REF-GCLOUD-KMS-REENCRYPT` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | re-encrypt-after-rotation precedent only; exact Google workflow steps are not a ViewFS contract |
| `REF-GCLOUD-KMS-KEYSTATES` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | key-version witness / primary-versus-decryptable precedent only; exact Cloud KMS state names are not a ViewFS contract |


| `REF-CEPH-ARCHITECTURE` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | logical-object-versus-placement precedent only; do not overfit Ceph PG or CRUSH details into a final ViewFS layout model |
| `REF-CEPH-SCRUB` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | scrub/deep-scrub wording may evolve; repair-verdict precedent only |
| `REF-TAHOE-CONFIG` | readthedocs | moving-head | `2026-03-28` | `2026-05-15` | k-of-n threshold wording may evolve; survivability-target precedent only |
| `REF-TAHOE-OUTLINE` | readthedocs | moving-head | `2026-03-28` | `2026-05-15` | share-placement/access-control separation precedent only; do not overfit Tahoe share-exchange details |
| `REF-AWS-S3-REPLICATION` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | asynchronous copy-spread precedent only; exact S3 replication modes are not a ViewFS contract |
| `REF-AWS-S3-REPLICATION-STATUS` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | status-value wording may evolve; repair/availability-state precedent only |

| `REF-S3-RESTORING-OBJECTS` | web docs | moving-head | `2026-03-28` | `2026-04-28` | archived-object restore / expiry semantics are useful inspiration; do not overfit exact AWS storage-class names or console wording |
| `REF-S3-RESTOREOBJECT` | API docs | moving-head | `2026-03-28` | `2026-04-28` | restore-job / temporary-copy semantics are useful; do not overfit exact request XML or tier names |
| `REF-S3-RESTORESTATUS` | API docs | moving-head | `2026-03-28` | `2026-04-28` | restore-status metadata is a good status-vs-object-identity precedent |
| `REF-AZURE-ARCHIVE-REHYDRATE` | web docs | moving-head | `2026-03-28` | `2026-04-28` | archive rehydration copy-vs-tier-change split is useful inspiration; do not overfit exact service-version or billing details |
| `REF-AZURE-ARCHIVE-BLOB` | web docs | moving-head | `2026-03-28` | `2026-04-28` | offline archive-tier posture is useful inspiration; do not overfit exact Azure tier taxonomy |

| `REF-AWS-S3-MRAP-ROUTING` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | nearest-route versus object-presence warning only; do not overfit S3 global-endpoint or bucket-routing details into the final ViewFS route model |
| `REF-GCS-BUCKET-LOCATIONS` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | dual-region residency precedent only; do not overfit Google location-code taxonomy |
| `REF-GCS-BUCKET-RPO` | vendor docs / API docs | moving-head | `2026-03-28` | `2026-04-28` | replication-policy/RPO precedent only; exact bucket JSON fields are not a ViewFS contract |
| `REF-AZURE-STORAGE-REDUNDANCY` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | secondary-read versus asynchronous-geo-replication precedent only; exact Azure redundancy names are not a ViewFS contract |
| `REF-CEPH-CRUSHMAP` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | topology-plus-placement-rule precedent only; exact CRUSH rule syntax is not a ViewFS contract |

| `REF-AWS-S3-CONSISTENCY` | web docs | moving-head | `2026-03-28` | `2026-04-25` | strong origin read-after-write/list consistency precedent only; do not overgeneralize to cache or permission propagation |
| `REF-GCS-CONSISTENCY` | web docs | moving-head | `2026-03-28` | `2026-04-25` | strong object/list truth plus eventual access/cache caveats are load-bearing for propagation/cache seam |
| `REF-RFC9111-CACHING` | RFC / standards text | stable | `2026-03-28` | `2026-06-01` | caching layer separation is inspiration for trail/cache-honesty only |
| `REF-RFC9211-CACHE-STATUS` | RFC / standards text | stable | `2026-03-28` | `2026-06-01` | cache-trail inspection precedent only; do not overgeneralize to a full ViewFS observability ABI |

| `REF-AWS-S3-PREFIXES` | vendor docs | moving-head | `2026-05-13` | `2026-06-15` | prefix-organizing precedent only; do not overfit S3 folder UI or delimiter conventions into final ViewFS folder model |
| `REF-AWS-S3-OBJECT-KEYS` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | flat bucket/object naming precedent only; exact S3 key-limit or console wording is not a ViewFS contract |
| `REF-GCS-OBJECTS` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | flat-namespace/no-folders precedent only; exact Cloud Storage product wording may evolve |
| `REF-GCS-MANAGED-FOLDERS` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | managed-folder-as-resource precedent only; exact IAM/resource wording is not a ViewFS contract |
| `REF-GCS-OBJECTS-LIST` | vendor docs / API docs | moving-head | `2026-03-28` | `2026-04-28` | list-result prefix projection precedent only; exact JSON field shapes are not a ViewFS contract |
| `REF-AZURE-BLOB-LIST` | vendor docs | moving-head | `2026-03-28` | `2026-04-28` | virtual-directory-via-delimiter precedent only; exact SDK helper names are not a ViewFS contract |
| `REF-AZURE-BLOB-NAMING` | vendor docs / REST docs | moving-head | `2026-03-28` | `2026-04-28` | hierarchical-namespace actual-directory precedent only; exact Azure naming limits or REST fields are not a ViewFS contract |

| `REF-CAPNP-RPC` | web docs | moving-head | `2026-05-13` | `2026-06-15` | capability-reference/table precedent only; exact CapTP/Cap'n Proto message mechanics are not a ViewFS schema |
| `REF-CAPNWEB` | vendor blog / project docs | moving-head | `2026-05-13` | `2026-06-15` | current web-native ocap RPC idea only; do not make browser/Javascript transport details a ViewFS requirement |
| `REF-XDG-PERMISSION-STORE` | web docs | moving-head | `2026-05-13` | `2026-06-15` | permission-store resource/app/string-array shape is inspiration only; do not freeze a portal DB schema |

| `REF-OPENBSD-UNVEIL` | man page | moving-head | `2026-05-13` | `2026-06-15` | host filesystem visibility hardening precedent only; do not make OpenBSD path/perms vocabulary a ViewFS contract |
| `REF-LINUX-LANDLOCK` | kernel docs | moving-head | `2026-05-13` | `2026-06-15` | self-confinement/ambient-right reduction precedent only; exact rule/action taxonomy may evolve |
| `REF-SLOPOS-CAPSTORE` | included archive | semi-stable | `2026-05-13` | `2026-06-15` | sibling-cube durable-root pressure only; do not treat CH-CAPSTORE as final ViewFS schema |
| `REF-EROS-FASTCAP` | paper/PDF | stable | `2026-05-13` | `2026-08-01` | persistent capability system precedent; do not imply transparent persistence is a ViewFS commitment |
| `REF-CAPROS` | project docs | semi-stable | `2026-05-13` | `2026-08-01` | orthogonal persistence precedent; details are historical inspiration only |
| `REF-AWS-S3-CONDITIONAL-WRITES` | vendor docs | moving-head | `2026-05-13` | `2026-06-15` | conditional-write currentness precedent only; exact header support may evolve |
| `REF-GCS-PRECONDITIONS` | vendor docs | moving-head | `2026-05-13` | `2026-06-15` | generation/metageneration currentness precedent only; exact API details may evolve |
| `REF-AZURE-BLOB-CONCURRENCY` | vendor docs | moving-head | `2026-05-13` | `2026-06-15` | ETag/lease currentness precedent only; exact service behavior may evolve |
| `REF-ETCD-TXN` | project docs | moving-head | `2026-05-13` | `2026-06-15` | compare-before-mutate precedent only; exact API version may evolve |
| `REF-QUBES-QREXEC` | project docs | moving-head | `2026-05-13` | `2026-06-15` | policy-mediated cross-domain flow precedent only; do not overfit Qubes service model |
| `REF-QUBES-FILECOPY` | project docs | moving-head | `2026-05-13` | `2026-06-15` | user-visible file transfer precedent only; do not overfit qube UI details |

| `REF-GIT-GC` | project docs | moving-head | `2026-05-13` | `2026-06-15` | unreachable-object/reflog/grace-period precedent only; exact defaults may evolve |
| `REF-IPFS-PINNING` | project docs | moving-head | `2026-05-13` | `2026-06-15` | pin/cache/MFS retention vocabulary inspiration only; do not import IPFS network assumptions |
| `REF-CONTAINERD-GC-LEASES` | project docs | moving-head | `2026-05-13` | `2026-06-15` | operation-scoped resource lease precedent only; do not import container runtime metadata schema |
| `REF-K8S-FINALIZERS` | project docs | moving-head | `2026-05-13` | `2026-06-15` | deletion-finalizer choreography precedent only; do not import Kubernetes object API |
| `REF-K8S-GC` | project docs | moving-head | `2026-05-13` | `2026-06-15` | owner/dependent/cascading cleanup precedent only; do not import controller model wholesale |
| `REF-ZFS-HOLD` | project docs | moving-head | `2026-05-13` | `2026-06-15` | named no-destroy hold precedent only; do not import ZFS snapshot semantics wholesale |

| `REF-SPDX-SBOM` | SPDX 3.0.1 SBOM class | moving | 2026-05-15 | 2026-06-15 | Re-check before freezing any SBOM claim-set vocabulary. |
| `REF-CYCLONEDX-OVERVIEW` | CycloneDX specification overview | moving | 2026-05-15 | 2026-06-15 | Re-check before adopting component/service/dependency/vulnerability vocabulary. |
| `REF-CYCLONEDX-COMPOSITIONS` | CycloneDX component compositions use case | moving | 2026-05-15 | 2026-06-15 | Re-check completeness state names before shell UX uses them. |
| `REF-OPENVEX-SPEC` | OpenVEX specification | moving | 2026-05-15 | 2026-06-15 | Re-check VEX status/justification rules before any suppression/admission policy. |
| `REF-PURL-ECMA427` | ECMA-427 Package-URL specification | moving | 2026-05-15 | 2026-06-15 | Re-check purl syntax/type guidance before any locator matcher. |
| `REF-OSV-SCHEMA` | OSV vulnerability schema | moving | 2026-05-15 | 2026-06-15 | Re-check alias/upstream/range semantics before vulnerability matching. |
| `REF-SLOPOS-SBOM-VEX-SEAMS` | Included SlopOS rev0695 supply-chain posture docs | vendored snapshot | 2026-05-15 | 2026-06-15 | Re-check if a newer SlopOS archive is imported. |

## Revision 145 source heads

- REF-SYSTEMD-CREDENTIALS — https://systemd.io/CREDENTIALS/ — checked 2026-05-15.
- REF-K8S-SECRETS — https://kubernetes.io/docs/concepts/configuration/secret/ — checked 2026-05-15.
- REF-K8S-PROJECTED-VOLUMES — https://kubernetes.io/docs/concepts/storage/projected-volumes/ — checked 2026-05-15.
- REF-DOCKER-SECRETS — https://docs.docker.com/engine/swarm/secrets/ — checked 2026-05-15.
- REF-SECRET-SERVICE-SPEC — https://specifications.freedesktop.org/secret-service/latest-single/ — checked 2026-05-15.
- REF-LINUX-PROC-ENVIRON — https://man7.org/linux/man-pages/man5/proc_pid_environ.5.html — checked 2026-05-15.
- REF-GITHUB-ACTIONS-SECRETS — https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-secrets — checked 2026-05-15.
- REF-AWS-IAM-TEMPORARY-CREDENTIALS — https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp.html — checked 2026-05-15.
- REF-SLOPOS-APPSECRET-CAPSHELL-SECRETS — included SlopOS rev0695 archive — checked locally 2026-05-15.

## Revision 146 source heads

- REF-SEL4-MANUAL-LATEST — https://sel4.systems/Info/Docs/seL4-manual-latest.pdf — checked 2026-05-15.
- REF-MACAROONS-NDSS14 — https://research.google/pubs/macaroons-cookies-with-contextual-caveats-for-decentralized-authorization-in-the-cloud/ — checked 2026-05-15.
- REF-UCAN-SPEC — https://ucan.xyz/specification/ — checked 2026-05-15.
- REF-UCAN-REVOCATION — https://github.com/ucan-wg/revocation — checked 2026-05-15.
- REF-RFC7009-REVOKE — https://datatracker.ietf.org/doc/html/rfc7009 — checked 2026-05-15.
- REF-AWS-IAM-TEMPORARY-CREDENTIALS — https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_temp.html — checked 2026-05-15.
- REF-W3C-CAPURL — https://www.w3.org/TR/capability-urls/ — checked 2026-05-15.
- REF-TAHOE-CAPS — https://tahoe-lafs.org/trac/tahoe-lafs/wiki/Capabilities — checked 2026-05-15.
- REF-CAPTP-DRAFT — https://github.com/ocapn/ocapn/blob/main/draft-specifications/CapTP%20Specification.md — checked 2026-05-15.
- REF-CLOUDFLARE-WORKERS-RPC — https://developers.cloudflare.com/workers/runtime-apis/rpc/visibility/ — checked 2026-05-15.
- REF-SLOPOS-DLEASE-REVOCATION — included SlopOS rev0695 archive — checked locally 2026-05-15.

## Revision 147 source heads

- REF-LINUX-PTRACE — https://man7.org/linux/man-pages/man2/ptrace.2.html — checked 2026-05-15.
- REF-LINUX-PROC-HIDEPID — https://man7.org/linux/man-pages/man5/proc.5.html — checked 2026-05-15.
- REF-LINUX-PROC-FD — https://man7.org/linux/man-pages/man5/proc_pid_fd.5.html — checked 2026-05-15.
- REF-LINUX-PR-SET-DUMPABLE — https://man7.org/linux/man-pages/man2/pr_set_dumpable.2const.html — checked 2026-05-15.
- REF-LINUX-CORE-CFILTER — https://man7.org/linux/man-pages/man5/core.5.html — checked 2026-05-15.
- REF-FUCHSIA-INSPECT — https://fuchsia.dev/fuchsia-src/development/diagnostics/inspect — checked 2026-05-15.
- REF-FUCHSIA-DIAGNOSTICS — https://fuchsia.dev/fuchsia-src/concepts/components/diagnostics — checked 2026-05-15.
- REF-MS-ETW-ABOUT — https://learn.microsoft.com/en-us/windows/win32/etw/about-event-tracing — checked 2026-05-15.
- REF-DTRACE-PRIVILEGES — https://docs.oracle.com/cd/E53394_01/html/E53395/gkyeh.html — checked 2026-05-15.
- REF-DTRACE-DESTRUCTIVE — https://docs.oracle.com/cd/E19253-01/819-5488/gcfsm/index.html — checked 2026-05-15.
- REF-K8S-RBAC-SUBRESOURCES — https://kubernetes.io/docs/reference/access-authn-authz/rbac/ — checked 2026-05-15.
- REF-APPLE-PRIVACY-CONTROLS — https://support.apple.com/guide/mac-help/change-privacy-security-settings-on-mac-mchl211c911f/mac — checked 2026-05-15.
- REF-SLOPOS-INSPECT-OBS-TRACE — included SlopOS rev0695 archive — checked locally 2026-05-15.

| `REF-FLATPAK-NETWORK-SANDBOX` | web docs | moving-head | `2026-05-15` | `2026-06-30` | no-network baseline and broad network grant caution; do not import Flatpak permissions as ViewFS ABI |
| `REF-APPLE-APP-SANDBOX-NETWORK` | vendor docs | moving-head | `2026-05-15` | `2026-06-30` | connect/listen entitlement split only; exact macOS entitlement keys are not ViewFS contract |
| `REF-ANDROID-INTERNET-PERMISSION` | vendor docs | moving-head | `2026-05-15` | `2026-06-30` | static manifest permission contrast case only |
| `REF-ANDROID-LOCAL-NETWORK-PERMISSION` | vendor docs | moving-head | `2026-05-15` | `2026-06-30` | local-network runtime permission trend; re-check Android release/status before stronger claims |
| `REF-OPENBSD-PLEDGE-NET-DNS` | man page | moving-head | `2026-05-15` | `2026-06-30` | DNS versus inet promise precedent; exact pledge names are not ViewFS API |
| `REF-RFC8484-DOH` | RFC | moving-head | `2026-05-15` | `2026-06-30` | DoH as resolver-channel warning; do not freeze one DNS transport policy |
| `REF-RFC9460-SVCB-HTTPS` | RFC | moving-head | `2026-05-15` | `2026-06-30` | SVCB/HTTPS alternate endpoint inspiration only; do not import service-binding semantics yet |
| `REF-RFC8305-HAPPY-EYEBALLS` | RFC | moving-head | `2026-05-15` | `2026-06-30` | address racing/selection warning; not a ViewFS connection algorithm |
| `REF-WICG-PRIVATE-NETWORK-ACCESS` | web spec draft | moving-head | `2026-05-15` | `2026-06-30` | public-to-private browser boundary inspiration; spec status may evolve |
| `REF-CHROME-LOCAL-NETWORK-ACCESS` | vendor blog | moving-head | `2026-05-15` | `2026-06-30` | local-network prompt UX precedent; re-check rollout/status before product claims |
| `REF-SLOPOS-NETLEASE-SEAMS` | included archive | pinned-by-upload | `2026-05-15` | `2026-06-30` | sibling-cube D-NETLEASE boundary family; design pressure only, not final ViewFS schema |
## Revision 149 source heads

- REF-RFC6763-DNSSD — https://datatracker.ietf.org/doc/html/rfc6763 — checked 2026-05-15; stable RFC precedent, re-check only for errata if quoted tightly.
- REF-RFC6762-MDNS — https://datatracker.ietf.org/doc/html/rfc6762 — checked 2026-05-15; stable RFC precedent, re-check only for errata/local-link wording.
- REF-K8S-SERVICE — https://kubernetes.io/docs/concepts/services-networking/service/ — checked 2026-05-15; moving docs, re-check before adopting exact service/discovery wording.
- REF-K8S-ENDPOINTSLICE-READINESS — https://kubernetes.io/docs/concepts/services-networking/endpoint-slices/ — checked 2026-05-15; moving docs, re-check condition names/status before shell UX freezes.
- REF-ENVOY-XDS-PROTOCOL — https://www.envoyproxy.io/docs/envoy/latest/api-docs/xds_protocol — checked 2026-05-15; moving docs, re-check xDS TTL/warming/resource sequencing before stronger claims.
- REF-SYSTEMD-SD-LISTEN-FDS — https://man.archlinux.org/man/sd_listen_fds.3.en — checked 2026-05-15; moving packaged manpage, use as activation-handle precedent only.
- REF-SPIFFE-WORKLOAD-IDENTITY — https://spiffe.io/ — checked 2026-05-15; moving project docs, re-check before exact workload-identity wording.
- REF-SLOPOS-SERVICE-BINDING-SEAMS — included SlopOS rev0695 archive — checked locally 2026-05-15; re-check if newer SlopOS archive is imported.

## Revision 150 source heads

- REF-RFC9525-SERVICE-IDENTITY — https://www.rfc-editor.org/rfc/rfc9525.html — checked 2026-05-16; stable RFC, re-check errata before quoting exact service-identity rules.
- REF-RFC8446-TLS13 — https://datatracker.ietf.org/doc/html/rfc8446 — checked 2026-05-16; stable RFC, re-check errata before exact TLS 1.3 wording.
- REF-RFC8446-0RTT — https://datatracker.ietf.org/doc/html/rfc8446 — checked 2026-05-16; stable RFC, re-check errata before freezing replay/early-data UI names.
- REF-RFC9266-TLS13-CHANNEL-BINDING — https://www.rfc-editor.org/rfc/rfc9266.html — checked 2026-05-16; stable RFC, re-check if channel-binding field names become protocol.
- REF-RFC6962-CT — https://datatracker.ietf.org/doc/html/rfc6962 — checked 2026-05-16; stable but CT ecosystem policies move, re-check before product claims.
- REF-OPENSSH-STRICTHOSTKEYCHECKING — https://man.openbsd.org/ssh_config — checked 2026-05-16; moving manpage, use as host-key posture precedent only.
- REF-SPIFFE-X509-SVID — https://spiffe.io/docs/latest/spiffe-specs/x509-svid/ — checked 2026-05-16; moving project docs, re-check before exact SVID validation claims.
- REF-RFC7671-DANE — https://datatracker.ietf.org/doc/html/rfc7671 — checked 2026-05-16; stable RFC, re-check errata before DANE usage wording hardens.
- REF-SLOPOS-SECURE-TRANSPORT-SEAMS — included SlopOS rev0695 archive — checked locally 2026-05-16; re-check if newer SlopOS archive is imported.



## Revision 151 source heads

- REF-VENTI-CAS — https://www.cs.princeton.edu/courses/archive/spr05/cos598E/bib/venti-fast.pdf — checked 2026-05-16.
- REF-FOUNDATION-CAS — https://swtch.com/~rsc/papers/fndn/ — checked 2026-05-16.
- REF-IPFS-CIDS — https://docs.ipfs.tech/concepts/content-addressing/ — checked 2026-05-16.
- REF-NIX-CONTENT-ADDRESS — https://nix.dev/manual/nix/2.26/store/store-object/content-address — checked 2026-05-16.
- REF-TAHOE-CONVERGENCE-SECRET — https://tahoe-lafs.readthedocs.io/en/latest/convergence-secret.html — checked 2026-05-16.
- REF-SECURE-DATA-DEDUPLICATION — https://escholarship.org/uc/item/9qn752v6 — checked 2026-05-16.
- REF-PROOFS-OF-OWNERSHIP — https://eprint.iacr.org/2011/207 — checked 2026-05-16.
- REF-DUPLESS-USENIX13 — https://www.usenix.org/conference/usenixsecurity13/technical-sessions/presentation/bellare — checked 2026-05-16.
- REF-ZFS-DEDUP-TRUENAS — https://www.truenas.com/docs/references/zfsdeduplication/ — checked 2026-05-16.
- REF-ZFS-DEDUP-ORACLE — https://docs.oracle.com/cd/E36784_01/html/E39134/fsdedup-1.html — checked 2026-05-16.
- REF-LINUX-KSM — https://docs.kernel.org/admin-guide/mm/ksm.html — checked 2026-05-16.
- REF-KSM-THREAT-GUESTOS — https://people.kth.se/~artho/papers/EuroSec2011-suzaki.pdf — checked 2026-05-16.
- REF-SLOPOS-DEDUP-EQUALITY-SEAMS — included SlopOS rev0695 archive — checked locally 2026-05-16.


## Revision 152 source heads

- REF-APPLE-SPOTLIGHT-PRIVACY — https://support.apple.com/guide/mac-help/prevent-spotlight-searches-specific-folders-mchl1bb43b84/mac — checked 2026-05-18; moving vendor docs, re-check before exact UI wording.
- REF-GNOME-LOCALSEARCH — https://gnome.pages.gitlab.gnome.org/localsearch/overview.html — checked 2026-05-18; moving project docs, re-check before exact daemon/API claims.
- REF-PINECONE-MULTITENANCY — https://docs.pinecone.io/guides/index-data/implement-multitenancy — checked 2026-05-18; moving vendor docs, use namespace isolation as precedent only.
- REF-WEAVIATE-MULTITENANCY — https://docs.weaviate.io/weaviate/manage-collections/multi-tenancy — checked 2026-05-18; moving vendor docs, use shard-per-tenant wording cautiously.
- REF-ACL-TEXT-EMBEDDINGS-REVEAL — https://aclanthology.org/2023.emnlp-main.765/ — checked 2026-05-18; stable paper page, use as embedding privacy risk evidence.
- REF-OWASP-LLM08-VECTOR-EMBEDDING — https://genai.owasp.org/llmrisk/llm082025-vector-and-embedding-weaknesses/ — checked 2026-05-18; moving OWASP guidance, re-check taxonomy/wording before stronger claims.
- REF-SLOPOS-SEMANTIC-DERIVATION-SEAMS — included SlopOS rev0695 archive — checked locally 2026-05-18; re-check if newer SlopOS archive is imported.
## Revision 153 source heads

- REF-OWASP-LLM01-PROMPT-INJECTION — https://genai.owasp.org/llmrisk/llm01-prompt-injection/ — checked 2026-05-18; moving OWASP guidance, re-check before stronger prompt-injection taxonomy claims.
- REF-OPENAI-PROMPT-INJECTIONS — https://openai.com/index/prompt-injections/ — checked 2026-05-18; moving provider guidance, use as current product/research framing.
- REF-MS-INDIRECT-PROMPT-INJECTION — https://learn.microsoft.com/en-us/security/zero-trust/sfi/defend-indirect-prompt-injection — checked 2026-05-18; moving vendor guidance, re-check containment wording before policy claims harden.
- REF-GOOGLE-WORKSPACE-IPI — https://blog.google/security/google-workspaces-continuous-approach-to-mitigating-indirect-prompt-injections/ — checked 2026-05-18; vendor blog, re-check product-defense wording before stronger claims.
- REF-MCP-SPEC-SECURITY-2025-06 — https://modelcontextprotocol.io/specification/2025-06-18 — checked 2026-05-18; spec page, re-check if MCP version advances before ABI sketches.
- REF-MCP-TOOLS-SECURITY-2025-06 — https://modelcontextprotocol.io/specification/2025-06-18/server/tools — checked 2026-05-18; spec page, re-check annotations/consent wording before toolcall-fuse schemas harden.
- REF-MCP-PROMPTS-2025-06 — https://modelcontextprotocol.io/specification/2025-06-18/server/prompts — checked 2026-05-18; spec page, re-check prompt semantics before catalog import claims harden.
- REF-MCP-RESOURCES-2025-06 — https://modelcontextprotocol.io/specification/2025-06-18/server/resources — checked 2026-05-18; spec page, re-check resource URI/access-control wording before resource import claims harden.
- REF-VSCODE-COPILOT-INSTRUCTIONS — https://code.visualstudio.com/docs/copilot/customization/custom-instructions — checked 2026-05-18; moving docs, re-check instruction priority/file discovery before UI claims harden.
- REF-VSCODE-AI-CUSTOMIZATION — https://code.visualstudio.com/docs/copilot/customization/overview — checked 2026-05-18; moving docs, re-check parent-repo discovery and customization categories before scope/trust claims harden.
- REF-INSTRUCTION-HIERARCHY-2404 — https://arxiv.org/abs/2404.13208 — checked 2026-05-18; stable paper page, use as model-side technique only.
- REF-SLOPOS-LLM-INSTRUCTION-SEAMS — included SlopOS rev0695 archive — checked locally 2026-05-18; re-check if a newer SlopOS archive is imported.

## Revision 154 source heads

- REF-EROS-EWS-VOLITION — https://www.usenix.org/conference/13th-usenix-security-symposium/design-eros-trusted-window-system — checked 2026-05-18; stable paper page, byte-lock PDF if exact wording becomes decision-load-bearing.
- REF-WHATWG-HTML-USER-ACTIVATION — https://html.spec.whatwg.org/multipage/interaction.html#tracking-user-activation — checked 2026-05-18; living standard, re-check before freezing exact activation categories.
- REF-WAYLAND-XDG-ACTIVATION — https://wayland.app/protocols/xdg-activation-v1 — checked 2026-05-18; generated from staging protocol, re-check protocol status before using exact fields.
- REF-MS-SAS-TRUSTED-PATH — https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/security-policy-settings/interactive-logon-do-not-require-ctrl-alt-del — checked 2026-05-18; vendor docs, use as trusted-path precedent only.
- REF-W3C-WEBAUTHN-UP-UV — https://www.w3.org/TR/webauthn-2/ — checked 2026-05-18; W3C Recommendation, re-check latest level if exact flags/ceremony language hardens.
- REF-FIDO-CTAP-PRESENCE — https://fidoalliance.org/specs/fido-v2.1-ps-20210615/fido-client-to-authenticator-protocol-v2.1-ps-20210615.html — checked 2026-05-18; FIDO spec versioned, re-check newer CTAP versions before protocol work.
- REF-OWASP-CLICKJACKING-CHEATSHEET — https://cheatsheetseries.owasp.org/cheatsheets/Clickjacking_Defense_Cheat_Sheet.html — checked 2026-05-18; moving cheat sheet, re-check before naming product controls.
- REF-SLOPOS-VOLITION-CONSENT-SEAMS — included SlopOS rev0695 archive — checked locally 2026-05-18; re-check if newer SlopOS/datacube archive is imported.

## Revision 156 source heads

- REF-LINUX-LANDLOCK-USER — https://docs.kernel.org/userspace-api/landlock.html — checked 2026-05-21; moving kernel docs, use for ambient-right restriction posture and denial vocabulary only.
- REF-LINUX-LANDLOCK-AUDIT — https://docs.kernel.org/admin-guide/LSM/landlock.html — checked 2026-05-21; moving kernel docs, use as denial-record/audit precedent only.
- REF-WASI-PREVIEW2 — https://github.com/WebAssembly/WASI — checked 2026-05-21; moving project repository, re-check before exact Preview 2 status claims.
- REF-WASI-CAPABILITY-PREOPENS — https://wasi.dev/ — checked 2026-05-21; moving project docs, use for capability-oriented host-interface posture only.
- REF-APPLE-SECURITY-SCOPED-BOOKMARKS — https://developer.apple.com/documentation/security/accessing-files-from-the-macos-app-sandbox — checked 2026-05-21; moving vendor docs, re-check before exact entitlement/bookmark wording.
- REF-MS-CVE-2025-31191-BOOKMARKS — https://www.microsoft.com/en-us/security/blog/2025/05/01/analyzing-cve-2025-31191-a-macos-security-scoped-bookmarks-based-sandbox-escape/ — checked 2026-05-21; vendor security blog, use as lifecycle-risk pressure for persistent access tokens.
- REF-MCP-SECURITY-BEST-PRACTICES — https://modelcontextprotocol.io/docs/tutorials/security/security_best_practices — checked 2026-05-21; moving official docs, re-check before MCP security taxonomy hardens.
- REF-OWASP-LLM06-EXCESSIVE-AGENCY — https://genai.owasp.org/llmrisk/llm06-sensitive-information-disclosure/ — checked 2026-05-21; moving OWASP guidance, page slug may lag title; use for excessive-agency posture only.
- REF-OASIS-KMIP-LIFECYCLE — https://docs.oasis-open.org/kmip/kmip-spec/v2.1/cs01/kmip-spec-v2.1-cs01.html — checked 2026-05-21; stable-ish standard page, use as lifecycle analogy only, not ViewFS cryptographic semantics.

## Revision 157 source heads

- REF-LINUX-OPENAT2-RESOLVE — https://man7.org/linux/man-pages/man2/openat2.2.html — checked 2026-05-21; use as path-resolution flag vocabulary, not ViewFS ABI.
- REF-WASI-FILESYSTEM-DESCRIPTORS — https://wa.dev/wasi%3Afilesystem — checked 2026-05-21; moving WASI component docs, re-check before exact descriptor/path wording hardens.
- REF-WICG-FILE-SYSTEM-ACCESS — https://wicg.github.io/file-system-access/ — checked 2026-05-21; incubator draft, re-check before claims about status or persistent grants.
- REF-MDN-FILE-SYSTEM-HANDLES — https://developer.mozilla.org/en-US/docs/Web/API/File_System_API — checked 2026-05-21; developer docs, re-check browser support/behavior before product claims.
- REF-SLSA-BUILD-PROVENANCE — https://slsa.dev/spec/draft/build-provenance — checked 2026-05-21; draft/current-version split visible, use as provenance analogy only.

## Revision 158 source heads

- REF-TUF-SPEC-FREEZE-ROLLBACK — https://theupdateframework.github.io/specification/latest/ — checked 2026-05-21; moving specification, re-check before freezing exact metadata-role semantics.
- REF-SLSA-BUILD-PROVENANCE-REV158 — https://slsa.dev/spec/draft/build-provenance — checked 2026-05-21; draft provenance page, use as evidence-separation pressure only.
- REF-SIGSTORE-REKOR-REV158 — https://docs.sigstore.dev/logging/overview/ — checked 2026-05-21; moving project docs, re-check before productizing transparency-verification claims.
- REF-OCI-IMAGE-DISTRIBUTION-1-1 — https://opencontainers.org/posts/blog/2024-03-13-image-and-distribution-1-1/ — checked 2026-05-21; release note, use alongside current OCI specs before implementing registry behavior.
- REF-WASI-FILESYSTEM-DESCRIPTORS-REV158 — https://wa.dev/wasi%3Afilesystem — checked 2026-05-21; moving WASI component docs, re-check before ABI claims.
- REF-OPENTELEMETRY-OVERVIEW-REV158 — https://opentelemetry.io/ — checked 2026-05-21; project overview, use as generated-report/observability analogy only.

## Revision 162 source heads

- REF-K8S-RBAC-ROLEBINDING — https://kubernetes.io/docs/reference/access-authn-authz/rbac/ — checked 2026-05-22; moving docs, use as role/binding/namespace-scope pressure only.
- REF-MATRIX-ROOM-STATE-AUTH — https://spec.matrix.org/ — checked 2026-05-22; moving spec site, re-check exact room-version/state-resolution wording before protocol claims harden.
- REF-WEBDAV-ACL-RFC3744 — https://datatracker.ietf.org/doc/html/rfc3744 — checked 2026-05-22; stable RFC, use as ACL/principal vocabulary pressure only.
- REF-LINUX-SHARED-SUBTREE — https://www.kernel.org/doc/Documentation/filesystems/sharedsubtree.txt — checked 2026-05-22; kernel documentation, use as mount-propagation precedent, not ViewFS ABI.
