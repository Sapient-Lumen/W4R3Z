# Research synthesis 2026-05-22 pass CLZ — policy, witness, replay, override

Revision 159 focuses on policy and witness laundering.

Open Policy Agent pressure: policy engines decouple decision-making from application enforcement. That split is useful for ViewFS, but it is exactly why the policy verdict must not become a handle. OPA decision logs also point toward keeping query input, policy, bundle metadata, decision id, and audit/debug rows visible but non-authoritative.

Cedar pressure: authorization requests are framed around principal, action, resource, context, and entity data. ViewFS should preserve that request shape in policy decisions while still requiring live authority carriers at the object boundary.

in-toto / SLSA pressure: provenance and attestations bind subjects, materials/inputs, builder/executor, and predicates. ViewFS witness bundles borrow the shape but not the authority semantics: a witness explains the decision basis; it does not replay the effect.

OpenTelemetry pressure: traces and spans are useful because operations and attributes are made explicit. ViewFS policy trace reporting borrows this review posture by generating a report from fixture rows rather than relying on hand-written prose.

Ward pressure: breakglass must be a stewardship warrant with scope, expiry, audit, and verification. It must not be a hidden admin bit or a helper-provided emergency label.

Design consequence: revision 159 adds policy bundles, decisions, witness bundles, replay scenarios, override warrants, four proof obligations, fourteen fixtures, and a generated policy trace report. The anti-collapse rule is simple: policy, witness, replay, and breakglass artifacts can explain and constrain effects, but only current live authority carriers perform effects.
