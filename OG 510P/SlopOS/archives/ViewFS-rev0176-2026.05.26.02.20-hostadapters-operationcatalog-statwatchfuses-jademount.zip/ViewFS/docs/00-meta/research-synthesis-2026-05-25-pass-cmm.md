# Research synthesis pass CMM — governance, rollout, feature gates, migration, and catalog hygiene

Revision 172 focuses on governance/change-management laundering and fixture-catalog drift.

## Pressure imported

- Change records and ADRs are evidence, not execution.
- Quorums and approvals explain why a change may be eligible, but they do not replace live effect authority.
- Progressive delivery and feature flags are powerful because they scope exposure; they are dangerous if flag membership is mistaken for capability authority.
- Deprecation and compatibility promises need exact version/scope binding; broad “supported” labels are too easy to overread.
- Migration runs require prechecks, current bases/schemas, rollback plans, and live write/migration authority.
- A large executable corpus needs its own catalog discipline; fixture identity drift can hide proof drift.

## ViewFS consequence

Governance artifacts now have their own checked lane. The lane intentionally does not decide organizational policy. It only prevents these artifacts from becoming hidden execution, migration, rollout, disclosure, or compatibility authority.
