# Research synthesis — 2026-05-22 pass CMC

Revision 162 pressure came from systems where collaboration, namespace composition, and access-control metadata are first-class but still easy to over-trust.

- Kubernetes RBAC distinguishes role/cluster-role definitions from bindings to subjects and namespaces. The ViewFS lesson is that a group or binding row participates in eligibility, but an object effect still needs exact scope and live authority.
- Matrix room specifications pressure ViewFS to treat room state, authorization, redaction, and event history as separate from client presentation. The ViewFS lesson is that a room timeline or room membership is not object authority.
- WebDAV ACL (RFC 3744) distinguishes principals, privileges, access-control entries, and resources. The ViewFS lesson is to keep principal/group facts and object handles separate even when ACL-like checks are added.
- Linux shared-subtree mount propagation pressure ViewFS to represent propagation as an explicit event class rather than a hidden side effect of a mount label. The ViewFS lesson is that projected mounts need propagation gates.
- Ward pressure remains central: delegation handoffs must carry target acceptance and accountability, not just source intent.
- Foundry pressure remains central: collaboration nouns need specimens and failure specimens before they become trusted vocabulary.

The concrete result is `SharedRoom`, `MountEdge`, `GroupMembership`, `LabelOverlay`, `HandoffPacket`, and `CollaborationCard` in the fixture checker, plus a generated collaboration trace report.
