# Research synthesis pass CMN: workflow automation custody

This pass uses external workflow/eventing practice as pressure, not as a design import.

- CloudEvents separates event context attributes from event data and standardizes event metadata. ViewFS borrows the envelope/metadata split but refuses to treat an event as authority.
- Temporal distinguishes durable workflow execution and message types such as signals, queries, and updates. ViewFS borrows the need for durable run state while requiring live authority at every ViewFS object effect.
- OpenFeature separates evaluation context and flag evaluation from the control plane. ViewFS borrows scoped evaluation/context posture but treats flag/trigger results as non-authority.
- HTTP idempotency-key practice highlights duplicate suppression for non-idempotent requests. ViewFS treats idempotency keys as replay guards, not effect replay authority.
- ActivityPub's inbox/outbox and permission-filtered streams are a reminder that delivery streams are not identical to access rights.

Speculative conclusion: ViewFS should not choose a workflow engine yet. It should keep the automation seam as a small executable custody model until SlopOS request/portal semantics and ViewFS handle semantics have a shared run-state protocol.
