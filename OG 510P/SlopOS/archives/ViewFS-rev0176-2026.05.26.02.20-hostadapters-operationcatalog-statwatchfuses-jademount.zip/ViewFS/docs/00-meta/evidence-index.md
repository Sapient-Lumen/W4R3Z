# Evidence index

| EVID-ID | Class | Summary | Artifact | Notes |
|---|---|---|---|---|
| EVID-2026-001 | E0 | First ViewFS datacube archive revision with foundation docs, architecture postures, inspiration map, and RFC seed. | `ViewFS-rev0001-2026.03.21.18.23-foundation-hygiene-openquestions-seedling.zip` | Archive seed |
| EVID-2026-002 | E0 | Generated context pack for Revision 001. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-003 | E0 | Second ViewFS datacube archive revision adding SlopOS seam alignment, decision-freeze RFC, expanded inspiration map, shell/terminal ideas, and release manifest hygiene. | `ViewFS-rev0002-2026.03.21.22.35-lessons-shell-portals-lighthouse.zip` | Research + hygiene revision |
| EVID-2026-004 | E0 | Generated context pack for Revision 002. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-005 | E0 | Third ViewFS datacube archive revision adding mutable-work-state, grant-lifecycle, capability-bundle, and shell/domain research notes. | `ViewFS-rev0003-2026.03.21.22.50-research-grants-shell-wayfinder.zip` | Research deepening revision |
| EVID-2026-006 | E0 | Generated context pack for Revision 003. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-007 | E0 | Fourth ViewFS datacube archive revision adding design-split guardrails, revocation/durable-grant design space, shell protocol sketch, and anti-coupling RFC. | `ViewFS-rev0004-2026.03.21.23.10-splits-revocation-protocol-keystone.zip` | Research + guardrail revision |
| EVID-2026-008 | E0 | Generated context pack for Revision 004. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-009 | E0 | Fifth ViewFS datacube archive revision adding host-bridge/backstop posture, grant-class/receipt-state notes, stronger OpenURI seam alignment, and higher-ambition shell ideas. | `ViewFS-rev0005-2026.03.21.23.45-backstops-routes-delight-starbridge.zip` | Research + design-phase hygiene revision |
| EVID-2026-010 | E0 | Generated context pack for Revision 005. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-011 | E0 | Sixth ViewFS datacube archive revision adding workspace/tree grant separation, truthful shell completion/routing notes, and a new anti-collapse RFC. | `ViewFS-rev0006-2026.03.21.23.59-workspaces-routing-truth-orbit.zip` | Research + seam-discipline revision |
| EVID-2026-012 | E0 | Generated context pack for Revision 006. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-013 | E0 | Seventh ViewFS datacube archive revision adding identity/recent/reveal separation and semantic terminal marks/links/overlay notes. | `ViewFS-rev0007-2026.03.21.23.59-identity-marks-reopen-pulse.zip` | Research + identity/UX seam revision |
| EVID-2026-014 | E0 | Generated context pack for Revision 007. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-015 | E0 | Eighth ViewFS datacube archive revision adding handle/ref/receipt separation and authority HUD / receipt-card shell ideas. | `ViewFS-rev0008-2026.03.21.23.44-handles-receipts-hud-lantern.zip` | Research + interaction seam revision |
| EVID-2026-016 | E0 | Generated context pack for Revision 008. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-017 | E0 | Ninth ViewFS datacube archive revision adding session-state versus authority guardrails and journals/notebooks/safe-replay shell ideas. | `ViewFS-rev0009-2026.03.21.23.58-sessionstate-replay-journals-kintsugi.zip` | Research + session-memory seam revision |
| EVID-2026-018 | E0 | Generated context pack for Revision 009. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-019 | E0 | Tenth ViewFS datacube archive revision adding advisory-registry guardrails for indexes/recents/selectors and palette provenance-lens shell ideas. | `ViewFS-rev0010-2026.03.21.23.59-indexes-palettes-advisory-lodestar.zip` | Research + advisory-registry seam revision |
| EVID-2026-020 | E0 | Generated context pack for Revision 010. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-021 | E0 | Eleventh ViewFS datacube archive revision adding workspace-access versus workspace-automation-trust guardrails and workspace-onboarding/trust-badge shell ideas. | `ViewFS-rev0011-2026.03.22.00.07-workspace-trust-shell-onboarding-meridian.zip` | Research + workspace-trust seam revision |
| EVID-2026-022 | E0 | Generated context pack for Revision 011. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-023 | E0 | Twelfth ViewFS datacube archive revision adding preview/extractor observation guardrails and inert peek/inspector shell ideas. | `ViewFS-rev0012-2026.03.22.00.28-previews-inspectors-observation-prism.zip` | Research + observation seam revision |
| EVID-2026-024 | E0 | Generated context pack for Revision 012. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-025 | E0 | Thirteenth ViewFS datacube archive revision adding watch/feed/rebuild guardrails and watch-block / settle-badge shell ideas. | `ViewFS-rev0013-2026.03.21.20.25-watchfeeds-rescans-livepanes-magnetar.zip` | Research + watch-seam revision |
| EVID-2026-026 | E0 | Generated context pack for Revision 013. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-027 | E0 | Fourteenth ViewFS datacube archive revision adding link/alias/shortcut seam guardrails and link-lens / relink-flow shell ideas. | `ViewFS-rev0014-2026.03.21.20.31-links-aliases-relinks-waypoint.zip` | Research + link-seam revision |
| EVID-2026-028 | E0 | Generated context pack for Revision 014. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-029 | E0 | Fifteenth ViewFS datacube archive revision adding origin/quarantine/trust seam guardrails and origin-badge / safe-open-ladder shell ideas. | `ViewFS-rev0015-2026.03.21.20.45-origin-quarantine-safeopen-firebreak.zip` | Research + quarantine/trust seam revision |
| EVID-2026-030 | E0 | Generated context pack for Revision 015. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-031 | E0 | Sixteenth ViewFS datacube archive revision adding delete/trash/recovery/retention/purge guardrails and trash-tray / retention-lens / undo-timeline shell ideas. | `ViewFS-rev0016-2026.03.22.00.53-trash-retention-undo-afterglow.zip` | Research + recoverability seam revision |
| EVID-2026-032 | E0 | Generated context pack for Revision 016. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-033 | E0 | Seventeenth ViewFS datacube archive revision adding checkpoint/fork/backup/publication/activation seam guardrails and time-travel shell ideas. | `ViewFS-rev0017-2026.03.22.01.03-checkpoints-clones-publish-helix.zip` | Research + time-travel seam revision |
| EVID-2026-034 | E0 | Generated context pack for Revision 017. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-035 | E0 | Eighteenth ViewFS datacube archive revision adding precondition/lease/conflict seam guardrails and guarded-save / reservation / merge-lane shell ideas. | `ViewFS-rev0018-2026.03.22.01.22-leases-preconditions-conflicts-rivet.zip` | Research + concurrency-seam revision |
| EVID-2026-036 | E0 | Generated context pack for Revision 018. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-037 | E0 | Nineteenth ViewFS datacube archive revision adding query-manifest/result-snapshot/live-feed seam guardrails and smart-folder freeze/diff/match-lens shell ideas. | `ViewFS-rev0019-2026.03.21.21.24-smartfolders-snapshots-livefeeds-quartz.zip` | Research + query-seam revision |
| EVID-2026-038 | E0 | Generated context pack for Revision 019. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-039 | E0 | Twentieth ViewFS datacube archive revision adding import/export/transfer/share/promised-file seam guardrails and shipping-lane / promised-output shell ideas. | `ViewFS-rev0020-2026.03.22.01.44-importexport-transfer-promises-waybill.zip` | Research + cross-boundary-lane seam revision |
| EVID-2026-040 | E0 | Generated context pack for Revision 020. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-041 | E0 | Twenty-first ViewFS datacube archive revision adding prefetch/cache/hydration/pin/mirror/offline-bundle seam guardrails and offline-readiness / hydration-plan / pin-hygiene shell ideas. | `ViewFS-rev0021-2026.03.22.02.12-pins-prefetch-offline-signalfire.zip` | Research + warm-state/offline seam revision |
| EVID-2026-042 | E0 | Generated context pack for Revision 021. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-043 | E0 | Twenty-second ViewFS datacube archive revision adding bundle/view-fragment/launch-kit seam guardrails and launch-rehearsal / kit-card shell ideas. | `ViewFS-rev0022-2026.03.22.08.46-launchkits-fragments-rehearsal-keystone.zip` | Research + launch-assembly seam revision |
| EVID-2026-044 | E0 | Generated context pack for Revision 022. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-045 | E0 | Twenty-third ViewFS datacube archive revision adding request/candidate/selection/grant/bind seam guardrails and chooser-sheet / staging-tray / grant-ledger shell ideas. | `ViewFS-rev0023-2026.03.22.09.18-requests-selections-imports-switchboard.zip` | Research + mediated-import seam revision |
| EVID-2026-046 | E0 | Generated context pack for Revision 023. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-047 | E0 | Twenty-fourth ViewFS datacube archive revision adding intent/plan/approval/result seam guardrails and route-plan / approval-checkpoint / result-card shell ideas. | `ViewFS-rev0024-2026.03.22.09.26-routeplans-approvals-results-switchyard.zip` | Research + prepared-action seam revision |
| EVID-2026-048 | E0 | Generated context pack for Revision 024. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-049 | E0 | Twenty-fifth ViewFS datacube archive revision adding suggested-automation / promoted-workflow / run-history seam guardrails and suggestion-tray / promotion-lane shell ideas. | `ViewFS-rev0025-2026.03.22.09.45-promotions-recipes-runbooks-turnstile.zip` | Research + automation-ownership seam revision |
| EVID-2026-050 | E0 | Generated context pack for Revision 025. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-051 | E0 | Twenty-sixth ViewFS datacube archive revision adding lend/borrow/delegated-ref/recall/expiry seam guardrails and lend-once / borrow-badge / recall-rail shell ideas. | `ViewFS-rev0026-2026.03.22.09.52-loans-recalls-expiry-flightdeck.zip` | Research + borrowed-authority seam revision |
| EVID-2026-052 | E0 | Generated context pack for Revision 026. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-053 | E0 | Twenty-seventh ViewFS datacube archive revision adding reuse-candidate / basis-record / drift-check / reconsent / renewal seam guardrails and basis-diff / reconsent-ladder shell ideas. | `ViewFS-rev0027-2026.03.22.10.11-basisdiffs-reconsent-renewal-breakwater.zip` | Research + replay/renewal-basis seam revision |
| EVID-2026-054 | E0 | Generated context pack for Revision 027. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-055 | E0 | Twenty-eighth ViewFS datacube archive revision adding witness/caveat/freshness/why-record seam guardrails and witness-drawer / caveat-chip / why-panel shell ideas. | `ViewFS-rev0028-2026.03.22.10.20-witnesspacks-caveats-freshness-clarion.zip` | Research + explanation-material seam revision |
| EVID-2026-056 | E0 | Generated context pack for Revision 028. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-057 | E0 | Twenty-ninth ViewFS datacube archive revision adding validation/policy/advice/diagnostic/log seam guardrails and policy-lens / advice-rail / diagnostic-card shell ideas. | `ViewFS-rev0029-2026.03.22.10.37-policyplanes-advice-diagnostics-switchglass.zip` | Research + policy-aware-shell seam revision |
| EVID-2026-058 | E0 | Generated context pack for Revision 029. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-059 | E0 | Thirtieth ViewFS datacube archive revision adding policy-family/cut/fallback/repair seam guardrails and cut-picker / fallback-rail / repair-prompt shell ideas. | `ViewFS-rev0030-2026.03.22.10.55-policycuts-fallbacks-repair-gatehouse.zip` | Research + judge-selection seam revision |
| EVID-2026-060 | E0 | Generated context pack for Revision 030. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-061 | E0 | Thirty-first ViewFS datacube archive revision adding proposal-origin / scope / escalation / adoption seam guardrails and proposer-badge / escalation-ladder / adoption-gate shell ideas. | `ViewFS-rev0031-2026.03.22.11.18-proposers-lanes-escalations-signalpost.zip` | Research + proposal/adoption seam revision |
| EVID-2026-062 | E0 | Generated context pack for Revision 031. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-063 | E0 | Thirty-second ViewFS datacube archive revision adding deny-ceiling / scope-eligibility / narrowing-transform seam guardrails and ceiling-pill / scope-fuse shell ideas. | `ViewFS-rev0032-2026.03.22.11.42-ceilings-narrowing-scopefuses-bulwark.zip` | Research + scope-control seam revision |
| EVID-2026-064 | E0 | Generated context pack for Revision 032. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-065 | E0 | Thirty-third ViewFS datacube archive revision adding policy-source / trust-gate / precedence seam guardrails and origin-stack / trust-shutter / override-ledger shell ideas. | `ViewFS-rev0033-2026.03.22.12.08-policysources-trustgates-overrides-watchtower.zip` | Research + source-precedence seam revision |
| EVID-2026-066 | E0 | Generated context pack for Revision 033. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-067 | E0 | Thirty-fourth ViewFS datacube archive revision adding policy-author / carrier / advisory-only seam guardrails and author-badge / carrier-tag shell ideas. | `ViewFS-rev0034-2026.03.22.12.36-authors-carriers-advisory-sentinel.zip` | Research + source-admissibility seam revision |
| EVID-2026-068 | E0 | Generated context pack for Revision 034. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-069 | E0 | Thirty-fifth ViewFS datacube archive revision adding protected-authorability / invoke-only-lane seam guardrails and protected-chip / matrix-drawer / latched-invoke shell ideas. | `ViewFS-rev0035-2026.03.22.12.58-protectedscopes-authorability-latches-circuitbreaker.zip` | Research + protected-authorability seam revision |
| EVID-2026-070 | E0 | Generated context pack for Revision 035. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-071 | E0 | Thirty-sixth ViewFS datacube archive revision adding helper lifecycle seam guardrails for publisher trust / install-config / enable-start / live-session / request-selection classes and publisher-badge / start-gate / tool-rack shell ideas. | `ViewFS-rev0036-2026.03.22.13.44-publishertrust-startgates-toolracks-sentinelshell.zip` | Research + helper-lifecycle seam revision |
| EVID-2026-072 | E0 | Generated context pack for Revision 036. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-073 | E0 | Thirty-seventh ViewFS datacube archive revision adding helper feature-class seam guardrails for resources / prompts / tools / app surfaces / completion / request-binding / live-invocation classes and resource-shelf / prompt-chip / app-dock shell ideas. | `ViewFS-rev0037-2026.03.22.14.18-resources-prompts-tools-appdocks-wayfinder.zip` | Research + helper-feature seam revision |
| EVID-2026-074 | E0 | Generated context pack for Revision 037. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-075 | E0 | Thirty-eighth ViewFS datacube archive revision adding immediate-request / task-wrapper / progress / input-checkpoint / final-result seam guardrails and task-badge / progress-lane / result-locker shell ideas. | `ViewFS-rev0038-2026.03.22.14.52-requesttasks-progress-resultlockers-harbormaster.zip` | Research + deferred-work seam revision |
| EVID-2026-076 | E0 | Generated context pack for Revision 038. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-077 | E0 | Thirty-ninth ViewFS datacube archive revision adding close/cancel / terminate / detach-delete / retry-fork-reset seam guardrails and stop-ladder / detach-rail / rerun-fork shell ideas. | `ViewFS-rev0039-2026.03.22.15.31-canceldetach-resets-reruns-signalharbor.zip` | Research + deferred-control seam revision |
| EVID-2026-078 | E0 | Generated context pack for Revision 039. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-079 | E0 | Fortieth ViewFS datacube archive revision adding observe/query/follow / attach / control-message / exec-debug / sideband seam guardrails and follow-tail / attach-rail / control-pane shell ideas. | `ViewFS-rev0040-2026.03.22.16.02-observeattach-controlplanes-sidebands-helmsman.zip` | Research + live-session seam revision |
| EVID-2026-080 | E0 | Generated context pack for Revision 040. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-081 | E0 | Forty-first ViewFS datacube archive revision adding a fresh SlopOS datacube evaluation note, more explicit low-regret non-decisions, and semantic-inspector / restricted-badge shell ideas. | `ViewFS-rev0041-2026.03.22.18.23-lessonssteals-shellmoves-gateharbor.zip` | Research + parent-datacube evaluation revision |
| EVID-2026-082 | E0 | Generated context pack for Revision 041. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-083 | E0 | Forty-second ViewFS datacube archive revision deepening SlopOS datacube evaluation around optional persistence, view-scoped query, and semantic shell metadata while preserving low-regret non-decisions. | `ViewFS-rev0042-2026.03.22.19.05-datacubelenses-persistencerails-shellchrome-cairn.zip` | Research + datacube/process refinement revision |
| EVID-2026-084 | E0 | Generated context pack for Revision 042. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-085 | E0 | Forty-third ViewFS datacube archive revision adding continuity/escrow seam guardrails, more explicit SlopOS datacube evaluation notes, and trusted-review-lane / collapsible-command-section shell ideas. | `ViewFS-rev0043-2026.03.22.19.22-escrowroutes-reviewlanes-commandchrome-breakwater.zip` | Research + continuity/shell-truth refinement revision |
| EVID-2026-086 | E0 | Generated context pack for Revision 043. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-087 | E0 | Forty-fourth ViewFS datacube archive revision refining narrow continuity with exact-handle locker ideas, separating identity/placement/operations more sharply, and adding handle-locker / exact-action-menu shell ideas. | `ViewFS-rev0044-2026.03.22.19.34-lockersaffordances-actionmenus-reefline.zip` | Research + continuity/affordance refinement revision |
| EVID-2026-088 | E0 | Generated context pack for Revision 044. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-089 | E0 | Forty-fifth ViewFS datacube archive revision refining transient staging-capsule / couriered-handle / committed-object separations and adding sealed-capsule / commit-last shell ideas. | `ViewFS-rev0045-2026.03.22.19.52-stagingcapsules-handlecouriers-commitrails-tidelock.zip` | Research + staging/transfer seam revision |
| EVID-2026-090 | E0 | Generated context pack for Revision 045. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-091 | E0 | Forty-sixth ViewFS datacube archive revision refining activation-kit / live-handle / issuer-badge / object-identity separations and adding truth-grade command chrome ideas. | `ViewFS-rev0046-2026.03.22.20.06-activationbadges-launchkits-actiongates-emberport.zip` | Research + activation/truth-ladder seam revision |
| EVID-2026-092 | E0 | Generated context pack for Revision 046. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-093 | E0 | Forty-seventh ViewFS datacube archive revision refining courier-peer-witness / transferred-handle / command-packet / transcript-row separations and adding peer-witness courier drawer ideas. | `ViewFS-rev0047-2026.03.22.20.31-peerwitness-commandpackets-routechrome-bellwether.zip` | Research + courier/provenance seam revision |
| EVID-2026-094 | E0 | Generated context pack for Revision 047. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-095 | E0 | Forty-eighth ViewFS datacube archive revision refining command-packet / live-process-handle / lifecycle-control / deep-inspection separations and adding live-process-card shell ideas. | `ViewFS-rev0048-2026.03.22.20.58-processcards-livehandles-lifecycletruth-fathom.zip` | Research + running-command/process-handle seam revision |
| EVID-2026-096 | E0 | Generated context pack for Revision 048. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-097 | E0 | Forty-ninth ViewFS datacube archive revision refining root-handle / resolve-posture / current-placement separations and adding root-badge / prompt-local-click shell ideas. | `ViewFS-rev0049-2026.03.22.21.17-rootbadges-clickprompts-landmarkrails-cinderpath.zip` | Research + rooted-resolution seam revision |
| EVID-2026-098 | E0 | Generated context pack for Revision 049. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-099 | E0 | Fiftieth ViewFS datacube archive revision refining detached-fragment / pre-attach-posture / live-bind separations and adding paste-capsule / input-origin shell ideas. | `ViewFS-rev0050-2026.03.22.21.43-detachedfragments-pastecapsules-keytruth-breakershore.zip` | Research + detached-fragment/input-origin seam revision |
| EVID-2026-100 | E0 | Generated context pack for Revision 050. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-101 | E0 | Fifty-first ViewFS datacube archive revision refining exact-exec-object / launch-basis / startup-credential separations and adding launch-basis-card shell ideas. | `ViewFS-rev0051-2026.03.22.22.16-execobjects-credentialslots-launchcards-signalreef.zip` | Research + launch-basis/startup-credential seam revision |
| EVID-2026-102 | E0 | Generated context pack for Revision 051. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-103 | E0 | Fifty-second ViewFS datacube archive revision refining exec-object / startup-code-closure / loader-policy / late-import separations and adding closure-certainty / loader-debt shell ideas. | `ViewFS-rev0052-2026.03.22.22.44-codeclosures-loadertruth-closurecards-hinterland.zip` | Research + startup-closure/loader-policy seam revision |
| EVID-2026-104 | E0 | Generated context pack for Revision 052. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-105 | E0 | Fifty-third ViewFS datacube archive revision refining selection-owner / offered-representation / pasted-input / imported-object separations and adding clipboard-offer-card shell ideas. | `ViewFS-rev0053-2026.03.22.23.11-selectionoffers-clipboardtruth-importrails-lanternbay.zip` | Research + clipboard/selection seam revision |
| EVID-2026-106 | E0 | Generated context pack for Revision 053. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-107 | E0 | Fifty-fourth ViewFS datacube archive revision refining live-process-handle / terminal-stream / controlling-TTY / foreground-turn separations and adding foreground-baton / TTY-lease shell ideas. | `ViewFS-rev0054-2026.03.22.23.42-foregroundbatons-ttyleases-jobcards-sparrowbank.zip` | Research + job-control/terminal-truth seam revision |
| EVID-2026-108 | E0 | Generated context pack for Revision 054. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-109 | E0 | Fifty-fifth ViewFS datacube archive revision refining exec-object / runner-runtime / bootstrap-posture / live-session separations and adding runner-badge / mutable-prompt-dock shell ideas. | `ViewFS-rev0055-2026.03.22.23.58-runnerbadges-promptdocks-bootstraptruth-harborlight.zip` | Research + runner/bootstrap seam revision |
| EVID-2026-110 | E0 | Generated context pack for Revision 055. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-111 | E0 | Fifty-sixth ViewFS datacube archive revision refining handle-slot / live-handle-copy / shared-open-state / independent-reopen separations and adding twin-handle / duplicate-versus-reopen shell ideas. | `ViewFS-rev0056-2026.03.23.00.23-handletwins-reopentruth-sharedstate-jettyglass.zip` | Research + handle-topology seam revision |
| EVID-2026-112 | E0 | Generated context pack for Revision 056. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-113 | E0 | Fifty-seventh ViewFS datacube archive revision refining locator/metadata-handle / live-byte-I/O / reopen-escalation / durable-ref separations and adding handle-class / inspect-first shell ideas. | `ViewFS-rev0057-2026.03.23.00.52-locatorclasses-inspectrails-kindtruth-quarrylight.zip` | Research + handle-class seam revision |
| EVID-2026-114 | E0 | Generated context pack for Revision 057. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-115 | E0 | Fifty-eighth ViewFS datacube archive revision refining current-handle / launch-inheritance / child-slot / launch-receipt separations and adding inheritance-shutter / child-slot-map shell ideas. | `ViewFS-rev0058-2026.03.23.01.29-inheritanceshutters-childslots-leaksirens-torchbay.zip` | Research + launch-inheritance seam revision |
| EVID-2026-116 | E0 | Generated context pack for Revision 058. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-117 | E0 | Fifty-ninth ViewFS datacube archive revision refining object-identity / source-parent / destination-parent / namespace-mutation separations and adding two-anchor-rename / collision-mode shell ideas. | `ViewFS-rev0059-2026.03.23.02.09-anchorpairs-collisionrails-nametruth-rillmark.zip` | Research + namespace-mutation seam revision |
| EVID-2026-118 | E0 | Generated context pack for Revision 059. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-119 | E0 | Sixtieth ViewFS datacube archive revision refining live-bind / propagation-posture / peer-group separations and adding propagation-badge / blast-radius shell ideas. | `ViewFS-rev0060-2026.03.23.02.39-propagationbadges-blastrails-peergroups-mooring.zip` | Research + bind-propagation seam revision |
| EVID-2026-120 | E0 | Generated context pack for Revision 060. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-121 | E0 | Sixty-first ViewFS datacube archive revision refining draft-object / namespace-publication / receipt separations and adding draft-object-card / publish-later shell ideas. | `ViewFS-rev0061-2026.03.23.03.09-namelessdrafts-publishrails-objecttruth-keelwake.zip` | Research + publication seam revision |
| EVID-2026-122 | E0 | Generated context pack for Revision 061. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-123 | E0 | Sixty-second ViewFS datacube archive revision refining content descriptors / live handles / receipts separations and adding descriptor-card / hydrate-later shell ideas. | `ViewFS-rev0062-2026.03.23.08.02-descriptorcards-hydrateladders-objectchips-glassharbor.zip` | Research + descriptor/handle seam revision |
| EVID-2026-124 | E0 | Generated context pack for Revision 062. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-125 | E0 | Sixty-third ViewFS datacube archive revision refining imported-source-ref / local-object-materialization / local-docref separations and adding localize-first-import / semantic-epoch shell ideas. | `ViewFS-rev0063-2026.03.23.08.31-localobjects-docrefladders-importtruth-amberjetty.zip` | Research + import-localization / shell-truth seam revision |
| EVID-2026-126 | E0 | Generated context pack for Revision 063. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-127 | E0 | Sixty-fourth ViewFS datacube archive revision refining remembered-designator / revalidation / continuity-locker / revived-live-handle separations and adding reopen-truth / continuity-shelf shell ideas. | `ViewFS-rev0064-2026.03.23.09.18-reopenrails-continuitylockers-stalebadges-breakwater.zip` | Research + continuity/reopen seam revision |
| EVID-2026-128 | E0 | Generated context pack for Revision 064. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-129 | E0 | Sixty-fifth ViewFS datacube archive revision refining transfer-offer / live-handle-copy / revival-designator / adopted-bind separations and adding transfer-sheet / adoption-rail shell ideas. | `ViewFS-rev0065-2026.03.23.01.18-transferoffers-adoptionrails-couriertruth-riverglass.zip` | Research + handoff/adoption seam revision |
| EVID-2026-130 | E0 | Generated context pack for Revision 065. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-131 | E0 | Sixty-sixth ViewFS datacube archive revision refining non-authoritative-designator / authority-bearing-ticket / local-alias / live-handle separations and adding inert-designator-paste / ticket-chip shell ideas. | `ViewFS-rev0066-2026.03.23.01.25-designatorchips-ticketrails-inertpaste-lighthouse.zip` | Research + designation/authority seam revision |
| EVID-2026-132 | E0 | Generated context pack for Revision 066. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-133 | E0 | Sixty-seventh ViewFS datacube archive revision refining caveat-set / membrane-lease / live-handle / receipt separations and adding caveat-laminate / membrane-badge shell ideas. | `ViewFS-rev0067-2026.03.23.01.48-caveatladders-membranebadges-attenuationtruth-ironharbor.zip` | Research + caveat/enforcement seam revision |
| EVID-2026-134 | E0 | Generated context pack for Revision 067. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-135 | E0 | Sixty-eighth ViewFS datacube archive revision refining permission-outlook / revival-designator / live-handle / death-state-verdict separations and adding permission-light / death-certificate shell ideas. | `ViewFS-rev0068-2026.03.23.01.58-permissionlights-deathcerts-repairtruth-signalcairn.zip` | Research + liveness/repair seam revision |
| EVID-2026-136 | E0 | Generated context pack for Revision 068. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-137 | E0 | Sixty-ninth ViewFS datacube archive revision refining provenance-attestation / endorsement-bundle / local-admission-verdict / live-handle separations and adding provenance-ribbon / verdict-shutter shell ideas. | `ViewFS-rev0069-2026.03.23.02.16-endorsementribbons-verdictshutters-admissiontruth-skyanchor.zip` | Research + provenance/admission seam revision |
| EVID-2026-138 | E0 | Generated context pack for Revision 069. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-139 | E0 | Seventieth ViewFS datacube archive revision refining request-handle / session-handle / portal-owned-live-state / local-adoption separations and adding request-ledger / session-card shell ideas, while fixing context-pack coverage to carry RFCs 0062 and 0063. | `ViewFS-rev0070-2026.03.23.02.18-requestledgers-sessionrails-portaltruth-brassquay.zip` | Research + portal-state/session seam revision |
| EVID-2026-140 | E0 | Generated context pack for Revision 070. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-141 | E0 | Seventy-first ViewFS datacube archive revision refining query-manifest / result-snapshot / live-query-feed / materialized-collection / current-bind separations and adding freeze-to-basket / drift-lens shell ideas. | `ViewFS-rev0071-2026.03.23.02.25-querybaskets-freezesets-smarttruth-cinderdock.zip` | Research + smart-query/materialized-set seam revision |
| EVID-2026-142 | E0 | Generated context pack for Revision 071. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-143 | E0 | Seventy-second ViewFS datacube archive revision refining completion-candidate / accepted-insertion / compiled-packet / prepared-action separations and adding ghost-row / packet-gutter shell ideas. | `ViewFS-rev0072-2026.03.23.02.41-ghostrows-packetgutters-reruntrust-silverdelta.zip` | Research + completion/prompt-buffer seam revision |

| EVID-2026-144 | E0 | Generated context pack for Revision 072. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-145 | E0 | Seventy-third ViewFS datacube archive revision refining selected-region / extracted-entity / route-envelope / prepared-action separations and adding entity-peel / route-slip shell ideas. | `ViewFS-rev0073-2026.03.23.03.07-entitypeels-routeslips-hypertruth-emberport.zip` | Research + transcript-entity/routed-action seam revision |
| EVID-2026-146 | E0 | Generated context pack for Revision 073. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-147 | E0 | Seventy-fourth ViewFS datacube archive revision refining gesture-evidence / activation-baton / armed-state / active-control separations and adding activation-baton / arming-rail shell ideas. | `ViewFS-rev0074-2026.03.23.03.44-activationbatons-armingrails-foregroundtruth-sunquarry.zip` | Research + interaction-proof/active-control seam revision |
| EVID-2026-148 | E0 | Generated context pack for Revision 074. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-149 | E0 | Seventy-fifth ViewFS datacube archive revision refining object-identity / view-placement / current-handle-rights / advertised-operations separations and adding place-card / verb-ledger shell ideas. | `ViewFS-rev0075-2026.03.23.04.12-affordancelenses-verbledgers-placecards-moonferry.zip` | Research + identity/placement/affordance seam revision |
| EVID-2026-150 | E0 | Generated context pack for Revision 075. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-151 | E0 | Seventy-sixth ViewFS datacube archive revision refining declared-type / derived-type / handler-association / chosen-opener / live-open-state separations and adding type-lens / handler-rack shell ideas. | `ViewFS-rev0076-2026.03.23.04.46-typelenses-handlerracks-snifftruth-rosebay.zip` | Research + type/opener/open-state seam revision |
| EVID-2026-152 | E0 | Generated context pack for Revision 076. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-153 | E0 | Seventy-seventh ViewFS datacube archive revision refining advisory-annotation / selector-label / policy-label / trusted-badge separations and adding label-ledger / trusted-badge-shutter shell ideas, while fixing context-pack and lint coverage to carry RFCs 0069 and 0070. | `ViewFS-rev0077-2026.03.23.05.18-labelrails-badgeshields-selectortruth-copperquay.zip` | Research + label/policy/chrome seam revision |
| EVID-2026-154 | E0 | Generated context pack for Revision 077. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-155 | E0 | Seventy-eighth ViewFS datacube archive revision refining continuation-cursor / sync-watermark / live-subscription / rebuilt-snapshot / gap-verdict separations and adding waterline-card / gap-badge / resync-ladder shell ideas. | `ViewFS-rev0078-2026.03.23.05.57-waterlinecards-gapbadges-resynctruth-slateharbor.zip` | Research + cursor/watermark/rebuild seam revision |
| EVID-2026-156 | E0 | Generated context pack for Revision 078. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-157 | E0 | Seventy-ninth ViewFS datacube archive revision refining observed-validator / writable-session / write-hold / commit-precondition / committed-version separations and adding stale-base-lamp / commit-shutter shell ideas. | `ViewFS-rev0079-2026.03.23.04.04-writefences-commitshutters-basetruth-harborforge.zip` | Research + validator/draft/commit seam revision |
| EVID-2026-158 | E0 | Generated context pack for Revision 079. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-159 | E0 | Eightieth ViewFS datacube archive revision refining partial-residency / chunk-layout / whole-object-proof / live-range-session separations and adding hole-map / whole-proof-ladder shell ideas. | `ViewFS-rev0080-2026.03.23.06.33-rangepanels-wholeproofs-sparsetruth-grayhaven.zip` | Research + sparse-coverage/whole-proof seam revision |
| EVID-2026-160 | E0 | Generated context pack for Revision 080. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-161 | E0 | Eighty-first ViewFS datacube archive revision refining delta-recipe / exact-basis / apply-session / reconstructed-target separations and adding basis-card / apply-ladder shell ideas. | `ViewFS-rev0081-2026.03.23.07.26-basiscards-applyladders-deltatruth-porcelainquay.zip` | Research + delta/basis/reconstruction seam revision |
| EVID-2026-162 | E0 | Generated context pack for Revision 081. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-163 | E0 | Eighty-second ViewFS datacube archive revision refining activation-carrier / live-handle-copy / issuer-badge / object-ref / local-bind separations and adding activation-sheet / handoff-sheet shell ideas. | `ViewFS-rev0082-2026.03.23.12.54-activationslots-issuerbadges-handoffsheets-riverglass.zip` | Research + startup/handoff/copy-lineage seam revision |
| EVID-2026-164 | E0 | Generated context pack for Revision 082. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-165 | E0 | Eighty-third ViewFS datacube archive revision refining store-membership / synthetic-view / live-handle / published-name separations and adding published-name-ledger / synthetic-view-badge shell ideas. | `ViewFS-rev0083-2026.03.23.13.15-publishednames-syntheticviews-portallocality-amberquay.zip` | Research + publication/locality seam revision |
| EVID-2026-166 | E0 | Generated context pack for Revision 083. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-167 | E0 | Eighty-fourth ViewFS datacube archive revision refining explicit-handle-open / rooted-compat-pathwalk / ambient-escape separations and adding safe-open-ladder / ambient-debt-siren shell ideas. | `ViewFS-rev0084-2026.03.23.14.05-ambientdebt-safeopens-escapereceipts-cinderpath.zip` | Research + open-lane/debt seam revision |
| EVID-2026-168 | E0 | Generated context pack for Revision 084. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-169 | E0 | Eighty-fifth ViewFS datacube archive revision refining discoverability / enumeration / exact-name reachability / fit-note separations and adding dark-directory / known-name-chip shell ideas. | `ViewFS-rev0085-2026.03.23.14.41-browsegates-knownnames-fitsheets-lanterndock.zip` | Research + browse/open/fit seam revision |
| EVID-2026-170 | E0 | Generated context pack for Revision 085. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-171 | E0 | Eighty-sixth ViewFS datacube archive revision refining advert/catalog-presence / readiness / grant-needed / current-authority separations and adding presence-halo / readiness-lamp shell ideas. | `ViewFS-rev0086-2026.03.23.15.32-presencehalos-readylamps-adverttruth-mistbeacon.zip` | Research + advert/readiness/authority seam revision |
| EVID-2026-172 | E0 | Generated context pack for Revision 086. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-173 | E0 | Eighty-seventh ViewFS datacube archive revision refining provider-ready / reacquire-needed / local-realized / live-handle separations and adding make-local-ladder / provider-owned-badge shell ideas. | `ViewFS-rev0087-2026.03.23.18.39-reacquireclaims-localrealize-repairrails-tideledger.zip` | Research + provider-ready/local-realized seam revision |
| EVID-2026-174 | E0 | Generated context pack for Revision 087. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-175 | E0 | Eighty-ninth ViewFS datacube archive revision refining possession / recency / step-up / local-presence / invocability separations and adding why-not-now-drawer / recency-shutter shell ideas. | `ViewFS-rev0089-2026.03.23.19.33-stepupladders-freshproofs-invokegates-lucentquay.zip` | Research + possession/invocability seam revision |
| EVID-2026-176 | E0 | Generated context pack for Revision 089. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-177 | E0 | Eighty-eighth ViewFS datacube archive revision refining claim-ticket / holder-bound-grant / passable-live-handle / spent-trace separations and adding redemption-ladder / holder-proof-badge shell ideas. | `ViewFS-rev0088-2026.03.23.19.08-claimtickets-holderproof-burnrails-emberquay.zip` | Research + claim/holder-proof seam revision |
| EVID-2026-178 | E0 | Generated context pack for Revision 088. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-179 | E0 | Ninetieth ViewFS datacube archive revision refining live-possession / watch-status-carrier / local-hold / successor-refresh separations and adding watch-braid / hold-rail / successor-lantern shell ideas. | `ViewFS-rev0090-2026.03.23.20.24-watchbraids-holdrails-successorlanterns-signalharbor.zip` | Research + watch/hold/successor seam revision |
| EVID-2026-180 | E0 | Generated context pack for Revision 090. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-181 | E0 | Ninety-first ViewFS datacube archive revision refining current-possession / local-duplication / live-lend / representation-export separations and adding lend-ladder / lane-fit-badge shell ideas. | `ViewFS-rev0091-2026.03.23.21.10-lendladders-lanefits-bytesfallback-glassdelta.zip` | Research + lend/export-lane seam revision |
| EVID-2026-182 | E0 | Generated context pack for Revision 091. | `out/context_pack.md` | Regenerate with `make context-pack` |
| EVID-2026-183 | E0 | Ninety-second ViewFS datacube archive revision refining foreign-backed-borrow / compat-attach / projected-import / local-realization separations and adding borrow-rail / projection-badge / make-here-ladder shell ideas. | `ViewFS-rev0092-2026.03.23.22.06-borrowrails-projectionfits-localizefog-ferryglass.zip` | Research + borrow/project/localize seam revision |
| EVID-2026-184 | E0 | Generated context pack for Revision 092. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-185 | E0 | Ninety-third ViewFS datacube archive revision refining route-capsule / authority-sidecar / sink-binding separations and adding route-slip / sidecar-chip / sink-tray shell ideas. | `ViewFS-rev0093-2026.03.23.22.54-routecapsules-sidecars-sinkbinds-latticewharf.zip` | Research + route/sidecar/sink-consequence seam revision |
| EVID-2026-186 | E0 | Generated context pack for Revision 093. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-187 | E0 | Ninety-fourth ViewFS datacube archive revision refining privilege-bracket / borrowed-authority / call-context / deny-only-veto separations and adding bracket-rail / caller-badge / who-asked-drawer shell ideas. | `ViewFS-rev0094-2026.03.23.23.31-bracketrails-callframes-deputyfog-slateharbor.zip` | Research + bracket/borrowed-authority/caller-context seam revision |
| EVID-2026-188 | E0 | Generated context pack for Revision 094. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-189 | E0 | Ninety-fifth ViewFS datacube archive revision refining native-attach / adapted-attach / coerced-representation / local-realization separations and adding attach-mode-badge / adapter-veil / virtuality-lamp shell ideas. | `ViewFS-rev0095-2026.03.23.23.58-attachmodes-adapterveils-virtuality-clearwater.zip` | Research + attach-fidelity seam revision |
| EVID-2026-190 | E0 | Generated context pack for Revision 095. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-191 | E0 | Ninety-sixth ViewFS datacube archive revision refining built-in-shell / reviewed-customization / startup-profile / project-hook separations and adding clean-start-lamp / bundle-ledger / hook-quarantine shell ideas. | `ViewFS-rev0096-2026.03.24.00.26-cleanstarts-bundleledgers-hookquarantine-auroradock.zip` | Research + shell-startup honesty seam revision |
| EVID-2026-192 | E0 | Generated context pack for Revision 096. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-193 | E0 | Ninety-seventh ViewFS datacube archive revision refining built-in-verb / lexical-expansion / command-layer / key-action / external-launch separations and adding verb-provenance-card / overlay-rack / key-table-lamp shell ideas. | `ViewFS-rev0097-2026.03.24.01.14-verbcards-overlayracks-keytablelamps-silverdelta.zip` | Research + command-surface honesty seam revision |
| EVID-2026-194 | E0 | Generated context pack for Revision 097. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-195 | E0 | Ninety-eighth ViewFS datacube archive revision refining editable-buffer / parse-structure / advisory-diagnostic / compiled-packet / prepared-action separations and adding parse-lens / diagnostic-rail / packet-gutter shell ideas. | `ViewFS-rev0098-2026.03.24.02.32-parselenses-diagnosticrails-packetgutters-nightglass.zip` | Research + parse/diagnostic/packet seam revision |
| EVID-2026-196 | E0 | Generated context pack for Revision 098. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-197 | E0 | Ninety-ninth ViewFS datacube archive revision refining room-identity / current-view / inheritance-posture / child-spawn-recipe / child-import separations and adding room-badge / context-diff / spawn-recipe shell ideas. | `ViewFS-rev0099-2026.03.24.03.18-roombadges-contextdiffs-spawnrecipes-switchglass.zip` | Research + room/current-view/spawn seam revision |
| EVID-2026-198 | E0 | Generated context pack for Revision 099. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-199 | E0 | One-hundredth ViewFS datacube archive revision refining namespace-plan / live-room-bind / portal-session / local-overlay separations and adding switchboard / overlay-rack / anchor-death-card shell ideas. | `ViewFS-rev0100-2026.03.24.04.46-switchboards-overlayracks-anchorcards-harborglass.zip` | Research + namespace-plan/live-bind/local-overlay seam revision |
| EVID-2026-200 | E0 | Generated context pack for Revision 100. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-201 | E0 | One-hundred-first ViewFS datacube archive revision refining durable-import-anchor / live-room-bind / stale-shadow / repair-plan separations and adding stale-shadow / repair-ladder / rebind-receipt shell ideas. | `ViewFS-rev0101-2026.03.24.05.34-staleshadows-repairladders-rebindreceipts-glowharbor.zip` | Research + durable-anchor/stale-shadow/repair seam revision |
| EVID-2026-202 | E0 | Generated context pack for Revision 101. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-203 | E0 | One-hundred-second ViewFS datacube archive revision refining activation-kit / restart-locker / namespace-pin / live-room-bind separations and adding restart-shelf / wake-kit / pin-badge shell ideas. | `ViewFS-rev0102-2026.03.24.06.18-wakekits-restartshelves-pinbadges-coldwake.zip` | Research + warm-restart/namespace-pin seam revision |
| EVID-2026-204 | E0 | Generated context pack for Revision 102. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-205 | E0 | One-hundred-third ViewFS datacube archive revision refining live-room-bind / currentness-witness / semantic-epoch / repair-offer separations and adding epoch-lamp / hop-badge / repair-offer-card shell ideas. | `ViewFS-rev0103-2026.03.24.07.07-epochlamps-hopbadges-repairoffers-signalquay.zip` | Research + currentness/semantic-footing/repair-offer seam revision |
| EVID-2026-206 | E0 | Generated context pack for Revision 103. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-207 | E0 | One-hundred-fourth ViewFS datacube archive revision refining live-room-bind / currentness-witness / renewal-window / retry-advice / repair-gate separations and adding renewal-lamp / retry-clock / gate-card shell ideas. | `ViewFS-rev0104-2026.03.24.08.12-renewallamps-retryclocks-gatecards-clearwake.zip` | Research + renewal/retry/repair-gate seam revision |
| EVID-2026-208 | E0 | Generated context pack for Revision 104. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-209 | E0 | One-hundred-fifth ViewFS datacube archive revision refining live-room-bind / visibility-state / keep-warm-lease / restore-intent / deferred-repair-job separations and adding warmth-rail / login-lantern / defer-drawer shell ideas. | `ViewFS-rev0105-2026.03.24.09.05-warmrails-loginlanterns-deferdrawers-hearthwake.zip` | Research + warmth/restore/deferred-repair seam revision |
| EVID-2026-210 | E0 | Generated context pack for Revision 105. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-211 | E0 | One-hundred-sixth ViewFS datacube archive revision refining live-room-bind / attention-cue / interrupt-grade / quiet-window / ack-ledger separations and adding attention-pip / quiet-shutter / ack-ledger shell ideas. | `ViewFS-rev0106-2026.03.24.10.02-attentionpips-quietshutters-ackledgers-signalkeep.zip` | Research + attention/interrupt/ack seam revision |
| EVID-2026-212 | E0 | Generated context pack for Revision 106. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-213 | E0 | One-hundred-seventh ViewFS datacube archive revision refining live-room-bind / summon-beacon / activation-baton / foreground-turn / secure-entry-gate separations and adding summon-beacon / front-latch / secure-entry-shutter shell ideas. | `ViewFS-rev0107-2026.03.24.11.07-summonbeacons-frontlatches-secureentry-signalporch.zip` | Research + summon/foreground/trusted-entry seam revision |
| EVID-2026-214 | E0 | Generated context pack for Revision 107. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-215 | E0 | One-hundred-eighth ViewFS datacube archive revision refining live-room-bind / observe-mirror / automation-lease / synthetic-input-lane / secure-entry-exclusion separations and adding mirror-strip / rehearsal-rail / secure-entry-curtain shell ideas. | `ViewFS-rev0108-2026.03.24.12.04-mirrorstrips-rehearsalrails-securecurtains-glassrelay.zip` | Research + automation/mirror/secure-entry seam revision |
| EVID-2026-216 | E0 | Generated context pack for Revision 108. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-217 | E0 | One-hundred-ninth ViewFS datacube archive revision refining live-room-bind / selection-owner / transfer-offer / manager-retention / paste-capsule / materialized-import separations and adding offer-card / paste-capsule / history-ghost shell ideas. | `ViewFS-rev0109-2026.03.24.13.01-offercards-pastecapsules-historyghosts-inkquay.zip` | Research + transfer/history/paste seam revision |
| EVID-2026-218 | E0 | Generated context pack for Revision 109. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-219 | E0 | One-hundred-tenth ViewFS datacube archive revision refining live-room-bind / provider-projection-site / published-room-alias / localization separations and adding site-ledger / provider-halo / bind-here-ladder shell ideas. | `ViewFS-rev0110-2026.03.24.13.46-siteledgers-providerhalos-bindlast-tideglass.zip` | Research + projection/publication/locality seam revision |
| EVID-2026-220 | E0 | Generated context pack for Revision 110. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-221 | E0 | One-hundred-eleventh ViewFS datacube archive revision refining live-room-bind / projected-base / local-upper-overlay / merged-presentation / publish-result separations and adding stack-badge / whiteout-ghost / commit-ladder shell ideas. | `ViewFS-rev0111-2026.03.24.14.40-shadowstacks-whiteoutghosts-mergerails-layerquay.zip` | Research + overlay/merge/publish seam revision |
| EVID-2026-222 | E0 | Generated context pack for Revision 111. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-223 | E0 | One-hundred-twelfth ViewFS datacube archive revision refining live-room-bind / local-edit-shadow / pushback-basis / provider-verdict / adopted-result separations and adding basis-lamp / verdict-card / adopt-rail shell ideas. | `ViewFS-rev0112-2026.03.24.15.32-basislamps-verdictcards-adoptrails-brineglass.zip` | Research + pushback/verdict/adoption seam revision |
| EVID-2026-224 | E0 | Generated context pack for Revision 112. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-225 | E0 | One-hundred-thirteenth ViewFS datacube archive revision refining live-room-bind / local-edit-shadow / accepted-request / provider-operation / completion-verdict / adopted-result separations and adding accept-slip / operation-bead / settle-rail shell ideas. | `ViewFS-rev0113-2026.03.24.16.21-acceptslips-opbeads-settlerails-gulflantern.zip` | Research + acceptance/completion/adoption seam revision |
| EVID-2026-226 | E0 | Generated context pack for Revision 113. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-227 | E0 | One-hundred-fourteenth ViewFS datacube archive revision refining live-room-bind / local-edit-shadow / intent-key / accepted-request / provider-operation / completion-verdict / adopted-result separations and adding intent-lamp / retry-braid / sameness-chip shell ideas. | `ViewFS-rev0114-2026.03.24.17.24-intentlamps-retrybraids-samenesschips-riverglass.zip` | Research + idempotency/retry-sameness seam revision |
| EVID-2026-228 | E0 | Generated context pack for Revision 114. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-229 | E0 | One-hundred-fifteenth ViewFS datacube archive revision refining caller-request-context / detached-root / deadline-intent / cancellation-state / provider-operation separations and adding cutoff-lamp / detach-root-card / continue-without-me shell ideas. | `ViewFS-rev0115-2026.03.24.18.18-cutofflamps-detachroots-cleanuprails-stillwater.zip` | Research + request-context/detach seam revision |
| EVID-2026-230 | E0 | Generated context pack for Revision 115. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-231 | E0 | One-hundred-sixteenth ViewFS datacube archive revision refining action-authority / payer-root / budget-lease / spend-reservation / charge-verdict separations and adding payer-chip / spend-rail / charge-ghost shell ideas. | `ViewFS-rev0116-2026.03.24.19.12-payerchips-spendrails-chargeghosts-meterquay.zip` | Research + sponsorship/budget-charge seam revision |
| EVID-2026-232 | E0 | Generated context pack for Revision 116. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-233 | E0 | One-hundred-seventeenth ViewFS datacube archive revision refining creator-seeded room / exact child handle table / later import and immutable object blob / mutable anchor / retention root / live authority separations. | `ViewFS-rev0117-2026.03.28.06.30-rootledgers-roomseeds-importladders-emberquay.zip` | Research + namespace-seeding/import/anchor-retention seam revision |
| EVID-2026-234 | E0 | Generated context pack for Revision 117. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-235 | E0 | One-hundred-eighteenth ViewFS datacube archive revision refining object-home room / attached-tool / imported-bind / published-name / retention-root separations while keeping the object-store and namespace story deliberately under-decided. | `ViewFS-rev0118-2026.03.28.02.45-grainhomes-tooldocks-rootledgers-hearthgrain.zip` | Research + object-home/tool-attachment seam revision |
| EVID-2026-236 | E0 | Generated context pack for Revision 118. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-237 | E0 | One-hundred-nineteenth ViewFS datacube archive revision refining object identity / capability facet / grouped kit / live room bind / published name separations while keeping the object-store and handle taxonomy deliberately under-decided. | `ViewFS-rev0119-2026.03.28.03.20-facetchips-kitcards-bindrails-lanterngrain.zip` | Research + capability-facet/kit-binding seam revision |
| EVID-2026-238 | E0 | Generated context pack for Revision 119. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-239 | E0 | One-hundred-twentieth ViewFS datacube archive revision refining descriptor/proof-row / verify-only facet / live read facet / live publish facet / live bind separations while keeping verification and opaque-token ABI choices deliberately under-decided. | `ViewFS-rev0120-2026.03.28.04.12-verifychips-proofcards-readrails-ambervault.zip` | Research + proof-versus-live-authority seam revision |
| EVID-2026-240 | E0 | Generated context pack for Revision 120. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-241 | E0 | One-hundred-twenty-first ViewFS datacube archive revision refining grant outlook / issued-bounds evidence / restore token / current live bind / death verdict separations while keeping grant-status and continuity carriers deliberately under-decided. | `ViewFS-rev0121-2026.03.28.05.18-grantgauges-restorebeads-deathcards-cinderquay.zip` | Research + continuity-status/death-verdict seam revision |
| EVID-2026-242 | E0 | Generated context pack for Revision 121. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-243 | E0 | One-hundred-twenty-second ViewFS datacube archive revision refining semantic object core / exact byte proof / structured address / live facet separations while keeping object-ID, canonicalization, and chunk-address families deliberately under-decided. | `ViewFS-rev0122-2026.03.28.03.52-objectcores-byteproofs-shapehashes-crystalquay.zip` | Research + object-core/byte-proof/shape-hash seam revision |
| EVID-2026-244 | E0 | Generated context pack for Revision 122. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-245 | E0 | One-hundred-twenty-third ViewFS datacube archive revision refining stable authority-core stamp / descriptive review envelope / explain sidecar / live bind separations while keeping digest families, envelope schemas, and sidecar carriers deliberately under-decided. | `ViewFS-rev0123-2026.03.28.04.00-corestamps-envelopecards-sidecarlamps-silverquay.zip` | Research + review-envelope/sidecar/live-bind seam revision |
| EVID-2026-246 | E0 | Generated context pack for Revision 123. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-247 | E0 | One-hundred-twenty-fourth ViewFS datacube archive revision refining strong-proof / weak-validator / comparison-profile / live-facet separations while keeping digest families, validator lanes, and comparison-profile syntax deliberately under-decided. | `ViewFS-rev0124-2026.03.28.04.11-stronglocks-weaklamps-compareprofiles-ironquay.zip` | Research + strong-proof/weak-validator seam revision |
| EVID-2026-248 | E0 | Generated context pack for Revision 124. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-249 | E0 | One hundred twenty-fifth ViewFS datacube archive revision refining object-core / designation / head-token / order-scope / supersession-row separations and adding head-badge / order-pip shell ideas. | `ViewFS-rev0125-2026.03.28.04.28-headbadges-orderpips-supersessionladders-riverquartz.zip` | Research + head/version/supersession seam revision |
| EVID-2026-250 | E0 | Generated context pack for Revision 125. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-251 | E0 | One-hundred-twenty-sixth ViewFS datacube archive revision refining semantic-record / canonical-payload / signed-wrapper / wire-copy separations and adding record-card / payload-chip / wrapper-seal shell ideas. | `ViewFS-rev0126-2026.03.28.08.45-payloadchips-wrapperseals-wireghosts-cedarquill.zip` | Research + payload/wrapper/wire seam revision |
| EVID-2026-252 | E0 | Generated context pack for Revision 126. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-253 | E0 | One-hundred-twenty-seventh ViewFS datacube archive revision refining fresh-object / shared-backing / copy-lineage / live-facet separations and adding birth-badge / backing-ghost / lineage-ladder shell ideas. | `ViewFS-rev0127-2026.03.28.09.18-birthbadges-backingghosts-lineageladders-hazelquay.zip` | Research + clone/backing/lineage seam revision |
| EVID-2026-254 | E0 | Generated context pack for Revision 127. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-255 | E0 | One-hundred-twenty-eighth ViewFS datacube archive revision refining upload-session / part-coverage / completion-manifest / committed-object / abort-verdict separations and adding session-bead / part-gauge / seal-ladder shell ideas. | `ViewFS-rev0128-2026.03.28.09.44-sessionbeads-partgauges-sealladders-brassharbor.zip` | Research + resumable-upload/finalization seam revision |
| EVID-2026-256 | E0 | Generated context pack for Revision 128. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-257 | E0 | One-hundred-twenty-ninth ViewFS datacube archive revision refining assembly-recipe / member-descriptor / aggregate-object / realized-work-surface / live-facet separations and adding recipe-card / member-rail / aggregate-seal shell ideas. | `ViewFS-rev0129-2026.03.28.09.24-recipecards-memberrails-unpacklamps-cedarharbor.zip` | Research + assembly/aggregate/realization seam revision |
| EVID-2026-258 | E0 | Generated context pack for Revision 129. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-259 | E0 | One-hundred-thirtieth ViewFS datacube archive revision refining transient-staging-capsule / seal-state / courier-handoff / committed-object separations and adding capsule-card / seal-shutter / courier-rail shell ideas. | `ViewFS-rev0130-2026.03.28.10.22-capsulecards-sealshutters-commitquays-glassember.zip` | Research + staging/freeze/courier/commit seam revision |
| EVID-2026-260 | E0 | Generated context pack for Revision 130. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-261 | E0 | One-hundred-thirty-first ViewFS datacube archive revision refining committed-object / retention-clock / hold-state / purge-verdict / live-facet separations and adding hold-badge / retention-rail / purge-lamp shell ideas. | `ViewFS-rev0131-2026.03.28.05.36-holdbadges-retentionrails-purgelamps-stoneharbor.zip` | Research + retention/hold/purge seam revision |
| EVID-2026-262 | E0 | Generated context pack for Revision 131. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-263 | E0 | One-hundred-thirty-second ViewFS datacube archive revision refining sealed-object / recipient-wrap / rewrap-plan / unwrap-handle / clear-facet separations and adding seal-badge / wrap-roster / rewrap-ladder shell ideas. | `ViewFS-rev0132-2026.03.28.05.52-sealbadges-wraprosters-rewrapladders-ivoryharbor.zip` | Research + sealed-object/wrap/unwrap seam revision |
| EVID-2026-264 | E0 | Generated context pack for Revision 132. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-265 | E0 | One-hundred-thirty-third ViewFS datacube archive revision refining committed-object / durability-profile / redundancy-layout / repair-verdict / availability-state separations and adding durability-badge / layout-ghost / repair-ladder shell ideas. | `ViewFS-rev0133-2026.03.28.11.06-durabadges-shareghosts-repairladders-ridgeharbor.zip` | Research + durability/layout/repair/availability seam revision |
| EVID-2026-266 | E0 | Generated context pack for Revision 133. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-267 | E0 | One-hundred-thirty-fourth ViewFS datacube archive revision refining committed-object / archive-tier / thaw-job / thawed-copy / live-facet separations and adding frost-badge / thaw-bead / expiry-lantern shell ideas. | `ViewFS-rev0134-2026.03.28.11.38-frostbadges-thawbeads-expirylanterns-mossharbor.zip` | Research + archive/thaw/temporary-readability seam revision |
| EVID-2026-268 | E0 | Generated context pack for Revision 134. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-269 | E0 | One-hundred-thirty-fifth ViewFS datacube archive revision refining committed-object / residency-profile / placement-realm / route-endpoint / egress-gate / live-facet separations and adding realm-badge / route-halo / egress-shutter shell ideas. | `ViewFS-rev0135-2026.03.28.06.27-realmbadges-routehalos-egressshutters-cedaratlas.zip` | Research + residency/placement/route/egress seam revision |
| EVID-2026-270 | E0 | Generated context pack for Revision 135. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-271 | E0 | One-hundred-thirty-sixth ViewFS datacube archive revision refining committed-object / access-propagation / public-cache / cache-trail / live-facet separations and adding truth-badge / propagation-echo / cache-ghost shell ideas. | `ViewFS-rev0136-2026.03.28.06.48-truthbadges-propagationechoes-cacheghosts-emberatlas.zip` | Research + origin-truth/propagation/cache-trail seam revision |
| EVID-2026-272 | E0 | Generated context pack for Revision 136. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-273 | E0 | One-hundred-thirty-seventh ViewFS datacube archive revision refining committed-object / prefix-projection / provider-folder-resource / listing-snapshot / published-name / live-facet separations and adding prefix-badge / folder-ghost / list-lantern shell ideas. | `ViewFS-rev0137-2026.03.28.06.50-prefixbadges-folderghosts-listlanterns-rivermap.zip` | Research + folder-projection/folder-resource/listing seam revision |
| EVID-2026-274 | E0 | Generated context pack for Revision 137. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-275 | E0 | One-hundred-thirty-eighth ViewFS datacube archive revision refining launch-view-plan / bound-root / handle-slot-table / portal-import-ticket / live-bind / receipt separations and adding slot-map / root-badge / import-ticket shell ideas. | `ViewFS-rev0138-2026.05.13.15.56-slotmaps-rootbadges-importtickets-copperloom.zip` | Research + launch/import authority seam revision |
| EVID-2026-276 | E0 | Generated context pack for Revision 138. | `out/context_pack.md` | Regenerate with `make context-pack` |

| `EVID-2026-277` | `2026-05-13` | `RFC 0126` + cap-flow architecture/shell docs | ViewFS keeps handle inventory, custody, outflow gate, flow snapshot/diff, leak verdict, live export, and receipt separate while evaluating SlopOS capability-graph/diff/export/wallet posture. |

| EVID-2026-278 | E0 | One-hundred-fortieth ViewFS datacube archive revision refining durable-root-commit / epoch-fence / restore-intent / resurrection-gate / activation-target / live-bind separations and adding root-ledger / restore-ticket shell ideas. | `ViewFS-rev0140-2026.05.13.17.05-rootledgers-epochfences-restorerails-ironmoss.zip` | Research + durable-root/restore/activation seam revision |
| EVID-2026-279 | E0 | Generated context pack for Revision 140. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-281 | E0 | One-hundred-forty-first ViewFS datacube archive revision refining reachability-root / live-handle-root / pin-hold-lease / sweep-candidate / finalizer / collected-ash / live-facet separations and adding GC-halo / pin-badge / sweep-rehearsal shell ideas. | `ViewFS-rev0141-2026.05.13.17.18-gchalos-pinleases-sweepguards-moonfern.zip` | Research + object-store liveness/GC seam revision |
| EVID-2026-282 | E0 | Generated context pack for Revision 141. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-283 | E0 | One-hundred-forty-second ViewFS datacube archive revision refining origin-evidence / quarantine-mark / safe-open-capsule / viewer-residue / derived-artifact / trust-clearance / live-open separations and adding quarantine-capsule / residue-lamp / trust-receipt shell ideas. | `ViewFS-rev0142-2026.05.13.18.14-quarantinecapsules-residuelamps-trustreceipts-amberreed.zip` | Research + quarantine/safe-open anti-laundering seam revision |
| EVID-2026-284 | E0 | Generated context pack for Revision 142. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-285 | E0 | One-hundred-forty-third ViewFS datacube archive revision refining archive/container extraction safety: container envelopes, member claims, extraction plans, sterile materialization roots, extracted member capsules, namespace commits, live opens, and receipts stay distinct. | `ViewFS-rev0143-2026.05.14.*-extractplans-membercapsules-pathguards-coralvault.zip` | Research + archive/container extraction seam revision |

| EVID-2026-286 | E0 | One-hundred-forty-fourth ViewFS datacube archive revision refining supply-chain evidence and admission hygiene: artifact envelopes, inventory claims, locator aliases, advisory/VEX statements, verification evidence, local admission verdicts, activation targets, live facets, and receipts stay distinct. | `ViewFS-rev0144-2026.05.15.14.36-sbomdrawers-vexshutters-admissioncuts-goldreed.zip` | Research + SBOM/VEX/provenance/admission seam revision |
| EVID-2026-287 | E0 | Generated context pack for Revision 144. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-288 | E0 | One-hundred-forty-fifth ViewFS datacube archive revision refining secret/credential delivery hygiene: secret descriptors, acquisition prompts, delivery slots/projections, environment shadows, redaction lenses, renewal/rotation leases, live-use handles, residue markers, and receipts stay distinct. | `ViewFS-rev0145-2026.05.15.15.16-secretslots-envshadows-renewalrails-obsidianwell.zip` | Research + secret delivery/redaction/renewal seam revision |
| EVID-2026-289 | E0 | Generated context pack for Revision 145. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-290 | E0 | One-hundred-forty-sixth ViewFS datacube archive revision refining delegation/revocation hygiene: delegation intents, attenuation/caveat envelopes, membrane leases, delegated handles, revocation requests, wavefront checkpoints, stale brakes, renewal/redelegation controls, current live authority, and receipts stay distinct. | `ViewFS-rev0146-2026.05.15.15.40-revokewaves-membraneleases-stalebrakes-blueash.zip` | Research + delegation/revocation wavefront seam revision |
| EVID-2026-291 | E0 | Generated context pack for Revision 146. | `out/context_pack.md` | Regenerate with `make context-pack` |

| EVID-2026-292 | E0 | One-hundred-forty-seventh ViewFS datacube archive revision refining inspection/diagnostics hygiene: inspection intents, target locators, namespace snapshots, fd/slot peeks, memory/core captures, trace probes, debug-control lanes, redaction/export cuts, current live authority, and receipts stay distinct. | `ViewFS-rev0147-2026.05.15.16.01-inspectlenses-procshades-tracefuses-cobaltfox.zip` | Research + inspection/trace/dump/debug seam revision |
| EVID-2026-293 | E0 | Generated context pack for Revision 147. | `out/context_pack.md` | Regenerate with `make context-pack` |

## Revision 148 evidence hooks

- **EVID-VIEWFS-148-001** — Network lease seam review: future proposals must classify whether they affect intent, destination designator, resolution witness, lease/admission cut, live network authority, stream state, local exposure, egress/import cut, or receipts.
- **EVID-VIEWFS-148-002** — Local-network/loopback negative tests: public-internet grants must not imply LAN, loopback, mDNS/SSDP discovery, listeners, advertisements, tunnels, or port forwards.
- **EVID-VIEWFS-148-003** — Fetch-to-object negative tests: successful network fetch must not bypass quarantine, extraction, supply-chain evidence, object-core currentness, or local admission.
- **EVID-VIEWFS-148-004** — Receipt non-revival tests: prior sync/update/upload/fetch receipts must not recreate live resolver/dialer/listener/stream authority.
- **EVID-VIEWFS-148-005** — Resolver/proxy omission tests: DNS, DoH, SVCB/HTTPS, Happy-Eyeballs, PAC/WPAD/proxy, and system resolver facts must be explicit, portal-local, or marked omitted rather than silently transcript-stable.
## Revision 149 evidence hooks

- **EVID-VIEWFS-149-001** — Service discovery seam review: future proposals must classify whether they affect service intent, designator, catalog/discovery authority, discovery snapshot, readiness evidence, binding cut, activation target, live service authority, advertisement, or receipt.
- **EVID-VIEWFS-149-002** — Candidate non-authority tests: DNS-SD instances, EndpointSlice rows, xDS resources, DID service entries, MCP tool rows, and catalog rows must not invoke without a binding cut and live handle.
- **EVID-VIEWFS-149-003** — Readiness non-trust tests: health green, `ready`, `serving`, route-warmed, or identity-matched must not bypass local policy, supply-chain admission, secret/export cuts, or live-handle minting.
- **EVID-VIEWFS-149-004** — Advertisement split tests: listen does not imply advertise; advertise does not imply listen; public endpoint allocation does not imply durable service publication.
- **EVID-VIEWFS-149-005** — Receipt non-revival tests: prior discovery/bind/activation/call receipts cannot rediscover, reconnect, rebind, invoke, or accept new calls.
## Revision 150 evidence hooks

- **EVID-VIEWFS-150-001** — Secure transport seam review: future proposals must classify whether they affect transport intent, reference identity, presented evidence, verifier profile, trust-anchor/pin inputs, verification verdict, channel binding, resumption/0-RTT, live secure channel, or receipts.
- **EVID-VIEWFS-150-002** — Reference-identity non-laundering tests: peer-presented identifiers, DNS aliases, redirects, SVCB/SRV intermediates, and proxy names must not silently become the reviewed reference identity.
- **EVID-VIEWFS-150-003** — Trust-input non-authority tests: certificate chains, CT SCTs, OCSP/CRL/status artifacts, DANE records, SVIDs, and SSH host keys must remain evidence until local policy selects anchors/pins/verifier rules.
- **EVID-VIEWFS-150-004** — Channel-binding secrecy tests: channel-binding/exporter material must be redacted or digest-only in ordinary transcripts and must not become passable bearer authority.
- **EVID-VIEWFS-150-005** — Resumption/0-RTT tests: session tickets, PSKs, and early data must not carry mutation/export/secret-release operations unless an explicit replay-safe cut says so.
- **EVID-VIEWFS-150-006** — Receipt non-revival tests: prior verified/connected/pinned/resumed receipts cannot reconnect, verify current peer state, or mint service/object authority.



| EVID-2026-303 | E0 | One-hundred-fifty-first ViewFS datacube archive revision refining content-address / equality / dedup / convergence / cache-hit / materialization hygiene: digest/proof lanes, comparison profiles, dedup domains, privacy domains, possession checks, live facets, and receipts stay distinct. | `ViewFS-rev0151-2026.05.16.04.14-digestshades-equalityrails-dedupshutters-pearlvault.zip` | Research + content-address/dedup privacy seam revision |
| EVID-2026-304 | E0 | Generated context pack for Revision 151. | `out/context_pack.md` | Regenerate with `make context-pack` |


| EVID-2026-305 | E0 | One-hundred-fifty-second ViewFS datacube archive revision refining semantic derivation and retrieval-store hygiene: semantic extraction intents, source snapshots/input capsules, extractor/model profiles, derived artifacts, index/store membership, query scopes, result projections, answer cards, live authority, and receipts stay distinct. | `ViewFS-rev0152-2026.05.18.14.05-semanticshades-embeddingvaults-answerreceipts-opalthread.zip` | Research + semantic derivation/retrieval-store seam revision |
| EVID-2026-306 | E0 | Generated context pack for Revision 152. | `out/context_pack.md` | Regenerate with `make context-pack` |

## Revision 152 evidence hooks

- **EVID-VIEWFS-152-001** — Semantic derivation seam review: future proposals must classify whether they affect extraction intent, source input capsule, extractor/model profile, derived artifact, index/store membership, query scope, result projection, answer card, live authority, or receipts.
- **EVID-VIEWFS-152-002** — Embedding sensitivity tests: vector rows, chunk embeddings, sparse vectors, summaries, OCR text, and assistant memories inherit source risk/secrecy unless a specific proof and policy downgrade exists.
- **EVID-VIEWFS-152-003** — Scope-before-search tests: semantic queries must be bounded by current handles/roots/import collections before metadata filters or ANN ranking refine the result set.
- **EVID-VIEWFS-152-004** — Result projection tests: snippets, thumbnails, highlights, answer quotes, and preview cards must respect projection policy and must not create live source authority.
- **EVID-VIEWFS-152-005** — Inert retrieved-instruction tests: text retrieved from sources cannot execute commands, request secrets, mutate namespaces, or call tools without a separate plan/approval/action lane.
- **EVID-VIEWFS-152-006** — Forget/unindex tests: removing vectors, derived artifacts, answer caches, source objects, provider rows, and receipts are distinct operations with explicit cleanup posture.
| EVID-2026-307 | E0 | One-hundred-fifty-third ViewFS datacube archive revision refining instruction/prompt/agent hygiene: instruction source records, trust/priority labels, context frames, model/prompt profiles, proposal text, typed action plans, tool invocation candidates, approval cuts, current live authority, result/observation lanes, and receipts stay distinct. | `ViewFS-rev0153-2026.05.18.*-instructionrails-contextshutters-toolfuses-rubyowl.zip` | Research + instruction/prompt/toolcall authority seam revision |
| EVID-2026-308 | E0 | Generated context pack for Revision 153. | `out/context_pack.md` | Regenerate with `make context-pack` |

## Revision 153 evidence hooks

- **EVID-VIEWFS-153-001** — Instruction-source seam review: future proposals must classify whether they affect instruction source records, trust/priority labels, context frames, model/prompt profiles, proposal text, action plans, tool invocation candidates, approval cuts, live authority, result lanes, or receipts.
- **EVID-VIEWFS-153-002** — Retrieved-instruction inertness tests: retrieved/quoted/imported text cannot request secrets, exfiltrate data, mutate namespaces, call tools, install helpers, save memory, or alter policy without a separate typed plan and approval.
- **EVID-VIEWFS-153-003** — Tool-description non-authority tests: tool descriptions, annotations, schemas, examples, and marketplace text cannot mark a call read-only/idempotent/safe or bypass a toolcall fuse and local validator.
- **EVID-VIEWFS-153-004** — Context exposure tests: including snippets/resources/tool manifests in model context must not grant live source/tool/file/secret/network authority.
- **EVID-VIEWFS-153-005** — Workspace instruction scope tests: workspace, parent-repo, package, profile, and org instructions need visible source/scope/trust labels and cannot silently widen a child room.
- **EVID-VIEWFS-153-006** — Receipt non-revival tests: old prompt/context/approval/tool-result receipts cannot rerun prompts, seed memory, import old tool outputs as current truth, or reapprove effects without fresh gates.

| EVID-2026-309 | E0 | One-hundred-fifty-fourth ViewFS datacube archive revision refining trusted-path / volition / consent hygiene: consent candidates, canonical summaries, presentation surfaces, trusted-path posture, gesture evidence, volition witnesses, approval cuts, live authority, outcomes, and receipts stay distinct. | `ViewFS-rev0154-2026.05.18.20.28-volitioncards-trustedpaths-consentfences-jadegate.zip` | Research + human-consent/trusted-path seam revision |
| EVID-2026-310 | E0 | Generated context pack for Revision 154. | `out/context_pack.md` | Regenerate with `make context-pack` |

## Revision 154 evidence hooks

- **EVID-VIEWFS-154-001** — Consent-seam review: future high-risk action proposals must classify candidate, canonical summary, presentation surface, trusted-path posture, gesture evidence, volition witness, approval cut, live authority, outcome, and receipt lanes.
- **EVID-VIEWFS-154-002** — Summary-binding tests: volition/approval material must fail closed if action digest, summary digest, target, authority delta, or policy profile changes.
- **EVID-VIEWFS-154-003** — Presentation-source tests: app-rendered, web-embedded, model-rendered, notification-only, remote-captured, and ordinary-focused surfaces cannot issue high-risk ViewFS approvals unless an explicit profile says so.
- **EVID-VIEWFS-154-004** — Gesture-consumption tests: one fresh gesture or activation token cannot approve multiple stronger plans, survive expiry, or be replayed from history.
- **EVID-VIEWFS-154-005** — Presence/verification distinction tests: authenticator presence or user verification can satisfy only the evidence class named by policy and cannot silently imply action-specific consent.
- **EVID-VIEWFS-154-006** — Receipt non-revival tests: consent, volition, and approval receipts cannot reapprove, reconnect, re-export, release secrets, or mint live authority without fresh gates.
| EVID-2026-311 | E0 | One-hundred-fifty-fifth ViewFS datacube archive revision consolidating the executable core schema, proof-obligation index, fixture corpus, registry/RFC lint gates, companion seam intake, and embedded SlopOS rev0720 refresh. | `ViewFS-rev0155-2026.05.21.11.44-executablespine-proofobligations-fixturecorpus-jadebridge.zip` | Research + executable-spine seam revision |
| EVID-2026-312 | E1 | Checked ViewFS core v0 fixture corpus covering portal import, view pathwalk, receipt non-authority, digest non-authority, path escape, semantic-card non-authority, consent denial, approval-cut allowance, and derived-artifact non-retention. | `fixtures/viewfs-core-v0/`; `tools/check_viewfs_core_fixtures.py` | Run with `make fixtures` or `make lint` |
| EVID-2026-313 | E1 | Registry and RFC-number hygiene gates preventing duplicated assurance IDs and duplicated RFC numeric prefixes. | `tools/check_registry_ids.py`; `tools/check_rfc_numbers.py` | Run with `make lint` |
| EVID-2026-314 | E0 | Generated context pack for Revision 155. | `out/context_pack.md` | Regenerate with `make context-pack` |

## Revision 155 evidence hooks

- **EVID-VIEWFS-155-001** — Core schema seam review: future proposals must classify whether they affect object cores, object refs, handles, live facets, view roots, binds, portal grants, compat pathwalks, derived artifacts, instruction frames, consent chains, or receipts.
- **EVID-VIEWFS-155-002** — Authority-carrier tests: only current live handles or live facets with matching rights may authorize effects.
- **EVID-VIEWFS-155-003** — Non-authority decoy tests: paths, digests, refs, receipts, answer cards, prompt text, gesture evidence, and old approvals must fail closed without a current grant/approval/handle conversion.
- **EVID-VIEWFS-155-004** — Companion-drift tests: embedded companion revisions should be version-visible, and ViewFS should record when SlopOS pressure is imported as proof posture rather than as a semantic dependency.
- **EVID-VIEWFS-155-005** — Promotion-gate tests: no new noun should be promoted without at least one positive specimen, one negative specimen, one shell representation, one assurance hook, and one companion-seam note.


## Revision 156 evidence hooks

- **EVID-VIEWFS-156-001** — Fixture corpus expanded from 8 to 20 checked specimens, including handle attenuation, mutable commit cuts, stale-base denial, restore-token death verdicts, explicit retention roots, prompt/action-plan toolcall boundaries, portal grant replay, and revoked-handle inertness.
- **EVID-VIEWFS-156-002** — Proof-obligation coverage gate: `tools/check_proof_fixture_coverage.py` fails when fixture-coverable proof obligations lack specimen coverage or fixtures cite unknown proof IDs.
- **EVID-VIEWFS-156-003** — Mutable-state witness: `docs/30-architecture/mutable-anchor-commit-cut-v0.md` plus `011`/`012` fixtures keep journals, observed bases, commit cuts, and receipts separate.
- **EVID-VIEWFS-156-004** — Revocation/retention witness: `docs/30-architecture/revocation-stale-brakes-and-retention-roots-v0.md` plus `013`, `014`, `015`, and `020` fixtures keep death verdicts, stale brakes, retention roots, and receipt ghosts separate.
- **EVID-VIEWFS-156-005** — Agentic-action witness: `docs/30-architecture/action-plan-toolcall-lane-v0.md` plus `016`/`017` fixtures keep prompt text, model proposal, typed action plan, approval cut, live authority, and receipt separate.
- **EVID-VIEWFS-156-006** — Research synthesis pass CLW records ambient-rights, persistent-token, MCP/LLM agency, and lifecycle-state pressure for the new hardening fixtures.

| EVID-2026-315 | E0 | One-hundred-fifty-seventh ViewFS datacube archive revision hardening resolver, delegation, shell-card, and derived-cleanup fixture lanes. | `ViewFS-rev0157-2026.05.21.*-resolverdelegation-shellhonesty-copyinventories-*.zip` | Research + executable fixture hardening revision |
| EVID-2026-316 | E1 | Resolver conformance fixtures distinguish symlink, magic/synthetic, and mount/provider crossing denial under explicit compat pathwalk flags. | `021-compat-symlink-crossing-denied.json`; `022-compat-magic-link-crossing-denied.json`; `023-compat-mount-crossing-denied.json` | Run with `make fixtures` or `make lint` |
| EVID-2026-317 | E1 | Delegation and shell-card honesty fixtures prevent widened delegated rights, revoked delegation reuse, and receipt-as-live-authority card laundering. | `024`-`028` fixtures; `tools/check_viewfs_core_fixtures.py` | Run with `make fixtures` or `make lint` |
| EVID-2026-318 | E1 | Derived cleanup fixtures deny source forgetting while local derived artifacts remain live and allow it after explicit minimization/deletion accounting. | `029-forget-source-derived-live-denied.json`; `030-forget-source-derived-minimized-allow.json` | Run with `make fixtures` or `make lint` |

## Revision 157 evidence hooks

- **EVID-VIEWFS-157-001** — Resolver conformance witness: `docs/30-architecture/resolver-conformance-v0.md` plus fixtures `021`-`023` keep path escape, symlink crossing, magic/synthetic crossing, mount crossing, missing bind, and missing right as distinguishable denial lanes.
- **EVID-VIEWFS-157-002** — Delegation witness: `docs/30-architecture/delegation-chain-and-shell-card-honesty-v0.md` plus fixtures `024`-`026` keep delegation intent, source handle, child handle, attenuation envelope, lease, revocation wavefront, and receipt history separate.
- **EVID-VIEWFS-157-003** — Shell-card honesty witness: fixtures `027`-`028` require authority badges to match backing live handles and require receipt-history cards to remain inert unless a live slot exists.
- **EVID-VIEWFS-157-004** — Derived cleanup witness: `docs/30-architecture/derived-artifact-cleanup-ledger-v0.md` plus fixtures `029`-`030` require explicit cleanup states before local forget-complete claims.
- **EVID-VIEWFS-157-005** — Research synthesis pass CLX records Linux `openat2`, WASI descriptor-relative paths, File System Access handle/persistence pressure, SLSA provenance analogy, and companion cube pressure for this hardening pass.

| EVID-2026-319 | E0 | One-hundred-fifty-eighth ViewFS datacube archive revision hardening quarantine, trust-transition, authority-diff, export-plan, and generated conformance-report lanes. | `ViewFS-rev0158-2026.05.21.*-quarantineauthdiff-exportplans-conformancereports-*.zip` | Research + executable fixture hardening revision |
| EVID-2026-320 | E1 | Quarantine/trust-transition fixtures deny direct open, allow safe-viewer read-only inspection, allow verified clean policy release, and deny summary/receipt-only trust release. | `031`-`034` fixtures; `tools/check_viewfs_core_fixtures.py` | Run with `make fixtures` or `make lint` |
| EVID-2026-321 | E1 | Authority-diff fixtures require gained/lost rights to be declared and require widening to be visibly badged. | `035`-`037` fixtures; `tools/check_viewfs_core_fixtures.py` | Run with `make fixtures` or `make lint` |
| EVID-2026-322 | E1 | Export-plan fixtures block quarantined-source export, allow cleared approved export, and deny old export receipt replay. | `038`-`040` fixtures; `tools/check_viewfs_core_fixtures.py` | Run with `make fixtures` or `make lint` |
| EVID-2026-323 | E1 | Generated conformance report summarizing fixture operations, modes, denial reasons, and proof coverage. | `tools/build_conformance_report.py`; `out/conformance_report.md` | Run with `make conformance-report` or `make lint` |

## Revision 158 evidence hooks

- **EVID-VIEWFS-158-001** — Quarantine witness: `docs/30-architecture/quarantine-trust-transition-v0.md` plus fixtures `031`-`034` keep origin evidence, quarantine mark, safe viewer, trust transition, live handle, and receipt separate.
- **EVID-VIEWFS-158-002** — Authority-diff witness: `docs/30-architecture/authority-diff-and-export-plan-v0.md` plus fixtures `035`-`037` make hidden widening a denial case.
- **EVID-VIEWFS-158-003** — Export witness: fixtures `038`-`040` keep typed export plan, approval cut, sink, quarantine clearance, live export authority, and receipt separate.
- **EVID-VIEWFS-158-004** — Conformance-report witness: `docs/40-verification/conformance-reporting-v0.md`, `tools/build_conformance_report.py`, and `out/conformance_report.md` make fixture/proof drift visible in generated markdown.
- **EVID-VIEWFS-158-005** — Research synthesis pass CLY records TUF freshness/rollback pressure, SLSA provenance separation, Sigstore/Rekor transparency-history pressure, OCI sidecar/referrer pressure, WASI descriptor access, and OpenTelemetry generated-report posture.


## Revision 160 executable distributed-state evidence

- `fixtures/viewfs-core-v0/055-lease-renewal-current-allow.json` through `076-journal-checkpoint-receipt-replay-denied.json` add distributed-currentness specimens.
- `tools/check_viewfs_core_fixtures.py` evaluates lease renewal, offline branch publish, merge reconciliation, remote attestation verification, freshness fences, and journal checkpoints.
- `tools/build_freshness_trace_report.py` derives `out/freshness_trace_report.md` from checked fixtures.
- `docs/40-verification/proof-obligations-v0.md` adds lease, offline, merge, attestation, freshness, and checkpoint proof obligations.

## Revision 172 evidence hooks

- **EVID-VIEWFS-172-001** — Governance/change-management fixture lane: fixtures `385`-`420` cover change proposals, decision records, approval quorums, rollout plans, feature flags, deprecation notices, compatibility contracts, migration runs, and governance-card honesty.
- **EVID-VIEWFS-172-002** — Governance trace report: `tools/build_governance_trace_report.py` generates `out/governance_trace_report.md` from checked fixtures.
- **EVID-VIEWFS-172-003** — Fixture catalog audit: `tools/check_fixture_catalog.py` enforces contiguous numbering, mode suffix discipline, unique fixture names, operation presence, and proof-obligation links.
- **EVID-VIEWFS-172-004** — Fixture catalog report: `tools/build_fixture_catalog_report.py` generates `out/fixture_catalog_report.md`, listing every fixture, operation, mode, and proof fan-in.
- **EVID-VIEWFS-172-005** — Catalog refactor witness: `tools/fixture_catalog.py` is shared by fixture-catalog, proof-coverage, and operation-balance tooling so those gates use the same corpus view.

## Revision 176 evidence hooks

- **EVID-VIEWFS-176-001** — Host-adapter fixture lane: fixtures `529`-`568` cover adapter mounts, stat projections, inode aliases, xattr parcels, watcher subscriptions, lock tokens, rename plans, tempfile leases, hydration tickets, and external-app handoff.
- **EVID-VIEWFS-176-002** — Host-adapter trace report: `tools/build_host_adapter_trace_report.py` generates `out/host_adapter_trace_report.md` through the shared report registry.
- **EVID-VIEWFS-176-003** — Operation-catalog audit: `tools/check_operation_catalog.py` checks evaluator/fixture/proof consistency for every checked operation.
- **EVID-VIEWFS-176-004** — Operation-catalog report: `tools/build_operation_catalog_report.py` generates `out/operation_catalog_report.md`, listing operations, evaluator presence, positive/negative counts, proof obligations, and first fixture evidence.
- **EVID-VIEWFS-176-005** — Operation-balance refactor witness: `tools/check_fixture_operation_balance.py` now uses `tools/operation_catalog.py` rather than separately loading fixture state.

## Revision 176 host-adapter references

- **REF-LINUX-FUSE-KERNEL** — Linux kernel documentation, *FUSE* — https://www.kernel.org/doc/html/next/filesystems/fuse.html
  - key: FUSE is a userspace filesystem framework with a kernel module, userspace library, and mount utility.
  - why: ViewFS host compatibility may need a userspace filesystem projection.
  - us: a FUSE-like mount is a projection/admission row, not ambient ViewFS root authority.
- **REF-LINUX-INODE-STATX** — Linux man-pages, *inode(7)* and *statx(2)* — https://man7.org/linux/man-pages/man7/inode.7.html / https://man7.org/linux/man-pages/man2/statx.2.html
  - key: inode/stat metadata exposes object metadata through host APIs.
  - why: ViewFS needs stat projections for legacy tools.
  - us: metadata projections do not grant read authority and may hide fields.
- **REF-LINUX-INOTIFY** — Linux man-pages, *inotify(7)* — https://man7.org/linux/man-pages/man7/inotify.7.html
  - key: watches monitor pathname/file events and deliver event notifications.
  - why: compatibility observers will expect change events.
  - us: watcher events notify; they do not open objects or refresh authority.
- **REF-LINUX-XATTR** — Linux man-pages, *xattr(7)* — https://man7.org/linux/man-pages/man7/xattr.7.html
  - key: extended attributes are name/value pairs associated with files/directories.
  - why: xattrs often carry policy-looking data.
  - us: xattr parcels are metadata, not policy/classification/disclosure authority.
- **REF-LINUX-FCNTL-LOCKING** — Linux man-pages, *fcntl_locking(2)* — https://man7.org/linux/man-pages/man2/fcntl_locking.2.html
  - key: record locks are advisory by default and useful only among cooperating processes.
  - why: locks are coordination facts, not universal enforcement.
  - us: lock tokens require target authority and do not grant write authority.
- **REF-POSIX-RENAME** — The Open Group, *rename()* — https://pubs.opengroup.org/onlinepubs/9799919799/functions/rename.html
  - key: rename changes the name of a file and has strong compatibility expectations.
  - why: legacy atomic-write patterns often rely on rename after tempfile writes.
  - us: rename plans, tempfiles, and completion receipts remain separate.
- **REF-WINDOWS-PROJFS** — Microsoft Learn, *Windows Projected File System* — https://learn.microsoft.com/en-us/windows/win32/projfs/projected-file-system
  - key: a user-mode provider projects hierarchical backing data into the file system.
  - why: projection/hydration is a core host-adapter pressure.
  - us: placeholder and hydration state is not native authority.
- **REF-APPLE-FILEPROVIDER** — Apple Developer Documentation, *File Provider* — https://developer.apple.com/documentation/fileprovider
  - key: File Provider extensions host and manage files accessed through the extension.
  - why: host-file-provider APIs blend remote storage, placeholders, and app access.
  - us: external handoff and hydration need explicit authority and redaction gates.
