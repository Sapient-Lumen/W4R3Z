# Research synthesis 2026-05-26 pass CMP

Revision 175 adds schema/ontology interoperability and record-family catalog audits.

External pressure:

- RDF emphasizes graph-oriented data interchange and schema evolution across differing schemas; ViewFS borrows the interchange lesson without treating graph identity as authority.
- JSON-LD contexts and IRIs help expand names and connect linked data; ViewFS treats context expansion as a namespace fact, not as policy or object authority.
- URI generic syntax defines identifiers and reference resolution, but ViewFS keeps URI/reference resolution separate from possession, disclosure, and live handles.
- SKOS, OWL, and ontology practice make vocabulary and semantic-alignment work powerful; ViewFS requires review/confidence gates and denies inferred authority.
- SHACL validates RDF data graphs against shapes graphs; ViewFS treats validation as evidence, not approval or use permission.
- DCAT is designed to facilitate data-catalog interoperability; ViewFS keeps catalog entries separate from raw payload disclosure and public-release approval.
- PROV-O/PROV-DM reinforce the distinction between entities, activities, agents, derivation, and responsibility; ViewFS applies that posture to schema/crosswalk evidence and cards.

Speculative guidance:

ViewFS should be willing to export/import linked metadata later, but only through a membrane that preserves live authority and retention boundaries. A future adapter can speak JSON-LD, RDF, DCAT, or SKOS externally while keeping internal authority expressed as ViewFS handles, grants, cuts, receipts, and shell cards.
