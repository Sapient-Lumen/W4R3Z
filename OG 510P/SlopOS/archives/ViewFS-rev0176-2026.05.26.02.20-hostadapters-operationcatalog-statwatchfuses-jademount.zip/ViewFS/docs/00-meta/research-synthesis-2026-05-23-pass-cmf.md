# Research synthesis 2026-05-23 pass CMF

Pass CMF added resource, quota, background-job, cache, capacity-signal, and metering gates.

External pressure considered:

- Linux cgroup v2 separates resource distribution controls such as weights, limits, protections, and allocations rather than treating resource accounting as one permission bit.
- Kubernetes distinguishes resource requests and limits and schedules/evicts based on resource pressure rather than equating a pod spec with limitless runtime capacity.
- systemd resource-control settings show that process/service resource policy is a separate operational envelope from program identity or filesystem access.
- Browser storage/quota and timing work illustrates that capacity and timing surfaces can be privacy/side-channel surfaces, not harmless metadata.
- Cloud/task-queue systems make a similar distinction between queued work, lease/visibility timeout, retry, and completed receipt; ViewFS should not let queued rows execute after authority drift.

Speculative conclusion: ViewFS should eventually expose a resource HUD beside authority, policy, provenance, and freshness HUDs. The HUD must be intentionally lossy for shared/multi-principal scopes, because exact capacity can reveal membership, active work, or hidden objects.
