# Research synthesis — 2026-05-22 pass CMB

Revision 161 pressure came from treating observability, eventing, privacy requests, and verifiable packaging as leak-prone authority-adjacent surfaces.

- OpenTelemetry logs pressure ViewFS to treat logs and events as structured records with attributes, timestamps, resources, and trace context, not as opaque text blobs. The ViewFS lesson is that structured observability is useful but can become a disclosure channel.
- CloudEvents pressure ViewFS to separate event context attributes from event data. The ViewFS lesson is that event envelopes can often be routed and inspected without revealing payload bytes, but the envelope is still not object authority.
- W3C Verifiable Credentials pressure ViewFS to distinguish credential/package claims, proofs, subjects, issuers, and verifiers. The ViewFS lesson is that a tamper-evident package can support verification but does not by itself authorize raw data release.
- Data-protection access/erasure rights pressure ViewFS to make subject-facing exports and erasure/forgetting ledgers explicit. The ViewFS lesson is not to claim legal compliance, but to keep subject, scope, redaction, review, disclosure, and receipt states separate.
- Schell pressure remains central: redaction, minimization, and forgetting are not just labels; they need copy inventories and retention posture.
- Harbor pressure remains central: publication and stale surfaces require recheck windows and explicit correction receipts.
- Ward pressure remains central: subject-access and breakglass/disclosure review need steward/accountability lanes rather than hidden admin bypasses.

The concrete result is `DisclosurePackage`, `RedactionView`, `AuditProjection`, `SubscriptionCursor`, `NotificationEnvelope`, and `SubjectAccessRequest` in the fixture checker, plus a generated disclosure trace report.
