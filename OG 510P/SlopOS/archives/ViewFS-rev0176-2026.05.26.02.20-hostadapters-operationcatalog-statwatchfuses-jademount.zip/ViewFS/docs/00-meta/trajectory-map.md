# Trajectory map

## North-star sentence
ViewFS is a **capability-native namespace and object layer** for SlopOS, not a traditional host-global filesystem.

## What should be stable early
- immutable-first backing store
- explicit handles with attenuable rights
- per-process synthetic root views
- portal-mediated import/export
- compatibility as a membrane
- explicit receipts and transcript-visible authority changes
- clear separation between grouped authority, namespace fragments, live binds, and child launch kits
- clear separation between mediated request objects, chooser-owned candidate sets, selected outcomes, minted grants/refs, and live binds
- clear separation between user intent, prepared plans, approval checkpoints, committed execution, and result receipts
- clear separation between suggested automation, promoted user-owned workflows, prepared run plans, committed runs, and history receipts
- clear separation between lend requests, live borrowed authority, durable delegated refs, issuer-side recall/expiry controls, and loan-end receipts
- clear separation between reuse candidates, exact basis records, drift checks, reconsent checkpoints, renewed artifacts, and reuse receipts
- clear separation between witness packs, caveat sets, freshness tokens, why-records, and durable receipts
- clear separation between validation/schema material, authoritative policy/caveat material, shell advice rails, per-decision diagnostics, and durable logs/receipts
- clear separation between policy-family/catalog choice, exact authoritative cuts/consistency posture, fallback candidates, repair proposals, and selection receipts/history
- clear separation between proposal origins/sources, proposal lanes/scopes, escalation requests, authoritative adoptions, and adoption receipts/history
- clear separation between deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and adoption receipts/history
- clear separation between author classes, carrier/container classes, trust gates, advisory-only helper sources, effective active state, and durable receipts/history
- clear separation between protected-authorable state, carrier/discovery presence, invoke-only helper material, trust-gated adoption lanes, effective active state, and durable receipts/history
- clear separation between publisher trust, installed helper packages, configured helper/server definitions, enabled state, start approvals, live brokered sessions, request-scoped tool selections, and durable receipts/history
- clear separation between helper-exposed resource descriptors, prompt templates, tool descriptors, app surfaces, completion suggestions, request-bound attachments/selections, live invocations/results, and durable receipts/history
- clear separation between immediate requests, accepted task wrappers, live progress/status streams, input-required checkpoints, deferred final results, and durable receipts/history
- clear separation between close/cancel acts, force termination, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipts/history
- clear separation between read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable transcripts/history
- clear separation between exact object identity, current placement in a view, current handle-rights posture, advertised operations, and durable receipts/history

## What should stay open longer
- exact on-disk pack format
- hash algorithm choice
- mutable transaction model
- live revocation mechanics
- distributed sync / replication
- query engine and indexing strategy
- shell language syntax
- final host-side backstop policy
- exact stored schema for bundles, fragments, and launch kits
- exact request/candidate/selection/grant/result schema for mediated imports
- exact intent/plan/approval/result schema for prepared actions
- exact suggestion/promotion/workflow/run schema for saved automation
- exact loan/delegated-ref/recall/expiry schema for borrowed authority
- exact reuse/basis-record/drift-check/reconsent/renewal schema for replay and renewal flows
- exact witness/caveat/freshness/why-record schema for decision explanation and replay inspection flows
- exact validation/policy/advice/diagnostic/log schema for policy-aware shell and replay flows
- exact policy-family/catalog, cut/consistency, fallback, repair, and selection-receipt schema for judge-selection flows
- exact proposer/source, proposal-lane/scope, escalation, adoption, and adoption-receipt schema for helper-lane and judge-switch proposals
- exact deny-ceiling, scope-eligibility, narrowing-transform, escalation-attempt, and adoption-receipt schema for scope-control proposals
- exact author-class, carrier/container, trust-gate, advisory-only-rail, and activation-receipt schema for source-admissibility proposals
- exact protected-state, invoke-only-helper, authorability-matrix, adoption-lane, and invoke/adopt-receipt schema for protected-authorability proposals
- exact publisher-trust, install/config, enablement, start-approval, live-session, request-selection, and lifecycle-receipt schema for helper-lifecycle proposals
- exact resource/prompt/tool/app/completion, request-binding, invocation/result, and durable-receipt schema for helper-feature proposals
- exact immediate-request, task-wrapper, progress/status, input-checkpoint, final-result, and durable-receipt schema for deferred-work proposals
- exact close/cancel, terminate, detach/delete, retry-fresh, reset/fork/attach, and durable-receipt schema for deferred-control proposals
- exact observe/query/follow, interactive attach, control-message, exec/debug, sideband, and durable-transcript schema for live-session proposals
- exact placement, rights-summary, advertised-affordance, and action-availability schema for object-action surfaces
- whether names, immutable IDs, mutable heads, and durable grants should ever collapse into a single primitive
- quarantine / origin / safe-open semantics beyond the minimal anti-collapse rule

## What we should prototype before we decide
- preopen-style compat membrane over a synthetic view root
- chooser/open/save receipt flow with bounded persistence
- host-side backstops and ambient-debt markers that stay visibly subordinate to ViewFS semantics
- block-oriented shell transcript with semantic zones and clickable receipts
- workspace/tree grant and rebind prototype distinct from recents and OpenURI
- mutable work-session sidecar over immutable objects
- view-scoped search / smart-folder behavior over explicit handles only
- launch rehearsal and bind-vs-launch diff UX over explicit kits/fragments only
- chooser-sheet plus staging-tray UX over explicit request/result/grant classes
- prepare-versus-commit route-plan UX over explicit intent/plan/approval/result classes
- suggest-versus-promote workflow UX over explicit suggestion/workflow/plan/run classes
- lend-versus-promote authority UX over explicit request/borrow/ref/recall/receipt classes
- basis-diff plus reconsent-ladder UX over explicit reuse/basis/drift/reconsent/renewal classes
- witness-drawer plus why-panel UX over explicit witness/caveat/freshness/explanation classes
- policy-lens plus advice-rail UX over explicit validation/policy/advice/diagnostic/log classes
- policy cut picker plus fallback rail UX over explicit family/cut/fallback/repair/selection-receipt classes
- proposer badge plus escalation ladder UX over explicit source/lane/escalation/adoption/adoption-receipt classes
- ceiling pill plus narrowing preview UX over explicit ceiling/eligibility/narrowing/escalation/adoption-receipt classes
- author badge plus carrier tag plus advisory-rail UX over explicit author/carrier/gate/advisory/effective-state classes
- protected chip plus matrix drawer plus latched-invoke UX over explicit protected-state/invoke-only/adoption-lane/effective-state classes
- publisher badge plus start gate plus live-session beacon plus tool rack UX over explicit publisher/install/config/enable/start/live/select classes
- resource shelf plus prompt chip plus tool rack plus app dock UX over explicit feature-class/completion/binding/invocation/receipt classes
- task badge plus progress lane plus input-required drawer plus result locker UX over explicit request/task/progress/input/result/receipt classes
- stop ladder plus detach rail plus retry-vs-fork drawer UX over explicit close/cancel/terminate/detach/retry/reset/receipt classes
- follow tail plus attach rail plus control pane plus sideband badge UX over explicit observe/attach/control/debug/tunnel/transcript classes
- place card plus verb ledger plus affordance lens UX over explicit identity/placement/rights/advertised-verb classes
- origin badges and safe-open ladders that preserve recency/history truth


- Keep session-state memory, journals, notebooks, and replay aids clearly separate from live authority while the shell UX grows richer.
- Keep indexes, recents, and selector registries clearly advisory instead of letting search surfaces become authority by accident.

## Revision 141 trajectory note
Object-store liveness is now tracked as a first-class trajectory: durable roots, live-handle roots, pin/hold/lease records, sweep candidates, finalizers, collected ash, live facets, and receipts should evolve separately until real prototypes prove which layers need a shared schema.

## Revision 144 trajectory note

The trajectory now includes supply-chain evidence/admission hygiene. The next object-store/capability-handle design should treat SBOM/VEX/provenance material as evidence lanes that can support local admission, not as object identity, fetch authority, trust clearance, retention roots, or live handles.


## Revision 151 trajectory note

Content addressing is still a north-star substrate technique, but the stable early truth should be narrower: exact proof/address profiles are evidence, while dedup/cache/materialization policy stays distinct from object identity, trust, membership, retention, and live authority.


## Revision 152 trajectory note

Semantic search is now a first-class trajectory, but the stable early truth is narrow: semantic artifacts are derived views over scoped authority, not a second root of authority. Index participation, vector-store membership, result rendering, answer composition, and memory persistence need their own labels before ViewFS chooses any native embedding/index substrate.
## Revision 153 trajectory note

Instruction hygiene is now a first-class trajectory. The stable early truth is narrow: prompt-like material and model output can propose and explain, but effectful behavior must pass through typed plans, explicit approvals, and current live authority. This keeps agentic ViewFS UX possible without letting retrieved text, workspace instructions, tool descriptions, or old receipts become an ambient authority plane.

## Revision 154 trajectory note

Consent hygiene is now a first-class trajectory. The stable early truth is narrow: high-risk ViewFS effects should flow through typed consent candidates, canonical summaries, explicit presentation/trusted-path posture, fresh gesture/volition evidence when policy requires it, approval cuts, and current live authority. This keeps delightful agentic approval UX possible without letting clicks, focus, prompt replies, helper widgets, remote screens, authenticator touches, or old receipts become ambient authority.
## Revision 155 trajectory note

Executable evidence is now a first-class trajectory. ViewFS should keep adding anti-collapse seams only when they are paired with specimens and checker/proof obligations. The stable early truth is narrower than the prose archive: object cores, handles, view binds, portal grants, compat pathwalks, derived artifacts, consent chains, live facets, and receipts are the first executable vocabulary. Everything else remains design pressure until a fixture proves it earns promotion.


## Revision 156 trajectory note

Lifecycle evidence is now part of the executable trajectory. ViewFS should keep mutable work, revocation, stale brakes, retention roots, portal replay, and prompt/tool invocation inside the same boring fixture discipline as paths and receipts. The stable early truth is now: no-widen handle attenuation, current-base commit cuts, restore-token death verdicts, explicit retention roots, typed action plans, and proof-obligation coverage. Richer shell cards and distributed semantics should follow only after these lanes stay falsifiable.

## Revision 157 trajectory note

Resolver conformance, delegation custody, shell-card honesty, and derived cleanup are now first-class executable lanes. The stable early truth is narrow: path resolution failures must be typed, delegated rights must not widen, shell projections must have backing records, and local forgetting must account for local derived artifacts. The exact kernel/runtime ABI, final shell card grammar, distributed delegation protocol, and unlearning algorithm remain open.

## Revision 158 trajectory note

Quarantine, trust transition, authority-diff, export-plan, and generated conformance reporting are now first-class trajectories. The stable early truth is narrow: foreign-origin evidence and sidecars can inform admission, but only explicit cuts and live handles authorize; shell cards may explain rights changes, but hidden widening is a denial; exports are typed egress plans, not replayable receipts or generic share labels. The next pressure point is stale evidence and sink-specific revalidation.


## Revision 160 trajectory addition

Rev160 moves ViewFS from local authority anti-collapse toward distributed-currentness anti-collapse: currentness is now modeled as bounded evidence with expiry, uncertainty, epoch, and revocation posture.
