# Research synthesis 2026-05-26 pass CMQ — host-adapter compatibility

This pass looked at operating-system filesystem adapter pressure and converted it into ViewFS anti-collapse fixtures.

- Linux `stat`/`statx` and inode metadata pressure suggests ViewFS needs explicit stat projections, but those projections cannot become complete object truth or read authority.
- Linux inotify pressure suggests file-change events are useful but path/event watches must remain notification surfaces, not authority refreshes.
- Linux extended attributes pressure suggests host metadata names are powerful enough to carry policy-looking data, so ViewFS must keep xattr parcels separate from policy, classification, and disclosure authority.
- POSIX/Linux advisory locks pressure suggests lock state coordinates cooperating writers, but does not grant write authority and cannot make non-cooperating effects impossible.
- POSIX/Linux rename pressure suggests atomic replacement expectations matter, but ViewFS must keep pending rename plans, cross-mount restrictions, commit cuts, and completion receipts separate.
- FUSE, Windows ProjFS, and Apple File Provider pressure all point toward projected/hydrated filesystems that are extremely useful for compatibility but dangerous if projection state, hydration state, or host-visible placeholders are treated as native authority.

The resulting revision adds adapter mount, stat projection, inode alias, xattr parcel, watcher subscription, lock token, rename plan, tempfile lease, hydration ticket, and external app handoff fixtures. It also adds an operation-catalog audit so the growing checker surface has a generated index.
