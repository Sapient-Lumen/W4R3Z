# Research synthesis — pass CMA — freshness, leases, merge, and attestations

Revision 160 takes pressure from distributed filesystems, local-first collaboration, content addressing, verifiable status lists, distributed clocks, write-ahead logs, and data-merge systems.

- NFSv4 delegation/stateid behavior shows that leases and delegated state can become invalid or stale after partition or recall; ViewFS therefore treats lease renewal and reacquisition as current-state checks, not receipt replay. Source: RFC 8881, especially lease expiration, stale stateids, and delegation recall sections.
- Automerge/local-first systems demonstrate that offline work and eventual convergence are desirable, but ViewFS still needs explicit publish/revalidation gates so local commits do not become publish authority. Source: Automerge project overview.
- IPFS CIDs reinforce that content-addressed labels name content, not location, possession, trust clearance, or authority. Source: IPFS CID documentation.
- W3C bitstring status lists illustrate a compact status/revocation side channel for credentials, with the subtlety that status applies to the credential/status object rather than all underlying facts. ViewFS mirrors this by making remote attestations evidence-only and subject-bound.
- Spanner TrueTime exposes clock uncertainty as a first-class factor in external consistency. ViewFS does not adopt TrueTime, but it borrows the lesson that freshness is bounded evidence rather than a raw timestamp.
- SQLite WAL separates append/commit/checkpoint and shows that checkpointing is a distinct operation with durability and concurrency consequences. ViewFS mirrors that by separating journal commit, checkpoint finalization, and receipt history.
- Dolt merge conflicts make conflict rows explicit and require further action when automated merge cannot infer a result. ViewFS uses merge plans, resolution cuts, and witnesses so merge receipts cannot launder unresolved conflicts.

The speculative rule for future ViewFS work: every distributed artifact should carry a `currentness horizon` and a `replay posture`. If the horizon is expired, mismatched, uncertain, or revoked, shell cards must render denial and repair paths rather than stale green affordances.
