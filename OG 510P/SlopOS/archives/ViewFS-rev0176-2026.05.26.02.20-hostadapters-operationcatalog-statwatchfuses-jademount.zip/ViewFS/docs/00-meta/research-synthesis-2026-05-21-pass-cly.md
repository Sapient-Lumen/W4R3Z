# Research synthesis 2026-05-21 pass CLY — quarantine, authority diffs, export, and conformance reporting

Revision 158 focuses on making foreign-origin import, trust transition, authority diff, export, and conformance reporting executable in the v0 fixture spine.

## TUF pressure: freshness, rollback, and freeze humility

The Update Framework's threat model is useful because it treats stale or inconsistent metadata as a security problem, not just an availability problem. ViewFS should borrow the posture, not the update roles wholesale: a quarantine/trust transition must make staleness, replay, and mix-and-match evidence visible. A cached clean verdict or old receipt should degrade to reviewed/quarantined unless a current policy cut admits it.

ViewFS consequence: trust transition fixtures should eventually include stale verdict, rollback evidence, and mismatched-evidence cases. Revision 158 starts smaller by denying summary/receipt evidence and direct opens from quarantine.

## Supply-chain attestation pressure: subject/evidence separation

SLSA provenance and in-toto-style attestations separate subject, build definition, run details, builder identity, parameters, dependencies, and byproducts. That separation is a useful analogy for ViewFS origin evidence: a signed statement, scanner result, transparency entry, SBOM, and local admission decision are different records. None should become live authority by itself.

ViewFS consequence: `OriginEvidence` is intentionally not a handle. It supports a `TrustTransition` only when paired with verdict and policy cut.

## Transparency-log pressure: history is not authority

Sigstore/Rekor-style transparency logs provide tamper-evident history. That is powerful, but history must not become current permission. A transparency entry can help decide whether to trust a package or artifact, but ViewFS still needs a local admission/trust transition and live handle before use.

ViewFS consequence: the `trust_transition_summary_only_denied` fixture refuses to treat summary/receipt-like evidence as verifying origin evidence.

## OCI/referrers pressure: artifacts accumulate sidecars

OCI artifact/referrer work shows that signatures, SBOMs, attestations, and other metadata can be associated with a subject artifact. ViewFS should expect the same around imported objects. The hard part is avoiding a sidecar pile that collapses to one green bit.

ViewFS consequence: quarantine cards should show evidence rows, scanner verdicts, policy cuts, authority diffs, and receipts as separate rows.

## WASI descriptor pressure: constrained access must be concrete

WASI filesystem APIs continue to be a good pressure source for descriptor-relative access. Revision 157 used this for resolver lanes. Revision 158 extends the same spirit to safe viewing: a safe viewer receives a constrained handle, not ambient access to the source object or host namespace.

ViewFS consequence: safe-viewer handles are read/inspect-only in the fixture corpus.

## OpenTelemetry pressure: reports should be generated from events

OpenTelemetry's general posture — structured traces/logs/metrics generated from instrumentation rather than hand-written narratives — is useful for ViewFS assurance. The ViewFS conformance report should be generated from the fixture/proof corpus so reviewers can see actual operation coverage and denial reasons.

ViewFS consequence: `tools/build_conformance_report.py` generates `out/conformance_report.md`, and `make lint` regenerates it.

## Speculative next fixtures

- stale scanner verdict denies release;
- origin evidence subject mismatch denies release;
- safe viewer with export right denies safe-viewer open;
- export to model context requires redaction/minimization cut;
- export sink replay denies when recipient handle changed;
- conformance report stale hash denies release packaging;
- artifact sidecar pile without policy cut denies trust transition;
- transparency entry plus no local admission denies live open.
