# Research synthesis — 2026-05-21 pass CLX

Revision 157 deepens the executable spine rather than adding another broad seam essay. The research pressure points at four places where ViewFS could still accidentally launder authority: resolver edge cases, persistent/local file handles, delegated custody, and provenance/cleanup accounting for derived artifacts.

## External pressure compressed

- **Linux openat2 resolver flags** (`REF-LINUX-OPENAT2-RESOLVE`) show that path safety is not one Boolean. Rooted resolution, beneath-only resolution, symlink refusal, magic-link refusal, and mount-crossing refusal are separate resolver concerns. ViewFS should have distinct receipts for those failures.
- **WASI filesystem descriptors** (`REF-WASI-FILESYSTEM-DESCRIPTORS`) reinforce descriptor-relative paths and no ambient global filesystem for sandboxed code. ViewFS can use this as compatibility pressure: path strings should be interpreted under explicit descriptors/view roots, not host-global truth.
- **File System Access API / MDN handle framing** (`REF-WICG-FILE-SYSTEM-ACCESS`, `REF-MDN-FILE-SYSTEM-HANDLES`) reinforces that user-mediated local file access becomes handle-shaped and security-sensitive, including persisted handles. ViewFS should separate picker/gesture, handle, persisted designator, permission state, and revalidation.
- **SLSA provenance** (`REF-SLSA-BUILD-PROVENANCE`) is not a filesystem authority model, but it usefully separates subject, build definition, run details, builder identity, external parameters, and byproducts. ViewFS should apply the same discipline to derived artifacts: answer cards, embeddings, summaries, and copy inventories need provenance/cleanup lanes rather than being informal cache dust.

## Companion pressure compressed

- **Schell** remains the strongest pressure for copy inventories and minimization ledgers.
- **Ward** supplies the accountability vocabulary for delegation warrants, recall, and stewardship trails.
- **Harbor** reminds ViewFS that external/public copies may need recheck windows and cannot be locally wished away.
- **Foundry** keeps pushing executable witnesses for classification boundaries and code-drift fences.
- **SlopOS rev0720** remains the companion truth source for portal/request/replay posture and should continue to be checked for version-visible drift.

## Resulting revision move

Revision 157 adds checked lanes for:

1. resolver edge cases: symlink, magic-link, and mount crossing denial;
2. delegation chains: narrowed handoff allowed, widening denied, revoked delegation denied;
3. shell-card honesty: inert receipt cards allowed, receipt-as-live-authority cards denied;
4. derived cleanup accounting: forget denied with live derived artifacts and allowed after minimization/deletion.

The speculative direction is now clearer: ViewFS should treat every human-facing convenience surface as a projection over an authority/lifecycle ledger. Projection is allowed. Projection lying is not.
