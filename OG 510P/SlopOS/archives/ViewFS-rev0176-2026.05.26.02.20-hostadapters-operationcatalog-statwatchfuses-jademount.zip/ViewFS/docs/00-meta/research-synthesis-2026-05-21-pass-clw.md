# Research synthesis — 2026-05-21 pass CLW

Revision 156 continues the consolidation path: fewer new nouns, more checked pressure. The research pressure since Revision 155 points at four risky seams: ambient fallback, persisted grants, agentic tool invocation, and lifecycle confusion around revoked/retained/destroyed material.

## External pressure compressed

- **Linux Landlock** (`REF-LINUX-LANDLOCK-USER`, `REF-LINUX-LANDLOCK-AUDIT`) is a reminder that restricting ambient rights should be additive and denial reasons matter. ViewFS should not merely fail a pathwalk; it should name whether the blocker was view escape, missing bind, revoked handle, stale grant, or denied right.
- **WASI Preview 2 / capability preopens** (`REF-WASI-PREVIEW2`, `REF-WASI-CAPABILITY-PREOPENS`) reinforces the “no universal filesystem by default” posture. Compatibility should begin from explicit directory/handle roots, not from process-global host paths.
- **macOS security-scoped bookmarks** (`REF-APPLE-SECURITY-SCOPED-BOOKMARKS`, `REF-MS-CVE-2025-31191-BOOKMARKS`) reinforce that persistent file access tokens are powerful lifecycle objects. ViewFS restore tokens need issuer evidence, revocation posture, stale brakes, and replay denial rather than becoming magic durable authority.
- **MCP security and OWASP LLM risks** (`REF-MCP-SECURITY-BEST-PRACTICES`, `REF-OWASP-LLM01-PROMPT-INJECTION`, `REF-OWASP-LLM06-EXCESSIVE-AGENCY`, `REF-OWASP-LLM08-VECTOR-EMBEDDING`) reinforce that prompt/tool/resource catalogs and retrieved context must not be allowed to perform effects. ViewFS needs typed action-plan fixtures, not only prose warnings.
- **KMIP lifecycle language** (`REF-OASIS-KMIP-LIFECYCLE`) is useful as an analogy: a destroyed or compromised object may retain audit/status facts while being forbidden for use. ViewFS revocation should similarly preserve receipt history while preventing live or future authority use.

## Companion pressure compressed

- **SlopOS rev0720** keeps pushing ViewFS toward replay and recovery evidence: portal grants, commit cuts, and append/resume decisions should all become deterministic replay lanes.
- **Schell rev0248** pushes retention and forgetting discipline: answer cards, embeddings, receipts, and transcript residue should have explicit retention roots or explicit non-root status.
- **Harbor rev0093** pushes stale-public-surface humility: a grant or export receipt should not imply the outside world has been cleaned up.
- **Steward rev0181** pushes retry and replay guards: a restore token or portal receipt must not be silently replayable.
- **Ward rev0077** pushes delegation accountability: death verdicts and recall receipts need visible issuers and stewardship context.
- **Helm rev0203** pushes repair honesty: stale-base denial should lead to repair lanes, not hidden auto-merge.
- **Foundry rev0082** pushes fixture/code-drift fences: proof obligations should be linked to specimens so registries cannot drift into decorative prose.

## Resulting revision move

Revision 156 adds checked lanes for:

1. handle attenuation and no-widen;
2. mutable commit cuts and stale observed bases;
3. restore-token death verdicts and revoked-handle inertness;
4. explicit retention roots versus receipt-only history;
5. prompt text versus typed approved action plans;
6. accepted portal grants versus spent/replayed grants;
7. proof-obligation fixture coverage.

The speculation remains the same but sharper: ViewFS should not merely be a file view system. It should be a **lifecycle-honest authority graph**. Authority carriers, projections, proofs, histories, and lifecycle brakes should be rendered together for humans and kept separate for machines.
