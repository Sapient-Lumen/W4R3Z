# Research synthesis — pass CMG — identity, key, credential, and secret custody

Revision 166 pulls external pressure from identity and secret-management systems into ViewFS without importing their authority model whole.

- WebAuthn Level 3 reinforces that credentials should be scoped to relying parties and created/used through authenticators with user mediation. ViewFS mirrors the idea by treating credential identity and current use as separate facts.
- OAuth 2.0 Security BCP and DPoP pressure the distinction between bearer strings and sender-constrained proof-of-possession credentials. ViewFS fixtures deny bearer-token authority and refresh-receipt replay.
- NIST SP 800-57 and KMS practice pressure key lifecycle states, algorithm posture, rotation, and rewrap accounting. ViewFS fixtures keep key id, ciphertext, and rotation receipt separate from decrypt authority.
- Vault-style dynamic secret leases pressure TTL, renewability, and revocation. ViewFS fixtures separate vault rows/descriptors from current secret leases.
- Kubernetes Secret delivery illustrates why environment shadows deserve explicit scrutiny: secret material can be injected as files or environment variables, and environment delivery can leak through logs/diagnostics/process surfaces. ViewFS fixtures deny unredacted env-shadow injection by default.
- SPIFFE/SPIRE workload identity pressure runtime-bound identity rather than static names. ViewFS keeps identity/session/currentness separate from file or secret authority.

The speculative design claim is that ViewFS secret custody should be rendered as a custody graph, not a hidden implementation detail: identity assertion → current session → credential/lease/key posture → approval/plan cut → live handle → redacted card → receipt.
