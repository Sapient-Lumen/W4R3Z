# Roadmap

## Phase A0 — archive seed
- repo hygiene
- charter / claims / non-claims
- bibliography and research map
- first RFC

## Phase A1 — minimal substrate design
- immutable blob + manifest object model
- directory/object handle vocabulary
- per-process view root posture
- portal import/export posture

## Phase A1.5 — alignment and decision freezing
- map ViewFS onto existing SlopOS seams instead of inventing parallel concepts
- record explicit deferred decisions
- identify a short list of spikes that answer real risk instead of speculative architecture curiosity

## Phase A2 — bounded compatibility
- synthetic path membrane
- cwd / root semantics
- failure-on-escape rules
- transcript-visible import/export receipts
- host-bridge bring-up discipline and ambient-debt visibility

## Phase A3 — shell and terminal differentiation
- structured pipelines over handles/receipts
- clickable blocks and receipts
- capability-aware completion and previews
- explicit view/domain switching UX
- workspace/tree bind and rebind UX distinct from recent-item reopen and URI launch
- plumb-style routing and transferable receipts
- typed route sheets and explain-access inspection
- prepare-versus-commit action planning with exact approval diffs and result cards
- suggestion-tray and promote-to-user-workflow UX distinct from prepare/run/history
- basis-diff and reconsent-ladder UX distinct from current authority and old receipts
- witness-drawer, caveat-chip, and why-panel UX distinct from live authority and durable history
- policy-lens, advice-rail, and diagnostic-card UX distinct from authoritative policy and durable audit history
- cut-picker, fallback-rail, and repair-prompt UX distinct from exact policy-family selection and durable selection history
- proposer-badge, scope-chip, escalation-ladder, and adoption-gate UX distinct from authoritative adoption and durable history
- ceiling-pill, narrowing-preview, scope-fuse, and adopt-narrowest-safe-rung UX distinct from authoritative ceilings and durable history
- resource-shelf, prompt-chip, tool-rack, app-dock, and completion-popover UX distinct from request binding and live invocation history
- task-badge, progress-lane, input-required drawer, queue rail, and result-locker UX distinct from immediate requests and durable history
- stop-ladder, detach-rail, termination-fuse, retry-vs-fork drawer, and result-retention locker UX distinct from immediate stop acts and durable history
- follow-tail, attach-rail, control-pane, debug-launch drawer, and sideband-badge UX distinct from transcript history and object authority

## Phase A4 — deferred hard decisions
- revocation semantics
- mutable directory transactions
- query/index model
- replication / sync model
- symlink/hardlink policy
- grouped capability bundle semantics
- whether immutable identity, naming, mutable heads, and durable grants ever need tighter coupling
- whether intent/plan/approval/result families need a shared schema or stay family-specific
- whether suggestion/promotion/workflow families need a shared schema or stay family-specific
- whether reuse/basis/drift/reconsent/renewal families need a shared schema or stay family-specific
- whether witness/caveat/freshness/why-record families need a shared schema or stay family-specific
- whether validation/policy/advice/diagnostic/log families need a shared schema or stay family-specific
- whether policy-family/catalog, exact cut, fallback, repair, and selection-receipt families need a shared schema or stay family-specific
- whether proposer/source, proposal-lane/scope, escalation, adoption, and adoption-receipt families need a shared schema or stay family-specific
- whether deny-ceiling, scope-eligibility, narrowing-transform, escalation-attempt, and adoption-receipt families need a shared schema or stay family-specific
- whether resource/prompt/tool/app/completion, request-binding, invocation/result, and durable-receipt families need a shared schema or stay family-specific
- whether close/cancel, terminate, detach/delete, retry-fresh, reset/fork/attach, and durable-receipt families need a shared schema or stay family-specific
- whether observe/query/follow, interactive attach, control-message, exec/debug, sideband, and durable-transcript families need a shared schema or stay family-specific
- keep session-state memory, journals, notebooks, and replay aids clearly separate from live authority while the shell UX grows richer
- keep indexes, recents, and selector registries clearly advisory instead of letting search surfaces become authority by accident
- prototype a protected-authorability matrix and one-shot invoke lane before deciding whether any lower-trust source classes may ever author always-on state
- prototype a helper lifecycle rack that keeps install/config state, enablement, start approval, live session, and request-scoped selection visibly distinct before deciding whether any helpers may auto-start or persist live authority across sessions
- prototype a helper-feature catalog flow that keeps resources, prompts, tools, interactive apps, completions, request bindings, and live invocation receipts visibly distinct before deciding whether any of those classes should share schemas or replay shortcuts
- prototype a live-session lane flow that keeps follow/query, attach, control, debug-exec, sideband access, and transcript history visibly distinct before deciding whether any of those classes should share schemas or shortcuts

## Revision 141 roadmap note
- Prototype a `why retained?` / `sweep --dry-run` lane before choosing any final object-store GC algorithm, and keep receipts/indexes/caches/listing rows out of the root set unless explicitly rooted.

## Revision 144 roadmap note

Before any package/helper activation prototype, add a spike for supply-chain evidence drawers: exact subject, SBOM claim set, locator aliases, advisory/VEX view, provenance/transparency/update evidence, local admission verdict, activation target, live facet, and receipt. The spike should explicitly avoid choosing a final package manager, vulnerability database, or signing root.

## Revision 150 roadmap note

Before any network/service prototype promotes a secure channel to a reusable capability, add a verifier-profile/channel-binding spike that keeps reference identity construction, presented evidence, trust-anchor inputs, verification verdicts, resumption/0-RTT posture, client-auth selection, live channel handles, and receipts separate.



## Revision 151 roadmap note

Before any object-store implementation exposes user-visible content-addresses, deduplication, encrypted dedup, shared backing, cache hit/miss, or skip-upload behavior, add a spike for digest shades and membership-safe materialization: addressing profile, equality profile, dedup domain, convergence/privacy domain, proof-of-possession, cache-hit redaction, fresh identity, quarantine/lineage preservation, live facet, and receipt.

## Revision 151 follow-up: prove digest/equality humility with one small scenario

Add a worked specimen where two imports have identical bytes but different origin/quarantine state, where provider-private dedup may reuse backing, where the shell can show only a local equality witness, and where export/admission still requires fresh local policy. The test should fail if a digest card can be used as an open handle, membership probe, or trust clearance.


## Revision 152 roadmap addition

- prototype a scope-gated semantic search slice that keeps extraction intent, source snapshot, model/extractor profile, derived artifact, retrieval-store membership, query scope, projection policy, answer card, live handle, and receipt separate before deciding on any native vector database, embedding model, or agent-memory plane.
## Revision 153 roadmap addition

Prototype instruction hygiene before agent autonomy hardens:

- source-labeled instruction ladders for system/user/workspace/retrieved/tool/model/history text;
- context shutters that show included, omitted, and redacted material;
- model output as proposal-only;
- typed action-plan cards before effectful calls;
- toolcall fuses that show exact authority slots;
- approval-basis drawers and receipt-only ghosts.

Do not choose a final prompt schema, model runtime, MCP ABI, or memory substrate yet.

## Revision 154 roadmap addition

Before any agentic shell, package installer, network send, secret release, durable grant, or namespace mutation prototype relies on human approval, add a consent-chain spike:

- canonical consent cards from typed plans;
- authority-diff panes;
- trusted-path lamps;
- gesture freshness/consumption chips;
- optional one-shot volition witnesses;
- approval-cut drawers naming exact live authority slots;
- stale receipt / summary mismatch / app-rendered UI / remote-captured UI denial tests.

Do not choose a final UI root, secure attention sequence, signature scheme, accessibility issuer, or headless profile yet.
## Revision 155 roadmap addition

- Treat `fixtures/viewfs-core-v0/` as the new minimum bar for core-seam work.
- Add handle-attenuation fixtures next: duplicate, narrow, deny-widen, expire, revoke, stale-brake.
- Add portal-grant replay fixtures after that, borrowing SlopOS rev0720 commit-log/recovery/append discipline.
- Add shell-card render fixtures only after the authority corpus is stable enough to be boring.
- Keep new nouns provisional until they pass the promotion rule in `docs/30-architecture/core-schema-v0.md`.


## Revision 156 roadmap addition

- Treat `tools/check_proof_fixture_coverage.py` as the guardrail against proof-obligation drift.
- Add shell-card render fixtures for the new lifecycle lanes only after the authority fixtures stay stable: attenuation cards, commit-cut cards, death/stale-brake cards, sweep-preview cards, and toolcall-fuse cards.
- Next mutable-state work should add conflict artifacts, merge/takeover cuts, and provider pushback without weakening stale-base denial.
- Next revocation work should model issuer-side recalls, offline windows, delegation wavefronts, and visible “cannot claw back exported copies” non-claims.
- Next retention work should add derived-index compaction, answer-card residue accounting, and Schell-style forgetting-ledger crosschecks.
- Next agentic-action work should add tool-output injection, covert tool invocation, parent-workspace instruction discovery, approval expiry, and budget/cancellation fixtures.

## Revision 157 roadmap addition

Before a compatibility shim, delegation UI, or semantic-index cleanup flow graduates beyond fixtures, build one conformance runner that replays the `viewfs-core-v0` corpus against a prototype implementation. The runner should assert typed denial reasons for resolver crossings, no-widen delegation envelopes, revoked delegation stale brakes, shell-card badge honesty, and copy-inventory cleanup before a source-forget claim.

Near-term spikes:

- resolver denial receipt renderer for escape/symlink/magic/mount/missing-bind/missing-right;
- delegation card with source/child/envelope/lease/revocation lanes;
- shell-card badge checker for authority and retention truth;
- `forget --dry-run` over source object plus derived artifact inventory.

## Revision 158 roadmap note

The next implementation spike should make quarantine and export visible in the same demo trace as pathwalk and delegation: import foreign object, place it in quarantine, inspect via safe viewer, attempt direct open and export denial, admit through trust transition, render authority diff, export through typed plan, then prove the old export receipt cannot replay. Add stale scanner verdict, evidence-subject mismatch, safe-viewer-too-powerful, and sink-revalidation fixtures before any broader trust/admission policy is promoted.


## Revision 160 roadmap pressure

The next hardening lane after rev160 should turn the distributed-state fixtures into a provider conformance ABI: every provider should report lease epoch, freshness fence, merge plan, attestation status, and checkpoint posture using the same denial reasons.
