# Research synthesis 2026-05-22 pass CMD

Revision 163 pressure came from retention, object-lock, backup-prune, and media-sanitization systems.

- SNIA SIRF and digital-preservation packaging pressure ViewFS to preserve enough metadata around retained objects that future systems can interpret why material is held.
- S3 Object Lock separates retention periods from legal holds; compliance-mode retention cannot simply be shortened, while legal holds have separate permissions and release posture.
- NIST SP 800-88 frames sanitization as making access infeasible at a target effort level; ViewFS therefore should not call a tombstone or GC sweep secure erasure.
- Borg and restic pruning documentation reinforces the distinction between removing backup/snapshot references and actually reclaiming repository storage.

Design consequence: ViewFS should render deletion and restore as evidence ladders, not booleans. Snapshot pins, archive holds, protected backups, deletion claims, sanitization proofs, and restore manifests must be visible without becoming authority.
