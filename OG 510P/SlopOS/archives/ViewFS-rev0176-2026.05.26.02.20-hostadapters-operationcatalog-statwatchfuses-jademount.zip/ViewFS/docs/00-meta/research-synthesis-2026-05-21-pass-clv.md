# Research synthesis — 2026-05-21 pass CLV

Revision 155 is a consolidation pass rather than another noun-expansion pass. The external and companion research all points to the same next move: keep ViewFS capability semantics small enough to execute, then make every anti-collapse distinction pass a specimen.

## External pressure compressed

- **Fuchsia capabilities/namespaces** (`REF-FUCHSIA-CAPS`, `REF-FUCHSIA-NAMESPACE`, `REF-FUCHSIA-DIR-CAPS`) reinforce ViewFS's per-process view-root model: a namespace is assembled from routed capabilities, not discovered from one universal root.
- **Capsicum** (`REF-CAPSICUM-SEC10`, `REF-CAPSICUM-RIGHTS`) reinforces the migration path: compatibility can exist, but ambient namespaces should be explicitly entered or removed, and rights should narrow rather than widen.
- **Linux `openat2`** (`REF-OPENAT2`) gives concrete failure vocabulary for rooted pathwalks: escape attempts, magic links, mount crossings, and retry-uncertain races should produce explicit denial reasons rather than silent host fallback.
- **XDG document portals** (`REF-XDG-DOCUMENTS`, `REF-XDG-PERMISSION-STORE`) show that mediated file exposure needs exact grant, permission, delete/revoke, and document-store semantics; a portal receipt is not the same thing as current file authority.
- **OWASP LLM risks and MCP seams** (`REF-OWASP-LLM01-PROMPT-INJECTION`, `REF-OWASP-LLM08-VECTOR-EMBEDDING`, `REF-MCP-TOOLS-SECURITY-2025-06`, `REF-MCP-PROMPTS-2025-06`, `REF-MCP-RESOURCES-2025-06`) support treating prompt text, retrieved context, vector membership, tool descriptions, and tool results as authority-adjacent but non-authoritative.
- **WebAuthn and Wayland activation** (`REF-WEBAUTHN-3`, `REF-XDG-ACTIVATION-V1`) reinforce the consent-chain split: presence, verification, focus/activation, gesture evidence, and action-specific approval are different things.

## Companion pressure compressed

- **SlopOS rev0720** contributes the proof-culture template: restart/recovery, commit-log replay, checkpointing, linearization, append/resume/truncation, and tamper cases should become ViewFS portal-grant and view-state evidence later.
- **Schell rev0248** says every semantic/index/answer surface needs retention, forgetting, minimization, and transcript-residue posture.
- **Harbor rev0093** says publication/export/share status needs implementation receipts, recheck windows, stale public surface accounting, and appeal/reopen humility.
- **Steward rev0181** says retries, replay guards, pushback budgets, and activation/readiness claims must not become authority.
- **Ward rev0077** says delegation warrants and stewardship labels must stay separate from approval, current handles, and governance closure.
- **Helm rev0203** says repair attempts and intervention traces must stay visible without pretending the problem is closed.
- **Foundry rev0082** says schema names, category labels, code values, and crosswalk mappings must be pinned before they are used for meaning-preserving joins.

## Resulting revision move

The low-regret move is not another anti-collapse essay. It is an executable v0 spine:

1. a small core schema;
2. a proof-obligation index;
3. checked positive/negative JSON fixtures;
4. lint gates for registry and RFC integrity;
5. a companion seam intake table;
6. an explicit embedded-SlopOS version refresh.

The key speculation is that ViewFS should become a **capability graph with projections**, not a filesystem that later learns capabilities. Paths, semantic search, shell cards, prompts, receipts, and publication surfaces are projections over authority; they are not the authority substrate.
