# Research synthesis 2026-05-23 pass CME

Revision 164 pressure came from software supply-chain and plugin-boundary systems.

- SLSA provenance pressure: subject/build/builder evidence is critical, but it is still evidence; admission and runtime authority need their own cuts.
- TUF pressure: update systems need versioned/expiring/threshold-signed verifier metadata so rollback, freeze, and arbitrary-install attacks cannot hide as ordinary metadata.
- Sigstore/Rekor pressure: transparency inclusion gives public history and inclusion evidence, but inclusion is not install or tool invocation authority.
- SPDX/CycloneDX pressure: SBOMs and dependency graphs improve inventory and review, but an inventory row or dependency range is not an exact authority-bearing pin.
- OpenSSF/OWASP supply-chain pressure: dependency confusion, compromised packages, malicious packages, and CI/CD abuse are boundary attacks where trust metadata can be laundered as capability.

Design consequence: ViewFS must make package admission and tool invocation visibly separate. Package envelope, SBOM, dependency pin, provenance attestation, transparency entry, verifier root, extension manifest, tool schema, tool binding, sandbox profile, action plan, live target handle, and receipt are different records with different failure modes.
