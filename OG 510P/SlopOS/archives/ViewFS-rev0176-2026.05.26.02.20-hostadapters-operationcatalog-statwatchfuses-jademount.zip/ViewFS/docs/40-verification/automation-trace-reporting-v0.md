# Automation trace reporting v0

`tools/build_automation_trace_report.py` generates `out/automation_trace_report.md` from the executable fixture corpus.

The report groups automation fixtures by operation, mode, expected reason, record id, and proof-obligation coverage. It is intentionally small and reviewable: if a future workflow feature adds a new automation noun without a positive and negative specimen, `make lint` should fail through the fixture-balance and proof-coverage gates.

Reviewer posture: workflow surfaces should be judged by whether they keep event occurrence, rule match, schedule eligibility, run state, step target authority, idempotency, retry, compensation, human approval, and shell rendering separate.
