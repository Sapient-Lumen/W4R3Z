# Supply-chain trace reporting v0

Revision 164 adds `out/supply_chain_trace_report.md`, generated from the checked fixture corpus. The report isolates package admission, dependency pins, provenance, transparency entries, verifier-root rotation, extension manifests, tool schemas, tool bindings, sandbox profiles, and approved tool invocation.

The report is a drift map, not a proof. It lets reviewers answer:

- which package/tool operations are currently checked;
- which fixtures are positive versus negative;
- which denial reasons exist;
- which proof obligations are pressured by supply-chain specimens;
- whether tool visibility, manifests, schemas, or transparency evidence are being treated as authority.

`make lint` regenerates the report so stale summaries do not survive ordinary validation.
