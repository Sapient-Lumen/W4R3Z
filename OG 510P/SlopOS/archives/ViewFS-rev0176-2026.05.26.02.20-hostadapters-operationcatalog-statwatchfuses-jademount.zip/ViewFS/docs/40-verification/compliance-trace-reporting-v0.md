# Compliance trace reporting v0

`tools/build_compliance_trace_report.py` generates `out/compliance_trace_report.md` from the checked fixture corpus. The report lists every classification/license/jurisdiction/purpose/release/card fixture, its mode, operation, expected result, expected reason, and proof obligations.

The report is intentionally not a legal conclusion. Its job is to make drift visible:

- when a new compliance record family appears without fixtures;
- when a label or card starts implying live authority;
- when a release path fails to require redaction, obligations, or live export authority;
- when purpose and license checks drift away from specimen coverage;
- when jurisdiction fences become inert labels instead of checked egress gates.

`make lint` regenerates the compliance trace report after validating RFC numbers, assurance registry IDs, fixture results, and proof-obligation coverage.
