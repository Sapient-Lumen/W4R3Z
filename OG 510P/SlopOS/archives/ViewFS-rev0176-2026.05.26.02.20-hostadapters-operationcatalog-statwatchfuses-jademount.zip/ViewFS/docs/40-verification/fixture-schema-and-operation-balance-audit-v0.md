# Fixture schema registry and operation balance audit v0

Revision 171 performs a small audit/refactor of the executable core.

`tools/fixture_schema.py` now owns the top-level fixture schema name, top-level keys, and record-family registry. `tools/check_viewfs_core_fixtures.py` imports that registry instead of carrying a long local record-family set beside evaluator logic.

`tools/check_fixture_operation_balance.py` audits the executable corpus for operation maturity. Every checked operation must have at least one positive fixture and at least one negative fixture. A one-sided operation can be useful during discovery, but it is not mature enough for the top-level lint gate because it does not show both the success cut and at least one refused collapse.

The audit forced four pre-existing negative-only operations to gain positive specimens:

| Operation | Added positive specimen |
|---|---|
| `read_handle` | `345-live-handle-read-allow.json` |
| `semantic_open` | `346-semantic-card-current-handle-allow.json` |
| `retain_source_via_index` | `347-derived-artifact-explicit-retention-root-allow.json` |
| `reacquire_from_restore_token` | `348-restore-token-live-redeemable-allow.json` |

This is intentionally a lightweight maintainability check, not a proof of semantic completeness. It prevents the cube from silently accreting operations that are only slogans, only happy paths, or only denials.
