# Interop trace reporting v0

Revision 175 adds `tools/build_interop_trace_report.py` and generated `out/interop_trace_report.md`.

The report is generated from fixtures whose operations are:

- `bind_namespace_context`
- `resolve_external_reference`
- `admit_vocabulary_term`
- `apply_crosswalk_mapping`
- `validate_shape_constraint`
- `verify_ontology_alignment`
- `publish_catalog_entry`
- `render_interop_card`

The report gives reviewers a compact way to inspect namespace/reference/vocabulary/crosswalk/shape/ontology/catalog/card evidence without opening every fixture file. It also makes proof pressure visible by listing which proof obligations each fixture covers.

## Reviewer posture

Interop reports are not certification reports. They are review aids. A green row in the report means the fixture checker produced the expected allow/deny result for a specimen. It does not mean the referenced external standard, vocabulary, URI, ontology, catalog, or schema is safe, current, authoritative, or complete.

The report exists to catch laundering attempts: URI-as-handle, context-as-policy, term-as-classification-authority, crosswalk-as-equivalence-proof, shape-validation-as-approval, catalog-entry-as-disclosure, and card-as-safety-certification.
