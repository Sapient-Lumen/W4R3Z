# Operation catalog audit v0

Revision 176 adds an operation-catalog audit around the large executable fixture checker. The earlier balance gate proved each checked operation had at least one positive and one negative fixture, but the evaluator registry itself was still hard to review as a first-class surface.

New files:

- `tools/operation_catalog.py` loads evaluator names and fixture evidence into a shared summary model.
- `tools/check_operation_catalog.py` fails lint if an evaluator has no fixture evidence, a fixture names an unsupported operation, an operation name is not snake_case, an operation has no proof-obligation coverage, or an operation lacks positive/negative specimens.
- `tools/build_operation_catalog_report.py` generates `out/operation_catalog_report.md`.

`tools/check_fixture_operation_balance.py` now uses the shared operation catalog instead of separately loading fixture state. This keeps operation identity, evaluator registration, and positive/negative balance checks aligned as the corpus grows.

The audit is intentionally boring. The point is to make operation growth visible and to prevent a new checker function from landing without specimens or a new fixture operation from landing without an evaluator.
