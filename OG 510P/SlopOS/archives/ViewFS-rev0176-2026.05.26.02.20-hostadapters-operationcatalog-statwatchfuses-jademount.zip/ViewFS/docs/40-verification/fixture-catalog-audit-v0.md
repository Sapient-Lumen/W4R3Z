# Fixture catalog audit v0

Revision 172 adds `tools/fixture_catalog.py`, `tools/check_fixture_catalog.py`, and `tools/build_fixture_catalog_report.py`.

The audit exists because the fixture corpus is now large enough that filename drift is itself a verification risk. A reviewer should be able to infer the rough role of a fixture from its stable number, slug, mode suffix, operation, and proof-obligation links.

## Enforced checks

`tools/check_fixture_catalog.py` fails when:

- a fixture filename does not begin with a zero-padded numeric prefix;
- fixture numbers are duplicated or have gaps;
- numbering does not start at `001`;
- a positive fixture does not end in `-allow.json`;
- a negative fixture does not end in `-denied.json`;
- fixture names duplicate;
- `operation.op` is missing;
- `covers` is empty.

Revision 172 also fixed the old filename `008-derived-artifact-not-retention-root.json` by renaming it to `008-derived-artifact-not-retention-root-denied.json`.

## Refactor note

`fixture_catalog.py` is now the shared loader for fixture catalog audits and related report/check scripts. This reduces the chance that coverage, balance, and catalog tools disagree about which files exist or how fixture identity is parsed.
