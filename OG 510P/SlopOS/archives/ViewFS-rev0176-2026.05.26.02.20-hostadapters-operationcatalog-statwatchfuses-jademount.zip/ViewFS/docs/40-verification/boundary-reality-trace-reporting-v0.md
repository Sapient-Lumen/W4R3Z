# Boundary reality trace reporting v0

Revision 167 adds `tools/build_boundary_reality_trace_report.py` and `out/boundary_reality_trace_report.md`.

The report covers fixtures whose operations exercise runtime posture, network connectors, clipboard parcels, drag/drop parcels, peripheral grants, device attestations, and sensor observations.

## Purpose

The report is a drift detector for boundary surfaces that humans often treat as self-evident authority:

- local runtime presence;
- host or container posture;
- connector installation;
- clipboard contents;
- drag/drop gestures;
- USB/Bluetooth/HID-like device descriptors;
- camera/location/microphone-like sensor observations.

The report does not certify a runtime, device, network, or sensor. It only summarizes executable specimens that enforce the ViewFS rule: boundary facts may constrain or explain authority but cannot replace live handles, policy cuts, trusted path, redaction posture, freshness, or sandbox fit.

## Gate

`make lint` regenerates the report. New proof obligations in the boundary lane must be covered by at least one fixture through `tools/check_proof_fixture_coverage.py`.
