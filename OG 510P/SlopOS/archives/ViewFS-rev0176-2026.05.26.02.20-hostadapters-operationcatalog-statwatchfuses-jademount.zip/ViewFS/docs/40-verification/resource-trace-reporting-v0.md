# Resource trace reporting v0

`tools/build_resource_trace_report.py` generates `out/resource_trace_report.md` from the checked fixture corpus. The report isolates resource-control fixtures from the larger conformance report so reviewers can inspect side-effect and capacity semantics without reading every JSON file.

The report lists:

- fixture count and positive/negative split;
- operation counts for `reserve_budget`, `admit_rate_limit`, `start_background_job`, `hydrate_cache_entry`, `emit_capacity_signal`, and `settle_metering_receipt`;
- every fixture row, expected result, expected reason, and proof-obligation coverage;
- first fixture evidence for each resource-related proof obligation.

## What the report is not

The report is not a quota implementation, fair scheduler, cache engine, billing ledger, side-channel proof, or benchmark. It is an E1 drift map for the anti-collapse rule: resource facts, queue state, cache residency, capacity hints, and metering receipts can bound or explain effects, but cannot become live authority.

## Review checklist

A reviewer should be able to answer:

1. Which resource surfaces can deny an operation?
2. Which surfaces are intentionally non-authority?
3. Which denial reason fires when budget, rate, queue, cache, capacity, or metering state is stale?
4. Which fixtures prove queued work is revalidated at run time?
5. Which fixtures prove capacity and cache metadata do not leak or revive object authority?

The report is regenerated during `make lint` through the top-level lint gate, so fixture rows and report rows should not drift silently.
