# Lint manifest refactor v0

Revision 174 audits the top-level lint surface. Before this pass, `tools/lint_repo.py` mixed three jobs: required-file registry, tool ordering, and lint orchestration. That made the linter itself a hand-edited seam accumulator.

The refactor adds:

- `tools/lint_manifest.py` as the source of truth for `REQUIRED_FILES` and `LINT_TOOLS`.
- `tools/check_lint_manifest.py` to audit duplicate manifest entries, missing files, missing `main()` functions, and trace-report registry coverage.
- a shorter `tools/lint_repo.py` that only orchestrates manifest checks and tool execution.

The non-goal is a full build system. The goal is a small anti-drift gate: when a new trace lane is added, its builder and generated report must appear in both the trace-report registry and the lint manifest.
