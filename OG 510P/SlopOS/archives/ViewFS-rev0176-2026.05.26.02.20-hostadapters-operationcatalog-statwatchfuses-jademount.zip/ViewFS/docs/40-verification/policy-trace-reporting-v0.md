# Policy trace reporting v0

Revision 159 adds `tools/build_policy_trace_report.py` and generated `out/policy_trace_report.md`.

The full conformance report answers: what fixtures exist, which operations do they exercise, and which proof obligations do they cover.

The policy trace report answers a narrower question: for policy/witness/replay/override fixtures, which bundle, decision, witness, scenario, and override-warrant rows are involved?

## Why this exists

Policy bugs often appear as explanation laundering:

- a decision log is shown as if it were authority;
- an advisory verdict is rendered as enforcement;
- a stale bundle result is reused;
- a witness bundle is replayed as if it were an approval;
- a happy-path scenario is presented as conformance;
- a breakglass label hides missing steward verification.

The report is intentionally generated from fixtures, not hand maintained. It should be safe to regenerate during `make lint` and should change whenever a fixture changes.

## Non-claims

The report is not a formal proof.

The report is not a production policy audit log.

The report is not an implementation conformance certificate.

The report is a drift map and review surface.
