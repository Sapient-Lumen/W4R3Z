# Collaboration trace reporting v0

Revision 162 adds `tools/build_collaboration_trace_report.py` and generated `out/collaboration_trace_report.md`.

The report is derived from fixtures whose operation is one of:

- `compose_shared_view`
- `group_bound_authority`
- `resolve_label_overlay`
- `handoff_packet`
- `render_collaboration_card`

## Why a separate report exists

The main conformance report lists every fixture. The collaboration report isolates the subset where social, shared, or UI-visible state is likely to be mistaken for authority:

- room membership;
- shared mount projection;
- group membership;
- classification/sharing labels;
- delegation handoff packets;
- collaboration cards.

This keeps reviewers from having to infer collaboration posture from scattered generic fixture rows.

## Reviewer posture

The report is not a product dashboard and not an ACL conformance suite. It is a drift map. A future implementation should be able to run the same scenarios against actual room composition, mount projection, group evaluation, handoff, and shell-card code.
