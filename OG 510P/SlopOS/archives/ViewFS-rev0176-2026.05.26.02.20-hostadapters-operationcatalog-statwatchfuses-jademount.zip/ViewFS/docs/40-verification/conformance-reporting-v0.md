# Conformance reporting v0

Revision 158 adds a generated conformance report: `out/conformance_report.md`. The report is built from the fixture corpus and proof-obligation table, not from hand-maintained prose.

## Goal

A reviewer should be able to answer the following questions without opening forty JSON files:

- how many fixtures exist;
- which operations are exercised;
- which fixtures are positive versus negative;
- what stable result/reason each fixture expects;
- which proof obligations each fixture covers;
- which proof obligations have fixture coverage and which are intentionally non-fixture evidence lanes.

## Non-goal

The report is not a formal proof and not implementation conformance. It is a drift map. It makes absence visible.

A future implementation conformance runner should replay the same fixture corpus against prototypes. The generated report should then grow implementation columns such as `model`, `prototype`, `kernel-shim`, `shell-renderer`, and `portal-bridge`.

## Current command

```sh
make conformance-report
```

`make lint` also regenerates the report. This makes stale reports less likely to ship in a release archive.

## Report inputs

- `fixtures/viewfs-core-v0/*.json`
- `docs/40-verification/proof-obligations-v0.md`

## Report output

- `out/conformance_report.md`

The output is deliberately plain markdown so the report can travel in context packs, release archives, review comments, and terminal sessions.
