# Disclosure trace reporting v0

`tools/build_disclosure_trace_report.py` generates `out/disclosure_trace_report.md` from the fixture corpus. The report isolates fixtures whose operation is one of:

- `redaction_view_read`
- `render_audit_projection`
- `disclose_package`
- `deliver_notification`
- `subject_access_export`

The report is an E1 review artifact. It is not a privacy-law compliance report, not an audit certification, and not implementation conformance. Its purpose is to keep disclosure laundering visible in review: redaction views, audit projections, disclosure packages, notifications, subscription cursors, subject-access requests, and old receipts must not silently turn into raw data access or live object authority.

Reviewers should use the report to answer four questions:

1. Which surfaces can reveal bytes or fields?
2. Which surfaces are metadata-only or redacted-only?
3. Which surfaces require live authority and an approval/review cut?
4. Which denial reasons protect against replay, expiry, missing redaction, scope mismatch, or authority-badge lies?
