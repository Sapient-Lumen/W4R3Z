# Query/eval trace reporting v0

`tools/build_query_eval_trace_report.py` generates `out/query_eval_trace_report.md` from checked fixtures that exercise query specs, planner traces, result sets, aggregation views, evaluation sets, benchmark runs, scoring rubrics, and model-selection cards.

The report exists to catch drift in these seams:

- saved queries or query text becoming search/read authority;
- planner traces or model proposals becoming executable authority;
- ranked hits and snippets becoming object-open authority;
- aggregate dashboards leaking raw rows or membership oracles;
- contaminated or uncleared evaluation sets being treated as valid inputs;
- scores and leaderboards becoming deployment cuts;
- rubric text and metric names becoming policy authority;
- model-selection cards hiding tradeoffs or claiming production readiness.

`make lint` regenerates the query/eval report after fixture validation and proof-obligation coverage. The report is a review surface, not an implementation conformance certificate.
