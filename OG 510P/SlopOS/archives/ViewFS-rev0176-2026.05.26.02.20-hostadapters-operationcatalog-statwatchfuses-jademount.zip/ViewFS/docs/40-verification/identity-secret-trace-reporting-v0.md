# Identity and secret trace reporting v0

`tools/build_identity_secret_trace_report.py` emits `out/identity_secret_trace_report.md` from the checked fixture corpus.

The report groups fixtures for identity assertions, session bindings, credential tokens, encryption envelopes, key versions, secret leases, injection plans, escrow recovery warrants, and secret cards. It is a reviewer index, not a proof and not a vault audit log.

The report exists to catch drift in one rule: identity facts, token strings, ciphertext, key ids, vault rows, leases, secret-delivery plans, escrow tickets, and shell cards may explain eligibility or custody, but cannot become live authority.
