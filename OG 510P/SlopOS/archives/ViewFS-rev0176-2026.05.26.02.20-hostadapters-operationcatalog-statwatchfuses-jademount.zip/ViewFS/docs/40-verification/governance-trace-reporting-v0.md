# Governance trace reporting v0

`out/governance_trace_report.md` is generated from the executable fixture corpus by `tools/build_governance_trace_report.py`.

The report covers:

- change proposal admission;
- decision record integrity;
- approval quorum verification;
- staged rollout starts;
- feature-flag evaluation;
- deprecation enforcement;
- compatibility-contract checks;
- migration-run execution gates;
- governance-card honesty.

The report is intentionally a verification surface rather than a product dashboard. It answers: which governance fixtures exist, which operation each fixture exercises, which proof obligation each fixture covers, and which reason the checker expects.

A future implementation can use this report as a seed for a conformance runner. Until then, it prevents governance nouns from being added as prose-only concepts.
