# Record family catalog audit v0

Revision 175 adds `tools/check_record_family_catalog.py` and `tools/build_record_family_report.py`.

The fixture checker already requires each fixture to carry the complete record-family key set. That catches missing keys, but it does not answer a different review question: which record families are actually exercised by non-empty evidence?

The record-family catalog audit closes that gap.

## Checks

`tools/check_record_family_catalog.py` fails when:

- `RECORD_FAMILIES` is not sorted;
- a record family is duplicated;
- a record family name is not snake_case;
- a family has no non-empty fixture evidence anywhere in the corpus;
- a fixture contains duplicate row ids inside the same family.

## Generated report

`out/record_family_report.md` lists every record family, how many fixtures contain non-empty rows for it, the first fixture evidence, the first operation, and the first row id.

This is an audit/refactor surface rather than a product feature. Its goal is to prevent schema accretion from becoming invisible. A family that exists only as an empty key in every fixture is not a real checked concept yet.
