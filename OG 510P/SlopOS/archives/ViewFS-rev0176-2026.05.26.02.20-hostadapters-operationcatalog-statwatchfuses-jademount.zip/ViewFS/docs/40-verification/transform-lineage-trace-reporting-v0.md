# Transform and lineage trace reporting v0

`tools/build_transform_lineage_trace_report.py` generates `out/transform_lineage_trace_report.md` from fixture rows whose operations exercise transform, codec, schema migration, patch, annotation, lineage, preview, and canonicalization lanes.

The report exists to keep interpretive products from becoming invisible authority. Reviewers can inspect every allow/deny specimen, expected reason, and proof-obligation mapping without opening every JSON row.

The report is not a renderer, codec sandbox, schema validator, provenance engine, annotation protocol, or Unicode security implementation. It is a drift map for one anti-collapse rule: transformed, decoded, migrated, patched, annotated, previewed, lineage-described, and canonicalized artifacts may support review or create new objects, but they do not become source authority or original-byte truth by default.
