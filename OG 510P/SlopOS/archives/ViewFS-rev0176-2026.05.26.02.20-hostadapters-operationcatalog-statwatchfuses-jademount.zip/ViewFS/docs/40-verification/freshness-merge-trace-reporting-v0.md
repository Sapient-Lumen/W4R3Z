# Freshness and merge trace reporting v0

`tools/build_freshness_trace_report.py` generates `out/freshness_trace_report.md` from the fixture corpus. The report isolates fixtures whose operation is one of:

- `renew_lease`
- `publish_offline_branch`
- `reconcile_merge`
- `verify_remote_attestation`
- `check_freshness_fence`
- `checkpoint_journal`

The report is an E1 review artifact. It is not a distributed consensus proof and not implementation conformance. Its purpose is to keep freshness laundering visible in review: timestamps, remote heads, leases, local commits, attestations, merge rows, and checkpoint receipts must not silently turn into authority.
