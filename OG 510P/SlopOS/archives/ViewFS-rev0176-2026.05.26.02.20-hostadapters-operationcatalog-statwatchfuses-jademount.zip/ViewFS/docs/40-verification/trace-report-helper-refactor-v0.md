# Trace report helper refactor v0

Revision 170 audits and refactors the trace-report generation layer. Before this pass, each specialized report script repeated the same operations:

- load all fixture JSON files;
- filter by operation name;
- count rows by operation and mode;
- render fixture tables;
- derive proof-obligation pressure;
- write markdown to `out/`;
- print a summary line for `make lint`.

That duplication made future drift likely: one report could render proof pressure differently, omit negative fixture counts, or silently stop escaping table values.

The refactor adds `tools/trace_report_common.py`. Specialized trace report builders now declare only:

- report title;
- operation set;
- output path;
- optional record-family columns;
- reviewer posture text.

The helper owns fixture loading, markdown escaping, operation/mode counting, proof-pressure tables, and write/print behavior.

## Audit finding

The fixture checker itself had also grown an unwieldy operation-dispatch chain. Revision 170 replaces that chain with an `EVALUATORS` table so new operations are auditable as data rather than hidden among many repeated `if operation == ...` branches. This also removed an accidental nested duplicate `delegate_handle` branch.

## Non-goal

This is not a public API stabilization of trace reports. It is an internal hygiene pass that reduces copy/paste risk while preserving the same CI contract: every trace report must be generated from checked fixtures and must remain part of `make lint`.
