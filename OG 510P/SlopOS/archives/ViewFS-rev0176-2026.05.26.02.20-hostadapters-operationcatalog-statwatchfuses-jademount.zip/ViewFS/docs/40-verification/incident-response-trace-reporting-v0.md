# Incident response trace reporting v0

`tools/build_incident_response_trace_report.py` generates `out/incident_response_trace_report.md` from checked fixtures that exercise alert signals, incident cases, triage verdicts, forensic snapshots, evidence chains, containment plans, remediation plans, recovery rollbacks, and postmortem records.

The report exists to catch drift in these seams:

- alert signals becoming proof of compromise or access authority;
- incident-case status becoming remediation or disclosure authority;
- triage verdicts becoming execution cuts;
- forensic snapshots becoming live opens or raw disclosure packages;
- evidence chains becoming causality proof, global truth, or access authority;
- containment plans widening blast radius or executing without approval;
- remediation plans using receipts or checklists as repair authority;
- rollback plans claiming to erase incident history or executing over stale epochs;
- postmortems claiming closure, no recurrence, live authority, or unredacted publication.

`make lint` regenerates the incident response report after fixture validation, proof-obligation coverage, and operation-balance audit. The report is a review surface, not an incident-management implementation.
