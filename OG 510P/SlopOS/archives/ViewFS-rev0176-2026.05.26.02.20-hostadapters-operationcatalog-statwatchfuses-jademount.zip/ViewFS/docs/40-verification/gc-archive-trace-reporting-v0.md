# GC/archive trace reporting v0

`tools/build_gc_archive_trace_report.py` generates `out/gc_archive_trace_report.md` from the checked fixture corpus.

The report isolates `collect_gc_candidate`, `prune_snapshot`, `release_archive_hold`, `restore_from_backup`, and `verify_deletion_claim` rows. It is meant for review and drift detection, not for proving secure erasure.

A future implementation runner should replay the same fixtures against any object-store sweeper, snapshot layer, archive-hold ledger, backup adapter, restore UI, or deletion-evidence card renderer.
