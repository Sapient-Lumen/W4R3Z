# Trace report registry refactor v0

Revision 173 audits the report-generation layer. Before this revision, `tools/lint_repo.py` hard-coded each trace report builder in a long list. That made every new report a multi-site edit: Makefile target, lint tool list, required-file list, and report script.

The refactor adds:

- `tools/report_registry.py` as the source of truth for trace report builders and outputs;
- `tools/build_all_trace_reports.py` to regenerate every registered trace report;
- `tools/check_report_registry.py` to verify builders, outputs, labels, and uniqueness;
- a `trace-reports` Make target;
- lint integration that calls the aggregate report builder instead of every individual report script.

This does not remove the individual report builders. They remain useful as focused developer entry points. The registry is the auditable release surface.

Anti-drift rule: adding a new trace-report lane should require one registry row, one builder, one output, one doc page, one RFC, and fixtures that cover proof obligations.
