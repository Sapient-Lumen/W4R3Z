# Inspirations mapped to ViewFS

## Lessons we must learn from the past


### L0c. Content-addressed storage is proof material, not membership or authority
- REF-VENTI-CAS and REF-FOUNDATION-CAS show how powerful content-addressed blocks/scores are for archival storage and deduplication.
- REF-IPFS-CIDS and REF-NIX-CONTENT-ADDRESS show that address profiles matter: a CID, store path, closure hash, and raw file checksum can name different layers.
- REF-TAHOE-CONVERGENCE-SECRET, REF-SECURE-DATA-DEDUPLICATION, REF-PROOFS-OF-OWNERSHIP, and REF-DUPLESS show that dedup-friendly encryption and client-side dedup create equality, possession, and membership hazards.
- REF-ZFS-DEDUP-ORACLE and REF-LINUX-KSM show that dedup is also a resource/isolation/side-channel policy.
- Therefore: do not let a digest, dedup hit, convergence domain, cache row, or old proof become object identity, trust clearance, publication, retention, ownership, or live ViewFS authority.

### L0b. Secure transport identity is evidence, not authority
- REF-RFC9525-SERVICE-IDENTITY shows why clients construct reference identifiers independently of server-presented identifiers.
- REF-RFC8446-TLS13 and REF-RFC8446-0RTT show that secure transport and early-data/resumption have different security properties.
- REF-RFC9266-TLS13-CHANNEL-BINDING shows channel-binding material is useful for binding upper-layer auth to a channel, not for creating a durable ViewFS handle.
- REF-RFC6962-CT, REF-OPENSSH-STRICTHOSTKEYCHECKING, REF-SPIFFE-X509-SVID, and REF-RFC7671-DANE make excellent evidence/identity/pinning vocabulary while leaving local authorization and object authority separate.
- Therefore: do not let `verified`, `logged`, `pinned`, `mTLS`, `resumed`, or `channel-bound` collapse into service invocation, object import, secret release, or durable reconnect authority.

### L0a. Authority is not sponsorship, and quota is not authorization
- REF-AWS-S3-REQUESTER-PAYS and REF-GCS-REQUESTER-PAYS show that permission to access data and who is billed for that access are different seams.
- REF-K8S-RBAC and REF-K8S-RESOURCEQUOTA show that authorization and aggregate resource ceilings are different seams too.
- REF-SEL4-MCS, REF-GENODE-QUOTA, and REF-CGROUPV2 show that runnable subjects, donated budgets, session properties, and hierarchical resource control can all be modeled separately.
- Therefore: do not let ViewFS handles or room binds silently double as payer roots, spend authority, or charge truth.

### L0. Retry-safe sameness is not admission, execution, or settlement
- REF-HTTPAPI-IDEMPOTENCY-KEY, REF-AWS-EC2-IDEMPOTENCY, REF-STRIPE-IDEMPOTENT-REQUESTS, and REF-STRIPE-ADVANCED-ERROR-HANDLING all show the same thing: a retry/dedupe key is a sameness witness with its own lifecycle, mismatch rules, and expiry window.
- Therefore: do not let one old key masquerade as mutable upsert authority, one provider ticket, or one final durable result.

### L1. Ambient namespaces always try to come back
- REF-CAPSICUM-SEC10, REF-FUCHSIA-NAMESPACE, and REF-WASMTIME-PREOPEN all show that bounded access works best when roots are explicit.
- Therefore: do not let “temporary” host-path fallback become a permanent escape hatch.

### L2. Capability persistence is harder than blob persistence
- REF-EROS and REF-KEYKOS both warn that durable authority edges create difficult stabilization and recovery semantics.
- Therefore: store immutable data first; postpone rich persistent capability graphs.

### L3. Private namespaces are a feature, not a hack
- REF-PLAN9 and REF-FUCHSIA-NAMESPACE show private, assembled views can be the primary user model.
- Therefore: make per-process `/` normal.

### L4. Rights attenuation should be visible and cheap
- REF-CAPSICUM-RIGHTS, REF-FUCHSIA-RIGHTS, and REF-FUCHSIA-DIR-CAPS show attenuation as normal practice.
- Therefore: rights-reduced duplicates should be common, not exotic.

### L5. Mediated imports beat broad static permissions
- REF-FLATPAK-BASICS, REF-XDG-FILECHOOSER, and REF-XDG-DOCUMENTS show the practical value of portals.
- Therefore: prioritize portal/open/save flows early.

### L6. Transfers need mediation too, not only chooser dialogs
- REF-XDG-FILETRANSFER shows that drag/drop and copy/paste can also be capability-grant moments with bounded sessions.
- Therefore: do not treat inter-app transfer as an ambient loophole.

### L7. Immutable object stores are powerful, but they are not the whole filesystem story
- REF-VENTI, REF-GIT-OBJECTS, REF-NIX-CA are excellent for storage and closure identity.
- Therefore: use them for the backing store, but do not pretend content addressing alone defines mutable namespace truth.

### L8. Mutable-over-immutable facades are real design space
- REF-IPFS-MFS, REF-SQLITE-SESSION, REF-PERKEEP-PERMANODE, and REF-TAHOE-MUTABLE all point to ways of getting mutable behavior over immutable content.
- Therefore: if ViewFS needs mutable working state, prototype explicit overlays, journals, claims, root-pointer updates, or stable slots before falling back to generic mutable inode assumptions.

### L9. Durable grants are useful but brittle
- REF-ANDROID-SAF and REF-XDG-DOCUMENTS both show that durable access hinges on stable identity and explicit revalidation.
- REF-APPLE-SSB-CVE2025 is a reminder that “magic bookmark persistence” can turn into a security problem.
- Therefore: make persistent grants explicit, inspectable, and revocable.

### L10. Central routing beats app-specific click heuristics
- REF-PLAN9-PLUMB demonstrates the power of typed routing messages across tools.
- Therefore: route object-open, inspect, and transfer intents explicitly instead of baking ad-hoc “open this string” behavior into every app.

### L11. A great shell is part of the security model
- REF-NUSHELL, REF-FISH, REF-WEZTERM-SHELL-INT, REF-WARP-BLOCKS, and REF-WARP-CMDPALETTE all show that interaction quality changes what users can safely understand.
- Therefore: authority previews, receipts, searchable workflows, and semantic blocks are not cosmetic extras.

### L12. Make ambient authority visible when it exists
- REF-CAPSTD shows the value of an explicit `AmbientAuthority` marker instead of pretending a fallback path open is morally equivalent to a passed-in directory handle.
- Therefore: build obvious debt markers for any ambient escape hatches used during bring-up.

### L13. Keep identity, naming, mutation, and persistence separate
- REF-WASMTIME-PREOPEN, REF-XDG-DOCUMENTS, REF-ANDROID-SAF, REF-IPFS-MFS, and REF-TAHOE-MUTABLE all hint that the best systems separate “what object is this?”, “where can I name it from here?”, “what is the current mutable head?”, and “can I reopen it later?”
- Therefore: ViewFS should resist collapsing those into one overloaded filesystem primitive.

### L14. Defense in depth still matters during bring-up
- REF-LANDLOCK is a good reminder that capability-native design can still benefit from lower-level ambient-rights restriction while the higher-level model is maturing.
- Therefore: keep room for host-side backstops without letting them redefine ViewFS semantics.

### L15. Terminal UX should be protocol-driven, not guessed
- REF-WEZTERM-SHELL-INT and REF-WARP-BLOCKS show that terminals can understand semantic zones and command blocks when the shell emits explicit metadata.
- Therefore: the ViewFS shell should export its state deliberately instead of making the terminal infer everything from text.

## Nifty ideas worth stealing
- **channel binder cards / cert braids / trust-anchor chips / resumption shades / secure-channel ghost receipts** from RFC 9525, TLS 1.3, TLS channel bindings, Certificate Transparency, OpenSSH known_hosts, SPIFFE X.509-SVID, DANE, and SlopOS D-NETLEASE verifier/resumption boundaries.
- **payer chips / spend rails / charge ghosts / switch-payer ladders** from REF-AWS-S3-REQUESTER-PAYS, REF-GCS-REQUESTER-PAYS, REF-K8S-RESOURCEQUOTA, REF-SEL4-MCS, and SlopOS budget-payer posture.
- **Intent lamps / retry braids / sameness chips** from REF-HTTPAPI-IDEMPOTENCY-KEY, REF-AWS-EC2-IDEMPOTENCY, REF-STRIPE-IDEMPOTENT-REQUESTS, and SlopOS request-key discipline.
- **Preopens / synthetic mounts for compat** from REF-WASMTIME-PREOPEN.
- **Per-component composite namespaces** from REF-FUCHSIA-NAMESPACE.
- **Routed directory capabilities** from REF-FUCHSIA-DIR-CAPS.
- **Capability dictionaries/bundles** from REF-FUCHSIA-DICTCAP and REF-FUCHSIA-DICT-RFC.
- **Descriptor rights that can only shrink** from REF-CAPSICUM-RIGHTS.
- **Explicit ambient-authority marker types** from REF-CAPSTD.
- **Write-once archival backing** from REF-VENTI.
- **Tiny core object vocabulary** from REF-GIT-OBJECTS.
- **Immutable application/runtime closures** from REF-NIX-CA.
- **Mutable facade over immutable content** from REF-IPFS-MFS.
- **Stable mutable anchors with ordered claims** from REF-PERKEEP-PERMANODE.
- **Stable mutable slots** from REF-TAHOE-MUTABLE.
- **Explicit changeset sidecars** from REF-SQLITE-SESSION.
- **Structured pipelines** from REF-NUSHELL.
- **Great interactive ergonomics** from REF-FISH.
- **Terminal blocks** from REF-WARP-BLOCKS.
- **Runnable notebooks** from REF-WARP-NOTEBOOKS.
- **Searchable parameterized workflows** from REF-WARP-WORKFLOWS.
- **A unified command/object palette** from REF-WARP-CMDPALETTE.
- **Semantic hyperlinks and visible domains** from REF-WEZTERM-HYPERLINKS and REF-WEZTERM-DOMAINS.
- **Shell integration metadata / semantic zones** from REF-WEZTERM-SHELL-INT.
- **Plumb-style typed routing** from REF-PLAN9-PLUMB.
- **Mediated drag/drop and clipboard file transfer** from REF-XDG-FILETRANSFER.
- **Scoped synthetic grant views** from REF-XDG-DOCS-FUSE.
- **Stable IDs for persisted grants** from REF-ANDROID-SAF.
- **Ambient-rights backstop sandboxes** from REF-LANDLOCK.

## Ideas to reject or treat carefully
- making host-global paths foundational again
- turning every service into a path string just because Plan 9 could
- overcommitting to persistence or revocation before the minimal object/view core is proven
- assuming portal persistence, revocation, or UX semantics are “obvious” without receipts and inspection tools
- adopting network-oriented content-addressing assumptions (routing, public lookup, pinning economics) when ViewFS only needs the local object-identity lessons
- importing cloud-sync-first workflow UX when local-first, inspectable playbooks are enough for Phase 1
- making bookmark-like durable grants invisible or irrecoverable to the user


### L16. Keep host backstops separate from semantics
- REF-OPENAT2, REF-CAPSTD, and REF-LANDLOCK are useful precisely because they help hold a line while a richer model is still under construction.
- Therefore: use host bridge/backstop tactics during bring-up, but make them visible debt instead of the conceptual center of ViewFS.

### L17. Open/save/transfer/reopen/reveal are one routing family
- REF-XDG-FILECHOOSER, REF-XDG-DOCUMENTS, REF-XDG-FILETRANSFER, REF-XDG-OPENURI, and REF-ANDROID-SAF all point to related grant and routing problems rather than isolated APIs.
- Therefore: ViewFS should unify these flows through receipts and route sheets, while still preserving the distinct authority classes.

### L18. Great text UIs can expose services as objects
- REF-PLAN9-PLUMB and REF-PLAN9-ACME show that text-centric tools can still expose rich structured services and routes.
- Therefore: the ViewFS shell should feel like an object router and inspector, not just a place where strings happen.

## More nifty ideas worth stealing
- **Loud debt markers for ambient fallback** from REF-CAPSTD plus REF-LANDLOCK.
- **Route sheets for object/URI actions** from REF-PLAN9-PLUMB and REF-XDG-OPENURI.
- **File-served tool control surfaces** from REF-PLAN9-ACME.
- **Receipt trays and block-local object reuse** inspired by REF-WARP-BLOCKS.
- **Safe replay with stripped authority** as a ViewFS-native extension of attenuation lessons from REF-CAPSICUM-RIGHTS and REF-FUCHSIA-DIR-CAPS.


### L19. Workspace binds, recents, and URI launch should not collapse into one “open” story
- REF-ANDROID-SAF, REF-XDG-FILECHOOSER, REF-XDG-FILETRANSFER, REF-XDG-DOCUMENTS, and REF-XDG-OPENURI each describe related but materially different grant/routing behaviors.
- Therefore: ViewFS should make workspace/tree binds, durable recents, transfer handoffs, and URI routes visibly different in both receipts and shell UX.

### L20. Shell suggestions should degrade honestly when authority is stale
- REF-FISH, REF-NUSHELL, REF-WEZTERM-ZONES, and REF-WARP-CMDPALETTE point toward a shell that can be both fast and semantically rich.
- Therefore: ViewFS should teach completions and palettes to say “rebind needed”, “portal needed”, or “ambient debt” instead of failing later with fake path errors.

## Even more nifty ideas worth stealing
- **Open-directory-as-workspace** from REF-ANDROID-SAF, but rendered as an explicit view bind.
- **Session-to-workspace promotion** from the contrast between REF-XDG-FILETRANSFER and REF-XDG-FILECHOOSER.
- **Truthful stale-grant suggestions** from combining REF-FISH with REF-WEZTERM-ZONES metadata.


### L21. Keep recent items and reopen handles honest
- REF-ITERM-SHELLINT, REF-ANDROID-SAF, and REF-XDG-DOCUMENTS all show the value of recency and reopen, but they also show that “recent” and “still authorized” are not the same thing.
- Therefore: ViewFS should make recents useful without letting them masquerade as silent durable authority.

### L22. Terminal metadata should be inspectable by humans, not just consumed by features
- REF-WEZTERM-SHELL-INT, REF-ITERM-SHELLINT, and REF-GHOSTTY-OSC133-OVERLAY show that semantic prompt/block metadata unlocks navigation, output selection, and protocol debugging.
- Therefore: ViewFS should ship a terminal inspector/debug view early.

## Yet more nifty ideas worth stealing
- **Typed object hyperlinks** from REF-ITERM-OSC8, but routed through ViewFS route sheets instead of raw URL launches.
- **Visible command marks and searchable command history** from REF-ITERM-SHELLINT.
- **Semantic-zone debug overlay** from REF-GHOSTTY-OSC133-OVERLAY.

### L23. Keep live handles, durable refs, and receipts separate
- REF-CAPSTD, REF-XDG-REQUEST, REF-XDG-FILECHOOSER, REF-XDG-FILETRANSFER, and REF-ANDROID-SAF point to different classes of thing: current capability values, interaction/request objects, durable reopen descriptors, and historical outcomes.
- Therefore: ViewFS should let shell history, recents, and route sheets talk about these classes explicitly instead of treating every remembered object as live authority.

## Additional ideas worth stealing
- **Request-handle plus response-signal interaction objects** from REF-XDG-REQUEST for chooser/save/rebind dialogs.
- **Authority HUDs and receipt cards** as a ViewFS-native synthesis of REF-WEZTERM-SHELL-INT, REF-ITERM-SHELLINT, and REF-WARP-BLOCKS.
- **Safe transcript sharing** where receipts survive but live handles do not.

### L24. Saved shell memory should stay useful without becoming authority
- REF-XDG-REQUEST, REF-XDG-FILECHOOSER, REF-XDG-FILETRANSFER, REF-ITERM-SHELLINT, REF-WEZTERM-SHELL-INT, and REF-WARP-WORKFLOWS all point to a world where interactions, history, and reusable workflow memory are powerful but not identical to live grants.
- Therefore: ViewFS should make journals, notebooks, workflows, and pane restore explicitly class-aware (`live`, `ref`, `receipt`, `note`) instead of letting saved state silently revive authority.

## More ideas worth stealing
- **Session restore checklists** that restore layout first and authority second.
- **Authority diffs before replay** so reruns show what is already live versus what needs rebind.
- **Notebook truth badges** (`ready`, `portal`, `receipt-only`, `stale`) on every replayable cell.
- **Receipt-to-workflow promotion** that turns a past successful block into a reusable recipe without exporting hidden grants.


### L25. Indexes, recents, and palettes are registries, not authority
- REF-GNOME-TRACKER, REF-GTK-RECENT, REF-ANDROID-SAF, and REF-WARP-CMDPALETTE all show that discovery, recency, and searchable selection can be extremely valuable without being the same thing as live access.
- Therefore: ViewFS should keep selector registries advisory and force any authority transition back through handles, refs, receipts, or explicit portal/rebind seams.

## More ideas worth stealing
- **Sandboxed metadata extraction** from REF-GNOME-LOCALSEARCH.
- **One typed omnibox/palette** from REF-WARP-CMDPALETTE, but with explicit provenance and authority badges.
- **Recent-item stores as advisory per-user registries** from REF-GTK-RECENT.
- **Eligibility/existence/status checks in search tooling** from REF-GNOME-LOCALSEARCH.


### L26. Opening a workspace and trusting its automation are different actions
- REF-VSCODE-WORKSPACE-TRUST, REF-JETBRAINS-PROJSEC, REF-DIRENV-ALLOW, REF-DIRENV-REQUIREALLOWED, and REF-VSCODE-JUPYTER-TRUST all point to the same lesson: browsing project contents and letting project-defined automation execute are materially different trust decisions.
- Therefore: ViewFS should make workspace binds useful in a restricted state first, then layer explicit approvals for env hooks, tasks, launchers, notebooks, and agents.

## More ideas worth stealing
- **Restricted-mode workspace opening** from REF-VSCODE-WORKSPACE-TRUST.
- **User-vs-workspace automation split** from REF-VSCODE-TASKS.
- **Trust dialogs that name risky action classes** from REF-JETBRAINS-PROJSEC.
- **Per-directory allow/deny with reapproval on watched-file changes** from REF-DIRENV-ALLOW and REF-DIRENV-REQUIREALLOWED.
- **Notebook read-before-run posture** from REF-VSCODE-JUPYTER-TRUST.


### L27. Watch feeds are hints, not truth
- REF-INOTIFY, REF-APPLE-FSEVENTS, REF-WIN-USN, REF-WIN-READDIRCHANGES, and REF-WATCHMAN-TROUBLE all show that file-watch systems need overflow/recrawl/rebuild stories.
- Therefore: ViewFS should make scoped live updates wonderful, but make rebuild/rescan and degraded coverage first-class states.

## More ideas worth stealing
- **Watch health badges and explicit rebuild actions** inspired by REF-INOTIFY, REF-APPLE-FSEVENTS, and REF-WATCHMAN-TROUBLE.
- **Volume-log recovery contrasted with directory-scoped notifications** from REF-WIN-USN and REF-WIN-READDIRCHANGES.
- **Remote-risk / unsupported provider badges** from REF-WATCHMAN-INSTALL.


### L28. Link-like convenience objects are useful, but they are not one seam
- REF-OPENAT2, REF-LINUX-PATHLOOKUP, REF-WIN-SHELLLINK, REF-APPLE-BOOKMARKS, and REF-APPLE-SECBOOKMARK all point to the same lesson: path indirection, durable reopen, and launch shortcuts solve different problems.
- Therefore: ViewFS should keep namespace aliasing, durable reopen, route/launch shortcuts, and transcript hyperlinks visibly distinct.

## More ideas worth stealing
- **Nofollow / rooted compat walkers** from REF-OPENAT2, REF-LINUX-PATHLOOKUP, and REF-CAPPRIMS-FS.
- **Clickable explicit hyperlinks** from REF-WEZTERM-HYPERLINKS rather than only cwd-heuristic file guessing.
- **Semantic-history-style filename navigation**, but clearly marked as heuristic, from REF-ITERM-SEMHIST.
- **Retargetable desktop shortcuts** as route objects rather than identity truth, inspired by REF-WIN-SHELLLINK.
- **Bookmark-based durable reopen** as non-bearer descriptors, inspired by REF-APPLE-BOOKMARKS and REF-APPLE-SECBOOKMARK.


### L30. Durable anchors, live binds, stale shadows, and repair plans are different seams
- REF-XDG-DOCUMENTS, REF-APPLE-SECSTART, REF-APPLE-SECRESOLVE, REF-ANDROID-SAF, REF-MS-FUTUREACCESSLIST, REF-WICG-FSACCESS, REF-CAPSICUM-HANDBOOK, and REF-LINUX-PIDFD all point to the same lesson: durable reopen state, live-handle truth, stale-but-repairable state, and historical receipts solve different problems.
- Therefore: ViewFS should let shell UX talk about `durable anchor`, `live now`, `stale shadow`, `repair ladder`, and `receipt only` explicitly instead of treating every remembered import as current authority.

## More ideas worth stealing
- **Stale shadow chips** from Apple bookmark staleness and web permission ladders.
- **Repair ladders** from portal/session flows and explicit permission request APIs.
- **Durable-access hygiene racks** from FutureAccessList-style bounded lists.
- **Rebind receipts** that say whether continuity was exact, repaired, or uncertain.

### L29. Origin and quarantine are useful, but only when they stay separate from trust and recency
- REF-APPLE-GATEKEEPER, REF-APPLE-QUARANTINEKEY, REF-MS-ATTACHMENTMGR, REF-MS-MOTW-OFFICE, REF-MS-APPGUARD, and REF-MS-SMARTSCREEN all point to the same lesson: origin/risk metadata helps most when guarded-open, trust-clear, and launch semantics do not collapse into one action.
- Therefore: ViewFS should treat origin badges, quarantine state, safe-open lanes, and explicit trust receipts as separate surfaces, and should keep that truth visible in shell history, recents, palettes, and workspace onboarding.

## More ideas worth stealing
- **Origin badges and trust ladders** inspired by Gatekeeper, MOTW, and Application Guard.
- **Default-to-peek / open-safe** actions for risky document-like objects.
- **Receipt cards for trust clears and sanitized exports** so risky-object handling stays transcript-visible.
- **Code-bearing versus document-bearing action hints** so the shell can be honest about why one object gets preview while another stays blocked.


### L30. Warm-state and offline promises should not collapse
- REF-IPFS-PERSISTENCE, REF-NIX-REALISE, REF-NIX-COPY, REF-NIX-PREFETCH-FILE, REF-OSTREE-REPO-MGMT, REF-OSTREE-STATIC-DELTAS, REF-SVCWORKER-SPEC, and REF-MDNPREFETCH all show that hinting, caching, hydration, retention, mirroring, and self-contained transport artifacts are different promises.
- Therefore: ViewFS should keep `hint-only`, `cached`, `hydrated`, `pinned`, `mirrored`, and `offline-bundled` as distinct user-visible classes.

## More ideas worth stealing
- **Hydration plans** from the contrast between REF-NIX-PREFETCH-FILE and REF-NIX-REALISE.
- **Mirror versus bundle discipline** from REF-OSTREE-REPO-MGMT and REF-OSTREE-STATIC-DELTAS.
- **Explicit retention/pinning** from REF-IPFS-PERSISTENCE.
- **Offline-readiness badges** inspired by REF-MS-ALWAYSOFFLINE and REF-SVCWORKER-SPEC, but kept truthful about what is actually local.


### L31. Creator-populated namespaces beat self-granting convenience
- REF-FUCHSIA-SANDBOXING, REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-DICTCAP, and REF-XDG-DOCUMENTS all point to the same lesson: a more-authoritative party assembles a restricted namespace and grouped authority explicitly rather than letting the child rediscover or widen it ambiently.
- Therefore: ViewFS should keep grouped kits, view fragments, live binds, launch kits, and historical receipts as separate seams, and it should make child namespace assembly explicit and inspectable.

## More ideas worth stealing
- **Launch rehearsal cards** from combining REF-FUCHSIA-SANDBOXING with REF-WEZTERM-SHELL-INT and REF-WARP-BLOCKS.
- **Bundle/kit inspectors** from REF-FUCHSIA-DICTCAP, but rendered as human-readable cards.
- **Bind-versus-launch diffs** so panes can compare current authority with candidate child assembly before execution.
- **Receipt-only recipe save** so history stays reusable without serializing live authority.


### L32. Portal request state, selection, and live bind are different classes
- REF-XDG-PORTAL-DESIGN, REF-XDG-REQUEST, REF-XDG-FILECHOOSER, REF-XDG-DOCUMENTS, and REF-ANDROID-SAF all point to the same lesson: mediated interactions have at least request state, chooser-owned candidate space, selected outcomes, minted grants/refs, and whatever finally becomes live authority in the app.
- Therefore: ViewFS should keep request objects, candidate/designation surfaces, selections, grants/refs, live binds, and receipts visibly distinct instead of calling all of them “opened”.

## More ideas worth stealing
- **Chooser-owned candidate sheets** from REF-XDG-PORTAL-DESIGN and REF-XDG-FILECHOOSER.
- **Staging trays between selection and bind** as a ViewFS-native synthesis of REF-XDG-REQUEST, REF-WARP-BLOCKS, and REF-PLAN9-PLUMB.
- **Ops-aware action filtering** from REF-ANDROID-SAF provider flags.
- **Quiet restricted mode, stronger prompt later** from REF-VSCODE-WORKSPACE-TRUST and the Workspace Trust blog post.

### L33. Retrofitting capability discipline is a tooling problem, not just a principles problem
- REF-CAPSICUM-ADOPTION is a useful reminder that designing for capability mode up front is much easier than “Capsicumizing” an existing program after the fact, and that tracing/diagnosing authority failures becomes crucial.
- Therefore: ViewFS should invest early in request/grant/bind ledgers, ambient-debt sirens, and explain inspectors instead of assuming developers will infer the missing authority story from ordinary failures.



### L34. Prepare, approve, and execute are different classes
- REF-PLAN9-PLUMB, REF-XDG-REQUEST, REF-DENO-PERMISSIONS, REF-ANDROID-DOCPROVIDER, and REF-VSCODE-WORKSPACE-TRUST all point to the same lesson: a useful system can keep intents typed, plans inspectable, approvals exact, and execution/productive restriction visibly distinct.
- Therefore: ViewFS should make route-plan cards, approval checkpoints, restricted execution states, and result receipts first-class instead of collapsing them into one magical shell action.

## More ideas worth stealing
- **Prepare-versus-commit route cards** from combining REF-PLAN9-PLUMB with REF-WEZTERM-SHELL-INT.
- **Exact approval basis** from SlopOS's own approval-basis posture, reinforced by REF-DENO-PERMISSIONS.
- **Provider-ops-aware plans** from REF-ANDROID-DOCPROVIDER.
- **Restricted-but-productive execution posture** from REF-VSCODE-WORKSPACE-TRUST.


### L35. Suggested automation, promoted workflows, and run history are different classes
- REF-WARP-WORKFLOWS, REF-WARP-NOTEBOOKS, REF-VSCODE-TASKS, REF-VSCODE-WORKSPACE-TRUST, REF-DIRENV-ALLOW, REF-DIRENV-REQUIREALLOWED, and REF-ITERM-SHELLINT all point to the same lesson: saved automation is much more useful when source provenance, adoption, re-approval, and run history stay visible instead of collapsing into one sticky command object.
- Therefore: ViewFS should keep externally suggested recipes, promoted user-owned workflows, prepared run plans, committed runs, and history receipts visibly distinct instead of calling all of them “the workflow”.

## More ideas worth stealing
- **Promote-to-mine flows** from combining REF-WARP-WORKFLOWS with REF-VSCODE-TASKS and REF-VSCODE-WORKSPACE-TRUST.
- **Reinspect / re-promote badges** inspired by REF-DIRENV-REQUIREALLOWED.
- **Suggestion trays with provenance chips** as a ViewFS-native synthesis of REF-WARP-BLOCKS, REF-WARP-NOTEBOOKS, and REF-PLAN9-PLUMB.
- **Result-to-workflow forks** that preserve history while creating a new user-owned recipe.


### L36. Borrowed authority, durable delegation, and recall are different classes
- REF-SEL4-CSPACE, REF-XDG-DOCUMENTS, REF-APPLE-SECBOOKMARK, REF-APPLE-SECSTART, REF-DENO-PERMISSIONS, and REF-DIRENV-REQUIREALLOWED all point to the same lesson: a request to borrow, live current access, durable reopen/delegation, and the conditions under which that access ends should stay visibly separate.
- Therefore: ViewFS should keep lend requests, live borrowed handle sets, durable delegated refs, issuer-side recall/expiry controls, and loan-end receipts as different seams instead of calling all of them “the shared handle”.

## More ideas worth stealing
- **Lend-for-this-run** flows from combining REF-DENO-PERMISSIONS with REF-WEZTERM-SHELL-INT and REF-ITERM-SHELLINT.
- **Borrow badges and expiry rails** inspired by REF-XDG-DOCUMENTS plus semantic shell metadata.
- **Promote-from-borrow** as an explicit class upgrade, inspired by REF-APPLE-SECBOOKMARK and REF-APPLE-SECSTART.
- **Issuer-visible recall and borrower-visible end-state receipts** from the contrast between REF-SEL4-CSPACE and REF-XDG-DOCUMENTS.


### L37. Past success, exact basis, and renewed authority are different classes
- SlopOS `approval-basis-posture-v0.md`, REF-DIRENV-REQUIREALLOWED, REF-APPLE-SECRESOLVE, REF-XDG-REQUEST, REF-XDG-DOCUMENTS, REF-DENO-PERMISSIONS, and REF-MS-FUTUREACCESSLIST all point to the same lesson: reuse gets dangerous when old success is allowed to float forward onto newer mutable state.
- Therefore: ViewFS should keep reuse candidates, exact basis records, current drift checks, fresh reconsent checkpoints, renewed artifacts, and reuse receipts visibly distinct instead of calling all of them “replay”.

## More ideas worth stealing
- **Basis diff drawers** from combining REF-DIRENV-REQUIREALLOWED with REF-WEZTERM-SHELL-INT.
- **Receipt-only fallback** when exact reuse is no longer honest.
- **Renew-with-narrowing** instead of default keep-everything permission carry-forward.
- **Bounded durable reopen hygiene** inspired by REF-MS-FUTUREACCESSLIST.

### L38. Policy truth, shell advice, diagnostics, and audit history are different classes
- REF-CEDAR-AUTHZ, REF-CEDAR-VALIDATION, REF-OPA-CORE, REF-OPA-DECISIONLOGS, REF-POLKIT-AUTHORITY, and REF-GHOSTTY-OSC133-OVERLAY all point to the same lesson: structural policy validation, authoritative decision-making, shell-level suggestion/ranking, per-evaluation explanation, and durable logs/debugging material should not collapse into one helper plane.
- Therefore: ViewFS should keep validation/schema material, authoritative policy/caveat material, shell advice rails, decision diagnostics, and durable logs/receipts visibly distinct instead of calling all of them “policy.”

## More ideas worth stealing
- **Policy lenses** from combining REF-CEDAR-AUTHZ with REF-WEZTERM-SHELL-INT and REF-GHOSTTY-OSC133-OVERLAY.
- **Advice rails with loud non-authoritative labeling** from the contrast between REF-OPA-CORE and REF-CEDAR-AUTHZ.
- **Diagnostic cards with determining-policy and error summaries** from REF-CEDAR-AUTHZ.
- **Redacted audit traces** inspired by REF-OPA-DECISIONLOGS.
- **Retained-authorization caution** from REF-POLKIT-AUTHORITY.

### L39. The current judge, the current cut, the fallback rail, and the repair hint are different classes
- REF-OPA-DISCOVERY, REF-CEDAR-VALIDATION, REF-CEDAR-AUTHZ, REF-SPICEDB-CONSISTENCY, and REF-XDG-REQUEST all point to the same lesson: dynamic policy/config selection can be useful, but the authoritative choice, exact point-in-time cut, fallback candidates, and repair suggestions should not collapse into one magical helper.
- Therefore: ViewFS should keep policy-family/catalog choice, exact authoritative cuts/consistency posture, fallback candidates, repair proposals, and durable selection receipts visibly distinct instead of calling all of them “policy selection.”

## More ideas worth stealing
- **Cut pickers** from combining REF-OPA-DISCOVERY with REF-WEZTERM-SHELL-INT and REF-GHOSTTY-SHELLINT.
- **Consistency badges** inspired by REF-SPICEDB-CONSISTENCY and REF-ZANZIBAR.
- **Repair rails** that stay loudly non-authoritative, from the contrast between REF-CEDAR-AUTHZ and REF-OPA-DISCOVERY.
- **Selection receipts that preserve history without silently reselecting** from combining REF-XDG-REQUEST with exact-basis discipline.



### L40. Proposal sources, escalation lanes, and authoritative adoption are different classes
- REF-GIT-CONFIG-ORIGIN-SCOPE, REF-VSCODE-CHAT-CUSTOM-DIAG, REF-VSCODE-MCP-SERVERS, REF-VSCODE-AGENT-PERMISSIONS, REF-POLKIT-AUTHORITY, and REF-DENO-PERMISSIONS all point to the same lesson: a helpful system can expose many proposal sources and scope levels, but suggestion surfaces, escalation prompts, authoritative adoption, and durable history should not collapse into one magical helper lane.
- Therefore: ViewFS should keep proposal origin/source, proposal lane/scope, escalation requests, authoritative adoptions, and durable adoption receipts visibly distinct instead of calling all of them “the setting” or “the policy choice.”

## More ideas worth stealing
- **Proposer badges with origin and scope** from combining REF-GIT-CONFIG-ORIGIN-SCOPE with REF-VSCODE-CHAT-CUSTOM-DIAG.
- **Adopt-once versus adopt-for-workspace/profile ladders** inspired by REF-VSCODE-AGENT-PERMISSIONS and REF-VSCODE-MCP-SERVERS.
- **Authority-versus-agent split** from REF-POLKIT-AUTHORITY.
- **Deny-ceiling and narrowest-first UX** reinforced by REF-DENO-PERMISSIONS.



### L41. Deny ceilings, scope eligibility, and narrowing are different classes
- REF-CEDAR-SECURITY, REF-DENO-PERMISSIONS, REF-VSCODE-CONTRIB-SCOPES, REF-VSCODE-WORKSPACE-TRUST-EXT, REF-VSCODE-AGENT-TOOLS, and REF-VSCODE-112 all point to the same lesson: a useful system can keep explicit vetoes, applicability-at-scope, narrowing choices, current-session autonomy, and broader standing adoption visibly separate.
- Therefore: ViewFS should keep deny ceilings, scope-eligibility rules, narrowing transforms, escalation attempts, and durable adoption history visibly distinct instead of calling all of them “the permission choice.”

## More ideas worth stealing
- **Ceiling pills** from combining REF-CEDAR-SECURITY with REF-WEZTERM-SHELL-INT and REF-GHOSTTY-SHELLINT.
- **Adopt-the-narrowest-safe-rung** from combining REF-DENO-PERMISSIONS with REF-VSCODE-AGENT-TOOLS.
- **Non-widenable source badges** inspired by REF-VSCODE-CONTRIB-SCOPES and REF-VSCODE-WORKSPACE-TRUST-EXT.
- **Queued steering against explicit session state** from REF-VSCODE-112 and REF-VSCODE-CHAT-OVERVIEW.


### L42. Policy source class, trust-state gating, user preference, imported helper material, and effective state are different classes
- REF-VSCODE-AI-POLICIES, REF-VSCODE-ENTERPRISE-POLICIES, REF-VSCODE-WORKSPACE-TRUST-EXT, REF-VSCODE-MCP-CONFIG, REF-GIT-CONFIG-ORIGIN-SCOPE, and REF-DENO-PERMISSIONS all point to the same lesson: a useful system can show many source layers and trust postures, but higher-authority ceilings, trust-state withholding, lower-precedence preferences, imported helper configs, and effective active state should not collapse into one magical settings plane.
- Therefore: ViewFS should keep owner/org policy sources, trust-state gates, user/profile preferences, workspace/imported helper material, effective active state, and durable history visibly distinct instead of calling all of them “the current policy.”

## More ideas worth stealing
- **Origin stacks with explicit winner/loser reasons** from combining REF-GIT-CONFIG-ORIGIN-SCOPE with REF-VSCODE-AI-POLICIES.
- **Trust shutters** inspired by REF-VSCODE-WORKSPACE-TRUST-EXT and REF-VSCODE-WORKSPACE-TRUST.
- **Import quarantine trays** from REF-VSCODE-MCP-CONFIG and REF-VSCODE-MCP-SERVERS.
- **Override ledgers with deny/audit posture** reinforced by REF-DENO-PERMISSIONS.


### L35. Some state types should be authorable only from protected scopes
- REF-GIT-PROTECTED-CONFIG, REF-GIT-SAFE-DIRECTORY, REF-VSCODE-ENTERPRISE-POLICIES, REF-VSCODE-WORKSPACE-TRUST-EXT, and REF-DENO-PERM-BROKER all point to the same lesson: not every visible source is allowed to author every class of state.
- Therefore: ViewFS should keep a source-class × state-class authorability matrix explicit, and some cells should be hard-deny or protected-only.

### L36. Manual invocation and automatic influence are different seams
- REF-VSCODE-PROMPT-FILES, REF-VSCODE-CUSTOM-INSTRUCTIONS, REF-VSCODE-CUSTOM-AGENTS, and REF-VSCODE-CUSTOMIZE-AI all point to the same lesson: automatically-applied guidance, manually-invoked helpers, and persistent role/tool bundles solve different problems.
- Therefore: ViewFS should keep invoke-only helper lanes distinct from always-on adopted state.

## More ideas worth stealing
- **Protected-only state classes** from REF-GIT-PROTECTED-CONFIG and REF-GIT-SAFE-DIRECTORY.
- **Latched invoke vs adopt** from REF-VSCODE-PROMPT-FILES.
- **Source-tooltip / source-class inspection** from REF-VSCODE-CUSTOM-AGENTS.
- **Broker badge / local-prompts-are-explanatory-only** from REF-DENO-PERM-BROKER.


### L43. Publisher trust, install presence, enablement, start approval, live session, and request selection are different classes
- REF-VSCODE-PUBLISHER-TRUST, REF-VSCODE-AGENT-PLUGINS, REF-VSCODE-MCP-SERVERS, REF-VSCODE-MCP-CONFIG, REF-VSCODE-COPILOT-SECURITY, REF-VSCODE-112, and REF-DENO-PERM-BROKER all point to the same lesson: a useful helper ecosystem can keep publisher trust, installed presence, startup trust, enablement, live session state, and request-scoped tool selection visibly separate.
- Therefore: ViewFS should keep publisher trust, installed helper packages, configured helper definitions, enabled state, start approvals, live brokered sessions, request-scoped tool selections, and durable history distinct instead of calling all of them “the installed helper.”

## More ideas worth stealing
- **Publisher badges** from REF-VSCODE-PUBLISHER-TRUST.
- **Start-gate drawers** from combining REF-VSCODE-MCP-SERVERS with REF-VSCODE-COPILOT-SECURITY.
- **Live-session beacons** from REF-DENO-PERM-BROKER and REF-VSCODE-AGENT-PLUGINS.
- **Tool racks** from REF-VSCODE-MCP-SERVERS and REF-VSCODE-AGENT-TOOLS.


### L44. Helper feature kinds, completion hints, request bindings, and live invocations are different classes
- REF-MCP-SPEC-FEATURES, REF-MCP-RESOURCES, REF-MCP-PROMPTS, REF-MCP-TOOLS, REF-MCP-COMPLETION, REF-VSCODE-MCP-SERVERS-LIVE, REF-VSCODE-AGENT-TOOLS, and REF-VSCODE-PROMPT-FILES all point to the same lesson: a useful helper ecosystem can expose context/data, prompt templates, invocable tools, interactive app surfaces, and completion hints without collapsing them into current request authority or live results.
- Therefore: ViewFS should keep resource descriptors, prompt templates, tool descriptors, app surfaces, completion suggestions, request-bound attachments/selections, live invocations/results, and durable receipts visibly distinct instead of calling all of them “helper items.”

## More ideas worth stealing
- **Resource shelves** from REF-MCP-RESOURCES and REF-WEZTERM-SHELL-INT.
- **Prompt chips with argument slots** from REF-MCP-PROMPTS and REF-VSCODE-PROMPT-FILES.
- **Tool racks that stay request-bound** from REF-MCP-TOOLS, REF-VSCODE-AGENT-TOOLS, and REF-VSCODE-MCP-SERVERS-LIVE.
- **Completion popovers with loud advisory posture** from REF-MCP-COMPLETION.
- **App docks** from the contrast between REF-VSCODE-MCP-SERVERS-LIVE and SlopOS plumb/mediator seams.


### L45. Immediate requests, accepted tasks, progress lanes, input-needed checkpoints, and final results are different classes
- REF-XDG-REQUEST, REF-MCP-TASKS, REF-MCP-PROGRESS, REF-GCLOUD-LRO, REF-XDG-BACKGROUND, REF-VSCODE-TASKS-BG, and REF-VSCODE-109-BGAGENTS all point to the same lesson: a useful system can queue and watch long-running work, but request submission, task acceptance, live progress, input-needed waits, deferred final result retrieval, and durable history should not collapse into one magical background-job helper.
- Therefore: ViewFS should keep immediate requests, accepted task wrappers, live progress/status streams, input-required checkpoints, deferred final results, and durable receipts visibly distinct instead of calling all of them “the running task.”

## More ideas worth stealing
- **Task badges** from REF-MCP-TASKS and REF-WEZTERM-SHELL-INT.
- **Progress lanes** from REF-MCP-PROGRESS and REF-XDG-BACKGROUND.
- **Input-required drawers** from REF-MCP-TASKS and REF-XDG-REQUEST.
- **Result lockers** from REF-GCLOUD-LRO and REF-MCP-TASKS.
- **Queue rails / still-running follow-ups** from REF-VSCODE-109-BGAGENTS and REF-VSCODE-TASKS-BG.


### L39. Stop, forget, and rerun are different control classes
- REF-XDG-REQUEST, REF-AIP151-LRO, REF-GCLOUD-LRO, REF-MCP-TASKS, REF-TEMPORAL-INTERRUPT, REF-TEMPORAL-WFID, and REF-VSCODE-CHAT-SESSIONS all point to the same lesson: ending an interaction, cancelling work, force-terminating work, forgetting retained state, retrying fresh, and forking from prior history are not the same act.
- Therefore: ViewFS should keep close/cancel acts, termination acts, detach/delete acts, retry-fresh acts, reset/fork/attach acts, and durable receipts visibly distinct instead of offering one generic stop-or-rerun menu.

## More ideas worth stealing
- **Stop ladders** from combining REF-XDG-REQUEST, REF-GCLOUD-LRO, and REF-TEMPORAL-INTERRUPT.
- **Detach rails** from the delete-versus-cancel split in REF-GCLOUD-LRO and REF-MCP-TASKS.
- **Retry-vs-fork drawers** from REF-TEMPORAL-WFID and REF-VSCODE-CHAT-SESSIONS.
- **Expiry/history-only badges** from REF-AIP151-LRO and REF-MCP-TASKS.


### L46. Observe-only lanes, interactive attach, control messages, debug exec, and sideband tunnels are different classes
- REF-KUBECTL-LOGS, REF-KUBECTL-ATTACH, REF-KUBECTL-PORTFWD, REF-TMUX, REF-TEMPORAL-MESSAGES, and REF-XDG-INPUTCAPTURE all point to the same lesson: a useful live-session system can expose follow streams, interactive attachment, read-only clients, control messages, and temporary side channels without collapsing them into one magical connected session.
- Therefore: ViewFS should keep read-only observe/query/follow lanes, interactive attach lanes, control-message lanes, injected exec/debug lanes, sideband tunnel/forward lanes, and durable transcripts visibly distinct instead of calling all of them “the session.”

## More ideas worth stealing
- **Follow tails** from REF-KUBECTL-LOGS.
- **Read-only attach rails** from REF-TMUX and the contrast with REF-KUBECTL-ATTACH.
- **Query / signal / update separation** from REF-TEMPORAL-MESSAGES.
- **Armed-versus-active badges** from REF-XDG-INPUTCAPTURE.
- **Sideband tunnel badges** from REF-KUBECTL-PORTFWD.


### L19. Transfer channels should negotiate explicitly, not smuggle ambient reach
- REF-XDG-FILETRANSFER and REF-WAYLAND-DATADEVICES both show that drag/drop and clipboard-style exchange work best when the offer, accepted representation, and transfer act remain explicit.
- Therefore: ViewFS should treat inter-process transfer as a typed mediated lane, not as a loophole where paths quietly regain authority.

## Fresh evaluation note
- `docs/90-inspirations/slopos-datacube-evaluation.md` records the current recommendation: keep freezing separations and shell truths, but postpone heavyweight object-store, mutable-head, and durable-capability choices until SlopOS itself settles more of the surrounding terrain.

## Another nifty idea worth stealing
- **Explicit MIME/data-offer negotiation for transfer lanes** from REF-WAYLAND-DATADEVICES.


### L46. Immutable storage, durable roots, and durable reopen are different classes
- REF-EROS, REF-CAPROS-USERDRIVERS, REF-TREESLS-SOSP23, and REF-XDG-DOCUMENTS all point to the same lesson: persisting exact data, persisting authority graphs, checkpointing system state, and letting a user reopen a thing later are related but materially different problems.
- Therefore: ViewFS should keep immutable object storage, optional durable-root/epoch stories, and durable reopen descriptors visibly separate instead of calling all of them “persistence.”

## More ideas worth stealing
- **Optional durable-root mode** from the contrast between REF-EROS and REF-XDG-DOCUMENTS.
- **Rollback/resurrection paranoia** from REF-CAPROS-USERDRIVERS and SlopOS's CapStore draft.
- **Capability-tree checkpoint thinking** from REF-TREESLS-SOSP23, but only as a later experiment once the smaller seams hold.

### L47. View-scoped query, live feed, and ambient inventory are different classes
- REF-HAIKU-QUERIES, REF-APPLE-NSMETADATAQUERY, REF-GNOME-LOCALSEARCH, and SlopOS `attrfs-posture-v0.md` all point to the same lesson: query can be wonderful without becoming a generic machine-wide inventory oracle.
- Therefore: ViewFS should keep snapshot query results, live feeds, saved-query manifests, and global inventory/count probes visibly separate instead of calling all of them “search.”

## More ideas worth stealing
- **Snapshot-first smart folders** from the contrast between REF-APPLE-NSMETADATAQUERY and SlopOS AttrFS.
- **Saved-query manifests owned by the shell** rather than by arbitrary apps.
- **Handle-returning results instead of path/count probes** as the default query shape.

### L48. Pane metadata, semantic zones, and semantic history are different classes
- REF-WEZTERM-ZONES, REF-WEZTERM-USERVARS, REF-ITERM-SHELLINT, REF-ITERM-SEMHIST, and REF-GHOSTTY-OSC133-OVERLAY all point to the same lesson: the terminal gets dramatically better when prompt/input/output regions and pane metadata are explicit, inspectable, and kept distinct from ordinary transcript text.
- Therefore: ViewFS should keep pane metadata, semantic zones, history rows, and live prompt input visibly separate instead of pretending the whole terminal is just one text stream.

## More ideas worth stealing
- **Pane vars for chrome truth** from REF-WEZTERM-USERVARS.
- **Prompt-local click/edit rules** from REF-WEZTERM-ZONES and REF-GHOSTTY-OSC133-OVERLAY.
- **Truth-labeled semantic history** from combining REF-ITERM-SHELLINT with REF-ITERM-SEMHIST.


## More ideas worth stealing

### L49. Narrow continuity, durable reopen, and persistent authority are different classes
- REF-FUCHSIA-IDLE-STOP, REF-SYSTEMD-FDSTORE, REF-XDG-REQUEST, REF-XDG-FILETRANSFER, and the current SlopOS datacube drafts all point to the same lesson: resuming a narrow live lane later is a materially smaller class than durable reopen or persistent authority.
- Therefore: ViewFS should keep escrow/resume artifacts, restart-stable handle lockers, durable reopen descriptors, and persistent-root stories visibly separate instead of calling all of them “saved session state.”

## More ideas worth stealing
- **Escrowable narrow continuity** from REF-FUCHSIA-IDLE-STOP.
- **Restart-stable exact-handle lockers** from REF-SYSTEMD-FDSTORE.
- **Expiry-friendly resumable request chips** from combining REF-XDG-REQUEST with REF-XDG-FILETRANSFER.
- **Resume-this-lane, not restore-the-world** as a product slogan.

### L50. Trusted review chrome, collapsible command sections, and transcript text are different classes
- REF-VSCODE-WORKSPACE-TRUST, REF-VSCODE-109-BGAGENTS, REF-VSCODE-110-TERMSECTIONS, REF-NUSHELL, and REF-PLAN9-PLUMB all point to the same lesson: the terminal gets better when review/gating chrome, structured command sections, and raw transcript text stop pretending to be the same surface.
- Therefore: ViewFS should keep trusted review lanes, collapsible command sections, structured object drawers, and plain transcript rows visibly separate instead of flattening everything into one scroll stream.

## More ideas worth stealing
- **Trusted review lanes** from the contrast between restricted mode and ordinary transcript flow.
- **Queue / steer / stop rails** from REF-VSCODE-109-BGAGENTS.
- **Collapsible command headers with truth badges** from REF-VSCODE-110-TERMSECTIONS.
- **Structured object drawers** from REF-NUSHELL.


### L51. Stable identity, current placement, and advertised operations are different classes
- REF-ANDROID-SAF, REF-ANDROID-DOCPROVIDER, REF-ANDROID-CREATE-DOCUMENT, and current SlopOS view/document drafts all point to the same lesson: a stable object ID, the directories/views where it appears, and the operations currently supported for it are different truths.
- Therefore: ViewFS should keep identity, current placement, held rights, and advertised operations visibly separate instead of inferring action menus from path folklore.

## More ideas worth stealing
- **Same object, many placements** from REF-ANDROID-SAF.
- **Provider-flag-driven action menus** from REF-ANDROID-DOCPROVIDER.
- **Explicitly taken durable reopen permission** from REF-ANDROID-CREATE-DOCUMENT.


### L52. Transient staging bytes, couriered live handles, committed objects, and durable reopen refs are different classes
- REF-MEMFD-CREATE, REF-MEMFD-SEALS, REF-UNIX-SCMRIGHTS, and REF-PLAN9-PLUMB all point to the same lesson: a useful system can hold exact bytes in a temporary object, freeze that object, explicitly courier it to a peer, and still keep durable commit/reopen as later and narrower questions.
- Therefore: ViewFS should keep staging capsules, couriered live handles, committed object identities, and durable reopen descriptors visibly separate instead of calling all of them “the file.”

## More ideas worth stealing
- **Draft-versus-sealed capsule badges** from REF-MEMFD-SEALS.
- **Explicit handle courier lanes** from REF-UNIX-SCMRIGHTS.
- **Commit-last compare rails** as a ViewFS-native synthesis of REF-MEMFD-CREATE and REF-PLAN9-PLUMB.



### L30. Activation carriers, badged handle copies, and object identity are different truths
- REF-SYSTEMD-SOCKETACT, REF-SYSTEMD-FDSTORE, REF-SEL4-BADGES, and REF-FUCHSIA-NAMESPACE all show that a process can start with already-delivered resources and copied capabilities that carry issuer-visible metadata.
- Therefore: keep activation slots, live handle copies, issuer-visible badges, immutable object refs, and transcript receipts visibly distinct.

### L31. Rich command chrome should advertise its truth grade
- REF-VSCODE-SHELLINT shows that shell integration has quality levels, nonce-aware protections, command decorations, sticky scroll, and command-aware navigation.
- Therefore: ViewFS should distinguish guessed blocks, marked blocks, shell-reported commands, and reviewed action objects before offering stronger actions like replay or exact reopen.

## More ideas worth stealing from this pass
- **Named activation slots and handed-in startup handles** from REF-SYSTEMD-SOCKETACT and REF-FUCHSIA-NAMESPACE.
- **Badged capability copies** from REF-SEL4-BADGES.
- **Truth-grade command blocks** from REF-VSCODE-SHELLINT plus the sibling Schell terminal notes.
- **Selection packets with a separate primary target** from the sibling Schell terminal notes.


### L53. Courier witnesses, transferred handles, command packets, and transcript rows are different classes
- REF-UNIX-SCMRIGHTS, REF-SOCKET-PASSCRED, REF-VSCODE-106-ATTCMD, REF-VSCODE-SHELLINT, REF-PLAN9-PLUMB, and the current SlopOS capshell/plumb drafts all point to the same lesson: who delivered a live thing, what live thing was delivered, what structured command/result packet was promoted for review, and what plain transcript text remains are different truths.
- Therefore: ViewFS should keep courier peer witnesses, transferred live handles, promoted command packets, durable receipts, and ordinary transcript rows visibly separate instead of flattening them into one replay/open/escalate surface.

## More ideas worth stealing
- **Peer-witness courier drawers** from combining REF-SOCKET-PASSCRED with REF-UNIX-SCMRIGHTS.
- **Explicit command-packet promotion** from REF-VSCODE-106-ATTCMD plus REF-VSCODE-SHELLINT.
- **Attach exact command/output/exit context** instead of copy-pasting transcript text.


### L54. Command packets, live process handles, lifecycle control, and deep inspection are different classes
- REF-LINUX-PIDFD, REF-LINUX-PIDFD-GETFD, REF-FREEBSD-PROCDESC, REF-VSCODE-SHELLINT, and the current SlopOS capshell drafts all point to the same lesson: an exact running process can be a capability-shaped object without forcing transcript rows, lifecycle control, debugger power, and command history to collapse into one surface.
- Therefore: ViewFS should keep prepared command packets, live process descriptors, lifecycle-control rights, deeper inspect/debug rights, and ordinary transcript/history rows visibly separate instead of flattening them into one generic process row.

## More ideas worth stealing
- **Live process cards with explicit right badges** from REF-LINUX-PIDFD and REF-FREEBSD-PROCDESC.
- **Running-versus-history truth transitions** from REF-VSCODE-SHELLINT.
- **Exact command-instance cards instead of PID folklore** as a ViewFS-native synthesis of these process-handle precedents with the SlopOS capshell drafts.


### L55. Detached fragments, live binds, and current placement are different classes
- REF-LINUX-OPEN-TREE, REF-LINUX-MOVE-MOUNT, REF-LINUX-MOUNT-SETATTR, and the current SlopOS view drafts all point to the same lesson: a subtree/view fragment can exist as a detached object, gain a narrow pre-attach posture, and only later be attached into one concrete namespace location.
- Therefore: ViewFS should keep detached fragments, pre-attach posture, live binds, and later placement/history visibly separate instead of flattening them into “that path exists.”

## More ideas worth stealing
- **Prepared-but-unattached view fragments** from REF-LINUX-OPEN-TREE.
- **Attach as a separate receipted act** from REF-LINUX-MOVE-MOUNT.
- **Pre-attach-only posture changes** from REF-LINUX-MOUNT-SETATTR.

### L56. Input origin and key identity are different truths from transcript text
- REF-XTERM-BRACKETED-PASTE and REF-KITTY-KEYBOARD both point to the same lesson: terminals get safer and more powerful when pasted bytes and richer key events are explicitly marked instead of colliding with ordinary text streams.
- Therefore: ViewFS should keep typed input, pasted input, prompt-local edit gestures, and transcript actions visibly separate instead of pretending they are all the same byte stream.

## More ideas worth stealing
- **Paste capsules / inspect-before-run** from REF-XTERM-BRACKETED-PASTE.
- **Disambiguated press/repeat/release key packets** from REF-KITTY-KEYBOARD.
- **Prompt-local gesture lanes** as a ViewFS-native synthesis of these terminal precedents with the sibling Schell terminal notes.

### L57. Exact exec objects, startup credentials, and launch basis are different classes
- REF-MAN7-FEXECVE, REF-MAN7-EXECVEAT, REF-SYSTEMD-CREDENTIALS, and the current SlopOS capshell/app-secret drafts all point to the same lesson: the exact executable object, explicit interpreter/script entry, argv/env shaping, activation-time credential delivery, and durable history are different truths.
- Therefore: ViewFS should keep exec objects, script input, argv/env basis, startup credential slots, launch receipts, and transcript/history visibly separate instead of flattening them into one vague command row or path-shaped run story.

## More ideas worth stealing
- **Launch by held executable handle or exact staged bytes** from REF-MAN7-FEXECVE and REF-MAN7-EXECVEAT.
- **Activation-time immutable credential slots** from REF-SYSTEMD-CREDENTIALS.
- **Exact-exec-object badges and launch-basis cards** as a ViewFS-native synthesis of these precedents with the SlopOS capshell drafts.


### L58. Exact exec objects, startup code closure, loader policy, and late imports are different classes
- REF-LINUX-LDSO, REF-LINUX-DLOPEN, REF-WIN-DLL-SEARCH, REF-WIN-LOADLIBRARY, and the current SlopOS capshell/code-closure drafts all point to the same lesson: one exact executable object does not by itself prove one exact startup native-code closure, and later plugin/module imports are another lane again.
- Therefore: ViewFS should keep exact exec objects, startup code closure, loader search posture, late plugin/import requests, and durable history visibly separate instead of flattening them into one vague “run this program” story.

## More ideas worth stealing
- **Closure-certainty badges** from REF-LINUX-LDSO and REF-WIN-DLL-SEARCH.
- **Loader-debt warnings** from the contrast between exact exec-object launch and mutable loader search paths.
- **Late-import / plugin route sheets** from REF-LINUX-DLOPEN and REF-WIN-LOADLIBRARY.


### L59. Selection ownership, offered representations, pasted input, and imported objects are different classes
- REF-WAYLAND-PRIMARY-SELECTION, REF-X11-ICCCM-SELECTIONS, REF-KITTY-CLIPBOARD, REF-XTERM-BRACKETED-PASTE, and the current SlopOS transfer/document portal drafts all point to the same lesson: a current clipboard/selection owner, the representations it offers, the one representation actually transferred, the pasted prompt bytes that may result, and any later imported or durable object are different truths.
- Therefore: ViewFS should keep selection owner/source, offered representations, accepted transfer payloads, prompt-input capsules, imported objects/live binds, and durable receipts/history visibly separate instead of flattening them into one magical `paste/open/import` story.

## More ideas worth stealing
- **Clipboard offer cards with MIME truth** from REF-WAYLAND-PRIMARY-SELECTION and REF-X11-ICCCM-SELECTIONS.
- **Permission-gated typed clipboard reads** from REF-KITTY-CLIPBOARD.
- **Paste-versus-import ladders** as a ViewFS-native synthesis of those transfer precedents with REF-XTERM-BRACKETED-PASTE.


### L60. Live process handles, terminal streams, controlling terminals, foreground turns, and transcript history are different classes
- REF-LINUX-CREDENTIALS-JC, REF-LINUX-SETPGID, REF-LINUX-SETSID, REF-GLIBC-LOGINTTY, REF-LINUX-TTY4, REF-VSCODE-SHELLINT, and REF-GHOSTTY-OSC133-OVERLAY all point to the same lesson: a shell can expose rich live-session ergonomics without flattening running-process identity, stream visibility, controlling-terminal posture, foreground ownership, and durable history into one vague attached-terminal story.
- Therefore: ViewFS should keep live process handles, stdio/PTY stream lanes, controlling-terminal posture, foreground-turn / interrupt-target state, and durable history visibly separate instead of flattening them into one `terminal session` class.

Steal-worthy shell moves:
- **Foreground baton pills** that say who currently owns terminal-generated signals and prompt-local interactive input.
- **TTY lease badges** that distinguish mirrored output from true controlling-terminal posture.
- **Interrupt previews** that show where Ctrl-C/Ctrl-Z style input will go before the user sends it.

### L61. Exact exec objects, selected runners, bootstrap posture, and live sessions are different classes
- REF-FUCHSIA-RUNNER, REF-FUCHSIA-CAPS, REF-OCI-RUNTIME-CONFIG, REF-OCI-PROCESS-CONFIGGO, and the current SlopOS capshell/startup-profile drafts all point to the same lesson: the exact thing selected to run, the runtime/runner that hosts it, the bootstrap posture around it, and the resulting live session are different truths.
- Therefore: ViewFS should keep exec objects, runner/runtime choice, bootstrap posture, live sessions, and durable history visibly separate instead of flattening them into one vague run row.

Steal-worthy shell moves:
- **Runner badges** from REF-FUCHSIA-RUNNER and the SlopOS startup-profile notes.
- **Bootstrap shutters** that distinguish clean start from compat/startup-hook debt.
- **Session-kind pills** (`interactive`, `batch`, `detached helper`, `history only`) as a ViewFS-native synthesis of those precedents.

### L62. Mutable prompt state and scrollback history are different classes
- REF-ITERM-CMDSELECT, REF-ITERM-CLEARBUFFER, and REF-ITERM-SHELLINT all point to the same lesson: command blocks in history can be selected, bookmarked, shared, and navigated while the live mutable prompt area remains a distinct thing.
- Therefore: ViewFS should keep the live editable prompt dock, reviewed command packets, launched sessions, and durable history visibly separate instead of flattening them into one terminal buffer.

Steal-worthy shell moves:
- **Clear scrollback, keep draft** from REF-ITERM-CLEARBUFFER.
- **Command info / bookmark / share on selected history blocks** from REF-ITERM-CMDSELECT.
- **Explicit draft-to-packet promotion** as a ViewFS-native synthesis of those precedents with the sibling Schell notes.

### L63. Handle slots, live handle copies, shared open state, and fresh reopens are different classes
- REF-MAN7-OPEN, REF-MAN7-DUP, REF-UNIX-SCMRIGHTS, REF-LINUX-PIDFD-GETFD, REF-LINUX-FLOCK, and the current SlopOS capshell handle-table drafts all point to the same lesson: one current handle slot, another live copy of that handle, the shared open-state group they may alias, and a fresh reopen to the same object are different truths.
- Therefore: ViewFS should keep slot/local binding, live aliasing, shared cursor/status/lock state, independent reopen, and durable history visibly separate instead of flattening them into one generic handle row.

Steal-worthy shell moves:
- **Twin-handle badges** from REF-MAN7-DUP and REF-UNIX-SCMRIGHTS.
- **Shared-open-state drawers** from combining REF-MAN7-OPEN, REF-LINUX-PIDFD-GETFD, and REF-LINUX-FLOCK.
- **Duplicate-versus-reopen ladders** as a ViewFS-native synthesis of those precedents with the SlopOS handle-table posture.

### L64. Locator/metadata handles, live byte-I/O handles, and durable refs are different classes
- REF-LINUX-OPATH, REF-LINUX-STATX, REF-LINUX-OPENTREE, and the current SlopOS cwd-root / handle-table drafts all point to the same lesson: one current root/object handle may only designate or inspect, while another current handle to the same object may carry live byte-I/O, and neither should be confused with a durable ref/history artifact.
- Therefore: ViewFS should keep locator/metadata handles, live byte-I/O handles, explicit reopen/escalation acts, and durable refs visibly distinct instead of calling all of them “open”.

## More ideas worth stealing
- **Handle-class badges** from REF-LINUX-OPATH plus the existing semantic-shell chrome ideas.
- **Inspect-first cards** from combining REF-LINUX-STATX with REF-WEZTERM-SEMZONE and REF-GHOSTTY-SHELLINT.
- **Open-for-more-power ladders** from the contrast between REF-LINUX-OPATH and ordinary read/write opens.
- **Root-versus-read truth** as a standing shell badge whenever a pane has a bound root but no live byte-I/O yet.

### L65. Current handle possession, launch inheritance, child slots, and launch receipts are different classes
- REF-MAN7-OPEN, REF-MAN7-EXEC3P, REF-MAN7-POSIX-SPAWN, REF-MAN7-CLOSE-RANGE, REF-MAN7-FCNTL, REF-OPENBSD-FCNTL, and the current SlopOS activation / exec-pack / handle-table drafts all point to the same lesson: a handle currently held by one process, the policy for whether it may cross a launch boundary, the exact child slot that receives a copy, and the durable launch receipt are different truths.
- Therefore: ViewFS should keep held-now authority, launch-boundary shutters/eligibility, exact child-slot delivery, and durable launch history visibly separate instead of flattening them into one vague inherited handle story.

Steal-worthy shell moves:
- **Inheritance shutters** from combining REF-MAN7-OPEN and REF-MAN7-CLOSE-RANGE.
- **Child-slot maps** from REF-MAN7-POSIX-SPAWN plus the SlopOS CH-FDSET / activation posture.
- **Authority-leak sirens** as a ViewFS-native synthesis of those launch-boundary precedents with existing launch-rehearsal cards.

### L66. Object identity, parent anchors, and namespace mutations are different classes
- REF-FUCHSIA-FSARCH, REF-FREEBSD-RIGHTS-LIVE, REF-MAN7-RENAME, and the current SlopOS cwd-root / document-portal drafts all point to the same lesson: one object identity, the source parent that can detach its old name, the destination parent that can create/replace the new name, and the mutation mode (`rename`, `replace`, `exchange`) are different truths.
- Therefore: ViewFS should keep object identity, source parent anchor, destination parent anchor, namespace-mutation act, and durable mutation receipts visibly separate instead of flattening them into one vague `move/open` story.

Steal-worthy shell moves:
- **Two-anchor rename cards** from REF-FUCHSIA-FSARCH plus the existing ViewFS route-card ideas.
- **Collision-mode ladders** (`create new only`, `replace target`, `exchange`) from REF-MAN7-RENAME.
- **Source/destination parent rights badges** from REF-FREEBSD-RIGHTS-LIVE.
- **Name-diff receipts** as a ViewFS-native synthesis that says `same object, different placement` without implying new byte authority.


### L67. Live binds, propagation posture, and peer blast radius are different classes
- REF-MAN7-MOUNTNS, REF-LINUX-OPEN-TREE, REF-LINUX-MOUNT-SETATTR, and the current SlopOS view / replication drafts all point to the same lesson: one current bind in one explicit view, that bind's propagation posture, any peer/master relationship or blast radius, and durable history are different truths.
- Therefore: ViewFS should keep live binds, propagation posture, peer/upstream relationships, and durable receipts visibly separate instead of flattening them into one vague bound-root story.

Steal-worthy shell moves:
- **Propagation badges** (`local only`, `shared`, `receive only`, `not cloneable`) from REF-MAN7-MOUNTNS.
- **Blast-radius previews** from combining REF-LINUX-OPEN-TREE with REF-LINUX-MOUNT-SETATTR.
- **Attach-private-first rails** as a ViewFS-native synthesis of those precedents with the SlopOS explicit-view / non-activating-replication posture.


### L68. Unnamed objects, namespace publication, and later receipts are different classes
- REF-LINUX-OTMPFILE, REF-MAN7-LINKAT, REF-MAN7-OPEN, and the current SlopOS CapStore / view / document-handle drafts all point to the same lesson: one exact object may already exist before it has any public name, and the later act that publishes that object into a namespace is another lane again.
- Therefore: ViewFS should keep draft/unpublished objects, publication anchors, namespace-publication acts, visible names/binds, and durable receipts visibly separate instead of flattening them into one vague `save` story.

Steal-worthy shell moves:
- **Draft-object cards** from REF-LINUX-OTMPFILE.
- **Publish-later ladders** from combining REF-LINUX-OTMPFILE with REF-MAN7-LINKAT.
- **Publication receipts** as a ViewFS-native synthesis that says `same object, now named here` without implying new byte authority or durable reopen.


### L69. Content descriptors, live handles, and receipts are different classes
- REF-OCI-DESCRIPTOR, REF-IPFS-CIDS, REF-WASI-CAPS, REF-FUCHSIA-CAPS, and the current SlopOS artifact-reference drafts all point to the same lesson: an exact content/object descriptor, one current live capability handle, and one durable receipt/history row are not the same thing even when they refer to the same underlying object.
- Therefore: ViewFS should keep descriptor envelopes, live handles/binds, hydration/publication acts, and durable history visibly separate instead of flattening them into one vague `file/object` story.

Steal-worthy shell moves:
- **Descriptor cards** showing digest/object ID, media type, size, and locator hints without implying live authority.
- **Hydrate-later ladders** that distinguish `descriptor only`, `local bytes present`, `bind here`, `publish here`, and `receipt only`.
- **Object chips in transcript/history** that stay useful after authority expires because they are clearly descriptors or receipts rather than live handles.


### L70. Imported source refs, materialized local objects, and local docrefs are different classes
- REF-XDG-DOCUMENTS, REF-ANDROID-SAF, REF-FUCHSIA-HANDLES, and the current SlopOS document-portal / import-boundary drafts all point to the same lesson: a source-side designation, a fresh local object created by explicit import/materialization, a local durable reopen designator, one current live handle, and the durable receipt about those acts are different truths.
- Therefore: ViewFS should keep imported source refs, materialized local objects, local docrefs, current live handles, and durable receipts visibly separate instead of flattening them into one vague `imported file` story.

Steal-worthy shell moves:
- **Localize-first import cards** from REF-XDG-DOCUMENTS plus the SlopOS import-to-docref boundary.
- **Stable local docref badges** inspired by REF-ANDROID-SAF, but only after explicit localization.
- **Rights-drop / duplicate-later handle truth** from REF-FUCHSIA-HANDLES so `local docref` and `live handle now` never collapse into one badge.

### L71. Semantic shell integration, bootstrap posture, and current authority are different classes
- REF-VSCODE-SHELLINT, REF-GHOSTTY-SHELLINT, REF-KITTY-SHELLINT, REF-SD-NOTIFY-BARRIER, and the current Steward shell-terminal integration notes all point to the same lesson: semantic terminal signals are useful, but the side-channel, the bootstrap mechanism that enabled it, the confidence/epoch of one event, and any current object authority are different truths.
- Therefore: ViewFS should keep semantic side channels, startup/bootstrap posture, confidence/freshness state, and current authority visibly separate instead of flattening them into one magical shell integration story.

Steal-worthy shell moves:
- **Semantic epoch badges** inspired by REF-SD-NOTIFY-BARRIER plus Steward's resync/observation-confidence posture.
- **Remembered/live/provisional labels** from Steward combined with REF-VSCODE-SHELLINT's command/cwd awareness.
- **Inspectable bootstrap shutters** from the contrast between REF-GHOSTTY-SHELLINT and REF-KITTY-SHELLINT so users can see whether integration is manual, auto-injected, or missing.


### L72. Remembered reopen, exact continuity lockers, and current live access are different classes
- REF-XDG-DOCUMENTS, REF-ANDROID-SAF, REF-APPLE-SECBOOKMARK, REF-APPLE-SECRESOLVE, REF-APPLE-SECSTART, REF-SYSTEMD-FDSTORE, and REF-FUCHSIA-LIFECYCLE all point to the same lesson: a remembered reopen designator, a fresh revalidation step, a narrow exact-handle continuity locker, one current live handle, and the durable receipt about those things are different truths.
- Therefore: ViewFS should keep remembered designators, revalidation acts, exact continuity lockers, revived live handles/binds, stale-target outcomes, and durable receipts visibly separate instead of flattening them into one vague `reopen` story.

Steal-worthy shell moves:
- **Reopen truth ladders** from combining REF-APPLE-SECBOOKMARK, REF-APPLE-SECRESOLVE, and REF-APPLE-SECSTART.
- **Exact continuity lockers** from REF-SYSTEMD-FDSTORE, but only as a narrow optional restart-continuity lane.
- **Stale / grant-needed repair rails** from REF-ANDROID-SAF plus REF-XDG-DOCUMENTS, where durable designation never guarantees that the target still resolves cleanly.
- **Remembered-versus-running continuity shelves** from REF-FUCHSIA-LIFECYCLE, where persistent state continuity is separate from the fact of being started with current capabilities now.


### L34. Transfer offers, live copied authority, later revival, and local adoption are different classes
- REF-WAYLAND-DATADEVICES, REF-UNIX-SCMRIGHTS, REF-FUCHSIA-HANDLES, REF-SYSTEMD-FDSTORE, REF-APPLE-SECBOOKMARK, and REF-APPLE-SSB-CVE2025 all point to the same lesson: a thing can be offered for transfer, copied as current live authority, remembered for later revival, and adopted locally on different seams — and security bugs appear when those seams become opaque.
- Therefore: ViewFS should keep transfer/courier offers, accepted representation choice, live copied handles, later revival designators, receiver-local adopted binds, and durable receipts visibly distinct.

## More ideas worth stealing
- **Offer sheets with explicit representation choice** from REF-WAYLAND-DATADEVICES, but rendered as human-readable shell cards.
- **Attenuate while copying** from REF-FUCHSIA-HANDLES instead of making every handoff all-or-nothing.
- **Exact local courier truth** from REF-UNIX-SCMRIGHTS, but without pretending a live copied handle is a durable reopen token.
- **Narrow continuity lockers** from REF-SYSTEMD-FDSTORE rather than silently widening every handoff into persistence.
- **Designator caution badges** from REF-APPLE-SECBOOKMARK and REF-APPLE-SSB-CVE2025 so durable revival stories stay inspectable and policy-killable.

## Added in Revision 066: designation versus authority

- **REF-W3C-CAPURL** reminds us that capability URLs are useful exactly because possession grants access, which is also why ordinary note/paste/share habits can leak them.
- **REF-OCAPN-LOCATORS** sharpens the same lesson for object-capability systems: a sturdyref locator should be considered a capability, so it should not be laundered into an innocent-looking bookmark chip.
- **REF-APPLE-APPSANDBOX-FILES** and **REF-APPLE-SECBOOKMARK-ENABLE** reinforce that persistent access across relaunch is a special, security-relevant class rather than ordinary naming.
- **REF-MS-SECBOOKMARK-CVE2025** is the cautionary reminder that persistent reopen machinery can become security-critical when its validation/storage story gets sloppy.
- **REF-XDG-DOCUMENTS** remains the better desktop shape for ordinary use: a controlled, mediator-projected view instead of casual bearer-ish paste tokens.
- **REF-WINDOWS-TERMINAL-SHELLINT** and **REF-VSCODE-SHELLINT** remain strong evidence that terminals get much better when metadata is explicit, which is exactly why ViewFS should expose `designation_only` versus `authority_ticket` instead of burying the difference.


## Added in Revision 067: caveats versus enforcement

- **REF-MACAROONS-NDSS14** reinforces that bearer-ish delegated credentials can carry contextual caveats, which is useful precisely because attenuation terms are first-class instead of hidden.
- **REF-ZCAP-LD** reinforces that delegated capabilities should carry explicit action/expiry constraints and explicit revocation handling, which keeps delegation honest but also makes lifecycle/state handling impossible to ignore.
- **REF-SEL4-MANUAL-LATEST** reminds us that copy/mint with reduced rights and revoke are explicit kernel acts, not side effects of naming.
- **REF-CAPSICUM-HANDBOOK** reinforces the simpler OS lesson that current possession of a capability matters more than ambient path folklore.
- **REF-FUCHSIA-CAPS** remains a strong reminder that discoverable namespace capability plus rights is the live authority truth for a component.
- The combined lesson is that ViewFS should keep **declared caveats**, **enforced membranes/proxies**, **live attenuated handles**, **revival designators**, and **receipt/history** visibly separate instead of one generic delegated object.

### L73. Permission outlook, current authority, and dead-state verdicts are different classes
- REF-W3C-PERMISSIONS, REF-WICG-FSACCESS, REF-XDG-DOCUMENTS, REF-ANDROID-SAF, REF-ZCAP-LD, and REF-SEL4-MANUAL-LATEST all point to the same lesson: queryable permission/liveness state, a stored designator, a current live handle, and an explicit revoke/expiry/delete/change verdict are different truths.
- Therefore: ViewFS should keep permission outlook, revival designators, current live handles, explicit death-state verdicts, and durable receipts visibly separate instead of flattening them into one vague `openable/stale` story.

Steal-worthy shell moves:
- **Permission lights** from REF-W3C-PERMISSIONS and REF-WICG-FSACCESS so `granted`, `prompt`, and `denied` are visible preflight state rather than hidden heuristics.
- **Death certificates** from combining REF-XDG-DOCUMENTS, REF-ZCAP-LD, and REF-SEL4-MANUAL-LATEST so `revoked`, `expired`, `target changed`, or `issuer unavailable` stay reason-rich instead of collapsing into `stale`.
- **Capability-flag inspectors** from REF-ANDROID-SAF so per-target affordances remain visible without pretending they are the same thing as current live authority.


### L74. Provenance claims, endorsement inputs, local appraisal, and live authority are different classes
- REF-RATS-RFC9334, REF-RATS-ENDORSEMENTS-DRAFT, REF-IN-TOTO-ATTESTATION, REF-SLSA-PROVENANCE, REF-SLSA-VERIFY-V1, REF-TUF-ROLES, REF-SIGSTORE-REKOR, REF-APPLE-GATEKEEPER, and REF-MS-MOTW-OFFICE all point to the same lesson: a useful system can preserve strong claims and endorsements, but attestation/provenance, endorsement/reference inputs, verifier-local admission, guarded-open posture, and current live authority should not collapse into one green `trusted/open` bit.
- Therefore: ViewFS should keep provenance ribbons, endorsement stacks, local admit/deny verdicts, current live handles, and durable history visibly distinct instead of calling all of them “trusted.”

## More ideas worth stealing
- **Why-runnable drawers** from combining REF-RATS-RFC9334, REF-IN-TOTO-ATTESTATION, and REF-WEZTERM-SHELL-INT.
- **Endorsement stacks with delegation/threshold truth** from REF-TUF-ROLES and REF-SIGSTORE-REKOR.
- **Verdict shutters in trusted chrome** from REF-APPLE-GATEKEEPER, REF-MS-MOTW-OFFICE, and Helm's trusted-chrome lane idea.
- **Well-described / well-endorsed / admitted here / live now** as four visible product states instead of one badge.

## Added in Revision 070: request handles versus session handles versus live portal state

- REF-XDG-REQUEST, REF-XDG-SESSION, REF-XDG-INHIBIT, REF-XDG-GLOBALSHORTCUTS, REF-XDG-BACKGROUND, and REF-XDG-FILETRANSFER all point to the same lesson: one interaction request, one longer-lived session/transfer object, the portal's current live state for that object, one local adopted bind, and history receipts are different truths.
- SlopOS `background-request-state-posture-v0.md` got the same split exactly right: a requester-chosen request key should not masquerade as current grant truth.

Steal-worthy shell moves:
- **Request ledgers** that keep `pending`, `succeeded`, `cancelled`, `dismissed`, `timed out`, and `errored` distinct from any later session state.
- **Session cards** that can show `open`, `active`, `ending`, `closed`, or `closed by portal` without implying local possession.
- **Adoption shutters** that say whether the current pane merely observed a portal outcome or actually adopted the resulting bind/handle.
- **Repair ladders** that start from the right seam: `retry request`, `rejoin/open session`, `retrieve transfer`, or `adopt locally again`.

## Revision 071: Saved queries, live query feeds, and materialized collections are different classes

Apple Smart Folders are saved search criteria that show items matching those criteria, not durable local collection objects by themselves.[REF-APPLE-SMARTFOLDERS]

Apple's NSMetadataQuery / Spotlight query model also keeps an important split between an initial gathering phase and later live updates, which is a good reminder that a current live feed is not the same thing as a frozen result set.[REF-APPLE-NSMETADATAQUERY][REF-APPLE-SPOTLIGHT-QUERYGUIDE]

Haiku's file-system query modules go even further and treat the query itself as a fully virtual object that can be live and emit notifications when entries start or stop matching.[REF-HAIKU-FSMODULES]

Windows saved searches similarly store the query recipe as an XML search descriptor that is rerun when the Search Folder is opened, instead of silently becoming a materialized folder object.[REF-WIN-SEARCH-MS]

GNOME's LocalSearch service is also a useful reminder that indexed-query services may live behind distinct mediation and portal boundaries rather than being ambient filesystem truth for every sandboxed process.[REF-GNOME-SERVICES]

For ViewFS, the steal-worthy seam is therefore: query manifest / current hit snapshot / live query feed / materialized local collection / current bind / receipt. The shell payoff is excellent: "freeze to basket", drift views between the recipe and the locally frozen basket, portal-gated index-debt badges, and transcript-visible truth labels like `query_manifest`, `result_snapshot`, `live_query_feed`, `materialized_collection`, and `live_collection_bind`.

## Revision 072: completions, insertions, and compiled packets are different classes

- REF-MCP-COMPLETION-20250618, REF-LSP-COMPLETION-317, REF-FISH-COMPLETIONS, REF-FISH-INTERACTIVE, REF-VSCODE-SHELLINT, and REF-VSCODE-TERMINAL-API-TRUST all point to the same lesson: completion rows, focus-triggered detail, accepted insertions, compiled/bound command packets, and trusted rerun affordances should stay on different seams.
- SlopOS `mcp-completion-import-boundary-v0.md` gets the most important half exactly right already: provider-local suggestion mechanics are not selector/default/workflow truth.

Steal-worthy shell moves:
- **Ghost rows** that stay advisory until accepted.
- **Detail drawers** that load docs/provenance/rights hints on focus without changing insertion semantics.
- **Accept-word / accept-fragment** ladders so speed does not imply execution.
- **Packet gutters** that say `heuristic`, `shell reported`, `trusted`, `portal needed`, `rebind needed`, or `ready`.
- **Rerun safety badges** so only trusted/object-composed packets qualify for the strongest replay affordances.

## Revision 073: selected regions, typed entities, and routed actions are different classes

- REF-PLAN9-PLUMBER4, REF-OSC8-HYPERLINKS, REF-LSP-DOCLINK-317, REF-KITTY-HINTS, REF-ITERM-OSC8, and REF-WEZTERM-HYPERLINKS all point to the same lesson: one visible range of text/cells, one extracted or explicit typed entity, one lazily resolved target, one typed route envelope, and one prepared action are different truths.
- SlopOS `rfcs/0117-plumb-messages-and-cli-intents.md` gets the routing half right already: typed message envelopes are real objects, and they must not become a covert capability lane.

Steal-worthy shell moves:
- **Entity peels** that reveal what a current selection might mean before routing anything.
- **Lazy resolve drawers** inspired by REF-LSP-DOCLINK-317 so missing targets, host mismatch, or `receipt only` truth can surface before action prep.
- **Route slips** inspired by REF-PLAN9-PLUMBER4 so typed clicks produce inspectable route envelopes rather than blind `open`.
- **Hypertruth badges** from REF-OSC8-HYPERLINKS so the shell can distinguish `heuristic text`, `explicit link`, `resolved target`, `prepared route`, and `receipt only`.

## Revision 074: gesture evidence, activation batons, armed state, and active control are different classes

- REF-HTML-USER-ACTIVATION, REF-XDG-ACTIVATION-V1, REF-XDG-INPUTCAPTURE, REF-XDG-OPENURI, REF-XDG-GLOBALSHORTCUTS, REF-MS-ALLOWSETFOREGROUND, REF-MS-COALLOWSETFOREGROUND, and REF-WAYLAND-XDGSHELL-USERACTION all point to the same lesson: fresh user-action proof, transferred activation/focus batons, enabled-or-armed session state, active foreground/control state, and durable receipts/history should stay on different seams.
- SlopOS attention/request/capture posture already points the same way: transient interaction and durable truth should not collapse.

Steal-worthy shell moves:
- **activation baton chips** that visibly expire or get consumed.
- **arming rails** that separate `prepared` / `enabled` from `active now`.
- **foreground-transfer cards** that say `may ask to activate` instead of pretending activation already happened.
- **consume-once guards** so one click or shortcut cannot silently power several stronger effects.


## Revision 075: identity, placement, rights, and advertised affordances are different classes

- REF-ANDROID-DOCPROVIDER, REF-LINUX-OPATH, REF-CAPSICUM-RIGHTS, REF-FUCHSIA-CAPS, REF-FUCHSIA-IO-RIGHTS, and REF-RFC9110-ALLOW all point to the same lesson: a stable object/document identity, one current placement in one view, one current handle-rights posture, and one currently advertised verb set are different truths.
- Android sharpens the identity/placement split because one opaque document ID may be included as a child of multiple directories, while `COLUMN_FLAGS` separately advertises rename/copy/move/delete/settings/web-link affordances.
- Linux `O_PATH` and Capsicum sharpen the rights split because one handle can designate or be explicitly narrowed without carrying the full ordinary operation set.
- Fuchsia sharpens the namespace/rights split because capabilities are handles in a component namespace with explicit rights, and concrete operations require specific rights sets.
- HTTP `Allow` sharpens the affordance split because a target resource can advertise which methods it currently supports, and that set can change dynamically.

Steal-worthy shell moves:
- **Place cards** that render `same object, different placement` truth instead of duplicating identity.
- **Verb ledgers** that explain `provider says yes` versus `current handle says no`.
- **Affordance lenses** that keep identity, placement, held rights, advertised verbs, and receipts in one honest drawer.
- **Why-not drawers** so unsupported or blocked actions explain themselves before the user commits.


## Revision 076: declared types, derived classifications, and chosen openers are different classes

- REF-MIMESNIFF, REF-SHARED-MIME-INFO, REF-APPLE-UTTYPE, REF-FDO-MIMEAPPS, REF-ANDROID-DOCPROVIDER, and REF-WIN-PREVIEW-HANDLERS all point to the same lesson: supplied/declared type, derived/computed type, handler association sets, chosen opener, live preview/editor state, and durable receipts are different truths.
- SlopOS already leans the right way in its OpenURI/content-type/handler-selection boundaries: generic launch should not become a portable content-classification oracle, and concrete opener choice should stay shell-owned rather than requester-visible truth.

Steal-worthy shell moves:
- **Type lenses** that show `declared`, `derived`, `virtual representation`, and `disagrees`.
- **Handler racks** that show `associated`, `default`, `chosen now`, `safe preview`, or `unavailable here`.
- **Why-this-opener drawers** so one open act can explain its route basis.
- **Open-state badges** that keep `previewing`, `editing`, `external`, and `history only` visibly separate.


## Revision 077: annotations, selector labels, policy labels, and trusted badges are different classes

- REF-K8S-LABELS, REF-K8S-ANNOTATIONS, REF-OCI-ANNOTATIONS, REF-SELINUX-CONTEXTS, REF-FIRST-TLP20, REF-ITERM2-BADGES, REF-ITERM2-STATUSBAR, and REF-WEZTERM-RIGHT-STATUS all point to the same lesson: arbitrary metadata, selector-safe grouping keys, policy-bearing labels, shell-owned badge chrome, and durable receipts/history should stay on different seams.
- Kubernetes sharpens the note-versus-selector split because labels are for selection and grouping while annotations are arbitrary non-identifying metadata.
- OCI sharpens the arbitrary-metadata lesson because annotations are intentionally arbitrary key/value metadata and unknown keys must not explode consumers.
- SELinux sharpens the policy lesson because some labels really do live in a stronger policy lane.
- TLP sharpens the modesty lesson because a handling label is still not a whole control/classification system.
- iTerm2 and WezTerm sharpen the chrome lesson because terminals can project rich dynamic badge/status surfaces that are clearly presentation lanes.

Steal-worthy shell moves:
- **Label ledgers** that separate `annotation`, `selector`, `policy`, `badge`, and `history only` rows.
- **Selector rails** so only query-safe labels feed smart baskets and saved filters.
- **Trusted badge shutters** so quarantine/review/handling labels live in shell-owned chrome rather than decorative chip clouds.
- **Why-this-badge drawers** so current chrome can explain whether it came from metadata, policy, provider state, or shell synthesis.



## Continuation cursors, sync watermarks, and rebuilt state
- **REF-K8S-API-CONCEPTS-WATCH** says a `BOOKMARK` event marks that all changes up to a `resourceVersion` have been sent, `sendInitialEvents=true` can pair synthetic initial state with a later bookmark, and `410 Gone` means the server no longer retains the requested version.
- **REF-DROPBOX-DETECT-CHANGES** says folder cursors point to a folder at a point in time, can later fetch changes, may expire and force a fresh list, and longpoll is a separate wait primitive that still hands control back to `/continue`.
- **REF-WATCHMAN-CLOCKSPEC** says wall-clock timestamps are race-prone, clock ids are safer for incremental change tracking, and named cursors are still query state with performance/tradeoff implications.
- **REF-APPLE-FSEVENTS-GUIDE** says dropped or coalesced events and root changes require rescan/rebuild and exposes event ids so clients can reason about progress through a stream.
- Therefore: ViewFS should keep continuation cursors, sync watermarks, live follow state, rebuilt snapshots, gap/reset verdicts, and durable history visibly distinct instead of collapsing them into one magical `live query` token.
- Nice shell thefts: **waterline cards**, **gap-badge stacks**, **resync ladders**, and **snapshot-versus-follow split views**.

## Revision 079: observed validators, private writable sessions, and durable winners are different classes

- REF-RFC7232-CONDITIONAL, REF-GCS-PRECONDITIONS, REF-ETCD-TXN, REF-WEBDAV-LOCKING, REF-MDN-CREATEWRITABLE, and REF-K8S-API-CONCEPTS-WATCH all point to the same lesson: the exact version you observed, the private writable session you are editing in, any live coordination hold, the exact commit precondition, the committed durable version that actually won, and durable receipts/history should stay on different seams.
- SlopOS `acp-precondition-witness-posture-v0.md` gets the basis half right already: reviewed/observed state must be expressed against exact local witness material rather than ambient `latest` folklore.
- SlopOS `capstore-commit-schema-v0.md` gets the durable side right already: commit/update meaning stays explicit instead of dissolving into mutable-session stories.

Steal-worthy shell moves:
- **Stale-base lamps** so one pane can show `based on X`, `target now Y`, or `history only`.
- **Draft gutters** so local/private staging state stays visible without pretending it is a shared hold.
- **Commit shutters** so `if-match`, `if-absent`, `under hold`, and `fork instead` are different acts.
- **Winner receipts** so a successful or failed mutation can say what durable version actually won.

## Revision 080: sparse coverage, chunk layouts, and whole-object proofs are different classes

- REF-RFC9110-RANGE, REF-RFC9111-INCOMPLETE, REF-STARGZ-OVERVIEW, REF-STARGZ-ESTARGZ, REF-AWS-S3-OBJECT-ETAG, REF-AWS-S3-MPU-OVERVIEW, REF-AWS-S3-INTEGRITY, and REF-ZARR-V3-CORE all point to the same lesson: partial local bytes, partition/layout metadata, whole-object completeness, exact whole-object proofs, live lazy/range-fill reachability, and durable receipts/history should stay on different seams.
- HTTP sharpens the transfer and recombination side because 206 responses are partial representations and combining them safely depends on strong validator discipline.
- HTTP caching sharpens the honesty side because incomplete responses may be stored but must not answer a complete request as if partial bytes were whole truth.
- eStargz sharpens the lazy-materialization side because OCI-compatible images can run before full local layer availability, fetching files or chunks on demand.
- Amazon S3 sharpens the proof side because multipart ETags are not necessarily whole-object MD5, while explicit full-object checksum validation is a stronger separate lane.
- Zarr sharpens the layout side because chunk grids/codecs are essential partition metadata without being the same thing as current local coverage or whole-array proof.
- Therefore: ViewFS should keep current sparse coverage, layout metadata, completeness verdicts, whole-object proofs, live range-fill sessions, and receipts visibly distinct instead of collapsing them into one vague hydration/download state.
- Nice shell thefts: **hole maps**, **range panels**, **whole-proof ladders**, **offline honesty lamps**, and **composite-checksum warnings**.


## Revision 081: delta recipes, exact bases, and reconstructed targets are different classes

- REF-RFC9110-IFRANGE, REF-RFC3229-DELTAHTTP, REF-RFC3284-VCDIFF, REF-OSTREE-STATIC-DELTAS, and REF-ZSYNC-THEORY all point to the same lesson: delta recipes, exact basis requirements, current apply sessions, reconstructed target objects, fallback whole-fetch lanes, and durable receipts/history should stay on different seams.
- HTTP sharpens the fallback honesty because `If-Range` says, effectively, `if basis still matches, send the requested part; otherwise send the whole representation`.
- Delta encoding in HTTP sharpens the base/result split because a delta response identifies the base instance separately from the current instance and treats the delta as an instance manipulation rather than a new identity.
- VCDIFF sharpens the reconstruction story because each target window is encoded against an explicit source segment or earlier target data.
- OSTree sharpens the object-store story because static deltas target exact commit pairs and `from NULL` is a distinct lane.
- zsync sharpens the local-reuse story because the client reuses current local bytes using checksum/control-file knowledge, but that is still a reconstruction act rather than magical continuity.
- Therefore: ViewFS should keep delta artifacts, basis truth, apply sessions, reconstructed targets, fallback full-fetch decisions, and receipts visibly distinct instead of collapsing them into one vague `updated object` story.
- Nice shell thefts: **basis cards**, **delta peels**, **apply ladders**, **fallback honesty lamps**, and **rebuilt-from lineage badges**.

## Revision 082: activation carriers, live copies, and object identity are different classes

- REF-PLAN9, REF-FUCHSIA-NAMESPACE, REF-SYSTEMD-SOCKETACT, REF-SYSTEMD-FDSTORE, REF-UNIX-SCMRIGHTS, and REF-SEL4-BADGES all point to the same lesson: a personal namespace, startup-delivered handle, narrow restart locker, local courier lane, issuer-visible badge, immutable object ref, and durable receipt are useful precisely because they are **not the same class**.
- Plan 9 sharpens the per-process namespace lesson: personal namespace assembly is powerful, but that does not mean every truth should collapse back into ambient path lookup.
- Fuchsia sharpens the launch-assembly lesson: a process can receive an explicit capability-routed namespace whose layout varies by role and rights, which is exactly the kind of creator-populated view ViewFS should steal.
- systemd sharpens the startup/continuity lesson: already-open descriptors at activation time and a narrow fd store for restart continuity are useful, but they do not magically settle durable identity or general persistence.
- UNIX descriptor passing sharpens the courier lesson: local send/receive of a current open resource is a first-class act and should stay separate from durable reopen folklore.
- seL4 sharpens the badge lesson: badge values belong to capability copies/senders, not to immutable object identity.
- Therefore: ViewFS should keep activation slots, live copies, issuer/courier witness, object refs, local binds, later revival lanes, and durable receipts visibly distinct.
- Nice shell thefts: **activation sheets**, **handoff sheets**, **copy-lineage drawers**, **issuer chips**, and **child-slot maps**.



## Store membership, synthetic views, live handles, and published names
- REF-PLAN9, REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-DICTCAP, REF-XDG-REQUEST, REF-XDG-FILECHOOSER, and REF-XDG-DOCUMENTS all point to the same lesson: one object may exist locally, be reachable through a restricted synthetic/mediated view, be held through a current live handle, and be published under one current name in one concrete process namespace — and those are different truths.
- Fuchsia sharpens the publication lesson: components consume a namespace and may separately publish objects through an outgoing directory.
- XDG sharpens the restricted-view lesson: selected files may be surfaced through a synthetic document view and stay accessible across sessions, but that still is not the same thing as native publication in every current application view.
- Therefore: ViewFS should keep object-store membership, synthetic view projection, live-handle possession, current published names, and durable receipts visibly distinct instead of calling all of them “the file.”

What to steal:
- **Published-name ledgers** that show every current publication site for one object separately.
- **Synthetic-view badges** that say `portal view`, `provider projection`, `published here`, `stored only`, or `history only`.
- **Publish-here ladders** so mediated selections land in staging before they become current local binds.
- **Same-object multi-view diffs** so shells can compare object ref, projection site, current publication, and current handle truth.

## Explicit-handle opens, rooted compat walkers, and ambient escapes

### L48. A rooted compat walk is not the same as direct current authority
- REF-CAPSICUM-SEC10 and REF-CAPSICUM-RIGHTS say current possession of capability-bearing handles matters more than ambient namespace folklore.
- REF-CAPSTD and REF-OPENAT2 say rooted helpers and explicit ambient markers are useful specifically because they distinguish narrow rooted resolution from ambient/global lookup.
- Therefore: ViewFS should allow rooted compat help during bring-up, but keep it visibly distinct from direct-handle opens and from truly ambient host escape hatches.

### L49. Mediation should explain fit and locality, not only permission
- REF-SANDSTORM-POWERBOX says isolated components can still exchange power through explicit user-mediated connection flows.
- REF-XDG-REQUEST and REF-XDG-DOCUMENTS say mediation can leave behind request objects and restricted synthetic views rather than one fake synchronous native open.
- Therefore: chooser/import UX should explain why a candidate is in scope, what becomes local, what stays mediated, and what receipt/history remains.

### L50. Content-addressed storage is storage truth, not current-authority truth
- REF-FOUNDATION-CAS and REF-VENTI are great reminders that content-addressed archival storage can preserve and deduplicate bytes very well.
- Therefore: use content addressing for object-store identity and verification, but do not let it silently answer publication, reopen, or current-live-authority questions.

## More nifty ideas worth stealing
- **Safe-open ladders** from REF-CAPSTD, REF-OPENAT2, REF-XDG-REQUEST, and REF-SANDSTORM-POWERBOX.
- **Ambient-debt sirens** from REF-CAPSTD plus rooted-helper posture from REF-OPENAT2.
- **Powerbox fit notes** from REF-SANDSTORM-POWERBOX so imports explain why an option is in scope.
- **Imported-fragment badges** from REF-PLAN9-IMPORT so imported namespace pieces do not masquerade as universal local path truth.
- **Route provenance drawers** from the combination of REF-PLAN9-PLUMB, REF-XDG-REQUEST, and REF-WEZTERM-SHELL-INT.


## Discoverability, enumeration, exact-name reachability, and fit notes
- REF-LINUX-ACCESS, REF-WASI-P1-RIGHTS, REF-FUCHSIA-CAPS, REF-FUCHSIA-DIR-CAPS, and REF-SANDSTORM-POWERBOX all point to the same lesson: discoverability, enumeration, exact-name reachability, advisory match quality, and direct live authority are different classes.
- Linux sharpens the directory-search lesson because path accessibility depends on search permission on each prefix directory, which is already a narrower truth than free browsing.
- WASI sharpens the rights lesson because `RIGHTS_FD_READDIR` and `RIGHTS_PATH_OPEN` are separate rights.
- Fuchsia sharpens the namespace lesson because capabilities combine resource plus rights and are surfaced explicitly through the component namespace.
- Sandstorm sharpens the fit lesson because powerbox descriptors can be preferred/acceptable/unacceptable without turning candidate ranking into authority.
- Therefore: ViewFS should keep browse/list truth, exact-name-open truth, suggestion/fit truth, and direct-handle truth visibly distinct instead of calling all of them `the file is there`.

What to steal:
- **dark directories** that keep exact-name reachability smaller than list disclosure;
- **known-name chips** that tell the transcript when success came from exact-name access under a held root;
- **fit sheets** that keep candidate quality visible and advisory;
- **search-result dimmers** so history/helper/index hits stay weaker than current authority.

## Presence adverts, readiness, grant-needed posture, and current authority
- REF-FUCHSIA-CAPS, REF-FUCHSIA-NAMESPACE, and REF-FUCHSIA-CONNECT all point to the same lesson: a component can consume a namespace while separately publishing outgoing/exposed capabilities, so discoverable publication is not identical to a client already holding authority.
- REF-MCP-ROOTS, REF-MCP-RESOURCES, REF-MCP-PROMPTS, and REF-MCP-TOOLS all point to the same lesson: helper catalogs and `listChanged` notifications are useful discoverability surfaces, but they do not become filesystem grants, current-state oracles, or completed invocations by themselves.
- REF-XDG-REQUEST, REF-XDG-FILECHOOSER, and REF-XDG-DOCUMENTS sharpen the mediation lesson because request handles, chooser rows, and restricted document views remain explicit instead of dissolving into native ambient path truth.
- REF-DNSSD sharpens the discovery lesson because browsing service instances is not the same thing as already holding a usable connection path.
- REF-K8S-ENDPOINTSLICE sharpens the freshness lesson because discoverable endpoints can still differ in `ready`, `serving`, and `terminating` state.
- Therefore: ViewFS should keep advert/catalog presence, freshness-scoped readiness, grant-needed posture, direct current authority, and durable receipts visibly distinct instead of calling all of them `available`.

What to steal:
- **presence halos** that say `advertised`, `ready`, `grant needed`, `withheld`, `withdrawn`, or `history only`;
- **readiness lamps** that decay honestly to `last known` and then `history only`;
- **withdrawn ghosts** so vanished provider/helper rows leave an explainable trace;
- **advert ledgers** that name who advertised something, when, and with what freshness caveat;
- **grant-needed ladders** that keep `ask portal`, `rebind here`, `reacquire`, and `receipt only` as visibly different next steps.


### L30. Provider-ready is not local-realized
- REF-GIT-PARTIAL-CLONE, REF-NIX-REALISE, REF-NIX-SSH-SUBSTITUTER, and REF-FUCHSIA-AVAILABILITY all show that `a provider can supply this` is a different class from `this exists locally here now`.
- Therefore: ViewFS should keep provider-ready, reacquire-needed, local-realized, and live-handle truths visibly separate.

## More ideas worth stealing
- **Promisor shading and offline fog** from REF-GIT-PARTIAL-CLONE.
- **Explicit make-local / realise verbs** from REF-NIX-REALISE.
- **Substituter/source ladders** from REF-NIX-SSH-SUBSTITUTER.
- **Route-availability expectations** from REF-FUCHSIA-AVAILABILITY.
- **Repair-duty ledgers and borrowed-handle cards** inspired by the Foundry companion cube.

## OAuth codes, DPoP, one-shot intents, and portal request/session handles

A very good family of ideas to steal is **authority artifact taxonomy** rather than one universal token story.

- OAuth authorization codes show a useful **redeemable claim** posture: short-lived, single-use, bound to a particular client/redirect context.
- DPoP shows a useful **holder-bound grant** posture: issued tokens can stay tied to possession of a key pair instead of drifting into replayable bearer material.
- Android PendingIntent guidance shows why a **one-shot / consumable** posture matters when a compact authority artifact could otherwise be replayed.
- XDG Request and Session objects show a useful **mediator-owned live object** posture: some handles live only for a user interaction or session and should not be mistaken for generic durable capability blobs.

For ViewFS, the shell steals are obvious:
- redemption ladders,
- burn-after-use chips,
- holder-proof badges,
- passability badges,
- spent ghosts,
- and transcript drawers that show whether a row is claim-only, holder-bound, passable, or historical.


### L31. Current possession is not current invocability
- REF-RFC9470-STEPUP, REF-OIDC-CORE-MAXAGE, REF-WEBAUTHN-3, and REF-ANDROID-KEYSTORE-AUTH all point to the same lesson: one local credential, handle, or token can exist now while the current action still needs fresher proof, stronger authentication, or immediate user presence/verification.
- Therefore: ViewFS should keep possession/local-realization, recency posture, step-up posture, local presence posture, current invocability, and receipts visibly separate.

## More ideas worth stealing
- **Why-not-now drawers** from REF-RFC9470-STEPUP and REF-ANDROID-KEYSTORE-AUTH.
- **Recency shutters** from REF-OIDC-CORE-MAXAGE.
- **Presence pins and satisfaction ghosts** from REF-WEBAUTHN-3.
- **Risk/context ladders** inspired by Harbor's proximity/timebound companion work.


### L38. Current good standing is not a property of possession alone
- REF-RFC7662-INTROSPECT, REF-RFC6960-OCSP, REF-RFC5280-CRL, REF-VC-BITSTRING-STATUS, REF-TUF-METADATA, and REF-TUF-SPEC all show that later status/freshness/successor truth is smaller than base object truth and often arrives on different clocks.
- Therefore: keep held/local truth separate from watch/status truth, local holds, and successor refresh.

## Another round of nifty ideas worth stealing
- **current-state queries smaller than base tokens** from REF-RFC7662-INTROSPECT.
- **reversible hold semantics** from REF-RFC5280-CRL and REF-RFC6960-OCSP.
- **typed compact status carriers** from REF-VC-BITSTRING-STATUS.
- **freeze detection and successor-root recovery** from REF-TUF-METADATA and REF-TUF-SPEC.
- **watch braids and attenuation rails** from Ward’s status-carrier and attenuation-event posture.


### L39. Held handles, live lends, and representation exports are different classes
- REF-MACH-PORT-RIGHTS, REF-SEL4-GRANT, REF-UNIX-SCMRIGHTS, REF-WAYLAND-DATADEVICES, REF-XDG-FILETRANSFER, and REF-KITTY-FILETRANSFER all point to the same lesson: current possession, local duplication, live authority lend, negotiated representation export, and historical receipt are different classes.
- Mach sharpens the right-class lesson because send, receive, and send-once are distinct rights rather than one generic `can share` bit.
- seL4 sharpens the courier lesson because Grant/GrantReply are explicit transfer postures and capability transfer does not ride on every ordinary message send.
- UNIX `SCM_RIGHTS` sharpens the local-lend lesson because the receiver gets another reference to the same open file description, not a magical path reopen.
- Wayland and XDG sharpen the representation lesson because a transfer can start as an offer of representations and complete as a selected exported payload without the receiver ever getting the original live authority.
- kitty sharpens the terminal lesson because even a TTY-native transfer lane is still just one explicit lane among others.
- Therefore: ViewFS should keep held-here truth, duplicate-local truth, live-lend truth, weaker representation export truth, and durable receipts/history visibly separate instead of flattening them into one `share` verb.

### L40. Foreign-backed borrow, projected locality, and true local realization are different classes
- REF-ANDROID-SAF, REF-ANDROID-DOCPROVIDER, REF-APPLE-DOCPICKER-ACCESS, REF-APPLE-FILEPROVIDER-SYNC, REF-XDG-DOCUMENTS, REF-XDG-DOCS-FUSE, REF-FUCHSIA-COMPONENT-NSENTRY, and REF-FUCHSIA-FSARCH all point to the same lesson: borrowed provider-backed usability, wrapper/relay attach posture, projected local views, explicit local realization, and durable receipts/history are different classes.
- Android sharpens the copy-versus-provider-backed split because `ACTION_GET_CONTENT` is copy-import while `ACTION_OPEN_DOCUMENT` is long-term access to provider-owned documents with stable document IDs and provider-declared capabilities.
- Apple sharpens the locality split because open-in-place uses security-scoped URLs while File Provider also distinguishes dataless and materialized local copies.
- XDG sharpens the projection split because document IDs and permissions back a restricted projected FUSE view instead of ambient local ownership.
- Fuchsia sharpens the attach/wrapper split because the receiver namespace is an explicit set of path→directory attachments and the standard library can wrap handles into fd-like UX without changing underlying authority truth.
- Therefore: ViewFS should keep foreign-backed borrow, compat attach, projected import, local realization, and durable history visibly separate instead of flattening them into one `opened here` story.

What to steal:
- **borrow rails** from REF-ANDROID-SAF plus SlopOS document-portal posture.
- **provider-owned halos** and **dataless/materialized lamps** from REF-APPLE-FILEPROVIDER-SYNC.
- **projection badges** from REF-XDG-DOCUMENTS and REF-XDG-DOCS-FUSE.
- **attach-versus-localize truth** from REF-FUCHSIA-COMPONENT-NSENTRY and REF-FUCHSIA-FSARCH.
- **make-here ladders** inspired by the contrast among Android copy-import, Apple open-in-place, XDG projection, and Foundry's foreign-cell posture.



### L41. Route capsules, authority sidecars, sink acceptance, and receipts are different classes
- REF-PLAN9-PLUMB, REF-PLAN9-PLUMBER4, REF-ANDROID-SHARE-FILE, REF-ANDROID-URIPERMISSION, REF-ANDROID-GRANTURIPERMISSION, REF-XDG-REQUEST, and REF-WAYLAND-DATADEVICES all point to the same lesson: one typed route/message envelope, one adjunct sidecar that narrows or explains it, one sink’s accepted representation or bind, and one durable receipt are different truths.
- Therefore: ViewFS should keep route slips, sidecar chips, sink trays, and receipts visibly separate instead of flattening them into one generic `open/share/import` verb.

### L32. Bounded caller context is useful only when it does not turn back into ambient authority
- REF-CONFUSED-DEPUTY-HARDY shows the classic failure mode: a tool carrying authority from two masters cannot keep them apart.
- REF-JEP506-SCOPEDVALUES, REF-PY-CONTEXTVARS, and REF-NODE-ASYNCLOCALSTORAGE show healthier modern patterns: bounded dynamic scope, automatic unwind, and context that is present only within explicit execution regions.
- REF-ASPNET-HTTPCONTEXTACCESSOR is a good warning that ambient async-local context is still dangerous enough that Microsoft tells developers to use it with caution.
- Therefore: ViewFS should treat caller context as explanation, borrowed handles as authority, brackets as bounded posture, and provenance-driven vetoes as deny-only.

## More ideas worth stealing
- **Bracket rails** from the combination of Scoped Values, `contextvars`, and AsyncLocalStorage `run()`/`exit()`.
- **Who-asked drawers** that show caller frames without turning them into grants.
- **Deputy-fog warnings** whenever one helper falls back from explicit borrowed handles to ambient helper state.
- **Deny-only provenance shutters** so plugin/helper context can veto routes without becoming a widening lane.

### L42. Native attach, adapted attach, coerced representation, and local realization are different classes
- REF-ANDROID-VIRTUALFILES, REF-ANDROID-SAF, REF-WIT-RESOURCE-HANDLES, REF-XDG-DOCUMENTS, REF-XDG-DOCS-FUSE, REF-FUCHSIA-NAMESPACE, and REF-FUCHSIA-COMPONENT-NSENTRY all point to the same lesson: a receiver can have direct native fit, adapter/relay-backed usability, an alternate representation, a stronger explicit local realization, or only durable history — and those are different truths.
- Android sharpens the representation lesson because virtual files may require alternate MIME coercion and are not directly openable as ordinary streams.
- WIT sharpens the handle lesson because resources are handles to external entities and owned/borrowed handles are different from copied plain data.
- XDG sharpens the projection lesson because a restricted FUSE view can make something reachable/useful without claiming ambient native ownership.
- Fuchsia sharpens the receiver-fit lesson because every component gets its own explicit namespace and object paths are not automatically meaningful across namespace boundaries.
- Therefore: ViewFS should keep native attaches, adapted attaches, coerced representations, local realizations, and durable history visibly separate instead of flattening them into one `opened natively` story.

What to steal:
- **attach-mode badges** from the contrast between Android virtual-file coercion and WIT resource handles.
- **adapter veils** from Fuchsia namespace assembly plus the existing ViewFS host-bridge posture.
- **virtuality lamps** from Android virtual files.
- **same-object versus translated drawers** from the contrast between WIT resource handles and alternate MIME/output representations.
- **make-local-for-native ladders** from the contrast among XDG projection, Android virtual/coerced lanes, and the current SlopOS import/docref posture.



## Added in Revision 096

### Shell startup honesty and explicit customization
- **SlopOS capshell startup-profile posture** keeps the reviewed baseline free of implicit rc/profile files and per-directory hooks.
  - ViewFS lesson: custom-shell delight can ship as built-in product behavior instead of ambient startup code.
- **direnv allow / require_allowed** keeps project-local activation behind explicit allow and re-allow-on-change.
  - ViewFS lesson: repo-local activation hooks should be their own trust/review seam, not a side effect of browsing.
- **VS Code Workspace Trust / Restricted Mode** keeps tasks, debugging, workspace settings, and agents withheld while browsing stays useful.
  - ViewFS lesson: shell/project browsing and project activation should remain different truths.
- **Ghostty shell integration** stays inspectable and manually sourceable, especially when users switch shells.
  - ViewFS lesson: terminal integration should stay explicit and debuggable instead of becoming blanket startup permission.
- **PowerShell profiles** are just startup scripts and can run arbitrary commands.
  - ViewFS lesson: host/user startup files should be treated as executable startup surfaces, not harmless personalization mist.


## Built-in verbs, lexical expansions, command layers, key actions, and external launches are different classes

- REF-FISH-ABBR is a strong reminder that typed abbreviation is still lexical expansion: fish explicitly says abbreviations only affect typed-in commands and are not expanded in scripts.
- REF-NU-OVERLAYS shows a healthier model for command layering: overlays are explicit layers of definitions that can be activated and deactivated on demand.
- REF-NU-CUSTOMCOMMANDS and REF-NU-WHICH show that custom commands can be first-class and the shell can honestly say whether a name resolves to a program file, alias, or custom command.
- REF-ZSH-ZLE shows that keybound widgets are a real editor/action plane, not the same thing as typed command namespace.
- REF-GHOSTTY-KEYTABLES and REF-GHOSTTY-CMDPALETTE show that modal key tables and command-palette actions become more useful when they stay explicit.
- REF-VSCODE-PROFILES shows that settings, keyboard shortcuts, snippets, tasks, extensions, and MCP servers can be sliced independently inside one profile rather than flattened into one blob.
- Therefore: ViewFS should keep built-in verbs, typed lexical expansions, semantic command layers, key actions/widgets, exact external launches, and durable receipts/history visibly separate instead of letting shell delight regress into alias/widget folklore.

## More ideas worth stealing
- **Verb provenance cards** from Nushell-style `which` honesty plus capability-native transcript cards.
- **Overlay racks** from Nushell overlays and Foundry's config-layer pressure.
- **Key-table lamps** from Ghostty's explicit modal key tables.
- **Abbr gutters** from fish's typed-only abbreviation model.
- **Profile-sliced command surfaces** inspired by VS Code profiles.


### L43. Editable buffer truth, parser truth, diagnostic truth, and packet truth should stay separate
- REF-TREESITTER shows that incremental parsing can stay useful on every keystroke and under syntax error without becoming final command meaning.
- REF-LSP-DIAGNOSTICS-317 shows that diagnostics are their own channel and need not collapse into the text buffer or execution path.
- REF-SHELLCHECK shows how shell-specific diagnostics can stay explanatory and advisory.
- REF-FISH-SYNTAX shows that immediate syntax color can improve speed and confidence without implying execution.
- Therefore: ViewFS should keep editable buffers, parsed structures, advisory diagnostics, compiled packets, prepared actions, and receipts/history visibly separate.

What to steal:
- parse lenses
- recovery veils
- diagnostic rails
- packet gutters
- compile diff cards


### L34. Room identity, current namespace, and child inheritance are different truths
- REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-DICTCAP, REF-XDG-REQUEST, REF-XDG-DOCUMENTS, REF-XDG-FILETRANSFER, and REF-WEZTERM-SHELL-INT together point to the same lesson: a human-visible room, an explicit current namespace, a prepared child context, and the imports a child actually receives are different classes even when the UI wants them to feel adjacent.
- Therefore: ViewFS should keep room identity, current room-local view, inheritance posture, prepared spawn/import recipes, child-received bindings, and receipts visibly distinct.

## More ideas worth stealing
- **Room badges** driven by explicit room/view metadata rather than cwd folklore.
- **Context diff drawers** before split/spawn/rerun so users can compare parent-room truth and candidate child-room truth.
- **Child import trays** that report `requested`, `granted`, `bound`, or `receipt only` instead of one vague split/open story.
- **Receipt-first room restore** so layout and explanation return before fresh authority does.

### L35. Great capability UX needs great diagnostics or it will lose to folklore
- REF-CAPSICUM-ADOPTION and REF-MAN7-OPEN point to a practical lesson from the past: capability discipline dies when inheritance mistakes are invisible and debugging requires kernel archaeology.
- Therefore: ViewFS should make launch/import/child-context failures first-class explainable shell states, not low-level trivia.

## More ideas worth stealing
- **Why-not-in-child drawers** that explain which import was dropped, blocked, stale, or intentionally inherit-shuttered.
- **Authority leak sirens** whenever a child recipe would inherit more than expected.
- **Launch/child diff receipts** that explain what changed between parent room, prepared recipe, and actual child state.

### L36. Delight should default to explicit layers, not hidden soup
- REF-FISH, REF-NU-OVERLAYS, REF-GHOSTTY-SHELLINT, and REF-GHOSTTY-CMDPALETTE point to the same lesson: users love shells and terminals that feel powerful immediately, but those products work best when layers, modes, and command blocks stay explicit.
- Therefore: ViewFS should make clean-room spawning, explicit overlays, room-aware palette actions, and semantic command blocks feel normal rather than niche.

## More ideas worth stealing
- **Clean-room split first-class verbs** (`split clean`, `rerun clean`, `clone layout only`).
- **Room-aware command palette** that can act on rooms, recipes, receipts, and current imports as separate classes.
- **Terminal inspector overlay** for debugging room metadata, semantic zones, and child-context diffs.

### L44. Namespace switchboards, local overlays, and anchor-death honesty
- REF-PLAN9 and REF-FUCHSIA-DICTCAP reinforce the lesson that explicit namespace assembly and grouped authority should stay inspectable rather than ambient.
- REF-XDG-REQUEST and REF-XDG-DOCUMENTS reinforce the lesson that request/session lifetime and resulting live accessibility are different classes.
- REF-WICG-FSACCESS, REF-MS-FUTUREACCESSLIST, and REF-APPLE-SECBOOKMARK-ENABLE reinforce the lesson that durable access UX only stays safe when repair and opt-in remain explicit.
- Helm's local-overlay contract reinforces the lesson that local convenience state should be derivative, scoped, cheap to discard, and should not travel by accident.
- Schell's anchor-death cards reinforce the lesson that restore/review comfort must still admit when an old exact anchor died.
- Therefore: ViewFS should make namespace switchboards, overlay racks, import-session strips, and anchor-death cards first-class shell ideas while refusing to flatten those classes into one room blob.

### L45. Activation kits, restart lockers, namespace pins, and live room binds are different seams
- REF-SYSTEMD-SOCKETACT, REF-SYSTEMD-FDSTORE, REF-LINUX-SETNS, REF-LINUX-NAMESPACES7, and REF-APPLE-LAUNCHD-SOCKETS point to the same lesson: startup-delivered resources, manager-held restart continuity, namespace-liveness pins, and current room occupancy are useful precisely because they are **not the same class**.
- systemd sharpens the middle seam: already-open descriptors at activation time and a narrow fd store for restart continuity are valuable, but they do not settle durable identity or general persistence.
- Linux sharpens the namespace seam: a namespace may be joined via a handle and may stay alive because of an open fd or bind mount even when no process currently inhabits it.
- Therefore: ViewFS should keep activation kits, restart lockers, namespace pins, live room binds, durable anchors, and receipts visibly distinct, and it should let the shell say `warm exact`, `warm partial`, `cold repair`, or `cold fresh` instead of one vague `restored` story.

## More ideas worth stealing
- **Restart shelves** that separate wake kit, locker, pin, live bind, anchor-only, and receipt-only rows.
- **Warm-start lamps** that tell the truth about exact warm restart versus colder fallbacks.
- **Pin badges** that explain liveness preservation without pretending to be current authority.
- **Cold-start honesty cards** that explain what exact fallback happened and what revalidation fence now applies.


### L46. Live binds, currentness witnesses, semantic epochs, and repair offers are different seams
- REF-FUCHSIA-SECURE and REF-FUCHSIA-ORIG-PRINCIPLES point to the same lesson: no-ambient-authority systems still need to be careful about what is current in a child/environment versus what is merely inherited or assumed.
- REF-XDG-REQUEST, REF-XDG-SESSION, and REF-XDG-DOCUMENTS point to the same lesson: request lifetime, session lifetime, and resulting accessibility are different classes.
- REF-WICG-FSACCESS, REF-W3C-PERMISSIONS, REF-ANDROID-SAF, and REF-MS-FUTUREACCESSLIST point to the same lesson: durable access and current permission/currentness should stay explicit, queryable, and repairable.
- REF-WEZTERM-SHELL-INT and REF-GHOSTTY-130 point to the same lesson: shell integration is strongest when prompt zones, cwd, command blocks, and finished-command chrome stay explicit.
- Steward sibling pressure sharpens the shell side: semantic epochs, hop lineage, target anchors, chrome lanes, and precision fences are the right language for stale-footing honesty.
- Therefore: ViewFS should keep live room binds, provider/issuer currentness witnesses, shell semantic epochs/hop scope, bounded repair offers, and receipts visibly separate instead of one vague `still valid` state.

## More ideas worth stealing
- **epoch lamps** that tell the truth about older semantic worlds instead of preserving stale exactness.
- **hop badges** that scope room and command-block affordances to the actual path.
- **currentness drawers** that show `current`, `revoked`, `expired`, `successor available`, or `unknown`.
- **repair-offer cards** that explain whether the next move is refresh, rebind, reconsent, make-local, or rerun-clean.
- **stale-anchor shutters** that degrade old affordances into `receipt only` instead of silently targeting latest.


### L31. Renewal timing, retry timing, and quieting state are different truths
- REF-SYSTEMD-FDSTORE, REF-SD-NOTIFY, REF-HTTP-RFC9110, REF-WICG-FSACCESS, REF-ANDROID-URIPERMISSION, and REF-XDG-REQUEST all point to the same lesson: live continuity, explicit renew-or-expire budgets, `not before` timing hints, and repeated-failure quieting solve different problems.
- Therefore: ViewFS should render `renewed through`, `retry after`, `cooling down`, and `repair required` as visibly different state classes instead of one vague `try again later` story.

## More ideas worth stealing
- **Renewal lamps** from REF-SD-NOTIFY and lease-shaped runtime posture.
- **Retry clocks** from REF-HTTP-RFC9110 rather than shell-local guessing.
- **Quality badges** from REF-VSCODE-SHELL-INTEGRATION so the terminal can confess how much it really knows.
- **Prompt-aware actions** from REF-GHOSTTY-130 and REF-WEZTERM-SHELL-INT.
- **Explicit layer toggles** from REF-NUSHELL-OVERLAYS.


## Warmth rails, login lanterns, and defer drawers
- REF-XDG-BACKGROUND, REF-ANDROID-BG-EXEC-LIMITS, REF-APPLE-BGTASKS, REF-K8S-LEASE, and REF-K8S-ENDPOINTSLICE all point to the same lesson: live presence, background presence, later restore, deferred repair work, and historical receipts should not collapse into one magical background-state blob.
- REF-VSCODE-SHELLINT, REF-VSCODE-199-SHELLINT, REF-WEZTERM-SHELL-INT, REF-GHOSTTY-130, and REF-NU-OVERLAYS all point to the same shell lesson: great chrome starts with explicit state classes and quality signals, not transcript guessing.
- Therefore: ViewFS should give the future shell **warmth rails**, **keep-warm badges**, **login lanterns**, **defer drawers**, and **quality chips** instead of one vague `restored/backgrounded` light.

### L47. Live presence, transient attention, interruption strength, quiet posture, and durable follow-up are different truths
- REF-XDG-NOTIFICATION points to the same lesson: an application can ask for attention and withdraw the request, but it should not infer that presentation definitely happened.
- REF-ANDROID-NOTIF-CHANNELS and REF-ANDROID-TIMESENSITIVE point to the same lesson: interruption strength is an explicit grade with strong system/user control rather than a payload-authored law.
- REF-APPLE-CRITICAL-ALERTS points to the same lesson: stronger interruption should be a separately governed class, not an ordinary `urgent` bit.
- REF-TMUX-ALERTS points to the same shell lesson: activity, bell, and silence are different attention states and deserve different chrome.
- SlopOS attention posture sharpens the durable-truth side: transient attention cues must not become the only durable carrier of consequential follow-up.
- Therefore: ViewFS should keep live room binds, attention pips, interrupt grades, quiet shutters, durable ack rows, and receipts/history visibly separate.

## More ideas worth stealing
- **Attention pips** with different glyphs for activity, bell, silence, and follow-up.
- **Interrupt ladders** that tell the truth about `badge only`, `banner`, `urgent but clamped`, and `requires separate grant`.
- **Quiet shutters** for focus/presentation/workspace hush posture.
- **Ack ledgers** that keep unresolved attention durable without pretending the original cue is still live.
- **Coalesced-event counters** so quiet mode can reduce noise without erasing history.

### L48. Summon cues, activation batons, foreground turns, and secure-entry truth are different classes
- REF-XDG-ACTIVATION-V1, REF-MS-ALLOWSETFOREGROUND, REF-MS-COALLOWSETFOREGROUND, REF-XTERM-FOCUS, REF-WEZTERM-SHELL-INT, REF-GHOSTTY-130, and SlopOS tool-ui/trusted-ui posture all point to the same lesson: `wants surfacing`, `may try to raise`, `actually frontmost/focused now`, and `trusted-input path active` should stay on different seams.
- Therefore: the future shell should never collapse summon beacons, activation batons, front latches, focus hints, and secure-entry shutters into one `focus` bit.

## More shell chrome worth stealing
- **Summon beacons** from REF-XDG-ACTIVATION-V1 plus SlopOS display-surface honesty.
- **Activation baton chips** from REF-MS-ALLOWSETFOREGROUND and REF-MS-COALLOWSETFOREGROUND.
- **Front latches** from explicit focus/foreground APIs rather than transcript guessing.
- **Focus-quality chips** from REF-XTERM-FOCUS, REF-WEZTERM-SHELL-INT, and REF-GHOSTTY-130 so the shell can admit whether it knows exact focus truth or only shell-integration hints.
- **Secure-entry shutters** from SlopOS trusted-UI posture so frontmost chrome never impersonates trusted approval/login truth.


### L50. Observe mirrors, automation leases, synthetic input, and secure-entry clamps are different classes
- REF-XDG-INPUTCAPTURE, REF-XDG-REMOTEDESKTOP, REF-ANDROID-MEDIAPROJECTION, REF-ANDROID-FLAGSECURE, REF-FUCHSIA-A11Y, REF-FUCHSIA-FOCUSCHAIN, REF-WIN-UIAUT-SECURITY, REF-WIN-UIACCESS-SECUREDESKTOP, and SlopOS accessibility/automation posture all point to the same lesson: `I can see a mirror`, `I hold a lease`, `I can inject now`, and `secure entry blocks this here` should stay on different seams.
- Therefore: the future shell should never collapse mirror strips, lease chips, rehearsal rails, secure-entry curtains, and history cards into one flattering `automation active` bit.

## More shell chrome worth stealing
- **Mirror strips** from REF-XDG-SCREENCAST, REF-ANDROID-MEDIAPROJECTION, and SlopOS display-surface honesty.
- **Lease chips** from REF-XDG-INPUTCAPTURE and REF-XDG-REMOTEDESKTOP.
- **Rehearsal rails** from the combination of observe-only accessibility posture and quality-graded shell integration.
- **Secure-entry curtains** from REF-ANDROID-FLAGSECURE, REF-WIN-UIACCESS-SECUREDESKTOP, and SlopOS trusted-UI posture.
- **Focus/automation quality chips** from REF-VSCODE-SHELL-INTEGRATION, REF-WEZTERM-SHELL-INT, and REF-GHOSTTY-130 so the shell can confess whether it knows semantic truth, mirror-only truth, or only prompt-local hints.

### L34. Clipboard truth has more states than `copied`
- REF-WAYLAND-DATADEVICES, REF-WAYLAND-PRIMARY-SELECTION, REF-XDG-FILETRANSFER, REF-WAYLAND-DATA-CONTROL, REF-W3C-CLIPBOARD, and REF-XTERM-BRACKETED-PASTE all show that current owner/source, offered representation, retained clipboard-manager copy, prompt-local paste, and later imported object are different truths.
- Therefore: make current offers, history ghosts, paste capsules, and materialized imports visibly different instead of laundering them into one clipboard/open story.

## More nifty ideas worth stealing
- **Offer cards, history ghosts, and paste capsules** from REF-XDG-FILETRANSFER, REF-WAYLAND-PRIMARY-SELECTION, REF-WAYLAND-DATA-CONTROL, REF-W3C-CLIPBOARD, REF-XTERM-BRACKETED-PASTE, and REF-KITTY-CLIPBOARD.

### L75. Projection sites, published aliases, and local realization are different truths
- REF-XDG-DOCUMENTS, REF-ANDROID-SAF, REF-ANDROID-FILEPROVIDER, REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-DIR-CAPS, REF-MS-CFREGISTER, and REF-MS-CFCONVERT all point to the same lesson: one visible namespace site can be mediated/provider-backed, one room may separately publish an alias for it, and one later act may localize it for real.
- Therefore: ViewFS should keep provider projection, room publication, live bind, localization, and receipt/history visibly distinct instead of flattening them into one fake path or `opened file` story.

## More ideas worth stealing
- **Site ledgers** that show projection sites, room aliases, and localization separately.
- **Provider halos** and **placeholder/hydrated lamps** from Cloud Files / file-provider posture.
- **Bind-here last** as a receiver-side shell default after chooser/import actions.
- **Same-object multi-site diffs** so a shell can compare mediated reachability, room publication, and local realization honestly.

### L76. Base stacks, writable uppers, merged views, and publish results are different truths
- REF-OVERLAYFS, REF-PLAN9-UNIONDIRS, REF-K8S-PROJECTED-VOLUMES, REF-APPLE-FILEPROVIDER-PLACEHOLDER, REF-APPLE-FILEPROVIDER-STARTPROVIDING, REF-APPLE-FILEPROVIDER-EVICT, and REF-NIX-REALISE all point to the same lesson: a projected/generated base, a writable local shadow, the merged presentation a room traverses, and a later durable publish/commit/adopt result are different classes.
- Therefore: ViewFS should keep projected bases, local upper overlays, merged room presentations, publish results, and receipts visibly separate instead of flattening them into one flattering editable path story.

## More ideas worth stealing
- **stack badges** and **merge rails** from OverlayFS lower/upper/whiteout posture.
- **ordered-creation pips** from Plan 9 union directories.
- **multi-source merge ledgers** from Kubernetes projected volumes.
- **placeholder/materialize/evict ladders** from File Provider systems.
- **explicit realize/publish ladders** from Nix.



### L77. Local draft, pushback basis, provider verdict, and adopted result should stay separate
- REF-RFC9110-PRECONDITIONS, REF-S3-CONDITIONAL-WRITES, REF-GCS-PRECONDITIONS, REF-GIT-FORCE-WITH-LEASE, REF-GIT-UPDATE-REF, REF-WEBDAV-LOCKING, REF-ETCD-TXN, and REF-MDN-CREATEWRITABLE all point to the same lesson: one private draft, one exact expected-old gate, one provider-side accept/reject verdict, and one locally adopted result are materially different truths.
- Therefore: ViewFS should keep live room bind, local edit shadow, pushback basis/preconditions, provider verdict, local adoption, and receipt/history visibly separate.

## More ideas worth stealing
- **Basis lamps** and **verdict cards** from modern shell/terminal quality signaling plus conditional-write posture.
- **Force-with-lease ladders** that retry safely without pretending every backend is Git.
- **Adopt rails** that separate `keep draft`, `fast-forward local`, `fork local`, and `receipt only`.


### L78. Accepted requests, operation tickets, completion verdicts, and local adoption are different truths
- REF-RFC9110-202, REF-XDG-REQUEST, REF-GCLOUD-LRO, REF-GDRIVE-LRO, REF-AIP151-LRO, REF-AZURE-ASYNC-REQREPLY, and SlopOS acceptance/completion posture all point to the same lesson: one request can be admitted now, followed through later, settled even later, and then still require an explicit local adoption choice.
- Therefore: ViewFS should keep accepted requests, provider operation tickets, completion verdicts, locally adopted results, and receipts visibly distinct instead of collapsing them into one flattering `saved/running/done` blob.

## More ideas worth stealing
- **Accept slips** that never impersonate completion.
- **Operation beads** that can age, expire, and lose freshness honestly.
- **Settle rails** that distinguish `pending`, `settled`, `expired`, and `history only`.
- **Adopt rails** that keep local post-settlement choices explicit.


## Revision 114 mapping: sameness witnesses, dedupe keys, and follow-up truth
- REF-HTTPAPI-IDEMPOTENCY-KEY, REF-AWS-EC2-IDEMPOTENCY, REF-STRIPE-IDEMPOTENT-REQUESTS, REF-STRIPE-ADVANCED-ERROR-HANDLING, REF-GCLOUD-LRO, and SlopOS `network-request-idempotency-boundary-v0.md` all point to the same lesson: one retry-safe sameness witness, one admitted request, one provider operation ticket, one later completion verdict, and one local adopted result are different truths.
- **Intent lamps** from HTTP and SlopOS request-key humility.
- **Retry braids** from grouping same-intent attempts without implying one universal run.
- **Sameness chips** from fail-closed parameter/fingerprint comparison.
- **Not-the-same-request shutters** from AWS/Stripe mismatch posture.
- **Dedupe afterglow** from replayed-first-result discipline.

### L80. Caller request context, detached continuation, deadline, and cancellation are different truths
- REF-GO-CONTEXT, REF-GO-CANCEL-OPS, REF-GO-WITHOUTCANCEL, REF-GRPC-DEADLINES, REF-KOTLIN-CANCEL, REF-KOTLIN-NONCANCELLABLE, REF-TEMPORAL-DISCONNECTEDCTX, and REF-CAPNP-CANCEL all point to the same lesson: one caller-bound context, one detached cleanup/continuation root, one cutoff/deadline intent, one live cancellation state, and one later provider follow-up handle are materially different classes.
- Therefore: ViewFS should keep caller request context, detached root, deadline intent, cancellation state, provider operation ticket, and receipt/history visibly separate instead of flattening them into one vague `background still running` story.

## More ideas worth stealing
- **Cutoff lamps** inspired by gRPC deadlines and Go context causes.
- **Detach-root cards** inspired by Go `WithoutCancel` and Temporal disconnected cleanup.
- **Continue-without-me ladders** that separate cleanup-only detachment from ordinary provider continuation.
- **Cancellation braids** that show propagated versus cooperatively acknowledged versus still-settling truth.

### L81. Creator-populated namespaces, exact child handle tables, and portal imports are different truths
- REF-PLAN9, REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-SANDBOXING, REF-CAPSICUM-SEC10, REF-OPENAT2, REF-XDG-DOCUMENTS, REF-XDG-FILETRANSFER, and REF-APPLE-SECSTART all point to the same lesson: a creator can seed a bounded view, a launcher can construct an exact child table, and later imports can widen reachability explicitly without making path rediscovery or ambient inheritance the semantic core.
- Therefore: ViewFS should let rooms be creator-seeded, launches be exact-table reviewed, and imports be explicit events rather than silent self-discovery.

## More ideas worth stealing
- **room seed kits** that summarize namespace fragments, activation slots, and launch-time handle posture.
- **exact-child-table receipts** instead of best-effort `close-on-exec hygiene` folklore.
- **ambient-debt sirens** when compat walkers or host-path escapes were used.
- **import ladders** that keep `temporary import`, `bind here`, `durable anchor`, and `receipt only` visibly separate.

### L82. Immutable blobs, mutable anchors, retention roots, and live authority are different truths
- REF-EROS, REF-CAPROS-USERDRIVERS, REF-NIX-GCROOTS, REF-GIT-UPDATE-REF, REF-S3-CONDITIONAL-WRITES, and REF-OSTREE-OVERVIEW all point to the same lesson: immutable stored objects, mutable named roots, retention/GC truth, and current live authority each have their own lifecycle and failure modes.
- Therefore: ViewFS should keep store membership, mutable anchors, retention roots, and live handle/currentness truth visibly separate.

## More ideas worth stealing
- **root ledgers** for mutable anchor changes over immutable objects.
- **retention racks** that distinguish `kept alive`, `collectible`, `continuity locker`, and `published name`.
- **compare-and-swap anchor moves** rather than silent last-writer-wins head changes.
- **live-versus-durable honesty lamps** so the shell can admit whether it has current possession, a stale durable anchor, or only a receipt.

### L83. Object homes, attached tools, imports, and retention roots are different classes
- REF-SANDSTORM-GRAINS and REF-SANDSTORM-POWERBOX show that object-centered work contexts and user-mediated capability introductions can stay safer and easier to explain than broad app-centric access.
- REF-FUCHSIA-NAMESPACE reminds us that names live in one namespace/container, not in the object itself.
- REF-NIX-GCROOTS shows that retention is an explicit root set rather than a side effect of current attachment or current open state.
- Therefore: do not let ViewFS collapse object-home rooms, attached tools, imported binds, published names, and retention roots into one magical `opened object`.

## More ideas worth stealing
- **grain-style object homes** from REF-SANDSTORM-GRAINS, but kept as a design option rather than a universal rule.
- **tool docks / attach-tool-later flows** from combining REF-SANDSTORM-GRAINS with REF-FUCHSIA-NAMESPACE.
- **room-seed cards** that say what object set is home, what arrived later by import, and what is only currently attached tooling.
- **root-ledger badges** from REF-NIX-GCROOTS so retention stays explicit instead of pretending `still around` means `still rooted`.


### L84. Object identity, capability facets, grouped kits, and published names are different classes
- REF-SANDSTORM-POWERBOX and REF-SANDSTORM-GRAINS show that the same underlying grain can be approached through different requested APIs or permission levels rather than one giant app permission.
- REF-FUCHSIA-CAPS and REF-FUCHSIA-DICTCAP show that capabilities combine resource plus rights, and grouped capabilities can be routed together without turning grouping into publication.
- REF-CAPSICUM-RIGHTS says narrower rights are a real new live truth because rights can only be reduced, never expanded.
- REF-CHERIOT-CAPS and REF-CHERIOT-SEALING remind us that capability tokens can stay typed and opaque instead of dissolving into stringly rediscovery.
- Therefore: ViewFS should keep object identity, chosen capability facets, grouped kits, live room binds, published names, and receipts visibly distinct instead of one magical `have the object` story.

## More ideas worth stealing
- **facet chips** for `inspect`, `edit`, `publish`, `automate`, `kit only`, or `history only`.
- **kit cards** that show grouped facets without implying they are all bound here now.
- **bind-one-facet-here ladders** so attaching a tool does not silently widen to every affordance of the object.
- **opaque-token posture** for especially sensitive handles so remembered strings cannot masquerade as the handle itself.


### L85. Descriptor/proof-only rows, verify-only facets, and live read/write facets are different classes
- REF-TAHOE-URIS and REF-TAHOE-MUTABLE show that one stored object can legitimately have write, read, and verify capability flavors instead of one magical universal object token.
- REF-LINUX-OPATH shows that a descriptor can indicate location and support descriptor-level operations while ordinary byte I/O still fails.
- REF-CHERIOT-SEALING reminds us that some returnable tokens should stay opaque and tamper-evident instead of becoming stringly rediscovery bait.
- Therefore: ViewFS should keep descriptor/proof-only rows, verify-only facets, live read/edit/publish facets, current room binds, and receipts visibly distinct instead of one flattering `object card` story.

## More ideas worth stealing
- **verify chips** that say `descriptor only`, `verify only`, `read now`, `publish now`, or `history only`.
- **proof cards** that are safe to keep in wallets, receipts, notebooks, and history without silently reviving authority.
- **read rails** and **publish rails** that make stronger live facets feel intentionally different rather than hidden upgrades.
- **opaque return tokens** for especially sensitive flows where a future hand-back should be validated, not rediscovered by name.


### L86. Grant outlooks, issued-bounds records, restore tokens, and current live state are different classes
- REF-W3C-PERMISSIONS, REF-WICG-FSACCESS, REF-ANDROID-URIPERMISSION, REF-XDG-REQUEST, REF-XDG-SESSION, REF-XDG-REMOTEDESKTOP, and SlopOS `lease-descriptor-state-boundary-v0.md` all point to the same lesson: preflight permission outlook, exact issued-bounds evidence, restore/reactivation material, current live state, and explicit death-state verdicts are different truths.
- Therefore: ViewFS should keep grant gauges, issued-bounds cards, restore beads, live binds, death cards, and durable receipts visibly distinct instead of flattening them into one vague `still allowed/openable` story.

## More ideas worth stealing
- **grant gauges** that say `prompt`, `granted`, `denied`, `reconsent needed`, or `unknown` without pretending any of those are live binds.
- **issued-time / persisted-time chips** from REF-ANDROID-URIPERMISSION and descriptor-evidence posture so old review artifacts stay visibly old.
- **single-use restore beads** from REF-XDG-REMOTEDESKTOP so continuity aids do not impersonate current sessions.
- **death cards** that preserve `revoked`, `expired`, `session closed`, `token spent`, `target changed`, or `history only` instead of collapsing into `stale`.
- **repair ladders** from combining REF-WICG-FSACCESS, REF-XDG-REQUEST, and SlopOS continuity humility.

### L87. Semantic object cores, exact byte proofs, structured addresses, and live facets are different classes
- REF-OCI-DESCRIPTOR, REF-RFC6920, REF-IPFS-CIDS, REF-NIX-CA, and the current SlopOS artifact/docref/capstore posture all point to the same lesson: several useful hash-like or descriptor-like identities can coexist without meaning the same thing.
- OCI sharpens the exact-byte lane because its descriptor digest is over targeted raw content while media type and size stay separate fields.
- RFC 6920 sharpens the hash-name lane because `ni:` names standardize hash-based naming for digital objects without pretending those names are live handles.
- IPFS sharpens the shape-address lane because CIDs include codec information and may identify the root block of a chunked DAG rather than the original file checksum.
- Nix sharpens the closure-address lane because a content-addressed store path can include file graph, references, name, and store-directory context instead of only raw bytes.
- Therefore: ViewFS should keep semantic object cores, exact byte proofs, structured addresses, names/designators, live facets, and receipts visibly distinct instead of flattening them into one magical `object id` story.

## More ideas worth stealing
- **object-core badges** that say `same object core`, `related derivative`, `core unknown`, or `history only`.
- **byte-proof lamps** that separate exact raw-byte proof from canonical-form proof.
- **shape-hash drawers** that explain `raw blob digest`, `root-block hash`, `chunked DAG address`, `closure/store-path address`, or `canonical-form digest`.
- **facet rails** that stop proof cards and names from impersonating current inspect/read/edit/publish authority.

## L88. Stable review stamps, descriptive envelopes, explain sidecars, and live authority are different classes
Steal from REF-GIT-PATCH-ID, REF-OCI-DESCRIPTOR, REF-OCI-ANNOTATIONS, REF-IN-TOTO-STATEMENT, REF-SLSA-PROVENANCE, and the current SlopOS wallet/core-digest posture.

Several systems keep a smaller stable comparison key separate from richer descriptive context:
- Git patch-id is a stable-enough patch-shaped key, not the whole commit object.
- OCI descriptors keep exact-content truth small while annotations stay descriptive.
- in-toto statements keep subject digest truth distinct from names and the broader predicate envelope.
- SlopOS now makes the same move directly with `wallet_core_digest` versus full-wallet correlation digest and separate graph/diff explainability digests.

That is a very strong hint that ViewFS should keep:
- **authority-core stamps** for drift/reconsent and stable review gates,
- **descriptive envelopes** for human context,
- **explain sidecars** for graph/diff/basis/provenance,
- **live binds** for current power,
- **receipts/history** for durable memory.

## More ideas worth stealing
- **core stamps** that stay calm even when issuance timestamps, labels, or local context change
- **envelope drawers** that make volatile descriptive fields visible without making them gate keys
- **sidecar lamps** that advertise diff/graph/provenance help without implying live authority
- **live rails** that say `bound here now` separately from every kind of descriptive card


## L89. Strong proofs, weak validators, comparison profiles, and live facets are different classes
Steal from REF-RFC9110-PRECONDITIONS, REF-AWS-S3-OBJECT-ETAG, REF-AWS-S3-INTEGRITY, REF-GIT-PATCH-ID, and the current SlopOS wallet/artifact/commit posture.

Several systems keep different comparison strengths for different jobs:
- HTTP explicitly distinguishes weak and strong validators, and strong comparison is what later mutation/range-sensitive flows depend on.
- Amazon S3 explicitly warns that an object ETag may or may not be an MD5 digest of the object data, while separate checksum lanes exist.
- Git patch-id is a reasonably stable patch-shaped key, not the whole commit object.
- SlopOS already gives the same shape locally with `wallet_core_digest` as a stable review key and CH-AREF / commit digests on the exact-artifact lane.

That is a very strong hint that ViewFS should keep:
- **strong-lock badges** for exact proof strength,
- **weak lamps** for calmer sameness/drift hints,
- **compare-profile drawers** for the declared equivalence rule,
- **facet rails** for current inspect/read/edit/publish authority,
- **receipts/history** for durable memory.

## More ideas worth stealing
- **strong-lock badges** that say `exact proof`, `range-safe`, `commit-safe`, `weaker than exact`, or `history only`
- **weak lamps** that say `same enough`, `changed under profile`, `profile changed`, `cannot compare`, or `heuristic only`
- **compare-profile drawers** that explain which fields/bytes are in or out of the comparison set
- **switch-profile ladders** so `review weak drift`, `fetch stronger proof`, `switch compare profile`, and `ask for fresh bind` stay visibly distinct


### L90. Object names, revision tokens, order scopes, supersession rows, and live facets are different classes
- REF-K8S-OBJECT-NAMES, REF-K8S-API-CONCEPTS-WATCH, REF-ETCD-API-REVISIONS, REF-AWS-S3-VERSIONING, REF-GIT-REFLOG, and the current SlopOS ordering-token / conflict-key posture all point to the same lesson: several useful `version-like` or `history-like` rows can coexist without meaning the same thing.
- Kubernetes sharpens the split because object `name`, `UID`, and `resourceVersion` are different truths, and watch history is explicitly finite.
- etcd sharpens the split because key identity, key-local `version`, `create_revision`, `mod_revision`, and the cluster revision are all different truths.
- S3 sharpens the split because key designation, opaque version IDs, current delete-marker posture, and noncurrent-version retrieval are different truths.
- Git sharpens the split because refs, object IDs, and reflogs are different truths.
- Therefore: ViewFS should keep semantic object cores, designations, revision/head tokens, order scopes, supersession rows, current live facets, and receipts visibly distinct instead of flattening them into one magical `versioned object handle` story.

## More ideas worth stealing
- **head badges** that say `current`, `noncurrent`, `superseded`, `delete marker`, `parallel head`, or `history only`.
- **order pips** that say `same order scope`, `parallel scope`, `scope mismatch`, or `order unknown`.
- **supersession ladders** that explain `replaced by`, `restored from`, `tombstoned by`, or `history only` without pretending any of those rows are live authority.
- **facet rails** that keep `current head` and `current live power` visibly separate.

### L91. Semantic records, canonical payloads, signed wrappers, wire copies, and live facets are different classes
- REF-JCS-RFC8785, REF-CBOR-RFC8949, REF-COSE-RFC9052, REF-IN-TOTO-ENVELOPE, REF-IN-TOTO-STATEMENT, and the current SlopOS wallet/encoding posture all point to the same lesson: several useful byte layers can coexist without meaning the same thing.
- JCS sharpens the split because cryptographic work can happen on a canonicalized counterpart while original JSON remains on the wire.
- RFC 8949 sharpens the split because protocols must be explicit when several encodings could express the same semantics.
- COSE sharpens the split because payloads can be detached and the application must then ensure the payload travels unchanged.
- in-toto sharpens the split because Statement and Envelope are separate layers and `payloadType` must be authenticated with the payload.
- Therefore: ViewFS should keep semantic records, canonical payloads, signed wrappers, wire/storage copies, live facets, and receipts visibly distinct instead of flattening them into one magical `signed object blob` story.

## More ideas worth stealing
- **record cards** that say `same meaning`, `changed meaning`, `review only`, or `unknown`.
- **payload chips** that say `same canonical payload`, `profile mismatch`, `payload changed`, or `not computed`.
- **wrapper seals** that say `signed`, `payload type authenticated`, `detached payload`, `wrapper changed`, or `wrapper only`.
- **wire ghosts** that say `transport copy`, `logged copy`, `export copy`, or `history only`.
- **live rails** that keep every payload/wrapper/wire row visibly weaker than current inspect/read/edit/publish power.



### L92. Fresh object identities, shared backing, copy lineage, and live facets are different classes
- REF-LINUX-FICLONE, REF-BTRFS-REFLINK, REF-ZFSCONCEPTS-CLONES, REF-APPLE-APFS-ABOUT, and the current SlopOS `import-to-docref-fresh-identity-boundary-v0.md` / `open-untrusted-export-lineage-boundary-v0.md` posture all point to the same lesson: several useful clone-like or copy-like truths can coexist without meaning the same thing.
- Linux reflink sharpens the split because files can share underlying storage while later writes stay private to the file being written.
- Btrfs sharpens the split because reflinked files share blocks but are otherwise independent.
- OpenZFS sharpens the split because clones start from snapshots, keep explicit origin dependency, and even have a separate promotion move.
- APFS sharpens the split because a clone can occupy no additional space initially while still being a copy, not a hard link.
- Therefore: ViewFS should keep fresh object identities, shared backing, copy lineage, current live facets, and receipts visibly distinct instead of flattening them into one magical `cheap copy` story.

## More ideas worth stealing
- **birth badges** that say `fresh object`, `derived object`, `rebuilt object`, or `history only`.
- **backing ghosts** that say `shares backing`, `backing diverged`, `deep copy`, or `unknown`.
- **lineage ladders** that explain `reflinked from`, `snapshot origin`, `explicit parent`, `rebuilt from`, or `history only`.
- **unshare/adopt ladders** so `deep copy now`, `keep shared`, `promote derived copy`, and `receipt only` stay visibly distinct.

### L93. Upload sessions, part coverage, completion manifests, committed objects, and live facets are different classes
- REF-AWS-S3-CREATEMPU, REF-AWS-S3-COMPLETEMPU, REF-AWS-S3-MPU-OVERVIEW, REF-TUS-PROTOCOL, REF-OCI-DISTRIBUTION-CHUNKED, REF-GCS-RESUMABLE-UPLOADS, and the current SlopOS D-PERSIST / CH-AREF / import/jobs posture all point to the same lesson: several useful `upload-like` or `in progress` truths can coexist without meaning the same thing.
- Amazon S3 sharpens the split because multipart upload has an explicit upload ID, per-part progress, a caller-maintained completion list, and a later complete-or-abort decision.
- tus sharpens the split because the resumable URL and current offset are session/progress truths, not the same thing as one finished durable object.
- OCI Distribution sharpens the split because chunked blob upload is explicitly three phases: obtain a session URL, upload chunks, then close the session.
- Google Cloud Storage sharpens the split because a resumable-upload session URI is an authentication-bearing session carrier that may expire and is not the same thing as the final object.
- Therefore: ViewFS should keep upload sessions, part coverage, completion manifests, committed objects, abort/expiry verdicts, current live facets, and receipts visibly distinct instead of flattening them into one magical `uploading object` story.

## More ideas worth stealing
- **session beads** that say `open`, `resuming`, `sealed`, `committing`, `expired`, or `history only`.
- **part gauges** that say `0 parts`, `partial`, `offset known`, `assembly list ready`, `cannot prove`, or `history only`.
- **seal ladders** that keep `finalize with manifest`, `resume`, `abort`, and `inspect committed object` visibly distinct.
- **abort ash** that preserves `aborted`, `expired`, `replaced`, or `cleanup pending` without pretending any of those are object identity or current authority.


### L94. Assembly recipes, member descriptors, aggregate objects, realized work surfaces, and live facets are different classes
- REF-GCS-COMPOSITE, REF-OCI-MANIFEST, REF-OCI-IMAGE-INDEX, REF-GIT-WRITE-TREE, REF-CONTAINERD-PULL-UNPACK, and the current SlopOS component-manifest / activation / persistence posture all point to the same lesson: several useful `assembled object` truths can coexist without meaning the same thing.
- Google Cloud Storage sharpens the split because a composite object can be created from existing source objects while the source objects remain unaffected and the resulting composite is its own later object truth.
- OCI sharpens the split because manifests and image indexes are explicit descriptor graphs, while configs/layers/content addresses remain distinct from later runtime unpack or execution truth.
- `git write-tree` sharpens the split because one tree object is minted from an explicit staged index rather than from ambient directory traversal folklore.
- containerd sharpens the split because pulled content in the content store, unpacked snapshots, containers, and live tasks are all different truths.
- Therefore: ViewFS should keep assembly recipes, member descriptors, aggregate objects, realized work surfaces, current live facets, and receipts visibly distinct instead of flattening them into one magical `bundle object` story.

## More ideas worth stealing
- **recipe cards** that say `declared`, `reviewed`, `stale`, `denied`, or `history only`.
- **member rails** that say `complete`, `missing`, `provider hidden`, `stale`, or `replaced`.
- **aggregate seals** that say `assembled`, `rejected`, `superseded`, `history only`, or `unknown`.
- **unpack lamps** that say `not realized`, `realized here`, `realized elsewhere`, `evicted`, or `rebuildable`.
- **live rails** that keep every recipe/member/aggregate row visibly weaker than current inspect/read/edit/publish power.


### L95. Transient staging capsules, seal states, courier handoffs, committed objects, and live facets are different classes
- REF-MEMFD-CREATE, REF-MEMFD-SEALS, REF-UNIX-SCMRIGHTS, REF-LINUX-OTMPFILE, REF-LINUX-MEMFD-PRESERVE, and the current SlopOS import/materialization/commit posture all point to the same lesson: several useful `draft` or `temporary` truths can coexist without meaning the same thing.
- `memfd_create()` sharpens the split because an anonymous regular-file-like object can exist privately and still be handed to another process.
- file seals sharpen the split because `freeze this now` is about allowed operations, not about durable identity or publication.
- UNIX FD passing sharpens the split because one explicit local courier act can move exact access between processes without publishing anything into a namespace.
- `O_TMPFILE` sharpens the split because an unnamed object can exist before any public name is attached.
- current Linux memfd-preservation docs sharpen the split because some continuity paths preserve bytes while seals still must be re-established.
- Therefore: ViewFS should keep transient staging capsules, seal states, courier handoffs, committed objects, current live facets, and receipts visibly distinct instead of flattening them into one magical `temporary file` story.

## More ideas worth stealing
- **capsule cards** that say `draft`, `exact bytes ready`, `discarded`, or `history only`.
- **seal shutters** that say `open`, `sealed for review`, `future writes blocked`, `locked`, or `unknown`.
- **courier rails** that say `sent locally`, `received locally`, `not published`, or `history only`.
- **commit lamps** that say `not committed`, `committed here`, `published now`, `discarded`, or `history only`.
- **live rails** that keep every draft/seal/courier row visibly weaker than current inspect/read/edit/publish power.


### L96. Committed objects, retention clocks, hold states, purge verdicts, and live facets are different classes
- REF-AWS-S3-OBJECT-LOCK, REF-GCS-OBJECT-HOLDS, REF-GCS-OBJECT-RETENTION-LOCK, REF-AZURE-IMMUTABLE-BLOB, and the current SlopOS persistence / verified-blob / receipt-boundary posture all point to the same lesson: several useful `kept`, `locked`, or `delete-later` truths can coexist without meaning the same thing.
- Amazon S3 sharpens the split because legal holds are independent from retention periods, stay until removed, and apply to object versions.
- Google Cloud Storage sharpens the split because temporary holds and event-based holds are different, because event-based holds interact differently with retention timing, and because retention-lock/lifecycle/metadata truths stay separate.
- Azure sharpens the split because legal holds, scope, tags, and audit logs are separate policy/history surfaces rather than blob identity or current live use.
- Therefore: ViewFS should keep committed objects, retention clocks, hold states, purge verdicts, current live facets, and receipts visibly distinct instead of flattening them into one magical `protected object` story.

## More ideas worth stealing
- **hold badges** that say `temporary hold`, `event hold`, `legal hold`, `multiple holds`, or `history only`.
- **retention rails** that say `retain until`, `editable`, `locked`, `satisfied`, or `history only`.
- **purge lamps** that say `eligible`, `blocked by retention`, `blocked by hold`, `lifecycle pending`, `purged`, or `history only`.
- **delete-now rails** that keep `policy allows delete` visibly separate from every kind of read/edit/publish authority.

### L94. Sealed objects, recipient wraps, rewrap plans, unwrap handles, and clear facets are different classes
- REF-RFC7516-JWE, REF-WEBCRYPTO-LEVEL2, REF-GCLOUD-KMS-ENVELOPE, REF-GCLOUD-KMS-REENCRYPT, REF-GCLOUD-KMS-KEYSTATES, and the current SlopOS cryptosvc/vault/wallet posture all point to the same lesson: several useful `encrypted` or `wrapped` rows can coexist without meaning the same thing.
- JWE sharpens the split because multiple recipients can share one ciphertext / IV / authentication tag while carrying separate per-recipient `encrypted_key` material and headers.
- WebCrypto sharpens the split because `CryptoKey` is an opaque reference and `wrapKey` / `unwrapKey` are separate operations.
- Cloud KMS sharpens the split because envelope encryption stores encrypted data with wrapped DEK material, key rotation does not automatically re-encrypt existing data, and ciphertext remembers which key version encrypted it.
- Therefore: ViewFS should keep sealed objects, wrap rosters, rewrap plans/receipts, unwrap handles, clear facets, and receipts visibly distinct instead of flattening them into one magical `encrypted object handle` story.

## More ideas worth stealing
- **seal badges** that say `sealed`, `typed sealed`, `signed+sealed`, `history only`, or `clear here now`.
- **wrap rosters** that say `1 recipient`, `3 recipients`, `provider hidden`, `mixed roster`, or `history only`.
- **rewrap ladders** that explain `rotate wraps`, `add recipient`, `drop recipient`, `rewrap done`, or `rewrap failed` without pretending any of those rows are current clear authority.
- **unwrap rails** that say `provider-bound handle`, `needs mediator`, `unwrapable here`, or `cannot clear here`.
- **clear rails** that keep `inspect/read/edit/publish now` visibly stronger than every seal/wrap/rewrap/history card.



### L97. Committed objects, durability profiles, redundancy layouts, repair verdicts, availability states, and live facets are different classes
- REF-CEPH-ARCHITECTURE, REF-CEPH-SCRUB, REF-TAHOE-CONFIG, REF-TAHOE-OUTLINE, REF-AWS-S3-REPLICATION, REF-AWS-S3-REPLICATION-STATUS, and the current SlopOS artifact/CapStore posture all point to the same lesson: several useful `stored safely` or `available now` truths can coexist without meaning the same thing.
- Ceph sharpens the split because object IDs are mapped through placement groups to OSDs via CRUSH, specifically to keep logical object identity separate from physical placement and dynamic rebalancing.
- Ceph also sharpens the split because scrubbing and peering are current integrity/repair truths, not object identity.
- Tahoe-LAFS sharpens the split because k-of-n share thresholds, filecap values, share placement, and access-control questions are separate layers.
- Amazon S3 sharpens the split because replication is asynchronous and replication status can be `PENDING`, `COMPLETED`, `FAILED`, or `REPLICA` without changing semantic object identity.
- Therefore: ViewFS should keep committed objects, durability profiles, redundancy layouts, repair verdicts, availability states, current live facets, and receipts visibly distinct instead of flattening them into one magical `healthy stored object` story.

## More ideas worth stealing
- **durability badges** that say `single copy`, `replica target`, `k-of-n target`, `policy hidden`, or `history only`.
- **layout ghosts** that say `shares placed`, `replicas spread`, `placement changed`, `layout hidden`, or `history only`.
- **repair ladders** that say `healthy`, `scrubbing`, `degraded`, `repairing`, `failed`, or `history only`.
- **availability lamps** that say `retrievable`, `retrievable with degradation`, `provider unavailable`, `unrecoverable`, or `history only`.
- **live rails** that keep every durability/layout/repair/availability row visibly weaker than current inspect/read/edit/publish power.

### L98. Committed objects, archive tiers, thaw jobs, thawed copies, and live facets are different classes
- REF-S3-RESTORING-OBJECTS, REF-S3-RESTOREOBJECT, REF-S3-RESTORESTATUS, REF-AZURE-ARCHIVE-REHYDRATE, REF-AZURE-ARCHIVE-BLOB, and the current SlopOS import/materialize/CapStore posture all point to the same lesson: several useful `stored`, `archived`, `restoring`, or `temporarily readable` truths can coexist without meaning the same thing.
- Amazon S3 sharpens the split because archived objects are not accessible in real time, restore is explicit, and restored copies for Glacier classes can expire after the requested duration.
- Amazon S3 also sharpens the split because restore-status rows are metadata about retrieval state, not semantic object identity or current live authority.
- Azure Blob Storage sharpens the split because archive-tier blobs are offline and unreadable until rehydrated.
- Azure also sharpens the split because rehydration can either copy to a new online blob or change the archived blob's tier, which is a strong reminder that `thawed` is not one universal object-store act.
- Therefore: ViewFS should keep committed objects, archive tiers, thaw jobs, thawed copies, current live facets, and receipts visibly distinct instead of flattening them into one magical `restored file` story.

## More ideas worth stealing
- **frost badges** that say `hot`, `cool`, `cold`, `archived`, `offline`, or `history only`.
- **thaw beads** that say `requested`, `pending`, `priority high`, `failed`, `expired`, or `history only`.
- **copy-thaw ladders** that say `temporary copy`, `tier changed`, `copy target ready`, `copy target pending`, or `history only`.
- **expiry lanterns** that say `expires then`, `no expiry exposed`, `expired`, or `history only`.
- **live rails** that keep every archive/thaw/history row visibly weaker than current inspect/read/edit/publish power.


### L99. Committed objects, residency profiles, placement realms, route endpoints, egress gates, and live facets are different classes
- REF-AWS-S3-REPLICATION, REF-AWS-S3-MRAP-ROUTING, REF-GCS-BUCKET-LOCATIONS, REF-GCS-BUCKET-RPO, REF-AZURE-STORAGE-REDUNDANCY, REF-CEPH-CRUSHMAP, and the current SlopOS cluster-map / replication-contract posture all point to the same lesson: several useful `where is it?` truths can coexist without meaning the same thing.
- Amazon S3 sharpens the split because Cross-Region Replication and Same-Region Replication are explicit copy-spread choices, while Multi-Region Access Point routing can still send a request to the closest bucket that does not hold the object yet.
- Google Cloud Storage sharpens the split because dual-region residency and bucket replication policy / RPO are explicit configuration layers rather than object identity.
- Azure sharpens the split because secondary-region copies can exist while secondary reads remain unavailable unless RA-GRS or RA-GZRS is enabled, and asynchronous replication means the secondary can lag.
- Ceph sharpens the split because topology-aware placement rules are explicit policy over physical layout rather than logical object identity.
- Therefore: ViewFS should keep committed objects, residency profiles, placement realms, route endpoints, egress gates, current live facets, and receipts visibly distinct instead of flattening them into one magical `global object` story.

## More ideas worth stealing
- **realm badges** that say `single realm`, `dual realm`, `cross-region`, `provider hidden`, or `history only`.
- **placement ghosts** that say `present in A`, `present in A+B`, `lagging`, `unknown`, or `history only`.
- **route halos** that say `nearest route`, `primary route`, `secondary read`, `failover lane`, `route hidden`, or `history only`.
- **egress shutters** that say `local only`, `cross-boundary denied`, `review needed`, `allowed by policy`, or `history only`.
- **residency compare drawers** that line up `policy says`, `placement says`, `route says`, and `egress says` without pretending any one layer is the whole truth.

### L100. Committed objects, access propagation, public cache copies, cache trails, and live facets are different classes
- Amazon S3 now documents strong read-after-write and list consistency for object operations.
- Google Cloud Storage documents strong object/list consistency, but separately documents eventual consistency for granting/revoking access and separately warns that cacheable publicly readable objects might not exhibit strong consistency because cached objects are not updated or deleted until cache lifetime expires.
- RFC 9111 keeps cache behavior as its own standards layer, and RFC 9211 standardizes `Cache-Status` so cache handling can be debugged explicitly instead of guessed.
- SlopOS boundary posture already refuses to let hidden cached provider state quietly become portable truth.
- Therefore: ViewFS should keep committed objects, access-propagation state, public-cache visibility, cache trails, current live facets, and receipts visibly distinct instead of flattening them into one magical `published latest object` story.

Nifty shell ideas to steal:
- **truth badges** that say `origin current`, `origin deleted`, `unknown`, or `history only`.
- **propagation echoes** that say `grant pending`, `revoke settling`, `config propagating`, `provider hidden`, or `history only`.
- **cache ghosts** that say `publicly cacheable`, `stale maybe`, `purge asked`, `cache bypassed`, or `history only`.
- **trail drawers** that expose `Cache-Status`-like hit/miss/forward/stored details without pretending they are authority.


### L101. Committed objects, prefix projections, provider folder resources, listing snapshots, published names, and live facets are different classes
- REF-AWS-S3-PREFIXES, REF-AWS-S3-OBJECT-KEYS, REF-GCS-OBJECTS, REF-GCS-MANAGED-FOLDERS, REF-GCS-OBJECTS-LIST, REF-AZURE-BLOB-LIST, REF-AZURE-BLOB-NAMING, and the current SlopOS capshell / AttrFS / document-import posture all point to the same lesson: several useful `folder-like` truths can coexist without meaning the same thing.
- Amazon S3 sharpens the split because prefixes can organize objects in a way that feels directory-like while still not being directories, and the service still says there is no hierarchy.
- Google Cloud Storage sharpens the split because flat-namespace buckets have no directories or folders, while managed folders are separate resources and `prefixes[]` in list results merely mimic directories.
- Azure sharpens the split because virtual directories can be created from delimiters in blob names, while hierarchical-namespace accounts can also contain actual directories.
- Therefore: ViewFS should keep committed objects, prefix projections, provider folder resources, listing snapshots, published names, current live facets, and receipts visibly distinct instead of flattening them into one magical `folder entry` story.

## More ideas worth stealing
- **prefix badges** that say `flat prefix`, `provider folder`, `managed folder`, `query projection`, or `history only`.
- **folder ghosts** that say `simulated from names`, `native folder resource`, `provider hidden`, or `not proven`.
- **list lanterns** that say `snapshot`, `live`, `partial`, `cached`, `stale possible`, or `history only`.
- **name rails** that keep `published here`, `listed here`, `bound here`, and `live here now` visibly separate.

### L102. Launch view plans, bound roots, handle slot tables, portal import tickets, live binds, and receipts are different classes
- REF-FUCHSIA-NAMESPACE, REF-FUCHSIA-CAPS, REF-FUCHSIA-FSARCH, REF-CAPSICUM-HANDBOOK, REF-WASI-CAPS, REF-WIT-RESOURCE-HANDLES, REF-XDG-DOCUMENTS, REF-XDG-PERMISSION-STORE, REF-TAHOE-URIS, REF-CAPNP-RPC, REF-EROS, REF-GCS-PRECONDITIONS, REF-AZURE-BLOB-CONCURRENCY, REF-ETCD-TXN, and the current SlopOS capshell/portal posture all point to the same lesson: several useful `the process can see this` truths can coexist without meaning the same thing.
- Fuchsia sharpens the split because namespace assembly and capability routing are explicit component/runtime concerns rather than global-root folklore.
- Capsicum and WASI sharpen the split because descriptors/preopens/resources are authority-bearing entries with rights, not mere comments beside path strings.
- XDG Documents sharpens the split because portal-mediated document-store IDs, FUSE paths, host paths, app permissions, grant/revoke calls, and deletion of store entries are separate layers.
- Tahoe-LAFS and Cap'n Proto sharpen the split because capability flavors and capability tables can be explicit without making one universal object/path string the entire model.
- EROS sharpens the split because persistent live capabilities are a deep storage/recovery/revocation design, not an incidental serialization feature.
- GCS/Azure/etcd sharpen the split because currentness witnesses and conditional mutation are different from object names, ticket IDs, and old receipts.
- Therefore: ViewFS should keep launch view plans, bound roots/namespaces, handle slot tables, portal import tickets, current live binds/facets, and receipts visibly distinct instead of flattening them into one magical `opened file` story.

## More ideas worth stealing
- **launch rehearsal cards** that show planned roots, planned slots, planned imports, and planned writes before any authority is installed.
- **root badges** that say `sealed empty`, `synthetic root`, `object-store root`, `provider projection`, `portal-adopted subtree`, `compat membrane`, or `history only`.
- **slot maps** that show rights, leases, own/borrow posture, provider origin, and receipt links for exact live handles.
- **import ticket trays** that say `request drafted`, `chooser open`, `granted-not-bound`, `adopting`, `adopted`, `denied`, `expired`, or `revoked`.
- **adoption ladders** that move from ticket/result to staging capsule, committed object, published bind, or live facet without hiding the transition.
- **live-bind rails** that keep `inspect/read/edit/publish now` visibly stronger than plans, tickets, list rows, and receipts.

## Revision 139: cap-flow, custody, and leak-hygiene ideas to steal

- **Confused deputy** — keep caller/purpose/authority/custody visible; do not let a less-authorized caller feed path strings to a more-authorized service and borrow the service's ambient authority.
- **Capability URLs** — bearer strings are too easy to leak through logs, screenshots, history, telemetry, and copy/paste; visible ViewFS surfaces should prefer redacted summaries and non-authoritative receipts.
- **Fuchsia / Plan 9 / Capsicum / WASI** — explicit namespaces and pre-opened capabilities are strong precedent, but ViewFS still needs post-launch flow accounting.
- **seL4 / Cap'n Proto / WIT** — steal slots/tables, live references, and owned-versus-borrowed handles as separable vocabulary, not as one required implementation.
- **Sandstorm / XDG portals** — user-mediated imports and exports should be handle-shaped, reviewable, and transcriptable.
- **`openat2`, `unveil`, and Landlock** — compatibility access to host paths needs visible root/resolve/restriction posture rather than becoming semantic core.
- **S3 / GCS / Azure Blob / etcd** — compare-before-mutate/currentness witnesses are the right pattern for adoption/export/reopen operations, but no one provider witness should become universal.

Nifty ViewFS ideas:

- flow diffs before portal import, helper launch, or export;
- custody badges on every live handle row;
- outflow gates instead of one overloaded `share` verb;
- leak sirens when expected-dead handles remain live;
- audit drawers that keep old receipts visibly weaker than current authority;
- redaction stripes on copied cap-flow snapshots;
- dead-handle receipt mode for post-revocation history;
- bytes-only alternatives when live authority cannot leave.


### L103. Durable root commits, epoch fences, restore intents, activation targets, and live binds are different classes
- REF-SLOPOS-CAPSTORE, REF-EROS-FASTCAP, REF-CAPROS, REF-AWS-S3-CONDITIONAL-WRITES, REF-GCS-PRECONDITIONS, REF-AZURE-BLOB-CONCURRENCY, REF-ETCD-TXN, REF-QUBES-QREXEC, and REF-WIT-RESOURCE-HANDLES all point to the same lesson: several useful `saved state` truths can coexist without meaning the same thing.
- SlopOS CapStore sharpens the split because root commits, parents, epochs, artifact refs, and durable caps are explicit, while wallets and cap graphs remain non-authoritative explanation surfaces.
- Persistent capability systems sharpen the split because capability persistence is a whole-system recovery/revocation design, not a serialization afterthought.
- Cloud/consenus stores sharpen the split because currentness witnesses are independent of names and object bytes.
- Qubes sharpens the split because cross-domain file/service flows are policy-mediated rather than silently reconnected by old state.
- WIT resources sharpen the split because owned and borrowed handles have lifecycle obligations that should not vanish into durable history.
- Therefore: ViewFS should keep durable root commits, epoch fences, restore intents, resurrection gates, activation targets, current live binds/handle sets, and receipts visibly distinct instead of flattening them into one magical `restored filesystem` story.

## More ideas worth stealing
- **root ledgers** that show recorded roots, accepted tips, rollback candidates, quarantined roots, and receipt-only rows separately.
- **epoch fence cards** that show expected tip, observed tip, comparison profile, and stale/rollback verdict.
- **restore tickets** that say whether the user is inspecting, repairing, rolling back, resuming, or activating.
- **resurrection drawers** that show portal/docref/sturdyref/keyref/secretref gate results before any handle is installed.
- **activation rails** that preview what live slots will and will not be installed.
- **receipt-only ghosts** for authority that existed historically but cannot revive now.

### L104. Reachability roots, live-handle roots, pins/holds/leases, sweep candidates, finalizers, collected ash, live facets, and receipts are different classes

- REF-NIX-GCROOTS, REF-IPFS-PINNING, REF-GIT-GC, REF-CONTAINERD-GC-LEASES, REF-K8S-FINALIZERS, REF-K8S-GC, REF-ZFS-HOLD, and the current SlopOS CapStore/lease posture all point to the same lesson: several useful `kept alive` truths can coexist without meaning the same thing.
- Nix sharpens the split because GC roots are explicit and live store paths are reachable from roots rather than from arbitrary history.
- IPFS sharpens the split because cached objects, direct pins, recursive pins, indirect pins, and MFS protection are different retention stories.
- Git sharpens the split because unreachable objects can survive grace periods and reflogs without becoming guaranteed durable roots.
- containerd sharpens the split because leases protect snapshots/content during and after operations, but the caller owns lease lifecycle.
- Kubernetes sharpens the split because owner references and finalizers choreograph deletion rather than redefining object identity.
- OpenZFS sharpens the split because holds are named no-destroy references that can be inspected and released.
- Therefore: ViewFS should keep reachability roots, live-handle roots, pins/holds/leases, sweep candidates, deletion finalizers, collected ash/tombstones, current live facets, and receipts visibly distinct instead of flattening them into one magical `object exists` story.

## More ideas worth stealing

- **GC halos** that say `durable root`, `live`, `pinned`, `leased`, `cached only`, `finalizing`, `collected`, or `receipt only`.
- **Pin badges** that distinguish direct, recursive, indirect, expiring, policy, provider, and debug pins.
- **Why-retained drawers** that explain root causes without leaking hidden names.
- **Sweep rehearsals** that show dry-run candidates, blockers, grace windows, and stale basis warnings.
- **Finalizer rails** that turn `resource busy` into named cleanup obligations.
- **Ash receipts** that preserve audit truth without keeping bytes or authority alive.

### L105. Origin evidence, quarantine marks, safe-open capsules, viewer residue, derived artifacts, trust clearances, live opens, and receipts are different classes

- REF-APPLE-QUARANTINEKEY, REF-APPLE-GATEKEEPER, REF-APPLE-SAFEOPEN, REF-APPLE-LSFILEQUARANTINEENABLED, REF-MS-ZONEIDENTIFIER, REF-MS-MOTW-OFFICE, REF-MS-PROTECTEDVIEW, REF-MS-APPGUARD, REF-GOOGLE-SAFEBROWSING, REF-CHROME-DANGEROUS-DOWNLOADS, REF-XDG-DOCUMENTS, REF-XDG-PERMISSION-STORE, REF-ANDROID-SAF, and current SlopOS D-QUAR/open-untrusted boundaries all point to the same lesson: several useful `risky content was handled` truths can coexist without meaning the same thing.
- Apple sharpens the split because quarantine metadata and Gatekeeper checks are useful but brittle if propagation and user-visible trust decisions are vague.
- Windows sharpens the split because zone/origin metadata can drive read-only Protected View, macro blocking, Application Guard isolation, or full trust as different lanes.
- Browser download protection sharpens the split because reputation/warning tiers are advisory inputs, not object identity or durable authority.
- XDG Documents and Android SAF sharpen the split because a chooser/document-store grant is scoped access, not content trust.
- SlopOS sharpens the split because it already forbids safe-open success, viewer residue, semantic indexing, derived matches, or same-digest import from silently clearing quarantine.
- Therefore: ViewFS should keep origin evidence, quarantine marks, safe-open capsules, viewer residue, derived artifacts, trust clearances, current live opens, and receipts visibly distinct instead of flattening them into one magical `trusted file` story.

## More ideas worth stealing

- **origin braids** that show arrival route and parent evidence without raw bearer leakage;
- **quarantine shutters** that show blocked operations and safe next actions;
- **safe-open capsule cards** with stable-input, active-content, residue, and export posture;
- **residue lamps** for thumbnails, MRU, autosave, OCR, embeddings, summaries, and crash recovery;
- **derived-artifact rails** that prevent hidden source resurfacing;
- **trust receipts** that scope clearance to preview/edit/active-content/execution separately;
- **metadata-safe search mode** for quarantined objects.

## Revision 143 — Archive/container extraction ideas to steal carefully

- **Extraction plan before extraction**: steal from Python tarfile filters, Go insecure-path toggles, and bsdtar path refusal by making the chosen path/link/device/metadata policy visible before bytes land.
- **Member claims, not paths**: raw archive names should render as evidence rows until a namespace commit adopts them.
- **Sterile materialization roots**: extract into disposable roots or virtual projections before publication.
- **Path-guard badges**: no-absolute, no-dotdot, no-link-escape, no-devices, no-setuid, no-xattrs, no-whiteout-commit by default.
- **Layer-aware but namespace-honest containers**: borrow OCI's manifest/index/layer/config separation without assuming every layer set is a live filesystem root.
- **Unpack receipts**: record denied entries, rewrites, budgets, and cleanup without creating reopen authority or retention roots.

## Revision 144 — supply-chain evidence ideas to steal carefully

- Steal **SPDX/CycloneDX inventory structure**, but keep SBOMs as claim sets, not local truth or live authority.
- Steal **CycloneDX composition completeness markers**, because `unknown` and `incomplete` are first-class states users need to see.
- Steal **PURL's ecosystem-local package coordinate vocabulary**, but never treat a package URL string as a fetch URL, object identity, or same-component proof by itself.
- Steal **OpenVEX/CycloneDX VEX scoped exploitability statements**, but never let `not_affected` become a global scanner suppression or trust clearance.
- Steal **OSV's graph-shaped vulnerability identity caution**, especially the distinction between aliases and upstream relationships.
- Steal **in-toto/SLSA layering**: subject, statement, predicate, envelope, bundle, provenance, verifier output.
- Steal **Sigstore/Rekor transparency**, but phrase it as logged/visible/auditable rather than approved.
- Steal **TUF freshness/delegation/rollback defenses**, but keep update metadata separate from ViewFS local admission and activation.
- Steal **SlopOS CH-SBOM/CH-VEX/CH-AREF posture**: digest-bound evidence, locator hints, verifier-local matching, and no ambient fetch/authority semantics.

## Revision 145 — secret/credential delivery ideas to steal carefully

- Steal **systemd credential shape**: activation-time, immutable during runtime, released on deactivation, file/slot-like, and not propagated down the process tree like environment variables.
- Steal **Kubernetes projected-volume vocabulary** for explicit composition of secret/config/service-account/trust/certificate sources, but keep projection separate from trust, update, and live-use authority.
- Steal **Docker secret mount ergonomics** for runtime-only service access and teardown, while treating platform differences and application-level copies as residue.
- Steal **Secret Service prompt/lock race honesty**: item exists, collection unlocked, secret retrieved, and still usable now are different states.
- Steal **GitHub Actions masking as a redaction lens**, but never let masking pretend to be containment or delivery control.
- Steal **AWS STS short-lived credential posture**: expiry, session tokens, role/audience scope, and reacquisition should be visible.
- Steal **SlopOS D-APPSECRET minimalism**: app seed is not vault, token store, account-linking, auth-result export, or password-manager semantics.

Shell ideas:

- secret slot cards;
- env-shadow lamps;
- redaction coverage lenses;
- renewal rails;
- residue sweepers;
- use receipts that never store bearer material;
- `rerun with fresh token` instead of transcript replay.

## Revision 146 — delegation and revocation ideas to steal carefully

- Steal **seL4's derivation honesty**: strong revoke claims need lineage/derivation knowledge; absent lineage, do not imply recursive recall.
- Steal **SlopOS D-LEASE's proxy-as-authority posture**: the live lease gate enforces; the descriptor explains.
- Steal **epoch/generation stale brakes** from SlopOS RFC-0019 and object-store currentness thinking: mismatch should fail closed with a clear reason.
- Steal **macaroon caveat ergonomics** for visible attenuation, while remembering bearer credentials remain bearer credentials.
- Steal **UCAN's delegable capability-chain and revocation vocabulary**, but preserve manual-revocation humility and irreversible-effect caveats.
- Steal **OAuth token revocation** as provider-local teardown vocabulary, not as a portable disconnect/account-state oracle.
- Steal **AWS STS short lifetime posture**: short-lived access often beats heroic revocation.
- Steal **W3C capability-URL warnings**: URL-shaped authority is paste/log/history/screenshot hazardous.
- Steal **CapTP / Workers RPC reference-passing clarity**: you can use what you have a reference to; history and discovery are separate.
- Steal **Tahoe-LAFS diminishing** as a user-facing mental model for deriving weaker authority from stronger authority.

Shell ideas:

- delegation cards;
- caveat chips with enforcement status;
- membrane lamps;
- revocation wave maps;
- stale-handle brakes;
- recall receipts;
- rotate/reissue ladders;
- redacted `who still can?` drawers.

## Revision 147 inspirations: diagnostics without hidden authority

- **Linux ptrace/procfs/dumpability**: process observation can also be process control, fd visibility, memory visibility, and core capture. ViewFS should refuse to treat same-user or same-workspace inspection as ambient.
- **Fuchsia Inspect**: structured diagnostic trees are a great shape for bounded snapshots, but they should remain observation artifacts, not live namespaces or handle tables.
- **ETW**: controller/provider/consumer separation plus lost-event accounting is useful vocabulary for trace fuses and drop badges.
- **DTrace**: privilege separation and explicit destructive-action enablement are good warnings that tracing systems can cross from observe into effect.
- **Kubernetes RBAC subresources**: logs, exec, attach, and port-forward-like surfaces can be related but separately authorizable.
- **macOS privacy categories**: screen, input, automation, accessibility, and full-disk classes should be user-visible rather than collapsed into one broad inspect bit.
- **SlopOS CH-INSPECT / CH-TRACE / D-OBS / capshell peer-inspection**: direct sibling-cube pressure for bounded snapshots, export cuts, field redaction, sandboxed trace processing, and non-ambient peer inspection.

Nifty ViewFS steal: **inspect lens cards**, **proc shades**, **fd peek cards**, **trace fuses**, **dump guards**, **redaction coverage lenses**, **debug rails**, and **support-bundle receipts**.

Guardrail: a process ID, namespace snapshot, fd row, trace sample, redaction mask, support-bundle manifest, or old inspection receipt is not current inspection/debug authority.

## Revision 148 inspirations: network leases without ambient egress

- **Flatpak**: no network by default is a strong baseline, but `--share=network` is intentionally broad. ViewFS should preserve the no-network posture while providing narrower lease cards.
- **Apple App Sandbox**: client and server network entitlements are separate, a useful connect/listen brightline.
- **Android**: `INTERNET` is a broad manifest permission, while newer local-network permission work shows LAN/loopback/discovery deserves its own user-visible boundary.
- **OpenBSD pledge**: promises can only reduce, and `dns` is distinct from `inet`; resolver authority deserves a name.
- **DoH / SVCB / Happy Eyeballs**: destination review cannot stop at the literal host string because resolution and transport selection can change endpoint shape.
- **Private/Local Network Access**: browsers are adding explicit local-network gates because public-origin code reaching private/loopback endpoints is dangerous.
- **SlopOS D-NETLEASE**: sibling-cube seam vocabulary for portal-issued network authority, resolver binding, request identity, and boundary-doc hygiene.

Nifty ViewFS steal: **net lease cards**, **resolver braids**, **local-exposure shutters**, **egress meters**, **DNS drift lamps**, **stream ghost rows**, **fetch-to-object split cards**, and **send receipts**.

Guardrail: a URL, DNS answer, proxy hint, stream row, old update setting, or send receipt is not current network authority.
## Revision 149 inspirations: service discovery without endpoint folklore

- **DNS-SD**: useful browse/resolve vocabulary; service instance metadata, SRV targets, and TXT records are candidates, not handles.
- **mDNS**: local-link zero-configuration discovery is convenient precisely because it is a privacy/local-network surface that needs visible shutters.
- **Kubernetes Service / EndpointSlice**: logical service, changing backend set, endpoint slices, `ready`, `serving`, and `terminating` states should not collapse.
- **xDS**: typed discovery resources, subscriptions, sequencing, warming, and TTLs are great cautionary patterns for route freshness.
- **systemd socket activation**: a manager-passed fd is a live authority; a unit/service label is not.
- **SPIFFE**: workload identity evidence is useful, but identity is not permission, trust clearance, or invocation authority.
- **SlopOS D-NETLEASE / DID / MCP / artifact-reference boundaries**: sibling-cube pressure to keep names, catalogs, resolver metadata, locators, endpoints, and live handles apart.

Nifty ViewFS steal: **service cards**, **discovery drawers**, **readiness lamps**, **binding braids**, **activation rails**, **advert shutters**, **identity evidence lenses**, **service diffs**, and **call receipts**.

Guardrail: a service designator, catalog row, DNS-SD instance, EndpointSlice endpoint, xDS resource, identity match, readiness green, advertisement, or old call receipt is not current service authority.

## Revision 151 inspirations: content addresses and dedup without membership or authority leaks

- **Venti / Foundation CAS**: immutable content-addressed blocks and idempotent writes are useful storage mechanisms; they are not object authority.
- **IPFS CIDs**: self-describing content identifiers prove the addressing profile matters; a CID is not a portal ticket, trust clearance, or live handle.
- **Nix content-addressed store**: store-object/closure identity can coexist with other identity modes; ViewFS should not invent one universal hash myth.
- **Tahoe-LAFS convergence secrets**: convergence domains are security boundaries, not hidden implementation details.
- **Proofs of ownership / DupLESS**: client-side dedup and message-locked encryption can need stronger proof/key-server lanes; knowing a digest is not enough.
- **ZFS dedup / KSM**: dedup has operational cost and isolation side-channel posture; storage density is not free semantics.
- **SlopOS / Foundry / Ward / Helm / Schell / Harbor**: sibling-cube pressure says dedupe, stable core digests, change digests, cache epochs, and duplicate horizons all need explicit posture.

Nifty ViewFS steal: **digest shades**, **equality rails**, **dedup shutters**, **convergence lamps**, **cache ghosts**, **possession challenge cards**, **leakage meters**, **unshare ladders**, and **membership-safe receipts**.

Guardrail: a digest, CID, content hash, cache hit, dedup table row, convergence output, duplicate suppression key, or old materialization receipt is not object identity, ownership proof, trust clearance, publication, retention, or live authority.


### L152. Semantic retrieval is a derived-view system, not authority
- REF-APPLE-SPOTLIGHT-PRIVACY, REF-GNOME-LOCALSEARCH, REF-PINECONE-MULTITENANCY, REF-WEAVIATE-MULTITENANCY, REF-ACL-TEXT-EMBEDDINGS-REVEAL, REF-OWASP-LLM08-VECTOR-EMBEDDING, and REF-SLOPOS-SEMANTIC-DERIVATION-SEAMS point to the same lesson: indexing, embeddings, query stores, result projections, and answers are derived/explanatory planes.
- What to steal: searchable scope gates, embedding vaults, model-profile chips, result shades, answer receipts, instruction-quarantine rails, memory shutters, and unindex ladders.
- What not to steal: a global ambient index, one universal vector store, metadata-filter-as-ACL, background semantic extraction from risky content, or old answer cards as agent memory.
## Revision 153 inspirations: instruction hygiene without prompt authority

- **OWASP LLM01**: prompt injection belongs in the core threat model; do not treat it as prompt polish.
- **OpenAI prompt-injection guidance**: third-party context can mislead agents, and robustness remains a hard evolving problem.
- **Microsoft and Google indirect-prompt-injection guidance**: assume untrusted content can influence model behavior; isolate and contain rather than trusting perfect filtering.
- **MCP**: resources, prompts, tools, sampling, roots, and elicitation are useful separate primitives, and the spec's own security text warns that tool metadata and tool calls need explicit consent/control.
- **VS Code AI customization**: workspace instructions, prompt files, agents, skills, hooks, MCP servers, and parent-repo discovery are strong UX precedents and equally strong scope/trust warnings.
- **Instruction hierarchy research**: source/priority labels help models, but do not replace validators and live-handle checks.
- **SlopOS D-LLM / MCP / tool-UI boundaries**: sibling-cube pressure says text is proposal-only and widgets/tools cannot open hidden authority paths.

Nifty ViewFS steal: **instruction ladders**, **context shutters**, **inert-text rails**, **proposal badges**, **plan compiler cards**, **toolcall fuses**, **approval-basis drawers**, **result quarantine**, **memory promotion shutters**, and **prompt receipt ghosts**.

Guardrail: a prompt, workspace instruction, retrieved imperative passage, tool description, structured tool result, model output, or old prompt receipt is not policy, approval, current fact, live authority, or future memory by itself.

## Revision 154 inspirations: consent cards without click-to-authority folklore

- **EROS Trusted Window System**: robust traceability of user volition is exactly the capability-UX lesson ViewFS needs, but the early steal is the seam, not a whole window system.
- **HTML user activation**: sticky, transient, transient-consuming, and history-action activation prove that recent interaction is timed and classed, not standing permission.
- **Wayland xdg-activation**: activation tokens can carry focus-transfer intent and still be refused; a token is a request witness, not a guaranteed foreground or authority grant.
- **Windows Secure Attention Sequence**: trusted credential UI requires a path normal apps cannot spoof; ViewFS should not pretend ordinary focus is enough for every high-risk approval.
- **WebAuthn / CTAP**: user presence and user verification are different flags in a scoped ceremony; neither is a general ViewFS consent receipt.
- **OWASP clickjacking defenses**: UI redress is real; presentation surfaces need provenance and embedding/capture posture.
- **SlopOS D-VOLITION / D-POWERBOX**: fresh local one-shot volition evidence can feed consent mediators without becoming a portable capability.

Nifty ViewFS steal: **consent cards**, **canonical-summary digests**, **trusted-path lamps**, **gesture chips**, **volition-token beads**, **clickjacking shields**, **approval-cut drawers**, **remote/headless issuer badges**, and **receipt ghosts**.

Guardrail: a prompt reply, click, focus state, notification action, app-rendered card, model-rendered widget, gesture witness, old volition token, or consent receipt is not current approval or live authority by itself.
